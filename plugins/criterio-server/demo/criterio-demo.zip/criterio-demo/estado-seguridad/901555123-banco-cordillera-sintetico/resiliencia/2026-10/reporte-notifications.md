# Las notificaciones · Banco Cordillera Sintético · periodo 2026-10

**Entidad:** Banco Cordillera Sintético (901555123) · **Fecha de corte:** 2026-10-15 · **Procesado:** 2026-10-15 · **Agente:** Amparo, versión 1.2.0 · **Comando:** `notifications`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una notificación que pide la matriz —al supervisor, a la autoridad de datos, a los clientes— se hizo tarde o no se hizo (`incident_notification_late`) | INC-BCO-103 → Superintendencia Financiera: notificado el 2026-09-23T13:30, 6 horas después del plazo de 24 horas (Reglamento sectorial de ciberseguridad (sintético)) | — | — | — | `00-referencia/matriz-notificaciones.csv` fila 2 · `70-incidentes/INC-BCO-103_notificacion-superintendencia-financiera.pdf` |
| 2 | Una notificación que pide la matriz —al supervisor, a la autoridad de datos, a los clientes— se hizo tarde o no se hizo (`incident_notification_late`) | INC-BCO-104 → Clientes afectados: la matriz pide notificar en 72 horas (Política de comunicación con clientes) y la ficha no registra la notificación | — | — | — | `00-referencia/matriz-notificaciones.csv` fila 4 · `70-incidentes/INC-BCO-104_informe.docx` |

## El resultado

| Incidente | Destinatario | Norma | Tope | Hecha | A tiempo |
|---|---|---|---|---|---|
| INC-BCO-105 | Comité de riesgos | Política de respuesta a incidentes | 2026-08-20T10:00 | 2026-08-18T22:00 | sí |
| INC-BCO-101 | Superintendencia Financiera | Reglamento sectorial de ciberseguridad (sintético) | 2026-09-04T09:10 | 2026-09-04T09:10 | sí |
| INC-BCO-101 | Comité de riesgos | Política de respuesta a incidentes | 2026-09-05T09:10 | 2026-09-03T15:10 | sí |
| INC-BCO-102 | Comité de riesgos | Política de respuesta a incidentes | 2026-09-12T14:00 | 2026-09-11T00:00 | sí |
| INC-BCO-103 | Superintendencia Financiera | Reglamento sectorial de ciberseguridad (sintético) | 2026-09-23T07:30 | 2026-09-23T13:30 | no |
| INC-BCO-103 | Autoridad de protección de datos | Ley de protección de datos (sintética) | 2026-09-25T07:30 | 2026-09-23T23:30 | sí |
| INC-BCO-103 | Comité de riesgos | Política de respuesta a incidentes | 2026-09-24T07:30 | 2026-09-22T12:30 | sí |
| INC-BCO-106 | Comité de riesgos | Política de respuesta a incidentes | 2026-09-30T16:45 | 2026-09-28T20:45 | sí |
| INC-BCO-104 | Clientes afectados | Política de comunicación con clientes | 2026-10-04T11:00 | — | no |
| INC-BCO-104 | Comité de riesgos | Política de respuesta a incidentes | 2026-10-03T11:00 | 2026-10-01T19:00 | sí |

La matriz es de la organización: los destinatarios y los plazos que exige cada norma los fija ella. Ninguna notificación la hace el agente.

## Lo que no se pudo procesar

- `00-referencia/credenciales-vpn.txt`: excluido por omisión: por su nombre es una credencial o una llave
- `10-controles/A.8.24_certificados/servidor-web.pem`: excluido por omisión: .pem es una llave, una credencial o un respaldo
- `90-continuidad/respaldo-correo-2026-06-20.zip`: excluido por omisión: .zip es una llave, una credencial o un respaldo

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/matriz-notificaciones.csv`
- `70-incidentes/INC-BCO-103_notificacion-superintendencia-financiera.pdf`
- `70-incidentes/INC-BCO-104_informe.docx`
