# Las revisiones de acceso · Banco Cordillera Sintético · periodo 2026-10

**Entidad:** Banco Cordillera Sintético (901555123) · **Fecha de corte:** 2026-10-15 · **Procesado:** 2026-10-15 · **Agente:** Alexis, versión 1.2.0 · **Comando:** `access-reviews`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | La revisión de accesos de un sistema pasó su fecha, o no hay ninguna (`access_review_overdue`) | Directorio activo: la última revisión de accesos es del 2026-06-30; tocaba el 2026-09-28 | — | Jefe de seguridad de la información | 17 | `00-referencia/sistemas.csv` fila 4 · `20-accesos/revision-accesos_directorio-activo_2026-06-30.pdf` |
| 2 | La revisión de accesos de un sistema pasó su fecha, o no hay ninguna (`access_review_overdue`) | Portal de clientes: ninguna revisión de accesos registrada; la tabla pide una cada 180 días | — | Jefe de seguridad de la información | — | `00-referencia/sistemas.csv` fila 5 |

## El resultado

| Sistema | Cada | Última revisión | Tocaba | Responsable |
|---|---|---|---|---|
| Core bancario | 90 días | 2026-08-10 | 2026-11-08 | Jefe de seguridad de la información |
| Correo corporativo | 180 días | 2026-05-02 | 2026-10-29 | Jefe de seguridad de la información |
| Directorio activo | 90 días | 2026-06-30 | 2026-09-28 | Jefe de seguridad de la información |
| Portal de clientes | 180 días | — | — | Jefe de seguridad de la información |

## Lo que no se pudo procesar

- `00-referencia/credenciales-vpn.txt`: excluido por omisión: por su nombre es una credencial o una llave
- `10-controles/A.8.24_certificados/servidor-web.pem`: excluido por omisión: .pem es una llave, una credencial o un respaldo
- `90-continuidad/respaldo-correo-2026-06-20.zip`: excluido por omisión: .zip es una llave, una credencial o un respaldo

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/sistemas.csv`
- `20-accesos/revision-accesos_directorio-activo_2026-06-30.pdf`
