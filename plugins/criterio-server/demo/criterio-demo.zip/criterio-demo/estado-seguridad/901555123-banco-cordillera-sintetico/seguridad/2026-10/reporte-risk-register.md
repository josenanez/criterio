# El registro de riesgos · Banco Cordillera Sintético · periodo 2026-10

**Entidad:** Banco Cordillera Sintético (901555123) · **Fecha de corte:** 2026-10-15 · **Procesado:** 2026-10-15 · **Agente:** Alexis, versión 1.2.3 · **Comando:** `risk-register`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una aceptación de riesgo pasó su fecha de revisión (`risk_acceptance_expired`) | R-03 · Respaldo fuera de sitio a más de 24 horas: aceptado por Comité de riesgos hasta el 2026-09-30, y no se volvió a revisar | — | Comité de riesgos | 15 | `40-riesgos/registro-riesgos.csv` fila 4 |

## El resultado

| Riesgo | Decisión | Aceptado por | Revisión |
|---|---|---|---|
| R-01 · Sistema heredado sin soporte del fabricante | Aceptar | Gerente general | 2026-12-31 |
| R-02 · Correo sin doble factor para proveedores | Mitigar | — | 2026-12-31 |
| R-03 · Respaldo fuera de sitio a más de 24 horas | Aceptar | Comité de riesgos | 2026-09-30 |
| R-04 · Equipos personales en la red de invitados | Aceptar | Gerente de tecnología | 2026-10-15 |

Ningún riesgo lo acepta el agente: aquí se dice qué aceptación pasó su fecha de revisión.

## Lo que no se pudo procesar

- `00-referencia/credenciales-vpn.txt`: excluido por omisión: por su nombre es una credencial o una llave
- `10-controles/A.8.24_certificados/servidor-web.pem`: excluido por omisión: .pem es una llave, una credencial o un respaldo
- `90-continuidad/respaldo-correo-2026-06-20.zip`: excluido por omisión: .zip es una llave, una credencial o un respaldo

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `40-riesgos/registro-riesgos.csv`
