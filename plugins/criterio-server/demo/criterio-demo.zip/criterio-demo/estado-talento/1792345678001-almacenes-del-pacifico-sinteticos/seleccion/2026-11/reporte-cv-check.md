# Las hojas de vida contra sus soportes · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Cándido, versión 1.1.0 · **Comando:** `cv-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | La hoja de vida afirma un título, una certificación o un empleo sin el documento que lo soporte (`claim_without_support`) | CAN-602: el título «Licenciatura en administración de empresas» no tiene el documento que lo soporte | — | — | — | `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf` |
| 2 | Las fechas de un empleo en la hoja de vida no son las de su certificado laboral (`employment_dates_differ`) | CAN-603: el empleo «Analista en Comercial Andina Sintética»: retiro 2022-08 en la hoja de vida y 2021-12 en el certificado | — | — | — | `30-candidatos/VAC-51/CAN-603/hoja-de-vida.pdf` · `30-candidatos/VAC-51/CAN-603/certificado-laboral.pdf` |
| 3 | Las fechas de un empleo en la hoja de vida no son las de su certificado laboral (`employment_dates_differ`) | CAN-610: el empleo «Analista en Comercial Andina Sintética»: ingreso 2018-01 en la hoja de vida y 2018-06 en el certificado | — | — | — | `30-candidatos/VAC-51/CAN-610/hoja-de-vida.pdf` · `30-candidatos/VAC-51/CAN-610/certificado-laboral.pdf` |

## El resultado

| Candidato | Vacante | Afirmaciones |
|---|---|---|
| CAN-601 | VAC-51 | 2 |
| CAN-602 | VAC-51 | 2 |
| CAN-603 | VAC-51 | 2 |
| CAN-604 | VAC-51 | 2 |
| CAN-605 | VAC-51 | 2 |
| CAN-606 | VAC-51 | 2 |
| CAN-607 | VAC-52 | 2 |
| CAN-608 | VAC-52 | 0 |
| CAN-609 | VAC-53 | 2 |
| CAN-610 | VAC-51 | 2 |

Cada afirmación se contrasta con su soporte; ninguna se da por falsa: se dice cuál no tiene soporte o no coincide.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf`
- `30-candidatos/VAC-51/CAN-603/certificado-laboral.pdf`
- `30-candidatos/VAC-51/CAN-603/hoja-de-vida.pdf`
- `30-candidatos/VAC-51/CAN-610/certificado-laboral.pdf`
- `30-candidatos/VAC-51/CAN-610/hoja-de-vida.pdf`
