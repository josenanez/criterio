# Las vacantes contra su plazo · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Cándido, versión 1.1.0 · **Comando:** `vacancy-status`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una vacante sigue abierta después del plazo de cobertura de la política (`vacancy_past_target`) | VAC-51 · PT-01: abierta desde el 2026-09-15; la política da 30 días y el plazo venció el 2026-10-15 | — | Gabriela Andrade | 32 | `20-vacantes/registro-vacantes.xlsx` fila 2 |
| 2 | Una vacante sigue abierta después del plazo de cobertura de la política (`vacancy_past_target`) | VAC-54 · PT-04: abierta desde el 2026-10-01; la política da 30 días y el plazo venció el 2026-10-31 | — | Gabriela Andrade | 16 | `20-vacantes/registro-vacantes.xlsx` fila 5 |

## El resultado

| Vacante | Perfil | Apertura | Plazo | Tope | Cierre | Días | Responsable |
|---|---|---|---|---|---|---|---|
| VAC-51 | PT-01 | 2026-09-15 | 30 días | 2026-10-15 | — | 62 | Gabriela Andrade |
| VAC-52 | PT-03 | 2026-10-25 | 30 días | 2026-11-24 | — | 22 | Gabriela Andrade |
| VAC-53 | PT-02 | 2026-03-01 | 30 días | 2026-03-31 | 2026-04-10 | 40 | Gabriela Andrade |
| VAC-54 | PT-04 | 2026-10-01 | 30 días | 2026-10-31 | — | 46 | Gabriela Andrade |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `20-vacantes/registro-vacantes.xlsx`
