# Cada candidato contra el perfil · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Cándido, versión 1.1.0 · **Comando:** `candidate-fit`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un requisito esencial del perfil no tiene evidencia ni en la hoja de vida ni en sus soportes (`requirement_not_evidenced`) | CAN-601: el requisito esencial R1 «Escucha activa con el cliente» del perfil PT-01 no tiene evidencia ni en la hoja de vida ni en sus soportes | — | — | — | `30-candidatos/VAC-51/CAN-601/hoja-de-vida.pdf` |
| 2 | Un requisito esencial del perfil no tiene evidencia ni en la hoja de vida ni en sus soportes (`requirement_not_evidenced`) | CAN-608: el requisito esencial R1 «Coordinación del equipo de ventas» del perfil PT-03 no tiene evidencia ni en la hoja de vida ni en sus soportes | — | — | — | `30-candidatos/VAC-52/CAN-608/hoja-de-vida.pdf` |

## El resultado

### CAN-601 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 0 | no | — |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-601/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-602 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-603 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-603/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-603/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-604 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-604/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-604/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-605 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-605/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-605/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-606 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-606/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-606/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

### CAN-607 · vacante VAC-52 · perfil PT-03

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Coordinación del equipo de ventas | sí | 1 | no | `30-candidatos/VAC-52/CAN-607/hoja-de-vida.pdf, p. 1` |
| R2 · Percepción social | no | 0 | no | — |
| R3 · Ventas y mercadeo | no | 0 | no | — |
| R4 · Profesar la religión católica | no | 0 | no | — |

### CAN-608 · vacante VAC-52 · perfil PT-03

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Coordinación del equipo de ventas | sí | 0 | no | — |
| R2 · Percepción social | no | 0 | no | — |
| R3 · Ventas y mercadeo | no | 0 | no | — |
| R4 · Profesar la religión católica | no | 0 | no | — |

### CAN-609 · vacante VAC-53 · perfil PT-02

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | no | 0 | no | — |
| R2 · Matemáticas para el arqueo de caja | no | 0 | no | — |
| R3 · Servicio al cliente | no | 0 | no | — |

### CAN-610 · vacante VAC-51 · perfil PT-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Escucha activa con el cliente | sí | 1 | no | `30-candidatos/VAC-51/CAN-610/hoja-de-vida.pdf, p. 1` |
| R2 · Matemáticas para el arqueo de caja | sí | 1 | no | `30-candidatos/VAC-51/CAN-610/hoja-de-vida.pdf, p. 1` |
| R3 · Buena presencia | no | 0 | no | — |

Los candidatos van en el orden de su identificador. No hay puntaje ni orden por número: quien selecciona decide.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `30-candidatos/VAC-51/CAN-601/hoja-de-vida.pdf`
- `30-candidatos/VAC-52/CAN-608/hoja-de-vida.pdf`
