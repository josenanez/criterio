# La autorización y la conservación de los datos · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Cándido, versión 1.1.0 · **Comando:** `privacy-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Los datos de un candidato pasaron el tiempo de conservación de la política y siguen en la carpeta (`retention_exceeded`) | CAN-609: su proceso terminó el 2026-06-09; la política conserva los datos 120 días, hasta el 2026-10-07, y siguen en la carpeta | — | — | 40 | `50-ats/exportacion-ats.csv` fila 10 · `30-candidatos/VAC-53/CAN-609/hoja-de-vida.pdf` |
| 2 | No hay autorización de tratamiento de datos del candidato, o es posterior a recibir sus datos (`consent_missing`) | CAN-604: no está en el registro de autorizaciones de tratamiento de datos | — | — | — | `30-candidatos/VAC-51/CAN-604/hoja-de-vida.pdf` |
| 3 | No hay autorización de tratamiento de datos del candidato, o es posterior a recibir sus datos (`consent_missing`) | CAN-607: la autorización es del 2026-09-17, después de recibir sus datos el 2026-09-05 | — | — | — | `40-autorizaciones/registro-autorizaciones.csv` fila 7 · `30-candidatos/VAC-52/CAN-607/hoja-de-vida.pdf` |
| 4 | Llegó un dato que no se debe tratar —fotografía, edad, documento de identidad, salud—, y se excluye del análisis (`protected_data_received`) | CAN-602: llegó fotografia; se excluye del análisis y no se usa para nada | — | — | — | `30-candidatos/VAC-51/CAN-602/foto.jpg` · `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf` |
| 5 | Llegó un dato que no se debe tratar —fotografía, edad, documento de identidad, salud—, y se excluye del análisis (`protected_data_received`) | CAN-606: llegó fecha de nacimiento; se excluye del análisis y no se usa para nada | — | — | — | `30-candidatos/VAC-51/CAN-606/hoja-de-vida.pdf` |
| 6 | Llegó un dato que no se debe tratar —fotografía, edad, documento de identidad, salud—, y se excluye del análisis (`protected_data_received`) | CAN-606: llegó fotografia; se excluye del análisis y no se usa para nada | — | — | — | `30-candidatos/VAC-51/CAN-606/foto.jpg` · `30-candidatos/VAC-51/CAN-606/hoja-de-vida.pdf` |

## El resultado

**Conservación de la política:** 120 días.

| Candidato | Recibido | Autorización | Estado | Conservar hasta | Excluido |
|---|---|---|---|---|---|
| CAN-601 | 2026-09-05 | 2026-09-05 | Entrevista | — | — |
| CAN-602 | 2026-09-05 | 2026-09-05 | Entrevista | — | fotografia |
| CAN-603 | 2026-09-05 | 2026-09-05 | Entrevista | — | — |
| CAN-604 | 2026-09-05 | — | Entrevista | — | — |
| CAN-605 | 2026-09-05 | 2026-09-05 | Entrevista | — | — |
| CAN-606 | 2026-09-05 | 2026-09-05 | Entrevista | — | fecha de nacimiento, fotografia |
| CAN-607 | 2026-09-05 | 2026-09-17 | Entrevista | — | — |
| CAN-608 | 2026-09-05 | 2026-09-05 | Entrevista | — | — |
| CAN-609 | 2026-03-01 | 2026-03-01 | No seleccionado | 2026-10-07 | — |
| CAN-610 | 2026-09-05 | 2026-09-05 | Entrevista | — | — |

Lo excluido no se copia ni se usa: aquí solo se dice que llegó.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `30-candidatos/VAC-51/CAN-602/foto.jpg`
- `30-candidatos/VAC-51/CAN-602/hoja-de-vida.pdf`
- `30-candidatos/VAC-51/CAN-604/hoja-de-vida.pdf`
- `30-candidatos/VAC-51/CAN-606/foto.jpg`
- `30-candidatos/VAC-51/CAN-606/hoja-de-vida.pdf`
- `30-candidatos/VAC-52/CAN-607/hoja-de-vida.pdf`
- `30-candidatos/VAC-53/CAN-609/hoja-de-vida.pdf`
- `40-autorizaciones/registro-autorizaciones.csv`
- `50-ats/exportacion-ats.csv`
