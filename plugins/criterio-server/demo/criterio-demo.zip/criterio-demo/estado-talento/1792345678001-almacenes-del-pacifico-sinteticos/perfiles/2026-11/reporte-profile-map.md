# El mapa de los perfiles · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Norma, versión 1.1.0 · **Comando:** `profile-map`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Dos perfiles comparten la ocupación y la mayor parte de sus requisitos (`profiles_overlap`) | PT-01 · Cajero de tienda y PT-02 · Cajero de autoservicio: la misma ocupación 41-2011.00 y 67 % de los requisitos en común | — | — | — | `10-perfiles/PT-01_cajero-de-tienda.docx` · `10-perfiles/PT-02_cajero-de-autoservicio.docx` |

## El resultado

| Perfil | Ocupación |
|---|---|
| PT-01 · Cajero de tienda | 41-2011.00 · Cashiers (synthetic) |
| PT-02 · Cajero de autoservicio | 41-2011.00 · Cashiers (synthetic) |
| PT-03 · Supervisor de tienda | 41-1011.00 · First-Line Supervisors of Retail Sales Workers (synthetic) |
| PT-04 · Almacenista | — |

| Se solapan | Ocupación | En común |
|---|---|---|
| PT-01 y PT-02 | 41-2011.00 | 67 % |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-perfiles/PT-01_cajero-de-tienda.docx`
- `10-perfiles/PT-02_cajero-de-autoservicio.docx`
- Fuentes técnicas: F-02, F-14 (families/criterio-chro/FUENTES.es.md)
