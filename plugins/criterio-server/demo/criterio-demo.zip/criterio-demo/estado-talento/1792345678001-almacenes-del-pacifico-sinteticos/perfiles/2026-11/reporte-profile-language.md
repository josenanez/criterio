# Lo que un perfil no puede pedir · Almacenes del Pacífico Sintéticos · periodo 2026-11

**Entidad:** Almacenes del Pacífico Sintéticos (1792345678001) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Norma, versión 1.1.0 · **Comando:** `profile-language`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PT-01 · Cajero de tienda: el requisito R3 «Buena presencia» pide apariencia, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PT-01_cajero-de-tienda.docx` |
| 2 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PT-03 · Supervisor de tienda: el requisito R4 «Profesar la religión católica» pide la religión o las convicciones, que no se puede pedir según Ley Orgánica de Protección de Datos Personales, art. 4 (F-14) | — | — | — | `10-perfiles/PT-03_supervisor-de-tienda.docx` |
| 3 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PT-04 · Almacenista: el requisito R2 «Mujer entre 20 y 30 años» pide edad, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PT-04_almacenista.docx` |
| 4 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PT-04 · Almacenista: el requisito R2 «Mujer entre 20 y 30 años» pide sexo, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PT-04_almacenista.docx` |

## El resultado

**Lo que no se puede pedir:**

- El origen racial o étnico: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La identidad de género: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La religión o las convicciones: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La opinión o la afiliación política: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- El pasado judicial: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La condición migratoria: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La vida o la orientación sexual: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- La salud: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- Los datos biométricos: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- Los datos genéticos: Ley Orgánica de Protección de Datos Personales, art. 4 (F-14)
- edad: la política de selección de la organización
- sexo: la política de selección de la organización
- estado civil: la política de selección de la organización
- fotografía: la política de selección de la organización
- apariencia: la política de selección de la organización

| Perfil | Requisitos que piden algo que no se puede pedir |
|---|---|
| PT-01 · Cajero de tienda | R3 |
| PT-02 · Cajero de autoservicio | — |
| PT-03 · Supervisor de tienda | R4 |
| PT-04 · Almacenista | R2, R2 |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-perfiles/PT-01_cajero-de-tienda.docx`
- `10-perfiles/PT-03_supervisor-de-tienda.docx`
- `10-perfiles/PT-04_almacenista.docx`
- Fuentes técnicas: F-14 (families/criterio-chro/FUENTES.es.md)
