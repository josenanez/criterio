# Lo que un perfil no puede pedir · Banco Cordillera Sintético · periodo 2026-11

**Entidad:** Banco Cordillera Sintético (901555123) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Norma, versión 1.1.0 · **Comando:** `profile-language`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PC-02 · Contador de impuestos: el requisito R5 «Hombre menor de 35 años» pide edad, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PC-02_contador-de-impuestos.docx` |
| 2 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PC-02 · Contador de impuestos: el requisito R5 «Hombre menor de 35 años» pide sexo, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PC-02_contador-de-impuestos.docx` |
| 3 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PC-04 · Analista de crédito: el requisito R4 «Gozar de buen estado de salud» pide la salud, que no se puede pedir según Ley 1581 de 2012, art. 5 (F-10) | — | — | — | `10-perfiles/PC-04_analista-de-credito.docx` |
| 4 | Un requisito pide un dato sensible según la ley del país, o algo que la política de selección prohíbe pedir (`requirement_not_allowed`) | PC-06 · Coordinador de cobranzas: el requisito R2 «Estado civil casado» pide estado civil, que no se puede pedir según la política de selección de la organización | — | — | — | `10-perfiles/PC-06_coordinador-de-cobranzas.docx` |

## El resultado

**Lo que no se puede pedir:**

- El origen racial o étnico: Ley 1581 de 2012, art. 5 (F-10)
- La opinión o la afiliación política: Ley 1581 de 2012, art. 5 (F-10)
- La religión o las convicciones: Ley 1581 de 2012, art. 5 (F-10)
- La afiliación sindical: Ley 1581 de 2012, art. 5 (F-10)
- La salud: Ley 1581 de 2012, art. 5 (F-10)
- La vida o la orientación sexual: Ley 1581 de 2012, art. 5 (F-10)
- Los datos biométricos: Ley 1581 de 2012, art. 5 (F-10)
- edad: la política de selección de la organización
- sexo: la política de selección de la organización
- estado civil: la política de selección de la organización
- fotografía: la política de selección de la organización

| Perfil | Requisitos que piden algo que no se puede pedir |
|---|---|
| PC-01 · Contador | — |
| PC-02 · Contador de impuestos | R5, R5 |
| PC-03 · Auxiliar contable | — |
| PC-04 · Analista de crédito | R4 |
| PC-05 · Cajero | — |
| PC-06 · Coordinador de cobranzas | R2 |
| PC-07 · Director financiero | — |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-perfiles/PC-02_contador-de-impuestos.docx`
- `10-perfiles/PC-04_analista-de-credito.docx`
- `10-perfiles/PC-06_coordinador-de-cobranzas.docx`
- Fuentes técnicas: F-10 (families/criterio-chro/FUENTES.es.md)
