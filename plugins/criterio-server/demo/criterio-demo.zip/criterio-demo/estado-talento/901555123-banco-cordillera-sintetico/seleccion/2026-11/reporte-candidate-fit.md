# Cada candidato contra el perfil · Banco Cordillera Sintético · periodo 2026-11

**Entidad:** Banco Cordillera Sintético (901555123) · **Fecha de corte:** 2026-11-16 · **Procesado:** 2026-11-16 · **Agente:** Cándido, versión 1.0.0 · **Comando:** `candidate-fit`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un requisito esencial del perfil no tiene evidencia ni en la hoja de vida ni en sus soportes (`requirement_not_evidenced`) | CAN-101: el requisito esencial R1 «Contabilidad bajo NIIF» del perfil PC-01 no tiene evidencia ni en la hoja de vida ni en sus soportes | — | — | — | `30-candidatos/VAC-01/CAN-101/hoja-de-vida.pdf` |
| 2 | Un requisito esencial del perfil no tiene evidencia ni en la hoja de vida ni en sus soportes (`requirement_not_evidenced`) | CAN-108: el requisito esencial R1 «Finanzas y análisis de estados financieros» del perfil PC-04 no tiene evidencia ni en la hoja de vida ni en sus soportes | — | — | — | `30-candidatos/VAC-02/CAN-108/hoja-de-vida.pdf` |
| 3 | Un requisito esencial del perfil no tiene evidencia ni en la hoja de vida ni en sus soportes (`requirement_not_evidenced`) | CAN-108: el requisito esencial R3 «Criterio y toma de decisiones de crédito» del perfil PC-04 no tiene evidencia ni en la hoja de vida ni en sus soportes | — | — | — | `30-candidatos/VAC-02/CAN-108/hoja-de-vida.pdf` |

## El resultado

### CAN-101 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 0 | no | — |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-101/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-101/tarjeta-profesional.pdf` |

### CAN-102 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-102/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-102/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-102/tarjeta-profesional.pdf` |

### CAN-103 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-103/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-103/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-103/tarjeta-profesional.pdf` |

### CAN-104 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-104/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-104/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-104/tarjeta-profesional.pdf` |

### CAN-105 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-105/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-105/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-105/tarjeta-profesional.pdf` |

### CAN-106 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-106/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-106/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-106/tarjeta-profesional.pdf` |

### CAN-107 · vacante VAC-02 · perfil PC-04

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Finanzas y análisis de estados financieros | sí | 1 | no | `30-candidatos/VAC-02/CAN-107/hoja-de-vida.pdf, p. 1` |
| R2 · Contabilidad | no | 0 | no | — |
| R3 · Criterio y toma de decisiones de crédito | sí | 1 | no | `30-candidatos/VAC-02/CAN-107/hoja-de-vida.pdf, p. 1` |
| R4 · Gozar de buen estado de salud | no | 0 | no | — |

### CAN-108 · vacante VAC-02 · perfil PC-04

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Finanzas y análisis de estados financieros | sí | 0 | no | — |
| R2 · Contabilidad | no | 0 | no | — |
| R3 · Criterio y toma de decisiones de crédito | sí | 0 | no | — |
| R4 · Gozar de buen estado de salud | no | 0 | no | — |

### CAN-109 · vacante VAC-03 · perfil PC-03

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Comprensión de lectura de documentos contables | no | 0 | no | — |
| R2 · Contabilidad básica | sí | 1 | no | `30-candidatos/VAC-03/CAN-109/hoja-de-vida.pdf, p. 1` |

### CAN-110 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-110/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-110/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | sí | `30-candidatos/VAC-01/CAN-110/tarjeta-profesional.pdf` |

### CAN-111 · vacante VAC-01 · perfil PC-01

| Requisito | Esencial | Evidencias | Con soporte | Dónde |
|---|---|---|---|---|
| R1 · Contabilidad bajo NIIF | sí | 1 | no | `30-candidatos/VAC-01/CAN-111/hoja-de-vida.pdf, p. 1` |
| R2 · Análisis de procesos contables | sí | 1 | no | `30-candidatos/VAC-01/CAN-111/hoja-de-vida.pdf, p. 1` |
| R3 · Evaluación y control de actividades del área | no | 0 | no | — |
| R4 · Tarjeta profesional de contador vigente | sí | 2 | no | `30-candidatos/VAC-01/CAN-111/hoja-de-vida.pdf`, `30-candidatos/VAC-01/CAN-111/hoja-de-vida.pdf, p. 1` |

Los candidatos van en el orden de su identificador. No hay puntaje ni orden por número: quien selecciona decide.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `30-candidatos/VAC-01/CAN-101/hoja-de-vida.pdf`
- `30-candidatos/VAC-02/CAN-108/hoja-de-vida.pdf`
