# Cada promoción con sus condiciones · Almacenes del Valle Sintéticos · periodo 2026-10

**Entidad:** Almacenes del Valle Sintéticos (901333555) · **Fecha de corte:** 2026-11-25 · **Procesado:** 2026-11-25 · **Agente:** Lucía, versión 1.2.0 · **Comando:** `promo-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una promoción no publica su vigencia o sus condiciones de modo y lugar (`promotion_terms_missing`) | Cumpleaños: sus bases no publican el fin | — | — | — | `30-promociones/bases_promocion_cumpleanos.pdf` |
| 2 | Una promoción no publica su vigencia o sus condiciones de modo y lugar (`promotion_terms_missing`) | Puntos dobles: sus bases no publican el fin | — | — | — | `30-promociones/bases_promocion_puntos_dobles.pdf` |
| 3 | Una promoción no publica su vigencia o sus condiciones de modo y lugar (`promotion_terms_missing`) | Regreso a clases: sus bases no publican las condiciones de modo y lugar | — | — | — | `30-promociones/bases_promocion_regreso_a_clases.pdf` |

## El resultado

| Promoción | Inicio | Fin | Condiciones de modo y lugar | Bases |
|---|---|---|---|---|
| Navidad | 2026-12-01 | 2026-12-24 | sí | `30-promociones/bases_promocion_navidad.pdf` |
| Puntos dobles | 2026-11-01 | — | sí | `30-promociones/bases_promocion_puntos_dobles.pdf` |
| Cumpleaños | 2026-10-01 | — | sí | `30-promociones/bases_promocion_cumpleanos.pdf` |
| Regreso a clases | 2026-10-15 | 2026-11-15 | no | `30-promociones/bases_promocion_regreso_a_clases.pdf` |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `30-promociones/bases_promocion_cumpleanos.pdf`
- `30-promociones/bases_promocion_puntos_dobles.pdf`
- `30-promociones/bases_promocion_regreso_a_clases.pdf`
- Fuentes técnicas: F-01, F-10 (families/criterio-cmo/FUENTES.es.md)
