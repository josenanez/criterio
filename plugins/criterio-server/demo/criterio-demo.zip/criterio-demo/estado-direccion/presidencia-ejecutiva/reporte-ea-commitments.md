# Compromisos · Banco del Istmo · al 2026-10-26 · oficina de Presidencia ejecutiva

**Entidad:** Banco del Istmo · **Fecha de corte:** 2026-10-26 · **Procesado:** 2026-10-26 · **Agente:** Ofelia, versión 1.6.0 · **Comando:** `ea-commitments`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-ejecutivo del 2026-10-05, C-1: «Entregar el informe 1 de seguimiento» de Gisela Barrios venció el 2026-10-12 y ningún documento lo sostiene como cumplido | — | Gisela Barrios | 14 | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 20` |
| 2 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-ejecutivo del 2026-10-05, C-2: «Entregar el informe 2 de seguimiento» de Fernando Arosemena venció el 2026-10-13 y ningún documento lo sostiene como cumplido | — | Fernando Arosemena | 13 | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 21` |
| 3 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-ejecutivo del 2026-10-05, C-3: «Entregar el informe 3 de seguimiento» de Yariela Castillo venció el 2026-10-14 y ningún documento lo sostiene como cumplido | — | Yariela Castillo | 12 | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 22` |
| 4 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-ejecutivo del 2026-10-05, C-4: «Entregar el informe 4 de seguimiento» de Eduardo Motta venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Eduardo Motta | 11 | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 23` |
| 5 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | junta-directiva del 2026-09-24, C-1: «Presentar el informe de cartera vencida» de Fernando Arosemena venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Fernando Arosemena | 11 | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14` |
| 6 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-ejecutivo del 2026-10-05, C-5: «Entregar el informe 5 de seguimiento» de Gisela Barrios venció el 2026-10-16 y ningún documento lo sostiene como cumplido | — | Gisela Barrios | 10 | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 24` |
| 7 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-ejecutivo del 2026-10-05, C-6: «Presentar el plan 6 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-04) | — | Fernando Arosemena | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 25` |
| 8 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-ejecutivo del 2026-10-05, C-7: «Presentar el plan 7 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-05) | — | Yariela Castillo | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 26` |
| 9 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-ejecutivo del 2026-10-05, C-8: «Presentar el plan 8 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-06) | — | Eduardo Motta | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 27` |
| 10 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | junta-directiva del 2026-09-24, C-2: «Entregar el plan de continuidad del negocio» se movió 3 veces (2026-10-15, 2026-10-30, 2026-11-20) | — | Eduardo Motta | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15` |
| 11 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-ejecutivo del 2026-10-05, A-10: «Renovar las pólizas de la sede» no tiene fecha | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 17` |
| 12 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-ejecutivo del 2026-10-05, A-6: «Definir el plan de capacitación» no tiene fecha | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 13` |
| 13 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-ejecutivo del 2026-10-05, A-7: «Ajustar el presupuesto de mercadeo» no tiene fecha | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 14` |
| 14 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-ejecutivo del 2026-10-05, A-8: «Contratar la consultoría de procesos» no tiene fecha | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 15` |
| 15 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-ejecutivo del 2026-10-05, A-9: «Migrar el archivo documental» no tiene fecha | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 16` |
| 16 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | junta-directiva del 2026-09-24, A-3: «Contratar la auditoría del sistema de pagos» no tiene fecha | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11` |
| 17 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-ejecutivo del 2026-10-05, A-1: «Renovar las pólizas de la sede» no tiene responsable | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 8` |
| 18 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-ejecutivo del 2026-10-05, A-2: «Publicar el informe de sostenibilidad» no tiene responsable | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 9` |
| 19 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-ejecutivo del 2026-10-05, A-3: «Actualizar el manual de compras» no tiene responsable | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 10` |
| 20 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-ejecutivo del 2026-10-05, A-4: «Revisar el tablero de indicadores» no tiene responsable | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 11` |
| 21 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-ejecutivo del 2026-10-05, A-5: «Cerrar el proyecto de nómina» no tiene responsable | — | — | — | `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 12` |
| 22 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | junta-directiva del 2026-09-24, A-2: «Actualizar la política de viajes» no tiene responsable | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10` |

## El resultado

| Órgano | Sesión | Id | Compromiso | Responsable | Vence | Veces movido | Estado |
|---|---|---|---|---|---|---|---|
| comite-ejecutivo | 2026-10-05 | C-1 | Entregar el informe 1 de seguimiento | Gisela Barrios | 2026-10-12 | 0 | vencido |
| comite-ejecutivo | 2026-10-05 | C-2 | Entregar el informe 2 de seguimiento | Fernando Arosemena | 2026-10-13 | 0 | vencido |
| comite-ejecutivo | 2026-10-05 | C-3 | Entregar el informe 3 de seguimiento | Yariela Castillo | 2026-10-14 | 0 | vencido |
| comite-ejecutivo | 2026-10-05 | C-4 | Entregar el informe 4 de seguimiento | Eduardo Motta | 2026-10-15 | 0 | vencido |
| comite-ejecutivo | 2026-10-05 | C-5 | Entregar el informe 5 de seguimiento | Gisela Barrios | 2026-10-16 | 0 | vencido |
| comite-ejecutivo | 2026-10-05 | C-6 | Presentar el plan 6 de mejora | Fernando Arosemena | 2026-12-04 | 3 | abierto |
| comite-ejecutivo | 2026-10-05 | C-7 | Presentar el plan 7 de mejora | Yariela Castillo | 2026-12-05 | 3 | abierto |
| comite-ejecutivo | 2026-10-05 | C-8 | Presentar el plan 8 de mejora | Eduardo Motta | 2026-12-06 | 3 | abierto |
| junta-directiva | 2026-09-24 | C-1 | Presentar el informe de cartera vencida | Fernando Arosemena | 2026-10-15 | 0 | vencido |
| junta-directiva | 2026-09-24 | C-2 | Entregar el plan de continuidad del negocio | Eduardo Motta | 2026-11-20 | 3 | abierto |

Cada compromiso es del acta donde nació. Un compromiso solo se da por cumplido con un documento que lo sostenga.

Se publica en Rostrum.

## Lo que no se pudo procesar

- `organos/comite-ejecutivo/2026-09-21/`: comite-ejecutivo:2026-09-21 no tiene ficha: corre ea-scan
- `organos/comite-ejecutivo/2026-10-19/`: comite-ejecutivo:2026-10-19 no tiene ficha: corre ea-scan
- `90-borradores/LEEME.txt`: un archivo en 90-borradores/ sin «BORRADOR» en el nombre

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 10`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 11`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 12`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 13`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 14`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 15`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 16`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 17`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 20`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 21`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 22`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 23`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 24`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 25`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 26`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 27`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 8`
- `organos/comite-ejecutivo/2026-10-05/40-acta/acta-firmada.md, línea 9`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15`
