# Compromisos · Banco Andino · al 2026-10-26 · oficina de Presidencia

**Entidad:** Banco Andino · **Fecha de corte:** 2026-10-26 · **Procesado:** 2026-10-26 · **Agente:** Ofelia, versión 1.2.1 · **Comando:** `ea-commitments`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-1: «Entregar el informe 1 de seguimiento» de Diana Cruz venció el 2026-10-12 y ningún documento lo sostiene como cumplido | — | Diana Cruz | 14 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 21` |
| 2 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-2: «Entregar el informe 2 de seguimiento» de Felipe Duarte venció el 2026-10-13 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 13 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 22` |
| 3 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-3: «Entregar el informe 3 de seguimiento» de Laura Gómez venció el 2026-10-14 y ningún documento lo sostiene como cumplido | — | Laura Gómez | 12 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 23` |
| 4 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-4: «Entregar el informe 4 de seguimiento» de Andrés Vela venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Andrés Vela | 11 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 24` |
| 5 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | junta-directiva del 2026-09-24, C-1: «Presentar el informe de cartera vencida» de Felipe Duarte venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 11 | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14` |
| 6 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-5: «Entregar el informe 5 de seguimiento» de Diana Cruz venció el 2026-10-16 y ningún documento lo sostiene como cumplido | — | Diana Cruz | 10 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 25` |
| 7 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-6: «Entregar el informe 6 de seguimiento» de Felipe Duarte venció el 2026-10-17 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 9 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 26` |
| 8 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-7: «Presentar el plan 7 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-04) | — | Laura Gómez | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 27` |
| 9 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-8: «Presentar el plan 8 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-05) | — | Andrés Vela | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 28` |
| 10 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-9: «Presentar el plan 9 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-06) | — | Diana Cruz | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 29` |
| 11 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | junta-directiva del 2026-09-24, C-2: «Entregar el plan de continuidad del negocio» se movió 3 veces (2026-10-15, 2026-10-30, 2026-11-20) | — | Andrés Vela | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15` |
| 12 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-10: «Renovar las pólizas de la sede» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17` |
| 13 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-11: «Publicar el informe de sostenibilidad» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18` |
| 14 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-7: «Ajustar el presupuesto de mercadeo» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14` |
| 15 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-8: «Contratar la consultoría de procesos» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15` |
| 16 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-9: «Migrar el archivo documental» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16` |
| 17 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | junta-directiva del 2026-09-24, A-3: «Contratar la auditoría del sistema de pagos» no tiene fecha | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11` |
| 18 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-1: «Renovar las pólizas de la sede» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8` |
| 19 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-2: «Publicar el informe de sostenibilidad» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9` |
| 20 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-3: «Actualizar el manual de compras» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10` |
| 21 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-4: «Revisar el tablero de indicadores» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11` |
| 22 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-5: «Cerrar el proyecto de nómina» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12` |
| 23 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-6: «Definir el plan de capacitación» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13` |
| 24 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | junta-directiva del 2026-09-24, A-2: «Actualizar la política de viajes» no tiene responsable | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10` |

## El resultado

| Órgano | Sesión | Id | Compromiso | Responsable | Vence | Veces movido | Estado |
|---|---|---|---|---|---|---|---|
| comite-de-presidencia | 2026-10-05 | C-1 | Entregar el informe 1 de seguimiento | Diana Cruz | 2026-10-12 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-2 | Entregar el informe 2 de seguimiento | Felipe Duarte | 2026-10-13 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-3 | Entregar el informe 3 de seguimiento | Laura Gómez | 2026-10-14 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-4 | Entregar el informe 4 de seguimiento | Andrés Vela | 2026-10-15 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-5 | Entregar el informe 5 de seguimiento | Diana Cruz | 2026-10-16 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-6 | Entregar el informe 6 de seguimiento | Felipe Duarte | 2026-10-17 | 0 | vencido |
| comite-de-presidencia | 2026-10-05 | C-7 | Presentar el plan 7 de mejora | Laura Gómez | 2026-12-04 | 3 | abierto |
| comite-de-presidencia | 2026-10-05 | C-8 | Presentar el plan 8 de mejora | Andrés Vela | 2026-12-05 | 3 | abierto |
| comite-de-presidencia | 2026-10-05 | C-9 | Presentar el plan 9 de mejora | Diana Cruz | 2026-12-06 | 3 | abierto |
| junta-directiva | 2026-09-24 | C-1 | Presentar el informe de cartera vencida | Felipe Duarte | 2026-10-15 | 0 | vencido |
| junta-directiva | 2026-09-24 | C-2 | Entregar el plan de continuidad del negocio | Andrés Vela | 2026-11-20 | 3 | abierto |

Cada compromiso es del acta donde nació. Un compromiso solo se da por cumplido con un documento que lo sostenga.

No se publica en Rostrum: así lo dice la configuración.

## Lo que no se pudo procesar

- `organos/comite-de-presidencia/2026-09-21/`: comite-de-presidencia:2026-09-21 no tiene ficha: corre ea-scan
- `organos/comite-de-presidencia/2026-10-19/`: comite-de-presidencia:2026-10-19 no tiene ficha: corre ea-scan
- `90-borradores/LEEME.txt`: un archivo en 90-borradores/ sin «BORRADOR» en el nombre

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 21`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 22`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 23`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 24`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 25`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 26`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 27`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 28`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 29`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15`
