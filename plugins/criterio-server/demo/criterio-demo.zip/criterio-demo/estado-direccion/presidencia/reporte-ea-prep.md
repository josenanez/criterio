# Preparar una sesión · Banco Andino · al 2026-10-26 · oficina de Presidencia

**Entidad:** Banco Andino · **Fecha de corte:** 2026-10-26 · **Procesado:** 2026-10-26 · **Agente:** Ofelia, versión 1.2.2 · **Comando:** `ea-prep`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | comite-de-presidencia, D-2: «Sede de la oficina regional» tiene plazo el 2026-11-04, en 9 días, y sigue pendiente | — | — | 9 | `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md, línea 3` |
| 2 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | comite-de-presidencia, D-1: «Proveedor de la mesa de ayuda» tiene plazo el 2026-11-03, en 8 días, y sigue pendiente | — | — | 8 | `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md, línea 3` |
| 3 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | junta-directiva, D-1: «Proveedor del centro de datos alterno» tiene plazo el 2026-11-02, en 7 días, y sigue pendiente | — | — | 7 | `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md, línea 3` |
| 4 | A los días configurados de una sesión de un órgano, su material no está en la carpeta (`meeting_without_material`) | junta-directiva del 2026-10-29: faltan 3 días y su material no está en 20-material/ | — | — | 3 | `organos/junta-directiva/2026-10-29/20-material/` |

## El resultado

### junta-directiva · 2026-10-29

**Material en la carpeta:** 0 archivo(s) — falta
**Lo que quedó abierto de la sesión del 2026-09-24:**

- C-1 · Presentar el informe de cartera vencida — Felipe Duarte, 2026-10-15 (vencido)
- C-2 · Entregar el plan de continuidad del negocio — Andrés Vela, 2026-11-20 (abierto)

**Decisión D-1: Proveedor del centro de datos alterno** — plazo 2026-11-02 (`organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md, línea 3`)

- Renovar con el proveedor actual — evidencia: `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md`
- Abrir una licitación — evidencia: `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md`
- Lo que falta saber: La oferta económica de la licitación

### Decisiones pendientes de un órgano sin sesión convocada

*comite-de-presidencia, de la sesión del 2026-10-05*

**Decisión D-1: Proveedor de la mesa de ayuda** — plazo 2026-11-03 (`organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md, línea 3`)

- Renovar con el proveedor actual por tres años, a 18.000 al mes — evidencia: `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md`
- Contratar al proveedor que ganó la cotización, a 15.500 al mes — evidencia: `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md`

*comite-de-presidencia, de la sesión del 2026-10-05*

**Decisión D-2: Sede de la oficina regional** — plazo 2026-11-04 (`organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md, línea 3`)

- Mantener la sede actual, con un canon de 42.000 al mes — evidencia: `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md`
- Trasladarse a la sede nueva del centro, con un canon de 47.500 al mes — evidencia: `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md`

Las opciones van en el orden en que las traen los documentos. Ofelia no las ordena ni dice cuál conviene: la decisión es del órgano.

No se publica en Rostrum: así lo dice la configuración.

## Lo que no se pudo procesar

- `organos/comite-de-presidencia/2026-09-21/`: comite-de-presidencia:2026-09-21 no tiene ficha: corre ea-scan
- `organos/comite-de-presidencia/2026-10-19/`: comite-de-presidencia:2026-10-19 no tiene ficha: corre ea-scan
- `90-borradores/LEEME.txt`: un archivo en 90-borradores/ sin «BORRADOR» en el nombre

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md, línea 3`
- `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md, línea 3`
- `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md, línea 3`
- `organos/junta-directiva/2026-10-29/20-material/`
