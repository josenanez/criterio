# Borrador del acta · Banco Andino · al 2026-10-26 · oficina de Presidencia

**Entidad:** Banco Andino · **Fecha de corte:** 2026-10-26 · **Procesado:** 2026-10-26 · **Agente:** Ofelia, versión 1.2.1 · **Comando:** `ea-minutes`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Pasados los días configurados de una sesión, su acta firmada no está (`meeting_without_minutes`) | comite-de-presidencia del 2026-09-21: pasaron 35 días y su acta firmada no está en 40-acta/ | — | — | 35 | `organos/comite-de-presidencia/2026-09-21/40-acta/` |
| 2 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-10: «Renovar las pólizas de la sede» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17` |
| 3 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-11: «Publicar el informe de sostenibilidad» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18` |
| 4 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-7: «Ajustar el presupuesto de mercadeo» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14` |
| 5 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-8: «Contratar la consultoría de procesos» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15` |
| 6 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-9: «Migrar el archivo documental» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16` |
| 7 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | junta-directiva del 2026-09-24, A-3: «Contratar la auditoría del sistema de pagos» no tiene fecha | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11` |
| 8 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-1: «Renovar las pólizas de la sede» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8` |
| 9 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-2: «Publicar el informe de sostenibilidad» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9` |
| 10 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-3: «Actualizar el manual de compras» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10` |
| 11 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-4: «Revisar el tablero de indicadores» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11` |
| 12 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-5: «Cerrar el proyecto de nómina» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12` |
| 13 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-6: «Definir el plan de capacitación» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13` |
| 14 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | junta-directiva del 2026-09-24, A-2: «Actualizar la política de viajes» no tiene responsable | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10` |

## El resultado

| Órgano | Sesión | Días | Notas | Acta |
|---|---|---|---|---|
| comite-de-presidencia | 2026-09-21 | 35 | sí | no |
| comite-de-presidencia | 2026-10-19 | 7 | sí | no |

**Borradores en 90-borradores/:** `90-borradores/LEEME.txt`

Cada borrador lleva «BORRADOR» en el nombre y en el texto. El acta es la que se firma; Ofelia nunca la archiva en 40-acta/.

No se publica en Rostrum: así lo dice la configuración.

## Lo que no se pudo procesar

- `organos/comite-de-presidencia/2026-09-21/`: comite-de-presidencia:2026-09-21 no tiene ficha: corre ea-scan
- `organos/comite-de-presidencia/2026-10-19/`: comite-de-presidencia:2026-10-19 no tiene ficha: corre ea-scan
- `90-borradores/LEEME.txt`: un archivo en 90-borradores/ sin «BORRADOR» en el nombre

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `organos/comite-de-presidencia/2026-09-21/40-acta/`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11`
