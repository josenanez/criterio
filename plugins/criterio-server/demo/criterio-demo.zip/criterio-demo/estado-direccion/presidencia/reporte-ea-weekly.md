# Resumen de la semana · Banco Andino · al 2026-10-26 · oficina de Presidencia

**Entidad:** Banco Andino · **Fecha de corte:** 2026-10-26 · **Procesado:** 2026-10-26 · **Agente:** Ofelia, versión 1.2.3 · **Comando:** `ea-weekly`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-1: «Entregar el informe 1 de seguimiento» de Diana Cruz venció el 2026-10-12 y ningún documento lo sostiene como cumplido | — | Diana Cruz | 14 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 21` |
| 2 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-2: «Entregar el informe 2 de seguimiento» de Felipe Duarte venció el 2026-10-13 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 13 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 22` |
| 3 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-3: «Entregar el informe 3 de seguimiento» de Laura Gómez venció el 2026-10-14 y ningún documento lo sostiene como cumplido | — | Laura Gómez | 12 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 23` |
| 4 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-4: «Entregar el informe 4 de seguimiento» de Andrés Vela venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Andrés Vela | 11 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 24` |
| 5 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | junta-directiva del 2026-09-24, C-1: «Presentar el informe de cartera vencida» de Felipe Duarte venció el 2026-10-15 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 11 | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14` |
| 6 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-5: «Entregar el informe 5 de seguimiento» de Diana Cruz venció el 2026-10-16 y ningún documento lo sostiene como cumplido | — | Diana Cruz | 10 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 25` |
| 7 | Un compromiso venció y ningún documento lo sostiene como cumplido (`commitment_overdue`) | comite-de-presidencia del 2026-10-05, C-6: «Entregar el informe 6 de seguimiento» de Felipe Duarte venció el 2026-10-17 y ningún documento lo sostiene como cumplido | — | Felipe Duarte | 9 | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 26` |
| 8 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | oficios@supervisor.test: «Requerimiento 45: cartera reestructurada» pidió respuesta para el 2026-10-20 y no hay una respuesta guardada | — | — | 6 | `20-correspondencia/2026-10-08-supervisor.msg` |
| 9 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | ventas@proveedor.test: «Solicitud 1: confirmación de condiciones» pidió respuesta para el 2026-10-20 y no hay una respuesta guardada | — | — | 6 | `20-correspondencia/2026-10-14-solicitud-1.msg` |
| 10 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | ventas@proveedor.test: «Solicitud 2: confirmación de condiciones» pidió respuesta para el 2026-10-21 y no hay una respuesta guardada | — | — | 5 | `20-correspondencia/2026-10-15-solicitud-2.msg` |
| 11 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | ventas@proveedor.test: «Solicitud 3: confirmación de condiciones» pidió respuesta para el 2026-10-22 y no hay una respuesta guardada | — | — | 4 | `20-correspondencia/2026-10-16-solicitud-3.msg` |
| 12 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | ventas@proveedor.test: «Solicitud 4: confirmación de condiciones» pidió respuesta para el 2026-10-23 y no hay una respuesta guardada | — | — | 3 | `20-correspondencia/2026-10-17-solicitud-4.msg` |
| 13 | Un correo guardado pide respuesta y su plazo venció sin una respuesta guardada (`correspondence_unanswered`) | ventas@proveedor.test: «Solicitud 5: confirmación de condiciones» pidió respuesta para el 2026-10-24 y no hay una respuesta guardada | — | — | 2 | `20-correspondencia/2026-10-18-solicitud-5.msg` |
| 14 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-10-29: «Sesión de la junta» (14:00–17:00) se cruza con «Visita del supervisor» (15:30–16:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 15 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-11-03: «Reunión con la firma auditora 4» (15:00–16:00) se cruza con «Visita del cliente 4» (15:30–16:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 16 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-11-03: «Llamada con la casa matriz» (09:00–10:00) se cruza con «Revisión con tesorería» (09:00–09:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 17 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-11-04: «Reunión con la firma auditora 1» (15:00–16:00) se cruza con «Visita del cliente 1» (15:30–16:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 18 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-11-05: «Reunión con la firma auditora 2» (15:00–16:00) se cruza con «Visita del cliente 2» (15:30–16:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 19 | Dos reuniones del ejecutivo se cruzan en la agenda exportada (`meeting_conflict`) | 2026-11-06: «Reunión con la firma auditora 3» (15:00–16:00) se cruza con «Visita del cliente 3» (15:30–16:30) | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `10-agenda/agenda-2026-10-25.ics` |
| 20 | Una reunión de la agenda cae durante un vuelo del itinerario del ejecutivo (`meeting_during_flight`) | «Llamada con la calificadora» (2026-10-27 19:15) cae durante el vuelo AV 9217, que sale a las 19:00 y llega a las 20:00 | — | — | — | `30-viajes/MDE-itinerario-medellin.md, línea 9` · `10-agenda/agenda-2026-10-25.ics` |
| 21 | Una reunión de la agenda cae durante un vuelo del itinerario del ejecutivo (`meeting_during_flight`) | «Cena de la junta del gremio» (2026-11-05 18:30) cae durante el vuelo AV 9342, que sale a las 18:00 y llega a las 19:35 | — | — | — | `30-viajes/UIO-itinerario-quito.md, línea 9` · `10-agenda/agenda-2026-10-25.ics` |
| 22 | Una reunión presencial en la ciudad del ejecutivo cae mientras el itinerario lo tiene de viaje en otra (`meeting_while_away`) | «Reunión con el sindicato» (2026-10-27 11:00) es presencial en Bogotá (Sede principal, Bogotá) y ese día el viaje a Medellín sigue | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `30-viajes/MDE-itinerario-medellin.md` |
| 23 | Una reunión presencial en la ciudad del ejecutivo cae mientras el itinerario lo tiene de viaje en otra (`meeting_while_away`) | «Visita a la oficina principal» (2026-10-28 14:00) es presencial en Bogotá (Oficina principal, Bogotá) y ese día el viaje a Cali sigue | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `30-viajes/CLO-itinerario-cali.md` |
| 24 | Una reunión presencial en la ciudad del ejecutivo cae mientras el itinerario lo tiene de viaje en otra (`meeting_while_away`) | «Comité de riesgos» (2026-11-04 10:00) es presencial en Bogotá (Sala de juntas, sede principal, Bogotá) y ese día el viaje a Quito sigue | — | — | — | `10-agenda/agenda-2026-10-25.ics` · `30-viajes/UIO-itinerario-quito.md` |
| 25 | Pasados los días configurados de una sesión, su acta firmada no está (`meeting_without_minutes`) | comite-de-presidencia del 2026-09-21: pasaron 35 días y su acta firmada no está en 40-acta/ | — | — | 35 | `organos/comite-de-presidencia/2026-09-21/40-acta/` |
| 26 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | comite-de-presidencia, D-2: «Sede de la oficina regional» tiene plazo el 2026-11-04, en 9 días, y sigue pendiente | — | — | 9 | `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md, línea 3` |
| 27 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | comite-de-presidencia, D-1: «Proveedor de la mesa de ayuda» tiene plazo el 2026-11-03, en 8 días, y sigue pendiente | — | — | 8 | `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md, línea 3` |
| 28 | Una decisión pendiente tiene una fecha que la fija dentro de los días configurados (`decision_deadline`) | junta-directiva, D-1: «Proveedor del centro de datos alterno» tiene plazo el 2026-11-02, en 7 días, y sigue pendiente | — | — | 7 | `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md, línea 3` |
| 29 | A los días configurados de una sesión de un órgano, su material no está en la carpeta (`meeting_without_material`) | junta-directiva del 2026-10-29: faltan 3 días y su material no está en 20-material/ | — | — | 3 | `organos/junta-directiva/2026-10-29/20-material/` |
| 30 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-7: «Presentar el plan 7 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-04) | — | Laura Gómez | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 27` |
| 31 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-8: «Presentar el plan 8 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-05) | — | Andrés Vela | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 28` |
| 32 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | comite-de-presidencia del 2026-10-05, C-9: «Presentar el plan 9 de mejora» se movió 3 veces (2026-09-30, 2026-10-20, 2026-12-06) | — | Diana Cruz | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 29` |
| 33 | Un compromiso se movió más veces de las configuradas (`commitment_rescheduled`) | junta-directiva del 2026-09-24, C-2: «Entregar el plan de continuidad del negocio» se movió 3 veces (2026-10-15, 2026-10-30, 2026-11-20) | — | Andrés Vela | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15` |
| 34 | Un vuelo del itinerario no está en la agenda: ese tiempo se ve libre (`trip_not_in_agenda`) | el vuelo AV 9210 (Bogotá → Medellín) sale el 2026-10-27 06:00 y no está en la agenda: ese tiempo se ve libre | — | — | — | `30-viajes/MDE-itinerario-medellin.md, línea 8` |
| 35 | Un vuelo del itinerario no está en la agenda: ese tiempo se ve libre (`trip_not_in_agenda`) | el vuelo AV 9341 (Bogotá → Quito) sale el 2026-11-03 06:00 y no está en la agenda: ese tiempo se ve libre | — | — | — | `30-viajes/UIO-itinerario-quito.md, línea 8` |
| 36 | Un vuelo del itinerario no está en la agenda: ese tiempo se ve libre (`trip_not_in_agenda`) | el vuelo AV 9520 (Bogotá → Cali) sale el 2026-10-28 06:30 y no está en la agenda: ese tiempo se ve libre | — | — | — | `30-viajes/CLO-itinerario-cali.md, línea 8` |
| 37 | Un vuelo del itinerario no está en la agenda: ese tiempo se ve libre (`trip_not_in_agenda`) | el vuelo AV 9527 (Cali → Bogotá) sale el 2026-10-28 20:00 y no está en la agenda: ese tiempo se ve libre | — | — | — | `30-viajes/CLO-itinerario-cali.md, línea 9` |
| 38 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-10: «Renovar las pólizas de la sede» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17` |
| 39 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-11: «Publicar el informe de sostenibilidad» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18` |
| 40 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-7: «Ajustar el presupuesto de mercadeo» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14` |
| 41 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-8: «Contratar la consultoría de procesos» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15` |
| 42 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | comite-de-presidencia del 2026-10-05, A-9: «Migrar el archivo documental» no tiene fecha | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16` |
| 43 | Un acuerdo del acta no tiene fecha (`agreement_without_date`) | junta-directiva del 2026-09-24, A-3: «Contratar la auditoría del sistema de pagos» no tiene fecha | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11` |
| 44 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-1: «Renovar las pólizas de la sede» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8` |
| 45 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-2: «Publicar el informe de sostenibilidad» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9` |
| 46 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-3: «Actualizar el manual de compras» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10` |
| 47 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-4: «Revisar el tablero de indicadores» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11` |
| 48 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-5: «Cerrar el proyecto de nómina» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12` |
| 49 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | comite-de-presidencia del 2026-10-05, A-6: «Definir el plan de capacitación» no tiene responsable | — | — | — | `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13` |
| 50 | Un acuerdo del acta no tiene responsable (`agreement_without_owner`) | junta-directiva del 2026-09-24, A-2: «Actualizar la política de viajes» no tiene responsable | — | — | — | `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10` |

## El resultado

**Llegó esta semana:** 1 correo(s). **Vence en los próximos siete días:** 1. **Por preparar:** 1 sesión(es).

- 2026-11-02 · D-1 · Proveedor del centro de datos alterno (junta-directiva)
- Preparar junta-directiva del 2026-10-29: 0 archivo(s) de material, 1 decisión(es) pendiente(s)

No se publica en Rostrum: así lo dice la configuración.

## Lo que no se pudo procesar

- `organos/comite-de-presidencia/2026-09-21/`: comite-de-presidencia:2026-09-21 no tiene ficha: corre ea-scan
- `organos/comite-de-presidencia/2026-10-19/`: comite-de-presidencia:2026-10-19 no tiene ficha: corre ea-scan
- `90-borradores/LEEME.txt`: un archivo en 90-borradores/ sin «BORRADOR» en el nombre

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-agenda/agenda-2026-10-25.ics`
- `20-correspondencia/2026-10-08-supervisor.msg`
- `20-correspondencia/2026-10-14-solicitud-1.msg`
- `20-correspondencia/2026-10-15-solicitud-2.msg`
- `20-correspondencia/2026-10-16-solicitud-3.msg`
- `20-correspondencia/2026-10-17-solicitud-4.msg`
- `20-correspondencia/2026-10-18-solicitud-5.msg`
- `30-viajes/CLO-itinerario-cali.md`
- `30-viajes/CLO-itinerario-cali.md, línea 8`
- `30-viajes/CLO-itinerario-cali.md, línea 9`
- `30-viajes/MDE-itinerario-medellin.md`
- `30-viajes/MDE-itinerario-medellin.md, línea 8`
- `30-viajes/MDE-itinerario-medellin.md, línea 9`
- `30-viajes/UIO-itinerario-quito.md`
- `30-viajes/UIO-itinerario-quito.md, línea 8`
- `30-viajes/UIO-itinerario-quito.md, línea 9`
- `organos/comite-de-presidencia/2026-09-21/40-acta/`
- `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-1.md, línea 3`
- `organos/comite-de-presidencia/2026-10-05/20-material/propuesta-2.md, línea 3`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 10`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 11`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 12`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 13`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 14`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 15`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 16`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 17`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 18`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 21`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 22`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 23`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 24`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 25`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 26`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 27`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 28`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 29`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 8`
- `organos/comite-de-presidencia/2026-10-05/40-acta/acta-firmada.md, línea 9`
- `organos/junta-directiva/2026-09-24/20-material/propuesta-centro-de-datos.md, línea 3`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 10`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 11`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 14`
- `organos/junta-directiva/2026-09-24/40-acta/acta-firmada.md, línea 15`
- `organos/junta-directiva/2026-10-29/20-material/`
