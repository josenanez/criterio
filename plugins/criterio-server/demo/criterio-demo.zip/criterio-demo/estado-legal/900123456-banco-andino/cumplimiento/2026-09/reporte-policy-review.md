# Políticas por revisar · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Constanza, versión 1.6.3 · **Comando:** `policy-review`

## Lo que hay que atender

Nada abierto en lo que procesa este comando.

## El resultado

| Código | Política | Versión | Responsable | Próxima revisión | Días |
|---|---|---|---|---|---|
| P-03 | Política de conflictos de interés | 4 | Diana Cruz | 2026-11-15 | 40 |
| P-02 | Política de atención al cliente | 2 | Andrés Vela | 2027-01-20 | 106 |
| P-01 | Política de gestión de riesgos | 3 | Marta Ríos | 2027-02-10 | 127 |
| P-04 | Política de conocimiento de proveedores | 1 | Andrés Vela | 2027-03-01 | 146 |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- Sin documentos citados.
