# Estado del cumplimiento · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Constanza, versión 1.6.2 · **Comando:** `compliance-status`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una obligación de la matriz pasó su fecha límite sin evidencia (`compliance_obligation_overdue`) | OB-09 · Reporte mensual de quejas: venció el 2026-10-05 y no hay evidencia en la ventana de su periodicidad | — | Diana Cruz | 1 | `00-referencia/matriz-obligaciones.csv` fila 10 |
| 2 | El informe declara el cumplimiento del periodo y hay señales abiertas que ese estado no explica (`declared_compliance_vs_evidence`) | el informe declara el periodo cumplido (cumplimiento-2026-09/20-reportes/informe-cumplimiento-2026-09.md) y hay 4 señales abiertas que ese estado no explica | — | — | — | `cumplimiento-2026-09/20-reportes/informe-cumplimiento-2026-09.md` |
| 3 | Una obligación de cumplimiento de un contrato no está en la matriz (`contract_obligation_not_in_matrix`) | CTR-101 · OBL-3 · Reporte de operaciones al oficial de cumplimiento: obligación de cumplimiento del contrato que la matriz no tiene | — | — | — | `contratos/CTR-101-soluciones-andinas-s-a-s/10-contrato/contrato.md, cláusula 7` |
| 4 | Una obligación de la matriz no tiene responsable (`obligation_without_owner`) | OB-12 · Registro de conflictos de interés: no tiene responsable | — | — | — | `00-referencia/matriz-obligaciones.csv` fila 11 |

## El resultado

**Estado declarado:** cumplido (`cumplimiento-2026-09/20-reportes/informe-cumplimiento-2026-09.md`) · **Avance con evidencia:** 72,73 % (ponderado por criticidad)

| Id | Obligación | Fuente | Responsable | Vence | Estado | Evidencia |
|---|---|---|---|---|---|---|
| OB-09 | Reporte mensual de quejas | Política P-02 | Diana Cruz | 2026-10-05 | vencida | — |
| OB-06 | Reporte de operaciones del contratista de tecnología | Política P-01 | Andrés Vela | 2026-10-05 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-06_reporte-de-operaciones-del-contratista-d-2026-09.md` |
| OB-01 | Reporte mensual de operaciones al supervisor | N-2026-01 · Resolución sintética 001 de 2026 | Andrés Vela | 2026-10-10 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-01_reporte-mensual-de-operaciones-al-superv-2026-09.md` |
| OB-03 | Informe trimestral del comité de riesgos | Política P-01 | Marta Ríos | 2026-10-20 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-03_informe-trimestral-del-comite-de-riesgos-2026-09.md` |
| OB-04 | Certificación anual de la junta | Estatutos, artículo 40 | Marta Ríos | 2026-12-31 | en plazo | — |
| OB-02 | Conciliación de la base de clientes vinculados | Política P-02 | Andrés Vela | 2026-10-07 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-02_conciliacion-de-la-base-de-clientes-vinc-2026-09.md` |
| OB-08 | Actualización de datos de proveedores críticos | Política P-04 | Diana Cruz | 2026-10-08 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-08_actualizacion-de-datos-de-proveedores-cr-2026-09.md` |
| OB-07 | Revisión semestral de la matriz de riesgos | Política P-01 | Marta Ríos | 2026-10-30 | cumplida con evidencia | `cumplimiento-2026-07/10-evidencias/OB-07_revision-semestral-de-la-matriz-de-riesg-2026-07.md` |
| OB-05 | Capacitación mensual del personal nuevo | Política P-03 | Diana Cruz | 2026-10-20 | en plazo | — |
| OB-12 | Registro de conflictos de interés | Política P-03 | — | 2026-10-10 | cumplida con evidencia | `cumplimiento-2026-09/10-evidencias/OB-12_registro-de-conflictos-de-interes-2026-09.md` |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/matriz-obligaciones.csv`
- `contratos/CTR-101-soluciones-andinas-s-a-s/10-contrato/contrato.md, cláusula 7`
- `cumplimiento-2026-09/20-reportes/informe-cumplimiento-2026-09.md`
