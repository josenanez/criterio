# Canal de denuncias · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Constanza, versión 1.6.3 · **Comando:** `reports-cases`

## Lo que hay que atender

Nada abierto en lo que procesa este comando.

## El resultado

| Caso | Tipo | Recibido | Respondido | Días |
|---|---|---|---|---|
| C-001 | trato al cliente | 2026-08-01 | 2026-08-10 | 9 |
| C-002 | proveedores | 2026-09-25 | abierto | 11 |

Plazo de respuesta configurado: 15 días. Sin datos de quién denunció.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- Sin documentos citados.
