# El marco y la declaración · Banco Andino Sintético · periodo 2026-10

**Entidad:** Banco Andino Sintético (901777333) · **Fecha de corte:** 2026-11-25 · **Procesado:** 2026-11-25 · **Agente:** Severo, versión 1.1.0 · **Comando:** `framework-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | La declaración de apetito no tiene la revisión de la junta en el plazo que fija el marco (`appetite_statement_outdated`) | Declaración de apetito por riesgo: la junta la revisó el 2025-08-28, y el marco pide revisarla cada 12 meses: tocaba el 2026-08-28 | — | — | 89 | `00-marco/declaracion_de_apetito.pdf` |
| 2 | Un límite del marco no tiene dueño (`limit_without_owner`) | L-02 · Indicador de cobertura de liquidez: el límite no tiene un dueño que responda por él | — | — | — | `00-marco/limites.xlsx` fila 3 |
| 3 | Un límite del marco no tiene dueño (`limit_without_owner`) | L-22 · Concentración sectorial de la cartera: el límite no tiene un dueño que responda por él | — | — | — | `00-marco/limites.xlsx` fila 11 |
| 4 | Un límite del marco no tiene dueño (`limit_without_owner`) | L-23 · Descalce de plazos a 30 días: el límite no tiene un dueño que responda por él | — | — | — | `00-marco/limites.xlsx` fila 12 |
| 5 | Un límite pasó su fecha de revisión (`limit_review_overdue`) | L-33 · Inversiones de baja liquidez: su revisión tocaba el 2026-04-30 | — | Tesorería | 209 | `00-marco/limites.xlsx` fila 14 |
| 6 | Un límite pasó su fecha de revisión (`limit_review_overdue`) | L-32 · Exposición en moneda extranjera: su revisión tocaba el 2026-05-31 | — | Tesorería | 178 | `00-marco/limites.xlsx` fila 13 |
| 7 | Un límite pasó su fecha de revisión (`limit_review_overdue`) | L-02 · Indicador de cobertura de liquidez: su revisión tocaba el 2026-06-30 | — | — | 148 | `00-marco/limites.xlsx` fila 3 |

## El resultado

**Declaración de apetito:** Declaración de apetito por riesgo · revisada por la junta el 2025-08-28 · próxima revisión 2026-08-28 · `00-marco/declaracion_de_apetito.pdf`.

| Límite | Métrica | Dueño | Próxima revisión |
|---|---|---|---|
| L-01 | Cartera vencida de consumo | Vicepresidencia de crédito | 2027-03-31 |
| L-02 | Indicador de cobertura de liquidez | — | 2026-06-30 |
| L-03 | Concentración en el mayor deudor | Vicepresidencia de crédito | 2027-03-31 |
| L-04 | Pérdidas por fraude externo sobre ingresos | Operaciones | 2027-06-30 |
| L-05 | Exposición a contrapartes sin calificación | Tesorería | 2027-06-30 |
| L-06 | Pérdidas operacionales sobre el patrimonio | Operaciones | 2027-06-30 |
| L-07 | Exposición al mayor banco corresponsal | Tesorería | 2027-06-30 |
| L-12 | Cartera vencida de vivienda | Vicepresidencia de crédito | 2027-03-31 |
| L-13 | Cartera vencida comercial | Vicepresidencia de crédito | 2027-03-31 |
| L-22 | Concentración sectorial de la cartera | — | 2027-03-31 |
| L-23 | Descalce de plazos a 30 días | — | 2027-03-31 |
| L-32 | Exposición en moneda extranjera | Tesorería | 2026-05-31 |
| L-33 | Inversiones de baja liquidez | Tesorería | 2026-04-30 |
| L-42 | Cupos de contraparte utilizados | Tesorería | 2027-06-30 |
| L-43 | Pérdidas por errores operativos sobre ingresos | Operaciones | 2027-06-30 |

Quién es el dueño de un límite y cuándo se revisa lo fija el marco: aquí se dice cuál falta o se venció.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-marco/declaracion_de_apetito.pdf`
- `00-marco/limites.xlsx`
- Fuentes técnicas: F-01, F-10 (families/criterio-cro/FUENTES.es.md)
