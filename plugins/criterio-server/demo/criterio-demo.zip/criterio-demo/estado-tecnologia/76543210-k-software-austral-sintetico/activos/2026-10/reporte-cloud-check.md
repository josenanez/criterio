# La nube contra su presupuesto · Software Austral Sintético · periodo 2026-10

**Entidad:** Software Austral Sintético (76543210-K) · **Fecha de corte:** 2026-11-25 · **Procesado:** 2026-11-25 · **Agente:** Domingo, versión 0.3.0 · **Comando:** `cloud-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | La factura de la nube de una cuenta supera su presupuesto más la tolerancia de la política (`cloud_over_budget`) | Analítica: la nube facturó 9,000,000 en 2026-10 y el presupuesto es 7,500,000; la política tolera un 5 % más | 1.500.000,00 | — | — | `50-nube/factura_de_la_nube_2026-10.xlsx` fila 5 · `50-nube/presupuesto_de_la_nube_2026.xlsx` fila 4 |
| 2 | La factura de la nube de una cuenta supera su presupuesto más la tolerancia de la política (`cloud_over_budget`) | Canales digitales: la nube facturó 12,750,000 en 2026-10 y el presupuesto es 11,250,000; la política tolera un 5 % más | 1.500.000,00 | — | — | `50-nube/factura_de_la_nube_2026-10.xlsx` fila 6 · `50-nube/presupuesto_de_la_nube_2026.xlsx` fila 5 |

## El resultado

**Tolerancia de la política sobre el presupuesto de cada cuenta:** 5 %.

| Cuenta | Facturado | Presupuesto |
|---|---|---|
| Analítica | 9,000,000 | 7,500,000 |
| Canales digitales | 12,750,000 | 11,250,000 |
| Desarrollo | 2,250,000 | 2,500,000 |
| Producción | 20,500,000 | 20,000,000 |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `50-nube/factura_de_la_nube_2026-10.xlsx`
- `50-nube/presupuesto_de_la_nube_2026.xlsx`
- Fuentes técnicas: F-02 (families/criterio-cto/FUENTES.es.md)
