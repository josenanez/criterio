# La nube contra su presupuesto · Banco Meridiano Sintético · periodo 2026-10

**Entidad:** Banco Meridiano Sintético (901222444) · **Fecha de corte:** 2026-11-25 · **Procesado:** 2026-11-25 · **Agente:** Domingo, versión 0.2.0 · **Comando:** `cloud-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | La factura de la nube de una cuenta supera su presupuesto más la tolerancia de la política (`cloud_over_budget`) | Analítica: la nube facturó 36,000,000 en 2026-10 y el presupuesto es 30,000,000; la política tolera un 5 % más | 6.000.000,00 | — | — | `50-nube/factura_de_la_nube_2026-10.xlsx` fila 5 · `50-nube/presupuesto_de_la_nube_2026.xlsx` fila 4 |
| 2 | La factura de la nube de una cuenta supera su presupuesto más la tolerancia de la política (`cloud_over_budget`) | Canales digitales: la nube facturó 51,000,000 en 2026-10 y el presupuesto es 45,000,000; la política tolera un 5 % más | 6.000.000,00 | — | — | `50-nube/factura_de_la_nube_2026-10.xlsx` fila 6 · `50-nube/presupuesto_de_la_nube_2026.xlsx` fila 5 |
| 3 | La factura de la nube de una cuenta supera su presupuesto más la tolerancia de la política (`cloud_over_budget`) | Respaldo: la nube facturó 14,000,000 en 2026-10 y el presupuesto es 12,000,000; la política tolera un 5 % más | 2.000.000,00 | — | — | `50-nube/factura_de_la_nube_2026-10.xlsx` fila 7 · `50-nube/presupuesto_de_la_nube_2026.xlsx` fila 6 |

## El resultado

**Tolerancia de la política sobre el presupuesto de cada cuenta:** 5 %.

| Cuenta | Facturado | Presupuesto |
|---|---|---|
| Analítica | 36,000,000 | 30,000,000 |
| Canales digitales | 51,000,000 | 45,000,000 |
| Desarrollo | 9,000,000 | 10,000,000 |
| Producción | 82,000,000 | 80,000,000 |
| Respaldo | 14,000,000 | 12,000,000 |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `50-nube/factura_de_la_nube_2026-10.xlsx`
- `50-nube/presupuesto_de_la_nube_2026.xlsx`
- Fuentes técnicas: F-02 (families/criterio-cto/FUENTES.es.md)
