# Cada proveedor contra su nivel · Banco Meridiano Sintético · periodo 2026-10

**Entidad:** Banco Meridiano Sintético (901222444) · **Fecha de corte:** 2026-11-25 · **Procesado:** 2026-11-25 · **Agente:** Domingo, versión 0.2.0 · **Comando:** `vendor-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un proveedor quedó por debajo de su nivel de servicio y su factura del periodo no trae el crédito que pacta el contrato (`vendor_breach_without_credit`) | Nube Andina · Disponibilidad: dio 99.7 en 2026-10 y el contrato pacta 99.95, con un crédito del 10 %; su factura FP-003 no trae el crédito | 90.000.000,00 | — | — | `40-proveedores/contrato_nube_andina.pdf` · `40-proveedores/cumplimiento_sla_2026-10.xlsx` fila 4 · `40-proveedores/facturas_proveedores_2026-10.xlsx` fila 4 |
| 2 | Un proveedor quedó por debajo de su nivel de servicio y su factura del periodo no trae el crédito que pacta el contrato (`vendor_breach_without_credit`) | Enlaces del Pacífico · Disponibilidad: dio 99.2 en 2026-10 y el contrato pacta 99.8, con un crédito del 8 %; su factura FP-004 no trae el crédito | 55.000.000,00 | — | — | `40-proveedores/contrato_enlaces_del_pacifico.pdf` · `40-proveedores/cumplimiento_sla_2026-10.xlsx` fila 5 · `40-proveedores/facturas_proveedores_2026-10.xlsx` fila 5 |
| 3 | Un proveedor quedó por debajo de su nivel de servicio y su factura del periodo no trae el crédito que pacta el contrato (`vendor_breach_without_credit`) | Soporte Integral · Casos resueltos a tiempo: dio 89 en 2026-10 y el contrato pacta 95, con un crédito del 5 %; su factura FP-005 no trae el crédito | 35.000.000,00 | — | — | `40-proveedores/contrato_soporte_integral.pdf` · `40-proveedores/cumplimiento_sla_2026-10.xlsx` fila 6 · `40-proveedores/facturas_proveedores_2026-10.xlsx` fila 6 |

## El resultado

| Proveedor | Métrica | Nivel del contrato | Medido | Crédito pactado | Facturado | Crédito en la factura |
|---|---|---|---|---|---|---|
| Centro de Datos Uno | Disponibilidad | 99.9 | 99.95 | 10 % | 120,000,000 | 0 |
| Mesa de Ayuda Sintética | Casos resueltos a tiempo | 95 | 94 | 5 % | 40,000,000 | 2,000,000 |
| Nube Andina | Disponibilidad | 99.95 | 99.7 | 10 % | 90,000,000 | 0 |
| Enlaces del Pacífico | Disponibilidad | 99.8 | 99.2 | 8 % | 55,000,000 | 0 |
| Soporte Integral | Casos resueltos a tiempo | 95 | 89 | 5 % | 35,000,000 | 0 |

Qué dice el contrato lo interpreta legal: aquí se dice qué incumplimiento se facturó completo.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `40-proveedores/contrato_enlaces_del_pacifico.pdf`
- `40-proveedores/contrato_nube_andina.pdf`
- `40-proveedores/contrato_soporte_integral.pdf`
- `40-proveedores/cumplimiento_sla_2026-10.xlsx`
- `40-proveedores/facturas_proveedores_2026-10.xlsx`
- Fuentes técnicas: F-02, F-10 (families/criterio-cto/FUENTES.es.md)
