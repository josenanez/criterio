# Comite de presidencia · sesión del 2026-10-05

1. Verificación del quórum.
2. Informe de la presidencia.
3. Asuntos que piden decisión.
4. Proposiciones y varios.
