# La posición de caja · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Áurea, versión 1.5.0 · **Aprueba:** Sofía León · **Comando:** `cash-position`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | El saldo de una cuenta o de la caja consolidada queda por debajo del mínimo que fija la política (`cash_below_minimum`) | andino-1101: saldo 13.273.400,00 COP, bajo el mínimo de 16.928.080,00 | 3.654.680,00 | — | — | `2026-09/20-bancos/andino-1101/extracto.xlsx` fila 17 · `00-referencia/politica-tesoreria.csv` fila 2 |

## El resultado

**Caja consolidada:** 43.273.400,00

| Cuenta | Moneda | Saldo | Mínimo | Proyectado | Desviación % |
|---|---|---|---|---|---|
| andino-1101 | COP | 13.273.400,00 | 16.928.080,00 | 13.273.400,00 | 0,00 |
| pacifico-1102 | COP | 30.000.000,00 | 14.000.000,00 | 30.000.000,00 | 0,00 |

Áurea no mueve dinero ni entra a un portal bancario: procesa las exportaciones.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/politica-tesoreria.csv`
- `2026-09/20-bancos/andino-1101/extracto.xlsx`
