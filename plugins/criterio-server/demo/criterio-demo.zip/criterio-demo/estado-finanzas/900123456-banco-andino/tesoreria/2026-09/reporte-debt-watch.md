# La deuda y sus covenants · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Áurea, versión 1.5.4 · **Aprueba:** Sofía León · **Comando:** `debt-watch`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un indicador de un contrato de deuda, calculado desde el balance que cierra Clara, cruza su límite o queda a menos del margen de él (`covenant_at_risk`) | Crédito de tesorería · Razón corriente: 3.07 contra el límite >= 2.92 (en riesgo), desde el balance de 2026-09 | — | — | — | `00-referencia/covenants.csv` fila 2 |

## El resultado

| Obligación | Indicador | Valor | Límite | Estado |
|---|---|---|---|---|
| Crédito de tesorería | Razón corriente | 3.07 | >= 2.92 | en riesgo |
| Crédito de tesorería | Endeudamiento | 0.33 | <= 0.65 | cumple |

| Obligación | Tipo | Contraparte | Saldo | Vence | Días |
|---|---|---|---|---|---|
| Crédito de tesorería | deuda | Banco del Norte | 400.000.000,00 | 2027-01-04 | 90 |
| Inversión a término | inversion | Banco del Sur | 150.000.000,00 | 2027-04-24 | 200 |

Áurea no recomienda una inversión, un financiamiento ni una cobertura: la decisión es de una persona.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/covenants.csv`
