# Proyección al cierre del año · Banco Andino · presupuesto 2026, corte 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09 · **Procesado:** 2026-10-06 · **Agente:** Tomás, versión 1.5.0 · **Aprueba:** Sofía León · **Comando:** `forecast`

## Lo que hay que atender

Nada abierto en lo que procesa este comando.

## El resultado

| Área | Línea | Aprobado | Proyección del área | Al ritmo | Al plan |
|---|---|---|---|---|---|
| Administración | Mantenimiento | 24.000.000,00 | 23.520.000,00 (2026-09-30) | 23.280.000,00 | 23.460.000,00 |
| Administración | Servicios públicos | 36.000.000,00 | 35.280.000,00 (2026-09-30) | 41.400.000,00 | 40.050.000,00 |
| Comercial | Eventos | 21.000.000,00 | 20.580.000,00 (2026-09-30) | 19.400.000,00 | 20.550.000,00 |
| Comercial | Publicidad | 45.000.000,00 | 44.100.000,00 (2026-09-30) | 44.620.000,00 | 43.965.000,00 |
| Operaciones | Transporte | 46.800.000,00 | 45.864.000,00 (2026-09-30) | 43.844.000,00 | 45.783.000,00 |
| Personal | Nómina | 240.000.000,00 | 240.000.000,00 (2026-09-30) | 240.000.000,00 | 240.000.000,00 |
| Tecnología | Licencias | 55.200.000,00 | 54.096.000,00 (2026-09-30) | 55.096.000,00 | 53.922.000,00 |
| Tecnología | PRY-310 | 72.000.000,00 | 70.560.000,00 (2026-09-30) | 69.840.000,00 | 70.380.000,00 |

**Al ritmo:** el ejecutado más el mayor entre el promedio mensual por los meses que faltan y lo comprometido. **Al plan:** el ejecutado más lo que falta del aprobado según su distribución mensual.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- Sin documentos citados.
