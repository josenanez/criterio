# Conciliación bancaria · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Clara, versión 1.5.0 · **Aprueba:** Sofía León · **Comando:** `bank-reconcile`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Hay movimientos del extracto sin su registro, o registros sin su movimiento (`bank_unreconciled`) | andino-1101: cheque pendiente de cobro del 2026-07-20 por -3.000.000,00 (CH-0450) | -3.000.000,00 | — | 72 | `2026-09/20-bancos/andino-1101/auxiliar-libros.csv` fila 2 |
| 2 | Hay movimientos del extracto sin su registro, o registros sin su movimiento (`bank_unreconciled`) | andino-1101: nota débito sin registrar del 2026-09-30 por -400.000,00 (sin referencia) | -400.000,00 | — | 0 | `2026-09/20-bancos/andino-1101/extracto.xlsx` fila 17 |
| 3 | Una partida conciliatoria lleva más días de los configurados (`reconciling_item_aged`) | andino-1101: cheque pendiente de cobro lleva 72 días (CH-0450) | -3.000.000,00 | — | 72 | `2026-09/20-bancos/andino-1101/auxiliar-libros.csv` fila 2 |

## El resultado

| Cuenta | Saldo según banco | Consignaciones en tránsito | Cheques pendientes | Notas crédito sin registrar | Notas débito sin registrar | Saldo según libros | Diferencia sin explicar |
|---|---|---|---|---|---|---|---|
| andino-1101 | 13.273.400,00 | 0,00 | -3.000.000,00 | 0,00 | -400.000,00 | 10.673.400,00 | 0,00 |
| pacifico-1102 | 30.000.000,00 | 0,00 | 0,00 | 0,00 | 0,00 | 30.000.000,00 | 0,00 |

**andino-1101 · partidas abiertas por antigüedad**

| Fecha | Clase | Referencia | Valor | Días | Tramo |
|---|---|---|---|---|---|
| 2026-07-20 | cheque pendiente de cobro | CH-0450 | -3.000.000,00 | 72 | 61-90 |
| 2026-09-30 | nota débito sin registrar | — | -400.000,00 | 0 | 0-30 |

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `2026-09/20-bancos/andino-1101/auxiliar-libros.csv`
- `2026-09/20-bancos/andino-1101/extracto.xlsx`
