# Cuadre del balance y el mayor · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Clara, versión 1.5.3 · **Aprueba:** Sofía León · **Comando:** `ledger-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | El saldo de una cuenta en el mayor no es el del balance de comprobación (`ledger_vs_trial_balance`) | cuenta 5305: el mayor suma débitos 0,00 y créditos 0,00; el balance dice 5.000,00 y 0,00 | -5.000,00 | — | — | `2026-09/10-contabilidad/balance-comprobacion.csv` fila 15 · `2026-09/10-contabilidad/libro-mayor.csv` |
| 2 | El saldo de una cuenta en el mayor no es el del balance de comprobación (`ledger_vs_trial_balance`) | cuenta 5305: saldo inicial más movimientos no da el saldo final (5.000,00) | 5.000,00 | — | — | `2026-09/10-contabilidad/balance-comprobacion.csv` fila 15 |
| 3 | Los débitos y los créditos del balance de comprobación no suman lo mismo (`trial_balance_unbalanced`) | débitos 253.437.700,00 y créditos 253.432.700,00: diferencia 5.000,00 | 5.000,00 | — | — | `2026-09/10-contabilidad/balance-comprobacion.csv` |

## El resultado

Débitos 253.437.700,00 · créditos 253.432.700,00 · diferencia 5.000,00.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `2026-09/10-contabilidad/balance-comprobacion.csv`
- `2026-09/10-contabilidad/libro-mayor.csv`
