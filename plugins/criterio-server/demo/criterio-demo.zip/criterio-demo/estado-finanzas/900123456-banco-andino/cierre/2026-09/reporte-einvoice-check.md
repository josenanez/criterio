# Facturas electrónicas · Banco Andino · periodo 2026-09

**Entidad:** Banco Andino (900123456) · **Fecha de corte:** 2026-09-30 · **Procesado:** 2026-10-06 · **Agente:** Clara, versión 1.5.1 · **Aprueba:** Sofía León · **Comando:** `einvoice-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | El valor o el impuesto del XML no es el del registro (`einvoice_amount_mismatch`) | factura SETP99000104: IVA 1.662.500,00 en el XML y 1.663.500,00 en libros | 1.000,00 | — | — | `2026-09/30-facturacion/emitidas/fe-SETP99000104.xml` · `2026-09/10-contabilidad/libro-mayor.csv` fila 15 · `2026-09/10-contabilidad/libro-mayor.csv` fila 16 |

## El resultado

17 facturas y notas electrónicas procesadas · 17 cruzadas con su registro · 0 identificadas solo por la clave de acceso · 0 líneas de ventas o compras sin número de documento.

Sin opinión fiscal: lo que es criterio tributario queda como pregunta para la persona.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `2026-09/10-contabilidad/libro-mayor.csv`
- `2026-09/30-facturacion/emitidas/fe-SETP99000104.xml`
- Fuentes técnicas: F-01 (families/criterio-cfo/FUENTES.es.md)
