# El pronóstico contra su respaldo · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-11-03 · **Procesado:** 2026-11-05 · **Agente:** Augusto, versión 1.2.1 · **Comando:** `forecast-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Lo comprometido supera lo que suman las oportunidades con evidencia, ponderadas por su etapa, más de la tolerancia configurada (`forecast_unsupported`) | 2026-10: se comprometieron 630.000.000,00 y lo cerrado más lo ponderado con evidencia suma 420.000.000,00; la tolerancia es 10 % | 210.000.000,00 | — | — | `20-comite/acta-comite-2026-10-02.docx` · `10-crm/oportunidades-2026-11-03.csv` |

## El resultado

**Comprometido:** 630.000.000,00 (`20-comite/acta-comite-2026-10-02.docx`) · **Cerrado:** 420.000.000,00 · **Ponderado con evidencia:** 0,00 · **Ponderado sin evidencia:** 0,00 · **Respaldo:** 420.000.000,00 · **Diferencia:** 210.000.000,00

| Oportunidad | Etapa | Monto | Probabilidad | Ponderado | Con evidencia | Cierre |
|---|---|---|---|---|---|---|

El pronóstico que se compromete es de una persona; aquí solo se dice qué lo sostiene.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-crm/oportunidades-2026-11-03.csv`
- `20-comite/acta-comite-2026-10-02.docx`
