# El embudo contra su evidencia · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-11-03 · **Procesado:** 2026-11-05 · **Agente:** Augusto, versión 1.2.0 · **Comando:** `pipeline-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1103 · Suministro anual: está en «Compromiso» y la ficha no tiene la orden de compra | 250.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 4 |
| 2 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1123 · Pedido marco 23: está en «Compromiso» y la ficha no tiene la orden de compra | 110.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 13 |
| 3 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1122 · Pedido marco 22: está en «Compromiso» y la ficha no tiene la orden de compra | 100.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 12 |
| 4 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1121 · Pedido marco 21: está en «Compromiso» y la ficha no tiene la orden de compra | 90.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 11 |
| 5 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1120 · Pedido marco 20: está en «Compromiso» y la ficha no tiene la orden de compra | 80.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 10 |
| 6 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1107 · Implementación por fases: la fecha de cierre se corrió 3 veces, de 2026-10-31 a 2026-12-18 | 110.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 2 · `10-crm/historial-2026-11-03.csv` fila 3 · `10-crm/historial-2026-11-03.csv` fila 4 |
| 7 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1129 · Renovación anual 29: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 80.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 11 · `10-crm/historial-2026-11-03.csv` fila 12 · `10-crm/historial-2026-11-03.csv` fila 13 |
| 8 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1126 · Prospecto 26: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 70.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 16 |
| 9 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1128 · Renovación anual 28: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 70.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 8 · `10-crm/historial-2026-11-03.csv` fila 9 · `10-crm/historial-2026-11-03.csv` fila 10 |
| 10 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1125 · Prospecto 25: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 60.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 15 |
| 11 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1127 · Renovación anual 27: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 60.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 5 · `10-crm/historial-2026-11-03.csv` fila 6 · `10-crm/historial-2026-11-03.csv` fila 7 |
| 12 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1124 · Prospecto 24: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 50.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 14 |

## El resultado

| Oportunidad | Etapa | Monto | Cierre | Falta | Días sin actividad | Veces corrido |
|---|---|---|---|---|---|---|
| OPP-1101 · Renovación de licencias | Ganada | 120.000.000,00 | 2026-10-10 | — | 26 | 0 |
| OPP-1102 · Proyecto de expansión | Ganada | 180.000.000,00 | 2026-10-22 | — | 14 | 0 |
| OPP-1103 · Suministro anual | Compromiso | 250.000.000,00 | 2026-11-20 | orden compra | 6 | 0 |
| OPP-1104 · Servicio de soporte | Propuesta | 90.000.000,00 | 2026-12-15 | — | 7 | 0 |
| OPP-1105 · Ampliación de contrato | Calificación | 70.000.000,00 | 2026-12-20 | — | 9 | 0 |
| OPP-1107 · Implementación por fases | Negociación | 110.000.000,00 | 2026-12-18 | — | 5 | 3 |
| OPP-1108 · Venta de equipos | Ganada | 50.000.000,00 | 2026-10-05 | — | 31 | 0 |
| OPP-1120 · Pedido marco 20 | Compromiso | 80.000.000,00 | 2026-12-12 | orden compra | 6 | 0 |
| OPP-1121 · Pedido marco 21 | Compromiso | 90.000.000,00 | 2026-12-12 | orden compra | 6 | 0 |
| OPP-1122 · Pedido marco 22 | Compromiso | 100.000.000,00 | 2026-12-12 | orden compra | 6 | 0 |
| OPP-1123 · Pedido marco 23 | Compromiso | 110.000.000,00 | 2026-12-12 | orden compra | 6 | 0 |
| OPP-1124 · Prospecto 24 | Calificación | 50.000.000,00 | 2026-12-18 | — | 61 | 0 |
| OPP-1125 · Prospecto 25 | Calificación | 60.000.000,00 | 2026-12-18 | — | 61 | 0 |
| OPP-1126 · Prospecto 26 | Calificación | 70.000.000,00 | 2026-12-18 | — | 61 | 0 |
| OPP-1127 · Renovación anual 27 | Calificación | 60.000.000,00 | 2026-12-20 | — | 5 | 3 |
| OPP-1128 · Renovación anual 28 | Calificación | 70.000.000,00 | 2026-12-20 | — | 5 | 3 |
| OPP-1129 · Renovación anual 29 | Calificación | 80.000.000,00 | 2026-12-20 | — | 5 | 3 |
| OPP-1130 · Cotización especial 30 | Negociación | 110.000.000,00 | 2026-12-10 | — | 7 | 0 |
| OPP-1131 · Cotización especial 31 | Negociación | 120.000.000,00 | 2026-12-10 | — | 7 | 0 |
| OPP-1132 · Venta directa 32 | Ganada | 30.000.000,00 | 2026-10-06 | — | 30 | 0 |
| OPP-1133 · Venta directa 33 | Ganada | 40.000.000,00 | 2026-10-07 | — | 29 | 0 |

Sin calificar a quien lleva cada oportunidad: la señal es de la oportunidad, no de la persona.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-crm/historial-2026-11-03.csv`
- `10-crm/oportunidades-2026-11-03.csv`
- Fuentes técnicas: F-02 (families/criterio-cco/FUENTES.es.md)
