# Qué cambió en el embudo · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-11-03 · **Procesado:** 2026-11-05 · **Agente:** Augusto, versión 1.2.0 · **Comando:** `pipeline-scan`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Lo comprometido supera lo que suman las oportunidades con evidencia, ponderadas por su etapa, más de la tolerancia configurada (`forecast_unsupported`) | 2026-10: se comprometieron 630.000.000,00 y lo cerrado más lo ponderado con evidencia suma 420.000.000,00; la tolerancia es 10 % | 210.000.000,00 | — | — | `20-comite/acta-comite-2026-10-02.docx` · `10-crm/oportunidades-2026-11-03.csv` |
| 2 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1103 · Suministro anual: está en «Compromiso» y la ficha no tiene la orden de compra | 250.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 4 |
| 3 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1123 · Pedido marco 23: está en «Compromiso» y la ficha no tiene la orden de compra | 110.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 13 |
| 4 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1122 · Pedido marco 22: está en «Compromiso» y la ficha no tiene la orden de compra | 100.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 12 |
| 5 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1121 · Pedido marco 21: está en «Compromiso» y la ficha no tiene la orden de compra | 90.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 11 |
| 6 | Una oportunidad está en una etapa y no tiene el documento que esa etapa exige: la propuesta enviada, la orden de compra (`stage_without_evidence`) | OPP-1120 · Pedido marco 20: está en «Compromiso» y la ficha no tiene la orden de compra | 80.000.000,00 | — | — | `10-crm/oportunidades-2026-11-03.csv` fila 10 |
| 7 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1107 · Implementación por fases: la fecha de cierre se corrió 3 veces, de 2026-10-31 a 2026-12-18 | 110.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 2 · `10-crm/historial-2026-11-03.csv` fila 3 · `10-crm/historial-2026-11-03.csv` fila 4 |
| 8 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1129 · Renovación anual 29: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 80.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 11 · `10-crm/historial-2026-11-03.csv` fila 12 · `10-crm/historial-2026-11-03.csv` fila 13 |
| 9 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1126 · Prospecto 26: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 70.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 16 |
| 10 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1128 · Renovación anual 28: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 70.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 8 · `10-crm/historial-2026-11-03.csv` fila 9 · `10-crm/historial-2026-11-03.csv` fila 10 |
| 11 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1125 · Prospecto 25: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 60.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 15 |
| 12 | La fecha de cierre de una oportunidad se movió más veces de las configuradas (`close_date_slipped`) | OPP-1127 · Renovación anual 27: la fecha de cierre se corrió 3 veces, de 2026-11-08 a 2026-12-20 | 60.000.000,00 | — | — | `10-crm/historial-2026-11-03.csv` fila 5 · `10-crm/historial-2026-11-03.csv` fila 6 · `10-crm/historial-2026-11-03.csv` fila 7 |
| 13 | Una oportunidad abierta no tiene actividad registrada en los días configurados (`stalled_opportunity`) | OPP-1124 · Prospecto 24: abierta en «Calificación», sin actividad desde el 2026-09-05 (61 días) | 50.000.000,00 | — | 61 | `10-crm/oportunidades-2026-11-03.csv` fila 14 |

## El resultado

| Exportación | Fecha | Formato | Oportunidades |
|---|---|---|---|
| `10-crm/oportunidades-2026-10-01.csv` | 2026-10-01 | salesforce | 22 |
| `10-crm/oportunidades-2026-10-16.csv` | 2026-10-16 | salesforce | 22 |
| `10-crm/oportunidades-2026-11-03.csv` | 2026-11-03 | salesforce | 22 |

**Desde la exportación anterior:** 0 nuevas, 1 ganadas, 1 perdidas, 1 cambios de etapa, 0 de monto y 6 de fecha de cierre. **Evidencia en la ficha:** 19 documentos.

- **Etapa:** OPP-1103: Negociación → Compromiso
- **Fecha de cierre:** OPP-1104: 2026-12-10 → 2026-12-15; OPP-1106: 2026-10-30 → 2026-10-28; OPP-1107: 2026-11-30 → 2026-12-18; OPP-1127: 2026-12-01 → 2026-12-20; OPP-1128: 2026-12-01 → 2026-12-20; OPP-1129: 2026-12-01 → 2026-12-20

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-crm/historial-2026-11-03.csv`
- `10-crm/oportunidades-2026-11-03.csv`
- `20-comite/acta-comite-2026-10-02.docx`
- Fuentes técnicas: F-02 (families/criterio-cco/FUENTES.es.md)
