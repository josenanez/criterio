# De lo ganado a la factura · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-10-31 · **Procesado:** 2026-11-05 · **Agente:** Valeria, versión 1.2.0 · **Comando:** `won-to-invoice`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Una oportunidad ganada no tiene su contrato firmado en la ficha de Fidel (`won_without_contract`) | OPP-1108 · Venta de equipos: ganada el 2026-10-05 por 50.000.000,00 y las fichas de Fidel no tienen un contrato firmado con el cliente 830011002 | 50.000.000,00 | — | 31 | `10-crm/oportunidades-2026-11-03.csv` fila 9 |
| 2 | Una oportunidad ganada no tiene su contrato firmado en la ficha de Fidel (`won_without_contract`) | OPP-1133 · Venta directa 33: ganada el 2026-10-07 por 40.000.000,00 y las fichas de Fidel no tienen un contrato firmado con el cliente 830011008 | 40.000.000,00 | — | 29 | `10-crm/oportunidades-2026-11-03.csv` fila 23 |
| 3 | Un contrato firmado no tiene su factura en la ficha de Clara dentro del plazo de facturación (`signed_without_invoice`) | CTR-1131: firmado con el cliente 830011010 el 2026-09-09 y las fichas de Clara no tienen una factura emitida a ese cliente hasta el 2026-10-09 | 40.000.000,00 | — | 27 | `contratos/CTR-1131.json` |
| 4 | Una oportunidad ganada no tiene su contrato firmado en la ficha de Fidel (`won_without_contract`) | OPP-1132 · Venta directa 32: ganada el 2026-10-06 por 30.000.000,00 y las fichas de Fidel no tienen un contrato firmado con el cliente 830011007 | 30.000.000,00 | — | 30 | `10-crm/oportunidades-2026-11-03.csv` fila 22 |
| 5 | Un contrato firmado no tiene su factura en la ficha de Clara dentro del plazo de facturación (`signed_without_invoice`) | CTR-1130: firmado con el cliente 830011009 el 2026-09-08 y las fichas de Clara no tienen una factura emitida a ese cliente hasta el 2026-10-08 | 30.000.000,00 | — | 28 | `contratos/CTR-1130.json` |

## El resultado

| Oportunidad ganada | Cuenta | Monto | Ganada | Contrato (Fidel) | Factura (Clara) |
|---|---|---|---|---|---|
| OPP-1101 · Renovación de licencias | 001A0000110000AaQZ | 120.000.000,00 | 2026-10-10 | CTR-1101 | FE-1101 |
| OPP-1102 · Proyecto de expansión | 001A0000110001AaQZ | 180.000.000,00 | 2026-10-22 | CTR-1102 | FE-1102 |
| OPP-1108 · Venta de equipos | 001A0000110002AaQZ | 50.000.000,00 | 2026-10-05 | — | — |
| OPP-1132 · Venta directa 32 | 001A0000110007AaQZ | 30.000.000,00 | 2026-10-06 | — | — |
| OPP-1133 · Venta directa 33 | 001A0000110008AaQZ | 40.000.000,00 | 2026-10-07 | — | — |

| Contrato | Cliente | Firmado | Plazo de facturación | Factura | Estado |
|---|---|---|---|---|---|
| CTR-1101 | 830011000 | 2026-10-13 | 2026-11-12 | FE-1101 | facturado |
| CTR-1102 | 830011001 | 2026-10-24 | 2026-11-23 | FE-1102 | facturado |
| CTR-1103 | 830011004 | 2026-10-20 | 2026-11-19 | — | en plazo |
| CTR-1130 | 830011009 | 2026-09-08 | 2026-10-08 | — | vencido |
| CTR-1131 | 830011010 | 2026-09-09 | 2026-10-09 | — | vencido |

Plazo de facturación configurado: 30 días. Los contratos y las facturas son los de las fichas de Fidel y de Clara: no se vuelven a procesar.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `10-crm/oportunidades-2026-11-03.csv`
- `contratos/CTR-1130.json`
- `contratos/CTR-1131.json`
