# Los descuentos contra su política · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-10-31 · **Procesado:** 2026-11-05 · **Agente:** Valeria, versión 1.2.2 · **Comando:** `discount-check`

## Lo que hay que atender

| # | Señal | Qué | Monto | Responsable | Días | Cita |
|---|---|---|---|---|---|---|
| 1 | Un descuento supera el tope de su nivel y no tiene la aprobación que pide la matriz, o ningún nivel lo cubre (`discount_outside_policy`) | COT-1103 · OPP-1103: el 22 % cae en el nivel 3, que pide la aprobación de gerente general, y lo aprobó Marta Gil como gerente comercial | 63.800.000,00 | — | — | `40-cotizaciones/COT-1103_cotizacion.pdf` · `00-referencia/matriz-descuentos.csv` fila 4 |
| 2 | Un descuento supera el tope de su nivel y no tiene la aprobación que pide la matriz, o ningún nivel lo cubre (`discount_outside_policy`) | COT-1105 · OPP-1131: el 22 % cae en el nivel 3, que pide la aprobación de gerente general, y lo aprobó Marta Gil como gerente comercial | 28.600.000,00 | — | — | `40-cotizaciones/COT-1105_cotizacion.pdf` · `00-referencia/matriz-descuentos.csv` fila 4 |
| 3 | Un descuento supera el tope de su nivel y no tiene la aprobación que pide la matriz, o ningún nivel lo cubre (`discount_outside_policy`) | COT-1104 · OPP-1130: el 22 % cae en el nivel 3, que pide la aprobación de gerente general, y lo aprobó Marta Gil como gerente comercial | 26.400.000,00 | — | — | `40-cotizaciones/COT-1104_cotizacion.pdf` · `00-referencia/matriz-descuentos.csv` fila 4 |

## El resultado

| Cotización | Oportunidad | Descuento | Nivel | Pide | Aprobó | Cargo | Dentro de la política |
|---|---|---|---|---|---|---|---|
| COT-1101 | OPP-1101 | 10,00 % | 1 | ninguno | — | — | sí |
| COT-1102 | OPP-1102 | 18,00 % | 2 | gerente_comercial | Marta Gil | gerente comercial | sí |
| COT-1103 | OPP-1103 | 22,00 % | 3 | gerente_general | Marta Gil | gerente comercial | no |
| COT-1104 | OPP-1130 | 22,00 % | 3 | gerente_general | Marta Gil | gerente comercial | no |
| COT-1105 | OPP-1131 | 22,00 % | 3 | gerente_general | Marta Gil | gerente comercial | no |

Ningún descuento lo aprueba el agente: aquí se dice cuál no tiene la aprobación que pide la matriz.

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- `00-referencia/matriz-descuentos.csv`
- `40-cotizaciones/COT-1103_cotizacion.pdf`
- `40-cotizaciones/COT-1104_cotizacion.pdf`
- `40-cotizaciones/COT-1105_cotizacion.pdf`
