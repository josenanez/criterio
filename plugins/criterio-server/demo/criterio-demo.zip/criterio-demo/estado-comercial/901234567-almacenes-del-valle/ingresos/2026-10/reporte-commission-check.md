# Las comisiones contra el plan · Almacenes del Valle · periodo 2026-10

**Entidad:** Almacenes del Valle (901234567) · **Fecha de corte:** 2026-10-31 · **Procesado:** 2026-11-05 · **Agente:** Valeria, versión 1.2.2 · **Comando:** `commission-check`

## Lo que hay que atender

Nada abierto en lo que procesa este comando.

## El resultado

| Responsable | Da el plan | Liquidado | Diferencia | Base |
|---|---|---|---|---|
| 005A0000ana_ru | 3.600.000,00 | 3.600.000,00 | 0,00 | OPP-1101 |
| 005A0000luis_m | 5.400.000,00 | 5.400.000,00 | 0,00 | OPP-1102 |

No se publica en Rostrum: son la remuneración de personas identificables (ADR 0019).

## Lo que no se pudo procesar

Todo lo que llegó se procesó.

## Las preguntas que hizo

Ninguna en esta corrida.

## Fuentes

- Sin documentos citados.
