# Tablero de métricas · Compra y recoge

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 141.373 | 2026-10-06 |
