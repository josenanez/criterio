# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2025-09-12
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 284.980 | Caso de negocio, 2025-09-12 |

## Retorno esperado

Retorno esperado en 24 meses.
