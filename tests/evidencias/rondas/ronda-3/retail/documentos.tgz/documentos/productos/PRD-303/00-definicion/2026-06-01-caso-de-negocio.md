# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2026-06-01
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 281.273 | Caso de negocio, 2026-06-01 |

## Retorno esperado

Retorno esperado en 24 meses.
