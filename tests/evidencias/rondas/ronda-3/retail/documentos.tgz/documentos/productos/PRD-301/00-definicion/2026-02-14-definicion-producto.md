# Definición de producto · Puntos de fidelización

**Código:** PRD-301
**Gerente de producto:** Javier Hoyos
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-02-14

## El problema

El segmento Pequeños negocios no tiene puntos de fidelización.

## La propuesta

- Propuesta principal

## Supuestos

- **Las tiendas soportan el volumen** · declarado el 2026-08-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
