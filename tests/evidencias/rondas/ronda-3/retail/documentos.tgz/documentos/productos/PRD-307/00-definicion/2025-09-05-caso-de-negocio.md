# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2025-09-05
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 176.706 | Caso de negocio, 2025-09-05 |

## Retorno esperado

Retorno esperado en 24 meses.
