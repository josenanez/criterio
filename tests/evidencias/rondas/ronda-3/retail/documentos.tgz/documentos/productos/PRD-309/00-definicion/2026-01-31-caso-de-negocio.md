# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-01-31
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 121.235 | Caso de negocio, 2026-01-31 |

## Retorno esperado

Retorno esperado en 24 meses.
