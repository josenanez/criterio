# Definición de producto · Tarjeta de la tienda

**Código:** PRD-309
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-01-31

## El problema

El segmento Clientes frecuentes no tiene tarjeta de la tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-04-15 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
