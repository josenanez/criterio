# Entrevistas · Venta en línea

**Ronda:** Ronda · 2026-08-18
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2026-08-18

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
