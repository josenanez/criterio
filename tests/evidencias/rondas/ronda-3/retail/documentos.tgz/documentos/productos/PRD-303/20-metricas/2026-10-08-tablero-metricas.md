# Tablero de métricas · Pago con QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 286.719 | 2026-10-08 |
