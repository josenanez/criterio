# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2026-02-14
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 130.211 | Caso de negocio, 2026-02-14 |

## Retorno esperado

Retorno esperado en 24 meses.
