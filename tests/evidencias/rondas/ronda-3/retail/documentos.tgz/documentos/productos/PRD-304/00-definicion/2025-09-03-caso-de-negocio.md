# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2025-09-03
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 164.469 | Caso de negocio, 2025-09-03 |

## Retorno esperado

Retorno esperado en 24 meses.
