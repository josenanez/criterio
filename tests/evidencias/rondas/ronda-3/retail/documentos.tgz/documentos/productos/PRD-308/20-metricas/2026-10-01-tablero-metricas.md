# Tablero de métricas · Marketplace

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 131.628 | 2026-10-01 |
