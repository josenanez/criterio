# Definición de producto · Entrega rápida

**Código:** PRD-305
**Gerente de producto:** Jorge Medina
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-06-19

## El problema

El segmento Jóvenes no tiene entrega rápida.

## La propuesta

- Propuesta principal

## Supuestos

- **Las tiendas soportan el volumen** · declarado el 2026-05-16 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
