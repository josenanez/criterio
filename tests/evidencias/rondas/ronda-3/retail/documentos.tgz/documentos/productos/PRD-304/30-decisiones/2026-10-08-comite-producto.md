# Comité de producto · Marca propia

**Fecha:** 2026-10-08
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | María Restrepo | — | — | aceptado | 2026-06-26 | — |
| REQ-4401 | Requerimiento REQ-4401 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-03-18 | — |
| REQ-4402 | Requerimiento REQ-4402 | Óscar Ramírez | — | Cliente entrevistado | propuesto | 2026-08-30 | — |
| REQ-4403 | Requerimiento REQ-4403 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-22 | — |
| REQ-4404 | Requerimiento REQ-4404 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4405 | Requerimiento REQ-4405 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4406 | Requerimiento REQ-4406 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-22 | — |
| REQ-4407 | Requerimiento REQ-4407 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-10 | — |
| REQ-4408 | Requerimiento REQ-4408 | Felipe Arango | — | Cliente entrevistado | propuesto | 2026-06-22 | — |
| REQ-4409 | Requerimiento REQ-4409 | Beatriz Cuéllar | — | — | propuesto | 2026-06-09 | — |
| REQ-4410 | Requerimiento REQ-4410 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-01 | — |
| REQ-4411 | Requerimiento REQ-4411 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-30 | — |
| REQ-4412 | Requerimiento REQ-4412 | Jorge Medina | — | Cliente entrevistado | propuesto | 2026-04-10 | — |
| REQ-4413 | Requerimiento REQ-4413 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-08-05 | — |

## Decisiones

- Se mantiene el plan
