# Entrevistas · Compra y recoge

**Ronda:** Ronda · 2026-06-20
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-06-20

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
