# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Natalia Ospina
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-09-05

## El problema

El segmento Jóvenes no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **Las tiendas soportan el volumen** · declarado el 2026-04-04 · verificado

## Proyectos que lo construyen

- Ninguno declarado
