# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2025-12-29
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 153.229 | Caso de negocio, 2025-12-29 |

## Retorno esperado

Retorno esperado en 24 meses.
