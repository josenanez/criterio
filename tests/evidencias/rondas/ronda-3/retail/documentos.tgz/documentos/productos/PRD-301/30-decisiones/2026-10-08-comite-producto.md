# Comité de producto · Puntos de fidelización

**Fecha:** 2026-10-08
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-4101 | Requerimiento REQ-4101 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-08-23 | — |
| REQ-4102 | Requerimiento REQ-4102 | Sandra Gil | se verifica en producción | — | aceptado | 2026-07-03 | — |
| REQ-4103 | Requerimiento REQ-4103 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-18 | — |
| REQ-4104 | Requerimiento REQ-4104 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-09 | — |
| REQ-4105 | Requerimiento REQ-4105 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-28 | — |
| REQ-4106 | Requerimiento REQ-4106 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4107 | Requerimiento REQ-4107 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-03-20 | — |
| REQ-4108 | Requerimiento REQ-4108 | Sandra Gil | se verifica en producción | — | propuesto | 2026-05-18 | — |
| REQ-4109 | Requerimiento REQ-4109 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4110 | Requerimiento REQ-4110 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4111 | Requerimiento REQ-4111 | sin asignar | se verifica en producción | — | propuesto | 2026-04-22 | — |
| REQ-4112 | Requerimiento REQ-4112 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-29 | — |
| REQ-4113 | Requerimiento REQ-4113 | Carlos Peña | se verifica en producción | — | aceptado | 2026-08-01 | — |
| REQ-2028 | Requerimiento REQ-2028 | Carlos Peña | se verifica en producción | — | aceptado | 2026-10-06 | — |

## Decisiones

- Se mantiene el plan
