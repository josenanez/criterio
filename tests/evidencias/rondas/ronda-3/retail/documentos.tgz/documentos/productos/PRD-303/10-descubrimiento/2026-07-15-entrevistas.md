# Entrevistas · Pago con QR

**Ronda:** Ronda · 2026-07-15
**Realizadas por:** Andrés Lozano

### Cliente entrevistado · 2026-07-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
