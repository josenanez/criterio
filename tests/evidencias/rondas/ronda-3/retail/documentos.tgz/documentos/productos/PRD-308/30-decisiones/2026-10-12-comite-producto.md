# Comité de producto · Marketplace

**Fecha:** 2026-10-12
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Carlos Peña | se verifica en producción | — | aceptado | 2026-04-09 | — |
| REQ-4801 | Requerimiento REQ-4801 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-03-30 | — |
| REQ-4802 | Requerimiento REQ-4802 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4803 | Requerimiento REQ-4803 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-04 | — |
| REQ-4804 | Requerimiento REQ-4804 | Natalia Ospina | se verifica en producción | — | propuesto | 2026-07-06 | — |
| REQ-4805 | Requerimiento REQ-4805 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-02 | — |
| REQ-4806 | Requerimiento REQ-4806 | Gustavo Neira | — | — | aceptado | 2026-06-28 | — |
| REQ-4807 | Requerimiento REQ-4807 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-05-15 | — |
| REQ-4808 | Requerimiento REQ-4808 | sin asignar | — | Cliente entrevistado | propuesto | 2026-05-24 | — |
| REQ-4809 | Requerimiento REQ-4809 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4810 | Requerimiento REQ-4810 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-31 | — |
| REQ-4811 | Requerimiento REQ-4811 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-15 | — |
| REQ-4812 | Requerimiento REQ-4812 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4813 | Requerimiento REQ-4813 | Liliana Torres | — | — | aceptado | 2026-06-09 | — |
| REQ-4814 | Requerimiento REQ-4814 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-04-02 | — |
| REQ-4815 | Requerimiento REQ-4815 | sin asignar | se verifica en producción | — | aceptado | 2026-04-26 | — |
| REQ-2030 | Requerimiento REQ-2030 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-25 | — |

## Decisiones

- Se mantiene el plan
