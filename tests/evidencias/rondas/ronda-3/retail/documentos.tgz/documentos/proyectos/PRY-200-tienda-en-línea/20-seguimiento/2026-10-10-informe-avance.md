# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **79%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.907.260.262 |
| Ejecutado | 1.428.337.704 |
| Proyección al cierre | 6.443.130.992 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
