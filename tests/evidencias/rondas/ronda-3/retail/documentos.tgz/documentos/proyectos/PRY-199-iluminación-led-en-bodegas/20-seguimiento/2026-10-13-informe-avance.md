# Informe de avance · Iluminación LED en bodegas

**Código:** PRY-199
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la regulación de datos personales que puede mover el alcance
