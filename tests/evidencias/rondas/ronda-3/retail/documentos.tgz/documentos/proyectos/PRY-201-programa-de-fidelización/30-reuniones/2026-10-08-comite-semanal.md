# Comité Comercial · Programa de fidelización

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-12-03 |
| Sandra Gil | Cerrar la prueba 2 | 2026-12-03 |
| Ricardo Salas | Revisar el anexo 3 | 2026-10-29 |
| Laura Vélez | Aprobar el diseño 5 | 2026-11-06 |
| Carlos Peña | Enviar el documento 9 | 2026-10-29 |
| Óscar Ramírez | Aprobar el diseño 13 | 2026-10-09 |
| Jorge Medina | Actualizar la matriz 14 | 2026-10-12 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-23 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-11 |
| Elena Duarte | Revisar el anexo 19 | 2026-11-03 |
| María Restrepo | Aprobar el diseño 21 | 2026-10-20 |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-17 |
| Camilo Beltrán | Confirmar la fecha 23 | 2026-11-03 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-26 |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Javier Hoyos): recibido, acta de recibo del 2026-10-08.
- Confirmar la fecha 7 (Diana Molina): recibido, acta de recibo del 2026-10-08.
- Confirmar la fecha 15 (Elena Duarte): recibido, acta de recibo del 2026-10-08.
- Entregar el punto 16 (Felipe Arango): recibido, acta de recibo del 2026-10-08.
- Validar el ambiente 20 (Camilo Beltrán): recibido, acta de recibo del 2026-10-08.
