# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Servicio al cliente
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Expansión
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-19

## Objetivo del negocio

Entregar reposición automática para Servicio al cliente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Expansión el 2025-09-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-29 |
| Cierre | 2026-08-25 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
