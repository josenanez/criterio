# Comité Comercial · Programa de fidelización

**Fecha:** 2026-10-01
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-24 |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-14 |
| Ricardo Salas | Revisar el anexo 3 | 2026-10-29 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-23 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-22 |
| Diana Molina | Confirmar la fecha 7 | 2026-10-16 |
| Carlos Peña | Enviar el documento 9 | 2026-10-22 |
| Óscar Ramírez | Aprobar el diseño 13 | 2026-10-09 |
| Jorge Medina | Actualizar la matriz 14 | 2026-10-12 |
| Elena Duarte | Confirmar la fecha 15 | 2026-09-30 |
| Felipe Arango | Entregar el punto 16 | 2026-10-29 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-08 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-11 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-26 |
| Camilo Beltrán | Validar el ambiente 20 | 2026-10-26 |
