# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-03
**Gerente:** Laura Vélez

## Estado declarado

**Rojo**

Avance reportado: **27%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.118.711.556 |
| Ejecutado | 1.299.157.774 |
| Proyección al cierre | 3.372.805.853 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
