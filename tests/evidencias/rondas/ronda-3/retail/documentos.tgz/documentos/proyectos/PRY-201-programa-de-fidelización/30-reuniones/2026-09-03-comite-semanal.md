# Comité Comercial · Programa de fidelización

**Fecha:** 2026-09-03
**Asistentes:** Diana Molina, Felipe Arango, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-23 |
| Sandra Gil | Cerrar la prueba 2 | 2026-09-21 |
| Ricardo Salas | Revisar el anexo 3 | por definir |
| Felipe Arango | Validar el ambiente 4 | 2026-09-30 |
