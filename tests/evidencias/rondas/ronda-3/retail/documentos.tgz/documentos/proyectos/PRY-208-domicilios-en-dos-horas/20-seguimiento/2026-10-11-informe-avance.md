# Informe de avance · Domicilios en dos horas

**Código:** PRY-208
**Fecha de corte:** 2026-10-11
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **81%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.667.124.370 |
| Ejecutado | 2.364.534.774 |
| Proyección al cierre | 8.103.742.416 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- Concentración del conocimiento en una sola persona
