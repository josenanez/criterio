# Acta de constitución · Pronóstico de demanda

**Código:** PRY-211
**Área dueña:** Comercio electrónico
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Expansión
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-27

## Objetivo del negocio

Entregar pronóstico de demanda para Comercio electrónico.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Expansión el 2025-05-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-06 |
| Cierre | 2027-01-26 |

## Criterio de éxito

Pronóstico de demanda en producción y medido.

## Dependencias declaradas

- Ninguna declarada
