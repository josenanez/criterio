# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.065.681.148 |
| Ejecutado | 2.002.590.000 |
| Proyección al cierre | 3.958.059.174 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
