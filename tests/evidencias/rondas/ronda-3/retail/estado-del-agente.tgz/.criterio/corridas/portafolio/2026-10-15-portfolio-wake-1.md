# Corrida · 2026-10-15-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T17:26:18 · **Fin:** 2026-10-15T17:27:00 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 28 | 61 | Barrido: 88 documentos sin cambios, 11 citas pm_record de PRY-201 sin resolver por ruta sin carpeta del proyecto. Confirmación: 5 preguntas sobre PRY-201 sin respondedor. No sé cuál fecha de fin es la vigente ni cuál cifra comprometido/ejecutado es correcta. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé la corrida de hoy, 2026-10-15: toca barrido y confirmación, y quedó registrada.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hubo que registrarlos de nuevo.
- **Barrido:** revisé 88 documentos y ninguno cambió, así que no recalculé ningún proyecto. En el índice, 11 citas del bloque `pm_record` de PRY-201 no resuelven. Apuntan a `00-gobierno/2025-05-10-acta-constitucion.docx` sin la carpeta del proyecto, aunque el archivo existe. No releí nada.
- **Peticiones:** no había ninguna en el servidor.
- **Confirmación:** quedaron cinco preguntas sobre PRY-201, sin respuesta porque nadie contesta en esta prueba. Son estas:
  - fecha de fin (2026-10-16 en el cronograma contra 2026-12-07 en el acta);
  - estado «verde» con avance de 39 %;
  - comprometido menor que ejecutado;
  - proyección por encima de lo aprobado;
  - fase y autoridad vacías.
- **Próxima vez:** vuelvo el 2026-10-16. El informe de comité del 22 de octubre toca el 2026-10-20.

Lo que escribí quedó en `estado/corridas/salida-portfolio-wake.md`, y la corrida en `estado/corridas/2026-10-15-portfolio-wake-1`. No sé cuál fecha de fin es la vigente ni cuál cifra de comprometido y ejecutado es la correcta; lo dejé anotado como pregunta abierta.
