# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T17:11:13 · **Fin:** 2026-10-15T17:11:48 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 19 | 61 | 88 documentos sin cambio, 0 por releer; 11 citas de PRY-201 al acta de constitución no resuelven aunque el archivo existe en disco; causa no determinada |

Por señal (`document-index`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

La carpeta está sin cambios: de 88 documentos, 88 siguen igual, así que no hay nada que releer. Hay un problema: 11 citas de PRY-201 no resuelven.

**Carpeta al 2026-10-15**

- **Cambios:** no hay documentos nuevos, modificados, reguardados, renombrados ni borrados.
- **Citas rotas:** son 11 campos de PRY-201 (`identity.code`, `name`, `business_area`, `product`, `sponsor`, `manager`, `committee`, `plan.start_date`, `plan.end_date`, `money.currency` y `money.approved`). Todos citan `00-gobierno/2025-05-10-acta-constitucion.docx`.
- **Causa sin determinar:** el archivo sí existe en `PRY-201-programa-de-fidelización/00-gobierno/`. No está borrado ni renombrado. No sé por qué el índice no lo resuelve; sospecho de cómo se escribe la ruta, pero no lo verifiqué. Hasta revisarlo, esos 11 campos se siguen mostrando como sustentados sin que el índice los pueda comprobar.
- **Formatos ilegibles:** el índice no reportó ninguno.
- **Barrido y renombrados:** no ofrezco `/portfolio-scan`, porque no hay proyectos tocados. Tampoco hay citas que corregir por renombrado.

**Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Registro de la corrida:** guardé la salida en `estado/corridas/salida-document-index.md` y la corrida quedó registrada con id `2026-10-15-document-index-1`. Duró 19 segundos. El registro anota 61 hallazgos abiertos en los 13 proyectos, que vienen de las fichas y no de este índice. La corrida no registró cuántos documentos leyó.
