# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-205 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T17:16:42 · **Fin:** 2026-10-15T17:17:51 · **Duración:** 70 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 54 | 61 | Solicitud de mover 30 días la salida a producción de PRY-205 (2026-12-03 a 2027-01-02). Impacto en portafolio: 0 proyectos, pero porque no hay dependencias declaradas, no porque no existan. No sé: motivo, solicitante, impacto en alcance y costo, autoridad que aprueba, holgura, cuál es la fecha de cierre válida (acta 2027-01-16 vs cronograma). Va a comité por defecto. No se registró línea base nueva. |

Por señal (`change-control`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Esta es la solicitud de cambio de PRY-205 (mover 30 días la salida a producción), tomada de la ficha. Quedó guardada en `estado/corridas/salida-change-control.md` y la corrida `2026-10-15-change-control-1` quedó registrada.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no registré una aceptación nueva.
- **Tiempo:** «Despliegue en la cadena» pasa del 2026-12-03 al 2027-01-02. Solo hay una línea base, la v1 del 2025-09-15, sin replanificaciones.
- **Alcance y costo:** la solicitud no declara impacto en ninguno de los dos. El margen contra el presupuesto aprobado es de 241,9 millones de COP (5,8 %), y el mes extra saldría de ahí, de horas no pagadas o de calidad.
- **Portafolio:** el cálculo no alcanza ningún proyecto, pero no sirve como respuesta. El acta declara «Ninguna declarada» en dependencias, así que el cero viene de que nadie las registró. Tampoco hay holgura por actividad, y no calculé cuántos días se mueve cada hito.
- **Quién decide:** el acta no declara autoridad. Lo llevo a comité por defecto (el próximo es el 2026-10-22). Esa conclusión es mía, no del documento.
- **Fechas que no cuadran:** el acta fija el cierre en 2027-01-16 y el cronograma pone el despliegue en 2026-12-03. Con el cambio quedarían 14 días para «medido», y ningún documento dice cuánto tarda esa medición.
- **Informe verde:** el informe del 14 de octubre dice verde con 37 % de avance, pero ya se ejecutó el 47,7 % del presupuesto.
- **Proveedor CT-377:** los cuatro entregables constan pendientes y sus fechas ya pasaron. Aun así hay una factura radicada de 247,7 millones sin acta de recibo.
- **Hitos y compromiso:** hay un compromiso vencido de Sandra Gil. El hito «Ambiente de pruebas certificado» tiene acta de recibo del 2026-10-03, unos 200 días después de lo previsto, y no figura como atraso.
- **Línea base:** no registré línea base nueva, porque nadie con autoridad la aprobó.
- **Pendiente:** falta el motivo, quién lo pide y quién absorbe el mes extra. Cuando estén esos datos puedo preparar el paquete para el comité con `/steering-pack`.

Como la sesión era sin interfaz, la solicitud queda incompleta sin esos datos.
