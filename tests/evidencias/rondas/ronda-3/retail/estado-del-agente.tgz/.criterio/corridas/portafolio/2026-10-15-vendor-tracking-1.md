# Corrida · 2026-10-15-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-15T17:15:34 · **Fin:** 2026-10-15T17:16:36 · **Duración:** 62 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 48 | 61 | Cruce de dos proveedores de PRY-201: facturado sobre lo aceptado en CT-963 (233.700.888 COP), licenciamiento CT-978 aceptado sin acta. Dijo que no sabe: vigencia y preaviso de ambos contratos, desglose de facturas, firma de actas, estado de pago. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Revisé los dos proveedores de PRY-201. Hay dos cobros sin acta que los respalde, y ningún contrato trae vigencia ni preaviso. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15, así que seguí sin pedir nada.

**Tecnología para Tiendas Ltda. (CT-963)**
- Facturó 921.509.752 COP (FV-1963), pero solo hay acta de recibo por 687.808.864 COP. Quedan **233.700.888 COP facturados sin acta**.
- Dos entregables siguen pendientes y sin evidencia: Licenciamiento de la plataforma (400 días de atraso) y Bolsa de horas de desarrollo (287 días).
- Los dos entregables con acta son Configuración del catálogo y Soporte del primer trimestre.

**Datos y Demanda S.A.S. (CT-978)**
- El Licenciamiento de la plataforma figura como aceptado y está incluido en la factura FV-2978, pero **no hay acta ni otro documento que lo pruebe**.
- Solo tiene acta la Bolsa de horas de desarrollo. El facturado (966.093.580 COP) cuadra con el aceptado únicamente si se cuenta ese licenciamiento.

**Lo que no sé**
- **Contratos:** no traen vigencia, renovación ni preaviso. No puedo decir si algún preaviso vence antes del cierre.
- **Facturas:** FV-1963 y FV-2978 son un valor global, sin desglose de qué entregables cobran. Tampoco sé si ya se pagaron: figuran "radicadas en cuentas por pagar".
- **Actas:** las que leí dicen "Recibido por: Diana Molina". Desde la copia en texto no puedo confirmar que estén firmadas, y el contrato exige firma del gerente.
- **Compromisos:** ninguno de los de los comités nombra a un proveedor. La nota del 2026-10-15 sobre un riesgo con "el proveedor" no dice de cuál habla, y nadie lo registró como riesgo.

Como siguiente paso, ofrezco llevar los dos cobros al comité del 2026-10-22, antes de aprobar su pago si aún no se hizo.

El informe completo quedó en `estado/corridas/salida-vendor-tracking.md` y la corrida registrada con id `2026-10-15-vendor-tracking-1`. El registro contó 13 proyectos y 61 hallazgos en total, porque el cálculo corre sobre todo el portafolio.
