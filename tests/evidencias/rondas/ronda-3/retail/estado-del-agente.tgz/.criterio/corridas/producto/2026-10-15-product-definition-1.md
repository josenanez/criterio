# Corrida · 2026-10-15-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:50:20 · **Fin:** 2026-10-15T16:51:04 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 17 | — | 28 | 28 | Volumen declarado 37% sobre lo medido; sin criterio de éxito ni autoridad; supuesto regulatorio marcado verificado sin sustento; demanda sostenida solo por una entrevista |

Por señal (`product-definition`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

Contrasté la definición de PRD-308 Marketplace contra la evidencia que hay: solo una cifra la contradice y la demanda está sostenida por una sola entrevista. Los términos ya estaban vigentes y aceptados a nombre de José Francisco Ñáñez el 2026-10-15, así que no los registré de nuevo.

- **Contradicción:** el caso de negocio (2025-10-14) declara un volumen mensual de 209.097. El tablero de métricas (corte 2026-10-01) mide 131.628, o sea 37 % por debajo, con el umbral en 20 %. La serie medida tiene un solo punto.
- **Nadie lo mide:** el «retorno esperado en 24 meses» no trae cifra ni base, así que no hay nada con qué contrastarlo.
- **Lo que no está dicho en ninguna parte:**
  - El criterio de éxito.
  - Quién decide. La configuración dice «Comité de producto», pero la definición no lo escribe.
  - La propuesta: solo dice «Propuesta principal», sin contenido.
  - Que el problema sea del segmento Empresas: la única entrevista (2026-02-08) no dice el segmento del cliente.
  - De dónde sale el 209.097.
  - Qué proyecto lo construye: «Ninguno declarado».
- **Supuesto:** «La regulación de datos lo permite» figura como verificado, pero no dice quién ni con qué. La fecha de declaración (2026-07-22) es posterior a la del documento (2025-10-14). Lo traté como verificación sin sustento y lo dejé como candidato a riesgo con doliente.
- **Evidencia:** la demanda se apoya en una sola cita («Lo necesito y hoy no lo tengo»), débil y sin segmento. Nada pasa el umbral de 12 meses; lo más nuevo es de hace 8 meses.
- **Normativo:** el estado es «no tengo la norma a la vista». La definición no declara país, así que no puedo nombrar la norma.
- **Cierre:** la definición no está cerrada, por eso no ofrecí `/product-charter`.

La corrida quedó registrada como `2026-10-15-product-definition-1` con 28 hallazgos (13 de ellos requerimientos aceptados sin proyecto) y 28 segundos medidos.

Archivos en `estado-producto/PRD-308/corridas/`:
- `salida-product-definition.md`
