# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view autopago en tienda

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T17:24:34 · **Fin:** 2026-10-15T17:25:13 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 23 | 61 | Producto de un solo proyecto (PRY-204): sin sección completa. 2 señales. No se sabe qué fuentes son evidencia o declaración (18 sin marcar); área dueña de los 6 proyectos sin producto no disponible. |

Por señal (`product-view`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Autopago en tienda** tiene un solo proyecto, PRY-204 (Cajas de autopago). La vista por producto no aporta nada ahí, así que no armé la sección completa. Los cálculos son del 2026-10-15. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), por eso no los registré de nuevo.

- **Aprobado y comprometido:** COP 4.200.000.000 aprobados y COP 3.287.754.922 comprometidos (78,3 %). Las cuatro cifras de dinero vienen completas.
- **Ejecutado y proyección:** COP 2.100.594.572 ejecutados (50,0 %). La proyección es COP 3.923.148.729, es decir −6,6 % frente al aprobado.
- **Fecha:** la más tardía es 2027-08-21, de PRY-204. No hay desviación ni replanes frente a la línea base.
- **Señal 1:** el hito «Diseño de la experiencia aprobado» (vencía 2026-07-20, hace 87 días) está declarado cumplido sin evidencia.
- **Señal 2:** el compromiso de Mauricio Pérez, «Entregar el punto 21», no tiene fecha.
- **Estado declarado:** el informe de avance de hoy declara rojo.
- **Avance:** declara 33 % y el plan sustenta entre 25 % y 50 %, sin brecha.
- **Dependencias:** no hay dependencias internas que llevar al comité.
- **Sin producto declarado:** seis de los 13 proyectos no declaran producto: PRY-202, 203, 206, 209, 210 y 211. No pude poner el área dueña porque ningún proyecto trae autoridad. Tampoco sé si alguno de esos seis sirve a autopago.
- **Evidencia sin marcar:** las 18 fuentes de la ficha de PRY-204 no están marcadas como evidencia ni como declaración. No sé cuáles de esos datos son evidencia.

La corrida quedó registrada como `2026-10-15-product-view-1` y tardó 23 segundos. El texto que muestro aquí está guardado en `estado/corridas/salida-product-view.md`.
