# Corrida · 2026-10-15-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:51:10 · **Fin:** 2026-10-15T16:52:00 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 17 | — | 34 | 28 | Caso de negocio armado: 1 cifra declarada contra 1 medida (37 % de diferencia), retorno sin cifra, costos ausentes, criterio de éxito no declarado, cruce con otros productos no posible (sin fichas publicadas). |

Por señal (`product-business-case`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_without_owner` 2, `claim_vs_metric` 1

## Lo que el agente mostró

Armé el caso de negocio de Marketplace (PRD-308) y dejé la corrida registrada. Es una estructura con vacíos señalados: no calcula retorno ni recomienda aprobar o rechazar.

Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-15, así que no los registré de nuevo.

- **Cifra que no coincide:** el caso declara un volumen mensual de 209.097 (2025-10-14) y el tablero mide 131.628 (corte 2026-10-01). La declarada queda 37 % por encima de la medida, con el umbral en 20 %. La serie medida tiene un solo punto.
- **Retorno sin cifra:** «Retorno esperado en 24 meses» no trae valor ni base, así que entra como supuesto.
- **Costos:** ningún documento trae el costo de construir ni el de operar. Ese es el primer vacío y, sin él, esto es una propuesta y no un caso evaluable.
- **Criterio de éxito:** no está declarado en ninguna parte, así que no se sabe cómo se verificaría que funcionó.
- **Demanda:** 13 de los 17 requerimientos están aceptados, pero ninguno tiene proyecto que lo ejecute. Cinco de ellos no tienen quién los pidió, y los otros ocho citan la misma entrevista de 2026-02-08.
- **Otros productos:** no hay fichas publicadas, así que el cruce de `/product-overlap` no se pudo hacer. Los casos de PRD-299 a PRD-309 declaran el mismo tipo de volumen, pero ninguno repite el valor 209.097.

No ofrecí `/product-charter`, porque al caso le faltan costo y criterio de éxito. Sí propuse pasar los cuatro supuestos a `assumption-tracking`. El regulatorio es el más débil: figura como verificado sin decir quién ni con qué.

Archivos en `estado-producto/PRD-308/corridas/`:
- `salida-product-business-case.md`
- `2026-10-15-product-business-case-1.md`
