# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-15T17:21:51 · **Fin:** 2026-10-15T17:22:29 · **Duración:** 38 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 24 | 61 | Revisión del acta PRY-203 (2025-09-19): falta autoridad del gerente, supuestos, restricciones, hitos, medidor del éxito y cadencia; objetivo y alcance no medibles. No supe qué se acordó fuera del acta y el informe del 2026-10-14. |

Por señal (`project-charter`): `milestone_met_without_evidence` 18, `commitment_overdue` 7, `declared_vs_evidence` 7, `vendor_deliverable_late` 7, `progress_vs_plan` 6, `commitment_undated` 3, `commitment_rescheduled` 3, `vendor_invoiced_over_accepted` 2, `vendor_accepted_without_evidence` 2, `milestone_overdue` 2, `variance_cost` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Acta de PRY-203 Reposición automática: revisión**

Hay acta previa, del 2025-09-19, aprobada por el Comité de Expansión. Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no existe. Laura Vélez no tiene un monto ni un tipo de cambio que pueda decidir sin comité, así que todo sube al Comité de Expansión. Hoy la proyección es 6.986.277.909 COP contra 6.800.000.000 aprobados (+2,7 %), y el acta no dice quién decide ese sobrecosto.
- **Objetivo de negocio:** describe la solución ("Entregar reposición automática para Servicio al cliente"), no un resultado medible.
- **Alcance:** "Componente 1, 2 y 3" sin definirlos, así que no se puede detectar crecimiento de alcance.
- **Exclusiones:** dice "Lo que otro proyecto cubre" sin nombrar ningún proyecto.
- **Supuestos y restricciones:** ausentes. Ya hay un riesgo abierto de congelamiento en temporada alta que podría haber sido una restricción conocida.
- **Criterio de éxito:** "en producción y medido", sin umbral. Tampoco dice quién lo mide.
- **Hitos y cadencia del comité:** ausentes.
- **Dependencias:** el acta dice "Ninguna declarada", pero el informe del 2026-10-14 menciona un proveedor que no ha confirmado su última entrega.

**Fuera del acta:** la fecha de cierre pactada (2026-08-25) ya pasó. Solo existe la versión 1 de la línea base, y el informe del 2026-10-14 declara rojo con 50 % de avance.

**Lo que no sé:** qué se acordó fuera del acta y del informe del 2026-10-14. No hay minutas ni cambios aprobados en la carpeta.

**Siguiente paso:** ofrezco llevar la definición de la autoridad del gerente al comité del 2026-10-22 y pasar dos supuestos al registro RAID. No tomé ninguna de las dos acciones.

La salida completa quedó en `estado/corridas/salida-project-charter.md` y la corrida en `2026-10-15-project-charter-1`.

El registro de la corrida muestra 13 proyectos y 61 hallazgos. Eso es el conteo de señales abiertas de todo el portafolio, no de esta revisión. Para PRY-203 no hay ninguna señal abierta.
