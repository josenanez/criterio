# Corrida · 2026-10-15-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T17:02:58 · **Fin:** 2026-10-15T17:03:54 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 39 | 8 | Dos puntos: autoridad de la gerente no declarada en el acta, y cierre 12-07 vs 12-17 (documento 1, 6 reprogramaciones). impact devolvió 0 alcanzados: la ficha no tiene hitos ni dependencias. No supe: costo de cada opción, qué bloquea el documento 1, si el documento 1 está en el camino crítico. |

Por señal (`pm-escalate`): `commitment_overdue` 4, `commitment_rescheduled` 3, `commitment_undated` 1

## Lo que el agente mostró

Armé el paquete de decisión de PRY-201 con dos puntos, y la corrida quedó registrada como `2026-10-15-pm-escalate-1`. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (versión 0.3.9, comprobante del 2026-10-15), así que no hubo que aceptarlos de nuevo.

1. **Autoridad de la gerente.** El acta del 2025-05-10 no dice qué puede decidir Diana Molina, así que este punto va primero. Recomiendo que el comité la declare por escrito, con un umbral de días y de COP.
2. **Cierre del 12-07 al 12-17.** El documento 1 de Paula Céspedes se movió 6 veces y su fecha vigente cae 10 días después del cierre. La prueba 2 de Sandra Gil se movió 5 veces y su fecha vigente (12-03) queda 4 días antes. Recomiendo primero exigir a Paula que nombre el bloqueo y una fecha que quepa, y aceptar el 12-17 solo si no cabe.

- **Efecto del cambio:** el cálculo de impacto de 10 días dio 0 proyectos y 0 hitos alcanzados. Eso refleja que la ficha no tiene hitos ni dependencias cargados, no que nadie quede afectado, así que quién depende de PRY-201 queda sin verificar.
- **Costo de cada opción:** no está documentado en lo que leí. Los contratos CT-963 y CT-978 existen en la carpeta, pero la ficha no los tiene cargados y no los abrí.
- **Supuesto sin confirmar:** que el documento 1 está en el camino crítico del cierre. Ningún documento lo dice.
- **Reunión:** la configuración dice comité semanal (10-22), pero las notas del 10-15 dicen «en dos semanas» (10-29). Hay que confirmar la fecha.

Dejé fuera del paquete los 5 vencidos sin evidencia y el riesgo del proveedor sin registrar, porque son decisiones de la gerente, no del comité. Llevar el paquete al comité y llamar a Felipe Arango (patrocinador) es tuyo.

La salida completa quedó en `estado/PRY-201-programa-de-fidelización/corridas/salida-pm-escalate.md`.
