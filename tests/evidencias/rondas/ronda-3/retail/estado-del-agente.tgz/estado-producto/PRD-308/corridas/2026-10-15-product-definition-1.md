# Corrida del 2026-10-15 · product-definition

PRD-308 · 17 requerimientos · 28 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Volumen declarado 37% sobre lo medido; sin criterio de éxito ni autoridad; supuesto regulatorio marcado verificado sin sustento; demanda sostenida solo por una entrevista

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Definición — Marketplace (PRD-308) · contrastada al 2026-10-15
**Documento:** 00-definicion/2025-10-14-definicion-producto.docx y 00-definicion/2025-10-14-caso-de-negocio.md · **del** 2025-10-14 · 6 afirmaciones

*Términos vigentes (v1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta volver a registrarlos. Sesión sin interfaz: no se hicieron preguntas.*

### Lo que la evidencia contradice
| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| Volumen mensual de 209.097 | Se mide 131.628: el declarado está 37 % por encima (umbral 20 %) | Caso de negocio, 2025-10-14 · tablero de métricas (bodega de datos), corte 2026-10-01 |

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 209.097 | 131.628 | 37 % por encima de lo medido | 00-definicion/2025-10-14-caso-de-negocio.md (2025-10-14) · 20-metricas/2026-10-01-tablero-metricas.md (2026-10-01) |

La serie tiene un solo punto; no se puede decir si 131.628 es tendencia o una foto.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» (sin cifra ni base) | 2025-10-14-caso-de-negocio.md | No hay serie ni cifra de retorno; nadie está midiendo lo que el caso afirma. No es contradicción. |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo declara.
- **Quién decide:** la configuración nombra «Comité de producto» como autoridad, pero la definición no lo dice; en la ficha queda sin encontrar.
- **Cuál es la propuesta:** la definición solo dice «Propuesta principal», sin contenido.
- **Que el problema lo tiene el segmento Empresas:** la única entrevista (2026-02-08) es de «Cliente entrevistado», sin segmento; no se puede decir que sea de Empresas.
- **De dónde sale el 209.097:** el caso lo declara sin método ni fuente de origen.
- **Qué proyecto lo construye:** la definición dice «Ninguno declarado», y los 13 requerimientos aceptados siguen sin proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La regulación de datos lo permite» | 0 por el cálculo, porque el documento lo marca «verificado» | El documento no dice quién lo verificó ni con qué, y la fecha de declaración (2026-07-22) es posterior a la del documento (2025-10-14). Falta nombre, fecha y soporte (concepto jurídico o norma citada). Mientras tanto se trata como supuesto con verificación sin sustento. |

Además, está escrito de forma muy amplia («la regulación de datos»): sin decir qué norma ni qué dato, no se puede desmentir.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Hay una necesidad sin cubrir | Entrevistas: «Lo necesito y hoy no lo tengo», tema «Necesidad principal» | 2026-02-08 | Débil: una sola cita, dicha y no pagada, sin segmento. Los requerimientos que citan «Cliente entrevistado» apuntan a esta misma entrevista. |
| Volumen mensual existente | Tablero de métricas | 2026-10-01 | Medido, pero es el dato que contradice la definición. |

### Evidencia que ya envejeció
Nada pasa el umbral de 12 meses. Lo más nuevo que sostiene la demanda es de 2026-02-08 (8 meses). La definición misma tiene 12 meses (2025-10-14) y no se ha revisado desde entonces.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales (supuesto «la regulación de datos lo permite») | No declarado en la definición | No se puede nombrar sin saber el país | — | No tengo la norma a la vista |

Esto no dice si cumple. Va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** falta en la definición (la configuración dice «Comité de producto»; hay que escribirlo en el documento).
- Problema y para quién están declarados (Empresas), pero sin evidencia que los sostenga.

### Después
- El supuesto regulatorio, con verificación sin sustento, es candidato a riesgo con doliente (raid-taxonomy).
- La definición no está cerrada: no se ofrece `/product-charter`.
