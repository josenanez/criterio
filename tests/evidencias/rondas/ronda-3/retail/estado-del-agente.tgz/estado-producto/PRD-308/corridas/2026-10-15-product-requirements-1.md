# Corrida del 2026-10-15 · product-requirements

PRD-308 · 17 requerimientos · 42 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

13 aceptados sin proyecto; 5 aceptados sin evidencia; 3 propuestos sin decidir más de 60 días; fichas de proyecto vacías

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Registro — Marketplace (PRD-308) · al 2026-10-15
17 requerimientos · 13 decididos · 61.5% con evidencia (8 de 13) · 0% con proyecto que lo ejecuta (0 de 13)

Fuente de los números: `producto.py compute`. Las fichas de proyecto (`estado/`) están vacías, así que ninguna traza pudo confirmarse contra una ficha.

### Se va a construir y nadie lo pidió
Aceptados con «Quién lo pidió: —» en el acta del comité (2026-10-12). Sin una sola cita.
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | aceptado (2026-04-09) | Carlos Peña |
| REQ-4801 | Requerimiento REQ-4801 | aceptado (2026-03-30) | Ricardo Salas |
| REQ-4806 | Requerimiento REQ-4806 | aceptado (2026-06-28) | Gustavo Neira |
| REQ-4813 | Requerimiento REQ-4813 | aceptado (2026-06-09) | Liliana Torres |
| REQ-4815 | Requerimiento REQ-4815 | aceptado (2026-04-26) | sin asignar |

REQ-4806 y REQ-4813 tampoco tienen criterio de aceptación; REQ-4815 tampoco tiene doliente. Son los tres con más huecos juntos.

### Decidido y nadie lo está construyendo
Los 13 aceptados tienen «Proyecto que lo ejecuta: —». Ninguno tiene proyecto.
| REQ | Decidido el | Lleva sin proyecto |
|---|---|---|
| REQ-4811 | 2026-03-15 | 214 días |
| REQ-4812 | 2026-03-28 | 201 días |
| REQ-4801 | 2026-03-30 | 199 días |
| REQ-4805 | 2026-04-02 | 196 días |
| REQ-4814 | 2026-04-02 | 196 días |
| REQ-4800 | 2026-04-09 | 189 días |
| REQ-4809 | 2026-04-22 | 176 días |
| REQ-4815 | 2026-04-26 | 172 días |
| REQ-4807 | 2026-05-15 | 153 días |
| REQ-4813 | 2026-06-09 | 128 días |
| REQ-4802 | 2026-06-16 | 121 días |
| REQ-4806 | 2026-06-28 | 109 días |
| REQ-2030 | 2026-09-25 | 20 días |

Doce de los trece llevan más de tres meses aceptados sin proyecto. Solo REQ-2030 es reciente.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4808 | Requerimiento REQ-4808 | «sin asignar» (propuesto) |
| REQ-4815 | Requerimiento REQ-4815 | «sin asignar» (aceptado) |

Quién lo cerraría: quien tenga la facultad de asignar dolientes, que según la configuración es el Comité de producto (gerente: Diana Molina).

### Sin criterio de aceptación
Solo los decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-4806 | Requerimiento REQ-4806 | aceptado |
| REQ-4807 | Requerimiento REQ-4807 | aceptado |
| REQ-4813 | Requerimiento REQ-4813 | aceptado |
| REQ-4814 | Requerimiento REQ-4814 | aceptado |

Quién lo cerraría: cada doliente (Gustavo Neira, Felipe Arango, Liliana Torres y Elena Duarte). REQ-4808 también carece de criterio, pero está propuesto y no se le exige.

### Decidido sin documento que lo respalde
Cada decisión cita el acta del comité de 2026-10-12, pero esa acta solo registra «Se mantiene el plan», con Diana Molina como única asistente. No dice quién decidió cada requerimiento ni cuándo. Las fechas de decisión son las columnas «Desde» de la tabla, anteriores al acta hasta en siete meses. Los 13 aceptados quedan con el respaldo débil: hay una tabla de estado, no una decisión por requerimiento.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4808 | Requerimiento REQ-4808 | 144 días (2026-05-24) | Comité de producto |
| REQ-4803 | Requerimiento REQ-4803 | 103 días (2026-07-04) | Comité de producto |
| REQ-4804 | Requerimiento REQ-4804 | 101 días (2026-07-06) | Comité de producto |

REQ-4810 (45 días) no pasa el umbral y no es hallazgo. Sobre la facultad: la configuración dice «Comité de producto», pero `compute` devuelve `authority: null` y lo lista como desconocido. Conviene confirmar quién decide de verdad, porque el acta del 12 de octubre tiene un solo asistente.

### Evidencia vieja
Ninguno. Lo más nuevo que sostiene los requerimientos con evidencia es del 2026-02-08, hace unos 8 meses, y el umbral es de 12.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 13 | 0 | 0 | 0 |

Nada descartado: si hubo discusiones que se cerraron, no quedaron registradas, y volverán.

## Aparte (no es del registro, pero salió en el cálculo)
El caso de negocio (2025-10-14) declara volumen_mensual de 209,097 y la bodega de datos mide 131,628 al 2026-10-01: el negocio declara 37% por encima de lo medido, con el umbral en 20%. Cabe revisarlo con `/product-definition`.

## Después
Hay 13 requerimientos decididos que nadie construye: corresponde `/product-trace`. Con doliente, criterio y evidencia, y por eso candidatos a `/product-charter`: REQ-2030, REQ-4802, REQ-4805, REQ-4809, REQ-4811 y REQ-4812.
