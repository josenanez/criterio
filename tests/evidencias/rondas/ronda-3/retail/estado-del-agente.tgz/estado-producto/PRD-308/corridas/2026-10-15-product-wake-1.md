# Corrida del 2026-10-15 · product-wake

PRD-308 · 17 requerimientos · 28 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Primera revisión, sin corte previo: línea base de 17 REQ, 13 sin traza, 3 sin decidir, brecha 37% en volumen_mensual. No sé: éxito, autoridad (config dice Comité, cálculo la devuelve vacía), supuestos. Fichas tomadas de estado/records porque la config no nombra carpeta.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Marketplace (PRD-308) · 2026-10-15

**Primera revisión del registro: no hay corte anterior, así que lo que sigue es la línea base, no "novedad".** Toca `review` (nunca se había corrido); `crossed` no aplica sin corte previo. Fichas leídas de `estado/records` (la configuración no nombra una carpeta de fichas; usé la del portafolio, que es la que existe).

17 requerimientos: 13 aceptados, 4 propuestos. 8 con evidencia (61,5 %); 0 con proyecto trazado.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 d) | REQ-4808 | 144 d | Además no tiene doliente ni criterio de aceptación: primero nombrar dueño | Sin doliente; decide Comité de producto |
| Propuesto sin decidir | REQ-4803 | 103 d | Decisión del comité | Rubén Cárdenas (doliente) |
| Propuesto sin decidir | REQ-4804 | 101 d | Decisión del comité; tampoco tiene evidencia de demanda | Natalia Ospina (doliente) |
| Aceptado sin evidencia de demanda | REQ-4800, 4801, 4806, 4813, 4815 | 109–199 d desde que se planteó | Qué afirmación de la definición queda sin sustento; quién lo pidió | Carlos Peña, Ricardo Salas, Gustavo Neira, Liliana Torres, sin doliente (4815) |
| Aceptado sin doliente | REQ-4815 | 172 d | Nombrar dueño | Sin doliente |

### Contradicción negocio vs. datos
`volumen_mensual`: el caso de negocio (2025-10-14) declara 209.097; el tablero mide 131.628 al 2026-10-01. Brecha de 37 % (umbral 20 %), declarado por encima.

### Las trazas
Los 13 aceptados quedan sin proyecto que los construya (`requirement_untraced`): ninguna ficha de `estado/records` nombra PRD-308. Es lo aceptado que nadie está construyendo; el listado completo va en el anexo (REQ-2030, 4800–4802, 4805–4807, 4809, 4811–4815).

### Aceptados sin criterio de aceptación
REQ-4806, 4807, 4813, 4814.

### Lo que no sé
- Éxito de la definición: no está dicho en ningún documento.
- Autoridad: la configuración dice "Comité de producto", pero el cálculo la devuelve vacía; conviene confirmarla.
- No hay supuestos registrados, así que no puedo decir cuáles están sin verificar.
- Del descubrimiento solo hay un documento (entrevistas del 2026-02-08); toda la evidencia cumple ocho meses, aún dentro de los 12 del umbral.

**Vuelvo el 2026-11-14.**
