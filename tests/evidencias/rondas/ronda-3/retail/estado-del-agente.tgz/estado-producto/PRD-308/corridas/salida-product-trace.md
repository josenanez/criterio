## Trazabilidad — Marketplace (PRD-308) · al 2026-10-15
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Los 13 requerimientos aceptados tienen la columna «Proyecto que lo ejecuta» en «—» en el acta del comité del 2026-10-12 (`documentos/productos/PRD-308/30-decisiones/2026-10-12-comite-producto.md`), y ninguna traza en el registro. La fecha es la de aceptación («Desde»); el acta no dice quién decidió cada uno, solo el doliente, y asistió Diana Molina.

| REQ | Doliente | Decidido el |
|---|---|---|
| REQ-4811 | Liliana Torres | 2026-03-15 |
| REQ-4812 | Ricardo Salas | 2026-03-28 |
| REQ-4801 | Ricardo Salas | 2026-03-30 |
| REQ-4805 | Natalia Ospina | 2026-04-02 |
| REQ-4814 | Elena Duarte | 2026-04-02 |
| REQ-4800 | Carlos Peña | 2026-04-09 |
| REQ-4809 | Elena Duarte | 2026-04-22 |
| REQ-4815 | sin asignar | 2026-04-26 |
| REQ-4807 | Felipe Arango | 2026-05-15 |
| REQ-4813 | Liliana Torres | 2026-06-09 |
| REQ-4802 | Ricardo Salas | 2026-06-16 |
| REQ-4806 | Gustavo Neira | 2026-06-28 |
| REQ-2030 | Óscar Ramírez | 2026-09-25 |

Cuatro de ellos además aceptados sin criterio de aceptación (REQ-4806, 4807, 4813, 4814) y cinco sin evidencia de demanda (REQ-4800, 4801, 4806, 4813, 4815); es otra conversación, pero cambia el orden para chartear.

### La traza no se confirma
Ninguna: ningún requerimiento nombra un proyecto, así que no hay traza que confirmar ni desacuerdo entre registro y ficha.

### Lo que un proyecto construye y el registro no tiene
Ninguno. Se revisaron las 13 fichas en `estado/records` (PRY-199 a PRY-211): ninguna cita PRD-308 ni Marketplace. Limitación: las fichas no tienen un campo de producto que ejecutan, así que la ausencia se verificó por texto, no por campo.

### La cadena completa
REQ → decisión del comité (2026-10-12) → proyecto: la cadena se rompe en el segundo eslabón para los 13; no hay proyecto ni entregables.

### Sin fichas a la vista
Hay fichas de 13 proyectos, pero ninguno está vinculado al producto, así que nada se pudo confirmar.

Después: `/product-charter` para el primero que esté listo (REQ-2030, el más reciente, con criterio de aceptación y evidencia).
