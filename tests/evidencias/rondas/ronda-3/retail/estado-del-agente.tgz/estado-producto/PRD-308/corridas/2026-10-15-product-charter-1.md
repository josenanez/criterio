# Corrida del 2026-10-15 · product-charter

PRD-308 · 17 requerimientos · 37 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4800 sin firma ni ficha. Vacíos: sin evidencia de demanda, sin autoridad declarada, sin patrocinador, criterio de aceptación no verificable, supuesto de regulación sin soporte.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.9-2026-10-15.md`). No se pidió un sí nuevo.

Verificación previa (paso 1) de REQ-4800 contra requirement-record: está aceptado y tiene un criterio de aceptación, pero **no tiene evidencia de demanda** y **la definición no declara la autoridad**. Respuesta sugerida tomada (sesión sin interfaz): seguir sin ellos y marcarlos como vacíos del acta, sin rellenarlos.

---

# Acta de constitución — Marketplace (REQ-4800) · borrador del 2026-10-15
**Producto:** PRD-308 · Marketplace · **Requerimientos:** REQ-4800

## Qué problema resuelve
"El segmento Empresas no tiene marketplace." (`documentos/productos/PRD-308/00-definicion/2025-10-14-definicion-producto.docx`, sección «El problema», 2025-10-14).
La propuesta de la definición es solo «Propuesta principal», sin más detalle. REQ-4800 no tiene título propio: el registro lo llama «Requerimiento REQ-4800» (`documentos/productos/PRD-308/30-decisiones/2026-10-12-comite-producto.md`, 2026-10-12). **Qué construye este requerimiento concretamente no está dicho en ningún documento.**

## Criterio de éxito
| Criterio | Cita | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `…/30-decisiones/2026-10-12-comite-producto.md`, fila REQ-4800 | **No se puede decir**: no nombra qué se mide, con qué umbral ni quién lo verifica. Es un criterio de aceptación en la forma pero no es verificable en el fondo. |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 (sin título descriptivo) | **Ninguna.** La columna «Quién lo pidió» del comité está en «—» y el registro tiene `evidence: []`. Doliente: Carlos Peña. Aceptado, desde 2026-04-09 (comité 2026-10-12). |

La única entrevista del producto (`…/10-descubrimiento/2026-02-08-entrevistas.md`: «Lo necesito y hoy no lo tengo», tema «Necesidad principal») es genérica y no nombra REQ-4800. **No se usa como sustento del requerimiento.**

### No entra
Esta acta cubre solo REQ-4800, que es lo pedido. Los demás del registro del comité del 2026-10-12 quedan fuera por esa razón; no hay en los documentos una decisión de excluirlos.

| REQ | Estado | Por qué no |
|---|---|---|
| REQ-4801, 4802, 4805, 4806, 4807, 4809, 4811, 4812, 4813, 4814, 4815, 2030 | aceptado | No se pidieron en esta invocación. Pueden constituirse en esta u otra acta. |
| REQ-4803, 4804, 4808, 4810 | propuesto | No se pidieron, y además no están aceptados: sin decisión del gerente de producto no hay acta. |

La razón de fondo por la que cada uno queda fuera del proyecto **no está dicha** en los documentos; la tabla solo dice por qué no entra en este borrador.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Este comando no nombra gerente; lo asigna quien tenga la autoridad. (Diana Molina figura como gerente de *producto*, no del proyecto.)
- **Comité:** «Comité de producto» (`.criterio/producto/PRD-308/config.json`, `product.authority`). El acta del 2026-10-12 solo registra a Diana Molina como asistente.
- **Autoridad del gerente del proyecto:** **no declarada** en la definición. Qué puede decidir solo y qué debe escalar queda vacío.
- **Quién aceptó REQ-4800:** el acta del comité lo muestra como «aceptado» (2026-10-12, desde 2026-04-09), sin decir quién tomó la decisión.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La regulación de datos lo permite» · declarado 2026-07-22 (definición) | Marcado «verificado» en la definición, **sin decir cómo, quién ni con qué documento**. No hay verificación citable. | Se registra como riesgo del proyecto con doliente por asignar (raid-taxonomy), porque su verificación no se puede comprobar. Doliente: sin asignar. |

REQ-4800 no declara supuestos propios (`assumptions: []`).

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| El supuesto de la definición menciona regulación de datos | No identificada: el barrido normativo no se ha corrido para este producto | No citada | **Sin resolver.** No se opina sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Evidencia de demanda de REQ-4800 | El proyecto arranca sobre un requerimiento aceptado que nadie documenta que alguien pidió. Si no se sostiene, se descubre en el cierre. | Doliente del requerimiento (Carlos Peña) / gerente de producto (Diana Molina) |
| Autoridad del gerente del proyecto | El gerente no sabe qué decide solo: escala todo o no escala nada. | Comité de producto |
| Patrocinador | Nadie responde por el presupuesto ni desbloquea escalamientos. | Comité de producto |
| Criterio de aceptación verificable | El cierre no se puede juzgar meses después: «se verifica en producción» admite cualquier resultado. | Doliente y gerente de producto |
| Título y contenido real de REQ-4800 | No hay alcance que firmar más que un identificador. | Doliente |
| Presupuesto aprobado e hitos | No declarados en ningún documento; no se inventan. La ficha nacerá sin ellos. | Patrocinador / gerente del proyecto |
| Verificación del supuesto de regulación | Un riesgo normativo queda dado por cerrado sin soporte. | Gerente de producto |
| Quién decidió aceptar REQ-4800 | La decisión que habilita el acta no tiene responsable registrado. | Comité de producto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad del Comité de producto (nombre por designar). **La ficha del proyecto no se creó:** se crea después de la firma, y solo entonces `identity.product = PRD-308`. El estado declarado queda vacío por diseño.

**Qué sigue y para quién:** quien sea designado gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella y Alba sabrá si su producto se está construyendo sin preguntarle a nadie.
