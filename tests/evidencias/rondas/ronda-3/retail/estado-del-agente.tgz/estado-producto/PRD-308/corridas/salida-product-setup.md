## Listo — Marketplace (PRD-308)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 5 documentos (4 en Markdown y 1 .docx, todos legibles) · 1 de descubrimiento (una ronda de entrevistas del 2026-02-08, con una sola cita de un cliente sin nombre) · la definición y el caso de negocio del 2025-10-14 · lo más reciente es el acta del comité del 2026-10-12.
**Preguntas:** ninguna se hizo (sesión de prueba sin interfaz); tomé la respuesta sugerida en cada una. Gerente: Diana Molina, de la definición. Estado en `estado-producto/PRD-308`. **Quién decide: ningún documento lo dice**; dejé «Comité de producto» en la configuración como propuesta, sin confirmar, y en la ficha el campo queda como no encontrado.
**Términos:** aceptados para la versión 0.3.9 (textos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 eff52306622e7cd2…

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Empresas no tiene marketplace | Solo en parte: una cita de un cliente sin nombre y sin segmento («Lo necesito y hoy no lo tengo») que no menciona marketplace | 2026-02-08 |
| volumen_mensual de 209.097 | Caso de negocio. La serie medida (bodega de datos, tablero de producto) da 131.628 al 2026-10-01: **37.0 % por debajo de lo declarado** | 2025-10-14 / 2026-10-01 |
| La regulación de datos lo permite | Supuesto marcado «verificado», sin decir quién ni con qué. Su fecha de declaración (2026-07-22) es posterior a la del documento (2025-10-14) | 2026-07-22 |
| Retorno esperado en 24 meses | Nada: no hay cifra ni cálculo | — |

### Lo que no está dicho en ninguna parte
- El **criterio de éxito** del producto: sin él no hay contra qué cerrar.
- **Quién decide qué se construye.**
- La **propuesta de valor**: la definición dice solo «Propuesta principal».
- El **retorno esperado**: no hay monto, ni método, ni supuestos.
- **Qué proyecto construye este producto**: la definición dice «Ninguno declarado» y el acta del comité tampoco nombra ninguno. De 13 requerimientos aceptados, **0 tienen proyecto (0.0 %)**.
- La fuente de la verificación de la regulación de datos.
- **Evidencia de demanda** en 5 de 13 aceptados (REQ-4800, 4801, 4806, 4813, 4815): solo 8 tienen evidencia (61.5 %), y esa es una única cita de entrevista que no nombra ningún requerimiento.
- **Criterio de aceptación** en 4 aceptados (REQ-4806, 4807, 4813, 4814). Los demás dicen todos igual: «se verifica en producción», que no es un criterio medible.
- **Doliente** en REQ-4808 y REQ-4815 («sin asignar»).

### Supuestos sobre los que está escrita
Uno declarado: «La regulación de datos lo permite», dado por verificado sin fuente. Como toca datos personales, vale un barrido normativo.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hoy hay una cita, de un cliente sin nombre, para 17 requerimientos.
- La serie de la métrica principal con más de un punto: hay una sola medición (2026-10-01) y no se ve la tendencia.
- Las decisiones del comité: el acta del 2026-10-12 dice solo «Se mantiene el plan». No dice quién decidió cada requerimiento, y 3 propuestos llevan más de 60 días sin decisión (REQ-4803: 103 días; REQ-4804: 101; REQ-4808: 144).
- REQ-2030 tiene una numeración distinta a la de los demás (REQ-48xx); no sé si es un error o viene de otro producto.

**Siguiente paso que te ofrezco:** `/product-discovery` sobre el material de entrevistas, para que los temas queden con la cita de quién los pidió.
