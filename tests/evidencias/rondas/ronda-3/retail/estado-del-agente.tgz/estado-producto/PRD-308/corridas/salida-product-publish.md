No publiqué la ficha de PRD-308 (Marketplace): no hay carpeta de productos publicados configurada. La configuración (`.criterio/producto/PRD-308/config.json`) no define ese sitio y no existe una carpeta `productos/publicados` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la inventé ni la creé.

**Lo que habría llevado** (corte al 2026-10-15, según `producto.py publish`):
- 17 requerimientos (13 aceptados, 4 propuestos), ninguno ligado a un proyecto
- 0 proyectos
- 1 métrica afirmada: volumen_mensual = 209097, de `documentos/productos/PRD-308/00-definicion/2025-10-14-caso-de-negocio.md` (2025-10-14)
- Segmento declarado: Segmento: Empresas

Dato para quien lo lea del otro lado: la medición del 2026-10-01 (bodega de datos, tablero de producto) da 131628, 37.0 % por debajo de lo declarado. Esa medición no se publica.

Para publicar: indicar la ruta de la carpeta común y volver a correr el comando; la ficha se escribiría como `<ruta>/PRD-308.json`.
