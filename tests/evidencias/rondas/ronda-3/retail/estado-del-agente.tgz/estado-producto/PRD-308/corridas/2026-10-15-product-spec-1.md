# Corrida del 2026-10-15 · product-spec

PRD-308 · 17 requerimientos · 52 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Borrador de especificación sobre 13 requerimientos aceptados (4 propuestos fuera). No pudo redactar comportamiento: los títulos son marcadores y el acta no los describe. Criterio 'se verifica en producción' no verificable en 9; 4 sin criterio; REQ-4815 sin doliente; ningún barrido normativo con cita; cifra volumen 209.097 vs 131.628 medido.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribió el agente; lo cierra Diana Molina (gerente de producto, PRD-308) y lo aprueba el Comité de producto. Este agente no puede dar esa firma.

# Especificación — Marketplace (PRD-308) · borrador del 2026-10-15

**Resultado en una línea:** el registro tiene 13 requerimientos aceptados, pero ninguno dice qué debe hacer el producto. Todos se llaman «Requerimiento REQ-xxxx» y el acta del comité (2026-10-12) no trae su descripción. Por eso la sección de comportamiento queda vacía a propósito, en vez de llenarla con lo que un marketplace suele hacer.

## Qué problema resuelve

«El segmento Empresas no tiene marketplace.» Segmento: Empresas. (Definición del producto, `00-definicion/2025-10-14-definicion-producto.docx`, 2025-10-14.)

La definición **no dice** cuál es el criterio de éxito del producto. Sin él, ningún criterio de aceptación de abajo se puede amarrar a un resultado.

## Alcance

Se tomaron los requerimientos en `aceptado` o `en_construccion`: **13 de 17**. Fuente: acta del Comité de producto, 2026-10-12.

### Entra (solo por identificador, sin contenido)

REQ-2030, REQ-4800, REQ-4801, REQ-4802, REQ-4805, REQ-4806, REQ-4807, REQ-4809, REQ-4811, REQ-4812, REQ-4813, REQ-4814, REQ-4815.

### No entra

- REQ-4803, REQ-4804, REQ-4808 y REQ-4810 siguen en `propuesto`. Nadie los ha decidido y especificarlos sería escribir el documento dos veces. REQ-4808 además no tiene doliente.
- Todo lo que no esté en el acta. Los documentos no registran ninguna otra capacidad pedida o aceptada.
- Diseño técnico, estimación, costo y fechas. Este borrador no los trata.
- **Cuáles son las capacidades del marketplace** (catálogo, pagos, facturación, etc.). Ningún documento lo dice, así que no queda ni dentro ni fuera del alcance. Es un vacío (ver V1).

## Comportamiento

| Sección | Requerimientos | Qué dice el registro |
|---|---|---|
| Comportamiento del producto | REQ-2030, 4800, 4801, 4802, 4805, 4806, 4807, 4809, 4811, 4812, 4813, 4814, 4815 | **No definido.** El título de cada uno es un marcador de posición. Redactar comportamiento aquí sería inventarlo. |

## Criterios de aceptación

El acta da dos situaciones: nueve requerimientos con la frase «se verifica en producción» y cuatro sin criterio.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-2030, 4800, 4801, 4802, 4805, 4809, 4811, 4812, 4815 | **No pasa la prueba.** Dice dónde se mira, no qué se mira. Dos personas ante lo construido pueden responder distinto. Hay que reescribirlo con el comportamiento a verificar, y eso depende de V1. | No aplica: no hay umbral que medir |
| (sin criterio) | REQ-4806, 4807, 4813, 4814 | — | — |

Sobre lo que se puede medir hoy: el único dato medido que existe es `volumen_mensual`, en el tablero de producto (bodega de datos, corte 2026-10-01). No hay ningún criterio escrito contra esa métrica ni contra otra.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La regulación de datos lo permite» (definición, 2025-10-14) | El documento dice «verificado», pero no cita quién ni con qué. La fecha de declaración (2026-07-22) es posterior a la del documento (2025-10-14). **Se trata como no verificado.** | Diana Molina, con quien haya hecho la verificación (no identificado) |
| La cifra del caso de negocio, `volumen_mensual` = 209.097 (2025-10-14), se trata como supuesto, no como hecho. | **No se sostiene.** El tablero mide 131.628 (2026-10-01): 37 % por debajo de lo declarado, y el umbral de la configuración es 20 %. | Diana Molina, con el responsable del tablero |
| Los textos de la columna «Quién lo pidió» (Cliente entrevistado) respaldan 9 requerimientos. | **Débil.** La entrevista (2026-02-08) es una sola cita genérica («Lo necesito y hoy no lo tengo») y no nombra ningún requerimiento. El vínculo lo da solo la columna del acta. | Diana Molina (autora de la ronda) |

## Vacíos

| # | Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|---|
| V1 | **Qué hace cada requerimiento.** Los 13 aceptados no tienen título ni descripción más allá del código. | No hay especificación posible. Quien construya decidirá por su cuenta. | Cada doliente (ver «Requerimientos sin cubrir») y Diana Molina |
| V2 | **Criterio de aceptación verificable** para los 13. Nueve tienen una frase vacía y cuatro (REQ-4806, 4807, 4813, 4814) no tienen nada. | Nadie podrá decir si lo construido está bien sin discutirlo. | Gustavo Neira (4806), Felipe Arango (4807), Liliana Torres (4813), Elena Duarte (4814); el resto, sus dolientes |
| V3 | **Doliente de REQ-4815.** Está aceptado desde 2026-04-26 y no tiene doliente. | Un requerimiento aceptado que nadie defiende, sin dueño para precisar su criterio. | Comité de producto / Diana Molina |
| V4 | **Criterio de éxito del producto**, no encontrado en la definición. | Los criterios por requerimiento no se amarran a un resultado de negocio. | Diana Molina |
| V5 | **Casos borde:** ningún documento describe qué pasa ante errores, duplicados, abandono o falta de conexión. No se puede ni formular la pregunta sin saber qué hace cada requerimiento. | Comportamiento sin definir en producción. | Dolientes, con Diana Molina |
| V6 | **Supuesto de regulación de datos sin sustento** (ver arriba). El documento no cita ninguna norma concreta. No se hizo un barrido normativo con cita, porque nada indica qué datos trata cada requerimiento. | Se podría construir sobre una autorización que nadie puede mostrar. | Diana Molina; área legal o de cumplimiento (no nombrada en los documentos) |
| V7 | **Lo que otro equipo tiene que hacer.** Ningún requerimiento tiene proyecto que lo ejecute (columna «Proyecto que lo ejecuta» = «—» en los 17), ni hay acuerdo escrito con ningún equipo. | Aceptado sin quien lo construya. | Diana Molina con el Comité de producto |
| V8 | **Cifra de volumen:** el caso de negocio declara 209.097 y la medición va en 131.628. | Se especifica para un volumen que no existe. | Diana Molina |
| V9 | **«Se mantiene el plan»** (decisión del comité, 2026-10-12): no se encontró ningún plan en los documentos. El comité lo atendió una sola asistente (Diana Molina). | La decisión no se puede rastrear. | Comité de producto |
| V10 | **Requerimientos aceptados sin evidencia de demanda:** REQ-4800, 4801, 4806, 4813, 4815 («Quién lo pidió» = «—»). | Aceptados sin que conste quién los pidió. | Dolientes respectivos |

## Requerimientos aceptados que esta especificación no cubre

Ningún aceptado quedó fuera por omisión: los 13 están en el alcance. Pero la especificación **no cubre el comportamiento de ninguno** (V1).

| REQ | Título | Doliente | Por qué no hay comportamiento / qué falta |
|---|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | Óscar Ramírez | Sin descripción. Criterio no verificable |
| REQ-4800 | Requerimiento REQ-4800 | Carlos Peña | Sin descripción. Criterio no verificable. Sin evidencia de demanda |
| REQ-4801 | Requerimiento REQ-4801 | Ricardo Salas | Sin descripción. Criterio no verificable. Sin evidencia de demanda |
| REQ-4802 | Requerimiento REQ-4802 | Ricardo Salas | Sin descripción. Criterio no verificable |
| REQ-4805 | Requerimiento REQ-4805 | Natalia Ospina | Sin descripción. Criterio no verificable |
| REQ-4806 | Requerimiento REQ-4806 | Gustavo Neira | Sin descripción. Sin criterio. Sin evidencia de demanda |
| REQ-4807 | Requerimiento REQ-4807 | Felipe Arango | Sin descripción. Sin criterio |
| REQ-4809 | Requerimiento REQ-4809 | Elena Duarte | Sin descripción. Criterio no verificable |
| REQ-4811 | Requerimiento REQ-4811 | Liliana Torres | Sin descripción. Criterio no verificable |
| REQ-4812 | Requerimiento REQ-4812 | Ricardo Salas | Sin descripción. Criterio no verificable |
| REQ-4813 | Requerimiento REQ-4813 | Liliana Torres | Sin descripción. Sin criterio. Sin evidencia de demanda |
| REQ-4814 | Requerimiento REQ-4814 | Elena Duarte | Sin descripción. Sin criterio |
| REQ-4815 | Requerimiento REQ-4815 | sin asignar | Sin descripción. Sin doliente. Criterio no verificable. Sin evidencia de demanda |

## Siguiente paso

No ofrezco `/product-charter` todavía: la especificación no tiene los vacíos cerrados ni un criterio de éxito del producto. Lo primero es que cada doliente escriba qué dice su requerimiento (V1) y que Diana Molina fije el criterio de éxito (V4).

---
**Pie.** Sale del registro `estado-producto/PRD-308/requirements/` (17 requerimientos), construido sobre el acta del Comité de producto del 2026-10-12. Cubre 13 requerimientos, solo por identificador. Términos aceptados (v1.1, José Francisco Ñáñez, 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
