# Corrida del 2026-10-15 · product-business-case

PRD-308 · 17 requerimientos · 34 s · 28 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Caso de negocio armado: 1 cifra declarada contra 1 medida (37 % de diferencia), retorno sin cifra, costos ausentes, criterio de éxito no declarado, cruce con otros productos no posible (sin fichas publicadas).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Marketplace (PRD-308) · borrador del 2026-10-15
**Desde:** 00-definicion/2025-10-14-definicion-producto.docx y 2025-10-14-caso-de-negocio.md (2025-10-14) · **Cifras con fuente:** 1 de 2 (la otra, «retorno esperado en 24 meses», no trae cifra)

*Términos vigentes (v1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta volver a registrarlos. Sesión sin interfaz: no se hicieron preguntas.*

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Empresas no tiene marketplace.» (definición, 2025-10-14)
- **Para quién:** «Segmento: Empresas» (definición, 2025-10-14)
- **Evidencia:** una sola entrevista, 2026-02-08, de «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» Sin segmento, sin pago: no sostiene que el problema sea de Empresas (10-descubrimiento/2026-02-08-entrevistas.md).

## Qué se construye
Decididos (aceptados): 13 de 17 registrados. Fuente: acta del comité 2026-10-12 (30-decisiones/2026-10-12-comite-producto.md). El acta solo dice «Se mantiene el plan», con Diana Molina como única asistente; las fechas de decisión son la columna «Desde».
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4802, 4805, 4807, 4809, 4811, 4812, 4814, REQ-2030 | aceptado | «Cliente entrevistado» (la misma entrevista de 2026-02-08) |
| REQ-4800, 4801, 4806, 4813, 4815 | aceptado | **Ninguna: nadie lo pidió** (quién lo pidió: «—») |

Proyecto que ejecuta cada uno: ninguno (0 de 13). Los 4 propuestos (REQ-4803, 4804, 4808, 4810) no entran al caso: no están decididos.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 209.097 | **Declarada** | Caso de negocio (Diana Molina); sin método ni fuente de origen | 2025-10-14 |
| volumen_mensual | 131.628 | **Medida** | Bodega de datos, tablero de producto | corte 2026-10-01 |
| Retorno esperado en 24 meses | — (sin cifra) | **Supuesta** | Frase en el caso de negocio, sin valor ni base | 2025-10-14 |

La serie medida tiene un solo punto: no se puede decir si 131.628 es tendencia o una foto.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 209.097 | 131.628 | La declarada está 37 % por encima de la medida (umbral 20 %) · 00-definicion/2025-10-14-caso-de-negocio.md (2025-10-14) · 20-metricas/2026-10-01-tablero-metricas.md (2026-10-01) |

Hay que advertir que las dos fechas están separadas por un año: el caso describe una expectativa y el tablero un valor actual. Aun así, el caso nunca se actualizó y hoy afirma un número que la serie propia no sostiene.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento (ni contratos, ni cotizaciones, ni costo declarado del equipo) |
| Costo de operar | **No hay** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta. Es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La regulación de datos lo permite» (marcado «verificado», declarado 2026-07-22, sin quién ni con qué; la fecha es posterior a la del documento) | Producto que roza datos personales y no puede salir, o sale con una obligación incumplida | Revisión jurídica; país y norma no declarados |
| El retorno llega en 24 meses | Sin cifra ni base, no se puede decir qué pasa; ningún dato lo mide | El negocio (Diana Molina) |
| El volumen mensual llegará a 209.097 | La base de cualquier cálculo de ingreso queda 37 % por encima de lo medido hoy | El negocio, con método y fuente |
| El segmento Empresas tiene el problema | Se construye para un segmento que nadie entrevistó | Descubrimiento con entrevistas por segmento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Finanzas / equipo del producto |
| Cifra y método del retorno esperado | «Retorno en 24 meses» no es verificable | Diana Molina |
| Origen del 209.097 (método, fuente) | Es la cifra que sostiene el caso y contradice a la medida | Diana Molina |
| Criterio de éxito | Ningún documento lo declara; sin él no se puede cerrar el producto | Diana Molina / Comité de producto |
| Quién decide | La configuración dice «Comité de producto»; ningún documento lo dice | Comité de producto |
| Qué pasa si no se hace; alternativas consideradas | No están en ningún documento | Diana Molina |
| Proyecto que construye los 13 aceptados | 0 de 13 con proyecto; el más viejo lleva 214 días | Comité de producto |
| Quién pidió REQ-4800, 4801, 4806, 4813, 4815 | Se construiría algo que nadie pidió | Dolientes respectivos |
| Concepto jurídico del supuesto regulatorio | Verificación sin sustento | Jurídico |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento fija criterio de éxito, métrica ni fecha de corte. Lo único medido es volumen_mensual (131.628 al 2026-10-01); si el negocio lo elige como criterio, hay que escribir el valor objetivo y la fecha. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
Ninguno publicado: la carpeta de fichas (`estado/`) está vacía, así que el cruce de `/product-overlap` no se pudo hacer sobre fichas. A título informativo, los casos de negocio de PRD-299 a PRD-309 también declaran volumen_mensual (entre 60.125 y 284.980), y ninguno coincide con 209.097; eso no prueba que no haya doble conteo, solo que no hay un valor idéntico.

## Después
- Pasar los supuestos (regulatorio, retorno, volumen, segmento) a `assumption-tracking`: el regulatorio es candidato a riesgo con doliente.
- No se ofrece `/product-charter`: el caso no tiene costo ni criterio de éxito. Quien decide aprobar o rechazar es el Comité de producto; este borrador no lo recomienda.
