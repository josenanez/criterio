<!-- origen: PRY-209-migración-del-erp/10-plan/2025-11-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-03-12,2026-03-12,cerrado
Ambiente de pruebas certificado,2026-06-22,2026-06-22,cerrado
Integración con el ERP,2026-10-03,2026-10-03,en curso
Piloto en tiendas,2027-01-13,2027-01-13,en curso
