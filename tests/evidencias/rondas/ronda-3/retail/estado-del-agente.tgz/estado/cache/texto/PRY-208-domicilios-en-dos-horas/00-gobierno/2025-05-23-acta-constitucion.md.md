<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2025-05-23-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Domicilios en dos horas

**Código:** PRY-208
**Área dueña:** Servicio al cliente
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Expansión
**Producto asociado:** entrega rápida
**Fecha de aprobación:** 2025-05-23

## Objetivo del negocio

Entregar domicilios en dos horas para Servicio al cliente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Expansión el 2025-05-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-02 |
| Cierre | 2026-02-28 |

## Criterio de éxito

Domicilios en dos horas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
