<!-- origen: PRY-206-precios-dinámicos/10-plan/2026-04-19-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-06-07,2026-06-07,cerrado
Ambiente de pruebas certificado,2026-07-17,2026-07-17,cerrado
Integración con el ERP,2026-08-25,2026-08-25,cerrado
Piloto en tiendas,2026-10-04,2026-10-04,en curso
Despliegue en la cadena,2026-11-13,2026-11-13,en curso
