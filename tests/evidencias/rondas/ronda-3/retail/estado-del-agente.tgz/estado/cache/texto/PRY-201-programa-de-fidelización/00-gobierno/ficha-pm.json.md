<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {"value": "PRY-201", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "name": {"value": "Programa de fidelización", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "business_area": {"value": "Comercio electrónico", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "product": {"value": "puntos de fidelización", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "authority": {"value": null, "source": null, "source_date": null, "state": "not_found"},
 "sponsor": {"value": "Felipe Arango", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "manager": {"value": "Diana Molina", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "committee": {"value": "Comité Comercial", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "phase": {"value": null, "source": null, "source_date": null, "state": "not_found"}
 },
 "declared": {
 "status": {"value": null, "source": null, "source_date": null, "state": "not_found", "source_kind": "declaration"},
 "progress_pct": {"value": null, "source": null, "source_date": null, "state": "not_found", "source_kind": "declaration"}
 },
 "plan": {
 "start_date": {"value": "2025-05-20", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "end_date": {"value": "2026-12-07", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "baseline": [],
 "milestones": []
 },
 "money": {
 "currency": {"value": "COP", "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"},
 "approved": {"value": 4200000000, "source": "00-gobierno/2025-05-10-acta-constitucion.docx", "source_date": "2025-05-10", "state": "found"}
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "probability": "no_declarada",
 "impact": "no_declarado",
 "owner": "no_identificado",
 "due_date": "no_declarada",
 "last_moved": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "note": "Se comentó en la reunión y, según las notas, nadie lo anotó como riesgo."
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Paula Céspedes",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-17",
 "original_due_date": "2026-09-23",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {"due_date": "2026-10-02", "stated_on": "2026-09-10", "source": "30-reuniones/2026-09-10-comite-semanal.md"},
 {"due_date": "2026-10-23", "stated_on": "2026-09-17", "source": "30-reuniones/2026-09-17-comite-semanal.md"},
 {"due_date": "2026-11-10", "stated_on": "2026-09-24", "source": "30-reuniones/2026-09-24-comite-semanal.md"},
 {"due_date": "2026-11-24", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"},
 {"due_date": "2026-12-03", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"},
 {"due_date": "2026-12-17", "stated_on": "2026-10-15", "source": "2026-10-15-notas-reunion.txt"}
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "due_text": "la otra semana",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Sandra Gil", "what": "Cerrar la prueba 2",
 "due_date": "2026-12-03", "original_due_date": "2026-09-21", "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-10-01", "stated_on": "2026-09-10", "source": "30-reuniones/2026-09-10-comite-semanal.md"},
 {"due_date": "2026-10-11", "stated_on": "2026-09-17", "source": "30-reuniones/2026-09-17-comite-semanal.md"},
 {"due_date": "2026-10-27", "stated_on": "2026-09-24", "source": "30-reuniones/2026-09-24-comite-semanal.md"},
 {"due_date": "2026-11-14", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"},
 {"due_date": "2026-12-03", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"}
 ]
 },
 {
 "who": "Laura Vélez", "what": "Aprobar el diseño 5",
 "due_date": "2026-11-06", "original_due_date": "2026-09-19", "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md", "state": "open",
 "note": "El 09-17 se repitió el 09-19 (no cuenta como reprogramación); el 09-24 ya estaba vencido y se movió al 10-10.",
 "reschedules": [
 {"due_date": "2026-10-10", "stated_on": "2026-09-24", "source": "30-reuniones/2026-09-24-comite-semanal.md"},
 {"due_date": "2026-10-23", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"},
 {"due_date": "2026-11-06", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"}
 ]
 },
 {
 "who": "Ricardo Salas", "what": "Revisar el anexo 3",
 "due_date": "2026-10-29", "original_due_date": "2026-10-08", "due_text": "por definir en los comités del 09-03, 09-10 y 09-17", "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-10-29", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"}
 ]
 },
 {
 "who": "Carlos Peña", "what": "Enviar el documento 9",
 "due_date": "2026-10-29", "original_due_date": "2026-09-26", "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-10-22", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"},
 {"due_date": "2026-10-29", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"}
 ]
 },
 {
 "who": "Óscar Ramírez", "what": "Aprobar el diseño 13",
 "due_date": "2026-10-09", "original_due_date": "2026-10-09", "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md", "state": "open",
 "note": "Misma fecha en los comités del 09-24, 10-01 y 10-08; no figura en las notas del 10-15. Sin acta de recibo.",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez", "what": "Cerrar la prueba 10",
 "due_date": "2026-10-15", "original_due_date": "2026-10-15", "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md", "state": "open",
 "note": "El 09-24 dijo que ya la entregó; no se presentó acta. Desde el 09-24 salió de la tabla de abiertos sin cierre documentado.",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez", "what": "Validar el ambiente 12",
 "due_date": "2026-10-14", "original_due_date": "2026-10-14", "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md", "state": "open",
 "note": "El 09-24 dijo que ya lo entregó; no se presentó acta. Desde el 10-01 salió de la tabla de abiertos sin cierre documentado.",
 "reschedules": []
 },
 {
 "who": "Jorge Medina", "what": "Actualizar la matriz 14",
 "due_date": "2026-10-12", "original_due_date": "2026-10-02", "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-10-12", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"}
 ]
 },
 {
 "who": "Andrés Lozano", "what": "Enviar el documento 17",
 "due_date": "2026-10-23", "original_due_date": "2026-10-08", "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-10-23", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"}
 ]
 },
 {
 "who": "Javier Hoyos", "what": "Cerrar la prueba 18",
 "due_date": "2026-10-11", "original_due_date": "2026-10-11", "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md", "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte", "what": "Revisar el anexo 19",
 "due_date": "2026-11-03", "original_due_date": "2026-10-26", "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md", "state": "open",
 "reschedules": [
 {"due_date": "2026-11-03", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"}
 ]
 },
 {
 "who": "María Restrepo", "what": "Aprobar el diseño 21",
 "due_date": "2026-10-20", "original_due_date": "2026-10-20", "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md", "state": "open", "reschedules": []
 },
 {
 "who": "Gustavo Neira", "what": "Actualizar la matriz 22",
 "due_date": "2026-10-17", "original_due_date": "2026-10-17", "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md", "state": "open", "reschedules": []
 },
 {
 "who": "Camilo Beltrán", "what": "Confirmar la fecha 23",
 "due_date": "2026-11-03", "original_due_date": "2026-11-03", "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md", "state": "open", "reschedules": []
 },
 {
 "who": "Mauricio Pérez", "what": "Entregar el punto 24",
 "due_date": "2026-10-26", "original_due_date": "2026-10-26", "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md", "state": "open", "reschedules": []
 },
 {
 "who": "Felipe Arango", "what": "Validar el ambiente 4",
 "due_date": "2026-09-30", "original_due_date": "2026-09-30", "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-09-10-acta-recibo-4.md", "reschedules": []
 },
 {
 "who": "Felipe Arango", "what": "Entregar el punto 8",
 "due_date": "2026-09-20", "original_due_date": "2026-09-20", "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-09-17-acta-recibo-8.md", "reschedules": []
 },
 {
 "who": "Camilo Beltrán", "what": "Revisar el anexo 11",
 "due_date": "2026-10-05", "original_due_date": "2026-10-05", "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-09-24-acta-recibo-11.md", "reschedules": []
 },
 {
 "who": "Javier Hoyos", "what": "Actualizar la matriz 6",
 "due_date": "2026-09-22", "original_due_date": "2026-09-22", "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-6.md", "reschedules": []
 },
 {
 "who": "Diana Molina", "what": "Confirmar la fecha 7",
 "due_date": "2026-10-16", "original_due_date": "2026-09-28", "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-7.md",
 "reschedules": [
 {"due_date": "2026-10-16", "stated_on": "2026-09-24", "source": "30-reuniones/2026-09-24-comite-semanal.md"}
 ]
 },
 {
 "who": "Elena Duarte", "what": "Confirmar la fecha 15",
 "due_date": "2026-09-30", "original_due_date": "2026-09-30", "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-15.md", "reschedules": []
 },
 {
 "who": "Felipe Arango", "what": "Entregar el punto 16",
 "due_date": "2026-10-29", "original_due_date": "2026-10-18", "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-16.md",
 "reschedules": [
 {"due_date": "2026-10-29", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"}
 ]
 },
 {
 "who": "Camilo Beltrán", "what": "Validar el ambiente 20",
 "due_date": "2026-10-26", "original_due_date": "2026-10-26", "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md", "state": "met",
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-20.md", "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [
 {"path": "2026-10-15-notas-reunion.txt", "hash": "2aa5dba13cfc4043d91e7eb499e69675edf761e3d374ab19e809ed1b2c971a1e", "text_hash": "", "date": "2026-10-15"},
 {"path": "30-reuniones/2026-10-08-comite-semanal.md", "hash": "3027a4c646655ec36b607fbe6ef3d2bad800b1490f0b8cf3cfa196cda5d5d0a7", "text_hash": "", "date": "2026-10-08"},
 {"path": "00-gobierno/2025-05-10-acta-constitucion.docx", "hash": "67e2f3309caac3e33ce036ee075d21200309fa25a78e6f1b2242ce2799798b35", "text_hash": "", "date": "2025-05-10"}
 ],
 "fields_not_found": ["identity.authority", "identity.phase", "declared.status", "declared.progress_pct"],
 "open_conflicts": []
 }
}
