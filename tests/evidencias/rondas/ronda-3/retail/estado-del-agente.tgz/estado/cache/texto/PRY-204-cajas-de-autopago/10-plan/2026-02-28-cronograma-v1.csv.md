<!-- origen: PRY-204-cajas-de-autopago/10-plan/2026-02-28-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-07-20,2026-07-20,cerrado
Ambiente de pruebas certificado,2026-11-29,2026-11-29,en curso
Integración con el ERP,2027-04-11,2027-04-11,en curso
Piloto en tiendas,2027-08-21,2027-08-21,en curso
