<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de fidelización
Código: PRY-201
Fecha de corte: 2026-09-27
Gerente: Diana Molina

Estado declarado
Verde
Avance reportado: 39%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.368.780.814
Ejecutado 1.750.850.713
Proyección al cierre 4.226.425.039

Riesgos abiertos
- Congelamiento de cambios en temporada alta
