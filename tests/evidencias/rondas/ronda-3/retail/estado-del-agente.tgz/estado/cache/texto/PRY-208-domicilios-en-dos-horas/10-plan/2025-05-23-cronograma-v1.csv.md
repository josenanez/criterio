<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2025-05-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-08-01,2025-08-01,cerrado
Ambiente de pruebas certificado,2025-09-30,2025-09-30,cerrado
Integración con el ERP,2025-11-29,2025-11-29,cerrado
Piloto en tiendas,2026-01-28,2026-01-28,cerrado
