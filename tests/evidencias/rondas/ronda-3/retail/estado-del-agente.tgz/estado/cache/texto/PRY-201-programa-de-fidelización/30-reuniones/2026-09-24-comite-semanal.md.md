<!-- origen: PRY-201-programa-de-fidelización/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Programa de fidelización

**Fecha:** 2026-09-24
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-10 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-27 |
| Ricardo Salas | Revisar el anexo 3 | 2026-10-08 |
| Laura Vélez | Aprobar el diseño 5 | 2026-10-10 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-22 |
| Diana Molina | Confirmar la fecha 7 | 2026-10-16 |
| Carlos Peña | Enviar el documento 9 | 2026-09-26 |
| Óscar Ramírez | Aprobar el diseño 13 | 2026-10-09 |
| Jorge Medina | Actualizar la matriz 14 | 2026-10-02 |
| Elena Duarte | Confirmar la fecha 15 | 2026-09-30 |
| Felipe Arango | Entregar el punto 16 | 2026-10-18 |

## Cerrados en esta reunión

- Revisar el anexo 11 (Camilo Beltrán): recibido, acta de recibo del 2026-09-24.

## Lo que se dijo

- Óscar Ramírez dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Mauricio Pérez dice que ya entregó «validar el ambiente 12». No se presentó acta.
