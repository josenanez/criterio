<!-- origen: PRY-201-programa-de-fidelización/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Programa de fidelización

**Fecha:** 2026-09-10
**Asistentes:** Diana Molina, Felipe Arango, Javier Hoyos, Laura Vélez, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-02 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-01 |
| Ricardo Salas | Revisar el anexo 3 | por definir |
| Laura Vélez | Aprobar el diseño 5 | 2026-09-19 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-22 |
| Diana Molina | Confirmar la fecha 7 | 2026-09-28 |
| Felipe Arango | Entregar el punto 8 | 2026-09-20 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Felipe Arango): recibido, acta de recibo del 2026-09-10.
