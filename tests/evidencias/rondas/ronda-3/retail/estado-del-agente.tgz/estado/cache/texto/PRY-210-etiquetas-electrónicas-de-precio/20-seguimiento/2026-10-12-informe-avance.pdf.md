<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 81%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.888.712.797
Ejecutado 1.672.978.293
Proyección al cierre 3.888.009.179

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la regulación de datos personales que puede mover el alcance
