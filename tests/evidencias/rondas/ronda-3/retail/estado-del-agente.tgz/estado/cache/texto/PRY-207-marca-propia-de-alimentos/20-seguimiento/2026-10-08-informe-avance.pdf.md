<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Marca propia de alimentos
Código: PRY-207
Fecha de corte: 2026-10-08
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 69%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.584.219.025
Ejecutado 3.566.519.533
Proyección al cierre 6.551.457.984

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la regulación de datos personales que puede mover el alcance
