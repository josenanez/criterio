<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-02-22-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Abastecimiento
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Transformación Digital
**Producto asociado:** marca propia
**Fecha de aprobación:** 2026-02-22

## Objetivo del negocio

Entregar marca propia de alimentos para Abastecimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-02-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-04 |
| Cierre | 2027-03-21 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
