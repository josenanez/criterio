<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Reposición automática

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Laura Vélez

## Estado declarado

**Rojo**

Avance reportado: **50%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.652.331.864 |
| Ejecutado | 3.402.192.640 |
| Proyección al cierre | 6.986.277.909 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- El proveedor no ha confirmado la fecha de la última entrega
