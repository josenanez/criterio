<!-- origen: PRY-205-pago-con-qr-en-caja/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Pago con QR en caja

Fecha: 2026-10-04

Asistentes: Óscar Ramírez, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Sandra Gil

Entregar el punto 37

2026-10-01
