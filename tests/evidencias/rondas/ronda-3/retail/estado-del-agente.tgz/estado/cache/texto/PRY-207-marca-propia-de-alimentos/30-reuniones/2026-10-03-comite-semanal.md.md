<!-- origen: PRY-207-marca-propia-de-alimentos/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Marca propia de alimentos

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 9 | 2026-10-25 |
