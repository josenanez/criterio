<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2025-10-26-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-12 | 2026-01-12 | cerrado
Ambiente de pruebas certificado | 2026-03-21 | 2026-03-21 | cerrado
Integración con el ERP | 2026-05-29 | 2026-05-29 | cerrado
Piloto en tiendas | 2026-08-05 | 2026-08-05 | cerrado
