<!-- origen: PRY-204-cajas-de-autopago/00-gobierno/2026-02-28-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Tiendas
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Expansión
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2026-02-28

## Objetivo del negocio

Entregar cajas de autopago para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Expansión el 2026-02-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-10 |
| Cierre | 2027-10-27 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
