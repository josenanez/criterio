<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2026-04-30-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-08-12 | 2026-08-12 | cerrado
Ambiente de pruebas certificado | 2026-11-14 | 2026-11-14 | en curso
Integración con el ERP | 2027-02-17 | 2027-02-17 | en curso
Piloto en tiendas | 2027-05-22 | 2027-05-22 | en curso
