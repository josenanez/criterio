<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración del ERP

**Código:** PRY-209
**Fecha de corte:** 2026-10-11
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **64%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.588.941.281 |
| Ejecutado | 3.392.842.170 |
| Proyección al cierre | 8.271.586.540 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Concentración del conocimiento en una sola persona
