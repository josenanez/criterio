<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cajas de autopago
Código: PRY-204
Fecha de corte: 2026-10-15
Gerente: Andrés Lozano

Estado declarado
Rojo
Avance reportado: 33%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.287.754.922
Ejecutado 2.100.594.572
Proyección al cierre 3.923.148.729

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
- Congelamiento de cambios en temporada alta
