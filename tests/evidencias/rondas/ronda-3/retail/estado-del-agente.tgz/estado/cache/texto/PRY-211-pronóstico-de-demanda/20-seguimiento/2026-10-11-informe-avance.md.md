<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **46%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.841.288.242 |
| Ejecutado | 844.241.353 |
| Proyección al cierre | 2.421.664.600 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
