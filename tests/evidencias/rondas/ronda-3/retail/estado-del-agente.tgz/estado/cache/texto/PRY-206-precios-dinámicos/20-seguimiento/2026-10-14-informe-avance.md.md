<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Rojo**

Avance reportado: **37%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.603.558.895 |
| Ejecutado | 1.215.603.378 |
| Proyección al cierre | 7.102.698.299 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
