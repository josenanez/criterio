<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-07-11-acta-recibo-ct-778-licenciamiento-de-la-plataforma.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento de la plataforma
Proyecto: PRY-206 · Precios dinámicos
Fecha de recibo: 2026-07-11
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Licenciamiento de la plataforma.
Contrato CT-778 · Logística del Valle Ltda..
