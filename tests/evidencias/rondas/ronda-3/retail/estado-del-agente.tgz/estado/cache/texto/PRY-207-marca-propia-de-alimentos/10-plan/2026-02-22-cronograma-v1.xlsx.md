<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2026-02-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-05-27 | 2026-05-27 | cerrado
Ambiente de pruebas certificado | 2026-08-20 | 2026-08-20 | cerrado
Integración con el ERP | 2026-11-13 | 2026-11-13 | en curso
Piloto en tiendas | 2027-02-06 | 2027-02-06 | en curso
