<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2025-09-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pago con QR en caja

Código: PRY-205

Área dueña: Servicio al cliente

Patrocinador: María Restrepo

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Transformación Digital

Producto asociado: pago con QR

Fecha de aprobación: 2025-09-15

Objetivo del negocio

Entregar pago con qr en caja para Servicio al cliente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-09-15.

Fechas comprometidas

Fecha

Inicio

2025-09-25

Cierre

2027-01-16

Criterio de éxito

Pago con QR en caja en producción y medido.

Dependencias declaradas

• Ninguna declarada
