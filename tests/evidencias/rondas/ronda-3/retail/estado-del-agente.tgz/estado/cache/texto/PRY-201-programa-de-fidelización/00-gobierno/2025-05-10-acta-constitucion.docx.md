<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-05-10-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de fidelización

Código: PRY-201

Área dueña: Comercio electrónico

Patrocinador: Felipe Arango

Gerente de proyecto: Diana Molina

Comité: Comité Comercial

Producto asociado: puntos de fidelización

Fecha de aprobación: 2025-05-10

Objetivo del negocio

Entregar programa de fidelización para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité Comercial el 2025-05-10.

Fechas comprometidas

Fecha

Inicio

2025-05-20

Cierre

2026-12-07

Criterio de éxito

Programa de fidelización en producción y medido.

Dependencias declaradas

• Ninguna declarada
