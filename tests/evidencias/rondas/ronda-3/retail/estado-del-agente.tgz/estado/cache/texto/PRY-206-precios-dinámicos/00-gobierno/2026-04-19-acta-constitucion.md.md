<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2026-04-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Precios dinámicos

**Código:** PRY-206
**Área dueña:** Comercio electrónico
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-19

## Objetivo del negocio

Entregar precios dinámicos para Comercio electrónico.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité Comercial el 2026-04-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-29 |
| Cierre | 2026-12-03 |

## Criterio de éxito

Precios dinámicos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
