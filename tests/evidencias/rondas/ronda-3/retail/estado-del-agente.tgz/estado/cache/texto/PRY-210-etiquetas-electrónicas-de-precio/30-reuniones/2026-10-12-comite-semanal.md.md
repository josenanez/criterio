<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Etiquetas electrónicas de precio

**Fecha:** 2026-10-12
**Asistentes:** Carlos Peña, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 3 | 2026-10-11 |
