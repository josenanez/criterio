<!-- origen: PRY-209-migración-del-erp/00-gobierno/2025-11-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración del ERP

**Código:** PRY-209
**Área dueña:** Talento humano
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-20

## Objetivo del negocio

Entregar migración del erp para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-11-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-30 |
| Cierre | 2027-03-06 |

## Criterio de éxito

Migración del ERP en producción y medido.

## Dependencias declaradas

- Ninguna declarada
