<!-- origen: PRY-201-programa-de-fidelización/10-plan/2025-05-10-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-08-30 | 2025-08-30 | cerrado
Ambiente de pruebas certificado | 2025-12-11 | 2025-12-11 | cerrado
Integración con el ERP | 2026-03-24 | 2026-03-24 | cerrado
Piloto en tiendas | 2026-07-05 | 2026-07-05 | cerrado
Despliegue en la cadena | 2026-10-16 | 2026-10-16 | en curso
