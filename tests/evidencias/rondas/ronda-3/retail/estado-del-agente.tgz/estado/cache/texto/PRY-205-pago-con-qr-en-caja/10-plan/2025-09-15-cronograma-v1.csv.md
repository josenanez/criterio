<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2025-09-15-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-12-20,2025-12-20,cerrado
Ambiente de pruebas certificado,2026-03-17,2026-03-17,cerrado
Integración con el ERP,2026-06-12,2026-06-12,cerrado
Piloto en tiendas,2026-09-07,2026-09-07,cerrado
Despliegue en la cadena,2026-12-03,2026-12-03,en curso
