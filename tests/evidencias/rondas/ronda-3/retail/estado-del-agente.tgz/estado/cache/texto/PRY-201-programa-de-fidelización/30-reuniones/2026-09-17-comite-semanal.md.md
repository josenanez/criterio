<!-- origen: PRY-201-programa-de-fidelización/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Programa de fidelización

**Fecha:** 2026-09-17
**Asistentes:** Camilo Beltrán, Carlos Peña, Diana Molina, Javier Hoyos, Laura Vélez, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-23 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-11 |
| Ricardo Salas | Revisar el anexo 3 | por definir |
| Laura Vélez | Aprobar el diseño 5 | 2026-09-19 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-09-22 |
| Diana Molina | Confirmar la fecha 7 | 2026-09-28 |
| Carlos Peña | Enviar el documento 9 | 2026-09-26 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-15 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-10-05 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-14 |

## Cerrados en esta reunión

- Entregar el punto 8 (Felipe Arango): recibido, acta de recibo del 2026-09-17.
