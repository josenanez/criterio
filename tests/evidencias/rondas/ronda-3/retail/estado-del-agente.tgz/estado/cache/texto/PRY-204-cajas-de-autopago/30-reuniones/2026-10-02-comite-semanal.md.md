<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Cajas de autopago

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 21 | por definir |
