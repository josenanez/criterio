<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2026-01-18-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tienda en línea

Código: PRY-200

Área dueña: Servicio al cliente

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Transformación Digital

Producto asociado: venta en línea

Fecha de aprobación: 2026-01-18

Objetivo del negocio

Entregar tienda en línea para Servicio al cliente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Transformación Digital el 2026-01-18.

Fechas comprometidas

Fecha

Inicio

2026-01-28

Cierre

2027-06-22

Criterio de éxito

Tienda en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
