<!-- origen: PRY-200-tienda-en-línea/10-plan/2026-01-18-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-05-21 | 2026-05-21 | cerrado
Ambiente de pruebas certificado | 2026-09-11 | 2026-09-11 | cerrado
Integración con el ERP | 2027-01-03 | 2027-01-03 | en curso
Piloto en tiendas | 2027-04-26 | 2027-04-26 | en curso
