Fuentes: ficha PRY-208 (estado/records/PRY-208.json), construida desde el acta de constitución (2025-05-23), el cronograma v1 (2025-05-23) y el informe de avance (2026-10-11). Cifras recalculadas con `portafolio.py compute` al 2026-10-15. Términos vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15).

## Presupuesto — PRY-208 Domicilios en dos horas, al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100% | acta de constitución | 2025-05-23 |
| Comprometido | 2.667.124.370 | 39.2% | informe de avance (declaración) | 2026-10-11 |
| Ejecutado | 2.364.534.774 | 34.8% | informe de avance (declaración) | 2026-10-11 |
| Proyección al cierre | 8.103.742.416 | 19.2% por encima del aprobado | informe de avance (declaración) | 2026-10-11 |

**Disponible real** (aprobado menos comprometido): 4.132.875.630 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | 0 (sin cambios registrados) |
| Proyección frente al aprobado | | | +19.2% |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. Por eso la proyección no tiene un aumento aprobado que la respalde: excede el aprobado sin que exista un cambio.

### Ejecución frente a avance
Ejecutado 34.8% · Hitos cumplidos 4 de 4 (declarados) · Avance declarado 81%.
Lectura: la ejecución está muy por debajo del avance declarado. Eso puede ser trabajo hecho y no facturado que aparecería de golpe, pero aquí no se puede afirmar: los 4 hitos figuran como cumplidos sin evidencia de cumplimiento en ningún documento. Además, el plan terminaba el 2026-01-28 (hace 260 días) y el avance declarado es 81%, no 100%: el cronograma respalda 100% y el informe dice 81 (brecha de 19.0 puntos, hacia atrás).

### Alertas
- **Proyección por encima del aprobado: +19.2%** (umbral 10%). La proyección es una declaración del informe del 2026-10-11, no un dato duro. No es más vieja que el último movimiento de presupuesto (no hay ninguno).
- **Estado declarado verde contra tres señales abiertas:** hitos cumplidos sin evidencia, avance contra plan y desviación de costo. El informe del 2026-10-11 no las explica.
- **Hitos cumplidos sin evidencia (4):** Diseño de la experiencia aprobado, Ambiente de pruebas certificado, Integración con el ERP, Piloto en tiendas.
- **Dato viejo:** el monto aprobado viene de un acta de hace 17 meses (umbral 12).
- Comprometido 39.2%: por debajo del umbral de 90%, sin alerta.

### Sin dato
- Autoridad de aprobación del presupuesto y fase del proyecto: no declaradas en ningún documento.
- Causa de la brecha entre la proyección (8.103.742.416) y lo comprometido (2.667.124.370): no está explicada en los documentos.
- Monto de la desviación en pesos de la proyección sobre el aprobado: el script entrega solo el porcentaje (19.2%); no lo calculo a mano.
- Proveedores/contratos: la ficha no registra ninguno, por lo que no hay detalle por proveedor.

### Siguiente paso
Como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`). No la he preparado.
