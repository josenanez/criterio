# Corrida del 2026-10-15 · document-index

13 proyectos · 19 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

88 documentos sin cambio, 0 por releer; 11 citas de PRY-201 al acta de constitución no resuelven aunque el archivo existe en disco; causa no determinada

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 88 · **Sin cambio:** 88 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | pm_record.identity.code | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.name | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.business_area | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.product | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.sponsor | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.manager | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.committee | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.plan.start_date | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.plan.end_date | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.money.currency | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.money.approved | 00-gobierno/2025-05-10-acta-constitucion.docx |

Nota: el archivo sí existe en disco (PRY-201-programa-de-fidelización/00-gobierno/2025-05-10-acta-constitucion.docx). No está borrado ni renombrado; el índice no logra resolver la cita. No sé la causa (posiblemente cómo se escribe la ruta con la carpeta del proyecto); hay que revisarla antes de confiar en esos 11 campos.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

Nada que releer: no se ofrece barrido. Corrección de citas por renombrado: no aplica.
