# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 28 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Barrido: 88 documentos sin cambios, 11 citas pm_record de PRY-201 sin resolver por ruta sin carpeta del proyecto. Confirmación: 5 preguntas sobre PRY-201 sin respondedor. No sé cuál fecha de fin es la vigente ni cuál cifra comprometido/ejecutado es correcta.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 88 documentos · 0 cambiaron · 0 proyectos recalculados

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

### Lo que cruzó un umbral
Nada nuevo por documentos. Un hallazgo del índice: 11 citas del bloque `pm_record` de PRY-201 (código, nombre, área, producto, patrocinador, gerente, comité, fechas de inicio y fin, moneda y aprobado) apuntan a `00-gobierno/2025-05-10-acta-constitucion.docx` y no resuelven, aunque el archivo existe en `PRY-201-programa-de-fidelización/00-gobierno/`. La ruta está escrita sin la carpeta del proyecto. No releí nada: el documento no cambió.

### Peticiones atendidas
Ninguna en el servidor.

### Preguntas
Nadie responde en esta corrida; quedan preguntadas el 2026-10-15, sin respuesta. Cinco campos de PRY-201, por importancia:
1. Fecha de fin: 2026-10-16 (cronograma v1) contra 2026-12-07 (`pm_record`, acta). ¿Cuál es la vigente?
2. Estado declarado «verde» y avance 39 % (informe de avance 2026-09-27), con fin de plan mañana según el cronograma. ¿Sigue vigente?
3. Comprometido 1.368.780.814 COP por debajo de ejecutado 1.750.850.713 COP (informe 2026-09-27). ¿Cuál cifra es la correcta?
4. Proyección 4.226.425.039 COP contra aprobado 4.200.000.000 COP. ¿Hay cambio aprobado que cubra la diferencia?
5. Fase y autoridad de aprobación: vacías en la ficha. ¿Quién es la autoridad y en qué fase está?

**Vuelvo el 2026-10-16.** El informe de comité (22 de octubre) toca el 2026-10-20.
