# Portafolio — 2026-10-15
13 proyectos · 10 con hallazgos · 61 señales · último barrido 2026-10-15

Cargué las 13 fichas de `estado/records` con fecha de barrido 2026-10-15. Ninguna tiene más de una semana sin barrido (el mayor silencio es de 7 días, PRY-207).

Términos vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15 para esta prueba).

## Qué cambió desde 2026-10-15
Sin cambios desde la corrida anterior. La instantánea previa es del mismo día (2026-10-15) y el diff dio 0 cambios.

## Contradicciones abiertas
7 proyectos declaran verde y la evidencia lo contradice: PRY-200, PRY-201, PRY-205, PRY-207, PRY-208, PRY-209 y PRY-210. El detalle de cada campo, con sus dos fuentes y fechas, está en `index.html`.
PRY-201 tiene además una diferencia entre lo que dice el gerente de proyecto y lo que dice la PMO (`pm_vs_pmo`).

## Hitos vencidos sin evidencia
- PRY-206: 1 hito vencido.
- PRY-209: 1 hito vencido.

Hitos dados por cumplidos sin evidencia: PRY-208 (4), PRY-205 (3), PRY-201 (2), PRY-202 (2), PRY-206 (2), PRY-207 (2), PRY-200 (1), PRY-204 (1), PRY-209 (1).

## Proyectos en silencio
Ninguno. El umbral es 15 días y el mayor silencio es de 7 días (PRY-207).

## Dependencias en riesgo
Ninguna. Ninguna ficha declara dependencias entre proyectos.

## Sin sustento
Avance declarado por encima de lo que el plan sostiene (señal `progress_vs_plan`):

| Proyecto | Declara | El plan sostiene |
|---|---|---|
| PRY-201 Programa de fidelización | 39 % | 80–100 % |
| PRY-202 Centro de distribución norte | 27 % | 100 % |
| PRY-205 Pago con QR en caja | 37 % | 80–100 % |
| PRY-206 Precios dinámicos | 37 % | 60–80 % |
| PRY-208 Domicilios en dos horas | 81 % | 100 % |
| PRY-210 Etiquetas electrónicas de precio | 81 % | 25–50 % |

PRY-210 es el caso inverso: declara más de lo que el plan sostiene.

## Vacíos de información
- Los 13 proyectos no tienen autoridad registrada.
- 6 proyectos no tienen producto asociado: PRY-202, PRY-203, PRY-206, PRY-209, PRY-210 y PRY-211.
- PRY-211 no declara porcentaje de avance.
- Compromisos sin fecha: PRY-201, PRY-202 y PRY-204.

## Estado general
| Proyecto | Señales | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 0 | 0 días | 0 días | 0 |
| PRY-200 Tienda en línea | 3 | 0 días | 0 días | 0 |
| PRY-201 Programa de fidelización | 17 | 0 días | 0 días | 0 |
| PRY-202 Centro de distribución norte | 4 | 0 días | 0 días | 0 |
| PRY-203 Reposición automática | 0 | 0 días | 0 días | 0 |
| PRY-204 Cajas de autopago | 2 | 0 días | 0 días | 0 |
| PRY-205 Pago con QR en caja | 11 | 0 días | 0 días | 0 |
| PRY-206 Precios dinámicos | 7 | 0 días | 0 días | 0 |
| PRY-207 Marca propia de alimentos | 3 | 0 días | 0 días | 0 |
| PRY-208 Domicilios en dos horas | 7 | 0 días | 0 días | 0 |
| PRY-209 Migración del ERP | 4 | 0 días | 0 días | 0 |
| PRY-210 Etiquetas electrónicas de precio | 3 | 0 días | 0 días | 0 |
| PRY-211 Pronóstico de demanda | 0 | 0 días | 0 días | 0 |

Costo: variación sobre el umbral del 10 % en PRY-208 y PRY-209.

Proveedores: PRY-205 tiene 4 entregables atrasados y una factura sin entrega. PRY-201 y PRY-206 tienen facturación por encima de lo aceptado y entregables aceptados sin evidencia. Compromisos vencidos: PRY-201 (4), PRY-200, PRY-205 y PRY-210 (1 cada uno); PRY-201 tiene además 3 compromisos reprogramados.

## Necesito que confirmes
Esta corrida de prueba no tiene a quién preguntarle, así que la confirmación mensual no se hizo. Las cinco preguntas cerradas quedan para la próxima corrida con interfaz.

## Dónde quedó el informe
Carpeta `reportes/2026-10-15-portafolio` (24 páginas):
- `index.html`: vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `decisiones.html`: vista por decisión, para el patrocinador. Solo lo que excede la facultad de quien gerencia.
- Una página por proyecto (13), por producto (7), más `productos.html` y `proyectos.html`.
- Para PDF, se imprime el HTML.

---
Criterio Portfolio v0.3.9 · 13 fichas aplicadas, todas con barrido de 2026-10-15 · campos inciertos: ver `index.html` · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
