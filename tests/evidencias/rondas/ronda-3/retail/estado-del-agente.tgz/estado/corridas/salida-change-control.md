Parto de la ficha `estado/records/PRY-205.json` (actualizada 2026-10-15). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15.

## Solicitud de cambio — PRY-205 Pago con QR en caja — 2026-10-15

**Qué se pide:** mover 30 días la salida a producción (hito «Despliegue en la cadena»). · **Quién lo pide:** no consta en los documentos; la solicitud llegó por la invocación. · **Por qué:** no se dio motivo. Sin motivo no hay solicitud completa.

### Línea base vigente
Una sola: v1, aprobada 2025-09-15 por el Comité de Transformación Digital (`10-plan/2025-09-15-cronograma-v1.csv`). Cero replanificaciones; la fecha vigente de cada hito es igual a la de la línea base. No hay solicitudes de cambio previas en la carpeta (`changes`: vacío).

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3, sin detalle (acta) | No declarado | Sin impacto declarado |
| Tiempo | Despliegue en la cadena: 2026-12-03 (cronograma v1) | 2027-01-02 | +30 días (hoy faltan 49 días para el 2026-12-03) |
| Costo | Aprobado 4.200.000.000 COP; proyección 3.958.059.174 COP; margen 241.940.826 COP (5,8 %) | No declarado | Sin impacto declarado |

**Quién absorbe lo no declarado.** Si el alcance no cambia y la fecha se mueve 30 días, el equipo y el proveedor trabajan un mes más sin presupuesto adicional pedido. Ese mes sale de los 241,9 millones de margen, de horas no pagadas, o de calidad. El documento no dice cuál; hay que preguntarlo. El margen es de 5,8 %, por debajo del umbral de variación de costo de 10 % configurado, y la proyección de 3.958 millones ya lo consume sin el mes extra.

**Discrepancia de fechas que hay que resolver antes de aprobar.** El acta de constitución fija el **cierre del proyecto en 2027-01-16**. El cronograma v1 pone el despliegue en 2026-12-03. Con el cambio, el despliegue queda en 2027-01-02, solo 14 días antes del cierre del acta. El criterio de éxito es «en producción y medido». Ningún documento dice cuánto tarda la medición, así que no se sabe si caben en esos 14 días. La ficha no registra esta diferencia como conflicto abierto; la dejo señalada.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno calculado | `impact` alcanza 0 proyectos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

**Esto no significa que no haya efecto.** El acta declara «Ninguna declarada» como dependencias, y la ficha tiene `dependencies` vacío. El cálculo solo recorre dependencias declaradas; con ninguna declarada, devuelve cero. No se sabe si otro proyecto espera esta salida (por ejemplo, el producto «pago con QR» en otros proyectos). Hay que preguntarlo a la PMO y al patrocinador. Tampoco se calcula cuántos días se mueve cada hito, porque la ficha no tiene holgura por actividad. El único hito por el que pasa el cambio es «Despliegue en la cadena».

### Cosas del proyecto que el cambio no arregla y que el comité va a querer ver
- **Estado declarado verde con 37 % de avance** (informe 2026-10-14), pero ya se ejecutó el 47,7 % del presupuesto aprobado (2.002.590.000 de 4.200.000.000) y se comprometió el 73 %. Pedir 30 días y reportar verde no es coherente. Que se pida una prórroga es en sí una señal contra el verde.
- **Los cuatro entregables del proveedor CT-377 constan pendientes, y las cuatro fechas ya pasaron** (licenciamiento 2025-12-29, bolsa de horas 2026-04-04, catálogo 2026-07-08, soporte 2026-10-12), sin acta de recibo en la carpeta. Aun así hay una factura FV-1377 de 247.703.694 COP radicada el 2026-08-29. El contrato exige acta de recibo firmada por el gerente para facturar, y esa acta no está. No se puede decir si se entregó; se puede decir que no hay evidencia.
- **Riesgos que el informe ya reconoce:** el proveedor no ha confirmado la fecha de la última entrega, y el conocimiento está concentrado en una persona. Ambos tocan directamente la salida a producción.
- **Compromiso vencido:** Sandra Gil, «Entregar el punto 37», para 2026-10-01, registrado en el comité del 2026-10-04 (fecha anterior a la reunión, sin evidencia de entrega, y ella no figura como asistente).
- **Hitos cerrados sin fecha real.** Todos los hitos cerrados muestran fecha vigente igual a la línea base. El acta de recibo del «Ambiente de pruebas certificado» es del 2026-10-03, y el hito estaba previsto para 2026-03-17. Esa diferencia, unos 200 días, no está reflejada como atraso ni como replanificación. Así que «0 replanificaciones» puede estar describiendo un plan que no se actualizó, no uno que se cumplió.

### Quién decide
**Autoridad requerida:** no determinable. La ficha tiene `identity.authority` en «no encontrado»: el acta no declara quién puede aprobar cambios de fecha o de costo, ni umbrales. · **Según:** acta de constitución 2025-09-15, sin cláusula de autoridad. · **Va a comité:** sí, por defecto. La línea base la aprobó el Comité de Transformación Digital, y lo que modifica una línea base aprobada por un comité no debería aprobarlo el gerente. Próximo comité configurado: 2026-10-22. Esto lo asumo yo; el documento no lo dice, y el hallazgo de fondo es justamente que falta la autoridad declarada.

### Si no se aprueba
El proyecto sigue con salida el 2026-12-03 y cierre el 2027-01-16, con 49 días por delante, 37 % de avance reportado y un entregable de proveedor sin confirmar fecha. No hay en los documentos nada que demuestre que esa fecha se sostiene; lo que hay (riesgo del proveedor, entregables sin acta, avance de 37 %) apunta a que no. No puedo afirmar que se incumplirá, porque no hay plan detallado ni holgura.

### Si se aprueba
Línea base 2 — despliegue 2027-01-02 · cierre del acta sin cambio (2027-01-16) salvo que el comité lo mueva · presupuesto: sin cambio solicitado (4.200.000.000 COP) · motivo: **pendiente, nadie lo ha dado**.
Desviación acumulada contra la línea base original: tiempo +30 días (despliegue) · costo: sin variación solicitada; proyección actual 241.940.826 COP por debajo del aprobado.
Quedaría la línea base v1 intacta, con su motivo, y el conteo de replanificaciones pasaría de 0 a 1. Hoy no hay días sin autorizar: `changes` está vacío y la línea base no se ha movido.

### Qué hace falta para completar esta solicitud
1. Motivo del cambio y quién lo solicita.
2. Si cambia el alcance o el costo, y quién absorbe el mes extra.
3. Qué otros proyectos o áreas esperan la salida (dependencias reales).
4. Cuál es la fecha de cierre válida: 2027-01-16 del acta, u otra.
5. Estado real de los entregables del CT-377 y sus actas de recibo.
6. Quién tiene autoridad de aprobar este cambio.

**Siguiente paso que ofrezco:** llevarlo al comité del 2026-10-22 como paquete de decisión (`/steering-pack`) una vez estén los puntos 1 a 4. No registro línea base nueva: nadie con autoridad la ha aprobado.

---
**Pie de rigor.** Todo lo anterior sale de los 7 documentos de la carpeta PRY-205 (acta, contrato, cronograma v1, factura, acta de recibo, informe de avance, acta de comité) y del cálculo `impact`. Lo que no está en esos documentos —motivo, autor, dependencias de otros proyectos, holgura, autoridad, fecha de cierre válida— lo digo como no sabido y no lo he inferido. Es un borrador de trabajo, no una decisión; la verificación contra los originales es de quien lo lee.
