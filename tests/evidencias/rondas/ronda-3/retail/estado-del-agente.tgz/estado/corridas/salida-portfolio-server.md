# Rostrum — modo «para mirarlo un rato»

Sin respuesta a «¿rato o que quede corriendo?» en esta prueba, y el argumento fue `rato`: se levanta el modo rato, que es también lo que se recomienda cuando no se sabe cuál se quiere.

**Términos:** ya vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15). No se registraron de nuevo.

**Informe que se sirve:** `reportes/2026-10-15-portafolio` (HTML, del 2026-10-15). Estado: `estado`. Organización en el portal: Retail (prueba).

**Dirección:** http://127.0.0.1:8787, solo en este equipo. Se apaga con Ctrl-C.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica y no manda nada. Las peticiones del formulario esperan al agente: `portafolio.py due` las cuenta y rompen el silencio de `/portfolio-wake`.

**Límite de este modo:** el patrocinador no tiene un enlace que funcione mañana. Para eso está «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización, que es quien autentica); es otra conversación y conviene tenerla con el portal ya visto funcionando.

**Qué enlace a quién:** en este modo, ninguno por ahora: la dirección solo abre en este equipo, así que se mira aquí, con quien esté presente. El informe es del 2026-10-15; la portada muestra su fecha, y queda desactualizado en cuanto cambien los documentos o se corra otro barrido, antes del comité del 2026-10-22.
