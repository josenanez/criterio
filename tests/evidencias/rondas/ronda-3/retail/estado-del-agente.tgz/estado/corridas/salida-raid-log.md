**Sale de:** las 13 fichas de `estado/records` (PRY-199 a PRY-211), los informes de avance (sección "Riesgos abiertos"), las actas de constitución (sección "Dependencias declaradas"), 14 minutas de comité y las notas de reunión del 2026-10-15 de PRY-201. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15. Escala de valoración: no hay una definida en la organización; se usaría alta/media/baja y ningún ítem trae probabilidad ni impacto.

## RAID — portafolio al 2026-10-15
15 riesgos · 0 supuestos · 12 incidencias · 8 dependencias
35 sin doliente · 35 sin fecha de resolución · 1 no registrado formalmente
"Sin movimiento" no se puede medir: cada ítem tiene una sola observación, la fecha de su informe, y no hay historial de movimiento. Se dice que no se sabe; no se supone.

Contado tras reclasificar (abajo). Antes eran 23 riesgos, 12 incidencias y 0 dependencias.

### Reclasificado
- **"El proveedor no ha confirmado la fecha de la última entrega" (PRY-199, 200, 202, 203, 205, 206, 207, 210): riesgo → dependencia declarada, sin confirmar.** Depende de un tercero y es algo que el proyecto no controla. Las actas de constitución de los 8 dicen "Ninguna declarada", así que la dependencia existe en el informe y no en el acta. No se cita un código de proyecto del que dependa: es un proveedor, y el informe no lo nombra.

### Necesitan decisión ahora
Los tres primeros cumplen el criterio de escalamiento "afecta a otro proyecto del portafolio". El cuarto lo cumple por dueño externo no identificado.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| Hallazgo de seguridad en los medios de pago | Incidencia | Mismo hallazgo en PRY-199, 202, 203, 209 | no identificado | 2026-10-03 (PRY-202) a 2026-10-14 (PRY-203) | Cuatro proyectos; sin doliente ni fecha. Es un hecho, no un riesgo. |
| La prueba de carga de temporada no alcanzó el umbral y se repite | Incidencia | PRY-199, 203, 211 | no identificado | 2026-10-11 a 2026-10-14 | Tres proyectos; sin fecha de repetición. |
| El equipo perdió dos semanas por rotación de un desarrollador clave | Incidencia | PRY-201, 208, 210 | no identificado | 2026-09-27 (PRY-201) a 2026-10-12 | Tres proyectos; pérdida ya ocurrida, sin plan de recuperación citado. |
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Riesgo (PRY-201) | Ver sección siguiente | no identificado | 2026-10-15 | Dueño externo (proveedor) y nadie lo anotó. |

Decisión que habría que formular para el comité del 2026-10-22: quién es el doliente único de cada una de las tres incidencias transversales y para cuándo se resuelven.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Riesgo | PRY-201, `2026-10-15-notas-reunion.txt`: "se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo" | 2026-10-15 |

Es el único. Las otras 13 minutas de comité solo traen compromisos y ningún riesgo dicho al pasar. No se inventó ninguno. El proveedor no está nombrado en la nota; PRY-201 tiene dos (Tecnología para Tiendas CT-963 y Datos y Demanda CT-978) y no sé a cuál se refiere. La ficha ya lo contiene con probabilidad, impacto, doliente y fecha en "no declarado".

### Sin doliente o sin fecha
Los 35 ítems no tienen doliente ni fecha de resolución; las fichas no los traen y el informe de avance tampoco. No se rellenó ninguno. Por tipo:

| Tipo | Ítems | Qué falta |
|---|---|---|
| Riesgo | 15 | Doliente, fecha, probabilidad, impacto |
| Incidencia | 12 | Doliente, fecha de resolución (solo traen fecha de inicio) |
| Dependencia declarada | 8 | Doliente, contraparte nombrada, confirmación, fecha |

### Dependencias en riesgo
Cruce entre proyectos: **no se puede hacer.** Ningún proyecto declara dependencia de otro (las 13 actas dicen "Ninguna declarada" y las fichas tienen `dependencies` vacío). Que no esté declarado no prueba que no exista. Las 8 dependencias son de proveedor, sin código de proyecto:

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199, 200, 202, 203, 205, 206, 207, 210 | Proveedor de la última entrega (no nombrado) | No | El informe más reciente de cada uno dice que el proveedor no ha confirmado la fecha. |

### Registro completo
Prob., impacto, doliente y fecha: "no declarado" en todos, salvo que se indique. El último movimiento es la fecha del informe donde aparece; no es un movimiento medido.

| Proyecto | Tipo | Qué | Fuente (fecha) |
|---|---|---|---|
| PRY-199 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-13 |
| PRY-199 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-13 |
| PRY-199 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-13 |
| PRY-199 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-13 |
| PRY-200 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-10 |
| PRY-201 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-09-27 |
| PRY-201 | Riesgo (no registrado formalmente) | Proveedor podría no llegar con equipo completo en la siguiente fase | notas 2026-10-15 |
| PRY-201 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-09-27 |
| PRY-202 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-03 |
| PRY-202 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-03 |
| PRY-203 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-14 |
| PRY-203 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-14 |
| PRY-203 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-14 |
| PRY-203 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-14 |
| PRY-204 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-15 |
| PRY-204 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-15 |
| PRY-205 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-14 |
| PRY-205 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-14 |
| PRY-206 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-14 |
| PRY-206 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-14 |
| PRY-206 | Incidencia | Validación con dos tiendas extendida una semana por conteo de inventario | 2026-10-14 |
| PRY-207 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-08 |
| PRY-207 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-08 |
| PRY-208 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-11 |
| PRY-208 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-11 |
| PRY-208 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-10-11 |
| PRY-209 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-11 |
| PRY-209 | Riesgo | Concentración del conocimiento en una sola persona | informe 2026-10-11 |
| PRY-209 | Incidencia | Validación con dos tiendas extendida una semana por conteo de inventario | 2026-10-11 |
| PRY-209 | Incidencia | Hallazgo de seguridad en los medios de pago | 2026-10-11 |
| PRY-210 | Dependencia | Proveedor sin confirmar fecha de última entrega | informe 2026-10-12 |
| PRY-210 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | informe 2026-10-12 |
| PRY-210 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | 2026-10-12 |
| PRY-211 | Riesgo | Congelamiento de cambios en temporada alta | informe 2026-10-11 |
| PRY-211 | Incidencia | Prueba de carga de temporada bajo el umbral, se repite | 2026-10-11 |

### Lo que debe verificar la persona
- **Texto idéntico en proyectos que no se parecen.** "Hallazgo de seguridad en los medios de pago" aparece en Iluminación LED en bodegas (PRY-199) y en Centro de distribución norte (PRY-202); "prueba de carga de temporada" también en PRY-199, y "rotación de un desarrollador clave" en Etiquetas electrónicas (PRY-210). Puede ser texto copiado de una plantilla en los informes y no un hallazgo real de cada proyecto. Lo registré porque los informes lo dicen, pero valdría la pena confirmarlo con cada gerente antes de llevarlo a comité.
- **"Congelamiento de cambios en temporada alta"** (5 proyectos) es una restricción conocida, no algo incierto. Lo dejé como riesgo porque el informe lo llama así; podría ser un supuesto o una restricción de calendario.
- **PRY-201:** el cronograma pone el despliegue en la cadena el 2026-10-16 (pendiente, sin evidencia) y el informe de avance declara 39 %. La ficha del PM da fin al 2026-12-07 según el acta. No es un ítem RAID y no lo registré; es un tema para `/health-check`.
- No se leyeron los contratos ni los cronogramas buscando vencimientos de mitigación. No hay mitigaciones con fecha en ninguna ficha.

### Después
Puedo subir a comité (2026-10-22) las tres incidencias transversales y el riesgo del proveedor de PRY-201. Puedo proponer un doliente para cada ítem sin doliente; propondría, no asignaría.
