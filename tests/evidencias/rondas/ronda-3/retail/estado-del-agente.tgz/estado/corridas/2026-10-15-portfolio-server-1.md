# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 61 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

puerto 8787, informe reportes/2026-10-15-portafolio, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Sin respuesta a «¿rato o que quede corriendo?» en esta prueba, y el argumento fue `rato`: se levanta el modo rato, que es también lo que se recomienda cuando no se sabe cuál se quiere.

**Términos:** ya vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15). No se registraron de nuevo.

**Informe que se sirve:** `reportes/2026-10-15-portafolio` (HTML, del 2026-10-15). Estado: `estado`. Organización en el portal: Retail (prueba).

**Dirección:** http://127.0.0.1:8787, solo en este equipo. Se apaga con Ctrl-C.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica y no manda nada. Las peticiones del formulario esperan al agente: `portafolio.py due` las cuenta y rompen el silencio de `/portfolio-wake`.

**Límite de este modo:** el patrocinador no tiene un enlace que funcione mañana. Para eso está «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización, que es quien autentica); es otra conversación y conviene tenerla con el portal ya visto funcionando.

**Qué enlace a quién:** en este modo, ninguno por ahora: la dirección solo abre en este equipo, así que se mira aquí, con quien esté presente. El informe es del 2026-10-15; la portada muestra su fecha, y queda desactualizado en cuanto cambien los documentos o se corra otro barrido, antes del comité del 2026-10-22.
