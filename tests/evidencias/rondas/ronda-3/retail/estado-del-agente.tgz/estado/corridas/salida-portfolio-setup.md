## Listo — Retail (prueba)

Soy Vera, el agente PMO de Criterio. Leo la documentación que ya tienes y digo qué no se sostiene.

**Miré:** 88 documentos en 13 proyectos · formatos: .md (50), .pdf (13), .docx (12), .xlsx (6), .csv (5), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (13 proyectos; respuesta sugerida)
**Te aviso:** dos días antes del comité quincenal; el próximo supuesto es el 2026-10-22 (respuesta sugerida, nadie la confirmó)
**En:** presentación (respuesta sugerida)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.9 de la familia (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 del .md f0f8a373c9bdced2…
**Dónde guardo lo que encuentro:** `estado/` · informes en `reportes/` · configuración en `.criterio/portafolio/config.json`

### Probé con tres proyectos

Elegí PRY-203, PRY-204 y PRY-206 (documentación del 14 y 15 de octubre). PRY-201 tiene fecha del 15 también, pero ya lo lleva su propio agente de proyecto y su ficha no es mía; queda para el barrido completo.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-203 Reposición automática | 2 | Patrocinador Camilo Beltrán, gerente Laura Vélez, Comité de Expansión. Presupuesto 6.800.000.000 COP; ejecutado 50 %, proyección 2,7 % sobre lo aprobado. Declara rojo, 50 % (informe del 2026-10-14). Cierre comprometido 2026-08-25. | Cronograma, hitos, producto, facultad del gerente, fase. Ningún proveedor documentado. |
| PRY-204 Cajas de autopago | 4 | Patrocinador Ricardo Salas, gerente Andrés Lozano. Presupuesto 4.200.000.000 COP; comprometido 78,3 %, ejecutado 50 %. Declara rojo, 33 % (informe del 2026-10-15). Producto: autopago en tienda. Cierre 2027-10-27. | Facultad del gerente, fase, proveedores. |
| PRY-206 Precios dinámicos | 12 | Patrocinador Felipe Arango, gerente Sandra Gil. Presupuesto 6.800.000.000 COP; ejecutado 17,9 %, proyección 4,5 % sobre lo aprobado. Declara rojo, 37 % (informe del 2026-10-14). Dos contratos: CT-557 y CT-778. | Producto, facultad del gerente, fase. |

### Hallazgos (los que levantó el cálculo)

**PRY-206 Precios dinámicos**
- **Avance contra plan:** declara 37 %, con 3 de 5 hitos cerrados el plan sustenta entre 60 % y 80 %; 23 puntos de diferencia, declarado por debajo del plan.
- **Hito vencido:** «Piloto en tiendas» (2026-10-04), 11 días, sigue en curso.
- **Hitos cerrados sin acta:** «Diseño de la experiencia aprobado» (2026-06-07) e «Integración con el ERP» (2026-08-25). Solo «Ambiente de pruebas certificado» tiene acta de recibo (2026-10-14).
- **Aceptado sin acta (CT-557, Retail Andino):** «Configuración del catálogo» figura como recibido en el contrato y no hay acta de recibo; aun así está facturado: 2.436.027.969 COP, que equivale a tres entregables.
- **Entregable tardío (CT-778, Logística del Valle):** «Configuración del catálogo», vencía el 2026-10-09, 6 días, pendiente.
- **Facturado sobre lo aceptado (CT-778):** facturado 1.406.566.924 COP contra 1.149.477.566 COP de entregables con acta; diferencia 257.089.358 COP.

**PRY-204 Cajas de autopago**
- **Hito cerrado sin acta:** «Diseño de la experiencia aprobado» (2026-07-20), 87 días.
- **Compromiso sin fecha:** Mauricio Pérez, «Entregar el punto 21», dicho en el comité del 2026-10-02 con fecha «por definir». Mauricio Pérez no figura entre los asistentes de esa reunión.

**PRY-203 Reposición automática:** el cálculo no levantó señales. Lo que el informe declara (rojo, prueba de carga repetida, hallazgo de seguridad en medios de pago) quedó registrado en su ficha como declaración, sin juicio propio.

Los tres proyectos declaran rojo, así que no hay verde contradicho en esta muestra.

### El portafolio completo
10 proyectos más (PRY-199, 200, 201, 202, 205, 207, 208, 209, 210, 211) y 73 documentos sin leer, en dos lotes uno tras otro. La corrida de prueba midió 67 segundos de cálculo, sin contar mi lectura de los documentos, así que no hay una estimación de tiempo fiable para el resto; el volumen es de 88 documentos, muy por debajo del tope de 400 por corrida.

### Lo que le falta a tu carpeta
- PRY-203 y PRY-211 no tienen cronograma; PRY-203 solo tiene acta e informe, y su cierre comprometido (2026-08-25) ya pasó. Sin cronograma no hay hitos que contrastar.
- Las actas de constitución de los tres proyectos tienen alcance genérico («Componente 1, 2, 3») y ninguna dice hasta dónde puede decidir el gerente sin subir a comité: ninguno de los tres tiene facultad declarada.
- Falta el acta de recibo de al menos un hito cerrado en cada proyecto con cronograma revisado.
- Ninguno de los tres tiene dependencias declaradas con otros proyectos.

Ninguno es bloqueante; esto funciona con lo que haya.

**Siguiente:** puedo correr el portafolio completo. También puedo publicar el estándar en una carpeta compartida si tu equipo de gerentes quiere usar los mismos criterios.

**Preguntas hechas:** 0 (sesión sin interfaz; se tomaron las respuestas sugeridas).
