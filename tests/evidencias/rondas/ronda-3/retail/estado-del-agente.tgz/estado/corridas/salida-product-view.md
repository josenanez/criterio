## Producto «autopago en tienda» al 2026-10-15

Fuente: cálculo de `portafolio.py compute` sobre las fichas en `estado`, con corte 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

**Este producto tiene un solo proyecto (PRY-204, Cajas de autopago).** La vista por producto no aporta nada distinto de la ficha del proyecto, así que no armo la sección completa. Sin dependencias internas que cruzar. Lo que sigue es lo que el cálculo da para ese proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| autopago en tienda | 1 (PRY-204) | 2 | 2027-08-21 (PRY-204) | COP 4.200.000.000 | COP 3.287.754.922 (78,3 %) |

**Señales (2):**
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado», vencía 2026-07-20 (87 días), declarado cumplido sin evidencia que lo sustente.
- `commitment_undated`: Mauricio Pérez, «Entregar el punto 21», sin fecha (`30-reuniones/2026-10-02-comite-semanal.md`).

**Otros datos del cálculo:**
- Ejecutado COP 2.100.594.572 (50,0 %); proyección COP 3.923.148.729 (−6,6 % frente al aprobado); disponible real COP 912.245.078. Las cuatro cifras de dinero vienen completas.
- Desviación de fecha frente a la línea base original y a la vigente: 0 días; 0 replanes; 0 cambios registrados.
- Avance declarado 33 %; el plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplidos). No hay brecha.
- El informe de avance del 2026-10-15 declara **rojo** y no da cuenta de la señal del hito sin evidencia.
- Sin proveedores registrados; sin dependencias declaradas.
- Faltan los campos `identity.authority` e `identity.phase`.
- Las 18 fuentes de la ficha no están marcadas como evidencia ni como declaración (0 y 0, 18 sin marcar). No sé cuáles de esos datos son evidencia y cuáles declaración.

### Proyectos sin producto declarado (hallazgo de portafolio)
Seis de los 13 proyectos no declaran producto: PRY-202 Centro de distribución norte, PRY-203 Reposición automática, PRY-206 Precios dinámicos, PRY-209 Migración del ERP, PRY-210 Etiquetas electrónicas de precio y PRY-211 Pronóstico de demanda. El cálculo no entrega el área dueña de ninguno (ningún proyecto tiene `authority`: 13 de 13 sin autoridad), así que no la pongo. Consecuencia: nadie puede responder por el conjunto al que sirven. No sé si alguno de ellos sirve a autopago en tienda; la ficha no lo dice.

**Para el comité (2026-10-22):** no hay dependencias internas que llevar. Lo único accionable de este producto es confirmar la evidencia del hito de diseño y poner fecha al compromiso del punto 21.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale del cálculo del script; la verificación contra los documentos citados es suya.
