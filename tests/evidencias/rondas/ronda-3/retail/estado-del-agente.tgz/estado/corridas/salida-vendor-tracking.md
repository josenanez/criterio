**Sale de:** la ficha `estado/records/PRY-201.json`, el cálculo `portafolio.py compute` al 2026-10-15, los contratos CT-963 y CT-978 (`00-gobierno`), las actas de recibo y las dos facturas de `20-seguimiento`, los comités semanales (09-03 a 10-08) y las notas del 2026-10-15.

## Proveedores — PRY-201 Programa de fidelización al 2026-10-15

### Tecnología para Tiendas Ltda. — contrato CT-963
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato. El contrato (`2025-05-04-contrato-ct-963.docx`) trae fecha de firma, entregables, montos y condición de pago; no trae vigencia, renovación ni preaviso.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2025-09-10 · 343.904.432 | `pending`, 400 días vencido | ninguna | factura FV-1963 (2026-09-03) por 921.509.752 COP, global |
| Bolsa de horas de desarrollo | 2026-01-01 · 343.904.432 | `pending`, 287 días vencido | ninguna | ídem |
| Configuración del catálogo | 2026-04-24 · 343.904.432 | `accepted` | `2026-05-09-acta-recibo-ct-963-configuración-del-catálogo.md` (Diana Molina) | ídem |
| Soporte del primer trimestre | 2026-08-15 · 343.904.432 | `accepted` | `2026-08-22-acta-recibo-ct-963-soporte-del-primer-trimestre.md` (Diana Molina) | ídem |

Monto aceptado con acta: 687.808.864 COP. Facturado: 921.509.752 COP.

### Datos y Demanda S.A.S. — contrato CT-978
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (`2025-05-14-contrato-ct-978.docx`, mismo caso).

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2025-11-24 · 483.046.790 | declarado `accepted` ("recibido" en el contrato) | **ninguna** | factura FV-2978 (2026-09-17) por 966.093.580 COP, global |
| Bolsa de horas de desarrollo | 2026-06-01 · 483.046.790 | `accepted` | `2026-06-20-acta-recibo-ct-978-bolsa-de-horas-de-desarrollo.pdf` (Diana Molina) | ídem |

Monto aceptado según la ficha: 966.093.580 COP. Facturado: 966.093.580 COP. El monto aceptado solo cuadra porque cuenta el licenciamiento, que no tiene acta.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-963: facturado vs. aceptado | Cada entregable se factura contra acta de recibo firmada por el gerente | Facturados 921.509.752; con acta 687.808.864; **diferencia 233.700.888 COP** facturados sin acta que los respalde | contrato CT-963; FV-1963; las dos actas de CT-963 |
| CT-963: entregables vencidos y no recibidos | Licenciamiento (2025-09-10) y bolsa de horas (2026-01-01) comprometidos; el contrato los marca "en curso" | Sin acta ni mención de entrega; 400 y 287 días de atraso | contrato CT-963; ficha |
| CT-978: licenciamiento "recibido" sin acta | Estado "recibido" en el contrato | No hay acta de recibo ni correo en la carpeta; FV-2978 lo incluye | contrato CT-978; FV-2978 |
| Informe de avance | Estado verde, 39 % (2026-09-27) | El cálculo registra 6 señales no explicadas, entre ellas atraso de proveedor y facturado sobre lo aceptado | `2026-09-27-informe-avance.pdf`; compute |

La condición de pago exige acta "firmada por el gerente del proyecto". Las actas leídas dicen "Recibido por: Diana Molina" (gerente según el acta de constitución), pero el texto de las actas no muestra firma; no puedo confirmar la firma desde la copia en texto.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-978 · Licenciamiento de la plataforma | `accepted` / "recibido" | fecha comprometida 2025-11-24; fecha de la marca: sin dato |

Los hitos del proyecto "Ambiente de pruebas certificado" (2025-12-11) e "Integración con el ERP" (2026-03-24) también figuran cumplidos sin evidencia, pero son hitos del plan, no entregables de proveedor.

### Compromisos del proveedor vencidos
Ninguno de los compromisos extraídos de los comités nombra a un proveedor como doliente, así que no hay compromiso de proveedor vencido que citar. Dos asuntos que sí tocan al proveedor:

| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Óscar Ramírez: revisión con el proveedor | notas 2026-10-15 | 2026-10-25 | no vencido |
| Riesgo comentado: el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo registró (sin probabilidad, impacto ni responsable) | notas 2026-10-15 | — | — |

No se identifica de cuál de los dos proveedores habla la nota.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-963 y CT-978: no están en los contratos de la carpeta. Sin ellos no puedo decir si algún preaviso vence antes del cierre del proyecto (el plan cierra el 2026-10-16 según el cronograma; el acta de constitución dice 2026-12-07, discrepancia abierta entre ambas fuentes).
- Desglose de las facturas FV-1963 y FV-2978: traen un valor global y el concepto "Entregables del contrato", sin decir qué entregables cobran.
- Aceptación de licenciamiento CT-978 y firma de las actas: ver arriba.

## Después
- Hay entregables facturados sin evidencia: 233.700.888 COP en CT-963 y una línea de 483.046.790 COP en CT-978. Se puede llevar al comité del 2026-10-22 antes de aprobar el pago de esas facturas, si siguen sin liquidar (ambas figuran "radicadas en cuentas por pagar"; su estado de pago no está en la carpeta).
- Pedir a quien tenga los contratos completos la vigencia y el preaviso.

*Pie de rigor: borrador de trabajo hecho solo con los documentos citados; no sé lo que se habló fuera de ellos. Las cifras derivadas salen del cálculo del script; verifique cada cita contra el original.*
