Informe generado desde la ficha `estado/records/PRY-206.json` (actualizada el 2026-10-15), con cifras de `portafolio.py compute` al 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## PRY-206 · Precios dinámicos — estado al 2026-10-15

**Declara el gerente (Sandra Gil):** rojo · 37% · al 2026-10-14 (1 día de antigüedad; declaración vigente)
**Sustento documental:** contradicho en parte. El rojo es coherente con la evidencia, pero el avance de 37% no coincide con el plan, y dos hitos y un entregable de proveedor figuran cumplidos o aceptados sin acta que lo respalde.
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `progress_vs_plan`, `vendor_deliverable_late`, `vendor_invoiced_over_accepted`
**Último documento:** 2026-10-14 (hace 1 día) · **Última reunión:** sin dato (la ficha no tiene reuniones ni compromisos registrados)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-11-13 | 2026-11-13 | 0 días contra la original y contra la vigente |
| Presupuesto | COP 6.800.000.000 (aprobado) | proyección COP 7.102.698.299 | +4,5% sobre lo aprobado |

Replanificaciones: 0. No hay línea base posterior a la v1 (aprobada el 2026-04-19 por el Comité Comercial). Cambios formales: 0.

Dinero (COP): comprometido 3.603.558.895 (53,0%), ejecutado 1.215.603.378 (17,9%), disponible real 3.196.441.105.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-06-07 | 2026-06-07 | declarado cumplido | **Sin evidencia** (130 días desde su fecha) |
| Ambiente de pruebas certificado | 2026-07-17 | 2026-07-17 | cumplido | Acta de recibo del 2026-10-14 (ver nota abajo) |
| Integración con el ERP | 2026-08-25 | 2026-08-25 | declarado cumplido | **Sin evidencia** (51 días desde su fecha) |
| Piloto en tiendas | 2026-10-04 | 2026-10-04 | pendiente | **Vencido hace 11 días** |
| Despliegue en la cadena | 2026-11-13 | 2026-11-13 | pendiente | — |

Avance: 3 de 5 hitos cumplidos según la ficha; el plan sustenta entre 60% y 80%, el gerente declara 37%, una brecha de 23,0 puntos (por debajo del plan). Solo 1 de los 3 hitos cumplidos tiene evidencia.

### Dónde no coincide
- **Avance declarado frente al plan.** Informe de avance del 2026-10-14: 37%. Cronograma v1 (2026-04-19) con 3 de 5 hitos cumplidos: 60–80%. El gerente reporta menos de lo que el cronograma marcaría; la diferencia es de 23,0 puntos y el informe no la explica.
- **Hitos cumplidos sin acta.** «Diseño de la experiencia aprobado» e «Integración con el ERP» constan como cumplidos en el cronograma, sin documento que los acredite.
- **Piloto en tiendas.** Vencido hace 11 días. El informe del 2026-10-14 registra como incidencia que la validación con dos tiendas se extendió una semana por el conteo de inventario; no hay fecha nueva ni cambio formalizado, y la línea base sigue en 2026-10-04.
- **CT-557 (Retail Andino Consultores S.A.S.).** «Configuración del catálogo» figura aceptado sin acta de recibo; 3 de 4 entregables aceptados, facturado COP 2.436.027.969, igual al monto de los 3 aceptados. Uno de esos tres no tiene acta.
- **CT-778 (Logística del Valle Ltda.).** «Configuración del catálogo» vencía el 2026-10-09 y sigue pendiente (6 días). Facturado COP 1.406.566.924 frente a COP 1.149.477.566 aceptado: **COP 257.089.358 facturados por encima de lo aceptado** (facturas del 2026-09-03; montos declarados en 3 de 3 entregables).
- **Fecha del acta del ambiente de pruebas.** El hito vencía el 2026-07-17 y el acta de recibo es del 2026-10-14, el mismo día del informe de avance. La ficha lo da por cumplido; la distancia entre la fecha del hito y la del acta queda sin explicar en los documentos.

### Abierto
**Riesgos e incidencias sin movimiento:** el informe del 2026-10-14 registra dos riesgos (proveedor sin confirmar la fecha de la última entrega; concentración del conocimiento en una persona) y una incidencia (validación en dos tiendas, desde el 2026-10-14). Todos nacen en ese documento, así que no hay días de antigüedad que medir. Ninguno trae responsable ni fecha de revisión.
**Compromisos vencidos:** ninguno registrado; tampoco hay reuniones leídas, por lo que esto es ausencia de dato y no confirmación de cumplimiento.
**Dependencias sin confirmar:** ninguna registrada. El riesgo del proveedor sin fecha de entrega podría ser una dependencia, pero el documento no dice de quién.

### Sin dato
- `identity.product`, `identity.authority` e `identity.phase`: no aparecen en ningún documento. Sin autoridad definida no se puede decir si los riesgos exceden la del gerente.
- Última reunión, compromisos y actas de comité.
- Evidencia de dos hitos cumplidos y de un entregable aceptado (arriba).
- Los PDF de actas y facturas (CT-778, factura CT-557) no tienen texto extraído en la ficha; los montos facturados provienen de lo registrado en ella.

### Qué sigue
Hay riesgos y desviaciones que justifican el punto de comité (próximo comité: 2026-10-22). Dos cosas se pueden preparar si lo pides: el paquete de comité, con la factura de CT-778 por encima de lo aceptado y el Piloto vencido, y la solicitud de cambio por el atraso del piloto, que hoy no está formalizado.

---
*Criterio Portfolio v0.3.9 · ficha PRY-206 aplicada del 2026-10-15 (datos del gerente al 2026-10-14) · campos inciertos: producto, autoridad, fase, última reunión · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9*
