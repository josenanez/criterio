## Carpeta al 2026-10-15

**Documentos:** 88 · **Sin cambio:** 88 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | pm_record.identity.code | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.name | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.business_area | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.product | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.sponsor | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.manager | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.identity.committee | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.plan.start_date | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.plan.end_date | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.money.currency | 00-gobierno/2025-05-10-acta-constitucion.docx |
| PRY-201 | pm_record.money.approved | 00-gobierno/2025-05-10-acta-constitucion.docx |

Nota: el archivo sí existe en disco (PRY-201-programa-de-fidelización/00-gobierno/2025-05-10-acta-constitucion.docx). No está borrado ni renombrado; el índice no logra resolver la cita. No sé la causa (posiblemente cómo se escribe la ruta con la carpeta del proyecto); hay que revisarla antes de confiar en esos 11 campos.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

Nada que releer: no se ofrece barrido. Corrección de citas por renombrado: no aplica.
