# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 88 documentos, 0 releídos y 88 sin cambio · 227 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Nada movido (no existe entrada/). Nada omitido: 70 de 88 documentos leídos, 18 sin cambio (PRY-203, 204, 206). Mirar: facturas sin acta en PRY-201 (CT-963, CT-978) y PRY-205 (CT-377); compromisos vencidos en PRY-200, 201, 205, 210; reprogramaciones en PRY-201; verde con proyección sobre presupuesto en PRY-208 y 209.

Contra la corrida del 2026-10-15: +52 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

**Términos:** vigentes (versión 1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9

**Documentos:** 88 en la carpeta · 70 leídos · 18 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 200, 201, 202, 205, 207, 208, 209, 210, 211) · 3 sin cambio y sin releer (PRY-203, 204, 206) · 0 sin carpeta propia

Formatos: 50 .md, 13 .pdf, 12 .docx, 6 .xlsx, 5 .csv, 1 .json, 1 .txt. Plan: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`); nada diferido. Se leyeron 70 de 88 documentos.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, fechas, presupuesto, estado declarado, 5 hitos, 1 contrato (3 entregables), 1 compromiso | autoridad, fase, facturado |
| PRY-200 Tienda en línea | 5 | identidad, fechas, presupuesto, estado declarado, 4 hitos, 1 compromiso | autoridad, fase |
| PRY-201 Programa de fidelización | 28 | identidad, fechas, presupuesto, estado declarado, 5 hitos, 2 contratos (6 entregables), 2 facturas, 26 compromisos, `ficha-pm.json` (guardada aparte en `pm_record`) | autoridad, fase |
| PRY-202 Centro de distribución norte | 6 | identidad, fechas, presupuesto, estado declarado, 4 hitos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-205 Pago con QR en caja | 7 | identidad, fechas, presupuesto, estado declarado, 5 hitos, 1 contrato (4 entregables), 1 factura, 1 compromiso | autoridad, fase |
| PRY-207 Marca propia de alimentos | 4 | identidad, fechas, presupuesto, estado declarado, 4 hitos, 1 compromiso | autoridad, fase |
| PRY-208 Domicilios en dos horas | 3 | identidad, fechas, presupuesto, estado declarado, 4 hitos | autoridad, fase |
| PRY-209 Migración del ERP | 4 | identidad, fechas, presupuesto, estado declarado, 4 hitos | producto («No aplica»), autoridad, fase |
| PRY-210 Etiquetas electrónicas de precio | 5 | identidad, fechas, presupuesto, estado declarado, 4 hitos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Pronóstico de demanda | 2 | identidad, fechas, presupuesto, estado declarado | producto («No aplica»), autoridad, fase, cronograma e hitos (no hay cronograma), reuniones (no hay actas de comité) |

La autoridad del gerente y la fase no aparecen en ningún documento de ningún proyecto leído.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| (ninguno) | Todas las fichas leídas son nuevas en el estado del portafolio; PRY-203, 204 y 206 no cambiaron y no se abrieron. | plan de lectura |

### Lo que vi al leer (el cálculo de señales lo hace el código; esto es lectura, con su fuente)
- **Facturado sin acta que lo respalde.** PRY-201, CT-978: factura FV-2978 por 966.093.580 COP (2026-09-17) cubre dos entregables, pero solo hay acta de recibo de uno (Bolsa de horas, 2026-06-20); el Licenciamiento figura «recibido» en el contrato sin acta. PRY-201, CT-963: factura FV-1963 por 921.509.752 COP (2026-09-03) contra dos entregables con acta (2 × 343.904.432 = 687.808.864); Licenciamiento y Bolsa de horas siguen «en curso» con fechas de 2025-09-10 y 2026-01-01. PRY-205, CT-377: factura FV-1377 por 247.703.694 COP (2026-08-29) y ningún entregable del contrato aceptado ni con acta.
- **Hitos declarados cerrados sin acta que los pruebe.** PRY-201 (Ambiente de pruebas, Integración con el ERP), PRY-199 (ninguno: su único hito cerrado tiene acta), PRY-200 (Diseño de la experiencia), PRY-202 (Integración con el ERP, Piloto en tiendas), PRY-205 (Diseño, Integración con el ERP, Piloto en tiendas), PRY-207 (Diseño, Ambiente de pruebas), PRY-208 (los cuatro), PRY-209 (Ambiente de pruebas), PRY-211 (no hay cronograma). Las actas existentes son posteriores en semanas o meses a la fecha del hito (p. ej. PRY-201 Diseño: línea base 2025-08-30, acta 2026-10-11).
- **Verde declarado frente a la evidencia.** PRY-208 declara verde con 81 % y cierre comprometido el 2026-02-28 (ya pasado), y proyecta 8.103.742.416 COP contra 6.800.000.000 aprobados. PRY-209 declara verde con proyección de 8.271.586.540 contra 6.800.000.000 y con el hito «Integración con el ERP» (línea base 2026-10-03) sin cerrar. PRY-202 declara rojo y su fecha de cierre (2026-09-09) ya pasó. PRY-199 declara verde y su propio informe lista un hallazgo de seguridad y una prueba de carga que no alcanzó el umbral.
- **Ejecutado mayor que comprometido.** PRY-201 (1.750.850.713 vs 1.368.780.814, informe del 2026-09-27) y PRY-202 (1.299.157.774 vs 1.118.711.556, informe del 2026-10-03).
- **Compromisos vencidos sin evidencia (al 2026-10-15).** PRY-201: Mauricio Pérez «Validar el ambiente 12» (2026-10-14, dijo el 09-24 que ya lo entregó, sin acta), Óscar Ramírez «Aprobar el diseño 13» (2026-10-09), Jorge Medina «Actualizar la matriz 14» (2026-10-12), Javier Hoyos «Cerrar la prueba 18» (2026-10-11). PRY-200: Gustavo Neira «Entregar el punto 21» (2026-10-14). PRY-205: Sandra Gil «Entregar el punto 37» (fecha 2026-10-01, anterior a la reunión del 10-04 que la registra). PRY-210: María Restrepo «Entregar el punto 3» (2026-10-11, anterior a la reunión del 10-12).
- **Compromisos reprogramados reunión tras reunión (PRY-201).** Paula Céspedes «Enviar el documento 1»: 2026-09-23 → 10-02 → 10-23 → 11-10 → 11-24 → 12-03 → 12-17 (seis reprogramaciones, última en las notas del 10-15). Sandra Gil «Cerrar la prueba 2»: cinco reprogramaciones, hasta 2026-12-03. Laura Vélez «Aprobar el diseño 5»: tres, hasta 2026-11-06. Ricardo Salas «Revisar el anexo 3» estuvo «por definir» en tres comités.
- **Riesgo dicho y no registrado (PRY-201).** Notas del 2026-10-15: el proveedor podría no llegar con el equipo completo para la siguiente fase; «nadie lo anotó como riesgo». Quedó levantado en la ficha, sin probabilidad, impacto ni responsable.
- **Compromisos sin fecha (PRY-201, PRY-202).** Laura Vélez «Mandar el ajuste del presupuesto» («la otra semana»); Ricardo Salas «Entregar el punto 37» (PRY-202, «por definir»).
- **Ficha del gerente.** PRY-201 publica `ficha-pm.json`. Se guardó entera en `pm_record`, sin fusionarla con la lectura de la PMO; el contraste lo emite el código.
- **Asistencia.** En PRY-201, el patrocinador (Felipe Arango) no figura entre los asistentes del 10-01, 10-08 ni de las notas del 10-15. No es un cambio de gobierno documentado: ningún documento nombra a otra persona en el rol.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | 0 ilegibles de 88. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` en `documentos/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

Nota: `2026-10-15-notas-reunion.txt` está en la raíz de la carpeta PRY-201 y no en `30-reuniones/`; se asignó a PRY-201 por su contenido y por su carpeta, y no se movió.

---
Criterio Portfolio 0.3.9 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 205, 207, 208, 209, 210, 211) · campos en `not_found`: autoridad y fase en las 10; producto en PRY-202, 209, 210 y 211; facturado en PRY-199; cronograma/hitos en PRY-211 · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
