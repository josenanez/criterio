# Corrida del 2026-10-15 · project-charter

13 proyectos · 24 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Revisión del acta PRY-203 (2025-09-19): falta autoridad del gerente, supuestos, restricciones, hitos, medidor del éxito y cadencia; objetivo y alcance no medibles. No supe qué se acordó fuera del acta y el informe del 2026-10-14.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Hay acta previa: `00-gobierno/2025-09-19-acta-constitucion.md`, del 2025-09-19 (aprobada por el Comité de Expansión). Modo revisar. Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-15, versión 0.3.9).

## Acta — PRY-203 Reposición automática
**Estado:** existe, del 2025-09-19

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente** (no hay monto ni tipo de cambio decidible sin comité) | Laura Vélez no tiene un límite escrito. Hoy el proyecto proyecta 6.986.277.909 COP contra 6.800.000.000 aprobados (+186.277.909, +2,7 %), y nada dice si ese sobrecosto, o un cambio de alcance para repetir la prueba de carga o corregir el hallazgo de seguridad, lo decide ella o sube al comité. Por defecto todo sube al Comité de Expansión. |
| Objetivo de negocio medible | **Insuficiente**: "Entregar reposición automática para Servicio al cliente" describe la solución, no el resultado de negocio | No hay un resultado contra el cual juzgar si el proyecto valió la pena; solo se podrá decir "se entregó" o "no". |
| Alcance | **Vacío en la práctica**: "Componente 1, 2 y 3" sin definirlos | No se puede verificar qué entra ni detectar crecimiento de alcance; un cambio de alcance no tiene contra qué compararse. |
| Exclusiones | **Declaradas sin contenido**: "Lo que otro proyecto cubre" | No nombra ningún proyecto; al no haber dependencias declaradas, si hay traslape con otro proyecto del portafolio nadie lo ve. |
| Patrocinador / gerente | Completo: Camilo Beltrán / Laura Vélez | — |
| Comité y cadencia | Comité de Expansión indicado; **cadencia no declarada** | No se sabe cada cuánto debe reportar ni cuándo escalar. |
| Supuestos y restricciones | **Ausentes** | Sin supuestos declarados, ninguno se puede verificar ni pasar a riesgo. Ya hay un riesgo abierto de congelamiento en temporada alta que, de ser una restricción conocida, debió estar en el acta. |
| Criterio de éxito | **Parcial**: "Reposición automática en producción y medido", sin umbral ni medidor | "Medido" no dice qué cifra ni quién la mide; el cierre se discutirá por opinión. |
| Quién mide el éxito | **Ausente** | Nadie responde por declarar el éxito. |
| Hitos principales | **Ausentes** (solo inicio 2025-09-29 y cierre 2026-08-25) | No hay puntos intermedios para detectar atraso antes del cierre. |
| Dependencias | "Ninguna declarada" | El informe de avance menciona un proveedor que no ha confirmado su última entrega: es una dependencia externa que el acta no recoge. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar reposición automática para Servicio al cliente" (solución, no resultado medible).
**Alcance:** Componente 1, 2 y 3 (sin detalle). Fuente: acta, 2025-09-19.
**Exclusiones:** "Lo que otro proyecto cubre" (sin nombrar proyecto). Fuente: acta.
**Patrocinador:** Camilo Beltrán · **Gerente:** Laura Vélez. Fuente: acta.
**Autoridad del gerente:** pendiente de definir.
**Comité al que reporta:** Comité de Expansión (fuente: acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Reposición automática en producción y medido" (fuente: acta; sin umbral) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Fechas del acta: inicio 2025-09-29, cierre 2026-08-25.
**Presupuesto aprobado:** 6.800.000.000 COP, Comité de Expansión, 2025-09-19.

### Observaciones fuera del acta (para el comité)
- La fecha de cierre del acta (2026-08-25) ya pasó hace 51 días y no hay línea base nueva registrada: solo existe la versión 1. El informe del 2026-10-14 declara rojo y 50 % de avance.
- La ficha tiene el campo "producto" y "autoridad" sin encontrar; el acta dice "Producto asociado: No aplica".

### Qué no sé
No sé qué se acordó fuera de estos dos documentos (el acta y el informe del 2026-10-14). No hay minutas ni cambios aprobados en la carpeta; si existen, no los vi.

### Después
- El acta quedó sin autoridad declarada: ofrezco llevar esa definición al Comité de Expansión (próximo comité: 2026-10-22). Es una decisión, no un trámite.
- De la revisión salen dos supuestos implícitos a registrar en RAID: que no existe dependencia externa (contradicho por el proveedor sin fecha) y que no hay congelamiento de temporada. Ofrezco pasarlos al registro RAID.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato cita su documento; la verificación es suya.*
