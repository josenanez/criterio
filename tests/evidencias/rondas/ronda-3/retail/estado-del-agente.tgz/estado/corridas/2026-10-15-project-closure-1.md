# Corrida del 2026-10-15 · project-closure

13 proyectos · 41 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Acta de cierre de PRY-202 sin cierre declarado: criterio de éxito (en producción y medido) no verificable; 2 de 4 hitos sin acta de recibo; fecha de cierre acta 2026-09-09 vs cronograma 2026-08-05; 0 lecciones sustentables; no se ofreció archivar.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Sale de:** ficha `estado/records/PRY-202.json`, salida de `portafolio.py compute` (as_of 2026-10-15) y los seis documentos de `PRY-202-centro-de-distribución-norte/`: acta de constitución (2025-10-26), cronograma v1 (2025-10-26), actas de recibo (2026-10-02 y 2026-10-13), informe de avance (2026-10-03) y comité (2026-10-12).

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que volver a registrarlos.*

## Cierre — PRY-202 Centro de distribución norte — 2026-10-15

**Antes de nada:** nadie ha declarado que este proyecto terminó. Su último informe (2026-10-03) lo reporta en **rojo, 27 % de avance**, con un hallazgo de seguridad abierto. Lo que sigue es lo que un cierre hoy podría afirmar con la evidencia que hay, no un cierre firmado.

### Contra lo comprometido
**Criterio de éxito:** «Centro de distribución norte en producción y medido.» (acta de constitución, 2025-10-26)
**Se cumplió:** **no se puede determinar.** Ningún documento muestra puesta en producción ni medición. El piloto en tiendas figura como cumplido sin acta de recibo, y el informe de avance no menciona ni producción ni mediciones.

| Entregable comprometido (hito) | Fecha línea base | Estado | Evidencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-01-12 | Cumplido | Acta de recibo del 2026-10-13 (Laura Vélez) |
| Ambiente de pruebas certificado | 2026-03-21 | Cumplido | Acta de recibo del 2026-10-02 (Laura Vélez) |
| Integración con el ERP | 2026-05-29 | Declarado cumplido | **Sin acta de recibo.** Señal `milestone_met_without_evidence`, 139 días |
| Piloto en tiendas | 2026-08-05 | Declarado cumplido | **Sin acta de recibo.** Señal `milestone_met_without_evidence`, 71 días |

Los cuatro hitos aparecen como cerrados en el cronograma, pero solo dos tienen acta, y esas dos están fechadas en octubre de 2026, mucho después de las fechas del plan. El cronograma (con sus cuatro hitos «cerrados») es del 2025-10-26: cualquier estado ahí es declarado, no medido. Con cuatro de cuatro hitos «cumplidos», el plan respaldaría 100 % de avance; el gerente declara 27 %. La brecha es de **73 puntos** (señal `progress_vs_plan`). Alguno de los dos números está mal, y los documentos no dicen cuál.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre» (acta; sin detalle de cuál proyecto) | Comité de Arquitectura, en la aprobación inicial | 2025-10-26 |

No hay solicitudes de cambio ni recortes de alcance registrados (0 cambios). El alcance de origen tampoco tiene detalle: «Componente 1, 2 y 3». No se puede contrastar entregado contra comprometido por componente, porque el acta no dice qué es cada uno.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-05 (cronograma v1) | 2026-08-05 | **No hay cierre declarado** | 0 días contra el plan; ver nota |
| Presupuesto (COP) | 3.300.000.000 | 3.300.000.000 | Proyección al cierre 3.372.805.853 | +2,2 % sobre el aprobado (proyección) |

Replanificaciones: **0**.

Presupuesto, según el informe del 2026-10-03: comprometido 1.118.711.556; ejecutado 1.299.157.774 (39,4 % del aprobado); disponible real 2.181.288.444. Ojo con una incoherencia: lo ejecutado supera a lo comprometido, y eso es lo contrario de lo esperable.

Notas:
- **La fecha de cierre tiene dos versiones.** El acta dice cierre **2026-09-09**; el cronograma v1 y la ficha usan **2026-08-05**. La ficha no la registró como conflicto. Con ambas fechas ya vencidas y el proyecto en 27 % declarado, el «0 días de desviación» sale de que nadie replanificó, no de que se haya cumplido.
- La proyección de 3.372.805.853 es la que declara el gerente; ningún documento la respalda con detalle.

### RAID al cierre
**Materializados:** el hallazgo de seguridad en los medios de pago (incidencia abierta desde 2026-10-03). No hay constancia de que se haya resuelto.
**No materializados:** ninguno se puede afirmar.
**Abiertos, con doliente:**
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega. Informe de avance, sin doliente nombrado. Aparece además sin proveedor ni contrato en la ficha (0 proveedores registrados).
- Incidencia: hallazgo de seguridad en medios de pago. Sin doliente nombrado ni fecha de resolución.
- Compromiso: «Entregar el punto 37», **Ricardo Salas**, comité del 2026-10-12, fecha «por definir» (señal `commitment_undated`). Tiene responsable, no fecha, y el documento no dice qué es el «punto 37».

Lo abierto sin doliente con nombre **no está cerrado**: hoy hay dos ítems así.

### Lecciones
No se registra ninguna. Ninguna se puede anclar a un hecho con fecha y efecto en estos documentos sin inventar el contenido. Dos hechos sí están documentados, y a una persona le toca decidir qué lección sacar de ellos:
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Las actas de recibo de dos hitos se firmaron el 2026-10-13 (hito del 2026-01-12) y el 2026-10-02 (hito del 2026-03-21) | Octubre 2026 | Los hitos figuran cerrados en el cronograma sin respaldo hasta esas fechas; los otros dos siguen sin acta | A definir por el equipo |
| Fecha de cierre distinta entre acta (2026-09-09) y cronograma (2026-08-05) | Desde 2025-10-26 | El proyecto no tiene una fecha de cierre única contra la cual medirse | A definir por el equipo |

### Sin dato
- Si el centro de distribución está en producción y se midió (el criterio de éxito mismo).
- Acta de recibo de «Integración con el ERP» y de «Piloto en tiendas».
- Cuál de las dos cifras es correcta: 27 % declarado o 4 de 4 hitos del plan.
- Qué son los «componentes 1, 2 y 3» y qué proyecto cubre lo excluido.
- Qué es el «punto 37» y para cuándo.
- Estado actual del hallazgo de seguridad y del proveedor.
- Producto asociado («No aplica» en el acta), autoridad y fase.
- Ficha con datos de identidad y plan de 12 meses de antigüedad (acta del 2025-10-26).

### Después
No ofrezco mover la carpeta a `archivo/` ni congelar la ficha: sin cierre declarado y con el criterio de éxito sin verificar, el proyecto debe seguir en el barrido diario. Si el comité decide cerrarlo igual, sería **un cierre por decisión, no por cumplimiento**, y así debe quedar escrito.

---
**Pie de rigor:** documentos leídos: 6, todos de la carpeta del proyecto. Las cifras derivadas (73 puntos, 139 y 71 días, 39,4 %, 2,2 %, 2.181.288.444) vienen de `portafolio.py compute`. No leí nada fuera de esos documentos, ni lo hablado fuera de ellos. Verificación por la persona responsable.
