**Fichas cargadas:** 13 proyectos (PRY-199 a PRY-211), corte 2026-10-15, recalculadas con `portafolio.py compute`. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-15). Respuestas sugeridas tomadas sin consulta (sesión sin interfaz).

# Comité de proyectos — 2026-10-22 (próximo comité configurado)
4 decisiones · 3 escalamientos sin decisión asociada · 10 de 13 proyectos con hallazgos (61 señales; 7 informes en verde contradichos por la evidencia)

## Decisiones del comité anterior
No hay registro de un comité anterior en `estado/` (ni decisiones registradas, ni solicitudes de cambio: 0 en los 13 proyectos). No se puede cerrar el ciclo previo; este paquete parte sin él.

## Decisiones de hoy

### [1] ¿Quién es la autoridad que aprueba en cada uno de los 13 proyectos?
**Proyecto:** todos · **Quién decide:** patrocinador del portafolio / PMO (no consta) · **Si no se decide hoy:** los puntos 2 a 4 no tienen a quién dirigirse y se devolverían.
`identity.authority` está vacío en los 13 proyectos; ningún documento leído dice quién aprueba cambios de costo, tiempo o pagos.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar una autoridad por proyecto y registrarla en el acta | Sin cambio | Una sesión | Sin efecto |
| B. Una sola autoridad para el portafolio (el comité) | Sin cambio | Inmediato, cuello de botella | Sin efecto |
**Recomendación:** A. Los puntos 2 a 4 requieren facultad de pago y de línea base; sin dueño nombrado, el comité decide sobre un vacío.

### [2] ¿Se aprueba un cambio de costo (o se exige plan de contención) en PRY-208 y PRY-209?
**Proyecto:** PRY-208 Domicilios en dos horas; PRY-209 Migración del ERP · **Quién decide:** sin autoridad registrada (ver [1]) · **Si no se decide hoy:** ambos siguen en verde declarado con proyección por encima del umbral de 10 %.
- PRY-208: aprobado 6.800.000.000 COP, proyección 8.103.742.416 (+19,2 %). Fin planeado 2026-01-28 (vencido). Declara 81 %.
- PRY-209: aprobado 6.800.000.000 COP, proyección 8.271.586.540 (+21,6 %). Hito «Integración con el ERP» vencido hace 12 días.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar el aumento y fijar nueva línea base | No consta | No consta | +19,2 % / +21,6 % sobre lo aprobado |
| B. Mantener presupuesto y recortar alcance | Recorte, sin cuantificar en los documentos | No consta | 0 % |
| C. Pedir plan de contención al gerente antes de decidir | Sin cambio | Una sesión más | Se sigue ejecutando |
**Recomendación:** C. Ninguno de los dos proyectos tiene solicitud de cambio ni cuantificado el efecto en alcance/tiempo; faltan datos para elegir A o B.

### [3] ¿Se retienen los pagos a Tecnología para Tiendas Ltda. (PRY-201 y PRY-205) hasta conciliar lo facturado con lo aceptado?
**Proyecto:** PRY-201, PRY-205 (mismo proveedor) · **Quién decide:** sin autoridad registrada (ver [1]) · **Si no se decide hoy:** siguen aprobándose facturas sin aceptación que las respalde.
- PRY-201: facturado 921.509.752 vs aceptado 687.808.864 → diferencia 233.700.888 COP. Dos entregables pendientes vencidos (400 y 287 días).
- PRY-205: facturado 247.703.694 sobre 4 entregables, ninguno aceptado; 4 entregables vencidos.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos y exigir actas de recibo | Sin cambio | Puede frenar al proveedor | Evita pagar lo no entregado |
| B. Seguir pagando y conciliar al cierre | Sin cambio | Sin efecto | Riesgo de 233.700.888 + 247.703.694 COP sin soporte |
**Recomendación:** A. Los montos facturados exceden lo aceptado en los documentos; afecta a dos proyectos, por eso excede al gerente de cada uno.

### [4] ¿Qué fecha de fin rige en PRY-201 y qué estado se reconoce?
**Proyecto:** PRY-201 Programa de fidelización · **Quién decide:** sin autoridad registrada (ver [1]) · **Si no se decide hoy:** la PMO y el gerente siguen midiendo contra fechas distintas.
La PMO lee fin 2026-10-16 (cronograma v1); el gerente, 2026-12-07 (acta). Declara verde y 39 %; el plan sostiene 80–100 %: 41 puntos de diferencia. 3 compromisos rescalonados 3 a 6 veces.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar 2026-10-16 y reportar atraso | Sin cambio | Atraso inmediato | Proyección 4.226.425.039 vs 4.200.000.000 (+0,6 %) |
| B. Fijar 2026-12-07 por solicitud de cambio formal | Sin cambio | +52 días respecto a 2026-10-16 | Igual |
**Recomendación:** B solo si el gerente presenta la solicitud de cambio con su soporte; hoy no existe. Mientras tanto, A.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-206 | Piloto en tiendas vencido (11 días); proveedor Logística del Valle facturó 1.406.566.924 vs aceptado 1.149.477.566 (dif. 257.089.358) | Hito 2026-10-04 | Conciliación igual a la del punto 3 |
| PRY-205 | Compromiso de Sandra Gil vencido 14 días; declara verde con 43 puntos de brecha | 2026-10-01 | Evidencia o corrección del estado |
| PRY-210 | Declara 81 % cuando el plan sostiene 25–50 % (adelantado, 31 puntos): dato inverosímil | 2026-10-12 | Verificación del avance real |

## Para conocimiento
- PRY-199, PRY-203, PRY-211: sin señales.
- PRY-200: verde contradicho (hito sin evidencia, compromiso vencido 1 día).
- PRY-202: declara 27 %, plan sostiene 100 %; 2 hitos sin evidencia.
- PRY-204: hito sin evidencia; 1 compromiso sin fecha.
- PRY-207: verde contradicho por un hito sin evidencia; 7 días en silencio.

## Anexo
- Estado por proyecto: ver `estado/records/` y la salida de `compute` (61 señales, 13 proyectos, 10 con alertas, 7 verdes contradichos, 0 sin línea base, 13 sin autoridad).
- Contradicciones abiertas: PRY-201 fin PMO vs PM (punto 4).
- Vacíos: `identity.authority` e `identity.phase` faltan en los 13; `identity.product` falta en PRY-202, 203, 206, 209, 210, 211; no hay solicitudes de cambio ni comité previo registrado; dependencias entre proyectos: ninguna registrada (el vínculo por proveedor lo detecté yo al cruzar nombres, no consta en documento).
- No sé: efecto en alcance y tiempo de las opciones de los puntos 2 y 3; si existe un comité anterior fuera de la carpeta.

---
Versión criterio-portfolio 0.3.9 · Términos v1.1 · Fichas aplicadas: 13 · Campos inciertos: autoridad, fase, producto (ver anexo) · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
