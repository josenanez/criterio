# Corrida del 2026-10-15 · health-check

13 proyectos · 67 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico desde cero de PRY-205 sobre 7 documentos: 3 sostenidas, 7 sin sustento, 4 contradichas. Estado verde contradicho por 5 señales; cierre 2026-12-03 (cronograma) vs 2027-01-16 (acta) sin resolver; factura FV-1377 sin acta de recibo del entregable. Dijo que no sabe: autoridad del gerente, origen de las cifras de dinero, qué es el punto 37.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-205 Pago con QR en caja · 2026-10-15

**Términos:** vigentes (v1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`.
**Leí:** 7 documentos · del 2025-09-07 al 2026-10-14 · formatos: docx (3), md (3), csv (1)
**No pude leer:** ninguno. Busqué «PRY-205» y «QR» en el resto de la carpeta de proyectos: ninguna minuta de otro proyecto lo menciona.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 4 (14 afirmaciones examinadas)

Desde esta carpeta se pueden afirmar el gobierno nominal (patrocinador, gerente, comité), el presupuesto aprobado y un único recibo: el del hito «Ambiente de pruebas certificado». No se puede afirmar que el proyecto esté en verde: el informe del 2026-10-14 lo declara verde con 37% de avance, y `compute` encuentra cinco señales abiertas que ese informe no explica (compromiso vencido, hitos cerrados sin evidencia, avance contra plan, entregables del proveedor vencidos y factura sin entrega). Ninguna cifra de dinero tiene fuente distinta del propio informe de avance.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | María Restrepo | Acta de constitución, 2025-09-15 |
| Gerente | Óscar Ramírez | Acta de constitución, 2025-09-15 |
| Autoridad declarada | **No está declarada.** El acta no dice qué puede aprobar el gerente sin pasar por el comité | Acta de constitución |
| Comité | Comité de Transformación Digital; aprobó el presupuesto el 2025-09-15 | Acta de constitución |

Sin autoridad declarada, ninguna fecha vigente es una desviación aprobada: es una fecha que alguien escribió. Aquí no hay cambios registrados, así que no hay nada que aprobar ni que desaprobar.

### Contra el plan
- **Línea base original (v1, 2025-09-15):** cierre 2026-12-03, según `10-plan/2025-09-15-cronograma-v1.csv`. Aprobación inicial por el comité (acta).
- **Línea base vigente:** igual a la original. 0 replanificaciones; 0 días de desviación contra la original y contra la vigente (salida de `compute`).
- **Contradicción de fechas:** el acta de constitución (2025-09-15) fija el cierre en **2027-01-16**; el cronograma v1 (misma fecha) lo fija en **2026-12-03**. Ningún documento dice cuál rige ni por qué difieren. La desviación de 0 días solo vale si el 2026-12-03 es la línea base, y eso no está establecido.
- **Avance contra plan:** declarado 37%; el cronograma marca 4 de 5 hitos cerrados, lo que sostiene entre 80% y 100%. Brecha de 43,0 puntos (`compute`). Una de las dos fuentes está mal, y el informe es la que no tiene respaldo.

### Hitos vencidos sin evidencia
Ningún hito aparece vencido y abierto. El problema es el contrario: tres hitos marcados «cerrado» no tienen documento que lo pruebe.

| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-12-20 | 299 | Acta de aprobación del diseño firmada por el patrocinador o el comité |
| Integración con el ERP | 2026-06-12 | 125 | Acta de pruebas de integración o de aceptación técnica |
| Piloto en tiendas | 2026-09-07 | 38 | Informe del piloto con tiendas y resultados |

«Ambiente de pruebas certificado» (2026-03-17) sí tiene acta de recibo, firmada por Óscar Ramírez el 2026-10-03, fecha posterior a la del hito. El quinto hito del cronograma, «Despliegue en la cadena» (2026-12-03), sigue en curso, sin evidencia que lo contradiga.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 COP | 3.065.681.148 COP (73,0%) | 2.002.590.000 COP (47,7%) | 3.958.059.174 COP (−5,8% frente a lo aprobado) | 1.134.318.852 COP |

- Aprobado: sostenido por el acta. Comprometido, ejecutado y proyección: solo aparecen en el informe de avance, sin libro de contabilidad ni extracto que los respalde.
- Comprometido por encima del umbral de 90%: no. Proyección sobre lo aprobado: no.
- El ejecutado (47,7%) es mayor que el avance declarado (37%). El documento no explica la diferencia.

### Proveedor · CT-377 · Tecnología para Tiendas Ltda.
El contrato (2025-09-07) establece: «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto».

| Entregable | Fecha comprometida | Días de atraso | Monto COP | Estado | Acta de recibo |
|---|---|---|---|---|---|
| Licenciamiento de la plataforma | 2025-12-29 | 290 | 247.703.694 | pendiente | no hay |
| Bolsa de horas de desarrollo | 2026-04-04 | 194 | 247.703.694 | pendiente (el contrato decía «en curso») | no hay |
| Configuración del catálogo | 2026-07-08 | 99 | 247.703.694 | pendiente | no hay |
| Soporte del primer trimestre | 2026-10-12 | 3 | 247.703.694 | pendiente | no hay |

- **Facturado:** 247.703.694 COP, factura FV-1377 del 2026-08-29, «Entregables del contrato CT-377», radicada en cuentas por pagar. Aceptado con acta: 0 entregables. La factura no dice a qué entregable corresponde, y es anterior a la única acta de recibo de la carpeta (2026-10-03), que además es de un hito del proyecto y no de un entregable del contrato.
- El valor facturado equivale al monto de un entregable. Qué entregable, no se sabe.

### Lo que se dijo y nadie registró
- **Compromiso:** Sandra Gil debía «entregar el punto 37» el 2026-10-01 (comité del 2026-10-04). Vencido hace 14 días, sin evidencia. La fecha es anterior a la reunión que lo registra, Sandra Gil no figura entre los asistentes (Óscar Ramírez, María Restrepo) y «el punto 37» no se define en ningún documento.
- **Riesgo que el informe nombra y ningún registro tiene:** el proveedor no ha confirmado la fecha de la última entrega (compatible con los entregables vencidos), y la concentración del conocimiento en una persona. No hay registro RAID; el acta dice «ninguna dependencia declarada» aunque el proyecto depende de un proveedor con cuatro entregables y de una integración con el ERP.
- **Acta del comité del 2026-10-04:** lista «Avance» y «Compromisos» como temas, sin contenido. No registra ninguna decisión ni acuerdo sobre el estado.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe de avance 2026-10-14: «Verde» | `compute`: 5 señales abiertas sin explicar (compromiso vencido, hitos sin evidencia, avance contra plan, entregables vencidos, factura sin entrega) |
| Avance de 37% | Informe de avance 2026-10-14 | Cronograma v1: 4 de 5 hitos «cerrado» (sostiene 80%–100%) |
| La factura FV-1377 corresponde a entregables del CT-377 | Factura 2026-08-29 | Contrato CT-377 (se factura contra acta de recibo) y carpeta (0 actas de recibo de entregables) |
| Fecha de cierre | Acta de constitución: 2027-01-16 | Cronograma v1: 2026-12-03 |

### Sin sustento
Lo que ningún documento respalda ni contradice:
- Hitos «Diseño de la experiencia aprobado», «Integración con el ERP» y «Piloto en tiendas» como cerrados.
- Comprometido, ejecutado y proyección al cierre (solo el informe).
- Los dos riesgos abiertos del informe (no hay registro RAID).
- El compromiso de Sandra Gil: existe, pero está vencido y sin entrega documentada.
- Lo reportado «en el periodo»: concepto de Jurídica sobre términos de uso y acuerdo con arquitectura sobre requisitos no funcionales. No hay documento de ninguno de los dos.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en verde.** Falta evidencia de tres hitos cerrados; sin ella no se puede decir ni que va bien ni que va mal.
- **Cuál es la fecha de cierre real.** Hay dos, 2026-12-03 y 2027-01-16; la desviación solo se mide contra una de ellas.
- **Si la factura de 247.703.694 COP debió pagarse.** Faltan el acta de recibo del entregable al que corresponde, o la confirmación de que no hay tal entregable.
- **Qué puede aprobar el gerente por su cuenta.** No hay autoridad declarada; si el cierre se mueve, no se sabe quién lo aprueba.
- **De dónde salen las cifras de dinero.** Sin libro de contabilidad, no se puede comprobar que el ejecutado sea el que dice el informe.
- **Qué es «el punto 37»** y si Sandra Gil pertenece al proyecto.
- **Quién guarda el conocimiento del proyecto**, que el propio informe reconoce concentrado.

### Cómo sigue
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo llevar las cuatro contradicciones al gerente como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.

---
**Pie de rigor:** 7 documentos leídos, ninguno ilegible. Cifras derivadas copiadas de `compute` (as_of 2026-10-15). Las conclusiones sobre el proyecto valen solo para lo que dice la carpeta; lo hablado fuera de ella no lo vi. La verificación de las citas es de quien lo lea.
