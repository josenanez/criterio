# Corrida del 2026-10-15 · project-history

13 proyectos · 110 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 7 |
| `vendor_deliverable_late` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `milestone_overdue` | 2 |
| `variance_cost` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Historia de PRY-201 sobre 28 documentos (2025-05-04 a 2026-10-15): 0 replanificaciones escritas, 0 cambios de gobierno, 3 trimestres sin documentos, 22 de 28 documentos desde 2026-08-22. Verde 2026-09-27 (39%) vs plan 80-100%. Dijo que no sabe: por qué no hay documentos 2025-05 a 2026-05, cierre válido (2026-12-07 vs 2026-10-16), quién editó cronograma y contratos, meses declarando sin sustento (una sola declaración).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Historia · PRY-201 Programa de fidelización · 2025-05-04 a 2026-10-15

**Leí:** 28 documentos entre 2025-05-04 y 2026-10-15 (texto en caché; las citas apuntan a los originales). Términos vigentes (v1.1, José Francisco Ñáñez, 2026-10-15): no hizo falta registrarlos de nuevo.
**Trimestres sin un solo documento:** 2025-T3, 2025-T4 y 2026-T1. Entre el 2025-05-14 y el 2026-05-09 no hay nada. De los 28, 22 son del 2026-08-22 en adelante; el primer acta de comité es del 2026-09-03.

### En una línea
El proyecto se aprobó el 2025-05-10 con cierre el 2026-12-07 (el cronograma dice 2026-10-16) y de los 28 documentos, 22 son de las últimas semanas (desde el 2026-08-22). En ese tramo aparecen un verde declarado (2026-09-27) sobre 39% de avance, facturas por encima de lo aceptado, hitos "cerrados" sin acta y tres compromisos que se corren cada semana. No hay una sola replanificación escrita: las fechas de la línea base nunca se movieron, aunque las actas de recibo de dos hitos llevan fechas posteriores a esa línea base.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 0 documentadas | 0 días según el cálculo, porque la línea base nunca se movió (no quiere decir que no haya atraso) | No calculable: en la carpeta hay una sola declaración de estado (2026-09-27) | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-05-04 | Contrato CT-963 (Tecnología para Tiendas) | 4 entregables de 343.904.432 COP; el primero vence el 2025-09-10. Se factura contra acta de recibo firmada por la gerente. |
| 2025-05-10 | Acta de constitución | Presupuesto 4.200.000.000 COP; inicio 2025-05-20, cierre 2026-12-07. Patrocinador Felipe Arango, gerente Diana Molina, Comité Comercial. Alcance "Componente 1/2/3"; sin autoridad declarada. |
| 2025-05-10 | Cronograma v1 | 5 hitos con fecha de línea base igual a la vigente; despliegue 2026-10-16. **El contenido es posterior al nombre:** marca 4 hitos "cerrado", y el último acta de esos hitos es del 2026-10-11. |
| 2025-05-14 | Contrato CT-978 (Datos y Demanda) | 2 entregables de 483.046.790 COP (vencen 2025-11-24 y 2026-06-01). Lo mismo: figuran "recibido" en un contrato fechado en 2025. |
| 2025-05-14 a 2026-05-08 | — | Sin documentos. |
| 2026-05-09 | Acta de recibo, catálogo (CT-963) | Recibido; vencía el 2026-04-24. |
| 2026-06-20 | Acta de recibo, bolsa de horas (CT-978) | Recibido; vencía el 2026-06-01. |
| 2026-08-22 | Acta de recibo, soporte 1.er trimestre (CT-963) | Recibido; vencía el 2026-08-15. |
| 2026-09-03 | Comité semanal | Primer acta de comité en la carpeta: 4 compromisos, 5 asistentes. |
| 2026-09-03 | Factura FV-1963 (CT-963) | 921.509.752 COP "entregables del contrato", radicada en cuentas por pagar. |
| 2026-09-10 | Comité + acta de recibo 4 | Paula Céspedes mueve "documento 1" a 2026-10-02; Sandra Gil mueve "prueba 2" a 2026-10-01. |
| 2026-09-17 | Comité, acta 8, factura FV-2978 (CT-978) | 966.093.580 COP radicada. 10 asistentes. |
| 2026-09-24 | Comité + acta 11 | Óscar Ramírez y Mauricio Pérez dicen que ya entregaron; no hay acta. |
| 2026-09-27 | Informe de avance (PDF) | Verde, 39%; ejecutado 1.750.850.713 COP, comprometido 1.368.780.814 COP. Pérdida de dos semanas por rotación de un desarrollador. Un solo riesgo abierto. |
| 2026-10-01 | Comité | 13 asistentes, 15 compromisos. |
| 2026-10-03 | Acta de recibo, piloto en tiendas | Vencía el 2026-07-05. |
| 2026-10-08 | Comité + actas 6, 7, 15, 16, 20 | 5 compromisos cerrados con acta. |
| 2026-10-11 | Acta de recibo, diseño de la experiencia | Vencía el 2025-08-30. Es el primer hito del cronograma y su acta es posterior a la del piloto. |
| 2026-10-15 | Notas de reunión | Paula Céspedes mueve "documento 1" al 2026-12-17; Laura Vélez sin fecha; se comentó un riesgo del proveedor que nadie anotó. |
| 2026-10-15 | ficha-pm.json | La gerencia publica su ficha sin estado ni avance declarados. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| — | — | — | — | — |

Ninguna. Sin embargo: (a) el acta de recibo del diseño (2026-10-11) y la del piloto (2026-10-03) son posteriores a sus fechas de línea base (2025-08-30 y 2026-07-05), que siguen sin moverse; (b) el informe del 2026-09-27 cuenta dos semanas perdidas y el cronograma no cambió; (c) el cierre vale 2026-12-07 en el acta y 2026-10-16 en el cronograma, ambos del 2025-05-10, y ningún documento dice cuál rige. No hay solicitud de cambio, así que ninguna de estas tres tiene motivo documentado.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Nada: patrocinador (Felipe Arango), gerente (Diana Molina) y comité (Comité Comercial) son los mismos en el acta y en las minutas. | Acta 2025-05-10; comités 2026-09-03 a 2026-10-08 |

Lo que sí cambió es la asistencia al comité: 5 personas el 2026-09-03, 15 el 2026-10-08 y el 2026-10-15. No es un cambio de gobierno, pero no sé por qué creció. La autoridad de la gerente no está declarada en el acta.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 6 | 2026-09-23 (original) → 10-02 → 10-23 → 11-10 → 11-24 → 12-03 → 12-17 |
| Sandra Gil | Cerrar la prueba 2 | 5 | 2026-09-21 (original) → 10-01 → 10-11 → 10-27 → 11-14 → 12-03 |
| Laura Vélez | Aprobar el diseño 5 | 3 | 2026-09-19 (original) → 10-10 → 10-23 → 11-06 |

Cada empujón ocurrió en una reunión semanal distinta. Además hay 4 vencidos sin acta (Mauricio Pérez, ambiente 12; Óscar Ramírez, diseño 13; Jorge Medina, matriz 14; Javier Hoyos, prueba 18) y uno sin fecha (Laura Vélez, ajuste del presupuesto, 2026-10-15). "Prueba 10" (Óscar Ramírez) y "ambiente 12" (Mauricio Pérez) salieron de la tabla de compromisos después de decir que ya estaban entregados, y no hay acta de ninguno.

### Desde cuándo lo declarado no se sostiene
- **La fecha:** no se puede fijar con una serie, porque hay una sola declaración de estado (verde, 39%, corte 2026-09-27). Lo más antiguo que se puede marcar es **2025-12-11**: el hito "Ambiente de pruebas certificado" figura cerrado y no tiene acta (308 días desde su fecha). El segundo es "Integración con el ERP" (2026-03-24, 205 días), también sin acta.
- **Qué se siguió reportando:** verde el 2026-09-27, con 6 señales abiertas que el informe no menciona (compromisos vencidos, compromisos reprogramados, hitos sin evidencia, avance contra plan, entregables de proveedor atrasados y factura sobre lo aceptado).
- **Avance:** declarado 39%; con 4 de 5 hitos cerrados el plan sostiene entre 80% y 100%. Diferencia de 41.0 puntos. No sé cuál de los dos números es el errado: puede ser que los hitos estén mal marcados o que el avance esté mal calculado.
- **Dinero:** ejecutado 41.7% y comprometido 32.6% del aprobado. Lo ejecutado supera lo comprometido; proyección 4.226.425.039 COP, 0.6% sobre lo aprobado.
- **Despliegue en la cadena** vence mañana (2026-10-16) y figura "en curso"; no hay evidencia de su estado.
- **Proveedores:** CT-963 facturado 921.509.752 COP contra 687.808.864 COP aceptados con acta (diferencia 233.700.888 COP). Licenciamiento (venció 2025-09-10, 400 días) y bolsa de horas (venció 2026-01-01, 287 días) siguen pendientes. CT-978 tiene "licenciamiento" como recibido en el contrato pero sin acta. Los dos contratos tienen entregables con el mismo nombre (licenciamiento, bolsa de horas); la carpeta no explica el reparto.

### Lecciones ancladas a un hecho
1. **Facturar sin acta.** Hecho: el 2026-09-03 se radicó FV-1963 por 921.509.752 COP, y el contrato exige acta firmada por entregable; las actas cubren 687.808.864 COP. Efecto: 233.700.888 COP en cuentas por pagar sin aceptación escrita.
2. **Un compromiso que se mueve cada semana no es un compromiso.** Hecho: "documento 1" se movió 6 veces entre 2026-09-10 y 2026-10-15. Efecto: la fecha vigente (2026-12-17) quedó después del cierre del acta (2026-12-07).
3. **Un hito cerrado necesita su acta.** Hecho: ambiente de pruebas (2025-12-11) e integración con el ERP (2026-03-24) figuran cerrados sin acta, y el diseño (primer hito) solo tiene acta del 2026-10-11, después de la del piloto. Efecto: el avance de 39% y el 80-100% del plan no se pueden conciliar.
4. **Lo que se dijo y no se escribió no existe para el seguimiento.** Hecho: el 2026-10-15 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo anotó; el informe del 2026-09-27 lista un solo riesgo (congelamiento de cambios en temporada alta). Efecto: el riesgo no tiene dueño ni fecha.
5. **El archivo no puede decir una fecha anterior a lo que contiene.** Hecho: cronograma y contratos fechados en mayo de 2025 traen estados de 2026. Efecto: la fecha del documento no sirve para ubicar cuándo cambió el estado; 11 citas al acta de constitución además no resuelven en el índice de documentos (causa no determinada).

### Lo que no sé
Por qué no hay documentos entre 2025-05-14 y 2026-05-09 (si no hubo comités o si no se guardaron); si hubo informes de avance anteriores al del 2026-09-27; quién editó cronograma y contratos después de sus fechas; cuál es la fecha de cierre válida; la autoridad de la gerente; qué bloquea el documento 1 y la prueba 2; la vigencia y el preaviso de los contratos; si las facturas se pagaron.

Esto describe qué dicen los documentos, no por qué. Que un atraso no quedara escrito no dice que alguien lo ocultara; esa conversación es de personas y esta historia sirve para tenerla con fechas. Puedo llevarla al comité del 2026-10-22 si hay una decisión que salga de ella (fecha de cierre, facturas sobre lo aceptado), o al cierre del proyecto.

*Pie de rigor: borrador de trabajo con cita a documentos; la verificación es suya. Cifras de cálculo copiadas de la salida de `compute`; los conteos de documentos y las fechas de la línea de tiempo son lectura mía de la carpeta.*
