# Plan — PRY-201 Programa de fidelización · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-05-10 (`00-gobierno/2025-05-10-acta-constitucion.docx`) · **Criterio de éxito:** «Programa de fidelización en producción y medido» (acta). No dice qué se mide, ni con qué meta, ni quién da por medido.

*Términos: vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.9). Preguntas de configuración: ninguna; no hubo a quién preguntar y no hizo falta.*

**Antes de leer el borrador:** este proyecto ya tiene un plan, no es un proyecto sin plan. Existe `10-plan/2025-05-10-cronograma-v1.xlsx` con cinco hitos, cuatro cerrados y uno en curso (Despliegue en la cadena, 2026-10-16). Este borrador reconstruye la descomposición desde el acta, como si se planificara hoy, para mostrar qué sostiene el acta y qué no. **No reemplaza ni modifica la línea base v1.**

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido real.** Dice «Componente 1 / 2 / 3» y fuera de alcance dice «Lo que otro proyecto cubre». | No se puede descomponer por entregable desde el acta. Toda la WBS de abajo sale de otros documentos o de supuestos. Es el vacío más caro. |
| **Criterio de éxito sin métrica.** «En producción y medido». | «Medido» no tiene indicador, meta ni fecha de lectura. El proyecto puede cerrar el 2026-12-07 «en producción» y nadie puede decir si tuvo éxito. |
| **Sin autoridad declarada.** El acta no dice qué puede decidir la gerente y qué debe subir (cambios de fecha, de presupuesto, de alcance). | No se sabe qué decisiones del plan son de Diana Molina y cuáles van al Comité Comercial o al patrocinador. |
| **Dependencias: «Ninguna declarada».** | El cronograma v1 tiene «Integración con el ERP» y hay dos proveedores contratados (CT-963, CT-978). Sí hay dependencias; el acta no las nombra. |
| **Objetivo del negocio genérico.** «Entregar programa de fidelización para Comercio electrónico». | No hay resultado de negocio contra el cual priorizar si hay que recortar. |
| Patrocinador: **Felipe Arango**, declarado. Presupuesto: 4.200.000.000 COP, aprobado por Comité Comercial el 2025-05-10. | Sin hallazgo: hay a quién llevarle las excepciones. |

Se sigue adelante marcando los huecos. No se rellenan.

## WBS
Cada nodo terminal es algo que alguien recibe y acepta. Donde nadie lo ha dicho, queda «sin definir».

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | **Programa de fidelización en producción** | Sin definir | del acta (criterio de éxito), pero sin forma de aceptarlo | — |
| 1.1 | Componente 1 | Sin definir | **sin definir** (el acta no lo nombra) | — |
| 1.2 | Componente 2 | Sin definir | **sin definir** | — |
| 1.3 | Componente 3 | Sin definir | **sin definir** | — |
| 2 | Medición del programa (indicador, línea de lectura, informe) | Sin definir | del acta («medido»), contenido **sin definir** | — |
| 3 | CT-963 · Licenciamiento de la plataforma (Tecnología para Tiendas) | Gerente de proyecto, por acta de recibo (contrato CT-963, condición de pago) | supuesto: viene del contrato, no del acta | vacía |
| 4 | CT-963 · Bolsa de horas de desarrollo | ídem | supuesto (contrato) | vacía |
| 5 | CT-963 · Configuración del catálogo | ídem | supuesto (contrato) | vacía |
| 6 | CT-963 · Soporte del primer trimestre | ídem | supuesto (contrato) | vacía |
| 7 | CT-978 · Licenciamiento de la plataforma (Datos y Demanda) | Gerente de proyecto, por acta de recibo (contrato CT-978) | supuesto (contrato) | vacía |
| 8 | CT-978 · Bolsa de horas de desarrollo | ídem | supuesto (contrato) | vacía |
| 9 | Diseño de la experiencia aprobado | Sin definir | supuesto: del cronograma v1, no del acta | vacía |
| 10 | Ambiente de pruebas certificado | Sin definir | supuesto (cronograma v1) | vacía |
| 11 | Integración con el ERP | Sin definir | supuesto (cronograma v1) | vacía |
| 12 | Piloto en tiendas | Sin definir | supuesto (cronograma v1) | vacía |
| 13 | Despliegue en la cadena | Sin definir | supuesto (cronograma v1) | vacía |

Los ocho entregables contractuales suman 2.341.711.308 COP (4 × 343.904.432 de CT-963 + 2 × 483.046.790 de CT-978). Contra los 4.200.000.000 aprobados, **1.858.288.692 COP no tienen un entregable asociado en ningún documento leído.**

Las fechas comprometidas de los contratos existen y están citadas en ellos; no se copian aquí como fechas del plan porque son compromisos de los proveedores, no del proyecto.

## Orden
Sin fechas. Qué necesita qué:

- 9 (Diseño aprobado) antes de 10, 11 y 12: es lo que se prueba, integra y se pilotea. *Supuesto: orden tomado del cronograma v1, el acta no lo dice.*
- 3 y 7 (licenciamiento de ambas plataformas) antes de 10 (ambiente de pruebas): sin plataforma no hay qué certificar. *Supuesto.*
- 5 (Configuración del catálogo) antes de 12 (Piloto): el piloto necesita catálogo. *Supuesto.*
- 4 y 8 (bolsas de horas) corren en paralelo al desarrollo de 11. *Supuesto: no se sabe qué consume cada bolsa.*
- 10 y 11 antes de 12 (Piloto), y 12 antes de 13 (Despliegue). *Supuesto, coincide con el orden del cronograma v1.*
- 13 antes de 2 (Medición): no se mide lo que no está en producción.
- 6 (Soporte del primer trimestre) depende de lo que ese «primer trimestre» cuente desde: **sin definir**.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los entregables de los contratos CT-963 y CT-978 son el alcance del programa (o la parte de él que se contrata). | Hay alcance fuera de contrato (≈ 1.858 millones COP) sin descomponer. El plan subestima el trabajo. |
| Los cinco hitos del cronograma v1 son los entregables propios del proyecto. | Faltan entregables que nadie planificó (por ejemplo, la medición). |
| El gerente del proyecto es quien acepta los entregables contractuales (lo dice la condición de pago de ambos contratos). | Si el Comité o el patrocinador deben validarlos, las facturas se liberan sin la aceptación correcta. |
| El orden de dependencias de arriba es el real. | Un entregable puede estar bloqueado por algo no previsto, y se descubre al ejecutarlo. |
| El proveedor tiene capacidad para la siguiente fase. **Las notas del 2026-10-15 dicen que podría no llegar con el equipo completo y nadie lo registró como riesgo.** | Retraso en lo que sigue al despliegue. Hoy no tiene doliente ni valoración. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son el Componente 1, 2 y 3 | Patrocinador (Felipe Arango) con la gerente |
| Qué se mide, con qué indicador y qué meta cuenta como «medido» | Patrocinador / Comité Comercial |
| Quién acepta cada hito propio (9–13) y la medición | Patrocinador |
| Qué decide la gerente y qué sube al Comité | Patrocinador / Comité Comercial |
| En qué se usa el presupuesto no asociado a contratos | Comité Comercial |
| Dependencias reales (ERP, otros proyectos, equipos internos) | Gerente, con el equipo |
| Desde cuándo se cuenta el «primer trimestre» de soporte | Proveedor CT-963 y gerente |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO. Es la respuesta correcta: sin análogos no se da ninguna referencia de cuánto se corre un proyecto así, y no se inventa una.

## Preguntas para el equipo
Una por cada duración vacía:

1. ¿Cuánto toma recibir y aceptar el licenciamiento de CT-963? ¿Y el de CT-978?
2. ¿Cuántas horas de la bolsa de CT-963 y de CT-978 están comprometidas y a qué trabajo?
3. ¿Cuánto toma cerrar la configuración del catálogo y desde cuándo empieza a contar?
4. ¿Cuándo empieza el «primer trimestre» de soporte y cuánto dura la aceptación?
5. ¿Cuánto toma aprobar el diseño de la experiencia, y quién lo aprueba?
6. ¿Cuánto toma certificar el ambiente de pruebas y con qué criterio?
7. ¿Cuánto toma la integración con el ERP y quién del equipo del ERP participa?
8. ¿Cuánto dura el piloto y qué resultado lo da por bueno?
9. ¿Cuánto toma el despliegue en la cadena, por tienda o por oleada?
10. ¿Cuánto tarda en estar disponible la primera lectura del indicador de éxito, y cuál es?
11. ¿Con qué equipo viene el proveedor en la siguiente fase, y quién lo confirma?

## Para comprometer una fecha falta
- La **disponibilidad real del equipo** (interno y de ambos proveedores) para la fase que sigue. Hoy solo hay un comentario sin registrar en las notas del 2026-10-15.
- La **fecha del proveedor** para el equipo completo; no hay documento que la fije.
- La **ventana de despliegue en tiendas**: cuándo puede operar el piloto y el despliegue sin chocar con la operación comercial. Ningún documento la trae.
- Una **definición de «medido»** para saber cuándo puede cerrar el proyecto.

Ninguna fecha queda comprometida en este borrador. Eso lo hace la gerente.
