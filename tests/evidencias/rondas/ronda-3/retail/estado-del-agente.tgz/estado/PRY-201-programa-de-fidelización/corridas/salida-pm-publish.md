Publiqué la ficha en `/home/claude/banco/ronda-3/retail/espacio/documentos/proyectos/PRY-201-programa-de-fidelización/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 11 campos con dato · 4 sin decir en ninguna parte (identity.authority, identity.phase, declared.status, declared.progress_pct) · **no declara estado**: el campo `declared.status` está vacío, así que la PMO no verá un estado tuyo.

**Lo más viejo que va ahí:** los 11 campos con dato (código, nombre, área, producto, patrocinador, gerente, comité, fechas de inicio y fin, moneda y presupuesto aprobado) salen del acta de constitución del 2025-05-10, hace 17 meses — pasa de un año. Ningún campo se ha contrastado con un documento más reciente.

**Antes de que la PMO la lea:** el cálculo trae 8 alertas de compromisos (4 vencidos sin evidencia, 1 sin fecha, 3 reprogramados 3 a 6 veces) y el proyecto no tiene línea base. Ninguna está explicada en una declaración de estado, porque no hay declaración.

Nota: la carpeta de gobierno ya existía; no había una ficha anterior que reemplazar. Los términos ya estaban vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no se registraron de nuevo.
