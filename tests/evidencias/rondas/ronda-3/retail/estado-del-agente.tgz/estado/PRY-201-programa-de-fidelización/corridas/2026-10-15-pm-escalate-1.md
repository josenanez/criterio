# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 39 s · 8 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 1 |

Dos puntos: autoridad de la gerente no declarada en el acta, y cierre 12-07 vs 12-17 (documento 1, 6 reprogramaciones). impact devolvió 0 alcanzados: la ficha no tiene hitos ni dependencias. No supe: costo de cada opción, qué bloquea el documento 1, si el documento 1 está en el camino crítico.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — Programa de fidelización (PRY-201) · 2026-10-15

Dos puntos, en este orden. El primero no es el que venías a subir, pero va antes.

---

### Punto 1 · ¿Qué puede decidir la gerente de PRY-201 sin ir al comité?

**Quién decide:** Felipe Arango (patrocinador) / Comité Comercial · **Si no se decide hoy:** no hay fecha dura. El 2026-10-22 es el próximo comité (`committee_next`; las notas del 10-15 dicen «en dos semanas», 10-29: hay que confirmarlo). Sin autoridad declarada, el punto 2 no se puede dirigir con certeza a quien tiene la facultad.

El acta de constitución del 2025-05-10 declara patrocinador, gerente, comité, presupuesto y fechas, pero **no dice qué puede decidir la gerente** (cambio de fecha, de costo, de alcance, ni hasta qué monto o cuántos días). No es un tema de interpretación: el campo no está en el documento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara por escrito la autoridad de la gerente (umbral de días y de COP) y se anexa al acta | Sin cambio | Una sesión | Sin costo directo declarado |
| B. Se asume que todo cambio de línea base va al comité | Sin cambio | Cada cambio espera comité semanal | Sin costo directo declarado; demora de hasta una semana por cambio |

**Recomiendo:** A. Sin umbral escrito, la gerente escala todo o nada, y el comité puede decidir algo que no le tocaba.

---

### Punto 2 · ¿Se acepta que el cierre de PRY-201 pase del 2026-12-07 al 2026-12-17, o se exige que el documento 1 y la prueba 2 entren antes del 12-07?

**Quién decide:** no se puede afirmar según el acta (ver punto 1). Mover el cierre cambia la línea base aprobada el 2025-05-10 por el Comité Comercial, así que lo razonable es Felipe Arango y el Comité Comercial. **Si no se decide hoy:** no hay una fecha externa documentada que obligue. Lo que sí está documentado: «Enviar el documento 1» ya se movió 6 veces (09-23 → 10-02 → 10-23 → 11-10 → 11-24 → 12-03 → 12-17) y la fecha vigente cae 10 días después del cierre; «Cerrar la prueba 2» se movió 5 veces y su fecha vigente (12-03) queda 4 días antes del cierre. Cada comité semanal que pasa sin decidir suma otro posible movimiento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aceptar el cierre al 12-17 (control de cambios, línea base nueva; la anterior no se borra) | Sin cambio declarado | +10 días | No documentado: no hay en los documentos leídos ninguna cifra de costo por día de extensión |
| B. Mantener el 12-07 y exigir a Paula Céspedes nombrar qué bloquea el documento 1 y una fecha que quepa | Sin cambio | 0 días, si la fecha cabe | No documentado |
| C. Mantener el 12-07 recortando alcance | El acta solo lista «Componente 1, 2, 3»; no se puede saber qué sería recortable | 0 días | No documentado |

**Recomiendo:** B primero, y A solo si la respuesta de Paula no cabe antes del 12-07. Razón: seis movimientos sin que nadie haya nombrado el bloqueo indican que mover el cierre tampoco garantiza que el 12-17 se cumpla. Esto es una recomendación con lo que se sabe hoy, no un cálculo.

**Supuesto que hay que confirmar:** que el documento 1 está en el camino crítico del cierre. Ningún documento lo dice; la agenda del 10-15 lo planteó como condicional («si Paula o Sandra no pueden entrar»).

### A quién alcanza
El cálculo (`impact`, 10 días sobre PRY-201) devolvió **0 proyectos alcanzados y 0 hitos**. Eso no significa que nadie quede afectado: significa que la ficha no tiene hitos ni dependencias cargados, y el acta declara «Ninguna declarada». No hay otros proyectos en el estado de esta carpeta contra los cuales cruzar. Quién depende de PRY-201 queda **sin verificar**, y esa es una pregunta para el patrocinador antes del comité.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| (ninguno calculable) | — | — | — |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| (ninguno en la ficha; solo la fecha de cierre) | 2026-12-07 → 2026-12-17 | 10 |

### Lo que no sé
- Qué bloquea el documento 1 y la prueba 2 (no está en ningún documento).
- La autoridad de la gerente (no está en el acta).
- El costo de cada opción: ni las actas ni los comités leídos traen cifras por día de extensión. Los contratos CT-963 y CT-978 existen en la carpeta, pero la ficha no los tiene cargados (`vendors` vacío) y no los abrí en esta corrida.
- Cuántos días se mueve cada proyecto alcanzado: necesita holgura por actividad, que la ficha no tiene.
- Si la próxima reunión es el 10-22 o el 10-29.

Fuera de este paquete, y sin escalar: los 5 vencidos sin evidencia (diseño 13, prueba 18, matriz 14, ambiente 12, prueba 10) y el ajuste del presupuesto de Laura Vélez, «la otra semana», sin fecha; se destraban con una llamada o en la sala. El riesgo del proveedor que no llega con el equipo completo sigue sin registrar; registrarlo es de la gerente, no del comité.

### De dónde sale esto
- Autoridad no declarada, patrocinador, comité, presupuesto y fechas: `00-gobierno/2025-05-10-acta-constitucion.docx` (2025-05-10) y ficha `records/PRY-201.json` (`identity.authority`: not_found).
- Reprogramaciones del documento 1 y de la prueba 2: comités `30-reuniones/2026-09-03` al `2026-10-08-comite-semanal.md` y `2026-10-15-notas-reunion.txt`.
- «Próxima reunión en dos semanas»: `2026-10-15-notas-reunion.txt`; comité semanal: `.criterio/proyecto/PRY-201/config.json`.
- Efecto del cambio: `portafolio.py impact --code PRY-201 --days 10` (2026-10-15).

### Después
Este paquete no escala solo ni decide. Si el comité decide, se registra la decisión con su fecha y documento; si mueve la línea base, es control de cambios y la línea base anterior no se toca. La llamada a Felipe Arango es tuya.
