# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 100 s · 8 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 1 |

Registro completado de 3 a 26 compromisos desde las minutas; 3 reprogramados (Paula 6, Sandra 5, Laura 3), 4 vencidos, 1 sin fecha, 8 cerrados con acta; 2 'ya entregué' sin acta (Óscar prueba 10, Mauricio ambiente 12)

Contra la corrida del 2026-10-15: +6 hallazgos.

## Lo que produjo

## Compromisos — Programa de fidelización (PRY-201) · al 2026-10-15

26 compromisos en las minutas del 09-03 al 10-08 y las notas del 10-15: **18 abiertos y 8 cerrados con acta de recibo**. Las notas del 10-15 solo mencionan 3; los demás siguen como quedaron en el comité del 10-08 (ni cierran ni se reprograman).

Antes de esta revisión el registro solo tenía 3 compromisos. Agregué los otros 23 desde las minutas; sin eso `compute` no veía 3 de los 4 vencidos ni 2 de los 3 reprogramados.

### Se viene reprogramando

> **Paula Céspedes** · Enviar el documento 1 — **6 reprogramaciones**
> Prometido para el 09-23, y antes de cada comité: 10-02 → 10-23 → 11-10 → 11-24 → 12-03 → **12-17**.
> La fecha vigente cae 10 días después del cierre planificado del proyecto (2026-12-07). **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Sandra Gil** · Cerrar la prueba 2 — **5 reprogramaciones**
> Prometido para el 09-21, y después: 10-01 → 10-11 → 10-27 → 11-14 → **12-03**.
> Queda 4 días antes del cierre planificado (12-07). No aparece en las notas del 10-15.

> **Laura Vélez** · Aprobar el diseño 5 — **3 reprogramaciones**
> Prometido para el 09-19, y después: 10-10 → 10-23 → **11-06**.
> El 09-17 se repitió el 09-19 (no cuenta como reprogramación) y el 09-24 ya estaba vencido. Tampoco figura en las notas del 10-15.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Óscar Ramírez | Aprobar el diseño 13 | 2026-10-09 | 6 días |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-11 | 4 días |
| Jorge Medina | Actualizar la matriz 14 | 2026-10-12 (antes 10-02) | 3 días |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-14 | 1 día |

- Mauricio Pérez dijo el 09-24 que ya entregó «validar el ambiente 12»; **no hay acta de recibo en el expediente**. El compromiso desapareció de la tabla de abiertos desde el 10-01 sin cierre documentado.
- Óscar Ramírez tiene el diseño 13 con la misma fecha (10-09) en tres comités seguidos (09-24, 10-01, 10-08) y no figura en las notas del 10-15.
- El acta del 2026-10-11 «Diseño de la experiencia aprobado» es un entregable del proyecto, no el recibo de «Aprobar el diseño 13» ni del 5 o el 21; no los cierra.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-15 (hoy) |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-17 |
| María Restrepo | Aprobar el diseño 21 | 2026-10-20 |

- Óscar Ramírez dijo el 09-24 que ya entregó «cerrar la prueba 10»; no hay acta y salió de la tabla de abiertos sin cierre.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-15 |

Ricardo Salas tuvo «Revisar el anexo 3» sin fecha («por definir») en los comités del 09-03, 09-10 y 09-17; hoy tiene el 2026-10-29.

### Cerrados con evidencia
| Quién | Qué | Documento |
|---|---|---|
| Felipe Arango | Validar el ambiente 4 | acta de recibo 2026-09-10 |
| Felipe Arango | Entregar el punto 8 | acta de recibo 2026-09-17 |
| Camilo Beltrán | Revisar el anexo 11 | acta de recibo 2026-09-24 |
| Javier Hoyos | Actualizar la matriz 6 | acta de recibo 2026-10-08 (vencía el 09-22) |
| Diana Molina | Confirmar la fecha 7 | acta de recibo 2026-10-08 |
| Elena Duarte | Confirmar la fecha 15 | acta de recibo 2026-10-08 (vencía el 09-30) |
| Felipe Arango | Entregar el punto 16 | acta de recibo 2026-10-08 |
| Camilo Beltrán | Validar el ambiente 20 | acta de recibo 2026-10-08 |

### Cifras de `compute`
Vencidos: 4 · Sin fecha: 1 · Reprogramados 3 o más veces: 3 (Paula 6, Sandra 5, Laura 3).

Otros 5 compromisos abiertos llevan una o dos reprogramaciones y todavía no cruzan el umbral de 3: Carlos Peña (documento 9, 2), Ricardo Salas (anexo 3, 1), Jorge Medina (matriz 14, 1), Andrés Lozano (documento 17, 1) y Elena Duarte (anexo 19, 1).

### Aparte
- «Revisión con el proveedor» (Óscar Ramírez) quedó para el 2026-10-25, que es domingo.

### Qué ofrezco
- **Decisión para el comité del 10-22:** Paula (6 veces, ya fuera del plazo) y Sandra (5, a 4 días del cierre) comprometen el cierre planificado. Puedo formular qué se pide, qué pasa si no se decide y quién tiene la facultad, con `/pm-escalate`.
- `/pm-publish` para que la PMO vea los cambios de la ficha.
