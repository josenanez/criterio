## Reunión de seguimiento — Programa de fidelización (PRY-201) · 2026-10-22
Es el comité semanal de `committee_next` (jueves 10-22). Las notas del 10-15 dicen «próxima reunión en dos semanas» (10-29); la configuración dice semanal. **Confirma la fecha antes de convocar.**

11 puntos (3 que no se destraban solos, 5 vencidos, 1 de decisión, 2 preventivos) · 43 minutos · 10 personas requeridas (Paula Céspedes, Sandra Gil, Laura Vélez, Óscar Ramírez, Javier Hoyos, Jorge Medina, Mauricio Pérez, Gustavo Neira, María Restrepo, Diana Molina).

Diff contra la reunión anterior: no hay foto previa (esta es la corrida base), así que "lo que cambió" sale de las minutas del 09-03 al 10-08 y de las notas del 10-15. Tampoco hay decisiones pendientes registradas en esas minutas.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea el documento 1 y fijar una fecha que quepa antes del 12-07** · 10 min · **Paula Céspedes**
> Prometido para el 12-17, y antes para el 12-03, 11-24, 11-10, 10-23, 10-02 y 09-23 (6 reprogramaciones).
> Fuente: notas 2026-10-15 y comités 09-03 al 10-08.
> **Si no se resuelve hoy:** la fecha vigente cae 10 días después del cierre planificado (2026-12-07). Seis movimientos no es seguimiento: es un bloqueo que nadie ha nombrado. Qué lo bloquea no está en ningún documento; hay que preguntarlo en la sala.

> **[2] Cerrar la prueba 2: qué falta y quién lo mueve** · 8 min · **Sandra Gil**
> Prometido para el 12-03, y antes para el 11-14, 10-27, 10-11, 10-01 y 09-21 (5 reprogramaciones).
> Fuente: comités 09-03 al 10-08. No aparece en las notas del 10-15.
> **Si no se resuelve hoy:** la fecha vigente queda 4 días antes del cierre planificado; cualquier otro movimiento lo pasa.

> **[3] Aprobar el diseño 5 y fechar el ajuste del presupuesto** · 7 min · **Laura Vélez**
> Diseño 5: prometido para el 11-06, y antes para el 10-23, 10-10 y 09-19 (3 reprogramaciones). No figura en las notas del 10-15.
> Ajuste del presupuesto: dicho el 10-15 «la otra semana», sin fecha.
> Fuente: comités 09-10 al 10-08 y notas 2026-10-15.
> **Si no se resuelve hoy:** el diseño 5 cruza al cuarto movimiento; el ajuste queda sin fecha, y lo que no tiene fecha no vence.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Óscar Ramírez | Aprobar el diseño 13 | 10-09 (misma fecha en 09-24, 10-01 y 10-08) | Entregar con acta de recibo o fecha nueva dicha en voz alta | 2 |
| Javier Hoyos | Cerrar la prueba 18 | 10-11 | Ídem | 2 |
| Jorge Medina | Actualizar la matriz 14 | 10-12 (antes 10-02) | Ídem | 2 |
| Mauricio Pérez | Validar el ambiente 12 | 10-14 | Dijo el 09-24 que ya lo entregó; **no hay acta de recibo**. Mostrar el acta o reabrirlo | 2 |
| Óscar Ramírez | Cerrar la prueba 10 | vence el 10-15 | Dijo el 09-24 que ya lo entregó; no hay acta. Mostrar el acta o reabrirlo | 2 |

Fuente: comités 09-24, 10-01 y 10-08 y `/pm-commitments` del 10-15. El acta del 10-11 «Diseño de la experiencia aprobado» es un entregable del proyecto; no cierra estos compromisos.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase: registrarlo como riesgo con dueño, probabilidad, impacto y fecha. Fecha de la «revisión con el proveedor» de Óscar, hoy en 10-25 (domingo) | Diana Molina (dueño del riesgo); Óscar Ramírez (fecha de la revisión) | Sigue dicho y no registrado, sin dueño, y la revisión cae en domingo | 5 |

Fuente: notas 2026-10-15 (riesgo mencionado, «nadie lo anotó»).

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-17 |
| María Restrepo | Aprobar el diseño 21 | 2026-10-20 |

Confirmar en la sala que ambos llegan; 1 min cada uno, incluido en el tiempo total.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Mover el cierre planificado del proyecto (2026-12-07) si Paula o Sandra no pueden entrar | Cambia la línea base; excede la autoridad del gerente. El patrocinador es Felipe Arango, que no estuvo el 10-08 | Control de cambios y material de comité. Puedo formularlo con `/pm-escalate` |

### Anexo — sin cambios desde el 2026-10-08
Una línea cada uno; no se repasan:
- Ricardo Salas · Revisar el anexo 3 · 10-29
- Carlos Peña · Enviar el documento 9 · 10-29 (2 reprogramaciones)
- Andrés Lozano · Enviar el documento 17 · 10-23
- Elena Duarte · Revisar el anexo 19 · 11-03
- Camilo Beltrán · Confirmar la fecha 23 · 11-03
- Mauricio Pérez · Entregar el punto 24 · 10-26
- 8 compromisos cerrados con acta de recibo (ver `/pm-commitments` del 10-15)

### Tiempo
10 + 8 + 7 + 10 + 5 + 3 = 43 min, 2 de holgura. Nada quedó fuera por tiempo.

### Lo que no sé
- Qué bloquea el documento 1 y la prueba 2: no está en ningún documento.
- Si la próxima reunión es el 10-22 o el 10-29.
- Si Felipe Arango debería estar en el punto 1; lo decide el gerente.

### Después
Cuando termine la reunión, `/pm-minutes` sobre la transcripción o las notas. Los compromisos que salgan entran a `/pm-commitments` con su cita.
