# PRY-201 Programa de fidelización — semana del 2026-10-09 al 2026-10-15

**Declara el gerente:** SIN DECLARACIÓN · sin avance · sin fecha. La declaración quedó en blanco: en esta sesión nadie respondió, y Samuel no la propone ni la suple.
**Sustento documental:** no evaluable (sin declaración que contrastar; 0 de 11 campos marcados como evidencia, 11 sin marcar)
**Lo que el semáforo no explica:** vencimientos de compromisos (`commitment_overdue`) y reprogramaciones (`commitment_rescheduled`). Cuando el gerente declare, el estado tiene que dar cuenta de ambas señales.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: el snapshot de hoy (2026-10-15) es el primero y el diff contra sí mismo da 0 cambios. Este informe es la línea de partida. Desde la próxima corrida habrá un «Estaba / Está».

## Lo que sigue igual y sigue mal
Sin corrida previa no se puede decir desde cuándo está mal cada cosa. Lo que ya está mal hoy, con los días que lleva vencido:

| Qué | Desde | Días así |
|---|---|---|
| Óscar Ramírez — Aprobar el diseño 13 | venció 2026-10-09 | 6 |
| Javier Hoyos — Cerrar la prueba 18 | venció 2026-10-11 | 4 |
| Jorge Medina — Actualizar la matriz 14 | venció 2026-10-12 | 3 |
| Mauricio Pérez — Validar el ambiente 12 | venció 2026-10-14 | 1 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin línea base | 2026-12-07 | no calculable |
| Presupuesto | sin línea base | COP 4.200.000.000 aprobado | no calculable |

Replanificaciones: 0 registradas. Sin línea base, ese 0 no significa que el plan no se haya movido. Significa que no hay con qué medirlo.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha: no hay hitos vencidos ni cumplidos sin evidencia porque no hay hitos registrados.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 4.200.000.000 | sin dato | sin dato | sin dato | no calculable (aprobado menos comprometido) |

## Abierto
**Reprogramados** (primero, son lo que más necesita a alguien):
- Paula Céspedes — Enviar el documento 1: **6 veces**. Original 2026-09-23; hoy va a 2026-12-17, casi 3 meses después.
- Sandra Gil — Cerrar la prueba 2: **5 veces**. Original 2026-09-21; hoy va a 2026-12-03.
- Laura Vélez — Aprobar el diseño 5: **3 veces**. Original 2026-09-19; hoy va a 2026-11-06. Llega al umbral de 3.

**Vencidos sin evidencia:** los cuatro de la tabla de arriba. Fuentes: comités del 17/09, 24/09 y 01/10.
**Sin fecha:** Laura Vélez — Mandar el ajuste del presupuesto (notas del 2026-10-15). Un compromiso sin fecha no puede vencer, y por eso no lo ve ninguna alerta.
**RAID sin movimiento:** sin dato (no hay RAID en la ficha).
**Proveedor:** sin proveedores registrados.

## Lo que necesito de alguien
- **Diana Molina (gerente):** declarar estado y avance. Sin eso este informe sale incompleto a propósito.
- **Paula Céspedes y Sandra Gil:** fecha firme o decisión de descartar. Con 6 y 5 reprogramaciones, otra fecha nueva no sirve.
- **Laura Vélez:** fecha para el ajuste del presupuesto, y confirmar si el diseño 5 sale el 2026-11-06.
- **Óscar Ramírez, Javier Hoyos, Jorge Medina, Mauricio Pérez:** cerrar o reprogramar con fecha lo vencido.
- Material de comité (jueves 2026-10-22): las tres reprogramaciones con 3 o más cambios son candidatas a punto de comité. Se ofrece armarlo con `/pm-escalate`.

## Lo que no se sabe
**Sin dato:** autoridad (`identity.authority`), fase, estado declarado, avance declarado, línea base, comprometido, ejecutado, proyección, hitos. Los 11 campos con fecha tienen 17 meses (fuente del 2025-05-10); el umbral de obsolescencia es 12.
**Silencio:** último documento hace 0 días (notas del 2026-10-15) · última reunión hace 0 días (2026-10-15).

---
Ficha: PRY-201, snapshot 2026-10-15. Campos sin dato: 4 (autoridad, fase, estado declarado, avance declarado). Campos obsoletos: 11. Términos 1.1 aceptados el 2026-10-15 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
