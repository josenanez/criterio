# Acta — Programa de fidelización (PRY-201) · 2026-10-15
**Asistieron:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** 2026-10-15-notas-reunion.txt · **Ausentes con tema en agenda:** no determinable (las notas no traen agenda)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 («lo de enviar el documento 1 no alcanzó») | 2026-12-17 | **Reprogramado 6 veces.** Promesa original 2026-09-23 → 10-02 → 10-23 → 11-10 → 11-24 → 12-03 → 12-17 (comités del 09-10 al 10-15) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo. Ojo: el 25 de octubre de 2026 es domingo |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dijo «la otra semana»; `due_date: no_declarada`, no se infiere fecha |

## Decisiones
Ninguna. Las notas no registran decisiones ni qué se descartó.

## Quedó sin decidir
Las notas no registran temas planteados y aplazados; no se inventa ninguno.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | No atribuido en las notas («se comentó») | Riesgo (RAID) — probabilidad, impacto y doliente: no declarados | No. Las notas dicen que nadie lo anotó. Queda en el registro con doliente `no_identificado` |

## Cerrado en esta reunión
Nada. Las notas no traen ningún documento que cierre un compromiso.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-29) | Comité semanal; próximo 2026-10-22 | Notas 2026-10-15 vs. `config.json` (cycle.committee: weekly, committee_next: 2026-10-22) |

Observación aparte: la nueva fecha de Paula (2026-12-17) queda 10 días después del cierre planificado del proyecto (2026-12-07, acta de constitución del 2025-05-10).

## Sin resolver de la transcripción
- «la otra semana» (Laura Vélez): no se sabe si es la semana del 19 o una fecha concreta.
- «próxima reunión en dos semanas»: no queda claro si reemplaza al comité semanal o es una excepción.
- Los otros 13 compromisos abiertos del comité del 2026-10-08 no se mencionan en estas notas; ni cierran ni se reprograman, siguen como estaban.

## Corrección al registro
El registro traía el compromiso de Paula con promesa original 2026-12-03 y una sola reprogramación. Revisando los comités anteriores, la promesa original es del 2026-09-03 (para el 09-23) y hay 6 reprogramaciones; el registro quedó corregido. Tras recalcular, `compute` marca: 1 compromiso sin fecha (Laura Vélez) y 1 reprogramado (Paula Céspedes, 6 veces; el umbral de alerta es 3).
