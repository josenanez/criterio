# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2025-10-06
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 186.985 | Caso de negocio, 2025-10-06 |

## Retorno esperado

Retorno esperado en 24 meses.
