# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-05-17
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 80.197 | Caso de negocio, 2026-05-17 |

## Retorno esperado

Retorno esperado en 24 meses.
