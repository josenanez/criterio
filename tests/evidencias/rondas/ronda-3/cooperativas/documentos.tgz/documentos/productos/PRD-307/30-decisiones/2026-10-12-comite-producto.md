# Comité de producto · Auxilios de solidaridad

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4701 | Requerimiento REQ-4701 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-13 | — |
| REQ-4702 | Requerimiento REQ-4702 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-05-30 | — |
| REQ-4703 | Requerimiento REQ-4703 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-4704 | Requerimiento REQ-4704 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-26 | — |
| REQ-4705 | Requerimiento REQ-4705 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4706 | Requerimiento REQ-4706 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4707 | Requerimiento REQ-4707 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4708 | Requerimiento REQ-4708 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-13 | — |
| REQ-4709 | Requerimiento REQ-4709 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-11 | — |
| REQ-4710 | Requerimiento REQ-4710 | Mauricio Pérez | se verifica en producción | — | propuesto | 2026-06-25 | — |
| REQ-4711 | Requerimiento REQ-4711 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-24 | — |
| REQ-2026 | Requerimiento REQ-2026 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-27 | — |
| REQ-2034 | Requerimiento REQ-2034 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-09-29 | — |

## Decisiones

- Se mantiene el plan
