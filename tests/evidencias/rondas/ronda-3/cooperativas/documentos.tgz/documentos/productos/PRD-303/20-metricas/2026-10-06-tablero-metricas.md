# Tablero de métricas · Tarjeta débito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 256.871 | 2026-10-06 |
