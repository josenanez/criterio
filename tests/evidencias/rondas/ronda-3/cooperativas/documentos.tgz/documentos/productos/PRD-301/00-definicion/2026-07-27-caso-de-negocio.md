# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-07-27
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 214.655 | Caso de negocio, 2026-07-27 |

## Retorno esperado

Retorno esperado en 24 meses.
