# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2026-02-13
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 142.636 | Caso de negocio, 2026-02-13 |

## Retorno esperado

Retorno esperado en 24 meses.
