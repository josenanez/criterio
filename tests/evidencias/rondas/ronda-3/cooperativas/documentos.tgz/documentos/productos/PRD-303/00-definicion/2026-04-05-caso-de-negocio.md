# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-04-05
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 250.670 | Caso de negocio, 2026-04-05 |

## Retorno esperado

Retorno esperado en 24 meses.
