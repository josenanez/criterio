# Definición de producto · Remesas familiares

**Código:** PRD-308
**Gerente de producto:** Paula Céspedes
**Segmento:** Microempresarios
**Fecha de la definición:** 2025-10-06

## El problema

El segmento Microempresarios no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-03-26 · verificado

## Proyectos que lo construyen

- Ninguno declarado
