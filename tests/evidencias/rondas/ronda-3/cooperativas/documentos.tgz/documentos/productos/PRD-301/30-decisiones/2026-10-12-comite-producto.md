# Comité de producto · Ahorro a la vista

**Fecha:** 2026-10-12
**Asistentes:** Sandra Gil

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-04 | — |
| REQ-4101 | Requerimiento REQ-4101 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-02 | — |
| REQ-4102 | Requerimiento REQ-4102 | Liliana Torres | se verifica en producción | — | aceptado | 2026-06-09 | — |
| REQ-4103 | Requerimiento REQ-4103 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-08-26 | — |
| REQ-4104 | Requerimiento REQ-4104 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-17 | — |
| REQ-4105 | Requerimiento REQ-4105 | Elena Duarte | se verifica en producción | — | propuesto | 2026-06-09 | — |
| REQ-4106 | Requerimiento REQ-4106 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-15 | — |
| REQ-4107 | Requerimiento REQ-4107 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4108 | Requerimiento REQ-4108 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-08-09 | — |
| REQ-4109 | Requerimiento REQ-4109 | Elena Duarte | — | — | propuesto | 2026-04-02 | — |
| REQ-4110 | Requerimiento REQ-4110 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-05 | — |
| REQ-4111 | Requerimiento REQ-4111 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-30 | — |
| REQ-4112 | Requerimiento REQ-4112 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4113 | Requerimiento REQ-4113 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-08-21 | — |

## Decisiones

- Se mantiene el plan
