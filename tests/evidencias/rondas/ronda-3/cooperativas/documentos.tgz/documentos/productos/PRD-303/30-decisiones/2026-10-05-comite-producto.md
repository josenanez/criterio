# Comité de producto · Tarjeta débito

**Fecha:** 2026-10-05
**Asistentes:** Sandra Gil

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-06-05 | — |
| REQ-4301 | Requerimiento REQ-4301 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-30 | — |
| REQ-4302 | Requerimiento REQ-4302 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-25 | — |
| REQ-4303 | Requerimiento REQ-4303 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4304 | Requerimiento REQ-4304 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4305 | Requerimiento REQ-4305 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4306 | Requerimiento REQ-4306 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-23 | — |
| REQ-4307 | Requerimiento REQ-4307 | María Restrepo | se verifica en producción | — | aceptado | 2026-04-28 | — |
| REQ-4308 | Requerimiento REQ-4308 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-03 | — |
| REQ-4309 | Requerimiento REQ-4309 | sin asignar | se verifica en producción | — | aceptado | 2026-07-31 | — |
| REQ-4310 | Requerimiento REQ-4310 | Paula Céspedes | — | Cliente entrevistado | propuesto | 2026-06-21 | — |
| REQ-4311 | Requerimiento REQ-4311 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4312 | Requerimiento REQ-4312 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-14 | — |
| REQ-4313 | Requerimiento REQ-4313 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-01 | — |
| REQ-4314 | Requerimiento REQ-4314 | sin asignar | se verifica en producción | — | aceptado | 2026-08-20 | — |
| REQ-4315 | Requerimiento REQ-4315 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |

## Decisiones

- Se mantiene el plan
