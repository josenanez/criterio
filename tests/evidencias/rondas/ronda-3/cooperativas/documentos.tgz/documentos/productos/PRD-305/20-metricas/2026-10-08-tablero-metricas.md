# Tablero de métricas · Microcrédito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 125.525 | 2026-10-08 |
