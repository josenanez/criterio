# Comité de producto · Microseguros

**Fecha:** 2026-10-12
**Asistentes:** Jorge Medina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4901 | Requerimiento REQ-4901 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4902 | Requerimiento REQ-4902 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4903 | Requerimiento REQ-4903 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-05-28 | — |
| REQ-4904 | Requerimiento REQ-4904 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4905 | Requerimiento REQ-4905 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4906 | Requerimiento REQ-4906 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-04-18 | — |
| REQ-4907 | Requerimiento REQ-4907 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-18 | — |
| REQ-4908 | Requerimiento REQ-4908 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-19 | — |
| REQ-4909 | Requerimiento REQ-4909 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-04 | — |
| REQ-4910 | Requerimiento REQ-4910 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-10 | — |
| REQ-4911 | Requerimiento REQ-4911 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-04-06 | — |
| REQ-4912 | Requerimiento REQ-4912 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4913 | Requerimiento REQ-4913 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-2035 | Requerimiento REQ-2035 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-07 | — |

## Decisiones

- Se mantiene el plan
