# Entrevistas · Ahorro a la vista

**Ronda:** Ronda · 2025-10-27
**Realizadas por:** Sandra Gil

### Cliente entrevistado · 2025-10-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
