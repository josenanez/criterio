# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Javier Hoyos
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-08-01

## El problema

El segmento Microempresarios no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-03-23 · verificado

## Proyectos que lo construyen

- Ninguno declarado
