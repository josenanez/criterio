# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Diana Molina
**Segmento:** Pensionados
**Fecha de la definición:** 2026-02-13

## El problema

El segmento Pensionados no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-07-02 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
