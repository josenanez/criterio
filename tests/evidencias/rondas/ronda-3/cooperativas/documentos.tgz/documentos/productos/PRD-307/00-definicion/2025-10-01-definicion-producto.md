# Definición de producto · Auxilios de solidaridad

**Código:** PRD-307
**Gerente de producto:** Laura Vélez
**Segmento:** Microempresarios
**Fecha de la definición:** 2025-10-01

## El problema

El segmento Microempresarios no tiene auxilios de solidaridad.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-07-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
