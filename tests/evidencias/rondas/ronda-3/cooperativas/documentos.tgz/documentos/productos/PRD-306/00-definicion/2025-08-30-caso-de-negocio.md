# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-08-30
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 149.447 | Caso de negocio, 2025-08-30 |

## Retorno esperado

Retorno esperado en 24 meses.
