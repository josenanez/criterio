# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2025-10-01
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 125.107 | Caso de negocio, 2025-10-01 |

## Retorno esperado

Retorno esperado en 24 meses.
