# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2026-06-27
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 54.102 | Caso de negocio, 2026-06-27 |

## Retorno esperado

Retorno esperado en 24 meses.
