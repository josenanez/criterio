# Comité de producto · Microcrédito

**Fecha:** 2026-10-12
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-05-23 | — |
| REQ-4501 | Requerimiento REQ-4501 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4502 | Requerimiento REQ-4502 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-28 | — |
| REQ-4503 | Requerimiento REQ-4503 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-06 | — |
| REQ-4504 | Requerimiento REQ-4504 | Rubén Cárdenas | se verifica en producción | — | propuesto | 2026-07-28 | — |
| REQ-4505 | Requerimiento REQ-4505 | Felipe Arango | se verifica en producción | — | propuesto | 2026-05-12 | — |
| REQ-4506 | Requerimiento REQ-4506 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-31 | — |
| REQ-4507 | Requerimiento REQ-4507 | sin asignar | se verifica en producción | — | propuesto | 2026-03-21 | — |
| REQ-4508 | Requerimiento REQ-4508 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4509 | Requerimiento REQ-4509 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-10 | — |
| REQ-4510 | Requerimiento REQ-4510 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4511 | Requerimiento REQ-4511 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-03 | — |
| REQ-4512 | Requerimiento REQ-4512 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4513 | Requerimiento REQ-4513 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-19 | — |

## Decisiones

- Se mantiene el plan
