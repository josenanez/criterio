# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-06-09
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 88.638 | Caso de negocio, 2026-06-09 |

## Retorno esperado

Retorno esperado en 24 meses.
