# Informe de avance · Core cooperativo

**Código:** PRY-202
**Fecha de corte:** 2026-10-14
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **76%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.390.493.898 |
| Ejecutado | 876.426.100 |
| Proyección al cierre | 2.493.540.214 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Dependencia del proveedor del core cooperativo
