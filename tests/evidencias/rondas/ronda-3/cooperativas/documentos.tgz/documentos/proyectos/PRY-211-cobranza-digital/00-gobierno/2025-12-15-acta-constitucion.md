# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Crédito
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Natalia Ospina
**Comité:** Consejo de Administración
**Producto asociado:** recaudos
**Fecha de aprobación:** 2025-12-15

## Objetivo del negocio

Entregar cobranza digital para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Consejo de Administración el 2025-12-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-25 |
| Cierre | 2027-07-22 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
