# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Pagos con QR
**Fecha:** 2026-10-15
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +20 días sobre la línea base vigente |
| Costo | 40.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
