# Comité de Educación · Apertura de ahorro en línea

**Fecha:** 2026-10-12
**Asistentes:** Jorge Medina, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 17 | 2026-11-05 |
