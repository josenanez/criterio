# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Tarjeta débito para asociados
**Fecha:** 2026-10-09
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +112 días sobre la línea base vigente |
| Costo | 224.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
