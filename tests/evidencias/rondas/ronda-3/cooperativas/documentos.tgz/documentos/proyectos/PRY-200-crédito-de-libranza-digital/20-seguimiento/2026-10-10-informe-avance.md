# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Andrés Lozano

## Estado declarado

**Amarillo**

Avance reportado: **74%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 479.424.471 |
| Ejecutado | 151.498.076 |
| Proyección al cierre | 823.042.967 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
- Concentración del conocimiento en una sola persona
