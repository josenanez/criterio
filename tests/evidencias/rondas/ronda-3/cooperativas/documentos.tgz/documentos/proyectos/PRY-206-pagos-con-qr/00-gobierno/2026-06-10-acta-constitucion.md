# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Bienestar social
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Riesgos
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-06-10

## Objetivo del negocio

Entregar pagos con qr para Bienestar social.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2026-06-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-20 |
| Cierre | 2027-07-05 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
