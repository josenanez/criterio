# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-04
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +33 días sobre la línea base vigente |
| Costo | 66.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
