# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Core cooperativo
**Fecha:** 2026-10-02
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +119 días sobre la línea base vigente |
| Costo | 238.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
