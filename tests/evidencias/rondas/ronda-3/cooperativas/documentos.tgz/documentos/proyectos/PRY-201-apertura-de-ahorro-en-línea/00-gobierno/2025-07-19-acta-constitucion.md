# Acta de constitución · Apertura de ahorro en línea

**Código:** PRY-201
**Área dueña:** Servicio al asociado
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Educación
**Producto asociado:** ahorro a la vista
**Fecha de aprobación:** 2025-07-19

## Objetivo del negocio

Entregar apertura de ahorro en línea para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Educación el 2025-07-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-29 |
| Cierre | 2026-12-11 |

## Criterio de éxito

Apertura de ahorro en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
