# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Convenios de libranza con empresas
**Fecha:** 2026-10-08
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +43 días sobre la línea base vigente |
| Costo | 86.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
