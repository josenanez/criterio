# Consejo de Administración · Core cooperativo

**Fecha:** 2026-10-15
**Asistentes:** Camilo Beltrán, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 35 | 2026-10-27 |
