# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-10-01
**Asistentes:** Carlos Peña, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-19 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-15 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-14 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-13 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 |
| Sandra Gil | Enviar el documento 9 | 2026-10-26 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-08 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-19 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-18 |
| María Restrepo | Confirmar la fecha 15 | por definir |
| Felipe Arango | Entregar el punto 16 | por definir |
| Carlos Peña | Enviar el documento 17 | 2026-10-09 |
| Jorge Medina | Cerrar la prueba 18 | 2026-10-17 |
| Natalia Ospina | Revisar el anexo 19 | por definir |
| Jorge Medina | Validar el ambiente 20 | 2026-10-11 |

## Lo que se dijo

- Diana Molina dice que ya entregó «aprobar el diseño 13». No se presentó acta.
