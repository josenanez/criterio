# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-07
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +27 días sobre la línea base vigente |
| Costo | 54.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
