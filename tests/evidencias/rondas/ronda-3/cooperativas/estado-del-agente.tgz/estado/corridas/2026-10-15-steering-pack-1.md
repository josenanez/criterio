# Corrida del 2026-10-15 · steering-pack

13 proyectos · 70 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Paquete de comité del 2026-10-22: 6 decisiones, 6 escalamientos. No sé: decisiones del comité anterior (sin registro), autoridad de cambios (0 de 13 declarada), solicitante y motivo de cada CC, si las facturas se pagaron, si la salida a producción de PRY-205 ocurrió.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Cargué las fichas de `estado/records/` (13 proyectos, selladas el 2026-10-15) y recalculé con `portafolio.py compute` al 2026-10-15. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos otra vez. Los demás datos que pedía el comando los tomé con la respuesta sugerida; nadie contestó en esta sesión.

# Comité de proyectos — 2026-10-22 (próximo comité según la configuración; material preparado el 2026-10-15)
6 decisiones · 6 escalamientos · 10 proyectos con hallazgos (de 13)

## Decisiones del comité anterior
No hay registro. Ninguna ficha trae decisiones de comité con fecha ni acta, y esta es la primera corrida de `steering-pack`. No puedo decir qué se decidió antes ni qué se hizo con eso. Lo más cercano son tres solicitudes de cambio que las fichas marcan como «aprobadas» por «el comité» sin nombre ni fecha de sesión (PRY-202, PRY-205, PRY-206); van en la decisión 1.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro en las fichas | — | — | No consta |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base en el portafolio, y el comité ratifica o rechaza los tres cambios ya «aprobados» sin firma?
**Proyecto:** los 13 (`identity.authority` no encontrado en ninguno) · **Quién decide:** el comité mismo; es el primer punto porque sin él los puntos 2 a 4 no tienen a quién dirigirse · **Si no se decide hoy:** las solicitudes pendientes siguen sin destinatario y las líneas base siguen moviéndose por una frase.

Aprobadas por «el comité», sin que el documento diga cuál ni quién firma:
- PRY-202 CC-01: +119 días, 238.000.000 COP.
- PRY-205 CC-01: +27 días, 54.000.000 COP adicionales.
- PRY-206 CC-01: +20 días, 40.000.000 COP adicionales; además la línea base no se registró como nueva (señal `change_without_baseline`).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Designar por escrito una autoridad de cambios (nombre y tope) y ratificar los tres CC con firma | Ampliaciones de alcance quedan avaladas | Quedan +119, +27 y +20 días en sus líneas base | Quedan 238.000.000, 54.000.000 y 40.000.000 COP |
| B. Designar autoridad y devolver los tres CC para que se vuelvan a presentar con firma | Ampliaciones suspendidas | Las líneas base vuelven a las anteriores hasta que haya firma | Sin sobrecosto hasta la firma |
| C. Mantener la situación | Sin cambio | Sin cambio | Sin cambio |

**Recomendación:** A, y que la designación sea el primer acuerdo del acta. Razón: B castiga a tres proyectos por un vacío de gobierno que no es suyo; C deja cada decisión de los puntos siguientes sin respaldo. Si el comité no reconoce esas aprobaciones, sería B. No sé quién autorizó realmente; eso lo sabe el comité.

### [2] PRY-204 Tarjeta débito — CC-01 (solicitado 2026-10-09): ¿aprobar +112 días y 224.000.000 COP?
**Proyecto:** PRY-204 · **Quién decide:** sin autoridad declarada, va a comité (ver [1]) · **Si no se decide hoy:** la fecha de cierre ya está en 2027-07-07, es decir 112 días contra la línea base original (32,2 %), movida sin autorización (`rebaseline_unauthorized`: 112 movidos, 0 autorizados). El informe del 2026-10-15 lo declara en verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación de alcance | Cierre 2027-07-07 queda como línea base | +224.000.000 COP sobre aprobado 9.500.000.000; ya comprometido 8.176.188.289 (86,1 %), disponible real 1.323.811.711 |
| B. Rechazar | Sin ampliación | Cierre vuelve al de la línea base original | Sin sobrecosto |
| C. Aprobar con condiciones (evidencia del hito «Diseño funcional aprobado», declarado cumplido sin evidencia, 79 días vencido) | Ampliación condicionada | +112 días diferidos hasta la evidencia | Se libera al cumplirse la condición |

**Recomendación:** C. Razón: el hito de diseño funcional figura como cumplido sin documento y la ampliación se apoya en él. No sé el motivo que dio el solicitante; no consta en la ficha.

### [3] PRY-208 Motor de crédito — CC-01 (solicitado 2026-10-04): ¿aprobar +33 días y 66.000.000 COP?
**Proyecto:** PRY-208 · **Quién decide:** sin autoridad declarada, va a comité · **Si no se decide hoy:** cierre 2027-07-25 ya movido 33 días (6,8 %) sin autorización. Declarado en verde (2026-10-11).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación de alcance | +33 días, cierre 2027-07-25 | +66.000.000 COP sobre aprobado 800.000.000; proyección actual 744.661.313 (−6,9 %) |
| B. Rechazar | Sin ampliación | Cierre vuelve al de la línea base original | Sin sobrecosto |

**Recomendación:** A, con la regularización de la línea base. Razón: la proyección está por debajo del aprobado y el cambio es de los más pequeños; el problema es el procedimiento, no la cifra. Limitación: el hito de diseño funcional (72 días vencido) también figura cumplido sin evidencia.

### [4] PRY-209 Convenios de libranza — CC-01 (solicitado 2026-10-08): ¿aprobar +43 días y 86.000.000 COP, con el proveedor facturado sin entregar?
**Proyecto:** PRY-209 · **Quién decide:** sin autoridad declarada, va a comité · **Si no se decide hoy:** cierre 2027-03-17 ya movido 43 días (10,7 %) sin autorización. Declarado en rojo.
Contexto que cambia la lectura: el proveedor Soluciones Solidarias S.A.S. (CT-901) facturó 1.882.339.743 COP con 0 entregables aceptados de 4, y 3 vencidos: licenciamiento del módulo (204 días), bolsa de horas de desarrollo (115) y parametrización de líneas de crédito (27).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar el CC sin condiciones | Ampliación de alcance | +43 días | +86.000.000 COP sobre aprobado 18.000.000.000 |
| B. Aprobar condicionado a un plan de entrega del proveedor con fechas y a no pagar más facturas hasta recibir | Ampliación de alcance | +43 días | +86.000.000 COP; frena nuevos pagos |
| C. Rechazar | Sin ampliación | Cierre vuelve al original | Sin sobrecosto, pero el proveedor sigue en mora |

**Recomendación:** B. Razón: ampliar plazo y alcance mientras lo ya facturado no se ha recibido le da más tiempo a quien no ha entregado. No sé si la factura se pagó; la ficha dice «facturado», no «pagado».

### [5] PRY-205 Prevención de lavado — proveedor Red Rural de Pagos (CT-869): ¿qué se hace con 241.126.726 COP facturados por encima de lo aceptado?
**Proyecto:** PRY-205 · **Quién decide:** sin autoridad declarada, va a comité · **Si no se decide hoy:** el sobrefacturado sigue abierto (facturado 1.396.951.861 contra aceptado 1.155.825.135 COP) y el acta de recibo de «Parametrización de líneas de crédito» sigue sin aparecer.
Dato adicional: 5 de 5 hitos «cumplidos» sin evidencia, entre ellos «Salida a producción» (fecha vigente 2026-06-23, 114 días vencida), y el avance declarado de 75 % queda 25 puntos por debajo de lo que el plan sustenta.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir nota crédito o acta de aceptación de lo facturado de más | Sin cambio | Sin cambio | Recupera hasta 241.126.726 COP |
| B. Aceptar el valor facturado y documentar el recibo | Sin cambio | Sin cambio | Cierra la diferencia sin recuperar |
| C. Retener pagos del contrato hasta aclarar | Sin cambio | Posible fricción con el proveedor | Sin pago adicional |

**Recomendación:** A, y que el gerente aporte primero si la salida a producción ocurrió. Razón: si no hay acta, no se puede sostener ni aceptar el pago. La cifra de 1.155.825.135 sale de la ficha y no la pude contrastar con un acta de recibo.

### [6] PRY-206 Pagos con QR — ¿cómo se cubre la proyección que supera el aprobado en 26,4 %?
**Proyecto:** PRY-206 · **Quién decide:** sin autoridad declarada, va a comité · **Si no se decide hoy:** la proyección es 3.033.676.286 COP contra 2.400.000.000 aprobados; lo ejecutado (821.233.249) ya supera lo comprometido (720.144.603), y el proyecto sigue en amarillo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar el presupuesto aprobado | Se mantiene | Sin cambio (cierre 2027-06-12) | Aprobado pasa a la proyección, 3.033.676.286 COP |
| B. Recortar alcance para volver al aprobado | Se reduce | Posible ajuste | Se mantiene 2.400.000.000 COP |
| C. Pedir al gerente un plan de contención antes de decidir | Sin cambio | Una semana más | Sin definición |

**Recomendación:** C para el 2026-10-22, con A o B decididas en esa sesión. Razón: la ficha no dice de dónde sale el exceso ni cuánto lo explica el CC-01 de 40.000.000 COP; con 26,4 % no se amplía a ciegas. No sé el motivo del desvío.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-203 Aportes sociales | Declarado verde, con 7 compromisos vencidos, 3 sin fecha y 2 reprogramados 6 y 5 veces (María Restrepo: original 2026-09-21; Paula Céspedes: original 2026-09-13). Avance declarado 60 % contra 100 % sustentado por el plan; 4 hitos cumplidos sin evidencia. Fecha de cierre vigente 2026-06-05 | Compromiso más antiguo vencido desde 2026-09-15 | Que el gerente corrija el estado o presente un plan de recuperación con fechas firmes |
| PRY-201 Apertura de ahorro en línea | Declarado rojo, 27 % contra 75–100 % del plan; 2 hitos cumplidos sin evidencia. Cierre vigente 2026-10-16. Ficha con datos de identidad de 15 meses | Cierre vigente 2026-10-16 | Dónde está el proyecto frente a su fecha, y si hay una solicitud de cambio que nadie presentó |
| PRY-202 Core cooperativo | Declarado verde; cierre vigente 2026-07-06 (ya pasado), 76 % declarado contra 100 % sustentado; 3 hitos cumplidos sin evidencia. Desviación 119 días (41,6 %) contra la original | Cierre vigente 2026-07-06 | Fecha real de cierre o nueva solicitud |
| PRY-207 Microcrédito rural | Declarado rojo (81 %); cierre vigente 2026-10-15; ejecutado 5.227.286.494 supera lo comprometido 4.013.515.654; 10 días sin movimiento | 2026-10-05 (último informe) | Estado real al cierre; por qué lo ejecutado supera lo comprometido |
| PRY-210 Corresponsales rurales | Declarado amarillo, 25 % contra 75–100 %; 3 hitos cumplidos sin evidencia; compromiso de Elena Duarte vencido hace 20 días. Cierre 2026-11-30 | 2026-09-25 | Si el 25 % o los hitos están mal |
| PRY-200 Crédito de libranza digital | Declarado 74 % contra 25–50 % sustentado (adelantado); hito «Diseño funcional aprobado» cumplido sin evidencia, 103 días vencido | 2026-07-04 | Documento que acredite el hito, o corregir el 74 % |

## Para conocimiento
- PRY-199 Cambio de mobiliario: verde, sin señales; 20 % declarado, dentro del rango del plan. Sin fase ni autoridad en la ficha.
- PRY-211 Cobranza digital: sin señales; 10 días sin informe (último 2026-10-05, verde, 39 %).
- Los otros 11 proyectos están en las decisiones o escalamientos de arriba.
- Totales del cálculo: 13 proyectos, 10 con alertas, 64 alertas, 5 verdes contradichos por la evidencia (PRY-202, 203, 204, 205, 208), 8 productos.

## Anexo
**Estado por proyecto (declarado → evidencia).** Ninguna ficha tiene evidencia primaria: en las 13 `sources.evidence` es 0; todo es declaración o documento sin marcar.
- Verdes contradichos: PRY-202, 203, 204, 205, 208.
- Rojo declarado: PRY-201, 207, 209. Amarillo declarado: PRY-200, 206, 210.

**Contradicciones abiertas:**
- Hitos «cumplidos» sin evidencia en 10 proyectos (PRY-200, 201, 202, 203, 204, 205, 206, 208, 209, 210).
- PRY-209: hito de pruebas cumplido, y a la vez licenciamiento, bolsa de horas y parametrización vencidos sin entrega.

**Vacíos de información:**
- Autoridad de cambios: falta en los 13.
- Fase (`identity.phase`): falta en PRY-199, 200, 201, 205, 206, 207, 208, 209, 210, 211.
- Producto (`identity.product`) vacío en PRY-202, 205, 208, 209, 210.
- Datos de identidad con 12 meses o más (umbral de la configuración): PRY-201 (15), PRY-202 (17), PRY-203 (12), PRY-205 (13).
- Dependencias entre proyectos: ninguna declarada en las 13, así que no puedo decir si una decisión de este paquete afecta a otro proyecto. Eso no significa que no exista.
- PRY-203 trae además `pm_record.declared.status` faltante.
- Qué se decidió en el comité anterior: no consta.
- Quién solicitó cada CC y su motivo: no consta en la ficha.
- Ningún proyecto supera el umbral de 15 días de silencio (el máximo son 10); el criterio de «dos períodos sin movimiento» no se pudo evaluar sin comités anteriores registrados.

**Pie:** versión de la familia 0.3.9 · plugin criterio-portfolio, términos 1.1 aceptados el 2026-10-15 · fichas aplicadas: `estado/records/PRY-199` a `PRY-211` (selladas 2026-10-15) · campos inciertos: autoridad de cambios (13/13), solicitante y motivo de cada CC, estado real de la salida a producción de PRY-205, pago real de las facturas de CT-901 y CT-869 · esto es un borrador de trabajo, no una decisión ni asesoría; la verificación es suya · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
