# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 79 documentos, 0 releídos y 79 sin cambio · 59 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

El informe quedó en `/home/claude/banco/ronda-3/cooperativas/espacio/reportes/index.html`.

5 proyectos en verde contradichos por la evidencia; PRY-203 concentra 18 de 64 señales; sin delta (misma fecha que el barrido)

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 10 con hallazgos (64 señales) · último barrido 2026-10-15 (13 fichas, todas de hoy, ninguna vencida)

Términos vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15). Criterio produce borradores de trabajo, no decisiones; cada dato lleva la cita de su documento y la verificación es suya. Términos completos: https://www.josenanez.com/es/agents/criterio-pmo/legal

## Qué cambió desde la corrida anterior
Sin cambios desde la instantánea del 2026-10-15: es la misma fecha del barrido, así que el diff devolvió 0 cambios. Esto es el punto de partida, no hay delta que reportar.

## Contradicciones abiertas
No extraje la lista campo por campo en esta corrida; el detalle con las dos fuentes y fechas está en `reportes/index.html` (vista por campo). La contradicción que sí está calculada es la de estado: **5 proyectos declaran verde y la evidencia lo contradice** (ver Estado general).

## Hitos vencidos sin evidencia
Hitos vencidos sin cumplir: ninguno. Hitos declarados cumplidos **sin evidencia** (22 señales). Los más antiguos y los proyectos con más:
| Proyecto | Hitos cumplidos sin evidencia | Más antiguo |
|---|---|---|
| PRY-205 Prevención de lavado de activos | 5 | Diseño funcional, 325 días |
| PRY-203 Aportes sociales en línea | 4 | Diseño funcional, 316 días |
| PRY-202 Core cooperativo | 3 | Ambiente de pruebas, 363 días |
| PRY-210 Corresponsales rurales | 3 | Diseño funcional, 179 días |
| PRY-201 Apertura de ahorro en línea | 2 | Diseño funcional, 332 días |
| PRY-200, 204, 206, 208, 209 | 1 cada uno | PRY-209: 131 días |

## Proyectos en silencio
Vacía. Ninguno supera el umbral de 15 días; el más callado es PRY-207 y PRY-211 (10 días cada uno).

## Dependencias en riesgo
Sin dependencias en riesgo marcadas por el cómputo.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | 74 % de avance | El plan sostiene 25–50 % (1 de 4 hitos) |
| PRY-204 | 74 % | El plan sostiene 33–67 % |
| PRY-208 | 74 % | El plan sostiene 33–67 % |
| PRY-206 | 50 % | Plan 25–50 %: en el límite, pero sin evidencia del diseño |

Al revés, declaran **menos** de lo que el plan sostiene: PRY-201 (27 % vs 75–100 %), PRY-210 (25 % vs 75–100 %), PRY-203 (60 % vs 100 %), PRY-202 (76 % vs 100 %), PRY-205 (75 % vs 100 %): reportan poco o el plan marca hitos que nadie sustenta; hay que confirmar cuál.

## Vacíos de información
Los 13 proyectos no tienen autoridad (patrocinador) identificada en la ficha. PRY-202, 205, 208, 209 y 210 no están asociados a ningún producto. El detalle de campos faltantes y vencidos está en las páginas por proyecto.

## Estado general
| Proyecto | Declarado | Sustento | vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-202 Core cooperativo | verde | contradicho | +119 d (41,6 %) | 0 | 1 |
| PRY-203 Aportes sociales | verde | contradicho: 7 compromisos vencidos, 2 reprogramados 5–6 veces | 0 | 0 | 0 |
| PRY-204 Tarjeta débito | verde | contradicho: +112 d sin autorización | +112 d (32,2 %) | 0 | 1 |
| PRY-205 Prevención LA | verde | contradicho: 5 hitos sin evidencia, factura sobre lo aceptado | +27 d (11,7 %) | 0 | 1 |
| PRY-208 Motor de crédito | verde | contradicho: +33 d sin autorización | +33 d | 0 | 1 |
| PRY-206 Pagos con QR | — | proyección de costo +26,4 % ($3.033.676.286 vs $2.400.000.000); cambio CC-01 (+20 d) sin línea base | +20 d | 0 | 1 |
| PRY-209 Convenios de libranza | — | proveedor Soluciones Solidarias: 3 entregables atrasados y $1.882.339.743 facturados sin entrega | +43 d (10,7 %) | 0 | 1 |
| PRY-200, 201, 210 | — | solo desfase de avance | 0 | 0 | 0 |
| PRY-199, 207, 211 | — | sin señales | 0 | 0 | 0 |

Lo que más pesa: PRY-203 concentra 18 de las 64 señales; PRY-204, 208 y 202 rebasaron fechas sin cambio aprobado.

## Necesito que confirmes
Este mes toca la confirmación de cinco campos, pero la sesión es sin interfaz y no se hicieron preguntas. Quedan pendientes y no los inventé: 1) ¿quién es el patrocinador de cada proyecto (13 sin autoridad)? 2) ¿a qué producto pertenecen PRY-202, 205, 208, 209 y 210? 3) ¿se autorizó el corrimiento de PRY-204 (+112 d) y PRY-208 (+33 d)? 4) ¿hay acta de aceptación del diseño funcional de PRY-205 y PRY-203? 5) ¿se aprobó el CC-01 de PRY-206?

## Informe generado
- `reportes/index.html` — por campo, con cadena de evidencia completa; para quien va a actuar.
- `reportes/decisiones.html` — por decisión; para el patrocinador y el comité del 2026-10-22.
- Una página por proyecto. 25 páginas en total. Para PDF, imprimir el HTML.
Carpeta: `/home/claude/banco/ronda-3/cooperativas/espacio/reportes`

---
Criterio Portfolio 0.3.9 · fichas aplicadas: 13, fecha 2026-10-15 · campos inciertos: contradicciones de campo no desglosadas aquí (ver index.html) · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
