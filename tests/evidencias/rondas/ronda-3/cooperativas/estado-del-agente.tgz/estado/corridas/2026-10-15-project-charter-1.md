# Corrida del 2026-10-15 · project-charter

13 proyectos · 30 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Revisión del acta PRY-207 (2025-12-22): falta autoridad del gerente, hitos, supuestos/restricciones, cadencia; objetivo, alcance, exclusiones y criterio de éxito son marcadores sin medida; acta dice sin dependencias y el informe declara la del core. No sabe si hay autoridad delegada fuera de los dos documentos ni por qué reporta al Comité de Educación.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Acta previa: **sí existe**, aprobada el 2025-12-22 (`PRY-207-microcrédito-rural/00-gobierno/2025-12-22-acta-constitucion.docx`). Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15.

## Acta — PRY-207 Microcrédito rural
**Estado:** existe, del 2025-12-22

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance o fecha decide Felipe Arango sin comité. | El informe del 2026-10-05 declara una reprogramación de la salida y no da fecha nueva. Sin autoridad escrita no se sabe si Felipe podía reprogramar solo o debió subir al Comité; cualquier decisión de plata o fecha de este proyecto termina en el comité por defecto. |
| Objetivo de negocio | Presente pero vacío: "Entregar microcrédito rural para Riesgo y Cumplimiento" describe la entrega, no un resultado. Sin cifra. | No hay contra qué juzgar si el proyecto valió lo que se gastó, aunque llegue a producción. |
| Alcance | Es un marcador: "Componente 1, Componente 2, Componente 3". | No se puede decir qué es un cambio de alcance. El 81% de avance reportado no se puede verificar contra componentes que no están nombrados. |
| Exclusiones | Es un marcador: "Lo que otro proyecto cubre". No nombra proyecto ni tema. | Si algo se discute en el cierre, no hay lista contra la cual decir "esto nunca estuvo". Con el core (PRY-202) como dependencia real, el límite entre ambos queda sin escribir. |
| Patrocinador | Gustavo Neira (persona con nombre). Cumple. | — |
| Comité y cadencia | Comité de Educación, sin cadencia. El área dueña es Riesgo y Cumplimiento y el producto es crédito: no se ve por qué lo gobierna un comité de educación. No lo sustento ni lo descarto; el acta no lo explica. | Si el comité no es el que corresponde, las decisiones de este proyecto podrían estar yendo a la mesa equivocada. Sin cadencia, nadie sabe cuándo se revisa. |
| Supuestos y restricciones | **No hay sección.** | Las dos cosas que hoy el informe llama riesgos (concepto del supervisor, aprobación del reglamento por el Consejo) son por naturaleza supuestos del plan que nunca se declararon, así que nadie los vigilaba. |
| Dependencias | El acta dice "Ninguna declarada". El informe del 2026-10-05 lista como riesgo la "dependencia del proveedor del core cooperativo". | Contradicción entre documentos: la dependencia existe y el acta dice que no. Quien planeó con el acta no tenía ese frente en el cronograma. |
| Criterio de éxito | "Microcrédito rural en producción y medido." No dice qué se mide, con qué umbral ni quién lo mide. | El proyecto podría declararse exitoso con un solo desembolso. Nadie queda a cargo de decir que no se cumplió. |
| Hitos principales | **No hay.** (La ficha tiene `milestones` vacío.) | Solo hay inicio (2026-01-01) y cierre (2026-10-15). El cierre es hoy y no hay hitos intermedios contra los cuales haber medido el atraso. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar microcrédito rural para Riesgo y Cumplimiento" (acta, sección *Objetivo del negocio*).
**Alcance:** pendiente de definir. El acta dice "Componente 1, 2 y 3" sin nombrarlos (acta, *Alcance*).
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre", sin nombrar cuál (acta, *Fuera de alcance*).
**Patrocinador:** Gustavo Neira · **Gerente:** Felipe Arango (acta).
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento.
**Comité al que reporta:** Comité de Educación (acta) · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 9.500.000.000 COP, Comité de Educación, 2025-12-22 (acta).
**Supuestos:** pendiente de definir. No hay sección. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Microcrédito rural en producción y medido" (acta); sin métrica ni umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo inicio 2026-01-01 y cierre 2026-10-15 (acta).

Dato del informe de avance del 2026-10-05 que agrava lo anterior: estado declarado rojo, 81% de avance, salida reprogramada sin fecha nueva. La fecha de cierre del acta es hoy (2026-10-15).

## Lo que no sé
- Si existe una autoridad del gerente fuera de estos dos documentos (reglamento de la PMO, delegación del comité). Solo revisé el acta y el informe de avance; no vi nada más en la carpeta del proyecto.
- Por qué el proyecto reporta al Comité de Educación.
- Qué son los componentes 1, 2 y 3.

## Siguiente paso
El acta quedó sin autoridad declarada. Te ofrezco llevar esa definición al comité (próximo 2026-10-22): es una decisión, no un trámite. También puedo pasar al registro RAID los dos supuestos que salen de esta revisión (concepto del supervisor y aprobación del reglamento por el Consejo) y la dependencia del core que el acta niega. No ejecuté ninguna de las dos.

*Pie de rigor: borrador de trabajo basado en dos documentos del proyecto; cada dato lleva su fuente. La verificación es suya.*
