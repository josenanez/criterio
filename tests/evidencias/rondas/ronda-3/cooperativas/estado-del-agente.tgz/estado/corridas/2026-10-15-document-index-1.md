# Corrida del 2026-10-15 · document-index

13 proyectos · 10 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

79 documentos sin cambio, 0 por releer. 7 citas de identidad de PRY-203 apuntan a un acta de constitución que no resuelve; no se sabe por qué (no figura como borrada ni renombrada).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 79 · **Sin cambio:** 79 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ningún documento.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.name | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.business_area | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.product | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.sponsor | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.manager | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.committee | 00-gobierno/2025-10-09-acta-constitucion.md |

Las siete citas de la identidad de PRY-203 apuntan al mismo documento, el acta de constitución, que no resuelve. No aparece como borrado ni como renombrado en el índice: la ficha cita una ruta que no existe en la carpeta. La ficha sigue mostrando esos datos como sustentados y ya no lo están. Hay que ubicar el acta o corregir la ruta citada.

### Formatos que no se pudieron leer
Ninguno.

Nada que releer, así que no hay barrido que ofrecer: `projects_to_recompute` está vacío.
