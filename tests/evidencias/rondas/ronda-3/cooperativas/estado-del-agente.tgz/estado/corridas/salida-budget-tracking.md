Salgo de la ficha PRY-206 (estado/records/PRY-206.json) y del recálculo de `portafolio.py compute` del 2026-10-15. Documentos: acta de constitución (2026-06-10), informe de avance (2026-10-12), cronogramas v1 (2026-06-10) y v2 (2026-10-12), solicitud de cambio CC-01 (2026-10-15).

## Presupuesto — PRY-206 Pagos con QR al 2026-10-15
**Moneda:** COP (única; no hubo conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | — | 00-gobierno/2026-06-10-acta-constitucion.md | 2026-06-10 |
| Comprometido | 720.144.603 | 30,0 % | 20-seguimiento/2026-10-12-informe-avance.pdf (declaración) | 2026-10-12 |
| Ejecutado | 821.233.249 | 34,2 % | 20-seguimiento/2026-10-12-informe-avance.pdf (declaración) | 2026-10-12 |
| Proyección al cierre | 3.033.676.286 | 26,4 % por encima del aprobado | 20-seguimiento/2026-10-12-informe-avance.pdf (declaración) | 2026-10-12 |

**Disponible real** (aprobado menos comprometido): 1.679.855.397 COP, tal como lo calcula el script. Ver la primera alerta: esta cifra puede estar sobrestimada.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 2.400.000.000 (acta, 2026-06-10) | no_encontrado: ningún documento registra una línea base de costo nueva | no calculable |
| Fecha de fin (como referencia) | 2027-05-23 (v1) | 2027-06-12 (v2) | +20 días, 5,9 % |

Replanificaciones de presupuesto: 0 registradas. La única replanificación (1) es de cronograma: v2, 2026-10-12, sin motivo declarado.

### Ejecución frente a avance
Ejecutado 34,2 % · Hitos cumplidos 1 de 4 · El avance declarado es 50 %, y el plan sustenta entre 25 y 50 %. El gasto no va por delante del avance. El único hito cumplido, «Diseño funcional aprobado» (2026-09-12), no tiene evidencia (hace 33 días), así que el avance de 50 % descansa en una declaración.

### Alertas
1. **Proyección por encima del aprobado, 26,4 %** (umbral 10 %): 3.033.676.286 contra 2.400.000.000. Pasa el umbral de desviación de costo. El informe de avance del 2026-10-12 no explica este exceso: el script lo marca como señal sin contabilizar.
2. **Comprometido menor que ejecutado** (720.144.603 contra 821.233.249). Normalmente lo comprometido incluye lo ejecutado. No sé si el informe reporta el comprometido solo como lo pendiente de causar. Si es así, el comprometido total sería mayor y el disponible real menor que 1.679.855.397. No lo corrijo: lo dejo señalado para que lo confirme quien emitió el informe.
3. **CC-01 aprobada sin línea base nueva.** Agrega 40.000.000 COP de costo y +20 días, con decisión «el comité» sin decisor identificado. No hay línea base de costo posterior. No sé si la proyección de 3.033.676.286 ya incluye esos 40.000.000.
4. **La proyección es más vieja que el último movimiento de presupuesto.** Es del 2026-10-12 y CC-01 es del 2026-10-15.
5. Umbral de comprometido (90 %): no se cruza, está en 30,0 %.

### Sin dato
- Presupuesto vigente después de CC-01: no_encontrado.
- Motivo de la replanificación v2: no_encontrado.
- Si el comprometido incluye lo ejecutado: no declarado.
- Si la proyección incluye CC-01: no declarado.
- Evidencia del hito «Diseño funcional aprobado»: no_encontrado.
- Proveedores y contratos: ninguno en la ficha, así que no hay detalle por proveedor ni otra moneda.
- Fuentes: de las cifras de dinero, solo el aprobado viene de un documento de gobierno. Comprometido, ejecutado y proyección son declaraciones de un informe de avance en PDF, sin contraste con registros contables.

**Siguiente paso posible:** como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto (CC-01 solo cubre 40.000.000 de una brecha de 633.676.286 que ya muestra la proyección).

*Pie de rigor: borrador de trabajo, no asesoría. Toda cifra viene de la ficha y de `portafolio.py compute`; la verificación contra los documentos es de quien lo use.*
