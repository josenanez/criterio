# Corrida del 2026-10-15 · product-view

13 proyectos · 27 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Producto con un solo proyecto (PRY-200): 2 señales (avance declarado 74% vs 25-50% sustentado; hito sin evidencia). 5 proyectos sin producto declarado; no sé si PRY-208/PRY-209 sirven a libranza. Área dueña no consta en las fichas.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Vista por producto: **crédito de libranza**. Sale de las fichas del portafolio, calculadas al 2026-10-15. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15.

## Productos al 2026-10-15

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| crédito de libranza | 1 (PRY-200) | 2 señales | 2027-06-10 | COP 800.000.000 | COP 479.424.471 |

**El producto tiene un solo proyecto declarado (PRY-200 Crédito de libranza digital).** La vista por producto no suma nada sobre la ficha del proyecto, así que no armo sección de producto. Esto es lo que dice la ficha:

- **Fecha comprometida:** 2027-06-10, sin replanificaciones (0) y sin desviación contra la línea base (0 días).
- **Señal 1, avance declarado sin sustento:** el informe del 2026-10-10 declara 74 % de avance. El plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplidos). La diferencia es de 24 puntos a favor de lo declarado.
- **Señal 2, hito cumplido sin evidencia:** «Diseño funcional aprobado», vencido el 2026-07-04 (hace 103 días), figura como cumplido y no hay documento que lo sustente.
- **Estado declarado:** amarillo. El informe no da cuenta de ninguna de las dos señales. De las fuentes de la ficha, 0 son evidencia, 2 son declaración y 15 no están marcadas.
- **Dinero (el proyecto trae las cuatro cifras, 1 de 1):**
  - Aprobado: COP 800.000.000.
  - Comprometido: COP 479.424.471 (59,9 %).
  - Ejecutado: COP 151.498.076 (18,9 %).
  - Proyección: COP 823.042.967, un 2,9 % por encima de lo aprobado, por debajo del umbral de 10 %.
- **Sin señal:** no tiene compromisos vencidos ni sin fecha, ni cambios, ni proveedores registrados. El último movimiento tiene 5 días (el umbral de silencio es 15).
- **Campos que faltan en la ficha:** `identity.authority` (quién aprueba) y `identity.phase`.
- **Dependencias internas:** ninguna declarada. Con un solo proyecto no hay cruce posible dentro del producto.

### Proyectos sin producto declarado

Son 5 de 13. Nadie puede responder por el conjunto al que sirven. Dos de ellos tienen nombre de crédito o de libranza, pero la ficha no dice que sirvan a este producto y no lo asumo.

| Proyecto | Área dueña | Alertas |
|---|---|---|
| PRY-202 Core cooperativo | no consta en la ficha | 6 |
| PRY-205 Prevención de lavado de activos | no consta en la ficha | 11 |
| PRY-208 Motor de crédito | no consta en la ficha | 4 |
| PRY-209 Convenios de libranza con empresas | no consta en la ficha | 7 |
| PRY-210 Corresponsales rurales | no consta en la ficha | 4 |

Los demás proyectos de otros productos no cambian esta vista.

**Lo que no sé:** si PRY-208 y PRY-209 pertenecen a «crédito de libranza». Si es así, el producto tendría tres proyectos y no uno. En ese caso la fecha del producto, la suma de dinero y las dependencias cambiarían, y PRY-209 aportaría señales graves: 43 días de desvío sin autorizar y facturación de COP 1.882.339.743 sin entregables recibidos. Antes de calcular nada, el dueño del producto tiene que declarar el producto en esas dos fichas.

**Decisión para el comité (22 de octubre):** asignar producto a los 5 proyectos sin declarar. Es una sola decisión, no cinco puntos de proyecto.

---
Pie de rigor: cifras copiadas de `portafolio.py compute` al 2026-10-15; dato no confirmado por el gerente ni verificado contra documentos externos a las fichas. Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación es suya.
