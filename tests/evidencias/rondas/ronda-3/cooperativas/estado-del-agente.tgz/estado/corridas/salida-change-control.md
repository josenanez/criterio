Sale de la ficha `estado/records/PRY-205.json` (sellada el 2026-10-15). Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos otra vez.

## Solicitud de cambio — PRY-205 Prevención de lavado de activos — 2026-10-15

**Qué se pide:** mover la «Salida a producción» 30 días. · **Quién lo pide:** no consta; la petición llegó por la invocación, sin solicitante. · **Por qué:** no consta; no hay motivo escrito.

**Antes de evaluar, un hallazgo que cambia la lectura.** La fecha vigente de salida a producción es **2026-06-23** y la nueva sería **2026-07-23**. Las dos son anteriores a hoy (2026-10-15). La ficha marca ese hito como «cumplido» (`met`) **sin evidencia** (114 días vencido), y el informe de avance del 2026-10-14 declara 75 % de avance. O la salida ya ocurrió y no hay nada que mover, o no ocurrió y el cronograma v2 (aprobado el 2026-10-14) ya nació con una fecha pasada. Esta solicitud no se puede aprobar tal como está escrita hasta aclarar cuál de las dos es.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta 2025-09-29) | No declarado | Sin impacto declarado |
| Tiempo | Cierre 2026-06-23 (línea base 2) | 2026-07-23 | +30 días |
| Costo | Aprobado 6.800.000.000 COP; proyección 7.077.935.008 COP (+4,1 %) | No declarado | Sin impacto declarado |

**Quién absorbe lo que no se declaró:** treinta días más de equipo y de contrato con el proveedor (CT-869) no son gratis. Si el costo y el alcance quedan en cero, alguien lo absorbe en horas no pagadas o en calidad. La prueba de carga ya no alcanzó el umbral pactado y se repite (incidencia abierta desde el 2026-10-14, sin dueño), y el riesgo de concentración del conocimiento en una sola persona no tiene probabilidad, impacto ni dueño. Ahí es donde caería. La holgura de caja es de 2.706.674.247 COP contra lo comprometido, pero la proyección ya supera el aprobado en 277.935.008 COP antes de este cambio.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` con 30 días devuelve 0 alcanzados, 0 que no puedan sostener su fecha y 0 dependencias sin confirmar | — |

Esto no significa que no haya efecto. La ficha de PRY-205 tiene **cero dependencias declaradas**, y por eso el cálculo no tiene por dónde propagarse. Si otro proyecto espera esta salida, nadie lo escribió. Lo que el cálculo tampoco dice, y no lo invento, es cuántos días se mueve cada proyecto: eso necesita holgura por actividad y la ficha de portafolio no la tiene.

### Quién decide
**Autoridad requerida:** no determinable. El acta no declara autoridad de cambios (`identity.authority`: no encontrado). · **Según:** acta de constitución 2025-09-29; el comité del proyecto es el Consejo de Administración. · **Va a comité:** sí, por defecto, ya que sin autoridad declarada no hay nadie por debajo que pueda aprobarlo. Próximo comité: 2026-10-22.

Hallazgo de fondo: el CC-01 (+27 días, +54.000.000 COP) quedó «autorizado por el comité» sin decir qué comité ni quién firma. Los 27 días de la línea base 2 sí coinciden con los 27 días aprobados (sin días sin autorizar), pero la autorización es de una frase y no nombra a nadie.

### Si no se aprueba
El proyecto sigue con cierre en 2026-06-23, fecha ya pasada. El informe lo declara en verde y 75 %, pero el cálculo contra la evidencia no lo sostiene: los 5 hitos están «cumplidos» y ninguno tiene evidencia, el avance declarado queda 25 puntos por debajo de lo que dice el plan, y el proveedor facturó 241.126.726 COP más de lo aceptado. Además, el acta de recibo de «Parametrización de líneas de crédito» no existe en la carpeta, y el compromiso de Paula Céspedes (punto 24, vencido el 2026-09-30) sigue sin entrega.

### Si se aprueba
Línea base 3 — cierre 2026-07-23 · presupuesto: sin cambio declarado (6.800.000.000 COP) · motivo: no consta, hay que escribirlo.
Desviación acumulada contra la línea base original (2026-05-27): **+57 días** (27 de la línea base 2 más 30 de esta), unos 24,7 % de la duración original, contra 11,7 % hoy. Contra la vigente se vería sana; contra la original, no. Costo acumulado contra la original: +54.000.000 COP del CC-01 más lo que declare esta solicitud (hoy nada).

### Qué falta para poder decidir
1. Aclarar si la salida a producción ya ocurrió, y con qué documento.
2. Solicitante, motivo e impacto en costo y alcance.
3. Nombre de quien tiene autoridad de cambios y de quién firmó el CC-01.
4. Las dependencias reales de PRY-205 con otros proyectos.

**Pie de rigor:** esto es un borrador de trabajo, no una decisión. Se basa en los documentos de la carpeta hasta el 2026-10-14; no sé lo que se haya hablado fuera de ellos. La verificación de cada dato es suya, con la cita en `estado/records/PRY-205.json`.
