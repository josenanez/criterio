**Sale de:** ficha `estado/records/PRY-202.json` y los documentos de `documentos/proyectos/PRY-202-core-cooperativo/` (acta de constitución 2025-05-17, cronograma v1 y v2, solicitud de cambio CC-01, acta de recibo 2026-10-06, informe de avance 2026-10-14, comité 2026-10-15). Cifras derivadas: `portafolio.py compute`, corte 2026-10-15.

## Cierre — PRY-202 Core cooperativo — 2026-10-15

**Antes de nada: nadie ha declarado que este proyecto terminó.** El último informe (2026-10-14, Camilo Beltrán) lo declara en **verde con 76 %** de avance y habla de un piloto pendiente de ajustes al reglamento. Lo que sigue es lo que el cierre diría hoy si se pidiera; no es un cierre declarado, y no se archiva nada.

### Contra lo comprometido
**Criterio de éxito:** «Core cooperativo en producción y medido» (acta de constitución, 2025-05-17, sección Criterio de éxito).
**Se cumplió:** **no se puede determinar** — y la documentación apunta a que no. Ningún documento muestra puesta en producción ni medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (línea base 2025-08-06) | Cumplido | Acta de recibo 2026-10-06, recibida por Camilo Beltrán |
| Ambiente de pruebas certificado (2025-10-17) | Declarado cumplido | **Sin evidencia** (363 días desde su fecha) |
| Integración con el core cooperativo (2025-12-27) | Declarado cumplido | **Sin evidencia** (292 días) |
| Piloto con asociados (línea base 2026-03-09, vigente 2026-07-06) | Declarado cumplido | **Sin evidencia** (101 días desde la fecha vigente); el informe del 2026-10-14 dice que el Consejo pidió ajustar el reglamento *antes* del piloto, lo que contradice que ya esté cumplido |
| Core en producción y medido (criterio de éxito) | Sin hito en el cronograma | Ninguna |

El alcance del acta es genérico («Componente 1, 2, 3»): no permite contrastar qué se entregó de qué se comprometió.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| No determinable. El acta solo dice «Lo que otro proyecto cubre». | — | — |
| CC-01 *amplía* el alcance («Ampliación de alcance», sin detalle de qué) | «El comité» — sin nombre ni acta de decisión | Solicitud 2026-10-02; fecha de la decisión no consta |

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-03-09 (cronograma v1) | 2026-07-06 (cronograma v2, aprobado 2026-10-14) | No hay cierre; la fecha vigente ya pasó | **119 días (41.6 %)**; vs vigente: 0 días |
| Presupuesto | 2.400.000.000 COP | 2.400.000.000 COP (CC-01 pide 238.000.000 COP más; no figura incorporado) | Proyección al cierre 2.493.540.214 COP | **3.9 %** sobre lo aprobado |

Presupuesto ejecutado: 876.426.100 COP (36.5 % de lo aprobado); comprometido: 1.390.493.898 COP (57.9 %).
Replanificaciones: **1**.

Dos cosas que el cierre no puede resolver con los documentos:
- El acta fija cierre el **2026-04-14**; el cronograma v1 termina el **2026-03-09**. Los 119 días se miden contra el cronograma; contra la fecha del acta la desviación sería otra y no se calcula aquí.
- El cronograma v2 se aprobó el 2026-10-14 con fecha de fin **2026-07-06, tres meses antes** de su propia aprobación, y sin motivo registrado. CC-01 (2026-10-02) pide +119 días «sobre la línea base vigente»: ese es justamente el movimiento de la línea base.

### RAID al cierre
**Materializados:** ninguno demostrable. El hallazgo de seguridad de la revisión de arquitectura y el pedido del Consejo de ajustar el reglamento (informe 2026-10-14) son incidencias que no están en ningún registro.
**No materializados:** no se puede afirmar; no hay registro RAID.
**Abiertos, con doliente:**
| Qué | Doliente | Estado |
|---|---|---|
| Cambio normativo del supervisor que puede mover el alcance | **No identificado** | Abierto; sin probabilidad ni impacto |
| Dependencia del proveedor del core cooperativo | **No identificado** | Abierto; sin probabilidad ni impacto; sin proveedor ni contrato en la ficha |
| Hallazgo de seguridad de arquitectura | **No identificado** | Sin registro ni fecha de resolución |
| Compromiso «Entregar el punto 35», para 2026-10-27 | Óscar Ramírez | Abierto; el «punto 35» no se define en ningún documento |

Lo abierto sin doliente con nombre no está cerrado.

### Lecciones
Solo las que se anclan a un hecho documentado:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El piloto con asociados pasó de 2026-03-09 a 2026-07-06 en un cronograma v2 sin motivo registrado | v2 aprobado 2026-10-14 | 119 días de desviación vs original (41.6 %) | Exigir motivo escrito y aprobador nombrado para toda línea base nueva |
| CC-01 quedó «autorizada por el comité» sin decir cuál miembro ni cuándo | Solicitud 2026-10-02 | Ampliación de alcance y 238.000.000 COP sin decisión trazable | Registrar quién y cuándo decide, en acta de comité |
| El Diseño funcional, con línea base 2025-08-06, se recibió formalmente el 2026-10-06 | 2026-10-06 | Es el único hito con acta de recibo; los otros tres se declaran cumplidos sin ella | Pedir acta de recibo al declarar un hito cumplido, no después |
| El informe reporta verde con 76 % mientras el plan marca 4 de 4 hitos cumplidos | 2026-10-14 | Las dos cifras no pueden ser ciertas a la vez (brecha de 24 puntos) | Reportar avance contra hitos con evidencia |

No se registra lección sobre el ambiente de pruebas ni la integración: no hay documento que las ancle.

### Sin dato
- Si el core está en producción y se mide (criterio de éxito); fecha real de cualquier hito.
- Alcance concreto comprometido y qué cubre CC-01.
- Motivo de la línea base v2 y fecha y miembros de la decisión de CC-01.
- Producto asociado y autoridad (la ficha no los tiene; el acta dice «No aplica»).
- Doliente de los riesgos y del hallazgo de seguridad; definición del «punto 35».
- Proveedor del core: no hay contrato ni entregables en la documentación.
- Campos de identidad y plan con 17 meses de antigüedad (acta de 2025-05-17).

### Después
Archivo no ofrecido: el proyecto sigue declarado activo (verde, 76 %), con un compromiso abierto al 2026-10-27. Moverlo a `archivo/` lo sacaría del barrido diario con alertas abiertas. Cuando el patrocinador (Ricardo Salas) declare el cierre, o decida cerrar por decisión sin cumplir el criterio, se rehace esta acta.
