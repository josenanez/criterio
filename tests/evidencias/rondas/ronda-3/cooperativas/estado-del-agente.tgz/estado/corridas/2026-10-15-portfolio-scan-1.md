# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 79 documentos, 0 releídos y 79 sin cambio · 198 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

10 fichas nuevas (PRY-199,200,201,205-211); 52 de 79 documentos leídos, 27 sin cambio; nada movido (no existe entrada/); nada omitido. Mirar: factura FV-1901 de PRY-209 sin acta de recibo del contrato; cronogramas v2 de PRY-208 y PRY-209 con CC-01 pendiente; compromisos con fecha anterior al acta en PRY-205 y PRY-210; citas de PRY-203 sin carpeta de proyecto.

Contra la corrida del 2026-10-15: +35 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva su cita y la verificación es de quien lo usa. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Documentos:** 79 en la carpeta · 52 leídos · 27 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Formatos: 38 .md, 12 .docx, 10 .pdf, 10 .xlsx, 7 .csv, 1 .txt, 1 .json. Plan: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Nada diferido. PRY-202, PRY-203 y PRY-204 no cambiaron y no se releyeron.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, declarado, plan, dinero, contrato CT-199, riesgo, compromiso | autoridad, fase |
| PRY-200 Crédito de libranza digital | 3 | identidad, declarado, plan, dinero, riesgos, incidencia | autoridad, fase |
| PRY-201 Apertura de ahorro en línea | 5 | ídem, más acta de recibo de la integración con el core, compromiso | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 10 | ídem, contrato CT-869, 2 actas de recibo, factura, CC-01, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-206 Pagos con QR | 5 | identidad, declarado, plan v1 y v2, dinero, CC-01, riesgos | autoridad, fase |
| PRY-207 Microcrédito rural | 2 | identidad, declarado, dinero, riesgos (sin cronograma) | autoridad, fase |
| PRY-208 Motor de crédito | 6 | identidad, plan v1 y v2, CC-01, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-209 Convenios de libranza con empresas | 9 | identidad, plan v1 y v2, contrato CT-901, factura, 2 actas de recibo, CC-01 | producto («No aplica»), autoridad, fase |
| PRY-210 Corresponsales rurales | 4 | identidad, plan v1, dinero, compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 2 | identidad, declarado, dinero, riesgo (sin cronograma) | autoridad, fase |

Ningún acta declara la autoridad del gerente ni la fase, en ninguno de los diez.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: las fichas de PRY-202, PRY-203 y PRY-204 se conservan tal cual (sus documentos no cambiaron) | — |

### Qué hay que mirar (lo que dicen los documentos, sin juicio nuevo)
- **PRY-209:** la factura FV-1901 (2026-08-30, 1.882.339.743 COP) está radicada, y no hay acta de recibo de ningún entregable del contrato CT-901. Las dos actas que existen (diseño funcional, integración con el core) son de hitos, no de entregables del contrato.
- **PRY-205:** la factura FV-1869 (2026-09-13) es por 1.396.951.861 COP; el contrato CT-869 suma tres entregables de 385.275.045 COP. Hay acta de recibo de dos; el tercero (Parametrización de líneas de crédito) figura «recibido» en el contrato sin acta.
- **PRY-199:** contrato CT-199 con tres entregables pendientes y ninguna factura; el informe declara 720.000.000 COP ejecutados.
- **Cronogramas v2 que aplican un cambio no aprobado:** PRY-208 (+33 días, CC-01 «pendiente de presentación al comité») y PRY-209 (+43 días, ídem). En PRY-205 y PRY-206 la CC-01 figura «autorizada por el comité» sin decir quién; en PRY-206 la solicitud (2026-10-15) es posterior al cronograma v2 (2026-10-12).
- **Hitos declarados cerrados sin acta que los pruebe:** PRY-200 (1), PRY-201 (2), PRY-205 (5), PRY-208 (1), PRY-209 (1), PRY-210 (3), PRY-206 (1), PRY-199 tiene su acta. Las actas existentes se citaron solo para el hito que nombran.
- **Compromisos con fecha anterior a la del acta que los registra** (marcados vencidos, sin evidencia de entrega): Paula Céspedes, punto 24, 2026-09-30 (PRY-205); Elena Duarte, punto 1, 2026-09-25 (PRY-210). Paula Céspedes, punto 25 (PRY-208), sin fecha («por definir»).
- **Presupuesto:** la proyección al cierre declarada supera el aprobado en PRY-205, PRY-206, PRY-200 y PRY-210; en PRY-206 y PRY-207 lo ejecutado declarado es mayor que lo comprometido. PRY-207 cierra el 2026-10-15 (hoy) con 81 % declarado y estado rojo.
- **Índice:** la ficha de PRY-203 cita su acta como `00-gobierno/2025-10-09-acta-constitucion.md` (sin la carpeta del proyecto) y el índice no resuelve esas siete citas. Además existe una carpeta anidada `estado/PRY-203-aportes-sociales-en-línea/` con estado propio. No las toqué; conviene revisarlas.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Todo se pudo leer (79 de 79 convertidos a texto) |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No existe carpeta `entrada/`; no había nada que mover | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno |

Pie: Criterio Portfolio 0.3.9 · fichas tocadas: 10 (PRY-199, 200, 201, 205, 206, 207, 208, 209, 210, 211) · campos en `not_found`: autoridad y fase en los 10; producto en 4 (PRY-205, 208, 209, 210, que declaran «No aplica») · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
