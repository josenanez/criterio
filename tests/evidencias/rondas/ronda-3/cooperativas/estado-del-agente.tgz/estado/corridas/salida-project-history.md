## Historia · PRY-205 Prevención de lavado de activos · 2025-09-24 a 2026-10-14

**Leí:** 10 documentos entre 2025-09-24 y 2026-10-14 (2 .docx, 1 .csv, 1 .xlsx, 1 .pdf, 5 .md). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo).
**Trimestres sin un solo documento:** 2026-T2 (abril–junio de 2026). Es justo el trimestre en que vencían la fecha original de salida a producción (2026-05-27) y la vigente (2026-06-23).

### En una línea
El proyecto se aprobó el 2025-09-29 con cierre comprometido el 2026-06-20 y presupuesto de 6.800.000.000 COP. La línea base v1 del cronograma pone la salida a producción el 2026-05-27. Entre diciembre de 2025 y febrero de 2026 hay actas de recibo de dos de los tres entregables del proveedor. Después no hay ningún documento hasta el 2026-09-13, cuando se radica una factura por todos los entregables del contrato. En la semana del 2026-10-07 al 2026-10-14 aparecen juntos la solicitud de cambio CC-01 (+27 días), una minuta, el cronograma v2 que mueve la salida a 2026-06-23 (fecha que ya había pasado) y un informe en verde con 75 % de avance. Ese mismo informe dice que la prueba de carga no alcanzó el umbral y se repite.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 27 días (11.7 %) | No se puede calcular: hay una sola declaración de estado (2026-10-14), no una serie. Lo que sí da el cálculo: el primer hito dado por cumplido sin evidencia vencía el 2025-11-24, hace 325 días. | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-09-24 | contrato-ct-869.docx | Se firma el contrato con Red Rural de Pagos: 3 entregables de 385.275.045 COP cada uno (compromisos 2025-12-11, 2026-02-13, 2026-04-17). La tabla los muestra ya en estado "recibido" el día de la firma. Cada entregable se factura contra acta de recibo firmada por el gerente. |
| 2025-09-29 | acta-constitucion.docx | Se aprueba el proyecto: inicio 2025-10-09, cierre 2026-06-20, 6.800.000.000 COP. Patrocinador Carlos Peña, gerente Rubén Cárdenas, comité Consejo de Administración. No declara dependencias. |
| 2025-09-29 | cronograma-v1.csv | Línea base de 5 hitos; salida a producción 2026-05-27. |
| 2025-12-12 | acta-recibo (licenciamiento del módulo).pdf | Se recibe el entregable 1 (comprometido 2025-12-11). |
| 2026-02-18 | acta-recibo (bolsa de horas).md | Se recibe el entregable 2 (comprometido 2026-02-13). |
| 2026-09-13 | factura-ct-869.md | Factura FV-1869 por 1.396.951.861 COP, "Entregables del contrato CT-869", radicada en cuentas por pagar. |
| 2026-10-07 | solicitud-cambio-cc-01.md | Ampliación de alcance: +27 días sobre la línea base vigente y +54.000.000 COP. "Autorizada por el comité", sin fecha de autorización. |
| 2026-10-12 | comite-semanal.md | Minuta con dos asistentes (Rubén Cárdenas, Carlos Peña). Temas: avance y compromisos. No menciona CC-01. Compromiso de Paula Céspedes "punto 24" con fecha 2026-09-30, anterior a la minuta. |
| 2026-10-14 | cronograma-v2.xlsx | Salida a producción: línea base 2026-05-27, vigente 2026-06-23. Los 5 hitos figuran "cerrado". |
| 2026-10-14 | informe-avance.md | Estado Verde, avance 75 %, proyección al cierre 7.077.935.008 COP. Reporta que la prueba de carga no alcanzó el umbral y se repite. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-07 (solicitud); cronograma v2 del 2026-10-14 | 2026-06-23 (salida a producción; antes 2026-05-27) | "Ampliación de alcance". No describe qué se amplía ni explica por qué el tiempo sube 27 días. | La propia CC-01 dice "Autorizada por el comité". No hay minuta ni acta de comité que la apruebe: la del 2026-10-12 no la menciona. |

El cambio se documenta con la fecha nueva (2026-06-23) ya vencida. El cronograma v1 y el v2 quedan ambos en la carpeta, así que la línea base original se conserva. El acta de constitución da cierre 2026-06-20 y el cronograma v1 da salida a producción 2026-05-27. Ningún documento aclara si son la misma fecha o dos distintas, así que no se concilian aquí.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios detectados. Patrocinador, gerente y comité son los mismos en todos los documentos. | acta-constitucion.docx, informe-avance.md, comite-semanal.md |

Solo hay una minuta, así que la ausencia de cambios es poco concluyente.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repite: hay una sola minuta. | — | — |

Abierto y vencido: Paula Céspedes, "Entregar el punto 24", para el 2026-09-30, 15 días de atraso. Andrés Lozano, "Entregar el punto 4", para el 2026-10-16, aún no vence.

### Desde cuándo lo declarado no se sostiene
- **Primer hito sin evidencia:** "Diseño funcional aprobado", vencimiento 2025-11-24, figura cumplido y no hay en la carpeta ningún documento que lo respalde. Siguen en el mismo caso "Ambiente de pruebas certificado" (2026-01-09), "Integración con el core cooperativo" (2026-02-24), "Piloto con asociados" (2026-04-11) y "Salida a producción" (2026-06-23). Ningún hito tiene documento de evidencia.
- **Lo que se siguió reportando:** el informe del 2026-10-14 declara Verde y 75 %. El plan, con los 5 hitos cerrados, sostiene 100 %: una diferencia de 25 puntos. El informe a la vez reporta una prueba de carga fallida que se repite, y el hito de salida a producción figura cerrado.
- **Dinero:** la factura FV-1869 por 1.396.951.861 COP supera en 241.126.726 COP el monto aceptado (1.155.825.135 COP, tres entregables de 385.275.045). El tercer entregable, "Parametrización de líneas de crédito", figura aceptado pero no tiene acta de recibo, y el contrato exige acta para facturar. La proyección al cierre (7.077.935.008) supera lo aprobado en 4.1 %, y el informe en verde no lo comenta.
- **Qué no se puede decir:** sin una serie de informes anteriores no se puede fechar el deslizamiento. Solo hay una declaración (2026-10-14) y cero documentos de evidencia. Lo que sí se ve es que todo el soporte formal (CC-01, cronograma v2, informe) se escribió en una semana de octubre de 2026, y que entre 2026-02-18 y 2026-09-13 la carpeta no tiene nada.

### Lecciones ancladas a un hecho
1. **Factura sin acta.** El 2026-09-13 se radicó una factura por todos los entregables, con dos actas de recibo en la carpeta (2025-12-12 y 2026-02-18) y una condición de pago que exige acta firmada. Efecto: 241.126.726 COP facturados sobre lo que el expediente respalda.
2. **Cambio autorizado después del vencimiento.** CC-01 (2026-10-07) mueve a 2026-06-23 una fecha que ya había pasado. Efecto: el atraso de 27 días se formaliza con la salida a producción ya vencida y sin minuta que lo apruebe.
3. **Trimestre sin documentos.** Abril–junio de 2026 no tiene ningún documento y es el periodo en que vencieron la fecha original y la vigente. Efecto: no hay forma de saber desde la carpeta qué ocurrió con la salida a producción.

**No se atribuye intención.** Que el atraso, la factura o los hitos queden sin soporte en la carpeta no dice que alguien lo ocultara. Puede haber evidencia fuera de la carpeta. La historia sirve para tener esa conversación con datos, y quién la tiene es una persona.

**Se puede llevar esta historia al cierre del proyecto o al comité del 2026-10-22**, si hay una decisión que salga de ella (por ejemplo, la factura FV-1869 o el estado Verde).

---
**Pie de rigor:** 10 documentos leídos; todas las cifras derivadas (días, porcentajes, diferencias, conteos) salen de `portafolio.py compute` del 2026-10-15. La cifra "meses declarando sin sustento" no se calculó por falta de una serie de estados declarados. Sin fuentes marcadas como evidencia (0 de 17). Criterio produce borradores de trabajo, no decisiones ni asesoría; no conoce lo hablado fuera de los documentos y puede equivocarse. La verificación contra los documentos citados es de quien lee.
