## Proveedores — PRY-205 Prevención de lavado de activos al 2026-10-15

**De qué documentos sale:** contrato `00-gobierno/2025-09-24-contrato-ct-869.docx`; acta de constitución `00-gobierno/2025-09-29-acta-constitucion.docx`; actas de recibo `20-seguimiento/2025-12-12-acta-recibo-ct-869-licenciamiento-del-módulo.pdf` y `20-seguimiento/2026-02-18-acta-recibo-ct-869-bolsa-de-horas-de-desarrollo.md`; factura `20-seguimiento/2026-09-13-factura-ct-869.md`; informe de avance `20-seguimiento/2026-10-14-informe-avance.md`; comité `30-reuniones/2026-10-12-comite-semanal.md`; cifras de `portafolio.py compute` (corte 2026-10-15). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15): no hizo falta registrarlos de nuevo.

### Red Rural de Pagos S.A.S. — contrato CT-869
**Vigencia:** firmado 2025-09-24; fecha de terminación no declarada · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado (ver «Sin dato»)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-12-11 · 385.275.045 COP | accepted | Acta de recibo 2025-12-12 (Rubén Cárdenas) | No desglosado |
| Bolsa de horas de desarrollo | 2026-02-13 · 385.275.045 COP | accepted | Acta de recibo 2026-02-18 (Rubén Cárdenas) | No desglosado |
| Parametrización de líneas de crédito | 2026-04-17 · 385.275.045 COP | **accepted sin evidencia** | **Ninguna.** Solo la columna «recibido» del propio contrato, que no es un acta | No desglosado |

La factura FV-1869 (2026-09-13) es una sola, por «Entregables del contrato CT-869», y no dice a cuál entregable corresponde. Facturado total: 1.396.951.861 COP.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado vs. aceptado | Los tres entregables suman 1.155.825.135 COP (monto aceptado según el script) | Factura de 1.396.951.861 COP: **241.126.726 COP por encima** de todo lo aceptado, contando incluso el entregable sin acta | Contrato CT-869; factura FV-1869 |
| Parametrización de líneas de crédito | «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto»; la tabla lo marca «recibido» | No hay acta de recibo en la carpeta | Contrato CT-869; carpeta `20-seguimiento` |
| Condición de pago | Factura solo contra acta firmada | La factura está «radicada en cuentas por pagar» sin acta para uno de los tres entregables | Contrato CT-869; factura FV-1869 |

El script no levanta `vendor_invoiced_without_delivery`: hay dos entregables aceptados con acta. El hallazgo es que se facturó más de lo aceptado y que uno de los tres aceptados no tiene acta.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Parametrización de líneas de crédito | accepted (contrato: «recibido») | Fecha comprometida 2026-04-17; no hay documento de recibo, así que no se puede fechar la aceptación |

Entregables tardíos sin declarar entrega: ninguno (`late` vacío).

### Compromisos del proveedor vencidos
Ningún compromiso del acta del 2026-10-12 está atribuido a Red Rural de Pagos. Hay uno vencido, pero su responsable (Paula Céspedes) no figura como del proveedor en ningún documento; lo dejo como compromiso del proyecto, no del proveedor:

| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Entregar el punto 24 (Paula Céspedes) | Comité 2026-10-12 | 2026-09-30 | 15 |

La fecha prometida es anterior a la del acta que la registra, y ningún documento muestra la entrega. El compromiso de Andrés Lozano («punto 4», para 2026-10-16) sigue abierto; tampoco se sabe si es del proveedor.

### Contexto que afecta la lectura
- El informe del 2026-10-14 declara estado **verde** y 75 % de avance. El script marca cinco señales que ese informe no explica, entre ellas: factura por encima de lo aceptado, los cinco hitos del plan como cumplidos sin documento de evidencia y un atraso de 27 días (11,7 %) contra la línea base original.
- La proyección al cierre es 7.077.935.008 COP contra 6.800.000.000 aprobados (4,1 % por encima). No es cifra del proveedor, pero la factura pesa en ella.

### Sin dato
- **Vigencia, fecha de terminación, renovación automática y preaviso de CT-869:** el contrato en la carpeta no los trae. No puedo decir si hay un preaviso por vencer.
- **A qué entregable corresponde la factura FV-1869:** no está desglosada.
- **Pagos efectivos:** solo consta que la factura fue radicada, no que se pagó.
- **Quién es Paula Céspedes y Andrés Lozano** (proyecto o proveedor): ningún documento lo dice.

### Después
Hay un entregable aceptado y facturado sin acta, y una factura 241.126.726 COP por encima de lo aceptado. Recomiendo llevarlo al comité del 2026-10-22 y **frenar el pago de FV-1869** hasta tener el acta de la Parametrización o su rechazo. ¿Lo preparo como paquete de comité? (Respuesta sugerida en esta prueba: sí, pero no lo genero aquí.)

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es de quien lo usa. Las cifras derivadas vienen de `portafolio.py compute`; lo que no está en los documentos se declara arriba como sin dato.*
