# Corrida del 2026-10-15 · status-report

13 proyectos · 28 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Informe de PRY-205: verde declarado contradicho por 5 señales (11.7% de atraso contra la original, 5 hitos sin evidencia, facturado 241.126.726 COP sobre lo aceptado, compromiso vencido). Dijo que no sabe producto, autoridad, fase ni quién aprobó CC-01.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

*Informe sobre la ficha PRY-205 (registro `estado/records/PRY-205.json`, actualizada 2026-10-15), cifras recalculadas con `compute` al 2026-10-15. Términos vigentes: v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15.*

## PRY-205 · Prevención de lavado de activos — estado al 2026-10-15

**Declara el gerente (Rubén Cárdenas):** verde · 75% · al 2026-10-14 (1 día; vigente)
**Sustento documental:** contradicho. Ninguna fuente es evidencia marcada (evidencia 0, declaración 2, sin marcar 15), y el script reporta `declared_vs_evidence`.
**Lo que el semáforo no explica:** compromiso vencido, hitos cumplidos sin evidencia, avance contra plan, desviación de tiempo, facturado por encima de lo aceptado.
**Último documento:** 2026-10-14 (1 día de silencio) · **Última reunión:** 2026-10-12

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-05-27 | 2026-06-23 | +27 días contra la original (11.7%, sobre el umbral de 10%); 0 contra la vigente |
| Presupuesto | 6.800.000.000 COP (aprobado) | sin segunda línea base de costo en la ficha | proyección 7.077.935.008 COP: 4.1% sobre lo aprobado |

Replanificaciones: 1. La v2 se aprobó el 2026-10-14 por CC-01, ampliación de alcance (+27 días). CC-01 declara además 54.000.000 COP adicionales; el aprobado de la ficha sigue en 6.800.000.000, así que ese costo no figura en una línea base nueva.

Dinero (COP): comprometido 4.093.325.753 (60.2%), ejecutado 2.820.549.297 (41.5%), disponible real 2.706.674.247.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-11-24 | 2025-11-24 | cumplido (declarado) | ninguna (325 días) |
| Ambiente de pruebas certificado | 2026-01-09 | 2026-01-09 | cumplido (declarado) | ninguna (279 días) |
| Integración con el core cooperativo | 2026-02-24 | 2026-02-24 | cumplido (declarado) | ninguna (233 días) |
| Piloto con asociados | 2026-04-11 | 2026-04-11 | cumplido (declarado) | ninguna (187 días) |
| Salida a producción | 2026-05-27 | 2026-06-23 | cumplido (declarado) | ninguna (114 días) |

Los 5 hitos están declarados cumplidos y ninguno tiene documento que lo sustente. El plan respalda 100%, el gerente declara 75%: diferencia de 25 puntos.

### Dónde no coincide
- **Verde frente a cinco señales abiertas**, todas sin explicar (informe de avance 2026-10-14; cálculo de hoy).
- **Salida a producción «cumplida»** (cronograma v2, 2026-10-14), pero el mismo informe de avance registra como incidencia que «la prueba de carga no alcanzó el umbral pactado y se repite» (desde 2026-10-14, sin responsable).
- **Proveedor Red Rural de Pagos S.A.S. (CT-869):** facturado 1.396.951.861 COP (factura 2026-09-13) frente a 1.155.825.135 aceptado: 241.126.726 COP por encima. «Parametrización de líneas de crédito» (vence 2026-04-17) figura aceptada sin acta de recibo. Los otros dos entregables sí tienen acta (2025-12-12 y 2026-02-18).
- **CC-01** aprobado por «el comité» sin nombre; la solicitud es del 2026-10-07 y la línea base v2 se aprobó el 2026-10-14.

### Abierto
**Riesgos e incidencias sin movimiento:** ninguno; los dos registrados se movieron el 2026-10-14. Pero ninguno tiene responsable: riesgo «Concentración del conocimiento en una sola persona» (probabilidad e impacto no declarados) e incidencia de la prueba de carga.
**Compromisos vencidos:** Paula Céspedes, «Entregar el punto 24», vencía el 2026-09-30 (15 días); el acta que lo registra es del 2026-10-12 y ningún documento muestra la entrega. Abierto y vigente: Andrés Lozano, «Entregar el punto 4», para el 2026-10-16.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
Producto (el acta dice «No aplica»), autoridad y fase del proyecto. Los campos de identidad, alcance y presupuesto aprobado salen del acta del 2025-09-29, con 13 meses de antigüedad (umbral 12). Impacto en costo de CC-01 sin reflejar en el aprobado.

### Después
La desviación de tiempo (11.7%) supera el umbral y hay facturación por encima de lo aceptado. Puedo preparar el punto de comité (próximo: 2026-10-22) o, para CC-01, la solicitud de cambio con su línea base de costo.

---
*Pie: Criterio Portfolio v0.3.9 · ficha PRY-205 actualizada 2026-10-15 · campos inciertos: producto, autoridad, fase, aprobador de CC-01, responsables de riesgo e incidencia · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal*
