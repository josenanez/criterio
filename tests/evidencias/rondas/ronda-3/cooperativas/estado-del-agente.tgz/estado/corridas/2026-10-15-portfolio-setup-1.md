# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 79 documentos, 52 releídos y 27 sin cambio · 88 s · 29 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 8 |
| `commitment_overdue` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 2 |
| `progress_vs_plan` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 1 |

0 preguntas (sesión sin interfaz: valores sugeridos); minutos hasta el primer resultado no medidos; 3 proyectos (202, 203, 204), 29 señales, los 3 en verde contradichos por los documentos

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Cooperativa

**Miré:** 79 documentos en 13 proyectos · formatos: .md (38), .docx (12), .pdf (10), .xlsx (10), .csv (7), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (hay varios proyectos; valor sugerido)
**Te aviso:** dos días antes del comité del 2026-10-22, cada dos semanas (valor sugerido; no dijiste fecha de comité)
**En:** presentación (valor sugerido)
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-15 para la versión 0.3.9 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 f0f8a373c9bdced2…
**Dónde queda todo:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; los informes en `reportes/`.

### Probé con tres proyectos

Entre los que tienen documentos del 2026-10-15 (empatan 202, 203, 204 y 206) tomé los tres primeros por código.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Core cooperativo | 7 | Gerente Camilo Beltrán, patrocinador Ricardo Salas, 2.400 M COP aprobados, 1.390 M comprometidos, 876 M ejecutados; declara verde y 76 % (informe 2026-10-14). Cierre del acta: 2026-04-14. | Facultad del gerente (`authority`); producto («No aplica» en el acta). |
| PRY-203 Aportes sociales en línea | 14 | Gerente Óscar Ramírez, 3.300 M aprobados, 1.340 M ejecutados; declara verde y 60 % (informe 2026-10-13). Tiene `ficha-pm.json` del gerente, guardada aparte como `pm_record`. 26 compromisos de seis reuniones. | Facultad del gerente; estado declarado en la ficha del gerente. |
| PRY-204 Tarjeta débito para asociados | 6 | Gerente Ricardo Salas, 9.500 M aprobados, 8.176 M comprometidos (86 %); declara verde y 74 % (informe 2026-10-15). Cierre del acta: 2027-05-15. | Facultad del gerente; fecha del compromiso «Entregar el punto 40» («por definir»). |

### Hallazgos (lo que levantó el cálculo, 29 señales en los tres)

Los tres declaran **verde** y en los tres los documentos no lo sostienen (`declared_vs_evidence`).

**PRY-202**
- `variance_time`: +119 días (41,6 %) contra la línea base original; el piloto pasó del 2026-03-09 al 2026-07-06.
- `progress_vs_plan`: el cronograma da los 4 hitos por cerrados (100 %) y el informe reporta 76 %.
- `milestone_met_without_evidence`: 3 hitos cerrados sin acta de recibo (Ambiente de pruebas, Integración con el core, Piloto con asociados). Solo «Diseño funcional aprobado» tiene acta, fechada 2026-10-06, 14 meses después de su fecha.

**PRY-203**
- `progress_vs_plan`: los 5 hitos figuran cerrados (100 %) y el informe reporta 60 %.
- `milestone_met_without_evidence`: 4 hitos cerrados sin acta. Solo «Salida a producción» la tiene (2026-10-04), mientras el informe del 10-13 dice que la salida se reprogramó.
- `commitment_overdue`: 7 compromisos vencidos. Cinco personas dijeron en reunión que ya entregaron y no hay acta (Beatriz Cuéllar, Sandra Gil, Diana Molina, María Restrepo, Carlos Peña).
- `commitment_rescheduled`: «Enviar el documento 1» (María Restrepo) va en 6 reprogramaciones, de 2026-09-21 a 2026-12-12; «Cerrar la prueba 2» (Paula Céspedes), 5.
- `commitment_undated`: 3 compromisos sin fecha.
- Fuera de cualquier registro: en la reunión del 10-15 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo anotó como riesgo. Lo dejé en la ficha como riesgo sin dueño.

**PRY-204**
- `variance_time` y `rebaseline_unauthorized`: el cronograma v2 (2026-10-15) movió la integración con el core 112 días, pero la solicitud CC-01 está «pendiente de presentación al comité». El plan cambió sin autorización.
- `milestone_met_without_evidence`: «Diseño funcional aprobado» cerrado sin acta.
- `commitment_undated`: «Entregar el punto 40» (Carlos Peña), «por definir».

Lo que no es señal pero conviene saber: la CC-01 de PRY-202 dice «autorizada por el comité» sin nombrar quién ni citar acta, y el acta de comité del 2026-10-15 de PRY-202 no la menciona.

### El portafolio completo
10 proyectos más (PRY-199 a 201, 205 a 211) y 76 documentos, en 2 lotes uno tras otro. No medí cuánto tardaron los tres de prueba, así que no tengo una cifra propia; con lo visto, calcula un rato proporcional a los tres de hoy multiplicado por tres o cuatro.

### Lo que le falta a tu carpeta
- Ninguna acta dice hasta dónde puede decidir el gerente (`authority`): falta en los 3 y el control de cambios no puede saber qué excede su facultad.
- Los alcances de las actas son genéricos («Componente 1, 2, 3»; «Lo que otro proyecto cubre»): no hay con qué contrastar un cambio de alcance.
- Las actas de recibo casi no existen: solo 1 de 4 hitos cerrados en PRY-202, 1 de 5 en PRY-203 y 0 de 1 en PRY-204.
- PRY-203 guarda `2026-10-15-notas-reunion.txt` fuera de `30-reuniones/`.
- PRY-207 y PRY-211 tienen solo acta e informe, sin cronograma ni reuniones; PRY-210 no tiene seguimiento de reuniones por fecha reciente.
