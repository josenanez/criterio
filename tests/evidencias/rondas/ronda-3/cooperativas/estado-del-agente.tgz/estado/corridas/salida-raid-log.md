**Sale de:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211), los informes de avance de cada proyecto (corte 2026-10-05 a 2026-10-15), las minutas de comité (PRY-199, 201, 202, 203, 204, 205, 208, 210), las notas de reunión de PRY-203 del 2026-10-15, las solicitudes de cambio CC-01 (PRY-202, 204, 205, 206, 208, 209) y los cronogramas. Escala de valoración: ningún proyecto la define; no se inventó una (ver abajo).

## RAID — portafolio al 2026-10-15
9 riesgos · 0 supuestos · 17 incidencias · 12 dependencias (38 ítems; 34 venían en las fichas, 4 incidencias salen de los informes y no estaban registradas)
38 sin doliente · 0 evaluables por "sin movimiento" · 5 no registrados formalmente

Tres cosas que condicionan la lectura:
- **Ningún ítem tiene doliente, fecha, probabilidad ni impacto.** Las fichas traen `no_identificado` / `no_declarada` en todos. No lo rellené: es hallazgo.
- **Los 21 "riesgos" de las fichas eran 9 riesgos y 12 dependencias.** Reclasifiqué los otros 12 (detalle abajo).
- **"Sin movimiento en dos períodos" no se puede medir:** hay un solo informe por proyecto en la carpeta. El "último movimiento" es la fecha de ese informe, no evidencia de gestión.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| TRANSV-1 (PRY-202/I2, 204/I1, 208/I3, 211/I2; dependencia en 200, 201, 206, 207, 208, 209) | Incidencia + dependencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto (informes 202: 2026-10-14, 204: 2026-10-15, 208: 2026-10-11, 211: 2026-10-05); y otros seis proyectos esperan la aprobación del mismo reglamento | no identificado | 2026-10-05 | Afecta a 9 proyectos (202, 204, 211 y 208 con incidencia; 200, 201, 206, 207, 208 y 209 con dependencia); el doliente está fuera de los proyectos y no hay respuesta registrada. Nadie ha dicho si es un solo reglamento o varios. |
| TRANSV-2 (PRY-199/D1, 201/D1, 202/D1, 207/D1) | Dependencia | Dependencia del proveedor del core cooperativo, declarada en cuatro proyectos | no identificado | 2026-10-05 | Afecta a cuatro proyectos; ninguna ficha dice quién coordina con el proveedor ni si este confirmó. |
| PRY-201/I1 | Incidencia | La prueba de carga no alcanzó el umbral y se repite (proyecto en Rojo, informe 2026-10-05) | no identificado | 2026-10-05 | Sin fecha de repetición ni responsable. La misma incidencia está en PRY-205, 209 y 211. |
| PRY-209/I1, I2 | Incidencia | Prueba de carga fallida y dos semanas perdidas por rotación de un desarrollador clave (proyecto en Rojo, informe 2026-10-13); además CC-01 (+43 días, 86.000.000 COP) sigue pendiente de presentación al comité | no identificado | 2026-10-13 | Proyecto en Rojo con dos incidencias abiertas y un cambio de alcance sin decidir. |
| PRY-207/I1 | Incidencia | Se reprogramó la salida por el cierre contable; el informe no da la fecha nueva (Rojo, informe 2026-10-05) | no identificado | 2026-10-05 | Una salida sin fecha. Igual en PRY-203, 206 y 208. |
| PRY-203/D1 | Dependencia (no registrada formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | no identificado | 2026-10-15 | Dicho en reunión el 2026-10-15 y nadie lo anotó; el gerente decide si lo formaliza. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Dependencia (declarada, sin confirmar por la contraparte) | PRY-203, notas de reunión | 2026-10-15 |

Las minutas de PRY-199, 201, 202, 204, 205, 208 y 210 solo traen compromisos; no dicen nada que sea riesgo. Las seis minutas semanales de PRY-203 (2026-09-03 a 2026-10-08) solo traen compromisos y "dice que ya entregó"; eso es asunto de `/pm-commitments`, no del RAID.

También hay cuatro incidencias que están en un informe de avance y no en la ficha (no son de reunión):
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| Se levantó un hallazgo de seguridad en la revisión de arquitectura | Incidencia (PRY-202/I1) | Informe de avance PRY-202 | 2026-10-14 |
| El Consejo pidió ajustar el reglamento antes del piloto | Incidencia (PRY-202/I2) | Informe de avance PRY-202 | 2026-10-14 |
| Se reprogramó la salida por el cierre contable (sin fecha nueva) | Incidencia (PRY-203/I1) | Informe de avance PRY-203 | 2026-10-13 |
| El Consejo pidió ajustar el reglamento antes del piloto | Incidencia (PRY-204/I1) | Informe de avance PRY-204 | 2026-10-15 |

### Sin doliente o sin fecha
Los 38 ítems carecen de doliente. Los 9 riesgos y las 12 dependencias carecen además de fecha; las 17 incidencias no traen fecha de resolución. No se rellenó ninguno. Lo que falta, por proyecto, está en el registro completo (todas las columnas "Doliente" y "Fecha" dicen "no identificado" o "—").

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199/D1, 201/D1, 202/D1, 207/D1 | Proveedor del core cooperativo — **código de proyecto no declarado** | No | PRY-202 (Core cooperativo) movió su línea base: cronograma v2 del 2026-10-14 y CC-01 autorizada (+119 días, +238.000.000 COP). **No afirmo** que el proveedor sea el de PRY-202: ninguna ficha lo dice. Si lo es, estas cuatro quedan en riesgo; el gerente debe confirmarlo y registrar el código. |
| PRY-200/D1, 201/D2, 206/D1, 207/D2, 208/D1, 209/D1 | Consejo de Administración (aprobación del reglamento) | No | En 208 ya se materializó: el Consejo pidió ajustes (incidencia, informe 2026-10-11). Los otros cinco no dicen en qué estado está la aprobación. |
| PRY-211/D1 | Proveedor de la última entrega | No: "no ha confirmado la fecha" (informe 2026-10-05) | Declarada, no acordada. |
| PRY-203/D1 | Proveedor de la siguiente fase | No | Dicha en reunión, sin respuesta del proveedor. |

Ninguna dependencia trae el código de otro proyecto. El cruce que prevé el método (B depende de A, A movió la fecha) solo se pudo hacer como hipótesis para el core.

### Registro completo
Los Id son rótulos provisionales de esta corrida (las fichas no traen Id de RAID). Prob./Impacto: ninguna ficha los trae y la organización no define escala, por eso van "no declarada"; no usé alta/media/baja para no inventar precisión. "Último movimiento" es la fecha del informe donde apareció el ítem. (r) = reclasificado; (nr) = no estaba en la ficha.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199/D1 | Dependencia (r) | Proveedor del core cooperativo | — | no declarado | no identificado | — | 2026-10-13 |
| PRY-200/R1 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarado | no identificado | — | 2026-10-10 |
| PRY-200/D1 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-10 |
| PRY-200/I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no declarado | no identificado | — | 2026-10-10 |
| PRY-201/D1 | Dependencia (r) | Proveedor del core cooperativo | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-201/D2 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-201/I1 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-202/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarado | no identificado | — | 2026-10-14 |
| PRY-202/D1 | Dependencia (r) | Proveedor del core cooperativo | — | no declarado | no identificado | — | 2026-10-14 |
| PRY-202/I1 | Incidencia (nr) | Hallazgo de seguridad en la revisión de arquitectura | — | no declarado | no identificado | — | 2026-10-14 |
| PRY-202/I2 | Incidencia (nr) | El Consejo pidió ajustar el reglamento antes del piloto | — | no declarado | no identificado | — | 2026-10-14 |
| PRY-203/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarado | no identificado | — | 2026-10-13 |
| PRY-203/R2 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarado | no identificado | — | 2026-10-13 |
| PRY-203/D1 | Dependencia (r, no formal) | Proveedor podría no llegar con el equipo completo para la siguiente fase | — | no declarado | no identificado | — | 2026-10-15 |
| PRY-203/I1 | Incidencia (nr) | Salida reprogramada por el cierre contable; sin fecha nueva | — | no declarado | no identificado | — | 2026-10-13 |
| PRY-204/R1 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarado | no identificado | — | 2026-10-15 |
| PRY-204/I1 | Incidencia (nr) | El Consejo pidió ajustar el reglamento antes del piloto | — | no declarado | no identificado | — | 2026-10-15 |
| PRY-205/R1 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarado | no identificado | — | 2026-10-14 |
| PRY-205/I1 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | no declarado | no identificado | — | 2026-10-14 |
| PRY-206/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarado | no identificado | — | 2026-10-12 |
| PRY-206/D1 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-12 |
| PRY-206/I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no declarado | no identificado | — | 2026-10-12 |
| PRY-206/I2 | Incidencia | Salida reprogramada por el cierre contable; sin fecha nueva | — | no declarado | no identificado | — | 2026-10-12 |
| PRY-207/D1 | Dependencia (r) | Proveedor del core cooperativo | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-207/D2 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-207/I1 | Incidencia | Salida reprogramada por el cierre contable; sin fecha nueva | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-208/R1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarado | no identificado | — | 2026-10-11 |
| PRY-208/D1 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-11 |
| PRY-208/I1 | Incidencia | Salida reprogramada por el cierre contable; sin fecha nueva | — | no declarado | no identificado | — | 2026-10-11 |
| PRY-208/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no declarado | no identificado | — | 2026-10-11 |
| PRY-208/I3 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | — | no declarado | no identificado | — | 2026-10-11 |
| PRY-209/D1 | Dependencia (r) | Aprobación del reglamento por el Consejo | — | no declarado | no identificado | — | 2026-10-13 |
| PRY-209/I1 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | no declarado | no identificado | — | 2026-10-13 |
| PRY-209/I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no declarado | no identificado | — | 2026-10-13 |
| PRY-210/R1 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarado | no identificado | — | 2026-10-10 |
| PRY-211/D1 | Dependencia (r) | El proveedor no ha confirmado la fecha de la última entrega | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-211/I1 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | — | no declarado | no identificado | — | 2026-10-05 |
| PRY-211/I2 | Incidencia | Prueba de carga no alcanzó el umbral; se repite | — | no declarado | no identificado | — | 2026-10-05 |

**Por qué reclasifiqué:** "Dependencia del proveedor del core", "Aprobación del reglamento por el Consejo" y "el proveedor no ha confirmado la fecha" dependen de alguien fuera del proyecto, así que son dependencias y no riesgos (se coordinan y se confirman, no se mitigan). "El proveedor podría no llegar…" también: es la entrega de un tercero. Quedaron como riesgo el cambio normativo y la concentración del conocimiento.

**Supuestos: cero.** Ninguna ficha ni documento declara uno. No inventé ninguno; los que suelen faltar (persona clave disponible, ambiente listo, aprobación que sea trámite) no aparecen dichos en estos documentos.

### Lo que no sé
- Quién es el proveedor del core y si es el de PRY-202.
- Si "el reglamento" es uno solo o varios.
- Si la "rotación de un desarrollador clave" (200, 206, 208, 209) es la misma persona.
- Si algo lleva dos períodos sin movimiento: hay un solo informe por proyecto.
- No hay mitigaciones registradas, así que ninguna puede estar vencida.
- Plazo del plan de PRY-202: el cronograma v2 fija el fin vigente en 2026-07-06, anterior a hoy, con 76% de avance en Verde. No es un ítem RAID, pero conviene verlo con `/health-check PRY-202`.

### Después
Cumplen el criterio de escalamiento (afectan a otros proyectos, doliente externo sin respuesta): **TRANSV-1** (Consejo/reglamento) y **TRANSV-2** (proveedor del core). Los proyectos en Rojo (201, 207, 209) tienen incidencias abiertas sin doliente. Puedo preparar la decisión formulada de las dos primeras para el comité del 2026-10-22, y proponer un doliente por ítem (el gerente de cada proyecto es el candidato natural); proponer, no asignar.

---
Pie de rigor: borrador de trabajo hecho sobre los documentos de la carpeta; no sabe lo que se habló fuera de ellos. Cada dato lleva su origen en la ficha o el informe citado; la verificación es suya.
