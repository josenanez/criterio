# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 24 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Barrido: 79 documentos sin cambios; 7 citas de PRY-203 con ruta sin carpeta de proyecto (el documento existe). Confirmación tocaba y no se hizo: nadie podía responder.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 79 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada cruzó un umbral. Sí hay una cita rota:

- **PRY-203** (aportes-sociales-en-línea): 7 campos de identidad (código, nombre, área, producto, patrocinador, gerente, comité) citan `00-gobierno/2025-10-09-acta-constitucion.md`, sin la carpeta del proyecto. El documento existe en `PRY-203-aportes-sociales-en-línea/00-gobierno/`; lo que no resuelve es la ruta de la cita, y las fichas de los demás proyectos sí la llevan completa. No reescribí la ficha: corregir la ruta pide recalcular PRY-203 con `/portfolio-scan`.

### Peticiones atendidas
No se consultó la bandeja de peticiones: `requests` no estaba entre lo que tocaba hoy.

### Preguntas
La confirmación periódica tocaba (nunca se ha hecho). En esta sesión nadie puede responder, así que no formulé preguntas ni la marqué como hecha; vuelve a tocar mañana.

**Vuelvo el 2026-10-16.** El informe de comité se genera el 2026-10-20 para el comité del 2026-10-22.
