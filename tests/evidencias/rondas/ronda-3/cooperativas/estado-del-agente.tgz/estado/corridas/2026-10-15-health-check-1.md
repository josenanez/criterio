# Corrida del 2026-10-15 · health-check

13 proyectos · 81 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico de PRY-202 sobre 7 documentos: 4 sostenidas, 7 sin sustento, 3 contradichas. Dijo que no puede afirmar el verde, que no hay autoridad declarada, ni evidencia del piloto, de CC-01 ni de v2, y que no buscó mencion en pdf/docx/xlsx de otras carpetas.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-202 Core cooperativo · 2026-10-15

**Leí:** 7 documentos del proyecto · 2025-05-17 a 2026-10-15 · formatos: md (5), csv (1), xlsx (1)
**Además:** busqué «PRY-202» y «core cooperativo» en el texto de las demás carpetas de proyectos. Ningún documento de otro proyecto habla de PRY-202; las coincidencias son hitos con el mismo nombre en los planes de PRY-204, 205, 206 y 208 y actas de PRY-201 y PRY-209, que son entregables de esos proyectos.
**No pude leer:** los .pdf, .docx y .xlsx de las otras carpetas no se buscaron por texto (la búsqueda solo cubre md y csv), así que una mención de PRY-202 ahí no la habría visto. Los términos de uso ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvió a registrar.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 3

Desde esta carpeta se puede afirmar quién patrocina y gestiona el proyecto, cuánto se aprobó y cuál fue el plan original. No se puede afirmar que el proyecto esté en verde. El informe dice 76 % de avance; el cronograma v2, fechado el mismo día, tiene cuatro de cuatro hitos cerrados. El piloto figura cerrado el 2026-07-06, pero el informe del 2026-10-14 dice que el Consejo pidió ajustar el reglamento «antes del piloto». De los 16 datos de la ficha, ninguno viene de un documento de evidencia: 2 son declaración del gerente y 14 no están marcados.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Ricardo Salas | acta de constitución 2025-05-17 |
| Gerente | Camilo Beltrán | acta de constitución 2025-05-17 |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o fechas | acta de constitución 2025-05-17 |
| Comité | Consejo de Administración (aprobó el presupuesto). Ricardo Salas y Camilo Beltrán asistieron a la reunión del 2026-10-15 | acta 2025-05-17; minuta 2026-10-15 |

Otros hechos del acta: «Producto asociado: No aplica»; alcance «Componente 1, 2 y 3» sin descripción; fuera de alcance «Lo que otro proyecto cubre»; dependencias «Ninguna declarada», aunque el informe del 2026-10-14 declara una dependencia del proveedor del core. Todos los campos de identidad tienen 17 meses de antigüedad (umbral: 12).

### Contra el plan
- **Línea base original (v1, 2025-05-17):** cierre comprometido 2026-04-14 en el acta; último hito (Piloto con asociados) 2026-03-09 en el cronograma v1.
- **Línea base vigente (v2, 2026-10-14):** el piloto pasa al 2026-07-06. Los otros tres hitos no se mueven. El archivo no trae motivo de la replanificación.
- **Desviación:** 119 días contra la original, 41,6 %; 0 días contra la vigente. Supera el umbral de 10 %.
- **CC-01 (2026-10-02):** pide +119 días «sobre la línea base vigente» y 238.000.000 COP adicionales por una ampliación de alcance. Los 119 días coinciden exactamente con el movimiento del piloto en v2. Pero la nueva fecha del piloto (2026-07-06) ya había pasado tres meses antes de la solicitud, y v2 se fecha 12 días después de ella. Es decir, la fecha se movió a una que ya había pasado.
- **La ampliación de alcance no aparece** en el alcance, que sigue siendo el del acta. El presupuesto aprobado tampoco la incorpora.
- **Decisión:** «Autorizada por el comité». No dice cuál comité, quién firmó ni en qué fecha decidió. No existe acta de comité de esa decisión.
- **Lo que mide el cierre:** el criterio de éxito («en producción y medido») no corresponde a ningún hito del cronograma. El último hito es el piloto.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ambiente de pruebas certificado | 2025-10-17 | 363 | Certificado o acta de recibo del ambiente de pruebas |
| Integración con el core cooperativo | 2025-12-27 | 292 | Acta de recibo de la integración |
| Piloto con asociados | 2026-07-06 | 101 | Acta de recibo o informe del piloto con resultados |

Cuenta aparte, el hito «Diseño funcional aprobado»: tiene acta de recibo, pero su fecha de recibo es 2026-10-06, y el cronograma lo da por cerrado el 2025-08-06. Además el acta la recibe Camilo Beltrán, que es el gerente, sin firma de patrocinador ni de usuario.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.390.493.898 | 876.426.100 | 2.493.540.214 | 1.009.506.102 |

COP. Comprometido 57,9 %; ejecutado 36,5 %. La proyección excede lo aprobado en 3,9 %. Con 36,5 % de ejecución y 76 % de avance declarado, o el avance está inflado o el gasto no está registrado: la carpeta no permite saber cuál. Las cuatro cifras vienen solo del informe de avance; no hay ejecución presupuestal ni contratos que las respalden. Los 238.000.000 COP de CC-01 no están sumados al aprobado, y ningún documento dice si la proyección los incluye. El proyecto no tiene proveedores registrados, pese a declarar dependencia del proveedor del core.

### Lo que se dijo y nadie registró
No existe ningún registro RAID en la carpeta. Esto está dicho en documentos y no en ningún registro:
- **Incidencia:** «Se levantó un hallazgo de seguridad en la revisión de arquitectura» (informe 2026-10-14). Sin responsable, gravedad ni fecha de cierre. Además el informe lo da por «lo que pasó» y mantiene el verde.
- **Riesgo:** cambio normativo del supervisor que puede mover el alcance. Sin probabilidad, impacto ni dueño.
- **Riesgo/dependencia:** el proveedor del core cooperativo. Sin probabilidad, impacto ni dueño, y contradice «Ninguna declarada» del acta.
- **Dependencia o condición:** el Consejo pidió ajustar el reglamento antes del piloto. No tiene responsable ni fecha.
- **Compromiso:** Óscar Ramírez, «Entregar el punto 35», para el 2026-10-27 (dicho el 2026-10-15). No vencido. Ningún documento define qué es el «punto 35», y Óscar Ramírez no aparece en ningún documento de gobierno del proyecto.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 76 % | Informe 2026-10-14: 76 % | Cronograma v2 2026-10-14: 4 de 4 hitos «cerrado» (100 %) |
| Piloto con asociados cerrado el 2026-07-06 | Cronograma v2: estado «cerrado» | Informe 2026-10-14: el Consejo pidió ajustar el reglamento «antes del piloto» |
| Diseño funcional aprobado el 2025-08-06 | Cronograma v1 y v2: fecha vigente 2025-08-06, «cerrado» | Acta de recibo: fecha de recibo 2026-10-06 |

### Sin sustento
Nada la contradice ni la respalda:
- **Estado «Verde».** Declarado por el gerente. Las alertas calculadas lo contradicen en espíritu (desviación de 41,6 %, tres hitos sin evidencia, brecha de 24 puntos de avance), pero ningún documento lo desmiente por sí solo. Sin sustento, con tres señales abiertas que el informe no explica.
- **Ambiente de pruebas certificado: cerrado.**
- **Integración con el core cooperativo: cerrada.**
- **CC-01 aprobada por el comité.** Sin acta, sin nombre, sin fecha de decisión.
- **Comprometido, ejecutado y proyección** (solo informe).
- **Los dos riesgos abiertos** del informe: existen como texto, no como registro.
- **El hallazgo de seguridad:** no hay documento de la revisión de arquitectura.

### Lo que esta carpeta no permite saber
- **Si el piloto ocurrió:** no hay acta ni informe del piloto. Consecuencia: no se puede decir si el proyecto está en el 100 %, en el 76 % o en un punto anterior.
- **Si el proyecto tiene autoridad para mover sus fechas:** el acta no declara autoridad ni umbrales. Consecuencia: sin autoridad declarada no hay desviación aprobada; hay fechas que alguien escribió. Quien tiene la facultad debe confirmar si v2 está aprobada.
- **Quién y cuándo aprobó CC-01 y v2:** sin eso, los 119 días y los 238.000.000 COP son una solicitud con una frase de autorización.
- **Por qué se replanificó:** v2 no trae motivo. Consecuencia: no se puede separar atraso de ampliación de alcance.
- **Qué incluye la ampliación de alcance:** el alcance sigue como «Componente 1, 2 y 3». Consecuencia: no se puede medir contra qué se entrega.
- **Cómo se llega a producción medida:** el criterio de éxito no tiene hito. Consecuencia: el proyecto puede cerrar todos sus hitos sin cumplir el acta.
- **Si el gasto es real:** sin ejecución presupuestal ni contratos, las cuatro cifras son declaración.
- **Gravedad del hallazgo de seguridad** y su efecto sobre el piloto.

### Siguiente paso
El diagnóstico no recomienda detener, continuar ni reestructurar; eso lo decide quien tiene la facultad. La carpeta permite dictaminar, pero no sostener el verde. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las tres contradicciones a Camilo Beltrán como preguntas, una por una.

*Pie de rigor: cifras derivadas copiadas del cálculo de la corrida (compute); todo lo demás, de los 7 documentos citados. Borrador de trabajo: la verificación es de quien lo lee.*
