## Carpeta al 2026-10-15

**Documentos:** 79 · **Sin cambio:** 79 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ningún documento.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.name | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.business_area | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.product | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.sponsor | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.manager | 00-gobierno/2025-10-09-acta-constitucion.md |
| PRY-203 | pm_record.identity.committee | 00-gobierno/2025-10-09-acta-constitucion.md |

Las siete citas de la identidad de PRY-203 apuntan al mismo documento, el acta de constitución, que no resuelve. No aparece como borrado ni como renombrado en el índice: la ficha cita una ruta que no existe en la carpeta. La ficha sigue mostrando esos datos como sustentados y ya no lo están. Hay que ubicar el acta o corregir la ruta citada.

### Formatos que no se pudieron leer
Ninguno.

Nada que releer, así que no hay barrido que ofrecer: `projects_to_recompute` está vacío.
