# Rostrum — modo «para mirarlo un rato»

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Informe encontrado en `reportes/` (13 proyectos, 7 productos, decisiones, listados).

Elegí la primera forma («para mirarlo un rato») porque es la que pediste y la recomendada para empezar: se levanta en diez segundos y no obliga a hablar con seguridad todavía.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

Aviso: en `reportes/` no hay un `pmo.html` generado; si `/pmo` no responde, hay que correr `/portfolio-report html` otra vez.

Lo que Rostrum no hace: no calcula (sirve lo que ya escribió el informe), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda correos. Las peticiones del formulario esperan a que el agente despierte; una abierta rompe el silencio de `/portfolio-wake`.

Cierre: este enlace (`http://127.0.0.1:8787`) solo funciona en este equipo y mientras el proceso siga vivo; no se le puede pasar al patrocinador. Para eso hace falta la forma «que quede corriendo» (`--abierto`, tras el control de acceso de la organización). El informe estará desactualizado en cuanto cambie algún documento o se corra un nuevo barrido; la portada muestra la fecha del informe.
