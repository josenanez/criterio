# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 64 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `rebaseline_unauthorized` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Informe encontrado en `reportes/` (13 proyectos, 7 productos, decisiones, listados).

Elegí la primera forma («para mirarlo un rato») porque es la que pediste y la recomendada para empezar: se levanta en diez segundos y no obliga a hablar con seguridad todavía.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

Aviso: en `reportes/` no hay un `pmo.html` generado; si `/pmo` no responde, hay que correr `/portfolio-report html` otra vez.

Lo que Rostrum no hace: no calcula (sirve lo que ya escribió el informe), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda correos. Las peticiones del formulario esperan a que el agente despierte; una abierta rompe el silencio de `/portfolio-wake`.

Cierre: este enlace (`http://127.0.0.1:8787`) solo funciona en este equipo y mientras el proceso siga vivo; no se le puede pasar al patrocinador. Para eso hace falta la forma «que quede corriendo» (`--abierto`, tras el control de acceso de la organización). El informe estará desactualizado en cuanto cambie algún documento o se corra un nuevo barrido; la portada muestra la fecha del informe.
