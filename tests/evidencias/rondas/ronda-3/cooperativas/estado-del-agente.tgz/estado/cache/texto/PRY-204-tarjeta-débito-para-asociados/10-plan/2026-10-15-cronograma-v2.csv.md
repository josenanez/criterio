<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2026-10-15-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-07-28,2026-07-28,cerrado
Ambiente de pruebas certificado,2026-11-21,2026-11-21,en curso
Integración con el core cooperativo,2027-03-17,2027-07-07,en curso
