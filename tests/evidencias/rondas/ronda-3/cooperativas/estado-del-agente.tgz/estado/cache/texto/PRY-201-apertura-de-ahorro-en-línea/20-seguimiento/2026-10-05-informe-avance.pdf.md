<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-05
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 27%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.766.031.514
Ejecutado 1.052.557.778
Proyección al cierre 4.164.612.267

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
