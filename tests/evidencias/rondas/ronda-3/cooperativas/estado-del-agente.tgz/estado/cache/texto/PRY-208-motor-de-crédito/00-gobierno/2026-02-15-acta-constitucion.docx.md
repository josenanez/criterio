<!-- origen: PRY-208-motor-de-crédito/00-gobierno/2026-02-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de crédito

Código: PRY-208

Área dueña: Cartera y cobranza

Patrocinador: María Restrepo

Gerente de proyecto: Liliana Torres

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2026-02-15

Objetivo del negocio

Entregar motor de crédito para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Tecnología el 2026-02-15.

Fechas comprometidas

Fecha

Inicio

2026-02-25

Cierre

2027-09-11

Criterio de éxito

Motor de crédito en producción y medido.

Dependencias declaradas

• Ninguna declarada
