<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Prevención de lavado de activos

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 4 | 2026-10-16 |
| Paula Céspedes | Entregar el punto 24 | 2026-09-30 |
