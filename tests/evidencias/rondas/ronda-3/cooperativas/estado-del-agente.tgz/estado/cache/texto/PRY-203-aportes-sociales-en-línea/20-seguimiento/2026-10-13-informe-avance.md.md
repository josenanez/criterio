<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-13
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **60%**

## Lo que pasó en el periodo

- Se recibió el concepto pendiente del ente supervisor
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.575.699.452 |
| Ejecutado | 1.339.456.908 |
| Proyección al cierre | 3.275.110.424 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Concentración del conocimiento en una sola persona
