<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2025-12-12-acta-recibo-ct-869-licenciamiento-del-módulo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento del módulo
Proyecto: PRY-205 · Prevención de lavado de activos
Fecha de recibo: 2025-12-12
Recibido por: Rubén Cárdenas
Se recibe a satisfacción el entregable Licenciamiento del módulo.
Contrato CT-869 · Red Rural de Pagos S.A.S..
