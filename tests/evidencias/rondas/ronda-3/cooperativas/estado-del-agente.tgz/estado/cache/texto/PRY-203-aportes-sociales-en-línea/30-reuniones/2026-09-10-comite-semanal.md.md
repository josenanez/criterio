<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-09-10
**Asistentes:** Beatriz Cuéllar, Gustavo Neira, Javier Hoyos, Laura Vélez, María Restrepo, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-12 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-30 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-14 |
| Laura Vélez | Validar el ambiente 4 | por definir |
| Javier Hoyos | Aprobar el diseño 5 | 2026-09-22 |
| Beatriz Cuéllar | Actualizar la matriz 6 | 2026-09-15 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-14 |
| Sandra Gil | Entregar el punto 8 | 2026-10-06 |
