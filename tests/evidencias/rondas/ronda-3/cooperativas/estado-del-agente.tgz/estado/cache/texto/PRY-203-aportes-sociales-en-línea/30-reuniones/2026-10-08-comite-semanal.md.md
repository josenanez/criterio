<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-10-08
**Asistentes:** Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-28 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-29 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-27 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-13 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 |
| Sandra Gil | Enviar el documento 9 | 2026-10-26 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-26 |
| Laura Vélez | Actualizar la matriz 14 | 2026-11-07 |
| Felipe Arango | Entregar el punto 16 | por definir |
| Jorge Medina | Cerrar la prueba 18 | 2026-10-24 |
| Natalia Ospina | Revisar el anexo 19 | 2026-10-26 |
| Jorge Medina | Validar el ambiente 20 | 2026-10-25 |
| Sandra Gil | Aprobar el diseño 21 | 2026-10-15 |
| Ricardo Salas | Actualizar la matriz 22 | 2026-10-14 |
| Felipe Arango | Confirmar la fecha 23 | 2026-11-05 |
| Paula Céspedes | Entregar el punto 24 | 2026-10-29 |

## Cerrados en esta reunión

- Revisar el anexo 11 (Jorge Medina): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- María Restrepo dice que ya entregó «confirmar la fecha 15». No se presentó acta.
- Carlos Peña dice que ya entregó «enviar el documento 17». No se presentó acta.
