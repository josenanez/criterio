<!-- origen: PRY-200-crédito-de-libranza-digital/00-gobierno/2026-03-03-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Crédito de libranza digital

**Código:** PRY-200
**Área dueña:** Tesorería
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Tecnología
**Producto asociado:** crédito de libranza
**Fecha de aprobación:** 2026-03-03

## Objetivo del negocio

Entregar crédito de libranza digital para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Tecnología el 2026-03-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-13 |
| Cierre | 2027-08-06 |

## Criterio de éxito

Crédito de libranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
