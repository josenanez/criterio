<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-10-acta-recibo-integración-con-el-core-cooperativo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Integración con el core cooperativo
Proyecto: PRY-209 · Convenios de libranza con empresas
Fecha de recibo: 2026-10-10
Recibido por: Laura Vélez
Se recibe a satisfacción el entregable Integración con el core cooperativo.
