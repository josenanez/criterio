<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-02-18-acta-recibo-ct-869-bolsa-de-horas-de-desarrollo.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Bolsa de horas de desarrollo

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha de recibo:** 2026-02-18
**Recibido por:** Rubén Cárdenas

Se recibe a satisfacción el entregable **Bolsa de horas de desarrollo**.

Contrato CT-869 · Red Rural de Pagos S.A.S..
