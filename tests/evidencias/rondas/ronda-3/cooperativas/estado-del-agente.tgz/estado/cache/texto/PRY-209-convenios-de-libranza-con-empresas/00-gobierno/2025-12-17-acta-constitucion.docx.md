<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2025-12-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Convenios de libranza con empresas

Código: PRY-209

Área dueña: Crédito

Patrocinador: María Restrepo

Gerente de proyecto: Laura Vélez

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2025-12-17

Objetivo del negocio

Entregar convenios de libranza con empresas para Crédito.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Crédito el 2025-12-17.

Fechas comprometidas

Fecha

Inicio

2025-12-27

Cierre

2027-03-15

Criterio de éxito

Convenios de libranza con empresas en producción y medido.

Dependencias declaradas

• Ninguna declarada
