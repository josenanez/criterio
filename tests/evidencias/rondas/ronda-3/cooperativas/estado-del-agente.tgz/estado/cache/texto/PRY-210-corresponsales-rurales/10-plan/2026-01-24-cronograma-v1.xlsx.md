<!-- origen: PRY-210-corresponsales-rurales/10-plan/2026-01-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-19 | 2026-04-19 | cerrado
Ambiente de pruebas certificado | 2026-07-03 | 2026-07-03 | cerrado
Integración con el core cooperativo | 2026-09-16 | 2026-09-16 | cerrado
Piloto con asociados | 2026-11-30 | 2026-11-30 | en curso
