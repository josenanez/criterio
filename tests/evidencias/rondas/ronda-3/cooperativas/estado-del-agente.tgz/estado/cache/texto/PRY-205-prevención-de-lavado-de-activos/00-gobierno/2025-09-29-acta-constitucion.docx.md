<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-09-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Servicio al asociado

Patrocinador: Carlos Peña

Gerente de proyecto: Rubén Cárdenas

Comité: Consejo de Administración

Producto asociado: No aplica

Fecha de aprobación: 2025-09-29

Objetivo del negocio

Entregar prevención de lavado de activos para Servicio al asociado.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Consejo de Administración el 2025-09-29.

Fechas comprometidas

Fecha

Inicio

2025-10-09

Cierre

2026-06-20

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
