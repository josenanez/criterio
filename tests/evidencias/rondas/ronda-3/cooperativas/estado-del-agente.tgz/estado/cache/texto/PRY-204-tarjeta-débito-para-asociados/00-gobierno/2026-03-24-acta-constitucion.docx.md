<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2026-03-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tarjeta débito para asociados

Código: PRY-204

Área dueña: Crédito

Patrocinador: Felipe Arango

Gerente de proyecto: Ricardo Salas

Comité: Comité de Crédito

Producto asociado: tarjeta débito

Fecha de aprobación: 2026-03-24

Objetivo del negocio

Entregar tarjeta débito para asociados para Crédito.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Crédito el 2026-03-24.

Fechas comprometidas

Fecha

Inicio

2026-04-03

Cierre

2027-05-15

Criterio de éxito

Tarjeta débito para asociados en producción y medido.

Dependencias declaradas

• Ninguna declarada
