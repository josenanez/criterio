<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Convenios de libranza con empresas

**Código:** PRY-209
**Fecha de corte:** 2026-10-13
**Gerente:** Laura Vélez

## Estado declarado

**Rojo**

Avance reportado: **66%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.216.644.126 |
| Ejecutado | 3.519.689.515 |
| Proyección al cierre | 17.179.849.890 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
