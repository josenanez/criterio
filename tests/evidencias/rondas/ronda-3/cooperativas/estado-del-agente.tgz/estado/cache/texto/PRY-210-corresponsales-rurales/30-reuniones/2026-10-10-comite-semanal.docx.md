<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Consejo de Administración · Corresponsales rurales

Fecha: 2026-10-10

Asistentes: María Restrepo, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Elena Duarte

Entregar el punto 1

2026-09-25
