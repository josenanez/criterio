<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pagos con QR
Código: PRY-206
Fecha de corte: 2026-10-12
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 50%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 720.144.603
Ejecutado 821.233.249
Proyección al cierre 3.033.676.286

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
- Cambio normativo del supervisor que puede mover el alcance
