<!-- origen: PRY-202-core-cooperativo/10-plan/2025-05-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-08-06,2025-08-06,cerrado
Ambiente de pruebas certificado,2025-10-17,2025-10-17,cerrado
Integración con el core cooperativo,2025-12-27,2025-12-27,cerrado
Piloto con asociados,2026-03-09,2026-03-09,cerrado
