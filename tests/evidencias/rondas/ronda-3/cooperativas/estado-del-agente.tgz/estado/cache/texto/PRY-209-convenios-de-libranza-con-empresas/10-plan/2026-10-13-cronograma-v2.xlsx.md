<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-17 | 2026-03-17 | cerrado
Ambiente de pruebas certificado | 2026-06-06 | 2026-06-06 | cerrado
Integración con el core cooperativo | 2026-08-25 | 2026-08-25 | cerrado
Piloto con asociados | 2026-11-14 | 2026-11-14 | en curso
Salida a producción | 2027-02-02 | 2027-03-17 | en curso
