<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-10-11-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-08-04,2026-08-04,cerrado
Ambiente de pruebas certificado,2027-01-12,2027-01-12,en curso
Integración con el core cooperativo,2027-06-22,2027-07-25,en curso
