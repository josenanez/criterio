<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-10-05
Gerente: Felipe Arango

Estado declarado
Rojo
Avance reportado: 81%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 4.013.515.654
Ejecutado 5.227.286.494
Proyección al cierre 9.169.395.432

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
