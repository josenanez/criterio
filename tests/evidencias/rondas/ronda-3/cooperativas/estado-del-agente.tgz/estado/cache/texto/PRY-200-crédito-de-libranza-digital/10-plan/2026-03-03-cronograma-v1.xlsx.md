<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2026-03-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-04 | 2026-07-04 | cerrado
Ambiente de pruebas certificado | 2026-10-26 | 2026-10-26 | en curso
Integración con el core cooperativo | 2027-02-16 | 2027-02-16 | en curso
Piloto con asociados | 2027-06-10 | 2027-06-10 | en curso
