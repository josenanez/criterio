<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-09-24
**Asistentes:** Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-01 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-29 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-14 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-06 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 |
| Sandra Gil | Enviar el documento 9 | 2026-10-06 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-08 |
| Natalia Ospina | Validar el ambiente 12 | por definir |
| Diana Molina | Aprobar el diseño 13 | 2026-10-17 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-18 |
| María Restrepo | Confirmar la fecha 15 | por definir |
| Felipe Arango | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Validar el ambiente 4 (Laura Vélez): recibido, acta de recibo del 2026-09-24.
