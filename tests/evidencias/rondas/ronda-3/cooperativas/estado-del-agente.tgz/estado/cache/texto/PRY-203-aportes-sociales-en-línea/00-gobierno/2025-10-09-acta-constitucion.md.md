<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-10-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Aportes sociales en línea

**Código:** PRY-203
**Área dueña:** Tesorería
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Educación
**Producto asociado:** aportes sociales
**Fecha de aprobación:** 2025-10-09

## Objetivo del negocio

Entregar aportes sociales en línea para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Educación el 2025-10-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-19 |
| Cierre | 2026-06-28 |

## Criterio de éxito

Aportes sociales en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
