<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2025-12-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Riesgo y Cumplimiento

Patrocinador: Gustavo Neira

Gerente de proyecto: Felipe Arango

Comité: Comité de Educación

Producto asociado: microcrédito

Fecha de aprobación: 2025-12-22

Objetivo del negocio

Entregar microcrédito rural para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Educación el 2025-12-22.

Fechas comprometidas

Fecha

Inicio

2026-01-01

Cierre

2026-10-15

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
