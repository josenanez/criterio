<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2025-10-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-12-03 | 2025-12-03 | cerrado
Ambiente de pruebas certificado | 2026-01-18 | 2026-01-18 | cerrado
Integración con el core cooperativo | 2026-03-05 | 2026-03-05 | cerrado
Piloto con asociados | 2026-04-20 | 2026-04-20 | cerrado
Salida a producción | 2026-06-05 | 2026-06-05 | cerrado
