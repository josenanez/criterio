<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Core cooperativo

**Fecha:** 2026-10-15
**Asistentes:** Camilo Beltrán, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 35 | 2026-10-27 |
