<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-10
**Gerente:** María Restrepo

## Estado declarado

**Amarillo**

Avance reportado: **25%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.968.436.555 |
| Ejecutado | 1.624.515.840 |
| Proyección al cierre | 4.347.669.001 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
