<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-09-03
**Asistentes:** Laura Vélez, María Restrepo, Paula Céspedes, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-09-21 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-13 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-14 |
| Laura Vélez | Validar el ambiente 4 | por definir |
