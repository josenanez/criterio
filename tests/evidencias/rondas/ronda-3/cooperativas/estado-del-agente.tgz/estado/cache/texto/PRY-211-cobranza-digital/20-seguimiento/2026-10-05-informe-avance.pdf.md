<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-05
Gerente: Natalia Ospina

Estado declarado
Verde
Avance reportado: 39%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.242.038.909
Ejecutado 539.491.951
Proyección al cierre 2.227.788.030

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
