<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-11
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **74%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- El equipo perdió dos semanas por rotación de un desarrollador clave
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 532.753.384 |
| Ejecutado | 145.357.128 |
| Proyección al cierre | 744.661.313 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Aprobación del reglamento por el Consejo de Administración
