<!-- origen: PRY-202-core-cooperativo/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-08-06 | 2025-08-06 | cerrado
Ambiente de pruebas certificado | 2025-10-17 | 2025-10-17 | cerrado
Integración con el core cooperativo | 2025-12-27 | 2025-12-27 | cerrado
Piloto con asociados | 2026-03-09 | 2026-07-06 | cerrado
