<!-- origen: PRY-204-tarjeta-débito-para-asociados/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Crédito · Tarjeta débito para asociados

Fecha: 2026-10-13

Asistentes: Ricardo Salas, Felipe Arango

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Entregar el punto 40

por definir
