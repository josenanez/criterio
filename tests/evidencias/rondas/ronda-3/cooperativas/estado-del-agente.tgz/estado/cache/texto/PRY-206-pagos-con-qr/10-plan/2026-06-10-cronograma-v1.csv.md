<!-- origen: PRY-206-pagos-con-qr/10-plan/2026-06-10-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-12,2026-09-12,cerrado
Ambiente de pruebas certificado,2026-12-05,2026-12-05,en curso
Integración con el core cooperativo,2027-02-28,2027-02-28,en curso
Piloto con asociados,2027-05-23,2027-05-23,en curso
