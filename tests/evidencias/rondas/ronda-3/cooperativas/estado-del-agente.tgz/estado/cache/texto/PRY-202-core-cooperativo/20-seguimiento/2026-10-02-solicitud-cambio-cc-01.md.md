<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-02-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Core cooperativo
**Fecha:** 2026-10-02
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +119 días sobre la línea base vigente |
| Costo | 238.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
