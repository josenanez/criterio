<!-- origen: PRY-202-core-cooperativo/00-gobierno/2025-05-17-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Ahorro y aportes
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-17

## Objetivo del negocio

Entregar core cooperativo para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Consejo de Administración el 2025-05-17.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-27 |
| Cierre | 2026-04-14 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
