<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2025-07-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-17 | 2025-11-17 | cerrado
Ambiente de pruebas certificado | 2026-03-08 | 2026-03-08 | cerrado
Integración con el core cooperativo | 2026-06-27 | 2026-06-27 | cerrado
Piloto con asociados | 2026-10-16 | 2026-10-16 | en curso
