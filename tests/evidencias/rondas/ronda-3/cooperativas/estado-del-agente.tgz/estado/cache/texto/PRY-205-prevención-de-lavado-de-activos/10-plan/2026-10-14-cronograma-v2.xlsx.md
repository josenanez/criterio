<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-24 | 2025-11-24 | cerrado
Ambiente de pruebas certificado | 2026-01-09 | 2026-01-09 | cerrado
Integración con el core cooperativo | 2026-02-24 | 2026-02-24 | cerrado
Piloto con asociados | 2026-04-11 | 2026-04-11 | cerrado
Salida a producción | 2026-05-27 | 2026-06-23 | cerrado
