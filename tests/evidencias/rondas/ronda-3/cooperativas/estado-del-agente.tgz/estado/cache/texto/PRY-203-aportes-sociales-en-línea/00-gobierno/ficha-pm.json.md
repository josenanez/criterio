<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-203",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "name": {
 "value": "Aportes sociales en línea",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "business_area": {
 "value": "Tesorería",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "product": {
 "value": "aportes sociales",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "sponsor": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "manager": {
 "value": "Óscar Ramírez",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Educación",
 "source": "00-gobierno/2025-10-09-acta-constitucion.md",
 "source_date": "2025-10-09",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "commitments": [
 {
 "who": "María Restrepo",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-12",
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "due_text": "la otra semana",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-25",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open"
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-29",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-13",
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-27",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-14",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "La fecha 2026-09-14 figuró en las minutas del 09-03 al 10-01 sin moverse y sin acta de recibo."
 },
 {
 "who": "Laura Vélez",
 "what": "Validar el ambiente 4",
 "due_date": "no_declarada",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "met",
 "closed_by": "20-seguimiento/2026-09-24-acta-recibo-4.md",
 "closed_on": "2026-09-24"
 },
 {
 "who": "Javier Hoyos",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-13",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-22",
 "reschedules": [
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-15",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "claimed_delivered": {
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "evidence": "ninguna: no se presentó acta"
 }
 },
 {
 "who": "Gustavo Neira",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-09-30",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-14",
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-06",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "claimed_delivered": {
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "evidence": "ninguna: no se presentó acta"
 }
 },
 {
 "who": "Sandra Gil",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-26",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-06",
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Liliana Torres",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-06",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-08",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "met",
 "closed_by": "20-seguimiento/2026-10-08-acta-recibo-11.md",
 "closed_on": "2026-10-08"
 },
 {
 "who": "Natalia Ospina",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-26",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-19",
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "Aparece sin fecha el 09-17 y el 09-24 (por definir); primera fecha el 10-01."
 },
 {
 "who": "Diana Molina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-17",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "claimed_delivered": {
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "evidence": "ninguna: no se presentó acta"
 }
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-11-07",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-18",
 "reschedules": [
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Confirmar la fecha 15",
 "due_date": "no_declarada",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "claimed_delivered": {
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "evidence": "ninguna: no se presentó acta"
 }
 },
 {
 "who": "Felipe Arango",
 "what": "Entregar el punto 16",
 "due_date": "no_declarada",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Carlos Peña",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-09",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "claimed_delivered": {
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "evidence": "ninguna: no se presentó acta"
 }
 },
 {
 "who": "Jorge Medina",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-24",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-17",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-26",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "note": "Sin fecha el 10-01 (por definir)."
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-25",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-11",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-15",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Ricardo Salas",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-14",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Felipe Arango",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-05",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open"
 },
 {
 "who": "Paula Céspedes",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-29",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (comentado en la reunión; nadie lo registró como riesgo)",
 "probability": "no_declarada",
 "impact": "no_declarado",
 "owner": "no_identificado",
 "due_date": null,
 "last_moved": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [
 {
 "path": "2026-10-15-notas-reunion.txt",
 "hash": "eeef5fe65cdabd2c3779b8c8e6962889dc1adfa9771231877bb943826a3c5f23",
 "date": "2026-10-15"
 },
 {
 "path": "30-reuniones/2026-10-08-comite-semanal.md",
 "hash": "fcdcea1d93da2fa9d8c34436316b8d8174453e1c868461f7bd8cfecb5d99baa4",
 "date": "2026-10-08"
 },
 {
 "path": "00-gobierno/2025-10-09-acta-constitucion.md",
 "hash": "7a415f2bd3f1db1d5f3607769ea44c99fefb7929f249669cc83ce1c2dbbd809a",
 "date": "2025-10-09"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "declared.status",
 "plan",
 "money"
 ],
 "open_conflicts": []
 }
}
