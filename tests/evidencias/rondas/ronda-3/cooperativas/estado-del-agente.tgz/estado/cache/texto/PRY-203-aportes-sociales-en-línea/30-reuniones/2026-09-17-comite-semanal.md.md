<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Aportes sociales en línea

**Fecha:** 2026-09-17
**Asistentes:** Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-22 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-13 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-14 |
| Laura Vélez | Validar el ambiente 4 | 2026-09-28 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-09-22 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 |
| Sandra Gil | Enviar el documento 9 | 2026-10-06 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-08 |
| Natalia Ospina | Validar el ambiente 12 | por definir |

## Lo que se dijo

- Beatriz Cuéllar dice que ya entregó «actualizar la matriz 6». No se presentó acta.
- Sandra Gil dice que ya entregó «entregar el punto 8». No se presentó acta.
