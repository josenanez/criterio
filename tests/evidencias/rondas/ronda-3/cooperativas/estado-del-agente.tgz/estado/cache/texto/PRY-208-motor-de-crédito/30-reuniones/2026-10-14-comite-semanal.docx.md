<!-- origen: PRY-208-motor-de-crédito/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Motor de crédito

Fecha: 2026-10-14

Asistentes: Liliana Torres, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Rubén Cárdenas

Entregar el punto 27

2026-11-09

Paula Céspedes

Entregar el punto 25

por definir
