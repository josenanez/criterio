<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/2026-01-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Corresponsales rurales

Código: PRY-210

Área dueña: Tecnología

Patrocinador: Jorge Medina

Gerente de proyecto: María Restrepo

Comité: Consejo de Administración

Producto asociado: No aplica

Fecha de aprobación: 2026-01-24

Objetivo del negocio

Entregar corresponsales rurales para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Consejo de Administración el 2026-01-24.

Fechas comprometidas

Fecha

Inicio

2026-02-03

Cierre

2027-01-07

Criterio de éxito

Corresponsales rurales en producción y medido.

Dependencias declaradas

• Ninguna declarada
