<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tarjeta débito para asociados
Código: PRY-204
Fecha de corte: 2026-10-15
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 74%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 8.176.188.289
Ejecutado 4.373.955.749
Proyección al cierre 9.409.033.806

Riesgos abiertos
- Concentración del conocimiento en una sola persona
