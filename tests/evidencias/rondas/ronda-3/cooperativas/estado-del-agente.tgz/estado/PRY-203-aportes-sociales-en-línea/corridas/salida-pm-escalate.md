## Para decisión — Aportes sociales en línea (PRY-203) · 2026-10-15

Sin tema en el argumento: tomé lo que ya estaba marcado como escalable en la ficha y en la agenda del 10-22. De eso, **un punto escala hoy y dos no están listos para escalar.**

### ¿Quién tiene la facultad de decidir sobre el proveedor, las fechas y el presupuesto de PRY-203, y hasta qué umbral: Óscar Ramírez, o el comité?

El acta de constitución del 2025-10-09 no trae ninguna sección de autoridad (`identity.authority`: no encontrado). Según la regla, **ese es el primer punto que escala**, antes que cualquier otro: sin él no se puede decir qué excede a Óscar y qué no.

**Quién decide:** el acta no lo dice. El patrocinador (Rubén Cárdenas) y el Comité de Educación, que aprobó el acta y el presupuesto, son quienes la pueden completar; que sea el comité es mi inferencia, no un dato del documento. · **Si no se decide hoy:** el 2026-10-25 (domingo; confirmar la fecha) Óscar hace la revisión con el proveedor sin saber si puede aceptar, rechazar o renegociar nada, y con el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» sin dueño, probabilidad ni impacto. Además, cualquier punto que Óscar suba al comité sin esto se puede devolver con un «eso lo decide usted».

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara por escrito la autoridad de Óscar (umbrales de fecha, monto y proveedor) y la agrega al acta | Sin cambio | Una sesión; el próximo comité es el 10-22 según la configuración, o el 10-29 según las notas de hoy («en dos semanas») | Sin costo directo en dinero; no puedo calcular otro |
| B. Se queda sin declarar y cada caso se resuelve cuando aparece | Sin cambio | Cada caso gasta una sesión en averiguar primero quién decide | No lo sé: depende de qué se escale y cuándo |

**Recomiendo:** A. Es la única opción que deja escrito qué puede decidir Óscar; con B, los dos compromisos de abajo y el proveedor seguirán sin poder clasificarse como «dentro de tu autoridad» o «al comité».

### A quién alcanza
No lo calculé. `portafolio.py impact` necesita un número de días de corrimiento, y este punto no mueve ninguna fecha. En el estado solo hay una ficha (PRY-203), así que tampoco hay otros proyectos contra los cuales cruzar. El acta declara dependencias: «Ninguna declarada», y el proveedor aparece en las notas de hoy como algo que sí condiciona la siguiente fase; esa contradicción la tiene que confirmar Óscar.

### Mis hitos por los que pasa
Ninguno calculado, por la misma razón. No leí el cronograma (`10-plan/2025-10-09-cronograma-v1.xlsx`).

---

### Lo que cumple la regla de escalamiento pero no está listo para subir

**María Restrepo — Enviar el documento 1** (seis reprogramaciones, una por reunión: 09-21 → 10-12 → 10-22 → 11-01 → 11-19 → 11-28 → 12-12; 82 días corridos).
**Paula Céspedes — Cerrar la prueba 2** (cinco: 09-13 → 09-30 → 10-13 → 10-29 → 11-15 → 11-29).

Ambos pasan el umbral de «reprogramado tres veces», pero **ninguna minuta dice qué los bloquea**; las notas de hoy solo dicen que «no alcanzó». Sin la causa no hay pregunta cerrada ni opciones con costo, y armarlas sería inventarlas. El paso previo es una llamada de Óscar a cada una para averiguar la causa: si es algo que Óscar puede resolver, no escala; si excede su autoridad, vuelve aquí con la pregunta formulada. Tampoco sé qué depende del documento 1 ni de la prueba 2.

### Lo que no escala
- El estado «Verde, 60 %» del informe del 10-13 frente a siete compromisos vencidos sin evidencia: es una declaración del gerente y va a `/criterio-project:pm-report`.
- El cierre comprometido en el acta (2026-06-28) ya pasó y el proyecto sigue en ejecución. No encontré en la carpeta un cambio aprobado que mueva la línea base. Eso es control de cambios, no un escalamiento, y la línea base anterior no se toca.

### De dónde sale esto
- Autoridad no declarada, patrocinador, comité, presupuesto, fechas y «Ninguna declarada» en dependencias: `00-gobierno/2025-10-09-acta-constitucion.md`.
- Reprogramaciones de María y Paula: minutas `30-reuniones/2026-09-03` a `2026-10-08-comite-semanal.md` y `2026-10-15-notas-reunion.txt` (ficha `records/PRY-203.json`).
- Proveedor sin equipo completo, revisión del 10-25 y «próxima reunión en dos semanas»: `2026-10-15-notas-reunion.txt`.
- Estado Verde 60 %: `20-seguimiento/2026-10-13-informe-avance.md`.
- Cadencia semanal, próximo comité 2026-10-22: `config.json`.

**Qué dije que no sé:** quién tiene la facultad según el acta, qué bloquea los dos compromisos, qué es «la siguiente fase», y los efectos sobre otros proyectos y sobre mis hitos.
