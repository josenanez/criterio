# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 86 s · 13 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 7 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 2 |

María Restrepo (6 reprogramaciones) y Paula Céspedes (5); 7 vencidos, 3 de ellos con entrega dicha y sin acta; 3 sin fecha; ficha ampliada de 3 a 26 compromisos desde las minutas

Contra la corrida del 2026-10-15: +11 hallazgos.

## Lo que produjo

## Compromisos — Aportes sociales en línea (PRY-203) · al 2026-10-15

26 compromisos registrados: 24 abiertos y 2 cerrados con documento. De los abiertos, 7 están vencidos, 2 se vienen reprogramando 5 veces o más, 3 no tienen fecha y 12 están en plazo.

> La ficha traía solo 3 compromisos (los de las notas de hoy). Extraje los otros 23 de las minutas del 09-03 al 10-08 y los agregué a la ficha. Cada uno lleva su cita.

### Se viene reprogramando

> **María Restrepo** · Enviar el documento 1
> Prometido para el 2026-09-21, y antes del 2026-10-12, 2026-10-22, 2026-11-01, 2026-11-19, 2026-11-28 y ahora el 2026-12-12. **Seis reprogramaciones, una por reunión.** Las notas de hoy dicen que «no alcanzó».
> Fuentes: `30-reuniones/2026-09-03-comite-semanal.md` … `2026-10-15-notas-reunion.txt`.

> **Paula Céspedes** · Cerrar la prueba 2
> Prometido para el 2026-09-13, y antes del 2026-09-30, 2026-10-13, 2026-10-29, 2026-11-15 y ahora el 2026-11-29. **Cinco reprogramaciones.** Hoy no la mencionan las notas; la fecha vigente sale de la minuta del 10-08.
> Fuentes: `30-reuniones/2026-09-03-comite-semanal.md` … `30-reuniones/2026-10-08-comite-semanal.md`.

**Cinco o seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Ninguna minuta dice por qué se mueve.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Beatriz Cuéllar | Actualizar la matriz 6 | 2026-09-15 | 30 días. Dijo el 09-17 que ya la entregó; no se presentó acta |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 | 15 días (ya se había movido del 09-14) |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 | 9 días |
| Sandra Gil | Entregar el punto 8 | 2026-10-06 | 9 días. Dijo el 09-17 que ya lo entregó; no se presentó acta |
| Carlos Peña | Enviar el documento 17 | 2026-10-09 | 6 días. Dijo el 10-08 que ya lo entregó; no se presentó acta |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-13 | 2 días (ya se movió dos veces) |
| Ricardo Salas | Actualizar la matriz 22 | 2026-10-14 | 1 día |

Beatriz, Sandra y Carlos dicen que entregaron; no hay nada en el expediente que lo respalde, así que siguen abiertos.

También dicen que entregaron, sin acta, y siguen abiertos aunque no estén vencidos:
- Diana Molina, «aprobar el diseño 13» (vence el 2026-10-17; lo dijo el 10-01).
- María Restrepo, «confirmar la fecha 15» (sin fecha; lo dijo el 10-08).

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Sandra Gil | Aprobar el diseño 21 | 2026-10-15 (hoy) |
| Diana Molina | Aprobar el diseño 13 | 2026-10-17 (ver arriba: dice que ya lo entregó) |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-15 |
| María Restrepo | Confirmar la fecha 15 | 2026-09-24 (7 semanas sin fecha) |
| Felipe Arango | Entregar el punto 16 | 2026-09-24 (7 semanas sin fecha) |

«La otra semana» no es una fecha; la dejé como `no_declarada` con ese texto.

### Cerrados desde la última revisión
- **Validar el ambiente 4** (Laura Vélez): `20-seguimiento/2026-09-24-acta-recibo-4.md`.
- **Revisar el anexo 11** (Jorge Medina): `20-seguimiento/2026-10-08-acta-recibo-11.md`.

### Aparte
- **Revisar el anexo 3 (Rubén Cárdenas)** figuró con fecha 2026-09-14 en las cuatro minutas del 09-03 al 10-01, sin moverse y sin acta. El 10-08 pasó al 2026-10-27. Es una reprogramación; durante cuatro semanas estuvo vencido sin que nadie lo dijera.
- **Óscar Ramírez** · revisión con el proveedor, para el 2026-10-25. En plazo.
- Las notas de hoy también recogen algo que nadie registró como riesgo: el proveedor podría no llegar con el equipo completo para la siguiente fase. Ya está en el RAID de la ficha, sin dueño.

### Después
- Hay dos compromisos reprogramados cinco o más veces. Puedo formularlos como decisión para el comité del 2026-10-22: qué se pide, qué pasa si no se decide y quién tiene la facultad (`/criterio-project:pm-escalate`). La ficha no registra quién tiene autoridad (`identity.authority` no encontrado).
- La ficha cambió (23 compromisos nuevos). Si quiere que la PMO lo vea, `/criterio-project:pm-publish`.
