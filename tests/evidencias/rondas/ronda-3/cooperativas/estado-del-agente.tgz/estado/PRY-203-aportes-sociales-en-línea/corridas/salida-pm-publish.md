**Antes de publicar (recalculado hoy, 2026-10-15):**
- Campos de identidad con dato: 7 (código, nombre, área, producto, patrocinador, gerente, comité), todos del acta de constitución del 2025-10-09.
- Sin decir en ninguna parte: 2 (`identity.authority`, `declared.status`), y las secciones `plan` y `money` no tienen nada.
- **Estado declarado: ninguno.** `declared.status` no está dicho en ninguna parte, así que la PMO va a ver la ficha sin estado ni fecha de corte declarados.
- Entre los ocho campos que Vera contrasta, 4 llevan dato (patrocinador, gerente, comité, producto) y 4 no: `plan.end_date`, `money.approved`, `declared.status` y `declared.as_of` quedan sin dato.
- Además lleva 26 compromisos y 1 riesgo no registrado.
- Los términos ya estaban vigentes (José Francisco Ñáñez, 2026-10-15, versión 0.3.9), así que no hubo que registrar nada nuevo.
- La carpeta de gobierno ya existía, no hubo que crearla.

Publiqué la ficha en `/home/claude/banco/ronda-3/cooperativas/espacio/documentos/proyectos/PRY-203-aportes-sociales-en-línea/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 7 campos con dato · 2 sin decir en ninguna parte (más `plan` y `money` vacíos) · declara **ningún estado** (no hay declaración tuya todavía)

**Lo más viejo que va ahí:** los 7 campos de identidad, del 2025-10-09 (acta de constitución). Pasa de un año: tienen 12 meses y unos días, y el acta no se ha actualizado desde entonces.
