Soy Samuel. Términos: ya estaban vigentes para esta versión (1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; no los volví a pedir. Sesión sin interfaz: no hice preguntas.

# Acta — Aportes sociales en línea (PRY-203) · 2026-10-15
**Asistieron (13):** Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `documentos/proyectos/PRY-203-aportes-sociales-en-línea/2026-10-15-notas-reunion.txt` (notas de alguien, sin autor ni agenda) · **Ausentes con tema en agenda:** las notas no traen agenda. Faltaron Carlos Peña y Diana Molina, que tenían compromisos en los comités anteriores; Carlos Peña tiene abierto «Enviar el documento 17» (para 2026-10-09, ya vencido) y el 2026-10-08 se dijo que lo había entregado sin acta.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-12-12 | **Reprogramado 6 veces.** Primera promesa: 2026-09-21 (comité del 2026-09-03). Fechas siguientes: 10-12, 10-22, 11-01, 11-19, 11-28 y hoy 12-12. Cita: «María Restrepo dice que lo de "enviar el documento 1" no alcanzó, se compromete para el 12/12/2026». La fecha se movió 82 días en 6 semanas de comité. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Abierto. Cita: «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25». El 2026-10-25 cae domingo; no sé si es la fecha que quisieron decir. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana»; no es una fecha y no la calculé. Cita: «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana». |

## Decisiones
Ninguna. Las notas no registran que nadie haya decidido algo.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué hacer con la posible falta de equipo del proveedor (ver abajo) | Se comentó y no se anotó ni se asignó | No identificado: el acta de constitución no trae la facultad del gerente |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | No dice quién; las notas escriben «se comentó» | Riesgo (con una dependencia del proveedor detrás) | **No.** Los riesgos abiertos del informe del 2026-10-13 son el cambio normativo del supervisor y la concentración del conocimiento en una persona. Quedó en la ficha sin dueño, sin probabilidad y sin impacto, porque la reunión no dijo ninguno. |

## Cerrado en esta reunión
(Se omite: nada se cerró con documento.)

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Dependencias | Hay un proveedor del que depende la siguiente fase (revisión con él el 10-25 y riesgo sobre su equipo) | «Ninguna declarada» | Notas, 2026-10-15 · acta de constitución, 2025-10-09 |
| Cadencia del comité | «Próxima reunión en dos semanas» (sería 2026-10-29) | Comité semanal, próximo 2026-10-22 | Notas, 2026-10-15 · `config.json` y comités semanales desde 2026-09-03 |

Tampoco me consta que haya un contrato con ese proveedor en la carpeta; no leí el cronograma (.xlsx) y no sé qué es «la siguiente fase».

## Sin resolver de la transcripción
- «lo de "enviar el documento 1" no alcanzó»: no dice qué fue lo que no alcanzó (tiempo, insumo, otra cosa).
- «la otra semana»: no queda claro qué semana ni qué día.
- «próxima reunión en dos semanas»: sin fecha, y rompe el ritmo semanal.
- Las notas no dicen quién las tomó ni quién comentó lo del proveedor.

## Lo que recalculé (`compute`)
2 señales: **commitment_rescheduled** (María Restrepo, 6 veces, umbral para marcar: 3) y **commitment_undated** (Laura Vélez). Ningún compromiso vencido.
Corregí la ficha: la corrida de configuración había dejado la promesa original de María en 2026-11-28; la primera es 2026-09-21 y las seis fechas siguientes ya van en `reschedules`.

El acta sale aquí y la guardas tú: no escribí nada en tu carpeta de reuniones. Siguiente paso: `/pm-commitments` para el seguimiento completo (hay 16 compromisos del comité del 2026-10-08 que aún no están en la ficha). `/pm-publish` no hace falta todavía por esta acta; los dos campos contradichos arriba conviene que los confirmes tú antes.
