# Aportes sociales en línea (PRY-203) — semana del 2026-10-08 al 2026-10-15

**Declara el gerente:** — sin declaración (no se declaró estado ni avance en esta corrida)
**Sustento documental:** no evaluable: sin declaración no hay contra qué contrastar
**Lo que el semáforo no explica:** compromisos vencidos sin evidencia y compromisos reprogramados (las dos señales que cualquier semáforo declarado tendría que cubrir)

> Este informe sale con la declaración en blanco, a propósito. El estado lo declara Óscar Ramírez; el sistema no lo propone.

## Qué cambió esta semana
| Qué | Estaba | Está | |
|---|---|---|---|
| Nada comparable | — | — | Esta es la primera foto guardada (2026-10-15); el diff contra la corrida anterior da 0 cambios. No hay «estaba» contra qué comparar. |

## Lo que sigue igual y sigue mal
Sin corrida anterior no se puede decir desde cuándo está así cada cosa. Lo que sí se mide es la antigüedad del vencimiento:

| Qué | Vencía | Días vencido |
|---|---|---|
| Beatriz Cuéllar — Actualizar la matriz 6 | 2026-09-15 | 30 |
| Gustavo Neira — Confirmar la fecha 7 | 2026-09-30 | 15 |
| Sandra Gil — Entregar el punto 8 | 2026-10-06 | 9 |
| Liliana Torres — Cerrar la prueba 10 | 2026-10-06 | 9 |
| Carlos Peña — Enviar el documento 17 | 2026-10-09 | 6 |
| Javier Hoyos — Aprobar el diseño 5 | 2026-10-13 | 2 |
| Ricardo Salas — Actualizar la matriz 22 | 2026-10-14 | 1 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin dato | sin dato | no calculable |
| Presupuesto | sin dato | sin dato | no calculable |

Replanificaciones: 0 registradas. No hay línea base en la ficha, así que la ausencia de replanificaciones no prueba que el plan no se haya movido.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| sin dato | sin dato | sin dato | sin dato | sin dato |

El disponible real (aprobado menos comprometido) no se puede calcular. Hay un compromiso sin fecha de Laura Vélez, «Mandar el ajuste del presupuesto», que apunta a que el presupuesto está en movimiento.

## Abierto
**Reprogramados:**
- María Restrepo — Enviar el documento 1: **6 veces**. Original 2026-09-21; ahora 2026-12-12 (pasó por 10-12, 10-22, 11-01, 11-19, 11-28). Pasa el umbral de 3 reprogramaciones.
- Paula Céspedes — Cerrar la prueba 2: **5 veces**. Original 2026-09-13; ahora 2026-11-29 (pasó por 09-30, 10-13, 10-29, 11-15). Pasa el umbral de 3.

**Vencidos sin evidencia:** los siete de la tabla anterior. Fuentes: actas de comité del 09-10, 09-17, 10-01 y 10-08.

**Sin fecha:** Laura Vélez («Mandar el ajuste del presupuesto», notas del 10-15; «Validar el ambiente 4», comité del 09-03), María Restrepo («Confirmar la fecha 15», 09-24), Felipe Arango («Entregar el punto 16», 09-24).

**RAID sin movimiento:** sin registro RAID en la ficha.
**Proveedor:** sin proveedores en la ficha.

## Lo que necesito de alguien
- **Óscar Ramírez:** declarar estado y avance. Sin eso este informe no se puede contrastar.
- **María Restrepo:** fecha firme para el documento 1, o decir que no se va a entregar. Seis reprogramaciones.
- **Paula Céspedes:** lo mismo para la prueba 2. Cinco reprogramaciones.
- **Beatriz Cuéllar:** estado de la matriz 6, vencida hace 30 días.
- **Laura Vélez, María Restrepo y Felipe Arango:** fecha para los compromisos sin fecha.
- Las dos reprogramaciones por encima del umbral pueden ser material de comité (próximo: 2026-10-22). Eso queda a juicio del gerente.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto, estado declarado, línea base (fechas y presupuesto), hitos, cifras de presupuesto. Los campos de identidad se leen de un documento del 2025-10-09, con 12 meses de antigüedad, y ninguno está marcado como evidencia (7 sin marcar).
**Silencio:** último documento hace 0 días (notas del 2026-10-15) · última reunión hace 0 días (2026-10-15).

---
*Origen: ficha de PRY-203, corte 2026-10-15. 2 campos sin dato (identity.authority, declared.status). Términos vigentes: https://www.josenanez.com/es/agents/criterio-pmo/legal*
