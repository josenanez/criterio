## Reunión de seguimiento — Aportes sociales en línea (PRY-203) · 2026-10-22
12 puntos · 45 minutos · 11 personas requeridas

Fecha tomada de la cadencia configurada (comité semanal, próximo 2026-10-22). Las notas de hoy dicen «próxima reunión en dos semanas» (sería 2026-10-29): si la fecha cambia, esta agenda se rehace, porque lo que vence entre el 10-22 y el 10-29 pasaría a vencido. No pediste tope de tiempo; la suma es mía.

No hay corrida anterior de esta ficha, así que no puedo decir «qué cambió»: tomé como punto de partida la minuta del 2026-10-08 y las notas de hoy.

### Lo que no se destraba solo

> **[1] Que se diga qué le impide a María enviar el documento 1, y una fecha que dependa de eso** · 8 min · **María Restrepo** (con Óscar Ramírez)
> Prometido para el 2026-12-12, y antes para el 2026-11-28, el 2026-11-19, el 2026-11-01, el 2026-10-22, el 2026-10-12, y la primera vez para el 2026-09-21. **Seis reprogramaciones, una por reunión; 82 días corridos.** Las notas de hoy solo dicen que «no alcanzó»; ninguna minuta dice por qué.
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md` … `2026-10-15-notas-reunion.txt`
> **Si no se resuelve hoy:** la fecha vuelve a moverse sin que se sepa por qué, como en las seis reuniones anteriores. No sé qué depende del documento 1: el cronograma (.xlsx) no lo he leído.
> Si lo que la bloquea excede la autoridad de Óscar, no se resuelve aquí: va al comité (`/criterio-project:pm-escalate`). La ficha no trae esa autoridad (`identity.authority` no encontrado).

> **[2] Lo mismo para Cerrar la prueba 2** · 6 min · **Paula Céspedes**
> Prometido para el 2026-11-29, y antes para el 2026-11-15, el 2026-10-29, el 2026-10-13, el 2026-09-30, y la primera vez para el 2026-09-13. **Cinco reprogramaciones.** Hoy las notas no la mencionan; la fecha vigente sale de la minuta del 10-08.
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md` … `30-reuniones/2026-10-08-comite-semanal.md`
> **Si no se resuelve hoy:** igual que el punto 1; ninguna minuta explica los movimientos.

### Vencido sin evidencia
Más viejo primero. «Qué se necesita hoy» es una de dos cosas: el acta de recibo, o una fecha nueva con su motivo.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Beatriz Cuéllar (no suele asistir: solo estuvo el 09-10) | Actualizar la matriz 6 | 2026-09-15 (30 días) | Dijo el 09-17 que ya la entregó; no hay acta. Óscar trae el acta o confirma que no existe, y alguien de la sala consigue a Beatriz. Fuente: comités 09-10 y 09-17 | 2 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-30 (15 días) | Ya se movió una vez (del 09-14). Entrega hoy o fecha nueva con su motivo. Fuente: comités 09-10 y 09-17 | 3 |
| Sandra Gil | Entregar el punto 8 | 2026-10-06 (9 días) | Dijo el 09-17 que ya lo entregó; no hay acta. Acta de recibo o se reabre. Fuente: comités 09-10 y 09-17 | 3 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-06 (9 días) | Entrega o fecha nueva con motivo. Fuente: comité 09-17 | 2 |
| Carlos Peña (no asistió hoy; estuvo el 10-01) | Enviar el documento 17 | 2026-10-09 (6 días) | Se dijo el 10-08 que ya lo entregó; no hay acta. Óscar trae el acta o confirma que no existe. Fuente: comités 10-01 y 10-08 | 2 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-13 (2 días) | Ya se movió dos veces (09-22 → 10-06 → 10-13). Aprobación hoy o motivo. Fuente: comités 09-10, 09-24 y 10-01 | 2 |
| Ricardo Salas | Actualizar la matriz 22 | 2026-10-14 (1 día) | Entrega o fecha. Fuente: comité 10-08 | 1 |

Estos siete corresponden al corte de hoy (2026-10-15). Para el 10-22 se suman los que vencen entre ahora y entonces (ver más abajo), y el recálculo del 2026-10-21 los pone al día.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **El proveedor podría no llegar con el equipo completo para la siguiente fase**: ponerle dueño, probabilidad e impacto, y registrarlo como riesgo. Nadie lo anotó; está en la ficha sin dueño. Fuente: notas 2026-10-15 | Óscar Ramírez como gerente. Quién tiene la facultad si hay que hacer algo con el proveedor: no está en la ficha | La revisión con el proveedor del 2026-10-25 (Óscar) se hace sin el riesgo valorado ni dueño. No sé qué es «la siguiente fase» ni si hay contrato en la carpeta | 7 |
| **Cadencia del comité**: confirmar si la próxima reunión es el 10-22 (semanal) o el 10-29 («dos semanas»). Fuente: notas 2026-10-15 vs. `config.json` | Óscar Ramírez | La fecha de esta agenda y de todo lo que «vence antes de la próxima» queda en el aire | 2 |
| **Tres compromisos sin fecha**: Laura Vélez, mandar el ajuste del presupuesto («la otra semana», dicho el 10-15); María Restrepo, confirmar la fecha 15 (sin fecha desde el 09-24, y dijo el 10-08 que ya lo entregó, sin acta); Felipe Arango, entregar el punto 16 (sin fecha desde el 09-24, siete semanas) | Cada uno de los tres pone fecha; Óscar la confirma | Siguen sin poder vencer, así que nadie puede decir que están atrasados | 3 |

### Vence antes de la próxima
Entre hoy y el 2026-10-29. Se lee en un minuto; no se discute salvo que su doliente diga que no llega.

| Quién | Qué | Para cuándo |
|---|---|---|
| Sandra Gil | Aprobar el diseño 21 | 2026-10-15 (hoy) |
| Diana Molina (no asistió hoy) | Aprobar el diseño 13 | 2026-10-17. Se dijo el 10-01 que ya lo entregó; no hay acta |
| Jorge Medina | Cerrar la prueba 18 | 2026-10-24 (ya se movió del 10-17) |
| Jorge Medina | Validar el ambiente 20 | 2026-10-25 (ya se movió del 10-11) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (cae domingo; confirmar la fecha) |
| Sandra Gil | Enviar el documento 9 | 2026-10-26 (ya se movió del 10-06) |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-26 (ya se movió del 10-19) |
| Natalia Ospina | Revisar el anexo 19 | 2026-10-26 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-10-27. Figuró con fecha 09-14 en las minutas del 09-03 al 10-01 sin moverse y sin acta; el 10-08 pasó al 10-27 |
| Paula Céspedes | Entregar el punto 24 | 2026-10-29 |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| El estado «Verde, 60 %» del informe del 2026-10-13 frente a 7 compromisos vencidos y 2 reprogramados cinco o más veces | Es una declaración del gerente, no un tema que la sala pueda mover | `/criterio-project:pm-report` |
| Qué hacer con los compromisos reprogramados 5 y 6 veces si el bloqueo excede a Óscar | La ficha no trae su autoridad; no puedo decir si le toca | `/criterio-project:pm-escalate`, para el comité |
| La dependencia del proveedor frente al acta de constitución («ninguna declarada») | Es un dato de la ficha que Óscar debe confirmar antes | `/criterio-project:pm-publish`, después de confirmarlo |

### Anexo — sin cambios desde el 2026-10-08 (no se repasa)
- Laura Vélez · Actualizar la matriz 14 · 2026-11-07 (ya se movió del 10-18)
- Felipe Arango · Confirmar la fecha 23 · 2026-11-05
- Cerrados con acta de recibo: Validar el ambiente 4 (Laura Vélez, 2026-09-24) y Revisar el anexo 11 (Jorge Medina, 2026-10-08). El cálculo aún lista «Validar el ambiente 4» como sin fecha aunque está cerrado; lo dejé fuera de la agenda.

Siguiente paso: la agenda no convoca a nadie; citar a la reunión es de Óscar. Terminada la reunión, `/criterio-project:pm-minutes` sobre las notas, y los compromisos que salgan entran a `/criterio-project:pm-commitments`.
