# Plan — Aportes sociales en línea (PRY-203) · borrador del 2026-10-15
**Desde:** el acta de constitución del 2025-10-09 (`00-gobierno/2025-10-09-acta-constitucion.md`) · **Criterio de éxito:** «Aportes sociales en línea en producción y medido» (acta, sección *Criterio de éxito*) — sin indicador ni umbral de «medido».

> Nota de situación: este proyecto no está en el arranque. El acta tiene un año, la fecha de cierre comprometida (2026-06-28) ya pasó, y existe un `10-plan/2025-10-09-cronograma-v1.xlsx` con cinco hitos. Este borrador parte del acta; el cronograma v1 se usa solo como referencia y se marca como tal. Si lo que se busca es revisar el plan vigente, el comando adecuado es `/pm-plan revisar`.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío:** «Componente 1 / 2 / 3» son marcadores, no entregables | No hay de dónde descomponer. Los nodos de la WBS por componente quedan «sin definir»; cualquier nombre que se les ponga lo inventa el plan, no el acta |
| **Fuera de alcance:** «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué | No se puede trazar la frontera; un entregable puede estar duplicado o huérfano |
| **Criterio de éxito sin medida:** «y medido» no dice qué se mide, con qué meta ni quién lo verifica | No se puede saber cuándo el último entregable está aceptado ni cuándo el proyecto cierra |
| **Autoridad del gerente no declarada** (la ficha lo marca como no encontrado) | No se sabe qué puede decidir quien planifica y qué debe subir al patrocinador o al comité |
| **Dependencias: «Ninguna declarada»**, mientras el informe del 2026-10-13 menciona el concepto del ente supervisor y un cambio normativo, y las notas del 2026-10-15 mencionan al proveedor | El plan nace con dependencias externas que el acta no reconoce; hay que decidir si el acta se corrige o si van como supuestos |
| **Fecha de cierre (2026-06-28) vencida** frente a hoy, 2026-10-15 | Ninguna fecha del acta sirve como ancla; la fecha vigente la tiene que declarar quien tiene autoridad |

Sí está declarado: patrocinador (Rubén Cárdenas), gerente (Óscar Ramírez), comité (Comité de Educación) y presupuesto aprobado (3.300.000.000 COP). Nada de lo anterior se rellenó.

## WBS
Por entregable. «De dónde sale» usa solo los tres estados. El cronograma v1 no es el acta, así que lo que viene de ahí va como **supuesto**, con su fuente.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | **sin definir** (el acta solo dice «Componente 1») | vacía |
| 2 | Componente 2 | sin definir | **sin definir** | vacía |
| 3 | Componente 3 | sin definir | **sin definir** | vacía |
| 4 | Diseño funcional aprobado | sin definir | **supuesto** (hito en cronograma v1; no está en el acta) | vacía |
| 5 | Ambiente de pruebas certificado | sin definir | **supuesto** (cronograma v1) | vacía |
| 6 | Integración con el core cooperativo | sin definir | **supuesto** (cronograma v1) | vacía |
| 7 | Piloto con asociados | sin definir | **supuesto** (cronograma v1) | vacía |
| 8 | Salida a producción | Óscar Ramírez recibió el 2026-10-04 (`20-seguimiento/2026-10-04-acta-recibo-salida-a-producción.md`); quién debía aceptarlo según el acta: sin definir | **supuesto** (cronograma v1) | vacía |
| 9 | Aportes sociales en producción, **medido** | sin definir (¿el patrocinador?) | **del acta** (criterio de éxito), pero sin indicador | vacía |

Observación de coherencia, sin resolverla: los nodos 4–8 no suman «Componente 1–3»; no sé si son los mismos entregables con otro nombre o dos descomposiciones distintas. Eso lo define quien escribió el acta.

## Orden
Sin fechas. Qué necesita qué (el orden de los nodos 4–9 es el del cronograma v1, tomado como supuesto):

- Diseño funcional aprobado (4) → Ambiente de pruebas certificado (5) → Integración con el core (6) → Piloto con asociados (7) → Salida a producción (8) → Medición en producción (9).
- 9 depende de que exista algo medible en producción; sin indicador definido, no se puede decir cuándo se cumple.
- Los Componentes 1–3 no se pueden ordenar: no se sabe qué son.
- Dependencias externas que no estaban en el acta y afectan el orden (**sin definir** cuál nodo bloquean): el concepto del ente supervisor, el posible cambio normativo, y la disponibilidad del proveedor «para la siguiente fase».

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v1 son los entregables reales del proyecto | La WBS de los nodos 4–8 está mal; faltan o sobran entregables |
| El orden 4→9 del cronograma v1 sigue vigente | El orden por dependencia cambia y el camino crítico es otro |
| «Componente 1–3» corresponden en algún sentido a esos hitos | Hay entregables en el alcance que ningún nodo cubre |
| «Medido» significa medición posterior a la salida a producción, por el área dueña (Tesorería) | El nodo 9 no tiene dueño ni criterio de aceptación |
| El presupuesto aprobado de 3.300.000.000 COP sigue siendo la referencia | Hay un ajuste de presupuesto pendiente (Laura Vélez, «la otra semana», sin fecha; notas del 2026-10-15) que puede cambiar el plan |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Rubén Cárdenas), vía corrección del acta |
| Qué proyecto cubre lo «fuera de alcance» y qué cubre | Patrocinador / Comité de Educación |
| Indicador, meta y responsable de «medido» | Patrocinador |
| Quién acepta cada entregable | Patrocinador; no el agente |
| Autoridad del gerente al planificar | Patrocinador |
| Qué nodo bloquea cada dependencia externa (supervisor, normativa, proveedor) | Gerente, con el patrocinador |
| Fecha de cierre vigente | Quien tenga autoridad para comprometerla (no este borrador) |

## Proyectos análogos
Ninguno a la vista: la configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no se buscó. No hay referencia de cuánto les pasó a proyectos parecidos, y no se sustituye con una estimación.

## Preguntas para el equipo
Una por cada duración vacía:

1. Componente 1: ¿qué es y cuánto toma?
2. Componente 2: ¿qué es y cuánto toma?
3. Componente 3: ¿qué es y cuánto toma?
4. Diseño funcional aprobado: ¿cuánto toma y quién lo aprueba?
5. Ambiente de pruebas certificado: ¿cuánto toma y quién lo certifica?
6. Integración con el core cooperativo: ¿cuánto toma y qué necesita del proveedor?
7. Piloto con asociados: ¿cuánto toma, con cuántos asociados y quién lo acepta?
8. Salida a producción: ¿qué falta tras el recibo del 2026-10-04 y qué significa «reprogramar la salida por el cierre contable» (informe del 2026-10-13)?
9. Medición: ¿qué se mide, con qué meta, desde cuándo y quién lo verifica?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (13 personas asistieron a la reunión del 2026-10-15; la dedicación de cada una no está en ningún documento).
- La fecha del proveedor: la revisión con el proveedor quedó para el 2026-10-25 y se comentó que podría no llegar con el equipo completo (notas del 2026-10-15; nadie lo registró como riesgo).
- La ventana de producción y el cierre contable de fin de mes (informe del 2026-10-13).
- El concepto/cambio normativo del ente supervisor.
- El ajuste de presupuesto pendiente de Laura Vélez.
- Un acta corregida con alcance, criterio de éxito medible y autoridad.

**Este borrador no compromete ninguna fecha.** Cuando el plan se apruebe, puede registrarse como línea base original y pasar los supuestos al RAID con doliente.
