# Corrida · 2026-10-15-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T16:27:42 · **Fin:** 2026-10-15T16:28:25 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 28 | 64 | Informe de PRY-205: verde declarado contradicho por 5 señales (11.7% de atraso contra la original, 5 hitos sin evidencia, facturado 241.126.726 COP sobre lo aceptado, compromiso vencido). Dijo que no sabe producto, autoridad, fase ni quién aprobó CC-01. |

Por señal (`status-report`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé el informe de estado de PRY-205 y dejé la corrida registrada. El proyecto declara verde, pero los documentos lo contradicen.

**PRY-205 · Prevención de lavado de activos, al 2026-10-15** (ficha actualizada el 2026-10-15, cifras recalculadas hoy)

- **Declara el gerente (Rubén Cárdenas):** verde y 75% de avance, al 2026-10-14.
- **Sustento documental:** contradicho. El semáforo no explica cinco señales abiertas:
  - un compromiso vencido;
  - hitos cumplidos sin evidencia;
  - el avance contra el plan;
  - la desviación de tiempo;
  - lo facturado por encima de lo aceptado.
- **Contra el plan:** la fecha de cierre pasó de 2026-05-27 a 2026-06-23. Eso es +27 días contra la original (11.7%, sobre el umbral de 10%), por una replanificación (CC-01, ampliación de alcance).
- **Presupuesto:** la proyección es de 7.077.935.008 COP contra 6.800.000.000 aprobados, un 4.1% por encima. CC-01 declara 54.000.000 COP adicionales que la ficha no refleja en el aprobado.
- **Hitos:** los 5 están declarados cumplidos y ninguno tiene evidencia. El plan respalda 100% y el gerente declara 75%.
- **Proveedor Red Rural de Pagos (CT-869):** facturó 241.126.726 COP más de lo aceptado. Un entregable figura aceptado sin acta de recibo.
- **Abierto:** Paula Céspedes tiene vencido desde el 2026-09-30 «Entregar el punto 24», sin entrega visible. Un riesgo y una incidencia (la prueba de carga que se repite) no tienen responsable.
- **Sin dato:** producto, autoridad, fase y quién aprobó CC-01 («el comité»).

Los términos ya estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo. El informe completo, con el pie y el enlace a los términos, está en `estado/corridas/salida-status-report.md`.

La corrida quedó registrada con id `2026-10-15-status-report-1`. Tardó 28 segundos medidos, pero el script no midió la cantidad de documentos leídos. El script la contó sobre los 13 proyectos, no solo sobre PRY-205, por lo que sus 64 hallazgos son del portafolio completo. Los de PRY-205 son 11.

Puedo preparar el punto de comité del 2026-10-22 o la solicitud de cambio de CC-01 con su línea base de costo.
