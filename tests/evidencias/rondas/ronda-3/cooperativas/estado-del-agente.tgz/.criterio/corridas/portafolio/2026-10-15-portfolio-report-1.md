# Corrida · 2026-10-15-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:41:22 · **Fin:** 2026-10-15T16:42:43 · **Duración:** 81 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 79 | 59 | 64 | 5 proyectos en verde contradichos por la evidencia; PRY-203 concentra 18 de 64 señales; sin delta (misma fecha que el barrido) |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

# Portafolio — 2026-10-15

Generé el informe HTML y registré la corrida (`2026-10-15-portfolio-report-1`). Cargué 13 fichas, todas con fecha 2026-10-15. Hay 13 proyectos, 10 con hallazgos y 64 señales en total.

**Términos:** ya estaban vigentes, versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15. No los registré de nuevo. Texto completo: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Dónde quedó el informe**, en `/home/claude/banco/ronda-3/cooperativas/espacio/reportes/` (25 páginas):
- **`index.html`:** vista por campo, con la cadena de evidencia completa. Es para quien va a actuar.
- **`decisiones.html`:** vista por decisión, para el patrocinador y el comité del 2026-10-22.
- **Una página por proyecto.** El PDF sale de imprimir el HTML.

**Qué cambió:** nada. La instantánea anterior tiene la misma fecha que el barrido, así que el diff dio 0 cambios. Esto es el punto de partida.

**Lo principal:**
- **Verdes contradichos:** 5 proyectos declaran verde y la evidencia no lo sostiene (PRY-202, 203, 204, 205 y 208).
- **Hitos sin evidencia:** hay 22 hitos declarados cumplidos sin evidencia. PRY-205 tiene 5, PRY-203 tiene 4, y el más viejo lleva 363 días en PRY-202.
- **Corrimientos sin autorización:** PRY-204 se corrió 112 días y PRY-208 se corrió 33, sin cambio aprobado.
- **PRY-203:** concentra 18 de las 64 señales. Tiene 7 compromisos vencidos, y dos de ellos se reprogramaron 5 y 6 veces.
- **PRY-206:** la proyección de costo está 26,4 % sobre lo aprobado, y el cambio CC-01 no tiene línea base.
- **PRY-209:** el proveedor Soluciones Solidarias tiene 3 entregables atrasados y $1.882.339.743 facturados sin entrega.
- **Silencio:** ningún proyecto pasa de 15 días sin movimiento.

**Notas y límites:**
- Las fichas están en `estado/records/`, no en `estado/fichas/` como dice el comando.
- No desglosé las contradicciones campo por campo, ni las dependencias; el informe remite al detalle en `index.html`.
- La confirmación del mes (5 campos) quedó pendiente, porque la sesión era sin interfaz. Las 5 preguntas están en el informe.
- Los 13 proyectos no tienen patrocinador identificado en la ficha.

Lo que te mostré aquí está guardado entero en `estado/corridas/salida-portfolio-report.md`.

Si quieres, el siguiente paso es preparar el material del comité del 2026-10-22 (`/criterio-portfolio:steering-pack`). También puedo entrar al detalle de PRY-203 o PRY-209.
