# Corrida · 2026-10-15-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:44:42 · **Fin:** 2026-10-15T16:45:31 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 16 | — | 33 | 39 | 11 requerimientos decididos y ninguno tiene proyecto; solo hay una ficha (PRY-203), que no ejecuta este producto |

Por señal (`product-trace`): `evidence_stale` 12, `requirement_untraced` 11, `requirement_undecided` 5, `requirement_accepted_without_evidence` 4, `requirement_without_owner` 4, `requirement_without_acceptance` 2, `assumption_unverified` 1

## Lo que el agente mostró

## Trazabilidad — Tarjeta débito (PRD-303) · al 2026-10-15

Ninguno de los 11 requerimientos decididos tiene proyecto asignado, y no hay ninguno confirmado contra una ficha ni entregado.

Los términos ya estaban vigentes para la versión 0.3.9, aceptados a nombre de José Francisco Ñáñez el 2026-10-15, así que no volví a registrarlos.

**Decidido y nadie lo está construyendo.** Los 16 requerimientos tienen el campo de proyecto en «—» en el acta del comité del 2026-10-05. Los 11 aceptados quedan sin proyecto: REQ-4300, 4301, 4303, 4304, 4305, 4307, 4309, 4311, 4313, 4314 y 4315. Los más viejos son REQ-4307 (170 días desde que se decidió), REQ-4301 (138) y REQ-4305 (137). Los 5 propuestos no cuentan porque aún no están decididos.

**La traza no se confirma.** No hay ninguna, porque ningún requerimiento declara qué proyecto lo ejecuta.

**Lo que un proyecto construye y el registro no tiene.** Ninguna ficha a la vista dice que ejecuta PRD-303. La única ficha publicada es la de PRY-203 y declara el producto «aportes sociales». Hay una pista sin confirmar: el proyecto PRY-204 «Tarjeta débito para asociados» tiene una solicitud de cambio (CC-01, 2026-10-09, de Ricardo Salas). Por el nombre parece ser el de este producto, pero no tiene ficha y ningún requerimiento lo nombra.

**Sin fichas a la vista.** Solo existe la de PRY-203. Faltan las de los otros 12 proyectos, PRY-204 entre ellas. Por eso ninguna traza se da por confirmada.

El 0 % de cobertura puede ser un hueco del registro y no prueba que nadie construya. No escribí nada en ninguna ficha de proyecto y no conté avance.

Como hay decididos sin proyecto, `/product-charter` sirve para el que ya esté listo. Si PRY-204 resulta ser el proyecto de este producto, hay que hablar con su gerente para que publique la ficha.

**Corrida registrada.** `2026-10-15-product-trace-1`: 16 requerimientos, 39 hallazgos y 33 segundos. El detalle completo, con la cadena y la lista de fichas faltantes, está en `estado-producto/PRD-303/corridas/salida-product-trace.md`.
