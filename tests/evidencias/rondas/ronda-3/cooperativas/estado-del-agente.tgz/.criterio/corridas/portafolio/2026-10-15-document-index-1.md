# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:27:11 · **Fin:** 2026-10-15T16:27:36 · **Duración:** 25 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 10 | 64 | 79 documentos sin cambio, 0 por releer. 7 citas de identidad de PRY-203 apuntan a un acta de constitución que no resuelve; no se sabe por qué (no figura como borrada ni renombrada). |

Por señal (`document-index`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

**Documentos:** 79 · **Sin cambio:** 79 · **Hay que releer:** 0

No hay documentos nuevos, con contenido cambiado, reguardados, renombrados ni borrados. Tampoco hay formatos que no se pudieran leer. No hay barrido que ofrecer, porque `projects_to_recompute` está vacío.

**Citas que dejaron de resolver:** hay siete, todas de PRY-203. Apuntan a `00-gobierno/2025-10-09-acta-constitucion.md`, que no resuelve.

| Campo de PRY-203 |
|---|
| `pm_record.identity.code` |
| `pm_record.identity.name` |
| `pm_record.identity.business_area` |
| `pm_record.identity.product` |
| `pm_record.identity.sponsor` |
| `pm_record.identity.manager` |
| `pm_record.identity.committee` |

El índice no la registra como borrada ni renombrada. No sé por qué la ruta no resuelve. La ficha sigue mostrando esos siete datos como sustentados y ya no lo están. Hay que ubicar el acta o corregir la ruta citada.

- **Términos:** ya estaban vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los volví a registrar.
- **Corrida registrada:** `2026-10-15-document-index-1`, con la salida guardada en `estado/corridas/salida-document-index.md`. Tardó 10 segundos.
- **Hallazgos acumulados:** la corrida también registra 64 hallazgos en los 13 proyectos. Vienen de las fichas ya existentes, no de este índice.
