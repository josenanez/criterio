# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-207 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-15T16:36:52 · **Fin:** 2026-10-15T16:37:37 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 30 | 64 | Revisión del acta PRY-207 (2025-12-22): falta autoridad del gerente, hitos, supuestos/restricciones, cadencia; objetivo, alcance, exclusiones y criterio de éxito son marcadores sin medida; acta dice sin dependencias y el informe declara la del core. No sabe si hay autoridad delegada fuera de los dos documentos ni por qué reporta al Comité de Educación. |

Por señal (`project-charter`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Acta previa:** sí existe, aprobada el 2025-12-22. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

## Acta PRY-207 Microcrédito rural: qué falta

| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | No está. | El informe del 2026-10-05 dice que la salida se reprogramó y no da fecha nueva. Sin autoridad escrita no se sabe si Felipe Arango podía hacerlo solo o debía subir al comité. |
| Objetivo de negocio | Dice "Entregar microcrédito rural…", sin cifra. | No hay con qué juzgar si el proyecto valió lo gastado. |
| Alcance | "Componente 1, 2, 3", sin nombrarlos. | No se puede definir qué es un cambio de alcance. El 81% de avance reportado tampoco se puede verificar. |
| Exclusiones | "Lo que otro proyecto cubre", sin decir cuál. | No hay lista contra la cual discutir el cierre. |
| Comité y cadencia | Comité de Educación, sin cadencia. | El área dueña es Riesgo y Cumplimiento y el acta no explica por qué lo gobierna ese comité. |
| Supuestos y restricciones | No hay sección. | Lo que el informe llama riesgos (concepto del supervisor, aprobación del reglamento por el Consejo) nunca se declaró como supuesto del plan. |
| Dependencias | El acta dice "Ninguna declarada". El informe declara la dependencia del proveedor del core. | Los dos documentos se contradicen. |
| Criterio de éxito | "En producción y medido", sin métrica, umbral ni quién mide. | Un solo desembolso bastaría para declararlo cumplido. |
| Hitos | No hay, solo inicio y cierre (2026-10-15, hoy). | No hay con qué medir el atraso. |

El patrocinador (Gustavo Neira) sí está con nombre de persona.

**Lo que no sé:**
- Si hay autoridad delegada fuera de estos dos documentos. Solo revisé el acta y el informe de avance.
- Por qué el proyecto reporta al Comité de Educación.
- Qué son los componentes 1, 2 y 3.

**Siguiente paso:** el acta quedó sin autoridad declarada. Puedo llevar esa definición al comité del 2026-10-22, y pasar al registro RAID los supuestos y la dependencia del core. No ejecuté ninguna de las dos cosas.

La corrida quedó registrada como `2026-10-15-project-charter-1`. Lo que te mostré está en `estado/corridas/salida-project-charter.md`.
