# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view crédito de libranza

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:40:26 · **Fin:** 2026-10-15T16:41:16 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 27 | 64 | Producto con un solo proyecto (PRY-200): 2 señales (avance declarado 74% vs 25-50% sustentado; hito sin evidencia). 5 proyectos sin producto declarado; no sé si PRY-208/PRY-209 sirven a libranza. Área dueña no consta en las fichas. |
| `product-view` | 13 | — | — | 64 | Producto con un solo proyecto (PRY-200): 2 señales (avance declarado 74% vs 25-50% sustentado; hito sin evidencia). 5 proyectos sin producto declarado; no sé si PRY-208/PRY-209 sirven a libranza. Área dueña no consta en las fichas. |

Por señal (`product-view`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

Por señal (`product-view`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Crédito de libranza al 2026-10-15

Este producto tiene un solo proyecto declarado, PRY-200 Crédito de libranza digital. Por eso no armé una sección de producto. Las cifras salen de `portafolio.py compute`. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| crédito de libranza | 1 (PRY-200) | 2 señales | 2027-06-10 | COP 800.000.000 | COP 479.424.471 |

- **Avance declarado sin sustento:** el informe del 2026-10-10 declara 74 %. El plan sustenta entre 25 % y 50 %, con 1 de 4 hitos cumplidos.
- **Hito sin evidencia:** «Diseño funcional aprobado», vencido el 2026-07-04, figura como cumplido y no hay documento que lo sustente.
- **Estado declarado:** amarillo. El informe no da cuenta de ninguna de las dos señales.
- **Dinero:** el proyecto trae las cuatro cifras (1 de 1).
  - Ejecutado: COP 151.498.076 (18,9 %).
  - Comprometido: 59,9 %.
  - Proyección: COP 823.042.967, un 2,9 % sobre lo aprobado, por debajo del umbral de 10 %.
- **Sin señal:** no tiene compromisos vencidos, cambios ni proveedores registrados. Dependencias internas: ninguna, porque con un solo proyecto no hay cruce posible.
- **Campos que faltan en la ficha:** `identity.authority` y `identity.phase`.

**Proyectos sin producto declarado:** son 5 de 13 (PRY-202, 205, 208, 209 y 210). En ninguna ficha consta el área dueña. Nadie puede responder por el conjunto al que sirven.

**Lo que no sé:** si PRY-208 Motor de crédito y PRY-209 Convenios de libranza con empresas pertenecen a este producto. Sus nombres lo sugieren, pero las fichas no lo dicen y no lo asumí. Si pertenecen, el producto tendría tres proyectos y no uno. La fecha, la suma de dinero y las dependencias cambiarían, y PRY-209 sumaría 43 días de desvío sin autorizar y COP 1.882.339.743 facturados sin entregables recibidos.

**Para el comité del 22 de octubre:** una sola decisión, asignar producto a esos 5 proyectos.

La corrida quedó registrada como `product-view`, con la salida en `estado/corridas/salida-product-view.md`. Al registrarla vi que había puesto 4 alertas para PRY-210 cuando son 5. Corregí el archivo y volví a registrar la corrida, así que ese registro queda duplicado.
