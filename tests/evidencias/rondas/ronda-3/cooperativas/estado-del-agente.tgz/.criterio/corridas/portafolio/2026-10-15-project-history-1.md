# Corrida · 2026-10-15-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T16:33:12 · **Fin:** 2026-10-15T16:34:35 · **Duración:** 82 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 64 | 64 | Historia de PRY-205 sobre 10 documentos (2025-09-24 a 2026-10-14). No se pudo calcular meses declarando sin sustento: hay una sola declaración de estado. No hay minuta que apruebe CC-01 ni acta del tercer entregable CT-869; 2026-T2 sin documentos. |

Por señal (`project-history`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

La historia de PRY-205 está hecha y la corrida quedó registrada. El texto completo está en `estado/corridas/salida-project-history.md`. La cifra de meses declarando sin sustento no se pudo calcular.

Leí 10 documentos entre 2025-09-24 y 2026-10-14. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15, y no volví a registrarlos.

- **Replanificaciones:** hay una, la solicitud de cambio CC-01 del 2026-10-07 (+27 días, +54.000.000 COP). Mueve la salida a producción de 2026-05-27 a 2026-06-23, una fecha que ya había pasado. Dice "autorizada por el comité", pero ninguna minuta la aprueba; la del 2026-10-12 no la menciona.
- **Atraso contra la línea base original:** 27 días, 11.7 %.
- **Meses declarando sin sustento:** no se puede calcular, porque hay una sola declaración de estado (el informe del 2026-10-14) y no una serie. Lo que sí hay: el primer hito dado por cumplido sin evidencia vencía el 2025-11-24, hace 325 días. Los 5 hitos están sin evidencia.
- **Cambios de gobierno:** ninguno detectado, pero hay una sola minuta.
- **Factura:** FV-1869 es por 1.396.951.861 COP, 241.126.726 COP por encima de lo aceptado. El tercer entregable del contrato no tiene acta de recibo, y el contrato la exige para facturar.
- **Informe del 2026-10-14:** declara Verde y 75 %. Ese mismo informe dice que la prueba de carga no alcanzó el umbral y se repite.
- **Compromisos:** ninguno se repite. Paula Céspedes tiene vencido "Entregar el punto 24" (2026-09-30, 15 días).
- **Vacío de documentos:** abril–junio de 2026 no tiene ningún documento, y en ese trimestre vencieron la fecha original y la vigente.

No atribuyo intención. Puede haber evidencia fuera de la carpeta.

Dejo ofrecido llevar esta historia al cierre del proyecto o al comité del 2026-10-22, pero no lo ejecuté.

Cosas que debes saber:
- El acta de constitución da cierre 2026-06-20 y el cronograma v1 da salida a producción 2026-05-27. Ningún documento aclara si son la misma fecha, así que no las concilié.
- La corrida registró 13 proyectos, no uno, porque el cálculo recorre todo el portafolio. Los hallazgos de PRY-205 son 11.
- El número de documentos leídos no quedó medido en el registro.
- No usé Glob (no estaba disponible) y extraje el texto de los .docx y .xlsx directamente.
