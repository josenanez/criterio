# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-205 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-15T16:32:13 · **Fin:** 2026-10-15T16:33:06 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 39 | 64 | Solicitud de mover 30 días la salida a producción de PRY-205. Hallazgo: la fecha vigente (2026-06-23) y la nueva (2026-07-23) ya pasaron, y el hito figura cumplido sin evidencia. Sin solicitante, motivo, impacto en costo ni alcance, autoridad declarada ni dependencias; por eso el impacto en portafolio da 0 y no se puede afirmar que no haya efecto. No se calcula cuántos días se mueve cada proyecto: falta holgura por actividad. |

Por señal (`change-control`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Armé la solicitud de cambio de PRY-205 (Prevención de lavado de activos), pero no se puede aprobar tal como está escrita: la salida a producción ya tiene una fecha pasada.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

- **La fecha ya pasó:** la salida a producción está en 2026-06-23 y con +30 días pasaría a 2026-07-23. Hoy es 2026-10-15, así que las dos son anteriores. La ficha marca ese hito como cumplido sin ninguna evidencia, y el informe lo declara en verde con 75 %. Hay que aclarar si la salida ya ocurrió o si el cronograma v2 (aprobado el 2026-10-14) nació con una fecha vencida.
- **Alcance y costo:** no hay impacto declarado. Alguien absorbe esos 30 días en horas o en calidad. La prueba de carga ya falló y se repite, y el riesgo de concentración del conocimiento no tiene dueño.
- **Portafolio:** el cálculo da 0 proyectos alcanzados. Eso solo significa que PRY-205 no declara dependencias, no que no haya efecto. Tampoco calculé cuántos días se movería cada proyecto, porque falta holgura por actividad.
- **Quién decide:** el acta no declara autoridad de cambios, así que va al comité (Consejo de Administración; el próximo es el 2026-10-22). El CC-01 dice «autorizado por el comité» sin nombrar a nadie. Sus 27 días coinciden con la línea base 2, así que no hay días sin autorizar.
- **Si se aprueba:** línea base 3 con cierre en 2026-07-23. Contra la línea base original (2026-05-27) la desviación acumulada pasaría de +27 a **+57 días**, unos 24,7 % de la duración original frente a 11,7 % hoy.
- **Lo que falta:** solicitante, motivo, quién tiene la autoridad de cambios y las dependencias reales de PRY-205.

Guardé el texto completo en `estado/corridas/salida-change-control.md` y registré la corrida como `2026-10-15-change-control-1`.
