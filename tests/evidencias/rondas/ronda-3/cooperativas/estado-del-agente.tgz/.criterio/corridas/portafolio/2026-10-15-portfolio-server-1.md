# Corrida · 2026-10-15-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:43:33 · **Fin:** 2026-10-15T16:44:14 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 64 | puerto 8787, carpeta del informe reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Rostrum arrancó bien en modo «para mirarlo un rato». No hice ninguna petición al servidor; el 15 s de espera fue un arranque de prueba y el proceso se cortó solo.

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los volví a registrar.
- **Informe:** existe en `reportes/`, con 13 proyectos. El servidor lista 8 productos, pero en `reportes/` hay 7 archivos de producto. Esa diferencia no la revisé.
- **Registro:** dejé lo que te mostré en `estado/corridas/salida-portfolio-server.md`. La corrida quedó registrada como `2026-10-15-portfolio-server-1`.
- **Dónde corre:** `http://127.0.0.1:8787/`, solo en este equipo. Las rutas son `/pmo`, `/decisiones`, `/proyectos`, `/productos`, `/corridas` y `/estado.json`.
- **Aviso sobre `/pmo`:** en `reportes/` no hay un `pmo.html`. Si esa ruta no responde, hay que correr `/portfolio-report html` otra vez.
- **Si lo vuelves a levantar:** este comando termina al detener el proceso. Para dejarlo corriendo hay que ejecutarlo en una terminal propia, con Ctrl-C para pararlo. Si el 8787 está ocupado, usa `--puerto 8788`.
- **A quién pasarle el enlace:** a nadie todavía. `127.0.0.1` solo abre en este equipo, así que el patrocinador no puede verlo. Para eso hace falta «que quede corriendo» con `--abierto`, detrás del control de acceso de la organización. El servidor no autentica.
- **Cuándo se desactualiza:** el informe es de 2026-10-15. Queda viejo cuando cambie algún documento o se corra un nuevo barrido. La portada muestra su fecha.
