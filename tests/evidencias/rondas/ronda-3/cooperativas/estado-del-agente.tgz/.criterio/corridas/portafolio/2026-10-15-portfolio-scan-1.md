# Corrida · 2026-10-15-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T16:23:30 · **Fin:** 2026-10-15T16:27:06 · **Duración:** 216 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 79 | 198 | 64 | 10 fichas nuevas (PRY-199,200,201,205-211); 52 de 79 documentos leídos, 27 sin cambio; nada movido (no existe entrada/); nada omitido. Mirar: factura FV-1901 de PRY-209 sin acta de recibo del contrato; cronogramas v2 de PRY-208 y PRY-209 con CC-01 pendiente; compromisos con fecha anterior al acta en PRY-205 y PRY-210; citas de PRY-203 sin carpeta de proyecto. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 22, `commitment_overdue` 9, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 5, `variance_time` 4, `rebaseline_unauthorized` 3, `vendor_deliverable_late` 3, `commitment_rescheduled` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `change_without_baseline` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Barrido terminado y registrado: leí 52 de los 79 documentos y levanté 10 fichas nuevas.

**Qué se hizo**
- Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo nada que aceptar de nuevo.
- Los 27 documentos sin cambio no se releyeron. Las fichas de PRY-202, 203 y 204 quedan como estaban.
- Las 10 fichas nuevas son PRY-199, 200, 201, 205, 206, 207, 208, 209, 210 y 211. Cada una se escribió y se selló al terminar su proyecto, una tras otra, sin subagentes.
- Los 79 documentos se pudieron leer.
- No existe la carpeta `entrada/`, así que no se movió nada.
- Los datos que no estaban en los documentos quedaron como `not_found`: la autoridad del gerente y la fase en los diez proyectos, y el producto en PRY-205, 208, 209 y 210, cuyas actas dicen «No aplica».

**Qué mirar** (lo que dicen los documentos y lo que marca el cálculo de la corrida, 64 hallazgos en total)
- **PRY-209:** hay una factura radicada (FV-1901, 1.882.339.743 COP) y ningún acta de recibo de entregables del contrato CT-901. El script lo marca como factura sin entrega.
- **PRY-205:** la factura (1.396.951.861 COP) supera lo aceptado. Además, el tercer entregable figura «recibido» en el contrato sin acta.
- **PRY-208 y PRY-209:** los cronogramas v2 ya aplican la CC-01, que sigue pendiente de presentación al comité.
- **Compromisos:** dos están vencidos con la fecha prometida anterior a la del acta que los registra: Paula Céspedes en PRY-205 y Elena Duarte en PRY-210.
- **Hitos:** 22 hitos están declarados cerrados sin un acta que los pruebe.
- **Índice:** la ficha de PRY-203 cita su acta sin la carpeta del proyecto, y existe una carpeta anidada `estado/PRY-203-…`. No las toqué.

Dejé el informe completo en `estado/corridas/salida-portfolio-scan.md` y la corrida con su instantánea quedó registrada como `2026-10-15-portfolio-scan-1`.

Si quiere, sigue el informe consolidado del portafolio, porque ya hay más de un proyecto con ficha.

Criterio Portfolio 0.3.9 · fichas tocadas: 10 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
