## Definición — Tarjeta débito (PRD-303) · contrastada al 2026-10-15
**Documento:** `00-definicion/2026-04-05-definicion-producto.docx` (con `2026-04-05-caso-de-negocio.md`) · **del** 2026-04-05 · 5 afirmaciones (problema, segmento, propuesta, cifra de volumen, supuesto del proveedor)

### Lo que la evidencia contradice
Nada. Ninguna fuente de la carpeta dice lo contrario de la definición.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 250.670 | 256.871 | +2,5 % | Caso de negocio, 2026-04-05 · Tablero de métricas (bodega de datos), corte 2026-10-06 |

La diferencia (2,5 %) está por debajo del umbral de 20 %: es imprecisión, no contradicción.

### Afirmaciones numéricas que nadie mide
Ninguna: la única cifra declarada (volumen_mensual) tiene serie. La serie tiene un solo punto (2026-10-06), así que no hay tendencia que juzgar.

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo declara.
- **Tamaño del segmento Pensionados:** la definición dice que no tienen tarjeta débito, sin cifra de cuántos son.
- **Qué es la «propuesta principal»:** la definición solo trae ese rótulo, sin contenido.
- **Cuánto pagaría o usaría el cliente:** no hay dato de disposición a pagar.
- **De dónde sale el volumen de 250.670:** el caso de negocio lo cita a sí mismo como fuente.
- **Qué significa «retorno esperado en 24 meses»:** no hay cifra ni método.
- **Proyecto que lo construye:** la definición dice «Ninguno declarado», y ninguno de los 16 requerimientos tiene proyecto.
- **Que el comprador son los Pensionados:** el problema se dice del segmento, pero la única entrevista no dice que su autor pertenezca a él.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado | 158 (declarado el 2026-05-10; el umbral es 30) | Nombrar al proveedor y el tiempo pactado, e incorporar el contrato o un acta de entrega. Hoy ninguno está en la carpeta. |

Nota: el supuesto está fechado el 2026-05-10 dentro de una definición del 2026-04-05, o sea que se agregó o se revisó después sin que cambiara la fecha del documento.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Pensionados no tiene tarjeta débito (el problema) | Una entrevista a un «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» | 2025-09-12 | Débil: una sola voz, dicha y no pagada, sin decir que sea Pensionado |
| volumen_mensual ≈ 250.670 | Tablero de métricas: 256.871 | 2026-10-06 | Medida, un solo punto |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema de los Pensionados | Entrevista del 2025-09-12 | 13 meses (umbral 12) |
| 12 de los 16 requerimientos | La misma entrevista; el acta la cita como origen, pero la entrevista no nombra ninguno | 13 meses |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Tarjeta débito: medios de pago, datos personales de clientes, protección al consumidor financiero | No consta en la configuración ni en los documentos | — | — | No tengo la norma a la vista. No es un cumplimiento: es un vacío del barrido. Va a revisión jurídica una vez se declare el país. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él la definición no se puede cerrar, porque el cierre se juzgaría contra algo que no se escribió.
- Problema: está dicho. Para quién: Pensionados. Quién decide: Comité de producto.
- Además, el comité del 2026-10-05 aceptó 11 requerimientos y «mantuvo el plan» con la definición abierta; 4 aceptados no tienen evidencia y 4 no tienen doliente (señales del registro, no de esta definición).

**Después:** el supuesto del proveedor lleva 158 días sin verificar; se puede convertir en riesgo con doliente (raid-taxonomy). La definición no está cerrada, así que no corresponde ofrecer `/product-charter`.
