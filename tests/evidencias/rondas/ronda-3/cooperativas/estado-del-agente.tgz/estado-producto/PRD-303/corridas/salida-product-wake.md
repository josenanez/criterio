## Tarjeta débito (PRD-303) · 2026-10-15

**Primera revisión del registro: no hay corte anterior, así que todo lo de abajo es nuevo.** Desde la próxima corrida solo se reportará lo que cruce un umbral después de hoy. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-15). Ningún documento nuevo ni cambiado: 5 de 5 sin cambios, solo recalculé.

### Lo que necesita decisión del comité de producto
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 d) | REQ-4306 | 175 días | Decisión formal; no hay dato de quién tiene la facultad | Sandra Gil (doliente) |
| Sin decidir | REQ-4312 | 154 días | Ídem | Ricardo Salas |
| Sin decidir | REQ-4310 | 116 días (y sin criterio de aceptación) | Ídem, más definir aceptación | Paula Céspedes |
| Sin decidir | REQ-4308 | 104 días | Ídem | Liliana Torres |
| Sin decidir | REQ-4302 | 82 días | Ídem | Liliana Torres |
| Supuesto sin verificar (umbral 30 d) | «El proveedor cumple el tiempo pactado» | 158 días | Evidencia de cumplimiento del proveedor (plazos reales contra el plazo pactado); si no se consigue, tratarlo como riesgo registrado | Sandra Gil |

### Aceptado sin sustento
- **Sin evidencia de demanda** (REQ-4300, 4307, 4309, 4314): aceptados sin que nada en la carpeta muestre que alguien los pidió.
- **Sin doliente** (REQ-4303, 4309, 4313, 4314): nadie responde por ellos.
- **Sin criterio de aceptación** (REQ-4303, 4305 aceptados; REQ-4310 propuesto): no se puede verificar que se cumplieron.
- **Sin proyecto que los construya: los 11 aceptados** (0 % de trazabilidad). Ninguno nombra proyecto.

### Evidencia envejecida
12 requerimientos se apoyan en la misma entrevista del 2025-09-12 (13 meses, umbral 12). Además, esa entrevista («Lo necesito y hoy no lo tengo.») no nombra ninguno de ellos. Quedan sin sustento vigente las afirmaciones de demanda de esos requerimientos, no solo envejece un documento.

### Las trazas
No se confirma ninguna: ningún requerimiento declara proyecto. La ficha de PRY-204 «Tarjeta débito para asociados» (gerente Ricardo Salas) dice producto «tarjeta débito», pero no cita PRD-303 ni ningún REQ. Es un candidato a vincular, no una traza: la confirma una persona.

### Del descubrimiento y la definición
- Éxito de la definición: **no está dicho en ningún documento**.
- Declarado vs. medido: volumen mensual declarado 250.670 contra 256.871 medido (tablero, 2026-10-06): brecha 2,5 %, bajo el umbral de 20 %. No es hallazgo.
- Sin documentos de descubrimiento nuevos; el único es la entrevista de 2025-09-12.

### Qué no sé
- Quién tiene la facultad de decidir los pendientes: el registro nombra solo al «Comité de producto».
- El chequeo de índice marca como «fuente no encontrada» los 7 campos de identidad y definición, aunque los archivos están en la carpeta. Lo trato como un fallo de resolución de rutas, no como borrado; vale la pena revisarlo.
- Qué REQ son en realidad: los títulos son genéricos («Requerimiento REQ-43xx»).

**Vuelvo el 2026-11-14.**
