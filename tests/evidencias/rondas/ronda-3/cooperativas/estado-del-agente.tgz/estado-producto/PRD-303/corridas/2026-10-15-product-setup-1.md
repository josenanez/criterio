# Corrida del 2026-10-15 · product-setup

PRD-303 · 16 requerimientos · 31 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 12 |
| `requirement_untraced` | 11 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

0 preguntas respondidas por la persona (sesión sin interfaz, 3 con propuesta por defecto); primer resultado en una sola pasada; 16 requerimientos, 11 aceptados sin proyecto, 4 aceptados sin evidencia, 12 con evidencia de 13 meses, 1 supuesto sin verificar 158 días, éxito no_encontrado, métrica con 2,5% de diferencia

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Tarjeta débito (PRD-303)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 5 documentos · 1 de descubrimiento (una sola ronda de entrevistas, 2025-09-12) · la definición del 2026-04-05 (caso de negocio y documento de producto) · lo más reciente es el tablero de métricas del 2026-10-06. Un formato que leí con cuidado: el `.docx` de la definición, que extraje como texto.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.9 (términos 1.1) · 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 de los términos d31e6b3611041618…
**Preguntas:** ninguna se pudo responder (sesión sin interfaz); tomé la propuesta en cada una:
- Producto: Tarjeta débito (PRD-303), gerente Sandra Gil, según el caso de negocio.
- Quién decide: «Comité de producto». Propuesta mía: ningún documento lo dice, y el acta solo lista como asistente a Sandra Gil.
- Estado: `estado-producto/PRD-303`, hermana de `documentos`. No usé `estado/`, que es de otro agente.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Los Pensionados no tienen tarjeta débito | Una cita: «Lo necesito y hoy no lo tengo.» No dice quién es, ni que sea pensionado, ni de qué producto habla | 2025-09-12 (13 meses) |
| volumen_mensual = 250.670 | El tablero mide 256.871: 2,5 % de diferencia, por debajo del umbral de 20 %; es imprecisión, no contradicción | Declarado 2026-04-05 · medido 2026-10-06 |
| «Retorno esperado en 24 meses» | Nada: no hay cifra ni fuente | 2026-04-05 |
| El proveedor cumple el tiempo pactado | Un supuesto declarado, sin verificar desde hace 158 días | Declarado 2026-05-10 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo trae; el caso de negocio solo dice «retorno esperado en 24 meses», sin cifra.
- **Qué necesita cada requerimiento.** Los 16 se llaman «Requerimiento REQ-43xx». Ningún documento dice qué problema resuelve ninguno.
- **Quién, de los Pensionados, pidió qué.** Hay una cita y 12 requerimientos dicen «Cliente entrevistado». Esa cita no nombra ningún requerimiento.
- **Qué proyecto ejecuta lo aceptado.** 11 requerimientos aceptados y 0 con proyecto. La definición dice «Ninguno declarado».
- **Cuál es «el plan» que el comité mantuvo el 2026-10-05.** No hay plan en la carpeta.
- **Quién decide.** El acta no nombra a quien aceptó los 11 requerimientos.
- **Cuántos Pensionados son, y cuál es el tiempo pactado con el proveedor.** No aparece el tamaño del segmento ni el plazo ni el contrato del proveedor.

### Lo que dice el registro (cifras de `compute`)
- 16 requerimientos: 11 aceptados, 5 propuestos.
- Aceptados sin evidencia de quién lo pidió: 4 (REQ-4300, 4307, 4309, 4314).
- Aceptados sin proyecto que los ejecute: 11.
- Sin doliente («sin asignar»): 4 (REQ-4303, 4309, 4313, 4314). Dos de ellos, 4309 y 4314, además sin evidencia y sin proyecto.
- Aceptados sin criterio de aceptación: 2 (REQ-4303, 4305). Los demás dicen «se verifica en producción», que no es un criterio verificable.
- Evidencia de más de 12 meses (13): 12 requerimientos, todos apoyados en la misma entrevista.
- Propuestos sin decisión: 5, entre 82 y 175 días (REQ-4306 es el más viejo, 175 días).
- Con evidencia: 63,6 % de los decididos; con traza a proyecto: 0,0 %.

### Supuestos sobre los que está escrita
Uno, declarado: «El proveedor cumple el tiempo pactado», del 2026-05-10, sin verificar (158 días). El documento no declara ningún otro. Eso también es un hallazgo: un producto de tarjeta débito para un segmento nuevo y ningún supuesto sobre adopción, regulación ni emisión.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una sola cita, de una sola ronda, de hace 13 meses.
- La serie de la métrica principal: hay un solo punto (2026-10-06), así que no se ve tendencia, solo una comparación contra la cifra de abril.
- Las decisiones del comité con quién decidió y por qué: sin ellas un requerimiento descartado se ve igual que uno que nadie miró. Esta acta no registra ninguno descartado.

### Una nota sobre cómo corrí
`sellar` exigió una corrida abierta (`corrida-inicio`) y que las fichas se escribieran dentro de ella; el comando dice que aquí no va. Abrí la corrida y reescribí las fichas, así que el tiempo medido es el de esta conversación completa.
Tampoco se registró ninguna pregunta contestada por la persona.

**Después:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién los pidió.
