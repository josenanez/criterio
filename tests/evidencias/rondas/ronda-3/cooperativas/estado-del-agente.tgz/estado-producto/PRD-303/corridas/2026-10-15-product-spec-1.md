# Corrida del 2026-10-15 · product-spec

PRD-303 · 16 requerimientos · 32 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 12 |
| `requirement_untraced` | 11 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

Borrador de especificación PRD-303: 11 aceptados en alcance, 5 propuestos fuera. Sin sección de comportamiento porque ningún requerimiento trae contenido; criterio 'se verifica en producción' no verificable; 2 sin criterio, 4 sin doliente; criterio de éxito y regulatorio sin resolver.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribe el agente; lo cierra Sandra Gil (gerente de producto) con la autoridad del Comité de producto. Este agente no aprueba.

# Especificación — Tarjeta débito (PRD-303) · borrador del 2026-10-15

## Qué problema resuelve
«El segmento Pensionados no tiene tarjeta débito.» (definición de producto, 2026-04-05). La definición **no dice** el criterio de éxito del producto (`success`: no encontrado).

## Lo que esta especificación no puede ser
El registro tiene 16 requerimientos y **ninguno trae contenido**: los títulos son «Requerimiento REQ-43xx» y el único criterio de aceptación escrito es «se verifica en producción». Ningún documento dice qué debe hacer cada uno. Por eso **no hay sección de Comportamiento**: redactarla sería inventar lo que nadie decidió. Lo que sigue es el esqueleto trazable y los huecos.

## Alcance
Entran los 11 requerimientos en estado `aceptado` (acta del comité del 2026-10-05). No hay ninguno `en_construccion`.

### Entra
REQ-4300, 4301, 4303, 4304, 4305, 4307, 4309, 4311, 4313, 4314, 4315.

### No entra
- REQ-4302, 4306, 4308, 4310, 4312: están `propuesto`; nadie los decidió. REQ-4306 lleva desde 2026-04-23 (175 días) sin decisión, y REQ-4312 desde 2026-05-14 (154 días), ambos sobre el umbral de 60 días.
- Todo lo que no esté en el registro: no se agregó nada. Tampoco hay definido qué queda fuera por decisión del producto (el documento de definición no lo dice).

## Comportamiento
Sin redactar: ningún requerimiento aceptado describe comportamiento (ver arriba). Cada requerimiento necesita que su doliente diga qué debe ocurrir antes de poder escribir esta sección.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | 4300, 4301, 4304, 4307, 4309, 4311, 4313, 4314, 4315 | No dice qué se mira ni qué resultado cuenta como cumplido; dos personas pueden discrepar | **No es verificable**: no hay umbral ni medida |
| *(sin criterio)* | 4303, 4305 | — | — |

Ningún criterio pasa la prueba de las dos personas. Es un hallazgo del registro, no un detalle: el comité aceptó 9 requerimientos con un criterio que es una frase de procedimiento, no una condición.

Dato de contexto medible: `volumen_mensual` se mide (tablero, 256.871 al 2026-10-06 vs. 250.670 declarado en el caso de negocio, +2,5 %). Ningún criterio lo usa; no se propuso ninguno.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-10) | No (más de 30 días sin verificar; son 158) | Sin dueño en el registro; propongo a Sandra Gil que lo asigne |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Contenido/comportamiento de cada requerimiento aceptado (los 11) | No hay qué construir ni qué verificar | Cada doliente; para 4300 Ricardo Salas, 4301 y 4305 Elena Duarte, 4304 Carlos Peña, 4307 María Restrepo, 4311 y 4315 Camilo Beltrán |
| Doliente de REQ-4303, 4309, 4313, 4314 («sin asignar») | Aceptados sin nadie que responda por ellos | Sandra Gil / Comité de producto |
| Criterio de aceptación de REQ-4303 y REQ-4305 | Aceptados sin forma de saber si quedaron bien | Doliente de 4305: Elena Duarte; 4303: sin doliente, Sandra Gil |
| Criterio verificable en lugar de «se verifica en producción» (9 req.) | La discusión de si quedó bien ocurre después de construir | Dolientes respectivos |
| Quién pidió REQ-4300, 4307, 4309, 4314 (el acta no lo dice: «—») | Aceptados sin demanda sustentada | Sandra Gil |
| Sustento de los demás: el acta dice «Cliente entrevistado», pero la única entrevista (2025-09-12) no nombra ningún requerimiento | Evidencia de 13 meses, general, no atribuible a un requerimiento concreto | Sandra Gil |
| Criterio de éxito del producto (no encontrado) | Nada contra qué medir si el producto funcionó | Sandra Gil / Comité |
| Casos borde (sin conexión, operación duplicada, pérdida o bloqueo de tarjeta, etc.): ninguno definido | Comportamiento decidido por quien construya | Dolientes; no los rellené |
| Lo que otros equipos deben hacer: no hay ningún proyecto asociado a ningún requerimiento y la definición dice «Ninguno declarado»; el proveedor es dependencia nombrada en el supuesto, sin acuerdo registrado | Aceptado y sin quien lo construya; dependencia no acordada | Sandra Gil con el equipo/proveedor que corresponda (no identificados en los documentos) |
| Obligaciones normativas: **no barridas**. El producto es una tarjeta débito para pensionados, que roza pagos, protección al consumidor financiero y datos personales | No se sabe qué obligaciones aplican ni quién responde | Sandra Gil con el área legal/cumplimiento (no identificada); corresponde correr regulatory-sweep antes de cerrar |

## Requerimientos aceptados que esta especificación no cubre
| ID | Título | Por qué no |
|---|---|---|
| REQ-4300, 4301, 4303, 4304, 4305, 4307, 4309, 4311, 4313, 4314, 4315 | «Requerimiento REQ-43xx» (sin título real) | **Ninguno queda cubierto con comportamiento**: el registro no dice qué piden. Figuran en el alcance y en criterios, no en una sección de comportamiento |

## Pie
Sale del registro de requerimientos (16 requerimientos, 11 aceptados cubiertos en alcance), tomado del acta del comité del 2026-10-05 y del estado a 2026-10-15. Términos aceptados (v1.1, comprobante 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal

Siguiente paso: **no ofrezco `/product-charter`** todavía; no se cumple la condición (vacíos abiertos y el producto sin criterio de éxito).
