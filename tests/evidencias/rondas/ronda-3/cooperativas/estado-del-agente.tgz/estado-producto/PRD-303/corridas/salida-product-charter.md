# Acta de constitución — Tarjeta débito (REQ-4300) · borrador del 2026-10-15
**Producto:** PRD-303 Tarjeta débito · **Requerimientos:** REQ-4300

> **Verificación previa (paso 1): el requerimiento NO pasa completo.** Sesión sin interfaz: tomo la respuesta sugerida —seguir marcando cada faltante como vacío del acta, sin rellenarlo— y lo digo aquí.
> - Aceptado: **sí**. Comité de producto, 2026-10-05, aceptado desde 2026-06-05 (`documentos/productos/PRD-303/30-decisiones/2026-10-05-comite-producto.md`).
> - Criterios de aceptación: **hay uno, pero no es verificable**: «se verifica en producción» (mismo documento). Dice dónde, no qué se mide.
> - Evidencia de demanda: **falta**. «Quién lo pidió» está en «—» y `evidence` está vacío en `REQ-4300.json`.
> - Autoridad: el producto declara «Comité de producto» (`config.json`, y la decisión del 2026-10-05), pero **la autoridad del gerente del proyecto no está dicha en ningún documento**.

## Qué problema resuelve
«El segmento Pensionados no tiene tarjeta débito.» (`00-definicion/2026-04-05-definicion-producto.docx`, 2026-04-05). **Ojo:** esa es la definición del producto, no de REQ-4300. El título del requerimiento es genérico («Requerimiento REQ-4300») y ningún documento dice qué pide ese requerimiento en concreto. No puedo afirmar que REQ-4300 resuelva ese problema; solo que pertenece a PRD-303.

## Criterio de éxito
| Criterio | Cita | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | comité 2026-10-05 | **No se puede decir.** No hay métrica, umbral ni fecha. |

El éxito del producto tampoco está definido: `definition.success` = no encontrado en la definición.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4300 | «Requerimiento REQ-4300» (sin título real) | **Ninguna registrada.** Doliente: Ricardo Salas (comité 2026-10-05). |

### No entra
Este acta cubre solo REQ-4300, así que el resto del registro queda fuera por no haberse pedido, no por una decisión de exclusión con razón. Para que ese corte no se lea como decisión del comité, lo dejo explícito:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4301 a REQ-4315 (15 requerimientos) | sin título real | **No se pidieron en esta acta.** Ninguna razón de fondo está documentada. De ellos, 4302, 4306, 4308, 4310 y 4312 siguen «propuestos» (no pueden entrar sin aceptación); 4303, 4309, 4313 y 4314 están aceptados pero «sin asignar» de doliente. Quién decide si entran en este proyecto o en otro: el gerente de producto. |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no dicho. Sandra Gil es la gerente del **producto** (definición 2026-04-05) y asistió sola al comité; no hay documento que la proponga para el proyecto. No lo nombro.
- **Comité:** Comité de producto (`config.json`; decisión del 2026-10-05 con asistente único: Sandra Gil).
- **Autoridad del gerente del proyecto:** no dicha. Es el campo que más cuesta después.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-05-10) | **No.** Lleva 158 días sin verificar, contra un umbral de 30 | **Sin doliente.** Propongo registrarlo como riesgo (RAID) del proyecto; quién lo asume lo decide quien firma. Además: la definición dice «Proyectos que lo construyen: ninguno declarado», así que no hay proveedor ni plazo pactado citado en ningún documento. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Tarjeta débito para pensionados (pagos, datos personales, consumidor financiero) | No levantada | **No se hizo el barrido normativo** en esta corrida | Sin resolver; no opino sobre cumplimiento. Debe correrse antes de firmar. |

## Cifras que el acta hereda (para que no se firmen a ciegas)
- Caso de negocio: volumen_mensual **250.670** (2026-04-05). Tablero: **256.871** medido el 2026-10-06. Diferencia 2,5 %, bajo el umbral de 20 %. Pero esa cifra pertenece al producto, no a REQ-4300, y el caso de negocio no explica de dónde sale un volumen mensual para un producto que, según la definición, el segmento aún no tiene. «Retorno esperado en 24 meses» no trae cifra.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Evidencia de demanda de REQ-4300 (quién lo pidió) | El proyecto arranca sin poder mostrar que alguien lo necesita. La única entrevista (2025-09-12, 1 cliente, «Lo necesito y hoy no lo tengo») tiene 13 meses, supera el umbral de 12 y no menciona REQ-4300 | Gerente de producto (Sandra Gil) |
| Qué pide REQ-4300 (título y descripción reales) | Nadie puede juzgar si el alcance «entra» | Ricardo Salas (doliente), con Sandra Gil |
| Criterio de aceptación verificable | El cierre no se podrá juzgar meses después | Ricardo Salas / Comité de producto |
| Criterio de éxito del producto | Idem, a nivel producto | Sandra Gil |
| Patrocinador | Nadie responde por el presupuesto ni por escalamientos | Comité de producto |
| Gerente del proyecto y su autoridad | Escala todo o nada escala | Quien tenga la autoridad de asignar |
| Barrido normativo | Obligaciones desconocidas al arrancar | Gerente de producto con Jurídico/Cumplimiento |
| Presupuesto e hitos | No hay ninguno declarado; la ficha nacería sin ellos | Patrocinador |
| Reunión del comité | Solo asistió una persona (Sandra Gil), que además es gerente de producto y doliente de REQ-4306: la aceptación no muestra deliberación | Comité de producto |

---
**Esto es un borrador.** Lo firma la persona con autoridad para constituir el proyecto (hoy sin identificar; el comité de producto es el órgano declarado). **La ficha del proyecto NO se crea:** no hay firma, y el acta tiene vacíos que condicionan la firma. Este comando no firma ni da por firmado.

**Qué sigue, y para quién:** primero, Sandra Gil cierra los vacíos de arriba (en especial demanda y criterio verificable). Después de la firma, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
