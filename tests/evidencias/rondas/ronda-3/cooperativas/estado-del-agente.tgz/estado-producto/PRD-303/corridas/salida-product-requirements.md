## Registro — Tarjeta débito (PRD-303) · al 2026-10-15
16 requerimientos · 11 decididos · 63,6 % con evidencia · 0 % con proyecto que lo ejecuta

Los 16 se llaman «Requerimiento REQ-43xx»: el acta del comité no les da título, así que no hay forma de decir de qué trata cada uno.

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió (la columna «Quién lo pidió» del acta está en «—»).
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4300 | sin título | aceptado el 2026-06-05 | Ricardo Salas |
| REQ-4307 | sin título | aceptado el 2026-04-28 | María Restrepo |
| REQ-4309 | sin título | aceptado el 2026-07-31 | sin asignar |
| REQ-4314 | sin título | aceptado el 2026-08-20 | sin asignar |

### Decidido y nadie lo está construyendo
Los 11 aceptados tienen «—» en proyecto que los ejecuta. Los más antiguos:
| REQ | Decidido el |
|---|---|
| REQ-4307 | 2026-04-28 |
| REQ-4301 | 2026-05-30 |
| REQ-4305 | 2026-05-31 |
| REQ-4300 | 2026-06-05 |
| REQ-4311 | 2026-06-11 |
| REQ-4303 | 2026-06-19 |
| REQ-4304 | 2026-06-27 |
| REQ-4309 | 2026-07-31 |
| REQ-4315 | 2026-08-04 |
| REQ-4314 | 2026-08-20 |
| REQ-4313 | 2026-09-01 |

### Sin doliente
| REQ | Dice |
|---|---|
| REQ-4303 | «sin asignar» |
| REQ-4309 | «sin asignar» |
| REQ-4313 | «sin asignar» |
| REQ-4314 | «sin asignar» |

Quién lo cierra: la asignación le toca a Sandra Gil, gerente del producto, en el comité (inferido de la configuración; ningún documento lo dice).

### Sin criterio de aceptación
Solo los decididos. REQ-4310 (propuesto) no cuenta: a un propuesto no se le exige.
| REQ | Estado |
|---|---|
| REQ-4303 | aceptado |
| REQ-4305 | aceptado |

Quién lo cierra: Elena Duarte para REQ-4305; REQ-4303 no tiene doliente y primero necesita uno.

Aparte: en los demás, el criterio dice «se verifica en producción», lo mismo en todos. No lo marco como vacío, pero tampoco dice qué se mide.

### Decidido sin documento que lo respalde
El cálculo no lo marca como señal. Lo que veo: las 11 decisiones citan el mismo acta (2026-10-05), que registra un solo asistente (Sandra Gil) y una sola decisión: «Se mantiene el plan». No dice quién aceptó cada requerimiento. Las fechas de decisión van de abril a septiembre, anteriores al acta. Falta el documento de cada decisión; el acta no lo reemplaza.

### Lleva meses y nadie lo decide
Umbral: 60 días. Los 5 propuestos lo pasan.
| REQ | Doliente | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4306 | Sandra Gil | 175 días (2026-04-23) | Comité de producto |
| REQ-4312 | Ricardo Salas | 154 días (2026-05-14) | Comité de producto |
| REQ-4310 | Paula Céspedes | 116 días (2026-06-21) | Comité de producto |
| REQ-4308 | Liliana Torres | 104 días (2026-07-03) | Comité de producto |
| REQ-4302 | Liliana Torres | 82 días (2026-07-25) | Comité de producto |

La facultad es del Comité de producto, según la configuración. Ese comité dejó el 2026-10-05 «Se mantiene el plan» y los cinco siguen propuestos. REQ-4306 es del propio gerente del producto.

### Evidencia vieja
12 requerimientos (7 aceptados y los 5 propuestos) se apoyan en lo mismo: la entrevista del 2025-09-12, de hace 13 meses (umbral 12). Los 12: REQ-4301, 4302, 4303, 4304, 4305, 4306, 4308, 4310, 4311, 4312, 4313, 4315.

Esa entrevista («Lo necesito y hoy no lo tengo.») no nombra ninguno de estos requerimientos. Así, el 63,6 % de evidencia es más generoso de lo que sostiene el documento: hay una cita general del segmento, no una por requerimiento.

### Además, de la definición
- Supuesto sin verificar hace 158 días: «El proveedor cumple el tiempo pactado» (umbral 30). Nadie figura como quien lo verifica.
- Volumen mensual: declarado 250.670 (caso de negocio, 2026-04-05) frente a 256.871 medido (tablero, 2026-10-06). Diferencia 2,5 %, bajo el umbral de 20 %: no es hallazgo.
- El criterio de éxito del producto no está definido.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 11 | 0 | 0 | 0 |

Ninguno descartado: no hay registro de qué se rechazó, y esa discusión puede volver.
