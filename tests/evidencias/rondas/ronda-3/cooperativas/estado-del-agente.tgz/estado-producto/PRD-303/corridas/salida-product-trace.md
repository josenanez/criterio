## Trazabilidad — Tarjeta débito (PRD-303) · al 2026-10-15
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Ningún requerimiento del registro nombra un proyecto (`project: null` en los 16). Los 11 aceptados quedan sin proyecto:

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4311 | Requerimiento REQ-4311 | 2026-06-11 | Comité de producto (doliente: Camilo Beltrán) |
| REQ-4303 | Requerimiento REQ-4303 | 2026-06-19 | Comité de producto (sin doliente) |
| REQ-4304 | Requerimiento REQ-4304 | 2026-06-27 | Comité de producto (doliente: Carlos Peña) |
| REQ-4300 | Requerimiento REQ-4300 | 2026-06-05 | Comité de producto (doliente: Ricardo Salas) |
| REQ-4301 | Requerimiento REQ-4301 | 2026-05-30 | Comité de producto (doliente: Elena Duarte) |
| REQ-4305 | Requerimiento REQ-4305 | 2026-05-31 | Comité de producto (doliente: Elena Duarte) |
| REQ-4307 | Requerimiento REQ-4307 | 2026-04-28 | Comité de producto (doliente: María Restrepo) |
| REQ-4309 | Requerimiento REQ-4309 | 2026-07-31 | Comité de producto (sin doliente) |
| REQ-4313 | Requerimiento REQ-4313 | 2026-09-01 | Comité de producto (sin doliente) |
| REQ-4314 | Requerimiento REQ-4314 | 2026-08-20 | Comité de producto (sin doliente) |
| REQ-4315 | Requerimiento REQ-4315 | 2026-08-04 | Comité de producto (doliente: Camilo Beltrán) |

Fuente: `documentos/productos/PRD-303/30-decisiones/2026-10-05-comite-producto.md`; la columna «Proyecto que lo ejecuta» está en «—» para los 16.
Los más viejos: REQ-4307 (decidido hace 170 días), REQ-4301 (138) y REQ-4305 (137).
Los 5 «propuesto» (REQ-4302, 4306, 4308, 4310, 4312) no se cuentan aquí: no están decididos.

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar, porque ningún requerimiento dice qué proyecto lo ejecuta.

### Lo que un proyecto construye y el registro no tiene
Ninguna ficha a la vista dice que ejecuta PRD-303. La única ficha (PRY-203, `00-gobierno/ficha-pm.json`) declara el producto «aportes sociales» (acta de constitución del 2025-10-09).
Un dato aparte, sin confirmar: el proyecto PRY-204 «Tarjeta débito para asociados» existe en la carpeta de proyectos y recibió una solicitud de cambio (CC-01, 2026-10-09, Ricardo Salas, ampliación de alcance). Por el nombre parece ser el que construye este producto, pero no tiene ficha y ningún REQ lo nombra. Es una hipótesis por el nombre, no un hallazgo: hay que ir a verlo.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 11 aceptados (lista arriba) | aceptado | Comité de producto, 2026-04-28 a 2026-09-01 | — | no | — |
| 5 propuestos | propuesto | sin decidir | — | no | — |

La cadena se rompe en el segundo eslabón: hay decisión con cita, pero no hay proyecto. Los eslabones siguientes no existen.

### Sin fichas a la vista
Solo hay una ficha publicada entre los proyectos (PRY-203). Faltan las de PRY-199, 200, 201, 202, 204, 205, 206, 207, 208, 209, 210 y 211, entre ellas PRY-204. Sin ellas ninguna traza se da por confirmada.

### Para tener en cuenta
- La cobertura es 0 % porque el registro no tiene el campo de proyecto lleno, no porque se haya comprobado que nadie construye. Puede ser un hueco del registro.
- Cada uno de los 11 aceptados tiene la señal `requirement_untraced`.
- No se cuenta avance.
- No se escribió nada en ninguna ficha de proyecto.

### Después
Hay decididos sin proyecto: `/product-charter` sirve para el que ya esté listo. Si PRY-204 resulta ser el proyecto de este producto, la salida es una conversación con su gerente de proyecto para que publique la ficha.
