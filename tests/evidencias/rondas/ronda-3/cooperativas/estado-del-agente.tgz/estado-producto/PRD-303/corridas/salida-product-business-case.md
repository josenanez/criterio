# Caso de negocio — Tarjeta débito (PRD-303) · borrador del 2026-10-15
**Desde:** caso de negocio de Sandra Gil (2026-04-05), definición (2026-04-05), tablero de métricas (2026-10-06), acta del comité (2026-10-05), entrevistas (2025-09-12) · **Cifras con fuente:** 1 de 1 (la única cifra del caso es de clase declarada; no hay ninguna cifra de costo ni de retorno con valor)

## Qué problema resuelve, y para quién
El segmento Pensionados no tiene tarjeta débito. (Definición, `00-definicion/2026-04-05-definicion-producto.docx`, 2026-04-05.)
Demanda: una sola entrevista, "Lo necesito y hoy no lo tengo" (Cliente entrevistado, `10-descubrimiento/2025-09-12-entrevistas.md`, 2025-09-12). Tiene más de 12 meses y no dice si el entrevistado es del segmento Pensionados.

## Qué se construye
Se toman los requerimientos en estado "aceptado" del acta del comité (`30-decisiones/2026-10-05-comite-producto.md`, 2026-10-05). Ninguno tiene proyecto que lo ejecute.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4300 | aceptado | Sin quién lo pidió |
| REQ-4301 | aceptado | Cliente entrevistado |
| REQ-4303 | aceptado | Cliente entrevistado; sin doliente ni criterio de aceptación |
| REQ-4304 | aceptado | Cliente entrevistado |
| REQ-4305 | aceptado | Cliente entrevistado; sin criterio de aceptación |
| REQ-4307 | aceptado | Sin quién lo pidió |
| REQ-4309 | aceptado | Sin quién lo pidió; sin doliente |
| REQ-4311 | aceptado | Cliente entrevistado |
| REQ-4313 | aceptado | Cliente entrevistado; sin doliente |
| REQ-4314 | aceptado | Sin quién lo pidió; sin doliente |
| REQ-4315 | aceptado | Cliente entrevistado |

Quedan fuera del alcance del caso los 5 propuestos (REQ-4302, 4306, 4308, 4310, 4312). Los títulos de los requerimientos son genéricos ("Requerimiento REQ-43xx"), así que el documento no dice qué se construye en concreto.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual esperado | 250.670 | Declarada | Caso de negocio, Sandra Gil | 2026-04-05 |
| volumen_mensual observado | 256.871 | Medida | Bodega de datos, tablero de producto | 2026-10-06 |
| Retorno esperado | "en 24 meses" | Sin valor: no es cifra | Caso de negocio | 2026-04-05 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 250.670 (caso de negocio, 2026-04-05) | 256.871 (tablero, 2026-10-06) | Diferencia de 6.201, es decir 2,5 %: está por debajo del umbral de 20 % configurado, así que no es hallazgo. Sí hay un detalle: la medida es un solo punto, y 250.670 es lo que el caso esperaba antes de lanzar. No se sabe si la tarjeta ya está en producción. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | No declarado | — (vacío) |
| Costo del equipo | No declarado | — (vacío) |
| Contratos o cotizaciones del proveedor | No declarados | — (vacío) |

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-05-10, sin verificar; más de 30 días, umbral configurado) | Se atrasa la entrega de la tarjeta y la cifra de volumen no se alcanza en el plazo | Sin asignar; propuesto: Sandra Gil con el contrato del proveedor, que no está en la carpeta |
| El volumen esperado de 250.670 es alcanzable por el segmento Pensionados. Está implícito: el caso no dice cómo se calculó | El caso entero se queda sin base | Sin asignar |
| Una entrevista de 2025 representa la demanda del segmento. Implícito | La demanda no está demostrada | Sandra Gil / descubrimiento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso de negocio que evaluar: hay una propuesta | Sandra Gil / Finanzas |
| Beneficio o ingreso con valor y fuente | "Retorno esperado en 24 meses" no es una cifra | Negocio (Sandra Gil) |
| Cómo se calculó 250.670 | La cifra está declarada pero su método no | Sandra Gil |
| Criterio de éxito (la definición no lo trae) | Sin él no se puede cerrar el producto | Sandra Gil / Comité de producto |
| Qué pasa si no se hace; alternativas consideradas | El caso no dice nada de ninguna | Sandra Gil |
| Contrato o fecha pactada con el proveedor | Sostiene el supuesto del proveedor | Sandra Gil / Compras |
| Si el producto ya opera (de dónde sale el volumen medido) | Cambia lo que significa la cifra medida | Sandra Gil / dueño del tablero |
| Serie de la métrica (solo hay un punto) | Con un punto no hay tendencia | Dueño del tablero |

## Cómo se sabrá si funcionó
No está declarado. La definición no tiene criterio de éxito. La única pista es volumen_mensual contra 250.670, sin fecha de corte ni umbral. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguna ficha publicada: la carpeta `estado/` está vacía. Busqué 250.670 en los documentos de PRD-299 a PRD-309 y no aparece. Otros once productos tienen una métrica volumen_mensual en sus propios casos o tableros. No los cruzo, porque sin ficha publicada no hay corte comparable. Cuando se publiquen, conviene correr `/product-overlap`.

## Lo que no hace este documento
No proyecta ingresos, retorno ni periodo de recuperación, y no recomienda aprobar ni rechazar.

Siguiente paso ofrecido: pasar los tres supuestos a assumption-tracking, y `/product-charter` solo si el caso se aprueba.
