**No publiqué la ficha de PRD-303 (Tarjeta débito).**

La configuración (`.criterio/producto/PRD-303/config.json`) no tiene configurada una carpeta de productos publicados. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé una ruta ni creé ninguna carpeta; no escribí ningún archivo de ficha.

Los términos de la versión 0.3.9 ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo.

**Lo que habría llevado la ficha (recalculado al 2026-10-15):**
- 16 requerimientos (11 aceptados, 5 propuestos) · 0 proyectos (ninguno está vinculado a un proyecto) · 1 métrica afirmada
- Segmento declarado: Pensionados
- Métrica: volumen_mensual, declarado 250670 en `documentos/productos/PRD-303/00-definicion/2026-04-05-caso-de-negocio.md` (2026-04-05)

**Para poder publicar:** definir en la configuración la carpeta común de productos publicados (por ejemplo `productos/publicados/`) y volver a correr el comando.
