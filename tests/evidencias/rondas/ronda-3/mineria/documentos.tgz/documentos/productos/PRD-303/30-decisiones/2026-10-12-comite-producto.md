# Comité de producto · Gemelo digital

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4301 | Requerimiento REQ-4301 | Sandra Gil | — | Cliente entrevistado | propuesto | 2026-03-31 | — |
| REQ-4302 | Requerimiento REQ-4302 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-18 | — |
| REQ-4303 | Requerimiento REQ-4303 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4304 | Requerimiento REQ-4304 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-15 | — |
| REQ-4305 | Requerimiento REQ-4305 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-08-14 | — |
| REQ-4306 | Requerimiento REQ-4306 | Diana Molina | se verifica en producción | — | aceptado | 2026-05-17 | — |
| REQ-4307 | Requerimiento REQ-4307 | Liliana Torres | se verifica en producción | — | aceptado | 2026-08-27 | — |
| REQ-4308 | Requerimiento REQ-4308 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-04-12 | — |
| REQ-4309 | Requerimiento REQ-4309 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-29 | — |
| REQ-4310 | Requerimiento REQ-4310 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4311 | Requerimiento REQ-4311 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-06-13 | — |
| REQ-4312 | Requerimiento REQ-4312 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4313 | Requerimiento REQ-4313 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4314 | Requerimiento REQ-4314 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-01 | — |
| REQ-4315 | Requerimiento REQ-4315 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-17 | — |
| REQ-2030 | Requerimiento REQ-2030 | Diana Molina | — | — | aceptado | 2026-09-30 | — |
| REQ-2038 | Requerimiento REQ-2038 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-25 | — |

## Decisiones

- Se mantiene el plan
