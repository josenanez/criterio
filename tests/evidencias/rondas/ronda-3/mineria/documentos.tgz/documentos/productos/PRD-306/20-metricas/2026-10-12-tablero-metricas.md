# Tablero de métricas · Almacén de repuestos

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 153.324 | 2026-10-12 |
