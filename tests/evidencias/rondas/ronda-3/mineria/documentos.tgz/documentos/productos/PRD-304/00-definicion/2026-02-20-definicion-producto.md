# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Diana Molina
**Segmento:** Operadores
**Fecha de la definición:** 2026-02-20

## El problema

El segmento Operadores no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-09-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
