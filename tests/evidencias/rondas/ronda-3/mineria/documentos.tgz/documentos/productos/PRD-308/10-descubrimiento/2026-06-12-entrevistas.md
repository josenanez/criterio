# Entrevistas · Permisos de trabajo digitales

**Ronda:** Ronda · 2026-06-12
**Realizadas por:** Gustavo Neira

### Cliente entrevistado · 2026-06-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
