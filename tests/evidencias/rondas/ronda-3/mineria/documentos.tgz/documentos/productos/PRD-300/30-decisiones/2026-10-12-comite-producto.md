# Comité de producto · Monitoreo de flota

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Liliana Torres | se verifica en producción | — | propuesto | 2026-07-29 | — |
| REQ-4001 | Requerimiento REQ-4001 | Felipe Arango | se verifica en producción | — | propuesto | 2026-08-28 | — |
| REQ-4002 | Requerimiento REQ-4002 | Diana Molina | — | — | propuesto | 2026-07-06 | — |
| REQ-4003 | Requerimiento REQ-4003 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4004 | Requerimiento REQ-4004 | Felipe Arango | se verifica en producción | — | aceptado | 2026-08-28 | — |
| REQ-4005 | Requerimiento REQ-4005 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-04-30 | — |
| REQ-4006 | Requerimiento REQ-4006 | Paula Céspedes | se verifica en producción | — | propuesto | 2026-04-04 | — |
| REQ-4007 | Requerimiento REQ-4007 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4008 | Requerimiento REQ-4008 | Laura Vélez | — | Cliente entrevistado | propuesto | 2026-07-22 | — |
| REQ-4009 | Requerimiento REQ-4009 | Jorge Medina | — | — | propuesto | 2026-07-28 | — |
| REQ-4010 | Requerimiento REQ-4010 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-08-09 | — |
| REQ-4011 | Requerimiento REQ-4011 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-04-25 | — |
| REQ-2026 | Requerimiento REQ-2026 | Paula Céspedes | — | — | aceptado | 2026-09-18 | — |
| REQ-2034 | Requerimiento REQ-2034 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-03 | — |

## Decisiones

- Se mantiene el plan
