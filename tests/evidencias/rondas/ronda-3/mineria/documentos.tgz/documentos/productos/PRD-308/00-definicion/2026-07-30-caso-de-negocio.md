# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-07-30
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 247.630 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
