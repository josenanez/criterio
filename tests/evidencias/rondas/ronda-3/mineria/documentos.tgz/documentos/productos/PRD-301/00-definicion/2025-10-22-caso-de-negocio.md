# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2025-10-22
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 89.970 | Caso de negocio, 2025-10-22 |

## Retorno esperado

Retorno esperado en 24 meses.
