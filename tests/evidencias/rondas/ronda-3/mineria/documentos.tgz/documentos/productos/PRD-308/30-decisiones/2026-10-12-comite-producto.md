# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-02 | — |
| REQ-4801 | Requerimiento REQ-4801 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-03 | — |
| REQ-4802 | Requerimiento REQ-4802 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-22 | — |
| REQ-4803 | Requerimiento REQ-4803 | Elena Duarte | — | — | aceptado | 2026-04-25 | — |
| REQ-4804 | Requerimiento REQ-4804 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4805 | Requerimiento REQ-4805 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4806 | Requerimiento REQ-4806 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4807 | Requerimiento REQ-4807 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4808 | Requerimiento REQ-4808 | Laura Vélez | — | — | aceptado | 2026-06-29 | — |
| REQ-4809 | Requerimiento REQ-4809 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-08-06 | — |
| REQ-4810 | Requerimiento REQ-4810 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-04-05 | — |
| REQ-4811 | Requerimiento REQ-4811 | Camilo Beltrán | — | Cliente entrevistado | propuesto | 2026-04-23 | — |
| REQ-2026 | Requerimiento REQ-2026 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-10-02 | — |

## Decisiones

- Se mantiene el plan
