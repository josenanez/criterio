# Tablero de métricas · Alerta de fatiga

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 80.541 | 2026-09-30 |
