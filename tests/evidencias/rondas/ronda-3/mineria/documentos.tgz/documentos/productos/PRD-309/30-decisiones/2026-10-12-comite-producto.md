# Comité de producto · Inspección con drones

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-28 | — |
| REQ-4901 | Requerimiento REQ-4901 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-14 | — |
| REQ-4902 | Requerimiento REQ-4902 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4903 | Requerimiento REQ-4903 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-07-31 | — |
| REQ-4904 | Requerimiento REQ-4904 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4905 | Requerimiento REQ-4905 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-08 | — |
| REQ-4906 | Requerimiento REQ-4906 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-05-15 | — |
| REQ-4907 | Requerimiento REQ-4907 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-08-10 | — |
| REQ-4908 | Requerimiento REQ-4908 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-27 | — |
| REQ-4909 | Requerimiento REQ-4909 | Gustavo Neira | se verifica en producción | — | propuesto | 2026-03-28 | — |
| REQ-4910 | Requerimiento REQ-4910 | Jorge Medina | se verifica en producción | — | aceptado | 2026-05-24 | — |
| REQ-4911 | Requerimiento REQ-4911 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-04 | — |

## Decisiones

- Se mantiene el plan
