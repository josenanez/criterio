# Tablero de métricas · Gemelo digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 43.055 | 2026-10-01 |
