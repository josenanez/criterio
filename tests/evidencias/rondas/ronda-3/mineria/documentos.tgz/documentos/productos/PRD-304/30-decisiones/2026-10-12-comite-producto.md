# Comité de producto · Trazabilidad

**Fecha:** 2026-10-12
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-03-23 | — |
| REQ-4401 | Requerimiento REQ-4401 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4402 | Requerimiento REQ-4402 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-07-03 | — |
| REQ-4403 | Requerimiento REQ-4403 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4404 | Requerimiento REQ-4404 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-21 | — |
| REQ-4405 | Requerimiento REQ-4405 | Javier Hoyos | — | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4406 | Requerimiento REQ-4406 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4407 | Requerimiento REQ-4407 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-04-02 | — |
| REQ-4408 | Requerimiento REQ-4408 | Elena Duarte | — | — | propuesto | 2026-08-25 | — |
| REQ-4409 | Requerimiento REQ-4409 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-15 | — |
| REQ-4410 | Requerimiento REQ-4410 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-15 | — |
| REQ-4411 | Requerimiento REQ-4411 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-31 | — |
| REQ-4412 | Requerimiento REQ-4412 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-07-22 | — |
| REQ-4413 | Requerimiento REQ-4413 | María Restrepo | se verifica en producción | — | aceptado | 2026-04-26 | — |
| REQ-2028 | Requerimiento REQ-2028 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-21 | — |

## Decisiones

- Se mantiene el plan
