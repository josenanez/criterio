# Definición de producto · Alerta de fatiga

**Código:** PRD-305
**Gerente de producto:** Elena Duarte
**Segmento:** Supervisores
**Fecha de la definición:** 2026-04-15

## El problema

El segmento Supervisores no tiene alerta de fatiga.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-08-21 · verificado

## Proyectos que lo construyen

- Ninguno declarado
