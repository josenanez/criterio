# Definición de producto · Alerta de taludes

**Código:** PRD-301
**Gerente de producto:** Felipe Arango
**Segmento:** Mantenimiento
**Fecha de la definición:** 2025-10-22

## El problema

El segmento Mantenimiento no tiene alerta de taludes.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-09-18 · verificado

## Proyectos que lo construyen

- Ninguno declarado
