# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-07-14
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 152.740 | Caso de negocio, 2026-07-14 |

## Retorno esperado

Retorno esperado en 24 meses.
