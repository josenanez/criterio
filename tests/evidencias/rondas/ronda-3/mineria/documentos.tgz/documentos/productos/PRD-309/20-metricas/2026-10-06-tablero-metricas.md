# Tablero de métricas · Inspección con drones

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 71.858 | 2026-10-06 |
