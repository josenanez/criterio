# Tablero de métricas · Trazabilidad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 79.065 | 2026-10-13 |
