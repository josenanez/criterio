# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Laura Vélez
**Segmento:** Comunidad
**Fecha de la definición:** 2025-09-05

## El problema

El segmento Comunidad no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-13 · verificado

## Proyectos que lo construyen

- Ninguno declarado
