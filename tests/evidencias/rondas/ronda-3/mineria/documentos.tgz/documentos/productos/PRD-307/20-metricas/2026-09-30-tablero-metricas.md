# Tablero de métricas · Reporte ambiental

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 115.407 | 2026-09-30 |
