# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Óscar Ramírez
**Segmento:** Comunidad
**Fecha de la definición:** 2026-08-02

## El problema

El segmento Comunidad no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-08-12 · verificado

## Proyectos que lo construyen

- Ninguno declarado
