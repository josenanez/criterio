# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-08-02
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 210.085 | Caso de negocio, 2026-08-02 |

## Retorno esperado

Retorno esperado en 24 meses.
