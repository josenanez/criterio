# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2026-01-13
**Realizadas por:** Rubén Cárdenas

### Cliente entrevistado · 2026-01-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
