# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** Ricardo Salas

## Estado declarado

**Verde**

Avance reportado: **65%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se reprogramó la parada de planta por la ventana de mantenimiento
- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.880.681.481 |
| Ejecutado | 2.237.756.617 |
| Proyección al cierre | 9.753.697.626 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
