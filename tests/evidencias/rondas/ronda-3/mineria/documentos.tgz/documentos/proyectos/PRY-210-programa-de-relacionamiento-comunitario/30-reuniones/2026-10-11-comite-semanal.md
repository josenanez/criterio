# Comité de Inversiones · Programa de relacionamiento comunitario

**Fecha:** 2026-10-11
**Asistentes:** Beatriz Cuéllar, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 28 | 2026-11-08 |
