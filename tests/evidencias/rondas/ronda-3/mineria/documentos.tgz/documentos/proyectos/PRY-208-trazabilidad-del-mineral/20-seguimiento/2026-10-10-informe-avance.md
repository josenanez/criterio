# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-10
**Gerente:** Natalia Ospina

## Estado declarado

**Rojo**

Avance reportado: **82%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.227.655.548 |
| Ejecutado | 1.982.333.435 |
| Proyección al cierre | 9.182.105.906 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
