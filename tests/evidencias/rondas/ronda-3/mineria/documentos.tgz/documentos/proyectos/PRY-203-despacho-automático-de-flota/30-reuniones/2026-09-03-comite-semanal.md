# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-09-03
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-09-10 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-21 |
| Elena Duarte | Revisar el anexo 3 | 2026-09-30 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-09-09 |
