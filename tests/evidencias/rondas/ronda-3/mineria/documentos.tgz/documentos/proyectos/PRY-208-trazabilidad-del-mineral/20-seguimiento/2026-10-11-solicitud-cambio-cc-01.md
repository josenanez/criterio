# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-11
**Solicitante:** Natalia Ospina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +60 días sobre la línea base vigente |
| Costo | 120.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
