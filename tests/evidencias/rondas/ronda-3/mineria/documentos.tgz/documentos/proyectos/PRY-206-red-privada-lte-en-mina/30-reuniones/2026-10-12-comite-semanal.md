# Comité de Inversiones · Red privada LTE en mina

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 37 | 2026-09-20 |
| Rubén Cárdenas | Entregar el punto 11 | 2026-11-01 |
