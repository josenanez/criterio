# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-14
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **42%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 5.730.913.292 |
| Ejecutado | 4.165.462.454 |
| Proyección al cierre | 9.776.375.957 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
