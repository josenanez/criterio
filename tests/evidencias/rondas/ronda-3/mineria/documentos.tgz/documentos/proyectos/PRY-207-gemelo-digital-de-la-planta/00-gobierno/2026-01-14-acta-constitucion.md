# Acta de constitución · Gemelo digital de la planta

**Código:** PRY-207
**Área dueña:** Seguridad y Salud
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Seguridad
**Producto asociado:** gemelo digital
**Fecha de aprobación:** 2026-01-14

## Objetivo del negocio

Entregar gemelo digital de la planta para Seguridad y Salud.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Seguridad el 2026-01-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-24 |
| Cierre | 2027-04-21 |

## Criterio de éxito

Gemelo digital de la planta en producción y medido.

## Dependencias declaradas

- Ninguna declarada
