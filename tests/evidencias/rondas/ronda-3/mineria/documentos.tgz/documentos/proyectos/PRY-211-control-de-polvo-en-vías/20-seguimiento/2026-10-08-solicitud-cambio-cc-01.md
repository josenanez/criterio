# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Control de polvo en vías
**Fecha:** 2026-10-08
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +54 días sobre la línea base vigente |
| Costo | 108.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
