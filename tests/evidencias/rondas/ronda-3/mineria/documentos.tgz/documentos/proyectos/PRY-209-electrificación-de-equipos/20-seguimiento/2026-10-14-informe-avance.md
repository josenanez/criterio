# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **52%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 387.174.080 |
| Ejecutado | 165.491.322 |
| Proyección al cierre | 760.039.075 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
