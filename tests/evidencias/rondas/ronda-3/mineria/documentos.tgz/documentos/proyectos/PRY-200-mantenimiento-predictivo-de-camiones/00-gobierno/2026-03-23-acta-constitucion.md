# Acta de constitución · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Área dueña:** Planta de procesamiento
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Operaciones
**Producto asociado:** monitoreo de flota
**Fecha de aprobación:** 2026-03-23

## Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Planta de procesamiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Operaciones el 2026-03-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-02 |
| Cierre | 2027-03-24 |

## Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

## Dependencias declaradas

- Ninguna declarada
