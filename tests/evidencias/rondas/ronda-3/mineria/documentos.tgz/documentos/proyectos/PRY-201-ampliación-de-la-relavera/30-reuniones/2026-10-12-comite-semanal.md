# Comité de Tecnología · Ampliación de la relavera

**Fecha:** 2026-10-12
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 19 | 2026-10-05 |
