# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-13
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **91%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.883.707.435 |
| Ejecutado | 1.954.681.222 |
| Proyección al cierre | 9.830.484.869 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- El proveedor no ha confirmado la fecha de la última entrega
