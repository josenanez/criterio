# Acta de constitución · Trazabilidad del mineral

**Código:** PRY-208
**Área dueña:** Tecnología
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Tecnología
**Producto asociado:** trazabilidad
**Fecha de aprobación:** 2026-02-12

## Objetivo del negocio

Entregar trazabilidad del mineral para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-22 |
| Cierre | 2027-05-21 |

## Criterio de éxito

Trazabilidad del mineral en producción y medido.

## Dependencias declaradas

- Ninguna declarada
