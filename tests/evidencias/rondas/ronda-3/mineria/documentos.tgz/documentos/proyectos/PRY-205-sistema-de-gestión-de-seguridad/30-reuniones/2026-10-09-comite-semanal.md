# Comité de Operaciones · Sistema de gestión de seguridad

**Fecha:** 2026-10-09
**Asistentes:** Natalia Ospina, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 39 | 2026-11-09 |
| Laura Vélez | Entregar el punto 16 | 2026-10-03 |
