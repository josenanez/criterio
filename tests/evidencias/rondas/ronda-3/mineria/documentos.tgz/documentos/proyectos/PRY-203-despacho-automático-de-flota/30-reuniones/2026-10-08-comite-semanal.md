# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-10-08
**Asistentes:** Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-11-10 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-13 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-11 |
| Javier Hoyos | Entregar el punto 8 | 2026-10-26 |
| Sandra Gil | Enviar el documento 9 | 2026-10-28 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-15 |
| Elena Duarte | Entregar el punto 16 | por definir |
| Diana Molina | Enviar el documento 17 | 2026-11-08 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-31 |
| Diana Molina | Revisar el anexo 19 | 2026-10-29 |
| Óscar Ramírez | Validar el ambiente 20 | por definir |
| María Restrepo | Aprobar el diseño 21 | 2026-10-27 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-25 |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-22 |
| Felipe Arango | Entregar el punto 24 | 2026-11-01 |

## Cerrados en esta reunión

- Actualizar la matriz 14 (Natalia Ospina): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- Javier Hoyos dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- Camilo Beltrán dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Diana Molina dice que ya entregó «confirmar la fecha 15». No se presentó acta.
