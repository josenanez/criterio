# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-10-03
**Asistentes:** Ricardo Salas, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 36 | 2026-10-23 |
