# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-09-24
**Asistentes:** Andrés Lozano, Camilo Beltrán, Diana Molina, Elena Duarte, Javier Hoyos, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-20 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-26 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-21 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-11 |
| Javier Hoyos | Entregar el punto 8 | 2026-10-11 |
| Sandra Gil | Enviar el documento 9 | 2026-10-13 |
| Camilo Beltrán | Cerrar la prueba 10 | por definir |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-15 |
| Andrés Lozano | Aprobar el diseño 13 | 2026-10-04 |
| Natalia Ospina | Actualizar la matriz 14 | por definir |
| Diana Molina | Confirmar la fecha 15 | por definir |
| Elena Duarte | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Javier Hoyos): recibido, acta de recibo del 2026-09-24.
- Revisar el anexo 11 (Beatriz Cuéllar): recibido, acta de recibo del 2026-09-24.
