# Comité de Inversiones · Cambio de luminarias del campamento

**Fecha:** 2026-10-11
**Asistentes:** Andrés Lozano, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Presentar el cierre de la fase | 2026-11-04 |
