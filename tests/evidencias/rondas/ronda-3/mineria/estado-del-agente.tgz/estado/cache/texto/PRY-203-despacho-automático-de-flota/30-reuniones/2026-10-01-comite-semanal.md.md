<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-10-01
**Asistentes:** Camilo Beltrán, Diana Molina, Elena Duarte, Javier Hoyos, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-31 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-03 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-21 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-11 |
| Javier Hoyos | Entregar el punto 8 | 2026-10-26 |
| Sandra Gil | Enviar el documento 9 | 2026-10-28 |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-20 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-15 |
| Natalia Ospina | Actualizar la matriz 14 | 2026-10-12 |
| Diana Molina | Confirmar la fecha 15 | por definir |
| Elena Duarte | Entregar el punto 16 | por definir |
| Diana Molina | Enviar el documento 17 | 2026-10-20 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-16 |
| Diana Molina | Revisar el anexo 19 | 2026-10-29 |
| Óscar Ramírez | Validar el ambiente 20 | por definir |

## Lo que se dijo

- Andrés Lozano dice que ya entregó «aprobar el diseño 13». No se presentó acta.
