<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Beatriz Cuéllar

Estado declarado
Rojo
Avance reportado: 41%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave
- Las lluvias detuvieron el montaje durante diez días
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.157.830.101
Ejecutado 8.186.566.284
Proyección al cierre 17.723.816.413

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
