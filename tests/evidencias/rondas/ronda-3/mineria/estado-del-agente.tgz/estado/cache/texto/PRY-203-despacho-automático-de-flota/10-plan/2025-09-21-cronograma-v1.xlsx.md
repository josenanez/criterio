<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2025-09-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-01-01 | 2026-01-01 | cerrado
Ingeniería de detalle aprobada | 2026-04-03 | 2026-04-03 | cerrado
Licencia y permisos obtenidos | 2026-07-05 | 2026-07-05 | cerrado
Montaje e instalación | 2026-10-05 | 2026-10-05 | en curso
Pruebas en operación | 2027-01-05 | 2027-01-05 | en curso
