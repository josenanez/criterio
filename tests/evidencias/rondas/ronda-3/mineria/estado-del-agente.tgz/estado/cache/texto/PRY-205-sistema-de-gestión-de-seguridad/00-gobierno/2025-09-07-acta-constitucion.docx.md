<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/2025-09-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de seguridad

Código: PRY-205

Área dueña: Medio Ambiente

Patrocinador: Óscar Ramírez

Gerente de proyecto: Natalia Ospina

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2025-09-07

Objetivo del negocio

Entregar sistema de gestión de seguridad para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Operaciones el 2025-09-07.

Fechas comprometidas

Fecha

Inicio

2025-09-17

Cierre

2027-04-23

Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

Dependencias declaradas

• Ninguna declarada
