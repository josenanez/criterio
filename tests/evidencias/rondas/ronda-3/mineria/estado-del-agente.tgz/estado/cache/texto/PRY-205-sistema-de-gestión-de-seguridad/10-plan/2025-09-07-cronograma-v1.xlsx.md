<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-09-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-03-02 | 2026-03-02 | cerrado
Ingeniería de detalle aprobada | 2026-08-16 | 2026-08-16 | cerrado
Licencia y permisos obtenidos | 2027-01-29 | 2027-01-29 | en curso
