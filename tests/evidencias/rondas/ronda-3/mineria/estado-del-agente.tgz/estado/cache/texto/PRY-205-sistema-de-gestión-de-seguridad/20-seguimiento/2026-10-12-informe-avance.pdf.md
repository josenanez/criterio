<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Sistema de gestión de seguridad
Código: PRY-205
Fecha de corte: 2026-10-12
Gerente: Natalia Ospina

Estado declarado
Verde
Avance reportado: 41%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 800.000.000
Comprometido 482.968.533
Ejecutado 447.470.626
Proyección al cierre 805.034.683

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio en la licencia ambiental que puede mover el alcance
