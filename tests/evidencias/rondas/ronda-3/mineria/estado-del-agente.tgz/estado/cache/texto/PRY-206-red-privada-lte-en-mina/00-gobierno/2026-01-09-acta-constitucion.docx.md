<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2026-01-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Mina

Patrocinador: Elena Duarte

Gerente de proyecto: Laura Vélez

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2026-01-09

Objetivo del negocio

Entregar red privada lte en mina para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Inversiones el 2026-01-09.

Fechas comprometidas

Fecha

Inicio

2026-01-19

Cierre

2027-04-05

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
