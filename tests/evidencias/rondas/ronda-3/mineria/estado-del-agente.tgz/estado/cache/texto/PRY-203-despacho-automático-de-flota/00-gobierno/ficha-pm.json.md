<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-203",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "name": {
 "value": "Despacho automático de flota",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "business_area": {
 "value": "Medio Ambiente",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "product": {
 "value": "despacho de flota",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "sponsor": {
 "value": "María Restrepo",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "manager": {
 "value": "Camilo Beltrán",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Inversiones",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "plan": {
 "start_date": {
 "value": "2025-10-01",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "end_date": {
 "value": "2027-02-21",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 },
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2025-09-21-acta-constitucion.md",
 "source_date": "2025-09-21",
 "state": "found"
 }
 },
 "raid": {
 "risks": [
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "probability": "no_declarada",
 "impact": "no_declarado",
 "owner": "no_identificado",
 "due_date": "no_declarada",
 "last_moved": "2026-10-15",
 "registered": false,
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "quote": "se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo",
 "note": "Relacionado, no igual: el informe de avance del 2026-10-13 registra «El proveedor no ha confirmado la fecha de la última entrega»; el equipo incompleto no está escrito en ninguna parte."
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "commitments": [
 {
 "who": "Óscar Ramírez",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-24",
 "original_due_date": "2026-09-10",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-26",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "quote": "Óscar Ramírez dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 24/11/2026"
 }
 ],
 "note": "Historial completo leído en los comités del 2026-09-03 al 2026-10-08 y las notas del 2026-10-15."
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "due_text": "la otra semana",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "quote": "Laura Vélez queda de mandar el ajuste del presupuesto la otra semana"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "quote": "Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25"
 }
 ],
 "meta": {
 "record_updated": "2026-10-15",
 "sealed": false,
 "scope": "Lectura parcial: notas del 2026-10-15, comités del 2026-09-03 al 2026-10-08, acta de constitución, contrato CT-683 e informe de avance del 2026-10-13. Cronograma y actas de recibo sin abrir.",
 "fields_not_found": [
 "identity.authority"
 ],
 "open_conflicts": []
 }
}
