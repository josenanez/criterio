<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Ampliación de la relavera

**Fecha:** 2026-10-12
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 19 | 2026-10-05 |
