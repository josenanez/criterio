<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-05-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-07-10 | 2026-07-10 | cerrado
Ingeniería de detalle aprobada | 2026-08-26 | 2026-08-26 | cerrado
Licencia y permisos obtenidos | 2026-10-11 | 2026-10-11 | en curso
Montaje e instalación | 2026-11-27 | 2026-11-27 | en curso
Pruebas en operación | 2027-01-12 | 2027-01-12 | en curso
