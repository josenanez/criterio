<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/2025-09-21-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Medio Ambiente
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Inversiones
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-09-21

## Objetivo del negocio

Entregar despacho automático de flota para Medio Ambiente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Inversiones el 2025-09-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-01 |
| Cierre | 2027-02-21 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
