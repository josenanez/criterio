<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2026-04-05-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-10-02,2026-10-02,en curso
Ingeniería de detalle aprobada,2027-03-22,2027-03-22,en curso
Licencia y permisos obtenidos,2027-09-08,2027-09-08,en curso
