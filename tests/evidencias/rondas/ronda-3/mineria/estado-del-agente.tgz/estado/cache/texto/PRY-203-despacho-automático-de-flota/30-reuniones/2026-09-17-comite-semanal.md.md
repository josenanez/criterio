<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-09-17
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Javier Hoyos, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-07 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-11 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-03 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-03 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-09-20 |
| Javier Hoyos | Entregar el punto 8 | 2026-09-26 |
| Sandra Gil | Enviar el documento 9 | 2026-10-13 |
| Camilo Beltrán | Cerrar la prueba 10 | por definir |
| Beatriz Cuéllar | Revisar el anexo 11 | 2026-10-13 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-15 |

## Lo que se dijo

- Elena Duarte dice que ya entregó «revisar el anexo 3». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «validar el ambiente 4». No se presentó acta.
