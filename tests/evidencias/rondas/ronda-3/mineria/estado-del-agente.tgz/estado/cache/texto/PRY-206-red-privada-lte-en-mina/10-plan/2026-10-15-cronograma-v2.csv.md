<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2026-10-15-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-04-27,2026-04-27,cerrado
Ingeniería de detalle aprobada,2026-08-03,2026-08-03,cerrado
Licencia y permisos obtenidos,2026-11-09,2026-11-09,en curso
Montaje e instalación,2027-02-15,2027-04-03,en curso
