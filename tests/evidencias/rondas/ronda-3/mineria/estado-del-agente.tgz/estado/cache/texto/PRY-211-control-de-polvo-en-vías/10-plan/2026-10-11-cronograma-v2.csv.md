<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2026-10-11-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-03-05,2026-03-05,cerrado
Ingeniería de detalle aprobada,2026-05-01,2026-05-01,cerrado
Licencia y permisos obtenidos,2026-06-28,2026-06-28,cerrado
Montaje e instalación,2026-08-24,2026-08-24,cerrado
Pruebas en operación,2026-10-21,2026-12-14,en curso
