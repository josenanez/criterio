<!-- origen: PRY-202-planta-de-tratamiento-de-agua/00-gobierno/2026-04-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Planta de tratamiento de agua

Código: PRY-202

Área dueña: Medio Ambiente

Patrocinador: Sandra Gil

Gerente de proyecto: Elena Duarte

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2026-04-05

Objetivo del negocio

Entregar planta de tratamiento de agua para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Seguridad el 2026-04-05.

Fechas comprometidas

Fecha

Inicio

2026-04-15

Cierre

2027-12-03

Criterio de éxito

Planta de tratamiento de agua en producción y medido.

Dependencias declaradas

• Ninguna declarada
