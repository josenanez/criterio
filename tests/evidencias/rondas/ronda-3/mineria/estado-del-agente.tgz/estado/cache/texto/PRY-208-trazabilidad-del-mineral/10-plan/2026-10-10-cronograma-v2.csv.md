<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2026-10-10-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-06-02,2026-06-02,cerrado
Ingeniería de detalle aprobada,2026-09-11,2026-09-11,cerrado
Licencia y permisos obtenidos,2026-12-21,2026-12-21,en curso
Montaje e instalación,2027-03-31,2027-05-30,en curso
