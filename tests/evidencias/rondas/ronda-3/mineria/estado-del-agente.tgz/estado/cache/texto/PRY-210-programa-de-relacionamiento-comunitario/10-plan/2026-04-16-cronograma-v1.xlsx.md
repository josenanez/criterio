<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2026-04-16-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-10-12 | 2026-10-12 | en curso
Ingeniería de detalle aprobada | 2027-03-31 | 2027-03-31 | en curso
Licencia y permisos obtenidos | 2027-09-17 | 2027-09-17 | en curso
