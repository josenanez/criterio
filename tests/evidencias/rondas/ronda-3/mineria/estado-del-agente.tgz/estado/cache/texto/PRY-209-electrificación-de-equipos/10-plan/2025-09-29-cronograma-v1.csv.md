<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2025-09-29-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-12-18,2025-12-18,cerrado
Ingeniería de detalle aprobada,2026-02-26,2026-02-26,cerrado
Licencia y permisos obtenidos,2026-05-07,2026-05-07,cerrado
