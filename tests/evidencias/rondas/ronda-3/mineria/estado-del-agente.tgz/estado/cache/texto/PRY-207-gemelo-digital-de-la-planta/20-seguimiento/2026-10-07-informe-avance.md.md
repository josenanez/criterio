<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-10-07-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-07
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Amarillo**

Avance reportado: **57%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 443.879.930 |
| Ejecutado | 380.446.339 |
| Proyección al cierre | 749.545.832 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
