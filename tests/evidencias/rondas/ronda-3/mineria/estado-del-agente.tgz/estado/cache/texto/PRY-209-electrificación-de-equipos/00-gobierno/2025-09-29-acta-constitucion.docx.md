<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2025-09-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Electrificación de equipos

Código: PRY-209

Área dueña: Mantenimiento

Patrocinador: Camilo Beltrán

Gerente de proyecto: Sandra Gil

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2025-09-29

Objetivo del negocio

Entregar electrificación de equipos para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Seguridad el 2025-09-29.

Fechas comprometidas

Fecha

Inicio

2025-10-09

Cierre

2026-06-11

Criterio de éxito

Electrificación de equipos en producción y medido.

Dependencias declaradas

• Ninguna declarada
