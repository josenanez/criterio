<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2025-12-04-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Tecnología

Patrocinador: Carlos Peña

Gerente de proyecto: Andrés Lozano

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2025-12-04

Objetivo del negocio

Entregar ampliación de la relavera para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Tecnología el 2025-12-04.

Fechas comprometidas

Fecha

Inicio

2025-12-14

Cierre

2027-03-16

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
