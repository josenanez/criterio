<!-- origen: PRY-206-red-privada-lte-en-mina/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Red privada LTE en mina

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 37 | 2026-09-20 |
| Rubén Cárdenas | Entregar el punto 11 | 2026-11-01 |
