<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Monitoreo de taludes
Código: PRY-204
Fecha de corte: 2026-09-27
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 27%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 403.511.534
Ejecutado 577.323.500
Proyección al cierre 1.183.123.627

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
