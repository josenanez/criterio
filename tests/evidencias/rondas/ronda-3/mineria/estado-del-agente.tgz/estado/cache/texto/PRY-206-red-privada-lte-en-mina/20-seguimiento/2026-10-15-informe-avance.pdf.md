<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 87%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 5.748.835.541
Ejecutado 3.185.563.569
Proyección al cierre 8.889.903.090

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
