<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **57%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.362.087.354 |
| Ejecutado | 1.097.802.366 |
| Proyección al cierre | 3.863.518.362 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- El proveedor no ha confirmado la fecha de la última entrega
