<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-202
**Fecha de corte:** 2026-10-10
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **77%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.151.268.083 |
| Ejecutado | 2.129.378.183 |
| Proyección al cierre | 4.075.616.439 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
