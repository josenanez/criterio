<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/2026-05-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Monitoreo de taludes

Código: PRY-204

Área dueña: Medio Ambiente

Patrocinador: Natalia Ospina

Gerente de proyecto: Ricardo Salas

Comité: Comité de Tecnología

Producto asociado: alerta de taludes

Fecha de aprobación: 2026-05-15

Objetivo del negocio

Entregar monitoreo de taludes para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Tecnología el 2026-05-15.

Fechas comprometidas

Fecha

Inicio

2026-05-25

Cierre

2027-02-05

Criterio de éxito

Monitoreo de taludes en producción y medido.

Dependencias declaradas

• Ninguna declarada
