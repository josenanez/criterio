<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Programa de relacionamiento comunitario

**Fecha:** 2026-10-11
**Asistentes:** Beatriz Cuéllar, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 28 | 2026-11-08 |
