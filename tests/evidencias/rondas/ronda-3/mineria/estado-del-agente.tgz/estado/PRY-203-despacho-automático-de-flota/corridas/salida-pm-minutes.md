# Acta — Despacho automático de flota (PRY-203) · 2026-10-15
**Asistieron:** Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en las notas; no puedo decirlo. (Beatriz Cuéllar, Natalia Ospina y Andrés Lozano estuvieron en comités anteriores y hoy no figuran.)

Términos: ya estaban vigentes (aceptados por José Francisco Ñáñez, 2026-10-15, versión 0.3.9); no hubo que pedirlos de nuevo.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-11-24 | **Reprogramado 6 veces.** Promesa original 2026-09-10 (comité 09-03); luego 09-26, 10-07, 10-20, 10-31, 11-10 y ahora 11-24. «Óscar Ramírez dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 24/11/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo. Ojo: el 25 de octubre es domingo. «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25» |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», que no es una fecha (¿del 19 al 23 de octubre o la siguiente?). Registrado con `due_date: no_declarada`. «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana» |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quien la tomó y lo que se descartó.

## Quedó sin decidir
Las notas no dicen qué quedó abierto. No lo invento.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase. «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | No consta: las notas dicen «se comentó» | Riesgo (sin probabilidad, impacto ni dueño: nadie los dijo) | **No.** Hay uno cercano pero distinto en el informe de avance del 2026-10-13: «El proveedor no ha confirmado la fecha de la última entrega». Aquel habla de una fecha; este, de que la entrega venga incompleta. |

## Cerrado en esta reunión
Nada. «Lo de enviar el documento 1 no alcanzó» no cierra nada: es lo contrario.

## Lo que esta reunión contradice
Ningún campo de la ficha cambió: patrocinador, gerente, comité y fecha de cierre no se tocaron. Dos observaciones sin conflicto probado:
- «Próxima reunión en dos semanas» (2026-10-29) frente a un comité que la configuración y los comités leídos muestran **semanal**. Si el ritmo pasó a quincenal, la configuración está desactualizada; las notas no lo dicen.
- Laura Vélez va a mandar un «ajuste del presupuesto». El informe del 2026-10-13 proyecta 9.830.484.869 COP contra 9.500.000.000 aprobados; no se dice si el ajuste tiene que ver. No puedo afirmarlo.

## Sin resolver de la transcripción
- «no alcanzó»: no queda claro si el documento 1 no llegó a tiempo o si lo enviado no fue suficiente. Lo traté como reprogramación porque Óscar da una fecha nueva.
- «el equipo completo»: no queda claro si se habla de personas (la bolsa de horas de ingeniería del CT-683) o de equipos físicos.
- «la otra semana»: sin fecha (ver arriba).
- De los 14 compromisos abiertos tras el comité del 2026-10-08 las notas no dicen nada: no los doy por cumplidos ni por reprogramados. Entre ellos, «Actualizar la matriz 6» (Elena Duarte) venció el 2026-10-11 y «Validar el ambiente 12» (Mauricio Pérez) vence hoy.

## Lo que calculó el script
2 alertas: `commitment_rescheduled` (documento 1, 6 veces; el umbral es 3) y `commitment_undated` (Laura Vélez). Ninguno vencido hoy.

## Después
`/criterio-project:pm-commitments` para el seguimiento completo, con el documento 1 como primer caso. `/criterio-project:pm-publish` no hace falta por esta acta: no cambió ningún campo de la ficha.

El acta sale en la conversación y la guardas tú; no la escribí en tu carpeta de reuniones. Solo actualicé la ficha de estado (`records/PRY-203.json`, sin sellar) con el historial del documento 1 y la nota sobre el riesgo.
