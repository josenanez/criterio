## PRY-203 Despacho automático de flota · 2026-10-15

Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-15, v0.3.9); no hubo que registrarlos de nuevo.

**Revisé:** 19 documentos · 19 nuevos (primera lectura del barrido) · 7 minutas (6 comités del 09-03 al 10-08 y las notas de hoy).

### Lo que se venció solo
Hasta hoy la ficha solo tenía los 3 compromisos de las notas de hoy. Los comités traían 23 más sin leer; ahora están registrados, con su historial. Cruzaron:

**Vencidos sin evidencia (4):**
- Actualizar la matriz 6 (Elena Duarte): venció el 2026-10-11; el comité del 10-08 la repitió con la misma fecha. Sin acta de recibo.
- Revisar el anexo 3 (Elena Duarte): venció el 2026-09-30. El 09-17 se dijo «ya entregó, no se presentó acta» y desapareció de la lista.
- Validar el ambiente 4 (Beatriz Cuéllar): venció el 2026-09-09. Mismo caso: «ya entregó», sin acta, fuera de la lista desde el 09-17.
- Aprobar el diseño 13 (Andrés Lozano): venció el 2026-10-04. «Ya entregó» el 10-01, sin acta, fuera de la lista desde el 10-08.

**Reprogramados:** Enviar el documento 1 (Óscar Ramírez), 6 veces, hoy al 2026-11-24 (75 días después de la primera promesa). Cerrar la prueba 2 (Paula Céspedes), 5 veces, hoy al 2026-11-13.

**Sin fecha (4):** ajuste del presupuesto (Laura Vélez, «la otra semana»), Entregar el punto 16 (Elena Duarte), Validar el ambiente 20 (Óscar Ramírez), Confirmar la fecha 15 (Diana Molina; además se dijo «ya entregó» el 10-08, sin acta).

**Vigilar:** Validar el ambiente 12 (Mauricio Pérez) vence hoy; todavía no hay acta de recibo. Cerrar la prueba 18 (Ricardo Salas) vence el 10-16.

**Cerrados con acta:** Confirmar la fecha 7, Revisar el anexo 11 y Actualizar la matriz 14. «Ya entregó» sin acta no cierra nada, y que un compromiso salga de la lista tampoco.

Dos casos más (Aprobar el diseño 5, Cerrar la prueba 10) también salieron de la lista con «ya entregó» sin acta, pero su fecha (10-21 y 10-20) aún no llega.

Las notas de hoy no dicen nada de los compromisos abiertos de los comités anteriores; no los di por cumplidos ni por reprogramados.

### La reunión
La de hoy ya está en acta (`/pm-minutes`, corrida de hoy): no hay nada que ofrecer. El comité siguiente es el 2026-10-29 («dos semanas», según las notas). La configuración dice que el comité es semanal; si pasó a quincenal, está desactualizada. Las notas no lo dicen. `/pm-agenda` ya corrió hoy, así que no la vuelvo a proponer. El informe toca el 2026-10-28.

### Tu ficha publicada
No está vieja: se publicó hoy (corte 2026-10-15). Pero esa ficha lleva 2 señales y desde este barrido hay más (4 vencidos y 2 reprogramados más). Si quieres que la PMO las vea, `/pm-publish` es decisión tuya; no lo hago solo.

### Aparte (sin cambio de umbral, solo para tu atención)
- El informe del 2026-10-13 declara Rojo con 91 % de avance y 1.954.681.222 de 9.500.000.000 ejecutados (20,6 %), con proyección de 9.830.484.869 (3,5 % sobre lo aprobado). No verifico cuál de las dos cifras de avance es la correcta; el estado lo declaras tú.
- El riesgo «el proveedor podría no llegar con el equipo completo» sigue sin registrar (ver acta de hoy).
- El 25 de octubre (revisión con el proveedor, Óscar Ramírez) es domingo.

**Vuelvo el 2026-10-16.**

Para que corra sin nadie delante en Claude Code: programa la línea `claude -p "/criterio-project:pm-wake" --permission-mode acceptEdits` en el cron del sistema operativo, con la sesión autorizada a ejecutar los scripts del plugin sin aprobar cada paso y la carpeta del proyecto montada cuando dispare el reloj. Si la organización no quiere corridas desatendidas, también sirve a mano cada lunes en la mañana.
