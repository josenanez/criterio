Publiqué la ficha en `documentos/proyectos/PRY-203-despacho-automático-de-flota/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 11 campos con dato · 1 sin decir en ninguna parte (`identity.authority`) · **no declara estado**: la ficha no trae declaración tuya, así que `declared.status` y `declared.as_of` llegan vacíos a la PMO.

**Lo más viejo que va ahí:** los 11 campos con dato (`identity.*`, `plan.*`, `money.*`) vienen del acta de constitución del 2025-09-21, con 13 meses — pasa de un año.

Aparte, la ficha lleva dos señales abiertas: «Enviar el documento 1» (Óscar Ramírez) reprogramado 6 veces, y «Mandar el ajuste del presupuesto» (Laura Vélez) sin fecha.

Nota: los términos ya estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo. No se avisó a nadie: Vera la encontrará en su próximo barrido.
