# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 19 s · 2 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |
| `commitment_rescheduled` | 1 |

Óscar Ramírez: «enviar el documento 1» reprogramado 6 veces (original 2026-09-10, vigente 2026-11-24), sin documento de entrega; Laura Vélez sin fecha en el ajuste del presupuesto

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-203 Despacho automático de flota · al 2026-10-15

3 compromisos abiertos: 1 reprogramado 6 veces, 1 sin fecha, 1 con fecha lejana. Ninguno vencido. Ninguno cerrado: no hay documento de entrega para ninguno.

### Se viene reprogramando

> **Óscar Ramírez** · Enviar el documento 1
> Prometido el 2026-09-03 para el 2026-09-10. Después lo movió, en este orden, al 09-26 (comité del 09-10), 10-07 (09-17), 10-20 (09-24), 10-31 (10-01), 11-10 (10-08) y 11-24 (notas del 10-15). Son 6 reprogramaciones.
> Fuentes: `30-reuniones/2026-09-03` al `2026-10-08-comite-semanal.md` y `2026-10-15-notas-reunion.txt`.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.** La fecha vigente está 75 días después de la primera promesa. En el expediente no hay ningún documento que respalde que se haya entregado.

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno.

Próximo con fecha: Óscar Ramírez · Revisión con el proveedor · 2026-10-25 (en 10 días; cae en domingo). Dicho el 2026-10-15 en `2026-10-15-notas-reunion.txt`.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-15 |

«La otra semana» es una referencia relativa, no una fecha, así que no puede vencer.

### Cerrados desde la última revisión
Ninguno.

### Lo que hay que tener presente
- Las notas del 10-15 dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase y que nadie lo anotó como riesgo. La revisión con el proveedor (10-25) es el compromiso que toca ese tema. El riesgo no está en el registro.
