# Despacho automático de flota (PRY-203) — corte al 2026-10-15

*Prueba sin interfaz: nadie respondió la pregunta de la declaración. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no se registraron de nuevo.*

**Declara el gerente (Camilo Beltrán):** *sin declarar* · *sin avance declarado* · sin fecha
**Sustento documental:** no evaluable — sin declaración no hay nada que contrastar
**Lo que el semáforo no explica:** sin semáforo declarado, ninguna señal queda explicada. El cálculo marca `commitment_rescheduled` como señal sin cubrir.

> El estado no lo escribe Samuel ni se sugiere. Si Camilo declara, se contrasta contra las señales de abajo. Este informe sale con esa línea en blanco a propósito.

## Qué cambió esta semana
No hay comparación posible. Existe un solo snapshot (2026-10-15) y el `diff` no devolvió cambios, así que esta es la primera corrida de informe. No se inventa un "estaba".

Lo que entró con las notas del 2026-10-15, ficha todavía parcial:

| Qué | Estaba | Está |
|---|---|---|
| Óscar Ramírez — «Enviar el documento 1» | 2026-11-10 | **2026-11-24** (reprogramado por 6.ª vez) |
| Óscar Ramírez — «Revisión con el proveedor» | — | Nuevo, para 2026-10-25 |
| Laura Vélez — «Mandar el ajuste del presupuesto» | — | Nuevo, **sin fecha** («la otra semana») |
| Riesgo: el proveedor podría no llegar con el equipo completo | — | Nuevo, **no registrado**, sin dueño, probabilidad ni impacto |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| «Enviar el documento 1» (Óscar Ramírez) sigue sin entregarse | Prometido para 2026-09-10 | **35** días desde la fecha original |
| Línea base inexistente | Sin dato en la ficha | No medible |
| Autoridad del proyecto sin identificar | Sin dato en la ficha | No medible |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | Sin línea base registrada | 2027-02-21 (acta de constitución) | **No calculable** |
| Presupuesto | Sin línea base registrada | COP 9.500.000.000 (aprobado) | **No calculable** |

Replanificaciones: 0 registradas. Cero no significa que no hayan ocurrido: la ficha no tiene línea base y el cronograma no se abrió.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha. El cronograma no se abrió; no se inventa ninguno.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 9.500.000.000 | sin dato | sin dato | sin dato | **no calculable** (aprobado menos comprometido; falta el comprometido) |

## Abierto
**Reprogramados:** Óscar Ramírez, «Enviar el documento 1», **6 veces**. Original 2026-09-10; luego 09-26, 10-07, 10-20, 10-31, 11-10 y 11-24. Supera el umbral de 3 reprogramaciones.
**Vencidos sin evidencia:** ninguno vencido a la fecha.
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto», dicho el 2026-10-15 como «la otra semana».
**RAID sin movimiento:** ninguno. El único riesgo detectado se movió hoy, pero no está registrado en ningún RAID.
**Proveedor:** no hay entregables de proveedor cargados. Contrato CT-683 leído, actas de recibo sin abrir. El informe de avance del 2026-10-13 dice que el proveedor no ha confirmado la fecha de la última entrega.

## Lo que necesito de alguien
- **Camilo Beltrán:** declarar estado y avance. Es lo único que falta para cerrar este informe.
- **Camilo Beltrán / Óscar Ramírez:** decidir qué pasa con el documento 1 tras la sexta reprogramación. Puede ser un punto de comité.
- **Laura Vélez:** poner fecha al ajuste del presupuesto.
- **Camilo Beltrán:** registrar el riesgo del equipo incompleto del proveedor, con dueño, probabilidad e impacto.
- **Comité de Inversiones (fuera de la autoridad del gerente):** definir la autoridad del proyecto y fijar una línea base. Es material de comité, no de este informe.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto; línea base (original y vigente); presupuesto comprometido, ejecutado y proyectado; hitos y cronograma; entregables del proveedor y lo facturado.
**Datos viejos:** 11 campos de identidad, plan y dinero salen del acta del 2025-09-21, con 13 meses de antigüedad. Superan el umbral de 12 meses.
**Silencio:** último documento hace 2 días (informe de avance del 2026-10-13) · última reunión hace 0 días (2026-10-15). El cálculo no devolvió `days_silent`; las cifras salen de la ficha, no de un cómputo. Lectura parcial: no se abrió el cronograma ni las actas de recibo.

## Después
- La reprogramación 6 de 6 supera el umbral de 3: se puede armar el punto de comité con la decisión formulada (`/pm-escalate`).
- No hay declaración, así que no hay contradicción que publicar con `/pm-publish`.

---
**Pie:** ficha `estado/PRY-203-despacho-automático-de-flota/records/PRY-203.json`, actualizada el 2026-10-15 (lectura parcial, sin sellar) · 1 campo sin dato en la ficha (`identity.authority`), más los de plan y dinero sin extraer · términos 1.1: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
