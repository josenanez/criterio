# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 36 s · 2 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |
| `commitment_rescheduled` | 1 |

Paquete con una pregunta cerrada: declarar la autoridad del gerente (no está en el acta). La proyección de 330.484.869 COP (3,5 %) sobre lo aprobado queda condicionada a esa autoridad. No corrió impact: ninguna fecha se mueve. No supe el origen de la proyección, el contenido del ajuste de Laura Vélez ni la holgura por actividad.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-203 Despacho automático de flota · 2026-10-15

Términos: ya vigentes (José Francisco Ñáñez, 2026-10-15, versión 0.3.9); no hubo que pedirlos de nuevo.

No traías un tema concreto, así que tomé lo que ya estaba marcado como escalable en la corrida de agenda. Salen dos cosas, y la primera es la que importa: **el acta no declara la autoridad del gerente, y sin eso no se puede decir si la segunda escala.**

### ¿Se declara por escrito hasta cuánto puede decidir el gerente de PRY-203 sobre presupuesto (y sobre fechas), o toda desviación sobre lo aprobado entra al Comité de Inversiones como solicitud de cambio?

**Quién decide:** el Comité de Inversiones, que aprobó el acta y el presupuesto el 2025-09-21 (acta de constitución; la patrocinadora es María Restrepo). El acta no dice quién puede delegar autoridad: si la delegación la firma el Comité o basta la patrocinadora lo confirma el Comité, no yo.
**Si no se decide hoy:** no hay una fecha dura en los documentos y no la invento. Lo que sí hay: Laura Vélez entrega «el ajuste del presupuesto» «la otra semana» (notas del 10-15), y la reunión siguiente es el 2026-10-29 según la configuración. Ese ajuste llegará a una sala donde nadie sabe si el gerente puede aprobarlo. El punto se vuelve a aplazar y sigue pasando sin que nadie pueda decir quién debía decidir.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El Comité declara por escrito la autoridad del gerente (topes de gasto y de movimiento de fechas, que fija el Comité) y queda anexa al acta | Sin cambio de alcance del proyecto | Una decisión del Comité; no calculé días porque ninguna fecha del proyecto se mueve | Sin costo directo. El monto de la tolerancia lo fija el Comité; no propongo cifra |
| B. Toda proyección sobre lo aprobado entra al Comité como solicitud de cambio (control de cambios), sin tolerancia para el gerente | Sin cambio de alcance | Cada desviación espera comité; con comité semanal, hasta una semana | Hoy arrastra los 330.484.869 COP de la proyección (3,5 % sobre 9.500.000.000, informe del 10-13) |
| C. No declarar nada y seguir como hasta ahora | Sin cambio | Sin cambio | Sigue sin saberse si 330.484.869 COP exceden la autoridad; el riesgo es que se apruebe algo que no valía |

**Recomiendo:** A — porque resuelve esta desviación y las siguientes, y B solo la resuelve hoy; el Comité elige los topes porque son suyos. Si el Comité prefiere B para este caso, es una decisión válida mientras tanto.

### Segundo punto, condicionado al primero: la proyección supera lo aprobado

La proyección al cierre del informe del 10-13 es 9.830.484.869 COP contra 9.500.000.000 aprobados: **330.484.869 COP (3,5 %) por encima**. No puedo decir que esto *exceda la autoridad del gerente* porque esa autoridad no está declarada (`identity.authority`: no encontrada). Si tras la decisión de arriba el 3,5 % queda fuera de la autoridad, este es el escalamiento; si queda dentro, **no escala** y no armo paquete aparte. Dos datos que no tengo: de dónde sale la proyección (el informe solo da la cifra) y si el «ajuste del presupuesto» de Laura Vélez la corrige o la confirma; su fecha es «la otra semana».

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| No calculado | — | — | — |

No corrí `impact`: lo que se escala no mueve una fecha, y calcularlo con días inventados sería describir, no calcular. El acta declara «Ninguna» como dependencia; que no haya ninguna declarada no prueba que no exista. Si el Comité elige mover una fecha, se corre con los días reales.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| No aplica | — | — |

El cierre comprometido es 2027-02-21 (acta); no hay cambio propuesto sobre él.

### Lo que no escala, y por qué
- **El «documento 1» de Óscar Ramírez** (6 reprogramaciones; vigente el 2026-11-24): es un compromiso vencido que se destraba en la sala, no excede la autoridad de nadie. Va en la agenda, no al Comité.
- **El proveedor que podría no llegar con el equipo completo:** tiene que estar en el registro de riesgos primero, y el dueño es el gerente. Hoy no tiene probabilidad, impacto ni dueño.
- **Entregable «Licenciamiento del software» del CT-683** (comprometido 2026-03-19, 1.025.448.522 COP, «pendiente»): no encontré su acta de recibo. Lo firma el gerente, así que es suyo; si lo que falta es pagar o renegociar algo, ahí sí cabría escalar, y los documentos no dicen eso.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2025-09-21-acta-constitucion.md` (sin sección de autoridad ni de tolerancias; búsqueda de «autoridad», «facultad», «tolerancia», «umbral», «escal» en todos los documentos del proyecto sin resultados).
- Presupuesto aprobado, comité y patrocinadora: la misma acta.
- Proyección, comprometido y ejecutado: `20-seguimiento/2026-10-13-informe-avance.md`.
- «Ajuste del presupuesto … la otra semana» y próxima reunión «en dos semanas»: `2026-10-15-notas-reunion.txt`. Fecha 2026-10-29: `config.json` (`committee_next`).
- Entregables del CT-683: `00-gobierno/2025-09-20-contrato-ct-683.md`.

### Lo que no sé
- Cuál es la autoridad real del gerente: puede existir fuera de la carpeta. Si existe, este escalamiento se cierra con ese documento.
- El origen de la proyección y el contenido del ajuste de Laura Vélez.
- Cuántos días se movería cada proyecto alcanzado: la ficha no tiene holgura por actividad.
- No abrí el cronograma ni las actas de recibo en PDF.

Este comando no escala solo: llevar el paquete al Comité de Inversiones es de Camilo Beltrán.
