# Plan — Despacho automático de flota (PRY-203) · borrador del 2026-10-15
**Desde:** el acta de constitución del 2025-09-21 (`00-gobierno/2025-09-21-acta-constitucion.md`) · **Criterio de éxito:** «Despacho automático de flota en producción y medido» (acta, sección *Criterio de éxito*), sin métrica ni umbral.

> **Antes de leer el borrador.** Este proyecto no está en su primer día: el acta es de hace más de un año y ya existe un `cronograma-v1.xlsx` del mismo 2025-09-21 con cinco hitos, dos de ellos recibidos en octubre de 2026. Este borrador **no reemplaza ese cronograma ni crea una línea base**; lo trata como un documento más y lo contrasta con el acta. Si lo que buscabas era revisar el plan vigente, la forma correcta es `/pm-plan revisar 10-plan/cronograma-v1.xlsx`.
> Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrar nada nuevo. Sesión sin interfaz: en cada decisión tomé la respuesta sugerida y la dejo dicha en una línea.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance real.** Dice «Componente 1 / 2 / 3» y fuera de alcance «Lo que otro proyecto cubre». Son marcadores, no alcance. | No hay forma de saber qué entregables caen dentro. La WBS de abajo sale del cronograma v1 y del contrato, **no del alcance del acta**; si el alcance verdadero es otro, la WBS hereda el error. |
| **Criterio de éxito sin medida.** «En producción y medido»: no dice qué se mide, con qué umbral ni quién lo certifica. | El último nodo de la WBS no se puede cerrar: nadie sabe cuándo «medido» es verdad. El informe del 13-oct habla de un ensayo de disponibilidad que «no alcanzó lo pactado», pero **lo pactado no está escrito en ningún documento que yo haya leído**. |
| **Autoridad del gerente no declarada.** El acta nombra gerente (Camilo Beltrán), patrocinadora (María Restrepo) y comité (Comité de Inversiones), pero no dice qué puede decidir el gerente al planificar y qué debe subir. | No sé qué parte de este plan puede aprobar el gerente y cuál va al comité. Lo dejo como pregunta, no lo supongo. |
| **Dependencias: «Ninguna declarada».** Pero el informe del 13-oct registra dos: la ventana de parada de planta (la define operaciones) y la última entrega del proveedor (sin fecha confirmada). | Un plan que parte de «sin dependencias» las esconde. Las traigo al plan como supuestos, con su fuente. |
| **Hitos y fechas intermedias.** El acta solo compromete inicio (2025-10-01) y cierre (2027-02-21). | Los cinco hitos del cronograma v1 no tienen respaldo en el acta; su autoridad es la del cronograma, no la del acta. |
| **Quién acepta cada entregable.** El acta no lo dice. El contrato CT-683 dice que los entregables del proveedor se facturan contra acta de recibo firmada por el gerente. | Solo puedo decir quién acepta los dos entregables contractuales. Los demás, y el resultado final, quedan sin dueño de aceptación. |

Sigue lo que sí está: patrocinador, presupuesto (9.500.000.000 COP, aprobado el 2025-09-21) y fecha de cierre. Seguí adelante marcando los huecos, sin rellenarlos.

## WBS
Descompuesta por entregable. «De dónde sale» usa los tres estados. Solo lo escrito en el acta es *del acta*; lo que sale de otro documento va como **supuesto** con su cita, porque el acta no lo respalda.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Despacho automático de flota en producción y medido | Sin definir | **Del acta** (*Criterio de éxito*) | — |
| 1.1 | Ingeniería básica aprobada | Sin definir | **Supuesto**: cronograma v1 (línea base 2026-01-01, «cerrado»). No hay acta de recibo en `20-seguimiento/`. | 92 d implícitos* |
| 1.2 | Ingeniería de detalle aprobada | Camilo Beltrán recibió (acta 2026-10-14); quién aprueba, sin definir | **Supuesto**: cronograma v1 (línea base 2026-04-03) + acta de recibo 2026-10-14 | 92 d implícitos* |
| 1.3 | Licencia y permisos obtenidos | Camilo Beltrán recibió (acta 2026-10-06); autoridad que otorga, sin definir | **Supuesto**: cronograma v1 (línea base 2026-07-05) + acta de recibo 2026-10-06 | 93 d implícitos* |
| 1.4 | Montaje e instalación | Sin definir | **Supuesto**: cronograma v1 (línea base 2026-10-05, «en curso»; ya pasó) | 92 d implícitos* |
| 1.5 | Pruebas en operación, incluida la repetición del ensayo de disponibilidad | Sin definir | **Supuesto**: cronograma v1 (línea base 2027-01-05) + informe 2026-10-13 | 92 d implícitos* |
| 1.6 | Licenciamiento del software (CT-683, 1.025.448.522 COP) | Gerente del proyecto (contrato, *Condición de pago*) | **Supuesto**: contrato CT-683, fecha comprometida 2026-03-19, estado «pendiente» | — |
| 1.7 | Bolsa de horas de ingeniería (CT-683, 1.025.448.522 COP) | Gerente del proyecto (contrato) | **Supuesto**: contrato CT-683, fecha 2026-09-04, «recibido» (acta de recibo del 2026-09-05) | — |
| 1.8 | Medición del despacho en producción (lo que vuelve «medido» el criterio de éxito) | Sin definir | **Sin definir**: el acta dice «medido», nadie dice con qué | — |
| 1.9 | Cierre del proyecto | Sin definir | **Supuesto**: acta, fecha de cierre 2027-02-21; no hay entregable de cierre descrito | 47 d implícitos** |
| — | Componentes 1, 2 y 3 del alcance | Sin definir | **Sin definir**: marcadores del acta; no los puedo mapear a 1.1–1.9 | — |
| — | Entregables que respalden el resto del presupuesto | Sin definir | **Sin definir**: los dos entregables de CT-683 suman 2.050.897.044 COP, el 21,6 % de los 9.500.000.000 aprobados; no veo a qué corresponde el resto | — |

\* Duración **implícita**, no estimada: es la diferencia entre fechas de línea base consecutivas del cronograma v1 (partiendo del inicio 2025-10-01 del acta), asumiendo que los hitos son consecutivos. Es una descripción del plan viejo, no una propuesta mía.
\*\* De 2027-01-05 (pruebas) a 2027-02-21 (cierre del acta), con el mismo supuesto.

Los nodos terminales 1.1–1.5 son hitos, no necesariamente entregables que alguien «reciba y acepte» —«Montaje e instalación» no dice qué se entrega ni a quién—. Eso queda como pregunta.

## Orden
Sin fechas. Lo que necesita qué:

- **Secuencia del cronograma v1** (supuesto: es finish-to-start; el cronograma no declara dependencias, solo fechas): 1.1 → 1.2 → 1.3 → 1.4 → 1.5 → 1.8 → 1.9.
- **1.4 Montaje** depende de la ventana de parada de planta (definida por operaciones) y de la última entrega del proveedor, sin fecha confirmada (ambas, informe 2026-10-13, *Riesgos abiertos*).
- **1.5 Pruebas** depende de 1.4. El ensayo de disponibilidad ya falló una vez y se repite (informe 2026-10-13).
- **1.6 Licenciamiento del software**: **no sé** de qué depende ni qué depende de él. Es el único entregable contractual pendiente, vencido desde 2026-03-19 (210 días a hoy), y no aparece en el cronograma v1. Sin definir.
- **1.8 Medición** depende de 1.5 y de que alguien defina la métrica.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 y los dos entregables de CT-683 son *todo* el trabajo del proyecto | Faltan entregables; la WBS y cualquier fecha derivada quedan cortas |
| Los hitos son consecutivos (finish-to-start) | Las duraciones implícitas no significan nada y el orden cambia |
| El cronograma v1 sigue siendo la línea base vigente (en todos los hitos, fecha vigente = fecha de línea base, aunque 1.2 y 1.3 se recibieron 194 y 93 días después de su fecha de línea base y 1.4 lleva 10 días vencido) | Si hubo una replanificación que no está en la carpeta, la desviación se mide contra una referencia equivocada |
| 1.1 Ingeniería básica está cerrada, como dice el cronograma, aunque en `20-seguimiento/` no hay su acta de recibo | Un hito dado por cerrado sin evidencia de aceptación; todo lo posterior descansa en él |
| «Producción y medido» se alcanza con la fase de pruebas en operación y una medición posterior | Podría ser otra cosa (otro entregable, otra fase) y faltar un nodo completo |
| El gerente del proyecto es quien acepta los entregables del proveedor (contrato) | Si el acta o el comité exigen otra firma, las actas de recibo vigentes no valen como aceptación |
| El producto asociado «despacho de flota» del acta es PRD-302 | PRD-302 tiene otro segmento (Comunidad, el acta dice área dueña Medio Ambiente) y declara «Proyectos que lo construyen: Ninguno declarado»; si no es el mismo producto, el proyecto no cuelga de ninguno que yo vea |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Alcance: qué son los componentes 1, 2 y 3, y qué queda fuera | Sin definir; el acta lo atribuye al patrocinio (María Restrepo) y al comité, pero no lo dice |
| Métrica, umbral y responsable de certificar «en producción y medido» | Sin definir (patrocinadora o comité, a confirmar) |
| «Lo pactado» para el ensayo de disponibilidad | Sin definir; no está en ningún documento leído |
| Quién acepta 1.1, 1.4, 1.5, 1.8, 1.9 y el resultado final | Sin definir |
| Autoridad del gerente al planificar | Sin definir (patrocinadora / comité) |
| Relación de 1.6 Licenciamiento con el resto del orden | Sin definir |
| A qué corresponde el 78,4 % del presupuesto que no respalda CT-683 | Sin definir |
| Vínculo del proyecto con el producto (PRD-302 u otro) | Sin definir |

## Proyectos análogos
**Ninguno a la vista.** La configuración de PRY-203 no apunta a una carpeta de fichas de la PMO, así que no consulté fichas. En la carpeta de trabajo hay otros proyectos (PRY-199, 201, 202, 205 y 209: luminarias, relavera, planta de agua, gestión de seguridad, electrificación), pero ninguno construye el mismo producto ni entregables del mismo tipo, y no los leí. Por eso no traigo ninguna cifra de desvío: sería forzar una analogía. Si la PMO tiene fichas de otros despachos o de otros proyectos con licenciamiento y montaje, esa es la referencia que falta.

| Proyecto | Qué le pasó | Fuente |
|---|---|---|
| — | — | — |

## Preguntas para el equipo
Una por cada duración vacía; las de arriba con «implícita» no cuentan como estimadas.

1. **1.1 a 1.5:** ¿cuánto tomó o va a tomar *realmente* cada uno? Los dos recibidos llegaron 194 y 93 días después de su línea base: ¿qué cambió y quién lo aprobó?
2. **1.4 Montaje:** ¿qué se entrega exactamente y a quién? ¿Cuánto falta desde hoy, dado que la línea base venció el 2026-10-05?
3. **1.5 Pruebas:** ¿cuánto toma repetir el ensayo de disponibilidad, y cuál es el umbral «pactado»?
4. **1.6 Licenciamiento del software:** ¿cuánto toma, de qué depende y por qué sigue pendiente 210 días después de su fecha contractual?
5. **1.8 Medición:** ¿qué se mide, con qué umbral y durante cuánto tiempo antes de decir «medido»?
6. **1.9 Cierre:** ¿qué incluye y quién lo acepta?
7. **Alcance:** ¿cuáles son los componentes 1, 2 y 3?
8. **Presupuesto:** ¿en qué entregables se gasta el 78,4 % que CT-683 no cubre?
9. **Proveedor:** las notas de hoy dicen que podría no llegar con el equipo completo para la siguiente fase y nadie lo anotó como riesgo. ¿Quién lo registra?

## Para comprometer una fecha falta
Ninguna de estas tres está en un documento que yo haya leído:

- **La disponibilidad real del equipo** que va a ejecutar montaje, repetición del ensayo y medición.
- **La fecha del proveedor**: el informe del 13-oct dice que no ha confirmado la última entrega, y las notas de hoy dicen que podría no llegar completo.
- **La ventana de parada de planta**: la define operaciones y su fecha no está escrita.

Además, mientras el alcance y la métrica de «medido» sigan sin definir, cualquier fecha de cierre sería una fecha sobre un destino sin definir. El cierre del 2027-02-21 es del acta; no lo toco.

---
*Este borrador no compromete ninguna fecha, no crea línea base, no asigna personas y no estima por analogía. Cuando el plan se apruebe, puedo registrarlo como línea base y pasar los supuestos al RAID con doliente.*
