## Reunión de seguimiento — PRY-203 Despacho automático de flota · 2026-10-29
7 puntos · 37 minutos · 8 personas requeridas (Óscar Ramírez, María Restrepo, Camilo Beltrán, Elena Duarte, Mauricio Pérez, Javier Hoyos, Diana Molina, Laura Vélez)

Términos: ya vigentes (José Francisco Ñáñez, 2026-10-15, versión 0.3.9); no hubo que pedirlos de nuevo.

Dos aclaraciones antes de la agenda:
- **La fecha es la de la configuración** (`committee_next: 2026-10-29`) y coincide con «próxima reunión en dos semanas» de las notas del 10-15. La configuración y los comités leídos son **semanales**: si el ritmo cambió a quincenal, la configuración está desactualizada, y si no, falta la reunión del 10-22. Las notas no lo dicen; lo decide el gerente.
- **No hay duración pedida**, así que la suma de los puntos es la duración: 37 minutos. Es la primera corrida de este proyecto (no hay foto anterior), por lo que «qué cambió» se midió contra la reunión del 10-08 y las notas del 10-15. La ficha tiene solo 3 compromisos; los otros 14 salen del comité del 10-08.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea el «documento 1» y salir con una fecha que dependa de algo concreto, o decidir que no se envía** · 15 min · **Óscar Ramírez** (con María Restrepo, patrocinadora)
> Prometido para el 2026-11-24, y antes para el 11-10, y antes para el 10-31, el 10-20, el 10-07 y el 09-26. La promesa original era el 2026-09-10: son **6 reprogramaciones** y la fecha vigente queda 75 días después de la primera. En el expediente no hay documento que respalde ninguna entrega.
> Fuente: `30-reuniones/2026-09-03` a `2026-10-08-comite-semanal.md` y `2026-10-15-notas-reunion.txt` («no alcanzó, se compromete para el 24/11/2026»).
> **Si no se resuelve hoy:** el 11-24 será la séptima fecha. No sé qué es el «documento 1» ni quién lo necesita: ningún documento lo dice. Las notas tampoco aclaran si «no alcanzó» es que no llegó a tiempo o que lo enviado no bastó. Esa pregunta se hace en la sala.
> Además: Óscar tiene 4 compromisos abiertos (documento 1, «Validar el ambiente 20» sin fecha, «Confirmar la fecha 23» para el 10-22 y la revisión con el proveedor para el 10-25). Es parte de lo que se habla en este punto.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Elena Duarte | Actualizar la matriz 6 | Venció el 2026-10-11; sin acta de recibo, y las notas del 10-15 no la mencionan | Entrega con acta, o nueva fecha dicha en voz alta | 3 |
| Mauricio Pérez | Validar el ambiente 12 | Vencía el 2026-10-15; al 10-29 son 14 días sin acta, salvo que llegue una antes | Acta, o qué lo detuvo | 3 |
| Javier Hoyos | «Aprobar el diseño 5», dicho como entregado el 10-08 | 2026-10-08, «no se presentó acta» | Acta o retirar la afirmación | 4 (los tres) |
| Camilo Beltrán | «Cerrar la prueba 10», dicho como entregado el 10-08 | 2026-10-08, «no se presentó acta» | Acta firmada por el gerente (que es quien la recibe) | |
| Diana Molina | «Confirmar la fecha 15», dicho como entregado el 10-08 | 2026-10-08, «no se presentó acta» | Acta o retirar la afirmación | |

Fuente: `30-reuniones/2026-10-08-comite-semanal.md`. Las tres últimas filas no son compromisos vencidos: son entregas declaradas sin documento, y su fila va junta para gastar 4 minutos, no 12.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo a la siguiente fase: ¿se registra como riesgo, con qué dueño, probabilidad e impacto? (Fuente: notas del 10-15, «nadie lo anotó como riesgo»; no consta quién lo dijo). Ojo: no se sabe si «equipo» son personas (la bolsa de horas del CT-683) o equipos físicos. | Camilo Beltrán, con Óscar Ramírez (revisa al proveedor el 10-25) | El riesgo sigue dicho al pasar y fuera del registro; el informe del 10-13 solo registra que el proveedor no confirmó la fecha de la última entrega, que es otra cosa | 5 |
| Entregable «Licenciamiento del software» del CT-683: fecha comprometida 2026-03-19, 1.025.448.522 COP, estado «pendiente» en el contrato. No encontré su acta de recibo. (El acta del 10-06 es de «Licencia y permisos obtenidos»; no puedo decir que sea el mismo entregable.) Fuente: `00-gobierno/2025-09-20-contrato-ct-683.md`. | Camilo Beltrán (firma el recibo y la factura se paga contra acta) | Un entregable con 7 meses de vencido queda sin dueño y sin fecha | 5 |
| Fecha del «ajuste del presupuesto» de Laura Vélez («la otra semana» no es una fecha) y si responde a la proyección del informe del 10-13: 9.830.484.869 COP contra 9.500.000.000 aprobados. | Laura Vélez | No puede vencer, así que no hay cómo saber que se incumplió | 2 |

### Vence antes de la próxima
Con la reunión el 10-29, todo lo de esta tabla vence **antes**: en la sala se pregunta si llegó el acta, no se discute.

| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-22 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (domingo) |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-25 |
| Javier Hoyos | Entregar el punto 8 | 2026-10-26 |
| María Restrepo | Aprobar el diseño 21 | 2026-10-27 |
| Sandra Gil | Enviar el documento 9 | 2026-10-28 |
| Laura Vélez | Mandar el ajuste del presupuesto | «la otra semana» |

Esta lista sale del comité del 10-08 y las notas del 10-15; las notas del 10-15 no dicen nada sobre los 14 compromisos del 10-08, así que no los doy por cumplidos ni por reprogramados.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Que la proyección (9.830.484.869 COP) supere lo aprobado (9.500.000.000 COP) en 330.484.869 COP, 3,5 % | La autoridad del gerente no está en la ficha (`identity.authority`: no encontrada), así que no puedo decir si esto la excede. Si el ajuste de Laura implica sobrepasar lo aprobado, no lo resuelve esta sala | Si excede su autoridad: `/criterio-project:pm-escalate` hacia el Comité de Inversiones. Primero, que el gerente confirme cuál es su autoridad |
| Qué pasa con el estado «Rojo» con 91 % de avance (informe del 10-13) | Es una afirmación del informe, no de una persona de la sala que la pueda mover | `/criterio-project:pm-report` |

### Anexo — sin cambios desde el 2026-10-08
No se repasa en la reunión. Compromisos del comité del 10-08 sin movimiento:
- Paula Céspedes: Cerrar la prueba 2 · 2026-11-13
- Elena Duarte: Entregar el punto 16 · por definir
- Diana Molina: Enviar el documento 17 · 2026-11-08
- Ricardo Salas: Cerrar la prueba 18 · 2026-10-31
- Diana Molina: Revisar el anexo 19 · 2026-10-29
- Felipe Arango: Entregar el punto 24 · 2026-11-01
- Cerrado el 10-08 con acta: Actualizar la matriz 14 (Natalia Ospina).
- Entregable «Ingeniería de detalle aprobada» recibido el 10-14 y «Licencia y permisos obtenidos» el 10-06 (actas firmadas por Camilo Beltrán).

### Quedó fuera por falta de dato, no por tiempo
- El cronograma (`10-plan/2025-09-21-cronograma-v1.xlsx`), la factura y el acta de recibo del CT-683 en PDF no se abrieron: no puedo decir si la factura del 09-08 corresponde a la bolsa de horas.
- Lo pendiente de decidir de las reuniones anteriores: las notas del 10-15 no registran decisiones, así que no sé qué quedó abierto. No lo invento.

**Después:** esta corrida no convoca a nadie. Cuando termine la reunión, `/criterio-project:pm-minutes` sobre las notas; lo que salga entra a `/criterio-project:pm-commitments`.
