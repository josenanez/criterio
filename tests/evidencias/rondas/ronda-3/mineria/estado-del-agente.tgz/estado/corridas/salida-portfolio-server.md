# Rostrum — para mirarlo un rato

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrarlos de nuevo.

Forma elegida: **«para mirarlo un rato»** (respuesta sugerida: empezar por la primera). Se levanta, se mira y se apaga; nadie tiene un enlace que funcione mañana.

Informe: `reportes/` (existe: portada, proyectos, decisiones, productos y 13 proyectos PRY-199 a PRY-211). Nota: no hay `pmo.html`, así que `/pmo` no tendrá contenido hasta que `/portfolio-report html` lo genere.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada y formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos`, `/p/<código>` | Listado e informe por proyecto | Todos |
| `/productos`, `/producto/<nombre>` | Listado e informe por producto | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

No calcula, no escribe fichas, no autentica y no manda nada. Las peticiones quedan en `estado/peticiones/` hasta que el agente despierte.

Enlace: `http://127.0.0.1:8787/` solo sirve en este equipo; para que el patrocinador tenga un enlace estable hay que pasar a «que quede corriendo» (`--abierto`, con host, puerto y control de acceso de la organización). El informe es del 2026-10-15; queda desactualizado en cuanto cambie la documentación.
