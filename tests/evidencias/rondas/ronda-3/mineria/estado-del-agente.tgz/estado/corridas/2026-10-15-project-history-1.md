# Corrida del 2026-10-15 · project-history

13 proyectos · 67 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Historia de PRY-211 sobre 8 documentos (2025-12-28 a 2026-10-11): 1 replanificación sin motivo ni aprobación (+54 días, 18.8%), 0 cambios de gobierno. Dijo que no sabe: por qué no hay documentos de 2026-T1 a T3, cuándo se editó el cronograma v1, quién aprueba CC-01/v2, y desde cuándo lo declarado no se sostiene (solo hay una declaración). Términos ya vigentes, no se registraron de nuevo.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos vigentes (v1.1, familia 0.3.9), aceptados el 2026-10-15 por José Francisco Ñáñez; no se registraron de nuevo.

## Historia · PRY-211 Control de polvo en vías · 2025-12-28 a 2026-10-11

**Leí:** 8 documentos entre 2025-12-28 y 2026-10-11 (todos los de la carpeta del proyecto; los dos .pdf, el .docx y el .xlsx desde el caché convertido, que cita el original)
**Trimestres sin un solo documento:** 2026-T1, 2026-T2 y 2026-T3. Hay 2 documentos de 2025-T4 (28 de diciembre) y 6 de 2026-T4 (del 3 al 11 de octubre). Nada intermedio.

### En una línea
El proyecto se constituyó el 2025-12-28 con cierre comprometido el 2026-11-19 y un cronograma v1 cuyo último hito (Pruebas en operación) era el 2026-10-21. Todo lo que hay después está escrito entre el 2026-10-03 y el 2026-10-11: el 2026-10-08 se pidió un cambio de +54 días (CC-01, pendiente de comité), el 2026-10-11 apareció un cronograma v2 que ya mueve ese hito al 2026-12-14, y ese mismo día el gerente declara **verde, 65%**. No hay un solo documento entre enero y septiembre de 2026 que muestre cómo se llegó hasta ahí.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 (cronograma v2, sin motivo ni aprobación) | 54 días (18.8 %) | No se puede calcular: hay una sola declaración (2026-10-11) y ya nace contradicha. Falta una serie de estados anteriores | 0 registrados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-12-28 | `00-gobierno/2025-12-28-acta-constitucion.docx` | Se aprueba el proyecto: 9.500.000.000 COP, inicio 2026-01-07, cierre 2026-11-19. Patrocinador Carlos Peña, gerente Ricardo Salas, Comité Ambiental. Alcance "Componente 1, 2 y 3" sin descripción; producto asociado "No aplica"; sin dependencias |
| 2025-12-28 | `10-plan/2025-12-28-cronograma-v1.xlsx` | Línea base v1: cinco hitos, el último (Pruebas en operación) el 2026-10-21. *Observación:* un archivo fechado en diciembre de 2025 ya trae cuatro hitos de 2026 (marzo a agosto) en estado "cerrado"; el contenido no puede ser de esa fecha, o fue editado después. No sé cuándo |
| 2026-10-03 | `30-reuniones/2026-10-03-comite-semanal.md` | Comité Ambiental (Ricardo Salas, Carlos Peña). Temas "Avance" y "Compromisos", sin detalle. Un compromiso: Natalia Ospina, "Entregar el punto 36", para 2026-10-23 |
| 2026-10-08 | `20-seguimiento/2026-10-08-solicitud-cambio-cc-01.md` | Ricardo Salas pide ampliación de alcance: +54 días sobre la línea base vigente y +108.000.000 COP. Autorización: "Pendiente de presentación al comité" |
| 2026-10-08 | `20-seguimiento/2026-10-08-acta-recibo-ingeniería-básica-aprobada.pdf` | Primer acta de recibo del proyecto. Recibe el propio Ricardo Salas. El hito estaba planeado para 2026-03-05 |
| 2026-10-09 | `20-seguimiento/2026-10-09-acta-recibo-licencia-y-permisos-obtenidos.pdf` | Acta de recibo de la licencia. Recibe Ricardo Salas. El hito estaba planeado para 2026-06-28 |
| 2026-10-11 | `10-plan/2026-10-11-cronograma-v2.csv` | Pruebas en operación pasa de 2026-10-21 a 2026-12-14. Los otros cuatro hitos igual que en v1 |
| 2026-10-11 | `20-seguimiento/2026-10-11-informe-avance.md` | Estado declarado **verde**, avance 65 %. Reporta: ensayo de disponibilidad que no alcanzó lo pactado y se repite, parada de planta reprogramada, dos semanas perdidas por rotación de un ingeniero clave. Riesgos: cambio en la licencia ambiental, bloqueo de la vía de acceso. No menciona CC-01 ni el cronograma v2 |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-11 | 2026-12-14 (Pruebas en operación; antes 2026-10-21) | Ninguno en el cronograma v2. CC-01 pide los mismos +54 días pero no da motivo; el informe del 2026-10-11 menciona una parada de planta reprogramada y la pérdida de dos semanas, sin vincularlas a la fecha | **Ninguno.** CC-01 está "pendiente de presentación al comité" y no hay acta de comité que lo apruebe. El sistema marca 54 días movidos y 0 autorizados |

Dos fechas de cierre conviven y no se concilian en los documentos: el acta de constitución dice 2026-11-19; la línea base v1 termina en 2026-10-21 y la v2 en 2026-12-14. No calculo una distancia contra el acta porque el cálculo del atraso (54 días) está hecho contra el cronograma original, no contra el acta.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Nada registrado. Patrocinador (Carlos Peña), gerente (Ricardo Salas) y comité (Comité Ambiental) son los mismos en el acta y en la reunión del 2026-10-03 | — |

Con un solo acta y una sola reunión no se puede ver un cambio de gobierno aunque lo haya habido. La autoridad para aprobar cambios no está declarada en ningún documento.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno se repite | Hay un solo compromiso: Natalia Ospina, "Entregar el punto 36" | 1 | 2026-10-23 (abierto, aún no vence) |

Dos notas: Natalia Ospina no figura entre los asistentes del 2026-10-03; y con una sola reunión no hay manera de ver repetición.

### Desde cuándo lo declarado no se sostiene
No se puede fechar como un deslizamiento, porque no hay serie: existe una sola declaración (2026-10-11) y en esa fecha ya no se sostiene. Lo que sí se puede decir:

- **El primer hito cerrado sin evidencia** es *Ingeniería de detalle aprobada* (planeado 2026-05-01, 167 días antes del corte de hoy), seguido de *Montaje e instalación* (2026-08-24, 52 días). Ninguno tiene acta de recibo. Los otros dos hitos cerrados sí la tienen, pero las actas se emitieron el 2026-10-08 y el 2026-10-09, entre 3 y 7 meses después de las fechas en que los hitos debían cerrarse, y el 2026-10-08 es también el día de la solicitud de cambio.
- **Qué se siguió reportando:** verde y 65 %, cuando el cronograma sostiene entre 80 y 100 % (4 de 5 hitos cerrados), el ejecutado es 23.6 % del aprobado y el comprometido 72.4 %. La proyección al cierre es 9.753.697.626 COP, 2.7 % sobre lo aprobado; no sé si incluye los 108.000.000 COP de CC-01.
- **Señales abiertas en el cierre de hoy:** variance_time, progress_vs_plan, milestone_met_without_evidence (2), rebaseline_unauthorized y declared_vs_evidence. Llevan 2 corridas seguidas (milestone_met_without_evidence, 1).

### Lecciones ancladas a un hecho
- **Hecho:** el cronograma v2 (2026-10-11) aplicó +54 días antes de que CC-01 (2026-10-08) pasara por comité. **Efecto:** la línea base vigente ya está movida sin autorización documentada; el atraso se ve como 0 contra la vigente y 54 días contra la original.
- **Hecho:** dos de cuatro hitos cerrados (2026-05-01 y 2026-08-24) no tienen acta de recibo, y las otras dos son de octubre. **Efecto:** el 65 % declarado no tiene respaldo documental en ninguno de los trimestres anteriores.
- **Hecho:** el informe del 2026-10-11 no menciona CC-01 ni v2. **Efecto:** quien lea solo el informe no ve el cambio de fecha.

Quedan fuera por no poder anclarse: cualquier lección sobre por qué no hay documentos de enero a septiembre, o sobre la rotación del ingeniero clave (el informe lo dice, no da fecha ni efecto medido).

### Lo que no sé
- Por qué la carpeta no tiene documentos de 2026-T1 a 2026-T3: puede que no se escribieran o que no estén en esta carpeta.
- Cuándo se editó realmente el cronograma v1 (fecha del archivo contra contenido).
- Si CC-01 y v2 son la misma decisión, y quién tiene autoridad para aprobarlas.
- Qué son los "Componentes 1, 2 y 3" del alcance, ni qué es "el punto 36".
- Si el ensayo de disponibilidad que se repite ya tiene resultado.

No atribuyo intención: que las actas de recibo aparezcan en octubre o que el informe no cite el cambio no dice que alguien lo ocultara. Es una conversación para tener con el gerente y el Comité Ambiental con estos datos.

¿Llevo esta historia al comité (hay una decisión pendiente: CC-01) o la dejo para el cierre del proyecto? Por defecto en esta sesión: al comité del 2026-10-19.

---
*Pie de rigor:* borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados; la verificación es suya. Cifras copiadas de `portafolio.py compute` al 2026-10-15.
