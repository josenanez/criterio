# Corrida del 2026-10-15 · health-check

13 proyectos · 78 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Diagnóstico de PRY-202 sobre 6 documentos: 3 afirmaciones sostenidas, 7 sin sustento, 4 contradichas. Dijo que no sabe: si el 77% y el dinero comprometido/ejecutado son reales (sin recibos ni facturas), quién aprobó la v2 y CC-01 (sin autoridad ni acta), qué incluye la ampliación de alcance, y qué permiso se recibió. Los .docx se leyeron desde el caché convertido.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-202 · Planta de tratamiento de agua · 2026-10-15

**Leí:** 6 documentos · del 2026-04-05 al 2026-10-11 · formatos: docx (2), csv (2), md (2)
**No pude leer:** nada quedó sin leer. Los dos .docx (acta de constitución y minuta del comité del 2026-10-10) los leí en su texto convertido (`estado/cache/texto/…`), no abriendo el original; la cita apunta al .docx. Busqué menciones de PRY-202 o de la planta en las demás carpetas y en el estado, y no hay ninguna fuera de esta carpeta. Esa búsqueda cubre texto plano y el caché convertido.
**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 4 (14 afirmaciones en total)

Desde esta carpeta se puede afirmar quién es el patrocinador, quién es el gerente, cuál es el presupuesto aprobado y que el plan se corrió 88 días en un hito. No se puede afirmar que el proyecto esté en verde ni que lleve 77 %: el plan no sostiene más de 33 % y ningún hito tiene evidencia de cumplimiento. El dinero comprometido, ejecutado y proyectado es solo lo que dice el informe: la carpeta no tiene contrato, factura ni acta de recibo. La replanificación y la solicitud de cambio CC-01 no tienen autoridad ni acta que las respalde. El informe declara verde y el cálculo dejó sin explicar cuatro señales: compromiso vencido, hito vencido, avance contra plan y desviación en tiempo.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Sandra Gil | acta de constitución 2026-04-05 (.docx) |
| Gerente | Elena Duarte | acta de constitución 2026-04-05; coincide con informe de avance e igual nombre en la minuta del 2026-10-10 |
| Autoridad declarada | **No declarada.** Ningún documento dice qué puede aprobar la gerente (fechas, presupuesto, alcance) | — |
| Comité | «Comité de Seguridad» (aprobó el presupuesto el 2026-04-05). El área dueña es Medio Ambiente; la carpeta no explica por qué lo aprueba ese comité | acta de constitución |

Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. Además, el acta deja alcance como «Componente 1, 2, 3», dependencias como «Ninguna declarada» y criterio de éxito «en producción y medido», sin ninguna métrica.

### Contra el plan
- **Línea base original (v1, 2026-04-05, aprobada por el Comité de Seguridad):** Ingeniería básica 2026-10-02 · Ingeniería de detalle 2027-03-22 · Licencia y permisos 2027-09-08.
- **Vigente (v2, 2026-10-10):** igual, salvo Licencia y permisos → **2027-12-05**. El cronograma v2 **no declara motivo** ni aprobación.
- **Desviación:** +88 días (17,2 %) contra la original; 0 días contra la vigente. 1 replanificación.
- **Solicitud CC-01 (2026-10-11):** ampliación de alcance, «+88 días sobre la línea base vigente», 176.000.000 COP adicionales, «Autorizada por el comité». La v2 ya contiene esos 88 días y es un día anterior a la solicitud. No hay acta de comité que la autorice (la única minuta, del 2026-10-10, trata «Avance» y «Compromisos» y es anterior a la solicitud). El cálculo la marca como cambio aprobado sin línea base nueva.
- **Cierre del acta:** 2027-12-03. La fecha vigente de Licencia y permisos (2027-12-05) cae después de ese cierre, y el criterio de éxito es la planta en producción.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-10-02 | 13 | Acta de recibo de ingeniería básica aprobada (en otras carpetas del portafolio ese hito se sustenta con un acta de recibo en `20-seguimiento`) |

Los tres hitos están «en curso»; ninguno tiene evidencia de cumplimiento (0 de 3 cumplidos).

### Dinero
Todas las cifras salen del informe de avance del 2026-10-10 (una declaración); la carpeta no tiene contrato, factura ni acta de recibo con que contrastarlas.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 COP | 3.151.268.083 COP (75,0 %) | 2.129.378.183 COP (50,7 %) | 4.075.616.439 COP (−3,0 % frente al aprobado) | 1.048.731.917 COP |

El informe no menciona CC-01: sigue mostrando 4.200.000.000 como aprobado y una proyección por debajo de él, mientras CC-01 dice que agrega 176.000.000 COP. Las cuatro cifras no quedan reconciliadas con el cambio.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Elena Duarte, «Entregar el punto 3», para 2026-10-08, dicho en la minuta del 2026-10-10. Lleva 7 días vencido sin evidencia. La minuta solo enumera dos temas, así que no hay un «punto 3» identificable, y la fecha es anterior a la reunión donde quedó anotado.
- **Riesgo sin registro:** «Bloqueo de la vía de acceso a la mina», que aparece solo en el informe, sin responsable, probabilidad, impacto ni fecha. No existe registro RAID en la carpeta.
- **Incidencia sin dueño:** «Se reprogramó la parada de planta por la ventana de mantenimiento». No aparece en ningún cronograma ni minuta.
- **Dependencias:** el acta declara «ninguna», pero el informe habla de un permiso ambiental y de una vía de acceso.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado **verde** | Informe 2026-10-10: «Verde» | Mismo periodo: 4 señales sin explicar (hito vencido 13 días, compromiso vencido 7 días, +88 días contra la original, avance sin respaldo del plan) |
| Avance **77 %** | Informe 2026-10-10 | Cronograma v2: 0 de 3 hitos cumplidos; el plan sostiene entre 0 y 33 %, o sea 44,0 puntos menos que lo declarado |
| CC-01: «+88 días sobre la línea base vigente» | Solicitud de cambio 2026-10-11 | Cronograma v2 (2026-10-10): la fecha vigente ya incluye esos 88 días; contra la vigente la desviación es 0 |
| Cierre comprometido **2027-12-03** | Acta de constitución | Cronograma v2: Licencia y permisos se obtiene el 2027-12-05, después del cierre |

### Sin sustento
Nada la contradice y nada la respalda:
1. «Se recibió el permiso ambiental pendiente desde el trimestre anterior» (informe). No hay documento del permiso. Ojo: el cronograma v2, de la misma fecha, sigue con «Licencia y permisos obtenidos» pendiente para 2027-12-05; puede tratarse de otro permiso, pero ningún documento lo dice.
2. «Se reprogramó la parada de planta» (informe).
3. Comprometido 3.151.268.083 COP (informe).
4. Ejecutado 2.129.378.183 COP (informe).
5. Proyección al cierre 4.075.616.439 COP (informe).
6. Riesgo «Bloqueo de la vía de acceso a la mina» (informe).
7. «Autorizada por el comité» en CC-01: sin nombre del comité, sin acta, sin fecha.

**Sostenido (3):** presupuesto aprobado de 4.200.000.000 COP (acta e informe coinciden) · gerente Elena Duarte (acta, informe, CC-01 y minuta) · patrocinador Sandra Gil (acta; asiste a la minuta del 2026-10-10).

### Lo que esta carpeta no permite saber
- **Si el 77 % es real:** no hay actas de recibo ni entregables; la consecuencia es que el avance solo se puede tomar como declaración.
- **Si el dinero comprometido y ejecutado existe:** no hay contratos, órdenes ni facturas; la proyección no se puede validar ni reconciliar con CC-01.
- **Quién aprobó la v2 y CC-01, y con qué facultad:** no hay autoridad declarada ni acta de comité posterior al 2026-10-10; mientras tanto, la fecha 2027-12-05 y los 176.000.000 COP no tienen aprobación demostrable.
- **Qué incluye la «ampliación de alcance»:** el acta lista «Componente 1, 2, 3» sin descripción y CC-01 no dice qué se agrega.
- **Por qué el cronograma solo tiene tres hitos:** no hay hitos de construcción, puesta en marcha ni producción, que es el criterio de éxito; el avance contra plan solo se puede medir sobre ingeniería y licencias.
- **Si el permiso recibido es el de «Licencia y permisos»:** sin el documento no se puede saber qué hito mueve.
- **Fase y producto:** no están en ningún documento (producto «No aplica» en el acta; fase no declarada).

### Pie de rigor
Este diagnóstico es un borrador de trabajo basado solo en los 6 documentos citados, leídos el 2026-10-15; no recoge lo que se haya hablado fuera de ellos. Las cifras derivadas (13 y 7 días, 88 días, 17,2 %, 44,0 puntos, 75,0 %, 50,7 %, −3,0 %, disponible real) vienen del cálculo del script, no de la mano. No recomiendo continuar, detener ni reestructurar: eso lo decide quien tiene la facultad. La verificación contra los originales es de quien lo use.

Siguiente paso posible: llevar las 4 contradicciones a Elena Duarte como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.
