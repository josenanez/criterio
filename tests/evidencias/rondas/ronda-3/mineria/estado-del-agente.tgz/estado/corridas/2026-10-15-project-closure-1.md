# Corrida del 2026-10-15 · project-closure

13 proyectos · 32 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

No se genero acta de cierre: PRY-209 sigue en ejecucion (52% declarado, Amarillo, 2026-10-14). Se entrego el contraste contra lo comprometido; no se pudo determinar cumplimiento del criterio de exito, hitos sin evidencia, discrepancia de fecha acta 2026-06-11 vs cronograma 2026-05-07, sin lecciones sustentables, sin doliente del riesgo.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha `estado/records/PRY-209.json` y los cuatro documentos de `PRY-209-electrificación-de-equipos/`: acta de constitución (2025-09-29), cronograma v1 (2025-09-29), informe de avance (2026-10-14) y acta del comité semanal (2026-10-14). Cifras de `portafolio.py compute`, con corte 2026-10-15.

## Cierre — PRY-209 Electrificación de equipos — 2026-10-15

**Este proyecto no se puede cerrar con la evidencia disponible.** Ningún documento declara que terminó. Los más recientes (2026-10-14) lo muestran en ejecución: estado Amarillo, avance declarado 52 %, montaje detenido por lluvias y compromisos abiertos en el comité. Genero el contraste contra lo comprometido, pero no el acta de cierre. Esto no es una decisión de cierre, y no la tomo yo.

### Contra lo comprometido
**Criterio de éxito (acta, 2025-09-29):** «Electrificación de equipos en producción y medido.»
**Se cumplió:** no se puede determinar. No hay evidencia de equipos en producción ni de medición. El criterio no trae métrica ni umbral, así que aun con evidencia sería difícil verificarlo.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin descripción en el acta | Ninguna |
| Componente 2 | Sin descripción en el acta | Ninguna |
| Componente 3 | Sin descripción en el acta | Ninguna |
| Hito: Ingeniería básica aprobada (2025-12-18) | «cerrado» en el cronograma | Sin evidencia de aprobación, 301 días |
| Hito: Ingeniería de detalle aprobada (2026-02-26) | «cerrado» en el cronograma | Sin evidencia de aprobación, 231 días |
| Hito: Licencia y permisos obtenidos (2026-05-07) | «cerrado» en el cronograma | Sin evidencia de licencia, 161 días |

Los tres hitos están marcados como cumplidos sin un documento que lo respalde. Además hay una brecha entre lo declarado y lo que el plan sostiene. Declaran 52 % de avance, pero el plan tiene sus 3 hitos de 3 cumplidos, lo que equivale a 100 %: diferencia de 48.0 puntos. Los hitos no cubren la obra física (montaje, puesta en producción, medición), así que esa cifra no mide el proyecto.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre» (exclusión del acta; no dice qué proyecto ni qué) | Acta de constitución | 2025-09-29 |

No hay recortes de alcance posteriores registrados: control de cambios con 0 solicitudes. Tampoco puedo afirmar que no hubo recortes, solo que no hay documento.

### Números finales
Son cifras al corte, no finales, porque el proyecto sigue abierto.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre (cronograma) | 2026-05-07 | 2026-05-07 | No hay (sin cierre) | 0 días registrados (replanificaciones: 0) |
| Fecha de cierre (acta) | 2026-06-11 | — | — | — |
| Presupuesto aprobado | 800.000.000 COP | — | — | — |
| Comprometido | — | 387.174.080 COP (48.4 %) | — | — |
| Ejecutado | — | 165.491.322 COP (20.7 %) | — | — |
| Proyección al cierre | — | 760.039.075 COP | — | −5.0 % vs aprobado |

Replanificaciones: 0.

**Hallazgo de fechas.** El acta fija el cierre en 2026-06-11 y el cronograma v1 lo termina en 2026-05-07. Esa discrepancia no está registrada como conflicto ni explicada. En cualquiera de las dos fechas el proyecto ya la superó (con corte 2026-10-15) y sigue en ejecución. Lo que dice «0 días de desviación» es que el cronograma nunca se replanificó: no que se haya cumplido. La línea base no se movió, pero el proyecto tampoco llegó a ella. Esto debe resolverlo el gerente o el comité. Yo no lo reescribo.

### RAID al cierre
**Materializados:** incidencia «Las lluvias detuvieron el montaje durante diez días» (informe 2026-10-14). Sin fecha de inicio ni doliente.
**No materializados:** ninguno determinable.
**Abiertos, con doliente:** el riesgo «Concentración del conocimiento en una sola persona» está abierto, sin doliente, sin probabilidad ni impacto, y no dice quién es esa persona. **Sin doliente no está cerrado.** Compromisos abiertos del comité 2026-10-14:
- Liliana Torres, «Entregar el punto 9»: sin fecha; el acta no dice qué es el punto 9.
- Rubén Cárdenas, «Entregar el punto 14»: para 2026-10-15; sin evidencia de entrega a la fecha de este corte.

### Lecciones
**Ninguna se sustenta.** Con estos documentos solo hay un hecho anclado: las lluvias detuvieron el montaje diez días, pero el informe no dice cuándo ni qué efecto tuvo sobre hitos o fecha. No lo convierto en lección. Una lección sobre «concentración del conocimiento» sería genérica sin un hecho, una fecha y un efecto.

### Sin dato
- Declaración de fin del proyecto y quién la hace.
- Evidencia de producción y medición (criterio de éxito), y qué métrica lo mide.
- Contenido de los Componentes 1, 2 y 3, y cuál proyecto cubre lo excluido.
- Evidencia de aprobación de los tres hitos marcados como cumplidos.
- Cuál es la fecha de cierre vigente: 2026-06-11 (acta) o 2026-05-07 (cronograma).
- Autoridad que aprueba el cierre (campo vacío en la ficha), producto asociado («No aplica» en el acta) y fase.
- Dolientes del riesgo y de la incidencia; qué son los puntos 9 y 14.
- Datos de identidad de la ficha con 13 meses de antigüedad (acta de 2025-09-29).

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto no está cerrado y hacerlo sacaría a un proyecto activo del barrido diario. Para cerrarlo hace falta que el gerente (Sandra Gil) y el patrocinador (Camilo Beltrán) lo declaren contra el criterio de éxito, o que el comité decida un cierre por decisión. Después se vuelve a correr `/project-closure PRY-209`.

*Rigor: borrador de trabajo, no decisión. Cada dato sale de los documentos citados arriba; verifíquelos antes de usarlos. Este análisis no sabe lo que se habló fuera de ellos.*
