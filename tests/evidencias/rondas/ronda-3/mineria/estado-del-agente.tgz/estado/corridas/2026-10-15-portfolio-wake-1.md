# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 51 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Barrido: 80 documentos sin cambios, nada que releer; diff 0. Cita rota PRY-203 (11 campos, ruta sin carpeta del proyecto; el documento existe), no corregida. 5 preguntas de confirmación sin respuesta. No sé qué hay fuera de los documentos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 80 documentos · 0 cambiaron · 0 proyectos recalculados. Primer barrido (sin corrida previa registrada). No hay documentos nuevos, renombrados ni borrados, así que no corrí `/portfolio-scan`. Tampoco apareció nada nuevo frente a la foto de hoy (`diff`: 0 cambios).

### Lo que cruzó un umbral
Nada cruzó hoy. Las 63 señales abiertas (10 de 13 proyectos; 6 con semáforo verde contradicho por la evidencia) ya estaban en la foto de hoy, y el último informe las recoge. Ninguna es nueva.

**Una cita rota que sí es noticia:** PRY-203 tiene 11 campos de la ficha (identidad, fechas del plan, moneda, aprobado) citados como `00-gobierno/2025-09-21-acta-constitucion.md`, ruta que no resuelve. El documento existe en `PRY-203-despacho-automático-de-flota/00-gobierno/2025-09-21-acta-constitucion.md`: lo roto es la ruta de la cita (sin la carpeta del proyecto), no el documento. No toqué la ficha; corregirla es trabajo de `/portfolio-scan` sobre PRY-203. Además hay un árbol de estado duplicado bajo `estado/PRY-203-despacho-automático-de-flota/`, que parece una corrida anterior con la carpeta de trabajo equivocada; conviene revisarlo.

### Peticiones atendidas
Ninguna: `requests` no tocaba hoy.

### Preguntas
Nadie responde en esta sesión sin interfaz, así que quedan **preguntadas el 2026-10-15, sin respuesta**; con la respuesta sugerida entre paréntesis. No las repito en la próxima corrida.

1. **PRY-201, estado declarado:** el informe del 14-oct (`PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-14-informe-avance.md`) declara verde, con costo +17,1% sobre lo aprobado, un hito vencido y un compromiso vencido hace 10 días. ¿Se mantiene el verde? (Sugerida: no; pasarlo a ámbar hasta que haya documento que lo sostenga).
2. **PRY-202, avance declarado:** 77% declarado; el plan sostiene 0–33% y 0 de 3 hitos cumplidos. ¿Qué documento sustenta el 77%? (Sugerida: ninguno aportado; dejar el dato sin confirmar).
3. **PRY-203, hito «Ingeniería básica aprobada»:** marcado cumplido (vencía el 2026-01-01), sin acta de recibo. ¿Hay acta? (Sugerida: pedirla al gerente).
4. **PRY-204, silencio:** 16 días sin documentos nuevos (desde el 2026-09-29), con el hito «Licencia y permisos obtenidos» vencido hace 4 días. ¿Sigue activo? (Sugerida: pedir al gerente el estado de la licencia).
5. **PRY-208, línea base:** se movió 60 días con 0 autorizados (1 cambio visto). ¿Quién aprobó el cambio? (Sugerida: solicitar el acta de control de cambios).

**Vuelvo el 2026-10-16.** El informe de comité (comité del 2026-10-19) toca el 2026-10-17.
