Cargué las 13 fichas de `estado/records/` (PRY-199 a PRY-211, actualizadas el 2026-10-15) y recalculé con `portafolio.py compute` al corte 2026-10-15. Las cifras derivadas salen de ese cálculo; las que vienen de un documento llevan su fuente. Términos: ya vigentes (José Francisco Ñáñez, 2026-10-15, versión 0.3.9); no hubo que pedirlos de nuevo.

# Comité de proyectos — próxima sesión fijada: 2026-10-19
6 decisiones · 7 escalamientos · 10 de 13 proyectos con hallazgos (63 alertas)

**Lo primero que hay que saber:** las 13 fichas tienen la autoridad sin declarar (`no_authority: 13`) y los proyectos dependen de cinco comités distintos (Inversiones, Operaciones, Tecnología, Seguridad, Ambiental). Sin eso no se puede decir quién decide cada punto de abajo; por eso es la decisión 1.

## Decisiones del comité anterior
No encontré registro de un comité anterior: ni acta, ni salida previa de `/steering-pack`, ni decisiones anotadas en las fichas. No sé qué se decidió antes. Dos solicitudes de cambio figuran «aprobadas por el comité» sin acta (decisión 3), lo que indica que hubo decisiones que no quedaron escritas.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | — | — |

## Decisiones de hoy

### [1] ¿Quién tiene autoridad para decidir cambios de alcance, tiempo y costo en cada proyecto, y qué comité decide qué?
**Proyecto:** los 13 · **Quién decide:** no está claro; ninguna acta declara umbrales de autoridad del gerente ni del patrocinador. Por eso es el primer punto. · **Si no se decide hoy:** cada cambio de los puntos 2 a 6 se decide sin regla, como ya pasó con CC-01 de PRY-202 y PRY-206, «autorizadas por el comité» sin acta.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité fija una matriz única de autoridad para el portafolio (gerente / patrocinador / comité) y la anexa a las 13 actas | Sin cambio | Una decisión; el anexo de las 13 actas lo hace cada gerente | Sin costo directo; los topes son del comité y no propongo cifra |
| B. Cada comité declara la autoridad solo de sus proyectos | Sin cambio | Cinco decisiones separadas, en calendarios distintos | Sin costo directo; riesgo de topes distintos para el mismo tipo de cambio |
| C. No declarar nada | Sin cambio | Sin cambio | Los puntos 2 a 6 se siguen decidiendo sin regla |

**Recomendación:** A, porque resuelve estos seis puntos y los siguientes con una sola regla, y evita que dos proyectos con el mismo cambio reciban tratos distintos.

### [2] ¿Se aprueba CC-01 de PRY-208 (+60 días, 120.000.000 COP, ampliación de alcance) y CC-01 de PRY-211 (+54 días, 108.000.000 COP, ampliación de alcance)?
**Proyecto:** PRY-208 Trazabilidad del mineral (Comité de Tecnología) y PRY-211 Control de polvo en vías (Comité Ambiental) · **Quién decide:** por el comité de cada proyecto, si la decisión 1 no dice otra cosa · **Si no se decide hoy:** las dos líneas base ya se movieron sin autorización (60 y 54 días, `rebaseline_unauthorized`) y el estado sigue en rojo (208) y verde (211) sobre una fecha que nadie aprobó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar la línea base nueva con motivo | Se amplía, según la solicitud | +60 días (PRY-208, 14,9 % sobre la original) y +54 días (PRY-211, 18,8 % sobre la original) quedan autorizados | +120.000.000 COP y +108.000.000 COP. Si la proyección actual ya los incluye, no está declarado |
| B. Rechazar y devolver la línea base a la original | Sin ampliación | La desviación de 60 y 54 días se declara como atraso, no como cambio aprobado | Sin costo adicional; el costo del atraso no está declarado |
| C. Diferir hasta que cada gerente sustente el motivo | Sin cambio hoy | Las fechas movidas siguen sin autorización | Sin cambio hoy |

**Recomendación:** C para ambos, con plazo hasta la sesión siguiente: las solicitudes ya movieron la línea base antes de ser aprobadas, y la carpeta no muestra el motivo ni si el costo ya está en la proyección. Con el motivo sustentado, A o B se decide en esa sesión.

### [3] ¿El comité ratifica en acta las aprobaciones de CC-01 de PRY-202 (+88 días, 176.000.000 COP) y CC-01 de PRY-206 (+47 días, 94.000.000 COP)?
**Proyecto:** PRY-202 Planta de tratamiento de agua (Comité de Seguridad) y PRY-206 Red privada LTE en mina (Comité de Inversiones) · **Quién decide:** el comité de cada proyecto; las fichas dicen «autorizada por el comité» sin nombrarlo ni citar acta · **Si no se decide hoy:** en PRY-202 el cambio está aprobado y la línea base nueva no está registrada (88 días); en PRY-206 la línea base se movió 47 días con una aprobación sin acta. La desviación contra la original (88 días, 17,2 %, y 47 días, 12,0 %) queda sin respaldo verificable.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar en acta y registrar la línea base nueva (PRY-202) | Ampliación, según las solicitudes | +88 días y +47 días quedan respaldados | +176.000.000 COP y +94.000.000 COP quedan respaldados |
| B. No ratificar: pasan a ser cambios no autorizados | Ampliación sin respaldo | Las fechas movidas se declaran como atraso | Costo sin respaldo |
| C. Pedir a los gerentes el acta o el correo de la aprobación original | Sin cambio hoy | Sin cambio hoy | Sin cambio hoy |

**Recomendación:** C primero, y ratificar (A) en cuanto aparezca el documento; si no aparece en la sesión siguiente, A solo si el comité confirma que sí aprobó. Ratificar sin saber quién aprobó es ratificar una aprobación que no se puede verificar.

### [4] ¿Qué fecha rige como cierre comprometido en PRY-203 y en PRY-204?
**Proyecto:** PRY-203 Despacho automático de flota (Comité de Inversiones) y PRY-204 Monitoreo de taludes (Comité de Tecnología) · **Quién decide:** el comité de cada proyecto, que aprobó la línea base y el presupuesto · **Si no se decide hoy:** cualquier desviación se mide contra una de dos fechas distintas, y el cambio de PRY-204 (punto 5) no se puede calcular.

| Proyecto | Fecha del cronograma | Fecha del acta |
|---|---|---|
| PRY-203 | 2027-01-05 | 2027-02-21 |
| PRY-204 | 2027-01-12 | 2027-02-05 |

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Rige el cronograma | Sin cambio | Fecha más cercana; PRY-203 ya tiene *Montaje e instalación* vencido 10 días | Sin cambio |
| B. Rige el acta | Sin cambio | Fecha más lejana; reconoce un colchón que el cronograma no tiene | Sin cambio |
| C. Los gerentes aclaran con quién se acordó cada fecha antes de decidir | Sin cambio | Una sesión más | Sin cambio |

**Recomendación:** C, porque ningún documento dice cuál es posterior en PRY-203 (`newer: null`) y las dos fechas están en documentos del mismo día. Si el comité ya conoce la fecha vigente, A o B se decide hoy mismo.

### [5] ¿Se aprueba mover 30 días la salida a producción de PRY-204?
**Proyecto:** PRY-204 Monitoreo de taludes · **Quién decide:** el Comité de Tecnología, por defecto; sin autoridad declarada no hay nivel por debajo (decisión 1) · **Si no se decide hoy:** el proyecto sigue con cierre en 2027-01-12 (cronograma) o 2027-02-05 (acta), con *Licencia y permisos obtenidos* vencido 4 días, sin movimiento hace 16 días y declarado verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar +30 días | Sin cambio declarado | +30 días sobre la fecha que resulte de la decisión 4 | No declarado. Proyección 1.183.123.627 COP contra 1.200.000.000 COP aprobados; un mes más puede romper ese margen |
| B. Rechazar | Sin cambio | Se mantiene la fecha | Sin cambio |
| C. Devolver hasta que se declare quién lo pide, por qué y cuánto cuesta un mes más | Sin cambio hoy | Una sesión más | Sin cambio hoy |

**Recomendación:** C. La solicitud no dice quién la pide ni por qué, ni el costo del mes adicional, y depende de la decisión 4. No hay base para aprobarla ni para rechazarla.

### [6] ¿Se condiciona el pago a Montajes Industriales Ltda. a la existencia de acta de recibo?
**Proyecto:** PRY-203 (CT-683) y PRY-204 (CT-594 y CT-331), el mismo proveedor · **Quién decide:** no está claro quién aprueba facturas; ninguna acta declara esa autoridad (decisión 1) · **Si no se decide hoy:** siguen vencidos *Licenciamiento del software* (PRY-203, 210 días; PRY-204, 58 y 92 días) y *Bolsa de horas de ingeniería* (PRY-204, 41 días), y en PRY-204 hay facturado sin entrega aceptada: 133.892.409 COP (CT-594) y 120.184.897 COP (CT-331), con 0 entregables aceptados en ambos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. No aprobar más facturas de este proveedor sin acta de recibo del entregable | Sin cambio | Puede frenar entregas que dependen de pagos al proveedor; no está declarado | Retiene pagos; el monto retenible no se puede calcular con los datos |
| B. Exigir por escrito un plan de entrega con fecha antes de la próxima factura | Sin cambio | Una semana de plazo, a fijar por el comité | Sin cambio |
| C. Seguir como hasta ahora | Sin cambio | Los entregables vencidos siguen sin fecha | Se mantiene lo facturado sin entrega aceptada |

**Recomendación:** B, con A como consecuencia si no llega el plan. Los contratos no dicen qué cláusulas aplican; no sé qué se puede retener ni si hay multa, y eso se mira con el área de contratos.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-201 | Proyección al cierre 3.863.518.362 COP contra 3.300.000.000 COP aprobados (17,1 % sobre lo aprobado, umbral 10 %), *Licencia y permisos obtenidos* vencido 1 día, compromiso de Paula Céspedes vencido 10 días, y declarado verde | Informe 2026-10-14 | El gerente explica el origen de la proyección; sin eso no se puede formular la decisión de presupuesto |
| PRY-202 | Avance declarado 77 % contra 0 a 33 % que sostiene el plan (0 de 3 hitos cumplidos); *Ingeniería básica aprobada* vencido 13 días; compromiso de Elena Duarte vencido 7 días; declarado verde | Informe 2026-10-10 | El gerente concilia el 77 % con los hitos |
| PRY-203 | Proyección 9.830.484.869 COP contra 9.500.000.000 COP aprobados (3,5 %); declarado rojo; compromisos reprogramados 6, 5 y 3 veces (Óscar Ramírez, Paula Céspedes, Javier Hoyos); 4 compromisos vencidos y 4 sin fecha | Informe 2026-10-13 | La decisión 1 define si el 3,5 % excede la autoridad del gerente. Los reprogramados se destraban en la sala del proyecto |
| PRY-204 | Sin movimiento hace 16 días (umbral 15) desde 2026-09-29; avance declarado 27 % contra 40 a 60 % que sostiene el plan; *Ingeniería básica* e *Ingeniería de detalle* marcadas cumplidas sin evidencia | 2026-09-29 | El gerente entrega informe nuevo y las actas de recibo de esos dos hitos |
| PRY-209 | Cierre planeado 2026-05-07 (cronograma) y 2026-06-11 (acta) ya pasado; sin solicitud de cambio; avance declarado 52 %; los 3 hitos del plan figuran cumplidos sin evidencia; declarado amarillo | Desde 2026-05-07 | Que el gerente presente solicitud de cambio con fecha nueva, o confirme cuál es la fecha vigente |
| Seis proyectos en verde contradichos por su propia evidencia | PRY-201, PRY-202, PRY-204, PRY-205, PRY-206 y PRY-211 declaran verde y tienen señales abiertas que el informe no menciona | Informes entre 2026-09-27 y 2026-10-15 | Que los gerentes vuelvan a declarar el estado teniendo a la vista las señales; la corrección del color es de ellos, no de este paquete |
| Transversal | Los mismos riesgos sin doliente repetidos en varios proyectos: licencia ambiental (PRY-199, 204, 205, 207, 210, 211), vía de acceso (PRY-201, 202, 204, 211) y ventana de parada de planta (varios). Los documentos no permiten saber si es un mismo hecho o una frase copiada | Sin fecha | Que alguien asigne doliente; si es un hecho común, hay que registrarlo una sola vez para el portafolio |

## Para conocimiento
- PRY-199 Cambio de luminarias del campamento: sin alertas; verde, avance 20 %.
- PRY-200 Mantenimiento predictivo de camiones: sin alertas; amarillo, avance 42 %; sin línea base registrada.
- PRY-205 Sistema de gestión de seguridad: avance declarado 41 % contra 67 a 100 % que sostiene el plan; dos hitos cumplidos sin evidencia; compromiso de Laura Vélez vencido 12 días.
- PRY-206 Red privada LTE en mina: avance declarado 87 % contra 50 a 75 %; un hito cumplido sin evidencia; compromiso de Ricardo Salas vencido 25 días (el cambio va en la decisión 3).
- PRY-207 Gemelo digital de la planta: sin alertas; amarillo, avance 57 %; sin movimiento hace 8 días; sin línea base registrada.
- PRY-210 Programa de relacionamiento comunitario: rojo declarado; *Ingeniería básica aprobada* vencido 3 días.
- Presupuesto: ninguna otra proyección supera el umbral de costo de 10 % aparte de PRY-201.

## Anexo
**Estado por proyecto (declarado / alertas)**
| Proyecto | Declarado | Alertas | Aprobado (COP) | Proyección sobre lo aprobado |
|---|---|---|---|---|
| PRY-199 | verde | 0 | 2.400.000.000 | 0,0 % |
| PRY-200 | amarillo | 0 | 9.500.000.000 | 2,9 % |
| PRY-201 | verde | 4 | 3.300.000.000 | 17,1 % |
| PRY-202 | verde | 6 | 4.200.000.000 | −3,0 % |
| PRY-203 | rojo | 16 | 9.500.000.000 | 3,5 % |
| PRY-204 | verde | 11 | 1.200.000.000 | −1,4 % |
| PRY-205 | verde | 5 | 800.000.000 | 0,6 % |
| PRY-206 | verde | 5 | 9.500.000.000 | −6,4 % |
| PRY-207 | amarillo | 0 | 800.000.000 | −6,3 % |
| PRY-208 | rojo | 4 | 9.500.000.000 | −3,3 % |
| PRY-209 | amarillo | 5 | 800.000.000 | −5,0 % |
| PRY-210 | rojo | 1 | 18.000.000.000 | −1,5 % |
| PRY-211 | verde | 6 | 9.500.000.000 | 2,7 % |

**Contradicciones abiertas**
- PRY-203: fecha de cierre del cronograma (2027-01-05) frente al acta (2027-02-21), sin fecha posterior que decida (`pm_vs_pmo`). La ficha no lo tiene como conflicto abierto.
- PRY-204: cronograma (2027-01-12) frente a acta (2027-02-05), mismo día.
- PRY-204: el informe del 2026-09-27 dice que se recibió el permiso ambiental, y el cronograma sigue con *Licencia y permisos obtenidos* en curso, vencido el 2026-10-11.
- PRY-204: ejecutado (577.323.500 COP) mayor que comprometido (403.511.534 COP), sin explicación en el informe.

**Vacíos de información**
- Autoridad: sin declarar en los 13 proyectos. Fase: sin declarar en los 13.
- Producto: sin declarar en PRY-201, 202, 205, 206, 209, 210 y 211.
- Sin línea base registrada: PRY-200 y PRY-207.
- Sin minutas de comité en la carpeta: PRY-200, 204, 207 y 208. No sé qué se habló allí.
- RAID: 43 ítems (21 riesgos y 22 incidencias) sin doliente ni fecha; ninguno cumple de forma demostrable un criterio formal de escalamiento. El riesgo de proveedor de PRY-203 dicho en reunión el 2026-10-15 no está registrado formalmente.
- Ninguna ficha declara dependencias entre proyectos; que no estén declaradas no prueba que no existan, y el impacto entre proyectos de los puntos 2 a 5 no se pudo calcular.
- La corrida anterior de PRY-203 (`pm-escalate`) cita la próxima sesión como 2026-10-29; la configuración dice 2026-10-19. Usé la configuración.
- Antigüedad del dato: PRY-203, PRY-205 y PRY-209 tienen campos de identidad y plan con 13 meses desde su acta (umbral 12).

---
**Pie de rigor.** Versión 0.3.9 · 13 fichas de `estado/records/` al 2026-10-15 · cifras de `portafolio.py compute` al corte 2026-10-15.
**Inciertos:** quién tiene autoridad en cada proyecto; quién aprobó CC-01 de PRY-202 y PRY-206; quién pide el cambio de PRY-204 y por qué; si el costo de CC-01 de PRY-208, PRY-211, PRY-202 y PRY-206 ya está en la proyección; qué fecha de cierre rige en PRY-203 y PRY-204; qué cláusulas tienen los contratos de Montajes Industriales Ltda.; si hubo un comité anterior. Las opciones y las recomendaciones son propuestas de trabajo, no decisiones.
**Borrador de trabajo:** la verificación contra los originales es de la PMO. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9

## Después
Cuando el comité sesione, puedo registrar sus decisiones en las fichas; así el material del siguiente comité arranca con el cierre del ciclo anterior.
