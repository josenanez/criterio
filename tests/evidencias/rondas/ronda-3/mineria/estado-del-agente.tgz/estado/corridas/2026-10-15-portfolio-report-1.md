# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 80 documentos, 0 releídos y 80 sin cambio · 22 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

El informe quedó en `/home/claude/banco/ronda-3/mineria/espacio/reportes/index.html`.

Mirar decisiones.html para el patrocinador; 6 verdes contradichos y 63 señales en 10 proyectos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 10 con hallazgos · último barrido 2026-10-15 (63 señales)

Fichas cargadas: 13, de `estado/records/`, fecha 2026-10-15 (frescas, ninguna con más de una semana sin barrido). Términos vigentes (0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea 2026-10-15 es la única; el diff dio 0 cambios).

## Hallazgos por proyecto (de `compute`)
| Proyecto | Señales |
|---|---|
| PRY-203 Despacho automático de flota | 16: compromisos vencidos, sin fecha y reprogramados; hito vencido; hito cumplido sin evidencia; proveedor tarde; avance vs plan; PM vs PMO |
| PRY-204 Monitoreo de taludes | 11: en silencio (16 días); hito vencido; hitos cumplidos sin evidencia; proveedor tarde y facturado sin entrega; declarado vs evidencia |
| PRY-202 Planta de tratamiento de agua | 6: desviación en tiempo; avance vs plan; hito vencido; compromiso vencido; cambio sin línea base; declarado vs evidencia |
| PRY-211 Control de polvo en vías | 6: desviación en tiempo; avance vs plan; hitos sin evidencia; replanificación no autorizada; declarado vs evidencia |
| PRY-201 Ampliación de la relavera | 4: hito vencido; desviación en costo; compromiso vencido; declarado vs evidencia |
| PRY-205 Sistema de gestión de seguridad | 5 |
| PRY-206 Red privada LTE en mina | 5 |
| PRY-208 Trazabilidad del mineral | 4: desviación en tiempo; hitos sin evidencia; replanificación no autorizada |
| PRY-209 Electrificación de equipos | 5 |
| PRY-210 Programa de relacionamiento comunitario | 1: hito vencido |
| PRY-199, PRY-200, PRY-207 | Sin hallazgos |

## Cruces
- 6 proyectos reportados en verde están contradichos por la evidencia.
- 2 proyectos sin línea base.
- 13 de 13 proyectos sin autoridad declarada.
- 7 proyectos sin producto asociado: PRY-201, 202, 205, 206, 209, 210, 211.

## Informe en HTML
Carpeta: `reportes/` (23 páginas).
- `reportes/index.html`: vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html`: vista por decisión, solo lo que excede la facultad de quien gerencia. Para el patrocinador.
- Una página por proyecto y por producto. El PDF sale de imprimir el HTML.

## Necesito que confirmes
Esta corrida no hizo preguntas: la sesión es de prueba y nadie las responde. Con la respuesta sugerida no toca confirmación mensual en esta corrida.

---
Criterio Portfolio 0.3.9 · fichas aplicadas: 13, fecha 2026-10-15 · campos inciertos: los listados como contradicciones y sin sustento en `reportes/index.html` · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
