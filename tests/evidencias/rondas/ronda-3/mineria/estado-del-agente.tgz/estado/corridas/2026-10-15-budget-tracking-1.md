# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 32 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Presupuesto de PRY-201: proyección 17.1% sobre el aprobado, comprometido 41.3%, ejecutado 33.3%. Las cuatro cifras salen solo del informe del gerente; sin respaldo contable, sin detalle por proveedor, y estado verde sin sustento.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15): no hubo que registrarlos de nuevo.

Sale de: ficha PRY-201 (`estado/records/PRY-201.json`), el informe de avance de corte 2026-10-14 y el acta de constitución del 2025-12-04. Cifras derivadas copiadas de `portafolio.py compute` con fecha de cálculo 2026-10-15.

## Presupuesto — PRY-201 Ampliación de la relavera al 2026-10-15
**Moneda:** COP (única moneda declarada; no hay contratos de proveedor en la ficha, así que no hay otra moneda que separar ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | — | Acta de constitución (aprobado por el Comité de Tecnología) y informe de avance | 2025-12-04 / 2026-10-14 |
| Comprometido | 1.362.087.354 | 41.3% | Informe de avance | 2026-10-14 |
| Ejecutado | 1.097.802.366 | 33.3% | Informe de avance | 2026-10-14 |
| Proyección al cierre | 3.863.518.362 | 17.1% por encima del aprobado | Informe de avance | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): 1.937.912.646 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 3.300.000.000 | 3.300.000.000 | 0 |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. Solo existe una versión de la línea base (v1, 2025-12-04), de modo que original y vigente coinciden.

### Ejecución frente a avance
Ejecutado 33.3% · Hitos cumplidos 2 de 4 · Avance declarado 57%.
Lectura: la ejecución queda por debajo del avance de hitos (2 de 4) y del avance declarado. Suele significar trabajo hecho y no facturado. El propio informe dice que el proveedor entregó los equipos y que están pendientes de aceptación, así que puede haber causación por venir. Es una hipótesis: ningún documento lo confirma.

### Alertas
- **La proyección excede el aprobado en 17.1%**, por encima del umbral de desviación de costo de 10%. La proyección es de 3.863.518.362 COP contra 3.300.000.000 aprobados. Hay un desvío proyectado sin solicitud de cambio registrada.
- **El estado declarado es verde y la evidencia no lo sostiene.** El script marca tres señales abiertas que el informe no recoge: la proyección que excede el presupuesto, el hito "Licencia y permisos obtenidos" vencido (1 día, vencía el 2026-10-14) y un compromiso vencido (Paula Céspedes, "Entregar el punto 19", vencido el 2026-10-05, 10 días, acta del comité del 2026-10-12).
- Comprometido en 41.3%: no cruza el umbral de 90%. Aquí no hay tope cercano.

### Sin dato
- **Las cuatro cifras tienen una sola fuente:** el informe de avance del gerente (el acta además respalda el aprobado). Lo que dice el informe es una declaración. No hay extracto contable, ejecución de ERP ni facturas que respalden el comprometido ni el ejecutado.
- **La proyección es una declaración**, con fuente y fecha 2026-10-14. No es más vieja que el último movimiento de presupuesto, porque no hay ningún movimiento posterior a la aprobación inicial. No dice cómo se calculó.
- No hay desglose por proveedor: la ficha no registra proveedores ni contratos para PRY-201.
- Faltan en la ficha identidad.producto, identidad.autoridad e identidad.fase (no afectan las cifras, pero impiden ubicar quién aprobaría un cambio).

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). No hay detalle por proveedor que ofrecer, porque el comprometido no está cerca del tope.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale del documento citado y la verificación es suya. Criterio no sabe lo que se habló fuera de los documentos.*
