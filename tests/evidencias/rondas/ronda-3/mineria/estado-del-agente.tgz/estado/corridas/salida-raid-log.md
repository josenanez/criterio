Salida construida a partir de: las 13 fichas en `estado/records/` (PRY-199 a PRY-211), los informes de avance, las actas de constitución, las minutas de comité de `documentos/proyectos/` y las notas de reunión de PRY-203 del 2026-10-15. Escala de valoración: no hay una definida por la organización, se usaría alta/media/baja; ningún ítem trae probabilidad ni impacto, así que no los inventé.

## RAID — portafolio al 2026-10-15
21 riesgos · 0 supuestos · 22 incidencias · 0 dependencias
43 sin doliente · 43 sin fecha · 42 sin fecha de movimiento (no se puede medir "sin movimiento en dos períodos") · 1 no registrado formalmente

### Necesitan decisión ahora
Ningún ítem cumple de forma demostrable un criterio formal de escalamiento: no hay mitigaciones con fecha que hayan vencido, ni doliente que no haya respondido, ni fechas de último movimiento. Lo que sigue sube por juicio, no por regla, y lo decide la PMO.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-203 (sin id) | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-15 (dicho en reunión) | PRY-203 declara rojo; en la ficha el entregable "Licenciamiento del software" de CT-683 está pendiente, vencía el 2026-03-19 y no tiene evidencia de recibo; además el informe del 2026-10-13 ya lista "el proveedor no ha confirmado la fecha de la última entrega". Hay dos ítems del mismo proveedor sin doliente ni fecha. |
| Transversal (sin id) | Riesgo/Incidencia | Mismo texto en varios proyectos: licencia ambiental (PRY-199, 204, 205, 207, 210, 211), bloqueo de la vía de acceso (PRY-201, 202, 204, 211), ventana/reprogramación de parada de planta (riesgo: PRY-203, 206, 207, 210; incidencia: PRY-200, 202, 205, 207, 210, 211) | sin doliente | sin fecha | Si es un mismo hecho, afecta a otros proyectos y cumple el criterio de escalamiento; si cada proyecto copió la frase, es ruido. Los documentos no permiten distinguirlo. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "el proveedor podría no llegar con el equipo completo para la siguiente fase" ("nadie lo anotó como riesgo") | Riesgo (PRY-203) | `PRY-203-despacho-automático-de-flota/2026-10-15-notas-reunion.txt` | 2026-10-15 |

Revisé las minutas de comité de PRY-199, 201, 202, 203 (seis), 205, 206, 209, 210 y 211: solo tienen tablas de compromisos y, en PRY-203, "lo que se dijo" sobre entregas. No contienen otro riesgo dicho al pasar. PRY-200, 204, 207 y 208 no tienen minutas en la carpeta, así que no sé qué se habló allí. Las notas de PRY-203 también incluyen compromisos (Óscar Ramírez 24/11 y 25/10, Laura Vélez "la otra semana", sin fecha): son asunto de /commitments, no RAID.

### Sin doliente o sin fecha
Los 43 ítems (21 riesgos y 22 incidencias) no tienen doliente ni fecha; se reporta como hallazgo y no se rellena. El detalle está en el registro completo.

### Reclasificaciones propuestas
- "El proveedor no ha confirmado la fecha de la última entrega" (PRY-200, 201, 203, 208): está registrado como riesgo, pero depende de un tercero fuera del proyecto, así que es una **dependencia** (declarada, no confirmada por la contraparte). Lo dejo como lo registró la ficha y propongo moverlo.
- "Ventana de parada de planta definida por operaciones" (PRY-203, 206, 207, 210): depende de operaciones, por tanto es una **dependencia**, no un riesgo. Operaciones no es un proyecto del portafolio, así que no hay código al cual cruzarla.
- "El proveedor entregó los equipos en el campamento, pendientes de aceptación" (PRY-201): figura como incidencia; es un estado de entrega y no un problema que ya esté afectando al proyecto. Además la ficha dice que no hay contrato de proveedor en la carpeta. No sé si es incidencia; lo dejo para que el gerente lo confirme.

### Dependencias en riesgo
Ninguna que cruzar. Las 13 actas de constitución dicen "Ninguna declarada" en dependencias y no hay ninguna registrada en las fichas. No es lo mismo que no tener dependencias: hay al menos ocho ítems de riesgo que, por su redacción, lo son (ver reclasificaciones). Sin código de proyecto de destino no puedo saber si algún proyecto movió su fecha.

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| — | — | — | — |

### Supuestos
Ninguno registrado. Por la tipología que más falla (persona clave, tercero que entrega a tiempo, ambiente o licencia listos), los informes ya mencionan rotación de un ingeniero clave (PRY-201, 205, 206, 210, 211) y concentración del conocimiento en una persona (PRY-205, 209). No levanté supuestos que nadie dijo.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-199 | Incidencia | Las lluvias detuvieron el montaje durante diez días | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-200 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-200 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-201 | Riesgo | Bloqueo de la vía de acceso a la mina | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-201 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-201 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-201 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación (ningún contrato de proveedor en la carpeta) | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-202 | Riesgo | Bloqueo de la vía de acceso a la mina | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-202 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-203 | Riesgo | Ventana de parada de planta definida por operaciones | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-203 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-203 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (no registrado formalmente) | sin valorar | sin valorar | sin doliente | sin fecha | 2026-10-15 |
| PRY-203 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-204 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-204 | Riesgo | Bloqueo de la vía de acceso a la mina | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205 | Incidencia | Las lluvias detuvieron el montaje durante diez días | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-206 | Riesgo | Ventana de parada de planta definida por operaciones | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-206 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-206 | Incidencia | Las lluvias detuvieron el montaje durante diez días | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-207 | Riesgo | Ventana de parada de planta definida por operaciones | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-207 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-207 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-207 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-208 | Riesgo | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-208 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-208 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-209 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-209 | Incidencia | Las lluvias detuvieron el montaje durante diez días | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210 | Riesgo | Ventana de parada de planta definida por operaciones | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210 | Incidencia | Las lluvias detuvieron el montaje durante diez días | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211 | Riesgo | Bloqueo de la vía de acceso a la mina | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |

## Después
Puedo subir a comité los dos puntos de "Necesitan decisión ahora" con la decisión formulada (¿se formaliza el riesgo del proveedor de PRY-203 y quién es su doliente?; ¿hay un solo ítem de portafolio para licencia, vía y parada de planta?). Para los 43 sin doliente puedo proponer uno, no asignarlo: la ficha no dice a quién corresponde, salvo el gerente de cada proyecto.

---
**Pie de rigor.** Salen de documentos: el texto de los 43 ítems, el riesgo no registrado de PRY-203 y que las 13 actas no declaran dependencias. No lo sé: probabilidad, impacto, dolientes, fechas, ni cuánto lleva cada ítem sin moverse; ni qué se habló en las reuniones sin minuta (PRY-200, 204, 207, 208) o fuera de los documentos. Borrador de trabajo: la verificación contra los originales es de la PMO.
