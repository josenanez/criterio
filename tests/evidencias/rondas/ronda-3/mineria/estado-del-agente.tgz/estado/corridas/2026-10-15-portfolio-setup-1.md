# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 80 documentos, 48 releídos y 32 sin cambio · 106 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `declared_vs_evidence` | 2 |
| `progress_vs_plan` | 2 |
| `milestone_met_without_evidence` | 2 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |
| `pm_vs_pmo` | 1 |
| `variance_time` | 1 |

0 preguntas a la persona (todas por defecto); minutos hasta el primer resultado no medidos; 3 proyectos (PRY-206, PRY-203, PRY-201), 31 documentos leídos; 25 señales, 2 verdes contradichos

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos mineros

**Miré:** 80 documentos en 13 proyectos · formatos: .md (38), .pdf (13), .docx (12), .xlsx (9), .csv (6), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (propuesto porque hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo comité supuesto es el 2026-10-19 (valor sugerido, sin confirmar)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.9 de la familia (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 del .md f0f8a373c9bdced2…
Dónde queda cada cosa: configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

Respuestas tomadas por defecto en esta prueba (nadie respondió): rol PMO, comité semanal, formato presentación, ubicación de estado e informes junto a la carpeta de documentos. Preguntas hechas a la persona: 0.

### Probé con tres proyectos (los de documentación más reciente)

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-206 Red privada LTE en mina | 7 | Gerente Laura Vélez, patrocinador Elena Duarte, presupuesto 9.500 M COP, cierre vigente 2027-04-05 (acta). Declara verde, 87%. Montaje movido de 2027-02-15 a 2027-04-03 (+47 días) por CC-01. | Producto, facultad del gerente (authority), fase. Evidencia de Ingeniería básica. Acta del comité que autorizó CC-01. |
| PRY-203 Despacho automático de flota | 19 (incluye `ficha-pm.json`) | Gerente Camilo Beltrán, patrocinador María Restrepo, contrato CT-683 con Montajes Industriales, declara rojo 91%. 25 compromisos de comité seguidos y reunión del 15/10. | Facultad del gerente, fase. Acta de recibo de Licenciamiento del software. Acta de Ingeniería básica. |
| PRY-201 Ampliación de la relavera | 6 | Gerente Andrés Lozano, patrocinador Carlos Peña, presupuesto 3.300 M COP, cierre 2027-03-16. Declara verde, 57%. | Producto, facultad del gerente, fase. Contrato del proveedor que entregó equipos. |

### Hallazgos (todos levantados por `compute`)

**PRY-206**
- `declared_vs_evidence`: declara verde y el cálculo levanta cuatro señales que lo contradicen.
- `variance_time`: +47 días (12 %) contra la línea base original.
- `progress_vs_plan`: declara 87 %, el plan sostiene entre 50 y 75 % (2 de 4 hitos cumplidos).
- `milestone_met_without_evidence`: Ingeniería básica aprobada está declarada cerrada y no hay acta de recibo.
- `commitment_overdue`: Ricardo Salas, «Entregar el punto 37», vencido hace 25 días.

**PRY-203**
- `progress_vs_plan`: declara 91 %, el plan sostiene entre 60 y 80 %.
- `milestone_overdue`: Montaje e instalación, vencido hace 10 días.
- `milestone_met_without_evidence`: Ingeniería básica aprobada, sin acta de recibo.
- `vendor_deliverable_late`: Licenciamiento del software (CT-683), 210 días de retraso.
- `commitment_rescheduled`: «Enviar el documento 1» (Óscar Ramírez) reprogramado 6 veces; «Cerrar la prueba 2» (Paula Céspedes) 5; «Entregar el punto 8» (Javier Hoyos) 3.
- `commitment_overdue`: 4 vencidos (Elena Duarte ×2, Beatriz Cuéllar, Andrés Lozano); varios con «ya lo entregué» dicho en comité y sin acta.
- `commitment_undated`: 4 compromisos sin fecha.
- `pm_vs_pmo`: fecha de cierre de `plan.end_date`: el cronograma dice 2027-01-05 y el acta (citada por la ficha del gerente) dice 2027-02-21.

**PRY-201**
- `declared_vs_evidence`: declara verde con tres señales en contra.
- `milestone_overdue`: Licencia y permisos obtenidos, 1 día de atraso.
- `variance_cost`: proyección 3.864 M COP contra 3.300 M aprobados (+17,1 %).
- `commitment_overdue`: Paula Céspedes, «Entregar el punto 19», 10 días.

Totales: 25 señales en 3 proyectos; 2 proyectos en verde contradichos. Los tres quedan sin `authority`.

Nota: en PRY-203 el riesgo «el proveedor podría no llegar con el equipo completo» salió de las notas del 15/10 y nadie lo registró. Está en la ficha como riesgo no registrado; el cálculo no lo levanta como señal y no lo cuento como hallazgo de `compute`.

### El portafolio completo
10 proyectos más (PRY-199, 200, 202, 204, 205, 207, 208, 209, 210, 211) · 2 lotes uno tras otro, 80 documentos en total (a leer: 51 más) · aproximadamente 30 a 40 minutos, estimado a partir de estos tres proyectos (no lo medí).

### Lo que le falta a tu carpeta
- Ningún proyecto trae el campo de facultad del gerente (`authority`), ni la fase.
- Las actas de constitución llevan «Componente 1/2/3» como alcance, sin descripción; el producto figura como «No aplica» en dos de tres.
- Hitos declarados cerrados sin acta de recibo en el cronograma (básica en PRY-203 y PRY-206).
- CC-01 de PRY-206 dice «Autorizada por el comité» sin acta ni fecha de esa autorización.
- Compromisos «ya entregados» en comité sin acta de recibo (PRY-203).
- Hay un archivo suelto en la raíz del proyecto PRY-203 (`2026-10-15-notas-reunion.txt`), fuera de las subcarpetas.
- Los demás proyectos siguen sin leer; sus hallazgos están pendientes.
