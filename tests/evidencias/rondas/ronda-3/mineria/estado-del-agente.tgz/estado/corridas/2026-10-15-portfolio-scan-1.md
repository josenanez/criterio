# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 80 documentos, 0 releídos y 80 sin cambio · 194 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Plan: 48 de 80 documentos leídos, 32 sin cambio; 10 fichas nuevas selladas (PRY-199,200,202,204,205,207,208,209,210,211). Nada movido (no hay entrada/). Nada omitido ni ilegible. Mirar: cierre contradicho por cronograma v2 en 202/208/211; hitos cerrados sin acta en 204/205/208/209/211; facturas sin acta de recibo en 204; CC-01 de 208 y 211 pendientes de comité con v2 ya aplicado; PRY-203 con cita huérfana (no tocada).

Contra la corrida del 2026-10-15: +38 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante ya registrado). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita de su documento y la verificación es suya. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Encontré 80 documentos en 13 carpetas de proyecto (.md 38, .pdf 13, .docx 12, .xlsx 9, .csv 6, .json 1, .txt 1). Ninguno ilegible. Leí 48 de 80: los 32 restantes no cambiaron desde la corrida anterior y no se abrieron.

**Documentos:** 80 en la carpeta · 48 leídos · 32 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta · 10 con ficha escrita y sellada en esta corrida (todos nuevos) · 3 sin cambio (PRY-201, PRY-203, PRY-206) · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan, 5 hitos, presupuesto, contrato CT-199, riesgos, 1 compromiso | authority, phase |
| PRY-200 Mantenimiento predictivo de camiones | 2 | identidad, plan, presupuesto, riesgos | authority, phase; sin cronograma ni hitos |
| PRY-202 Planta de tratamiento de agua | 6 | identidad, plan (v1 y v2), 3 hitos, presupuesto, CC-01, 1 compromiso | product ("No aplica"), authority, phase |
| PRY-204 Monitoreo de taludes | 7 | identidad, plan, 5 hitos, presupuesto, contratos CT-594 y CT-331 con 2 facturas | authority, phase |
| PRY-205 Sistema de gestión de seguridad | 4 | identidad, plan, 3 hitos, presupuesto, 2 compromisos | product ("No aplica"), authority, phase |
| PRY-207 Gemelo digital de la planta | 2 | identidad, plan, presupuesto, riesgos | authority, phase; sin cronograma ni hitos |
| PRY-208 Trazabilidad del mineral | 5 | identidad, plan (v1 y v2), 4 hitos, presupuesto, CC-01 | authority, phase |
| PRY-209 Electrificación de equipos | 4 | identidad, plan, 3 hitos, presupuesto, 2 compromisos | product ("No aplica"), authority, phase |
| PRY-210 Programa de relacionamiento comunitario | 4 | identidad, plan, 3 hitos, presupuesto, 1 compromiso | product ("No aplica"), authority, phase |
| PRY-211 Control de polvo en vías | 8 | identidad, plan (v1 y v2), 5 hitos, presupuesto, CC-01, 1 compromiso | product ("No aplica"), authority, phase |

### Actualizados
Ninguno: las tres fichas previas (PRY-201, PRY-203, PRY-206) no tuvieron documentos nuevos ni cambiados en el plan.

### Contradicciones y cosas que hay que mirar
- **Fecha de cierre contradicha por el cronograma v2** (campo `ambiguous`, sin umbral):
  - PRY-202: el acta fija cierre 2027-12-03; el cronograma v2 (2026-10-10) pone Licencia y permisos el 2027-12-05.
  - PRY-208: acta 2027-05-21; cronograma v2 (2026-10-10) pone Montaje e instalación el 2027-05-30.
  - PRY-211: acta 2026-11-19; cronograma v2 (2026-10-11) pone Pruebas en operación el 2026-12-14.
- **Hitos declarados cerrados sin acta de recibo** (la declaración se conserva; falta la prueba): PRY-204 (2 hitos), PRY-205 (2), PRY-208 (2), PRY-209 (3), PRY-211 (2: Ingeniería de detalle y Montaje e instalación). PRY-199 y PRY-211 sí tienen acta para Ingeniería básica; PRY-211 también para Licencia y permisos.
- **Solicitudes de cambio:**
  - PRY-202 CC-01 (+88 días, 176.000.000 COP) figura «Autorizada por el comité» sin nombrar el comité ni citar acta; el cronograma v2 es del 2026-10-10, un día anterior a la solicitud (2026-10-11).
  - PRY-208 CC-01 (+60 días, 120.000.000 COP) y PRY-211 CC-01 (+54 días, 108.000.000 COP) están «pendiente de presentación al comité», pero sus cronogramas v2 ya aplican esos días.
- **Facturas de proveedor sin acta de recibo** en PRY-204: FV-1594 (CT-594, 133.892.409 COP, 2026-09-14) y FV-2331 (CT-331, 120.184.897 COP, 2026-09-29); ningún entregable de esos contratos consta como aceptado.
- **Presupuesto de PRY-204:** el informe del 2026-09-27 reporta ejecutado (577.323.500) mayor que comprometido (403.511.534). Se registró tal cual.
- **PRY-208** declara rojo y 82 % de avance con 1.982.333.435 COP ejecutados de 9.500.000.000 aprobados.
- **PRY-209:** el acta fija cierre 2026-06-11 y el informe del 2026-10-14 reporta 52 % de avance, sin replanificación en la carpeta.
- **Compromisos vencidos al registrarlos:** PRY-202 (Elena Duarte, punto 3, para 2026-10-08, dicho el 2026-10-10) y PRY-205 (Laura Vélez, punto 16, para 2026-10-03, dicho el 2026-10-09). PRY-209 tiene un compromiso sin fecha (Liliana Torres, punto 9: «por definir»).
- **Fichas previas con cita huérfana:** PRY-203 cita `00-gobierno/2025-09-21-acta-constitucion.md`, que el índice no encuentra en disco (11 campos). No se tocó: no estaba en el plan de esta corrida.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 80 documentos se convirtieron a texto sin error |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No hay carpeta `entrada/` con archivos sueltos |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. Nota: `PRY-203-…/2026-10-15-notas-reunion.txt` está suelto en la raíz del proyecto (ya clasificado, sin cambio) |

---
Pie: criterio-portfolio 0.3.9 · fichas tocadas: 10 (PRY-199, 200, 202, 204, 205, 207, 208, 209, 210, 211) · campos en `not_found`: `authority` y `phase` en las 10 fichas; `product` en 5 (202, 205, 209, 210, 211, por «No aplica») · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

Decisiones tomadas por la prueba sin interfaz (respuesta sugerida, sin preguntar): ninguna pregunta surgió; los términos ya estaban vigentes.
