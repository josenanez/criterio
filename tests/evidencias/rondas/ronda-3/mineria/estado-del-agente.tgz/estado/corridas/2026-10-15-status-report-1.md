# Corrida del 2026-10-15 · status-report

13 proyectos · 27 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Informe de PRY-204: verde declarado contradicho por seis señales abiertas. Dijo que no sabe la última reunión, autoridad, fase, evidencia de hitos ni datos de riesgos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Ficha aplicada: `estado/records/PRY-204.json`, actualizada el 2026-10-15. Cifras recalculadas con `compute` al 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## PRY-204 Monitoreo de taludes — estado al 2026-10-15

**Declara el gerente (Ricardo Salas):** verde · 27% · al 2026-09-27 (hace 18 días) — informe de avance `20-seguimiento/2026-09-27-informe-avance.pdf`
**Sustento documental:** contradicho
**Lo que el semáforo no explica:**
- Hitos marcados como cumplidos sin evidencia (2)
- Hito vencido (1)
- Avance declarado por debajo de lo que el plan soporta
- Silencio documental
- Entregables de proveedor atrasados
- Facturación sin entrega
**Último documento:** 2026-09-29 (factura CT-331), 16 días de silencio (umbral 15) · **Última reunión:** sin dato; no hay ninguna minuta ni transcripción en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-12 | 2027-01-12 | 0 días contra la original y contra la vigente |
| Presupuesto aprobado | COP 1.200.000.000 | COP 1.200.000.000 | Proyección COP 1.183.123.627 (-1,4%) |

Replanificaciones: 0. Hay una sola línea base (v1, aprobada el 2026-05-15 por el Comité de Tecnología). No hay solicitudes de cambio.

Dinero (COP, informe de avance del 2026-09-27): comprometido 403.511.534 (33,6%) · ejecutado 577.323.500 (48,1%) · disponible real 796.488.466.
Contraste: ejecutado 48,1% frente a avance declarado de 27%.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-07-10 | 2026-07-10 | Cumplido (declarado) | Ninguna |
| Ingeniería de detalle aprobada | 2026-08-26 | 2026-08-26 | Cumplido (declarado) | Ninguna |
| Licencia y permisos obtenidos | 2026-10-11 | 2026-10-11 | Pendiente, vencido hace 4 días | Ninguna |
| Montaje e instalación | 2026-11-27 | 2026-11-27 | Pendiente | Ninguna |
| Pruebas en operación | 2027-01-12 | 2027-01-12 | Pendiente | Ninguna |

Hitos cumplidos: 2 de 5. Con ese conteo el plan soporta entre 40% y 60% de avance; el gerente declara 27%, 13 puntos por debajo. Es decir, el proyecto va atrasado frente a su propio plan aunque reporte verde.

### Dónde no coincide
- **Verde declarado el 2026-09-27 frente a seis señales abiertas.** Ninguna está explicada en el informe. La alerta `declared_vs_evidence` las lista todas.
- **Dos hitos "cumplidos" sin un solo documento de aprobación.** Ingeniería básica (vencía el 2026-07-10, hace 97 días) e ingeniería de detalle (vencía el 2026-08-26, hace 50 días). La carpeta no trae acta de aprobación.
- **Facturado sin entrega.** Fuente: contratos CT-594 y CT-331, y facturas del 2026-09-14 y 2026-09-29.
  - CT-594: facturado COP 133.892.409; 0 de 2 entregables aceptados.
  - CT-331: facturado COP 120.184.897; 0 de 4 entregables aceptados.
  - Monto aceptado en ambos: 0.
- **Entregables del proveedor vencidos (Montajes Industriales Ltda.):**
  - CT-331, Licenciamiento del software, vencido el 2026-07-15 (92 días).
  - CT-594, Licenciamiento del software, vencido el 2026-08-18 (58 días).
  - CT-331, Bolsa de horas de ingeniería, vencida el 2026-09-04 (41 días).
- **Licencia y permisos.** El hito vencido el 2026-10-11 coincide con el riesgo "Cambio en la licencia ambiental que puede mover el alcance". Ese riesgo está en el informe, pero sin probabilidad, impacto, responsable ni fecha.

### Abierto
**Riesgos e incidencias sin movimiento:** dos riesgos, ambos de la fuente del 2026-09-27, sin fecha de último movimiento (días sin movimiento no calculables):
- Cambio en la licencia ambiental que puede mover el alcance.
- Bloqueo de la vía de acceso a la mina.
No hay incidencias, supuestos ni dependencias registrados.
**Compromisos vencidos:** ninguno registrado. Tampoco hay compromisos en la ficha, porque no hay minutas que los sustenten.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad de aprobación (`identity.authority`) y fase (`identity.phase`): no encontradas.
- Última reunión y compromisos: no hay minutas.
- Para los riesgos: probabilidad, impacto, responsable y fecha.
- Para los hitos: documento de evidencia de cumplimiento.
- Comprometido (COP 403.511.534) es menor que ejecutado (COP 577.323.500) en el informe. Es atípico y conviene confirmarlo con el gerente; no lo he corregido.
- Ninguna de las 16 fuentes está marcada como evidencia o declaración; todas aparecen "sin marcar".

### Siguiente paso
Hay desviación de avance, un hito vencido y facturación sin entrega, que probablemente exceden la autoridad del gerente. Puedo preparar el punto de comité (`/steering-pack`) con la decisión sobre los pagos a Montajes Industriales. El próximo comité es el 2026-10-19.

---
Criterio Portfolio v0.3.9 · ficha de PRY-204 actualizada el 2026-10-15 · campos inciertos: autoridad, fase · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
