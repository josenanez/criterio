Sale de la ficha `estado/records/PRY-204.json` (Monitoreo de taludes, corte del informe 2026-09-27, ficha actualizada 2026-10-15) y del cálculo `portafolio.py impact`.

## Solicitud de cambio — PRY-204 Monitoreo de taludes — 2026-10-15

**Qué se pide:** mover 30 días la salida a producción. Leo «salida a producción» como el hito de cierre *Pruebas en operación* (el criterio de éxito del acta es «Monitoreo de taludes en producción y medido»); si se refería a otro hito, hay que decirlo.
**Quién lo pide:** no consta en la solicitud ni en ningún documento de la carpeta.
**Por qué:** no consta. El único indicio es que *Licencia y permisos obtenidos* (2026-10-11) sigue «en curso» en el cronograma, cuatro días vencido, aunque el informe del 2026-09-27 dice que «se recibió el permiso ambiental pendiente». No hay un documento que muestre cuál de las dos cosas es cierta, y no es un motivo declarado para este cambio.

### Hallazgo previo: el proyecto tiene dos fechas de cierre
| Documento | Cierre |
|---|---|
| Acta de constitución (2026-05-15), «Fechas comprometidas» | **2027-02-05** |
| Cronograma v1 (2026-05-15), hito *Pruebas en operación*, que la ficha toma como línea base 1 | **2027-01-12** |

Hay 24 días de diferencia entre dos documentos del mismo día, y la ficha no tiene el conflicto abierto (`open_conflicts` está vacío). Antes de medir «30 días» hay que saber 30 días desde cuál. Los dos resultados:

- Desde el cronograma: 2027-01-12 → **2027-02-11**.
- Desde el acta: 2027-02-05 → **2027-03-07**.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (el acta no los describe) | Sin cambio declarado | 0 declarado |
| Tiempo | Cierre 2027-01-12 (cronograma) / 2027-02-05 (acta) | 2027-02-11 / 2027-03-07 | +30 días |
| Costo | Aprobado 1.200.000.000 COP; proyección 1.183.123.627 COP | No declarado | No se puede calcular |

**Quién absorbe lo no declarado.**
- **Alcance sin cambio y 30 días más:** los absorbe el costo o la calidad. Nadie dijo cuál de los dos.
- **Costo:** la proyección al cierre ya está en 98,6 % del aprobado, con un margen de 16.876.373 COP. Cualquier gasto de 30 días más de equipo, proveedor o soporte lo rompe. No hay en la carpeta una cifra de lo que cuesta un mes más; no la invento.
- **Ejecutado mayor que comprometido:** el informe reporta ejecutado 577.323.500 y comprometido 403.511.534. Lo ejecutado supera lo comprometido, y el informe no lo explica. Es un dato por aclarar antes de proyectar un mes más de gasto.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo no alcanza a ningún proyecto, directa ni indirectamente: 0 alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

**Esto significa que nadie declaró depender de PRY-204; no significa que nadie dependa.** El acta de PRY-204 dice «Ninguna declarada» y su ficha tiene `dependencies` vacío. Un proyecto que dependa de la alerta de taludes sin haberlo escrito no sale en este cálculo.

Hitos por los que pasa el cambio, no los que se movieron: *Montaje e instalación* (2026-11-27, a 43 días) y *Pruebas en operación* (2027-01-12, a 89 días). **Cuántos días se mueve cada uno no lo sé:** eso necesita holgura por actividad y la ficha no la tiene. Los 30 días son del hito final tal como se pidió; no se pueden repartir hacia atrás.

Contratos de Montajes Industriales Ltda. que caen dentro de la ventana: CT-331 (*Calibración de sensores*, 2026-10-25; *Soporte del primer trimestre*, 2026-12-15) y CT-594 (*Bolsa de horas de ingeniería*, 2026-11-11). Ningún documento dice si sus fechas o montos cambian con esto.

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo `authority` está en «no encontrado» y el acta no declara umbrales de autoridad del gerente ni del patrocinador.
**Según:** acta de constitución 2026-05-15, que nombra patrocinador (Natalia Ospina), gerente (Ricardo Salas) y comité (Comité de Tecnología), sin autoridad de cambio.
**Va a comité:** sí, por defecto. Sin autoridad declarada no hay un nivel por debajo del comité que pueda decidir, y fue el Comité de Tecnología quien aprobó la línea base 1 y el presupuesto. El próximo comité semanal está fijado para 2026-10-19.

**El hallazgo de fondo es la autoridad no declarada.** Mientras no esté escrita, cualquier cambio de este proyecto se decide sin regla.

### Si no se aprueba
El proyecto sigue con cierre 2027-01-12 según el cronograma (2027-02-05 según el acta), con *Licencia y permisos obtenidos* ya vencido el 2026-10-11 y sin evidencia de cierre. El estado declarado es verde, con 27 % de avance al 2026-09-27, y ningún documento de la carpeta sustenta ni contradice ese 27 %.

### Si se aprueba
No se registra línea base nueva: nadie con autoridad la ha aprobado. Cuando se apruebe, quedaría así:

Línea base 2 — cierre **2027-02-11** (o 2027-03-07, según el conflicto de fechas que se resuelva) · presupuesto **1.200.000.000 COP**, sin cambio declarado · motivo: **sin motivo declarado, hay que obtenerlo de quien lo pide**.
La línea base 1 no se toca. El conteo de replanificaciones pasa de 0 a 1 (la ficha tiene `changes` vacío).

Desviación acumulada contra la línea base original: **tiempo +30 días** (contra la línea base 1 del cronograma, 2027-01-12); si la original es el acta, el cierre pasa a +30 días sobre 2027-02-05. **Costo: no calculable** hasta que se declare el efecto del mes adicional; la holgura contra lo aprobado es de 16.876.373 COP.

### Lo que no sé
- Quién pide el cambio y por qué.
- Cuál de las dos fechas, 2027-01-12 o 2027-02-05, es la línea base de cierre.
- Qué hito exacto significa «salida a producción».
- Cuánto cuesta un mes más.
- Si hay proyectos que dependen de este sin haberlo declarado.
- Si el permiso ambiental se obtuvo (informe) o sigue en curso (cronograma).

### Siguiente paso
Llevarlo al comité del 2026-10-19 con estas preguntas abiertas. Registrar la línea base 2 solo cuando lo apruebe quien pueda aprobarlo.
