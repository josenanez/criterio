**Sale de:** `00-gobierno/2025-09-20-contrato-ct-683.md`, `00-gobierno/2025-09-21-acta-constitucion.md`, `20-seguimiento/2026-09-05-acta-recibo-ct-683-bolsa-de-horas-de-ingeniería.pdf`, `20-seguimiento/2026-09-08-factura-ct-683.pdf`, `20-seguimiento/2026-10-13-informe-avance.md`, las seis minutas de `30-reuniones/` (2026-09-03 a 2026-10-08) y `2026-10-15-notas-reunion.txt`, más la salida de `portafolio.py compute` al 2026-10-15. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## Proveedores — PRY-203 Despacho automático de flota al 2026-10-15

### Montajes Industriales Ltda. — contrato CT-683
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae fecha de firma, 2025-09-20, entregables, montos y condición de pago)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (1.025.448.522 COP) | 2026-03-19 | **Pendiente, vencido hace 210 días** | Ninguna de recibo; el contrato mismo lo marca «pendiente» | No (facturado total del proveedor = monto aceptado) |
| Bolsa de horas de ingeniería (1.025.448.522 COP) | 2026-09-04 | Recibido (con 1 día de diferencia entre lo comprometido y el acta) | Acta de recibo del 2026-09-05, recibido por Camilo Beltrán (gerente) | Sí: FV-1683 del 2026-09-08 por 1.025.448.522 COP |

Cifras del script: 2 entregables, 1 aceptado, 0 aceptados sin evidencia, 1 atrasado, facturado 1.025.448.522, aceptado 1.025.448.522. No se levanta la señal «facturado sin entrega».

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Licenciamiento del software | Comprometido para 2026-03-19, estado «pendiente» | Ningún acta ni minuta lo da por entregado; el informe de avance del 2026-10-13 dice solo «El proveedor no ha confirmado la fecha de la última entrega», sin decir cuál | Contrato CT-683; informe de avance 2026-10-13 |
| Concepto de la factura | Cada entregable se factura contra acta de recibo firmada por el gerente | FV-1683 dice «Entregables del contrato CT-683» (plural, sin nombrar cuál); su valor coincide con un solo entregable, el de la bolsa de horas, que sí tiene acta anterior (09-05). Cuadra en monto y fecha; el concepto es ambiguo | Factura 2026-09-08; acta 2026-09-05 |
| Fin del proyecto (afecta el horizonte del contrato) | — | Cronograma v1 (PMO) dice 2027-01-05; acta de constitución (PM) dice 2027-02-21; ninguna es más reciente | Cronograma v1; acta de constitución |

No confundir: el acta del 2026-10-06 «Licencia y permisos obtenidos» es un hito del proyecto, no el «Licenciamiento del software» del proveedor. No sustenta ese entregable.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Ninguno | — | — |

La bolsa de horas está marcada «recibido» y tiene acta. El licenciamiento no está marcado como entregado. Una salvedad: la lectura del PDF da el texto del acta, no verifica la firma.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Ninguno atribuido al proveedor | — | — | — |

Los 4 compromisos vencidos del proyecto son de personas del equipo (Elena Duarte ×2, Beatriz Cuéllar, Andrés Lozano), no del proveedor. Dos cosas que tocan al proveedor sin ser compromiso suyo: «revisión con el proveedor» a cargo de Óscar Ramírez, para 2026-10-25 (aún no vence; notas del 2026-10-15), y el riesgo de que «el proveedor podría no llegar con el equipo completo para la siguiente fase», comentado en esa reunión y **no registrado como riesgo** en ninguna parte.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-683: no están en el contrato de la carpeta. No se puede decir si el preaviso vence antes del cierre del proyecto.
- Qué entregable es «la última entrega» que el proveedor no ha confirmado.
- Si el hito vencido «Montaje e instalación» (previsto 2026-10-05, 10 días de atraso) corresponde a Montajes Industriales: ningún documento lo vincula al contrato.
- Valor total del contrato y porcentaje facturado: el script no los entrega; no se calculan a mano.

### Después
- Sin preaviso que vigilar (no hay dato de vencimiento): conseguir el texto completo de CT-683 con vigencia y cláusula de renovación.
- Sin entregables facturados sin evidencia, por lo que no hay nada que llevar a comité por ese concepto. Sí vale llevar: el licenciamiento 210 días vencido y sin explicación escrita, y el riesgo del equipo incompleto, sin registrar.

**Rigor:** cifras copiadas de `compute` al 2026-10-15; evidencia leída en los documentos citados; lo no hallado se declara como sin dato. Esto es un borrador de trabajo: la verificación contra los documentos es suya.
