# Corrida del 2026-10-15 · project-charter

13 proyectos · 26 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Revisión del acta de PRY-200: faltan autoridad del gerente, objetivo medible, alcance descrito, exclusión con proyecto nombrado, criterio de éxito medible y quién lo mide, supuestos, cadencia e hitos. No se sabe nada de lo hablado fuera de los dos documentos; no se completó ningún campo.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Acta previa:** sí existe, del 2026-03-23 (`PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2026-03-23-acta-constitucion.md`), aprobada por el Comité de Operaciones. Términos vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15).

## Acta — PRY-200 · Mantenimiento predictivo de camiones
**Estado:** existe, del 2026-03-23 · Modo: revisar

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance decide Rubén Cárdenas sin subir a comité. | Cualquier ajuste de alcance o de presupuesto, por pequeño que sea, tiene que ir al Comité de Operaciones. Hoy la proyección al cierre (9.776.375.957 COP) ya supera lo aprobado (9.500.000.000) en 276.375.957 COP (+2,9 %), y no hay forma de saber si eso lo puede absorber el gerente o es una decisión del comité. |
| Objetivo de negocio | **Es la solución repetida, no un objetivo.** "Entregar mantenimiento predictivo de camiones para Planta de procesamiento" no dice qué problema se resuelve (paradas, costo, disponibilidad). | Sin objetivo medible no hay forma de decidir si el proyecto vale lo que cuesta cuando se retrasa o se encarece. |
| Alcance | **Vacío en la práctica.** "Componente 1, 2 y 3" sin descripción. | No se puede distinguir un cambio de alcance de una aclaración; el control de cambios no tiene contra qué comparar. |
| Exclusiones | **Sin contenido útil.** Dice "Lo que otro proyecto cubre", sin nombrar cuál. | Si dos proyectos construyen lo mismo, nadie lo ve: la exclusión no remite a ningún proyecto. |
| Criterio de éxito | **No medible y sin responsable.** "En producción y medido": no hay métrica, umbral ni fecha, ni dice quién mide. | El cierre queda a discreción de quien lo declare; no hay contra qué cerrar. |
| Patrocinador / gerente | Presentes con nombre de persona: Laura Vélez / Rubén Cárdenas. | — |
| Supuestos y restricciones | **Ausentes** (no hay sección). Las dependencias dicen "Ninguna declarada". | El informe de avance (2026-10-14) ya menciona un proveedor sin fecha de última entrega: una dependencia que el acta no registra. |
| Cadencia del comité | **Ausente.** Solo se nombra el comité. | No se sabe cada cuánto debe rendir cuentas ni cuándo se escala. |
| Hitos principales | **Ausentes.** Solo inicio (2026-04-02) y cierre (2027-03-24). | Sin hitos intermedios, el 42 % declarado de avance no se puede contrastar con nada. |
| Presupuesto y fechas | Presentes: 9.500.000.000 COP aprobado el 2026-03-23; 2026-04-02 a 2027-03-24. | — |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe la solución).
**Alcance:** "Componente 1, 2 y 3", sin descripción — pendiente de definir. (Fuente: acta, sección Alcance.)
**Exclusiones:** "Lo que otro proyecto cubre" — sin proyecto nombrado; pendiente de definir. (Fuente: acta, sección Fuera de alcance.)
**Patrocinador:** Laura Vélez · **Gerente:** Rubén Cárdenas (Fuente: acta.)
**Autoridad del gerente:** pendiente de definir — no está en ningún documento.
**Comité al que reporta:** Comité de Operaciones (Fuente: acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Mantenimiento predictivo de camiones en producción y medido" (Fuente: acta) — sin métrica · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo inicio 2026-04-02 y cierre 2027-03-24 (Fuente: acta).

### Lo que sale de otros documentos (no del acta)
- Informe de avance al 2026-10-14: estado declarado amarillo, 42 %; comprometido 5.730.913.292 (60,3 % del aprobado); ejecutado 4.165.462.454; proyección 9.776.375.957 (+2,9 % sobre lo aprobado, por debajo del umbral de 10 % configurado).
- Riesgo abierto: "El proveedor no ha confirmado la fecha de la última entrega" — sin responsable, probabilidad ni fecha.
- Incidencia: "Se reprogramó la parada de planta por la ventana de mantenimiento" — sin responsable ni desde cuándo.

### Después
- El acta quedó **sin autoridad declarada**: te propongo llevar esa definición al Comité de Operaciones (próximo comité según configuración: 2026-10-19). Es una decisión, no un trámite. Con `/criterio-portfolio:steering-pack` se puede preparar.
- De la revisión salieron supuestos implícitos (entrega del proveedor, ventana de parada de planta): te propongo pasarlos al registro RAID con `/criterio-portfolio:raid-log`.

*Pie de rigor: borrador de trabajo hecho solo con los dos documentos de la carpeta del proyecto; no sé lo que se haya hablado fuera de ellos. Nada se completó por lo razonable: lo que no está quedó marcado como pendiente. La verificación es tuya.*
