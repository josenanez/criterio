# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 63 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

puerto 8787, informe reportes/, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrarlos de nuevo.

Forma elegida: **«para mirarlo un rato»** (respuesta sugerida: empezar por la primera). Se levanta, se mira y se apaga; nadie tiene un enlace que funcione mañana.

Informe: `reportes/` (existe: portada, proyectos, decisiones, productos y 13 proyectos PRY-199 a PRY-211). Nota: no hay `pmo.html`, así que `/pmo` no tendrá contenido hasta que `/portfolio-report html` lo genere.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada y formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos`, `/p/<código>` | Listado e informe por proyecto | Todos |
| `/productos`, `/producto/<nombre>` | Listado e informe por producto | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

No calcula, no escribe fichas, no autentica y no manda nada. Las peticiones quedan en `estado/peticiones/` hasta que el agente despierte.

Enlace: `http://127.0.0.1:8787/` solo sirve en este equipo; para que el patrocinador tenga un enlace estable hay que pasar a «que quede corriendo» (`--abierto`, con host, puerto y control de acceso de la organización). El informe es del 2026-10-15; queda desactualizado en cuanto cambie la documentación.
