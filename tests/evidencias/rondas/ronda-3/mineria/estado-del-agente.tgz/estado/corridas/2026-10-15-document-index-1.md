# Corrida del 2026-10-15 · document-index

13 proyectos · 28 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

80 documentos sin cambio, 0 por releer; 11 citas de PRY-203 (pm_record) sin resolver por ruta sin carpeta de proyecto; el archivo existe. No se corrigió ninguna ficha. No se verificó el contenido de los documentos, solo hashes.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.name | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.business_area | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.product | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.sponsor | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.manager | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.identity.committee | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.plan.start_date | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.plan.end_date | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.money.currency | 00-gobierno/2025-09-21-acta-constitucion.md |
| PRY-203 | pm_record.money.approved | 00-gobierno/2025-09-21-acta-constitucion.md |

El documento no se borró ni se renombró: existe en
`PRY-203-despacho-automático-de-flota/00-gobierno/2025-09-21-acta-constitucion.md`
y el resto de la ficha lo cita con esa ruta completa. La sección `pm_record` lo cita sin la
carpeta del proyecto, por eso no resuelve. Es un problema de la cita, no del documento.
Corregirlo toca la ficha y no se hace en silencio: se propone cambiar esas 11 citas a la
ruta completa, una por una, cuando la persona lo apruebe.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

## Qué sigue
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Lo único pendiente es
la corrección de las 11 citas de PRY-203.
