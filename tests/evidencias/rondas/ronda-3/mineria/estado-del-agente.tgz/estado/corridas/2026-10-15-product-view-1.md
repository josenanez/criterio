# Corrida del 2026-10-15 · product-view

13 proyectos · 28 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `milestone_overdue` | 5 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_invoiced_without_delivery` | 2 |
| `rebaseline_unauthorized` | 2 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |

Producto con un solo proyecto (PRY-204), 11 alertas, declarado verde. Sin autoridad ni fase en la ficha; ejecutado > comprometido sin explicación; Licenciamiento del software en dos contratos. No listé proyectos sin producto por pedirse un producto concreto.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-15

Sale del cálculo de `portafolio.py compute` sobre las fichas en `estado`, con corte al 2026-10-15. Vista pedida: **alerta de taludes**.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| alerta de taludes | 1 (PRY-204) | 1 de 1 (11 alertas) | 2027-01-12 (PRY-204) | COP 1.200.000.000 | COP 403.511.534 |

**Alerta de taludes tiene un solo proyecto (PRY-204 Monitoreo de taludes).** La vista por producto no aporta nada distinto de la del proyecto, así que no armo sección de producto. Lo que sigue es el detalle de ese proyecto, tal como sale del cálculo.

### PRY-204 — Monitoreo de taludes
**Lo que hay que ver (11 alertas):**
- **Declarado vs. evidencia:** el informe de avance del 2026-09-27 (tiene 18 días) declara **verde**; el cálculo encuentra seis señales que ese informe no explica: hito cumplido sin evidencia, hito vencido, avance contra plan, silencio, entregable de proveedor atrasado y facturación sin entrega. Fuente: `PRY-204-monitoreo-de-taludes/20-seguimiento/2026-09-27-informe-avance.pdf`.
- **Silencio:** 16 días sin movimiento, desde el 2026-09-29 (umbral: 15).
- **Avance contra plan:** declara 27 %; el plan sostiene entre 40 % y 60 % (2 de 5 hitos cumplidos). Brecha de 13 puntos, por debajo del plan.
- **Hito vencido:** «Licencia y permisos obtenidos», vencía el 2026-10-11, 4 días.
- **Hitos dados por cumplidos sin evidencia:** «Ingeniería básica aprobada» (vencía 2026-07-10) e «Ingeniería de detalle aprobada» (vencía 2026-08-26).
- **Proveedor Montajes Industriales Ltda. — entregables atrasados, ninguno aceptado:**
  - CT-594: «Licenciamiento del software», vencía 2026-08-18, 58 días, pendiente.
  - CT-331: «Licenciamiento del software», vencía 2026-07-15, 92 días, pendiente.
  - CT-331: «Bolsa de horas de ingeniería», vencía 2026-09-04, 41 días, pendiente.
- **Facturado sin entrega:** CT-594, COP 133.892.409 facturados con 2 entregables y 0 aceptados; CT-331, COP 120.184.897 facturados con 4 entregables y 0 aceptados. No sumo las dos cifras porque el cálculo no las entrega sumadas.
- **Dato a revisar:** «Licenciamiento del software» aparece en dos contratos distintos (CT-594 y CT-331) con fechas distintas. No sé si es el mismo entregable contratado dos veces o dos entregables con el mismo nombre; las fichas no lo aclaran.

**Dinero (las cuatro cifras están, COP):** aprobado 1.200.000.000; comprometido 403.511.534 (33,6 %); ejecutado 577.323.500 (48,1 %); proyección 1.183.123.627 (−1,4 % sobre lo aprobado); disponible real 796.488.466. Ojo: lo ejecutado es mayor que lo comprometido; no sé a qué se debe y la ficha no lo explica.

**Dependencias internas:** ninguna, porque el producto tiene un solo proyecto. El cálculo tampoco registra dependencias declaradas de PRY-204 con otros proyectos.

**Fecha comprometida del producto:** 2027-01-12, que sale de PRY-204. Sin desviación contra la línea base original ni contra la vigente (0 días), sin replanificaciones y sin solicitudes de cambio.

### Lo que no sé
- **Autoridad y fase:** la ficha de PRY-204 no trae `identity.authority` ni `identity.phase`. Nadie figura como dueño que responda por el producto.
- **Fuentes sin marcar:** las 16 fuentes de la ficha no están marcadas como evidencia ni como declaración.
- **Proyectos sin producto declarado:** no los listo, porque pediste un producto concreto. Esa lista sale corriendo `/product-view` sin argumento.

### Qué haría con esto
Una sola decisión para el comité del 2026-10-19: qué se hace con PRY-204 reportado en verde y con 11 alertas, y qué pasa con lo facturado a Montajes Industriales sin ningún entregable aceptado.

*Pie de rigor: borrador de trabajo de Criterio, no una decisión ni una asesoría. Las cifras salen del cálculo del 2026-10-15 sobre las fichas; la verificación contra los documentos citados es de quien lo lee.*
