# Corrida del 2026-10-15 · product-definition

PRD-306 · 14 requerimientos · 30 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 10 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); contradice la cifra de volumen (38,5 %); falta criterio de éxito

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Definición — Almacén de repuestos (PRD-306) · contrastada al 2026-10-15
**Documento:** `00-definicion/2026-05-06-definicion-producto.docx` y `00-definicion/2026-05-06-caso-de-negocio.md` · **del** 2026-05-06 · 6 afirmaciones

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado). Gerente de producto: Óscar Ramírez.

### Lo que la evidencia contradice
| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| El volumen mensual es 249.273 | El tablero mide 153.324 (el caso declara 38,5 % por encima; el umbral es 20 %) | Caso de negocio, 2026-05-06 · Tablero de métricas (bodega de datos), corte 2026-10-12 |

Reserva: la serie tiene un solo punto y el tablero no define qué cuenta como «volumen» (`definition: not_found`). La diferencia es real entre los dos documentos; si ambos miden lo mismo, nadie lo ha confirmado.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 249.273 | 153.324 | 38,5 % (declarado por encima) | caso-de-negocio.md 2026-05-06 · tablero-metricas.md 2026-10-12 |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» (sin cifra ni cálculo) | caso-de-negocio.md, 2026-05-06 | No hay serie ni cifra contra la cual contrastar. Nadie mide el retorno. |

### No está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo declara.
- **La propuesta de valor.** La sección «La propuesta» solo dice «Propuesta principal», sin contenido.
- **Que el segmento Gerencia sea quien tiene el problema.** Lo afirma la definición; la única entrevista no menciona segmento.
- **Qué mide «volumen_mensual».** Ningún documento lo define.
- **Cómo se calculó 249.273.** El caso de negocio da la cifra sin método.
- **Qué proyecto construye el producto.** La definición dice «Ninguno declarado».
- **Quién decide.** Ningún documento lo dice; «Comité de producto» es una propuesta por defecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-24) | 205 (umbral 30) | Nombrar al proveedor y el plazo pactado, y contrastar entregas reales contra ese plazo (órdenes de compra y recepciones). Hoy ningún documento nombra proveedor ni plazo, así que el supuesto es difícil de desmentir tal como está escrito. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Gerencia no tiene almacén de repuestos | Una entrevista: «Lo necesito y hoy no lo tengo.» Cliente sin nombre, citado según el acta | 2025-10-14 | Débil: alguien dijo que lo necesita; nadie pagó ni se comprometió. Un solo entrevistado. |

Los 9 requerimientos con evidencia se apoyan en esa misma entrevista. Son una sola fuente, no nueve.

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema existe (y 11 requerimientos que citan al «Cliente entrevistado») | Entrevista del 2025-10-14 | 12 meses (umbral 12) |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada identificado: la definición no roza datos personales, pagos, consumidor financiero ni retención de información | No declarado en la configuración | — | — | No tengo la norma a la vista. Esto no es un cumplimiento ni una ausencia de obligaciones: es que el documento no da pie y el país no está declarado. Revisión jurídica pendiente. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** no declarado en ningún documento (propuesta por defecto: Comité de producto).
- Problema y para quién: declarados (El segmento Gerencia no tiene almacén de repuestos · Segmento Gerencia).
- Nota: el cálculo devuelve `unknown` vacío, pero el criterio de éxito figura como `not_found` en la ficha. Se toma la ficha, que coincide con el documento.

### Después
- El supuesto del proveedor lleva 205 días sin verificarse: se puede convertir en riesgo con doliente (raid-taxonomy).
- La definición no está cerrada (sin criterio de éxito ni autoridad); no corresponde ofrecer `/product-charter` todavía.
