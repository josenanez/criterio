# Corrida del 2026-10-15 · product-spec

PRD-306 · 14 requerimientos · 38 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 10 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador de especificación PRD-306: comportamiento vacío a propósito porque ningún requerimiento dice qué pide; 10 aceptados sin cubrir; 6 criterios no verificables, 4 sin criterio; normativo sin barrer por falta de datos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribe el agente; lo cierra Óscar Ramírez, gerente del producto, con la firma que este agente no puede dar. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

# Especificación — Almacén de repuestos (PRD-306) · borrador del 2026-10-15

**Resultado en una línea:** el registro no alcanza para escribir comportamiento. Ninguno de los 14 requerimientos dice qué pide (el campo «necesidad» es `not_found` en todos y el título es solo «Requerimiento 46xx»). Redactar el comportamiento sería inventarlo, así que esta sección se deja vacía y a la vista.

## Qué problema resuelve
«El segmento Gerencia no tiene almacén de repuestos.» (definición de producto, 2026-05-06). Para quién: Segmento Gerencia (misma fuente).
No lo dice la definición: el criterio de éxito del producto (`success: not_found`) ni el contenido de «La propuesta» (el documento solo trae el rótulo «Propuesta principal»).

## Alcance
Propuesto a partir del registro (estados `aceptado` o `en_construccion`; hay 10 aceptados y 0 en construcción). Quién decide el alcance es el Comité de producto; esta lista no lo decide.

### Entra (10 aceptados, sin contenido descrito)
REQ-4600, REQ-4601, REQ-4602, REQ-4603, REQ-4604, REQ-4605, REQ-4607, REQ-4609, REQ-4610, REQ-4611. Fuente del estado: acta del comité del 2026-10-10.

### No entra
- REQ-4606, REQ-4608, REQ-4612 y REQ-4613: siguen `propuesto`. Llevan entre 176 y 195 días sin decisión (umbral 60). El próximo comité es el 2026-11-12.
- Todo lo que no tenga requerimiento aceptado. En particular, nada de lo que diga «La propuesta» de la definición, porque ese texto está vacío.
- Diseño técnico, estimación de esfuerzo, costo y fecha: no son de este documento.

## Comportamiento
**Vacío a propósito.** Ningún requerimiento aceptado describe qué debe hacer el sistema: ni el acta (que trae «Requerimiento REQ-46xx» y un criterio), ni la definición, ni la entrevista. Lo único que dice quien lo pidió es «Lo necesito y hoy no lo tengo.» (entrevista del 2025-10-14, un cliente sin nombre), y esa frase es la misma para los 10. Escribir secciones de comportamiento aquí sería poner texto del agente donde nadie ha decidido nada. Quien lo cierra: cada doliente, ver la tabla de vacíos.

## Criterios de aceptación
Ninguno pasa la prueba de que dos personas lleguen a la misma respuesta.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4600, 4601, 4602, 4604, 4609, 4610 | No dice qué se observa ni con qué umbral; es el lugar donde se verifica, no el criterio | No. Además lo único que el tablero mide hoy es `volumen_mensual`. |
| Sin criterio | REQ-4603, 4605, 4607, 4611 | — | — |

Hallazgo: el criterio copiado en seis requerimientos es idéntico, así que tampoco distingue un requerimiento de otro. No lo reescribí con un número razonable, porque el número es del doliente.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado el 2026-03-24, 205 días; umbral 30) | No | Óscar Ramírez, gerente del producto. La definición no nombra proveedor. |
| Volumen mensual de 249.273 (caso de negocio, 2026-05-06) como base de dimensionamiento | Contradicho: el tablero mide 153.324 (2026-10-12), el declarado queda 38,5% por encima del medido (umbral 20%) | Óscar Ramírez, autor del caso de negocio. Ningún requerimiento cita el volumen; esto es contexto, no criterio. |
| «Retorno esperado en 24 meses» | Sin cifra ni cálculo | Óscar Ramírez |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada uno de los 14 requerimientos (título y necesidad) | No se puede escribir ni verificar ningún comportamiento | Cada doliente, con Óscar Ramírez |
| Criterio de aceptación de REQ-4603, 4605, 4607, 4611 | Aceptados sin forma de saber si quedaron bien | Ricardo Salas (4603), Carlos Peña (4605), Javier Hoyos (4607), Paula Céspedes (4611) |
| Criterio verificable en los seis que dicen «se verifica en producción» | La discusión de si quedó bien se tiene después de construir | Andrés Lozano (4600), Natalia Ospina (4602), Ricardo Salas (4604), Diana Molina (4609), Rubén Cárdenas (4610); REQ-4601 sin doliente |
| Doliente de REQ-4601 («sin asignar») | Nadie responde por él | Óscar Ramírez |
| Quién decidió cada aceptación: el acta no lo dice (`decision.who: not_found` en los 10) | La decisión no se puede rastrear a nadie | Comité de producto |
| Criterio de éxito del producto | No hay contra qué cerrar el producto | Óscar Ramírez / Comité de producto |
| Casos borde (falta de existencias, repuesto no disponible, pedido duplicado, proveedor que incumple, etc.) | Comportamiento sin definir; lo definiría quien construya | Dolientes de cada requerimiento. Los ejemplos son míos y no son requerimientos. |
| Lo que otro equipo tenga que hacer (proveedor, bodega, sistemas): ningún documento lo menciona | Dependencias sin acordar; no puedo afirmar que no existen | Óscar Ramírez |
| Proyecto que ejecuta cada requerimiento: «Ninguno declarado» y la carpeta de fichas está vacía | 10 aceptados que nadie construye (ver `/product-trace`) | Óscar Ramírez |
| Obligaciones normativas: ningún documento dice qué datos maneja el producto, así que no pude hacer el barrido (regulatory-sweep) | No sé si toca datos personales, pagos u otra obligación; no digo que no | Óscar Ramírez, con quien corresponda en el área legal |
| Evidencia de demanda: los 10 aceptados dependen de una sola entrevista de hace 12 meses; REQ-4609 no tiene ninguna | Se construiría sobre una sola voz, vieja | Óscar Ramírez |

## Requerimientos aceptados que esta especificación no cubre
Con comportamiento escrito, ninguno. Los 10 aceptados quedan sin cubrir por la misma razón: el registro no dice qué piden.

| ID | Título | Por qué no |
|---|---|---|
| REQ-4600 | Requerimiento 4600 | Sin necesidad descrita; criterio no verificable |
| REQ-4601 | Requerimiento 4601 | Sin necesidad; sin doliente; criterio no verificable |
| REQ-4602 | Requerimiento 4602 | Sin necesidad; criterio no verificable |
| REQ-4603 | Requerimiento 4603 | Sin necesidad; sin criterio |
| REQ-4604 | Requerimiento 4604 | Sin necesidad; criterio no verificable |
| REQ-4605 | Requerimiento 4605 | Sin necesidad; sin criterio |
| REQ-4607 | Requerimiento 4607 | Sin necesidad; sin criterio |
| REQ-4609 | Requerimiento 4609 | Sin necesidad; sin evidencia de quién lo pidió; criterio no verificable |
| REQ-4610 | Requerimiento 4610 | Sin necesidad; criterio no verificable |
| REQ-4611 | Requerimiento 4611 | Sin necesidad; sin criterio |

---
Sale del registro `estado-producto/PRD-306/requirements/` (14 requerimientos, actualizado el 2026-10-15) y de los documentos hasta el 2026-10-12. Cubre 0 requerimientos con comportamiento; lista los 10 aceptados. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** no corresponde `/product-charter` todavía: primero los vacíos de arriba. Lo más corto de cerrar es que los dolientes describan qué pide su requerimiento y reescriban el criterio.
