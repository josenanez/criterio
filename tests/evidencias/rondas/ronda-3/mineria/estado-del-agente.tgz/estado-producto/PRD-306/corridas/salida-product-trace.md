## Trazabilidad — Almacén de repuestos (PRD-306) · al 2026-10-15
10 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

(La parte de «decidido» sale de `documentos/productos/PRD-306/30-decisiones/2026-10-10-comite-producto.docx`. Los 4 requerimientos restantes están en estado propuesto —REQ-4606, 4608, 4612, 4613— y no entran en la cadena.)

### Decidido y nadie lo está construyendo
Ninguno de los 10 requerimientos aceptados tiene proyecto: la cadena se rompe en el eslabón de proyecto en todos. «Por quién» no figura en el acta en ningún caso (`decision.who` = no encontrado).

| REQ | Título | Decidido el | Por quién | Doliente |
|---|---|---|---|---|
| REQ-4609 | Requerimiento 4609 | 2026-03-24 | no consta | Diana Molina |
| REQ-4600 | Requerimiento 4600 | 2026-04-21 | no consta | Andrés Lozano |
| REQ-4603 | Requerimiento 4603 | 2026-05-01 | no consta | Ricardo Salas |
| REQ-4602 | Requerimiento 4602 | 2026-05-07 | no consta | Natalia Ospina |
| REQ-4601 | Requerimiento 4601 | 2026-05-16 | no consta (sin doliente) | no encontrado |
| REQ-4610 | Requerimiento 4610 | 2026-05-30 | no consta | Rubén Cárdenas |
| REQ-4605 | Requerimiento 4605 | 2026-06-08 | no consta | Carlos Peña |
| REQ-4604 | Requerimiento 4604 | 2026-06-29 | no consta | Ricardo Salas |
| REQ-4607 | Requerimiento 4607 | 2026-07-26 | no consta | Javier Hoyos |
| REQ-4611 | Requerimiento 4611 | 2026-08-04 | no consta | Paula Céspedes |

El más antiguo lleva 205 días decidido (REQ-4609, además sin evidencia de demanda). Fuente de cada decisión: el acta del comité del 2026-10-10 arriba citada; la fecha de decisión es la que el acta registra para cada uno.

### La traza no se confirma
Nada que confirmar: ningún requerimiento declara proyecto, así que no hay traza que contrastar contra una ficha. Las 10 alertas `requirement_untraced` son esta misma brecha, no una distinta.

### Lo que un proyecto construye y el registro no tiene
Ninguno. Se revisaron las 13 fichas de `estado/records` (PRY-199 a PRY-211): ninguna dice que ejecuta PRD-306 ni «almacén de repuestos». Declaran PRD-299 (PRY-199), «monitoreo de flota» (PRY-200), «alerta de taludes» (PRY-204), «gemelo digital» (PRY-207), «despacho de flota» (PRY-203) y «trazabilidad» (PRY-208). Siete fichas tienen el campo de producto vacío (PRY-201, 202, 205, 206, 209, 210, 211); es un hallazgo del lado de esos proyectos, y no se sabe si alguno construye algo de este producto.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4600 | aceptado | comité, 2026-04-21 | — | no | — |
| REQ-4601 | aceptado | comité, 2026-05-16 | — | no | — |
| REQ-4602 | aceptado | comité, 2026-05-07 | — | no | — |
| REQ-4603 | aceptado | comité, 2026-05-01 | — | no | — |
| REQ-4604 | aceptado | comité, 2026-06-29 | — | no | — |
| REQ-4605 | aceptado | comité, 2026-06-08 | — | no | — |
| REQ-4607 | aceptado | comité, 2026-07-26 | — | no | — |
| REQ-4609 | aceptado | comité, 2026-03-24 | — | no | — |
| REQ-4610 | aceptado | comité, 2026-05-30 | — | no | — |
| REQ-4611 | aceptado | comité, 2026-08-04 | — | no | — |

### Sin fichas a la vista
Hay fichas de los 13 proyectos del portafolio, así que no falta ninguna. Lo que falta es del otro lado: ningún requerimiento nombra un proyecto, y siete fichas no dicen qué producto ejecutan.

### Nota
No se cuenta avance: cobertura de lo decidido = 0 de 10 con proyecto, 9 de 10 con evidencia de demanda (la más reciente del 2025-10-14, vencida a 12 meses).
