## Listo — Almacén de repuestos (PRD-306)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-10-14) · la definición del 2026-05-06 · el acta del comité de producto del 2026-10-10 · el tablero de métricas del 2026-10-12. Los 5 se leyeron (los .docx extrayendo su texto).
**Términos:** aceptados para la versión 0.3.9 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 eff52306622e7cd2… (md)
**Respuestas por defecto, sin nadie que contestara:** estado en `estado-producto/PRD-306` (hermana de la documentación); quien decide = «Comité de producto» (propuesta mía: el acta existe, pero ningún documento dice quién decide); ciclo mensual, próximo comité 2026-11-12 (supuesto mío).

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Gerencia no tiene almacén de repuestos» | Solo la definición misma. La única entrevista dice «Lo necesito y hoy no lo tengo.», sin decir quién, de qué segmento ni qué | 2026-05-06 (entrevista: 2025-10-14) |
| volumen_mensual = 249.273 | Nada que lo sustente. El tablero mide 153.324 al 2026-10-12: el caso está declarado por encima, con una diferencia de 38.5 % (umbral 20 %). Caso de negocio 2026-05-06 contra tablero de la bodega de datos 2026-10-12 | 2026-05-06 |
| «Retorno esperado en 24 meses» | Nada: no hay cifra, ni cálculo, ni supuestos | 2026-05-06 |
| «El proveedor cumple el tiempo pactado» | Es un supuesto, declarado el 2026-03-24 y sin verificar: 205 días | 2026-03-24 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito del producto.** La definición no lo trae.
- **La definición de volumen_mensual.** Ni el caso ni el tablero dicen qué cuentan, así que no se sabe si 249.273 y 153.324 son la misma serie. Además hay un solo punto medido: no hay tendencia.
- **De dónde sale el retorno de 24 meses.** Solo la frase.
- **Quién decide qué se construye.** El acta solo registra a Óscar Ramírez como asistente; ninguna decisión lleva nombre.
- **Qué pidió cada cliente.** El acta dice «Cliente entrevistado» en 11 de 14 requerimientos; la entrevista, una sola, no nombra ninguno. Los 14 títulos son «Requerimiento REQ-46xx», sin el problema escrito.
- **Qué proyecto construye algo.** «Ninguno declarado» en la definición y «—» en los 14 requerimientos.
- **Por qué «Se mantiene el plan».** La decisión del comité no dice qué plan ni quién lo decidió.

### Requerimientos (14: 10 aceptados, 4 propuestos)
- **10 aceptados sin proyecto que los ejecute** (REQ-4600 a 4605, 4607, 4609 a 4611).
- **4 aceptados sin criterio de aceptación** (REQ-4603, 4605, 4607, 4611).
- **1 aceptado sin evidencia de demanda** (REQ-4609) y **1 sin doliente** (REQ-4601, «sin asignar»).
- **11 con evidencia de hace 12 meses** (la entrevista del 2025-10-14), por encima del umbral de 12.
- **3 propuestos sin decidir hace más de 60 días**: REQ-4606 (195 días), REQ-4612 (192), REQ-4613 (176).
- El criterio que sí está escrito, «se verifica en producción», es el mismo en todos los que lo tienen: no dice qué se mide ni cuándo.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», sin verificar hace 205 días. No declara ninguno sobre demanda, volumen ni retorno, que es donde están los números.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una sola ronda, de hace 12 meses, y sin ellas los 11 «Cliente entrevistado» no se pueden convertir en citas.
- La serie de volumen_mensual con su fuente y su definición: hoy hay un punto.
- Las decisiones del comité de producto con quién decidió; un requerimiento descartado hoy se vería igual que uno que nadie miró.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién lo pidió.
