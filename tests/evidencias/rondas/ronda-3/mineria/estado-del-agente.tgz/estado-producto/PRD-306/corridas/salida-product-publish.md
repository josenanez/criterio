No publiqué la ficha de PRD-306 (Almacén de repuestos), corte 2026-10-15: no hay carpeta de productos publicados configurada ni existente.

La configuración (`.criterio/producto/PRD-306/config.json`) no define un sitio común de publicación y no existe ninguna carpeta `publicados`. Sin un sitio acordado por la organización esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ninguna carpeta ni escribí ningún archivo de ficha.

Lo que habría llevado (calculado con `compute` y `publish`):
- 14 requerimientos (10 aceptados, 4 propuestos) · 0 proyectos (ningún requerimiento tiene proyecto) · 1 métrica afirmada
- Segmento declarado: Segmento Gerencia
- Métrica: volumen_mensual = 249273.0, de documentos/productos/PRD-306/00-definicion/2026-05-06-caso-de-negocio.md (2026-05-06). Ojo: el tablero de métricas del 2026-10-12 mide 153324.0, una brecha de 38.5 % con la declarada por encima; la ficha publica solo la cifra declarada.

Para publicar: indicar la carpeta común de productos publicados (y, si no existe, autorizar crearla) y volver a correr el comando.
