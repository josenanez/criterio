# Corrida del 2026-10-15 · product-wake

PRD-306 · 14 requerimientos · 46 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 10 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Primera revisión: 14 REQ, 29 señales, todas nuevas por no haber corte previo. Trazas leídas de estado/records (13 fichas), ninguna confirmada. No releí documentos de descubrimiento; no sé si hay material nuevo.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Almacén de repuestos (PRD-306) · 2026-10-15

**Primera revisión del registro (no hay corte anterior):** 14 requerimientos (10 aceptados, 4 propuestos), 29 señales abiertas. Como no existe corte previo, todas cuentan como nuevas; desde la próxima corrida solo se reportará lo que cruce un umbral después de hoy.

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4606 | 195 días (desde 2026-04-03; umbral 60) | Que alguien con facultad lo decida; hoy esa facultad es del Comité de producto | Óscar Ramírez (doliente) → Comité de producto |
| Sin decidir | REQ-4612 | 192 días (desde 2026-04-06) | Ídem | Mauricio Pérez → Comité de producto |
| Sin decidir | REQ-4613 | 176 días (desde 2026-04-22) | Ídem | Ricardo Salas → Comité de producto |
| Supuesto sin verificar: «El proveedor cumple el tiempo pactado» | definición | 205 días (umbral 30) | Verificarlo exige el historial de entregas del proveedor contra el plazo pactado. Con 205 días ya pasó el punto en que conviene tratarlo como riesgo registrado (assumption-tracking) | Óscar Ramírez |
| Evidencia vencida (12 meses) | 11 REQ: 4600, 4601, 4602, 4603, 4604, 4605, 4607, 4608, 4610, 4611, 4612 | La evidencia más nueva es del 2025-10-14, cumplió 12 meses ayer | Los 11 se sostienen en la misma única entrevista, de un cliente sin nombre ni cita propia («Lo necesito y hoy no lo tengo.»). Se quedan sin sustento todos a la vez, no uno por uno; hace falta evidencia de demanda nueva | Óscar Ramírez |

### Lo que el negocio declara contra lo que los datos miden
- **volumen_mensual:** el caso de negocio (2026-05-06) declara 249.273; el tablero de producto (2026-10-12) mide 153.324. La declaración está 38,5 % por encima (umbral 20 %). Es una contradicción para el comité.

### Aceptado sin que nadie lo construya
- Los 10 requerimientos aceptados están **sin traza**: ninguno tiene proyecto (REQ-4600 a 4605, 4607, 4609, 4610, 4611). Es lo decidido que nadie está construyendo, o que no está registrado como construido.
- **REQ-4609** fue aceptado el 2026-03-24 sin ninguna evidencia de que alguien lo pidiera, y lleva 205 días así.
- **Sin criterio de aceptación:** REQ-4603, 4605, 4607 y 4611 (aceptados), y REQ-4608 (propuesto).
- **Sin doliente:** REQ-4601 no tiene dueño.

### Las trazas
Ninguna traza estaba declarada, así que no hay nada que confirmar ni nada que haya dejado de decirse. Revisé la carpeta de fichas `estado/records` (13 fichas, PRY-199 a PRY-211); la configuración no indica otra. Ninguna ficha cuenta como traza confirmada de PRD-306.

### Del descubrimiento
No relei documentos de descubrimiento ni de definición en esta corrida: las cifras salen del registro y de las métricas ya cargadas. No sé si hay entrevistas o tickets nuevos en la carpeta `documentos/productos/PRD-306`; revisar eso a mano con `/product-discovery`.

### Para el comité del 2026-11-12
Llevar solo: los tres requerimientos sin decidir, los diez aceptados sin proyecto (más REQ-4609 sin evidencia), la caída del 38,5 % del volumen contra lo declarado y el supuesto del proveedor. Lo demás va al anexo.

**Vuelvo el 2026-11-10.**
