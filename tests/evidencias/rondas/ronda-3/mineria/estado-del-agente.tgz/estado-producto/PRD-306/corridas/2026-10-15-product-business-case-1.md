# Corrida del 2026-10-15 · product-business-case

PRD-306 · 14 requerimientos · 43 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 10 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Caso de negocio armado: 1 cifra declarada (volumen 249.273) vs medida 153.324 (38,5 %, umbral 20 %); retorno sin cifra; ningún costo en ningún documento; criterio de éxito no declarado; sin otros productos publicados con las mismas cifras.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Almacén de repuestos (PRD-306) · borrador del 2026-10-15
**Desde:** la definición del 2026-05-06 y el caso de negocio del 2026-05-06 · **Cifras con fuente:** 1 de 1 (y esa una no coincide con lo medido)

Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado). Gerente de producto: Óscar Ramírez.

**Lo primero:** con lo que hay escrito esto es una propuesta, no un caso de negocio evaluable. No hay ningún costo en ningún documento, no hay criterio de éxito, y el único retorno declarado no tiene cifra.

## Qué problema resuelve, y para quién
- Problema: «El segmento Gerencia no tiene almacén de repuestos.» (`00-definicion/2026-05-06-definicion-producto.docx`, 2026-05-06)
- Para quién: Segmento Gerencia (misma fuente).
- Lo que lo sostiene: una sola entrevista, con un cliente sin nombre: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-10-14-entrevistas.docx`, 2025-10-14). Evidencia débil, de un solo entrevistado, y la entrevista no menciona el segmento. Cumple 12 meses, que es el umbral.

## Qué se construye
Entran los 10 requerimientos aceptados (acta del comité `30-decisiones/2026-10-10-comite-producto.docx`). Ninguno tiene proyecto que lo ejecute. Los 4 propuestos (4606, 4608, 4612, 4613) quedan fuera del alcance del caso hasta que se decidan; el comité es el 2026-11-12.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4600 | aceptado (2026-04-21) | «Cliente entrevistado» (entrevista 2025-10-14) |
| REQ-4601 | aceptado (2026-05-16) | «Cliente entrevistado»; sin doliente |
| REQ-4602 | aceptado (2026-05-07) | «Cliente entrevistado» |
| REQ-4603 | aceptado (2026-05-01) | «Cliente entrevistado»; sin criterio de aceptación |
| REQ-4604 | aceptado (2026-06-29) | «Cliente entrevistado» |
| REQ-4605 | aceptado (2026-06-08) | «Cliente entrevistado»; sin criterio de aceptación |
| REQ-4607 | aceptado (2026-07-26) | «Cliente entrevistado»; sin criterio de aceptación |
| REQ-4609 | aceptado (2026-03-24) | **Nadie lo pidió: sin cita** |
| REQ-4610 | aceptado (2026-05-30) | «Cliente entrevistado» |
| REQ-4611 | aceptado (2026-08-04) | «Cliente entrevistado»; sin criterio de aceptación |

Nueve de los diez se apoyan en la misma entrevista: es una sola fuente, no nueve.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 249.273 | Declarada | `00-definicion/2026-05-06-caso-de-negocio.md`, tabla «Cifras que sostienen el caso» (sin método de cálculo) | 2026-05-06 |
| volumen_mensual | 153.324 | Medida | `20-metricas/2026-10-12-tablero-metricas.md` (bodega de datos, tablero de producto) | corte 2026-10-12 |
| «Retorno esperado en 24 meses» | sin cifra | **Supuesta** (afirmada sin valor ni cálculo) | `00-definicion/2026-05-06-caso-de-negocio.md`, sección «Retorno esperado» | 2026-05-06 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 249.273 | 153.324 | caso-de-negocio.md 2026-05-06 · tablero-metricas.md corte 2026-10-12 |

La declarada está 38,5 % por encima de la medida; el umbral es 20 %. Reserva: la serie medida tiene un solo punto, y ningún documento define qué cuenta como «volumen» (`definition: not_found`). La diferencia es real entre los dos documentos; que ambos midan lo mismo no lo ha confirmado nadie. Además, las fechas están separadas por cinco meses: no es una comparación del mismo corte.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no encontrado** | Ningún documento: ni contrato, ni cotización, ni costo declarado del equipo |
| Costo de operar | **no encontrado** | Ningún documento |
| Costo del proveedor | **no encontrado** | Ningún documento nombra al proveedor |

No pongo ningún valor de referencia. El costo de construir es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-24, 205 días sin verificar; umbral 30) | No se puede decir con la información disponible: ningún documento nombra al proveedor ni el plazo pactado, así que el supuesto tal como está escrito es difícil de desmentir | Quien gestione al proveedor, con órdenes de compra y recepciones; sin doliente asignado |
| Las 249.273 transacciones mensuales del caso son alcanzables | El caso se apoya en un volumen 38,5 % por encima de lo medido | Quien produce el tablero de la bodega de datos, más Óscar Ramírez para el método de la cifra declarada |
| El problema lo tiene el segmento Gerencia | La demanda de todos los requerimientos descansa en una entrevista que no menciona segmento | Óscar Ramírez, con más entrevistas |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y de operar) | Sin él no hay caso que evaluar: hay una propuesta | Óscar Ramírez / quien tenga los contratos o la cotización del equipo |
| El valor del «Retorno esperado en 24 meses» y cómo se calculó | Hoy es una frase, no una cifra | El negocio (autor del caso: Óscar Ramírez) |
| Método de cálculo de 249.273 | Sin él no se puede reconciliar con 153.324 | Óscar Ramírez |
| Definición de «volumen_mensual» | Declarado y medido pueden no medir lo mismo | Dueño del tablero (bodega de datos) |
| Alternativas consideradas y qué pasa si no se hace | El comité no tiene contra qué comparar | Óscar Ramírez |
| Criterio de éxito | Sin él el producto no se puede cerrar meses después | Comité de producto (propuesto como autoridad por defecto; ningún documento dice quién decide) |
| Propuesta de valor (la sección dice solo «Propuesta principal») | No hay qué se ofrece | Óscar Ramírez |
| Proyecto que construye el producto («Ninguno declarado») | Los 10 decididos no tienen quién los construya | Comité de producto, ver `/product-trace` |
| Más de una fuente de demanda y evidencia posterior al 2025-10-14 | Hoy es una sola entrevista de hace 12 meses | Óscar Ramírez |
| País para la revisión normativa | No está declarado en la configuración; revisión jurídica pendiente | Quien configure el producto |

## Cómo se sabrá si funcionó
**No está declarado.** El criterio de éxito no existe en ningún documento. La única métrica con serie es volumen_mensual y no tiene meta ni fecha de corte futura. Hace falta una meta, su métrica y su fecha; el comité del 2026-11-12 es la ocasión natural.

## Si hay otros productos publicados
No hay ficha publicada de ningún otro producto a la vista. Revisé los documentos de PRD-299 a PRD-309: ninguno declara 249.273 ni nombra «Almacén de repuestos». Comparten el nombre genérico de la métrica `volumen_mensual`, pero sin cifras iguales no hay cruce que afirmar. Cuando haya fichas publicadas, conviene repetir con `/product-overlap`.

## Después
- Supuestos al seguimiento (assumption-tracking): los tres de arriba. El del proveedor lleva 205 días sin verificarse y se puede convertir en riesgo con doliente.
- `/product-charter`: todavía no corresponde. No hay criterio de éxito, ni autoridad declarada, ni costo.

Este documento no calcula rentabilidad ni periodo de recuperación y no recomienda aprobar ni rechazar: decide quien tiene la autoridad.
