## Registro — Almacén de repuestos (PRD-306) · al 2026-10-15
14 requerimientos · 10 decididos · 90% con evidencia · 0% con proyecto que lo ejecuta

*Nota: la carpeta de fichas de proyecto (`estado/`) está vacía, así que ningún requerimiento tiene proyecto confirmado. Los requerimientos no traen título propio (solo «Requerimiento 46xx»).*

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4609 | Requerimiento 4609 | aceptado (2026-03-24) | Diana Molina |

Sin una sola cita de quien lo pidió. Es el aceptado más antiguo del registro (205 días).

### Decidido y nadie lo está construyendo
Los 10 aceptados, ninguno con proyecto: REQ-4600, 4601, 4602, 4603, 4604, 4605, 4607, 4609, 4610 y 4611. Decididos entre el 2026-03-24 (REQ-4609) y el 2026-08-04 (REQ-4611). Ver `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4601 | Requerimiento 4601 | not_found (aceptado el 2026-05-16) |

Lo cerraría Óscar Ramírez, gerente del producto, asignando una persona.

### Sin criterio de aceptación
Solo los decididos:
| REQ | Título | Estado |
|---|---|---|
| REQ-4603 | Requerimiento 4603 | aceptado |
| REQ-4605 | Requerimiento 4605 | aceptado |
| REQ-4607 | Requerimiento 4607 | aceptado |
| REQ-4611 | Requerimiento 4611 | aceptado |

Los cierran sus dolientes: Ricardo Salas (4603), Carlos Peña (4605), Javier Hoyos (4607) y Paula Céspedes (4611). REQ-4608, propuesto, tampoco lo tiene, pero a un propuesto no se le exige.

### Decidido sin documento que lo respalde
| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-4601 | not_found | 2026-05-16 |
| REQ-4609 | not_found | 2026-03-24 |

Solo revisé estas dos fichas una por una; en las demás aceptadas no confirmé quién decidió. Todas citan el acta del comité del 2026-10-10 como fuente del estado, pero esa acta no dice quién decidió. Lo cierra el Comité de producto, dejando constancia.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4606 | Requerimiento 4606 | 195 días (2026-04-03) | Comité de producto |
| REQ-4612 | Requerimiento 4612 | 192 días (2026-04-06) | Comité de producto |
| REQ-4613 | Requerimiento 4613 | 176 días (2026-04-22) | Comité de producto |

El umbral es 60 días. El próximo comité es el 2026-11-12. Se propone decidirlos ahí; no se cierran por viejos. REQ-4606 y 4613 además no tienen evidencia, lo cual es normal en un propuesto.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4600, 4601, 4602, 4603, 4604, 4605, 4607, 4608, 4610, 4611, 4612 | Entrevista del 2025-10-14 | 12 meses |

Las 11 se apoyan en la misma entrevista: un cliente sin nombre ni cita propia, «Lo necesito y hoy no lo tengo.». Es una sola fuente, no once.

### Aparte, de la definición del producto
- El caso de negocio declara un volumen mensual de 249.273 (2026-05-06); el tablero de métricas mide 153.324 (2026-10-12): 38,5% por encima de lo medido, con un umbral de 20%.
- Supuesto sin verificar hace 205 días: «El proveedor cumple el tiempo pactado».

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 10 | 0 | 0 | 0 |

Después: hay 10 decididos sin construir, así que corresponde `/product-trace`. Para pasar a `/product-charter`, un aceptado debe tener evidencia y criterio. Cumplen eso REQ-4600, 4601, 4602, 4604 y 4610, aunque la evidencia es vieja.
