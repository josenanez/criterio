# Corrida del 2026-10-15 · product-charter

PRD-306 · 14 requerimientos · 40 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 10 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4600; sin firma ni ficha. Vacíos: quién aceptó, patrocinador, autoridad, criterio de éxito verificable, evidencia débil (1 entrevista, 12 meses), cifra de volumen 38,5 % sobre lo medido.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado; no se pidió de nuevo). Sesión sin interfaz: en cada pregunta se tomó la respuesta sugerida.

## Verificación previa (requirement-record) — REQ-4600

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | **Sí**: «aceptado desde 2026-04-21» (acta del comité, 2026-10-10). Pero **quién lo aceptó no está dicho** (`decision.who: not_found`): el acta solo dice «Se mantiene el plan» y su único asistente es Óscar Ramírez. |
| Criterios de aceptación | **Hay uno, pero no es verificable**: «se verifica en producción». No dice qué se mide, con qué umbral ni quién lo verifica. |
| Evidencia de demanda con cita | **Débil**: una entrevista del 2025-10-14, de un «Cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo.» Es anterior a la aceptación del REQ y tiene 12 meses (umbral 12). El REQ no declara la necesidad (`need: not_found`). |
| Autoridad declarada en la definición | **Falta.** Ningún documento dice quién decide; «Comité de producto» es una propuesta por defecto. |

Respuesta sugerida tomada: seguir marcando cada falta como vacío del acta, sin rellenarla.

---

# Acta de constitución — Almacén de repuestos · borrador del 2026-10-15
**Producto:** PRD-306 · Almacén de repuestos · **Requerimientos:** REQ-4600

## Qué problema resuelve
«El segmento Gerencia no tiene almacén de repuestos.» (`00-definicion/2026-05-06-definicion-producto.docx`, 2026-05-06). Para quién: Segmento Gerencia (misma fuente). La única entrevista no menciona segmento.

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `30-decisiones/2026-10-10-comite-producto.docx`, 2026-10-10 | **No está dicho.** Sin métrica, umbral ni responsable. |

El criterio de éxito del producto tampoco está declarado en la definición (`success: not_found`). Ver vacíos.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | Requerimiento 4600 (el acta no le da otro título) | Entrevista del 2025-10-14, «Lo necesito y hoy no lo tengo.», cliente sin nombre, citado según el acta. Una sola fuente; débil. Doliente del REQ: Andrés Lozano (acta del comité, 2026-10-10). |

### No entra
Razón común: el acta se pidió solo para REQ-4600; nadie ha decidido incluir los demás. Ninguno está en un proyecto (`Proyecto que lo ejecuta: —`).

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4601 | Requerimiento 4601 | No pedido; además aceptado sin doliente («sin asignar») |
| REQ-4602 | Requerimiento 4602 | No pedido; doliente Natalia Ospina |
| REQ-4603 | Requerimiento 4603 | No pedido; sin criterio de aceptación |
| REQ-4604 | Requerimiento 4604 | No pedido; doliente Ricardo Salas |
| REQ-4605 | Requerimiento 4605 | No pedido; sin criterio de aceptación |
| REQ-4606 | Requerimiento 4606 | Está **propuesto**, no aceptado; sin evidencia de quién lo pidió |
| REQ-4607 | Requerimiento 4607 | No pedido; sin criterio de aceptación |
| REQ-4608 | Requerimiento 4608 | Está **propuesto**; sin criterio de aceptación |
| REQ-4609 | Requerimiento 4609 | No pedido; sin evidencia de quién lo pidió |
| REQ-4610 | Requerimiento 4610 | No pedido; doliente Rubén Cárdenas |
| REQ-4611 | Requerimiento 4611 | No pedido; sin criterio de aceptación |
| REQ-4612 | Requerimiento 4612 | Está **propuesto**, no aceptado |
| REQ-4613 | Requerimiento 4613 | Está **propuesto**; sin evidencia de quién lo pidió |

Fuente de todas las filas: `30-decisiones/2026-10-10-comite-producto.docx`, 2026-10-10.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. El gerente de **producto** es Óscar Ramírez (definición, 2026-05-06); el gerente del **proyecto** no se nombra aquí: lo asigna quien tiene la autoridad.
- **Comité:** Comité de producto, propuesta por defecto (ningún documento lo confirma como quien decide). Próxima reunión: 2026-11-12 (configuración).
- **Autoridad del gerente:** no está dicho. Es el campo que más cuesta después.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-03-24; definición, 2026-05-06) | No. 205 días sin verificar (umbral 30). Ningún documento nombra proveedor ni plazo. | **Sin doliente**: lo asigna quien firme el acta. Registrar con raid-taxonomy. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Nada identificado en la definición (sin datos personales, pagos, consumidor financiero ni retención) | — | — | País no declarado en la configuración. No es un cumplimiento ni una ausencia de obligaciones: revisión jurídica pendiente. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4600 (`decision.who`) | La decisión de construir no tiene responsable; el acta se apoya en «Se mantiene el plan» | Gerente de producto (Óscar Ramírez) con el Comité |
| Autoridad que decide / autoridad del gerente | El gerente del proyecto no sabrá qué puede decidir: escala todo o no escala nada | Quien firme el acta |
| Patrocinador | Nadie responde por el presupuesto ni por destrabar | Quien firme el acta |
| Criterio de éxito verificable (producto y REQ) | El cierre no se podrá juzgar meses después contra nada medible | Gerente de producto con Andrés Lozano |
| Necesidad del REQ (`need: not_found`) | No se sabe qué pidió exactamente quien lo pidió | Gerente de producto |
| Evidencia de demanda: una sola entrevista, sin nombre, de hace 12 meses | La demanda descansa en una voz; los 9 REQ con evidencia son una fuente, no nueve | Gerente de producto (nueva ronda de entrevistas) |
| Cifra del caso de negocio: volumen mensual declarado 249.273 vs. medido 153.324 (38,5 % por encima; umbral 20 %; tablero 2026-10-12). El tablero no define «volumen» y la serie tiene un solo punto | Cualquier presupuesto o retorno apoyado en 249.273 arranca sobre una cifra que los datos no sostienen | Gerente de producto |
| «Retorno esperado en 24 meses» sin cifra ni cálculo | No hay línea base de retorno | Gerente de producto |
| Propuesta de valor vacía («Propuesta principal») | No se sabe qué se va a construir | Gerente de producto |
| Presupuesto e hitos | No declarados en ningún documento; el acta no los inventa ni lleva cronograma | Quien firme / gerente del proyecto |
| Proyecto que lo construye | La definición dice «Ninguno declarado» | Quien asigne gerente |

---
**Esto es un borrador.** Lo firma **quien tenga la autoridad para hacerlo: no está dicho en ningún documento**. La ficha del proyecto se crea después de la firma. **No se ha creado ficha** (`portafolio.py init` no se corrió) y no se escribió estado declarado.

Con tantos vacíos de gobierno, mi recomendación es no firmar hasta cerrar al menos: quién aceptó, patrocinador, autoridad y un criterio de éxito verificable.

## Después
Cuando haya acta firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella, y desde ahí Alba se entera de si su producto se está construyendo sin preguntarle a nadie.
