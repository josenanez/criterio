# Corrida · 2026-10-15-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T18:13:19 · **Fin:** 2026-10-15T18:14:26 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 14 | — | 46 | 31 | Primera revisión: 14 REQ, 29 señales, todas nuevas por no haber corte previo. Trazas leídas de estado/records (13 fichas), ninguna confirmada. No releí documentos de descubrimiento; no sé si hay material nuevo. |

Por señal (`product-wake`): `evidence_stale` 11, `requirement_untraced` 10, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

## Almacén de repuestos (PRD-306) · 2026-10-15

Esta fue la primera revisión del registro. No había corte anterior, así que las 31 señales abiertas cuentan como nuevas. Desde la próxima corrida solo se reportará lo que cruce un umbral después de hoy.

**Términos:** ya estaban vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15. No hubo nada que registrar.

### Cruzó un umbral sin que nadie hiciera nada
- **Tres requerimientos sin decidir** (umbral 60 días). La facultad de decidirlos es del Comité de producto, que se reúne el 2026-11-12.
  - REQ-4606 lleva 195 días (Óscar Ramírez).
  - REQ-4612 lleva 192 días (Mauricio Pérez).
  - REQ-4613 lleva 176 días (Ricardo Salas).
- **Supuesto «El proveedor cumple el tiempo pactado»:** lleva 205 días sin verificar (umbral 30). Verificarlo exige el historial de entregas del proveedor contra el plazo pactado. Ya pasó el punto en que conviene registrarlo como riesgo.
- **Evidencia vencida en 11 requerimientos:** todos se apoyan en la misma entrevista, de un cliente sin nombre, del 2025-10-14. Esa evidencia cumplió 12 meses ayer, así que todos se quedan sin sustento a la vez.

### Contradicción entre lo declarado y lo medido
El caso de negocio declara un volumen mensual de 249.273. El tablero de producto mide 153.324. La declaración queda 38,5 % por encima (umbral 20 %).

### Aceptado sin que nadie lo construya
- **Sin traza:** los 10 requerimientos aceptados no tienen proyecto.
- **REQ-4609:** se aceptó sin evidencia de que alguien lo pidiera.
- **Sin criterio de aceptación:** REQ-4603, 4605, 4607 y 4611.
- **Sin doliente:** REQ-4601.

### Las trazas
Ninguna traza estaba declarada, así que no hay nada que confirmar. La configuración no indica dónde están las fichas de proyecto. Leí `estado/records` (13 fichas) por mi cuenta, y ninguna dice ejecutar PRD-306.

### Del descubrimiento
No releí documentos de descubrimiento ni de definición en esta corrida, así que no sé si hay material nuevo. Hay que revisarlo a mano con `/product-discovery`.

Tras registrar la corrida corregí «29» por «31» señales en el archivo de salida. La cifra inicial estaba mal y la del script es la correcta. El archivo ya había quedado registrado como evidencia de la corrida, así que ese registro puede no coincidir con su contenido final.

Registré la revisión, tomé el corte (`snapshots/2026-10-15.json`) y guardé la corrida `2026-10-15-product-wake-1` (46 segundos). La salida completa está en `estado-producto/PRD-306/corridas/salida-product-wake.md`.

**Vuelvo el 2026-11-10.**
