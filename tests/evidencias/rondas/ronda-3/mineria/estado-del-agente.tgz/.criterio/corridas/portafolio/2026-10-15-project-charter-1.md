# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-15T18:04:21 · **Fin:** 2026-10-15T18:05:02 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 26 | 63 | Revisión del acta de PRY-200: faltan autoridad del gerente, objetivo medible, alcance descrito, exclusión con proyecto nombrado, criterio de éxito medible y quién lo mide, supuestos, cadencia e hitos. No se sabe nada de lo hablado fuera de los dos documentos; no se completó ningún campo. |

Por señal (`project-charter`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Revisé el acta de PRY-200 (Mantenimiento predictivo de camiones, del 2026-03-23) y le faltan los campos de gobierno que importan. Los términos estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrar nada nuevo. Corrí el modo revisar con solo dos documentos: el acta y el informe de avance del 2026-10-14.

**Qué falta y qué consecuencia tiene**

| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | Ausente | Todo ajuste de alcance o presupuesto sube al Comité de Operaciones. La proyección al cierre (9.776.375.957 COP) ya supera lo aprobado (9.500.000.000 COP) en 276.375.957 COP (+2,9 %), y no se puede saber si Rubén Cárdenas puede absorberlo. |
| Objetivo de negocio | Es la solución repetida, sin problema que resolver | No hay base para decidir si el proyecto vale su costo cuando se retrasa. |
| Alcance | "Componente 1, 2 y 3" sin descripción | No se distingue un cambio de alcance de una aclaración. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar cuál | Si dos proyectos construyen lo mismo, nadie lo ve. |
| Criterio de éxito | "En producción y medido", sin métrica ni quién mide | El cierre queda a discreción de quien lo declare. |
| Supuestos, restricciones y cadencia del comité | Ausentes | El acta no registra al proveedor sin fecha de última entrega, que el informe ya menciona como riesgo. |
| Hitos | Solo inicio (2026-04-02) y cierre (2027-03-24) | El 42 % de avance declarado no se puede contrastar con nada. |

Patrocinador (Laura Vélez), gerente (Rubén Cárdenas), presupuesto y fechas sí están.

Los campos que faltan quedaron marcados como pendientes de definir; no completé ninguno.

**Siguientes pasos que ofrezco**
- **Autoridad del gerente:** llevar esa definición al Comité de Operaciones, que según la configuración se reúne el 2026-10-19. Se puede preparar con `/criterio-portfolio:steering-pack`.
- **Supuestos:** pasar los que salieron de la revisión al registro RAID con `/criterio-portfolio:raid-log`.

La corrida quedó registrada como `2026-10-15-project-charter-1`, con el texto completo en `salida-project-charter.md`. Dos cosas de ese registro:
- La corrida figura sobre 13 proyectos aunque el caso es PRY-200.
- Los 63 hallazgos que lista son señales abiertas de todo el portafolio, no de esta revisión. Para PRY-200 no lista ninguno.

Archivos (dentro de `/home/claude/banco/ronda-3/mineria/espacio/estado/corridas/`):
- `salida-project-charter.md`
- `2026-10-15-project-charter-1.md`
