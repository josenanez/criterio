# Corrida · 2026-10-15-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-15T17:55:43 · **Fin:** 2026-10-15T17:56:28 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 27 | 63 | Informe de PRY-204: verde declarado contradicho por seis señales abiertas. Dijo que no sabe la última reunión, autoridad, fase, evidencia de hitos ni datos de riesgos. |

Por señal (`status-report`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

## PRY-204 Monitoreo de taludes — estado al 2026-10-15

El proyecto reporta verde, pero los documentos no lo sustentan. Salgo de la ficha `estado/records/PRY-204.json`, actualizada el 2026-10-15. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Declara el gerente (Ricardo Salas):** verde, 27%, al 2026-09-27 (hace 18 días).
**Sustento documental:** contradicho. Seis señales abiertas no están explicadas por ese verde:
- Dos hitos marcados como cumplidos sin evidencia.
- Un hito vencido.
- Avance por debajo de lo que el plan soporta.
- Silencio documental.
- Entregables del proveedor atrasados.
- Facturación sin entrega.

**Último documento:** 2026-09-29, hace 16 días. Pasa el umbral de 15.
**Última reunión:** sin dato, porque no hay minutas ni transcripciones en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-12 | 2027-01-12 | 0 días |
| Presupuesto aprobado | COP 1.200.000.000 | COP 1.200.000.000 | Proyección COP 1.183.123.627 (-1,4%) |

No hay replanificaciones ni solicitudes de cambio. Se ha ejecutado el 48,1% del presupuesto frente a un avance declarado de 27%. Lo comprometido es 33,6% (COP 403.511.534) y el disponible real es COP 796.488.466.

### Hitos
| Hito | Base y vigente | Estado | Evidencia |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-07-10 | Cumplido (declarado) | Ninguna |
| Ingeniería de detalle aprobada | 2026-08-26 | Cumplido (declarado) | Ninguna |
| Licencia y permisos obtenidos | 2026-10-11 | Vencido hace 4 días | Ninguna |
| Montaje e instalación | 2026-11-27 | Pendiente | Ninguna |
| Pruebas en operación | 2027-01-12 | Pendiente | Ninguna |

Con 2 hitos de 5 cumplidos, el plan soporta entre 40% y 60% de avance. El gerente declara 27%, 13 puntos por debajo.

### Dónde no coincide
- **Facturado sin entrega.** Montajes Industriales Ltda. facturó COP 133.892.409 (CT-594) y COP 120.184.897 (CT-331). Ningún entregable de los dos contratos está aceptado.
- **Entregables vencidos:**
  - CT-331, licenciamiento del software: vencido hace 92 días.
  - CT-594, licenciamiento del software: vencido hace 58 días.
  - CT-331, bolsa de horas de ingeniería: vencida hace 41 días.
- **Licencia y permisos.** El hito venció y el informe lista el riesgo de cambio en la licencia ambiental, sin probabilidad, impacto, responsable ni fecha.

### Abierto
- **Riesgos sin fecha de último movimiento (no puedo calcular los días):** cambio en la licencia ambiental y bloqueo de la vía de acceso a la mina.
- **Compromisos vencidos y dependencias:** ninguno registrado, pero tampoco hay minutas que los sustenten.

### Sin dato
- Autoridad de aprobación y fase del proyecto.
- Última reunión y compromisos.
- Documentos de evidencia de los hitos.
- Datos de los riesgos: probabilidad, impacto, responsable y fecha.
- El comprometido (COP 403.511.534) es menor que el ejecutado (COP 577.323.500). Es atípico y hay que confirmarlo con el gerente; no lo corregí.

Si quiere, preparo el punto de comité con la decisión sobre los pagos a Montajes Industriales. El próximo comité es el 2026-10-19.

La salida completa quedó en `estado/corridas/salida-status-report.md` y la corrida en `estado/corridas/2026-10-15-status-report-1`.

---
Criterio Portfolio v0.3.9 · ficha de PRY-204 del 2026-10-15 · campos inciertos: autoridad y fase · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
