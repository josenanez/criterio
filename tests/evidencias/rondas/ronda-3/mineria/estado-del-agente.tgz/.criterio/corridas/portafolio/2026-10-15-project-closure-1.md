# Corrida · 2026-10-15-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-209

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-15T18:05:07 · **Fin:** 2026-10-15T18:05:56 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 32 | 63 | No se genero acta de cierre: PRY-209 sigue en ejecucion (52% declarado, Amarillo, 2026-10-14). Se entrego el contraste contra lo comprometido; no se pudo determinar cumplimiento del criterio de exito, hitos sin evidencia, discrepancia de fecha acta 2026-06-11 vs cronograma 2026-05-07, sin lecciones sustentables, sin doliente del riesgo. |

Por señal (`project-closure`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Corrí `/project-closure` sobre PRY-209 y no generé el acta de cierre, porque el proyecto no está cerrado. El informe del 2026-10-14 lo declara en ejecución: estado Amarillo, 52 % de avance, y el montaje se detuvo diez días por lluvias. Ningún documento declara que terminó.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-15), así que no los registré de nuevo. Las cifras salen de `portafolio.py compute`, y el análisis completo está en `estado/corridas/salida-project-closure.md`.

- **Criterio de éxito:** el acta pide «Electrificación de equipos en producción y medido». No hay evidencia de producción ni de medición, y no se puede determinar si se cumplió. Los Componentes 1, 2 y 3 no tienen descripción en el acta.
- **Hitos:** los tres están marcados como cumplidos sin evidencia de aprobación (301, 231 y 161 días de antigüedad). El plan sostiene 100 % y el avance declarado es 52 %, una diferencia de 48.0 puntos. Los tres hitos no cubren la obra física, así que ese 100 % no mide el proyecto.
- **Fechas:** el acta fija el cierre en 2026-06-11 y el cronograma en 2026-05-07. Esa discrepancia no está registrada como conflicto. Hay 0 replanificaciones, pero el proyecto ya superó ambas fechas.
- **Presupuesto:** de 800.000.000 COP aprobados hay 387.174.080 comprometidos (48.4 %) y 165.491.322 ejecutados (20.7 %). La proyección al cierre es 760.039.075 COP, un −5.0 % frente a lo aprobado.
- **RAID:** el riesgo «Concentración del conocimiento en una sola persona» no tiene doliente, así que no está cerrado. Hay dos compromisos abiertos del comité: Liliana Torres, «punto 9», sin fecha, y Rubén Cárdenas, «punto 14», para el 2026-10-15.
- **Lecciones:** ninguna se puede sustentar. La única con un hecho anclado son las lluvias, y el informe no dice cuándo ni qué efecto tuvieron.
- **Archivo:** no moví la carpeta a `archivo/` ni congelé la ficha, porque el proyecto sigue activo. Para cerrarlo, Sandra Gil y Camilo Beltrán tendrían que declararlo contra el criterio de éxito, o el comité tendría que decidir un cierre por decisión. Después se corre el comando otra vez.

La corrida quedó registrada como `2026-10-15-project-closure-1`, con la salida adjunta. El tiempo medido fue de 32 segundos.
