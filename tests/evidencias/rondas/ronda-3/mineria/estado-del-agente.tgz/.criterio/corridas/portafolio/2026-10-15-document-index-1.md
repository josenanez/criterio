# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T17:54:53 · **Fin:** 2026-10-15T17:55:36 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 28 | 63 | 80 documentos sin cambio, 0 por releer; 11 citas de PRY-203 (pm_record) sin resolver por ruta sin carpeta de proyecto; el archivo existe. No se corrigió ninguna ficha. No se verificó el contenido de los documentos, solo hashes. |

Por señal (`document-index`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

No hay documentos nuevos, cambiados, reguardados, renombrados ni borrados, y el índice no reportó formatos ilegibles. No hace falta `/portfolio-scan`.

**Citas que dejaron de resolver:** hay 11, todas de PRY-203, en los campos `pm_record.identity.{code, name, business_area, product, sponsor, manager, committee}`, `pm_record.plan.{start_date, end_date}` y `pm_record.money.{currency, approved}`. Todas citan `00-gobierno/2025-09-21-acta-constitucion.md`.

El acta no se borró ni se renombró. Está en `PRY-203-despacho-automático-de-flota/00-gobierno/2025-09-21-acta-constitucion.md`. La sección `pm_record` de la ficha la cita sin la carpeta del proyecto, y el resto de la ficha sí la cita completa. El fallo está en la cita, no en el documento.

No corregí nada. Propongo cambiar las 11 citas a la ruta completa, una por una y mostrando el cambio, si lo aprueban.

**Términos:** ya estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Corrida:** quedó registrada como `2026-10-15-document-index-1`, con la salida guardada en `estado/corridas/salida-document-index.md`. Tardó 28 segundos. El registro no recoge el número de documentos leídos, porque este comando solo cuenta y compara hashes.
