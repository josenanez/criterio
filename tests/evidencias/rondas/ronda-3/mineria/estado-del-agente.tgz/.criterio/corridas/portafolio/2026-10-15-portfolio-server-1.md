# Corrida · 2026-10-15-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T18:11:16 · **Fin:** 2026-10-15T18:11:51 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 63 | puerto 8787, informe reportes/, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Rostrum está corriendo en modo «para mirarlo un rato», en `http://127.0.0.1:8788/`. El puerto 8787 ya estaba ocupado, así que usé el 8788.

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No hizo falta registrarlos otra vez.
- **Qué sirve:** el informe de `reportes/`, que cubre 13 proyectos (PRY-199 a PRY-211) y 6 productos. No hay peticiones abiertas.
- **Rutas:**
  - `/` es la portada.
  - `/pmo` es el informe de la PMO.
  - `/decisiones` es para el comité.
  - `/proyectos` y `/productos` son los listados.
  - `/corridas` muestra las corridas registradas.
  - `/estado.json` da la fecha del informe.
- **`/pmo`:** en `reportes/` no hay `pmo.html`. Puede que esa ruta salga vacía hasta que se corra `/portfolio-report html`. No la abrí para comprobarlo.
- **Solo en este equipo:** el enlace no sirve para el patrocinador. Para darle uno estable hay que pasar a «que quede corriendo» (`--abierto`). Eso exige pedir a la organización un host, un puerto y su control de acceso, porque el servidor no autentica.
- **Cuándo se desactualiza:** el informe es del 2026-10-15 y queda viejo en cuanto cambie la documentación.
- **Para pararlo:** el servidor está en segundo plano. Se detiene matando su proceso, y el registro está en `/tmp/claude-0/rostrum.log`.
- **Corrida registrada:** la salida está en `estado/corridas/salida-portfolio-server.md` y la corrida quedó como `2026-10-15-portfolio-server-1`.
