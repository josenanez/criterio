# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-15T17:58:15 · **Fin:** 2026-10-15T17:59:06 · **Duración:** 51 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 32 | 63 | Presupuesto de PRY-201: proyección 17.1% sobre el aprobado, comprometido 41.3%, ejecutado 33.3%. Las cuatro cifras salen solo del informe del gerente; sin respaldo contable, sin detalle por proveedor, y estado verde sin sustento. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

## Presupuesto de PRY-201 Ampliación de la relavera, al 2026-10-15

La proyección al cierre supera el presupuesto aprobado en 17.1%, y el umbral de alerta es 10%. El informe del gerente declara el proyecto en verde, y la evidencia no lo sostiene.

Los términos ya estaban vigentes (versión 0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Moneda:** COP. La ficha no tiene contratos de proveedor, así que no hay otra moneda que separar.

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | — | Acta de constitución e informe de avance | 2025-12-04 / 2026-10-14 |
| Comprometido | 1.362.087.354 | 41.3% | Informe de avance | 2026-10-14 |
| Ejecutado | 1.097.802.366 | 33.3% | Informe de avance | 2026-10-14 |
| Proyección al cierre | 3.863.518.362 | 17.1% por encima del aprobado | Informe de avance | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): 1.937.912.646 COP.

- **Contra la línea base:** original y vigente coinciden en 3.300.000.000. La desviación es 0, con 0 replanificaciones y 0 solicitudes de cambio. Solo existe la versión 1 de la línea base.
- **Ejecución frente a avance:** el ejecutado es 33.3%, hay 2 de 4 hitos cumplidos y el avance declarado es 57%. La ejecución va por debajo del avance. El informe dice que el proveedor entregó los equipos y están pendientes de aceptación, así que puede haber una causación por venir. Es una hipótesis que ningún documento confirma.
- **Alertas:**
  - La proyección excede el aprobado y no hay solicitud de cambio registrada.
  - El hito "Licencia y permisos obtenidos" venció el 2026-10-14.
  - El compromiso de Paula Céspedes ("Entregar el punto 19") venció el 2026-10-05, hace 10 días.
  - El comprometido está en 41.3%, lejos del umbral de 90%.
- **Sin dato:**
  - Las cuatro cifras salen solo del informe del gerente. No hay respaldo contable ni facturas, y el acta solo respalda el aprobado.
  - La proyección es una declaración y no dice cómo se calculó. Su fecha es posterior a la aprobación del presupuesto, que es el único movimiento registrado.
  - No hay detalle por proveedor, porque la ficha no registra proveedores para PRY-201.
  - Faltan en la ficha el producto, la autoridad y la fase del proyecto.

**Siguiente paso:** puedo preparar la solicitud de cambio con `/criterio-portfolio:change-control`, porque la proyección excede el aprobado. No ofrezco el detalle por proveedor, porque el comprometido no está cerca del tope.

La corrida quedó registrada con el id `2026-10-15-budget-tracking-1`. Tardó 32 segundos sobre el caso PRY-201. El texto completo está en `estado/corridas/salida-budget-tracking.md`.

*Borrador de trabajo, no decisión ni asesoría. Cada cifra sale del documento citado y la verificación es suya. Criterio no sabe lo que se habló fuera de los documentos.*
