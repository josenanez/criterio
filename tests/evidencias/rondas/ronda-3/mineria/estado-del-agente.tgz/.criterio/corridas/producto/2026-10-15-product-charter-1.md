# Corrida · 2026-10-15-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4600

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4600

**Inicio:** 2026-10-15T17:36:06 · **Fin:** 2026-10-15T17:37:03 · **Duración:** 57 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 14 | — | 40 | 31 | Borrador de acta para REQ-4600; sin firma ni ficha. Vacíos: quién aceptó, patrocinador, autoridad, criterio de éxito verificable, evidencia débil (1 entrevista, 12 meses), cifra de volumen 38,5 % sobre lo medido. |

Por señal (`product-charter`): `evidence_stale` 11, `requirement_untraced` 10, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4600 del producto PRD-306 (Almacén de repuestos), sin firma y sin ficha de proyecto. El acta tiene muchos vacíos de gobierno. Mi recomendación es no firmarla hasta cerrar al menos cuatro: quién aceptó el requerimiento, el patrocinador, la autoridad y un criterio de éxito verificable.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los volví a registrar.

REQ-4600 pasa dos de las cuatro verificaciones previas solo en parte. En cada una tomé la respuesta sugerida, que es seguir y marcar el vacío sin rellenarlo.
- **Aceptación:** consta como aceptado desde 2026-04-21, pero ningún documento dice quién lo aceptó. El acta del comité solo dice «Se mantiene el plan».
- **Criterio de aceptación:** el único es «se verifica en producción». No dice qué se mide, con qué umbral ni quién lo verifica.
- **Evidencia de demanda:** es una sola entrevista de hace 12 meses, de un cliente sin nombre. El requerimiento tampoco declara la necesidad.
- **Autoridad:** ningún documento dice quién decide. «Comité de producto» es solo una propuesta por defecto.

Otros puntos que quedan en el borrador:
- **Alcance:** entra solo REQ-4600. Los otros 13 requerimientos quedan fuera, cada uno con su razón.
- **Supuesto del proveedor:** «El proveedor cumple el tiempo pactado» lleva 205 días sin verificar y nadie lo tiene a cargo. Pasa al proyecto como riesgo sin doliente.
- **Cifra del caso de negocio:** declara 249.273 de volumen mensual y el tablero mide 153.324, un 38,5 % menos.
- **Faltan** patrocinador, presupuesto, hitos, propuesta de valor y proyecto que lo construya. El «retorno esperado en 24 meses» no trae cifra ni cálculo.
- **Normativa:** no identifiqué nada, pero el país no está declarado, así que queda pendiente la revisión jurídica.

No corrí `portafolio.py init`, así que no existe ficha, y no escribí estado declarado. Cuando haya acta firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

Registré la corrida (id `2026-10-15-product-charter-1`, 40 s, 31 señales abiertas sobre 14 requerimientos).

Archivos en `estado-producto/PRD-306/corridas/`:
- `salida-product-charter.md`
