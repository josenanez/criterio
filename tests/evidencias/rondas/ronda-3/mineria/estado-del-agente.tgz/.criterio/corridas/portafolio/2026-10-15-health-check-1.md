# Corrida · 2026-10-15-health-check-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:health-check PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-15T17:56:34 · **Fin:** 2026-10-15T17:58:09 · **Duración:** 95 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `health-check` | 13 | — | 78 | 63 | Diagnóstico de PRY-202 sobre 6 documentos: 3 afirmaciones sostenidas, 7 sin sustento, 4 contradichas. Dijo que no sabe: si el 77% y el dinero comprometido/ejecutado son reales (sin recibos ni facturas), quién aprobó la v2 y CC-01 (sin autoridad ni acta), qué incluye la ampliación de alcance, y qué permiso se recibió. Los .docx se leyeron desde el caché convertido. |

Por señal (`health-check`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

Diagnóstico de PRY-202 (Planta de tratamiento de agua) terminado y corrida registrada: `2026-10-15-health-check-1`.

Las afirmaciones del proyecto quedan así: 3 sostenidas, 7 sin sustento y 4 contradichas.

- **Estado y avance:** el informe declara verde y 77 %, pero ningún hito tiene evidencia de cumplimiento y el plan solo sostiene entre 0 y 33 %. Además hay un hito vencido 13 días (Ingeniería básica, 2026-10-02), un compromiso vencido 7 días y una desviación de +88 días (17,2 %) contra la línea base original.
- **Gobierno:** el patrocinador es Sandra Gil y la gerente es Elena Duarte, pero ningún documento declara la autoridad de la gerente. La replanificación v2 no trae motivo ni aprobación.
- **Cambio CC-01:** dice «autorizada por el comité», pero no hay acta que lo respalde. Su «+88 días sobre la vigente» choca con la v2, que ya incluye esos 88 días.
- **Cierre del acta:** el cierre comprometido (2027-12-03) cae antes de la fecha vigente de Licencia y permisos (2027-12-05).
- **Dinero:** todas las cifras salen del informe. La carpeta no tiene contratos, facturas ni actas de recibo para contrastarlas.

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez. Los dos .docx los leí desde el texto convertido en caché, no desde el original. El tiempo de la corrida (78 segundos) está medido. El número de documentos no se pudo medir, así que quedó vacío en el registro.

No recomiendo continuar, detener ni reestructurar, porque eso lo decide quien tiene la facultad. Puedo llevar las 4 contradicciones a Elena Duarte como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.

Archivos en `/home/claude/banco/ronda-3/mineria/espacio/estado/corridas/`:
- salida-health-check.md
- 2026-10-15-health-check-1.md (nombre inferido del `id` de la corrida; no lo verifiqué)
