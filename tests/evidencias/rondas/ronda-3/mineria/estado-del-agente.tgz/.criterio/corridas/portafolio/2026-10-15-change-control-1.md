# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-204 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-15T18:00:12 · **Fin:** 2026-10-15T18:01:10 · **Duración:** 58 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 42 | 63 | Solicitud de mover 30 días la salida a producción de PRY-204. Impacto en portafolio: 0 proyectos alcanzados, sin dependencias declaradas. No se sabe: quién pide y por qué, cuál es la fecha de cierre (acta 2027-02-05 contra cronograma 2027-01-12), el costo de un mes más, ni la autoridad de cambio (no declarada). Sin línea base nueva: nadie con autoridad la ha aprobado. |

Por señal (`change-control`): `milestone_met_without_evidence` 13, `commitment_overdue` 8, `progress_vs_plan` 7, `declared_vs_evidence` 6, `milestone_overdue` 5, `commitment_undated` 5, `variance_time` 4, `vendor_deliverable_late` 4, `commitment_rescheduled` 3, `vendor_invoiced_without_delivery` 2, `rebaseline_unauthorized` 2, `variance_cost` 1, `change_without_baseline` 1, `pm_vs_pmo` 1, `silent` 1

## Lo que el agente mostró

**Solicitud de cambio PRY-204 (Monitoreo de taludes): mover 30 días la salida a producción.** Esto sale de la ficha de PRY-204 y del cálculo de impacto del script `portafolio.py impact`.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15, y no hubo que registrarlos de nuevo.

- **Dos fechas de cierre:** el acta dice 2027-02-05 y el cronograma v1, que la ficha usa como línea base 1, dice 2027-01-12.
  - Desde el cronograma, el cierre pasaría a 2027-02-11. Desde el acta, a 2027-03-07.
  - La ficha no tiene este conflicto abierto.
- **Efecto en el portafolio:** el cálculo no alcanza a ningún proyecto. Eso solo significa que nadie declaró depender de PRY-204: el acta dice «Ninguna declarada». No prueba que nadie dependa.
- **Hitos por los que pasa el cambio:** *Montaje e instalación* (2026-11-27) y *Pruebas en operación* (2027-01-12). No se puede decir cuántos días se mueve cada uno, porque la ficha no tiene holgura por actividad.
- **Costo:** la proyección de 1.183.123.627 COP deja solo 16.876.373 COP de margen frente a los 1.200.000.000 aprobados. No hay en la carpeta una cifra de lo que cuesta un mes más, así que no la calculé.
- **Quién decide:** la autoridad no está declarada en el acta. Lo llevo al Comité de Tecnología, que aprobó la línea base original. El próximo comité semanal es el 2026-10-19.
- **Línea base nueva:** no la registré, porque nadie con autoridad aprobó el cambio. Cuando se apruebe, la 1 queda intacta.

No sé quién pide el cambio, por qué, ni qué hito exacto significa «salida a producción». Lo leí como *Pruebas en operación*, el hito de cierre.

El informe del 2026-09-27 dice que se recibió el permiso ambiental, pero el cronograma sigue mostrando *Licencia y permisos obtenidos* (2026-10-11) en curso y vencido.

La corrida quedó registrada como `2026-10-15-change-control-1`. El texto completo de la solicitud está en `estado/corridas/salida-change-control.md`.
