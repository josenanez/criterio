# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-04-22
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 108.292 | Caso de negocio, 2026-04-22 |

## Retorno esperado

Retorno esperado en 24 meses.
