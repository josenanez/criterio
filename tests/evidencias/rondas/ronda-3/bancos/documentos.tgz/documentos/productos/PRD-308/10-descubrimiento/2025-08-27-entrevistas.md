# Entrevistas · Cuenta de ahorros joven

**Ronda:** Ronda · 2025-08-27
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2025-08-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
