# Comité de producto · Remesas familiares

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-31 | — |
| REQ-4701 | Requerimiento REQ-4701 | Camilo Beltrán | — | Cliente entrevistado | propuesto | 2026-07-27 | — |
| REQ-4702 | Requerimiento REQ-4702 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-03-21 | — |
| REQ-4703 | Requerimiento REQ-4703 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4704 | Requerimiento REQ-4704 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4705 | Requerimiento REQ-4705 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-02 | — |
| REQ-4706 | Requerimiento REQ-4706 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-23 | — |
| REQ-4707 | Requerimiento REQ-4707 | Diana Molina | — | — | aceptado | 2026-08-23 | — |
| REQ-4708 | Requerimiento REQ-4708 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-06-02 | — |
| REQ-4709 | Requerimiento REQ-4709 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4710 | Requerimiento REQ-4710 | Jorge Medina | se verifica en producción | — | aceptado | 2026-05-14 | — |
| REQ-4711 | Requerimiento REQ-4711 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-14 | — |

## Decisiones

- Se mantiene el plan
