# Tablero de métricas · Nómina empresarial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 201.716 | 2026-09-29 |
