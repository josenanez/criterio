# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Paula Céspedes
**Segmento:** Personas
**Fecha de la definición:** 2026-02-27

## El problema

El segmento Personas no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-05-16 · verificado

## Proyectos que lo construyen

- Ninguno declarado
