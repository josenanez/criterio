# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-07-05
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 252.275 | Caso de negocio, 2026-07-05 |

## Retorno esperado

Retorno esperado en 24 meses.
