# Definición de producto · Cuenta de ahorros joven

**Código:** PRD-308
**Gerente de producto:** Natalia Ospina
**Segmento:** PyME
**Fecha de la definición:** 2026-02-11

## El problema

El segmento PyME no tiene cuenta de ahorros joven.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-03-27 · verificado

## Proyectos que lo construyen

- Ninguno declarado
