# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-10-01
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 217.163 | Caso de negocio, 2025-10-01 |

## Retorno esperado

Retorno esperado en 24 meses.
