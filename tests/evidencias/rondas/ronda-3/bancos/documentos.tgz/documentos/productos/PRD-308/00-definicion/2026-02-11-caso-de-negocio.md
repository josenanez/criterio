# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-02-11
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 268.099 | Caso de negocio, 2026-02-11 |

## Retorno esperado

Retorno esperado en 24 meses.
