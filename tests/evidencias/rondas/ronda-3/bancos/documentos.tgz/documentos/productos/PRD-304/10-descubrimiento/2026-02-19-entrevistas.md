# Entrevistas · Tarjeta de crédito digital

**Ronda:** Ronda · 2026-02-19
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2026-02-19

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
