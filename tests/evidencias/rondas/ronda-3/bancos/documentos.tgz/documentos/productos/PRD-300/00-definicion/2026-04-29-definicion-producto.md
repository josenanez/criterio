# Definición de producto · Pagos QR comercios

**Código:** PRD-300
**Gerente de producto:** Gustavo Neira
**Segmento:** PyME
**Fecha de la definición:** 2026-04-29

## El problema

El segmento PyME no tiene pagos qr comercios.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-09-16 · verificado

## Proyectos que lo construyen

- Ninguno declarado
