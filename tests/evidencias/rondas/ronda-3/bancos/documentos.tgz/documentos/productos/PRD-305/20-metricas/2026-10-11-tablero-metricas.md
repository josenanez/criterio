# Tablero de métricas · Recaudos y cobros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 257.967 | 2026-10-11 |
