# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Sandra Gil
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-04-22

## El problema

El segmento Microcomercio no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-06-07 · verificado

## Proyectos que lo construyen

- Ninguno declarado
