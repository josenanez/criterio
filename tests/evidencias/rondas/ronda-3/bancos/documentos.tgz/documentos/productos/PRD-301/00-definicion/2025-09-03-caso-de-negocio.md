# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2025-09-03
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 267.895 | Caso de negocio, 2025-09-03 |

## Retorno esperado

Retorno esperado en 24 meses.
