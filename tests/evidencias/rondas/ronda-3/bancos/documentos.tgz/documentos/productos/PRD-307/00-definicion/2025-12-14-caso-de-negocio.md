# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2025-12-14
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 81.526 | Caso de negocio, 2025-12-14 |

## Retorno esperado

Retorno esperado en 24 meses.
