# Tablero de métricas · Crédito hipotecario digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 177.552 | 2026-10-10 |
