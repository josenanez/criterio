# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-04-06
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 178.935 | Caso de negocio, 2026-04-06 |

## Retorno esperado

Retorno esperado en 24 meses.
