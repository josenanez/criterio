# Tablero de métricas · Microseguros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 175.238 | 2026-10-06 |
