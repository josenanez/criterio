# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-02-27
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 90.835 | Caso de negocio, 2026-02-27 |

## Retorno esperado

Retorno esperado en 24 meses.
