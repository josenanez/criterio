# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2026-04-29
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 235.594 | Caso de negocio, 2026-04-29 |

## Retorno esperado

Retorno esperado en 24 meses.
