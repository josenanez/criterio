# Tablero de métricas · Pagos QR comercios

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 246.442 | 2026-10-01 |
