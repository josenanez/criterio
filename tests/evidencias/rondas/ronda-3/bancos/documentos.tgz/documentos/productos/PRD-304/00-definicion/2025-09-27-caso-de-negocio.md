# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2025-09-27
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 187.069 | Caso de negocio, 2025-09-27 |

## Retorno esperado

Retorno esperado en 24 meses.
