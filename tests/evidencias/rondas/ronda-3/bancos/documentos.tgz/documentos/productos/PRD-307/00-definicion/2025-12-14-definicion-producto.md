# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Andrés Lozano
**Segmento:** Microcomercio
**Fecha de la definición:** 2025-12-14

## El problema

El segmento Microcomercio no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-07-17 · verificado

## Proyectos que lo construyen

- Ninguno declarado
