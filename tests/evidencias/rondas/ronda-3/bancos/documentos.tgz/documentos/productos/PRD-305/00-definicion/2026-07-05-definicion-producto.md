# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** PyME
**Fecha de la definición:** 2026-07-05

## El problema

El segmento PyME no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-06-12 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
