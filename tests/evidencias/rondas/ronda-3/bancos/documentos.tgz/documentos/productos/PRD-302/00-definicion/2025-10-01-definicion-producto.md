# Definición de producto · Crédito hipotecario digital

**Código:** PRD-302
**Gerente de producto:** Óscar Ramírez
**Segmento:** PyME
**Fecha de la definición:** 2025-10-01

## El problema

El segmento PyME no tiene crédito hipotecario digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-07-06 · verificado

## Proyectos que lo construyen

- Ninguno declarado
