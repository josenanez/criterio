# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-09-17
**Asistentes:** Beatriz Cuéllar, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-09-25 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-19 |
| Carlos Peña | Revisar el anexo 3 | 2026-09-17 |
| Laura Vélez | Aprobar el diseño 5 | 2026-09-17 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-17 |
| Elena Duarte | Confirmar la fecha 7 | 2026-10-03 |
| Diana Molina | Entregar el punto 8 | 2026-10-02 |
| Felipe Arango | Enviar el documento 9 | 2026-09-26 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-14 |
| Gustavo Neira | Revisar el anexo 11 | 2026-09-27 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-02 |
