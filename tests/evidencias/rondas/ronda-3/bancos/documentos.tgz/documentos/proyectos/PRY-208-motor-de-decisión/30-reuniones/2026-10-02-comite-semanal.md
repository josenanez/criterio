# Comité de Riesgos · Motor de decisión

**Fecha:** 2026-10-02
**Asistentes:** Rubén Cárdenas, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 8 | por definir |
