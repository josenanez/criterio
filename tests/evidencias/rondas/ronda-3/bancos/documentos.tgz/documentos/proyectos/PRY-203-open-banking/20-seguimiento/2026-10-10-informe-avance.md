# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-10-10
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **25%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.587.925.781 |
| Ejecutado | 3.636.734.860 |
| Proyección al cierre | 6.811.598.728 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- El proveedor no ha confirmado la fecha de la última entrega
