# Informe de avance · Motor de decisión

**Código:** PRY-208
**Fecha de corte:** 2026-10-11
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **29%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó la salida por ventana de cambio del área de operaciones

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.936.719.206 |
| Ejecutado | 4.311.150.525 |
| Proyección al cierre | 8.794.767.161 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
