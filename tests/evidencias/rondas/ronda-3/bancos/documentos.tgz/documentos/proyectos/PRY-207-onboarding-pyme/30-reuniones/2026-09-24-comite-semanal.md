# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-09-24
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-06 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-31 |
| Carlos Peña | Revisar el anexo 3 | 2026-09-17 |
| Laura Vélez | Aprobar el diseño 5 | 2026-09-17 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-17 |
| Diana Molina | Entregar el punto 8 | 2026-10-13 |
| Felipe Arango | Enviar el documento 9 | 2026-09-26 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-14 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-05 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-02 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-07 |
| Felipe Arango | Actualizar la matriz 14 | 2026-10-13 |
| María Restrepo | Confirmar la fecha 15 | 2026-10-01 |
| Camilo Beltrán | Entregar el punto 16 | por definir |

## Lo que se dijo

- Elena Duarte dice que ya entregó «confirmar la fecha 7». No se presentó acta.
