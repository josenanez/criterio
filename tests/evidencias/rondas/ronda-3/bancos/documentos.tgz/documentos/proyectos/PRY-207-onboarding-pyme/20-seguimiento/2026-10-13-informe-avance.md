# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-13
**Gerente:** Mauricio Pérez

## Estado declarado

**Amarillo**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 6.076.638.985 |
| Ejecutado | 3.102.676.711 |
| Proyección al cierre | 7.058.214.079 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
