# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Migración a la nube
**Fecha:** 2026-10-07
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +66 días sobre la línea base vigente |
| Costo | 132.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
