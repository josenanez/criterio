# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **31%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.427.747.882 |
| Ejecutado | 1.943.195.301 |
| Proyección al cierre | 3.408.996.184 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Disponibilidad del equipo de seguridad para la revisión final
