# Comité de Riesgos · Portal de proveedores

**Fecha:** 2026-10-02
**Asistentes:** Sandra Gil, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 8 | 2026-11-06 |
