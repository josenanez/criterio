# Acta de constitución · Originación digital

**Código:** PRY-200
**Área dueña:** Operaciones
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Banca Empresas
**Producto asociado:** crédito de consumo
**Fecha de aprobación:** 2025-09-20

## Objetivo del negocio

Entregar originación digital para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Banca Empresas el 2025-09-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-30 |
| Cierre | 2026-12-28 |

## Criterio de éxito

Originación digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
