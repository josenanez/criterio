# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-13
**Gerente:** María Restrepo

## Estado declarado

**Rojo**

Avance reportado: **57%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.690.295.199 |
| Ejecutado | 2.710.944.241 |
| Proyección al cierre | 9.526.687.391 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio regulatorio en discusión que puede mover el alcance
