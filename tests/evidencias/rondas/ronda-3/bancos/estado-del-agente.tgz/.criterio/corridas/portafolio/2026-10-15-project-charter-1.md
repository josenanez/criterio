# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-15T15:50:47 · **Fin:** 2026-10-15T15:51:31 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 29 | 68 | Revisión del acta PRY-203 (2025-05-16): faltan autoridad del gerente, supuestos/restricciones, hitos, cadencia, quién mide el éxito; objetivo, alcance y exclusiones son marcadores sin llenar. No se supo qué se habló fuera de documentos ni quién es el proveedor. |

Por señal (`project-charter`): `milestone_met_without_evidence` 25, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 4, `vendor_deliverable_late` 4, `variance_cost` 2, `variance_time` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `silent` 1, `milestone_overdue` 1, `pm_vs_pmo` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Revisé el acta de PRY-203 (Open Banking, 2025-05-16): le faltan campos clave y varios de los que tiene son marcadores sin llenar.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo. La carpeta solo tiene dos documentos de este proyecto: el acta y el informe de avance del 2026-10-10.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no figura. Sandra Gil no tiene un límite escrito de monto ni de cambios. La proyección ya pasa del presupuesto (6.811.598.728 COP contra 6.800.000.000, +0,17%), y nadie sabe si eso lo decide ella o sube al Comité de Riesgos.
- **Objetivo, alcance y exclusiones:** son marcadores. El objetivo dice "Entregar open banking para Operaciones". El alcance dice "Componente 1, 2, 3". La exclusión dice "Lo que otro proyecto cubre". Así no se puede juzgar si las dos historias que salieron del sprint son un cambio de alcance.
- **Criterio de éxito:** "en producción y medido" no tiene métrica, umbral ni quién lo mide. El cierre del 2026-10-29 no tiene una prueba de aprobado o fallido.
- **Supuestos, restricciones, hitos y cadencia:** no existen. Las dependencias dicen "Ninguna declarada", pero el informe reporta dependencia del core y un proveedor sin fecha confirmada.
- **Patrocinador (María Restrepo) y comité (Comité de Riesgos):** sí están.

**Dato del informe:** con 25% de avance declarado, ya se ejecutó el 53,5% del presupuesto, y faltan 14 días para el cierre. No califiqué si "Amarillo" es razonable: el acta no da con qué juzgarlo.

**No sé:** qué se habló en el Comité de Riesgos fuera de los documentos, quién es el proveedor ni qué debe entregar.

**Pendientes que ofrezco:**
- Llevar la definición de la autoridad del gerente al comité del 2026-10-21.
- Pasar al registro RAID los dos riesgos sin dueño y el hallazgo de seguridad sin fecha.

Guardé la salida en `/home/claude/banco/ronda-3/bancos/espacio/estado/corridas/salida-project-charter.md` y registré la corrida como `2026-10-15-project-charter-1`. Duró 29 segundos. Su señal por caso para PRY-203 quedó vacía: ninguna de las señales automáticas del barrido se activó sobre este proyecto, aunque la revisión del acta sí encontró vacíos.
