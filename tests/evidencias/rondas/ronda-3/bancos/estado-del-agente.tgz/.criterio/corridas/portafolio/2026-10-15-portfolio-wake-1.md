# Corrida · 2026-10-15-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:57:59 · **Fin:** 2026-10-15T15:58:53 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 37 | 68 | Barrido: 82 documentos sin cambios, nada que releer. Confirmación: 5 preguntas sin respondedor. 11 citas de PRY-207 sin resolver aunque el archivo existe; no se determinó la causa. No había peticiones. Primera corrida: sin referencia para decir qué cruzó un umbral hoy. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 25, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 4, `vendor_deliverable_late` 4, `variance_cost` 2, `variance_time` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `silent` 1, `milestone_overdue` 1, `pm_vs_pmo` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Corrió el barrido y la confirmación del 15 de octubre. Los 82 documentos no cambiaron, así que no releí nada ni recalculé fichas. Los términos ya estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo nada que registrar.

- **Señales abiertas:** la corrida registró 68 hallazgos en 13 proyectos. Como es la primera corrida registrada, no hay una anterior para decir cuáles cruzaron un umbral hoy.
- **Declarados en verde con evidencia en contra:** PRY-201, PRY-202, PRY-209 y otros cuatro (PRY-206, 208, 210 y 211).
  - PRY-201 lleva 24 días en silencio y un sobrecosto proyectado de 13,5 %.
  - PRY-202 lleva 66 días de atraso y 25,1 % de sobrecosto proyectado.
  - PRY-209 movió su línea base 32 días sin autorización.
- **PRY-207:** la fecha de fin es 2027-08-10 en el cronograma y 2027-11-03 en el acta, y tiene seis compromisos vencidos.
- **Citas rotas:** 11 campos de PRY-207 citan `00-gobierno/2026-03-09-acta-constitucion.md`, y el índice las marca como no resueltas aunque el archivo está en la carpeta. No determiné la causa y no lo corregí.
- **Confirmación:** formulé cinco preguntas, una por campo, y quedan sin respuesta porque nadie las contestó en esta sesión sin interfaz. Fueron PRY-207 fecha de fin, PRY-209 línea base, PRY-201 estado, PRY-202 presupuesto y PRY-208 avance.
- **Peticiones:** hoy no tocaban.

La salida completa está en `estado/corridas/salida-portfolio-wake.md`. Dejé registrados el barrido y la confirmación como ejecutados, y la corrida quedó guardada como `2026-10-15-portfolio-wake-1`. Vuelvo el 2026-10-16.
