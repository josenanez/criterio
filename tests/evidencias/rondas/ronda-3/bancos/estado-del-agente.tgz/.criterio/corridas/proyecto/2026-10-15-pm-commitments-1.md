# Corrida · 2026-10-15-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:26:36 · **Fin:** 2026-10-15T15:27:11 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 19 | 2 | Cerrar la prueba 2 (Laura Vélez) reprogramada 6 veces; ajuste de presupuesto de Laura Vélez sin fecha |

Por señal (`pm-commitments`): `commitment_undated` 1, `commitment_rescheduled` 1

## Lo que el agente mostró

## Compromisos — Onboarding PyME (PRY-207) · al 2026-10-15

Hay 3 compromisos abiertos. Ninguno está vencido. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

### Se viene reprogramando
> **Laura Vélez** · Cerrar la prueba 2
> Prometido para el 2026-12-07, y antes para el 11-23, el 11-10, el 10-31, el 10-19 y el 10-05. La promesa original era para el 2026-09-23.
> Son seis reprogramaciones en seis comités seguidos. **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

Las notas no dicen por qué no alcanzó, y este comando no lo juzga.

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. Óscar Ramírez tiene «Revisión con el proveedor» para el 2026-10-25. Está abierto y no ha vencido.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Enviar el ajuste del presupuesto («la otra semana») | 2026-10-15 |

«La otra semana» no dice cuál semana, y no le inventé fecha.

### Cerrados desde la última revisión
Ninguno. Ningún documento del expediente respalda el cierre de los tres compromisos.

### Después
- **Ofrezco formular «Cerrar la prueba 2» como decisión para el comité** con `/pm-escalate`. La ficha no trae autoridad (`identity.authority` sin encontrar), así que primero habría que definir quién decide. El próximo comité está configurado para el 2026-10-29.
- No hace falta `/pm-publish`: ningún compromiso cambió un campo de la ficha.

Las cifras salen de `portafolio.py compute`: 6 reprogramaciones (el umbral es 3), 1 compromiso sin fecha y 0 vencidos.

La corrida quedó registrada como `2026-10-15-pm-commitments-1`, con la salida en `estado/PRY-207-onboarding-pyme/corridas/salida-pm-commitments.md`.
