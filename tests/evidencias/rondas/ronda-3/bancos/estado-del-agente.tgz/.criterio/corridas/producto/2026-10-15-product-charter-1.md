# Corrida · 2026-10-15-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4100

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4100

**Inicio:** 2026-10-15T15:22:30 · **Fin:** 2026-10-15T15:23:17 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 18 | — | 31 | 44 | Borrador de acta para REQ-4100 con 9 vacíos: sin evidencia de demanda, sin persona que aceptó, criterio no medible, sin autoridad ni patrocinador. No se creó la ficha: el acta no está firmada. Supuesto regulatorio sin fuente. |

Por señal (`product-charter`): `requirement_untraced` 17, `evidence_stale` 16, `requirement_without_acceptance` 6, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4100 (producto PRD-301, Nómina empresarial) y la corrida registrada. No creé la ficha del proyecto, porque el acta no está firmada.

Los términos de esta versión ya estaban vigentes (los aceptó José Francisco Ñáñez el 2026-10-15), así que no tuve que registrarlos de nuevo.

REQ-4100 no cumple todo lo que pide el paso 1. Como nadie podía responder, tomé la respuesta sugerida: seguí adelante y marqué cada faltante como vacío del acta, sin rellenarlo. Los vacíos principales son:
- **Evidencia de demanda:** ninguna. El campo «Quién lo pidió» está vacío en el comité.
- **Aceptación sin responsable:** el requerimiento figura como aceptado, pero ningún documento dice quién lo aceptó.
- **Criterio de aceptación:** «se verifica en producción» no dice qué se mide ni con qué umbral.
- **Autoridad y patrocinador:** la definición no declara la autoridad del gerente, y no hay patrocinador.
- **Descripción:** el requerimiento no tiene título ni descripción propios.
- **Supuesto regulatorio:** «La regulación vigente lo permite» dice «verificado» sin citar con qué. Lo pasé al proyecto como riesgo por asignar y dejé la restricción normativa sin resolver, sin opinar sobre cumplimiento.

El acta completa tiene nueve vacíos, cada uno con su consecuencia y quién lo cierra.

La corrida marcó 44 hallazgos en todo el producto y tardó 31 segundos. Dejé el estado declarado en blanco.

El siguiente paso es que alguien con autoridad firme el acta y vuelva a correr este comando para crear la ficha. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

Archivos en `/home/claude/banco/ronda-3/bancos/espacio/estado-producto/PRD-301/corridas/`:
- salida-product-charter.md
- 2026-10-15-product-charter-1.md
