# Corrida · 2026-10-15-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:31:52 · **Fin:** 2026-10-15T15:33:03 · **Duración:** 71 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 53 | 2 | Tres puntos: autoridad no declarada en el acta, proyección +258.214.079 COP (+3,8%) y prueba 2 con seis reprogramaciones. impact con 75 días (supuesto mío) devolvió cero alcanzados porque la ficha no tiene hitos ni dependencias; no sabe qué se recortaría, ni umbrales, ni causa de los atrasos. |

Por señal (`pm-escalate`): `commitment_undated` 1, `commitment_rescheduled` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-207 con tres puntos para decisión y registré la corrida (`2026-10-15-pm-escalate-1`). El cálculo de efecto no encontró a nadie alcanzado, pero eso viene de que la ficha no tiene hitos ni dependencias cargados, no de que el cambio no afecte a otros proyectos.

Los términos ya estaban vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15), así que no volví a registrarlos. Como no pasaste un tema, tomé lo que ya estaba marcado como escalable.

1. **Autoridad del gerente.** El acta del 2026-03-09 no declara qué puede decidir Mauricio Pérez, y lleva 220 días así. Pregunta para el Comité de Arquitectura: ¿declara los umbrales por escrito antes del comité del 10-29? Recomiendo que sí, porque de esto depende a quién se dirigen los otros dos puntos.
2. **Presupuesto.** El informe del 10-13 proyecta 7.058.214.079 COP contra 6.800.000.000 aprobados (+258.214.079 COP, +3,8 %). Recomiendo no elegir todavía: falta el ajuste que Laura Vélez dijo que enviaría «la otra semana», y la cifra no está contrastada contra un documento de cambio. Tampoco puedo decir qué alcance se recortaría para sostener el presupuesto, porque el acta solo lista «Componente 1, 2, 3».
3. **«Cerrar la prueba 2».** Lleva seis reprogramaciones en seis comités seguidos, y la promesa original era del 09-23. Recomiendo que Beatriz Cuéllar nombre quién puede quitar el bloqueo y que alguien diga la causa, que las notas no dan.

- **Efecto en otros proyectos:** usé 75 días como supuesto mío (lo que se movió el compromiso). Con ese supuesto el cierre pasaría del 2027-11-03 al 2028-01-17, pero no sé si la prueba 2 mueve el cierre.
- **Fechas límite:** los documentos no traen fecha de vencimiento para los puntos 2 y 3, y no la inventé.
- **El riesgo del proveedor no escala.** Registrarlo y ponerle dueño es del gerente; lo dejé fuera del paquete.

El paquete no se lleva solo al comité ni se le escribió a nadie.

Archivos en `/home/claude/banco/ronda-3/bancos/espacio/estado/PRY-207-onboarding-pyme/corridas/`:
- `salida-pm-escalate.md`
