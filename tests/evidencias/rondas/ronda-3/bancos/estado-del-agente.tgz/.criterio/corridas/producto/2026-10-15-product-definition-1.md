# Corrida · 2026-10-15-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:19:04 · **Fin:** 2026-10-15T15:19:48 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 18 | — | 25 | 44 | La evidencia sostiene débilmente el problema (una entrevista de hace 13 meses); volumen declarado 24,7 % sobre lo medido; sin criterio de éxito ni quien decida; supuesto regulatorio sin cita |

Por señal (`product-definition`): `requirement_untraced` 17, `evidence_stale` 16, `requirement_without_acceptance` 6, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `claim_vs_metric` 1

## Lo que el agente mostró

## Definición de Nómina empresarial (PRD-301), contrastada al 2026-10-15

Los términos ya estaban vigentes (v1.1) y registrados a nombre de José Francisco Ñáñez, con fecha 2026-10-15, así que no los volví a pedir. La definición es del 2025-09-03 y tiene 6 afirmaciones. La evidencia no la contradice de frente. Lo que sí hay es una diferencia en el volumen y varios vacíos.

- **Cifras:** el caso de negocio declara un volumen mensual de 267.895 y el tablero del 2026-09-29 mide 201.716. El declarado queda 24,7 % por encima, y el umbral es 20 %. El tablero no define qué cuenta como volumen y solo tiene un punto, así que no se sabe si ambos miden lo mismo.
- **Sin serie:** nadie mide «Retorno esperado en 24 meses». No tiene cifra ni base de cálculo.
- **No está dicho en ninguna parte:**
  - el criterio de éxito;
  - quién decide (solo figura el nombre del comité);
  - qué incluye la propuesta;
  - qué cuenta en el volumen;
  - el país;
  - de dónde sale el 267.895;
  - con qué se verificó el supuesto regulatorio;
  - qué proyecto lo construye.
- **Supuesto:** «La regulación vigente lo permite» figura como «verificado» sin citar con qué. Su fecha (2026-05-30) es posterior a la del documento (2025-09-03). Haría falta la norma o el concepto citados, con fecha y responsable.
- **Evidencia:** solo hay una entrevista, anónima y del 2025-09-20, de hace más de 12 meses. Dice «lo necesito», no «lo pagué», y no menciona el segmento. Por eso sostiene el problema de forma débil. Es también la evidencia de 15 de los 17 requerimientos aceptados.
- **Normativo:** toca datos personales, pagos y retención. Como los documentos no dicen el país, no nombré ninguna norma. Queda como «no tengo la norma a la vista», para revisión jurídica.
- **Para cerrar la definición faltan** el criterio de éxito y la persona que decide. Por eso no ofrezco `/product-charter`. El supuesto regulatorio es candidato a riesgo con doliente.

La corrida quedó registrada como `2026-10-15-product-definition-1`, con 44 hallazgos según el cálculo. El texto completo está en `estado-producto/PRD-301/corridas/salida-product-definition.md`.

Como no había nadie para responder, me quedé con las respuestas sugeridas. No me faltó ningún comando ni archivo.
