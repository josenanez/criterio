# Corrida · 2026-10-15-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:19:56 · **Fin:** 2026-10-15T15:20:52 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 18 | — | 38 | 44 | Caso de negocio armado: 2 cifras con fuente (declarada 267.895 vs medida 201.716, brecha 24,7 %), retorno sin cifra. Dijo que no sabe: costos, origen del 267.895, criterio de éxito, país, quién decide. Sin productos publicados para cruzar. |

Por señal (`product-business-case`): `requirement_untraced` 17, `evidence_stale` 16, `requirement_without_acceptance` 6, `requirement_accepted_without_evidence` 2, `requirement_undecided` 1, `requirement_without_owner` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Armé el borrador del caso de negocio de Nómina empresarial (PRD-301), pero no se puede evaluar todavía. No hay ningún documento con el costo de construir ni con una cifra de retorno.

Los términos (v1.1) ya estaban vigentes con tu nombre del 2026-10-15, así que no los registré de nuevo.

- **Cifras:** el caso declara un volumen mensual de 267.895 (caso de negocio, 2025-09-03). El tablero mide 201.716 (corte 2026-09-29), un 24,7 % menos, por encima del umbral de 20 %. El tablero no define qué cuenta en esa métrica y la serie tiene un solo punto, así que no se sabe si ambas miden lo mismo. El 267.895 tampoco dice de dónde sale.
- **Retorno:** «Retorno esperado en 24 meses» no trae cifra ni base de cálculo. Lo dejé como supuesto.
- **Costos:** ningún documento los trae. No estimé ninguno.
- **Qué se construye:** hay 17 requerimientos aceptados el 2026-10-10 y ninguno tiene proyecto que lo construya. REQ-4100 y REQ-4108 no tienen a nadie que conste como quien los pidió. La propuesta dice solo «Propuesta principal».
- **Supuesto regulatorio:** figura «verificado» sin citar con qué.
- **Demanda:** sale de una sola entrevista anónima de hace 13 meses.
- **Sin declarar:** el criterio de éxito con su fecha de corte, quién decide (solo consta el comité) y el país de operación.
- **Otros productos:** el cruce de métricas no se hizo. No hay productos publicados (la carpeta `estado` está vacía) y los otros productos en `documentos/productos` no tienen ficha publicada.

No ofrezco `/product-charter`, porque la definición no está cerrada y el caso no tiene costos. Pasar los supuestos a seguimiento queda pendiente.

La corrida quedó registrada con id `2026-10-15-product-business-case-1` (38 s, 44 hallazgos abiertos).

Archivos en `/home/claude/banco/ronda-3/bancos/espacio/estado-producto/PRD-301/corridas/`:
- `salida-product-business-case.md`
