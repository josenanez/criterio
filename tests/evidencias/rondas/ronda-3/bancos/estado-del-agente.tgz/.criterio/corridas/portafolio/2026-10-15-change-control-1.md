# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-200 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-15T15:45:45 · **Fin:** 2026-10-15T15:46:56 · **Duración:** 71 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 52 | 68 | Solicitud de mover salida a producción 30 días (2026-11-16 a 2026-12-16). Impacto en portafolio: 0 alcanzados, pero el acta declara cero dependencias y el informe nombra una con el core. No dice: solicitante, motivo, costo, autoridad de cambio, vigencia de CT-581, holgura por actividad. Conflicto sin registrar: cierre del acta 2026-12-28 vs fin del cronograma 2026-11-16. Va a comité por falta de autoridad declarada. |

Por señal (`change-control`): `milestone_met_without_evidence` 25, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 4, `vendor_deliverable_late` 4, `variance_cost` 2, `variance_time` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `silent` 1, `milestone_overdue` 1, `pm_vs_pmo` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

La solicitud de cambio de PRY-200 está lista y la corrida quedó registrada, pero no está completa: faltan el solicitante, el motivo, el costo y quién tiene autoridad para aprobarla. Esos datos no están en ningún documento de la carpeta, así que los dejé como vacíos y no los inventé. No hacía falta aceptar términos otra vez: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

- **Tiempo:** la salida a producción pasaría del 2026-11-16 al 2026-12-16, es decir, +30 días. Sería la línea base 2 y las replanificaciones subirían de 0 a 1. La línea base original no se toca.
- **Costo:** no hay impacto declarado. La proyección del informe del 2026-10-08 ya está 100.311.840 COP (4,2 %) por encima de lo aprobado, sin contar el mes adicional.
- **Alcance:** no hay impacto declarado.
- **Portafolio:** el cálculo no alcanza a ningún otro proyecto. Pero el acta declara cero dependencias y el informe nombra un riesgo por el calendario de liberaciones del core, así que ese cero significa "ninguna declarada", no "ninguna existe".
- **Quién decide:** no se puede determinar, porque ni la ficha ni el acta traen autoridad de cambio. Recomiendo llevarlo al Comité de Banca Empresas; esa recomendación es mía, el acta no la establece.
- **Conflicto de fechas sin registrar:** el acta fija el cierre del proyecto en 2026-12-28 y el cronograma termina el 2026-11-16. Hay que aclarar cuál es la fecha base antes de aprobar.
- **No pude evaluar:**
  - Si 30 días más desbordan el contrato CT-581: el texto leído no trae fecha de vigencia.
  - Cuánto se mueve cada actividad intermedia: la ficha no tiene holgura por actividad.
  - Si la parametrización del tarifario cabe en el nuevo calendario: lleva 108 días vencida.
- **Sin leer:** las actas PDF de recibo y la factura. Dos hitos cerrados tienen actas muy posteriores a su fecha de línea base (piloto con usuarios internos y diseño funcional), pero no sé si se cumplieron tarde.

Archivos en `/home/claude/banco/ronda-3/bancos/espacio/estado/corridas/`:
- `salida-change-control.md`
- `2026-10-15-change-control-1.md` (registro de la corrida)
