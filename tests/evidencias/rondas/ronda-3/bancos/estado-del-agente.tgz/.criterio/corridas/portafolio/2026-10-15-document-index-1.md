# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T15:40:35 · **Fin:** 2026-10-15T15:41:09 · **Duración:** 34 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 19 | 68 | 82 documentos sin cambio, 0 por releer; 11 citas de PRY-207 (acta-constitucion.md) no resuelven aunque el archivo existe en disco; causa no determinada |

Por señal (`document-index`): `milestone_met_without_evidence` 25, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 4, `vendor_deliverable_late` 4, `variance_cost` 2, `variance_time` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `silent` 1, `milestone_overdue` 1, `pm_vs_pmo` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**Carpeta al 2026-10-15:** 82 documentos, los 82 sin cambio, y ninguno que releer. No hay nada nuevo, cambiado, reguardado, renombrado ni borrado, y el índice no reportó formatos ilegibles.

**Citas que no resuelven:** 11 campos de PRY-207 citan `00-gobierno/2026-03-09-acta-constitucion.md`. Son identidad (código, nombre, área, producto, sponsor, gerente, comité), fechas de inicio y fin, y moneda y presupuesto aprobado. El archivo sí existe en `PRY-207-onboarding-pyme/00-gobierno/`, y el índice no lo da por borrado ni renombrado. No sé por qué la cita no resuelve, así que hay que revisarlo a mano.

**Barrido:** no lo ofrezco, porque `projects_to_recompute` está vacío.

**Términos:** ya estaban vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15. No tuve que registrar nada.

**Registro de la corrida:** quedó guardada como `2026-10-15-document-index-1`, con la salida en `estado/corridas/salida-document-index.md`. Tardó 19 segundos. El registro no midió la cantidad de documentos. También muestra 68 señales abiertas de corridas anteriores, que este comando no revisó.
