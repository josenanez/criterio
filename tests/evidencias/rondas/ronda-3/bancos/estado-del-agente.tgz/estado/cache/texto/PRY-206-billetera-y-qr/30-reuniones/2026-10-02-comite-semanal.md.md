<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-02
**Asistentes:** Elena Duarte, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 8 | 2026-10-26 |
