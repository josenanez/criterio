<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-10-08
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 23%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.407.401.878
Ejecutado 679.065.258
Proyección al cierre 2.500.311.840

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
