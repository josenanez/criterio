<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2026-03-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Banca PyME
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2026-03-09

## Objetivo del negocio

Entregar onboarding pyme para Banca PyME.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Arquitectura el 2026-03-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-19 |
| Cierre | 2027-11-03 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
