<!-- origen: PRY-202-migración-a-la-nube/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-26 | 2026-01-26 | cerrado
Ambiente de pruebas certificado | 2026-04-04 | 2026-04-04 | cerrado
Integración con el core | 2026-06-11 | 2026-08-16 | cerrado
