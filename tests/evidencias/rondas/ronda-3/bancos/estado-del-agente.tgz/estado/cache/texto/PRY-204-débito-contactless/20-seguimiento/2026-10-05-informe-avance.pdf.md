<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-05
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 67%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 14.381.676.241
Ejecutado 4.037.464.048
Proyección al cierre 16.668.912.353

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
- Dependencia del calendario de liberaciones del core
