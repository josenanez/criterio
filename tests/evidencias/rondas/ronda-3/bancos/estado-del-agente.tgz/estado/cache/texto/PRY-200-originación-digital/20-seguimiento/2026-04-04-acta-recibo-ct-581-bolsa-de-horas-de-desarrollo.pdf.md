<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-04-04-acta-recibo-ct-581-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-200 · Originación digital
Fecha de recibo: 2026-04-04
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-581 · Integra Sistemas Ltda..
