<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-10-08
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-03 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-23 |
| Jorge Medina | Actualizar la matriz 6 | 2026-11-02 |
| Felipe Arango | Enviar el documento 9 | 2026-10-25 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-11-01 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-16 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-02 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-14 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-09 |
| Mauricio Pérez | Validar el ambiente 20 | 2026-10-29 |
| Paula Céspedes | Aprobar el diseño 21 | 2026-10-12 |
| Paula Céspedes | Actualizar la matriz 22 | 2026-10-19 |
| Jorge Medina | Confirmar la fecha 23 | por definir |
| Felipe Arango | Entregar el punto 24 | 2026-10-27 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Diana Molina): recibido, acta de recibo del 2026-10-08.
- Actualizar la matriz 14 (Felipe Arango): recibido, acta de recibo del 2026-10-08.
- Enviar el documento 17 (Diana Molina): recibido, acta de recibo del 2026-10-08.
- Revisar el anexo 19 (Liliana Torres): recibido, acta de recibo del 2026-10-08.
