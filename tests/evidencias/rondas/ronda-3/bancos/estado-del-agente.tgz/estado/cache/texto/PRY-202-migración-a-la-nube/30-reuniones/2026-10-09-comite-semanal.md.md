<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-09
**Asistentes:** Paula Céspedes, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 25 | 2026-09-19 |
| Natalia Ospina | Entregar el punto 38 | 2026-10-16 |
