<!-- origen: PRY-207-onboarding-pyme/10-plan/2026-03-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-04,2026-09-04,cerrado
Ambiente de pruebas certificado,2027-02-21,2027-02-21,en curso
Integración con el core,2027-08-10,2027-08-10,en curso
