<!-- origen: PRY-207-onboarding-pyme/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {"value": "PRY-207", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "name": {"value": "Onboarding PyME", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "business_area": {"value": "Banca PyME", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "product": {"value": "cuenta PyME", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "sponsor": {"value": "Beatriz Cuéllar", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "manager": {"value": "Mauricio Pérez", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "committee": {"value": "Comité de Arquitectura", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "authority": {"value": null, "source": null, "source_date": null, "state": "not_found"}
 },
 "plan": {
 "start_date": {"value": "2026-03-19", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "end_date": {"value": "2027-11-03", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "milestones": []
 },
 "money": {
 "currency": {"value": "COP", "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"},
 "approved": {"value": 6800000000, "source": "00-gobierno/2026-03-09-acta-constitucion.md", "source_date": "2026-03-09", "state": "found"}
 },
 "raid": {
 "risks": [
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; se comentó en la reunión y nadie lo anotó como riesgo",
 "owner": "no_identificado",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "registered": false
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "commitments": [
 {
 "who": "Laura Vélez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-07",
 "original_due_date": "2026-09-23",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {"due_date": "2026-10-05", "stated_on": "2026-09-10", "source": "30-reuniones/2026-09-10-comite-semanal.md"},
 {"due_date": "2026-10-19", "stated_on": "2026-09-17", "source": "30-reuniones/2026-09-17-comite-semanal.md"},
 {"due_date": "2026-10-31", "stated_on": "2026-09-24", "source": "30-reuniones/2026-09-24-comite-semanal.md"},
 {"due_date": "2026-11-10", "stated_on": "2026-10-01", "source": "30-reuniones/2026-10-01-comite-semanal.md"},
 {"due_date": "2026-11-23", "stated_on": "2026-10-08", "source": "30-reuniones/2026-10-08-comite-semanal.md"},
 {"due_date": "2026-12-07", "stated_on": "2026-10-15", "source": "2026-10-15-notas-reunion.txt"}
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Enviar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "due_text": "la otra semana",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-25",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-15",
 "sealed": false,
 "documents_seen": [
 {"path": "2026-10-15-notas-reunion.txt", "date": "2026-10-15"},
 {"path": "30-reuniones/2026-10-08-comite-semanal.md", "date": "2026-10-08"},
 {"path": "00-gobierno/2026-03-09-acta-constitucion.md", "date": "2026-03-09"}
 ],
 "fields_not_found": ["identity.authority", "plan.milestones", "declared.status"],
 "open_conflicts": []
 }
}
