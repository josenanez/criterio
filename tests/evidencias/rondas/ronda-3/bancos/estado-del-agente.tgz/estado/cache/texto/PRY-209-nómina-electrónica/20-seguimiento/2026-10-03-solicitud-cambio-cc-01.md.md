<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-03-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Nómina electrónica
**Fecha:** 2026-10-03
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +32 días sobre la línea base vigente |
| Costo | 64.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
