<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-11-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Banca Hipotecaria

Patrocinador: Liliana Torres

Gerente de proyecto: Paula Céspedes

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-11-09

Objetivo del negocio

Entregar migración a la nube para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-11-09.

Fechas comprometidas

Fecha

Inicio

2025-11-19

Cierre

2026-07-15

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
