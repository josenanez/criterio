<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-05
Gerente: Elena Duarte

Estado declarado
Verde
Avance reportado: 62%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.130.744.586
Ejecutado 2.365.932.991
Proyección al cierre 4.218.177.817

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
