<!-- origen: PRY-210-portal-de-proveedores/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Portal de proveedores

**Fecha:** 2026-10-02
**Asistentes:** Sandra Gil, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 8 | 2026-11-06 |
