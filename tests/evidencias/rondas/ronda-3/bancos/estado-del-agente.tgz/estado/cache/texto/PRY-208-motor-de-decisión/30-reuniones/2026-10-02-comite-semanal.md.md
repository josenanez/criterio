<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Motor de decisión

**Fecha:** 2026-10-02
**Asistentes:** Rubén Cárdenas, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 8 | por definir |
