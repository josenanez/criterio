<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-01-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Banca de Personas

Patrocinador: Andrés Lozano

Gerente de proyecto: María Restrepo

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2026-01-29

Objetivo del negocio

Entregar prevención de lavado de activos para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Transformación Digital el 2026-01-29.

Fechas comprometidas

Fecha

Inicio

2026-02-08

Cierre

2026-12-09

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
