<!-- origen: PRY-203-open-banking/00-gobierno/2025-05-16-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Open Banking

**Código:** PRY-203
**Área dueña:** Operaciones
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Riesgos
**Producto asociado:** APIs de datos
**Fecha de aprobación:** 2025-05-16

## Objetivo del negocio

Entregar open banking para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Riesgos el 2025-05-16.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-26 |
| Cierre | 2026-10-29 |

## Criterio de éxito

Open Banking en producción y medido.

## Dependencias declaradas

- Ninguna declarada
