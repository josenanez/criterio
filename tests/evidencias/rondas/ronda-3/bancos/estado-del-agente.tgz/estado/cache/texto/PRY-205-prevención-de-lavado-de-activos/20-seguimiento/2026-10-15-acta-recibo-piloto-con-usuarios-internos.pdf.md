<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-15-acta-recibo-piloto-con-usuarios-internos.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Piloto con usuarios internos
Proyecto: PRY-205 · Prevención de lavado de activos
Fecha de recibo: 2026-10-15
Recibido por: María Restrepo
Se recibe a satisfacción el entregable Piloto con usuarios internos.
