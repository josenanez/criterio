<!-- origen: PRY-211-cobranza-digital/10-plan/2025-12-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-15 | 2026-04-15 | cerrado
Ambiente de pruebas certificado | 2026-07-29 | 2026-07-29 | cerrado
Integración con el core | 2026-11-12 | 2026-11-12 | en curso
