<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-09-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-09-03
**Asistentes:** Beatriz Cuéllar, Carlos Peña, Laura Vélez, Liliana Torres, Mauricio Pérez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | por definir |
| Laura Vélez | Cerrar la prueba 2 | 2026-09-23 |
| Carlos Peña | Revisar el anexo 3 | 2026-09-17 |
| Liliana Torres | Validar el ambiente 4 | 2026-09-24 |
