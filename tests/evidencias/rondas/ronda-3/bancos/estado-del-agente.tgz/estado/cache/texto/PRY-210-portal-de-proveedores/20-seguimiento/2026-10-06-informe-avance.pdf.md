<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de proveedores
Código: PRY-210
Fecha de corte: 2026-10-06
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 51%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 5.857.287.277
Ejecutado 4.765.960.555
Proyección al cierre 17.464.476.617

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
