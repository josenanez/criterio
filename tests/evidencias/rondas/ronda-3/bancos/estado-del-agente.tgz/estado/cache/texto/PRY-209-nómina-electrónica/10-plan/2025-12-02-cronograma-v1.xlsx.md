<!-- origen: PRY-209-nómina-electrónica/10-plan/2025-12-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-19 | 2026-01-19 | cerrado
Ambiente de pruebas certificado | 2026-02-26 | 2026-02-26 | cerrado
Integración con el core | 2026-04-05 | 2026-04-05 | cerrado
Piloto con usuarios internos | 2026-05-13 | 2026-05-13 | cerrado
Salida a producción | 2026-06-20 | 2026-06-20 | cerrado
