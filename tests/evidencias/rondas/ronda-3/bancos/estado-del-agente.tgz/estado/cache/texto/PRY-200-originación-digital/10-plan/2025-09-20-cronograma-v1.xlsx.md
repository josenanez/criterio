<!-- origen: PRY-200-originación-digital/10-plan/2025-09-20-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-12-21 | 2025-12-21 | cerrado
Ambiente de pruebas certificado | 2026-03-14 | 2026-03-14 | cerrado
Integración con el core | 2026-06-04 | 2026-06-04 | cerrado
Piloto con usuarios internos | 2026-08-26 | 2026-08-26 | cerrado
Salida a producción | 2026-11-16 | 2026-11-16 | en curso
