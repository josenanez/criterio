<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Banca Empresas · Originación digital

Fecha: 2026-10-14

Asistentes: Sandra Gil, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 34

por definir

Natalia Ospina

Entregar el punto 36

2026-11-01
