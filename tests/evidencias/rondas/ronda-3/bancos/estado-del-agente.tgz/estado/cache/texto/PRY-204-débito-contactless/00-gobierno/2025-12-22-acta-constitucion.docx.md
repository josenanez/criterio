<!-- origen: PRY-204-débito-contactless/00-gobierno/2025-12-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Medios de Pago

Patrocinador: Óscar Ramírez

Gerente de proyecto: Javier Hoyos

Comité: Comité de Riesgos

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-12-22

Objetivo del negocio

Entregar débito contactless para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-12-22.

Fechas comprometidas

Fecha

Inicio

2026-01-01

Cierre

2027-05-31

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
