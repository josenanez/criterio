<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-15
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 86%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 683.705.364
Ejecutado 461.927.421
Proyección al cierre 1.121.091.254

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
- Concentración del conocimiento en una sola persona
