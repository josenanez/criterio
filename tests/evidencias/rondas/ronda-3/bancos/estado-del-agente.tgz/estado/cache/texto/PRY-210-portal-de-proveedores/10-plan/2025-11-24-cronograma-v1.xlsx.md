<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-11-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-14 | 2026-02-14 | cerrado
Ambiente de pruebas certificado | 2026-04-28 | 2026-04-28 | cerrado
Integración con el core | 2026-07-10 | 2026-07-10 | cerrado
