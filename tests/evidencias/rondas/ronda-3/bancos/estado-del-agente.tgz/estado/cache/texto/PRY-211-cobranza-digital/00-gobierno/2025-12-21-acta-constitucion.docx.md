<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-12-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Riesgo y Cumplimiento

Patrocinador: Felipe Arango

Gerente de proyecto: Andrés Lozano

Comité: Comité de Arquitectura

Producto asociado: recaudos

Fecha de aprobación: 2025-12-21

Objetivo del negocio

Entregar cobranza digital para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2025-12-21.

Fechas comprometidas

Fecha

Inicio

2025-12-31

Cierre

2027-01-04

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
