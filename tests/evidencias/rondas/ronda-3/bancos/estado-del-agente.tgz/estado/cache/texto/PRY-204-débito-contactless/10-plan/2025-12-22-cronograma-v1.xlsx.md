<!-- origen: PRY-204-débito-contactless/10-plan/2025-12-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-04 | 2026-04-04 | cerrado
Ambiente de pruebas certificado | 2026-07-07 | 2026-07-07 | cerrado
Integración con el core | 2026-10-08 | 2026-10-08 | en curso
Piloto con usuarios internos | 2027-01-10 | 2027-01-10 | en curso
Salida a producción | 2027-04-14 | 2027-04-14 | en curso
