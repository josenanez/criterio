<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-09-21-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-09-21
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 30%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.283.317.036
Ejecutado 922.042.148
Proyección al cierre 4.767.564.975

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
