<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-12-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Nómina electrónica

Código: PRY-209

Área dueña: Riesgo y Cumplimiento

Patrocinador: Laura Vélez

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Arquitectura

Producto asociado: nómina empresarial

Fecha de aprobación: 2025-12-02

Objetivo del negocio

Entregar nómina electrónica para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Arquitectura el 2025-12-02.

Fechas comprometidas

Fecha

Inicio

2025-12-12

Cierre

2026-07-09

Criterio de éxito

Nómina electrónica en producción y medido.

Dependencias declaradas

• Ninguna declarada
