<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-01-29-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-04-04,2026-04-04,cerrado
Ambiente de pruebas certificado,2026-05-29,2026-05-29,cerrado
Integración con el core,2026-07-23,2026-07-23,cerrado
Piloto con usuarios internos,2026-09-17,2026-09-17,cerrado
Salida a producción,2026-11-11,2026-11-11,en curso
