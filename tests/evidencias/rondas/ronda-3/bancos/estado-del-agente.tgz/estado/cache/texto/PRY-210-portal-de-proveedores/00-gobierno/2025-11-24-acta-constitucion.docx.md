<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-11-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Banca Hipotecaria

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-11-24

Objetivo del negocio

Entregar portal de proveedores para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-11-24.

Fechas comprometidas

Fecha

Inicio

2025-12-04

Cierre

2026-08-16

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
