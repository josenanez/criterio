<!-- origen: PRY-199-renovación-de-cajeros-automáticos/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Renovación de cajeros automáticos

**Código:** PRY-199
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad del equipo de seguridad para la revisión final
