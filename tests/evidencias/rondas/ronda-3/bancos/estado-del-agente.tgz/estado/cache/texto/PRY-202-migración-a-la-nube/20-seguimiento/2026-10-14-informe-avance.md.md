<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-14
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 722.706.561 |
| Ejecutado | 551.181.414 |
| Proyección al cierre | 1.501.431.307 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- Concentración del conocimiento en una sola persona
