<!-- origen: PRY-207-onboarding-pyme/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión onboarding pyme — 2026-10-15
estuvieron: Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

- Laura Vélez dice que lo de «cerrar la prueba 2» no alcanzó, se compromete para el 07/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
