<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2025-06-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Riesgo y Cumplimiento

Patrocinador: Felipe Arango

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-06-15

Objetivo del negocio

Entregar motor de decisión para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Riesgos el 2025-06-15.

Fechas comprometidas

Fecha

Inicio

2025-06-25

Cierre

2026-10-15

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
