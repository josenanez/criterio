<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Riesgos · Débito contactless

Fecha: 2026-10-10

Asistentes: Javier Hoyos, Óscar Ramírez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Javier Hoyos

Entregar el punto 11

2026-09-27

Gustavo Neira

Entregar el punto 4

2026-11-05
