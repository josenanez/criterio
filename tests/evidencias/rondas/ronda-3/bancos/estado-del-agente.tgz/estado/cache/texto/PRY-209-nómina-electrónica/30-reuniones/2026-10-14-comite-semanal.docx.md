<!-- origen: PRY-209-nómina-electrónica/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Nómina electrónica

Fecha: 2026-10-14

Asistentes: Rubén Cárdenas, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 5

2026-11-08
