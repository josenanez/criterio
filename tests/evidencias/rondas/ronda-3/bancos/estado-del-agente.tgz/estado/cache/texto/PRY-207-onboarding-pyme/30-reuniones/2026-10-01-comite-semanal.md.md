<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-10-01
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-23 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-10 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-17 |
| Felipe Arango | Enviar el documento 9 | 2026-10-13 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-14 |
| Gustavo Neira | Revisar el anexo 11 | 2026-10-05 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-02 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-07 |
| Felipe Arango | Actualizar la matriz 14 | 2026-10-13 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-14 |
| Diana Molina | Enviar el documento 17 | 2026-10-13 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-09 |
| Liliana Torres | Revisar el anexo 19 | 2026-10-04 |
| Mauricio Pérez | Validar el ambiente 20 | 2026-10-29 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Carlos Peña): recibido, acta de recibo del 2026-10-01.
- Aprobar el diseño 5 (Laura Vélez): recibido, acta de recibo del 2026-10-01.
- Confirmar la fecha 15 (María Restrepo): recibido, acta de recibo del 2026-10-01.

## Lo que se dijo

- Diana Molina dice que ya entregó «entregar el punto 8». No se presentó acta.
