<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Prevención de lavado de activos

Fecha: 2026-10-13

Asistentes: María Restrepo, Andrés Lozano

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Mauricio Pérez

Entregar el punto 22

2026-11-06
