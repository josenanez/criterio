## Reunión de seguimiento — Onboarding PyME (PRY-207) · 2026-10-29
8 puntos · 34 minutos · 10 personas requeridas

Fecha tomada de la cadencia configurada (`committee_next` = 2026-10-29; las notas del 10-15 dicen «próxima reunión en dos semanas»). La agenda se arma hoy, 2026-10-15, con lo que hay hasta hoy; conviene regenerarla el 2026-10-28, que es cuando la configuración dice que toca el informe. Tiempo propuesto: 34 minutos, porque no se pidió un tope.

**Dos avisos antes de leerla**
- `diff` devolvió «sin snapshot previo: este es el punto de partida», así que «qué cambió» no sale de un cálculo sino de comparar el comité del 10-08 con las notas del 10-15.
- La ficha (`records/PRY-207.json`) solo trae 3 compromisos, los de las notas del 10-15. La tabla de 14 compromisos abiertos del comité del 10-08 no está en la ficha, y por eso la corrida de `/pm-commitments` de hoy dijo «ninguno vencido». Con esa tabla leída directamente, **hay 4 vencidos sin evidencia** (abajo). Conviene volver a correr `/pm-commitments` con ellos incluidos.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Cerrar la prueba 2» y quién lo puede quitar** · 10 min · **Laura Vélez**, con **Beatriz Cuéllar** (patrocinadora, estuvo el 10-15)
> Prometido para el 2026-12-07, y antes para el 11-23, y antes para el 11-10, y antes para el 10-31, y antes para el 10-19, y antes para el 10-05. La primera promesa fue para el 2026-09-23. Seis reprogramaciones en seis comités seguidos.
> Fuente: comités del 2026-09-03, 09-10, 09-17, 09-24, 10-01 y 10-08 (`30-reuniones/`) y `2026-10-15-notas-reunion.txt` (línea 2: «no alcanzó, se compromete para el 07/12/2026»).
> **Qué tiene que quedar resuelto:** una causa dicha en voz alta, y una persona que pueda quitarla con fecha. Las notas no dicen por qué no alcanzó, y esta agenda no lo supone. La ficha no trae autoridad (`identity.authority` sin encontrar): el nombre de quién decide hay que ponerlo en la sala.
> **Si no se resuelve hoy:** la fecha vigente ya queda 2026-09-23 → 2026-12-07, tres meses y dos semanas después de la promesa original, y la séptima fecha será igual de poco confiable que las seis anteriores.

> **[2] «Enviar el documento 1»: fecha firme o decir que no hay** · 5 min · **Beatriz Cuéllar**
> Prometido para el 2026-11-03, y antes para el 10-23, y antes para el 10-06, y antes para el 09-25, y antes para el 09-17. Empezó «por definir» el 09-03. Cuatro reprogramaciones desde que tuvo fecha.
> Fuente: comités del 2026-09-03, 09-10, 09-17, 09-24, 10-01 y 10-08.
> **Qué tiene que quedar resuelto:** si el 11-03 se sostiene y qué lo sostiene. No aparece en las notas del 10-15: nadie lo revisó ese día. Es un compromiso de la patrocinadora; si ella no lo puede mover, ese dato también sirve.
> **Si no se resuelve hoy:** pasa el 11-03 con la misma incertidumbre y ya serían cinco reprogramaciones.

### Vencido sin evidencia
Medido al 2026-10-15; al 10-29 cada uno tendrá 14 días más. En `20-seguimiento/` no hay acta de recibo de ninguno de los cuatro.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-02 (13 días; en la lista de los comités del 09-17 al 10-08, siempre con la misma fecha) | Si está hecho: el acta de recibo. Si no: nueva fecha y qué falta | 3 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-09 (6 días; comité del 10-08) | Ídem | 2 |
| Paula Céspedes | Aprobar el diseño 21 | 2026-10-12 (3 días; comité del 10-08) | Ídem | 2 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-14 (1 día; estaba «por definir» el 09-24 y se fechó el 10-01) | Ídem | 2 |

Fuente: `30-reuniones/2026-10-08-comite-semanal.md` (tabla de compromisos abiertos). Las notas del 10-15 no los mencionan, así que no se sabe si ya se cerraron sin acta; la agenda no lo da por hecho.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **El riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» tiene dueño y queda registrado.** Se comentó el 10-15 y «nadie lo anotó como riesgo». Quién lo registra y quién lo vigila | Mauricio Pérez, con Óscar Ramírez (su «revisión con el proveedor» es el 10-25, antes de esta reunión, y le da el dato) | Sigue sin dueño, sin fecha de revisión y fuera del registro; el informe del 10-13 lista un solo riesgo abierto («dependencia del calendario de liberaciones del core») y este no está | 5 |

Fuente: `2026-10-15-notas-reunion.txt` (línea 6) e `informe-avance` del 2026-10-13.

### Vence antes de la próxima
Es el repaso preventivo: un minuto por persona, sin discusión si va bien. 5 min en total.

| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Revisar el anexo 11 (ya lo movió dos veces: 09-27 → 10-05 → 10-16) | 2026-10-16 |
| Paula Céspedes | Actualizar la matriz 22 | 2026-10-19 |
| Laura Vélez | Enviar el ajuste del presupuesto. **Sin fecha**: dijo «la otra semana» el 10-15 y las notas no precisan cuál. Pedirle un día | por definir |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 |
| Felipe Arango | Enviar el documento 9 (ya lo movió dos veces: 09-26 → 10-13 → 10-25) | 2026-10-25 |
| Felipe Arango | Entregar el punto 24 | 2026-10-27 |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Proyección al cierre de 7.058.214.079 COP contra 6.800.000.000 aprobados: **+258.214.079 COP (+3,8 %)**, y el «ajuste del presupuesto» de Laura Vélez | Mover el presupuesto excede al gerente de proyecto; en la ficha la autoridad no está definida. La cifra es del informe del 2026-10-13 y no está contrastada contra un acta de cambio | `/pm-escalate` para formularlo; `change-control` para la línea base. Si el comité del 10-29 es esta misma reunión, entra allí como punto de decisión, no como seguimiento |
| «Confirmar la fecha 7» (Elena Duarte) y «Entregar el punto 8» (Diana Molina): ambas dijeron en el comité que ya entregaron y **no se presentó acta**; luego salieron de la lista sin quedar como cerradas (el 7 desde el comité del 09-24, el 8 desde el del 10-01) | Ninguna de las dos figura en la asistencia del 10-08 ni del 10-15, así que no pueden contestar en la sala | Mauricio Pérez pide el acta o la confirmación por escrito antes del 10-29; si llega, se cierran con su cita |

### Anexo — sin cambios desde el 2026-10-08
Una línea cada uno; no se repasan.
- Mauricio Pérez · Validar el ambiente 20 · 2026-10-29 (vence el día de la reunión; es del propio gerente)
- Natalia Ospina · Cerrar la prueba 10 · 2026-11-01 (una reprogramación: 10-14 → 11-01)
- Jorge Medina · Actualizar la matriz 6 · 2026-11-02 (**dos reprogramaciones**: 10-03 → 10-17 → 11-02; una más y entra en el punto 1)
- Jorge Medina · Confirmar la fecha 23 · por definir (lista desde el 10-08)
- Cerrados con acta (no se tocan): 13, 14, 17 y 19 (acta del 10-08); 3, 5 y 15 (10-01); 4 (09-10).

## Después
Cuando la reunión termine, ofrezco `/pm-minutes` sobre la transcripción o las notas, y los compromisos que salgan entran a `/pm-commitments` con su cita. Antes de eso, `/pm-commitments` debería volver a correr con la tabla del 10-08 para que la ficha incluya a los 14.

*Dato no disponible: el motivo por el que cada compromiso se movió (los comités solo registran la fecha nueva), los asistentes que se esperan para el 10-29 y el tope de tiempo de la reunión.*
