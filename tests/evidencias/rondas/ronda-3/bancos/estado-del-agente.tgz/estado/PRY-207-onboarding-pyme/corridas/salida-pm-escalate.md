## Para decisión — Onboarding PyME (PRY-207) · 2026-10-15

Términos vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15): no hubo que registrarlos de nuevo. Sin tema en el argumento, tomé lo ya marcado como escalable: la autoridad sin declarar, la proyección de costo y el compromiso reprogramado seis veces. Salen **tres puntos**, en este orden, porque el primero condiciona a los otros dos.

---

### Punto 1 — ¿Qué puede decidir el gerente de proyecto sin ir al comité?

**Pregunta cerrada:** ¿El Comité de Arquitectura declara por escrito, antes del 2026-10-29, los umbrales de autoridad del gerente de PRY-207 (cambio de fecha, cambio de presupuesto, cambio de alcance), sí o no?

**Quién decide:** Comité de Arquitectura, a propuesta de la patrocinadora Beatriz Cuéllar. Esa es la instancia que aprobó el acta el 2026-03-09. El acta no dice quién puede modificar la autoridad, así que es lo que se deduce de quién la aprobó, no algo escrito.
**Si no se decide hoy:** no hay fecha límite en los documentos. Lo medible es que el acta lleva 220 días sin autoridad declarada (2026-03-09 → 2026-10-15) y que los puntos 2 y 3 no se pueden dirigir con certeza a nadie. El comité siguiente es el 2026-10-29; si pasa sin esto, se devuelve el punto 2 por no saber a quién corresponde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Declarar umbrales por escrito (acta o adenda) | Sin cambio | Una decisión en el comité del 10-29 | Ninguno en COP. Falta definir los umbrales y no los invento. |
| B. Dejar que cada caso se resuelva en comité | Sin cambio | Cada punto espera hasta 14 días al siguiente comité (cadencia quincenal) | Sin cifra: no hay documento que lo cuantifique. |

**Recomiendo:** A. Sin umbrales, el gerente escala todo o no escala nada, y hoy hay dos asuntos (puntos 2 y 3) que no se pueden dirigir con certeza.

**Evidencia:** el acta `00-gobierno/2026-03-09-acta-constitucion.md` no tiene sección de autoridad, y la ficha marca `identity.authority` como `not_found`.

---

### Punto 2 — Proyección de costo por encima del aprobado

**Pregunta cerrada:** ¿Se abre control de cambios para ampliar el presupuesto de 6.800.000.000 a 7.058.214.079 COP (+258.214.079 COP, +3,8 %), o se le pide al gerente un plan que sostenga los 6.800.000.000?

**Quién decide:** el presupuesto lo aprobó el Comité de Arquitectura (acta, 2026-03-09), así que le corresponde a ese comité. Falta confirmarlo con el punto 1.
**Si no se decide hoy:** no hay fecha de vencimiento en los documentos. Falta un dato para fijarla: Laura Vélez dijo el 10-15 que enviaría «el ajuste del presupuesto la otra semana», sin día. Mientras ese ajuste no llegue, la cifra de 258 millones no tiene contraste contra un documento de cambio.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto vía control de cambios | Sin cambio | No sustentado | +258.214.079 COP sobre 6.800.000.000, según la proyección del informe del 10-13. La línea base anterior se conserva. |
| B. Sostener 6.800.000.000 | **No sustentado.** El acta lista «Componente 1, 2, 3» sin detalle, así que no puedo decir qué se recortaría. | No sustentado | 0 COP adicionales; el costo en alcance y tiempo no se puede calcular con estos documentos. |

**Recomiendo:** no elegir todavía. Esperar el ajuste de Laura Vélez y llevar la opción A o B con su sustento al 10-29. La cifra es una proyección del informe del propio proyecto, de un gerente que declara amarillo, y nadie la contrastó contra los comprometidos. Es un punto a medias, no una decisión lista.

**Evidencia:** `20-seguimiento/2026-10-13-informe-avance.md` (aprobado 6.800.000.000; comprometido 6.076.638.985; ejecutado 3.102.676.711; proyección 7.058.214.079). Compromiso de Laura Vélez: `2026-10-15-notas-reunion.txt`, línea 3.

---

### Punto 3 — «Cerrar la prueba 2» lleva seis reprogramaciones

**Pregunta cerrada:** ¿La patrocinadora Beatriz Cuéllar nombra a la persona que puede quitar el bloqueo de la prueba 2 y se sostiene el 2026-12-07 como fecha única, o se reasigna el compromiso?

**Quién decide:** Beatriz Cuéllar, como patrocinadora. Con el punto 1 sin resolver, no se puede confirmar si es un asunto de ella o del comité.
**Si no se decide hoy:** la séptima fecha repite el patrón. Medida contra la promesa original, 2026-09-23 → 2026-12-07 son **75 días**, y han pasado seis comités seguidos con una fecha nueva cada vez.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Sostener el 2026-12-07 con un desbloqueador nombrado | Sin cambio | 75 días sobre la promesa original | No sustentado |
| B. Reasignar el compromiso | No sustentado | No sustentado | No sustentado |

**Recomiendo:** A, con una condición: que alguien diga la causa en voz alta. Las notas no dicen por qué no alcanzó, y no la voy a suponer.

**Evidencia:** comités del 2026-09-03, 09-10, 09-17, 09-24, 10-01 y 10-08 (`30-reuniones/`) y `2026-10-15-notas-reunion.txt` (línea 2).

---

### A quién alcanza

El cálculo de efecto (`impact`, 75 días) devolvió **cero proyectos alcanzados y cero hitos**. **Eso no significa que el cambio no afecte a nadie.** Significa que la ficha no tiene hitos cargados (`plan.milestones` vacío) y el acta declara «Ninguna declarada» en dependencias. El resultado sale de un vacío, no de una comprobación.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| No se pudo calcular | — | — | — |

Además, **asumí 75 días** porque es lo que se movió el compromiso. No se sabe si «Cerrar la prueba 2» mueve el cierre del proyecto. Con ese supuesto el cierre pasaría del 2027-11-03 al 2028-01-17, pero **es una hipótesis mía, no un dato**.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ninguno cargado en la ficha | — | — |

El cronograma v1 (`10-plan/2026-03-09-cronograma-v1.csv`) lista tres hitos: «Diseño funcional aprobado» (cerrado), «Ambiente de pruebas certificado» (2027-02-21) e «Integración con el core» (2027-08-10). **No sé si la prueba 2 es parte de alguno de ellos**, y el informe del 10-13 dice que «se reprogramó la salida» sin que el cronograma lo refleje.

### De dónde sale esto
- Autoridad y presupuesto aprobado: `00-gobierno/2026-03-09-acta-constitucion.md`.
- Cifras de costo y estado declarado (amarillo, 65 %): `20-seguimiento/2026-10-13-informe-avance.md`.
- Reprogramaciones: seis comités semanales (`30-reuniones/`) y las notas del 10-15.
- Hitos: `10-plan/2026-03-09-cronograma-v1.csv`.
- Efecto en otros proyectos: `portafolio.py impact` (sin datos que cruzar).

### Lo que no escala, y lo que no sé
- **No escala:** el riesgo «el proveedor podría no llegar con el equipo completo» (nadie lo registró). Es del gerente: registrarlo y ponerle dueño está dentro de lo que puede hacer sin comité. Va a `/pm-report` o al RAID.
- **No sé:** por qué se movió cada compromiso, qué alcance se recortaría, qué umbrales tiene el gerente, ni cuántos días se mueve cada proyecto alcanzado (la ficha no tiene holgura).
- Llevar el paquete al comité y llamar a quien corresponda es tuyo. No se escribió a nadie.
