# Plan — Onboarding PyME (PRY-207) · borrador del 2026-10-15
**Desde:** el acta de constitución del 2026-03-09 (`00-gobierno/2026-03-09-acta-constitucion.md`) · **Criterio de éxito:** «Onboarding PyME en producción y medido» (acta, §Criterio de éxito). Está declarado, pero no dice qué se mide, con qué cifra ni quién lo certifica.

Nota de contexto: el proyecto no está arrancando. El acta fija el inicio en 2026-03-19 y ya hay un hito cerrado (Diseño funcional aprobado, 2026-09-04, según `10-plan/2026-03-09-cronograma-v1.csv`). Este borrador es entonces un plan reconstruido sobre un proyecto en marcha, no un plan de arranque.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío.** Dice «Componente 1, 2, 3» y no nombra ningún entregable | No hay de dónde sacar la WBS. Todo nodo que no venga del cronograma v1 queda «sin definir». Si lo lleno con lo razonable, el modelo decide el alcance, no el patrocinador |
| **Fuera de alcance sin contenido.** «Lo que otro proyecto cubre» no dice cuál proyecto ni qué | No se puede saber dónde termina este proyecto. El riesgo es duplicar trabajo o dejar un hueco entre dos proyectos |
| **Objetivo del negocio circular.** «Entregar onboarding pyme para Banca PyME» repite el nombre | El criterio de éxito es lo único que acota el alcance, y es corto |
| **Criterio de éxito sin medida.** «En producción y medido»: no dice qué métrica ni qué umbral | Un entregable «medición» no se puede aceptar porque nadie sabe contra qué se acepta |
| **Autoridad del gerente no declarada.** El acta no dice qué puede decidir Mauricio Pérez y qué debe subir | No sé qué puedo asumir al planificar y qué hay que subir. Lo trato todo como a subir |
| **Dependencias: «Ninguna declarada».** Pero el informe del 2026-10-13 menciona «dependencia del calendario de liberaciones del core», y el cronograma tiene el hito «Integración con el core» | El acta y el resto de la documentación se contradicen. El plan no puede ordenar bien lo que depende del core |
| **Sin proveedor ni contrato en la carpeta del proyecto**, aunque las notas del 2026-10-15 hablan de «el proveedor» y de su «equipo completo» | No hay duraciones ni capacidad citables del proveedor |
| **Cierre 2027-11-03 vs. último hito 2027-08-10** (cronograma v1): hay casi tres meses sin hitos ni entregables nombrados | No hay nada nombrado entre la integración con el core y el cierre. Es un hueco, no un colchón |

Tiene patrocinador (Beatriz Cuéllar), gerente (Mauricio Pérez), comité (Comité de Arquitectura), presupuesto (6.800.000.000 COP) y fechas de inicio y cierre. Esos puntos no faltan.

## WBS
Solo hay tres entregables nombrados en toda la documentación. Todo lo demás está sin definir. No relleno nodos para que la estructura se vea completa.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Sin definir (el acta no dice quién aprueba) | **Del cronograma v1**, no del acta: hito cerrado, 2026-09-04 | Cerrado; duración real sin dato |
| 2 | Ambiente de pruebas certificado | Sin definir (¿quién certifica?; el informe del 2026-10-13 menciona que se ajustó el plan de pruebas con el «área de seguridad», pero no dice que certifique) | **Del cronograma v1**: hito, 2027-02-21, en curso | Vacía |
| 3 | Integración con el core | Sin definir | **Del cronograma v1**: hito, 2027-08-10, en curso | Vacía |
| 4 | Pruebas (el comité y las notas hablan de «cerrar la prueba 2», «prueba 10», «prueba 18») | Sin definir | **Supuesto**: los compromisos de comité son pruebas y no sé si son entregables del plan | Vacía |
| 5 | Salida a producción | Sin definir | **Supuesto**: el criterio de éxito dice «en producción». El informe del 2026-10-13 dice «se reprogramó la salida por ventana de cambio de operaciones», así que existe una salida, pero no hay fecha ni hito | Vacía |
| 6 | Medición del onboarding | Sin definir | **Supuesto**: el criterio de éxito dice «medido». No hay métrica nombrada | Vacía |
| 7 | Alcance restante del acta («Componentes 1 a 3») | Sin definir | **Sin definir**. El acta no los describe | Vacía |

Los nodos 1 a 3 vienen del cronograma, no del acta. Los dejo como del cronograma v1 para que no parezca que el acta los respalda.

## Orden
Sin fechas. Solo qué necesita qué:

- Diseño funcional aprobado → Ambiente de pruebas certificado → pruebas. **Supuesto**: el orden coincide con las fechas del cronograma v1 (2026-09-04, luego 2027-02-21), pero el cronograma no declara la dependencia.
- Integración con el core → salida a producción. **Supuesto**: la salida depende de la integración. El informe menciona que depende del «calendario de liberaciones del core», así que el core condiciona el orden.
- Salida a producción → medición. Se deriva del criterio de éxito («en producción y medido»).
- Ventana de cambio de operaciones: condiciona la salida (informe del 2026-10-13). Es una restricción y está sin definir.
- No sé si la integración con el core puede arrancar antes de certificar el ambiente de pruebas. Es una pregunta para el equipo, no la resuelvo yo.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres hitos del cronograma v1 son los entregables del proyecto | Si hay más (los «Componentes 1 a 3» del acta), la WBS está incompleta |
| Los compromisos del comité («pruebas», «matrices», «anexos») son tareas de trabajo y no entregables de la WBS | Si lo son, la WBS tiene decenas de nodos más |
| La salida a producción es un entregable propio | Si está dentro de «Integración con el core», el orden cambia |
| La medición posterior a la salida es parte del alcance de este proyecto | Si la hace otro equipo, el criterio de éxito no se puede cerrar aquí |
| El Comité de Arquitectura es quien acepta los hitos | Si es el patrocinador u otro, ningún nodo tiene aceptador correcto |

Estos pasan a riesgos del proyecto (RAID) cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido real de los «Componentes 1 a 3» | La patrocinadora, Beatriz Cuéllar |
| Qué queda fuera de alcance y qué proyecto lo cubre | La patrocinadora, con la PMO |
| Métrica y umbral de «medido» | La patrocinadora (negocio, Banca PyME) |
| Quién acepta cada entregable | La patrocinadora / el Comité de Arquitectura |
| Autoridad del gerente al planificar | La patrocinadora |
| Fecha de la salida a producción | Operaciones (ventana de cambio) y el gerente |
| Qué hay entre 2027-08-10 y 2027-11-03 | El gerente, con el equipo |
| Proveedor: quién es, qué entrega y con qué equipo | El gerente. No hay contrato en la carpeta |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-207 solo apunta a su propia carpeta de documentos y de estado; no apunta a una carpeta de fichas de la PMO. En el árbol de documentos hay otros proyectos (PRY-199 a PRY-211), pero no los leí como análogos: no tengo cómo saber cuáles construyen un producto o entregables del mismo tipo. Es la respuesta correcta y evita una falsa precisión: no hay referencia de duración por analogía.

## Preguntas para el equipo
Una por cada duración vacía:

1. ¿Cuánto toma certificar el ambiente de pruebas, y quién emite esa certificación?
2. ¿Cuánto toma la integración con el core, y cuándo es la próxima liberación del core que la habilita?
3. ¿Cuánto toman las pruebas, y cuáles de las pruebas del comité (2, 10, 18) son entregables y cuáles son tareas?
4. ¿Cuándo es la próxima ventana de cambio de operaciones que sirve para salir a producción?
5. ¿Cuánto tiempo y qué esfuerzo exige la medición, y quién la hace?
6. ¿Qué trabajo ocupa el tramo entre el 2027-08-10 y el cierre del 2027-11-03?
7. ¿Cuántas personas del proveedor se necesitan en la siguiente fase, y cuántas hay confirmadas? (Las notas del 2026-10-15 dicen que podría no llegar completo y nadie lo registró.)

## Para comprometer una fecha falta
- La disponibilidad real del equipo del proyecto y la del proveedor para la siguiente fase.
- El contrato o compromiso del proveedor: fechas y composición del equipo.
- La ventana de cambio de operaciones y el calendario de liberaciones del core.
- La definición del alcance real (Componentes 1 a 3) y de «medido». Sin ella, ninguna fecha de cierre tiene contra qué cumplirse.
- Un dato fuera de este plan, pero que lo condiciona: el informe del 2026-10-13 proyecta 7.058.214.079 COP al cierre, contra 6.800.000.000 aprobados. El plan no puede asumir que el presupuesto alcanza.

No comprometí ninguna fecha. Las fechas que aparecen (2026-09-04, 2027-02-21, 2027-08-10, 2027-11-03) vienen del cronograma v1 y del acta, con su cita. No son nuevas.

## Después
Cuando el plan se apruebe: registrarlo como línea base y pasar los supuestos a RAID con doliente. Lo que se dijo en la reunión del 2026-10-15 sobre el proveedor ya merece una entrada en RAID, porque nadie la anotó.
