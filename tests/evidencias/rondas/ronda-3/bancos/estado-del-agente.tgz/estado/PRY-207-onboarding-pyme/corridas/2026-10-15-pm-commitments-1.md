# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 19 s · 2 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |
| `commitment_rescheduled` | 1 |

Cerrar la prueba 2 (Laura Vélez) reprogramada 6 veces; ajuste de presupuesto de Laura Vélez sin fecha

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Compromisos — Onboarding PyME (PRY-207) · al 2026-10-15

3 compromisos abiertos: 1 reprogramado 6 veces, 1 sin fecha, 1 con fecha vigente. Ninguno vencido.

### Se viene reprogramando

> **Laura Vélez** · Cerrar la prueba 2
> Prometido para el 2026-12-07, y antes para el 11-23, y antes para el 11-10, y antes para el 10-31, y antes para el 10-19, y antes para el 10-05. La primera promesa fue para el 2026-09-23.
> Seis reprogramaciones en seis comités consecutivos (09-10, 09-17, 09-24, 10-01, 10-08 y 10-15). **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuentes: 30-reuniones/2026-09-03, 09-10, 09-17, 09-24, 10-01 y 10-08 (comités semanales) y 2026-10-15-notas-reunion.txt. Cita del 15-oct: «lo de "cerrar la prueba 2" no alcanzó, se compromete para el 07/12/2026».
> La fecha vigente (12-07) ya queda 3 meses y 2 semanas después de la promesa original. Las notas no dicen por qué no alcanzó, y este comando no lo juzga.

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. El único compromiso con fecha además del anterior es de Óscar Ramírez: «Revisión con el proveedor», para el 2026-10-25 (dicho el 2026-10-15, notas línea 6). Está abierto y no ha vencido.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Enviar el ajuste del presupuesto («la otra semana») | 2026-10-15 (2026-10-15-notas-reunion.txt, línea 5) |

No puede estar vencido, por eso se cuenta aparte. «La otra semana» no dice cuál semana ni qué día, y no se le inventó fecha.

### Cerrados desde la última revisión
Ninguno. En el expediente no hay acta de recibo, correo de entrega ni entregable que cierre ninguno de los tres. Las actas de recibo de 20-seguimiento no mencionan la prueba 2, el ajuste de presupuesto ni la revisión con el proveedor.

## Después
- **Ofrezco formular «Cerrar la prueba 2» como decisión para el comité** (`/pm-escalate`): qué se pide, qué pasa si no se decide y quién tiene la facultad. La ficha no trae autoridad (`identity.authority` sin encontrar), así que habría que definir primero quién decide. El próximo comité está configurado para el 2026-10-29.
- No hace falta `/pm-publish`: ningún compromiso cambió un campo de la ficha.

*Cifras de `portafolio.py compute`: `commitment_rescheduled` = 6 veces (umbral 3), `commitment_undated` = 1, `commitments_overdue` = 0.*
