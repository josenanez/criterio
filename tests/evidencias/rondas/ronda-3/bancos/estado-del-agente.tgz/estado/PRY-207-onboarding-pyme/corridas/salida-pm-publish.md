Publiqué la ficha en `/home/claude/banco/ronda-3/bancos/espacio/documentos/proyectos/PRY-207-onboarding-pyme/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 11 campos con dato · 3 sin decir en ninguna parte (identity.authority, plan.milestones, declared.status) · **no declara estado**: la ficha no tiene declaración tuya, así que la PMO no verá estado ni fecha de corte (`declared.status` y `declared.as_of`).

**Lo más viejo que va ahí:** los 11 campos con dato salen del acta de constitución del 2026-03-09, con unos 7 meses de antigüedad; ninguno pasa de un año.

**De los ocho campos que Vera contrasta:** sponsor (Beatriz Cuéllar), manager (Mauricio Pérez), committee (Comité de Arquitectura), product (cuenta PyME), plan.end_date (2027-11-03) y money.approved (6.800.000.000 COP) van con dato. declared.status y declared.as_of van vacíos.

**Qué dice el recálculo:** 2 alertas, ambas sobre compromisos.
- "Cerrar la prueba 2" (Laura Vélez) se ha reprogramado 6 veces. Era para el 2026-09-23 y está en el 2026-12-07.
- "Enviar el ajuste del presupuesto" (Laura Vélez) no tiene fecha ("la otra semana").

La ficha no lleva línea base ni hitos.

**Términos:** vigentes (versión 0.3.9, aceptados el 2026-10-15 por José Francisco Ñáñez). No hizo falta registrarlos otra vez.

**Nota:** `compute` corrió sin errores. `ficha-pm.json` es copia exacta de `records/PRY-207.json`; no se le agregó ni quitó nada.
