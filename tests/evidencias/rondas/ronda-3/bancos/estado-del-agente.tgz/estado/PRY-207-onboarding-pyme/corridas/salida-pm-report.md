# Onboarding PyME (PRY-207) — semana del 2026-10-08 al 2026-10-15

**Declara el gerente:** *(sin declarar en esta corrida)* · avance: — · al: —
**Sustento documental:** no evaluable sin declaración
**Lo que el semáforo no explica:** sin semáforo declarado no hay contra qué medir; el cálculo deja `commitment_rescheduled` como señal sin cubrir (Laura Vélez, «Cerrar la prueba 2», 6 reprogramaciones).

> La declaración quedó en blanco a propósito. Esta sesión no tuvo a nadie que respondiera y este comando no propone un estado. En `20-seguimiento/2026-10-13-informe-avance.md` (corte 2026-10-13) hay un informe a nombre de Mauricio Pérez con estado y avance escritos. La ficha no lo registra como declaración (`declared.status` sin encontrar), y no lo uso como tal: **el gerente debe declarar hoy, con las señales de abajo a la vista.** Mientras tanto, sus cifras de presupuesto aparecen abajo marcadas como «según informe del 13-oct».

## Qué cambió esta semana
Es la primera corrida con snapshot: `diff` no tiene corrida anterior contra la cual comparar (0 cambios), así que lo siguiente sale de los documentos de la semana, no del diff.

| Qué | Estaba | Está | |
|---|---|---|---|
| Laura Vélez · Cerrar la prueba 2 | 2026-11-23 (comité 10-08) | 2026-12-07 (notas 10-15) | Reprogramado por 6.ª vez; original 2026-09-23 |
| Laura Vélez · Enviar el ajuste del presupuesto | no existía | «la otra semana» (sin fecha) | Nuevo, sin fecha |
| Óscar Ramírez · Revisión con el proveedor | no existía | 2026-10-25 | Nuevo |
| Riesgo: el proveedor podría no llegar con el equipo completo | no existía | dicho en reunión, **nadie lo anotó**; sin responsable | Nuevo, no registrado |
| Actas de recibo 13, 14, 17, 19 (10-08) | — | 4 compromisos de otros responsables cerrados con acta | Cerrado con evidencia |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Autoridad del proyecto sin definir (`identity.authority`) | acta de constitución 2026-03-09 | 220 |
| Sin línea base cargada en la ficha (`has_baseline: false`, `plan.milestones` vacío) | acta de constitución | 220 |
| «Cerrar la prueba 2» sin cerrar | primera promesa 2026-09-23 | 22 desde la primera fecha prometida |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-11-03 | 2027-11-03 | 0 días; no se registra ninguna replanificación |
| Presupuesto | 6.800.000.000 COP | 6.800.000.000 COP | 0 en lo aprobado. La proyección del informe (7.058.214.079) queda 258.214.079 sobre lo aprobado (3,8 %; umbral 10 %) |

Replanificaciones: 0 registradas. Ojo: el informe del 13-oct dice «se reprogramó la salida por ventana de cambio», pero ningún documento de línea base ni de control de cambios lo respalda, y la base y la vigente del cronograma coinciden. Eso es un movimiento sin línea base nueva.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno cae entre el 2026-10-15 y el 2026-11-12 | — | — | — |

Del cronograma v1: «Diseño funcional aprobado» (2026-09-04) figura *cerrado*, pero no encontré en la carpeta un documento que lo sustente. «Ambiente de pruebas certificado» (2027-02-21) e «Integración con el core» (2027-08-10) siguen en curso. La ficha no trae los hitos, por eso el cálculo no puede medirlos.

## Las cifras
Según informe del 13-oct (cifras del gerente, sin otra fuente en la carpeta):

| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 6.076.638.985 | 3.102.676.711 | 7.058.214.079 | **723.361.015** (aprobado − comprometido; 10,6 %) |

El disponible real es el 10,6 % de lo aprobado, mientras que lo ejecutado es el 45,6 %. Comprometido: 89,4 % (umbral de alerta 90 %). Solo aprobado sale de un documento con cita (acta de constitución).

## Abierto
**Reprogramados:** Laura Vélez, «Cerrar la prueba 2», 6 veces en 6 comités consecutivos (09-10, 09-17, 09-24, 10-01, 10-08, 10-15); el umbral es 3.
**Vencidos sin evidencia:** ninguno entre los 3 compromisos que registra la ficha.
**Sin fecha:** Laura Vélez, «Enviar el ajuste del presupuesto» («la otra semana»), dicho el 10-15.
**RAID sin movimiento:** el único riesgo (equipo del proveedor) nunca se registró; 0 días en pie. El informe del 13-oct nombra «dependencia del calendario de liberaciones del core», pero el acta dice «Ninguna declarada» en dependencias.
**Proveedor:** la ficha no tiene proveedores ni entregables contractuales; no hay nada que contrastar. «Revisión con el proveedor» (Óscar Ramírez, 10-25) está abierta.
**Lo que la ficha no ve:** el comité del 10-08 lista 14 compromisos abiertos y la ficha solo sigue 3. Varios tenían fecha ya pasada al 10-15 (Rubén Cárdenas 10-02, Ricardo Salas 10-09, Paula Céspedes 10-12, Camilo Beltrán 10-14) y no hay acta de recibo suya en la carpeta. No afirmo que estén vencidos, porque el cálculo no los tomó; hay que cargarlos y revisarlos.

## Lo que necesito de alguien
- **Mauricio Pérez:** declarar estado y avance, viendo la reprogramación 6 de «Cerrar la prueba 2» y el riesgo del proveedor sin registrar.
- **Mauricio Pérez:** confirmar si el informe del 13-oct es su declaración vigente.
- **Laura Vélez:** fecha concreta para «Enviar el ajuste del presupuesto».
- **Quien tenga la facultad (sin definir) — material de comité:** decidir sobre «Cerrar la prueba 2». Seis reprogramaciones superan lo que seguimiento resuelve. El próximo comité es el 2026-10-29.
- **Mauricio Pérez:** designar responsable y registrar el riesgo del proveedor.
- **Mauricio Pérez / sponsor Beatriz Cuéllar:** definir la autoridad del proyecto.

## Lo que no se sabe
**Sin dato:** `identity.authority`; `plan.milestones` (la ficha no los trae); `declared.status`; comprometido, ejecutado y proyección con fuente verificable (solo el informe del gerente); línea base formal.
**Silencio:** último documento hace 0 días (2026-10-15) · última reunión hace 0 días (2026-10-15). No hay silencio; el problema es lo reprogramado, no la falta de reportes.

---
*Origen: ficha `records/PRY-207.json` (actualizada 2026-10-15), cálculo de `portafolio.py compute` al 2026-10-15. 3 campos sin dato (`identity.authority`, `plan.milestones`, `declared.status`). Es un borrador de trabajo, no una decisión: la verificación es del gerente. Términos v1.1 aceptados: https://www.josenanez.com/es/agents/criterio-pmo/legal*
