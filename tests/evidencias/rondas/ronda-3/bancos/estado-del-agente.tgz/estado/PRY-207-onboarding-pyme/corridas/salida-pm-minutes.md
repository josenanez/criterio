# Acta — Onboarding PyME (PRY-207) · 2026-10-15
**Asistieron:** Beatriz Cuéllar, Camilo Beltrán, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** ninguno identificable (las notas no traen agenda; todos los asistentes del comité del 2026-10-08 estuvieron, y Óscar Ramírez aparece por primera vez).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Laura Vélez | Cerrar la prueba 2 | 2026-12-07 | **Reprogramado 6 veces.** Original 2026-09-23 → 10-05 → 10-19 → 10-31 → 11-10 → 11-23 → 12-07. Cita: «lo de "cerrar la prueba 2" no alcanzó, se compromete para el 07/12/2026» (línea 4) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo (línea 6) |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Enviar el ajuste del presupuesto — «la otra semana» (línea 5). No se convirtió en fecha: la semana de referencia es ambigua. |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Nada explícito. Hay un punto que las notas no resuelven: la fecha de «la otra semana» del ajuste de presupuesto (ver sin fecha).

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» — «nadie lo anotó como riesgo» (línea 7) | No identificado en las notas | Riesgo (proveedor/recursos) | No. El acta de constitución declara «Ninguna» en dependencias y no hay RAID previo. |

## Cerrado en esta reunión
Nada. Ningún documento de cierre acompaña las notas.

## Lo que esta reunión contradice
Nada. Patrocinador, gerente, comité y fechas de la ficha no cambian en las notas.

## Sin resolver de la transcripción
- «La otra semana» (línea 5): no dice cuál semana ni qué día.
- «Siguiente fase» (línea 7): las notas no dicen cuál es, ni de qué proveedor se habla, ni quién lo dijo. «Revisión con el proveedor» (línea 6) puede ser el mismo proveedor, pero las notas no lo afirman.
- «Próxima reunión en dos semanas» (línea 8): coincide con el comité del 2026-10-29 en la configuración, pero las notas no dan fecha.

## Lo que recalculó el script
- `commitment_rescheduled`: Laura Vélez, «Cerrar la prueba 2», 6 veces (umbral para marcar: 3).
- `commitment_undated`: Laura Vélez, «Enviar el ajuste del presupuesto».
- Compromisos vencidos: ninguno. Sin autoridad identificada en la ficha (`identity.authority`).

**Corrección a la ficha:** la ficha traía «Cerrar la prueba 2» con original 2026-11-23 y una sola reprogramación. Los comités del 09-03 al 10-08 muestran que la promesa nació el 2026-09-23. La corregí en `records/PRY-207.json`.

**Sobre los términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos otra vez.

**Siguiente paso:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta: el acta no contradice ningún campo de la ficha. El acta queda en esta conversación y en la corrida; guardarla en tu carpeta de reuniones es cosa tuya.
