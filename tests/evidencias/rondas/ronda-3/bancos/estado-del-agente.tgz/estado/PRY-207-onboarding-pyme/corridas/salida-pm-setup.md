## Listo — Onboarding PyME (PRY-207)

**Lo que miré:** 18 documentos · 7 minutas (6 comités semanales y las notas de la reunión del 15 de octubre) · la última del 2026-10-15. Formatos: 16 .md, 1 .csv, 1 .txt; todos legibles.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.9 (fecha 2026-10-15) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 0d907bfa1ce7cb7061c4c…

Las cuatro preguntas las respondí con la propuesta por defecto, porque la sesión era de prueba y nadie contestaba:
- Proyecto y gerente: PRY-207, Onboarding PyME, Mauricio Pérez (del acta de constitución del 2026-03-09).
- Reunión: jueves, cada dos semanas, según las notas («próxima reunión en dos semanas») → próxima 2026-10-29.
- Estado: `estado/PRY-207-onboarding-pyme`.
- Términos: aceptados como arriba.

### Lo que se prometió en tu última reunión (2026-10-15)
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Laura Vélez | Cerrar la prueba 2 | 2026-12-07 | Reprogramado: el comité del 2026-10-08 decía 2026-11-23. «lo de cerrar la prueba 2 no alcanzó, se compromete para el 07/12/2026» (notas del 2026-10-15). La fecha está escrita día/mes; la leí como 7 de diciembre. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | «revisión con el proveedor, queda para el 2026-10-25» (notas del 2026-10-15). Abierto. |
| Laura Vélez | Enviar el ajuste del presupuesto | sin fecha | «queda de mandar el ajuste del presupuesto la otra semana» (notas del 2026-10-15) |

Ninguno está vencido. `compute` levantó una sola señal: `commitment_undated`, el del presupuesto.

### Sin fecha
- **Laura Vélez — ajuste del presupuesto.** «La otra semana» no es una fecha y no la calculé. No puede estar vencido, y por eso es el que desaparece de los informes. Conviene preguntar el día en la próxima reunión.

### Otro hallazgo de la reunión
- Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase y nadie lo anotó como riesgo. Lo dejé en la ficha, sin dueño identificado. Tampoco hay proveedores ni dependencias declarados en el acta («Ninguna declarada»).

### Qué le falta a tu carpeta
- Las notas del 2026-10-15 son un .txt sin acta formal, y no dicen quién dijo cada cosa más allá de los nombres. Un acta de la reunión daría mejor sustento.
- Del cronograma (`10-plan/2026-03-09-cronograma-v1.csv`) y de las ocho actas de recibo no leí nada todavía, porque en este paso solo leo la última reunión. Sin ellas no puedo decir si un compromiso cerrado se cumplió o no. Tampoco hay hitos en la ficha.
- El acta de constitución no declara la autoridad del gerente (hasta qué monto o cambio de alcance puede decidir sin subir a comité). Alcance y exclusiones están en marcadores genéricos («Componente 1…», «Lo que otro proyecto cubre»).
- No hay presupuesto comprometido ni ejecutado en la ficha, y no hay línea base de fechas. Ninguno de los dos se puede calcular todavía.
- La ficha no está sellada: leí una minuta, no el proyecto.

**Cuándo vuelvo:** el jueves 2026-10-29, que es la próxima reunión de seguimiento, con el informe un día antes.

Si quieres, leo las cinco minutas anteriores del comité (del 2026-09-03 al 2026-10-01) para tener el historial completo de compromisos. Ahí se ve si alguno se reprogramó más de una vez.
