## Historia · PRY-209 Nómina electrónica · 2025-12-02 a 2026-10-15

**Leí:** 10 documentos entre 2025-12-02 y 2026-10-15
**Trimestres sin un solo documento:** 2026-T1 (ene–mar) y 2026-T2 (abr–jun). Entre el 2025-12-10 y el 2026-09-08 no hay ningún documento fechado.

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

### En una línea
El proyecto se aprobó el 2025-12-02 con cierre comprometido en el acta el 2026-07-09 (el cronograma v1 de la misma fecha dice 2026-06-20). Después hay diez meses sin papel: los siguientes documentos son del 2026-09-08 en adelante. Entre el 2026-10-03 y el 2026-10-15 aparecen juntos la solicitud de cambio CC-01 (sin decidir), dos actas de recibo, un cronograma v2 con la salida movida al 2026-07-22 y un informe que declara Verde con 86 %. De los cinco hitos que el cronograma marca como cerrados, solo dos tienen acta de recibo, y esas actas se escribieron los días 2026-10-06 y 2026-10-11, meses después de las fechas de los hitos (2026-01-19 y 2026-04-05; los días de diferencia no los entrega el script).

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 32 días (16.8 %) contra la línea base original (2026-06-20 → 2026-07-22) | No calculable: solo existe una declaración de estado (2026-10-15); falta la serie de informes anteriores | 0 detectados (hay una sola minuta de comité; no hay correos) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-12-02 | `00-gobierno/2025-12-02-acta-constitucion.docx` | Se aprueba el proyecto: 1.200.000.000 COP, inicio 2025-12-12, cierre 2026-07-09. Patrocinadora Laura Vélez, gerente Rubén Cárdenas, Comité de Arquitectura. |
| 2025-12-02 | `10-plan/2025-12-02-cronograma-v1.xlsx` | Línea base v1: salida a producción 2026-06-20. El archivo ya muestra los cinco hitos como «cerrado», algo que no pudo ser cierto en esa fecha: la fecha del archivo no es la de su última edición. |
| 2025-12-10 | `00-gobierno/2025-12-10-contrato-ct-154.docx` | Contrato con Redes del Norte Ltda.: tres entregables de 105.979.087 COP cada uno (2026-02-02, 2026-03-26, 2026-05-17). Pago contra acta de recibo firmada por el gerente. El texto ya marca «recibido» la bolsa de horas, que vencía en marzo de 2026: mismo caso de fecha de archivo que no es fecha de escritura. |
| 2026-09-08 | `20-seguimiento/2026-09-08-factura-ct-154.pdf` | Factura FV-1154 por 105.979.087 COP, «Entregables del contrato CT-154», radicada en cuentas por pagar. No cita acta de recibo. |
| 2026-10-03 | `20-seguimiento/2026-10-03-solicitud-cambio-cc-01.md` | CC-01 (Rubén Cárdenas): ampliación de alcance, +32 días «sobre la línea base vigente», +64.000.000 COP. Autorización: «Pendiente de presentación al comité». |
| 2026-10-06 | `20-seguimiento/2026-10-06-acta-recibo-diseño-funcional-aprobado.md` | Acta de recibo del hito «Diseño funcional aprobado» (fecha de línea base 2026-01-19). |
| 2026-10-11 | `20-seguimiento/2026-10-11-acta-recibo-integración-con-el-core.md` | Acta de recibo del hito «Integración con el core» (fecha de línea base 2026-04-05). |
| 2026-10-14 | `30-reuniones/2026-10-14-comite-semanal.docx` | Comité: asisten Rubén Cárdenas y Laura Vélez. Un compromiso abierto (Camilo Beltrán, «Entregar el punto 5», 2026-11-08). El temario lista dos puntos (Avance, Compromisos), así que «el punto 5» no se puede ubicar. No consta que se tratara CC-01. |
| 2026-10-15 | `10-plan/2026-10-15-cronograma-v2.csv` | Línea base v2: salida a producción pasa de 2026-06-20 a 2026-07-22, con el hito aún marcado «cerrado». Sin motivo ni documento de aprobación. |
| 2026-10-15 | `20-seguimiento/2026-10-15-informe-avance.pdf` | Estado declarado Verde, avance 86 %. Presupuesto: comprometido 683.705.364, ejecutado 461.927.421, proyección 1.121.091.254 COP. Dice «se reprogramó la salida por ventana de cambio del área de operaciones». Dos riesgos abiertos sin probabilidad, impacto ni responsable. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-15 | 2026-07-22 (v1: 2026-06-20) | No está documentado en el cronograma. El informe del mismo día dice «ventana de cambio del área de operaciones», sin vincularlo a una línea base. | Ninguno. El script marca el movimiento de 32 días como no autorizado (0 días autorizados, 1 cambio visto). CC-01 pide los mismos +32 días y sigue pendiente. |

Hechos que se desprenden de las fechas: la nueva fecha de cierre (2026-07-22) ya estaba 85 días vencida cuando se registró (2026-10-15). Además, el acta de constitución dice cierre 2026-07-09 y el cronograma v1 dice 2026-06-20, dos fechas de origen para la misma aprobación. La cifra de 32 días usa 2026-06-20; contra 2026-07-09 el atraso sería otro y el script no lo calcula.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos. Autoridad de aprobación y fase del proyecto: no encontradas. | — |

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ningún compromiso repetido. Hay uno solo abierto (Camilo Beltrán, 2026-11-08), sin historial de reprogramación. | 1 | 2026-11-08 |

Con una sola minuta no hay forma de detectar repetición. Eso no significa que no ocurriera.

### Desde cuándo lo declarado no se sostiene
No se puede fechar un deslizamiento: hay una sola declaración de estado (2026-10-15) y ninguna anterior. Lo que sí se puede fechar es la evidencia que falta:

- **Primer hito sin evidencia:** «Ambiente de pruebas certificado», vencía el 2026-02-26 y consta como cumplido sin acta (231 días).
- Siguen sin evidencia «Piloto con usuarios internos» (2026-05-13, 155 días) y «Salida a producción» (2026-07-22, 85 días).
- **Proveedor:** «Licenciamiento del motor» (vencía 2026-02-02, 255 días) y «Parametrización del tarifario» (2026-05-17, 151 días) siguen pendientes. «Bolsa de horas» figura aceptada sin acta de recibo.
- **Lo que se siguió reportando:** el informe del 2026-10-15 declara Verde y 86 %. El plan v2 marca 5 de 5 hitos cumplidos, lo que sustentaría 100 % (14 puntos más que lo declarado), pero solo 2 de 5 tienen acta. Los cinco indicadores que el script no ve reconocidos en el informe son: hitos cumplidos sin evidencia, avance contra plan, línea base movida sin autorización, atraso de tiempo y entregables del proveedor vencidos.
- **Dinero:** ejecutado 38.5 %, comprometido 57.0 %, proyección 6.6 % por debajo del aprobado. La proyección no incluye de forma visible los 64.000.000 COP de CC-01.

### Lecciones ancladas a un hecho
1. **Un hito se recibe cuando se escribe, no cuando ocurre.** Las actas de «Diseño funcional» (hito 2026-01-19) y «Integración con el core» (hito 2026-04-05) se firmaron el 2026-10-06 y el 2026-10-11. Efecto: durante ese lapso el cumplimiento era invisible o improbable de verificar para el comité; hoy solo 2 de 5 hitos tienen respaldo.
2. **La línea base v2 se publicó sin aprobación.** El 2026-10-15 la salida pasó del 2026-06-20 al 2026-07-22 y el hito quedó «cerrado». Efecto: 32 días de atraso (16.8 %) con 0 autorizados; CC-01 pide los mismos 32 días y sigue pendiente de comité.
3. **Una factura sin acta.** FV-1154 (2026-09-08, 105.979.087 COP) se radicó cuando el contrato exige acta de recibo firmada y no hay ninguna en la carpeta. Efecto: se pagó (o está por pagar) un entregable cuya aceptación no se puede sustentar; el script cuenta 105.979.087 COP facturados y aceptados contra una sola aceptación sin evidencia.

### Lo que no sé
- Qué pasó entre 2025-12-10 y 2026-09-08: no hay documentos de esos nueve meses, así que no sé si el trabajo ocurrió y no se escribió, o no ocurrió.
- Si CC-01 se presentó al comité: la minuta del 2026-10-14 no lo menciona.
- El motivo real de la replanificación y quién decidió mover la fecha.
- Cuál de las dos fechas de cierre originales (2026-07-09 o 2026-06-20) es la vigente para el patrocinador.

Nada de lo anterior atribuye intención: un atraso sin papel no dice que alguien lo ocultara. Sirve para tener esa conversación con datos en vez de con memorias, y quién la tiene es una persona. Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-21, donde CC-01 y la línea base v2 piden decisión.

*Pie de rigor: borrador de trabajo generado a partir de 10 documentos; cada dato viene del documento citado y la verificación es suya. Las cifras derivadas salen de `portafolio.py compute` con fecha de corte 2026-10-15.*
