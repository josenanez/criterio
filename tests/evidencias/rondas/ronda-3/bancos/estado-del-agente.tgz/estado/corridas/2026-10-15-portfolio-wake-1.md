# Corrida del 2026-10-15 · portfolio-wake

13 proyectos · 37 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Barrido: 82 documentos sin cambios, nada que releer. Confirmación: 5 preguntas sin respondedor. 11 citas de PRY-207 sin resolver aunque el archivo existe; no se determinó la causa. No había peticiones. Primera corrida: sin referencia para decir qué cruzó un umbral hoy.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## 2026-10-15

**Revisé:** 82 documentos · 0 cambiaron · 0 proyectos recalculados por lectura (se recalcularon las señales con lo ya leído)

Términos vigentes (v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15).

### Lo que cruzó un umbral
No hay documentos nuevos desde el último barrido, así que esto es lo que sigue abierto en las fichas, no una novedad de hoy. Es la primera corrida registrada: no hay una anterior contra la cual decir qué cruzó el umbral hoy.

- **PRY-201 Core de depósitos** — declarado verde (informe del 2026-09-21), pero 24 días en silencio y proyección 13,5 % sobre lo aprobado (COP 4.767.564.975 contra 4.200.000.000).
- **PRY-202 Migración a la nube** — declarado verde (2026-10-14), con atraso de 66 días (32,4 %) contra la línea base original, sobrecosto proyectado de 25,1 % y un compromiso vencido hace 26 días (Diana Molina, «punto 25»).
- **PRY-209 Nómina electrónica** — declarado verde (2026-10-15), con línea base movida 32 días sin autorización (0 autorizados), 17 % de atraso y dos entregables del proveedor Redes del Norte pendientes (255 y 151 días vencidos).
- **PRY-207 Onboarding PyME** — la fecha de fin difiere entre fuentes: 2027-08-10 (cronograma v1) contra 2027-11-03 (acta de constitución); seis compromisos vencidos y dos reprogramados 4 y 6 veces.
- **PRY-208, PRY-210, PRY-211, PRY-206** — declarados verdes con avance declarado muy por debajo de lo que el plan sustenta (brechas de 71, 49, 36 y 13 puntos) e hitos «cumplidos» sin evidencia.

### Citas rotas
- **PRY-207:** 11 campos citan `00-gobierno/2026-03-09-acta-constitucion.md` y el índice los marca como no resueltos, aunque el archivo existe en la carpeta del proyecto. Falta determinar si es un problema de ruta de la cita o del índice. No lo corregí.

### Peticiones atendidas
Ninguna: hoy no tocaban peticiones.

### Preguntas
Sin nadie que respondiera, quedan preguntadas una sola vez, y se reportan como «preguntada el 15, sin respuesta»:
1. PRY-207 · `plan.end_date`: ¿la vigente es 2027-08-10 (cronograma v1) o 2027-11-03 (acta)? Ambos del 2026-03-09.
2. PRY-209 · línea base: ¿quién autorizó el movimiento de 32 días?
3. PRY-201 · estado: ¿sigue en verde con 24 días sin informe y 13,5 % de sobrecosto proyectado?
4. PRY-202 · presupuesto: ¿se aprobó el sobrecosto de 25,1 % (1.501.431.307 contra 1.200.000.000)?
5. PRY-208 · avance: ¿el 29 % declarado es correcto frente a los 3 de 3 hitos cumplidos? ¿Dónde está la evidencia de esos hitos?

**Vuelvo el 2026-10-16.**
