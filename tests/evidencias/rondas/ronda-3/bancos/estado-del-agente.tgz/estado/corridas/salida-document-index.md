## Carpeta al 2026-10-15

**Documentos:** 82 · **Sin cambio:** 82 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-207 | pm_record.identity.code | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.name | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.business_area | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.product | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.sponsor | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.manager | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.committee | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.plan.start_date | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.plan.end_date | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.money.currency | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.money.approved | 00-gobierno/2026-03-09-acta-constitucion.md |

Son 11 campos de un mismo documento. Ojo: el archivo sí existe en disco
(`PRY-207-onboarding-pyme/00-gobierno/2026-03-09-acta-constitucion.md`), y el índice no lo
da por borrado ni renombrado. Por qué la cita no resuelve no lo sé: no lo di por causa
conocida. Hay que verificarlo a mano.

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Siguiente paso
No hay nada que releer, así que no se ofrece barrido (`projects_to_recompute` vacío).
Sí queda pendiente revisar las 11 citas de PRY-207.
