**Fuentes:** las 13 fichas (`estado/records/PRY-199…PRY-211`, con su RAID y sin historial de movimiento), los 13 informes de avance, las 13 actas de constitución (sección "Dependencias declaradas"), 4 contratos, 2 solicitudes de cambio, 21 minutas de comité y las notas de reunión de PRY-207 del 2026-10-15. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.

## RAID — portafolio (13 proyectos) al 2026-10-15
7 riesgos · 6 supuestos · 9 incidencias · 10 dependencias (32 ítems, tras reclasificar; ver más abajo)
32 sin doliente · 32 sin fecha · movimiento: no evaluable · 1 no registrado formalmente en una reunión (más 3+6 en informes, abajo)

Lo que dice este registro sobre sí mismo: **ningún ítem trae probabilidad, impacto, doliente, fecha ni fecha de último movimiento**. Se reporta como hallazgo; no se rellenó. Como la organización no definió escala, la valoración queda "no declarada" (la escala por defecto sería alta/media/baja, pero nadie valoró nada). Las fichas no traen id: los ids de abajo (`PRY-xxx-R/S/I/D n`) los asigné aquí para poder citarlos.

### Necesitan decisión ahora
Criterio de escalamiento cumplido: afectan a más de un proyecto, o el proyecto está en rojo. Ninguno tiene doliente.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| Calendario de liberaciones del core | Dependencia | Seis proyectos lo listan (PRY-200, 203, 204, 206, 207, 208) y tres reportan historias fuera del sprint por esa causa (PRY-199, 200, 203) | no identificado | no declarada | Afecta a otros proyectos. Ningún documento nombra el proyecto o equipo del core (ver "Dependencias en riesgo") |
| Disponibilidad del equipo de seguridad | Supuesto | Seis proyectos cuentan con él para la revisión final (PRY-199, 200, 202, 206, 210, 211) | no identificado | no declarada | Recurso compartido que varios proyectos dan por disponible; PRY-202, 203 y 205 ya tienen hallazgos de seguridad abiertos |
| PRY-205-I1 y PRY-205-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura; la prueba de carga no alcanzó el umbral y se repite | no identificado | 2026-10-13 | Proyecto en **rojo** con dos incidencias sin doliente. El gerente es María Restrepo (informe 2026-10-13) |
| PRY-204-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | no identificado | no declarada | Proyecto en **rojo**, 18.000 M COP aprobados; sin doliente ni fecha. La solicitud de cambio, si llega, excede al gerente |

También se repite entre proyectos «la prueba de carga no alcanzó el umbral» (PRY-200, 202, 205, 210) y «hallazgo de seguridad» (PRY-202, 203, 205). La redacción es idéntica: puede ser un problema común de plataforma o texto de plantilla en los informes. No lo sé; vale la pena preguntarlo.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase; las notas dicen «nadie lo anotó como riesgo» (PRY-207) | Riesgo | `PRY-207-onboarding-pyme/2026-10-15-notas-reunion.txt` | 2026-10-15 |

Revisé las 21 minutas de comité (md, docx y las notas .txt). Solo esa trae un riesgo dicho al pasar; el resto es tablas de compromisos. Los compromisos son de `/commitments`, no entran aquí. El proveedor de PRY-207 no está identificado: no hay contrato suyo en la carpeta.

**No registrados, pero salidos de informes de avance (no de reuniones).** Esto es lo que el informe cuenta como ocurrido y que no está en el RAID de la ficha:
- **Incidencia:** «Dos historias quedaron fuera del alcance del sprint por dependencia con el core» — PRY-199 (2026-10-13), PRY-200 (2026-10-08), PRY-203 (2026-10-10).
- **Incidencia (candidata):** «Se reprogramó la salida por ventana de cambio del área de operaciones» — PRY-201 (2026-09-21), PRY-204 (2026-10-05), PRY-205 (2026-10-13), PRY-207 (2026-10-13), PRY-208 (2026-10-11), PRY-209 (2026-10-15). Es un hecho ya ocurrido; los informes no dicen cuánto movió la fecha, así que no sé si pesa.

### Sin doliente o sin fecha
Los 32 ítems carecen de doliente, de fecha y de probabilidad e impacto. No repito la lista: están todos en el registro completo. Falta de doliente y de fecha son hallazgos de los gerentes; no propuse nombres aquí (ver "Después").

Actas de constitución: las 13 dicen «Dependencias declaradas: Ninguna declarada», y 10 ítems de los informes son de hecho dependencias.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| Calendario de liberaciones del core (PRY-200, 203, 204, 206, 207, 208) | **sin código de proyecto**; ningún documento dice cuál | No (declarada, no acordada) | No puedo cruzar si el core movió su fecha. Existe PRY-201 «Core de depósitos» y PRY-202 movió su hito «Integración con el core» de 2026-06-11 a 2026-08-16 (CC-01, +66 días), pero ningún documento dice que sea de ese core. Es una hipótesis, no un hallazgo |
| Fecha de la última entrega del proveedor (PRY-199, 201, 203, 205) | Proveedor (sin código) | No: «no ha confirmado» | Dependencia declarada, no acordada. Solo PRY-199 tiene contrato en la carpeta (CT-199, Consultora Andina): su primer entregable vence 2026-11-14 y está pendiente. PRY-201, 203 y 205 no tienen contrato |

Dato extra para el cruce: PRY-201 es el único que lleva más de 15 días en silencio (último informe 2026-09-21, 24 días) y su cierre comprometido era 2026-10-12, ya pasado. Si el core es PRY-201, la dependencia se apoya en un proyecto sin datos recientes. Si no lo es, no aplica.

### Reclasificaciones
Por la prueba rápida, estos ítems estaban como riesgo y son otra cosa:
- «Dependencia del calendario de liberaciones del core» (6 ítems): depende de alguien fuera del proyecto → **dependencia**.
- «El proveedor no ha confirmado la fecha de la última entrega» (4 ítems): depende de un tercero → **dependencia**.
- «Disponibilidad del equipo de seguridad para la revisión final» (6 ítems): se está dando por cierta sin verificar → **supuesto**. Si el equipo de seguridad es ajeno al proyecto sería dependencia; los documentos no lo dicen.

Se quedan como riesgo: cambio regulatorio (PRY-204, 205, 209) y concentración del conocimiento en una sola persona (PRY-202, 209, 211). Los hallazgos de seguridad, pruebas de carga y la rotación del desarrollador ya ocurrieron y están bien como incidencia. No reescribí las fichas: la reclasificación es propuesta, la decide el gerente.

### Registro completo
Tipo = registrado → propuesto. «nd» = no declarado / no identificado / sin dato. Prob., Impacto, Doliente, Fecha y Último movimiento son nd en los 32 ítems; solo cambia «Desde».

| Id | Tipo | Qué | Fuente (corte) | Desde |
|---|---|---|---|---|
| PRY-199-D1 | riesgo → dependencia | Proveedor sin confirmar fecha de la última entrega | informe 2026-10-13 | nd |
| PRY-199-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-13 | nd |
| PRY-200-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-08 | nd |
| PRY-200-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-08 | nd |
| PRY-200-I1 | incidencia | Prueba de carga no alcanzó el umbral; se repite | informe 2026-10-08 | nd |
| PRY-201-D1 | riesgo → dependencia | Proveedor sin confirmar fecha de la última entrega | informe 2026-09-21 | nd |
| PRY-202-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-14 | nd |
| PRY-202-R1 | riesgo | Concentración del conocimiento en una persona | informe 2026-10-14 | nd |
| PRY-202-I1 | incidencia | Hallazgo de seguridad en la revisión de arquitectura | informe 2026-10-14 | nd |
| PRY-202-I2 | incidencia | Prueba de carga no alcanzó el umbral; se repite | informe 2026-10-14 | nd |
| PRY-203-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-10 | nd |
| PRY-203-D2 | riesgo → dependencia | Proveedor sin confirmar fecha de la última entrega | informe 2026-10-10 | nd |
| PRY-203-I1 | incidencia | Hallazgo de seguridad en la revisión de arquitectura | informe 2026-10-10 | nd |
| PRY-204-R1 | riesgo | Cambio regulatorio puede mover el alcance | informe 2026-10-05 | nd |
| PRY-204-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-05 | nd |
| PRY-205-D1 | riesgo → dependencia | Proveedor sin confirmar fecha de la última entrega | informe 2026-10-13 | nd |
| PRY-205-R1 | riesgo | Cambio regulatorio puede mover el alcance | informe 2026-10-13 | nd |
| PRY-205-I1 | incidencia | Hallazgo de seguridad en la revisión de arquitectura | informe 2026-10-13 | 2026-10-13 |
| PRY-205-I2 | incidencia | Prueba de carga no alcanzó el umbral; se repite | informe 2026-10-13 | 2026-10-13 |
| PRY-206-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-05 | nd |
| PRY-206-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-05 | nd |
| PRY-207-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-13 | nd |
| PRY-207-R1 | riesgo (**no registrado formalmente**) | Proveedor podría no llegar con el equipo completo a la siguiente fase | notas 2026-10-15 | 2026-10-15 |
| PRY-208-D1 | riesgo → dependencia | Calendario de liberaciones del core | informe 2026-10-11 | nd |
| PRY-208-I1 | incidencia | Dos semanas perdidas por rotación de un desarrollador clave | informe 2026-10-11 | nd |
| PRY-209-R1 | riesgo | Cambio regulatorio puede mover el alcance | informe 2026-10-15 | nd |
| PRY-209-R2 | riesgo | Concentración del conocimiento en una persona | informe 2026-10-15 | nd |
| PRY-210-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-06 | nd |
| PRY-210-I1 | incidencia | Prueba de carga no alcanzó el umbral; se repite | informe 2026-10-06 | nd |
| PRY-211-R1 | riesgo | Concentración del conocimiento en una persona | informe 2026-10-14 | nd |
| PRY-211-S1 | riesgo → supuesto | Disponibilidad del equipo de seguridad | informe 2026-10-14 | nd |
| PRY-211-I1 | incidencia | Dos semanas perdidas por rotación de un desarrollador clave | informe 2026-10-14 | nd |

## Lo que no sé
- Si algún ítem lleva dos períodos sin movimiento o tiene mitigación vencida: ninguno trae fecha de último movimiento ni mitigación, y no hay informes anteriores en la carpeta (un informe por proyecto). No lo puedo evaluar.
- A qué proyecto corresponde «el core». Ningún acta declara dependencias.
- Quién es el proveedor de PRY-207 y si el riesgo del equipo incompleto está cubierto en algún contrato.
- Si el texto idéntico entre proyectos es un problema común real o plantilla.

## Después
Los cuatro puntos de "Necesitan decisión ahora" cumplen el criterio de escalamiento. Puedo llevarlos al comité del 2026-10-21 con la decisión formulada (`/steering-pack`). También puedo proponer doliente para los ítems sin él: propongo, no asigno. En esta prueba no hubo a quién preguntar, así que no hice ninguna de las dos cosas.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; la verificación es de quien lo usa. Corrida sobre las 13 carpetas de PRY-199 a PRY-211, en una sola conversación y sin subagentes. Los PDF y DOCX se leyeron como texto; no se revisaron los .xlsx de cronograma en esta corrida.*
