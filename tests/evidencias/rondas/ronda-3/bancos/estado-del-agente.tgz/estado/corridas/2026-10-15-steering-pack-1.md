# Corrida del 2026-10-15 · steering-pack

13 proyectos · 156 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de comité 2026-10-21: 6 decisiones, 6 escalamientos, 11 de 13 proyectos con hallazgos. Dije que no sé: decisiones del comité anterior (ninguna escrita), autoridad de los gerentes, qué es el core, comité y cadencia vigentes, presupuesto vigente de PRY-202, si FV-1470 y FV-1154 están pagadas.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Cargué:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211), generadas el 2026-10-15, más las salidas de las corridas de hoy (scan, raid-log, change-control, vendor-tracking, budget-tracking, health-check, project-history, project-charter, project-closure) y el paquete `pm-escalate` de PRY-207. Cifras de `portafolio.py compute` con corte 2026-10-15. Términos vigentes (v1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo. Sin nadie que responda, tomé lo sugerido: fecha del comité = `committee_next` de la configuración.

# Comité de proyectos — 2026-10-21
6 decisiones · 6 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (68 señales abiertas; 7 proyectos declaran verde y las señales lo contradicen)

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Ninguna registrada | — | No hay corrida previa de `/steering-pack` ni una sola decisión escrita en las 21 minutas de comité de las carpetas (solo tablas de compromisos). | Sin dato |

Este comité decide sin saber qué se decidió antes. Lo que se decida hoy debe quedar escrito para que el ciclo pueda cerrarse.

## Decisiones de hoy

### [1] ¿Se fija como regla transitoria que todo cambio de fecha, costo o alcance suba al comité del proyecto hasta que cada acta declare los umbrales del gerente, sí o no?
**Proyectos:** los 13 · **Quién decide:** no determinable con certeza. La regla transitoria, el comité de portafolio, si tiene facultad sobre los otros; los umbrales de cada proyecto, su propio comité. Son cuatro: Transformación Digital (PRY-199, 201, 202, 205), Banca Empresas (200, 206), Riesgos (203, 204, 208, 210) y Arquitectura (207, 209, 211). Ningún documento dice que el comité de portafolio mande sobre ellos; si no lo hace, aclararlo es lo primero de esta sesión.
**Si no se decide hoy:** `authority` está vacío en las 13 fichas (`no_authority: 13`). Hay tres cambios en curso (PRY-200, 202 y 209) que ningún documento permite dirigir con certeza a quien aprueba.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Regla transitoria: todo sube al comité | Sin cambio | Cada cambio espera al siguiente comité (la configuración dice semanal) | Sin cifra en COP; carga de agenda del comité |
| B. Pedir a cada patrocinador una adenda con umbrales | Sin cambio | Sin fecha en los documentos; la fija el comité | Sin cifra |
| C. A hoy y B con fecha | Sin cambio | A de inmediato; B según la fecha | Sin cifra |

**Recomiendo:** C. Sin umbrales por escrito, "desviación aprobada" no existe: hay fechas que alguien escribió (PRY-209 es el caso).

### [2] PRY-209 Nómina electrónica — ¿Se aprueba hoy CC-01 (+32 días, +64.000.000 COP), sí o no?
**Proyecto:** PRY-209 · **Quién decide:** Comité de Arquitectura (aprobó el presupuesto en el acta del 2025-12-02); depende del punto 1 · **Si no se decide hoy:** el cronograma v2 sigue publicado con la salida en 2026-07-22 y 32 días de movimiento sin autorizar (`unauthorized_days: 32`, `rebaseline_unauthorized` abierta).
Hechos: el informe del 2026-10-15 declara verde con 86 %, y esa salida (2026-07-22) ya venció hace 85 días; no hay acta de paso a producción. El informe atribuye el movimiento a una "ventana de cambio del área de operaciones" y CC-01 lo presenta como "ampliación de alcance": dos motivos para el mismo movimiento. La minuta del 2026-10-14 no registra que CC-01 se tratara.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación sin describir (el acta lista "Componente 1, 2 y 3" sin detalle) | Salida 2026-07-22, ya vencida (+32 días, 16,8 % sobre la original) | +64.000.000 COP; la proyección de 1.121.091.254 COP no dice si ya los incluye |
| B. Rechazar | Sin cambio | Vuelve a la línea base v1 (2026-06-20); los 32 días quedan como desviación no autorizada | 0 COP adicionales |
| C. Devolver con requisitos | Sin cambio | Decide en el comité siguiente | Sin cifra |

**Recomiendo:** C. Antes de aprobar una fecha ya consumada hay que saber cuál es el motivo real y si el proyecto salió a producción (3 de 5 hitos sin acta). Requisitos: motivo único por escrito, acta de paso a producción o declaración de que no ocurrió, y si la proyección incluye los 64.000.000 COP.

### [3] PRY-202 Migración a la nube — ¿Se ratifica por escrito CC-01 (+66 días, +132.000.000 COP) y se exige una solicitud de cambio aparte por la proyección de 1.501.431.307 COP, sí o no?
**Proyecto:** PRY-202 · **Quién decide:** Comité de Transformación Digital (según la ficha). CC-01 dice "autorizada por el comité" sin nombrar cuál. · **Si no se decide hoy:** no existe presupuesto vigente que ningún documento declare: el informe del 2026-10-14 sigue en 1.200.000.000 COP aprobado y la proyección supera lo aprobado en 25,1 %.
Hechos: fin original 2026-06-11, vigente 2026-08-16 (+66 días, 32,4 %); ambas fechas ya pasaron. Declara verde con 65 %; el plan sostiene 100 % y los 3 hitos no tienen acta. Compromiso de Diana Molina vencido hace 26 días.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 y exigir solicitud aparte por la proyección | Ampliación de CC-01 queda reconocida | Línea base 2: 2026-08-16; la 1 se conserva | +132.000.000 COP reconocidos; el exceso restante no se puede calcular porque falta el vigente |
| B. Ratificar CC-01 sin más | Ídem | Ídem | La proyección queda sin contraste |
| C. No ratificar | Vuelve al alcance original | Vuelve a 2026-06-11, ya vencida | 1.200.000.000 COP; la proyección sigue 25,1 % encima |

**Recomiendo:** A. Deja escrito quién aprobó y obliga a que el sobrecosto proyectado pase por control de cambios en vez de aparecer al cierre.

### [4] Redes del Norte Ltda. (PRY-204 y PRY-209) — ¿Se instruye a los dos gerentes a no autorizar más pagos de este proveedor sin acta de recibo por entregable y se revisan las facturas ya radicadas, sí o no?
**Proyectos:** PRY-204 (CT-470, rojo, 18.000.000.000 COP aprobados) y PRY-209 (CT-154) · **Quién decide:** el comité de cada proyecto (Riesgos para PRY-204; Arquitectura para PRY-209). El contrato de PRY-209 dice que se paga contra acta firmada por el gerente. · **Si no se decide hoy:** los pagos siguen a criterio de cada gerente; no sé si FV-1470 o FV-1154 ya se pagaron.
El patrón se repite en los dos contratos: "Licenciamiento del motor" vencido (159 días en PRY-204, 255 en PRY-209), "Bolsa de horas de desarrollo" aceptada sin acta de recibo, y una factura por exactamente ese monto aceptado: FV-1470 por 1.822.428.850 COP y FV-1154 por 105.979.087 COP. En PRY-209 también está vencida la Parametrización del tarifario (151 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Instruir y revisar facturas | Sin cambio | Puede frenar entregas del proveedor | 0 COP nuevos; quedan retenidos los pagos pendientes de las dos facturas |
| B. Dejarlo a cada gerente | Sin cambio | Sin efecto | Sin cifra; se mantiene la exposición |

**Recomiendo:** A. Pagar sin el acta que el contrato exige no se corrige después. Que sea un mismo proveedor en dos contratos hace que merezca una instrucción y no dos conversaciones.

### [5] Calendario de liberaciones del core — ¿El comité nombra un responsable de publicarlo y confirmarlo, sí o no?
**Proyectos:** PRY-200, 203, 204, 206, 207 y 208 lo declaran como dependencia; PRY-199, 200 y 203 ya sacaron historias del sprint por esa causa · **Quién decide:** no identificado; ningún documento nombra el proyecto o equipo del core · **Si no se decide hoy:** seis proyectos siguen apoyados en una fecha que nadie confirmó (las 13 actas dicen "Ninguna declarada" en dependencias).
Hipótesis, no hallazgo: el core podría ser PRY-201 (Core de depósitos), que lleva 24 días en silencio y cuyo cierre comprometido (2026-10-12) ya pasó. PRY-202 movió "Integración con el core" +66 días; ningún documento dice que sea el mismo core.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar responsable y fecha de publicación | Sin cambio | El comité fija la fecha | Sin cifra |
| B. Cada proyecto lo gestiona con su proveedor | Sin cambio | Sin efecto | Sin cifra |

**Recomiendo:** A. La dependencia afecta a seis proyectos y a ninguno le corresponde resolverla. Primero hay que decir qué es "el core".

### [6] Disponibilidad del equipo de seguridad — ¿Se le pide a seguridad confirmar por escrito su capacidad para las revisiones finales de seis proyectos, sí o no?
**Proyectos:** PRY-199, 200, 202, 206, 210 y 211 lo dan por disponible sin verificarlo; PRY-202, 203 y 205 ya tienen hallazgos de seguridad abiertos · **Quién decide:** no identificado · **Si no se decide hoy:** el supuesto sigue sin verificar y ningún ítem de RAID tiene doliente ni fecha (32 de 32).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir confirmación escrita con calendario | Sin cambio | Hasta la respuesta; sin fecha en los documentos | Sin cifra |
| B. Seguir sin verificar | Sin cambio | Sin efecto hoy | Sin cifra |

**Recomiendo:** A. Es un supuesto compartido; si falla, falla en seis proyectos a la vez.

## Escalamientos sin decisión asociada
Pasan el criterio de escalamiento, pero el punto no está listo (falta quien lo pida, el dato o el doliente), así que no se formula como decisión.

| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200 | Solicitud de mover la salida de 2026-11-16 a 2026-12-16 (+30 días), sin solicitante, motivo ni costo; avance declarado 23 % contra 80–100 % que sostiene el plan; Parametrización del tarifario vencida hace 108 días | Solicitud 2026-10-15; entregable desde 2026-06-29 | Solicitante, motivo y costo por escrito; aclarar cuál es la fecha base (cierre del acta 2026-12-28 o cronograma 2026-11-16). **Devuelta al gerente (Sandra Gil).** |
| PRY-201 | 24 días en silencio, cierre comprometido 2026-10-12 vencido, proyección 4.767.564.975 COP contra 4.200.000.000 aprobados (+13,5 %), declarado verde | 2026-09-21 | Informe actualizado y solicitud de cambio de costo. Gerente: Laura Vélez |
| PRY-203 | Cierre comprometido 2026-10-29 con 25 % declarado y sin cronograma ni hitos; ejecutado 3.636.734.860 COP mayor que comprometido 2.587.925.781 COP | 2026-10-10 (informe) | Cronograma con hitos o fecha nueva autorizada; explicación de ejecutado > comprometido. Gerente: Sandra Gil |
| PRY-204 | Rojo; hito "Integración con el core" vencido hace 7 días; compromiso de Javier Hoyos vencido hace 18 días; riesgo de cambio regulatorio sin doliente | 2026-10-08 (hito) · 2026-09-27 (compromiso) | Doliente del riesgo y fecha nueva del hito |
| PRY-205 | Rojo; dos incidencias sin doliente (hallazgo de seguridad y prueba de carga bajo el umbral); avance declarado 57 % contra 80–100 % | 2026-10-13 | Doliente por incidencia. Gerente: María Restrepo |
| PRY-207 | "Cerrar la prueba 2" (Laura Vélez) reprogramado 6 veces: del 2026-09-23 al 2026-12-07; fecha de fin 2027-08-10 en el cronograma y 2027-11-03 en el acta | 2026-09-23 | Causa del bloqueo dicha por quien la conoce; cuál fecha de fin es la vigente. La patrocinadora (Beatriz Cuéllar) es quien puede nombrar al desbloqueador |

## Para conocimiento
- **PRY-199** Renovación de cajeros: verde 20 %; sin señales. Primer entregable de CT-199 vence 2026-11-14 y está pendiente.
- **PRY-206** Billetera y QR: verde 62 %; plan sostiene 75–100 %; 3 hitos sin acta; ejecutado 56,3 % y comprometido 26,9 %.
- **PRY-208** Motor de decisión: verde 29 %; plan sostiene 100 %; 3 hitos sin acta; compromiso de Gustavo Neira sin fecha.
- **PRY-210** Portal de proveedores: verde 51 %; plan sostiene 100 %; 3 hitos sin acta.
- **PRY-211** Cobranza digital: verde 31 %; plan sostiene 67–100 %; 2 hitos sin acta; ejecutado 58,9 % y comprometido 43,3 %.
- **PRY-207** además: proyección 7.058.214.079 COP contra 6.800.000.000 (+3,8 %, bajo el umbral de 10 %); comprometido 89,4 %, a 0,6 puntos del umbral de 90 %.
- PRY-200, 201, 202, 203, 204, 205, 207 y 209 aparecen arriba.

## Anexo

### Estado por proyecto (declarado contra lo que muestran los documentos)
| Proyecto | Declarado | Avance declarado | Plan sostiene | Señales abiertas | Días en silencio |
|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 20–40 % | 0 | 2 |
| PRY-200 | amarillo | 23 % | 80–100 % | 5 | 1 |
| PRY-201 | verde | 30 % | sin hitos | 3 | 24 |
| PRY-202 | verde | 65 % | 100 % | 8 | 1 |
| PRY-203 | amarillo | 25 % | sin hitos | 0 | 5 |
| PRY-204 | rojo | 67 % | 40–60 % | 6 | 5 |
| PRY-205 | rojo | 57 % | 80–100 % | 4 | 0 |
| PRY-206 | verde | 62 % | 75–100 % | 5 | 10 |
| PRY-207 | amarillo | 65 % | 33–67 % | 12 | 0 |
| PRY-208 | verde | 29 % | 100 % | 6 | 4 |
| PRY-209 | verde | 86 % | 100 % | 10 | 0 |
| PRY-210 | verde | 51 % | 100 % | 5 | 9 |
| PRY-211 | verde | 31 % | 67–100 % | 4 | 1 |

PRY-204 es el único donde lo declarado supera lo que el plan sostiene (67 % contra 40–60 %). Los verdes contradichos por señales: PRY-201, 202, 206, 208, 209, 210 y 211.

### Contradicciones abiertas
- **PRY-207:** fecha de fin 2027-08-10 (cronograma, PMO) contra 2027-11-03 (acta, gerente), ambos del 2026-03-09; la ficha no dice cuál es posterior.
- **PRY-209:** cierre 2026-07-09 en el acta y 2026-06-20 en el cronograma v1; motivo del movimiento: "ventana de operaciones" en el informe y "ampliación de alcance" en CC-01.
- **PRY-200:** cierre 2026-12-28 en el acta y 2026-11-16 en el cronograma.
- **PRY-202:** CC-01 "autorizada por el comité" sin nombrarlo; presupuesto vigente sin declarar.
- **PRY-200 (proveedor):** FV-1581 es del 2026-09-27 y el acta de la Mesa de ayuda, del 2026-09-30. Monto facturado = aceptado (506.909.451 COP); es un hallazgo de procedimiento.
- **Comité:** la configuración dice comité semanal con próximo el 2026-10-21; el paquete de PRY-207 asumió cadencia quincenal y comité el 2026-10-29. No sé cuál rige.

### Vacíos de información
- Autoridad del gerente y fase: sin dato en las 13 fichas. Producto: sin dato en PRY-202, 205, 208 y 210.
- Campos de identidad de más de 12 meses sin confirmar: PRY-200 (13 meses), PRY-203 (17), PRY-206 (13), PRY-208 (16).
- PRY-201 y PRY-203 no tienen cronograma ni hitos; solo 4 proyectos (199, 200, 204, 209) tienen contrato en la carpeta.
- Vigencia y preaviso de CT-581 (PRY-200): sin dato.
- RAID: 32 ítems, ninguno con probabilidad, impacto, doliente ni fecha. No pude evaluar "dos períodos sin movimiento" ni "mitigación vencida": no hay fechas de movimiento ni informes anteriores.
- `compute` cuenta 0 campos como "evidencia" en las 13 fichas (los demás son declaración o sin marcar); no sé si es una regla del script o falta de clasificación.
- Comité anterior: no hay decisiones escritas.

## Después
Cuando el comité sesione, dime qué se decidió en cada punto y lo registro en las fichas (líneas base nuevas incluidas, sin borrar las anteriores). Así el material del próximo comité parte de lo decidido y no del vacío. No escribí a nadie ni asigné dolientes: las propuestas son del agente, la decisión es de quien tiene la facultad.

---
*Pie de rigor:* criterio-portfolio · familia 0.3.9 · términos v1.1 (https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9). Fichas aplicadas: las 13, generadas el 2026-10-15. Campos inciertos: autoridad y fase (13 fichas), producto (4), presupuesto vigente de PRY-202, fecha de fin vigente de PRY-207, comité que rige y su cadencia, estado de pago de FV-1470 y FV-1154. Borrador de trabajo, no decisión ni asesoría; la verificación es de quien lo usa. Corrida en una sola conversación, sin subagentes.
