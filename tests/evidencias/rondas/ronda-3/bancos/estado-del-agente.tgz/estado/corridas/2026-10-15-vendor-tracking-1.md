# Corrida del 2026-10-15 · vendor-tracking

13 proyectos · 35 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Proveedores PRY-200: CT-581 Integra Sistemas. 3 de 4 entregables aceptados con acta; Parametrización del tarifario 108 dias vencida; factura FV-1581 (2026-09-27) anterior al acta de Mesa de ayuda (2026-09-30). Sin dato: vigencia y preaviso del contrato.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Proveedores — PRY-200 Originación digital al 2026-10-15

**Sale de:** contrato CT-581 (`00-gobierno/2025-09-28-contrato-ct-581.docx`), tres actas de recibo y la factura FV-1581 (`20-seguimiento/`), el comité del 2026-10-14 (`30-reuniones/`) y la ficha del proyecto. Cifras de `portafolio.py compute`. Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-15).

### Integra Sistemas Ltda. — contrato CT-581
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-09-28) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2025-12-29 · 168.969.817 COP | accepted | Acta 2026-01-04, recibida por Sandra Gil (gerente) | Sí, dentro de FV-1581 |
| Bolsa de horas de desarrollo | 2026-03-30 · 168.969.817 COP | accepted | Acta 2026-04-04, Sandra Gil | Sí, dentro de FV-1581 |
| Parametrización del tarifario | 2026-06-29 · 168.969.817 COP | pending (108 días vencido) | Ninguna | No identificable |
| Mesa de ayuda del primer trimestre | 2026-09-28 · 168.969.817 COP | accepted | Acta 2026-09-30, Sandra Gil | Sí, dentro de FV-1581 |

Facturado: 506.909.451 COP (FV-1581, 2026-09-27) = aceptado: 506.909.451 COP (3 entregables). Totales del script, sin diferencia de monto.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura anterior al acta de uno de los tres entregables | Cada entregable se factura contra acta firmada por el gerente | FV-1581 es del 2026-09-27; el acta de la Mesa de ayuda es del 2026-09-30. El día de la factura solo existían 2 de las 3 actas | contrato CT-581; factura FV-1581; acta 2026-09-30 |
| Estado del contrato vs. realidad | Parametrización del tarifario: "en curso" | Sin acta y 108 días después de la fecha comprometida | contrato CT-581; `compute` (vendor_deliverable_late) |

El monto facturado coincide con lo aceptado hoy, pero la factura se emitió antes de que la condición de pago se cumpliera para uno de sus tres componentes. Es un hallazgo de procedimiento, no de monto; la factura dice "Entregables del contrato CT-581" sin desglosar cuál cubre cada parte, así que el desglose es inferido (3 × 168.969.817).

### Sin evidencia de recibo
Ninguno: `accepted_without_evidence` = 0.

### Compromisos del proveedor vencidos
Ninguno. El comité del 2026-10-14 no registra compromisos de Integra Sistemas. Los dos compromisos del acta son de Camilo Beltrán (punto 34, **sin fecha**) y Natalia Ospina (punto 36, 2026-11-01); ninguno es del proveedor y no hay evidencia de que lo sean.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-581: el contrato no los trae. No se puede decir si hay un preaviso por vencer antes del cierre del proyecto (2026-11-16).
- Factura de la Parametrización del tarifario: no hay.
- Sobre el proyecto (contexto, no del proveedor): el informe de avance del 2026-10-08 declara 23 % y amarillo, y el plan sustenta 80–100 % (brecha de 57 puntos); la Parametrización vencida figura entre las señales que ese informe no explica.

### Después
- Llevar a comité: la Parametrización del tarifario, 108 días vencida y de un proyecto que cierra el 2026-11-16; y la factura emitida tres días antes del acta de la Mesa de ayuda.
- Pedir a Contratos el texto completo de CT-581 (vigencia y preaviso).

*Rigor: cifras copiadas del script; nada inferido sin decirlo; lo que no está en la carpeta figura como sin dato. La verificación de las citas es suya.*
