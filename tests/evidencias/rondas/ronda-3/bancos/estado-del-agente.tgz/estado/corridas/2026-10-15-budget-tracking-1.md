# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 33 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Presupuesto de PRY-202: proyección 25,1 % sobre lo aprobado, comprometido 60,2 %; dijo que no hay presupuesto vigente tras CC-01, que ninguna cifra tiene evidencia y que el verde declarado no lo sustentan las señales.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de: acta de constitución (2025-11-09), informe de avance (2026-10-14), solicitud de cambio CC-01 (2026-10-07), cronograma v2 (2026-10-14) y la salida de `portafolio.py compute` al 2026-10-15. Todo en la ficha `estado/records/PRY-202.json`.

## Presupuesto — PRY-202 Migración a la nube al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 1.200.000.000 | 100 % | Acta de constitución; repetido en el informe de avance | 2025-11-09 / 2026-10-14 |
| Comprometido | 722.706.561 | 60,2 % | Informe de avance (declaración del gerente) | 2026-10-14 |
| Ejecutado | 551.181.414 | 45,9 % | Informe de avance (declaración del gerente) | 2026-10-14 |
| Proyección al cierre | 1.501.431.307 | 125,1 % (excede en 25,1 %) | Informe de avance (declaración del gerente) | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): 477.293.439 COP

Las cuatro cifras vienen de un solo documento, el informe de avance, que es una declaración. Ningún documento de evidencia (extracto, contabilidad, facturas) las respalda: las fuentes son 0 de evidencia, 2 de declaración.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 1.200.000.000 (acta, 2025-11-09) | **No declarado** | No se puede calcular |
| Fecha de fin | 2026-06-11 | 2026-08-16 | +66 días (32,4 %) contra la original; 0 contra la vigente |

Replanificaciones: 1 (cronograma v2, aprobado el 2026-10-14).

La solicitud CC-01 añade 132.000.000 COP al costo y está marcada como aprobada. Ningún documento restablece el presupuesto aprobado con ese monto: el informe del 2026-10-14, posterior a CC-01, sigue diciendo 1.200.000.000. Por eso no hay línea base de costo vigente y no escribo una cifra que ningún documento declara. Además, CC-01 dice "autorizada por el comité" sin nombrar cuál, y el cronograma v2 solo mueve un hito y no declara fecha de cierre.

### Ejecución frente a avance
Ejecutado 45,9 % · Hitos cumplidos 3 de 3 · Avance declarado 65 %.

Los tres números no cuadran entre sí. Los 3 hitos figuran como cumplidos, pero ninguno tiene evidencia de cumplimiento; el plan sostendría 100 % y el gerente declara 65 % (diferencia de 35 puntos). La ejecución, 45,9 %, está por debajo de ese 65 %. Eso puede ser trabajo hecho y no facturado, que aparecería de golpe. Pero la proyección de 125,1 % indica que el gerente espera costar más que lo aprobado. Con los documentos disponibles no puedo decir cuál de las dos lecturas es la correcta.

### Alertas
- **Proyección por encima del aprobado: 25,1 %** (1.501.431.307 contra 1.200.000.000), por encima del umbral de 10 %. Aunque se sumaran los 132.000.000 de CC-01, ninguna cifra declarada indica que eso cubra la proyección.
- **Comprometido 60,2 %**, por debajo del umbral de 90 %: no hay alerta de tope.
- **Estado declarado "verde" (2026-10-14)** frente a cinco señales abiertas que el informe no recoge: desviación de costo, desviación de tiempo (+66 días), avance declarado frente al plan, hitos cumplidos sin evidencia y un compromiso vencido (Diana Molina, "Entregar el punto 25", vencido el 2026-09-19, 26 días).
- **Fechas.** La proyección (2026-10-14) es posterior al último movimiento de presupuesto (CC-01, 2026-10-07), así que no está vencida respecto a él. No sé si ya incluye los 132.000.000 de CC-01.

### Sin dato
- Presupuesto vigente después de CC-01.
- Respaldo en evidencia de comprometido y ejecutado.
- Fecha de cierre en el cronograma v2.
- Producto, autoridad y fase del proyecto (campos `not_found`).
- Proveedores: no hay contratos registrados, así que no hay detalle por proveedor.

### Siguiente paso
La proyección excede el aprobado. Puedo preparar la solicitud de cambio de presupuesto con `/criterio-portfolio:change-control`. Antes habría que saber si CC-01 ya se incorporó al presupuesto vigente.

---
*Pie de rigor:* esto es un borrador de trabajo, no una decisión ni asesoría. Cada cifra sale del documento citado y de `compute`; no sé lo que se haya hablado fuera de esos documentos. Verifique contra los originales antes de actuar.
