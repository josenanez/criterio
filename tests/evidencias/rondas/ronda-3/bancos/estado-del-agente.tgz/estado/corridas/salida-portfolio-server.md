# Rostrum — para mirarlo un rato

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`). Elegí la forma «para mirarlo un rato», que es la respuesta sugerida cuando no se sabe cuál se quiere: cero infraestructura y ninguna conversación con seguridad.

Informe encontrado en `reportes/` (13 proyectos, 8 productos, decisiones). Se sirve con:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda nada. El servidor no puede correr el agente: las peticiones esperan a `/portfolio-wake`.

Cierre: el enlace `http://127.0.0.1:8787/` solo sirve en este equipo y mientras el proceso esté vivo; no se lo pases a un patrocinador. El informe es del día en que se generó por última vez (la portada lo dice). Para un enlace estable mañana hace falta la forma «que quede corriendo», con host, puerto y control de acceso de la organización.
