# Corrida del 2026-10-15 · document-index

13 proyectos · 19 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

82 documentos sin cambio, 0 por releer; 11 citas de PRY-207 (acta-constitucion.md) no resuelven aunque el archivo existe en disco; causa no determinada

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 82 · **Sin cambio:** 82 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-207 | pm_record.identity.code | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.name | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.business_area | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.product | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.sponsor | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.manager | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.identity.committee | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.plan.start_date | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.plan.end_date | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.money.currency | 00-gobierno/2026-03-09-acta-constitucion.md |
| PRY-207 | pm_record.money.approved | 00-gobierno/2026-03-09-acta-constitucion.md |

Son 11 campos de un mismo documento. Ojo: el archivo sí existe en disco
(`PRY-207-onboarding-pyme/00-gobierno/2026-03-09-acta-constitucion.md`), y el índice no lo
da por borrado ni renombrado. Por qué la cita no resuelve no lo sé: no lo di por causa
conocida. Hay que verificarlo a mano.

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Siguiente paso
No hay nada que releer, así que no se ofrece barrido (`projects_to_recompute` vacío).
Sí queda pendiente revisar las 11 citas de PRY-207.
