Fichas cargadas: 13 (`estado/records/`), barrido del 2026-10-15. Ninguna tiene más de una semana. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

# Portafolio — 2026-10-15
13 proyectos · 11 con hallazgos · 68 señales · último barrido 2026-10-15

## Qué cambió desde la corrida anterior
Este es el punto de partida: la única instantánea (`snapshots/2026-10-15.json`) es de hoy, así que el diff da 0 cambios y no hay delta contra una fecha anterior.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-207 Onboarding PyME | fin del plan | 2027-08-10 | `10-plan/2026-03-09-cronograma-v1.csv` (2026-03-09) | 2027-11-03 | `00-gobierno/2026-03-09-acta-constitucion.md` (2026-03-09) |

Las dos fuentes tienen la misma fecha, así que ninguna es más reciente; la diferencia es de 85 días y el script no puede decidir cuál manda.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-204 Débito contactless | Integración con el core | 2026-10-08 | 7 | sin evidencia de cumplimiento |

Además hay **25 hitos declarados "cumplido" sin documento que lo respalde** (ver "Sin sustento").

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-201 Core de depósitos | 24 | 2026-09-21 (`20-seguimiento/2026-09-21-informe-avance.pdf`) |

Umbral: 15 días. PRY-201 también tiene fecha de fin 2026-10-12, ya pasada.

## Dependencias en riesgo
Ninguna detectada: las fichas no declaran dependencias entre proyectos por código. Que no haya es información, pero también puede ser un vacío de las fichas.

Riesgo de proveedor compartido: **Redes del Norte Ltda.** tiene entregables vencidos en PRY-204 y PRY-209 (licenciamiento del motor, 159 y 255 días; parametrización del tarifario en PRY-209, 151 días) y una bolsa de horas "aceptada" sin evidencia en ambos.

## Sin sustento
Estado declarado en **verde** que las señales contradicen (7 de 13):

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | verde (2026-09-21) | silencio de 24 días y proyección de costo +13,5% (4.767 M vs 4.200 M aprobados) |
| PRY-202 Migración a la nube | verde (2026-10-14) | atraso de 66 días (32,4%) vs original, costo +25,1%, 3 hitos sin evidencia, avance declarado 65% con plan que sostiene 100%, compromiso de Diana Molina vencido 26 días |
| PRY-206 Billetera y QR | verde (2026-10-05) | 3 hitos sin evidencia; avance 62% vs 75–100% que sostiene el plan |
| PRY-208 Motor de decisión | verde (2026-10-11) | 3 hitos sin evidencia; avance 29% con plan que sostiene 100% (fin previsto 2026-08-07) |
| PRY-209 Nómina electrónica | verde (2026-10-15) | atraso de 32 días con corrimiento de línea base no autorizado (0 de 32 días aprobados), 3 hitos sin evidencia incluida "Salida a producción", 2 entregables de proveedor vencidos |
| PRY-210 Portal de proveedores | verde (2026-10-06) | 3 hitos sin evidencia; avance 51% con plan que sostiene 100% (fin previsto 2026-07-10) |
| PRY-211 Cobranza digital | verde (2026-10-14) | 2 hitos sin evidencia; avance 31% vs 67–100% |

También con hitos sin evidencia pero sin estado verde contradicho: PRY-200 (2), PRY-204 (2), PRY-205 (3, avance 57% vs 80–100%), PRY-207 (1).

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | No hay autoridad de aprobación identificada (`no_authority` = 13) |
| PRY-202, PRY-205, PRY-208, PRY-210 | Sin producto asociado |
| PRY-200, PRY-207, PRY-208 | Compromisos sin fecha (4 en total: Camilo Beltrán, Jorge Medina, Laura Vélez, Gustavo Neira) |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | — | sin señales | 0 d | 0 d | 0 |
| PRY-200 Originación digital | — | con hallazgos (5) | 0 d | 0 d | 0 |
| PRY-201 Core de depósitos | verde | contradicho | 0 d (costo +13,5%) | 0 d | 0 |
| PRY-202 Migración a la nube | verde | contradicho | +66 d | 0 d | 1 |
| PRY-203 Open Banking | — | sin señales | 0 d | 0 d | 0 |
| PRY-204 Débito contactless | — | con hallazgos (6) | 0 d | 0 d | 0 |
| PRY-205 Prevención de lavado | — | con hallazgos (4) | 0 d | 0 d | 0 |
| PRY-206 Billetera y QR | verde | contradicho | 0 d | 0 d | 0 |
| PRY-207 Onboarding PyME | — | con hallazgos (12) | 0 d | 0 d | 0 |
| PRY-208 Motor de decisión | verde | contradicho | 0 d | 0 d | 0 |
| PRY-209 Nómina electrónica | verde | contradicho | +32 d | 0 d | 1 |
| PRY-210 Portal de proveedores | verde | contradicho | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | verde | contradicho | 0 d | 0 d | 0 |

Los tres proyectos con más señales: PRY-207 (12, sobre todo compromisos: 6 vencidos, 2 sin fecha, 2 reprogramadas 4 y 6 veces), PRY-209 (10) y PRY-202 (8). Los únicos sin hallazgos son PRY-199 y PRY-203.

## Necesito que confirmes
No se confirma ningún campo por mes: la cadencia es mensual y esta sesión no tuvo a nadie que respondiera. Quedan como preguntas cerradas para el comité del 2026-10-21:
1. PRY-207: ¿la fecha de fin vigente es 2027-08-10 (cronograma) o 2027-11-03 (acta)?
2. PRY-209: ¿el corrimiento de 32 días de la línea base fue autorizado por alguien con facultad? Si sí, ¿en qué documento?
3. PRY-209: ¿"Salida a producción" (2026-07-22) ocurrió? ¿Qué documento lo prueba?

## Informe en HTML
Generado en `/home/claude/banco/ronda-3/bancos/espacio/reportes` (26 páginas: 13 proyectos, 9 productos, más las dos vistas):
- `index.html` — por campo, con la cadena de evidencia completa. Para quien va a actuar (PMO, gerentes).
- `decisiones.html` — por decisión, para el patrocinador y el comité. Es otro objeto, no la vista interna recortada.
Para PDF, se imprime el HTML (ya trae `@media print`).

---
criterio-portfolio 0.3.9 · fichas aplicadas: 13, barrido 2026-10-15 · campos inciertos: fin del plan de PRY-207 (dos fuentes del mismo día) y autoridad de aprobación de los 13 proyectos · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
