# Corrida del 2026-10-15 · health-check

13 proyectos · 78 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Dictamen PRY-209: 3 sostenidas, 5 sin sustento, 3 contradichas. Verde y 86% no se sostienen (5 señales sin explicar). Dijo que no sabe: si salió a producción, quién autorizó los 32 días, soporte contable del dinero, qué cubre FV-1154, autoridad del gerente.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-209 Nómina electrónica · 2026-10-15

**Leí:** 10 documentos · del 2025-12-02 al 2026-10-15 · formatos: .docx (3), .xlsx (1), .csv (1), .md (3), .pdf (2)
**No pude leer:** ninguno. Busqué el proyecto también en las demás carpetas del portafolio (código, nombre, contrato CT-154, proveedor): ninguna minuta de otro proyecto habla de PRY-209. Solo aparecen Rubén Cárdenas y Laura Vélez como asistentes en PRY-207 y Rubén como gerente de PRY-208; no dicen nada de este proyecto.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 5 · **Contradicho:** 3 (sobre 11 afirmaciones del informe de avance, del cronograma v2 y del contrato)

El informe del 2026-10-15 declara el proyecto en **verde** con **86 %** de avance. La carpeta no lo sostiene. El único respaldo en documentos de recibo es para 2 de los 5 hitos. El plan v2 ya movió la salida a producción 32 días sin que ninguna autoridad lo haya aprobado: la solicitud de cambio CC-01 sigue "pendiente de presentación al comité". Del dinero, solo el aprobado tiene documento de origen; lo comprometido, lo ejecutado y la proyección salen únicamente del informe. Desde esta carpeta se puede afirmar que hay un acta de constitución con patrocinador, gerente y presupuesto, y dos actas de recibo. No se puede afirmar que el proyecto esté en verde ni que haya salido a producción.

La señal de contraste que calcula el script (declarado vs. evidencia) se abre con 5 señales sin explicar: hito cumplido sin evidencia, avance contra plan, línea base movida sin autorización, desviación de tiempo y entregable de proveedor vencido.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Laura Vélez | acta de constitución, 2025-12-02 |
| Gerente | Rubén Cárdenas | acta de constitución, 2025-12-02 |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o días | acta de constitución (ausencia) |
| Comité | Comité de Arquitectura. Aprobó el presupuesto el 2025-12-02. La minuta del 2026-10-14 solo registra a Rubén Cárdenas y Laura Vélez como asistentes | acta de constitución; minuta 2026-10-14 |

Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. Además, el área dueña es Riesgo y Cumplimiento y el comité es de Arquitectura; el acta no explica por qué.

### Contra el plan
- **Línea base original (v1, aprobada 2025-12-02):** salida a producción el 2026-06-20 (cronograma-v1.xlsx). El acta fija el cierre del proyecto el 2026-07-09.
- **Vigente (v2, fechada 2026-10-15):** salida a producción el 2026-07-22 (cronograma-v2.csv). **Motivo de la replanificación: no está en ningún documento.**
- **Desviación contra la original:** 32 días (16,8 %), por encima del umbral de 10 %. Contra la vigente: 0 días.
- **Cambio de línea base sin autorización:** 32 días movidos, 0 autorizados, 1 solicitud vista. CC-01 (2026-10-03, solicitante Rubén Cárdenas) pide +32 días y 64.000.000 COP adicionales por "ampliación de alcance" y dice "Pendiente de presentación al comité". La v2 ya contiene exactamente esos 32 días. Además, el informe atribuye la reprogramación a una "ventana de cambio del área de operaciones", y la solicitud la presenta como ampliación de alcance: dos motivos distintos para el mismo movimiento.
- **Avance contra plan:** el informe dice 86 %; el cronograma v2 tiene los 5 hitos en "cerrado", que sostienen 100 %. La diferencia es de 14 puntos.

### Hitos vencidos sin evidencia
Los 5 hitos figuran como cerrados; solo 2 tienen un documento de recibo.

| Hito | Fecha vigente | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Ambiente de pruebas certificado | 2026-02-26 | 231 | Acta de certificación del ambiente |
| Piloto con usuarios internos | 2026-05-13 | 155 | Acta de cierre del piloto o informe de resultados |
| Salida a producción | 2026-07-22 | 85 | Acta de paso a producción y medición (el criterio de éxito exige "en producción y medido") |

Los dos hitos con acta: *Diseño funcional aprobado* (acta de recibo del 2026-10-06, hito previsto el 2026-01-19) y *Integración con el core* (acta del 2026-10-11, hito previsto el 2026-04-05). Las dos actas son de meses después de la fecha del hito y se reducen a una línea ("se recibe a satisfacción"), sin criterios ni anexos. Se cuentan como evidencia, pero la fecha de recibo no coincide con la fecha en que el cronograma dice que se cerró cada hito.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 1.200.000.000 | 683.705.364 (57,0 %) | 461.927.421 (38,5 %) | 1.121.091.254 (−6,6 % vs. aprobado) | 516.294.636 |

Cifras en COP. Solo el aprobado tiene documento de origen (acta de constitución). Comprometido, ejecutado y proyección vienen del informe de avance, que es declaración de quien reporta. No hay extracto contable ni ningún otro soporte en la carpeta. No se puede saber si la proyección incluye los 64.000.000 COP de CC-01.

**Proveedor Redes del Norte Ltda. (CT-154):**
- Entregables con fecha pasada y sin recibo: *Licenciamiento del motor* (comprometido 2026-02-02, 255 días de vencido) y *Parametrización del tarifario* (2026-05-17, 151 días). El contrato los marca "en curso".
- *Bolsa de horas de desarrollo* figura "recibido" en el contrato, pero no hay acta de recibo firmada; el contrato exige esa acta para facturar.
- Factura FV-1154 del 2026-09-08 por 105.979.087 COP, radicada en cuentas por pagar, con concepto "Entregables del contrato CT-154" (en plural) y sin decir cuál. Ese valor es el de un solo entregable. Cuántos entregables cubre la factura no se puede saber desde estos documentos.

### Lo que se dijo y nadie registró
- **Riesgos que están en el informe y en ningún registro:** "cambio regulatorio en discusión que puede mover el alcance" y "concentración del conocimiento en una sola persona". No hay registro RAID en la carpeta, ni valoración, ni dueño. El primero es además un riesgo sobre el alcance que CC-01 ya está ampliando.
- **Dependencias:** el acta dice "Ninguna declarada". El proyecto depende del proveedor CT-154 y, según el informe, de una ventana de cambio de Operaciones. Ninguna figura como dependencia.
- **Compromisos de la minuta del 2026-10-14:** uno solo, "Camilo Beltrán — Entregar el punto 5 — 2026-11-08". No hay vencidos. Pero la minuta no define qué es el "punto 5", y Camilo Beltrán no figura como asistente ni en el acta del proyecto.
- La minuta lista dos temas ("Avance", "Compromisos") sin ninguna decisión registrada. No dice que CC-01 se haya tratado.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado "Verde" | Informe de avance 2026-10-15: Verde, 86 % | Cronograma v2 vs. v1 (+32 días sin autorizar), 3 hitos sin evidencia, 2 entregables del proveedor vencidos |
| Avance 86 % | Informe de avance: 86 % | Cronograma v2: 5 de 5 hitos "cerrado" (100 %) |
| "Se reprogramó la salida" en este periodo | Informe 2026-10-15: salida reprogramada por ventana de cambio | Cronograma v2: *Salida a producción* "cerrado" con fecha 2026-07-22; CC-01 explica el movimiento como ampliación de alcance |

### Sin sustento
- Ambiente de pruebas certificado, Piloto con usuarios internos y Salida a producción como "cerrados": ningún documento de recibo.
- Comprometido, ejecutado y proyección al cierre: solo el informe.
- Bolsa de horas de desarrollo "recibida": el contrato lo dice, no hay acta.
- Que el proyecto esté en producción y medido (criterio de éxito): nada en la carpeta.
- Motivo de la v2: el cronograma no lo trae. *Sostenido* (3): presupuesto aprobado de 1.200.000.000 COP, y los dos hitos con acta de recibo.

### Lo que esta carpeta no permite saber
- **Si el proyecto salió a producción:** no hay acta de paso ni medición. Consecuencia: el cierre y el criterio de éxito no se pueden evaluar.
- **Quién autorizó mover la línea base 32 días:** sin autoridad declarada ni decisión del comité, el comité no sabe si decide sobre una fecha ya consumada.
- **Cuánto se ha ejecutado de verdad:** sin soporte contable, el disponible real de 516.294.636 COP es el del informe.
- **Qué cubre la factura FV-1154:** si ya se pagó algo contra un entregable sin acta, el pago está sin la condición contractual.
- **El alcance:** el acta lista "Componente 1, 2 y 3" sin describirlos, así que CC-01 (ampliación de alcance) no se puede medir contra algo.
- **Fase del proyecto** y **autoridad del gerente:** no figuran en ningún documento.

### Después
Esta carpeta no permite validar el estado verde. Dejo para quien tiene la facultad lo que corresponde decidir (no recomiendo detener, continuar ni reestructurar). Ofrezco preparar el punto de comité con la lista de lo que falta, y llevar las 3 contradicciones al gerente como preguntas, una por una.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado; las cifras derivadas (días, porcentajes, disponible) vienen de `portafolio.py compute` del 2026-10-15. Lo declarado por el gerente se separó de lo que los documentos prueban. La verificación es de quien lo lee.*
