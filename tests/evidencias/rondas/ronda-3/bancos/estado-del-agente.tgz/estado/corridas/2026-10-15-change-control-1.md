# Corrida del 2026-10-15 · change-control

13 proyectos · 52 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Solicitud de mover salida a producción 30 días (2026-11-16 a 2026-12-16). Impacto en portafolio: 0 alcanzados, pero el acta declara cero dependencias y el informe nombra una con el core. No dice: solicitante, motivo, costo, autoridad de cambio, vigencia de CT-581, holgura por actividad. Conflicto sin registrar: cierre del acta 2026-12-28 vs fin del cronograma 2026-11-16. Va a comité por falta de autoridad declarada.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-15), con el acta de constitución, el cronograma v1, el contrato CT-581 y el informe de avance del 2026-10-08. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado).

## Solicitud de cambio — PRY-200 Originación digital — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días, del 2026-11-16 al 2026-12-16.
**Quién lo pide:** no consta. La solicitud llegó sin solicitante.
**Por qué:** no consta. Ningún documento de la carpeta registra un motivo para este cambio. El informe del 2026-10-08 trae dos hechos que podrían explicarlo, pero son hipótesis y no motivo declarado: la prueba de carga no alcanzó el umbral pactado y se repite, y dos historias quedaron fuera del sprint por dependencia con el core.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, 2025-09-20) | No declarado | Sin impacto declarado |
| Tiempo | Salida a producción 2026-11-16 (línea base v1, sin replanificaciones) | 2026-12-16 | +30 días |
| Costo | Aprobado 2.400.000.000 COP; proyección al cierre 2.500.311.840 COP (informe 2026-10-08) | No declarado | Sin impacto declarado; la proyección ya excede lo aprobado en 100.311.840 COP (4,2 %) |

**Quién absorbe lo no declarado:** el cambio es solo de tiempo, y nadie dijo que el costo no se mueva. Un mes más de equipo de proyecto, mesa de ayuda y bolsa de horas de CT-581 no es gratis. Si el presupuesto no se amplía, ese mes lo absorbe el proyecto, y la proyección ya está por encima de lo aprobado. Quien pide el cambio debe declarar el costo; este documento no lo inventa.

**Dos observaciones sobre la fecha base:**
- El acta fija el cierre del proyecto en **2026-12-28**. El cronograma v1 y la ficha usan **2026-11-16** como fecha final, y esa es la fecha de la salida a producción. Son dos fechas distintas en dos documentos del mismo día. Mover la salida a 2026-12-16 la deja 12 días antes del cierre del acta, o sea que el cambio cabe en el cierre del acta si ese cierre es el vigente. Hay que aclarar cuál de las dos fechas es la línea base antes de aprobar.
- Los hitos cerrados quedan con fecha vigente igual a la de línea base, y las actas de recibo de dos de ellos son muy posteriores: piloto con usuarios internos (línea base 2026-08-26, acta 2026-10-11) y diseño funcional (línea base 2025-12-21, acta 2026-10-02). No leí esas actas, así que no afirmo que el hito se haya cumplido tarde. Si lo fue, el atraso ya existe y no se replanificó.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact --code PRY-200 --days 30`: 0 proyectos alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

Alcanza el hito «Salida a producción» del propio proyecto (2026-11-16 → 2026-12-16).

**Lo que este resultado no dice:**
- El acta declara «Ninguna dependencia», pero el informe del 2026-10-08 nombra un riesgo por el calendario de liberaciones del core. Una dependencia real no está en la ficha, así que el cálculo no la ve. Un resultado de cero alcanzados significa «ninguna declarada», no «ninguna existe».
- No sé cuántos días se mueve cada actividad intermedia. Eso necesita holgura por actividad y la ficha no la tiene.
- El contrato CT-581 no trae fecha de vigencia en el texto leído. No puedo decir si 30 días más lo desborda. Tampoco que la parametrización del tarifario (vencida desde 2026-06-29, 108 días, sin acta de recibo) cabe en el nuevo calendario.

### Quién decide
**Autoridad requerida:** no determinable. La ficha no tiene autoridad declarada (`identity.authority`: no encontrada) y el acta no fija umbrales de cambio.
**Según:** acta de constitución 2025-09-20, que no contiene cláusula de autoridad ni de control de cambios. Es el hallazgo de fondo.
**Va a comité:** sí. Sin autoridad declarada, no hay a quién delegarle la decisión. El Comité de Banca Empresas aprobó el presupuesto y las fechas, y es el órgano que figura en el acta. Esto es una recomendación del agente. El acta no la establece.

### Si no se aprueba
El proyecto sigue con salida el 2026-11-16, 32 días desde hoy. Con el estado actual (prueba de carga repetida, revisión de seguridad sin disponibilidad confirmada, historias fuera del sprint, declarado 23 % de avance frente a un plan que sustenta entre 80 y 100 % por hitos cumplidos), la fecha se pierde de todos modos, pero sin línea base nueva ni autorización. Es una desviación sin documento que la respalde.

### Si se aprueba
Línea base 2 — salida a producción 2026-12-16 · presupuesto 2.400.000.000 COP (sin cambio declarado) · motivo: **pendiente, nadie lo ha escrito**. Documento que la aprueba: ninguno todavía.
La línea base 1 (aprobada 2025-09-20, cronograma v1) no se toca. Las replanificaciones pasan de 0 a 1.
Desviación acumulada contra la línea base original: **+30 días** en tiempo (salida a producción) · **0 COP** por el cambio, con la salvedad de que la proyección del informe ya está 100.311.840 COP (4,2 %) por encima de lo aprobado antes de cualquier ampliación.

### Qué falta para poder decidir
1. Quién solicita y el motivo escrito.
2. Impacto en costo declarado.
3. Cuál es la fecha base vigente: cierre del acta (2026-12-28) o fin del cronograma (2026-11-16).
4. Autoridad de cambio del proyecto.
5. Vigencia de CT-581 y estado de la parametrización del tarifario.
6. Si el core es una dependencia, registrarla.

**Siguiente paso:** llevarlo al Comité de Banca Empresas (la ficha de portafolio indica comité semanal; próximo 2026-10-21) como paquete de decisión una vez estén los puntos 1 a 3. Si ya lo aprobó alguien con autoridad, indícame el documento y registro la línea base 2.

---
*Pie de rigor:* sale de la ficha PRY-200 y de los documentos citados. Los números de portafolio son del script `impact` y `compute`. El motivo, el solicitante y el costo del cambio son vacíos, no estimaciones. No leí las actas PDF de recibo ni la factura. Esta es una solicitud para revisión, no una aprobación. La verificación es de quien la lea.
