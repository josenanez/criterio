Informe construido con la ficha `estado/records/PRY-201.json` (actualizada 2026-10-15) y el cálculo de `portafolio.py compute` con fecha de corte 2026-10-15.

## PRY-201 · Core de depósitos — estado al 2026-10-15

**Declara el gerente (Laura Vélez):** verde · 30 % · al 2026-09-21 (24 días de antigüedad; fuente: `20-seguimiento/2026-09-21-informe-avance.pdf`)
**Sustento documental:** sin sustento. De los documentos leídos, 0 son evidencia, 2 son declaración y 16 no están marcados. Ningún documento independiente respalda el verde ni el 30 %.
**Lo que el semáforo no explica:** `silent` (24 días sin documentos, desde 2026-09-21) y `variance_cost` (proyección 13.5 % sobre lo aprobado).
**Último documento:** 2026-09-21 · **Última reunión:** sin dato (la ficha no registra actividad ni reuniones)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-12 | 2026-10-12 | 0 días contra la original y contra la vigente |
| Presupuesto (COP) | 4.200.000.000 (aprobado) | 4.200.000.000 | Proyección 4.767.564.975 → 13.5 % sobre lo aprobado (umbral 10 %) |

Dinero: comprometido 2.283.317.036 (54.4 %) · ejecutado 922.042.148 (22.0 %) · disponible real 1.916.682.964.

Replanificaciones: 0. La ficha tiene una sola línea base (v1, aprobada el 2025-11-22 en el acta de constitución).

La fecha de cierre vigente, 2026-10-12, es anterior a la fecha de corte, 2026-10-15. La última declaración (30 %, verde) es de antes de esa fecha. Ningún documento posterior dice si el proyecto cerró, se movió o sigue abierto. El script no calcula esta diferencia como atraso porque no hay replanificación registrada.

### Hitos
Sin hitos en la ficha (`plan.milestones` está vacío). No hay base, vigente ni evidencia de cumplimiento que comparar. El avance de 30 % no se puede contrastar con el plan.

### Dónde no coincide
- **Declarado:** verde, 30 %, al 2026-09-21 (informe de avance).
- **Documentos:** el mismo informe reporta una proyección de 4.767.564.975 contra 4.200.000.000 aprobados, es decir 13.5 % por encima, y el umbral es 10 %. Además, desde ese informe no hay ningún documento en 24 días. Es la alerta `declared_vs_evidence`: verde declarado con dos señales abiertas que ese verde no cubre.
- El mismo informe registra un riesgo: «El proveedor no ha confirmado la fecha de la última entrega». No tiene probabilidad, impacto, dueño ni fecha, y la ficha no tiene proveedores registrados (`vendors` está en `not_found`).
- La declaración tiene 24 días; está por debajo de los 30 del umbral `declaration_stale`, así que todavía no se marca como vencida.

### Abierto
**Riesgos e incidencias sin movimiento:** 1 riesgo (proveedor sin confirmar fecha de la última entrega) sin fecha de último movimiento. Los días sin movimiento no se pueden calcular.
**Compromisos vencidos:** ninguno registrado. La ficha no tiene compromisos, lo que no significa que no existan.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- `identity.authority`: no se encontró la autoridad de aprobación.
- `identity.phase`: no se encontró la fase.
- `plan.milestones`: no hay hitos.
- `vendors`: no hay proveedor ni contrato, aunque el riesgo menciona uno.
- Última reunión y compromisos: sin actividad registrada.
- El PDF del informe de avance no tiene huella de texto (`text_hash` nulo). Conviene verificar a mano que la lectura de sus cifras sea correcta.

### Siguiente paso posible
La proyección supera el umbral de costo, el verde no está sustentado y el cierre planeado ya pasó. Puedo preparar el punto de comité (`/steering-pack`) con este caso. Si el sobrecosto viene de un cambio no formalizado, puedo preparar la solicitud de cambio, pero ningún documento lo dice.

---
*Pie: criterio-portfolio v0.3.9 · ficha PRY-201 con fecha 2026-10-15 · campos inciertos: autoridad, fase, hitos, proveedores, última reunión · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9*
