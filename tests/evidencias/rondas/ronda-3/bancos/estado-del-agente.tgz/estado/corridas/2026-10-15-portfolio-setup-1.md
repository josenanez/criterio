# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 82 documentos, 48 releídos y 34 sin cambio · 129 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 7 |
| `commitment_overdue` | 6 |
| `progress_vs_plan` | 2 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (prueba sin interfaz, valores sugeridos); primer resultado sobre 3 proyectos (PRY-209, PRY-205, PRY-207) en unos minutos; 26 señales: PRY-209 verde contradicho, PRY-207 compromiso reprogramado 6 veces, hitos cerrados sin acta en los tres

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 82 documentos en 13 proyectos · formatos: .md (37), .docx (16), .pdf (14), .xlsx (9), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo, que supuse para el 2026-10-21, me llega el 2026-10-19
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez (2026-10-15) para la versión 0.3.9 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 del .md f0f8a373c9bdced2… y del .pdf 979c05533bd27dac…

Sin interfaz nadie respondió: tomé los valores sugeridos. Estado en `estado/`, informes en `reportes/`. Lo que quieras cambiar (comité, formato, fecha del comité) me lo dices aquí y lo reescribo.

### Probé con tres proyectos

Los de documentación más reciente: PRY-209, PRY-205 y PRY-207.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-209 Nómina electrónica | 10 | Gerente Rubén Cárdenas, patrocinadora Laura Vélez. Declara verde y 86% (informe 2026-10-15). Presupuesto 1.200.000.000 COP: comprometido 683.705.364, ejecutado 461.927.421. Proveedor Redes del Norte (CT-154), factura de 105.979.087 COP. Solicitud de cambio CC-01 pendiente: +32 días, +64.000.000 COP | Facultad del gerente, fase |
| PRY-205 Prevención de lavado de activos | 5 | Gerente María Restrepo, patrocinador Andrés Lozano. Declara rojo y 57% (informe 2026-10-13). Presupuesto 9.500.000.000 COP: comprometido 4.690.295.199, ejecutado 2.710.944.241. Cierre 2026-12-09 | Facultad del gerente, fase, producto (el acta dice «No aplica») |
| PRY-207 Onboarding PyME | 19 | Gerente Mauricio Pérez, patrocinadora Beatriz Cuéllar. Declara amarillo y 65% (informe 2026-10-13). Presupuesto 6.800.000.000 COP: comprometido 6.076.638.985, ejecutado 3.102.676.711. Tiene ficha del gerente (`ficha-pm.json`), que quedó aparte, sin mezclar con la mía | Facultad del gerente, fase |

### Hallazgos (los levantó el cálculo, no la lectura)

**PRY-209 — el verde no se sostiene**
- Declara verde, pero el cálculo lo contradice con cinco señales: avance reportado 86% contra 100% que sustentan los hitos, hitos declarados cerrados sin acta, desviación de 32 días (16,8% contra la línea base original), entregables del proveedor vencidos, y una replanificación no autorizada.
- Hitos cerrados sin acta de recibo: Ambiente de pruebas certificado (vencido 2026-02-26), Piloto con usuarios internos (2026-05-13) y Salida a producción (2026-07-22). Solo Diseño funcional e Integración con el core tienen acta.
- Proveedor Redes del Norte: Licenciamiento del motor (comprometido 2026-02-02, 255 días) y Parametrización del tarifario (2026-05-17, 151 días) siguen «en curso» en el contrato. La Bolsa de horas figura como recibida sin acta de recibo.
- Replanificación no autorizada: la salida a producción pasó de 2026-06-20 a 2026-07-22 en el cronograma v2 (2026-10-15), y la solicitud CC-01 sigue pendiente de comité: 32 días movidos, 0 autorizados.

**PRY-205 — declara rojo, y el rojo es coherente con los documentos**
- Avance declarado 57% contra 80–100% que sustentan los hitos: el proyecto va por detrás de su plan en 23 puntos.
- Tres hitos cerrados sin acta de recibo: Diseño funcional (2026-04-04), Ambiente de pruebas (2026-05-29) e Integración con el core (2026-07-23). El Piloto sí tiene acta (2026-10-15).

**PRY-207 — el compromiso que no se cierra**
- «Cerrar la prueba 2» (Laura Vélez) lleva 6 reprogramaciones: de 2026-09-23 a 2026-12-07. Es un bloqueo que nadie ha nombrado, no seis atrasos sueltos.
- «Enviar el documento 1» (Beatriz Cuéllar) lleva 4 reprogramaciones, hasta 2026-11-03.
- Seis compromisos vencidos sin evidencia: Confirmar la fecha 7 (12 días), Validar el ambiente 12 (13), Cerrar la prueba 18 (6), Aprobar el diseño 21 (3), Entregar el punto 8 (2) y Entregar el punto 16 (1). En dos de ellos, alguien dijo en comité que ya lo había entregado y no se presentó acta.
- Dos compromisos sin fecha: «Enviar el ajuste del presupuesto» («la otra semana») y «Confirmar la fecha 23».
- Hito «Diseño funcional aprobado» cerrado el 2026-09-04 sin acta.
- Contraste con la ficha del gerente: en el cierre del proyecto, su ficha dice 2027-11-03 (acta) y el cálculo de la PMO sale de la última fecha del cronograma, 2027-08-10. Ojo: esa fecha corresponde al hito «Integración con el core», no a un cierre. Hay que preguntarle al gerente cuál es la vigente.
- Se dijo en la reunión del 2026-10-15 que el proveedor podría no llegar con el equipo completo, y nadie lo anotó como riesgo. Queda en la ficha como riesgo no registrado.

**En los tres:** ninguna acta dice hasta qué monto puede decidir el gerente sin subir a comité.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-204, PRY-206, PRY-208, PRY-210 y PRY-211), 60 documentos, en 2 lotes uno tras otro en esta misma conversación · aproximadamente 20 minutos.

### Lo que le falta a tu carpeta
- Los proyectos de mayor vida (PRY-203, PRY-208 y PRY-206, con actas de 2025) tienen pocos documentos de seguimiento: un informe y, en dos de ellos, una sola acta de comité.
- Los hitos que los cronogramas dan por cerrados casi nunca tienen su acta de recibo; es lo que más señales levanta.
- Ninguna acta de constitución declara la facultad del gerente para decidir sin comité.
- Varias actas traen alcance genérico («Componente 1, 2, 3») y «Dependencias: ninguna declarada».
- En PRY-207 hay una nota de reunión suelta en la raíz del proyecto, fuera de `30-reuniones/`.

Ninguno de esto bloquea el análisis.

**Siguiente paso:** puedo correr el portafolio completo. Como eres PMO y es un portafolio de este tamaño, también puedo publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios.
