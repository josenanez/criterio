## Barrido — 2026-10-15

Términos vigentes (v1.1, familia 0.3.9), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9

**Documentos:** 82 en la carpeta · 48 leídos · 34 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia
**Formatos:** .md 37 · .docx 16 · .pdf 14 · .xlsx 9 · .csv 4 · .json 1 · .txt 1. Todo el contenido se leyó por su texto (caché en `estado/cache/texto/`); las citas van a los originales.
**Plan:** 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Nada quedó diferido. Cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | identidad (con producto PRD-299), declarado, plan, 5 hitos, presupuesto, contrato CT-199, riesgos, 1 compromiso | autoridad, fase, facturado |
| PRY-200 Originación digital | 11 | ídem, 4 actas de recibo, factura FV-1581, contrato CT-581, 2 compromisos | autoridad, fase |
| PRY-201 Core de depósitos | 2 | identidad, declarado, presupuesto, riesgo | autoridad, fase, cronograma e hitos, proveedores |
| PRY-202 Migración a la nube | 6 | identidad, línea base v1 y v2, 3 hitos, CC-01, presupuesto, 2 compromisos | autoridad, fase, producto («No aplica»), proveedores |
| PRY-203 Open Banking | 2 | identidad, declarado, presupuesto, riesgos | autoridad, fase, cronograma e hitos, proveedores |
| PRY-204 Débito contactless | 6 | identidad, 5 hitos, contrato CT-470, factura FV-1470, 2 compromisos | autoridad, fase |
| PRY-206 Billetera y QR | 4 | identidad, 4 hitos, presupuesto, 1 compromiso | autoridad, fase, proveedores |
| PRY-208 Motor de decisión | 4 | identidad, 3 hitos, presupuesto, 1 compromiso | autoridad, fase, producto («No aplica»), proveedores |
| PRY-210 Portal de proveedores | 4 | identidad, 3 hitos, presupuesto, 1 compromiso | autoridad, fase, producto («No aplica»), proveedores |
| PRY-211 Cobranza digital | 3 | identidad, 3 hitos, presupuesto, riesgos | autoridad, fase, proveedores, compromisos |

PRY-205, PRY-207 y PRY-209 no cambiaron y no se releyeron (34 documentos).

### Actualizados
Ninguno: las tres fichas previas (PRY-205, PRY-207, PRY-209) no tenían documentos nuevos ni cambiados.

### No pude leer
Ninguno. Los 82 archivos se convirtieron a texto.

### Movidos desde entrada/
Ninguno. No hay carpeta `entrada/` con archivos sueltos en la documentación.

### Pendientes de clasificar
Ninguno.

## Lo que el cálculo levanta (script `compute`, umbrales de la configuración)

**Declarado contra lo que prueban los documentos**
- **PRY-202** declara verde (65 %) y acumula ocho señales: +66 días contra la línea base original (CC-01, ampliación de alcance autorizada «por el comité» sin nombrar cuál), proyección 25,1 % sobre el presupuesto aprobado, los 3 hitos declarados cerrados sin acta de recibo, compromiso de Diana Molina vencido hace 26 días, y avance 65 % cuando el plan sostiene 100 %. Además, el cronograma v2 mueve «Integración con el core» al 2026-08-16, pero el acta fija el cierre en 2026-07-15 y ningún documento declara fecha de cierre nueva: dato que falta, no se infirió.
- **PRY-201** declara verde, sin documento desde el 2026-09-21 (24 días en silencio), proyección 13,5 % sobre el presupuesto, y la fecha de cierre comprometida (2026-10-12) ya pasó sin informe posterior. No hay cronograma.
- **PRY-204** declara rojo. Hito «Integración con el core» vencido hace 7 días; entregable «Licenciamiento del motor» vencido hace 159 días; «Bolsa de horas» figura recibida en el contrato sin acta de recibo, y ya hay una factura FV-1470 por 1.822.428.850 COP; compromiso de Javier Hoyos vencido hace 18 días.
- **PRY-200** declara amarillo con 23 % de avance cuando el plan sostiene 80-100 % (4 de 5 hitos cerrados). Dos hitos cerrados sin acta («Ambiente de pruebas», «Integración con el core»). «Parametrización del tarifario» vencida hace 108 días. Facturado 506.909.451 COP = tres entregables con acta (coincide). Un compromiso sin fecha (Camilo Beltrán).
- **Hitos declarados cerrados sin acta de recibo** (`milestone_met_without_evidence`): PRY-202, 204, 206, 208, 210, 211 (además de los de PRY-200). PRY-199 es la excepción: su único hito cerrado sí tiene acta.
- **Avance declarado por debajo de lo que sostiene el plan:** PRY-208 (29 % frente a 100 %), PRY-210 (51 % frente a 100 %), PRY-211 (31 % frente a 67-100 %), PRY-206 (62 % frente a 75-100 %).
- **Compromisos sin fecha:** PRY-200 (Camilo Beltrán) y PRY-208 (Gustavo Neira). **Vencidos:** PRY-202 y PRY-204.

**Sin señal del cálculo, pero a mirar:** PRY-203 (amarillo, 25 %) reporta ejecutado (3.636.734.860) mayor que comprometido (2.587.925.781), lo cual no debería ocurrir; y su cierre comprometido es 2026-10-29, sin cronograma. PRY-206 y PRY-211 muestran el mismo patrón ejecutado > comprometido. PRY-199 no levanta señales.

**Cobertura de autoridad:** el campo `authority` falta en las 10 fichas nuevas (el acta no lo dice).

**Antigüedad:** varios campos de identidad de PRY-200 y otros provienen de actas de más de 12 meses sin confirmación posterior.

**Del índice:** el `index` de PRY-207 lista 11 campos de `pm_record` cuya cita (`00-gobierno/2026-03-09-acta-constitucion.md`) no resuelve contra la raíz de documentación; es la ficha publicada por el gerente y su ruta es relativa a la carpeta del proyecto. No se tocó; se deja a la vista.

## Pie
criterio-portfolio · familia 0.3.9 · términos v1.1 (https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9)
Fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 206, 208, 210, 211) · fichas sin tocar: 3 (PRY-205, 207, 209)
Campos en `not_found` por ficha: autoridad y fase en las 10; producto en 3 (PRY-202, 208, 210, «No aplica»); facturado en PRY-199; cronograma/hitos en PRY-201 y 203; proveedores en 7 sin contrato.
