# Corrida del 2026-10-15 · project-closure

13 proyectos · 38 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Cierre de PRY-201 por decisión, no por cumplimiento: sin declaración de terminado ni evidencia del criterio de éxito (producción y medido). No supo: entregables por componente, fecha real, ejecución final, doliente del riesgo del proveedor. No archivó la carpeta.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-201.json` y de dos documentos: el acta de constitución (`PRY-201-core-de-depósitos/00-gobierno/2025-11-22-acta-constitucion.docx`) y el informe de avance con corte 2026-09-21 (`PRY-201-core-de-depósitos/20-seguimiento/2026-09-21-informe-avance.pdf`). Las cifras derivadas vienen de `portafolio.py compute` con fecha de cálculo 2026-10-15. Los términos vigentes (v0.3.9) ya estaban aceptados por José Francisco Ñáñez el 2026-10-15; no se registraron de nuevo.

## Cierre — PRY-201 Core de depósitos — 2026-10-15

**Antes de cerrar:** en la documentación no hay ninguna declaración de que el proyecto terminó. El último documento es el informe del 2026-09-21, que lo declara en **verde con 30 % de avance**. La fecha de cierre comprometida, 2026-10-12, ya pasó. Lo que sigue es un **cierre por decisión, no por cumplimiento**: nada demuestra que el criterio de éxito se cumplió. Con lo que hay, el acta de cierre no se puede dar por cumplida.

### Contra lo comprometido
**Criterio de éxito:** "Core de depósitos en producción y medido." (acta, 2025-11-22).
**Se cumplió:** no se puede determinar. Ningún documento muestra puesta en producción ni medición. El único reporte posterior al acta (2026-09-21) dice 30 % de avance, y su propio texto dice que "se reprogramó la salida por ventana de cambio del área de operaciones".

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | No se puede determinar | Acta: aparece solo con ese nombre, sin descripción ni hito |
| Componente 2 | No se puede determinar | Ídem |
| Componente 3 | No se puede determinar | Ídem |

La ficha no tiene hitos (`plan.milestones` vacío). El acta no define qué es cada componente, así que no hay contra qué contrastar lo entregado.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Del acta: "Lo que otro proyecto cubre" (formulación genérica, sin nombrar proyecto) | Acta de constitución | 2025-11-22 |
| Recortes posteriores de alcance | Sin dato: no hay solicitudes de cambio ni decisiones registradas | — |

Sin recortes registrados no hay hallazgo de recorte, pero tampoco hay evidencia del alcance final.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-10-12 | 2026-10-12 | Sin dato (no hay fecha real de cierre) | Sin dato |
| Presupuesto (COP) | 4.200.000.000 aprobado | 4.200.000.000 | Ejecutado al 2026-09-21: 922.042.148 (22,0 % del aprobado) | Proyección al cierre 4.767.564.975: **13,5 %** sobre lo aprobado, por encima del umbral de 10 % |

- Comprometido al 2026-09-21: 2.283.317.036 (54,4 % del aprobado). Disponible real: 1.916.682.964.
- Replanificaciones registradas en la línea base: **0**. El cálculo da 0 días de desviación contra la línea base original y contra la vigente, pero eso sólo dice que no hay otra fecha registrada. El informe habla de una salida reprogramada y ninguna línea base nueva la recoge. Esa reprogramación está sin autorizar ni documentar.
- El ejecutado es del 2026-09-21; no hay cifra de ejecución final. La cifra final del presupuesto no se puede declarar.

### RAID al cierre
**Materializados:** sin dato. Lo único que prueba es la reprogramación de la salida, que el informe reporta como hecho del periodo.
**No materializados:** sin dato.
**Abiertos, con doliente:** hay uno abierto y **no tiene doliente**: "El proveedor no ha confirmado la fecha de la última entrega" (informe 2026-09-21). Probabilidad, impacto y fecha no están declarados, y no se identifica responsable. Mientras no tenga doliente con nombre, no está cerrado.El acta no declara dependencias. Tampoco hay proveedor ni contrato en la ficha (`vendors` vacío), aunque el riesgo menciona uno.

### Lecciones
Ninguna lección se puede sustentar con los documentos que hay. Sólo existen dos, y no tienen hechos fechados con efecto verificable. Estas son observaciones, no lecciones:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El informe declaraba verde con 30 % de avance, con la fecha de cierre comprometida todavía por llegar, una reprogramación de la salida y una proyección 13,5 % sobre el presupuesto | Corte 2026-09-21 | Las señales de silencio (24 días) y de desviación de costo contradicen el verde declarado | Condicionar "verde" a que el informe explique la reprogramación y la proyección. Hace falta que la persona lo confirme; no es un hallazgo del cierre |

### Sin dato
- Si el proyecto terminó, cuándo y con qué resultado. No hay documentos posteriores al 2026-09-21. Lleva 24 días en silencio, desde 2026-09-21; el umbral configurado es 15.
- Si el core de depósitos está en producción y medido (criterio de éxito).
- Qué es cada componente del alcance y si se entregó.
- La nueva fecha de salida, quién autorizó la reprogramación y cuándo.
- Ejecución final del presupuesto.
- Responsable del riesgo abierto, y los datos de autoridad y fase del proyecto (`identity.authority` e `identity.phase`, no encontrados).

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: sin declaración de terminado ni evidencia del criterio de éxito, archivarlo ocultaría un proyecto abierto y en silencio. Cuando Laura Vélez o el Comité de Transformación Digital declaren el cierre y haya documentos que lo respalden, se repite este comando y entonces sí.

*Pie de rigor: borrador de trabajo hecho con la documentación indicada; no es una decisión ni una asesoría. Cada dato lleva la fuente de donde salió, y la verificación es de quien lo usa.*
