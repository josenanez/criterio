# Corrida del 2026-10-15 · product-view

13 proyectos · 20 s · 68 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 25 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 4 |
| `vendor_deliverable_late` | 4 |
| `variance_cost` | 2 |
| `variance_time` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `silent` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |
| `rebaseline_unauthorized` | 1 |

Producto de un solo proyecto (PRY-204); no armé sección de producto. Declaré que faltan identity.authority e identity.phase y que ninguna fuente está marcada como evidencia. Reporté 4 proyectos sin producto.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Producto «tarjeta débito» al 2026-10-15

Fuente: fichas de `estado/records`, recalculadas con `portafolio.py compute` (as_of 2026-10-15). Términos vigentes: v0.3.9, aceptados por José Francisco Ñáñez el 2026-10-15.

**Este producto tiene un solo proyecto: PRY-204 Débito contactless.** La vista por producto no aporta nada distinto a la vista de proyecto, así que no armo sección de producto: solo lo que sale del cálculo.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| tarjeta débito | 1 (PRY-204) | 6 alertas | 2027-04-14 (PRY-204) | COP 18.000.000.000 | COP 14.381.676.241 (79,9 %) |

**Lo que hay que ver (PRY-204):**
- Hito vencido: «Integración con el core», vencía 2026-10-08, 7 días.
- Hitos declarados cumplidos sin evidencia: «Diseño funcional aprobado» (vencía 2026-04-04, 194 días) y «Ambiente de pruebas certificado» (vencía 2026-07-07, 100 días).
- Compromiso vencido: Javier Hoyos, «Entregar el punto 11», vencía 2026-09-27, 18 días (fuente: 30-reuniones/2026-10-10-comite-semanal.docx).
- Proveedor Redes del Norte Ltda. (CT-470): «Licenciamiento del motor» pendiente, vencía 2026-05-09, 159 días; «Bolsa de horas de desarrollo» figura aceptada sin evidencia de recibo.
- El gerente declara **rojo** (informe del 2026-10-05, hace 10 días), y esa declaración no explica cuatro de las señales anteriores. No hay contradicción de semáforo: el rojo es coherente con la evidencia.
- Avance declarado 67 % frente a un plan que sustenta 40–60 % (2 de 5 hitos cumplidos): el declarado está por encima del plan, no por debajo; no cruza el umbral.

**Dinero:** aprobado 18.000.000.000; comprometido 14.381.676.241; ejecutado 4.037.464.048 (22,4 %); proyección 16.668.912.353 (7,4 % por debajo de lo aprobado); disponible real 3.618.323.759. Proveedor: aceptado y facturado 1.822.428.850. Las cuatro cifras están completas.

**Dependencias internas:** no aplica (un solo proyecto). El proyecto no declara dependencias.

**Fecha comprometida del producto:** 2027-04-14, de PRY-204. Sin atraso contra línea base (0 días, 0 replanificaciones, 0 cambios).

**Lo que no sé / faltantes:** `identity.authority` e `identity.phase` no están en la ficha; ninguna fuente está marcada como evidencia (0 de 19; 2 son declaraciones, 17 sin marcar).

## Proyectos sin producto declarado
Cuatro proyectos no declaran producto: PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión, PRY-210 Portal de proveedores. Consecuencia: nadie puede responder por el conjunto al que sirven. La ficha no trae el área dueña, así que no la tabulo. Ninguno afecta a «tarjeta débito».

Pie de rigor: borrador de trabajo, no decisión ni asesoría; cada cifra sale del cálculo sobre las fichas y debe verificarla una persona contra los documentos citados.
