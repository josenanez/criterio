Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`). Modo revisar, PRY-203.

**Acta previa:** sí, del 2025-05-16 (`PRY-203-open-banking/00-gobierno/2025-05-16-acta-constitucion.md`). Es el único documento de gobierno de la carpeta; además hay un informe de avance del 2026-10-10.

## Acta — PRY-203 Open Banking
**Estado:** existe, del 2025-05-16

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente** (el acta no dice monto ni tipo de cambio) | Sandra Gil no tiene un límite escrito. Hoy hay una proyección de 6.811.598.728 COP contra 6.800.000.000 aprobados (+11.598.728, +0,17%) y dos historias sacadas del sprint; sin autoridad declarada nadie sabe si eso lo decide ella o sube al Comité de Riesgos, y por defecto todo sube. |
| Objetivo de negocio | **Es una frase vacía**: "Entregar open banking para Operaciones" | Describe la entrega, no el resultado. No se puede saber si el proyecto cumplió su propósito ni cuándo conviene recortarlo. |
| Alcance | **Marcador sin llenar**: "Componente 1, 2, 3" | No hay línea contra la cual juzgar que "dos historias quedaron fuera del alcance del sprint" sea o no un cambio de alcance. Toda discusión de alcance será de opinión. |
| Exclusiones | **Marcador sin llenar**: "Lo que otro proyecto cubre" | No nombra ningún proyecto ni ningún tema. No protege de nada: la dependencia con el core no queda separada de lo que este proyecto debe construir. |
| Patrocinador | Presente: María Restrepo | — |
| Supuestos y restricciones | **Ausentes** (dependencias: "Ninguna declarada") | El informe de 2026-10-10 reporta dependencia del calendario de liberaciones del core y un proveedor sin fecha confirmada. Ninguna estaba declarada en el acta: hoy son riesgos sin dueño, no supuestos aprobados. |
| Criterio de éxito | **No medible**: "Open Banking en producción y medido" | No dice qué se mide, con qué umbral, ni quién lo mide. El cierre del 2026-10-29 no tiene una prueba de aprobado o fallido. |
| Quién mide el éxito | **Ausente** | Quien reporta el avance es quien se evalúa a sí mismo. |
| Comité y cadencia | Comité de Riesgos presente; **cadencia ausente** | No hay frecuencia de reporte pactada; el informe de avance no se puede declarar tarde ni a tiempo. |
| Hitos principales | **Ausentes** (solo inicio 2025-05-26 y cierre 2026-10-29) | No existe un punto intermedio contra el cual medir el atraso. Con 25% declarado de avance a 14 días del cierre comprometido, no hay hito que muestre dónde se rompió el plan. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar open banking para Operaciones" (acta, sección Objetivo del negocio); eso no es medible.
**Alcance:** pendiente de definir. El acta lista "Componente 1; Componente 2; Componente 3" sin describirlos (acta, sección Alcance).
**Exclusiones:** pendiente de definir. El texto "Lo que otro proyecto cubre" no declara ninguna exclusión concreta.
**Patrocinador:** María Restrepo · **Gerente:** Sandra Gil (acta, encabezado)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento.
**Comité al que reporta:** Comité de Riesgos (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Open Banking en producción y medido" (acta); sin métrica ni umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-05-26 y cierre 2026-10-29 (acta).
**Dato adicional del acta:** presupuesto aprobado 6.800.000.000 COP por Comité de Riesgos el 2025-05-16.

### Lo que el informe muestra y el acta no deja juzgar
Informe del 2026-10-10: estado Amarillo, avance 25%, ejecutado 3.636.734.860 COP (53,5% del aprobado) y comprometido 2.587.925.781 COP (suma 6.224.660.641, 91,5%). El gasto va por delante del avance, y el cierre pactado es el 2026-10-29. Con un acta sin hitos ni criterio de éxito medible, no hay forma de decir desde el acta si "Amarillo" es una descripción razonable. No lo califico: dejo el dato y la brecha.

### Lo que no sé
- Qué se habló en el Comité de Riesgos fuera de documentos: no hay actas de comité de este proyecto en la carpeta.
- Si existe otra versión del acta, un cronograma o un contrato con el proveedor: la carpeta solo tiene dos documentos.
- Quién es el proveedor ni qué debe entregar.

## Después
- El acta quedó sin autoridad declarada: te ofrezco llevar esa definición al Comité de Riesgos (próximo comité semanal: 2026-10-21). Es una decisión, no un trámite.
- Del informe salen dos riesgos sin dueño ni valoración y un hallazgo de seguridad sin fecha ni responsable: te ofrezco pasarlos al registro RAID (`/raid-log`).

*Pie de rigor: borrador de trabajo basado solo en los dos documentos citados; no es decisión ni asesoría. Cada dato lleva su fuente; la verificación es tuya.*
