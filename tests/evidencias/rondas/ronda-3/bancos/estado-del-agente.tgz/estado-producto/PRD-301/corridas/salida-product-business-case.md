# Caso de negocio — Nómina empresarial (PRD-301) · borrador del 2026-10-15
**Desde:** la definición y el caso de negocio del 2025-09-03 · **Cifras con fuente:** 2 de 3 (la tercera, el retorno, no tiene cifra)

*Gerente de producto: Paula Céspedes. Autoridad: Comité de producto (ninguna persona figura como quien decide). Términos v1.1 ya vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.*

## Qué problema resuelve, y para quién
«El segmento Base de la pirámide no tiene nómina empresarial.» (Definición de producto, 2025-09-03). Para: Base de la pirámide (misma fuente).
Sustento: una sola entrevista anónima, «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, 2025-09-20). Es débil —una voz, sin mención del segmento— y tiene 13 meses (umbral 12).

## Qué se construye
La propuesta en la definición dice solo «Propuesta principal»: **no está dicho qué incluye.** Los requerimientos decididos son 17 aceptados el 2026-10-10 (acta del Comité de producto, asistente único: Paula Céspedes). El 18.º, REQ-4104, sigue propuesto hace 71 días (umbral 60).

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4101, 4102, 4103, 4105, 4106, 4107, 4109, 4110, 4111, 4112, 4113, 4114, 4115, REQ-2030, REQ-2038 (15) | aceptado | «Cliente entrevistado» (2025-09-20); la cita no nombra ninguno de ellos |
| **REQ-4100** (Elena Duarte), **REQ-4108** (Andrés Lozano) | aceptado | **Ninguna: nadie consta como quien lo pidió** |
| REQ-4104 (Ricardo Salas) | propuesto | «Cliente entrevistado» (2025-09-20) |

Ninguno de los 17 aceptados declara proyecto que lo ejecute; en el acta no consta quién decidió; REQ-4109 no tiene doliente; 6 aceptados no tienen criterio de aceptación y los otros 11 traen «se verifica en producción», que no es medible. Los títulos son solo el identificador: el contenido de cada requerimiento no está en ningún documento.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 267.895 | **Declarada** | Caso de negocio (00-definicion/2025-09-03-caso-de-negocio.md), preparado por Paula Céspedes. No dice de dónde sale el número | 2025-09-03 |
| volumen_mensual | 201.716 | **Medida** | Tablero de métricas, bodega de datos (20-metricas/2026-09-29-tablero-metricas.md) | corte 2026-09-29 |
| «Retorno esperado en 24 meses» | sin cifra | **Supuesta** (ni siquiera declarada con valor) | Caso de negocio, una línea, sin base de cálculo | 2025-09-03 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 267.895 | 201.716 | 24,7 % por encima, contra umbral de 20 %. Caso de negocio, 2025-09-03 · Tablero de métricas, corte 2026-09-29 |

Dos reservas que van dentro del caso: el tablero no define qué cuenta en volumen_mensual, y la serie tiene un solo punto. No se sabe si ambas cifras miden lo mismo; la diferencia es real contra ese punto. Tampoco se sabe si 267.895 era una meta o una línea de partida.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no hay** | Ningún documento de la carpeta |
| Contratos, cotizaciones, costo del equipo | **no hay** | Ningún documento |
| Costo de operar | **no hay** | Ningún documento |

No se estima ninguno. **El costo de construir es el primer vacío: sin él esto es una propuesta, no un caso de negocio que se pueda evaluar.**

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La regulación vigente lo permite» (marcado «verificado», declarado el 2026-05-30; el documento es del 2025-09-03) | El producto entero no se puede ofrecer. Está «verificado» sin citar con qué | Revisión jurídica; Paula Céspedes aporta el concepto o la norma, con fecha y responsable |
| Que 267.895 transacciones mensuales es una cifra alcanzable (implícita) | El caso se apoya en un volumen que hoy se mide 24,7 % menor | Quien produce el tablero, definiendo qué cuenta |
| Que lo dicho por un solo cliente representa al segmento Base de la pirámide (implícita) | Los 17 requerimientos aceptados quedan sin demanda demostrada | Paula Céspedes, con nuevas entrevistas |
| Que habrá retorno en 24 meses (implícita) | No hay con qué contrastarlo | El negocio, con cifra y base de cálculo |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso evaluable | Finanzas / Paula Céspedes |
| Cifra de retorno y su base de cálculo | «Retorno esperado en 24 meses» no se puede verificar ni cerrar | El negocio |
| De dónde sale el 267.895 | Es la única cifra que sostiene el caso y no tiene origen | Paula Céspedes |
| Qué cuenta en volumen_mensual | Declarada y medida pueden no ser comparables | Dueño del tablero |
| Criterio de éxito y su fecha de corte | Sin él el producto no se puede cerrar | Paula Céspedes / Comité de producto |
| Quién decide (una persona) | Solo consta el nombre del comité | Comité de producto |
| Qué incluye la propuesta | Dice «Propuesta principal» | Paula Céspedes |
| País de operación | Sin él no se nombra la norma de datos personales, pagos de salarios y retención laboral | Paula Céspedes; luego revisión jurídica |
| Qué pasa si no se hace; alternativas consideradas | El caso no las menciona | El negocio |
| Proyecto que construye los requerimientos | Ninguno declarado | Paula Céspedes (`/product-trace`) |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento fija el criterio de éxito, su métrica ni su fecha de corte. La única métrica con serie es volumen_mensual, pero ningún documento dice que sea el criterio de éxito. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
Ninguno publicado a la vista: la carpeta `estado` está vacía, así que no se pudo hacer el cruce de métricas. En `documentos/productos` hay carpetas de otros productos (PRD-299 a PRD-309), pero sin ficha publicada; no las cruzo. Queda sin verificar si otro producto cuenta las mismas transacciones.

## Después
Los supuestos (regulatorio, volumen, representatividad del segmento, retorno) se pueden pasar a seguimiento con assumption-tracking. No ofrezco `/product-charter`: la definición no está cerrada (falta criterio de éxito y quién decide) y el caso no tiene costos. Este documento no recomienda aprobar ni rechazar.
