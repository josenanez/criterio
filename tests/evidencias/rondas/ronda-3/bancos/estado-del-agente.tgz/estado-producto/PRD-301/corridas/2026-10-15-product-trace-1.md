# Corrida del 2026-10-15 · product-trace

PRD-301 · 18 requerimientos · 28 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 16 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `claim_vs_metric` | 1 |

17 requerimientos decididos el 2026-10-10 y ningún proyecto los construye; PRY-209 dice ejecutar nómina empresarial y ningún REQ lo nombra

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Nómina empresarial (PRD-301) · al 2026-10-15
17 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

(Fichas leídas: 13 en `estado/records` — PRY-199 a PRY-211.)

### Decidido y nadie lo está construyendo
Los 17 requerimientos aceptados, decididos el 2026-10-10 por el Comité de producto (acta `documentos/productos/PRD-301/30-decisiones/2026-10-10-comite-producto.docx`). Ninguno nombra proyecto: el registro dice «El acta no declara proyecto que lo ejecute (—)».

| REQ | Responsable | Decidido el | Por quién |
|---|---|---|---|
| REQ-2030 | Felipe Arango | 2026-10-10 | Comité de producto |
| REQ-2038 | Laura Vélez | 2026-10-10 | Comité de producto |
| REQ-4100 | Elena Duarte | 2026-10-10 | Comité de producto |
| REQ-4101 | Laura Vélez | 2026-10-10 | Comité de producto |
| REQ-4102 | Diana Molina | 2026-10-10 | Comité de producto |
| REQ-4103 | Natalia Ospina | 2026-10-10 | Comité de producto |
| REQ-4105 | Ricardo Salas | 2026-10-10 | Comité de producto |
| REQ-4106 | Beatriz Cuéllar | 2026-10-10 | Comité de producto |
| REQ-4107 | Óscar Ramírez | 2026-10-10 | Comité de producto |
| REQ-4108 | Andrés Lozano | 2026-10-10 | Comité de producto |
| REQ-4109 | (sin responsable) | 2026-10-10 | Comité de producto |
| REQ-4110 | Mauricio Pérez | 2026-10-10 | Comité de producto |
| REQ-4111 | Javier Hoyos | 2026-10-10 | Comité de producto |
| REQ-4112 | Sandra Gil | 2026-10-10 | Comité de producto |
| REQ-4113 | Javier Hoyos | 2026-10-10 | Comité de producto |
| REQ-4114 | Ricardo Salas | 2026-10-10 | Comité de producto |
| REQ-4115 | Javier Hoyos | 2026-10-10 | Comité de producto |

REQ-4104 sigue «propuesto» (71 días sin decidir) y no entra en esta lista.

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar, porque ningún requerimiento nombra proyecto. La cadena se rompe en el eslabón decisión → proyecto, en los 17.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-209 «Nómina electrónica» | «nómina empresarial» (acta de constitución 2025-12-02, `PRY-209-nómina-electrónica/00-gobierno/2025-12-02-acta-constitucion.docx`) | Ningún REQ de PRD-301 nombra a PRY-209 |

Es probable que PRY-209 sea el proyecto de los 17 decididos, pero eso no lo dice ningún documento: lo que hay es una coincidencia de nombre de producto, y la conexión la tiene que hacer una persona.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 17 REQ aceptados (lista arriba) | aceptado | Comité de producto, 2026-10-10 | — | no | — |
| REQ-4104 | propuesto | sin decidir | — | no | — |

### Sin fichas a la vista
Ninguna ficha se pudo cruzar con un requerimiento, porque el registro no cita proyectos. Las otras 12 fichas declaran otros productos o ninguno, y no se tocan.
