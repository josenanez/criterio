## Definición — Nómina empresarial (PRD-301) · contrastada al 2026-10-15
**Documento:** documentos/productos/PRD-301/00-definicion/2025-09-03-definicion-producto.docx (con el caso de negocio del mismo día) · **del** 2025-09-03 · 6 afirmaciones

### Lo que la evidencia contradice
Nada contradice la definición de frente. La única diferencia está en las cifras (sección siguiente).

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 267.895 | 201.716 | 24,7 % (declarado por encima; umbral 20 %) | Caso de negocio, 2025-09-03 (00-definicion/2025-09-03-caso-de-negocio.md) · Tablero de métricas, corte 2026-09-29 (20-metricas/2026-09-29-tablero-metricas.md) |

Dos reservas: el tablero no define qué cuenta en volumen_mensual, y la serie tiene un solo punto. La diferencia es real contra ese punto, pero no se sabe si ambos miden lo mismo.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses.» | Caso de negocio, 2025-09-03 | Sin cifra, sin base de cálculo y sin ninguna serie que la siga. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara.
- **Quién decide.** El acta del 2026-10-10 nombra al «Comité de producto» (único asistente: Paula Céspedes); ninguna persona figura como quien decide.
- **Qué incluye la propuesta.** Dice solo «Propuesta principal».
- **Qué cuenta en volumen_mensual** y cómo se mide.
- **En qué país opera el producto.** Sin eso no se puede nombrar la norma que aplica.
- **De dónde sale el 267.895** del caso de negocio.
- **Con qué se verificó la regulación** (ver supuestos).
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado». Ninguno de los 17 requerimientos aceptados tiene proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La regulación vigente lo permite» (marcado «verificado», declarado el 2026-05-30) | 0: figura verificado, pero sin cita | El documento no dice con qué se verificó, y la fecha del supuesto (2026-05-30) es posterior a la del documento (2025-09-03). Haría falta el concepto o la norma citados, con fecha y responsable. Es el que sostiene el producto entero. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Base de la pirámide no tiene nómina empresarial | Una entrevista: «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, tema «Necesidad principal») | 2025-09-20 | Débil: una sola voz, anónima, dicha y no pagada, y no menciona el segmento Base de la pirámide. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema y la necesidad del segmento (también 15 de los 17 requerimientos aceptados, atribuidos a «Cliente entrevistado») | Entrevista del 2025-09-20 | 12 meses o más (13 al 2026-10-15; umbral 12) |

Es la única entrevista de la carpeta. La cita no nombra ninguno de los requerimientos que se le atribuyen.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de empleados (nómina) | No dicho | Tratamiento de datos personales | — | No tengo la norma a la vista |
| Pagos de salarios | No dicho | Condiciones del pago | — | No tengo la norma a la vista |
| Retención de la información laboral | No dicho | Plazos de conservación | — | No tengo la norma a la vista |

Esto va a revisión jurídica, no la reemplaza. No se dice si el producto cumple. Los documentos no dicen el país, así que no se nombra ninguna norma concreta.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** falta una persona. Solo está el nombre del comité.
- **Problema y para quién:** están declarados (Base de la pirámide). Faltan evidencia actual y el contenido de la propuesta.

### Después
- El supuesto regulatorio es candidato a riesgo con doliente (raid-taxonomy).
- La definición **no** está cerrada, así que no corresponde ofrecer `/product-charter`.
