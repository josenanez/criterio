# Corrida del 2026-10-15 · product-charter

PRD-301 · 18 requerimientos · 31 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 16 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4100 con 9 vacíos: sin evidencia de demanda, sin persona que aceptó, criterio no medible, sin autoridad ni patrocinador. No se creó la ficha: el acta no está firmada. Supuesto regulatorio sin fuente.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Los términos de esta versión (1.1, criterio-product 0.3.9) ya estaban vigentes: los aceptó José Francisco Ñáñez el 2026-10-15 y el comprobante está en `.criterio/terminos/`. No hubo que registrarlos de nuevo.

**Verificación previa (paso 1) — REQ-4100 no cumple todo lo que el acta necesita.** Como nadie puede responder en esta sesión, tomo la respuesta sugerida: **sigo adelante y marco cada faltante como vacío del acta, sin rellenarlo.**

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado» el 2026-10-10 (`documentos/productos/PRD-301/30-decisiones/2026-10-10-comite-producto.docx`). Pero la decisión no tiene persona que decide: el único asistente es Paula Céspedes y no se dice quién aceptó. |
| Criterios de aceptación verificables | Parcial: «se verifica en producción» (mismo docx). Dice dónde se verifica, no qué se mide ni con qué umbral. |
| Evidencia de demanda con su cita | **No.** «Quién lo pidió» es «—» en el comité; el registro tiene `evidence: []`. |
| Autoridad declarada en la definición | **No.** La definición (`2025-09-03-definicion-producto.docx`) no declara qué puede decidir el gerente. De «Comité de producto» solo está escrito el nombre del comité. |

---

# Acta de constitución — Nómina empresarial · borrador del 2026-10-15
**Producto:** PRD-301 Nómina empresarial · **Requerimientos:** REQ-4100

## Qué problema resuelve
«El segmento Base de la pirámide no tiene nómina empresarial.» (`documentos/productos/PRD-301/00-definicion/2025-09-03-definicion-producto.docx`, 2025-09-03). La definición no dice qué sería éxito ni qué ofrece la propuesta más allá de «Propuesta principal».
**El requerimiento REQ-4100 no tiene título ni descripción propios:** el comité lo llama «Requerimiento REQ-4100» (comité del 2026-10-10). El acta no puede decir qué se construye.

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| «se verifica en producción» (comité 2026-10-10) | **No está dicho.** Falta la medida, el umbral y quién verifica. Es un vacío, no un criterio. |

La definición del producto tampoco declara criterio de éxito (`definition.success`: no encontrado).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4100 | «Requerimiento REQ-4100» (sin título propio) | **Ninguna.** «Quién lo pidió: —». Doliente: Elena Duarte; desde 2026-06-01. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4101 a REQ-4115, REQ-2030, REQ-2038 | «Requerimiento REQ-xxxx» | No se pidieron en esta invocación. No es una decisión de exclusión del comité: el comité no dice nada sobre alcance (su única decisión escrita es «Se mantiene el plan»). Qué se excluye y por qué queda para quien firme. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no se nombra. Paula Céspedes es gerente de **producto** (definición, 2025-09-03); si gerencia el proyecto lo decide quien tiene la autoridad.
- **Comité:** Comité de producto (comité 2026-10-10). Único asistente: Paula Céspedes.
- **Autoridad del gerente:** no está dicha.
- **Quién aceptó REQ-4100:** no está dicho (`decision.who`: no encontrado).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La regulación vigente lo permite» (definición, 2025-09-03; declarado el 2026-05-30) | Dice «verificado» **sin citar con qué**. La fecha del supuesto (2026-05-30) es posterior a la del documento (2025-09-03). | Por asignar. Propongo registrarlo como riesgo del proyecto hasta que tenga fuente. El doliente lo nombra quien firme. |
| REQ-4100 no declara supuestos propios | — | — |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Nómina empresarial (pagos y datos de empleados) | No está relevada | No identificada en los documentos | **Sin resolver.** El supuesto de arriba afirma que la regulación lo permite, pero no cita norma. No opino sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Evidencia de demanda de REQ-4100 («Quién lo pidió: —») | El proyecto arranca sin saber quién lo necesita ni si se sostiene | Paula Céspedes, con Elena Duarte |
| Persona que aceptó el requerimiento | La aceptación no se puede rastrear a una decisión | Comité de producto |
| Criterio de aceptación medible | El cierre no se podrá juzgar | Elena Duarte |
| Autoridad del gerente | El gerente escalará todo o nada | Comité de producto |
| Patrocinador | No hay quien responda por el presupuesto | Comité de producto |
| Título y descripción de REQ-4100 | No se sabe qué se construye | Elena Duarte |
| Criterio de éxito del producto, retorno sin cifra («Retorno esperado en 24 meses», caso de negocio 2025-09-03) | No hay contra qué medir el proyecto | Paula Céspedes |
| Fuente del supuesto regulatorio | Un riesgo normativo queda dado por cerrado | Quien declaró el supuesto |
| Presupuesto e hitos | El acta no los declara | Quien firme |

---
**Esto es un borrador.** Lo firma una persona con autoridad; no está designada en los documentos. **La ficha del proyecto no se creó:** una ficha creada sobre un acta sin firma es un proyecto que existe en el sistema y no en la organización. Tampoco se escribió el estado declarado.

**Qué sigue y para quién:** quien firme decide qué hacer con los vacíos. Con el acta firmada, vuelve a correr este comando para crear la ficha. El gerente del proyecto que se designe instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
