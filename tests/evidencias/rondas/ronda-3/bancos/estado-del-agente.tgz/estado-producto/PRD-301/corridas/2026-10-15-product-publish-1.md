# Corrida del 2026-10-15 · product-publish

PRD-301 · 18 requerimientos · 15 s · 44 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 16 |
| `requirement_without_acceptance` | 6 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 1 |
| `requirement_without_owner` | 1 |
| `claim_vs_metric` | 1 |

No se publicó: no hay carpeta de productos publicados configurada

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-301.** La configuración no tiene una carpeta de productos publicados (`paths` solo trae `documents` y `state`), y en el espacio no existe ninguna carpeta `publicados`. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la creé ni la inventé.

Corte al 2026-10-15. Esto es lo que habría llevado la ficha (cifras de `producto.py publish`):

**Lleva:** 18 requerimientos · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Base de la pirámide
**Métricas:** `volumen_mensual`, 267895, del caso de negocio `documentos/productos/PRD-301/00-definicion/2025-09-03-caso-de-negocio.md` (2025-09-03).

Antes de publicar, ten en cuenta:
- Ningún requerimiento tiene proyecto: los 17 aceptados salen sin trazar.
- El tablero de métricas del 2026-09-29 mide 201716 de `volumen_mensual`. La definición declara 267895, 24.7 % por encima. La ficha publica la cifra declarada, no la medida.

Para publicar: indica la carpeta común de productos publicados, agrégala a la configuración y vuelve a correr el comando.
