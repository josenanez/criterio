# Especificación — Nómina empresarial (PRD-301) · borrador del 2026-10-15

> **Esto es un borrador. Lo cierra Paula Céspedes (gerente de producto) con el Comité de producto; este agente no aprueba ni firma.**
> Resultado en una línea: **el registro no alcanza para especificar comportamiento.** Los 18 requerimientos tienen como título «Requerimiento REQ-xxxx», ninguno tiene la necesidad escrita, y la propuesta de la definición es el texto «Propuesta principal». Escribir comportamiento sería inventarlo, así que no lo escribí: lo que sigue deja los huecos a la vista.

## Qué problema resuelve

«El segmento Base de la pirámide no tiene nómina empresarial.» (definición de producto, 2025-09-03, `00-definicion/2025-09-03-definicion-producto.docx`).

Es todo lo que la definición dice. No dice qué es «nómina empresarial» para ese segmento, ni el país, ni el criterio de éxito del producto (`success`: no está dicho en ninguna parte). La propuesta es el texto «Propuesta principal», que no describe nada.

## Alcance

### Entra (propuesta que sale del registro, no decisión)
17 requerimientos en estado `aceptado`, todos por el Comité de producto del 2026-10-10 (`30-decisiones/2026-10-10-comite-producto.docx`):
REQ-2030, REQ-2038, REQ-4100, REQ-4101, REQ-4102, REQ-4103, REQ-4105, REQ-4106, REQ-4107, REQ-4108, REQ-4109, REQ-4110, REQ-4111, REQ-4112, REQ-4113, REQ-4114, REQ-4115.

Ninguno está `en_construccion`: el acta no declara proyecto que ejecute ninguno, y la definición dice «Proyectos que lo construyen: Ninguno declarado».

### No entra
- **REQ-4104** (Ricardo Salas): sigue `propuesto`, nadie decidió nada. Especificarlo sería escribir el documento dos veces.
- Todo lo que no esté en el registro. Ningún documento nombra funciones, canales, países, integraciones ni segmentos distintos de «Base de la pirámide»; no los agrego.
- Diseño técnico, estimación de esfuerzo, costo y fechas: no son de este documento.

## Comportamiento

**No redactado.** Para cada uno de los 17 el registro solo tiene: un título genérico, un doliente, un criterio de aceptación (11 de 17: «se verifica en producción»), y una cita de evidencia que no nombra el requerimiento. Con eso no hay un comportamiento que describir sin ponerle palabras al autor. Cada sección de comportamiento nacerá cuando el doliente de cada REQ escriba su necesidad (ver Vacíos, fila 1).

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (texto del acta) | REQ-2038, 4100, 4101, 4102, 4105, 4106, 4107, 4109, 4110, 4111, 4114 (11) | **No pasa la prueba.** No dice qué se observa, con qué umbral ni quién. Dos personas mirando lo construido no llegarían a la misma respuesta. Es una ubicación, no un criterio. | No. Nada que medir. |
| Sin criterio | REQ-2030, 4103, 4108, 4112, 4113, 4115 (6) | No hay nada que verificar. El acta tiene «—». | No |
| Referencia a métrica | Ninguno | El único dato medido en la organización es `volumen_mensual` (tablero de métricas, 2026-09-29: 201.716). Ningún criterio de ningún REQ lo usa. | Esa métrica sí; ningún criterio se apoya en ella |

Hallazgo: **0 de 17 requerimientos aceptados tienen un criterio de aceptación verificable.** Los criterios que habría que escribir tampoco puedo proponerlos sin conocer la necesidad; un umbral inventado se vería completo y lo decidiría el agente.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La regulación vigente lo permite» (definición) | **Marcado «verificado» sin citar con qué.** Además lo fecha el 2026-05-30, posterior al documento (2025-09-03). Lo trato como **no verificado**: no hay fuente que citar. | Paula Céspedes, con la revisión jurídica de la organización |
| Los registros de los 18 requerimientos no declaran ningún supuesto | — | No inventé los que el autor «obviamente tenía»: es *no está dicho en ninguna parte* |
| Contraste de cifra (no es supuesto declarado, pero sostiene el caso): volumen declarado 267.895 (caso de negocio, 2025-09-03) vs medido 201.716 (tablero, 2026-09-29) | La brecha es de **24,7 %**, sobre el umbral de 20 % de la configuración. Ninguna fuente gana por defecto. | Paula Céspedes |

Evidencia de demanda: la única es una entrevista de 2025-09-20 («Lo necesito y hoy no lo tengo.», Cliente entrevistado, tema «Necesidad principal»). Tiene 13 meses (umbral: 12), la cita **no nombra ningún requerimiento** y no dice quién es el cliente. REQ-4100 y REQ-4108 no tienen ninguna evidencia. Los otros 15 se apoyan en esa misma cita.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Necesidad y título de cada requerimiento** (los 18 son «Requerimiento REQ-xxxx»; `need` sin escribir) | No hay qué especificar; cualquier sección sería invención | El doliente de cada REQ (ver tabla final); Paula Céspedes consolida |
| **Criterio de aceptación verificable** para los 17 (11 con «se verifica en producción», 6 sin criterio) | Se construye sin poder decir si quedó bien; la discusión ocurre después | Doliente de cada REQ, con Paula Céspedes |
| **Doliente de REQ-4109**: el acta dice «sin asignar» | Aceptado sin persona que responda por él | Comité de producto (nombrarla); sin persona decidiendo hoy |
| **Proyecto que ejecuta cada aceptado**: ninguno (acta «—» en los 17; el acta solo dice «Se mantiene el plan» y no hay plan en los documentos) | Un `aceptado` exige proyecto; hoy 17 decisiones sin quien las construya | Comité de producto / Paula Céspedes (dispara `/product-charter` cuando haya criterio) |
| **Quién decidió**: el acta tiene un único asistente (Paula Céspedes) y ninguna persona figura como quien decide | La autoridad del comité no está respaldada por una persona nombrada | Paula Céspedes, definiendo quién firma |
| **Fechas de aceptación inconsistentes con el acta**: la columna «Desde» va de 2026-03-16 a 2026-10-03, pero el acta que los registra es del 2026-10-10 | No se sabe si la aceptación es anterior (¿qué documento la registró?) o se puso por defecto | Paula Céspedes |
| **Evidencia de demanda**: una sola entrevista, vieja y sin nombrar requerimiento; REQ-4100 y REQ-4108 sin evidencia (el acta tampoco dice quién los pidió) | Aceptados sin sustento de demanda; el aceptado exige evidencia | Paula Céspedes (nueva ronda de entrevistas) |
| **Casos borde sin definir** (falla de conexión, pago duplicado, rechazo de una dispersión, empleado retirado, corrección de una nómina ya pagada, etc.): ningún documento dice nada | Comportamiento decidido por quien construya | Doliente de cada REQ, una vez escrita la necesidad |
| **Lo que otro equipo tiene que hacer**: ningún documento nombra equipos ni dependencias | No hay acuerdo con nadie; se descubre al construir | Paula Céspedes (inventario de dependencias) |
| **Criterio de éxito del producto** y alcance del «retorno esperado en 24 meses» (sin cifra) | No hay con qué juzgar si el producto funcionó | Paula Céspedes |
| **País y obligaciones normativas** (ver barrido abajo) | Obligaciones decididas tarde, tras construir | Paula Céspedes con revisión jurídica |

### Barrido normativo (primero, citando solo lo que sé; revisión jurídica pendiente)

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Una nómina maneja datos de personas (empleados) y sus ingresos | no dicho en ninguna parte | Tratamiento de datos personales: autorización, finalidad, encargado | — | no tengo la norma a la vista (no hay país) |
| Mueve dinero de la empresa a los empleados | no dicho | Quién puede dispersar fondos y con qué autorización | — | no tengo la norma a la vista |
| Conserva registros de pago y de pago de nómina | no dicho | Retención y trazabilidad | — | no tengo la norma a la vista |
| «La regulación vigente lo permite» | no dicho | Declarado verificado sin cita | — | **sin resolver** |

Esto nombra, no dictamina cumplimiento. No inventé normas.

## Requerimientos aceptados que esta especificación no cubre

Ninguno tiene sección de comportamiento. Razón común: el registro no trae la necesidad ni título descriptivo. Se añade lo particular de cada uno.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 (Felipe Arango) | Sin necesidad; **sin criterio de aceptación** |
| REQ-2038 | Requerimiento REQ-2038 (Laura Vélez) | Sin necesidad; criterio no verificable |
| REQ-4100 | Requerimiento REQ-4100 (Elena Duarte) | Sin necesidad; criterio no verificable; **sin evidencia ni solicitante** |
| REQ-4101 | Requerimiento REQ-4101 (Laura Vélez) | Sin necesidad; criterio no verificable |
| REQ-4102 | Requerimiento REQ-4102 (Diana Molina) | Sin necesidad; criterio no verificable |
| REQ-4103 | Requerimiento REQ-4103 (Natalia Ospina) | Sin necesidad; **sin criterio** |
| REQ-4105 | Requerimiento REQ-4105 (Ricardo Salas) | Sin necesidad; criterio no verificable |
| REQ-4106 | Requerimiento REQ-4106 (Beatriz Cuéllar) | Sin necesidad; criterio no verificable |
| REQ-4107 | Requerimiento REQ-4107 (Óscar Ramírez) | Sin necesidad; criterio no verificable |
| REQ-4108 | Requerimiento REQ-4108 (Andrés Lozano) | Sin necesidad; **sin criterio, sin evidencia ni solicitante** |
| REQ-4109 | Requerimiento REQ-4109 (**sin doliente**) | Sin necesidad; criterio no verificable; sin persona responsable |
| REQ-4110 | Requerimiento REQ-4110 (Mauricio Pérez) | Sin necesidad; criterio no verificable |
| REQ-4111 | Requerimiento REQ-4111 (Javier Hoyos) | Sin necesidad; criterio no verificable |
| REQ-4112 | Requerimiento REQ-4112 (Sandra Gil) | Sin necesidad; **sin criterio** |
| REQ-4113 | Requerimiento REQ-4113 (Javier Hoyos) | Sin necesidad; **sin criterio** |
| REQ-4114 | Requerimiento REQ-4114 (Ricardo Salas) | Sin necesidad; criterio no verificable |
| REQ-4115 | Requerimiento REQ-4115 (Javier Hoyos) | Sin necesidad; **sin criterio** |

Fuera del alcance por estado: REQ-4104 (`propuesto`).

## Después

`/product-charter` **no corresponde todavía**: exige vacíos cerrados y criterio de éxito. Lo primero es que cada doliente escriba la necesidad y el criterio de su requerimiento, y que Paula Céspedes defina país, criterio de éxito del producto y proyecto responsable.

---
**Pie.** Sale del registro `estado-producto/PRD-301/requirements/` (18 requerimientos; 17 `aceptado` considerados, 1 `propuesto` excluido), actualizado el 2026-10-15, contrastado con la definición (2025-09-03), el caso de negocio (2025-09-03), la entrevista (2025-09-20), el tablero de métricas (2026-09-29) y el acta del comité (2026-10-10). Requerimientos cubiertos con comportamiento: **0 de 17**. Términos aceptados por José Francisco Ñáñez (v0.3.9, 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.9
