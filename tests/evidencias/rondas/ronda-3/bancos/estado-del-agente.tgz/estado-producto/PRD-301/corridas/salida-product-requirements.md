## Registro — Nómina empresarial (PRD-301) · al 2026-10-15
18 requerimientos · 17 decididos · 88,2 % con evidencia · 0 % con proyecto que lo ejecuta

*Nota de la corrida: la carpeta de fichas de proyecto (`estado`) está vacía, así que ninguna traza se pudo confirmar contra una ficha. El 0 % de proyecto es lo que dice el acta (ningún requerimiento declara proyecto), no una verificación contra fichas.*

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió.
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | aceptado | Elena Duarte |
| REQ-4108 | Requerimiento REQ-4108 | aceptado | Andrés Lozano |

Quien lo cerraría: cada doliente aporta la cita de quien lo pidió, o el Comité de producto lo devuelve a `propuesto`.

### Decidido y nadie lo está construyendo
Los 17 aceptados el 2026-10-10 (acta del comité de producto) y ninguno declara proyecto que lo ejecute: REQ-2030, REQ-2038, REQ-4100 a REQ-4103, REQ-4105 a REQ-4115. Quien lo cerraría: Paula Céspedes (gerente de producto), con `/product-trace` y luego `/product-charter` para el primero que esté listo.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4109 | Requerimiento REQ-4109 | Sin doliente en el acta |

Quien lo cerraría: Paula Céspedes asigna una persona.

### Sin criterio de aceptación
Solo decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado |
| REQ-4103 | Requerimiento REQ-4103 | aceptado |
| REQ-4108 | Requerimiento REQ-4108 | aceptado |
| REQ-4112 | Requerimiento REQ-4112 | aceptado |
| REQ-4113 | Requerimiento REQ-4113 | aceptado |
| REQ-4115 | Requerimiento REQ-4115 | aceptado |

Quien lo cerraría: el doliente de cada uno (Felipe Arango, Natalia Ospina, Andrés Lozano, Sandra Gil, Javier Hoyos ×2). Los otros 11 aceptados traen el mismo criterio, «se verifica en producción», que todavía no es medible.

### Decidido con documento, pero sin quién decidió
El documento existe (acta del comité del 2026-10-10), pero en ninguno de los 17 consta quién decidió.
| REQ | Quién decidió | Cuándo |
|---|---|---|
| los 17 aceptados | no consta | 2026-10-10 |

Quien lo cerraría: la secretaría del Comité de producto, anotando en el acta quién aprobó.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4104 | Requerimiento REQ-4104 | 71 días (desde 2026-08-05; umbral 60) | Comité de producto |

Propongo que el comité lo decida —aceptar, descartar o pedir evidencia—, no que se cierre por viejo. Doliente: Ricardo Salas.

### Evidencia vieja
Dieciséis requerimientos (15 aceptados y REQ-4104) se sostienen en lo mismo: la entrevista del 2025-09-20, 12 meses atrás. Y su cita, «Lo necesito y hoy no lo tengo.» (Cliente entrevistado), **no nombra ninguno de los requerimientos**. Es la misma frase repetida: sostiene el tema, no cada requerimiento.
REQ-2030, REQ-2038, REQ-4101 a REQ-4107, REQ-4109 a REQ-4115 (excepto los dos sin evidencia).

### Aparte: la definición
El caso de negocio (2025-09-03) declara un volumen mensual de 267.895; el tablero del 2026-09-29 mide 201.716. Brecha de 24,7 % por encima, contra un umbral de 20 %. El criterio de éxito de la definición no está dicho en ninguna parte.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 17 | 0 | 0 | 0 |

Después: hay 17 decididos que nadie construye, así que corresponde `/product-trace`.
