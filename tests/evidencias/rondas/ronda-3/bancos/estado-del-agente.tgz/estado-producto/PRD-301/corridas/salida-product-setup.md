Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

(Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta. Quién eres: Paula Céspedes, gerente de Nómina empresarial (PRD-301), según el caso de negocio. Quién decide: «Comité de producto», el único nombre escrito; ninguna persona figura como quien decide. Estado en `estado-producto/PRD-301`, hermana de la documentación y distinta de `estado/`, que es del portafolio.)

## Listo — Nómina empresarial (PRD-301)

**Lo que miré:** 5 documentos · 1 de descubrimiento (entrevistas del 2025-09-20, una sola cita) · la definición y el caso de negocio del 2025-09-03 · lo más reciente: tablero de métricas del 2026-09-29. Formatos que no pude leer: ninguno (los .docx los leí desde su XML). Quedaron 18 requerimientos levantados del acta del comité del 2026-10-10 (17 aceptados, 1 propuesto), una serie de métrica y la ficha del producto, y la lectura quedó sellada.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-15 para la versión 0.3.9 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.9-2026-10-15.md` y `.pdf` · SHA-256 eff52306622e7cd2…

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Base de la pirámide no tiene nómina empresarial | Una cita: «Lo necesito y hoy no lo tengo» (cliente entrevistado, sin nombre ni empresa) | 2025-09-20 |
| Volumen mensual de 267.895 | Solo el caso de negocio. El tablero mide 201.716 al 2026-09-29: el caso está **24,7 % por encima** de lo medido | 2025-09-03 / 2026-09-29 |
| La regulación vigente lo permite | Un supuesto marcado «verificado», sin decir con qué. Declarado «el 2026-05-30» en un documento fechado 2025-09-03 | 2025-09-03 |
| Retorno esperado en 24 meses | Nada. Sin cifra, sin base | 2025-09-03 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito del producto.** La definición no lo trae.
- **De dónde sale el retorno de 24 meses** y de dónde sale el 267.895.
- **Qué cuenta como `volumen_mensual`.** El tablero no lo define: no sé si las dos cifras miden lo mismo.
- **Con qué se verificó la regulación**, y cuál es.
- **Quién decide.** El acta solo registra a Paula Céspedes como asistente; no hay una persona que decida.
- **Qué pidió cada requerimiento.** La única entrevista no nombra ninguno; el acta se lo atribuye a «Cliente entrevistado» en 15 de 18.
- **Proyecto que ejecute alguno:** 0 de 18 (0,0 %). La definición dice «Ninguno declarado».
- **Quién pidió REQ-4100 y REQ-4108**, aceptados sin evidencia.
- **Doliente de REQ-4109** («sin asignar»).
- **Criterio de aceptación en 6 aceptados:** REQ-2030, 4103, 4108, 4112, 4113 y 4115. En los demás es «se verifica en producción», que no dice qué se mide.
- **Por qué sigue propuesto REQ-4104** (71 días sin decidirse).
- **Quién decidió cada aceptación.** El acta dice «Se mantiene el plan» y nada más.

### Supuestos sobre los que está escrita
Uno declarado: «La regulación vigente lo permite», marcado verificado sin fuente. Ningún otro; la definición no declara los de demanda ni los de volumen.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas. Hay una cita de 2025-09-20 y 16 requerimientos se apoyan en ella: tiene 12 meses, justo el límite.
- La serie de `volumen_mensual`: hay un solo punto (201.716, 2026-09-29), sin historia ni definición.
- Las decisiones del comité por requerimiento. REQ-2030 y REQ-2038 llevan otra numeración (2xxx) y se aceptaron el 2026-10-02 y 03: puede que sean de otro producto; no los saqué del registro.

Ofrezco `/product-discovery` sobre las entrevistas: ahí los temas se vuelven requerimientos con la cita de quién lo pidió.
