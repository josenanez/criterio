## Nómina empresarial (PRD-301) · 2026-10-15

**Primera revisión del registro: no hay corte anterior** (`last: null`), así que no se puede decir qué cruzó un umbral desde antes. Lo de abajo es la línea base: el próximo corte dirá qué es nuevo.

18 requerimientos: 17 aceptados, 1 propuesto. 15 con evidencia (88,2 %), 0 con traza a proyecto (0 %).

### Lo que necesita decisión del Comité de producto
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4104 | 71 días (planteado el 2026-08-05) | Quién tiene la facultad de decidirlo; llevarlo al comité | Ricardo Salas (doliente); decide el Comité de producto |
| Aceptado sin evidencia de demanda | REQ-4100, REQ-4108 | aceptados el 2026-10-10 | Aclarar quién lo pidió, o reabrir la aceptación | Elena Duarte; Andrés Lozano |
| Aceptado sin criterio de aceptación | REQ-2030, 4103, 4108, 4112, 4113, 4115 | — | Definir criterio verificable | Felipe Arango, Natalia Ospina, Andrés Lozano, Sandra Gil, Javier Hoyos (x2) |
| Sin doliente | REQ-4109 | — | Asignar doliente | Paula Céspedes (gerente de producto) |

### Declarado contra medido
`volumen_mensual`: el caso de negocio (2025-09-03) declara 267.895; el tablero del 2026-09-29 mide 201.716. **Declarado 24,7 % por encima** (umbral 20 %).

### Evidencia envejecida
16 requerimientos se apoyan solo en las entrevistas del 2025-09-20, que ya cumplen 12 meses. La cita («Lo necesito y hoy no lo tengo») es genérica y no nombra ningún requerimiento. La afirmación de demanda de esos requerimientos se queda sin sustento fechado.

### Las trazas
Ningún requerimiento aceptado tiene proyecto (17 sin traza). Se leyeron las 13 fichas de `estado/records`: ninguna nombra este producto, así que ninguna traza se da por confirmada. Los 17 aceptados del 2026-10-10 no los está construyendo nadie que se pueda ver.

### Del descubrimiento
Sin documentos nuevos que ofrecer. `success` (criterio de éxito de la definición) sigue sin estar dicho en ninguna parte.

### Lo que no sé
- No hay corte anterior, así que no distingo lo nuevo de lo viejo.
- No sé si los proyectos construyen estos requerimientos sin decirlo en la ficha.
- Dónde está la carpeta de fichas no consta en la configuración; usé `estado/records`, la misma de la corrida de trace.

**Vuelvo el 2026-11-14.**
