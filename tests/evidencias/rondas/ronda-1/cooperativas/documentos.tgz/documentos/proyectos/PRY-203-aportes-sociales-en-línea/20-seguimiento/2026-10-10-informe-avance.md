# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-10
**Gerente:** Felipe Arango

## Estado declarado

**Amarillo**

Avance reportado: **34%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.143.719.187 |
| Ejecutado | 1.394.242.890 |
| Proyección al cierre | 2.440.580.892 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
