# Informe de avance · Apertura de ahorro en línea

**Código:** PRY-201
**Fecha de corte:** 2026-09-20
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **41%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.106.858.928 |
| Ejecutado | 1.757.668.119 |
| Proyección al cierre | 3.962.345.640 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
