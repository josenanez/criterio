# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Convenios de libranza con empresas
**Fecha:** 2026-10-08
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +114 días sobre la línea base vigente |
| Costo | 228.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
