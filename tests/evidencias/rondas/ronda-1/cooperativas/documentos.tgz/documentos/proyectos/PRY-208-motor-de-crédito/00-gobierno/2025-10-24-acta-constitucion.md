# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Cartera y cobranza
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Crédito
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-10-24

## Objetivo del negocio

Entregar motor de crédito para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Crédito el 2025-10-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-03 |
| Cierre | 2026-11-29 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
