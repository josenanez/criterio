# Comité de Riesgos · Microcrédito rural

**Fecha:** 2026-10-01
**Asistentes:** Sandra Gil, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 14 | 2026-10-20 |
