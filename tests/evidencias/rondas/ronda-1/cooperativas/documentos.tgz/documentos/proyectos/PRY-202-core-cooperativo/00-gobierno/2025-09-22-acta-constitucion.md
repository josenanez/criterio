# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Tesorería
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Educación
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-22

## Objetivo del negocio

Entregar core cooperativo para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Educación el 2025-09-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-02 |
| Cierre | 2026-05-21 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
