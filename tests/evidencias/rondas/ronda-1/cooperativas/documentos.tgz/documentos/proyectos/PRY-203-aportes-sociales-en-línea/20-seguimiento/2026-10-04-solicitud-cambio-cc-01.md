# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Aportes sociales en línea
**Fecha:** 2026-10-04
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +23 días sobre la línea base vigente |
| Costo | 46.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
