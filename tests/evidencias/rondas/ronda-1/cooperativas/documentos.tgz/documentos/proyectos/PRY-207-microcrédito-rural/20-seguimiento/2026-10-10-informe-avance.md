# Informe de avance · Microcrédito rural

**Código:** PRY-207
**Fecha de corte:** 2026-10-10
**Gerente:** Sandra Gil

## Estado declarado

**Rojo**

Avance reportado: **80%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 866.884.995 |
| Ejecutado | 324.608.268 |
| Proyección al cierre | 1.248.412.916 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
