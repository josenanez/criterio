# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-10
**Gerente:** Natalia Ospina

## Estado declarado

**Rojo**

Avance reportado: **75%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.454.221.172 |
| Ejecutado | 749.267.576 |
| Proyección al cierre | 3.189.967.248 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
