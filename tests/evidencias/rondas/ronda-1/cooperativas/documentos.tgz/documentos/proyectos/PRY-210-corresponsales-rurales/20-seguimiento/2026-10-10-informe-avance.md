# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-10
**Gerente:** Diana Molina

## Estado declarado

**Verde**

Avance reportado: **80%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.343.553.438 |
| Ejecutado | 903.804.668 |
| Proyección al cierre | 2.331.733.355 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio normativo del supervisor que puede mover el alcance
