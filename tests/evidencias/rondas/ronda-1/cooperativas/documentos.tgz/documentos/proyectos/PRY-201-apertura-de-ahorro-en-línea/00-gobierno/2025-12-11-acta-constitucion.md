# Acta de constitución · Apertura de ahorro en línea

**Código:** PRY-201
**Área dueña:** Servicio al asociado
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Consejo de Administración
**Producto asociado:** ahorro a la vista
**Fecha de aprobación:** 2025-12-11

## Objetivo del negocio

Entregar apertura de ahorro en línea para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Consejo de Administración el 2025-12-11.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-21 |
| Cierre | 2027-06-09 |

## Criterio de éxito

Apertura de ahorro en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
