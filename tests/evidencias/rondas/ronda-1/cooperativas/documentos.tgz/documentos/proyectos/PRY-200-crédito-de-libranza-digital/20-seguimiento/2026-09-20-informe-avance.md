# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-09-20
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **53%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.671.355.133 |
| Ejecutado | 9.866.479.229 |
| Proyección al cierre | 18.642.360.710 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
