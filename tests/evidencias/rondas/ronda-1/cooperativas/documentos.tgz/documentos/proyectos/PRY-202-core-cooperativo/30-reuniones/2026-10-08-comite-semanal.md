# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-08
**Asistentes:** Mauricio Pérez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 35 | 2026-11-08 |
