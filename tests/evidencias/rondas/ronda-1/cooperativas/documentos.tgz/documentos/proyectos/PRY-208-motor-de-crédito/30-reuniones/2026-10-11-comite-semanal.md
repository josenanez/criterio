# Comité de Crédito · Motor de crédito

**Fecha:** 2026-10-11
**Asistentes:** Liliana Torres, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 30 | 2026-10-19 |
| Paula Céspedes | Entregar el punto 34 | 2026-10-01 |
