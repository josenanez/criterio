# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-09
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.357.612.499 |
| Ejecutado | 1.981.334.792 |
| Proyección al cierre | 9.967.736.822 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
