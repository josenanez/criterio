# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-02
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +100 días sobre la línea base vigente |
| Costo | 200.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
