# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-11
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **81%**

## Lo que pasó en el periodo

- El proveedor entregó el componente de integración, pendiente de aceptación
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.042.212.937 |
| Ejecutado | 1.294.116.301 |
| Proyección al cierre | 2.786.927.469 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
