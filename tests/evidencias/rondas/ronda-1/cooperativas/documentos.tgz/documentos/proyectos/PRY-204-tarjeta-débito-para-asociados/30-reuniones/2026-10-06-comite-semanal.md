# Comité de Tecnología · Tarjeta débito para asociados

**Fecha:** 2026-10-06
**Asistentes:** Mauricio Pérez, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 34 | 2026-09-27 |
