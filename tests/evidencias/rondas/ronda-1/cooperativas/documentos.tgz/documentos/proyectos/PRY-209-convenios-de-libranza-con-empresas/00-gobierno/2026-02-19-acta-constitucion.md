# Acta de constitución · Convenios de libranza con empresas

**Código:** PRY-209
**Área dueña:** Bienestar social
**Patrocinador:** Paula Céspedes
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-19

## Objetivo del negocio

Entregar convenios de libranza con empresas para Bienestar social.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-01 |
| Cierre | 2026-10-01 |

## Criterio de éxito

Convenios de libranza con empresas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
