# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-05-09
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 211.347 | Caso de negocio, 2026-05-09 |

## Retorno esperado

Retorno esperado en 24 meses.
