# Comité de producto · Microseguros

**Fecha:** 2026-10-08
**Asistentes:** Ricardo Salas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1090 | Requerimiento REQ-1090 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-15 | — |
| REQ-1091 | Requerimiento REQ-1091 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-1092 | Requerimiento REQ-1092 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-05 | — |
| REQ-2017 | Requerimiento REQ-2017 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-06 | — |
| REQ-2025 | Requerimiento REQ-2025 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-10-05 | — |

## Decisiones

- Se mantiene el plan
