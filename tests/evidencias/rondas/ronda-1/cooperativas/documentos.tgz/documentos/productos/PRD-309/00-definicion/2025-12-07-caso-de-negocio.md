# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2025-12-07
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 234.178 | Caso de negocio, 2025-12-07 |

## Retorno esperado

Retorno esperado en 24 meses.
