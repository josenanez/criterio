# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Liliana Torres
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-07-26

## El problema

El segmento Jóvenes no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-05-30 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
