# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2026-07-22
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 190.981 | Caso de negocio, 2026-07-22 |

## Retorno esperado

Retorno esperado en 24 meses.
