# Comité de producto · Recaudos

**Fecha:** 2026-10-07
**Asistentes:** Beatriz Cuéllar

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1060 | Requerimiento REQ-1060 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-14 | — |
| REQ-1061 | Requerimiento REQ-1061 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-22 | — |
| REQ-1062 | Requerimiento REQ-1062 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-22 | — |

## Decisiones

- Se mantiene el plan
