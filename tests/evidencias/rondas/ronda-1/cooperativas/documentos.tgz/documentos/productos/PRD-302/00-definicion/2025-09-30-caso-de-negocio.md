# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-09-30
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 199.682 | Caso de negocio, 2025-09-30 |

## Retorno esperado

Retorno esperado en 24 meses.
