# Entrevistas · Ahorro a la vista

**Ronda:** Ronda · 2026-06-11
**Realizadas por:** Óscar Ramírez

### Cliente entrevistado · 2026-06-11

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
