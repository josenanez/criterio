# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2026-07-26
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 223.986 | Caso de negocio, 2026-07-26 |

## Retorno esperado

Retorno esperado en 24 meses.
