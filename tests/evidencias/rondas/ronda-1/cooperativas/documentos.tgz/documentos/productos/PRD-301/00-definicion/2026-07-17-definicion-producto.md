# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Óscar Ramírez
**Segmento:** Pensionados
**Fecha de la definición:** 2026-07-17

## El problema

El segmento Pensionados no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-04-09 · verificado

## Proyectos que lo construyen

- Ninguno declarado
