# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2025-09-04
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 226.062 | Caso de negocio, 2025-09-04 |

## Retorno esperado

Retorno esperado en 24 meses.
