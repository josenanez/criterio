# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-07-22
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 280.819 | Caso de negocio, 2026-07-22 |

## Retorno esperado

Retorno esperado en 24 meses.
