# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Ricardo Salas
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-12-07

## El problema

El segmento Jóvenes no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-08-13 · verificado

## Proyectos que lo construyen

- Ninguno declarado
