# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-07-17
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 187.987 | Caso de negocio, 2026-07-17 |

## Retorno esperado

Retorno esperado en 24 meses.
