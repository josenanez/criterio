# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** Jorge Medina
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-09-30

## El problema

El segmento Asociados urbanos no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-07-08 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
