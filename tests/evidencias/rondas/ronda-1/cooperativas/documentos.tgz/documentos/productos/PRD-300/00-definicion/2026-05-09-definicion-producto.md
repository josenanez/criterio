# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Laura Vélez
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-05-09

## El problema

El segmento Asociados urbanos no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-03 · verificado

## Proyectos que lo construyen

- Ninguno declarado
