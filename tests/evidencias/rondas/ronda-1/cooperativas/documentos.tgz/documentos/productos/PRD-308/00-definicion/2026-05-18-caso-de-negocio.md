# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-05-18
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 200.434 | Caso de negocio, 2026-05-18 |

## Retorno esperado

Retorno esperado en 24 meses.
