# Tablero de métricas · Pagos QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 112.310 | 2026-10-09 |
