# Corrida · 2026-10-14-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T16:19:48 · **Fin:** 2026-10-14T16:23:28 · **Duración:** 220 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 72 | 198 | 60 | 10 fichas nuevas (PRY-199..204, 206, 207, 210, 211); 49 de 72 documentos leídos, 23 sin cambio (PRY-205, 208, 209); sin entrada/, nada movido; 0 ilegibles. Mirar: 19 hitos cerrados sin acta, 3 proyectos con cierre vencido y cronograma cerrado, factura FV-1509 de PRY-211, CC-01 de PRY-203 y PRY-210 con cronograma ya movido, 2 compromisos vencidos, rutas del pm_record de PRY-208 que no resuelven. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 26, `progress_vs_plan` 7, `declared_vs_evidence` 5, `variance_time` 4, `silent` 3, `rebaseline_unauthorized` 3, `commitment_overdue` 3, `commitment_undated` 2, `change_without_baseline` 2, `vendor_accepted_without_evidence` 2, `budget_committed` 1, `variance_cost` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

El barrido terminó. Leí 49 de los 72 documentos y escribí y sellé las 10 fichas de proyectos nuevos. Los términos v1.0 ya estaban aceptados en la configuración (José Francisco Ñáñez, 2026-10-14). Como la sesión no tenía interfaz, no hubo preguntas que contestar.

- **Documentos:** de los 72, 23 no cambiaron y no se abrieron. Son los de PRY-205, PRY-208 y PRY-209. Ninguno fue ilegible. No hay carpeta `entrada/`, así que no se movió nada.
- **Fichas nuevas:** PRY-199, 200, 201, 202, 203, 204, 206, 207, 210 y 211.
- **Sin dato en las 10:** la autoridad del gerente y la fase no aparecen en ningún documento.

Lo que debe mirar la PMO:
- **Hitos cerrados sin acta:** 19 de 24 hitos declarados cerrados no tienen acta de recibo. El script cuenta 26 al sumar PRY-205, 208 y 209, que no releí.
- **Cierre vencido con cronograma cerrado:** PRY-202, 207 y 211 pasaron su fecha de cierre y su cronograma da todos los hitos por cerrados. Los gerentes declaran 43 %, 80 % y 59 % de avance.
- **PRY-211, factura sin respaldo:** la factura FV-1509 es por 2.179.464.246 COP, el valor de tres entregables del contrato CT-509. Solo hay una acta de recibo, la de la bolsa de horas.
- **Cambios con el cronograma ya movido:** en PRY-203 la solicitud CC-01 sigue pendiente de comité y el cronograma v2 ya movió la fecha. En PRY-210 la CC-01 dice "autorizada por el comité" sin decir cuál, y el acta del 13 de octubre no la menciona.
- **Compromisos vencidos:** uno en PRY-204 (Gustavo Neira, para el 2026-09-27) y uno en PRY-210 (Beatriz Cuéllar, para el 2026-10-03).
- **Ejecutado mayor que comprometido:** PRY-200 y PRY-203 reportan más ejecutado que comprometido.
- **PRY-208:** las rutas de la ficha del gerente no resuelven contra la raíz de documentación. No la toqué, porque tiene otro escritor.

La corrida quedó registrada con `snapshot` y `corrida` (id `2026-10-14-portfolio-scan-1`, 198 segundos, 60 hallazgos en el portafolio). El script también marcó como hallazgos que mi resumen no incluye: tres proyectos en silencio (PRY-200, 201 y 211), tres con lo declarado contra la evidencia (PRY-201, 204 y 210), y atraso en PRY-210.

Archivos en `estado/`:
- `corridas/salida-portfolio-scan.md`
- `records/`
