# Corrida · 2026-10-14-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T16:14:47 · **Fin:** 2026-10-14T16:15:43 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 34 | 1 | Paquete de decisión sobre CC-01 y la autoridad no declarada en el acta; impact devolvió 0 alcanzados por falta de plan en la ficha, declarado como no sabido; cronograma v2 ya aplica +100 días sin autorización. |

Por señal (`pm-escalate`): `commitment_undated` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-208 y registré la corrida (`2026-10-14-pm-escalate-1`). Los términos ya estaban aceptados (v1.0, 2026-10-14), así que no hubo que pedirlos.

**Qué escala**
- **Autoridad sin declarar (primer punto):** el acta no dice qué puede decidir la gerente. Asumí que CC-01 excede su facultad, pero esa lectura es mía, no del acta.
- **CC-01 (+100 días, +200 M COP):** el cierre pasaría del 2026-11-29 al 2027-03-09. Decide el Comité de Crédito el 2026-10-28.
- **Recomendación:** aprobar con condiciones. CC-01 dice «ampliación de alcance», pero el atraso está en un hito que ya existía. Además cubre 200 M, mientras la proyección del informe está 386,9 M sobre el aprobado.
- **Cronograma ya movido:** el v2 ya mueve la integración con el core cooperativo exactamente 100 días, y CC-01 sigue sin autorización.

**A quién alcanza:** no se pudo calcular. `impact` devolvió 0 proyectos y 0 hitos porque la ficha no tiene plan ni fecha de cierre, y el acta dice «ninguna dependencia declarada». Eso no significa que no alcance a nadie. Lo dejé escrito como no sabido y no inventé gerentes ni proyectos.

El paquete también marca, sin desarrollarlo, un riesgo del proveedor sin registrar y un estado «Verde» al 81 % que no cuadra con el atraso. El paquete completo está en `estado/PRY-208-motor-de-crédito/corridas/salida-pm-escalate.md`.
