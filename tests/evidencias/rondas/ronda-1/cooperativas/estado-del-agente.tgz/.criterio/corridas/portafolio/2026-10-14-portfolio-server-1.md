# Corrida · 2026-10-14-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T16:39:56 · **Fin:** 2026-10-14T16:40:42 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 60 | puerto 8787, informe reportes/, modo rato (solo 127.0.0.1) |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 26, `progress_vs_plan` 7, `declared_vs_evidence` 5, `variance_time` 4, `silent` 3, `rebaseline_unauthorized` 3, `commitment_overdue` 3, `commitment_undated` 2, `change_without_baseline` 2, `vendor_accepted_without_evidence` 2, `budget_committed` 1, `variance_cost` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

Rostrum arrancó bien en `127.0.0.1:8787`, pero no sigue corriendo. Esta sesión no tiene interfaz y el comando de arranque se cortó a los 15 segundos. Para mirarlo, ejecuta tú el comando de más abajo en tu máquina.

- **Modo:** «para mirarlo un rato», como indicaste. Escucha solo en el equipo donde corre, sin autenticación ni acceso desde fuera.
- **Términos:** la configuración ya tenía la aceptación de José Francisco Ñáñez (versión 1.0, 2026-10-14), igual que `TERMS.es.md`. No hizo falta pedirla.
- **Informe:** ya existía en `reportes/`, así que no hubo que correr `/portfolio-report`.
- **Corrida:** quedó registrada como `2026-10-14-portfolio-server-1`. El texto mostrado está en `estado/corridas/salida-portfolio-server.md`. Lo guardé antes de arrancar el servidor, como pide el comando.
- **Cifra de productos:** mi texto guardado dice 3 productos, pero el servidor cuenta 8. El 3 salió de los archivos `producto-*.html` que vi en un listado cortado. Vale la cifra del servidor.

Páginas que sirve el portal:
- `/` es la portada, con el formulario de peticiones.
- `/pmo` muestra cómo va el portafolio.
- `/decisiones` reúne lo que necesita decisión del comité.
- `/proyectos` lista 13 proyectos.
- `/productos` lista 8 productos.
- `/corridas` lista 34 corridas.
- `/estado.json` dice de cuándo es el informe.

Para levantarlo otra vez:
```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-1/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-1/cooperativas/espacio/estado --config /home/claude/banco/ronda-1/cooperativas/espacio/.criterio/portafolio/config.json
```
Si el puerto 8787 está ocupado, añade `--puerto 8788`.

**A quién pasarle el enlace:** `http://127.0.0.1:8787/` solo abre en el equipo donde corre. Sirve para enseñárselo a alguien delante de la pantalla, no para mandárselo a un patrocinador. Para eso hay que dejarlo corriendo con `--abierto`. Eso requiere un host y un puerto dentro de la red, publicados detrás del control de acceso que la organización ya usa, y que el equipo siga encendido.

**Cuándo se desactualiza:** el informe está al día hasta la última vez que se corrió `/portfolio-report`. La portada muestra esa fecha.
