# Corrida · 2026-10-14-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-14T16:34:08 · **Fin:** 2026-10-14T16:35:16 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 42 | 60 | Cierre de PRY-202 por decisión, no por cumplimiento: criterio de éxito no determinable, 3 hitos sin evidencia, contradicción de fecha de cierre entre acta (2026-05-21) y cronograma (2026-04-25). No archivado. |

Por señal (`project-closure`): `milestone_met_without_evidence` 26, `progress_vs_plan` 7, `declared_vs_evidence` 5, `variance_time` 4, `silent` 3, `rebaseline_unauthorized` 3, `commitment_overdue` 3, `commitment_undated` 2, `change_without_baseline` 2, `vendor_accepted_without_evidence` 2, `budget_committed` 1, `variance_cost` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

## Cierre — PRY-202 Core cooperativo — 2026-10-14

Fuentes: la ficha de PRY-202, la salida de `compute` y los cinco documentos de la carpeta del proyecto. Los términos 1.0 ya estaban aceptados.

**PRY-202 no se puede cerrar por cumplimiento.** El informe del 2026-10-12 lo declara en Amarillo, con 43 % de avance. La integración está «pendiente de aceptación» y el piloto espera un ajuste del reglamento. Solo se puede cerrar por decisión de alguien con autoridad.

- **Criterio de éxito:** «Core cooperativo en producción y medido» (acta, 2025-09-22). Ningún documento muestra producción ni medición, así que no se puede determinar si se cumplió. Lo documentado indica que no.
- **Hitos:** el cronograma marca los cuatro como «cerrado». Solo «Diseño funcional aprobado» tiene acta de recibo (2026-10-07). Los otros tres no tienen evidencia, con 275, 223 y 172 días desde su vencimiento. La brecha entre el avance declarado y lo que respalda el plan es de 57,0 puntos.
- **Números (COP):** aprobado 3.300.000.000; ejecutado 934.996.135 (28,3 %); comprometido 2.516.300.758 (76,3 %); proyección 3.353.645.589 (+1,6 % sobre lo aprobado). Hay 0 replanificaciones y 0 días de desviación contra la línea base. Ese 0 solo dice que la línea base nunca se movió, no que se haya cumplido.
- **Contradicción:** el acta fija el cierre en 2026-05-21 y el cronograma en 2026-04-25, y ambos están fechados el 2025-09-22. La ficha usa la fecha del cronograma, y alguien tiene que decidir cuál es la original.
- **RAID abierto:**
  - Aceptación de la integración: sin doliente.
  - Ajuste del reglamento: sin doliente.
  - Dependencia del proveedor: sin doliente.
  - «Entregar el punto 35»: Jorge Medina, para 2026-11-08.
- **Lecciones:** solo dos se sustentan. Los hitos se marcaron cerrados sin evidencia, y el acta de recibo del diseño funcional llegó después de la fecha del hito. La rotación del desarrollador clave costó dos semanas, pero no tiene fecha y no entra como lección.
- **Archivo:** no archivé la carpeta. Tomé la respuesta sugerida, porque el proyecto sigue en ejecución según su último informe.

Corrida registrada como `2026-10-14-project-closure-1`, con la salida completa en `estado/corridas/salida-project-closure.md`.

El campo `documentos` de la corrida quedó sin medir (`null`).
