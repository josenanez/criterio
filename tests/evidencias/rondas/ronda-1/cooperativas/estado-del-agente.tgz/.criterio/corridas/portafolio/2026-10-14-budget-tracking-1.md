# Corrida · 2026-10-14-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-14T16:26:51 · **Fin:** 2026-10-14T16:27:41 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 30 | 60 | Presupuesto de PRY-205: cuatro cifras de una sola declaración (2026-10-02), comprometido 91,1 % sobre umbral, proyección anterior a CC-01. Dijo que no sabe: presupuesto vigente, si la proyección incluye CC-01/CC-02, detalle por proveedor, evidencia contable. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 26, `progress_vs_plan` 7, `declared_vs_evidence` 5, `variance_time` 4, `silent` 3, `rebaseline_unauthorized` 3, `commitment_overdue` 3, `commitment_undated` 2, `change_without_baseline` 2, `vendor_accepted_without_evidence` 2, `budget_committed` 1, `variance_cost` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

Informe de presupuesto de PRY-205 (Prevención de lavado de activos). Quedó guardado como `estado/corridas/salida-budget-tracking.md` y la corrida registrada como `2026-10-14-budget-tracking-1`. Los términos v1.0 ya constaban en la configuración (José Francisco Ñáñez, 2026-10-14).

Abro declarando las fuentes: sale de la ficha `estado/records/PRY-205.json`, del informe de avance del 2026-10-02, de las solicitudes de cambio CC-01 y CC-02, y de `compute` recalculado el 2026-10-14. Las cifras en pesos (COP) son todas declaración del informe de avance, sin evidencia contable.

| | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 2.400.000.000 | 100 % |
| Comprometido | 2.186.680.942 | 91,1 % |
| Ejecutado | 585.670.336 | 24,4 % |
| Proyección al cierre | 2.312.291.507 | el script no la da |

- **Disponible real:** 213.319.058 COP (aprobado menos comprometido).
- **Comprometido sobre el umbral:** 91,1 % supera el umbral de 90 %, con solo 24,4 % ejecutado. El presupuesto está casi agotado y casi todo sin causar.
- **Proyección desactualizada:** es del 2026-10-02 y CC-01 (+82.000.000, aprobada el 2026-10-04) es posterior. CC-02 (+142.000.000) sigue pendiente, sin decisor. Ninguna de las dos parece estar incluida.
- **CC-01 sin respaldo:** la aprobó «el comité» sin decir cuál, y ningún acta lo recoge. No tiene nueva línea base.
- **Atraso en tiempo:** 112 días contra la línea base original (34,6 %). Solo 41 están autorizados por CC-01, así que 71 días quedan sin autorización.
- **Ejecución frente a avance:** el plan marca 4 de 4 hitos cumplidos, ninguno con evidencia. El gerente declara 67 % de avance y el dinero ejecutado es 24,4 %. Los documentos no permiten decidir si hay trabajo sin causar o hitos mal marcados.
- **Sin dato:** el presupuesto vigente, si la proyección incluye CC-01 o CC-02, el detalle por proveedor (la ficha no tiene proveedores) y cualquier evidencia contable.

La proyección no excede el aprobado según el script, así que no hay solicitud de cambio que preparar por esa vía. Puedo preparar el pedido de proyección actualizada a Liliana Torres, el detalle de compromisos por proveedor, o la llevada de CC-02 a decisión.

Las cifras derivadas están copiadas de `compute`, y lo que no se pudo calcular quedó en «Sin dato».
