# Corrida · 2026-10-14-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-211

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-211

**Inicio:** 2026-10-14T16:27:46 · **Fin:** 2026-10-14T16:28:40 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 31 | 60 | Proveedor CT-509: 2 de 3 entregables facturados (FV-1509) sin acta de recibo, 1 atrasado 145 dias. Dije que no sé: vigencia, preaviso y renovación del contrato, minutas con el proveedor. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 26, `progress_vs_plan` 7, `declared_vs_evidence` 5, `variance_time` 4, `silent` 3, `rebaseline_unauthorized` 3, `commitment_overdue` 3, `commitment_undated` 2, `change_without_baseline` 2, `vendor_accepted_without_evidence` 2, `budget_committed` 1, `variance_cost` 1, `vendor_deliverable_late` 1

## Lo que el agente mostró

## Proveedores — PRY-211 Cobranza digital al 2026-10-14

**Documentos de los que sale:**
- el contrato CT-509 (`00-gobierno/2025-11-01-contrato-ct-509.docx`)
- el acta de recibo del 2026-02-23
- la factura FV-1509 (`2026-09-10-factura-ct-509.md`)
- la ficha `PRY-211.json`
- la salida de `compute`

Los términos quedaron aceptados por José Francisco Ñáñez (versión 1.0, 2026-10-14).

### Soluciones Solidarias S.A.S. — contrato CT-509
El contrato se firmó el 2025-11-01. No declara fin de vigencia, renovación automática ni preaviso.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-12-26 | `accepted`, solo porque el contrato dice "recibido" | **Ninguna** | Sí, dentro de FV-1509 |
| Bolsa de horas de desarrollo | 2026-02-13 | `accepted` | Acta del 2026-02-23, firmada por Carlos Peña, el gerente del proyecto | Sí, dentro de FV-1509 |
| Parametrización de líneas de crédito | 2026-04-03 | `accepted`, solo porque el contrato dice "recibido" | **Ninguna** | Sí, dentro de FV-1509 |
| Mesa de ayuda del primer trimestre | 2026-05-22 | `pending`, atrasado 145 días | Ninguna | No |

Cada entregable vale 726.488.082 COP. La factura FV-1509 es del 2026-09-10 por 2.179.464.246 COP, está radicada en cuentas por pagar y cubre tres entregables.

### Dónde no cuadra
- **Condición de pago incumplida:** el contrato exige facturar cada entregable contra un acta de recibo firmada por el gerente. Solo existe un acta, la de la bolsa de horas.
- **Licenciamiento y parametrización:** el contrato los marca como "recibidos", pero ningún acta, correo o minuta lo prueba. Esa palabra es una declaración, no evidencia.
- **Monto facturado sin acta:** el script no da esa cifra y no la calculo a mano. Cada uno de esos dos entregables vale 726.488.082 COP según el contrato.

### Compromisos del proveedor vencidos
No hay ninguno registrado. La carpeta no tiene minutas con el proveedor, así que eso significa que no hay nada registrado, no que no existan compromisos.

### Sin dato
- No hay vigencia, terminación, renovación ni preaviso de CT-509. No puedo decir si hay un preaviso por vencer.
- No hay minutas ni correos con el proveedor.
- Contexto del proyecto: los 5 hitos figuran como cumplidos sin evidencia. El informe del 2026-09-27 declara 59 % de avance, y el plan sostiene 100 %.

### Después
Recomiendo llevar la factura FV-1509 al comité del 2026-10-21 antes de pagarla. Dos de sus tres entregables no tienen acta, y la mesa de ayuda sigue atrasada y sin facturar.

**Pie de rigor:** las cifras salen de `compute`, sin recálculo manual. Lo que no sé está en "Sin dato".

La corrida quedó registrada como `2026-10-14-vendor-tracking-1`, con la salida completa en `estado/corridas/salida-vendor-tracking.md`. Tardó 31 segundos. El número de documentos leídos no quedó medido.
