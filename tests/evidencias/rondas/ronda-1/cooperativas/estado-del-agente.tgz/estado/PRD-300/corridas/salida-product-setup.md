## Listo — Crédito de libranza (PRD-300)

**Lo que miré:** 4 documentos · 1 de descubrimiento (entrevistas del 2025-10-11) · la definición y el caso de negocio del 2026-05-09 · el acta del comité del 2026-10-13. Formatos que no pude leer: ninguno (2 .docx y 2 .md).

**Configuración (respuestas sugeridas, sin nadie que respondiera):** producto Crédito de libranza, gerente Laura Vélez (sale del caso de negocio), decide Comité de producto (sale del acta del 2026-10-13), estado en `estado/PRD-300` (hermana de `documentos/`, fuera de la documentación), términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14. Quedó en `.criterio/producto/PRD-300/config.json`. Nota: la persona que aceptó los términos no es la gerente que firma el caso; queda registrado tal cual.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Asociados urbanos no tiene crédito de libranza» | Una sola entrevista de un cliente sin nombre: «Lo necesito y hoy no lo tengo» (sostiene la necesidad de ese cliente, no la ausencia de oferta en el segmento) | 2025-10-11 |
| «El proveedor cumple el tiempo pactado» (supuesto, marcado «verificado») | Supuesta verificación sin ningún documento que la muestre; el proveedor ni se nombra | declarado el 2026-09-03 |
| volumen_mensual 211.347 | Solo el propio caso de negocio, que se cita a sí mismo como fuente | 2026-05-09 |
| «Retorno esperado en 24 meses» | Nada: sin cifra, sin base de cálculo | — |

### Lo que no está dicho en ninguna parte
- De dónde sale el volumen mensual de 211.347: ni entrevistas, ni serie medida, ni cálculo.
- Qué retorno es el esperado en 24 meses, ni con qué supuestos.
- Qué es la «Propuesta principal»: la definición lista un título y nada más.
- Quién es el segmento «Asociados urbanos» y cuántos son; y qué es el éxito (no hay métrica de éxito).
- Quién es el proveedor y cuál es el tiempo pactado.
- El criterio de aceptación de REQ-2023: está vacío y el comité lo marcó «aceptado» el 2026-10-10.
- El proyecto que ejecuta REQ-1000, REQ-1001 y REQ-2023: los tres figuran «—», y la definición dice «Ninguno declarado».
- Quién pidió cada requerimiento: el acta pone «Cliente entrevistado» en los tres, pero la única entrevista es una, de un cliente, sin nombre y sin vínculo con ninguno de los tres.
- El motivo de «Se mantiene el plan»: el acta no dice qué plan, ni por qué.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», con fecha 2026-09-03 y estado «verificado» sin evidencia de verificación. Aparte, la definición se apoya sin declararlo en que el volumen del caso de negocio es alcanzable.

### Contraste de cifras con series medidas
No hay ninguna serie medida a la vista. **Nadie está midiendo lo que el negocio afirmó** (211.347 al mes). Sin serie no puedo decir cuánto se desvía. Tampoco calculé días ni porcentajes: el script `compute` salió vacío porque el registro de requerimientos aún no existe, y lo que él no da no lo escribo.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una sola, de una frase.
- La serie de la métrica principal (volumen mensual) con su fuente.
- Decisiones del comité que expliquen por qué se mantiene el plan; sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.
- La entrevista del 2025-10-11 está en el borde de los 12 meses que el umbral usa para llamar vieja una evidencia; el script no lo calculó, así que lo dejo como pendiente de verificar.

**Siguiente paso que ofrezco:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.

*Borrador de trabajo, no certificado. La verificación es tuya (TERMS.md v1.0). Una ausencia de hallazgo no es evidencia de que todo esté bien.*
