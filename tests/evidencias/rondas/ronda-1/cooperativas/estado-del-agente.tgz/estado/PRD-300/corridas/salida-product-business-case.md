# Caso de negocio — Crédito de libranza (PRD-300) · borrador del 2026-10-14
**Desde:** `00-definicion/2026-05-09-definicion-producto.md` y `2026-05-09-caso-de-negocio.md` (ambos del 2026-05-09) · **Cifras con fuente:** 0 de 2

Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (ya constan en la configuración). Sesión sin interfaz: nadie respondió preguntas, se tomó la respuesta sugerida en cada una y se siguió.

**Lectura corta:** esto todavía no es un caso de negocio evaluable. El costo de construir no está en ningún documento del producto, así que hoy hay una propuesta. Las dos cifras del caso se citan a sí mismas o no tienen número. Este borrador no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Asociados urbanos no tiene crédito de libranza.» (definición, 2026-05-09).
- **Para quién:** Asociados urbanos (definición, 2026-05-09). No hay cuántos son ni cuántos quieren libranza.
- **Lo que lo sostiene:** una sola frase de un cliente sin nombre: «Lo necesito y hoy no lo tengo» (entrevistas, 2025-10-11). Evidencia débil y con 12 meses y 3 días, sobre el umbral de 12 meses. Sostiene la necesidad de un cliente, no que no exista oferta en el segmento.

## Qué se construye
La definición dice «Propuesta principal» y nada más. Los requerimientos son los del acta de comité del 2026-10-13 (`30-decisiones/2026-10-13-comite-producto.docx`). El registro de estado tiene 0 requerimientos, así que esta tabla sale del acta.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1000 · doliente Paula Céspedes · criterio «se verifica en producción» | aceptado (desde 2026-06-22) | Pedido por «Cliente entrevistado». La entrevista es del 2025-10-11 y no menciona este requerimiento. |
| REQ-1001 · doliente Diana Molina · criterio «se verifica en producción» | aceptado (desde 2026-08-11) | Pedido por «Cliente entrevistado», con la misma salvedad. |
| REQ-2023 · doliente Jorge Medina · **sin criterio de aceptación** | aceptado (desde 2026-10-10) | Pedido por «Cliente entrevistado», con la misma salvedad. |

Los tres tienen nombre genérico («Requerimiento REQ-xxxx») y proyecto «—». «Se verifica en producción» no es un criterio verificable. La única decisión del acta es «Se mantiene el plan», sin decir qué plan.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 211.347 | **Declarada**, sin base | Caso de negocio, 2026-05-09, que se cita a sí mismo como fuente. No hay entrevista, serie ni cálculo detrás. | 2026-05-09 |
| Retorno esperado | «en 24 meses», sin valor | **Sin cifra**: no es declarada, medida ni supuesta | Caso de negocio, 2026-05-09 | 2026-05-09 |
| Implícito: el volumen es alcanzable | — | **Supuesta** (nadie la ha declarado) | Está dentro del razonamiento del caso | — |

No hay ninguna cifra **medida**: `estado/PRD-300/metrics/` está vacío. No traje ni calculé ingresos, retorno, ahorro ni periodo de recuperación.

### Donde la cifra declarada y la medida no coinciden
No hay contraste posible: sin serie medida no hay segunda cifra. Que nadie mida el 211.347 es en sí un vacío, y entra abajo.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir el producto | **No declarado en ningún documento de PRD-300** | — (primer vacío) |
| Candidato a confirmar: PRY-200 «Crédito de libranza digital» | Presupuesto aprobado 18.000.000.000 COP (acta 2025-09-17). Informe del 2026-09-20: comprometido 9.671.355.133, ejecutado 9.866.479.229, proyección al cierre 18.642.360.710. | El acta de PRY-200 dice «Producto asociado: crédito de libranza», por nombre y sin código. La definición de PRD-300 dice «Ninguno declarado». **Vínculo no confirmado**, así que no se suma como costo del caso. |
| Candidato a confirmar: PRY-209 «Convenios de libranza con empresas» | 6.800.000.000 COP aprobados (acta 2026-02-19) | Su acta dice «Producto asociado: No aplica». No lo trato como costo de PRD-300. |

Dos hechos que hay que confirmar con quien corresponda (no son conclusiones mías):
- En PRY-200 el ejecutado (9.866 M) supera al comprometido (9.671 M), y la proyección (18.642 M) supera lo aprobado (18.000 M).
- El acta de PRY-200 tiene como área dueña Riesgo y Cumplimiento, no el segmento Asociados urbanos.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» · declarado 2026-09-03 · marcado «verificado», sin rastro de la verificación | El cronograma, y con él el momento en que arranca cualquier beneficio, no se sostiene. | Laura Vélez: nombrar al proveedor, citar el contrato con el tiempo y el acta de recibo. |
| Implícito: un volumen mensual de 211.347 es alcanzable | Todo beneficio que dependa de ese volumen queda sin base. | Nadie asignado. Falta declararlo y fijarle una serie o un piloto. |
| Implícito: el segmento no tiene oferta de libranza hoy | El problema que justifica el producto no existe como está escrito. | Nadie asignado. Hace falta evidencia distinta de una entrevista. |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| **Costo de construir el producto** | Sin él no hay caso que evaluar, hay una propuesta. | Gerencia de producto (Laura Vélez), con el proyecto que lo construya. |
| De dónde sale el 211.347 | Es la cifra que sostiene el caso y se cita a sí misma. | Quien la afirmó en el caso de negocio (Laura Vélez). |
| Qué es el «retorno esperado» y su base | Sin valor ni base no se puede discutir ni medir. | El negocio. Este agente no lo estima. |
| Una serie medida del volumen | Sin serie no se puede contrastar lo declarado. | El sistema donde viva el producto; hoy no hay fuente. |
| Qué pasa si no se hace | El comité no tiene contra qué comparar. | El negocio. |
| Alternativas consideradas | Nada muestra que se compararan opciones. | El negocio. |
| Cuántos son los Asociados urbanos y cuántos quieren libranza | Es el tamaño del problema. | Gerencia de producto. |
| Evidencia de demanda vigente y de más de un cliente | Hay una frase de hace más de 12 meses. | Descubrimiento, con nuevas entrevistas. |
| Qué proyecto construye el producto | La definición dice «Ninguno declarado», pero PRY-200 y PRY-209 hablan de libranza. | Laura Vélez, con la PMO. |
| Criterio de aceptación de REQ-2023 | Está aceptado sin criterio. | Jorge Medina. |
| Normativa aplicable (país y norma sin fijar) | Libranza, consumidor financiero, datos personales y retención de información crediticia están sin norma a la vista. | Revisión jurídica. Este agente no cita norma de memoria. |
| Verificación del supuesto del proveedor | «Verificado» es una etiqueta sin documento. | Laura Vélez. |
| Fecha de los documentos | La definición es del 2026-05-09 pero lleva un supuesto del 2026-09-03: se editó sin cambiar la fecha o el supuesto vino de otro documento. | Laura Vélez. |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito en la definición ni en el caso, ni métrica con fecha de corte. El único criterio cercano es el de PRY-200 («Crédito de libranza digital en producción y medido»), que mide un proyecto y no el caso. Sin esto el producto no se puede cerrar meses después. Propongo que el criterio de éxito sea el primer texto que escriba la autoridad (Comité de producto), con su métrica, su fuente y su fecha de corte. No propongo yo el valor.

## Si hay otros productos publicados
No hay ningún producto publicado a la vista: `estado/` solo tiene PRD-300 y no hay fichas publicadas de otros. Busqué el valor 211.347 en toda la carpeta de documentos y solo aparece en el caso de PRD-300. No detecto otro caso de negocio que cuente las mismas transacciones. Eso no prueba que no se solapen: los demás productos tienen documentos en `documentos/productos/` pero nadie los ha publicado ni cruzado.

## Notas de la corrida
- Estado sin poblar (`producto.json` vacío, 0 requerimientos, `metrics/` vacío), igual que en las corridas anteriores de hoy.
- Borrador de trabajo, no certificado. La verificación es tuya (TERMS.md v1.0). Que no aparezca un hallazgo no es evidencia de que todo esté bien.

**Después que ofrezco:** pasar los tres supuestos al seguimiento con `assumption-tracking`. No ofrezco `/product-charter`: el caso no tiene costo ni criterio de éxito, y el acta del comité no vincula ningún proyecto.
