## Especificación — Crédito de libranza (PRD-300) · al 2026-10-14
Borrador no producido: el registro de requerimientos de PRD-300 está vacío (0 requerimientos en `estado/PRD-300/requirements/`, y `producto.json` sin identidad ni definición). No hay ningún requerimiento en `aceptado` ni `en_construccion` que especificar, y no se inventa uno.

Los documentos existen (definición y caso de negocio del 2026-05-09, entrevistas, acta del comité del 2026-10-13), pero nadie los ha inventariado como requerimientos. Escribir la especificación desde ellos sería saltarse el registro, y lo que saliera no se podría rastrear a nada.

Términos: versión 1.0, aceptados por José Francisco Ñáñez el 2026-10-14 (config.json).

Siguiente paso: correr `/criterio-product:product-setup` y `/criterio-product:product-requirements` para levantar el registro, y que el comité acepte requerimientos. Después, `/product-spec`.

Pie: sin registro del cual salir · 0 requerimientos cubiertos · cierra el gerente de producto, Laura Vélez · Términos: TERMS.md
