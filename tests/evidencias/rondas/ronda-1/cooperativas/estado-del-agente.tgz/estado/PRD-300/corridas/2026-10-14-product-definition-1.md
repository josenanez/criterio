# Corrida del 2026-10-14 · product-definition

? · 0 requerimientos · 33 s · 0 hallazgos

La evidencia sostiene solo una necesidad dicha por un cliente (2025-10-11, ya vieja); cifras sin serie, sin criterio de éxito, supuesto del proveedor sin rastro de verificación

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Definición — Crédito de libranza (PRD-300) · contrastada al 2026-10-14
**Documento:** `00-definicion/2026-05-09-definicion-producto.md` (con `2026-05-09-caso-de-negocio.md`) · **del** 2026-05-09 · 4 afirmaciones

Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (ya en la configuración). Sesión sin interfaz: no hubo preguntas que responder.

### Lo que la evidencia contradice
Nada. La única evidencia de demanda es una frase de una entrevista y no contradice ninguna afirmación; tampoco hay serie medida que lo haga.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %) porque no hay serie con la cual compararla. `compute` devolvió `claim_vs_metric` vacío.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 211.347 | Caso de negocio, 2026-05-09 (se cita a sí mismo como fuente) | `estado/PRD-300/metrics/` está vacío. Nadie está midiendo lo que el negocio afirmó. |
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-05-09 | Sin cifra ni base de cálculo: no hay nada que medir. |

### No está dicho en ninguna parte
- De dónde sale el volumen mensual de 211.347: ni entrevista, ni serie, ni cálculo.
- Qué retorno se espera a 24 meses y con qué supuestos.
- Qué es la «Propuesta principal»: la definición pone un título y nada más.
- Quiénes son los «Asociados urbanos», cuántos son, y cuántos de ellos quieren libranza.
- Que la ausencia de crédito de libranza en el segmento es un hecho: lo afirma la definición y ningún documento lo muestra (la entrevista sostiene la necesidad de un cliente, no la ausencia de oferta).
- Quién es el proveedor y cuál es el tiempo pactado.
- Qué es el éxito: no hay criterio de éxito.
- Qué proyecto construye el producto: la definición dice «Ninguno declarado» y los tres REQ del acta del 2026-10-13 tienen «—».
- Qué plan «se mantiene» (acta del 2026-10-13) y por qué.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «El proveedor cumple el tiempo pactado» · declarado 2026-09-03 · marcado «verificado» | No aplica: ya figura como verificado, pero ningún documento muestra la verificación. Lleva 41 días desde la declaración (aritmética de fechas; `compute` no lo calculó). | Nombrar al proveedor, citar el contrato con el tiempo pactado y la entrega o el acta de recibo que muestra que lo cumplió. Sin eso «verificado» es una etiqueta. |
| Implícito, no declarado: el volumen del caso de negocio es alcanzable | — (no está declarado, no corre el reloj) | Declararlo como supuesto y ponerle una serie o un piloto contra el cual medirlo. |

Ninguno de los dos está escrito de forma infalsable; el primero sí es verificable, y nadie ha dejado el rastro.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento no tiene crédito de libranza» (solo la necesidad) | Entrevista de un cliente sin nombre: «Lo necesito y hoy no lo tengo» | 2025-10-11 | Débil: dicho, no pagado ni pedido formalmente; un solo entrevistado; sin vínculo documentado con el segmento ni con ningún requerimiento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad de libranza en el segmento | Entrevista del 2025-10-11 | 12 meses y 3 días: pasa el umbral de 12 meses. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Crédito con descuento por nómina (libranza) | No dicho en la documentación | Reglas del crédito de libranza y de los descuentos sobre salario o pensión | — | No tengo la norma a la vista |
| Consumidor financiero / información al asociado | No dicho | Información previa, transparencia de tasas y costos | — | No tengo la norma a la vista |
| Datos personales (nómina, ingresos, asociados) | No dicho | Autorización, finalidad y custodia de datos | — | No tengo la norma a la vista |
| Retención de información crediticia | No dicho | Plazos de conservación | — | No tengo la norma a la vista |

Es un listado de qué tocar, no un dictamen: ningún documento de la carpeta cita norma ni fija el país, y no cito ninguna de memoria. No digo si el producto cumple. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
`compute` deja `unknown`: **problema, para quién, criterio de éxito y autoridad**. El texto de la definición sí enuncia un problema y un segmento, pero el estado (`producto.json`) está vacío, así que el cálculo no los ve. Falta cargarlos o confirmarlos.
- **Criterio de éxito: no existe.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- Autoridad: el acta del 2026-10-13 la da como Comité de producto; falta que conste en el estado.

### Notas de la corrida
- Estado sin poblar: `producto.json` vacío, 0 requerimientos registrados, `metrics/` vacío. Por eso `compute` salió vacío y los contrastes numéricos quedan en «nadie mide».
- La fecha de la definición (2026-05-09) es anterior a la del supuesto que lleva (2026-09-03): la definición se editó después sin cambiar la fecha o el supuesto se añadió a otro documento.
- Borrador de trabajo, no certificado. La verificación es tuya (TERMS.md v1.0). Una ausencia de hallazgo no es evidencia de que todo esté bien.

**Después que ofrezco:** convertir el supuesto del proveedor y el volumen en riesgo con doliente (`raid-taxonomy`). No ofrezco `/product-charter`: la definición no está cerrada (sin criterio de éxito).
