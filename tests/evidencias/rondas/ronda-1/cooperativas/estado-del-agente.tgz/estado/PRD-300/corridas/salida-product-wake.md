## Crédito de libranza (PRD-300) · 2026-10-14

Tocaba `review` (nunca se había corrido). No cruzó ningún umbral: no hay señales `crossed`, porque el registro tiene 0 requerimientos y la definición está vacía (problema, quién, éxito y autoridad: no dichos en ninguna parte del estado).

**Revisión del registro contra la carpeta:** la carpeta tiene 4 documentos (definición y caso de negocio del 2026-05-09, entrevistas del 2025-10-11, acta del comité del 2026-10-13) y ninguno está volcado al registro. Hasta que se levante, los umbrales de 60 días sin decidir, 30 de supuesto sin verificar y 12 meses de evidencia no pueden medirse.

**Trazas:** no existe la carpeta de fichas (`estado/PRD-300/fichas`); ninguna traza se da por confirmada.

**Qué haría falta:** correr `/criterio-product:product-setup` (o `/product-requirements`) para que Alba inventaríe los documentos. No lo hice aquí: este comando no construye el registro.

**Vuelvo el 2026-11-13.**
