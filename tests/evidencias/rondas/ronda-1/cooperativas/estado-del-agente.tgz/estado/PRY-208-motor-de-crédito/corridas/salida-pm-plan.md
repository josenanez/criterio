Términos: ya aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14), coinciden con TERMS.md v1.0. Sesión sin interfaz: no hubo preguntas que responder.

# Plan — PRY-208 Motor de crédito · borrador del 2026-10-14
**Desde:** acta de constitución aprobada el 2025-10-24 · **Criterio de éxito:** «Motor de crédito en producción y medido» (declarado, pero sin métrica ni umbral)

> El proyecto ya está en ejecución y tiene cronograma v1 (2025-10-24) y v2 (2026-10-11). Este borrador es la descomposición por entregable desde el acta; no reemplaza ni crea una línea base, y no compromete fechas.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1, 2, 3» | No se puede descomponer por entregable lo que no tiene nombre. Tres nodos del WBS quedan «sin definir» y nadie sabe qué hay que aceptar. |
| **Fuera de alcance:** «Lo que otro proyecto cubre» | No dice qué ni cuál proyecto. Cualquier frontera con otros proyectos (p. ej. el core) queda sin trazar. |
| **Criterio de éxito sin medida:** «en producción y medido» | No dice medido por qué, con qué umbral ni quién lo mide. «Medido» no se puede convertir en un entregable aceptable. |
| **Dependencias: «Ninguna declarada»**, pero el informe del 2026-10-11 lista como riesgo la «dependencia del proveedor del core cooperativo», y el cronograma tiene el hito «Integración con el core cooperativo» | El plan nace con una dependencia que el acta niega. La integración es el hito en curso y el que se movió. |
| **Sin sección de autoridad** (qué decide el gerente y qué sube al comité) | No sé qué puedes decidir al planificar y qué hay que escalar. Va como pregunta abierta, no como supuesto. |
| **Objetivo genérico:** «Entregar motor de crédito para Cartera y cobranza» | No distingue qué decisiones de crédito automatiza el motor. Afecta qué cuenta como «producción». |
| **Cierre del acta (2026-11-29)** frente a la fecha vigente de la integración (2027-01-12) | Observación, no conclusión mía: la fecha vigente de un hito intermedio ya cae después del cierre del acta. La solicitud CC-01 (+100 días, +200.000.000 COP) sigue «pendiente de presentación al comité». |

Hay patrocinador (Andrés Lozano) y gerente (Liliana Torres), así que las excepciones tienen a quién llevarse. Sigo marcando los huecos en lugar de rellenarlos.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado (cerrado, fecha vigente 2026-02-22) | Sin definir | Del cronograma v1/v2 (no del acta) | — |
| 2 | Ambiente de pruebas certificado (cerrado, 2026-06-14) | Sin definir | Del cronograma v1/v2 | — |
| 3 | Integración con el core cooperativo (en curso). El informe dice que el proveedor entregó el componente «pendiente de aceptación» | Sin definir | Del cronograma v2 e informe 2026-10-11 | — |
| 4 | Componente 1 | Sin definir | Del acta (sin nombre ni contenido) | — |
| 5 | Componente 2 | Sin definir | Del acta (sin nombre ni contenido) | — |
| 6 | Componente 3 | Sin definir | Del acta (sin nombre ni contenido) | — |
| 7 | Reglamento aprobado por el Consejo de Administración | Consejo de Administración (supuesto) | Supuesto: solo aparece como riesgo en el informe, no como entregable | — |
| 8 | Motor de crédito en producción | Sin definir | Del acta (criterio de éxito) | — |
| 9 | Medición del motor en producción | Sin definir qué se mide ni quién | Del acta («y medido») | — |
| 10 | Ampliación de alcance de CC-01 | Sin definir | Documento CC-01, **no aprobado**; no entra al plan hasta que el comité decida | — |

Los «puntos 30 y 34» del comité (compromisos de Gustavo Neira y Paula Céspedes) no se pueden asignar a ningún nodo: ningún documento dice a qué entregable pertenecen. Quedan en «Sin definir».

## Orden
Solo dependencias, sin fechas.
- 1 → 2 → 3: es el orden del cronograma (**supuesto**: que cada uno necesita al anterior; ningún documento lo dice).
- 3 necesita la aceptación del componente entregado por el proveedor (del informe).
- 8 necesita 3 y 7 (**supuesto**).
- 9 necesita 8 (del acta: «en producción **y** medido»).
- 4, 5 y 6 respecto de 3 y 8: **sin definir**, no se sabe qué son.
- 10 no tiene lugar en el orden hasta que se apruebe CC-01.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Diseño, ambiente de pruebas e integración van en cadena | El orden cambia y la ruta crítica no es la que parece. |
| El reglamento del Consejo es requisito para salir a producción | Si no lo es, se quita una dependencia. Si lo es y no está planificado, es un entregable sin dueño. |
| La aceptación del componente de integración le toca al negocio o al comité | No hay a quién pedirle la aceptación y el hito sigue «en curso». |
| El proveedor del informe es el del core cooperativo (el informe lo nombra así) | Si hay dos proveedores, hay dos dependencias. |
| La ampliación CC-01 queda fuera del plan hasta que el comité la apruebe | Si ya se está trabajando, el alcance real supera al del acta. |

Estos pasan al RAID con doliente en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Andrés Lozano) con el área dueña (Cartera y cobranza) |
| Qué se mide y con qué umbral para dar por logrado «medido» | Patrocinador |
| Quién acepta cada entregable | Patrocinador / comité |
| Qué es «lo que otro proyecto cubre» | Patrocinador |
| A qué entregable pertenecen los puntos 30 y 34 | Gustavo Neira y Paula Céspedes (responsables de esos compromisos) |
| Autoridad del gerente al planificar | Patrocinador / comité |
| Contenido real de CC-01 («ampliación de alcance» no dice cuál) | Liliana Torres, para llevarlo al comité |

## Proyectos análogos
Ninguno a la vista. Tu configuración no apunta a una carpeta de fichas de la PMO, y en `estado/` solo está este proyecto y PRD-300. En `documentos/proyectos/` hay otros proyectos (p. ej. PRY-202 core-cooperativo, PRY-200 crédito de libranza digital), pero no los leí ni sé si son análogos. Decir cuánto tomaron sería inventarlo.

## Preguntas para el equipo
Una por duración vacía:
1. Diseño funcional (nodo 1): ¿cuánto tomó realmente, y quién lo aceptó?
2. Ambiente de pruebas (nodo 2): ¿cuánto tomó realmente, y quién lo certificó?
3. Integración con el core (nodo 3): ¿cuánto falta, dado que el proveedor ya entregó y falta la aceptación? ¿Quién acepta y cuándo?
4. Componentes 1, 2 y 3 (nodos 4-6): ¿qué son, quién los recibe y cuánto toma cada uno?
5. Reglamento (nodo 7): ¿es requisito para producción? ¿Cuándo sesiona el Consejo y cuánto se demora una aprobación?
6. Producción (nodo 8): ¿cuánto toma el despliegue y qué ventana de producción hay?
7. Medición (nodo 9): ¿qué se mide, con qué umbral y cuánto tiempo hay que medir antes de declarar el éxito?
8. CC-01 (nodo 10): ¿qué entra en la ampliación y cómo se llegó a +100 días y 200.000.000 COP?
9. Puntos 30 y 34: ¿a qué entregable pertenecen?

## Para comprometer una fecha falta
- **Disponibilidad real del equipo.** El informe habla de dos semanas perdidas por la rotación de un desarrollador clave, y las notas del 2026-10-14 dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase (nadie lo registró como riesgo).
- **La fecha del proveedor para la siguiente fase** (hay una revisión con el proveedor el 2026-10-24, según las notas).
- **La ventana de producción y el calendario del Consejo de Administración.**
- **La decisión del comité sobre CC-01**, prevista para el comité del 2026-10-28 según la configuración. Hasta entonces hay dos futuros posibles para el alcance.
- Contexto de costo: la proyección al cierre del informe (2.786.927.469 COP) ya supera el presupuesto aprobado (2.400.000.000 COP), sin contar CC-01.

Ninguna de las cuatro está en un documento.
