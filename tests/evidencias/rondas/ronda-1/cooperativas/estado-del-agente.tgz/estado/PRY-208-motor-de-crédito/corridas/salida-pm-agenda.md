*(Prueba sin interfaz: nadie respondió preguntas. Términos 1.0 ya aceptados en la configuración por José Francisco Ñáñez el 2026-10-14. Sin tope de minutos en el argumento: usé el que sale de la suma.)*

## Reunión de seguimiento — PRY-208 Motor de crédito · 2026-10-28
2 puntos · 10 minutos · 2 personas requeridas (Liliana Torres, Óscar Ramírez) y una por identificar

Base de esta agenda: es la primera corrida, **no hay foto anterior contra la cual comparar** (`diff`: «starting point»). Por eso no hay anexo «sin cambios». Y `due` no marca nada hoy (corte 2026-10-14; la próxima reunión es el 2026-10-28, en 14 días). **Hoy no hay nada vencido ni reprogramado tres veces**; lo que sigue está armado sobre lo que *va a* vencer antes de esa fecha.

### Lo que no se destraba solo
Nada todavía: ningún compromiso lleva tres reprogramaciones y ninguno está vencido sin evidencia. Si el 28 llega así, es una reunión de seguimiento y se dice.

### Se decide hoy o se atrasa
> **[1] Que el riesgo del proveedor tenga dueño y quede en el RAID, con el resultado de la revisión de Óscar a la vista** · 5 min · **Liliana Torres, Óscar Ramírez**
> El 14 «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». Sin autor y sin dueño. Óscar tiene «revisión con el proveedor» para el 2026-10-24, o sea que el 28 ya tiene resultado, y el informe del 11 lista otro riesgo parecido («Dependencia del proveedor del core cooperativo»): decidir si es el mismo o uno nuevo.
> Fuente: `2026-10-14-notas-reunion.txt` (2026-10-14); `2026-10-11-informe-avance.md`.
> **Si no se resuelve hoy:** sigue siendo algo que «se comentó»: sin dueño no se mueve nada, y la siguiente fase arranca con el riesgo sin registrar.
> *Pendiente de confirmar con Óscar:* las notas no aclaran si la revisión es suya o de otros.

> **[2] Quién acepta, o rechaza, el componente de integración del proveedor** · 5 min · **quien tenga la autoridad de aceptación (no consta en los documentos)**
> El informe del 2026-10-11 dice «el proveedor entregó el componente de integración, pendiente de aceptación». No hay acta de recibo. No hay contrato en la carpeta, así que no sé quién acepta ni en qué plazo.
> Fuente: `2026-10-11-informe-avance.md`.
> **Si no se resuelve hoy:** el entregable queda en «entregado, no aceptado» indefinidamente y la revisión de Óscar (punto 1) se hace sobre algo sin estado.

### Vencido sin evidencia
Ninguno al 2026-10-14. Se vuelve a calcular el 28.

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Qué mirar antes |
|---|---|---|---|
| Gustavo Neira | Entregar el punto 30 | 2026-10-19 | Dicho el 11/10; el 14 estuvo en la reunión y no se lo mencionó. **Preguntarle antes del 19**, no el 28: si llega al 28 sin evidencia, entra a la agenda como vencido. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Alimenta el punto 1. Confirmar que la revisión es suya. |
| Laura Vélez | Mandar el ajuste del presupuesto | sin fecha («la otra semana») | No puede vencer y por eso nadie lo va a notar. Pedirle una fecha **por mensaje, esta semana**; no gasta tiempo de reunión. |
| Paula Céspedes | Entregar el punto 34 | 2026-10-28 | Vence **el mismo día** de la reunión. Antes: 2026-10-01 (comité del 11/10), 1 reprogramación. Si no entrega el 28, es la segunda. Pedir la evidencia ese día; no es punto de agenda salvo que falle. |

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Solicitud de cambio CC-01: ampliación de alcance, +100 días, +200.000.000 COP | «Pendiente de presentación al comité» (2026-10-02). Excede al gerente. | Comité (`/pm-escalate`, material de comité). Ojo: la reunión del 28 coincide con la fecha del comité en la configuración; ver abajo. |
| Que la proyección del informe (2.786.927.469 COP) supera lo aprobado (2.400.000.000 COP) | Es una decisión de presupuesto, no se destraba en una reunión de seguimiento. | Comité, junto con CC-01. No lo calculé contra CC-01: los documentos no dicen si la proyección ya lo incluye. |

### Anexo
No hay: primera corrida, sin foto anterior.

---
**Lo que no sé y conviene resolver antes de convocar**
- **«Próxima reunión en dos semanas»** (notas del 14): sin día. La configuración pone el comité el 2026-10-28, mismo día del compromiso de Paula. Asumí el 28; si es la misma reunión que el comité, CC-01 pasa a ser punto y necesita a Andrés Lozano, que no figura entre los asistentes del 14.
- Quién acepta entregables del proveedor.
- Si la revisión con el proveedor es de Óscar.

**Después:** cuando termine la reunión, `/pm-minutes` sobre las notas; los compromisos entran a `/pm-commitments`. Esta agenda no convoca a nadie.

---
Generado con Criterio · borrador de trabajo, según los documentos leídos
Verificar contra la fuente antes de decidir. Términos: TERMS.md
