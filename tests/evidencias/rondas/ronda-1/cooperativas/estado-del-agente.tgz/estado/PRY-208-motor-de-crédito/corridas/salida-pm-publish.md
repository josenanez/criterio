Publiqué la ficha en `documentos/proyectos/PRY-208-motor-de-crédito/00-gobierno/ficha-pm.json`, con corte al 2026-10-14.

**Lleva:** 11 elementos con dato (6 de identidad, 4 compromisos, 1 riesgo) · 2 sin decir en ninguna parte (la fecha del compromiso de Laura Vélez y el responsable del riesgo del proveedor) · 5 bloques sin dato (declaración de estado, plan, dinero, proveedores, cambios) · **no declara estado**: no hay declaración tuya en los documentos, así que `declared.status` y `declared.as_of` no van.

**Lo más viejo que va ahí:** identidad del proyecto (código, nombre, área, patrocinador, gerente, comité), del 2025-10-24 (acta de constitución) — 355 días, casi un año; el cálculo ya la marca como vieja (12 meses).

**Lo que la PMO verá, de los ocho campos que contrasta:** `identity.sponsor`, `identity.manager` e `identity.committee` salen solo del acta de 2025; `identity.product`, `plan.end_date`, `money.approved`, `declared.status` y `declared.as_of` salen vacíos. La PMO tendrá poco con qué contrastar.

**Aviso:** 1 alerta viva — compromiso sin fecha (Laura Vélez, «Mandar el ajuste del presupuesto»). Sin línea base. Términos: José Francisco Ñáñez, v1.0, 2026-10-14.
