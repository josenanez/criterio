# Corrida del 2026-10-14 · pm-commitments

1 proyectos · 32 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

4 abiertos, 0 vencidos, 1 sin fecha (Laura Vélez), Gustavo Neira vence 19/10, Paula Céspedes reprogramada 1 vez (bajo umbral 3); sin cierres con evidencia

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

*(Prueba sin interfaz: nadie respondió preguntas. Términos 1.0 ya aceptados en la configuración por José Francisco Ñáñez el 2026-10-14.)*

## Compromisos — PRY-208 Motor de crédito · al 2026-10-14

4 compromisos abiertos. Ninguno vencido, ninguno reprogramado tres veces, ninguno cerrado con evidencia. Una señal: `commitment_undated`.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Entregar el punto 30 | 2026-10-19 |

Dicho en el comité del 2026-10-11. Gustavo estuvo en la reunión del 14 y las notas no lo mencionan: nadie dijo si va en camino.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-14 |

Cita: «queda de mandar el ajuste del presupuesto la otra semana». «La otra semana» no es una fecha y no se le inventó una. No puede estar vencido; por eso se cuenta aparte.

### Abiertos con fecha posterior
| Quién | Qué | Para cuándo | Nota |
|---|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Las notas no aclaran si la revisión es suya o de otros. Confirmarlo con él. |
| Paula Céspedes | Entregar el punto 34 | 2026-10-28 | **Reprogramado 1 vez:** antes 2026-10-01 (comité del 2026-10-11). Por debajo del umbral de 3. |

Sobre Paula: el comité del 11 registró el 01/10 como fecha ya pasada, así que el primer plazo estaba vencido cuando se anotó. No hay documento que diga qué pasó entre el 1 y el 11 de octubre.

### Cerrados desde la última revisión
Ninguno. El informe del 2026-10-11 dice que el proveedor entregó el componente de integración, «pendiente de aceptación»; no hay acta de recibo ni nada que cierre un compromiso.

---
**Cifras (`compute`, corte 2026-10-14):** vencidos 0 · sin fecha 1 · reprogramados en exceso 0.

**Después:** nada llegó a tres reprogramaciones, así que no hay decisión que subir al comité. `/pm-publish` no hace falta: ningún campo de la ficha cambió.

---
Generado con Criterio · borrador de trabajo, según los documentos leídos
Verificar contra la fuente antes de decidir. Términos: TERMS.md
