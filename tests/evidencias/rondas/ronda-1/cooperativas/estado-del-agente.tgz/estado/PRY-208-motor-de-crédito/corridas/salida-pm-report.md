# Motor de crédito (PRY-208) — semana del 2026-10-07 al 2026-10-14

**Declara el gerente:** SIN DECLARACIÓN. La sesión no tuvo a nadie que respondiera, y el sistema no propone un estado: la línea queda en blanco a propósito.
**Sustento documental:** no evaluable (no hay declaración que contrastar).
**Lo que el semáforo no explica:** no aplica sin declaración. Señales abiertas que el gerente tendría que ver antes de declarar: 1 compromiso sin fecha (Laura Vélez); la ficha no tiene línea base, plan ni dinero.

> Nota de contexto, no es la declaración de esta semana: el informe de avance del 2026-10-11 (`20-seguimiento/2026-10-11-informe-avance.md`) trae «Verde, 81%». No está cargado en la ficha, así que el cálculo no lo contrastó. Ver «Contra el plan».

## Qué cambió esta semana
No hay base de comparación: el único snapshot es el de hoy (2026-10-14) y el diff contra él da 0 cambios. Lo nuevo es lo que entró con las notas de hoy:
| Qué | Estaba | Está | |
|---|---|---|---|
| Paula Céspedes, «entregar el punto 34» | 2026-10-01 | 2026-10-28 | reprogramado 1 vez |
| Óscar Ramírez, revisión con el proveedor | — | 2026-10-24 | nuevo |
| Laura Vélez, ajuste del presupuesto | — | sin fecha («la otra semana») | nuevo, sin fecha |
| Riesgo: proveedor sin equipo completo | — | dicho en reunión, sin dueño ni registro | nuevo |

## Lo que sigue igual y sigue mal
Sin histórico no se pueden contar días. Lo que sigue mal según documentos: solicitud de cambio CC-01 (2026-10-02) «pendiente de presentación al comité», 12 días.

## Contra el plan
La ficha no tiene plan (`has_baseline: false`). Lo siguiente sale de los documentos y **no está verificado por el cálculo**:
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Integración con el core cooperativo | 2026-10-04 | 2027-01-12 | +100 días (≈ lo pedido en CC-01) |
| Presupuesto | 2.400.000.000 COP aprobado | proyección 2.786.927.469 | +16,1% |

Replanificaciones registradas en la ficha: 0. El cronograma v2 (2026-10-11) ya usa la fecha nueva mientras CC-01 (+100 días, +200.000.000 COP) sigue sin autorización: una replanificación sin aprobar. El hito de integración está vencido contra la base (2026-10-04).

### Hitos de las próximas cuatro semanas
Ninguno en el cronograma v2 cae en la ventana; el de integración ya venció contra su base y se movió a 2027-01-12.

## Las cifras
Del informe del 2026-10-11, no de la ficha (COP):
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.042.212.937 | 1.294.116.301 | 2.786.927.469 | 1.357.787.063 |

Disponible real = aprobado − comprometido. Ojo: el ejecutado es mayor que el comprometido, algo que no cuadra y requiere explicación del gerente.

## Abierto
**Reprogramados:** Paula Céspedes, punto 34, una vez (01-10 → 28-10).
**Vencidos sin evidencia:** ninguno por fecha hoy.
**Sin fecha:** Laura Vélez, ajuste del presupuesto.
**Próximos:** Gustavo Neira, punto 30, 2026-10-19; Óscar Ramírez, 2026-10-24.
**RAID sin movimiento:** el riesgo del proveedor no tiene dueño ni está registrado.
**Proveedor:** el informe dice que entregó la integración y está «pendiente de aceptación», sin documento de aceptación. La ficha no trae el contrato.

## Lo que necesito de alguien
- Liliana Torres: declarar estado y avance; explicar por qué el ejecutado supera al comprometido.
- Laura Vélez: fecha para el ajuste del presupuesto.
- Dueño para el riesgo del proveedor (sin nombre).
- Comité (excede al gerente): CC-01, +100 días y +200.000.000 COP, ya aplicado en el cronograma v2 sin autorización. Próximo comité: 2026-10-28.

## Lo que no se sabe
**Sin dato en la ficha:** declaración, plan, dinero, proveedores, cambios; fecha del compromiso de Laura Vélez; dueño del riesgo.
**Silencio:** último documento hace 0 días (2026-10-14) · última reunión hace 0 días.

---
Ficha `estado/PRY-208-motor-de-crédito/records/PRY-208.json`, actualizada 2026-10-14, sin sellar; 7 campos sin dato. Términos: TERMS.md v1.0 (aceptados por José Francisco Ñáñez, 2026-10-14).
