*(Prueba sin interfaz: nadie respondió preguntas. Términos 1.0 ya aceptados en la configuración por José Francisco Ñáñez el 2026-10-14; no hubo que volver a pedirlos.)*

# Acta — PRY-208 Motor de crédito · 2026-10-14
**Asistieron:** Gustavo Neira, Liliana Torres, Paula Céspedes, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-14-notas-reunion.txt` (notas sueltas de alguien, no transcripción) · **Ausentes con tema en agenda:** no se puede decir, las notas no traen agenda. Andrés Lozano (patrocinador) no figura entre los asistentes.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 34 | 2026-10-28 | **Reprogramado, 1 vez:** antes 2026-10-01 (comité del 2026-10-11). Cita: «lo de "entregar el punto 34" no alcanzó, se compromete para el 28/10/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Cita: «revisión con el proveedor, queda para el 2026-10-24» (ver *Sin resolver*) |

Sigue abierto, sin que se haya hablado el 14: Gustavo Neira, «Entregar el punto 30», para 2026-10-19 (comité del 2026-10-11). Estuvo en la reunión y las notas no lo mencionan.

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana». «La otra semana» no es una fecha; no se le inventó una. |

## Decisiones
Ninguna. Las notas no registran que nadie haya decidido nada.

## Quedó sin decidir
Nada se planteó como decisión pendiente en las notas, así que no hay qué listar. Lo más cercano es el ajuste del presupuesto de Laura Vélez, que está en camino pero sin decisión asociada.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | No se sabe: la nota dice «se comentó», sin autor | Riesgo | No. No hay registro RAID en la carpeta; el informe del 2026-10-11 lista otros dos riesgos («Dependencia del proveedor del core cooperativo», «Aprobación del reglamento por el Consejo de Administración») y ninguno es este. Queda sin responsable. |

## Cerrado en esta reunión
Nada. Sección omitida: ningún compromiso se cerró contra un documento. El informe del 2026-10-11 dice que el proveedor entregó el componente de integración, «pendiente de aceptación»; no hay acta de recibo.

## Lo que esta reunión contradice
Nada contradice un campo de la ficha. Patrocinador, gerente, comité y fecha de cierre no se tocaron. Sí hay dos puntos para tener a la vista:
- El acta de constitución es de 2025-10-24 (12 meses) y es la única fuente de patrocinador, gerente y comité; esta reunión ni la confirma ni la desmiente.
- El comité del 2026-10-11 lista como asistentes a Liliana Torres y Andrés Lozano; las notas del 14, a otras cinco personas y no a Andrés. Son reuniones distintas; lo señalo para que no se confundan.

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-24»: no queda claro si Óscar se compromete a hacer la revisión ese día o si la revisión (de otros) se aplazó a esa fecha. Lo registré como compromiso suyo; confirmarlo con él.
- «lo de "entregar el punto 34" no alcanzó»: no dice por qué no alcanzó.
- «28/10/2026»: leído como 28 de octubre (día/mes); no puede ser mes 28.
- «próxima reunión en dos semanas»: sin día; en la configuración el comité queda para 2026-10-28, la misma fecha del compromiso de Paula.

---
**Recalculado (`compute`, corte 2026-10-14):** 4 compromisos abiertos, 0 vencidos, 1 sin fecha (Laura Vélez), 0 marcados como reprogramados en exceso (el umbral es 3; Paula lleva 1). Una señal: `commitment_undated`. La ficha ya tenía todo esto desde `/pm-setup`; no cambió.

**Siguiente:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por ahora: ningún campo de la ficha cambió. El acta es tuya antes de ser evidencia de nadie: no escribí nada en tu carpeta de reuniones.

---
Generado con Criterio · borrador de trabajo, según los documentos leídos
Verificar contra la fuente antes de decidir. Términos: TERMS.md
