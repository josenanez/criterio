## Para decisión — PRY-208 · Motor de crédito · 2026-10-14

> Sesión sin interfaz: términos ya aceptados (v1.0, José Francisco Ñáñez, 2026-10-14). Sin argumento de tema, se tomó lo escalable que hay marcado: la solicitud CC-01 y la autoridad que el acta no declara.

### 0. Primer punto, antes que el que venías a subir: el acta no declara tu autoridad

El acta del 2025-10-24 no tiene sección de autoridad del gerente (qué puede aprobar Liliana Torres en tiempo, costo y alcance). Sin eso no se puede decir con respaldo si CC-01 excede tu facultad. **Se asume que sí lo excede** (+100 días sobre un cierre aprobado por el Comité de Crédito y +200 M COP sobre un presupuesto que también aprobó el comité), y esa lectura es mía, no del acta.

**Pregunta cerrada:** ¿Declara el Comité de Crédito, por escrito y en el acta, hasta qué desviación en tiempo y costo puede decidir la gerente sin venir al comité? (sí / no / la opción B: umbral X días y Y COP)
**Quién decide:** Comité de Crédito (aprobó el acta) · **Si no se decide el 2026-10-28:** CC-01 sigue sin autorización y la siguiente sesión es en dos semanas (2026-11-11 si la cadencia se mantiene), 18 días antes del cierre comprometido del 2026-11-29.

### 1. La decisión de fondo: CC-01

### ¿Se aprueba CC-01 (+100 días, +200.000.000 COP) y el cierre pasa a 2027-03-09, o se rechaza y se replantea el cierre del 2026-11-29?

**Quién decide:** Comité de Crédito, que aprobó el presupuesto y las fechas (acta, 2025-10-24); CC-01 dice «Pendiente de presentación al comité». Próxima sesión: **2026-10-28**. · **Si no se decide el 2026-10-28:** el cierre comprometido del 2026-11-29 se vence sin autorización para moverlo, y el hito «Integración con el core cooperativo», con línea base 2026-10-04, ya lleva 10 días vencido.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 tal cual | Ampliación (CC-01 no dice cuál) | Cierre 2026-11-29 → **2027-03-09** (cálculo: +100 días sobre el cierre del acta; la línea base vigente no está en la ficha) | +200.000.000 → 2.600.000.000 COP |
| B. Rechazar y mantener 2026-11-29 | Se recorta o se difiere lo que no cabe; no hay lista de qué | Sin cambio, pero la integración vigente es 2027-01-12, posterior al cierre: **no se sostiene** | Sin cambio aprobado; la proyección del informe ya es 2.786.927.469 (+386.927.469, 16,1 %) |
| C. Aprobar con condiciones (alcance y costo recalculados) | Se pide a la gerente desglosar la ampliación | Se decide el 2026-10-28 con cifra cerrada | Se pide cubrir los 386,9 M de la proyección, no solo 200 M |

**Recomiendo:** C — el cambio no cuadra consigo mismo: dice «ampliación de alcance» pero el atraso está en un hito que ya existía, y cubre 200 M cuando el propio informe proyecta 386,9 M sobre el aprobado.

### A quién alcanza
No se pudo calcular. `portafolio.py impact` devolvió 0 proyectos y 0 hitos alcanzados porque la ficha no tiene plan ni fecha de cierre (campos `plan`, `money`, `changes` sin encontrar), y el acta declara «Ninguna declarada» en dependencias. **No quiere decir que no alcance a nadie:** el informe de avance menciona la dependencia del proveedor del core cooperativo y nadie confirmó el otro lado. Cuántos días se mueve cada proyecto alcanzado tampoco se estima (falta holgura por actividad).

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Sin datos en la ficha | — | — | Core cooperativo: no confirmada |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Integración con el core cooperativo | 2027-01-12 (línea base 2026-10-04) | +100 ya aplicados en el cronograma v2 |
| Cierre del proyecto | 2026-11-29 (acta) | +100 → 2027-03-09 si se aprueba |

**Hallazgo que el comité debe conocer:** el cronograma v2 (2026-10-11) ya mueve la integración exactamente 100 días, y CC-01 está sin autorizar. Se está planeando sobre un cambio que nadie aprobó. La línea base anterior no se toca.

### Lo que también conviene llevar
- **Riesgo no registrado:** el proveedor podría no llegar con el equipo completo para la siguiente fase (notas 2026-10-14), sin responsable. Si se aprueba CC-01 hay que registrarlo antes.
- **Estado declarado «Verde»** con 81 % de avance, frente a 100 días de atraso en el hito crítico y presupuesto proyectado 16,1 % sobre el aprobado: el comité va a preguntar.
- **Compromiso reprogramado:** Paula Céspedes, «punto 34», de 2026-10-01 a 2026-10-28 (dos fechas; no llega a tres).
- Laura Vélez prometió el ajuste del presupuesto «la otra semana», sin fecha: relacionado con la decisión de arriba.

### De dónde sale esto
- Autoridad no declarada, presupuesto, cierre, dependencias: `00-gobierno/2025-10-24-acta-constitucion.md`.
- CC-01 (+100 días, +200 M COP, pendiente de comité): `20-seguimiento/2026-10-02-solicitud-cambio-cc-01.md`.
- Hitos y fechas: `10-plan/2026-10-11-cronograma-v2.csv`.
- Presupuesto proyectado, estado Verde, 81 %, riesgos: `20-seguimiento/2026-10-11-informe-avance.md`.
- Compromisos y riesgo dicho en reunión: `2026-10-14-notas-reunion.txt`, `30-reuniones/2026-10-11-comite-semanal.md`.
- Próximo comité 2026-10-28: `.criterio/proyecto/PRY-208/config.json`.
- Aritmética de fechas (2026-11-29 + 100 = 2027-03-09; 2026-10-04 + 100 = 2027-01-12) y de costo (2.786.927.469 − 2.400.000.000): cálculo propio.

**No sé:** cuál es tu autoridad declarada, la línea base vigente, qué proyectos dependen del tuyo, ni qué contiene la «ampliación de alcance». No hay llamada a otro gerente que recomendar porque la ficha no nombra a ninguno.
