## Carpeta al 2026-10-14

**Documentos:** 72 · **Sin cambio:** 72 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Las 24 son de PRY-208 y salen de la ficha del gerente (`00-gobierno/ficha-pm.json`), no de `estado/records/PRY-208.json`.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-208 | pm_record.identity.code, name, business_area, sponsor, manager, committee (6 campos) | 00-gobierno/2025-10-24-acta-constitucion.md |
| PRY-208 | pm_record.commitments[0], [2], [3]: who, what, due_date, source (12 campos) | 2026-10-14-notas-reunion.txt |
| PRY-208 | pm_record.commitments[1]: who, what, due_date, source (4 campos) | 30-reuniones/2026-10-11-comite-semanal.md |
| PRY-208 | pm_record.raid.risks[0]: what, owner (2 campos) | 2026-10-14-notas-reunion.txt |

Los tres documentos citados **existen** en `documentos/proyectos/PRY-208-motor-de-crédito/`, y el índice los ve sin cambio. Lo que no resuelve es la ruta: la ficha del gerente cita relativo a la carpeta del proyecto, y el índice busca desde `documentos/proyectos/`. La ficha del portafolio (`estado/records/PRY-208.json`) sí cita con el prefijo `PRY-208-motor-de-crédito/`. Es una hipótesis por la forma de las rutas; no la comprobé en el código del índice. No corregí ninguna cita.

### Formatos que no se pudieron leer
Ninguno. Este comando no lee contenido; solo cuenta y compara.

### Lo siguiente
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Queda pendiente decidir cómo citar la ficha del gerente de PRY-208 (con prefijo de proyecto o resolviendo relativo al proyecto); con esa ruta corregida, las citas rotas bajarían a cero.
