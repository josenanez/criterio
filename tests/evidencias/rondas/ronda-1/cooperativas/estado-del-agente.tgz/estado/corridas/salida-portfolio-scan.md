## Barrido — 2026-10-14

Términos v1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (consta en la configuración local). Sesión de prueba sin interfaz: no hubo preguntas; no aplicó ninguna respuesta sugerida.

**Documentos:** 72 en la carpeta · 49 leídos · 23 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Formatos: 27 md, 14 docx, 11 pdf, 10 xlsx, 8 csv, 1 txt, 1 json. Todos se convirtieron a texto; ninguno quedó sin leer.
Plan de lectura: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Nada diferido. PRY-205, PRY-208 y PRY-209 (23 documentos) no cambiaron y no se abrieron.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, declarado, plan, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase; el contrato no tiene factura |
| PRY-200 Crédito de libranza digital | 3 | identidad, declarado, plan, 3 hitos, presupuesto, 1 riesgo, 2 incidencias | autoridad, fase, acta de recibo de 2 hitos cerrados |
| PRY-201 Apertura de ahorro en línea | 3 | identidad, declarado, plan, 3 hitos, presupuesto, 1 riesgo, 3 incidencias | autoridad, fase, acta de recibo de 1 hito cerrado |
| PRY-202 Core cooperativo | 5 | identidad, declarado, plan, 4 hitos, presupuesto, 2 riesgos, 3 incidencias, 1 compromiso | autoridad, fase, acta de recibo de 3 hitos cerrados |
| PRY-203 Aportes sociales en línea | 6 | identidad, declarado, plan (2 líneas base), 3 hitos, presupuesto, CC-01, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase, acta de recibo de 2 hitos cerrados |
| PRY-204 Tarjeta débito para asociados | 5 | identidad, declarado, plan, 4 hitos, presupuesto, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase |
| PRY-206 Pagos con QR | 4 | identidad, declarado, plan, 4 hitos, presupuesto, 1 riesgo, 1 incidencia | autoridad, fase, acta de recibo de 1 hito cerrado |
| PRY-207 Microcrédito rural | 5 | identidad, declarado, plan, 4 hitos, presupuesto, 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase, acta de recibo de 3 hitos cerrados |
| PRY-210 Corresponsales rurales | 6 | identidad, declarado, plan (2 líneas base), 3 hitos, presupuesto, CC-01, 2 riesgos, 3 incidencias, 1 compromiso | autoridad, fase, producto («No aplica»), acta de recibo de 2 hitos cerrados |
| PRY-211 Cobranza digital | 6 | identidad, declarado, plan, 5 hitos, presupuesto, contrato CT-509 (4 entregables), factura FV-1509, 2 riesgos, 1 incidencia | autoridad, fase, acta de recibo de 5 hitos cerrados y de 2 entregables del contrato |

PRY-202 también tiene «No aplica» como producto. Ninguna ficha nombra la autoridad del gerente ni la fase. Dependencias declaradas: ninguna en los 10 proyectos.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-205, PRY-208, PRY-209 | Nada: sus documentos no cambiaron, no se releyeron | — |

### Lo que hay que mirar
1. **Hitos cerrados sin acta que lo pruebe: 19 de 24 declarados cerrados.** Solo 5 tienen acta de recibo: Diseño funcional en PRY-199, 202, 204 y 207, y Ambiente de pruebas en PRY-206. Por proyecto sin acta: PRY-211 (5), PRY-202 (3), PRY-207 (3), PRY-200 (2), PRY-203 (2), PRY-210 (2), PRY-201 (1), PRY-206 (1). La declaración se conservó como `met`; lo que falta es la prueba.
2. **Cierre comprometido vencido, cronograma todo cerrado y avance declarado menor al 100%.** PRY-202 (cierre 2026-05-21, avance 43 %), PRY-207 (cierre 2026-03-19, avance 80 %, en rojo) y PRY-211 (cierre 2026-07-10, avance 59 %). Los tres cronogramas declaran cerrados todos los hitos, incluido el piloto. En PRY-211 el hito «Salida a producción» figura cerrado pese al 59 %. Las dos fuentes se guardaron sin elegir.
3. **PRY-211, factura sin respaldo completo.** La factura FV-1509 (2026-09-10) es por 2.179.464.246 COP, el mismo monto que suman tres entregables de CT-509 a 726.488.082 COP cada uno. Hay una sola acta de recibo, la de «Bolsa de horas de desarrollo» (2026-02-23). Los otros dos entregables figuran «recibido» en el contrato sin acta. El cuarto, «Mesa de ayuda del primer trimestre» (comprometido 2026-05-22), sigue «en curso».
4. **PRY-203, cronograma movido antes de la aprobación.** La CC-01 (2026-10-04, +23 días, 46.000.000 COP) está «pendiente de presentación al comité», pero el cronograma v2 del 2026-10-10 ya mueve la integración con el core del 2026-10-01 al 2026-10-24.
5. **PRY-210, CC-01 sin rastro de la decisión.** La solicitud (2026-10-09, +69 días, 138.000.000 COP) dice «Autorizada por el comité» sin decir cuál. El acta del Consejo del 2026-10-13 no la menciona. El cronograma v2 (2026-10-10) ya mueve la integración del 2026-11-11 al 2027-01-19.
6. **Compromisos vencidos sin evidencia:** PRY-204, Gustavo Neira, «Entregar el punto 34», para 2026-09-27 (dicho el 2026-10-06, ya vencido al decirlo); PRY-210, Beatriz Cuéllar, «Entregar el punto 2», para 2026-10-03 (dicho el 2026-10-13, ya vencido al decirlo). Los otros 5 compromisos están abiertos.
7. **Ejecutado mayor que comprometido** en PRY-200 (ejecutado 9.866.479.229 vs comprometido 9.671.355.133 COP) y PRY-203 (1.394.242.890 vs 1.143.719.187 COP). Es lo que dicen los informes; no cuadra y hay que preguntar.
8. **Reuniones:** PRY-200, 201, 206 y 211 no tienen ninguna minuta en `30-reuniones`. PRY-207 tiene la última del 2026-10-01 y su informe está en rojo.
9. **PRY-208 (no releído):** el índice reporta 24 campos de su `pm_record` cuya fuente no resuelve contra la raíz de documentación, porque las rutas de la ficha del gerente son relativas a la carpeta del proyecto y no a la raíz. No se tocó esa ficha; es de otro escritor.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: 72 de 72 convertidos |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` en la documentación |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno |

---
criterio-portfolio 0.3.6 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 206, 207, 210, 211) · campos en `not_found`: autoridad y fase en las 10, más 19 actas de recibo de hitos y 2 de entregables de CT-509 · términos: TERMS.md v1.0
