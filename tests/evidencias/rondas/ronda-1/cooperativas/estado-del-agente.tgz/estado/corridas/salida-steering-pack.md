# Comité de proyectos — 2026-10-21 (material preparado el 2026-10-14)
6 decisiones · 4 escalamientos sin decisión asociada · 12 de 13 proyectos con hallazgos

Cargué 13 fichas de `estado/records` (PRY-199 a PRY-211), con corte al 2026-10-14, y las cifras de `portafolio.py compute` con los umbrales de la configuración. Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14.

## Decisiones del comité anterior
No hay registro. Ninguna ficha ni corrida de `estado/` recoge un comité de portafolio anterior, ni decisiones suyas.
Tres solicitudes de cambio figuran como «aprobadas por el comité» sin decir cuál (PRY-205 CC-01, PRY-209 CC-01, PRY-210 CC-01). El acta del comité del 2026-10-13 que cita PRY-209 no menciona la decisión. Esto se trata en la decisión [1] y la [5].

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo, y hasta qué monto, en cada proyecto del portafolio?
**Proyecto:** los 13 · **Quién decide:** el comité, o la autoridad que lo nombre · **Si no se decide hoy:** las 4 solicitudes pendientes (decisiones [2] a [4]) no tienen quién las apruebe, y los proyectos siguen moviendo fechas sin autorización.

La autoridad del gerente no está en ninguna ficha: 13 de 13 proyectos sin autoridad. Cada proyecto declara un comité distinto como instancia:
- Consejo de Administración: PRY-203 y PRY-210.
- Comité de Tecnología: PRY-205 y PRY-209.
- Comité de Crédito: PRY-208 y PRY-211.
- No he revisado los comités de PRY-199, 200, 201, 202, 204, 206 y 207.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar una autoridad por monto y por días de cambio, igual para todos | Se aprueba o se sube con una regla única | Cambios pequeños se deciden sin esperar comité | Hay que fijar el monto; no tengo base en los documentos para proponer una cifra |
| B. Mantener a cada comité por proyecto y exigir acta de cada decisión | Cada instancia decide lo suyo | Depende de la agenda de cada una | Sin cambio |
| C. No definir nada hoy | Sin cambio | Los cambios siguen sin dueño | Sin cambio |

**Recomendación:** A, o B con acta obligatoria. Sin saber quién aprueba, las decisiones [2] a [5] no se pueden cerrar con validez. Ese es el primer punto del comité.

### [2] PRY-208 Motor de crédito — CC-01: ¿se aprueba la ampliación de alcance (+100 días, 200.000.000 COP)?
**Proyecto:** PRY-208 · **Quién decide:** sin definir (ver [1]); la ficha declara el Comité de Crédito, con patrocinador Andrés Lozano y gerente Liliana Torres · **Si no se decide hoy:** la fecha de fin ya está movida a 2027-01-12, 100 días sobre la original, y los 100 sin autorización.
Estado: solicitud del 2026-10-02, decisión pendiente. La proyección de costo supera el aprobado en 16.1 % (umbral 10 %). El informe de avance del 2026-10-11 declara Verde, y 4 señales abiertas lo contradicen.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar | Entra la ampliación | Se formaliza la línea base nueva con +100 días | +200.000.000 COP sobre un proyecto ya proyectado 16.1 % sobre el aprobado |
| Aplazar a 2026-10-21 con condiciones | Sin cambio hasta decidir | La fecha ya movida queda sin respaldo una semana más | Sin cambio |
| Rechazar | No entra | Hay que devolver la fecha vigente o declarar el atraso sin cambio de alcance | Sin cambio en la solicitud; el sobrecosto proyectado sigue |

**Recomendación:** aplazar, con tres condiciones: que [1] esté resuelta, que Laura Vélez entregue el ajuste de presupuesto que prometió «la otra semana» (compromiso sin fecha, notas del 2026-10-14) y que el proyecto corrija su informe Verde. No hay cifra confiable de costo para decidir mientras el ajuste no llegue.

### [3] PRY-205 Prevención de lavado de activos — CC-02: ¿se aprueba la ampliación (+71 días, 142.000.000 COP) y se regulariza CC-01?
**Proyecto:** PRY-205 · **Quién decide:** sin definir (ver [1]); la ficha declara el Comité de Tecnología, con patrocinador Andrés Lozano y gerente Liliana Torres · **Si no se decide hoy:** la fecha de fin (2026-10-14) ya incluye 112 días sobre la original: 41 aprobados en CC-01 y 71 sin autorización.
CC-01 (+41 días, 82.000.000 COP) figura aprobado por «el comité», sin indicar cuál y sin línea base nueva registrada. CC-02 se pidió el 2026-10-14 y está pendiente. El presupuesto está comprometido al 91.1 % (umbral 90 %), con disponible real de 213.319.058 COP.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar CC-02 y registrar la línea base nueva | Entra la ampliación | Se respaldan los 71 días | +142.000.000 COP; comprometido ya sobre el umbral |
| Aplazar | Sin cambio | Los 71 días siguen sin respaldo | Sin cambio |
| Rechazar | No entra | Hay que devolver 71 días o declarar el atraso | Sin cambio |

**Recomendación:** no aprobar hoy. Primero se confirma quién aprobó CC-01 y se registra su línea base, porque sin eso CC-02 se apila sobre una decisión sin dueño. El proyecto lleva además un compromiso vencido (Óscar Ramírez, punto 15, 15 días) y uno sin fecha (Gustavo Neira, punto 24).

### [4] PRY-203 Aportes sociales en línea — CC-01: ¿se aprueba la ampliación (+23 días, 46.000.000 COP)?
**Proyecto:** PRY-203 · **Quién decide:** sin definir (ver [1]); la ficha declara el Consejo de Administración, con patrocinador Ricardo Salas y gerente Felipe Arango · **Si no se decide hoy:** la fecha de fin ya está movida a 2026-10-24 (23 días, 5.8 % sobre la original) sin autorización.
Solicitud del 2026-10-04, pendiente. El progreso declarado es 34 %, y el plan sostiene entre 67 % y 100 %.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Aprobar | Entra la ampliación | Se respalda la fecha 2026-10-24 | +46.000.000 COP; proyección actual 1.7 % sobre el aprobado |
| Rechazar | No entra | Hay que devolver 23 días o declarar el atraso | Sin cambio |

**Recomendación:** aprobar condicionado a [1] y a que el proyecto sustente con documentos los dos hitos que declara cumplidos sin evidencia. Es el cambio más pequeño del paquete y la fecha ya está corrida, así que lo que falta es la formalidad.

### [5] PRY-209 CC-01 (+114 días, 228.000.000 COP) y PRY-210 CC-01 (+69 días, 138.000.000 COP): ¿el comité ratifica lo que figura aprobado «por el comité» sin acta?
**Proyectos:** PRY-209 y PRY-210 (y la CC-01 de PRY-205, ver [3]) · **Quién decide:** sin definir (ver [1]) · **Si no se decide hoy:** quedan tres cambios aprobados sin acta y sin decisor identificable.
- PRY-209: aprobado el 2026-10-08; sin línea base nueva registrada; fecha de fin 2026-12-30; 114 días (60.0 %) sobre la original.
- PRY-210: aprobado el 2026-10-09; fecha de fin 2027-01-19; 69 días (15.5 %) sobre la original. Compromiso de Beatriz Cuéllar vencido hace 11 días.
Las dos aparecen en la ficha como Verde, y señales abiertas contradicen ambas.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Ratificar con acta y línea base nueva | Se confirma la ampliación | Queda respaldada la fecha vigente | +228.000.000 COP (209) y +138.000.000 COP (210) quedan avalados |
| Devolver a evaluación | Se suspende la ampliación | Se reabre la fecha | Se reabre el costo |

**Recomendación:** ratificar solo si quien decidió puede ser nombrado y existe el acta; si no, devolver a evaluación. Un cambio aprobado por quien no tenía la facultad es un hallazgo, no una decisión.

### [6] PRY-211 Cobranza digital: ¿se retienen nuevos pagos a Soluciones Solidarias (CT-509) hasta que haya evidencia de recibo?
**Proyecto:** PRY-211 · **Quién decide:** sin definir (ver [1]); la ficha declara el Comité de Crédito, con patrocinador Ricardo Salas y gerente Carlos Peña · **Si no se decide hoy:** el contrato sigue facturando sin soporte.
Hechos: facturado 2.179.464.246 COP, igual a lo aceptado. De los 4 entregables, 3 figuran aceptados y 2 de esos sin evidencia de recibo (licenciamiento del módulo; parametrización de líneas de crédito). Uno está atrasado 145 días (mesa de ayuda del primer trimestre, pendiente, vencido el 2026-05-22). El proyecto lleva 17 días en silencio y declara 59 % de avance, mientras sus 5 hitos figuran cumplidos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| Retener pagos nuevos hasta tener actas | Sin cambio | Puede frenar al proveedor | Protege el dinero aún no pagado |
| Seguir pagando y pedir actas en paralelo | Sin cambio | Sin freno | Riesgo de pagar sin entrega |

**Recomendación:** retener pagos nuevos y pedir las actas de recibo. Ya hay 2.179.464.246 COP facturados contra entregables que el expediente no sustenta del todo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-202, 205, 207, 209, 211 | Progreso declarado muy por debajo de lo que sostiene el plan (brechas de 57, 33, 20, 60 y 41 puntos) con todos los hitos «cumplidos» | Informes de 2026-09-27 a 2026-10-12 | Que cada gerente aclare si los hitos están cumplidos o el porcentaje está mal |
| PRY-200, 201, 211 | En silencio 24, 24 y 17 días (umbral 15) | Desde 2026-09-20 y 2026-09-27 | Que los gerentes reporten; sin respuesta, escalar a patrocinadores |
| PRY-204 | Compromiso de Gustavo Neira (punto 34) vencido hace 17 días, con informe Verde | 2026-09-27 | Fecha nueva o aviso de que no se hará |
| PRY-208 | Riesgo dicho en reunión del 2026-10-14: el proveedor podría no llegar con el equipo completo; sin doliente y no registrado | 2026-10-14 | Nombrar doliente o descartarlo |

## Para conocimiento
- PRY-199: sin señales abiertas; Verde declarado el 2026-10-12.
- PRY-200: Amarillo; en silencio 24 días; 2 hitos cumplidos sin evidencia.
- PRY-201: Verde contradicho por 2 señales (silencio e hito sin evidencia).
- PRY-202: Amarillo; 3 de 4 hitos cumplidos sin evidencia; fecha de fin 2026-04-25 ya pasada con 43 % de avance declarado.
- PRY-204: Verde contradicho por un compromiso vencido.
- PRY-206: Rojo declarado; un hito sin evidencia.
- PRY-207: Rojo declarado; fecha de fin 2026-02-23 ya pasada; 3 hitos sin evidencia.
- Verde contradicho por la evidencia: 5 proyectos (201, 204, 208, 209, 210).

## Anexo
**Cifras del portafolio** (de `compute`): 13 proyectos, 12 con alertas, 60 alertas, 8 productos, 0 sin línea base, 13 sin autoridad.

**Vacíos de información:**
- Autoridad del gerente y fase: faltan en las 13 fichas.
- Ninguna ficha tiene fuente de tipo «evidencia»: 0 evidencias frente a 2 declaraciones por proyecto. «Hito cumplido sin evidencia» es la señal más repetida del portafolio. Hay actas de recibo en las carpetas de PRY-202, 204, 206, 207 y 209, fechadas entre 2026-10-06 y 2026-10-12, que las fichas no citan. No las abrí en esta corrida; conviene releerlas antes del comité.
- Campos vencidos por antigüedad (más de 12 meses): PRY-200, 202, 203, 205, 207, 208, 210 y 211, en los campos de identidad y plan tomados del acta de constitución.
- Compromiso sin fecha: PRY-205 (Gustavo Neira, punto 24) y PRY-208 (Laura Vélez, ajuste de presupuesto).
- Riesgo sin doliente: PRY-208, dos riesgos.
- Dependencias entre proyectos: ninguna declarada con código de proyecto. Varios proyectos citan la «dependencia del proveedor del core cooperativo» (PRY-205, 208, 209) y PRY-202 es el Core cooperativo. No se puede decir si es la misma dependencia sin que alguien la confirme.
- Contradicciones de documentos registradas (`conflicts`): ninguna.

**Dato que no pude calcular:** el monto de autoridad sugerido en [1] y el costo total de los cambios pendientes, porque `compute` no los entrega. No los calculé a mano.

---
*Criterio Portfolio — steering-pack · términos 1.0 (TERMS.md) · fichas aplicadas: 13 (PRY-199 a PRY-211), corte 2026-10-14 · campos inciertos: autoridad (13), evidencia de hitos, antigüedad de identidad y plan · no se leyeron los documentos originales en esta corrida.*
