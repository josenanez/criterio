## Producto «crédito de libranza» al 2026-10-14

*Sale de las fichas de estado (`estado/records`, 13 proyectos) y del cálculo `portafolio.py compute` del 2026-10-14. Términos aceptados (v1.0, José Francisco Ñáñez, 2026-10-14).*

**Este producto tiene un solo proyecto declarado: PRY-200.** La vista por producto no suma nada sobre la vista de proyecto, así que no armo sección comparativa; abajo va lo que sí hay.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| crédito de libranza | 1 (PRY-200) | 1 de 1 (4 alertas) | 2026-11-17 | COP 18.000.000.000 | COP 9.671.355.133 |

**Proyectos:** PRY-200 Crédito de libranza digital.

**Lo que hay que ver (PRY-200):**
- **En silencio:** 24 días sin documento nuevo (último: informe de avance del 2026-09-20; umbral 15).
- **Avance declarado frente al plan:** declara 53,0 %; el plan sustenta entre 67 % y 100 % (2 de 3 hitos cumplidos). Diferencia: 14,0 puntos, por detrás.
- **Hito «Diseño funcional aprobado»** (vence 2026-02-12, 244 días): declarado cumplido, sin evidencia.
- **Hito «Ambiente de pruebas certificado»** (vence 2026-07-01, 105 días): declarado cumplido, sin evidencia.
- **Estado declarado:** Amarillo. No recoge ninguna de las tres señales anteriores.
- Fuentes: 0 datos con evidencia, 2 declaraciones, 25 sin marcar. Los campos de identidad y plan vienen de un documento del 2025-09-17 (13 meses; umbral 12).

**Dinero (1 de 1 proyectos trae las cuatro cifras):** aprobado 18.000.000.000; comprometido 9.671.355.133 (53,7 %); ejecutado 9.866.479.229 (54,8 %); proyección 18.642.360.710, es decir 3,6 % sobre lo aprobado; disponible real 8.328.644.867 (COP). Nota: lo ejecutado supera lo comprometido; la ficha no explica por qué, y no lo resuelvo yo.

**Dependencias internas:** ninguna declarada (el cálculo no devuelve dependencias para ningún proyecto del portafolio). No puedo decir que no existan, solo que nadie las escribió.

**Fecha comprometida del producto:** 2026-11-17, de PRY-200. Sin replanificaciones (0) y sin atraso contra la línea base (0 días); la fecha no se ha movido, pero tampoco está sustentada por evidencia de hitos.

### Proyectos sin producto declarado (5 de 13)
| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | Tesorería |
| PRY-205 Prevención de lavado de activos | Ahorro y aportes |
| PRY-208 Motor de crédito | Cartera y cobranza |
| PRY-209 Convenios de libranza con empresas | Bienestar social |
| PRY-210 Corresponsales rurales | Ahorro y aportes |

Consecuencia: nadie puede responder por el conjunto al que sirven. **Ojo con PRY-209:** por el nombre toca la libranza, pero su ficha no declara producto; no lo asigno a «crédito de libranza» por parecido. Si pertenece, el producto tendría dos proyectos de dos áreas distintas, y sus cifras y fecha cambiarían. Pregunta para el dueño del producto: ¿PRY-209 (y quizá PRY-208) sirven a la libranza?

**Pie de rigor:** cifras copiadas de la salida de `compute` del 2026-10-14. No sé si el avance real de PRY-200 es el declarado: ningún hito tiene evidencia en la ficha. Sin dependencias, sin autoridad declarada (`identity.authority` falta) y sin fase declarada.
