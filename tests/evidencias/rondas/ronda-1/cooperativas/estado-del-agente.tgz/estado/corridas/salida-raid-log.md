## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-14

**De qué documentos sale:** las 13 fichas en `estado/records/` (sección RAID, tal como la dejó el último barrido), los informes de avance de cada proyecto, las actas de constitución (dependencias declaradas), las minutas de comité y las notas de reunión de PRY-208 del 2026-10-14. Términos: v1.0 aceptados por José Francisco Ñáñez, 2026-10-14 (consta en la configuración).

Registrado: 20 riesgos · 0 supuestos · 24 incidencias · 0 dependencias (44 ítems).
**Tras reclasificar:** 8 riesgos · 0 supuestos · 18 incidencias · 12 dependencias · 6 ítems que no son RAID.
44 sin doliente (todos) · 44 sin fecha (todos) · sin movimiento: no se puede medir (ver Límites) · 1 no registrado formalmente.

Escala de valoración: la organización no define una; se usaría alta/media/baja. Ningún ítem trae probabilidad ni impacto, y no los inventé: van "sin valorar".

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| D1 (PRY-202, 205, 206, 207, 208, 209, 211) | Dependencia (estaba como riesgo) | «Dependencia del proveedor del core cooperativo» | Sin doliente | Informes del 2026-09-27 al 2026-10-12 | Afecta a 7 proyectos a la vez; el doliente está fuera de cada proyecto; ninguna acta declara la dependencia ni a qué proyecto apunta. Si el core es PRY-202 (inferencia mía, no hay documento que lo diga): su línea base vence el 2026-04-25, hace 172 días, sin replanificación aprobada, con 43 % declarado y Amarillo. |
| D2 (PRY-202, 204, 208, 211) | Dependencia (estaba como riesgo) | «Aprobación del reglamento por el Consejo de Administración» | Sin doliente | 2026-09-27 al 2026-10-12 | Un mismo órgano externo frena a 4 proyectos. En PRY-200, 202 y 209 el Consejo ya pidió ajustar el reglamento antes del piloto: ahí ya ocurrió. |
| D3 (PRY-201, 205, 209, 210, 211) | Incidencia | «Hallazgo de seguridad levantado en la revisión de arquitectura» | Sin doliente | 2026-09-20 al 2026-10-10 | Ya pasó, está abierta en 5 proyectos y ningún documento muestra resolución, doliente ni fecha. |
| D4 (PRY-208) | Riesgo no registrado | El proveedor podría no llegar con el equipo completo para la siguiente fase | Sin doliente | 2026-10-14 | Doliente fuera del proyecto, sin mitigación, y PRY-208 acaba de ampliar su línea base a 2027-01-12. |

Decisión que habría que formular para cada una (propongo, no asigno): D1, quién en la PMO es doliente de la relación con el proveedor del core y se confirma o no que es PRY-202; D2, quién ante el Consejo y para qué fecha se pide el pronunciamiento; D3, quién cierra cada hallazgo y con qué fecha; D4, si se formaliza y quién lo gestiona.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Riesgo (a confirmar con quién es el proveedor: no lo dice la nota) | PRY-208, notas de reunión (`2026-10-14-notas-reunion.txt`) | 2026-10-14 |

Es el único. Las otras 9 minutas de comité (PRY-199, 202, 203, 204, 205, 207, 208 del 11/10, 209, 210) solo traen «Avance» y «Compromisos»: no dicen nada que sea riesgo, y no inventé ninguno. Los otros tres puntos de la nota del 14/10 (compromiso de Paula Céspedes para el 28/10, ajuste de presupuesto de Laura Vélez, revisión con el proveedor el 24/10) son compromisos, no RAID. Ese riesgo ya aparece en la ficha de PRY-208 con el doliente en «no encontrado», pero no está en su informe de avance del 11/10.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 44 ítems (ver registro completo) | Todos | Todos | Doliente y fecha. Ninguno de los 13 proyectos los trae. Se reporta como hallazgo; no se rellenó. Tampoco hay mitigación, probabilidad ni impacto. |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| D1 en 7 proyectos | «Proveedor del core cooperativo»; sin código de proyecto | No (declarada, no acordada) | Las actas de PRY-201, 202, 208 y 209 dicen «Ninguna declarada»; la dependencia solo aparece como riesgo en los informes. Si apunta a PRY-202, esa fecha está vencida (arriba). No puedo afirmarlo. |
| PRY-209 | Proveedor de la última entrega, sin nombre ni código | No | Informe del 2026-10-04: «el proveedor no ha confirmado la fecha de la última entrega». PRY-209 replanificó el 2026-10-04 a 2026-12-30 (antes 2026-09-07). |
| D2 en 4 proyectos | Consejo de Administración (no es proyecto) | No | Ver D2. |

### Reclasificados, y por qué
- **Riesgo → dependencia (12):** «Dependencia del proveedor del core» (7), «Aprobación del reglamento por el Consejo» (4), «El proveedor no ha confirmado la fecha» (PRY-209). Dependen de alguien fuera del proyecto.
- **Incidencia → no es RAID (6):** «Se ajustó el plan de pruebas con seguridad» (PRY-201, 203) y «Se recibió el concepto pendiente del ente supervisor» (PRY-203, 210) son novedades del periodo, no problemas; «El proveedor entregó el componente de integración, pendiente de aceptación» (PRY-202, 204) es un entregable por aceptar: va a vendor-tracking, no a incidencias.
- **Se quedan como incidencia:** «Se reprogramó la salida por el cierre contable» (PRY-200, 201, 206, 210; ya pasó y mueve fecha), «El equipo perdió dos semanas por rotación» (6 proyectos), hallazgo de seguridad (5), Consejo pidió ajustar el reglamento (3).

### Registro completo
Id = proyectos donde aparece el ítem. Prob./Impacto: sin valorar en todos. Doliente: sin doliente en todos. Fecha: sin fecha en todos. «Fuente» es el informe más reciente de cada proyecto.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199, 200, 203, 205, 210 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | — | — | — | — | Informes 2026-09-20 a 2026-10-12 |
| PRY-201, 210 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-09-20 / 2026-10-10 |
| PRY-208 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | no encontrado | — | 2026-10-14 |
| PRY-202, 205, 206, 207, 208, 209, 211 | Dependencia (reclasificada) | Proveedor del core cooperativo | — | — | — | — | 2026-09-27 a 2026-10-12 |
| PRY-202, 204, 208, 211 | Dependencia (reclasificada) | Aprobación del reglamento por el Consejo | — | — | — | — | 2026-09-27 a 2026-10-12 |
| PRY-209 | Dependencia (reclasificada) | Proveedor sin fecha confirmada de la última entrega | — | — | — | — | 2026-10-04 |
| PRY-199, 202, 204, 205, 207, 208 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | n/a | — | — | — | 2026-10-02 a 2026-10-12 |
| PRY-201, 205, 209, 210, 211 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | n/a | — | — | — | 2026-09-20 a 2026-10-10 |
| PRY-200, 201, 206, 210 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | n/a | — | — | — | 2026-09-20 a 2026-10-10 |
| PRY-200, 202, 209 | Incidencia | El Consejo pidió ajustar el reglamento antes del piloto | n/a | — | — | — | 2026-09-20 a 2026-10-12 |
| PRY-201, 202, 203, 204, 210 (6 ítems) | No es RAID | Ajuste del plan de pruebas; concepto del supervisor recibido; componente del proveedor pendiente de aceptación | — | — | — | — | — |

### Límites de lo que dije
- **Sin movimiento en dos períodos:** no lo puedo medir. Solo hay una fotografía del estado y una fecha por ítem; no hay historial de movimiento.
- **Texto idéntico entre proyectos:** frases como «El equipo perdió dos semanas…» se repiten palabra por palabra en 6 proyectos. No sé si cada proyecto de verdad lo vive o si el texto se copió entre informes; conviene confirmarlo con cada gerente.
- **Quién es el «proveedor del core»:** ningún documento lo nombra ni lo vincula a un código de proyecto.
- No revisé mitigaciones vencidas: ningún ítem tiene mitigación registrada.

### Después
¿Subo a comité del 2026-10-21 D1 a D4? Y ¿propongo doliente para los 44 ítems? Propongo, no asigno: lo decide el gerente de cada proyecto.

*Pie de rigor: citas a nivel de documento, no de línea; las cifras salen de las fichas y los informes, no de una medición mía. Las dos inferencias marcadas (core = PRY-202; riesgo de PRY-208 ligado a un proveedor concreto) no están sustentadas en un documento.*
