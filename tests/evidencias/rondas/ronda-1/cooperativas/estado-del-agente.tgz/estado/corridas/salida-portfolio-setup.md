## Listo — Cooperativas (prueba)

**Miré:** 72 documentos en 13 proyectos · formatos: .md 27, .docx 14, .pdf 11, .xlsx 10, .csv 8, .json 1, .txt 1 · más reciente: 2026-10-14
**Eres:** PMO del portafolio (hay varios proyectos; tomé la respuesta sugerida)
**Te aviso:** dos días antes del comité del 2026-10-21 (los archivos se llaman «comité semanal», así que asumí comité semanal; la fecha del próximo es una suposición mía, dime la real y la cambio)
**En:** página (la forma de la plantilla de configuración; la sugerida era presentación, y es lo que se cambia si lo pides)
**Términos:** aceptados por José Francisco Ñáñez para esta prueba, 2026-10-14 (TERMS.md).
**Guardado en:** configuración en `.criterio/portafolio/config.json`, lo que voy encontrando en `estado/`, informes en `reportes/`.

### Probé con tres proyectos

Los tres con la documentación más reciente: PRY-208, PRY-205 y PRY-209. Fichas en `estado/records/`, selladas.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-208 Motor de crédito | 8 | Patrocinador Andrés Lozano, gerente Liliana Torres, presupuesto 2.400 M COP y cierre 2026-11-29 (acta 2025-10-24). Declara Verde con 81% (informe 2026-10-11). Cuatro compromisos de las notas del 2026-10-14. | Autoridad del gerente, fase, actas de recibo de los dos hitos cerrados, dueño del riesgo del proveedor, fecha del ajuste de presupuesto. Sin proveedor/contrato en la carpeta. |
| PRY-205 Prevención de lavado de activos | 7 | Mismo patrocinador y gerente que PRY-208; presupuesto 2.400 M COP. Declara Amarillo con 67% (informe 2026-10-02). Dos solicitudes de cambio: CC-01 autorizada (+41 días, 82 M) y CC-02 pendiente (+71 días, 142 M). | Autoridad, fase, actas de recibo de tres de sus cuatro hitos, acta del comité que autorizó CC-01, fecha del compromiso «punto 24». |
| PRY-209 Convenios de libranza con empresas | 8 | Patrocinadora Paula Céspedes, gerente Carlos Peña, presupuesto 6.800 M COP. Declara Verde con 40% (informe 2026-10-04). CC-01 autorizada (+114 días, 228 M). Actas de recibo del piloto y del ambiente de pruebas. | Autoridad, fase, actas de recibo del diseño funcional y de la integración con el core, acta del comité que autorizó CC-01. |

### Hallazgos (solo lo que levantó el cálculo)

**PRY-208 — declara Verde, y el cálculo levantó 4 señales que ese verde no explica**
- Plazo: 100 días de atraso contra la línea base original (29,9%), y ningún cambio aprobado lo respalda (CC-01 sigue pendiente de presentarse al comité). Es `rebaseline_unauthorized`: 100 días movidos, 0 autorizados.
- Costo: la proyección al cierre es 2.786,9 M COP contra 2.400 M aprobados (+16,1%).
- Dos hitos declarados cerrados (diseño funcional, ambiente de pruebas) sin un acta que lo pruebe, de hace 234 y 122 días.
- Un compromiso sin fecha: Laura Vélez, ajuste del presupuesto («la otra semana»).

**PRY-205 — declara Amarillo, 10 señales**
- Plazo: 112 días de atraso contra la original (34,6%). Solo 41 están autorizados; el cálculo deja 71 sin autorizar (`rebaseline_unauthorized`). Además, CC-01 está autorizada pero no hay línea base nueva que la recoja (`change_without_baseline`).
- Avance: el cronograma da los 4 hitos por cerrados y el informe declara 67%, 33 puntos por debajo de lo que el plan sostiene.
- Tres hitos cerrados sin acta (hace 355, 274 y 193 días).
- Presupuesto: 91,1% comprometido, quedan 213,3 M COP disponibles.
- Compromiso vencido: Óscar Ramírez, «punto 15», para el 2026-09-29 (15 días). Y uno sin fecha: Gustavo Neira, «punto 24» («por definir»).

**PRY-209 — declara Verde, 3 señales sin explicar**
- Plazo: 114 días de atraso contra la original (60%), autorizados por CC-01; pero la línea base no se actualizó (`change_without_baseline`).
- Avance: 4 de 4 hitos cerrados y 40% declarado, 60 puntos por debajo de lo que el plan sostiene.
- Dos hitos cerrados sin acta (diseño funcional, hace 180 días; integración con el core, hace 85).

**Entre los tres:** 23 señales; 2 proyectos en verde contradichos por la evidencia (PRY-208 y PRY-209).
No hay contradicciones entre documentos ni cambios de gobierno; la ficha del gerente de PRY-208 (`ficha-pm.json`) no discrepa de la lectura de la PMO.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-204, PRY-206, PRY-207, PRY-210 y PRY-211), unos 57 documentos, en dos lotes uno tras otro en esta misma conversación. Tres proyectos de ocho documentos cada uno es lo que acabo de hacer, así que son unas tres veces y media esto; no medí el tiempo exacto, así que lo digo como orden de magnitud.

### Lo que le falta a tu carpeta
- **Actas de recibo:** casi ningún hito cerrado tiene su acta (hay solo dos en todo lo que leí). Es lo que más señales produce.
- **Actas de comité de las autorizaciones:** CC-01 de PRY-205 y de PRY-209 dicen «autorizada por el comité», sin decir cuál ni dejar el acta.
- **Autoridad del gerente y fase:** ninguna acta declara hasta qué monto decide el gerente sin subir a comité.
- **Línea base:** los cambios aprobados no dejan una línea base nueva firmada.
- **Compromisos sin fecha o con fecha relativa** («la otra semana», «por definir»).
- **Riesgos dichos en reunión sin registrar** (el equipo incompleto del proveedor en PRY-208).
Ninguno es bloqueante.

### Cómo corrió
Preguntas hechas: 0 (sesión de prueba sin interfaz; tomé las respuestas sugeridas y las dije arriba). Minutos hasta el primer resultado: no los medí.

### Después
¿Corro el portafolio completo? Como PMO con equipo, también puedo publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios (no hay carpeta compartida configurada; no la inventé).
