# Corrida del 2026-10-14 · status-report

13 proyectos · 32 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Informe de PRY-211: amarillo 59% declarado sin ningún sustento documental; 5 hitos cumplidos sin evidencia, 41 puntos de brecha de avance, 17 días de silencio, 2 entregables del proveedor aceptados sin acta. Dije que no sé: autoridad, fase, última reunión, estado y dueño de los RAID.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Informe construido desde la ficha `estado/records/PRY-211.json` (actualizada el 2026-10-14) y recalculado con `compute` el 2026-10-14.

## PRY-211 Cobranza digital — estado al 2026-10-14

**Declara el gerente (Carlos Peña):** Amarillo · 59% · al 2026-09-27 (hace 17 días; la declaración no está vencida)
**Sustento documental:** sin sustento. La ficha no marca ninguna fuente como evidencia (`evidence: 0`, `declaration: 2`, `unmarked: 33`). Los cinco hitos figuran como cumplidos sin un solo documento que lo pruebe.
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `progress_vs_plan`, `silent`, `vendor_deliverable_late`
**Último documento:** 2026-09-27 (17 días de silencio; el umbral es 15) · **Última reunión:** sin dato

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-06-17 | 2026-06-17 | 0 días contra la original y contra la vigente |
| Presupuesto aprobado | COP 9.500.000.000 | COP 9.500.000.000 | proyección COP 9.109.449.352 (-4,1% sobre lo aprobado) |

Replanificaciones: 0. No hay solicitudes de cambio registradas.

Dinero (COP): comprometido 4.785.540.413 (50,4%), ejecutado 3.853.542.458 (40,6%), disponible real 4.714.459.587.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-12-21 | 2025-12-21 | cumplido (según el cronograma v1) | sin evidencia (297 días desde su fecha) |
| Ambiente de pruebas certificado | 2026-02-04 | 2026-02-04 | cumplido (según el cronograma v1) | sin evidencia (252 días) |
| Integración con el core cooperativo | 2026-03-20 | 2026-03-20 | cumplido (según el cronograma v1) | sin evidencia (208 días) |
| Piloto con asociados | 2026-05-04 | 2026-05-04 | cumplido (según el cronograma v1) | sin evidencia (163 días) |
| Salida a producción | 2026-06-17 | 2026-06-17 | cumplido (según el cronograma v1) | sin evidencia (119 días) |

### Dónde no coincide
- **Avance:** el gerente declara 59% (informe de avance, 2026-09-27); con 5 de 5 hitos cumplidos, el plan sostiene 100%. Diferencia de 41 puntos, en la dirección de «atrás».
- **Estado de los hitos:** la única fuente del estado «cumplido» es el cronograma v1 del 2025-10-28, un documento anterior a todas las fechas de los hitos. No puede probar que se cumplieron. Si «Salida a producción» se cumplió, un 59% de avance y un amarillo no concuerdan; si no se cumplió, el estado de los hitos está mal. Los documentos no permiten decidir cuál.
- **Proveedor (Soluciones Solidarias, CT-509):** el contrato suma 4 entregables; 3 figuran aceptados. Solo la «Bolsa de horas de desarrollo» tiene acta de recibo (2026-02-23). «Licenciamiento del módulo» y «Parametrización de líneas de crédito» figuran aceptados sin evidencia. Facturado: COP 2.179.464.246, igual al monto aceptado declarado.
- **Entregable atrasado:** «Mesa de ayuda del primer trimestre», vencía el 2026-05-22, sigue pendiente (145 días).

### Abierto
**Riesgos e incidencias sin movimiento:** hay 2 riesgos (dependencia del proveedor del core cooperativo; aprobación del reglamento por el Consejo de Administración) y 1 incidencia (hallazgo de seguridad de la revisión de arquitectura), todos del informe del 2026-09-27. La ficha no trae estado, dueño ni fecha de cada uno, y el cálculo no da días sin movimiento. No puedo decir cuánto llevan quietos.
**Compromisos vencidos:** ninguno registrado. La ficha no tiene compromisos y no hay reunión registrada, así que esto es ausencia de dato, no ausencia de incumplimientos.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad del proyecto (`identity.authority`) y fase (`identity.phase`).
- Evidencia de los 5 hitos.
- Evidencia de aceptación de 2 entregables del proveedor.
- Última reunión.
- Estado, dueño y fecha de los riesgos e incidencias.
- Campos con más de 12 meses de antigüedad (todos de la identidad, el plan y el alcance, fechados el 2025-10-28).

### Qué sigue
El silencio supera el umbral, el avance declarado está 41 puntos por debajo de lo que sostiene el plan y hay 2 entregables aceptados sin acta. Puedo preparar el punto de comité. No hay desviación de fecha ni de presupuesto contra la línea base, así que no corresponde una solicitud de cambio.

---
criterio-portfolio 0.3.6 · ficha PRY-211 actualizada el 2026-10-14 · campos inciertos: los listados en «Sin dato» · términos v1.0 aceptados el 2026-10-14 por José Francisco Ñáñez (`/home/claude/banco/criterio/TERMS.md`)
