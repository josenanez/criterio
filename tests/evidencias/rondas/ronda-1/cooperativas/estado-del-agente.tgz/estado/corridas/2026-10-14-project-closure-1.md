# Corrida del 2026-10-14 · project-closure

13 proyectos · 42 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Cierre de PRY-202 por decisión, no por cumplimiento: criterio de éxito no determinable, 3 hitos sin evidencia, contradicción de fecha de cierre entre acta (2026-05-21) y cronograma (2026-04-25). No archivado.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha `estado/records/PRY-202.json`, salida de `compute` del 2026-10-14, y los cinco documentos de `PRY-202-core-cooperativo/`: acta de constitución (2025-09-22), cronograma v1 (2025-09-22), acta de recibo del diseño funcional (2026-10-07), comité semanal (2026-10-08) e informe de avance (2026-10-12). Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14.

## Cierre — PRY-202 Core cooperativo — 2026-10-14

**Antes del acta: este proyecto no está terminado según sus propios documentos.** El informe del 2026-10-12 lo declara en Amarillo, con 43 % de avance, con el componente de integración entregado «pendiente de aceptación» y el piloto detenido a la espera de un ajuste del reglamento. Lo que sigue es un cierre *por decisión* si alguien lo toma así; no es un cierre por cumplimiento. No se archiva nada hasta que alguien con autoridad lo declare.

### Contra lo comprometido
**Criterio de éxito:** «Core cooperativo en producción y medido» (acta de constitución, 2025-09-22).
**Se cumplió:** no se puede determinar; lo documentado indica que no. Ningún documento muestra producción ni medición, y el piloto —previo a producción— no tiene evidencia de haberse hecho.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (línea base 2025-11-22) | Cumplido | Acta de recibo del 2026-10-07, firmada por Mauricio Pérez |
| Ambiente de pruebas certificado (2026-01-12) | Marcado «cerrado» en el cronograma; sin evidencia | Ninguna. Días desde el vencimiento: 275 |
| Integración con el core cooperativo (2026-03-05) | Marcado «cerrado» en el cronograma; el informe dice «pendiente de aceptación» | Ninguna de recibo. Días: 223 |
| Piloto con asociados (2026-04-25) | Marcado «cerrado» en el cronograma; el informe dice que el reglamento debe ajustarse *antes* del piloto | Ninguna. Días: 172 |
| Componentes 1, 2 y 3 (alcance del acta) | No se puede determinar | El acta no los describe, y ningún documento los cruza con los hitos |

Avance declarado 43 % frente a un plan que, con los 4 hitos marcados como cumplidos, respalda 100 %: brecha de 57,0 puntos. Alerta `progress_vs_plan`, sentido «atrasado». Los tres hitos marcados cumplidos sin evidencia son la alerta `milestone_met_without_evidence`.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre» (acta; sin detallar cuál proyecto) | Acta de constitución | 2025-09-22 |

No hay ningún recorte de alcance posterior registrado: la ficha tiene 0 solicitudes de cambio.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-04-25 (cronograma v1) | 2026-04-25 | Sin cierre real | 0 días |
| Presupuesto (COP) | 3.300.000.000 | 3.300.000.000 | Proyección 3.353.645.589 | +1,6 % sobre lo aprobado (proyección, no cierre) |

- Ejecutado: 934.996.135 COP (28,3 % del aprobado). Comprometido: 2.516.300.758 COP (76,3 %). Disponible real: 783.699.242 COP. Todo del informe del 2026-10-12, sin respaldo contable en la carpeta.
- Replanificaciones: 0. Cambios aprobados: 0. La desviación en fecha es 0 porque nunca se movió la línea base, no porque se haya cumplido: la fecha ya pasó.
- **Contradicción sin resolver:** el acta fija el cierre en 2026-05-21; el cronograma v1, con la misma fecha de aprobación, lo fija en 2026-04-25. La ficha usa la del cronograma. Hay que decidir cuál es la original antes de dar por buena la desviación.

### RAID al cierre
- **Materializados:** la rotación de un desarrollador clave, que costó dos semanas (informe 2026-10-12; sin fecha del hecho). El ajuste del reglamento pedido por el Consejo de Administración es una incidencia abierta.
- **No materializados:** ninguno se puede afirmar. «Dependencia del proveedor del core» y «Aprobación del reglamento por el Consejo» siguen listados como abiertos en el informe.
- **Abiertos, con doliente:**
  - Aceptación del componente de integración: sin doliente nombrado.
  - Ajuste y aprobación del reglamento: sin doliente nombrado; el Consejo de Administración es una instancia, no una persona.
  - «Entregar el punto 35»: Jorge Medina, para 2026-11-08, abierto. El comité no dice a qué corresponde el «punto 35».
  - Dependencia del proveedor: sin doliente. La ficha no registra proveedor ni contrato.

  Sin doliente con nombre, estos puntos no están cerrados.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 trae los cuatro hitos como «cerrado» con fecha de documento 2025-09-22, es decir, antes de que ocurrieran | 2025-09-22 | Tres hitos «cumplidos» sin evidencia, hasta 275 días después de su fecha; el estado del plan no sirve para medir | Un hito se marca cumplido solo con acta de recibo. Esta regla es una propuesta a partir del hecho; no la pactó nadie |
| El acta de recibo del diseño funcional (hito de 2025-11-22) se firmó el 2026-10-07 | 2026-10-07 | El acta quedó firmada después de la fecha del hito (el intervalo exacto no lo da `compute`, no lo calculo); nadie registró un cambio | Registrar el cambio de fecha cuando ocurre |
| Rotación de un desarrollador clave | Sin fecha en el informe | Dos semanas perdidas (informe 2026-10-12); no hay hito ni fecha a la que se pueda atar el efecto | No se puede sustentar más |

No entran otras lecciones: no hay documento que ancle un hecho, una fecha y un efecto.

### Sin dato
- Evidencia de ambiente de pruebas certificado, integración y piloto.
- Qué son los componentes 1, 2 y 3, y qué es el «punto 35».
- Cuál proyecto cubre lo que el acta deja fuera.
- Cuál es la fecha original de cierre (2026-04-25 o 2026-05-21).
- Proveedor y contrato (la ficha no registra ninguno), y cualquier dato contable que respalde las cifras del informe.
- Autoridad de aprobación y fase del proyecto (no figuran). El acta marca el producto como «No aplica».
- Quién declara el cierre, y si hay decisión de cerrarlo.

### Después
Se ofrece, no se hace: mover `PRY-202-core-cooperativo` a `archivo/` y congelar la ficha. Respuesta sugerida y tomada: no archivar, porque el proyecto sigue en ejecución según su último informe y saldría del barrido diario con tres hitos sin evidencia y cuatro puntos abiertos.

---
**Pie de rigor:** cada cifra de dinero, días y porcentaje sale de `compute` o de los documentos citados; la comparación del acta de constitución con el cronograma la hice yo leyendo ambos. Es lectura de documentos, no auditoría: ninguna cifra tiene respaldo contable en la carpeta.
