**Fuentes:** contrato `PRY-211-cobranza-digital/00-gobierno/2025-11-01-contrato-ct-509.docx`, acta de recibo `20-seguimiento/2026-02-23-acta-recibo-ct-509-bolsa-de-horas-de-desarrollo.pdf`, factura `20-seguimiento/2026-09-10-factura-ct-509.md`, ficha `estado/records/PRY-211.json` y `portafolio.py compute` al 2026-10-14. Términos aceptados por José Francisco Ñáñez (v1.0, 2026-10-14).

## Proveedores — PRY-211 Cobranza digital al 2026-10-14

### Soluciones Solidarias S.A.S. — contrato CT-509
**Vigencia:** firmado el 2025-11-01; fin de vigencia no declarado · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-12-26 | `accepted` (solo lo dice el contrato: "recibido") | **ninguna** | Sí, dentro de FV-1509 |
| Bolsa de horas de desarrollo | 2026-02-13 | `accepted` | Acta de recibo 2026-02-23, firmada por Carlos Peña (gerente del proyecto) | Sí, dentro de FV-1509 |
| Parametrización de líneas de crédito | 2026-04-03 | `accepted` (solo lo dice el contrato: "recibido") | **ninguna** | Sí, dentro de FV-1509 |
| Mesa de ayuda del primer trimestre | 2026-05-22 | `pending`, atrasado 145 días | ninguna | No |

Monto de cada entregable: 726.488.082 COP. Facturado según el script: 2.179.464.246 COP (FV-1509, 2026-09-10, radicada en cuentas por pagar). Entregables: 4; aceptados según el contrato: 3.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Condición de pago | Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto | Hay una sola acta (Bolsa de horas); la factura cubre tres entregables | Contrato CT-509; factura FV-1509; acta 2026-02-23 |
| Licenciamiento del módulo | "recibido" | Sin acta, correo ni minuta que lo pruebe | Contrato CT-509; carpeta sin documento |
| Parametrización de líneas de crédito | "recibido" | Sin acta, correo ni minuta que lo pruebe | Contrato CT-509; carpeta sin documento |

El estado "recibido" lo escribe el propio contrato, así que es declaración, no evidencia. El script marca `vendor_accepted_without_evidence` para esos dos entregables. Cuánto de lo facturado carece de acta: el script no da esa cifra y no la calculo a mano; cada entregable sin acta vale 726.488.082 COP según el contrato.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del módulo | accepted | Contrato 2025-11-01; compromiso 2025-12-26 |
| Parametrización de líneas de crédito | accepted | Contrato 2025-11-01; compromiso 2026-04-03 |

### Compromisos del proveedor vencidos
Ninguno detectado (`commitments_overdue` vacío). La carpeta no tiene minutas de comité con el proveedor, así que esto significa que no hay compromisos registrados, no que no existan.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-509: el contrato no los declara. No puedo decir si hay un preaviso por vencer.
- Minutas o correos con el proveedor: no están en la carpeta.
- Plan: los cinco hitos figuran como cumplidos sin evidencia (señal `milestone_met_without_evidence`), y el informe de avance del 2026-09-27 declara 59 % contra 100 % que sostiene el plan. Es contexto de proyecto, no de proveedor.

### Después
Hay entregables facturados sin evidencia de recibo (2 de los 3 de FV-1509) y uno atrasado sin facturar. Recomiendo llevar la factura FV-1509 a comité antes de pagarla. Próximo comité: 2026-10-21.
