# Corrida del 2026-10-14 · portfolio-report

13 proyectos · 72 documentos, 0 releídos y 72 sin cambio · 27 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

El informe quedó en `/home/claude/banco/ronda-1/cooperativas/espacio/reportes/index.html`.

5 verdes contradichos (PRY-201, 204, 208, 209, 210); abrir decisiones.html para el comité del 2026-10-21

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-14
Cargué 13 fichas (`estado/records/`, instantánea 2026-10-14). 13 proyectos · 12 con hallazgos · 60 señales · 5 en verde contradichos por la evidencia.

## Qué cambió desde la corrida anterior
Sin cambios desde la instantánea comparada (2026-10-14, misma fecha): 0 diferencias. No hay instantánea anterior distinta, así que esto es punto de partida, no delta.

## Contradicciones y verdes contradichos
| Proyecto | Declara | Qué lo contradice |
|---|---|---|
| PRY-201 Apertura de ahorro | Verde (2026-09-20) | silencio de 24 días; hito "Diseño funcional" cumplido sin evidencia |
| PRY-204 Tarjeta débito | Verde (2026-10-09) | compromiso de Gustavo Neira vencido hace 17 días |
| PRY-208 Motor de crédito | Verde (2026-10-11) | +100 días vs original, +16,1 % costo, replanificación no autorizada, hitos sin evidencia |
| PRY-209 Convenios de libranza | Verde (2026-10-04) | +114 días (60 %), avance 40 % con plan al 100 %, hitos sin evidencia |
| PRY-210 Corresponsales rurales | Verde (2026-10-10) | +69 días (15,5 %), compromiso vencido 11 días, hitos sin evidencia |

## Hitos cumplidos sin evidencia
Presente en 12 proyectos (PRY-200 a 211 salvo 204). Los más antiguos: PRY-205 "Diseño funcional" (355 días), PRY-207 "Ambiente de pruebas" (328), PRY-211 cinco hitos entre 119 y 297 días.

## Proyectos en silencio (umbral 15 días)
| Proyecto | Días | Desde |
|---|---|---|
| PRY-200 | 24 | 2026-09-20 |
| PRY-201 | 24 | 2026-09-20 |
| PRY-211 | 17 | 2026-09-27 |

## Desviación y línea base
| Proyecto | Vs original | Nota |
|---|---|---|
| PRY-205 | +112 días (34,6 %) | 71 días sin autorización; CC-01 sin línea base; comprometido 91,1 % |
| PRY-209 | +114 días (60 %) | CC-01 sin línea base |
| PRY-208 | +100 días (29,9 %); costo +16,1 % (proyección 2.786.927.469 vs 2.400.000.000 COP) | sin autorización |
| PRY-210 | +69 días (15,5 %) | |
| PRY-203 | +23 días | replanificación no autorizada |

## Avance declarado por encima de lo que el plan sustenta
PRY-209 (60 pts), PRY-202 (57), PRY-211 (41), PRY-205 (33), PRY-203 (33), PRY-207 (20), PRY-200 (14).

## Compromisos
Vencidos: PRY-204 Gustavo Neira (17 d), PRY-205 Óscar Ramírez (15 d), PRY-210 Beatriz Cuéllar (11 d). Sin fecha: PRY-205 Gustavo Neira, PRY-208 Laura Vélez.

## Proveedores
PRY-211 (Soluciones Solidarias S.A.S.): "Mesa de ayuda del primer trimestre" pendiente hace 145 días; dos entregables aceptados sin evidencia (Licenciamiento, Parametrización).

## Dependencias en riesgo
El script no devolvió dependencias entre proyectos con alerta. Vacío.

## Vacíos de información
Los 13 proyectos sin autoridad registrada. 5 proyectos sin producto asociado: PRY-202, 205, 208, 209, 210.

## Necesito que confirmes
Ninguna pregunta este mes: la confirmación mensual no se corrió en esta prueba sin interfaz.

## Dónde quedó
`/home/claude/banco/ronda-1/cooperativas/espacio/reportes/` — 25 páginas.
- `index.html`: vista por campo con cadena de evidencia completa, para quien va a actuar.
- `decisiones.html`: vista por decisión, para el patrocinador/comité (próximo 2026-10-21).
- Una página por proyecto. El PDF sale de imprimir el HTML.

Pie: Criterio Portfolio v0.1 · fichas del 2026-10-14 · campos inciertos: autoridad (13/13) y producto (5) · Términos v1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (`TERMS.md`).
