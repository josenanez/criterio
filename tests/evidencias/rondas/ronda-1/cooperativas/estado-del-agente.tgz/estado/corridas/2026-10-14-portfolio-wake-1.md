# Corrida del 2026-10-14 · portfolio-wake

13 proyectos · 20 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Barrido: 72 documentos, 0 cambios. 24 citas de PRY-208 sin resolver en el índice (los archivos existen; probable ruta relativa). Confirmación no corrida: sin interfaz para respuestas.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## 2026-10-14

**Revisé:** 72 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada. El barrido corrió y no había documentos nuevos, cambiados, renombrados ni borrados.

### Hallazgo del índice
En PRY-208 hay 24 campos de la ficha (identidad, compromisos, un riesgo) cuya fuente el índice no resuelve: `00-gobierno/2025-10-24-acta-constitucion.md`, `2026-10-14-notas-reunion.txt` y `30-reuniones/2026-10-11-comite-semanal.md`. Los tres archivos existen en la carpeta del proyecto; lo más probable es que la cita esté escrita relativa a esa carpeta y el índice la busque desde la raíz de documentos. No lo corregí ni toqué la ficha: queda abierto.

### Peticiones atendidas
No se consultaron (`requests` no tocaba hoy).

### Preguntas
Toca la confirmación periódica (nunca se ha corrido), pero la sesión es sin interfaz y nadie puede responder. No formulé las cinco preguntas ni la marqué como hecha; vuelve a tocar mañana.

**Vuelvo el 2026-10-15.**
