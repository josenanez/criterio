# Corrida del 2026-10-14 · change-control

13 proyectos · 26 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Solicitud incompleta: +30 días da 2026-07-17, ya vencida (hoy 2026-10-14; 119 días de atraso contra línea base v1). Sin autoridad en el acta, sin dependencias declaradas (impacto 0 por falta de declaración), sin motivo ni solicitante. No se creó línea base nueva. No se sabe: fecha real nueva, holgura, quién depende de PRY-211.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

**Sale de la ficha** `estado/records/PRY-211.json` (Cobranza digital, actualizada 2026-10-14). Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14.

## Solicitud de cambio — PRY-211 Cobranza digital — 2026-10-14

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta en ningún documento; el pedido llegó por esta sesión. · **Por qué:** no se dio motivo, y sin motivo no hay solicitud completa.

### Hallazgo previo: el cambio, tal como está pedido, no tiene sentido contra el calendario
- Línea base vigente (y única): v1, aprobada 2025-10-28, cierre y salida a producción **2026-06-17**.
- Con +30 días la salida quedaría el **2026-07-17**. Hoy es 2026-10-14: esa fecha **ya pasó hace 89 días**.
- El proyecto ya lleva **119 días de atraso** contra su única línea base (2026-06-17 → 2026-10-14) y sigue en ejecución: 59 % declarado, estado Amarillo (informe del 2026-09-27).
- Lo que se necesita no es "+30 días", sino una **fecha nueva** posterior a hoy con su sustento. Esa fecha no la puedo inventar; la tiene que dar el gerente (Carlos Peña).
- Además, el hito "Salida a producción" figura `met` en la ficha, pero la fuente es el cronograma v1 de 2025-10-28 (un plan, no una evidencia) y la evidencia del hito **no se encontró**. Los otros cuatro hitos están igual. Un proyecto al 59 % no puede haber salido a producción: ese `met` no se sostiene.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 (sin detalle en el acta) | Sin declarar | Ninguna declarada |
| Tiempo | Salida 2026-06-17 (vencida) | 2026-07-17 (también vencida) | +30 días declarados; real contra hoy: ≥ 119 días |
| Costo | Aprobado COP 9.500.000.000; comprometido 4.785.540.413; ejecutado 3.853.542.458; proyección 9.109.449.352 | Sin declarar | Ninguna declarada |

Quién absorbe lo no declarado: la solicitud solo declara tiempo. Mover 30 días con alcance y costo "sin cambio" significa que alguien absorbe 30 días más de equipo y de proveedor sin presupuesto. Atención al proveedor: CT-509 (Soluciones Solidarias) tiene la "Mesa de ayuda del primer trimestre" pendiente (vencía 2026-05-22), y ya se facturó COP 2.179.464.246 por tres entregables de los que solo uno tiene acta de recibo. Un corrimiento no resuelve eso; lo prolonga.

### Efecto en el portafolio
Cálculo `impact` (+30 días): **0 proyectos alcanzados**, 0 hitos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar.
**Esto no significa que nadie dependa de PRY-211.** La ficha tiene `dependencies: []`: no hay ninguna dependencia declarada, ni propia ni ajena. Un cero por falta de declaración no es un cero por inexistencia. Además, el riesgo registrado "Dependencia del proveedor del core cooperativo" sugiere dependencias reales que nadie anotó.
Lo que el cálculo tampoco dice: cuántos días se mueve cada afectado (la ficha no tiene holgura por actividad).

| Proyecto afectado | Cómo | Gerente |
| Ninguno declarado | — | Carlos Peña (de PRY-211) |

### Quién decide
**Autoridad requerida:** no determinable. · **Según:** el acta (2025-10-28) no declara autoridad de cambios (`identity.authority`: no encontrado). Comité nombrado: Comité de Crédito; patrocinador: Ricardo Salas. · **Va a comité:** sí, por defecto: sin autoridad declarada no hay base para decir que alguien por debajo del comité pueda aprobarlo, y el cambio mueve un hito vencido. Que el acta no diga quién aprueba cambios es el hallazgo de fondo.
Próximo comité configurado: 2026-10-21.

### Si no se aprueba
El proyecto sigue con una línea base (cierre 2026-06-17) ya vencida en 119 días, sin fecha vigente que lo describa, reportado en Amarillo. Se queda sin referencia contra la cual medir.

### Si se aprueba
Línea base 2 — cierre: **fecha por definir** (la propuesta de 2026-07-17 ya pasó, no se puede registrar) · presupuesto: sin cambio declarado (COP 9.500.000.000) · motivo: no declarado.
Desviación acumulada contra la línea base original: tiempo **≥ 119 días hoy** (más lo que añada la fecha nueva); costo: sin cambio declarado (proyección 9.109.449.352 contra 9.500.000.000 aprobados, −4,1 %, sin que la proyección incluya el corrimiento).
Contabilidad de cambios: `changes` está vacío; no hay cambio aprobado previo, así que ningún documento autoriza hoy los 119 días corridos. Esa diferencia es de por sí un hallazgo.

### Qué falta para completar la solicitud
1. Quién la pide y el motivo.
2. Fecha nueva real de salida a producción, posterior a hoy.
3. Impacto declarado en alcance y costo.
4. Quién tiene autoridad de aprobar cambios en el acta.
5. Dependencias de otros proyectos sobre PRY-211.

**Pie de rigor:** fuente única la ficha del 2026-10-14; no se releyeron los documentos originales. Las cifras salen de la ficha y del cálculo `impact`; los 119 y 89 días son diferencias de calendario. No se calculó efecto por holgura. Nada se aprobó ni se registró: no se creó línea base nueva.
