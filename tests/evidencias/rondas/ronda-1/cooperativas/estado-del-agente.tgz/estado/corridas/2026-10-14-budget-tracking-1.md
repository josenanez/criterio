# Corrida del 2026-10-14 · budget-tracking

13 proyectos · 30 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Presupuesto de PRY-205: cuatro cifras de una sola declaración (2026-10-02), comprometido 91,1 % sobre umbral, proyección anterior a CC-01. Dijo que no sabe: presupuesto vigente, si la proyección incluye CC-01/CC-02, detalle por proveedor, evidencia contable.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Informe construido desde la ficha `estado/records/PRY-205.json` (fuentes: informe de avance del 2026-10-02, cronograma v3 del 2026-10-02, solicitudes de cambio CC-01 del 2026-10-04 y CC-02 del 2026-10-14) y recalculado con `compute` el 2026-10-14. Términos v1.0 aceptados por José Francisco Ñáñez (2026-10-14).

## Presupuesto — PRY-205 Prevención de lavado de activos al 2026-10-14
**Moneda:** COP (única; no hay contratos en otra moneda)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | 100 % | informe de avance (declaración) | 2026-10-02 |
| Comprometido | 2.186.680.942 | 91,1 % | informe de avance (declaración) | 2026-10-02 |
| Ejecutado | 585.670.336 | 24,4 % | informe de avance (declaración) | 2026-10-02 |
| Proyección al cierre | 2.312.291.507 | no la da el script | informe de avance (declaración) | 2026-10-02 |

**Disponible real** (aprobado menos comprometido): 213.319.058 COP

Las cuatro cifras salen de una sola fuente, una declaración del gerente. Ningún documento de evidencia (factura, extracto, ejecución contable) las respalda.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 2.400.000.000 | no declarado | no calculable |

Replanificaciones de presupuesto: no hay línea base de presupuesto versionada. Lo que hay son dos solicitudes de cambio con costo:
- **CC-01** (2026-10-04): +82.000.000 COP, **aprobada** por «el comité», sin indicar cuál; ningún acta de comité de la carpeta la recoge. No se sabe si el aprobado de 2.400.000.000 ya la incluye.
- **CC-02** (2026-10-14): +142.000.000 COP, **pendiente**, sin decisor.

Para el tiempo, el script sí reporta una línea base: 112 días de atraso contra la original (34,6 %) y 0 contra la vigente. La v3 movió el cierre 112 días, y solo 41 están autorizados (CC-01): quedan 71 sin autorización y sin motivo declarado.

### Ejecución frente a avance
Ejecutado 24,4 % · Hitos cumplidos 4 de 4 · Avance declarado 67 %.
Los tres indicadores no cuadran entre sí. Con 4 de 4 hitos «cumplidos» el plan sostiene 100 %, pero el gerente declara 67 % (diferencia de 33 puntos) y solo se ha ejecutado 24,4 % del dinero. Ninguno de los 4 hitos tiene evidencia de cumplimiento. Con ejecución tan baja frente a un avance que dice estar completo, la lectura posible es trabajo hecho y no causado, que aparecería de golpe, o hitos marcados cumplidos sin estarlo. Los documentos no permiten decidir cuál.

### Alertas
- **Comprometido 91,1 %**, por encima del umbral de 90 %. Con 24,4 % ejecutado, el presupuesto está casi agotado y casi todo sin causar.
- **Proyección más vieja que el último movimiento de presupuesto.** La proyección es del 2026-10-02 y CC-01 (+82.000.000) se aprobó el 2026-10-04; la proyección puede no incluirla. CC-02 (+142.000.000), pendiente, tampoco puede estar en ella.
- **Ejecución desalineada del avance** (ver arriba).
- Cambio CC-01 aprobado sin nueva línea base y sin decisor identificado; replanificación no autorizada de 71 días.
- El estado declarado es Amarillo. Seis señales abiertas no están reconocidas en esa declaración, entre ellas el comprometido sobre el umbral.

### Sin dato
- Presupuesto vigente (con o sin CC-01) y presupuesto original versionado.
- Si la proyección incorpora CC-01.
- Ejecución y compromisos por proveedor: la ficha no tiene proveedores registrados (`vendors` vacío).
- Evidencia de las cifras (todas son declaración).
- Tasa de cambio: no aplica, una sola moneda.

## Siguiente paso
La proyección (2.312.291.507) no excede el aprobado según el script, así que no hay solicitud de cambio que preparar por esa vía. Sí conviene (a) pedir a la gerente, Liliana Torres, una proyección actualizada que incluya CC-01 y CC-02; (b) pedir el detalle de compromisos por proveedor, dado el 91,1 % comprometido; (c) llevar CC-02 a decisión con decisor identificado. Si quieres, preparo cualquiera de las tres.

---
**Pie de rigor:** cifras derivadas copiadas de `compute` al 2026-10-14. Toda cifra monetaria es declaración del informe del 2026-10-02; no hay evidencia contable en la carpeta. Lo que no se pudo calcular queda en «Sin dato».
