# Corrida del 2026-10-14 · health-check

13 proyectos · 64 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 26 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 5 |
| `variance_time` | 4 |
| `silent` | 3 |
| `rebaseline_unauthorized` | 3 |
| `commitment_overdue` | 3 |
| `commitment_undated` | 2 |
| `change_without_baseline` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `budget_committed` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |

Diagnóstico PRY-205 desde 7 documentos: 2 sostenidas, 6 sin sustento, 2 contradichas. Dijo que no sabe: autoridad, evidencia de hitos, motivo del v3, proyección con CC-01/CC-02.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-205 Prevención de lavado de activos · 2026-10-14

**Leí:** 7 documentos del proyecto · 2025-07-25 a 2026-10-14 · formatos: docx (2), pdf (1), xlsx (1), csv (1), md (2). Además busqué menciones de PRY-205 o «lavado» en los md, csv y docx de los otros 12 proyectos: no hay ninguna.
**No pude leer:** nada de la carpeta del proyecto. No revisé los pdf ni xlsx de los otros proyectos.
**Términos:** aceptados por José Francisco Ñáñez, v1.0, 2026-10-14 (prueba sin interfaz; consta en la configuración).

### Dictamen
**Sostenido:** 2 afirmaciones · **Sin sustento:** 6 · **Contradicho:** 2

La carpeta permite afirmar quién gobierna el proyecto y cuánto se aprobó. No permite afirmar que haya avanzado lo que se reporta. Ningún documento es evidencia de entrega: los 4 hitos figuran cerrados en el cronograma y ninguno tiene acta, certificado ni prueba. El informe de avance declara Amarillo y 67%, y el plan que lo acompaña dice que los 4 hitos están cerrados (100%). El cronograma v3, fechado 2026-10-02, ya incorpora 112 días de corrimiento. De esos 112 días, el comité autorizó 41 (CC-01) y 71 están pendientes de presentación (CC-02).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Andrés Lozano | acta-constitucion.docx (2025-07-25) |
| Gerente | Liliana Torres | acta-constitucion.docx |
| Autoridad declarada | No declarada en ningún documento | — |
| Comité | Comité de Tecnología. Aprobó 2.400.000.000 COP el 2025-07-25 | acta-constitucion.docx |

Sin autoridad declarada para el gerente no hay desviación aprobada: hay fechas que alguien escribió. El acta tiene 15 meses. Su alcance es genérico («Componente 1, 2, 3») y dice «Ninguna declarada» en dependencias. El informe de avance, en cambio, menciona la dependencia del proveedor del core cooperativo.

### Contra el plan
- **Línea base original (v1, 2025-07-25):** último hito, Piloto con asociados, 2026-06-24. El acta fija inicio 2025-08-04 y cierre 2026-08-04. El cronograma v1 no tiene hito de cierre ni de producción, aunque el criterio de éxito es «en producción y medido».
- **Vigente (v3, 2026-10-02):** fin 2026-10-14, sin motivo escrito. No hay v2 en la carpeta.
- **Desviación contra la original:** 112 días (34.6%), por encima del umbral de 10%. **Contra la vigente:** 0 días. Replanificaciones: 1.
- **Control de cambios:** CC-01 (2026-10-04, +41 días, +82.000.000 COP) dice «Autorizada por el comité», sin fecha, acta ni nombre de quien decide. CC-02 (2026-10-14, +71 días, +142.000.000 COP) está pendiente de presentación. Movimiento de línea base sin autorización: 71 días.
- **Orden de los hechos:** el v3 (2026-10-02) contiene los 112 días, pero CC-01 es del 2026-10-04 y CC-02 del 2026-10-14. La línea base se movió antes de que existieran las solicitudes que la justifican.
- **Hito movido:** el Piloto con asociados pasó de 2026-06-24 a 2026-10-14 y figura «cerrado» en un archivo fechado 2026-10-02, es decir, doce días antes de esa fecha.
- Las dos solicitudes dicen «Ampliación de alcance» sin decir qué alcance.

### Hitos vencidos sin evidencia
Los hitos están declarados como cumplidos. Ninguno tiene el documento que lo sostiene.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2025-10-24 | 355 | Acta de aprobación del diseño firmada |
| Ambiente de pruebas certificado | 2026-01-13 | 274 | Certificado o acta de pruebas |
| Integración con el core cooperativo | 2026-04-04 | 193 | Acta de integración y pruebas con el core |
| Piloto con asociados | 2026-10-14 | 0 | Informe del piloto y su aceptación |

### Dinero
COP, copiado del informe de avance (declaración del gerente, corte 2026-10-02) y recalculado por el script.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 2.186.680.942 (91.1%) | 585.670.336 (24.4%) | 2.312.291.507 (-3.7% sobre lo aprobado) | 213.319.058 |

Lo comprometido pasa el umbral de 90%. Ninguna cifra tiene un documento contable que la respalde. El informe no dice si la proyección incluye CC-01 (+82.000.000) ni CC-02 (+142.000.000). Por eso no calculo un total con ellas.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Óscar Ramírez, «Entregar el punto 15», para 2026-09-29, 15 días vencido (comité del 2026-10-10).
- **Compromiso sin fecha:** Gustavo Neira, «Entregar el punto 24», «por definir». Ninguno de los dos asistió a la reunión. Los «puntos» 15 y 24 no se explican en ningún documento.
- **Riesgos:** el informe declara «cambio normativo del supervisor que puede mover el alcance» y «dependencia del proveedor del core cooperativo». No hay registro RAID. La dependencia contradice «Ninguna declarada» del acta.
- **Incidencias:** un hallazgo de seguridad en la revisión de arquitectura y dos semanas perdidas por rotación de un desarrollador clave. Solo están en el informe, sin acción ni responsable.
- El acta del comité del 2026-10-10 trata «Avance» y «Compromisos». No menciona CC-01, el cronograma v3 ni los riesgos.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 67% | Informe de avance (2026-10-02): 67% | Cronograma v3 (2026-10-02): 4 de 4 hitos cerrados, que sostienen 100%. Brecha de 33 puntos |
| La línea base se movió con autorización | CC-01 autoriza 41 días y CC-02 está pendiente | Cronograma v3, fechado antes de ambas, ya mueve 112 días. Quedan 71 sin autorización |

### Sin sustento
1. **Estado Amarillo.** No dice con qué criterio. Seis señales del propio proyecto superan los umbrales y el informe no las recoge: desviación de 112 días, brecha de avance, hitos sin evidencia, compromiso vencido, línea base movida sin autorización y 91.1% comprometido.
2. **Cifras de dinero** (comprometido, ejecutado, proyección): sin documento contable.
3. **Los 4 hitos «cerrados»:** ninguno tiene evidencia.
4. **«Autorizada por el comité» en CC-01:** sin acta ni fecha. El comité del 2026-10-10 no la menciona.
5. **Riesgos abiertos:** sin registro, sin valoración y sin dueño.
6. **Hechos del periodo:** concepto recibido del ente supervisor, hallazgo de seguridad y rotación del desarrollador. Ningún documento los respalda.

**Sostenido:** presupuesto aprobado de 2.400.000.000 COP (acta). Patrocinador, gerente y comité con nombre (acta, y la reunión del 2026-10-10 los muestra presentes).

### Lo que esta carpeta no permite saber
- **Quién tiene autoridad para mover fechas y dinero.** Sin ella, ni CC-01 ni el v3 son una desviación aprobada.
- **Si algo se entregó.** Sin evidencia de hitos, no se puede decir que el proyecto vaya al 100%, al 67% ni a ningún otro porcentaje.
- **Cuándo se alcanza producción y medición,** que es el criterio de éxito. El plan no tiene ese hito.
- **Por qué cambió el cronograma.** El v3 no tiene motivo y falta el v2.
- **Cuánto cuesta terminar.** Sin la proyección con CC-01 y CC-02 no se sabe si el costo cabe en lo aprobado.
- **Qué son los puntos 15 y 24** ni de quién depende el cumplimiento.

### Siguiente paso
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las dos contradicciones a la gerente como preguntas, una por una.

---
**Pie de rigor:** análisis hecho solo sobre los 7 documentos citados. Las cifras derivadas vienen de `portafolio.py compute`. Lo declarado por el gerente y lo probado por documentos van separados. No sustituye el juicio de quien tiene la facultad de decidir.
