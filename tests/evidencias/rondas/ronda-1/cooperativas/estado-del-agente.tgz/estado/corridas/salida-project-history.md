## Historia · PRY-205 Prevención de lavado de activos · 2025-07-25 a 2026-10-14

**Leí:** 7 documentos entre 2025-07-25 y 2026-10-14 (acta de constitución, cronograma v1, cronograma v3, informe de avance, CC-01, CC-02, acta del comité semanal del 2026-10-10).
**Trimestres sin un solo documento:** Q4 2025, Q1 2026, Q2 2026 y Q3 2026. Hay documentos de Q3 2025 (2 del 2025-07-25) y de Q4 2026 (5, todos entre 2026-10-02 y 2026-10-14).

### En una línea
El proyecto arrancó el 2025-07-25 con cierre previsto el 2026-06-24 y, entre esa fecha y el 2026-10-02, la carpeta no guarda un solo documento. El 2026-10-02 aparecen de golpe el cronograma v3 (cierre al 2026-10-14, 112 días después del original) y un informe de avance en Amarillo con 67 %. De los 112 días, solo 41 tienen una solicitud de cambio aprobada (CC-01, del 2026-10-04); los otros 71 coinciden con CC-02, que sigue pendiente de comité.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 112 días (34.6 %) | No calculable: hay una sola declaración (2026-10-02) | 0 detectados (con un solo documento de gobierno no hay contra qué comparar) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-07-25 | Acta de constitución | Patrocinador Andrés Lozano, gerente Liliana Torres, Comité de Tecnología. Inicio 2025-08-04. |
| 2025-07-25 | Cronograma v1 (csv) | Línea base inicial: cierre 2026-06-24. Cuatro hitos, todos con estado «cerrado» en un archivo fechado ese mismo día. |
| 2026-10-02 | Cronograma v3 (xlsx) | Cierre 2026-10-14. «Piloto con asociados» pasa del 2026-06-24 al 2026-10-14. Los cuatro hitos figuran «met». No hay v2 en la carpeta. |
| 2026-10-02 | Informe de avance (pdf) | Declara Amarillo, 67 %. Aprobado 2.400.000.000 COP, comprometido 2.186.680.942, ejecutado 585.670.336, proyección 2.312.291.507. |
| 2026-10-04 | CC-01 | Ampliación de alcance, +41 días, +82.000.000 COP. «Autorizada por el comité», sin decir cuál. |
| 2026-10-10 | Acta del comité semanal | Dos compromisos: Óscar Ramírez (punto 15, vencido el 2026-09-29) y Gustavo Neira (punto 24, sin fecha). |
| 2026-10-14 | CC-02 | Ampliación de alcance, +71 días, +142.000.000 COP. «Pendiente de presentación al comité». |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-02 | 2026-10-14 (+112 días sobre el 2026-06-24) | No consta | Ninguno. El cronograma v3 se aprueba a sí mismo; no hay acta ni solicitud de cambio que lo respalde. |

- Autorizados con documento: 41 días (CC-01). Movidos: 112. Sin autorización documentada: 71 días.
- CC-01 está fechada el 2026-10-04, dos días después del v3. Su «+41 días sobre la línea base vigente» no queda reflejado en una línea base nueva: la señal `change_without_baseline` está abierta.
- CC-02 pide +71 días y está pendiente; el v3 del 2026-10-02 ya tiene la fecha de cierre que resulta de sumar 41 + 71. Eso es lo que muestran los documentos; por qué ocurre no consta.
- El informe de avance no menciona replanificación alguna; el desvío de tiempo no está entre sus señales declaradas.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente ni comité aparece en los documentos. | — |

Límites: solo hay un documento de gobierno (el acta de 2025-07-25), de modo que «sin cambios» significa «sin evidencia de cambios», no «confirmado que no hubo». Liliana Torres figura como solicitante en CC-01 y CC-02, coherente con el acta. No se encontró autoridad ni fase del proyecto. CC-01 dice que la autorizó «el comité» y ninguna acta de la carpeta lo recoge; CC-02 no tiene quien decida.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ningún compromiso aparece más de una vez | — | — |

Hay una sola acta de reunión, así que no se puede ver reprogramación. Lo que sí consta: Óscar Ramírez, «Entregar el punto 15», con fecha 2026-09-29, quedó escrito el 2026-10-10, once días después de vencer, y lleva 15 días vencido sin evidencia de entrega. Gustavo Neira, «Entregar el punto 24», no tiene fecha.

### Desde cuándo lo declarado no se sostiene
Con lo que hay, la fecha más antigua es el **2025-10-24**: «Diseño funcional aprobado» figura «met» y no tiene evidencia de cierre en ningún documento (355 días). Después vienen «Ambiente de pruebas certificado» (2026-01-13, 274 días) e «Integración con el core cooperativo» (2026-04-04, 193 días). «Piloto con asociados» (fecha vigente 2026-10-14) también está «met» sin evidencia.

Qué se siguió reportando: el 2026-10-02 se declara Amarillo, 67 %, con el plan marcando 4 de 4 hitos cumplidos (el plan sostendría 100 %). La declaración y el plan no coinciden entre sí, y ninguno de los dos tiene evidencia (fuentes de la ficha: 0 evidencia, 2 declaración, 46 sin marcar).

No puedo decir si fue un deslizamiento o un salto: la carpeta no tiene ninguna declaración de estado anterior al 2026-10-02, y no hay documentos entre julio de 2025 y octubre de 2026. La serie de estados declarados tiene un solo punto.

Señales abiertas que el informe no reconoce: variance_time, progress_vs_plan, hitos cumplidos sin evidencia, compromiso vencido, rebaseline sin autorización y presupuesto comprometido (91.1 %, disponible real 213.319.058 COP).

### Lecciones ancladas a un hecho
- **Hecho:** el cronograma v3 del 2026-10-02 mueve el cierre 112 días y solo hay 41 con solicitud aprobada (CC-01, 2026-10-04). **Efecto:** 71 días de atraso sin autorización documentada, más una solicitud (CC-02) pendiente por el mismo valor. Una fecha no se mueve en el plan antes de que el comité la apruebe.
- **Hecho:** CC-01 dice «autorizada por el comité» y ningún acta lo recoge. **Efecto:** no se puede comprobar quién autorizó +41 días y 82.000.000 COP.
- **Hecho:** tres hitos con fechas 2025-10-24, 2026-01-13 y 2026-04-04 figuran «met» sin evidencia, y el cronograma v1 (2025-07-25) ya los marca «cerrado». **Efecto:** el estado «cumplido» no se puede auditar en ninguno de los cuatro hitos.
- **Hecho:** no hay documentos entre 2025-07-25 y 2026-10-02. **Efecto:** la historia de esos once meses no se puede reconstruir desde esta carpeta; lo que pasó ahí no se sabe.

### Qué no sé
- No hay cronograma v2 ni motivo del v3.
- No hay informes de avance anteriores al 2026-10-02.
- No leí por mi cuenta el .docx, el .xlsx ni el .pdf; esos datos vienen de la ficha `records/PRY-205.json`, que cita su fuente. Sí leí directamente CC-01, CC-02 y el cronograma v1.
- «Meses declarando sin sustento» no sale del script; con una sola declaración no se calcula.

### Pie de rigor
Cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-14). Nada de lo anterior atribuye intención: que 71 días no tengan autorización documentada no dice que alguien lo hiciera a propósito. La conversación sobre eso es de una persona, con estos datos. El pie de rigor no está definido en el plugin; este es un resumen mínimo de qué se verificó y qué no.

### Siguiente paso
Puedo llevar esta historia al cierre del proyecto, o al comité del 2026-10-21 si ahí hay que decidir CC-02 (+71 días, +142.000.000 COP).
