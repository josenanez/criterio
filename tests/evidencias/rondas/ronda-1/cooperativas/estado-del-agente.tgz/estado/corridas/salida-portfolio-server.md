# Rostrum — para mirarlo un rato

Modo: **para mirarlo un rato** (argumento `rato`). Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C.

Informe servido: `reportes/` (hay informe: `index.html`, `decisiones.html`, 13 proyectos y 3 productos). Estado: `estado/`. Configuración: `.criterio/portafolio/config.json`. El portal lleva el nombre «Cooperativas (prueba)».

Términos: aceptados (versión 1.0, 2026-10-14, José Francisco Ñáñez).

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | La portada, con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, como pregunta cerrada y con la consecuencia de no decidirla | El comité y el patrocinador |
| `/proyectos` | El listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | El informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | El listado de productos y los proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | El informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda nada.

Qué enlace, a quién: `http://127.0.0.1:8787/` solo funciona en este equipo; sirve para mirar y para enseñárselo a alguien delante de la pantalla. No sirve como enlace para un patrocinador: para eso es «que quede corriendo» (`--abierto`, un host y un puerto, detrás del control de acceso de la organización). El informe está al día hasta la última vez que se corrió `/portfolio-report`; la portada muestra la fecha.
