Términos: vigentes (v1.0, aceptados por José Francisco Ñáñez el 2026-10-14).

## Acta — PRY-206 Pagos con QR
**Estado:** existe, del 2025-12-17 (`00-gobierno/2025-12-17-acta-constitucion.docx`). Modo revisar; sin cambios a la fuente.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente (monto y cambios de alcance sin comité) | **Ausente** | Natalia Ospina no tiene un límite escrito. Toda reprogramación o ajuste de presupuesto —como la salida reprogramada que reporta el 2026-10-10— termina en el Comité de Riesgos, o se decide sin que nadie pueda decir si le correspondía. |
| Objetivo de negocio | **Débil**: "Entregar pagos con qr para Riesgo y Cumplimiento" | Describe la solución, no el resultado de negocio. No hay forma de saber si el proyecto sirvió aunque entregue. |
| Alcance | **Relleno**: "Componente 1 / 2 / 3" | El alcance no está definido. Cualquier solicitud de cambio se puede argumentar dentro o fuera, y el control de cambios no tiene contra qué medir. |
| Exclusiones | **Relleno**: "Lo que otro proyecto cubre" | No nombra qué proyecto ni qué cubre. Riesgo de que el trabajo quede sin dueño o se construya dos veces. |
| Patrocinador | Presente: Felipe Arango | — |
| Supuestos y restricciones | **Ausentes** | Lo que el plan da por cierto (p. ej. disponibilidad del core cooperativo) no está declarado, así que no se puede saber cuándo dejó de cumplirse. |
| Dependencias | Declara "Ninguna" | **Contradicha**: el informe del 2026-10-10 reporta como riesgo abierto la "dependencia del proveedor del core cooperativo", y el cronograma incluye el hito "Integración con el core cooperativo". |
| Criterio de éxito | **Débil**: "Pagos con QR en producción y medido" | Sin umbral, sin indicador y sin nombre de quién mide. "Medido" no es una medida. |
| Quién mide el éxito | **Ausente** | Nadie responde por declarar si el proyecto cumplió. |
| Cadencia de reporte al comité | **Ausente** (el comité sí está: Comité de Riesgos) | No hay ritmo pactado para que el proyecto rinda cuentas. |
| Hitos principales | **Ausentes del acta** (están en el cronograma v1) | El acta no compromete hitos; solo inicio y cierre. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar pagos con qr para Riesgo y Cumplimiento" (acta, "Objetivo del negocio"), que es la solución.
**Alcance:** pendiente de definir. El acta solo trae "Componente 1, 2, 3" (acta, "Alcance").
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre" (acta, "Fuera de alcance").
**Patrocinador:** Felipe Arango (acta) · **Gerente:** Natalia Ospina (acta)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento.
**Comité al que reporta:** Comité de Riesgos (acta) · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 3.300.000.000 COP, Comité de Riesgos, 2025-12-17 (acta).
**Fechas comprometidas:** inicio 2025-12-27, cierre 2027-07-05 (acta).
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Pagos con QR en producción y medido" (acta) · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2025-12-17, `10-plan/2025-12-17-cronograma-v1.xlsx`; ninguno con fecha vigente distinta de la línea base):
- Diseño funcional aprobado: 2026-04-29, cerrado
- Ambiente de pruebas certificado: 2026-08-30, cerrado
- Integración con el core cooperativo: 2027-01-01, en curso
- Piloto con asociados: 2027-05-04, en curso

### Lo que el acta no explica y los demás documentos sí muestran
- **Hito cerrado tarde sin replanificar:** el acta de recibo del "Ambiente de pruebas certificado" está fechada 2026-10-11 (`20-seguimiento/…acta-recibo-ambiente-de-pruebas-certificado.pdf`), 42 días después de la fecha de línea base y vigente (2026-08-30). El cronograma no registra ese desplazamiento. Sin autoridad declarada tampoco hay a quién atribuirle la decisión de no registrarlo.
- **Avance contra ejecución:** el informe del 2026-10-10 declara Rojo con 75 % de avance, con 749.267.576 COP ejecutados de 3.300.000.000 (22,7 %) y 2.454.221.172 comprometidos (74,4 %). Los dos hitos restantes (integración y piloto) siguen en curso. El 75 % coincide con lo comprometido, no con lo ejecutado ni con los hitos; no lo puedo sustentar con los documentos.
- **Inicio:** el acta fija el inicio el 2025-12-27, diez días después de aprobada, y el cronograma v1 es del mismo día de la aprobación (2025-12-17). No hay cronograma posterior.

### Qué sigue
- Como el acta quedó **sin autoridad declarada**, esto es una decisión del Comité de Riesgos, no un trámite: cuánto puede mover Natalia Ospina sin subir y qué cambios de alcance. Si quieres, preparo ese punto para el comité del 2026-10-21 (`/steering-pack`). Esta sesión es de prueba y no tomo la respuesta por ti: queda ofrecido, no hecho.
- Los supuestos que salieron de esta revisión (disponibilidad del proveedor del core; criterio de medición del éxito) se pueden pasar al registro RAID (`/raid-log`). Ofrecido, no hecho.

### Pie de rigor
- Leí: el acta (.docx), el cronograma v1 (.xlsx), el informe de avance del 2026-10-10 y el acta de recibo del 2026-10-11 (.pdf). No leí otros documentos del proyecto porque no hay más en la carpeta.
- No sé: quién mide el criterio de éxito, qué proyecto cubre las exclusiones, ni qué autoridad se ejerce de hecho. Esos campos quedan como pendientes de definir; no los completé.
- No se editó ningún documento. El 75 % de avance es lo que declara el gerente, no algo que los documentos sustenten.
