# Definición de producto · Marca propia

**Código:** PRD-304
**Gerente de producto:** Natalia Ospina
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2025-10-06

## El problema

El segmento Clientes frecuentes no tiene marca propia.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-03-28 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
