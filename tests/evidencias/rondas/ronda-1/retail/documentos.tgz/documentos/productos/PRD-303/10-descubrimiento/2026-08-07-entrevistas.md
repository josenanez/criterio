# Entrevistas · Pago con QR

**Ronda:** Ronda · 2026-08-07
**Realizadas por:** Rubén Cárdenas

### Cliente entrevistado · 2026-08-07

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
