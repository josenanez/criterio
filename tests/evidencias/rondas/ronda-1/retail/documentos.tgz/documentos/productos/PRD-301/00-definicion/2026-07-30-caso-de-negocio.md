# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2026-07-30
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 200.866 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
