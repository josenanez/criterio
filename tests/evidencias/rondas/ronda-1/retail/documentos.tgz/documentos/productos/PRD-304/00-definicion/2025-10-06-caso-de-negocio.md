# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2025-10-06
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 286.926 | Caso de negocio, 2025-10-06 |

## Retorno esperado

Retorno esperado en 24 meses.
