# Entrevistas · Marca propia

**Ronda:** Ronda · 2026-03-18
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-03-18

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
