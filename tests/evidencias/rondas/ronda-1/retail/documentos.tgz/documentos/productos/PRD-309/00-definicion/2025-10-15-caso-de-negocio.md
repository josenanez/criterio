# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2025-10-15
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 106.839 | Caso de negocio, 2025-10-15 |

## Retorno esperado

Retorno esperado en 24 meses.
