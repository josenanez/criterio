# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Javier Hoyos
**Segmento:** Empresas
**Fecha de la definición:** 2026-05-27

## El problema

El segmento Empresas no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-13 · verificado

## Proyectos que lo construyen

- Ninguno declarado
