# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-05-27
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 89.047 | Caso de negocio, 2026-05-27 |

## Retorno esperado

Retorno esperado en 24 meses.
