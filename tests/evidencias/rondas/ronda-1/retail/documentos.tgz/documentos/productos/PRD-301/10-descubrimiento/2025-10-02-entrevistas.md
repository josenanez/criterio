# Entrevistas · Puntos de fidelización

**Ronda:** Ronda · 2025-10-02
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2025-10-02

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
