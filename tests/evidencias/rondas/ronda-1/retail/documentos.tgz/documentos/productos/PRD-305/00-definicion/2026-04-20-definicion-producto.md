# Definición de producto · Entrega rápida

**Código:** PRD-305
**Gerente de producto:** Mauricio Pérez
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-04-20

## El problema

El segmento Clientes frecuentes no tiene entrega rápida.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-03-31 · verificado

## Proyectos que lo construyen

- Ninguno declarado
