# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-01-06
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 171.148 | Caso de negocio, 2026-01-06 |

## Retorno esperado

Retorno esperado en 24 meses.
