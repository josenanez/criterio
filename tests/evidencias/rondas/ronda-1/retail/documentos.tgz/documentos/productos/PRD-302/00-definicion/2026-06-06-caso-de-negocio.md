# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-06-06
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 162.318 | Caso de negocio, 2026-06-06 |

## Retorno esperado

Retorno esperado en 24 meses.
