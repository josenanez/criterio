# Acta de constitución · Pronóstico de demanda

**Código:** PRY-211
**Área dueña:** Comercial
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-09

## Objetivo del negocio

Entregar pronóstico de demanda para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Arquitectura el 2026-02-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-19 |
| Cierre | 2027-05-04 |

## Criterio de éxito

Pronóstico de demanda en producción y medido.

## Dependencias declaradas

- Ninguna declarada
