# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-10-10
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 12.522.209.731 |
| Ejecutado | 6.187.850.036 |
| Proyección al cierre | 16.613.468.226 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
