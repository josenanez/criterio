# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-07
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **86%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 7.839.495.025 |
| Ejecutado | 5.058.064.524 |
| Proyección al cierre | 9.136.237.291 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
