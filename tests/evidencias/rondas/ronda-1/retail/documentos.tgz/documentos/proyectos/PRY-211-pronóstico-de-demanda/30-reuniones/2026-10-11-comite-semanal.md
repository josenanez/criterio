# Comité de Arquitectura · Pronóstico de demanda

**Fecha:** 2026-10-11
**Asistentes:** Camilo Beltrán, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 3 | 2026-10-05 |
