# Comité de Transformación Digital · Reposición automática

**Fecha:** 2026-10-11
**Asistentes:** Natalia Ospina, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 23 | 2026-09-28 |
