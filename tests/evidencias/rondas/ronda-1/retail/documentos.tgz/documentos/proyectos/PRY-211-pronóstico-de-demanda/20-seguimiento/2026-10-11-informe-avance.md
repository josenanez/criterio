# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 6.114.630.594 |
| Ejecutado | 8.207.812.682 |
| Proyección al cierre | 18.391.344.930 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
- Concentración del conocimiento en una sola persona
