# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 2 | 2026-10-21 |
| Mauricio Pérez | Entregar el punto 13 | 2026-11-04 |
