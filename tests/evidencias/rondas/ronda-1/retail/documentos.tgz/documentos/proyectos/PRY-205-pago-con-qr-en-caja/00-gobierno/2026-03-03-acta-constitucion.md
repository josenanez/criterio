# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Tecnología
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Arquitectura
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2026-03-03

## Objetivo del negocio

Entregar pago con qr en caja para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Arquitectura el 2026-03-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-13 |
| Cierre | 2027-03-05 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
