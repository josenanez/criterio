# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-10
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **58%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.287.629.939 |
| Ejecutado | 4.450.795.344 |
| Proyección al cierre | 9.670.413.730 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Congelamiento de cambios en temporada alta
