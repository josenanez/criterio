# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Servicio al cliente
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** María Restrepo
**Comité:** Comité de Expansión
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2025-09-03

## Objetivo del negocio

Entregar programa de fidelización para Servicio al cliente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Expansión el 2025-09-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-13 |
| Cierre | 2026-08-19 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
