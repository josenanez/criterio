# Informe de avance · Reposición automática

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **56%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 446.554.875 |
| Ejecutado | 398.490.070 |
| Proyección al cierre | 791.774.022 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
