# Acta de constitución · Domicilios en dos horas

**Código:** PRY-208
**Área dueña:** Abastecimiento
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Arquitectura
**Producto asociado:** entrega rápida
**Fecha de aprobación:** 2026-05-07

## Objetivo del negocio

Entregar domicilios en dos horas para Abastecimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Arquitectura el 2026-05-07.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-17 |
| Cierre | 2027-03-16 |

## Criterio de éxito

Domicilios en dos horas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
