# Informe de avance · Migración del ERP

**Código:** PRY-209
**Fecha de corte:** 2026-10-09
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- Se levantó un hallazgo de seguridad en los medios de pago

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.092.622.637 |
| Ejecutado | 446.793.651 |
| Proyección al cierre | 2.325.442.152 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
