# Comité de Arquitectura · Pago con QR en caja

**Fecha:** 2026-10-06
**Asistentes:** Camilo Beltrán, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 34 | 2026-10-19 |
