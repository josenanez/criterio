# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Abastecimiento
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-22

## Objetivo del negocio

Entregar reposición automática para Abastecimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-08-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-01 |
| Cierre | 2026-12-31 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
