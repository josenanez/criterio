# Comité de Expansión · Programa de fidelización

**Fecha:** 2026-10-06
**Asistentes:** María Restrepo, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 31 | 2026-10-26 |
