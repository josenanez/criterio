# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Marca propia de alimentos
**Fecha:** 2026-10-11
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +90 días sobre la línea base vigente |
| Costo | 180.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
