# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Camilo Beltrán

## Estado declarado

**Amarillo**

Avance reportado: **24%**

## Lo que pasó en el periodo

- El proveedor entregó el componente de integración, pendiente de aceptación
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.640.293.336 |
| Ejecutado | 2.219.894.936 |
| Proyección al cierre | 4.073.370.024 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Congelamiento de cambios en temporada alta
