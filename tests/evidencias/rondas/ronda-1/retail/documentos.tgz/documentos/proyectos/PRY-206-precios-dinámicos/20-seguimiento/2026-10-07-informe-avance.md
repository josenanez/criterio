# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-07
**Gerente:** Carlos Peña

## Estado declarado

**Verde**

Avance reportado: **40%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.184.854.645 |
| Ejecutado | 1.454.327.865 |
| Proyección al cierre | 3.117.880.048 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- Disponibilidad de los jefes de tienda para el piloto
