## Registro — Puntos de fidelización (PRD-301) · al 2026-10-14

El registro de requerimientos no existe todavía: `estado/requirements` está vacío y `compute` devuelve 0 requerimientos, sin porcentajes ni vacíos. No hay nada que contar, y no lo invento.

Lo que sí se sabe de la corrida de configuración (no del registro): REQ-1010, REQ-1011 y REQ-1012 figuran como aceptados en el acta de comité del 2026-10-14, sin texto, sin proyecto y con «Cliente entrevistado» como único doliente. Esos tres no están levantados como requerimientos, así que no se evalúan aquí.

Siguiente paso: levantar el registro desde los documentos (inventario con requirement-record) y volver a correr /product-requirements.
