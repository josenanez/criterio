# Corrida del 2026-10-14 · product-definition

PRD-301 · 0 requerimientos · 53 s · 0 hallazgos

La definición no tiene criterio de éxito, el 200.866 mensual no tiene serie, y la única cita de demanda (2025-10-02) ya envejeció

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Definición — Puntos de fidelización (PRD-301) · contrastada al 2026-10-14
**Documento:** `00-definicion/2026-07-30-definicion-producto.docx` y `00-definicion/2026-07-30-caso-de-negocio.md` · **del** 2026-07-30 · 5 afirmaciones

Términos 1.0 aceptados por José Francisco Ñáñez (2026-10-14), coinciden con TERMS.md v1.0.
Sesión sin interfaz: en cada pregunta se tomó la respuesta sugerida. Para que el cálculo viera la definición se cargó la ficha `producto.json` con lo que dicen los documentos y nada más (problema, segmento, la cifra 200.866 y el supuesto del proveedor, cada uno con su fuente).

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Pero hay una razón: casi nada tiene una segunda fuente con la que contrastarse (ver las secciones siguientes).

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque ninguna tiene serie medida con la que compararse.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 200.866 | Caso de negocio, 2026-07-30 (se cita a sí mismo como fuente) | No hay serie medida de `volumen_mensual` en ningún documento ni en el estado. Nadie está midiendo lo que el negocio afirmó. No es una contradicción: es que no se puede saber. |

### No está dicho en ninguna parte
- **Criterio de éxito.** Ni la definición ni el caso de negocio lo traen.
- **Cuál es la propuesta.** La definición dice «Propuesta principal» y nada más.
- **Cuánto es el retorno y cómo se calcula.** Solo dice «Retorno esperado en 24 meses»: sin cifra, método ni fuente.
- **De dónde sale el 200.866 mensual** y qué cuenta (¿transacciones?, ¿clientes?, ¿puntos?). La unidad no está dicha.
- **Qué es «no tiene puntos de fidelización».** La definición no dice qué tienen hoy esos clientes, ni qué cuesta no tenerlos.
- **Qué es el proveedor ni cuál es el tiempo pactado** del supuesto.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado» y el acta del comité (2026-10-14) pone «—» en REQ-1010, REQ-1011 y REQ-1012, aceptados desde 2026-03-28, 2026-05-04 y 2026-05-12, es decir, antes de la definición del 2026-07-30.
- **Qué decidió el comité.** «Se mantiene el plan» y no hay plan en la carpeta.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-17, marcado «verificado») | 0 según la definición: ella misma lo marca verificado. Pero la verificación no está a la vista y el supuesto lleva 150 días escrito. | Nombrar al proveedor y el tiempo pactado, y anexar el documento que muestra el cumplimiento (acta de entrega, contrato, registro de tiempos) con su fecha. Sin eso, «verificado» es una palabra y no un hecho. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento «Clientes frecuentes» no tiene puntos de fidelización | Una cita de un cliente: *«Lo necesito y hoy no lo tengo»* (entrevista de Mauricio Pérez) | 2025-10-02 | Débil. Alguien dijo; nadie pagó ni pidió por escrito. Una sola voz, sin nombre ni segmento, y la cita no nombra los puntos de fidelización. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento «Clientes frecuentes» no tiene puntos de fidelización | La cita del 2025-10-02 | 12 meses y 12 días: pasa el umbral de 12 meses configurado. Es además anterior a la definición (2026-07-30). |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Un programa de puntos para «clientes frecuentes» acumula, por fuerza, datos personales de compra de cada cliente, y puede tocar consumidor (vigencia o caducidad de puntos, publicidad de condiciones) | No declarado | No puedo nombrarla sin el país | — | **No tengo la norma a la vista.** No es un cumplimiento: es un vacío. Ni la definición ni la configuración dicen el país. Va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. **Sin él el producto no se puede cerrar**, porque el cierre se juzga contra él meses después.
- Problema: dicho en una frase, sin cuantificar.
- Para quién: dicho («Clientes frecuentes») pero sin definir qué es un cliente frecuente.
- Quién decide: Comité de producto (según la configuración); ningún documento nombra a una persona con autoridad.

### Después
- Si se quiere, convertir en riesgo con doliente que el 200.866 no tiene serie y que el supuesto del proveedor no tiene su verificación a la vista. No se ofrece `/product-charter`: la definición no está cerrada.

_Borrador de trabajo bajo los Términos 1.0; la verificación es de la persona que lo usa._
