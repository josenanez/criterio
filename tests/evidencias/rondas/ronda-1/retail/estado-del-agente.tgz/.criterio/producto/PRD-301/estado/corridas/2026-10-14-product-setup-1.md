# Corrida del 2026-10-14 · product-setup

? · 0 requerimientos · 0 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

0 preguntas (sesión sin interfaz, respuestas sugeridas); primer resultado en pocos minutos; 4 documentos, 1 de descubrimiento con una sola cita de más de 12 meses; 9 vacíos sin sustento, entre ellos retorno, éxito y proyecto que ejecute los 3 requerimientos

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Puntos de fidelización (PRD-301)

**Lo que miré:** 4 documentos · 1 de descubrimiento (entrevistas del 2025-10-02) · la definición del 2026-07-30 (caso de negocio y definición de producto, ambos de esa fecha) · un acta de comité del 2026-10-14. No hay formatos que no pueda leer.

**Cómo quedó configurado (sin preguntas, con la respuesta sugerida en cada una):**
- Producto: Puntos de fidelización, PRD-301; gerente: Mauricio Pérez (firma el caso de negocio y la definición).
- Quién decide qué se construye: Comité de producto (es el que sesiona en el acta del 2026-10-14; ningún documento nombra a una persona con autoridad).
- Estado guardado en `.criterio/producto/PRD-301/estado`, fuera de la carpeta de documentación.
- Términos 1.0 aceptados por José Francisco Ñáñez, 2026-10-14.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento «Clientes frecuentes» no tiene puntos de fidelización | Una cita de un cliente: «Lo necesito y hoy no lo tengo» | 2025-10-02 |
| El volumen mensual es 200.866 | Solo el propio caso de negocio (se cita a sí mismo como fuente) | 2026-07-30 |
| Habrá retorno en 24 meses | Nada: no hay cifra, ni método, ni fuente | — |
| El proveedor cumple el tiempo pactado | Supuesto declarado «verificado» el 2026-05-17, sin la verificación a la vista | 2026-05-17 |

### Lo que no está dicho en ninguna parte
- **Quién es el cliente que dijo «Lo necesito».** La cita no dice de qué segmento es ni qué necesita: no nombra los puntos de fidelización. Es una sola voz, y ya está fechada más de 12 meses antes de hoy (2025-10-02 → 2026-10-14), pasado el umbral de 12 meses configurado.
- **De dónde sale el 200.866 mensual.** No hay serie medida ni fuente distinta al caso de negocio; nadie está midiendo lo que el negocio afirmó.
- **Cuánto es el retorno esperado y cómo se calcula.** Solo dice «24 meses».
- **Cuál es la propuesta.** La definición dice «Propuesta principal» y nada más.
- **Qué es éxito.** Ni la definición ni el caso traen criterio de éxito.
- **Qué pidió cada requerimiento.** REQ-1010, REQ-1011 y REQ-1012 no tienen texto, solo el ID repetido; los tres figuran «aceptados» con «Cliente entrevistado» como quien lo pidió, pero la entrevista trae una sola cita, sin relación con ningún ID.
- **Quién construye esto.** La definición dice «Proyectos: ninguno declarado» y el comité muestra «—» como proyecto en los tres requerimientos. Aceptados desde 2026-03-28, 2026-05-04 y 2026-05-12, sin proyecto.
- **Qué decidió el comité.** «Se mantiene el plan» — no hay plan en la carpeta.
- **Fecha de los requerimientos vs. la definición.** Los tres requerimientos están aceptados desde antes de la definición (2026-07-30): se aceptó antes de definir.

### Supuestos sobre los que está escrita
Uno: «El proveedor cumple el tiempo pactado», declarado 2026-05-17 y marcado verificado, sin evidencia de la verificación en la carpeta. No se nombra al proveedor ni el tiempo pactado.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas completas (hay una sola cita).
- La serie de la métrica principal (volumen mensual) con su fuente y su fecha; sin ella no se puede contrastar el 200.866.
- Las decisiones del comité con su motivo y el plan que «se mantiene»; sin ellas un requerimiento descartado se ve igual que uno que nadie miró.
- El texto de cada requerimiento.

Nota: el cálculo del script salió vacío (el registro de requerimientos aún no se levantó), así que no hay porcentajes ni conteos derivados en este informe. Las fechas son las de los documentos.

Siguiente paso: `/product-discovery` sobre las entrevistas, para convertir los temas en requerimientos con cita de quién los pidió.

_Borrador de trabajo bajo los Términos 1.0; la verificación es de la persona que lo usa._
