# Caso de negocio — Puntos de fidelización (PRD-301) · borrador del 2026-10-14
**Desde:** la definición del 2026-07-30 y el caso de negocio del 2026-07-30 · **Cifras con fuente:** 0 de 1 con fuente independiente (la única cifra se cita a sí misma)

*Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (ya registrados en la configuración).*

## Qué problema resuelve, y para quién
El segmento «Clientes frecuentes» no tiene puntos de fidelización. (`00-definicion/2026-07-30-definicion-producto.docx`, 2026-07-30.)

Evidencia de demanda: una sola cita, de un cliente sin nombre, del 2025-10-02 (hace más de 12 meses): «Lo necesito y hoy no lo tengo». (`10-descubrimiento/2025-10-02-entrevistas.md`.)

## Qué se construye
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1010 (doliente Felipe Arango) | aceptado desde 2026-03-28 | «Cliente entrevistado»: la única entrevista es del 2025-10-02 |
| REQ-1011 (doliente Felipe Arango) | aceptado desde 2026-05-04 | ídem |
| REQ-1012 (doliente Mauricio Pérez) | aceptado desde 2026-05-12 | ídem |

Fuente: `30-decisiones/2026-10-14-comite-producto.docx`. Los tres tienen como criterio «se verifica en producción» (no es verificable de antemano) y ningún proyecto que los ejecute. La definición declara «Proyectos que lo construyen: ninguno». El título de cada requerimiento es solo su código; no dice qué se construye.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 200.866 | **Declarada** (Mauricio Pérez) | `00-definicion/2026-07-30-caso-de-negocio.md`, cuya fuente es «Caso de negocio, 2026-07-30»: se cita a sí misma | 2026-07-30 |
| Retorno esperado | «en 24 meses» | **Supuesta** | Sin cifra, método ni fuente | 2026-07-30 |

### Donde la cifra declarada y la medida no coinciden
No se puede contrastar: no hay serie medida de `volumen_mensual` para PRD-301. Lo que existe es una declaración y ninguna medición. (Los umbrales de la configuración, `claim_gap_pct` = 20 %, quedan sin aplicar por falta de la cifra medida.)

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento |
| Costo de operar | **No hay** | Ningún documento |

**El costo de construir es el primer vacío. Sin él lo que hay es una propuesta, no un caso de negocio que evaluar.**

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-17, marcado «verificado») | Se mueve el plazo; no hay proveedor, tiempo ni contrato a la vista | Mauricio Pérez: falta la verificación misma, solo hay la marca |
| El volumen de 200.866 mensuales es el que tendrá el producto | Todo lo que dependa del volumen cae | Dueño del sistema donde viviría el dato; hoy nadie |
| El retorno llegará en 24 meses | No hay base para el plazo | Mauricio Pérez / Finanzas |
| Una entrevista de 2025 representa la demanda de «Clientes frecuentes» | Los tres requerimientos aceptados no tienen quién los pidió | Quien haga nueva ronda de descubrimiento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso | Mauricio Pérez con quien cotice o presupueste |
| Fuente del 200.866 (serie medida, corte, sistema) | Hoy se cita a sí mismo | Dueño del sistema de transacciones |
| Cifra, método y fuente del retorno | «Retorno en 24 meses» no es una cifra | Mauricio Pérez / Finanzas |
| Criterio de éxito (`success` vacío en el estado del producto) | Sin él nada es verificable después | Mauricio Pérez, validado por el Comité de producto |
| Qué pasa si no se hace | Ausente del caso | Mauricio Pérez |
| Alternativas consideradas | Ausente del caso | Mauricio Pérez |
| Entrevistas más recientes y con nombre | La única evidencia pasó el umbral de 12 meses | Mauricio Pérez |
| Proyecto que ejecute REQ-1010/1011/1012 | Aceptados hace 5 a 6 meses sin dueño de ejecución | Comité de producto |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito, ni métrica, ni fecha de corte. Sin esto el producto no se puede cerrar meses después. (Lo único cercano es «retorno en 24 meses», que no mide nada.)

## Si hay otros productos publicados
No hay fichas publicadas de otros productos. Mirando sus documentos en bruto:
- PRD-304 (volumen_mensual 286.926) y PRD-305 (281.211) comparten el segmento «Clientes frecuentes», pero resuelven otros problemas (marca propia, entrega rápida) y declaran cifras distintas. No hay una cifra repetida de forma idéntica con PRD-301.
- Con todo, tres productos cuentan transacciones mensuales del mismo segmento: si son las mismas transacciones, la suma no existe. No se puede confirmar sin fichas publicadas ni la definición de cada volumen; queda como pregunta para `/product-overlap`.

## Siguiente paso
Pasar los cuatro supuestos a **assumption-tracking**. Este borrador no recomienda aprobar ni rechazar, y no estima ni calcula retorno.
