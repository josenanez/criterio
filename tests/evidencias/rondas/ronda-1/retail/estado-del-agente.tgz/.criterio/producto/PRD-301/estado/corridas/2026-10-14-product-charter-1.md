# Corrida del 2026-10-14 · product-charter

PRD-301 · 0 requerimientos · 35 s · 0 hallazgos

Borrador de acta para REQ-1010 con vacíos marcados: criterio de aceptación no verificable, demanda anónima y vencida (2025-10-02), sin criterio de éxito, sin autoridad del gerente, sin patrocinador, sin barrido normativo. No se creó la ficha: falta la firma.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (ya constaba en la configuración). Preguntas de la sesión: ninguna respondida por persona; se tomó la respuesta sugerida —seguir marcando los vacíos en el acta, sin rellenarlos.

# Acta de constitución — Puntos de fidelización · borrador del 2026-10-14
**Producto:** PRD-301 Puntos de fidelización · **Requerimientos:** REQ-1010

## Verificación previa (paso 1)
| Condición | Resultado | Fuente |
|---|---|---|
| Aceptado, no propuesto | Sí: «aceptado», desde 2026-03-28 | 30-decisiones/2026-10-14-comite-producto.docx |
| Criterios de aceptación verificables | **No.** El único texto es «se verifica en producción», que no dice qué se mide ni con qué umbral | ídem |
| Evidencia de demanda con cita | **Débil.** Una sola cita anónima («Cliente entrevistado»): «Lo necesito y hoy no lo tengo.» Es del 2025-10-02, 12 meses y 12 días antes de hoy, pasado el umbral de 12 meses; no menciona REQ-1010 ni dice qué se pidió | 10-descubrimiento/2025-10-02-entrevistas.md |
| Autoridad del gerente declarada en la definición | **No.** La definición nombra al gerente (Mauricio Pérez) pero no dice qué puede decidir; la configuración solo dice que la autoridad del producto es el «Comité de producto» | 00-definicion/2026-07-30-definicion-producto.docx; config.json |

El registro de requerimientos del estado está vacío: REQ-1010 solo existe como una fila del acta de comité. Su título es el propio identificador («Requerimiento REQ-1010») y no hay texto del requerimiento. Se sigue marcando cada vacío, sin rellenarlo.

## Qué problema resuelve
«El segmento Clientes frecuentes no tiene puntos de fidelización.» (definición, 2026-07-30). No consta qué parte de ese problema cubre REQ-1010.

## Criterio de éxito
**Vacío.** La definición no declara criterio de éxito (`success` nulo). El único criterio del requerimiento es «se verifica en producción», que no se puede juzgar meses después. Falta una métrica, un umbral y una fecha.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1010 | «Requerimiento REQ-1010» (sin título propio) | Aceptado en el comité del 2026-10-14, doliente Felipe Arango; demanda: una cita anónima de 2025-10-02, vencida |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1011 | «Requerimiento REQ-1011» | No se pidió en este argumento. Aceptado desde 2026-05-04, sin proyecto |
| REQ-1012 | «Requerimiento REQ-1012» | No se pidió en este argumento. Aceptado desde 2026-05-12, sin proyecto |

No hay otros requerimientos levantados. Excluir estos dos es consecuencia del argumento y no un juicio sobre su valor; si debían ir en el mismo proyecto, lo decide el gerente de producto.

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no nombrado. Mauricio Pérez es gerente de producto, no consta como gerente de proyecto. Asignarlo no corresponde a este borrador.
- **Comité:** Comité de producto, mensual (config.json; acta del 2026-10-14, asistió solo Mauricio Pérez).
- **Autoridad del gerente del proyecto:** no dicha (ver vacíos).
- **Doliente del requerimiento:** Felipe Arango (acta de comité 2026-10-14).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-17) | La definición dice «verificado», pero no cita cómo ni cuándo. Mismo tipo de afirmación sin fuente | Gerente del proyecto, por asignar. Se registra en RAID como supuesto con verificación sin respaldo |
| «Volumen mensual 200.866» (cifra del caso de negocio, 2026-07-30) | Solo declarada. No hay serie medida que la contraste | Gerente del proyecto, por asignar |
| Hay demanda vigente para REQ-1010 | No: la única cita tiene más de 12 meses y es anónima | Gerente del proyecto, por asignar |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Un programa de puntos asocia compras a clientes identificados, lo que probablemente toca datos personales | No determinada | Sin barrido hecho en esta corrida; no se cita norma | **Sin resolver:** requiere `regulatory-sweep` antes de firmar |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación verificable de REQ-1010 | El cierre del proyecto no se podrá juzgar | Mauricio Pérez con Felipe Arango |
| Criterio de éxito del producto | Igual: no hay contra qué medir | Mauricio Pérez |
| Texto y título del requerimiento | El proyecto arranca sin saber qué construir | Felipe Arango |
| Demanda vigente y nominada | Se construye sobre una cita anónima vencida | Mauricio Pérez (nueva ronda de entrevistas) |
| Autoridad del gerente del proyecto | El gerente escala todo o nada | Comité de producto |
| Patrocinador | Nadie responde por el presupuesto | Comité de producto |
| Presupuesto e hitos | El acta no declara ninguno; no se inventan | Comité de producto |
| Barrido normativo | Obligaciones ignoradas hasta que aparezcan tarde | Mauricio Pérez / área legal |

---
**Esto es un borrador.** Lo firma el Comité de producto o quien este designe; no consta quién. La ficha del proyecto no se crea hasta que esté firmada: en esta corrida no se ejecutó `portafolio.py init` ni se escribió el estado declarado.

## Qué sigue
Con el acta firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
