## Descubrimiento — Puntos de fidelización (PRD-301) · 1 pieza nueva al 2026-10-14

Términos: aceptados por José Francisco Ñáñez (v1.0, 2026-10-14), coinciden con TERMS.md v1.0.
Leído: 4 documentos (1 de descubrimiento, 2 de definición, 1 de decisiones). Solo el de descubrimiento es material de cliente.

### Temas
Ninguno. Una sola pieza, una sola voz, una sola cita: no hay nada que contar como "N de N".

### Dicho y nunca convertido en nada
Ninguno detectable. El comité del 2026-10-14 lista REQ-1010, REQ-1011 y REQ-1012, los tres con "Quién lo pidió: Cliente entrevistado", pero la ficha del producto no está cargada y no puedo cruzar tema contra requerimiento.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| *«Lo necesito y hoy no lo tengo.»* (tema rotulado "Necesidad principal") | Cliente entrevistado (sin nombre ni segmento), entrevista de Mauricio Pérez | 2025-10-02 |

No se promueve y no se descarta. La cita no dice qué es "lo", así que no se puede atribuir a puntos de fidelización ni a ningún REQ concreto.

### Afirmaciones numéricas de los entrevistados
Ninguna. La cifra volumen_mensual = 200.866 sale del caso de negocio (2026-07-30), no de un entrevistado, y no tiene serie medida en la carpeta.

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna contradicción. Hallazgos de contexto, sin concluir:
- Los 3 REQ aceptados citan como origen al "Cliente entrevistado", pero la única entrevista es de 2025-10-02 y es una frase sin referencia a ningún REQ.
- Los 3 REQ no tienen proyecto que los ejecute ("—"), y la definición dice "Proyectos que lo construyen: Ninguno declarado".

### Lo que no se pudo hacer
- `sellar` se negó: la ficha producto.json no se escribió en esta corrida (este comando no la escribe). Los 4 documentos quedan sin sellar y la próxima corrida los vuelve a leer.
- `compute` devolvió el producto vacío (0 requerimientos, código "?") por la misma razón. No hay cifras recalculadas.
- No se crean requerimientos.

1 pieza de cliente leída, ningún tema que el registro pueda contrastar todavía.
