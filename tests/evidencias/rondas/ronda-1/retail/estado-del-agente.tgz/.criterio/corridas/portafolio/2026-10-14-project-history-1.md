# Corrida · 2026-10-14-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-207

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-14T17:10:59 · **Fin:** 2026-10-14T17:12:03 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 46 | 37 | Historia de PRY-207 sobre 3 documentos; sin hitos ni serie de estados, no se pudo fijar el punto de separación ni los meses sin sustento; no se sabe qué pasó entre 2025-10 y 2026-10-06 ni si lo ejecutado está dentro de lo comprometido. |

Por señal (`project-history`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Historia · PRY-207 Marca propia de alimentos · 2025-10-18 a 2026-10-11

**Leí:** 3 documentos entre 2025-10-18 y 2026-10-11.
**Trimestres sin un solo documento:** 2026-T1, T2 y T3. Entre el acta y el informe de avance no hay nada en casi once meses.
**Términos:** la configuración ya traía la aceptación de José Francisco Ñáñez, versión 1.0, 2026-10-14. Es la misma versión que `TERMS.md`.

**En una línea:** el acta es del 2025-10-18, con cierre comprometido para el 2026-10-30 y 6.800.000.000 COP aprobados. El informe del 2026-10-06 declara Rojo y 66%. La solicitud de cambio CC-01 (2026-10-11) pide +90 días y 180.000.000 COP, y sigue sin decisión. La carpeta no permite reconstruir el recorrido: solo muestra el punto de partida y las dos últimas semanas.

| Replanificaciones | Atraso vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 0 | 0 días | No calculable | 0 documentados |

- **Meses sin sustento:** hay una sola declaración y el plan no tiene hitos, así que no hay con qué contrastarla.
- **Cambios de gobierno:** con tres documentos, "0 documentados" no es lo mismo que "no hubo".
- **Punto de separación:** no se puede fijar una fecha, por la misma razón.
- **Compromisos repetidos:** no hay ninguno, porque no existe una sola minuta en la carpeta.
- **Presupuesto del informe:** la proyección al cierre es 6.882.930.735 COP, que supera lo aprobado en 1,2%. El script da como disponible real 4.059.842.504 COP. El informe no dice si lo ejecutado está dentro de lo comprometido, y de eso depende si esa cifra es real. Hay que preguntárselo al gerente.
- **Atribución:** no se atribuye intención. La carpeta no explica por qué no hay documentos en esos meses.

**Siguiente paso posible:** llevar la CC-01 y esta historia al Comité Comercial, que es quien debe decidir. La historia completa, con la línea de tiempo y las tablas, está en `estado-portafolio/corridas/salida-project-history.md`.

**Pie de rigor:** las cifras vienen de `portafolio.py compute` (as_of 2026-10-14). Lo que el script no daba, no se escribió. Todo se funda en tres documentos de un solo proyecto.

La corrida quedó registrada como `2026-10-14-project-history-1`, con 46 segundos medidos por la corrida y la nota de lo que no se sabe. El número de documentos no se midió: el registro lo dejó en null.
