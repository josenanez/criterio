# Corrida · 2026-10-14-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-14T17:14:04 · **Fin:** 2026-10-14T17:15:04 · **Duración:** 60 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 40 | 37 | Revisión del acta de PRY-200: falta autoridad del gerente, supuestos, restricciones, medidor del éxito y cadencia; objetivo, alcance y criterio de éxito débiles; fechas de cierre contradictorias entre acta (2027-12-28) y cronograma (2027-10-11). No pude saber si hubo decisiones de comité posteriores; no abrí el .xlsx. |

Por señal (`project-charter`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Acta de PRY-200 (Tienda en línea), revisada.** El acta existe, del 2026-06-22, y le faltan la autoridad del gerente y varios campos más. Los términos ya estaban aceptados en la configuración (v1.0, 2026-10-14), igual que `TERMS.md`.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no figura. Camilo Beltrán no tiene un monto ni un tipo de cambio que pueda decidir solo, así que todo cambio de alcance o de presupuesto va al Comité de Transformación Digital. Hoy están pendientes la reprogramación del despliegue y un posible cambio de alcance por la regulación de datos.
- **Supuestos, restricciones, quién mide el éxito y cadencia del comité:** no figuran. El congelamiento de temporada alta se conocía de antemano y terminó siendo una reprogramación.
- **Objetivo, alcance, exclusiones y criterio de éxito:** son débiles o vacíos.
  - El objetivo es solo el entregable ("Entregar tienda en línea para Logística"), sin resultado medible.
  - El alcance es "Componente 1, 2, 3" sin detalle.
  - La exclusión "Lo que otro proyecto cubre" no nombra ningún proyecto.
  - El criterio de éxito "en producción y medido" no dice qué se mide ni con qué umbral.
- **Dependencias:** el acta dice "Ninguna declarada", pero el informe del 2026-10-10 habla de un proveedor que entregó el componente de integración.
- **Patrocinador:** cumple, es Mauricio Pérez.
- **Fechas de cierre contradictorias:** el acta fija el cierre en 2027-12-28 y el cronograma v1 lo fija en 2027-10-11, 78 días antes. El cronograma lo tomé de la ficha, no abrí el .xlsx.
- **Presupuesto (cifras declaradas por el gerente, sin respaldo):** ejecutado más comprometido suman 3.860.188.272 COP, el 91,9 % de lo aprobado, con un avance declarado de 24 %. Eso supera el umbral de 90 % configurado.

No sé si hubo decisiones de comité posteriores al acta, porque este proyecto no tiene actas de comité ni carpeta de reuniones en la documentación. Los campos sin sustento quedaron marcados como pendientes de definir.

**Siguiente paso, si quieres:** llevar la definición de la autoridad de Camilo Beltrán al comité, y pasar los supuestos que salieron de la revisión al registro RAID.

El informe completo está en `estado-portafolio/corridas/salida-project-charter.md` y la corrida quedó registrada como `2026-10-14-project-charter-1`.

El registro de la corrida mostró cifras de todo el portafolio (13 proyectos, 37 hallazgos), no de PRY-200. Para este proyecto no registró ninguna señal.

Este es un borrador de trabajo, no certificado: verifícalo antes de decidir o escalar.
