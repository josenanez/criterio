# Corrida · 2026-10-14-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-14T17:15:10 · **Fin:** 2026-10-14T17:16:11 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 37 | 37 | Pre-cierre de PRY-201, no acta firmable: nadie declaró cierre, avance 77% vs 5 hitos cerrados sin evidencia (brecha 23.0 pts). No supo: evidencia del criterio de éxito, fecha de cierre vigente (acta 2026-08-19 vs cronograma 2026-07-19), dolientes de RAID, contrato del proveedor. Carpeta no archivada. |

Por señal (`project-closure`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Preparé el pre-cierre de PRY-201, pero no es un acta de cierre firmable, porque nadie ha declarado que el proyecto terminó. Los términos están aceptados (v1.0, José Francisco Ñáñez, 2026-10-14) y las cifras derivadas salen de `compute`.

- **Criterio de éxito:** "Programa de fidelización en producción y medido". No se puede determinar si se cumplió, porque no hay evidencia de producción ni de medición en la carpeta.
- **Avance y hitos:** el informe del 2026-10-06 declara amarillo y 77 %, pero el cronograma tiene los 5 hitos como cerrados, sin evidencia, y el script marca una brecha de 23.0 puntos. La integración del proveedor está sin aceptar y la prueba de carga se repite.
- **Números:** 0 replanificaciones y 0 días de atraso contra el cronograma. Presupuesto aprobado 800.000.000 COP, ejecutado 180.349.863 (22.5 %), comprometido 358.781.943 (44.8 %), proyección 806.743.033 (+0.8 %). Las tres cifras del gasto son declaración del gerente, sin respaldo contable en la carpeta.
- **Fecha de cierre en conflicto:** el acta fija el cierre en 2026-08-19 y el cronograma, aprobado el mismo día, en 2026-07-19. Nadie decidió cuál rige, y la ficha no registró ese conflicto.
- **Abierto sin doliente:** los 2 riesgos, las 2 incidencias y el compromiso "punto 31" (para 2026-10-26, sin decir qué es) no tienen responsable.
- **Lecciones:** no entra ninguna, porque ninguna se puede anclar a un hecho documentado. Puse en su lugar los dos hechos por explicar: la fecha duplicada y los hitos cerrados con avance de 77 %.

No moví la carpeta a `archivo/` ni congelé la ficha: un proyecto sin cierre declarado y con incidencias abiertas debe seguir en el barrido diario.

La salida completa está en `estado-portafolio/corridas/salida-project-closure.md`, y la corrida quedó registrada como `2026-10-14-project-closure-1`.
