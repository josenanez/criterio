# Corrida · 2026-10-14-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-14T17:08:14 · **Fin:** 2026-10-14T17:08:56 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 18 | 37 | Presupuesto de PRY-210: proyección 12,4 % sobre el aprobado; comprometido 43,7 %. Dijo que no sabe: presupuesto original vs vigente por separado, evidencia contable, proveedores. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Presupuesto de PRY-210 (Etiquetas electrónicas de precio) al 2026-10-14

Salen de la ficha PRY-210 y del `compute` de hoy. Los términos 1.0 ya estaban aceptados en la configuración (José Francisco Ñáñez, 2026-10-14).

**Moneda:** COP, la única que hay, sin conversión.

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 2.400.000.000 | 100 % | Acta de constitución | 2026-01-21 |
| Comprometido | 1.049.743.627 | 43,7 % | Informe de avance (declaración) | 2026-09-28 |
| Ejecutado | 469.411.976 | 19,6 % | Informe de avance (declaración) | 2026-09-28 |
| Proyección al cierre | 2.698.160.369 | 112,4 % | Informe de avance (declaración) | 2026-09-28 |

**Disponible real** (aprobado menos comprometido): 1.350.256.373 COP.

- **Contra la línea base:** no hay replanificaciones ni solicitudes de cambio. La ficha guarda un solo aprobado, así que el original y el vigente coinciden. La proyección excede el aprobado en 12,4 %, es decir 298.160.369 COP. Esa resta la hice yo; `compute` solo da el porcentaje.
- **Ejecución frente a avance:** el ejecutado es 19,6 % y el avance declarado es 32 %, con 1 hito cumplido de 4. No hay gasto adelantado. Pero el único hito cumplido, "Diseño de la experiencia aprobado", no tiene evidencia.
- **Alertas:**
  - **Proyección:** supera el umbral de 10 %.
  - **Comprometido:** está bajo el umbral de 90 %, sin alerta de tope.
  - **Declaraciones:** comprometido, ejecutado y proyección salen de un informe de avance, no de un documento contable.
  - **Otras señales:** hay 16 días de silencio y el hito "Ambiente de pruebas certificado" lleva 12 días vencido. El informe declara verde pese a eso y al sobrecosto.
- **Sin dato:** el presupuesto original y el vigente como dos cifras separadas, la evidencia contable de comprometido y ejecutado, y los proveedores (la ficha no registra ninguno).

Como la proyección excede el aprobado, puedo preparar la solicitud de cambio con `/change-control`. No ofrezco el detalle por proveedor: el comprometido está lejos del tope y no hay proveedores registrados.

La corrida quedó registrada como `2026-10-14-budget-tracking-1`, con la salida completa en `estado-portafolio/corridas/salida-budget-tracking.md`.
