# Corrida · 2026-10-14-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-14T17:05:15 · **Fin:** 2026-10-14T17:06:03 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 23 | 37 | Informe de PRY-210: verde declarado contradicho por 4 señales (hito vencido, hito cumplido sin evidencia, silencio de 16 días, proyección +12,4%). No se sabe: producto, autoridad, fase, última reunión. |

Por señal (`status-report`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Ficha:** `estado-portafolio/records/PRY-210.json`, actualizada el 2026-10-14. Las cifras salen de `compute`, recalculado ese día. Los términos v1.0 están aceptados por José Francisco Ñáñez (2026-10-14).

## PRY-210 · Etiquetas electrónicas de precio — estado al 2026-10-14

- **Declara el gerente (Javier Hoyos):** verde, 32%, al 2026-09-28 (hace 16 días).
- **Sustento documental:** contradicho. No hay ningún documento de evidencia: la ficha tiene 3 declaraciones y 10 documentos sin marcar.
- **Lo que el semáforo no explica:** un hito vencido, un hito cumplido sin evidencia, 16 días de silencio y una proyección de costo por encima del umbral. Es la alerta `declared_vs_evidence`.
- **Último documento:** 2026-09-28. **Última reunión:** sin dato, porque la ficha no registra reuniones.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-06-04 | 2027-06-04 | 0 días |
| Presupuesto aprobado (COP) | 2.400.000.000 | 2.400.000.000 | — |
| Proyección declarada (COP) | — | 2.698.160.369 | +12,4% (umbral 10%) |

Hay 0 replanificaciones. Comprometido: 1.049.743.627 (43,7%). Ejecutado: 469.411.976 (19,6%). Estas cifras y la proyección son declaración del informe del 2026-09-28, no evidencia.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-06-02 | 2026-06-02 | cumplido (declarado) | ninguna, hace 134 días |
| Ambiente de pruebas certificado | 2026-10-02 | 2026-10-02 | pendiente, vencido hace 12 días | ninguna |
| Integración con el ERP | 2027-02-02 | 2027-02-02 | pendiente | ninguna |
| Piloto en tiendas | 2027-06-04 | 2027-06-04 | pendiente | ninguna |

### Dónde no coincide
- El informe del 2026-09-28 dice verde, pero el cronograma v1 fija el ambiente de pruebas para el 2026-10-02 y sigue pendiente.
- El mismo informe declara una proyección de +12,4% sobre el presupuesto, y no hay solicitud de cambio.
- El informe reconoce que la prueba de carga no alcanzó el umbral y que el despliegue se reprogramó sin fecha nueva. El plan no se movió.

### Abierto
- **Riesgos e incidencias sin movimiento (16 días, todos sin responsable):** congelamiento en temporada alta, cambio en la regulación de datos personales, prueba de carga bajo el umbral y despliegue reprogramado.
- **Compromisos vencidos:** ninguno, pero la ficha tiene 0 compromisos registrados. Eso es ausencia de registro, no cumplimiento.
- **Dependencias sin confirmar:** ninguna registrada. El acta excluye «lo que otro proyecto cubre» sin nombrarlo.

### Sin dato
- Producto, autoridad y fase. Sin autoridad no se puede decir si los riesgos exceden la del gerente.
- Fecha de la última reunión.
- Responsable, probabilidad e impacto de los riesgos e incidencias.
- Fecha nueva del despliegue reprogramado.

### Siguiente paso
Puedo preparar el punto de comité (Comité de Expansión) por la desviación de costo y el hito vencido. También puedo preparar la solicitud de cambio por la reprogramación del despliegue. No hice ninguno de los dos.

*Pie: criterio-portfolio v0.3.6. Ficha del 2026-10-14, declaración del 2026-09-28. Campos inciertos: producto, autoridad, fase, última reunión. Términos v1.0 (2026-09-18).*

La corrida quedó registrada como `2026-10-14-status-report-1`, con la salida en `estado-portafolio/corridas/salida-status-report.md`. El tiempo medido fue de 23 segundos. El número de documentos no se pudo medir.
