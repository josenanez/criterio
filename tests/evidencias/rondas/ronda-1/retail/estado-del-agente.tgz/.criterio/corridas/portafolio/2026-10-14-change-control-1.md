# Corrida · 2026-10-14-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-14T17:09:57 · **Fin:** 2026-10-14T17:10:52 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 37 | 37 | Solicitud de mover 30 días la salida a producción de PRY-201. Impacto en portafolio: 0 alcanzados (sin dependencias declaradas). No se sabe: autoridad (no declarada), motivo, costo del mes extra, ni por qué el hito figura cerrado. Acta (cierre 2026-08-19) y cronograma v1 (2026-07-19) no coinciden; ambas fechas ya pasaron. |

Por señal (`change-control`): `milestone_met_without_evidence` 17, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_overdue` 2, `milestone_overdue` 2, `vendor_deliverable_late` 1, `silent` 1, `variance_cost` 1, `commitment_undated` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

No se puede aprobar ni registrar el cambio de PRY-201 todavía. Pedir «30 días» no tiene un punto de partida válido, y falta quién lo autorice.

Partí de la ficha de PRY-201, el acta, el cronograma v1 y la minuta del comité del 6 de octubre. Los términos 1.0 estaban aceptados.

- **La línea base no cuadra.** El acta compromete el cierre el 2026-08-19, y el cronograma v1 (la única línea base) dice 2026-07-19. Son 31 días sin explicación ni autorización.
- **Las dos fechas ya pasaron.** Hoy es 2026-10-14. Sumar 30 días a la del cronograma da 2026-08-18, que sigue 57 días en el pasado, así que el cambio tal como se pidió no se puede ejecutar. Hace falta una fecha calendario nueva. Si contara desde hoy, sería 2026-11-13.
- **El hito de salida figura cerrado.** El cronograma marca «Despliegue en la cadena» como cerrado, pero la ficha declara 77 % de avance, hay una prueba de carga fallida y un componente sin aceptar. Esas afirmaciones se contradicen.
- **Efecto en el portafolio: ninguno calculado.** El script devolvió 0 proyectos alcanzados. Es porque el acta no declara dependencias y ninguna otra ficha cita a PRY-201, no porque se haya comprobado que no hay.
- **Quién decide: no se puede determinar.** La ficha no tiene autoridad declarada. Por defecto iría al Comité de Expansión, con Jorge Medina como patrocinador.
- **Costo: sin estimar.** El presupuesto aprobado es de 800.000.000 COP y la proyección declarada, de 806.743.033 COP. Los montos de comprometido, ejecutado y proyección salen solo de una declaración del informe de avance.
- **Sin línea base nueva.** Faltan la fecha, el motivo y el documento que aprueba el cambio. La v1 no se toca. El atraso contra ella hoy es de 87 días, y de 117 si el cierre nuevo fuera 2026-11-13.

Tampoco sé quién pidió el cambio ni por qué, ni si «salida a producción» es ese hito.

La corrida quedó registrada como `2026-10-14-change-control-1`, con la salida completa en `estado-portafolio/corridas/salida-change-control.md`.
