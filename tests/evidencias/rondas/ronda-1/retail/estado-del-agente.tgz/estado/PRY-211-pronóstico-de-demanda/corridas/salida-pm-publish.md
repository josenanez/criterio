Términos: aceptados v1.0 por José Francisco Ñáñez el 2026-10-14 (la sesión de prueba lo confirmó).

Recalculé antes de publicar (fecha de cálculo 2026-10-14). Publiqué la ficha en `documentos/proyectos/PRY-211-pronóstico-de-demanda/00-gobierno/ficha-pm.json`, con corte al 2026-10-14.

**Lleva:** 10 campos con dato · 8 sin decir en ninguna parte (authority, identity.product, declared.status, declared.progress_pct, declared.as_of, plan.milestones, money.committed, money.executed) · **no declara estado**: nadie ha declarado verde, amarillo ni rojo para este proyecto, y esto es lo primero que la PMO va a mirar.

**Lo más viejo que va ahí:** los 10 campos con dato salen del acta de constitución del 2026-02-09 (8 meses; no pasa de un año).

**De los ocho campos que Vera contrasta:** 5 con dato (sponsor, manager, committee, end_date 2027-05-04, approved 18.000.000.000 COP) y 3 sin decir (product, declared.status, declared.as_of).

Aparte, sin publicar: hay un compromiso sin fecha (Laura Vélez, «Mandar el ajuste del presupuesto», notas del 2026-10-14) y no hay línea base.
