# PRY-211 Pronóstico de demanda — semana del 2026-10-08 al 2026-10-14

**Declara el gerente (Camilo Beltrán):** SIN DECLARACIÓN · sin avance · sin fecha
**Sustento documental:** no evaluable — sin declaración no hay nada que sustentar o contradecir
**Lo que el semáforo no explica:** no aplica sin semáforo. Señal abierta: 1 compromiso sin fecha (Laura Vélez).

> Sesión sin interfaz: nadie respondió la pregunta de la declaración. Por diseño el sistema no propone ni sugiere un estado, así que la línea queda en blanco. Un informe sin declaración es incómodo a propósito.

## Qué cambió esta semana
No hay base de comparación: no existe una corrida anterior de `pm-report` ni snapshot previo a hoy (el diff devolvió 0 cambios contra el snapshot de hoy, recién tomado). Esto es una primera lectura, no «no cambió nada».

Lo que sí entró hoy desde `2026-10-14-notas-reunion.txt`: 3 compromisos, 1 riesgo no registrado.

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Sin línea base | Acta 2026-02-09 | 247 |
| Sin autoridad definida (`authority`) | Sin dato | n/d |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin línea base | 2027-05-04 (acta) | no calculable |
| Presupuesto | COP 18.000.000.000 (acta) | sin dato | no calculable |

Replanificaciones: 0 registradas. Sin línea base no se puede medir desviación contra la original ni contra la vigente; 0 replanificaciones aquí significa «no registradas», no «no ocurrieron».

### Hitos de las próximas cuatro semanas
Sin dato: `plan.milestones` no está en la ficha.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 18.000.000.000 | sin dato | sin dato | sin dato | no calculable (aprobado − comprometido) |

## Abierto
**Reprogramados:** Ricardo Salas, «Entregar el punto 3»: 1 reprogramación (2026-10-05 → 2026-10-28). Por debajo del umbral de 3. Nota: la fecha original ya estaba vencida cuando se dijo en el comité del 2026-10-11.
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto», dicho «la otra semana» (2026-10-14). Sin fecha no puede vencer ni verificarse.
**Vencidos sin evidencia:** ninguno hoy. Próximos: Óscar Ramírez, «Revisión con el proveedor», 2026-10-24; Ricardo Salas, 2026-10-28.
**RAID sin movimiento:** nada con antigüedad medible. Riesgo sin dueño ni registro formal: el proveedor podría no llegar con el equipo completo en la siguiente fase (comentado en reunión, owner no identificado).
**Proveedor:** sin entregables de proveedor en la ficha.

## Lo que necesito de alguien
- Camilo Beltrán: declarar estado y avance (única línea que este informe no escribe).
- Camilo Beltrán: confirmar si la línea base existe; sin ella ninguna desviación es medible.
- Laura Vélez: fecha concreta para el ajuste del presupuesto.
- Quien corresponda: dueño para el riesgo del equipo del proveedor.
- Nada excede hoy la autoridad del gerente, pero `authority` no está definida, así que eso tampoco se puede afirmar.

## Lo que no se sabe
**Sin dato:** authority, declared.status, declared.progress_pct, plan.milestones, money.committed, money.executed.
**Silencio:** último documento hace 0 días · última reunión hace 0 días (2026-10-14). Los 10 documentos leídos están sin marcar como evidencia o declaración; ninguno cuenta como evidencia.

---
Ficha: `records/PRY-211.json`, actualizada 2026-10-14 · 6 campos sin dato · Términos: TERMS.md v1.0 (aceptados por José Francisco Ñáñez, 2026-10-14).
