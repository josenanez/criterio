# Acta — Pronóstico de demanda (PRY-211) · 2026-10-14

**Asistieron:** Camilo Beltrán, Carlos Peña, Ricardo Salas, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-14-notas-reunion.txt` · **Ausentes con tema en agenda:** no se puede saber (las notas no traen agenda). María Restrepo (patrocinadora) no figura entre los asistentes.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Ricardo Salas | Entregar el punto 3 | 2026-10-28 | **Reprogramado 1 vez.** Fecha anterior: 2026-10-05 (`30-reuniones/2026-10-11-comite-semanal.md`). Umbral de bandera: 3. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Nuevo |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana»; no es una fecha y no se le inventó una (`due_date: no_declarada`). |

## Decisiones
Ninguna. Las notas no registran que nadie haya decidido algo.

## Quedó sin decidir
Nada se dejó explícitamente como pendiente de decisión.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» | No identificado (las notas dicen «se comentó») | Riesgo (posible, sin materializar), dependencia del proveedor | No. Los riesgos del informe del 11-10 son otros dos: jefes de tienda para el piloto y concentración del conocimiento. El acta de constitución declara «Ninguna» dependencia. Queda en el estado con doliente `no_identificado`. |

## Cerrado en esta reunión
Nada. Ricardo Salas dice que «el punto 3 no alcanzó»; no hay documento de entrega, y no cierra nada.

## Lo que esta reunión contradice
Nada. Ni el patrocinador, ni la fecha de cierre (2027-05-04), ni el comité cambian respecto al acta de constitución. «Próxima reunión en dos semanas» coincide con el comité configurado del 2026-10-28.

## Sin resolver de la transcripción
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: no se sabe qué día; «la otra semana» puede ser la del 19 o la del 26 de octubre.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-24»: las notas no dicen si es un compromiso propio o una reunión que debe convocar otro. Se registró como compromiso suyo.
- Quién planteó el riesgo del proveedor no está en las notas.
- Observación sobre el compromiso reprogramado: el comité del 11-10 registra la fecha original como 2026-10-05, anterior a esa reunión, y Ricardo Salas no figura entre sus asistentes. Conviene confirmar con Camilo Beltrán desde cuándo estaba vencido.

---
**Recalculado (`compute`):** 1 alerta: compromiso sin fecha (Laura Vélez). 0 vencidos, 0 contradicciones.

**Siguiente:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por ahora: ningún campo de la ficha cambió. Esta acta sale en la conversación y no se guardó en tu carpeta de reuniones; guardarla es cosa tuya.
