## PRY-211 · 2026-10-14

**Revisé:** 8 documentos · 8 nuevos (primer barrido, sin barrido previo) · 2 minutas nuevas (comité 2026-10-11, notas 2026-10-14)

### Lo que se venció solo
Nada nuevo cruzó desde la corrida anterior (no hay corrida anterior de barrido).
- Compromiso de Ricardo Salas, «Entregar el punto 3», para 2026-10-05 (`30-reuniones/2026-10-11-comite-semanal.md`): venció sin evidencia de entrega, y ya está reprogramado al 2026-10-28 (`2026-10-14-notas-reunion.txt`). Es su primer reprogramado; el umbral es 3.
- Laura Vélez, «ajuste del presupuesto»: dijo «la otra semana», sin fecha. No puede vencer porque no tiene fecha; queda abierto y sin fecha declarada.
- Óscar Ramírez, revisión con el proveedor, 2026-10-24: aún no vence.
- Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase (sin doliente). Ya está en la ficha.
- Los compromisos de las dos minutas ya estaban extraídos en la ficha; no volví a extraer.

### La reunión
Comité el 2026-10-28, faltan 14 días. Todavía no toca agenda (se ofrece cuando falte un día o menos). El informe toca el 2026-10-27. Las notas del 2026-10-14 ya tienen su acta/compromisos extraídos; no hay reunión pasada sin acta.

### Tu ficha publicada
Al día: se publicó hoy, 2026-10-14. No hay aviso.

**Vuelvo el 2026-10-15.**
