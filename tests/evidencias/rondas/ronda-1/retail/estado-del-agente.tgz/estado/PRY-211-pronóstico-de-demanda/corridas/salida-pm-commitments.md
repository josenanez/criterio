## Compromisos — PRY-211 Pronóstico de demanda · al 2026-10-14

3 compromisos abiertos: ninguno vencido, ninguno reprogramado 3 veces, 1 sin fecha.

### Se viene reprogramando
Nada llega al umbral de 3 reprogramaciones. Se deja a la vista el que lleva una:

> **Ricardo Salas** · Entregar el punto 3
> Prometido para el 2026-10-28 (dicho el 2026-10-14), y antes para el 2026-10-05 (comité del 2026-10-11, `30-reuniones/2026-10-11-comite-semanal.md`).
> Una reprogramación todavía no es un patrón; si vuelve a moverse, sube.

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. (Lo más cercano: Óscar Ramírez, revisión con el proveedor, 2026-10-24.)

| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 (fuera de esta semana) |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-14 · `2026-10-14-notas-reunion.txt` |

No puede estar vencido; se cuenta aparte para que no desaparezca. «La otra semana» no es una fecha y no se le puso una.

### Cerrados desde la última revisión
Ninguno. Las actas de recibo del expediente (ambiente de pruebas, diseño de la experiencia) no corresponden a «el punto 3».

### Aparte
En las notas del 2026-10-14 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. No es un compromiso: ya está en la ficha como riesgo sin doliente.

Fuente de las cifras: `portafolio.py compute` (commitments_overdue 0, commitments_undated 1, commitments_rescheduled 0).
