## Reunión de seguimiento — PRY-211 Pronóstico de demanda · 2026-10-28
4 puntos · 25 minutos · 4 personas requeridas (Camilo Beltrán, Ricardo Salas, Óscar Ramírez, Laura Vélez)

Los minutos son propuesta mía: la configuración no trae duración de la reunión. Fecha: «próxima reunión en dos semanas» (`2026-10-14-notas-reunion.txt`), que coincide con el comité configurado del 2026-10-28.

### Lo que no se destraba solo
Nada. No hay compromisos reprogramados tres veces (el umbral), ninguno vencido sin evidencia y ninguna decisión que haya quedado pendiente en la reunión anterior. **Es una reunión de seguimiento, no de destrabe.**

### Vencido sin evidencia
Ninguno.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **Quién es el doliente del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase».** Hoy está en la ficha con doliente `no_identificado` y no figura en el informe de avance del 11-10 ni en el acta de constitución (que declara «Ninguna» dependencia). Fuente: `2026-10-14-notas-reunion.txt`. | Camilo Beltrán | Sigue siendo un comentario de reunión sin nadie que lo mueva. **Esto no debería esperar al 28:** la revisión con el proveedor es el 24, y es el sitio natural para llevar la pregunta. | 10 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Min |
|---|---|---|---|
| Óscar Ramírez | Revisión con el proveedor (`2026-10-14-notas-reunion.txt`). Qué tiene que quedar: resultado de la revisión y qué dijo el proveedor sobre el equipo de la siguiente fase. | 2026-10-24 | 5 |
| Laura Vélez | Mandar el ajuste del presupuesto. **Sin fecha**: dijo «la otra semana», que puede ser la del 19 o la del 26. Qué tiene que quedar: una fecha puesta por ella, que Camilo debería pedirle ya, sin esperar a la reunión. Fuente: `2026-10-14-notas-reunion.txt`. | no declarada | 5 |
| Ricardo Salas | Entregar el punto 3. Vence el mismo día de la reunión. Lleva **una** reprogramación (antes 2026-10-05, comité del 2026-10-11, `30-reuniones/2026-10-11-comite-semanal.md`); no es un patrón todavía, y está aquí para verificar que hay entrega, no para repasar. | 2026-10-28 | 5 |

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Hallazgo de seguridad en los medios de pago (informe de avance del 2026-10-11, `20-seguimiento/2026-10-11-informe-avance.md`) | Está en el informe pero no en ningún registro de incidencias, y el informe no dice quién lo lleva ni nadie de los que van aparece como su doliente (el informe menciona al área de seguridad en otra línea, y no está en la sala). | Confirmar con Camilo quién lo lleva; si excede su autoridad, `/pm-escalate` |
| Presupuesto: el informe del 11-10 declara ejecutado 8.207.812.682 COP contra comprometido 6.114.630.594 COP (ejecutado mayor que comprometido) y proyección de 18.391.344.930 COP sobre 18.000.000.000 aprobados | Las cifras no están en la ficha (`money.committed` y `money.executed` sin encontrar), así que no las verifiqué y la cifra se lee sin contraste. Lo ata el ajuste de Laura; si cambia el aprobado, es decisión de comité. | Se aclara con el ajuste de Laura; después `/pm-commitments` o el material del comité |
| María Restrepo (patrocinadora) no figuró entre los asistentes del 2026-10-14 | La reunión del 28 coincide con el comité configurado, pero el comité del 11-10 lo hicieron Camilo y María, y la reunión de equipo la hicieron otras personas. Si el 28 es una sola reunión, cambian los asistentes y esta agenda es corta para el comité. | Camilo decide si son dos reuniones o una |

### Anexo — sin cambios desde la reunión anterior
No se puede armar: esta es la primera corrida y `diff` no tiene un estado anterior contra el cual comparar (`baseline_run`). Por eso no afirmo qué «sigue igual». Lo único que sé que no se movió: Carlos Peña asistió el 14-10 y no tiene compromisos registrados.

### Lo que esta agenda no sabe
- Los entregables del proveedor (actas de recibo del 2026-10-05 y del 2026-10-12) no están en la ficha como proveedor, y no los leí; no puedo decir si hay alguno vencido o aceptado sin documento.
- El estado «verde» y el avance de 35% son lo declarado en el informe; no los contrasté con el plan, que la ficha tampoco trae.

*Fuente de las cifras: `portafolio.py compute` (commitments_overdue 0, commitments_rescheduled 0, commitments_undated 1) y `portafolio.py due` (comité 2026-10-28, a 14 días).*

**Siguiente:** cuando termine la reunión, `/pm-minutes` sobre las notas. Esta agenda no convoca a nadie; citar es tuyo.
