# Plan — PRY-211 Pronóstico de demanda · borrador del 2026-10-14
**Desde:** acta de constitución del 2026-02-09 (`00-gobierno/2026-02-09-acta-constitucion.md`) · **Criterio de éxito:** «Pronóstico de demanda en producción y medido» (acta, «Criterio de éxito»). Está declarado, pero no dice medido contra qué.

*Términos: TERMS.md v1.0 aceptado por José Francisco Ñáñez, 2026-10-14 (ya consta en la configuración).*

**Una advertencia antes del plan:** este no es un primer borrador sobre un acta recién firmada. El proyecto arrancó el 2026-02-19, ya hay un `cronograma-v1.csv` con cuatro hitos, dos están cerrados y el informe del 2026-10-11 declara 35 %. Lo de abajo reconstruye una WBS desde el acta y contrasta con ese cronograma. No toca la línea base.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** dice «Componente 1, Componente 2, Componente 3» | No se puede descomponer por entregable lo que el acta no nombra. Los tres componentes quedan como «sin definir» en la WBS. |
| **Fuera de alcance sin contenido:** «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué | No hay frontera. Cualquier petición de Comercial puede entrar sin que haya que pasarla por control de cambios. |
| **«Medido» sin métrica:** el criterio de éxito no dice qué se mide, contra qué línea de comparación, ni en qué plazo después de producción | No se puede saber cuándo el proyecto cumplió, ni qué entregable es el que lo demuestra. |
| **Autoridad del gerente no declarada** | No se sabe qué puede decidir Camilo Beltrán al planificar y qué hay que subir al Comité de Arquitectura o a la patrocinadora. |
| **Dependencias: «Ninguna declarada»**, pero el cronograma tiene un hito «Integración con el ERP» | O hay una dependencia con el ERP que nadie escribió, o el hito depende solo de este equipo. El acta no lo dice. (En la carpeta hay un proyecto PRY-209 «Migración del ERP»; no lo leí y no afirmo que se relacionen.) |
| **Quién acepta cada entregable: no está** | Las actas de recibo de los dos hitos cerrados dicen «Recibido por: Camilo Beltrán», es decir, el gerente recibe lo que su propio equipo entrega. El acta no dice si la aceptación del negocio la da María Restrepo (patrocinadora) u otra persona. |

Patrocinador: declarado (María Restrepo). Comité: declarado (Comité de Arquitectura).

## WBS
Descompuesta por entregable. Lo que el acta no nombra no se completa con lo razonable.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado | Sin definir (acta de recibo: Camilo Beltrán) | Supuesto: es hito del `cronograma-v1.csv`, el acta no lo nombra. Cerrado; acta de recibo del 2026-10-12 | n/a, cerrado |
| 2 | Ambiente de pruebas certificado | Sin definir (acta de recibo: Camilo Beltrán) | Supuesto: hito del cronograma, no del acta. Cerrado; acta de recibo del 2026-10-05 | n/a, cerrado |
| 3 | Integración con el ERP | Sin definir | Supuesto: hito del cronograma, no del acta. En curso | vacía |
| 4 | Piloto en tiendas | Sin definir | Supuesto: hito del cronograma, no del acta. En curso. El informe lista como riesgo la disponibilidad de los jefes de tienda | vacía |
| 5 | Componente 1 | Sin definir | **Sin definir.** El acta solo dice «Componente 1» | vacía |
| 6 | Componente 2 | Sin definir | **Sin definir** | vacía |
| 7 | Componente 3 | Sin definir | **Sin definir** | vacía |
| 8 | Pronóstico de demanda en producción | Sin definir | Del acta, en parte: está en el criterio de éxito. No hay hito en el cronograma | vacía |
| 9 | Medición del pronóstico en producción | Sin definir | Del acta, en parte: «y medido». Sin métrica, sin línea de comparación, sin periodo | vacía |
| 10 | ¿Cierre del hallazgo de seguridad en medios de pago y plan de pruebas ajustado con seguridad? | Sin definir | **Sin definir.** Sale del informe del 2026-10-11, no del acta. No sé si es un entregable, parte del 2 o trabajo ajeno al plan | vacía |

Los hitos 1 a 4 no son necesariamente los componentes 1 a 3; el acta no permite saberlo.

## Orden
Sin fechas. Solo lo que se sostiene:
- **8 antes que 9:** el criterio de éxito dice «en producción y medido». Medir lo que no está en producción no tiene sentido.
- **4 (piloto) antes que 8 (producción):** supuesto. El cronograma los ordena así, pero ningún documento dice que producción dependa del piloto.
- **3 (ERP) antes que 4 (piloto):** supuesto. Solo es el orden de las filas del cronograma, no una dependencia declarada.
- **1 y 2:** ya cerrados.
- **5, 6, 7 y 10:** no se pueden ordenar. No se sabe qué son.

**Hueco en el cronograma:** el último hito, «Piloto en tiendas», está en 2027-03-16 y el cierre del acta es 2027-05-04. Entre los dos no hay ningún hito para «en producción y medido», que es el criterio de éxito. Eso no lo resuelve este comando.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del `cronograma-v1.csv` son los entregables del proyecto | Si los «Componentes 1–3» del acta son otra cosa, falta trabajo en la WBS y el cronograma no cubre el alcance. |
| «Integración con el ERP» no depende de otro proyecto | Si depende (p. ej. de PRY-209), el atraso de ese otro proyecto mueve este, y el acta dice que no hay dependencias. |
| El piloto precede a producción | Si producción puede ir sin piloto, o el piloto es parte de producción, el orden cambia. |
| El proveedor llega con el equipo completo a la siguiente fase | **Dicho en la reunión del 2026-10-14 («podría no llegar con el equipo completo») y nadie lo registró como riesgo.** Si es falso, afecta cualquier hito que dependa del proveedor, y no sé cuáles son. |
| El equipo actual se sostiene | El informe del 2026-10-11 reporta dos semanas perdidas por rotación de un desarrollador clave y riesgo de «concentración del conocimiento en una sola persona». |

Estos pasan a RAID cuando el plan se apruebe, y el del proveedor ya debería estar ahí.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Patrocinadora (María Restrepo) con el gerente; el acta no dice quién |
| Qué queda fuera de alcance, y qué otro proyecto lo cubre | Patrocinadora / Comité de Arquitectura |
| Métrica, línea de comparación y plazo de «medido» | Área dueña (Comercial) |
| Quién acepta cada entregable por el negocio | Patrocinadora |
| Autoridad del gerente sobre el plan | Patrocinadora / Comité de Arquitectura |
| Si el hallazgo de seguridad de medios de pago es entregable de este proyecto | Gerente, con el área de seguridad |
| Si hay dependencia con el ERP y de quién | Gerente |
| Qué es «el punto 3» (compromiso de Ricardo Salas, antes para 2026-10-05, ahora para 2026-10-28) | Ricardo Salas / gerente. No hay documento que lo defina |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, y no inferí análogos desde las carpetas de otros proyectos. Esa es la respuesta correcta aquí, y evita una falsa precisión.

**Referencia del propio proyecto** (recibo vs. línea base del `cronograma-v1.csv` y las actas de recibo):

| Hito | Línea base | Acta de recibo | Diferencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-05-27 | 2026-10-12 | 138 días después |
| Ambiente de pruebas certificado | 2026-09-02 | 2026-10-05 | 33 días después |

El cronograma sigue mostrando `fecha_vigente` igual a `fecha_linea_base` en los dos, sin replanificación registrada. Es un dato de lo ocurrido, no una estimación de lo que sigue. Los tres hitos en curso tienen su fecha en el cronograma; este comando no las confirma ni las cambia.

## Preguntas para el equipo
Una por duración vacía:
1. **Integración con el ERP:** ¿cuánto toma, qué sistemas y qué equipos externos participan, y quién la acepta?
2. **Piloto en tiendas:** ¿cuántas tiendas, cuánto dura, y qué jefes de tienda tienen que estar disponibles y cuándo?
3. **Componentes 1, 2 y 3:** ¿qué son, y cuánto toma cada uno?
4. **Pronóstico en producción:** ¿qué hay que hacer entre el piloto y producción, y cuánto toma?
5. **Medición:** ¿qué se mide, contra qué línea de comparación, y cuántas semanas hacen falta para decir «medido»?
6. **Hallazgo de seguridad en medios de pago:** ¿es de este proyecto? Si lo es, ¿cuánto toma cerrarlo y quién lo acepta?

## Para comprometer una fecha falta
Nada de esto está en un documento:
- **Disponibilidad real del equipo.** Hay rotación reciente, una persona concentra el conocimiento, y no se sabe quién reemplaza al desarrollador que salió.
- **Fecha y equipo del proveedor para la siguiente fase.** Lo único escrito es una revisión con el proveedor el 2026-10-24 (Óscar Ramírez) y la duda sobre si llegan completos.
- **Ventana y disponibilidad para el piloto en tiendas** y para el paso a producción (jefes de tienda, calendario comercial).
- **Fecha del dueño de la integración con el ERP**, si no es este equipo.
- **El ajuste del presupuesto** que Laura Vélez quedó de mandar «la otra semana», sin fecha.

*Aparte, sin que sea parte de este plan:* el informe declara «Verde», 35 % de avance, y reporta ejecutado 8.207.812.682 COP contra 6.114.630.594 COP comprometido (el ejecutado supera al comprometido) y una proyección al cierre de 18.391.344.930 COP, por encima de los 18.000.000.000 COP aprobados. Eso es para `/pm-report`, no para el plan.

## Qué sigue
Este borrador no crea línea base. Si se aprueba, el siguiente paso es registrarlo como línea base original y llevar los supuestos al RAID con doliente, empezando por el del proveedor.
