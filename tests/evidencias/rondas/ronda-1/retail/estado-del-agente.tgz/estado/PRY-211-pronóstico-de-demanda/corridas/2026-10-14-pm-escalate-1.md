# Corrida del 2026-10-14 · pm-escalate

1 proyectos · 29 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

Escala solo la autoridad no declarada en el acta; seguridad, presupuesto y riesgo del proveedor no escalan sin ella. Sin impact (no mueve fechas). Costos en horas y otra fuente de autoridad: no sabe.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-211 Pronóstico de demanda · 2026-10-14

*Términos: José Francisco Ñáñez acepta TERMS.md v1.0 para esta prueba (2026-10-14). Sesión sin interfaz: no se pidió ni se recibió ninguna respuesta; sin tema en el argumento, se tomó «lo que ya está marcado como escalable».*

**Lo que escala es una sola cosa, y no es la que venías a subir: el acta no declara la autoridad del gerente.**

### ¿Qué puede decidir Camilo Beltrán por su cuenta —cambios de fecha, de presupuesto y de alcance, y la contratación o el reemplazo de proveedor—, y a partir de qué umbral decide el Comité de Arquitectura? ¿Se declara en un anexo al acta, o se deja sin declarar?

**Quién decide:** el Comité de Arquitectura, que aprobó el acta el 2026-02-09 (patrocinadora: María Restrepo). El acta no dice quién tiene la facultad de modificarla; esa es la lectura que hago, no un dato. · **Si no se decide hoy:** no hay una fecha dura en los documentos. La más cercana es el comité del **2026-10-28** (a 14 días). Si llega sin autoridad declarada, ese día no se podrá decir si el hallazgo de seguridad y el ajuste del presupuesto son del gerente o del comité, y los dos puntos se aplazan otra sesión (la siguiente sería hacia el 2026-11-11, por la cadencia quincenal; es inferencia). Hay un riesgo más cercano: la revisión con el proveedor es el **2026-10-24**, y se haría sin saber quién decide sobre él.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Declarar la autoridad en un anexo al acta, con umbrales de fecha y de presupuesto | Un documento corto, firmado por la patrocinadora | Se puede cerrar en el comité del 28-10 | Sin costo de presupuesto. No sé cuántas horas toma; no está estimado en ningún documento |
| B. No declararla y escalar caso por caso | Cada punto sube al comité | Cada punto espera a la sesión quincenal | Sin costo directo. Cada decisión demora hasta 14 días, y el acta seguirá sin respuesta a «¿esto lo decido yo?» |

**Recomiendo:** A. Es la única opción que evita que el próximo punto (seguridad, presupuesto o proveedor) llegue sin saber si le corresponde al gerente o al comité. Cuesta una hoja y una firma.

### Lo que NO escala todavía, y por qué
No armo paquete para estos puntos, porque sin autoridad declarada no puedo decir que excedan la de Camilo:

- **Hallazgo de seguridad en los medios de pago** (informe del 11-10): no está en el RAID ni tiene doliente. Primero es de Camilo, que debe decir quién lo lleva. Si después de tener la autoridad declarada resulta que lo excede, entra a `/pm-escalate` con su pregunta cerrada.
- **Presupuesto:** el informe declara ejecutado 8.207.812.682 COP contra comprometido 6.114.630.594 COP (ejecutado mayor que comprometido) y proyección de 18.391.344.930 COP sobre 18.000.000.000 aprobados. La desviación proyectada es de 391.344.930 COP (2,2 %), por debajo del umbral de 10 % de la configuración. Las cifras no están en la ficha y no las verifiqué. Lo ata el ajuste de Laura Vélez, sin fecha («la otra semana»). Si el ajuste cambia el aprobado, ahí sí es del comité.
- **Riesgo del proveedor sin doliente** («podría no llegar con el equipo completo»): tiene solución dentro del proyecto. Camilo asigna doliente y lo lleva a la revisión del 24-10 de Óscar Ramírez.
- **Ricardo Salas, «entregar el punto 3»:** una reprogramación (05-10 → 28-10), por debajo del umbral de 3.

### A quién alcanza
No calculé el impacto: este escalamiento no mueve ninguna fecha, así que `impact` no aplica. Tampoco hay otros proyectos en las fichas que cruzar. El acta declara «Ninguna» dependencia; eso tampoco está confirmado con nadie.

### Mis hitos por los que pasa
Ninguno. La ficha no trae hitos (`plan.milestones` sin encontrar) y no leí el cronograma `10-plan/2026-02-09-cronograma-v1.csv`; si el escalamiento acabara moviendo fechas, hay que calcularlo con `impact` cuando haya hitos.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2026-02-09-acta-constitucion.md` (contiene patrocinador, comité, presupuesto, fechas, criterio de éxito y dependencias; no contiene autoridad). La ficha la lista en `fields_not_found: authority`.
- Hallazgo de seguridad, presupuesto y riesgos: `20-seguimiento/2026-10-11-informe-avance.md`.
- Doliente del riesgo del proveedor, compromisos y revisión del 24-10: `2026-10-14-notas-reunion.txt`.
- Reprogramación de Ricardo Salas: `30-reuniones/2026-10-11-comite-semanal.md`.
- Comité del 28-10: `.criterio/proyecto/PRY-211/config.json`.

### Lo que este paquete no sabe
- Si existe otro documento (política de la organización, delegación) que declare la autoridad del gerente fuera del acta. Solo leí la carpeta del proyecto.
- Los costos de las opciones en horas, los de fechas y cualquier cifra de cambio: no los inventé.

**Siguiente:** llevar la pregunta al comité del 28-10 es tuyo. Este comando no escala solo.
