# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Camilo Beltrán
**Segmento:** Gerencia
**Fecha de la definición:** 2025-12-09

## El problema

El segmento Gerencia no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La red de la mina soporta el volumen** · declarado el 2026-06-11 · verificado

## Proyectos que lo construyen

- Ninguno declarado
