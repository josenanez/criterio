# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-09-21
**Asistentes:** Javier Hoyos

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1080 | Requerimiento REQ-1080 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-1081 | Requerimiento REQ-1081 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-1082 | Requerimiento REQ-1082 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-1083 | Requerimiento REQ-1083 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-03 | — |

## Decisiones

- Se mantiene el plan
