# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-05-18
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 89.390 | Caso de negocio, 2026-05-18 |

## Retorno esperado

Retorno esperado en 24 meses.
