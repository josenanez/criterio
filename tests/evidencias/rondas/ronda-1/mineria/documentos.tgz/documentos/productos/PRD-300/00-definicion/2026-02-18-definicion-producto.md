# Definición de producto · Monitoreo de flota

**Código:** PRD-300
**Gerente de producto:** Javier Hoyos
**Segmento:** Comunidad
**Fecha de la definición:** 2026-02-18

## El problema

El segmento Comunidad no tiene monitoreo de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-03-31 · verificado

## Proyectos que lo construyen

- Ninguno declarado
