# Tablero de métricas · Alerta de taludes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-28

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 52.716 | 2026-09-28 |
