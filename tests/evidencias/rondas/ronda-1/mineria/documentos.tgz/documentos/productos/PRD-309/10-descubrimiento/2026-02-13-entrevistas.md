# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2026-02-13
**Realizadas por:** Gustavo Neira

### Cliente entrevistado · 2026-02-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
