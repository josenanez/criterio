# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2025-09-11
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 124.239 | Caso de negocio, 2025-09-11 |

## Retorno esperado

Retorno esperado en 24 meses.
