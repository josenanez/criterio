# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-06-21
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 103.297 | Caso de negocio, 2026-06-21 |

## Retorno esperado

Retorno esperado en 24 meses.
