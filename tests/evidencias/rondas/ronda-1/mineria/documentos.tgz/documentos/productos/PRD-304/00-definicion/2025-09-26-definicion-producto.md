# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Andrés Lozano
**Segmento:** Mantenimiento
**Fecha de la definición:** 2025-09-26

## El problema

El segmento Mantenimiento no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-05-15 · verificado

## Proyectos que lo construyen

- Ninguno declarado
