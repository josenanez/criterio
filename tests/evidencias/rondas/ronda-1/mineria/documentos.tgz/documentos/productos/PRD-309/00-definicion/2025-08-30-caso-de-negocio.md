# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2025-08-30
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 80.454 | Caso de negocio, 2025-08-30 |

## Retorno esperado

Retorno esperado en 24 meses.
