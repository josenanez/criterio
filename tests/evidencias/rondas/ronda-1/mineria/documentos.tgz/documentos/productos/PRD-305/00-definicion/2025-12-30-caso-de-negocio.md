# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-12-30
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 263.030 | Caso de negocio, 2025-12-30 |

## Retorno esperado

Retorno esperado en 24 meses.
