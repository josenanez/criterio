# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-05-16
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 57.033 | Caso de negocio, 2026-05-16 |

## Retorno esperado

Retorno esperado en 24 meses.
