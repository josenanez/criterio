# Tablero de métricas · Gemelo digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 179.966 | 2026-10-12 |
