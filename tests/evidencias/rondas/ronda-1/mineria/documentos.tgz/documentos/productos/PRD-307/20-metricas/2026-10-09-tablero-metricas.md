# Tablero de métricas · Reporte ambiental

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 71.630 | 2026-10-09 |
