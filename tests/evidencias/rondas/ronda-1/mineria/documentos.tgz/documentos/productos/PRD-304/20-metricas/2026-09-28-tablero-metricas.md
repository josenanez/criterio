# Tablero de métricas · Trazabilidad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-28

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 204.113 | 2026-09-28 |
