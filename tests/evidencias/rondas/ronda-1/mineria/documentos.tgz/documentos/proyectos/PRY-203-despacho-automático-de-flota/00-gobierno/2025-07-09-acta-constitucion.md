# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Relacionamiento comunitario
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Tecnología
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-07-09

## Objetivo del negocio

Entregar despacho automático de flota para Relacionamiento comunitario.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Tecnología el 2025-07-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-19 |
| Cierre | 2026-08-18 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
