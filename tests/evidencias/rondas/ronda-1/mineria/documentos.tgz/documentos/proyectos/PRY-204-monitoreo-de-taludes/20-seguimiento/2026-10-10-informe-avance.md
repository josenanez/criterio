# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-10
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **54%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.049.157.519 |
| Ejecutado | 1.326.122.124 |
| Proyección al cierre | 6.372.625.163 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
