# Acta de constitución · Control de polvo en vías

**Código:** PRY-211
**Área dueña:** Finanzas
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** María Restrepo
**Comité:** Comité de Seguridad
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-03

## Objetivo del negocio

Entregar control de polvo en vías para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Seguridad el 2025-12-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-13 |
| Cierre | 2027-06-06 |

## Criterio de éxito

Control de polvo en vías en producción y medido.

## Dependencias declaradas

- Ninguna declarada
