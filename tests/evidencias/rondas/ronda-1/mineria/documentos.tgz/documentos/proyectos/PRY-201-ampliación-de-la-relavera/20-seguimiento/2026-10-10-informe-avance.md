# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-10
**Gerente:** Ricardo Salas

## Estado declarado

**Amarillo**

Avance reportado: **64%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 13.804.849.851 |
| Ejecutado | 7.110.855.022 |
| Proyección al cierre | 16.853.937.302 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- Ventana de parada de planta definida por operaciones
