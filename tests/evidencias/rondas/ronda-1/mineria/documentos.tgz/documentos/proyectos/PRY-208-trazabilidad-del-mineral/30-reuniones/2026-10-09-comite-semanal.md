# Comité de Inversiones · Trazabilidad del mineral

**Fecha:** 2026-10-09
**Asistentes:** Gustavo Neira, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 31 | 2026-10-28 |
| Elena Duarte | Entregar el punto 31 | 2026-10-31 |
