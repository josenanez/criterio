# Comité Ambiental · Programa de relacionamiento comunitario

**Fecha:** 2026-10-05
**Asistentes:** Diana Molina, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 35 | 2026-10-09 |
