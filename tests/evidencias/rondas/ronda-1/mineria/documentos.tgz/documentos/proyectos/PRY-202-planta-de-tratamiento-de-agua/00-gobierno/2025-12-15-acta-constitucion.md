# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Mantenimiento
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-15

## Objetivo del negocio

Entregar planta de tratamiento de agua para Mantenimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité Ambiental el 2025-12-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-25 |
| Cierre | 2026-11-29 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
