# Acta de constitución · Red privada LTE en mina

**Código:** PRY-206
**Área dueña:** Finanzas
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** María Restrepo
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-19

## Objetivo del negocio

Entregar red privada lte en mina para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité Ambiental el 2026-04-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-29 |
| Cierre | 2027-02-24 |

## Criterio de éxito

Red privada LTE en mina en producción y medido.

## Dependencias declaradas

- Ninguna declarada
