# Acta de constitución · Trazabilidad del mineral

**Código:** PRY-208
**Área dueña:** Geología
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Inversiones
**Producto asociado:** trazabilidad
**Fecha de aprobación:** 2025-07-26

## Objetivo del negocio

Entregar trazabilidad del mineral para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Inversiones el 2025-07-26.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-05 |
| Cierre | 2026-07-21 |

## Criterio de éxito

Trazabilidad del mineral en producción y medido.

## Dependencias declaradas

- Ninguna declarada
