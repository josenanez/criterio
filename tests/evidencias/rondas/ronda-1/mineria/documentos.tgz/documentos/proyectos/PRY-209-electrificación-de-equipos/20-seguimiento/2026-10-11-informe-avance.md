# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-11
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 8.758.572.947 |
| Ejecutado | 4.993.105.125 |
| Proyección al cierre | 18.540.943.448 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
