# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **88%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 7.132.708.268 |
| Ejecutado | 4.994.116.251 |
| Proyección al cierre | 9.239.845.787 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
