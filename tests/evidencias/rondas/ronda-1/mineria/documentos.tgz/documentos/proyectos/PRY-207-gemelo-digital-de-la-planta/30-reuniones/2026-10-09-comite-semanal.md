# Comité de Seguridad · Gemelo digital de la planta

**Fecha:** 2026-10-09
**Asistentes:** Jorge Medina, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 36 | 2026-09-17 |
| Gustavo Neira | Entregar el punto 1 | 2026-10-20 |
