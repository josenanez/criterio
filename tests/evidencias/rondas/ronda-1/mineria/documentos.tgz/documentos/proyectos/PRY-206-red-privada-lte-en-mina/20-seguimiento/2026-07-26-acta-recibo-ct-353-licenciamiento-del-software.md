# Acta de recibo · Licenciamiento del software

**Proyecto:** PRY-206 · Red privada LTE en mina
**Fecha de recibo:** 2026-07-26
**Recibido por:** María Restrepo

Se recibe a satisfacción el entregable **Licenciamiento del software**.

Contrato CT-353 · Automatización de Procesos Ltda..
