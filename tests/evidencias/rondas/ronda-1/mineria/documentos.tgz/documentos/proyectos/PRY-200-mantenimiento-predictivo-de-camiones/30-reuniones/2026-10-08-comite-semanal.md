# Comité de Tecnología · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-08
**Asistentes:** Beatriz Cuéllar, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 27 | 2026-10-18 |
