# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **40%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.619.833.791 |
| Ejecutado | 1.181.630.534 |
| Proyección al cierre | 2.419.828.881 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
