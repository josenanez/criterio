# Informe de avance · Programa de relacionamiento comunitario

**Código:** PRY-210
**Fecha de corte:** 2026-10-11
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 5.257.995.841 |
| Ejecutado | 3.274.897.886 |
| Proyección al cierre | 9.159.464.688 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
