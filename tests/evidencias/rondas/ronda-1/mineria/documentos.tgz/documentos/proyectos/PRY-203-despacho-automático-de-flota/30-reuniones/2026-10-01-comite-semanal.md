# Comité de Tecnología · Despacho automático de flota

**Fecha:** 2026-10-01
**Asistentes:** Óscar Ramírez, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 5 | 2026-10-14 |
