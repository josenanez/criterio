# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-202
**Fecha de corte:** 2026-10-09
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **40%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 344.010.782 |
| Ejecutado | 278.347.648 |
| Proyección al cierre | 749.320.132 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
