# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Despacho automático de flota
**Fecha:** 2026-10-11
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +32 días sobre la línea base vigente |
| Costo | 64.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
