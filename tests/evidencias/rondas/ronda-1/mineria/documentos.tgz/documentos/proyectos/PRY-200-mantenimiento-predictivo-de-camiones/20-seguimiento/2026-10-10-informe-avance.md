# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Rojo**

Avance reportado: **53%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.586.233.839 |
| Ejecutado | 5.412.722.249 |
| Proyección al cierre | 8.914.964.282 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
