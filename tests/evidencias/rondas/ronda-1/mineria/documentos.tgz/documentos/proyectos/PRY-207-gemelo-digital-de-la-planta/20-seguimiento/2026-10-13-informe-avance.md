# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-13
**Gerente:** Jorge Medina

## Estado declarado

**Rojo**

Avance reportado: **65%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Las lluvias detuvieron el montaje durante diez días
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.116.727.959 |
| Ejecutado | 2.397.804.823 |
| Proyección al cierre | 11.790.477.110 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
