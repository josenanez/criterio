# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-09-26
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **75%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.802.031.890 |
| Ejecutado | 730.741.848 |
| Proyección al cierre | 3.290.941.311 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
