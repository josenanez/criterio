# Corrida · 2026-10-14-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T17:45:12 · **Fin:** 2026-10-14T17:45:46 · **Duración:** 34 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 19 | 39 | 69 documentos, ninguno por releer; 12 citas de PRY-208 no resuelven por falta del prefijo de carpeta (los archivos existen). No se corrigió ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

## Carpeta al 2026-10-14

**Documentos:** 69 · **Sin cambio:** 69 · **Hay que releer:** 0

No cambió, se renombró ni se borró ningún documento. No hace falta `/portfolio-scan`.

**Citas que dejaron de resolver:** 12, todas de PRY-208 (11 campos de identidad, plan y dinero, más `declared.status`).
- Once citan `00-gobierno/2025-07-26-acta-constitucion.md` y una cita `2026-10-14-notas-reunion.txt`.
- La ficha escribió las rutas sin la carpeta `PRY-208-trazabilidad-del-mineral/`, y el índice las busca desde la raíz de documentos.
- Los dos archivos sí existen en disco. Lo que está mal es la ruta citada, no los documentos.
- No corregí ninguna ficha. Queda propuesto anteponer la carpeta del proyecto a esas 12 rutas, y eso lo decides tú.

La corrida quedó registrada como `2026-10-14-document-index-1` (19 s), con la salida guardada en `estado/portafolio/corridas/salida-document-index.md`. Los términos (v1.0) ya constaban en la configuración, así que no pedí aceptación.

El registro de la corrida dejó vacío el número de documentos medidos. El resto de las cifras sí se registró.
