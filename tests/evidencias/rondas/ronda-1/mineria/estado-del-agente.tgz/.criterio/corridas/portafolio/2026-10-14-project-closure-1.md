# Corrida · 2026-10-14-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-14T17:55:08 · **Fin:** 2026-10-14T17:55:58 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 30 | 39 | PRY-201 sigue abierto (64% declarado, cierre comprometido 2026-11-16): no se produjo acta de cierre sino estado del cierre. Criterio de exito declarado pero sin medida. Dijo que no sabe: hitos, entregables por componente, evidencia del avance, autoridad, dolientes de RAID, contrato y recibo del proveedor. Sin lecciones sustentables. No se archivo. |

Por señal (`project-closure`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

PRY-201 (Ampliación de la relavera) no está para cerrarse, así que no produje un acta de cierre. Dejé el estado del cierre contra lo pactado y no moví la carpeta a `archivo/`.

- **Estado:** nadie ha declarado que terminó. El informe del 2026-10-10 lo reporta en amarillo, con 64 % de avance, y el cierre comprometido es el 2026-11-16.
- **Criterio de éxito:** el acta dice "Ampliación de la relavera en producción y medido", pero no fija qué se mide ni qué valor cuenta como éxito. Por eso no se puede determinar si se cumplió.
- **Números al corte del 2026-10-10:**
  - Fecha: 0 días de desviación y 0 replanificaciones.
  - Presupuesto: de 18.000.000.000 COP aprobados, hay 7.110.855.022 ejecutados (39,5 %).
  - La proyección de 16.853.937.302 queda 6,4 % por debajo de lo aprobado, pero es una declaración del informe, no un cálculo sustentado.
- **RAID:** quedan 2 incidencias y 2 riesgos abiertos, ninguno con doliente. Una incidencia es el hallazgo de la auditoría de seguridad y la otra, los equipos del proveedor entregados sin contrato ni acta de recibo.
- **Lecciones:** no entró ninguna, porque ninguna se puede anclar a un hecho documentado con fecha y efecto. La carpeta tiene solo el acta y un informe.
- **Sin dato:** hitos, cronograma, entregables por componente, quién aprobó el acta, evidencia del 64 %, y contrato y facturación del proveedor.

Los términos 1.0 ya estaban aceptados en la configuración (José Francisco Ñáñez, 2026-10-14). Ante la pregunta sobre archivar tomé la respuesta sugerida: no archivar mientras el proyecto siga abierto.

La corrida quedó registrada como `2026-10-14-project-closure-1`. Lo que te mostré está en `estado/portafolio/corridas/salida-project-closure.md`.
