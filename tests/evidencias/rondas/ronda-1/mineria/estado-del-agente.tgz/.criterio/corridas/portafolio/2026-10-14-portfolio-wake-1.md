# Corrida · 2026-10-14-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T17:59:11 · **Fin:** 2026-10-14T17:59:57 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 30 | 39 | Barrido sin cambios (69 docs, 0 a leer). 12 citas de PRY-208 sin resolver por falta de prefijo de carpeta; no se corrigió la ficha. Confirmación: 5 preguntas formuladas, sin respuesta (sesión sin interfaz). No se consultaron peticiones (no tocaban). No se pudo saber quién escribió la ruta de las citas. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

## 2026-10-14

**Revisé:** 69 documentos. Ninguno cambió, así que no corrí `scan` y no recalculé ningún proyecto.

**Lo que toca hoy:** el barrido diario y la confirmación periódica. El informe de comité sale el 2026-10-26 y las peticiones no tocaban.

**Citas rotas en PRY-208:**
- 12 campos de la ficha del gerente citan `00-gobierno/2025-07-26-acta-constitucion.md` y `2026-10-14-notas-reunion.txt`.
- Esos archivos existen, pero la cita no lleva el prefijo `PRY-208-trazabilidad-del-mineral/`, y por eso el índice no la resuelve.
- No toqué la ficha. Corregir la ruta le toca a quien la escribió.

**Señales que siguen abiertas (no son novedad de hoy):**
- **PRY-210:**
  - Lleva 91 días (17,2 %) de atraso contra la línea base original, con umbral de 10 %.
  - Además, el compromiso «Entregar el punto 35» de Óscar Ramírez venció el 9 de octubre.
- **PRY-202 y PRY-206:** el hito «Licencia y permisos obtenidos» está vencido (desde el 11 y el 10 de octubre).
- **PRY-203 y PRY-208:** el avance declarado (40 % y 75 %) queda por debajo de lo que sostiene el plan (100 %), y varios hitos aparecen cumplidos sin evidencia.

**Preguntas de la confirmación:**
- Formulé cinco, una por campo, y quedan registradas como preguntadas el 2026-10-14 sin respuesta, porque esta sesión no tiene a nadie que conteste. No se repiten hasta la próxima confirmación.
- Los campos son el avance declarado de PRY-203 y de PRY-208, las licencias de PRY-202 y de PRY-206, y el compromiso vencido de PRY-210.

La salida completa está en `estado/portafolio/corridas/salida-portfolio-wake.md`, y la corrida quedó registrada como `2026-10-14-portfolio-wake-1`. Registré como hechos solo el barrido y la confirmación.

**Vuelvo el 2026-10-15.**
