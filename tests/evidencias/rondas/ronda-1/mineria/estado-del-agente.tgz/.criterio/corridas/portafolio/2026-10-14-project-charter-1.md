# Corrida · 2026-10-14-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-201 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-14T17:54:16 · **Fin:** 2026-10-14T17:55:04 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 27 | 39 | Revisión del acta PRY-201 (2025-12-21): sin autoridad del gerente, objetivo es la solución, alcance y exclusiones sin detalle, sin supuestos/restricciones/hitos/medidor de éxito; dependencias 'ninguna' contradice el informe. No sé: proyecto excluido, cronograma, versión posterior del acta, por qué Comité de Tecnología. |

Por señal (`project-charter`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Revisé el acta de PRY-201 (Ampliación de la relavera). Está sin autoridad del gerente y con otros vacíos graves. La corrida quedó registrada con id `2026-10-14-project-charter-1`.

Los términos ya estaban aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14) y coinciden con la versión de `TERMS.md`. Existe un acta previa, del 2025-12-21, aprobada por el Comité de Tecnología. Solo hay dos documentos en la carpeta del proyecto: esa acta y el informe de avance del 2026-10-10.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no está. No hay un monto ni un tipo de cambio que Ricardo Salas pueda decidir sin comité, así que todo, incluido aceptar los equipos entregados, tiende a subir al comité.
- **Objetivo de negocio:** el acta solo dice "Entregar ampliación de la relavera", que es la solución y no una meta medible. Sin meta no hay con qué juzgar un cambio de alcance ni cerrar el proyecto.
- **Alcance y exclusiones:** el alcance es "Componente 1, 2 y 3" sin detalle. La exclusión es "lo que otro proyecto cubre", sin nombrar cuál. Con eso el 64 % de avance no se puede verificar.
- **Supuestos, restricciones, hitos y quién mide el éxito:** no existen. Del 2025-12-31 al 2026-11-16 solo constan inicio y cierre, y quedan 33 días. Sin hitos no se sabe si el 64 % va adelantado o atrasado.
- **Criterio de éxito:** "en producción y medido" no tiene cifra ni umbral.
- **Dependencias:** el acta dice "ninguna", pero el informe ya muestra dos: la ventana de parada de planta, que define Operaciones, y el acceso a la mina.
- **Comité:** no hay cadencia declarada. Además, un proyecto de Seguridad y Salud depende de un comité de Tecnología, y el acta no explica por qué.

**Del informe de avance (cifras del informe, no verificadas contra otra fuente)**
- **Estado y avance:** amarillo, 64 %.
- **Dinero:** ejecutado 39,5 % del aprobado, comprometido 76,7 % y proyección al cierre 93,6 %.
- **Hallazgo de auditoría:** sin responsable.
- **Equipos del proveedor:** entregados sin acta de recibo ni contrato en la carpeta.
- **Riesgos:** los dos abiertos no tienen probabilidad, impacto ni dueño.

Los campos que no están en ningún documento quedaron marcados como "pendiente de definir". No sé quién es el proyecto excluido, si hay cronograma o contrato fuera de la carpeta, ni si existe una versión posterior del acta.

Ofrezco llevar la definición de autoridad del gerente al comité del 2026-10-28 y pasar los supuestos a RAID. No hice ninguna de las dos, porque nadie podía confirmarlo en esta prueba.

El resultado completo está en `/home/claude/banco/ronda-1/mineria/espacio/estado/portafolio/corridas/salida-project-charter.md`.
