# Corrida · 2026-10-14-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-206

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-14T17:49:57 · **Fin:** 2026-10-14T17:50:52 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 33 | 39 | Cruce CT-353 de PRY-206: 2 de 3 entregables aceptados con acta; facturado 177.240.348 contra aceptado 111.334.766 (diferencia 65.905.582). No se pudo decir vigencia, preaviso ni vencimiento: el contrato no los declara. Compromisos de Hoyos y Cárdenas no atribuibles al proveedor. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

**Proveedores — PRY-206 Red privada LTE en mina, al 2026-10-14**

Esto sale de la configuración (términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14), la ficha de PRY-206, el cálculo del script y los documentos del proyecto: contrato CT-353, las dos actas de recibo, la factura FV-1353 y el comité del 2026-10-13.

**Automatización de Procesos Ltda., contrato CT-353**
- **Aceptados con acta:** 2 de 3 entregables. El licenciamiento del software tiene acta del 2026-07-26 y la bolsa de horas de ingeniería, del 2026-09-29. Ambas las firmó María Restrepo.
- **Pendiente:** la calibración de sensores vence el 2026-12-10, así que todavía no está atrasada.
- **Sin entregables atrasados** ni aceptados sin evidencia.

**Dónde no cuadra**
- **Facturado contra aceptado:** la factura FV-1353 es por 177.240.348 COP. Lo aceptado con acta suma 111.334.766 COP. La diferencia es 65.905.582 COP, sin entregable aceptado que la respalde. El contrato exige factura contra acta de recibo.
- **Orden de la factura:** FV-1353 es del 2026-08-27 y está radicada en cuentas por pagar. Ese día solo existía el acta del licenciamiento, porque la de la bolsa de horas llegó un mes después.
- **Qué cubre la factura:** dice «Entregables del contrato CT-353» sin desglose, así que no se sabe qué entregables incluye.

**Compromisos del comité del 2026-10-13**
- **Javier Hoyos, «Entregar el punto 20»:** prometido para el 2026-09-26, vencido hace 18 días. Ningún documento prueba la entrega.
- **Rubén Cárdenas, «Entregar el punto 36»:** para el 2026-10-29, aún abierto.
- **Quiénes son:** ninguno de los dos asistió al comité, y el acta no dice si son del proveedor. No los atribuyo al proveedor.

**Sin dato**
- **Contrato:** CT-353 no declara vigencia, fecha de terminación, renovación automática ni preaviso. Por eso no puedo decir si hay un preaviso por vencer.
- **Valor total:** el contrato tampoco trae su valor total, solo los tres montos por entregable.

**Qué haría**
Llevar al comité del 2026-10-28 los 65.905.582 COP facturados sin acta, para decidir si se retienen hasta que exista el acta de la calibración de sensores. No lo he llevado a ningún sitio: queda como oferta.

**Rigor:** las cifras vienen del script, sin recalcular a mano. No verifiqué firmas físicas de las actas.

La corrida quedó registrada como `2026-10-14-vendor-tracking-1`, con el texto completo en `estado/portafolio/corridas/salida-vendor-tracking.md`. El registro de la corrida cuenta los 13 proyectos del portafolio; el análisis de esta respuesta es solo de PRY-206.
