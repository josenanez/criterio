# Corrida · 2026-10-14-health-check-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:health-check PRY-208

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-208

**Inicio:** 2026-10-14T17:46:37 · **Fin:** 2026-10-14T17:48:52 · **Duración:** 135 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `health-check` | 13 | — | 112 | 39 | Diagnóstico de PRY-208 desde cero: 17 afirmaciones (6 sostenidas, 5 sin sustento, 6 contradichas). Dijo que no sabe: autoridad del gerente, gasto real, si hubo montaje y pruebas, fecha de cierre vigente, qué es el punto 31. El script no marca la reprogramación de Elena Duarte que sí está en las minutas. |

Por señal (`health-check`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Corrí el health-check de PRY-208 y quedó registrado en `corridas/2026-10-14-health-check-1.md`. La carpeta no permite diagnosticar el avance real.

Los términos están vigentes (v1.0, aceptados por José Francisco Ñáñez el 2026-10-14). Leí 12 documentos del 2025-07-26 al 2026-10-14: los 11 de la carpeta del proyecto y la definición de producto PRD-304. Los 12 se leyeron sin falla. De 17 afirmaciones, 6 quedaron sostenidas, 5 sin sustento y 6 contradichas.

- **Estado y avance:** el informe declara verde y 75%. El cronograma dice 5 de 5 hitos cerrados, una brecha de 25,0 puntos.
- **Hitos sin evidencia:** Ingeniería básica (372 días), Montaje e instalación (181) y Pruebas en operación (117) constan como cerrados en el cronograma, sin ningún acta de recibo. El informe dice que los equipos siguen pendientes de aceptación.
- **Proveedor:** la bolsa de horas del contrato CT-462 lleva 202 días vencida sin recibo. La factura de 289.334.112 COP cubre un solo entregable aceptado.
- **Gobierno:** patrocinador, gerente y comité son la misma persona, y ningún documento declara la autoridad del gerente. El acta y el cronograma dan fechas de cierre distintas (2026-07-21 y 2026-06-19).
- **Dinero:** las cifras de ejecución salen solo del informe del gerente. Comprometido 1.802.031.890, ejecutado 730.741.848 (22,1% del aprobado) y proyección 3.290.941.311 no tienen documento que las respalde.
- **Sin registrar:** el riesgo de que el proveedor no llegue con el equipo completo no está en ningún registro. Hay 4 compromisos abiertos, y ninguno vence hoy. Laura Vélez no puso fecha ("la otra semana") y nadie define qué es el "punto 31".

El script `compute` no marca la reprogramación de Elena Duarte (del 2026-10-31 al 2026-11-14), que sí aparece en las minutas. Lo dejé anotado en la salida y en la nota de la corrida.

No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité del 2026-10-28 con la lista de lo que falta, o llevar las contradicciones al gerente como preguntas, una por una.

La salida completa está en `estado/portafolio/corridas/salida-health-check.md`.
