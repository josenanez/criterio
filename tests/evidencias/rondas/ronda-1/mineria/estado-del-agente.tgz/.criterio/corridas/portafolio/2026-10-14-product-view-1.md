# Corrida · 2026-10-14-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view despacho de flota

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T17:57:32 · **Fin:** 2026-10-14T17:58:09 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 22 | 39 | Producto con un solo proyecto (PRY-203); sin sección de producto. Declaró no saber si los hitos se cumplieron (sin evidencia) ni a qué sirven los 7 proyectos con 'No aplica'. |

Por señal (`product-view`): `milestone_met_without_evidence` 16, `progress_vs_plan` 5, `declared_vs_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_deliverable_late` 2, `pm_vs_pmo` 2, `variance_cost` 1, `commitment_undated` 1, `variance_time` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

**Producto «despacho de flota» al 2026-10-14**

Las cifras salen del `compute` de hoy. Los términos (v1.0) quedaron aceptados por José Francisco Ñáñez el 2026-10-14.

El producto tiene un solo proyecto, PRY-203 Despacho automático de flota. No armé sección de producto porque la vista no aporta nada distinto a la del proyecto.

- **Avance:** el proyecto declara 40,0 % (estado amarillo), pero el plan sustenta 100 % porque los 4 hitos figuran como cumplidos. La brecha es de 60,0 puntos.
- **Hitos sin evidencia:** tres hitos aparecen como cumplidos sin evidencia. Son «Ingeniería básica aprobada» (365 días), «Ingeniería de detalle aprobada» (277 días) y «Montaje e instalación» (69 días).
- **Fecha del producto:** 2026-08-06, la del hito «Montaje e instalación». Ya pasó hace 69 días y el avance declarado sigue en 40 %, así que los dos datos no pueden ser ciertos a la vez.
- **Desviación en tiempo:** 32 días contra la línea base original (9,1 %, bajo el umbral de 10 %) y 0 contra la vigente.
- **Dinero:** aprobado COP 2.400.000.000, comprometido COP 1.619.833.791 y ejecutado COP 1.181.630.534 (49,2 %). La proyección es COP 2.419.828.881, 0,8 % sobre lo aprobado. Los cuatro montos están en la ficha.
- **Dependencias internas:** ninguna.
- **Proyectos sin producto declarado:** ninguno sin el campo. Siete proyectos traen «No aplica» como producto (PRY-201, 202, 205, 206, 209, 210 y 211). No traje su área dueña porque esta vista no la calcula.
- **Datos que faltan:** la ficha no tiene autoridad ni fase, y varios campos de identidad y plan vienen de una fuente de 2025-07-09, con 15 meses.

Lo que no sé: si los hitos se cumplieron de verdad, porque no hay evidencia en la carpeta, y a qué producto sirven los siete proyectos con «No aplica».

La corrida quedó registrada como `2026-10-14-product-view-1`, con la salida completa en `estado/portafolio/corridas/salida-product-view.md`.
