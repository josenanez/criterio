# Corrida del 2026-10-14 · product-business-case

? · 0 requerimientos · 39 s · 0 hallazgos

Caso armado con 1 cifra declarada (198.346) vs medida 179.966 (9,3%, bajo umbral 20%); costos, criterio de éxito y retorno sin fuente, quedan como vacíos; cruce con otros productos no posible sin fichas publicadas.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Gemelo digital (PRD-303) · borrador del 2026-10-14
**Desde:** definición del 2025-12-09 y caso de negocio del 2025-12-09 · **Cifras con fuente:** 1 de 1 (la única cifra es declarada; no hay ninguna medida que sostenga el caso)

*Términos: aceptados por José Francisco Ñáñez, v1.0, 2026-10-14 (ya en la configuración). Sesión sin interfaz: no se hicieron preguntas.*

## Qué problema resuelve, y para quién
"El segmento Gerencia no tiene gemelo digital." (`00-definicion/2025-12-09-definicion-producto.md`, sección El problema.) Segmento: Gerencia. La propuesta está escrita solo como "Propuesta principal", sin contenido. No hay criterio de éxito declarado en la definición.

Evidencia de demanda: una entrevista del 2026-08-31, "Lo necesito y hoy no lo tengo" (cliente sin nombre; `10-descubrimiento/2026-08-31-entrevistas.md`). Es una cita de un solo cliente, y no dice si ese cliente es de Gerencia.

## Qué se construye
El alcance son los requerimientos decididos. El registro formal está vacío (`estado/requirements/` sin archivos; ver `salida-product-requirements.md`). Lo único que existe es la tabla del acta del comité del 2026-10-10 (`30-decisiones/2026-10-10-comite-producto.docx`), con seis requerimientos en estado "aceptado":

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1030 (doliente Óscar Ramírez) | aceptado | Pedido por "Cliente entrevistado" |
| REQ-1031 (Gustavo Neira) | aceptado | Pedido por "Cliente entrevistado" |
| REQ-1032 (María Restrepo) | aceptado | **Nadie lo pidió** (campo "Quién lo pidió" vacío) |
| REQ-1033 (Andrés Lozano) | aceptado | Pedido por "Cliente entrevistado" |
| REQ-2018 (Jorge Medina) | aceptado | Pedido por "Cliente entrevistado" |
| REQ-2026 (Felipe Arango) | aceptado | **Nadie lo pidió**, y **sin criterio de aceptación** |

Ningún requerimiento tiene proyecto que lo ejecute (columna "Proyecto" en "—"), y la definición dice "Ninguno declarado". Los cinco con quien lo pidió remiten a una sola entrevista. Los nombres de los requerimientos son solo el ID, sin descripción. El acta se limita a "Se mantiene el plan"; no dice cuál.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 198.346 | Declarada | Caso de negocio, Camilo Beltrán | 2025-12-09 |
| volumen_mensual | 179.966 | Medida | Bodega de datos, tablero de producto | corte 2026-10-12 |
| "Retorno esperado en 24 meses" | sin valor | **Supuesta** | Ningún documento; no dice cuánto, ni en qué unidad, ni desde cuándo | sin fecha |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 198.346 | 179.966 | Caso de negocio 2025-12-09 · Tablero 2026-10-12 |

La diferencia es de 18.380 (la medida es 9,3 % menor que la declarada). Está por debajo del umbral configurado (`claim_gap_pct` = 20 %), así que no es hallazgo por umbral. Se deja dentro del caso porque son dos cifras con diez meses de distancia. Los documentos no dicen si el tablero y el caso cuentan lo mismo, ni si el producto estaba operando en diciembre de 2025. El tablero tiene un solo corte, así que no se puede hablar de tendencia.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no está en ningún documento** | — |
| Costo del equipo | no declarado | — |
| Contratos o cotizaciones | ninguno | — |

Este es el primer vacío. Sin el costo de construir lo que hay es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| "La red de la mina soporta el volumen" · declarado 2026-06-11 · marcado *verificado* | Si la red no soporta el volumen, la cifra de 198.346 no es alcanzable | Quien lo marcó verificado: no dice quién, ni con qué prueba. **No hay evidencia citada de la verificación.** |
| Que el volumen de 198.346 sea alcanzable por el producto | El retorno se cae | Nadie lo ha afirmado como supuesto; está implícito |
| Que haya retorno en 24 meses | No hay caso | Nadie; la frase no tiene cifra ni base |
| Que el segmento Gerencia sea quien pide el producto | El problema planteado no está sustentado | Nadie; el entrevistado no dice su segmento |

La definición lleva fecha 2025-12-09 pero contiene un supuesto declarado el 2026-06-11: se editó después y conserva la fecha original.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | Camilo Beltrán / el negocio |
| Qué significa "retorno esperado" (monto, unidad, base, fecha de partida) | La frase de 24 meses no se puede verificar | El negocio |
| Criterio de éxito y fecha de corte | Sin ellos el producto no se puede cerrar | Camilo Beltrán, y decide el Comité de producto |
| Qué alternativas se consideraron y qué pasa si no se hace | El comité no tiene contra qué comparar | El negocio |
| Evidencia de la verificación de la red | El único supuesto "verificado" no tiene prueba a la vista | Quien lo verificó (no identificado) |
| Descripción de la propuesta ("Propuesta principal" vacía) | No se sabe qué se construye | Camilo Beltrán |
| Proyecto que construye el producto | El caso no tiene quién lo ejecute ni cuánto cuesta | Comité de producto |
| Quién pidió REQ-1032 y REQ-2026; criterio de aceptación de REQ-2026 | Aceptados sin demanda trazada | Dolientes (María Restrepo, Felipe Arango) |
| Registro de requerimientos (vacío) | El acta del comité no está inventariada | `/criterio-product:product-setup` |
| Nombre y segmento del cliente entrevistado | Una sola cita sostiene toda la demanda | Quien hizo la ronda (Camilo Beltrán) |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito, métrica de éxito ni fecha de corte en ningún documento. El único indicador con serie es volumen_mensual y solo tiene un corte (2026-10-12). El caso no dice si 198.346 es la meta, la línea base o una proyección. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay fichas publicadas a la vista (`estado/fichas` no existe), así que el cruce formal no se pudo hacer. Como revisión parcial, en `documentos/productos/` hay otros diez productos (PRD-299 a PRD-309, sin el 303) con una cifra volumen_mensual en su caso de negocio. Ninguno coincide con 198.346, y no se puede saber desde los documentos si cuentan las mismas transacciones. Para cerrar esto hace falta que los otros productos publiquen su ficha.

## Lo que este comando no hizo
No produjo ni estimó cifras, no calculó retorno ni recuperación y no recomienda aprobar o rechazar. Decide el Comité de producto.

## Después
- Pasar los cuatro supuestos a seguimiento (**assumption-tracking**). Los tres implícitos no están en la definición.
- No corresponde `/product-charter` todavía: no hay caso aprobado ni costos.
