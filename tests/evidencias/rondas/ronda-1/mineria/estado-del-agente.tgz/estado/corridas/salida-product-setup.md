## Listo — Gemelo digital (PRD-303)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas, 2026-08-31, con una sola cita) · la definición del 2025-12-09 · el tablero de métricas del 2026-10-12 · el acta del comité del 2026-10-10. Todos legibles (el .docx lo leí extrayendo su texto). No hay transcripciones, ni tickets, ni encuestas.

**Configuración (respuestas por defecto, sesión sin interfaz):** producto Gemelo digital (PRD-303), gerente Camilo Beltrán (del caso de negocio), decide el Comité de producto (propuesta mía: el acta del comité no dice quién decide, ver abajo), estado en `estado/` (hermana de `documentos/`, fuera de la documentación), términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14. Guardada en `.criterio/producto/PRD-303/config.json`. Las rutas de fichas (`estado/fichas`) y la fecha del próximo comité son provisionales.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Gerencia no tiene gemelo digital» | Una cita: «Lo necesito y hoy no lo tengo» — «Cliente entrevistado», sin nombre ni segmento | 2026-08-31 (posterior a la definición, que es de 2025-12-09) |
| «Volumen mensual: 198.346» | Solo el propio caso de negocio. El tablero mide 179.966, por debajo de lo declarado | Declarado 2025-12-09 · medido 2026-10-12 |
| «La red de la mina soporta el volumen» (supuesto) | Solo su etiqueta «verificado»; no hay en la carpeta ninguna prueba de esa verificación | «declarado el 2026-06-11» (fecha posterior a la definición) |

### Lo que no está dicho en ninguna parte
- **La propuesta.** La definición dice «Propuesta principal» y nada más: no hay qué se construye.
- **Quién es el cliente.** Ni la definición ni la entrevista nombran persona, empresa o rol dentro de Gerencia.
- **Cómo se sabrá que funcionó.** No hay criterio de éxito.
- **Cómo se calculó 198.346.** El caso de negocio no explica el origen de la cifra ni su método.
- **El retorno.** «Retorno esperado en 24 meses»: sin monto, sin supuestos, sin fuente.
- **Quién decide.** El acta del 2026-10-10 solo registra a Camilo Beltrán como asistente; no hay presidente ni autoridad. Lo del Comité de producto es mi propuesta, no un dato del documento.
- **Qué plan se mantiene.** La decisión del comité es «Se mantiene el plan», y no hay plan en la carpeta.
- **Quién pidió REQ-1032** (aceptado, sin solicitante) **ni cómo se acepta REQ-2026** (aceptado sin criterio de aceptación ni solicitante).
- **Quién los construye.** La definición dice «Ninguno declarado» y los 6 requerimientos del acta tienen «—» en proyecto: seis aceptados, ninguno con proyecto.

### Supuestos sobre los que está escrita
Uno declarado: la red de la mina soporta el volumen. Está marcado verificado sin evidencia a la vista, y se declaró seis meses después de la definición, así que es más bien una verificación posterior que no dejó rastro. El resto de la definición no declara ningún supuesto, aunque depende de varios (que Gerencia es el segmento, que el volumen se sostiene, que el retorno llega en 24 meses).

### Cifras
No calculo la brecha entre 198.346 y 179.966: el script no la da todavía porque el registro de métricas y de requerimientos está vacío (`compute` devuelve 0 requerimientos y problema, quién, éxito y autoridad sin resolver). Los dos valores son los que lee cada documento. Cuando la serie esté registrada, el contraste sale del script y se compara contra el umbral de 20 % configurado.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hoy hay una cita de una línea.
- La serie de la métrica principal con su fuente: hay un solo punto (2026-10-12), no una serie.
- Las decisiones del comité con motivo: sin ellas un requerimiento descartado se ve igual que uno que nadie miró.
- El plan que el comité «mantiene».

### Aviso
Esto es un borrador de trabajo, no asesoría ni certificación. Verifica cada salida antes de decidir o reportar con ella; lo que no está en los documentos, Alba no lo sabe (TERMS.md v1.0, secciones 1–3).

### Lo que sigue
Corre `/product-discovery` sobre las entrevistas: ahí los temas se vuelven requerimientos con la cita de quién lo pidió, y se llena el registro que hoy está vacío.
