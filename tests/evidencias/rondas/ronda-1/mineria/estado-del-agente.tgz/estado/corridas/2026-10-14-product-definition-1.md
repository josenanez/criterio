# Corrida del 2026-10-14 · product-definition

? · 0 requerimientos · 62 s · 0 hallazgos

Definición de una línea: sin criterio de éxito, sin propuesta; demanda = una entrevista; volumen −9,3 % (bajo umbral); supuesto de red marcado verificado sin soporte; PRY-207 sin confirmar

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Definición — Gemelo digital (PRD-303) · contrastada al 2026-10-14
**Documento:** `00-definicion/2025-12-09-definicion-producto.md` y `2025-12-09-caso-de-negocio.md` · **del** 2025-12-09 (hace 309 días) · 5 afirmaciones

**Una advertencia sobre el cálculo:** `producto.py compute` corrió, pero `estado/producto.json` está vacío (sin afirmaciones, supuestos ni series), así que no entregó `claim_vs_metric` ni pudo contar nada de la definición. Lo que sigue sale de leer los documentos a mano; la única cifra que cruza lo declarado con lo medido la calculé yo, no el script, y se marca como tal.

Las cinco afirmaciones son:
1. El segmento Gerencia no tiene gemelo digital.
2. La propuesta principal (no dice cuál).
3. «La red de la mina soporta el volumen» (supuesto, marcado *verificado*).
4. volumen_mensual = 198.346.
5. Retorno esperado en 24 meses.

### Lo que la evidencia contradice
Nada que se pueda afirmar con dos fuentes que se contradigan de frente. Hay un cruce por confirmar, que no es contradicción todavía:

| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| Proyectos que lo construyen: *«Ninguno declarado»* · segmento *Gerencia* | El acta de PRY-207 «Gemelo digital de la planta» dice *«Producto asociado: gemelo digital»*, área dueña **Geología**, 9.500.000.000 COP, inicio 2025-12-09 (el mismo día de la definición). No lleva el código PRD-303. | Definición PRD-303, 2025-12-09 · Acta de constitución PRY-207, 2025-11-29 |

Si PRY-207 construye este producto, la definición no lo sabe y además cambia el segmento (Geología, no Gerencia). Si construye otro, hay dos gemelos digitales. Esto lo cruza `/product-trace`; yo no lo asumo.

### El negocio y los datos
Nada pasa el umbral (`claim_gap_pct` = 20 %).

| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 198.346 | 179.966 | −18.380 (−9,3 %), hacia abajo | Caso de negocio, 2025-12-09 · Tablero de métricas (bodega de datos), corte 2026-10-12 |

Es imprecisión, no contradicción: queda bajo el umbral. Pero ninguno de los dos documentos dice en qué unidad está el volumen ni qué se cuenta, así que ni siquiera se sabe si las dos cifras miden lo mismo. La diferencia la calculé a mano (el script no la entregó).

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses | Caso de negocio, 2025-12-09 | No hay monto, ni base, ni serie en el tablero. Nadie está midiendo lo que el negocio afirmó. |

### No está dicho en ninguna parte
- **La propuesta.** La definición dice solo «Propuesta principal»: es el título, sin contenido.
- **Para quién, más allá de «Gerencia».** No hay rol, ni cuántas personas, ni cuántas lo necesitan.
- **Qué tan grande es el problema.** Una línea: «El segmento Gerencia no tiene gemelo digital». No hay costo de no tenerlo.
- **Cuánto pagaría o qué haría el cliente.** Ninguno de los documentos lo dice.
- **El criterio de éxito.** No existe en la definición ni en el caso de negocio.
- **Quién decide.** La configuración nombra al Comité de producto; la definición no lo dice.
- **De dónde sale 198.346**, qué cuenta y a qué plazo.
- **Qué significa «retorno»** y de qué monto parte.
- **Cómo se verificó la red.** Ver más abajo.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La red de la mina soporta el volumen | Declarado el 2026-06-11 (hace 125 días). Figura como *verificado*, pero sin documento, fecha ni quién lo verificó. | Una medición de capacidad de la red contra volumen_mensual (198.346 o 179.966, y en qué unidad), con fecha y firma. Mientras no exista, es un supuesto marcado como verificado. Además, la fecha de declaración (2026-06-11) es posterior a la fecha de la definición (2025-12-09): el documento se editó sin cambiar su fecha. Lleva el umbral de 30 días rebasado si se trata como no verificado. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene gemelo digital / lo necesitan | Entrevista a «Cliente entrevistado» (una persona, sin nombre, sin segmento): *«Lo necesito y hoy no lo tengo»* | 2026-08-31 (hace 44 días) | **Débil.** Es lo que alguien dijo; no hay nadie que haya pagado, pedido formalmente o usado algo sustituto. Una sola voz. |

Dato relacionado: el comité del 2026-10-10 tiene 6 requerimientos aceptados. Cuatro dicen que los pidió «Cliente entrevistado» (REQ-1030, 1031, 1033, 2018) y dos no tienen origen (REQ-1032, REQ-2026). Es decir: **cuatro requerimientos se atribuyen a la única entrevista que existe**, y tres de ellos (REQ-1030, 1031, 1033) tienen fecha «Desde» anterior a esa entrevista (2026-06-25, 07-13, 07-30 contra 08-31). Esto es de `/product-requirements`; lo dejo anotado porque cambia cuánta demanda sostiene la definición: una conversación, no cuatro.

### Evidencia que ya envejeció
Nada pasa `evidence_stale_months` (12). La definición tiene 10 meses y la única evidencia de demanda, 44 días. El problema no es que haya envejecido, sino que casi no hay.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada que la definición diga | — | — | — | La definición no menciona datos personales, pagos, consumidor financiero ni retención de información. Eso no es un cumplimiento: el documento es de una línea y no dice qué datos ingiere el gemelo. No tengo la norma a la vista y esto debe ir a revisión jurídica si el alcance incluye datos de personas (operarios, por ejemplo). |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. **Sin él el producto no se puede cerrar**, porque el cierre se juzga contra él meses después.
- **Problema:** hay una línea; falta su tamaño y su costo.
- **Para quién:** solo el segmento; falta quién, cuántos.
- **Quién decide:** la definición no lo dice (la configuración nombra al Comité de producto).
- **La propuesta**, en blanco.
- **Proyectos que lo construyen:** «Ninguno declarado», con PRY-207 sin confirmar.
- Antes de cerrar, llenar `estado/producto.json` para que el cálculo pueda hacer su parte.

### Después
El supuesto de la red lleva 125 días declarado y sin soporte: si no se verifica, conviene convertirlo en riesgo con doliente (raid-taxonomy). La definición no está cerrada (sin criterio de éxito ni autoridad), así que no ofrezco `/product-charter`.
