# Corrida del 2026-10-14 · product-charter

? · 0 requerimientos · 34 s · 0 hallazgos

Borrador de acta para REQ-1030. Sin firma ni ficha. Vacíos: criterio medible, autoridad, patrocinador, gerente, demanda específica, evidencia del supuesto de red. Registro de requerimientos vacío; fuente única el acta del comité.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Gemelo digital (REQ-1030) · borrador del 2026-10-14
**Producto:** PRD-303 Gemelo digital · **Requerimientos:** REQ-1030

*Sesión de prueba sin interfaz. Términos (TERMS.md v1.0) aceptados por José Francisco Ñáñez el 2026-10-14. Ante la pregunta «¿seguir sin lo que falta?» tomé la respuesta sugerida: seguir y marcar cada falta como vacío del acta, sin rellenarla.*

## Verificación previa del requerimiento
| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | **Sí.** Estado «aceptado» en el acta del comité del 2026-10-10 (`30-decisiones/2026-10-10-comite-producto.docx`). |
| Criterios de aceptación verificables | **Débil.** Dice solo «se verifica en producción». No es un criterio medible. |
| Evidencia de demanda con cita | **Débil.** «Cliente entrevistado», una sola entrevista, 2026-08-31: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2026-08-31-entrevistas.md`). La cita no nombra a REQ-1030 y es posterior a su fecha «Desde» (2026-06-25). |
| Autoridad declarada en la definición | **No.** `2025-12-09-definicion-producto.md` no la dice. La configuración local nombra al «Comité de producto» como autoridad del producto, pero eso no es lo que la definición declara sobre el proyecto. |

El registro de requerimientos (`estado/requirements/`) está vacío. REQ-1030 existe solo en el acta del comité, que es la única fuente. Su título es «Requerimiento REQ-1030», sin descripción.

## Qué problema resuelve
«El segmento Gerencia no tiene gemelo digital.» (`00-definicion/2025-12-09-definicion-producto.md`, «El problema»). La propuesta dice solo «Propuesta principal». **Qué hace REQ-1030 dentro de eso no está dicho en ninguna parte.**

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| «se verifica en producción» (acta del comité, 2026-10-10) | **No está dicho.** No hay métrica, umbral ni fecha. Con esto el cierre no se podrá juzgar. |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-1030 | Requerimiento REQ-1030 (título sin descripción) | Una entrevista del 2026-08-31 (cita genérica, sin referencia al requerimiento). Doliente: Óscar Ramírez, según el acta. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-1031, REQ-1032, REQ-1033, REQ-2018, REQ-2026 | Aceptados por el comité del 2026-10-10 | No se pidieron en este acta. Esto es alcance fuera del proyecto, no una decisión sobre su mérito. |

## Gobierno
- **Patrocinador:** no está dicho en ninguna parte.
- **Gerente propuesto:** no está dicho. Camilo Beltrán es el gerente de producto (config. y definición), no se ha nombrado un gerente de proyecto. Este comando no lo nombra.
- **Comité:** Comité de producto, mensual (config.). El acta del 2026-10-10 registra un solo asistente, Camilo Beltrán.
- **Autoridad del gerente:** no está dicho.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La red de la mina soporta el volumen» (declarado el 2026-06-11) | Marcado «verificado» en la definición, **sin evidencia de cómo ni cuándo**. No puedo darlo por verificado. | Por asignar. Se propone registrarlo como riesgo del proyecto hasta que haya evidencia. Doliente: sin nombrar. |

## Cifras que el negocio declara
- `volumen_mensual`: 198.346 declarado (caso de negocio, 2025-12-09) frente a 179.966 medido (tablero, 2026-10-12). Diferencia de 9,3 %, por debajo del umbral de 20 % de la configuración. No es hallazgo. Sí es el volumen del que depende el supuesto de la red.
- El caso de negocio dice «Retorno esperado en 24 meses» sin cifra ni fuente. No lo traslado al acta.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Nada identificado | — | — | Ningún documento del producto roza datos personales, pagos ni retención. Esto no es un barrido normativo completo. No dice que no haya obligaciones. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación medible | El cierre no se puede juzgar meses después | Óscar Ramírez (doliente) con Camilo Beltrán |
| Demanda específica de REQ-1030 | Una cita genérica de 2026-08-31 se atribuye a cuatro requerimientos, y REQ-1030 se aceptó antes de ella | Camilo Beltrán |
| Autoridad del gerente | El gerente no sabrá qué puede decidir: escala todo o no escala nada | Comité de producto |
| Patrocinador | Nadie responde por el presupuesto ni por el escalamiento | Comité de producto |
| Gerente del proyecto | Sin gerente no hay dueño de la ficha | Quien tenga la autoridad para asignarlo |
| Descripción de REQ-1030 | No se sabe qué se construye | Óscar Ramírez |
| Evidencia de verificación del supuesto de red | Un supuesto «verificado» sin sustento | Camilo Beltrán |
| Presupuesto e hitos | No se declara ninguno, y el acta no los inventa | Patrocinador, cuando exista |
| Proyecto que lo ejecuta | El acta dice «—» y la definición «Ninguno declarado» | Gerente del proyecto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad: por lo que hay, el Comité de producto, sin firmante nombrado. La ficha del proyecto no se creó y se crea después de la firma.

**Qué sigue:** quien firme y asigne al gerente. Ese gerente instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
