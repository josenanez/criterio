## Trazabilidad — Gemelo digital (PRD-303) · al 2026-10-14
0 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

No hay cadena que trazar: el registro de requerimientos está vacío (`estado/requirements` no tiene ningún REQ) y `estado/producto.json` no tiene identidad ni definición cargadas. El cálculo no encontró nada que decidir, asignar ni entregar, y no se inventa una cadena.

### Sin fichas a la vista
La carpeta de fichas de la configuración (`estado/fichas`) no existe. Ninguna traza se podría dar por confirmada aunque hubiera requerimientos. Una ficha existe en `estado/PRY-208-trazabilidad-del-mineral/records/PRY-208.json`, pero ningún REQ nombra PRY-208, así que no hay traza que contrastar con ella.

Siguiente paso: registrar los requerimientos del producto (`/criterio-product:product-requirements`) y publicar las fichas de los proyectos en `estado/fichas`; después, repetir `/product-trace`.
