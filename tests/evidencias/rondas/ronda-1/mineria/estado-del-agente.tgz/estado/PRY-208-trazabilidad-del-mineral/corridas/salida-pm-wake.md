## PRY-208 Trazabilidad del mineral · 2026-10-14

**Revisé:** 11 documentos · 11 nuevos para el índice (primera corrida del barrido) · 2 minutas (2026-10-09 y 2026-10-14), ya recogidas en la ficha

Términos: aceptados en la configuración (versión 1.0, igual a TERMS.md).

### Lo que se venció solo
Nada venció. No hay compromisos vencidos, hitos vencidos ni reprogramados en el umbral (3 reprogramaciones).
Una señal abierta: el compromiso de Laura Vélez de «mandar el ajuste del presupuesto» tiene fecha `no_declarada` («la otra semana», 2026-10-14). No es una fecha; hay que pedirla en la próxima reunión.
Para tener presente: el compromiso de «entregar el punto 31» de Elena Duarte se movió una vez (31/10 → 14/11); el de Diana Molina sobre lo mismo (28/10) no se mencionó el 14 y no tiene evidencia de entrega ni de cambio de fecha.

### La reunión
Comité el 2026-10-28, en 14 días. Todavía no toca agenda (se ofrece con un día o menos). El informe toca el 2026-10-27. No hay una reunión pasada sin acta: las dos minutas existen.

### Tu ficha publicada
Se publicó hoy (`/pm-publish`); no está vieja.

Aparte: el riesgo de que el proveedor no llegue con el equipo completo sigue sin registrarse formalmente (se comentó el 14/10 y nadie lo anotó).

**Vuelvo el 2026-10-15.**
