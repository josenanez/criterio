Publiqué la ficha en `/home/claude/banco/ronda-1/mineria/espacio/documentos/proyectos/PRY-208-trazabilidad-del-mineral/00-gobierno/ficha-pm.json`, con corte al 2026-10-14.

**Lleva:** 11 campos con dato · 1 sin decir en ninguna parte (`declared.status`) · **no declara estado**: la minuta del 2026-10-14 no lo dice, y `declared.as_of` queda vacío.

**Lo más viejo que va ahí:** los 11 campos con dato (identidad, plan y dinero aprobado) vienen del acta de constitución del 2025-07-26, con 15 meses: pasa de un año. Además, `plan.end_date` es 2026-07-21, ya vencida, y la ficha no tiene hitos ni línea base.

**Antes de publicar, para que quede dicho:**
- El patrocinador y el gerente figuran como la misma persona (Gustavo Neira) según el acta; si cambió algo desde 2025, la PMO lo va a ver como contradicción.
- La ficha lee solo la minuta más reciente, la del 2026-10-09 y el acta; el resto del proyecto no se ha leído (`meta.scope_read`).
- Alerta abierta: compromiso sin fecha de Laura Vélez («Mandar el ajuste del presupuesto», «la otra semana»).
- La carpeta de gobierno ya existía; no se creó nada. No se avisó a nadie: Vera la leerá en su próximo barrido.
