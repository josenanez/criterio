# Trazabilidad del mineral (PRY-208) — semana del 2026-10-08 al 2026-10-14

**Declara el gerente:** (sin declaración) · — · —
Sesión sin interfaz: nadie respondió la pregunta de la declaración, y el comando no propone un estado por él. La línea queda en blanco a propósito.
**Sustento documental:** no evaluable. Sin declaración no hay nada que contrastar; la ficha tiene 0 fuentes de evidencia y 0 de declaración (14 sin marcar).
**Lo que el semáforo no explica:** nada calculado (sin semáforo declarado). Señal abierta: compromiso sin fecha (Laura Vélez).

## Qué cambió esta semana
No se puede comparar: el snapshot de hoy (2026-10-14) es el primero, así que `diff` devuelve 0 cambios porque no hay corrida anterior contra la cual medir. Lo siguiente es lo que la ficha recoge de las reuniones del 2026-10-09 y 2026-10-14, no un diff calculado:

| Qué | Estaba | Está |
|---|---|---|
| Elena Duarte, «Entregar el punto 31» | 2026-10-31 (prometido el 10-09) | 2026-11-14 (dijo el 10-14 que «no alcanzó») — 1 reprogramación |
| Laura Vélez, «Mandar el ajuste del presupuesto» | — | nuevo, «la otra semana», sin fecha |
| Óscar Ramírez, «Revisión con el proveedor» | — | nuevo, 2026-10-24 |
| Riesgo: el proveedor podría no llegar con el equipo completo | — | comentado el 10-14, nadie lo registró |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Fecha de cierre vigente 2026-07-21, ya pasada, sin replanificación registrada | 2026-07-21 | 85 |
| Diana Molina, «Entregar el punto 31», para 2026-10-28: no se mencionó el 10-14, sin evidencia | 2026-10-09 | 5 |
| Sin línea base registrada | — | sin dato |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | no registrada | 2026-07-21 (acta, 2025-07-26) | no calculable: sin línea base; contra hoy, la fecha ya venció hace 85 días |
| Presupuesto | COP 3.300.000.000 (aprobado) | sin dato | no calculable |

Replanificaciones: 0 registradas. Con la fecha de cierre vencida hace 85 días, que no haya ninguna es una pregunta, no una buena noticia.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha (`milestones` vacío). El cronograma `10-plan/2025-07-26-cronograma-v1.xlsx` no se ha leído.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 3.300.000.000 | sin dato | sin dato | sin dato | sin dato (es aprobado menos comprometido; no se calcula con ejecutado) |

## Abierto
**Reprogramados:** Elena Duarte, «Entregar el punto 31» — 1 vez (umbral de alerta: 3).
**Vencidos sin evidencia:** ninguno vencido hoy. En riesgo: Diana Molina (2026-10-28).
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana»).
**RAID sin movimiento:** nada sin movimiento; hay 1 riesgo dicho en reunión y no registrado (proveedor), sin probabilidad, impacto ni dueño.
**Proveedor:** la ficha no lleva entregables de proveedor. En la carpeta hay contrato CT-462, factura (2026-09-02) y actas de recibo, sin leer.

## Lo que necesito de alguien
- Gustavo Neira: declarar estado y avance.
- Laura Vélez: dar fecha al ajuste del presupuesto.
- Gustavo Neira: confirmar si la fecha de cierre del 2026-07-21 sigue vigente o se replanificó, y dónde consta.
- Quien corresponda: registrar el riesgo del proveedor con dueño.
- Elena Duarte y Diana Molina: ambas tienen «punto 31». Confirmar si es el mismo entregable.
Nada de esto excede la autoridad del gerente; no hay material de comité por ahora.

## Lo que no se sabe
**Sin dato:** estado declarado; línea base; hitos; comprometido, ejecutado y proyección; entregables de proveedor. Los 11 campos de identidad, plan y dinero de la ficha tienen 15 meses (acta del 2025-07-26).
**Silencio:** último documento hace 0 días · última reunión hace 0 días. Que haya actividad no dice nada del contenido: la ficha solo leyó 3 documentos (las dos minutas y el acta). No se han leído `20-seguimiento/` (informe de avance del 2026-09-26, actas de recibo, factura) ni el cronograma.

---
Fuente: ficha `PRY-208.json` (actualizada el 2026-10-14), corte al 2026-10-14. 1 campo declarado `not_found` (`declared.status`) más los de arriba sin dato. Términos: TERMS.md v1.0, aceptados por José Francisco Ñáñez el 2026-10-14.
