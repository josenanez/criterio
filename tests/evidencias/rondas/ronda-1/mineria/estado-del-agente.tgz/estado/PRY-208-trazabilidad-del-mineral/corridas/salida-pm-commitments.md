## Compromisos — PRY-208 Trazabilidad del mineral · al 2026-10-14

Términos (TERMS.md v1.0): ya aceptados en la configuración por José Francisco Ñáñez, 2026-10-14. Sin preguntas pendientes.

4 compromisos abiertos. Ninguno vencido, ninguno reprogramado 3 veces o más, ninguno vence esta semana. Uno sin fecha. Según `compute`: `commitments_overdue` vacío, `commitments_rescheduled` vacío (umbral: 3), `commitments_undated` con 1.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», no es una fecha y no la calculé) | 2026-10-14 · `2026-10-14-notas-reunion.txt` línea 5 |

No puede estar vencido, y por eso es el que se pierde. Se cuenta aparte.

### Abiertos con fecha (para que no se pierdan de vista)
| Quién | Qué | Para cuándo | Nota |
|---|---|---|---|
| Diana Molina | Entregar el punto 31 | 2026-10-28 | Dicho el 2026-10-09 (`30-reuniones/2026-10-09-comite-semanal.md`). No se mencionó el 2026-10-14; sin evidencia de entrega ni de cambio de fecha. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Dicho el 2026-10-14 (línea 6). |
| Elena Duarte | Entregar el punto 31 | 2026-11-14 | **Reprogramada 1 vez**: antes 2026-10-31 (2026-10-09), ahora 2026-11-14 (2026-10-14, «no alcanzó», línea 4). Por debajo del umbral de 3; es la única con historial. |

### Aparte
- «Entregar el punto 31» está a nombre de Diana Molina (10-28) y de Elena Duarte (10-31 → 11-14). Si es el mismo entregable, dos fechas distintas con dos dolientes es una contradicción; las notas no lo aclaran. Las traté como dos compromisos.
- Cerrados: ninguno. Hay actas de recibo del 2026-10-02 y 2026-10-12 en `20-seguimiento`, pero buscando «punto 31», «presupuesto» y «proveedor» en los `.md` del expediente ninguna cubre estos compromisos. Los `.pdf`, `.docx` y `.xlsx` no los leí.

### Después
Nada reprogramado 3 veces, así que no hay decisión para el comité del 2026-10-28. `/pm-publish` no hace falta: ningún compromiso cambió lo que dice la ficha.

*Borrador de trabajo (TERMS.md): verifica cada dato contra su cita antes de usarlo.*
