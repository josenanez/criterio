# Acta — PRY-208 Trazabilidad del mineral · 2026-10-14
**Asistieron:** Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-14-notas-reunion.txt` (notas de alguien, 8 líneas) · **Ausentes con tema en agenda:** no se puede decir; las notas no traen agenda.

Términos (TERMS.md v1.0): ya aceptados en la configuración por José Francisco Ñáñez, 2026-10-14. Sin preguntas pendientes; donde había que elegir tomé la respuesta sugerida.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Entregar el punto 31 | 2026-11-14 | **Reprogramado, 1 vez.** Antes 2026-10-31 (comité 2026-10-09). Cita: «lo de "entregar el punto 31" no alcanzó, se compromete para el 14/11/2026» (línea 4) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-10-24» (línea 6). Dice «queda para», no «me comprometo»: lo tomé como compromiso con fecha, pero la frase no nombra quién la hace más allá del inicio de línea |

Sigue vigente de la reunión anterior, sin mención hoy: **Diana Molina — Entregar el punto 31 — 2026-10-28** (comité 2026-10-09). Ni cerrado ni movido; sin evidencia en ningún sentido.

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana» (línea 5). «La otra semana» no es una fecha y no la calculé. Es la señal que `compute` levantó (`commitment_undated`). |

## Decisiones
Ninguna. Las notas no registran que nadie haya decidido nada.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Fecha de la próxima reunión | Las notas dicen «próxima reunión en dos semanas», sin día. La configuración tiene el comité para el 2026-10-28 | Gustavo Neira, como gerente (el acta de constitución no define su autoridad) |
| Fecha del ajuste de presupuesto | Ver «Sin fecha» | No determinable; lo fecha quien se comprometió, Laura Vélez |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | Las notas no dicen quién; dicen «se comentó» | Riesgo (algo que podría pasar, no ha pasado). Toca además al proveedor, que el acta de constitución no lista: «Dependencias declaradas: ninguna» | **No.** No hay RAID en la carpeta; la ficha lo guarda con `registered: false`, sin dueño, probabilidad, impacto ni fecha, porque no se dijeron |

## Cerrado en esta reunión
Nada. (Sección omitida: ningún documento sustenta un cierre. Hay actas de recibo del 2026-10-02 y 2026-10-12 en `20-seguimiento` que no leí; nadie las mencionó en la reunión.)

## Lo que esta reunión contradice
Nada. La reunión no cambió patrocinador, fecha de cierre ni comité. Aparte, y sin relación con la reunión: el acta de constitución fija cierre el 2026-07-21, ya pasado, y no he leído nada posterior que lo mueva.

## Sin resolver de la transcripción
- «Entregar el punto 31» aparece a nombre de Diana Molina (2026-10-28) y de Elena Duarte (antes 2026-10-31, ahora 2026-11-14). No queda claro si es el mismo entregable con dos dolientes o dos entregables. Los traté como dos compromisos distintos.
- La minuta del 2026-10-09 lista como asistentes «Gustavo Neira, Gustavo Neira», sin Diana ni Elena, que figuran con compromisos. Pudo ser un error de captura; no lo corregí.
- Línea 4: «lo de "entregar el punto 31" no alcanzó» no dice qué parte no alcanzó.
- Línea 5: quién y qué es «el ajuste del presupuesto» no tiene más contexto en las notas.

---
**Recalculado con `compute`:** 1 señal, `commitment_undated` (Laura Vélez). Sin vencidos. Elena Duarte lleva 2 fechas en el historial, por debajo del umbral de 3 reprogramaciones.

**Siguiente:** `/pm-commitments` para el seguimiento completo con lo que entró hoy. `/pm-publish` no hace falta por ahora: el acta no contradice ningún campo de la ficha.

El acta está en esta conversación y en el registro de la corrida; no la escribí en tu carpeta de reuniones. Guárdala tú si la das por buena.

*Borrador de trabajo (TERMS.md): verifica cada dato contra su cita antes de usarlo.*
