# Corrida del 2026-10-14 · pm-escalate

1 proyectos · 33 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

Escala 1 punto: acta sin autoridad declarada del gerente (pregunta cerrada A/B, recomienda A). No escalan: riesgo proveedor sin registrar, Elena (1 reprogramación), Laura sin fecha. Cierre 2026-07-21 vencido sin línea base nueva leída: vigilar, sin fecha propuesta. No corrió impact (sin días a mover); no leí cronograma ni otros proyectos. Sin preguntas interactivas.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# /pm-escalate — PRY-208 Trazabilidad del mineral · 2026-10-14

Términos (TERMS.md v1.0): ya aceptados en la configuración por José Francisco Ñáñez, 2026-10-14. Sin preguntas pendientes; no hubo tema en el argumento, así que se revisó «lo que ya está marcado como escalable».

**Lo primero: el acta no declara la autoridad del gerente.** El acta de constitución (2025-07-26) nombra al comité y el presupuesto aprobado, pero no dice qué puede decidir el gerente por su cuenta y qué no. Por la regla del comando, ese es el primer punto que escala.

## Para decisión — PRY-208 · 2026-10-14

### ¿Se fija por escrito qué puede decidir el gerente del proyecto (fechas, presupuesto, proveedor, reasignación de dolientes) y qué debe subir al Comité de Inversiones, o se mantiene sin declarar?

**Quién decide:** Comité de Inversiones, que aprobó el acta el 2025-07-26 (el acta no lo dice expresamente; lo infiero de que aprobó el presupuesto) · **Si no se decide hoy:** el próximo comité configurado es el 2026-10-28; hasta entonces cada decisión del gerente (por ejemplo la fecha del ajuste de presupuesto o un cambio de fecha de cierre) queda sin saberse si valía. No hay en los documentos una fecha límite externa; no la invento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se adenda el acta con una tabla de autoridad (umbral de COP, días de movimiento de fechas, cambios de proveedor) | Gobierno del proyecto, sin tocar el alcance técnico | Una sesión de comité (2026-10-28) | Sin costo directo; no hay cifra en los documentos |
| B. Se mantiene sin declarar; todo cambio sube al comité | Sin cambio | Cada decisión espera al comité quincenal (hasta ~14 días) | Sin cifra en los documentos |

**Recomiendo:** A, porque con B el gerente escala todo y el comité acaba discutiendo temas menores, o lo contrario: nadie sabe qué puede decidir y no escala nada.

### Lo que NO escala (dentro de la autoridad del gerente o con solución en el proyecto)
- **Riesgo del proveedor** («podría no llegar con el equipo completo para la siguiente fase», notas 2026-10-14): no escala todavía. Se registra en el RAID con dueño, probabilidad e impacto; hoy tiene `registered: false`. Escalará si el proveedor lo confirma.
- **Elena Duarte, «punto 31»**: reprogramado 1 vez (2026-10-31 → 2026-11-14), por debajo del umbral de 3. No escala.
- **Laura Vélez, ajuste del presupuesto**: sin fecha; se destraba pidiéndosela, no con un comité.

### Para vigilar, sin paquete todavía
- El acta fija cierre el **2026-07-21**, ya pasado (85 días). No hay en lo que leí una línea base nueva aprobada. El informe de avance del 2026-09-26 declara **Verde, 75%**. Si no hay cambio aprobado, eso es control de cambios y no un escalamiento, y necesita la fecha nueva que propone el gerente. **No la tengo, y no la invento.**

### A quién alcanza
No calculé el efecto con `impact`: no se está moviendo ninguna fecha todavía (el comando necesita `--days`) y no leí fichas de otros proyectos. Dependencias declaradas en el acta: «ninguna declarada», así que tampoco hay proyecto alcanzado documentado. Lo que sí hay es un proveedor mencionado en las notas sin dependencia registrada.

### Mis hitos por los que pasa
No aplica: la ficha no tiene hitos (`milestones: []`) y el cronograma `10-plan/2025-07-26-cronograma-v1.xlsx` no se leyó.

### De dónde sale esto
- Acta de constitución, `00-gobierno/2025-07-26-acta-constitucion.md`: comité, presupuesto 3.300.000.000 COP, cierre 2026-07-21, dependencias «ninguna declarada», sin sección de autoridad.
- `2026-10-14-notas-reunion.txt`, líneas 4 a 7: compromisos y riesgo del proveedor.
- `20-seguimiento/2026-09-26-informe-avance.md`: estado Verde, 75%.
- `.criterio/proyecto/PRY-208/config.json`: comité siguiente 2026-10-28.

**Qué no sé:** si existe un documento de autoridad fuera de la carpeta; si el cierre se movió por otra vía; cuánto cuesta cada opción.

*Borrador de trabajo (TERMS.md): verifica cada dato contra su cita antes de usarlo. Este comando no escala solo: llevar el paquete al comité es tuyo.*
