## Reunión de seguimiento — PRY-208 Trazabilidad del mineral · 2026-10-28
4 puntos · 28 minutos · 5 personas requeridas (Diana Molina, Elena Duarte, Laura Vélez, Óscar Ramírez, Gustavo Neira)

Términos (TERMS.md v1.0): ya aceptados en la configuración por José Francisco Ñáñez, 2026-10-14. Sin preguntas pendientes. Fecha tomada del comité configurado (`committee_next` 2026-10-28), que coincide con «próxima reunión en dos semanas» de las notas.

Primera corrida: no hay snapshot anterior (`diff` = punto de partida), así que no puedo decir qué cambió desde una reunión previa; construí la agenda sobre los compromisos y lo abierto de las minutas del 2026-10-09 y 2026-10-14.

### Lo que no se destraba solo
Nada. No hay compromisos reprogramados 3 veces ni vencidos sin evidencia (`compute`: `commitments_overdue` y `commitments_rescheduled` vacíos). **La reunión es de seguimiento y se dice así.** Lo más cercano es el punto 31, reprogramado una vez.

### Se decide hoy o se atrasa
| Qué tiene que quedar resuelto | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **«Entregar el punto 31»: ¿un entregable o dos?** Hoy está a nombre de Diana Molina (28-oct) y de Elena Duarte (31-oct, luego 14-nov). Al terminar: un solo dueño y una sola fecha, o dos entregables con nombre propio. Elena ya lo movió una vez («no alcanzó»). | Gustavo Neira, con Diana y Elena | Dos fechas con dos dolientes para lo mismo; el 14-nov nadie sabrá de cuál de las dos se habla. Diana vence el mismo día de la reunión. | 10 |
| **Fecha del ajuste de presupuesto (Laura Vélez).** «La otra semana» no es una fecha. Al terminar: día exacto dicho por Laura. | Laura Vélez | Compromiso sin fecha: no puede vencer, así que no aparece nunca en un seguimiento. | 5 |
| **Riesgo del proveedor sin registrar.** «Podría no llegar con el equipo completo para la siguiente fase»; nadie lo anotó. Al terminar: dueño, probabilidad, impacto y fecha de revisión, o decisión explícita de no registrarlo. | Gustavo Neira, con Óscar Ramírez | Queda dicho en una reunión y en ningún registro; ninguna corrida lo va a levantar. | 8 |

Fuente de los tres: `2026-10-14-notas-reunion.txt` líneas 4, 5 y 7; `30-reuniones/2026-10-09-comite-semanal.md` (tabla de compromisos).

### Vencido sin evidencia
Ninguno.

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Min |
|---|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | 5 |

Fuente: `2026-10-14-notas-reunion.txt` línea 6. Está ligada al riesgo del proveedor: que Óscar traiga el resultado de la revisión hace el punto de riesgo decidible. Si la revisión ya se hizo, entra primero en el tiempo del riesgo.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Cierre del proyecto fijado el 2026-07-21, ya pasado | El acta de constitución (2025-07-26) fija el cierre; no he leído nada posterior que lo mueva. Mover una fecha base no es del gerente solo. | Comité del 2026-10-28 (Comité de Inversiones); formularlo con `/pm-escalate` o `/pm-commitments`. Antes hay que leer el resto del expediente. |
| Estado declarado | La minuta del 2026-10-14 no trae estado; el último informe (2026-09-26) dice «Verde, 75%» con el cierre ya vencido. No lo contrasto aquí. | `/pm-report` |

### Anexo — sin cambios desde el [no hay corrida anterior]
No hay base de comparación. Fuera de la agenda por no necesitar a nadie: Diana Molina, entrega del punto 31, 28-oct (sin mención el 14-oct, sin evidencia en ningún sentido; entra en el primer punto).

### Lo que no sé
- Si «punto 31» es el mismo entregable para Diana y Elena: las notas no lo dicen.
- Si hay actas de recibo que cierren algún compromiso: leí solo los `.md`; los `.pdf`, `.docx` y `.xlsx` no.
- La minuta del 2026-10-09 lista «Gustavo Neira, Gustavo Neira» como asistentes, sin Diana ni Elena; no lo corregí.
- No puse límite de tiempo (no se pidió); 28 minutos es la suma de los puntos.

No convoqué a nadie. Después de la reunión, `/pm-minutes` sobre las notas.

*Borrador de trabajo (TERMS.md): verifica cada dato contra su cita antes de usarlo.*
