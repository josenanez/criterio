# Plan — PRY-208 Trazabilidad del mineral · borrador del 2026-10-14
**Desde:** acta de constitución del 2025-07-26 · **Criterio de éxito:** «Trazabilidad del mineral en producción y medido» (declarado, pero sin métrica ni umbral)

Términos: José Francisco Ñáñez acepta TERMS.md v1.0 (registrado en la configuración, 2026-10-14). Prueba sin interfaz: no hubo preguntas; donde había una, se tomó la respuesta sugerida.

> **Aviso de contexto.** Este es el «primer borrador» de un plan, pero el acta tiene 14 meses y la fecha de cierre comprometida (2026-07-21) ya pasó. Existe un cronograma v1 (2025-07-26) con 5 hitos, todos «cerrados». Este borrador no lo reemplaza ni lo corrige: lo usa como fuente citada y señala dónde contradice a los demás documentos.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| Alcance real: solo dice «Componente 1, 2, 3» | Ningún componente es un entregable que alguien acepte; la WBS no puede colgar de ellos. Se descompone con lo que dicen el contrato y el cronograma, y los componentes quedan en «sin definir». |
| «Fuera de alcance: lo que otro proyecto cubre» sin decir qué ni cuál proyecto | No se puede saber qué excluir; el riesgo es planificar trabajo que ya tiene dueño en otro proyecto. |
| Criterio de éxito sin métrica, línea de base ni umbral («en producción y medido») | No se puede saber cuándo el último entregable está aceptado. «Medido» ¿por quién y contra qué? |
| Autoridad no declarada; patrocinador y gerente son la misma persona (Gustavo Neira) | No hay a quién llevar una excepción distinta del propio gerente. No se sabe qué puede decidir el gerente al planificar y qué debe subir al Comité de Inversiones. |
| Dependencias: «Ninguna declarada» | Contradice lo que dicen otros documentos: hay un proveedor (CT-462) y un riesgo abierto de «ventana de parada de planta definida por operaciones» (informe 2026-09-26). Ambas son dependencias externas. |
| Objetivo del negocio de una línea («Entregar trazabilidad del mineral para Geología») | Sin beneficio esperado no hay con qué decidir recortes de alcance. |

Se siguió adelante marcándolo; ninguno de estos huecos se rellenó.

## WBS
Descomposición por entregable. «De dónde sale»: **del acta** (con cita) · **supuesto** · **sin definir**. Ningún entregable terminal del acta es aceptable tal como está escrito, por eso casi todo cae en supuesto.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Licenciamiento del software (CT-462) | Gerente del proyecto, por acta de recibo (condición de pago del contrato) | Supuesto: sale del contrato, no del acta. Recibido 2025-12-14 (acta de recibo); fecha contractual 2025-11-29 | — (ya recibido) |
| 2 | Bolsa de horas de ingeniería (CT-462) | Gerente del proyecto, por acta de recibo | Supuesto: contrato (estado «en curso», fecha 2026-03-26). La factura FV-1462 del 2026-09-02 por 289.334.112 COP dice «Entregables del contrato CT-462» sin precisar cuál | vacía |
| 3 | Ingeniería básica aprobada | Sin definir (no hay acta de recibo en la carpeta) | Supuesto: hito del cronograma v1 (línea base 2025-10-07, «cerrado») | vacía |
| 4 | Ingeniería de detalle aprobada | Gerente del proyecto (acta de recibo 2026-10-12) | Supuesto: hito del cronograma v1 (línea base 2025-12-10, «cerrado»). El acta de recibo es de 2026-10-12 | — (recibido) |
| 5 | Licencia y permisos obtenidos | Gerente del proyecto (acta de recibo 2026-10-02) | Supuesto: hito del cronograma v1 (línea base 2026-02-11, «cerrado»). Acta de recibo de 2026-10-02 | — (recibido) |
| 6 | Montaje e instalación | Sin definir (no hay acta de recibo) | Supuesto: hito del cronograma v1 (línea base 2026-04-16, «cerrado») | vacía |
| 7 | Pruebas en operación | Sin definir (no hay acta de recibo) | Supuesto: hito del cronograma v1 (línea base 2026-06-19, «cerrado») | vacía |
| 8 | Equipos entregados en campamento | Sin definir: el informe dice «pendientes de aceptación» | Supuesto: informe de avance 2026-09-26. El contrato CT-462 no lista equipos como entregable | vacía |
| 9 | Trazabilidad del mineral en producción y medida | Sin definir | Del acta (criterio de éxito), pero sin métrica | vacía |
| 10 | Componentes 1, 2 y 3 | Sin definir | Del acta, pero sin contenido | vacía |

## Orden
Sin fechas. Qué necesita qué:

- 3 (ingeniería básica) → 4 (detalle) → 5 (licencia y permisos) → 6 (montaje e instalación) → 7 (pruebas en operación) → 9 (producción y medición). Es el orden del cronograma v1; es una suposición hasta que alguien lo confirme.
- 1 (licenciamiento) y 2 (horas de ingeniería) alimentan al software y la ingeniería; de cuáles hitos dependen exactamente está **sin definir**.
- 8 (equipos) tiene que ocurrir antes de 6 (montaje). No hay documento que lo diga; es lógica del trabajo, supuesto.
- 6 y 7 dependen de la **ventana de parada de planta** (riesgo del informe del 2026-09-26), que define operaciones y no el proyecto.
- 10 no se puede ordenar: no se sabe qué son los componentes.

**Señal a revisar antes de aprobar el orden:** el cronograma v1 marca los 5 hitos «cerrado» con fecha vigente igual a la de línea base, pero las actas de recibo de los hitos 4 y 5 son de octubre de 2026 (10 y 8 meses después de lo planeado), no hay actas para 3, 6 y 7, y el informe del 2026-09-26 reporta 75% con los equipos aún sin aceptar. El cronograma v1 no es evidencia de que esos hitos estén hechos.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| El orden 3→4→5→6→7→9 del cronograma v1 sigue vigente | La secuencia y la dependencia de equipos y parada de planta cambian; hay que rehacer el orden. |
| Los entregables del contrato CT-462 son solo los dos que lista (licenciamiento y bolsa de horas) | Si hay equipos u otros entregables contractuales, falta un nodo y su aceptación. |
| «Equipos entregados» es un entregable del proyecto aunque no esté en el contrato | Si pertenece a otro contrato o proyecto, el nodo 8 sale y cambian las dependencias del montaje. |
| El gerente del proyecto es quien acepta cada entregable (así lo dicen las actas de recibo y el contrato) | Si el Comité de Inversiones o Geología deben aceptar, la cadena de aceptación es más larga. |
| Los hitos 3, 6 y 7 no tienen acta de recibo porque no están aceptados, no porque se perdió el documento | Si ya se aceptaron, el avance real es mayor al que sustenta la carpeta. |
| Hay una ventana de parada de planta que operaciones definirá | Si no se concede una, montaje y pruebas no tienen fecha posible. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Sin definir; el acta no lo dice (patrocinador/gerente: Gustavo Neira) |
| Qué cubre «otro proyecto» y cuál es | Sin definir |
| Métrica, umbral y responsable de medir «en producción y medido» | Sin definir; Geología (área dueña) o el Comité de Inversiones, según el acta, pero no está escrito |
| Quién acepta los hitos 3, 6, 7 y los equipos | Sin definir |
| Qué puede decidir el gerente y qué sube al comité | Sin definir (el acta no declara autoridad) |
| Estado actual del proyecto | El informe dice verde y 75%; la fecha de cierre del acta (2026-07-21) ya pasó. Nadie ha declarado una fecha vigente. |
| Quién es el punto 31 | «Entregar el punto 31» (Diana Molina, Elena Duarte) no remite a ningún documento de la carpeta; no se sabe a qué nodo corresponde |
| Cuál es el riesgo «proveedor no llega con el equipo completo» como entrada de plan | Dicho en la reunión del 2026-10-14 y no registrado; falta dueño, probabilidad e impacto |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a ninguna carpeta de fichas de la PMO, así que no se buscó. Es la respuesta correcta y evita una falsa precisión: no hay referencia de lo que les pasó a proyectos parecidos.

## Preguntas para el equipo
Una por cada duración vacía:

1. **Bolsa de horas de ingeniería (2):** ¿cuántas horas quedan y en cuánto tiempo se consumen? ¿Cuál entregable cubre la factura FV-1462?
2. **Ingeniería básica (3):** ¿está aceptada? ¿Dónde está el acta?
3. **Montaje e instalación (6):** ¿cuánto toma, y desde cuándo se puede empezar (equipos, parada de planta)?
4. **Pruebas en operación (7):** ¿cuánto toman y quién declara que pasaron?
5. **Equipos en campamento (8):** ¿cuándo se aceptan, quién los acepta y de qué contrato son?
6. **Trazabilidad en producción y medida (9):** ¿qué se mide, con qué umbral y cuánto tiempo hay que medirlo antes de dar el proyecto por cumplido?
7. **Componentes 1, 2 y 3 (10):** ¿qué son y quién los acepta?
8. **Cierre:** el cierre comprometido (2026-07-21) pasó. ¿Quién tiene autoridad para fijar uno nuevo y a quién se le lleva?
9. **Punto 31:** ¿a qué entregable o nodo corresponde?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (Diana Molina, Elena Duarte, Laura Vélez, Óscar Ramírez): ningún documento la trae.
- La fecha del proveedor Equipos Pesados Andinos para el equipo completo y para la bolsa de horas. En la reunión del 2026-10-14 se dijo que podría no llegar completo; la revisión con el proveedor es el 2026-10-24 (Óscar Ramírez).
- La ventana de parada de planta, que define operaciones.
- Una decisión de quién tiene autoridad para replanificar, dado que patrocinador y gerente son la misma persona.

*No se comprometió ninguna fecha. No se creó línea base. No se asignaron personas.*

## Después
Cuando el plan se apruebe: registrarlo como línea base original (la anterior es el cronograma v1) y pasar los supuestos de arriba al RAID con dueño.
