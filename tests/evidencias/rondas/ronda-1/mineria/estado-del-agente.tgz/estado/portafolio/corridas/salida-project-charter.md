Acta previa: sí, existe, del 2025-12-21 (aprobada por el Comité de Tecnología). Términos aceptados: José Francisco Ñáñez, v1.0, 2026-10-14.

## Acta — PRY-201 Ampliación de la relavera
**Estado:** existe, del 2025-12-21 (`00-gobierno/2025-12-21-acta-constitucion.docx`). Modo: revisar.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance o fechas puede decidir Ricardo Salas sin comité. | Nada de lo que ocurra en el proyecto tiene un umbral que diga "esto lo resuelve el gerente". Con 18.000 M COP aprobados, todo cambio —incluido aceptar los equipos entregados en el campamento— queda sin dueño claro de decisión y tiende a subir al Comité de Tecnología. |
| Objetivo de negocio | Hay, pero es la solución: "Entregar ampliación de la relavera para Seguridad y Salud". No dice qué problema resuelve ni con qué medida (capacidad, toneladas, plazo de vida útil, cumplimiento). | Sin objetivo medible no se puede decidir si un cambio de alcance lo protege o lo desvirtúa, ni cerrar el proyecto contra algo. |
| Alcance | Insuficiente: "Componente 1, 2 y 3", sin descripción de ninguno. | Nadie puede decir si un hallazgo de auditoría o un equipo entregado está dentro o fuera. El avance de 64 % no es verificable contra un alcance que no está definido. |
| Exclusiones | Insuficiente: "Lo que otro proyecto cubre", sin nombrar el proyecto. | La frontera con otro proyecto no se puede hacer valer ni cruzar contra otras fichas; riesgo de doble cobertura o de vacío entre proyectos. |
| Patrocinador | Cumple: María Restrepo. | — |
| Supuestos | **No hay sección.** | El informe de avance ya trae una ventana de parada de planta "definida por operaciones": eso es un supuesto/dependencia vivo que el acta nunca declaró. |
| Restricciones | **No hay sección.** | Sin restricciones declaradas (regulatorias, de parada de planta, de acceso a la mina) no hay contra qué medir una desviación. |
| Dependencias | El acta dice "Ninguna declarada". | Contradice el informe del 2026-10-10: la ventana de parada depende de Operaciones y el acceso a la mina puede bloquearse. Es una dependencia externa sin dueño ni fecha. |
| Criterio de éxito | Hay, pero no medible: "en producción y medido". No dice qué se mide, con qué umbral. | "Medido" sin cifra permite declarar éxito con cualquier resultado. |
| Quién mide el éxito | **No está.** | Sin medidor designado, el cierre lo declara el mismo gerente que reporta. |
| Hitos principales | **No hay.** Solo inicio (2025-12-31) y cierre (2026-11-16). | No existe base para medir atraso intermedio. Quedan 33 días al cierre comprometido y no hay hito contra el cual decir si 64 % es adelanto o atraso. |
| Comité y cadencia | Comité de Tecnología; cadencia no declarada. | Sin cadencia no hay fecha en que obligatoriamente se revise el proyecto. Además, un proyecto de Seguridad y Salud (relavera) aprobado por un comité de Tecnología es una asignación que conviene confirmar; el acta no la explica. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo dice "Entregar ampliación de la relavera para Seguridad y Salud", que es la solución, no el objetivo). Fuente: acta 2025-12-21.
**Alcance:** "Componente 1, 2 y 3" sin detalle. Fuente: acta 2025-12-21. Detalle pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (sin nombrar). Fuente: acta 2025-12-21. Proyecto excluido pendiente de definir.
**Patrocinador:** María Restrepo (acta 2025-12-21) · **Gerente:** Ricardo Salas (acta 2025-12-21; informe 2026-10-10)
**Autoridad del gerente:** hasta [monto pendiente de definir] y [cambios pendientes de definir] sin comité. No está en ningún documento.
**Comité al que reporta:** Comité de Tecnología (acta) · **Cadencia:** pendiente de definir
**Supuestos:** pendiente de definir (el acta no los tiene). · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Ampliación de la relavera en producción y medido" (acta) — sin métrica ni umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-12-31 y cierre 2026-11-16 (acta). Presupuesto aprobado: 18.000.000.000 COP, aprobado el 2025-12-21 (acta).

### Lo que el informe de avance (2026-10-10) muestra y el acta no cubre
- Estado declarado amarillo, avance 64 %. Ejecutado 7.110.855.022 COP = 39,5 % del aprobado; comprometido 13.804.849.851 = 76,7 %; proyección al cierre 16.853.937.302 = 93,6 %. Son cifras del informe, no verificadas contra otra fuente.
- Hallazgo de la auditoría de seguridad: sin responsable, y sin umbral del acta para saber si lo decide el gerente o el comité.
- Equipos entregados por el proveedor, pendientes de aceptación; no hay contrato ni acta de recibo en la carpeta, por lo que esa entrega no se puede dar por válida.
- Dos riesgos abiertos (vía de acceso, ventana de parada) sin probabilidad, impacto, dueño ni fecha.

### Qué no sé
Quién es el proyecto "otro" de las exclusiones; si existe un cronograma o un contrato fuera de la carpeta; por qué un proyecto de Seguridad y Salud depende del Comité de Tecnología; si hay una versión posterior del acta que no esté en la carpeta.

### Siguiente paso
El acta quedó sin autoridad declarada: ofrezco llevar esa definición al comité del 2026-10-28 como una decisión (monto y tipos de cambio que Ricardo Salas decide solo). También ofrezco pasar al registro RAID la ventana de parada de planta (supuesto/dependencia) y la dependencia con Operaciones. Respuesta tomada por defecto, sin interfaz: no ejecuté ninguna de las dos.

---
Pie de rigor: lectura del acta .docx y del informe .md del 2026-10-10, únicos documentos de la carpeta de PRY-201. Nada fue completado por inferencia; lo que no está figura como pendiente de definir. Las cifras son del informe de avance y no se contrastaron con contabilidad ni con contrato.
