# Corrida del 2026-10-14 · product-view

13 proyectos · 22 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `progress_vs_plan` | 5 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_undated` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Producto con un solo proyecto (PRY-203); sin sección de producto. Declaró no saber si los hitos se cumplieron (sin evidencia) ni a qué sirven los 7 proyectos con 'No aplica'.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Producto «despacho de flota» al 2026-10-14

Sale de las fichas en `estado/portafolio`, recalculadas hoy con `portafolio.py compute` (as_of 2026-10-14). Términos: aceptados por José Francisco Ñáñez, v1.0, 2026-10-14.

**«Despacho de flota» tiene un solo proyecto: PRY-203 Despacho automático de flota.** La vista por producto no aporta nada distinto a la del proyecto, así que no armo sección de producto. Lo que sigue es lo que sale del cálculo.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| despacho de flota | 1 (PRY-203) | 1 proyecto, 4 alertas | 2026-08-06 (PRY-203) | COP 2.400.000.000 | COP 1.619.833.791 |

**Lo que hay que ver (PRY-203):**
- Avance declarado 40,0 % (estado declarado: amarillo) contra un plan que sustenta 100 %: 4 de 4 hitos marcados como cumplidos. Brecha de 60,0 puntos, «behind».
- Tres hitos declarados cumplidos sin evidencia: «Ingeniería básica aprobada» (vencía 2025-10-14, 365 días), «Ingeniería de detalle aprobada» (2026-01-10, 277 días), «Montaje e instalación» (2026-08-06, 69 días). La ficha no tiene ninguna fuente de tipo evidencia (0 evidencia, 2 declaración, 20 sin marcar).
- Esas dos señales quedan sin explicar en el informe de avance del 2026-10-14.
- Desviación en tiempo: 32 días contra la línea base original (9,1 %), 0 contra la vigente. Un cambio aprobado de 32 días, con línea base movida; sin cambios no autorizados. Umbral configurado: 10 %.
- Dinero: ejecutado 1.181.630.534 (49,2 %), comprometido 67,5 %, proyección 2.419.828.881 (0,8 % sobre lo aprobado), disponible real 780.166.209. Los cuatro montos están en la ficha.

**Dependencias internas:** ninguna (un solo proyecto; la ficha no declara dependencias).

**Fecha comprometida del producto:** 2026-08-06, de PRY-203. Ya pasó hace 69 días, con el avance declarado en 40 %. Los dos datos no pueden ser ciertos a la vez.

**Datos que faltan:** autoridad y fase del proyecto no están en la ficha; campos de identidad y plan con fuente de 2025-07-09 (15 meses, sobre el umbral de 12).

**Proyectos sin producto declarado:** ninguno sin campo. Siete proyectos (PRY-201, 202, 205, 206, 209, 210, 211) traen «No aplica» como producto; no aparecen en este producto. No traigo su área dueña porque esta vista no la calculó.

---
Rigor: cifras copiadas de `compute`; nada estimado. Lo que no sé: si los hitos se cumplieron en la realidad (no hay evidencia en carpeta) y a qué producto sirven los siete proyectos con «No aplica».
