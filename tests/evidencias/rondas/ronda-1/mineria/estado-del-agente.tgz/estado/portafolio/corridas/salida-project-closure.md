## Cierre — Ampliación de la relavera (PRY-201) — 2026-10-14

**Sale de:** ficha `estado/portafolio/records/PRY-201.json` (actualizada 2026-10-14), recalculada con `portafolio.py compute`; acta de constitución `00-gobierno/2025-12-21-acta-constitucion.docx` e informe de avance `20-seguimiento/2026-10-10-informe-avance.md`. Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14.

**Veredicto previo: este proyecto no está para cerrarse.** Nadie ha declarado que terminó. El único informe (2026-10-10) lo reporta en **amarillo, 64 % de avance**, con fecha de cierre comprometida el **2026-11-16** (a 33 días). Lo que sigue es el estado del cierre contra lo pactado, no un acta de cierre. No se mueve la carpeta a `archivo/` ni se congela la ficha.

### Contra lo comprometido
**Criterio de éxito:** "Ampliación de la relavera en producción y medido." (acta, 2025-12-21). Está declarado, pero no tiene umbral ni medida: no dice qué se mide ni cuál valor cuenta como éxito.
**Se cumplió:** no se puede determinar. El avance declarado es 64 %, sin evidencia que lo sustente.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta lo nombra sin detalle; no hay cronograma ni hitos en la carpeta |
| Componente 2 | Sin dato | Ídem |
| Componente 3 | Sin dato | Ídem |
| Equipos del proveedor | Entregados en el campamento, pendientes de aceptación (informe 2026-10-10) | No hay contrato ni acta de recibo |

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta) | Acta, Comité de Tecnología | 2025-12-21 |

No hay cambios de alcance registrados (0 solicitudes de cambio). El acta no dice qué otro proyecto cubre lo excluido.

### Números finales
Aún no son finales; son los del corte 2026-10-10.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-11-16 | 2026-11-16 | No hay (proyecto abierto) | 0 días (0 replanificaciones) |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | Proyección 16.853.937.302 | -6,4 % (proyección bajo lo aprobado) |

Replanificaciones: 0.

Presupuesto al corte: comprometido 13.804.849.851 (76,7 %); ejecutado 7.110.855.022 (39,5 %); disponible real 4.195.150.149.

Una advertencia sobre estas cifras: el avance físico declarado es 64 % y el gasto ejecutado es 39,5 %. No se puede contrastar contra un plan porque no hay hitos. La proyección de 16.853.937.302 es una declaración del informe, no un cálculo sustentado.

### RAID al cierre
**Materializados:** el hallazgo de la auditoría de seguridad (incidencia desde 2026-10-10) y los equipos entregados sin acta de recibo (incidencia desde 2026-10-10). Los dos están abiertos, no resueltos.
**No materializados:** ninguno se puede afirmar. Los riesgos "Bloqueo de la vía de acceso a la mina" y "Ventana de parada de planta definida por operaciones" siguen abiertos, sin probabilidad, impacto, doliente ni fecha.
**Abiertos, con doliente:** ninguno tiene doliente. Las 2 incidencias y los 2 riesgos aparecen con dueño "no encontrado". Mientras no tengan nombre no están cerrados.

### Lecciones
No hay ninguna que se pueda sustentar todavía. Un aprendizaje solo entra si se ancla a un hecho documentado con fecha y efecto, y la carpeta tiene dos documentos, sin cronología de hitos ni minutas. Lo único verificable es una carencia: el acta se aprobó sin detalle de los tres componentes, sin autoridad aprobadora identificada y con un criterio de éxito sin medida. Eso es un hallazgo del cierre, no una lección sobre el efecto que tuvo.

### Sin dato
- Declaración de cierre y quién la haría (el proyecto sigue en curso).
- Cronograma e hitos (`plan.milestones` vacío); entregables por componente.
- Autoridad que aprobó el acta (`identity.authority`: no encontrada) y fase del proyecto.
- Medida del "en producción y medido".
- Contrato y acta de recibo del proveedor; monto facturado.
- Dolientes de los 2 riesgos y las 2 incidencias.
- Qué proyecto cubre lo excluido del alcance.
- Evidencia del 64 % de avance: la ficha cuenta 0 fuentes de evidencia y 2 declaraciones.

### Después
Se toma la respuesta sugerida: no se mueve a `archivo/` ni se congela la ficha, porque el proyecto sigue abierto. Se vuelve a correr `/project-closure` cuando alguien declare el cierre contra el criterio de éxito.

---
*Pie de rigor: cifras copiadas de `portafolio.py compute` (corte 2026-10-14) y de la ficha; ninguna se calculó a mano. Todo lo derivado de un solo informe de gerente y un acta está marcado como declaración, no como evidencia.*
