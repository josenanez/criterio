# Corrida del 2026-10-14 · steering-pack

13 proyectos · 64 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `progress_vs_plan` | 5 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_undated` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Paquete con 6 decisiones y 4 escalamientos. Dijo que no sabía: autoridad de decisión (13 de 13 sin encontrar), acta del comité anterior, motivo del sobrecosto de PRY-207, y probabilidad/impacto de los riesgos. Sesión sin interfaz, valores sugeridos.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (TERMS.md vigente: versión 1.0). Fichas cargadas: 13 proyectos (PRY-199 a PRY-211), cifras recalculadas hoy con `compute` (as_of 2026-10-14). Próximo comité según configuración: 2026-10-28.

# Comité de proyectos — 2026-10-28 (material preparado el 2026-10-14)
6 decisiones · 4 escalamientos · 9 de 13 proyectos con hallazgos (39 señales; 3 proyectos declarados en verde que la evidencia contradice)

## Decisiones del comité anterior
No hay acta de comité anterior en la carpeta ni decisiones registradas en las fichas, así que no se puede cerrar el ciclo previo. Dos solicitudes de cambio dicen haber sido autorizadas por «el comité» sin acta que lo respalde (PRY-203 y PRY-210, puntos 2 y 3). Es un vacío de información, no una conclusión.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios, sobrecostos y pagos en cada proyecto, y se registra en el acta de constitución?
**Proyecto:** los 13 · **Quién decide:** patrocinador de cada proyecto; el comité solo si el patrocinador lo delega por escrito · **Si no se decide hoy:** los puntos 2 a 6 se deciden sin poder comprobar que quien decide tiene la facultad.
La ficha marca la autoridad como no encontrada en 13 de 13 proyectos. El contrato de datos pide autoridad explícita y ninguna acta la trae.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada patrocinador confirma por escrito su autoridad y sus topes | Ninguno | Días, antes del comité | Ninguno directo |
| B. El comité fija una regla única de topes para todo el portafolio | Ninguno | Una sesión | Ninguno directo |
| C. Seguir sin registrar | Ninguno | Ninguno | Riesgo de decisiones sin facultad |
**Recomendación:** A antes del comité, y B si los patrocinadores no responden. Sin esto, los demás puntos quedan sujetos a verificación.

### [2] ¿Se ratifica el cambio CC-01 de PRY-203 (+32 días, 64.000.000 COP, ampliación de alcance), autorizado «por el comité» sin acta?
**Proyecto:** PRY-203 Despacho automático de flota · **Quién decide:** no verificable (autoridad no encontrada; comité declarado: Comité de Tecnología; patrocinador: Felipe Arango) · **Si no se decide hoy:** la línea base ya se movió 32 días sobre una decisión que no se puede demostrar.
Hechos: solicitud del 2026-10-11, estado aprobado. Presupuesto aprobado 2.400.000.000 COP, comprometido 1.619.833.791, proyección 2.419.828.881 (0,8 % sobre lo aprobado). Declara 40 % de avance con amarillo; el plan sostiene 100 % (4 de 4 hitos cumplidos, tres sin evidencia).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta del comité | Se amplía | +32 días ya en la línea base | +64.000.000 COP |
| B. Rechazar y volver a la línea base anterior | Se mantiene | −32 días | Sin el adicional |
| C. Ratificar solo con la evidencia de los 3 hitos «cumplidos» | Se amplía | +32 días | +64.000.000 COP, condicionado |
**Recomendación:** C. Ampliar alcance sobre tres hitos declarados cumplidos sin evidencia (el plan sostiene 100 % y el gerente declara 40 %) no se sustenta todavía; primero la evidencia, luego el acta.

### [3] ¿Se ratifica el cambio CC-01 de PRY-210 (+91 días, 182.000.000 COP, ampliación de alcance), cuya solicitud no dice qué comité lo aprobó?
**Proyecto:** PRY-210 Programa de relacionamiento comunitario · **Quién decide:** no verificable (autoridad no encontrada) · **Si no se decide hoy:** el atraso de 91 días (17,2 %) ya figura como aprobado sin respaldo.
Hechos: solicitud del 2026-10-05, aprobada. Proyección 9.159.464.688 sobre 9.500.000.000 aprobado (−3,6 %). Un compromiso vencido hace 5 días (Óscar Ramírez, «Entregar el punto 35»).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta | Se amplía | +91 días | +182.000.000 COP |
| B. Rechazar | Se mantiene | Vuelve a la línea base | Sin el adicional |
| C. Devolver para sustentar el impacto en el cronograma y ratificar luego | Pendiente | Pendiente | Pendiente |
**Recomendación:** C. Son 91 días de una sola solicitud; antes de firmarlos conviene que quien la pidió sustente el impacto en tiempo.

### [4] ¿Se autoriza un sobrecosto de PRY-207 o se pide replanificar?
**Proyecto:** PRY-207 Gemelo digital de la planta · **Quién decide:** no verificable (autoridad no encontrada) · **Si no se decide hoy:** el gerente ya declara rojo; la proyección sigue sobre el techo aprobado.
Hechos: proyección 11.790.477.110 COP contra 9.500.000.000 aprobado: 24,1 % sobre el umbral de 10 %. Comprometido 64,4 %; ejecutado 25,2 %. Avance declarado 65 %; el plan sostiene 100 % (4 de 4 hitos, dos sin evidencia). Fecha de fin en la ficha: 2026-07-28. Un compromiso vencido hace 27 días (Laura Vélez, «Entregar el punto 36»).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar el sobrecosto | Se mantiene | Sin cambio | Hasta 11.790.477.110 COP |
| B. Recortar alcance al techo aprobado | Se reduce | Por definir | 9.500.000.000 COP |
| C. Pedir replanificación con línea base nueva antes de decidir | Por definir | Por definir | Por definir |
**Recomendación:** C. No hay solicitud de cambio registrada para este sobrecosto y la ficha no trae el motivo; el comité no debe aprobar una cifra sin su solicitud.

### [5] ¿Se retiene el pago a Montajes Industriales Ltda. (PRY-211) por lo facturado sobre lo aceptado?
**Proyecto:** PRY-211 Control de polvo en vías · **Quién decide:** no verificable (autoridad no encontrada) · **Si no se decide hoy:** se paga una factura 186.961.598 COP por encima de lo aceptado.
Hechos: facturado 1.143.205.796; aceptado 956.244.198; diferencia 186.961.598 COP (montos declarados en 3 de 3 entregables). Además, «Licenciamiento del software» figura aceptado sin evidencia de recibo; «Bolsa de horas de ingeniería» lleva 35 días de atraso. El proyecto se declara verde (2026-10-11) y las señales lo contradicen.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener la diferencia hasta tener las actas de recibo | Sin cambio | Puede retrasar al proveedor | 186.961.598 COP retenidos |
| B. Pagar y exigir las actas después | Sin cambio | Ninguno | Pago anticipado de 186.961.598 COP |
**Recomendación:** A. Una factura adelantada sin aceptación documentada no se paga hasta que la evidencia exista.

### [6] ¿Se retiene el pago a Automatización de Procesos Ltda. (PRY-206) por lo facturado sobre lo aceptado?
**Proyecto:** PRY-206 Red privada LTE en mina · **Quién decide:** no verificable (autoridad no encontrada) · **Si no se decide hoy:** se paga 65.905.582 COP por encima de lo aceptado.
Hechos: facturado 177.240.348; aceptado 111.334.766; diferencia 65.905.582 COP (3 de 3 montos declarados). Hito «Licencia y permisos obtenidos» vencido hace 4 días (fecha 2026-10-10). Compromiso vencido hace 18 días (Javier Hoyos, «Entregar el punto 20»). Proyección 4,2 % sobre lo aprobado (por debajo del umbral de 10 %).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener la diferencia hasta tener las actas | Sin cambio | Puede retrasar al proveedor | 65.905.582 COP retenidos |
| B. Pagar y exigir las actas después | Sin cambio | Ninguno | Pago anticipado de 65.905.582 COP |
**Recomendación:** A, por el mismo criterio del punto 5.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | Declarado verde (2026-10-09), pero hay hito de licencias vencido 3 días (fecha 2026-10-11), avance declarado 40 % contra 67 a 100 % que sostiene el plan, y dos hitos «cumplidos» sin evidencia (197 y 100 días) | Informe del 2026-10-09 | Que el gerente corrija el estado o aporte evidencia; la licencia necesita responsable |
| PRY-208 Trazabilidad del mineral | Declarado verde (2026-09-26) contra señales de atraso; dos fechas de fin distintas: 2026-06-19 (cronograma) y 2026-07-21 (acta de constitución); un riesgo dicho en la reunión del 2026-10-14 (el proveedor podría no llegar con el equipo completo) que nadie registró; compromiso sin fecha (Laura Vélez, «Mandar el ajuste del presupuesto») | Cronograma y acta, 2025-07-26 | Fijar cuál es la fecha vigente; registrar el riesgo; fechar el compromiso |
| PRY-208 y PRY-211 | Proveedores con entregables vencidos: «Bolsa de horas de ingeniería» a 202 días (PRY-208, Equipos Pesados Andinos, vencía 2026-03-26) y a 35 días (PRY-211) | 2026-03-26 y 2026-09-09 | Que el patrocinador decida exigir, renegociar o rescindir |
| PRY-203, PRY-207, PRY-208 | Hitos «cumplidos» sin evidencia de aceptación (3, 2 y 3 respectivamente; además PRY-200, PRY-202, PRY-206, PRY-209 y PRY-211 con 2, 2, 2, 1 y 1) | Variable | Entregar las actas de aceptación o cambiar el estado del hito |

## Para conocimiento
- PRY-199 Cambio de luminarias: sin señales; 2 días sin movimiento.
- PRY-200 Mantenimiento predictivo: avance 53 % contra 67 a 100 % del plan; 2 hitos sin evidencia.
- PRY-201 Ampliación de la relavera: sin señales de umbral; comprometido 76,7 %.
- PRY-204 Monitoreo de taludes: sin señales.
- PRY-205 Sistema de gestión de seguridad: sin señales; comprometido 82,6 %, cerca del umbral de 90 %.
- PRY-209 Electrificación de equipos: un hito sin evidencia.

## Anexo
**Cifras del portafolio (compute, 2026-10-14):** 13 proyectos; 9 con alertas; 39 alertas; 0 sin línea base; 3 verdes contradichos (PRY-202, PRY-208, PRY-211); 7 productos; 0 proyectos con autoridad encontrada.

**Detalle de PRY-203:** presupuesto aprobado 2.400.000.000; comprometido 1.619.833.791 (67,5 %); ejecutado 1.181.630.534 (49,2 %); proyección 2.419.828.881.

**Contradicciones abiertas:** PRY-208, fecha de fin (2026-06-19 contra 2026-07-21); estado verde del 2026-09-26 contra las notas del 2026-10-14, que no lo repiten.

**Vacíos de información:** autoridad en 13 de 13 fichas; probabilidad, impacto, responsable y fecha de los riesgos no se encontraron en ninguna ficha; no hay acta del comité anterior; no hay solicitud de cambio asociada al sobrecosto de PRY-207; el motivo de las dos ampliaciones de alcance (PRY-203 y PRY-210) no se pudo contrastar con un acta. Las fichas de PRY-200 y PRY-201 mencionan «equipos entregados, pendientes de aceptación» sin contrato ni acta de recibo en la carpeta.

Pie: criterio-portfolio 0.3.6 · fichas aplicadas: raid-taxonomy, governance-artifacts · campos inciertos: autoridad, probabilidad e impacto de riesgos, motivo del sobrecosto de PRY-207 · términos: TERMS.md versión 1.0.
