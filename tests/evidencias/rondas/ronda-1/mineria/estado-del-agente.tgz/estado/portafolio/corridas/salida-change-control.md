Ficha de origen: estado/portafolio/records/PRY-206.json (actualizada 2026-10-14; informe de avance del 2026-09-27).
Términos: aceptados por José Francisco Ñáñez, v1.0, 2026-10-14.

## Solicitud de cambio — PRY-206 Red privada LTE en mina — 2026-10-14

**Qué se pide:** mover 30 días la salida a producción. Se lee como el hito «Pruebas en operación» y el cierre: 2027-01-27 → 2027-02-26. La ficha no tiene un hito llamado «salida a producción»; confirmar que es ese.
**Quién lo pide:** no consta en la solicitud. La gerente del proyecto es María Restrepo; el patrocinador es Beatriz Cuéllar.
**Por qué:** no consta. La ficha sí registra que «las lluvias detuvieron el montaje durante diez días» (informe del 2026-09-27) y que el hito «Licencia y permisos obtenidos» (2026-10-10) sigue pendiente. Ninguno de los dos documentos dice que sea la causa de este cambio.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (sin detalle) | Sin declarar | Sin cambio declarado |
| Tiempo | Cierre 2027-01-27 (línea base 1, única) | 2027-02-26 | +30 días |
| Costo | Aprobado 800.000.000 COP; proyección 833.931.534 COP | Sin declarar | No calculable con la ficha |

- **Alcance sin cambio declarado:** si el alcance no cambia y el cierre se mueve 30 días, alguien absorbe la diferencia en horas no pagadas o en calidad. Hay que preguntarlo.
- **Costo sin cambio declarado:** mover 30 días casi nunca cuesta cero (equipo, proveedor, gestión). La ficha no trae costo por día, así que no se estima.
- **Ya hay sobrecosto antes del cambio:** la proyección supera lo aprobado en 33.931.534 COP (4,2 %), por debajo del umbral de 10 % de la configuración.
- **Hitos que pasa el cambio** (el script no dice cuántos días se mueve cada uno, porque eso necesita holgura por actividad):
  - Montaje e instalación, 2026-12-03.
  - Pruebas en operación, 2027-01-27.
- **Proveedor CT-353:** el entregable pendiente «Calibración de sensores» vence el 2026-12-10, y el proveedor aún no confirmó la fecha de la última entrega (riesgo en el informe). No consta si el contrato admite el corrimiento; no leí el contrato para esta corrida.

### Efecto en el portafolio
Ningún proyecto queda alcanzado: el cálculo da 0 proyectos alcanzados, 0 que no puedan sostener su fecha y 0 dependencias sin confirmar. Esto **no significa que nadie dependa de PRY-206**. La ficha tiene `dependencies: []`, o sea que ninguna dependencia está declarada. Si existe alguna sin declarar, este cálculo no la ve.

| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno por dependencias declaradas | — | María Restrepo (el propio proyecto) |

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta (2026-04-19) no declara autoridad de cambio (`identity.authority: not_found`). Este es el hallazgo de fondo.
**Según:** acta de constitución del 2026-04-19; el aprobador de la línea base 1 fue el Comité Ambiental.
**Va a comité:** sí, por defecto. Sin autoridad declarada no hay umbral que permita a la gerencia aprobarlo sola. El próximo comité es el 2026-10-28.

### Si no se aprueba
El proyecto sigue con cierre 2027-01-27 y estado declarado amarillo (68 % de avance al 2026-09-27). Ya tiene en contra un hito de permisos vencido desde el 2026-10-10 sin evidencia de cumplimiento, diez días de montaje perdidos por lluvia y un hallazgo de seguridad sin responsable. El cierre actual queda en riesgo sin que la línea base lo refleje.

### Si se aprueba
Línea base 2 — cierre 2027-02-26 · presupuesto: sin definir (hoy 800.000.000 COP aprobados) · motivo: pendiente; hay que escribirlo y citar el documento que lo aprobó.
Desviación acumulada contra la línea base original: tiempo +30 días · costo: sin dato (la proyección actual ya es +33.931.534 COP sobre lo aprobado, y el cambio no la actualiza).
La línea base 1 no se toca. El conteo de replanificaciones pasa de 0 a 1.

### Lo que esta corrida no sabe
- Quién pide el cambio y por qué.
- Costo del corrimiento.
- Si hay dependientes no declarados.
- Si el contrato CT-353 permite mover las fechas.
- Qué es exactamente «salida a producción».
- Cuántos días se mueve cada hito intermedio.

Siguiente paso: llevarlo al comité del 2026-10-28 con motivo y costo escritos, o registrar la línea base 2 cuando lo apruebe quien tenga autoridad. Antes, que el acta declare quién decide.

Rigor: cifras de la ficha y del script `impact`; nada estimado. Los vacíos están nombrados arriba.
