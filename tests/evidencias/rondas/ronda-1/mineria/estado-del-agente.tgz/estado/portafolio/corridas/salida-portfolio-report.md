# Portafolio — 2026-10-14
Fichas cargadas: 13 (`estado/portafolio/records/`, PRY-199 a PRY-211), todas con documentos de los últimos 8 días (silencio máximo: 8 días, umbral 15). Términos v1.0 aceptados por José Francisco Ñáñez el 2026-10-14.
13 proyectos · 9 con hallazgos (39 alertas) · 3 en verde contradichos por la evidencia · último barrido 2026-10-14

## Qué cambió desde la corrida anterior
Sin cambios: la única instantánea (2026-10-14) es de hoy, así que este es el punto de partida y no hay delta.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-208 | plan.end_date | 2026-06-19 | 10-plan/2025-07-26-cronograma-v1.xlsx | 2026-07-21 | 00-gobierno/2025-07-26-acta-constitucion.md (misma fecha, sin cuál sea más nuevo) |
| PRY-208 | declared.status | verde | 20-seguimiento/2026-09-26-informe-avance.md | no se encuentra | 2026-10-14-notas-reunion.txt (más nueva) |

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-202 | Licencia y permisos obtenidos | 2026-10-11 | 3 | pendiente |
| PRY-206 | Licencia y permisos obtenidos | 2026-10-10 | 4 | pendiente |

Además, hitos declarados "cumplidos" sin evidencia documental: PRY-200 (2), PRY-202 (2), PRY-203 (3), PRY-206 (2), PRY-207 (2), PRY-208 (3), PRY-209 (1), PRY-211 (1). Ver `reportes/index.html`.

## Proyectos en silencio
Vacía: ningún proyecto supera 15 días sin documentos (el máximo es PRY-205, 8 días).

## Dependencias en riesgo
Vacía: el script no detectó dependencias declaradas por código que se hayan roto.

## Sin sustento
Tres proyectos declaran verde y la evidencia no lo sostiene:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-202 | verde (2026-10-09) | hitos cumplidos sin evidencia, hito vencido, avance 27 puntos bajo el plan |
| PRY-208 | verde (2026-09-26) | hitos sin evidencia, avance 25 puntos bajo el plan, entregable de proveedor 202 días tarde |
| PRY-211 | verde (2026-10-11) | hito sin evidencia, entregable tarde, facturado por encima de lo aceptado |

También hay avance declarado por debajo de lo que el plan sostiene en PRY-200 (53% vs 67–100%), PRY-203 (40% vs 100%, 60 puntos) y PRY-207 (65% vs 100%).

## Vacíos de información
- Compromisos sin fecha: PRY-208, Laura Vélez, "Mandar el ajuste del presupuesto".
- Compromisos vencidos: PRY-206 Javier Hoyos (18 días), PRY-207 Laura Vélez (27 días), PRY-210 Óscar Ramírez (5 días).
- Proveedores: PRY-206 Automatización de Procesos facturó 177.240.348 contra 111.334.766 aceptado (+65.905.582); PRY-211 Montajes Industriales facturó 1.143.205.796 contra 956.244.198 aceptado (+186.961.598), y un entregable "aceptado" sin evidencia; PRY-208 y PRY-211 con "Bolsa de horas de ingeniería" pendiente (202 y 35 días tarde).

## Estado general
| Proyecto | Desviación vs original | vs vigente | Replanificaciones | Otras señales |
|---|---|---|---|---|
| PRY-203 | +32 días | 0 | 1 | avance muy bajo el plan |
| PRY-207 | 0 | 0 | 0 | costo proyectado +24,1% (11.790 M vs 9.500 M aprobados) |
| PRY-210 | +91 días (17,2%, sobre umbral 10%) | 0 | 1 | compromiso vencido |
| PRY-199, 201, 204, 205 | 0 | 0 | 0 | sin hallazgos |
| Resto | 0 | 0 | 0 | ver secciones anteriores |

## Necesito que confirmes
Este mes toca confirmación (mensual, 5 campos), pero la sesión es de prueba sin interfaz: no se formularon preguntas.

---
Archivos (en `reportes/`): `index.html` — vista por campo con cadena de evidencia, para quien actúa (gerente de PMO, gerentes de proyecto); `decisiones.html` — vista por decisión, para el patrocinador y el comité del 2026-10-28; más una página por proyecto y por producto. El PDF sale de imprimir el HTML.
Pie: criterio-portfolio v0.1 · fichas aplicadas: 13, fecha 2026-10-14 · campos inciertos: 2 contradicciones en PRY-208, 1 compromiso sin fecha · términos: TERMS.md v1.0.
Nota: la configuración trae `report.format: pptx`; se usó `html` porque se pidió en la invocación.
