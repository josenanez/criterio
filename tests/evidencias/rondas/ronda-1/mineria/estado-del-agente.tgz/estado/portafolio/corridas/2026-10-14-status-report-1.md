# Corrida del 2026-10-14 · status-report

13 proyectos · 19 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `progress_vs_plan` | 5 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_undated` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Informe de PRY-202: verde declarado contradicho por hito vencido, 2 hitos cumplidos sin evidencia y avance 27 puntos bajo el plan. Sin dato: autoridad, fase, última reunión.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Fuente: ficha PRY-202 (record_updated 2026-10-14) y salida de `compute` con fecha de corte 2026-10-14. Términos aceptados: v1.0, José Francisco Ñáñez, 2026-10-14.

## PRY-202 · Planta de tratamiento de agua — estado al 2026-10-14

**Declara el gerente (Camilo Beltrán):** verde · 40% · al 2026-10-09 (declaración de 5 días)
**Sustento documental:** contradicho. No hay ninguna fuente marcada como evidencia (evidence: 0; declaración: 2; sin marcar: 18).
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `progress_vs_plan`
**Último documento:** 2026-10-09 (5 días de silencio; umbral 15) · **Última reunión:** sin dato (la ficha no registra actividad de reuniones)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-11 | 2026-10-11 | 0 días contra original y contra vigente |
| Presupuesto | 800.000.000 COP | 800.000.000 COP | Proyección 749.320.132 COP (-6.3% sobre lo aprobado) |

Presupuesto: comprometido 344.010.782 (43.0%), ejecutado 278.347.648 (34.8%), disponible real 455.989.218 COP.

Replanificaciones: 0. La fecha de cierre (2026-10-11) ya pasó y el proyecto declara 40%.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-03-31 | 2026-03-31 | cumplido (declarado) | ninguna: cumplido sin evidencia, 197 días |
| Ingeniería de detalle aprobada | 2026-07-06 | 2026-07-06 | cumplido (declarado) | ninguna: cumplido sin evidencia, 100 días |
| Licencia y permisos obtenidos | 2026-10-11 | 2026-10-11 | pendiente, vencido 3 días | ninguna |

### Dónde no coincide
- El informe de avance del 2026-10-09 declara verde y 40%. El cronograma v1 (2025-12-15) tiene 2 de 3 hitos cumplidos, lo que sostiene entre 67% y 100%: el avance declarado queda 27.0 puntos por debajo del plan (`progress_vs_plan`, dirección «behind»). Dos lecturas posibles: el avance está subdeclarado o los hitos «cumplidos» no lo están; la ficha no permite decidir cuál.
- Verde, con el hito de licencias y permisos vencido 3 días (`milestone_overdue`) y con los dos hitos cumplidos sin ningún documento de recibo (`milestone_met_without_evidence`). Alerta `declared_vs_evidence` abierta.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: bloqueo de la vía de acceso a la mina. Sin probabilidad, impacto, dueño ni fecha. Último movimiento 2026-10-09.
- Incidencia: el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite. Desde 2026-10-09, sin dueño.
- Incidencia: reprogramación de la parada de planta por la ventana de mantenimiento. Desde 2026-10-09, sin dueño.
**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad del gerente (`identity.authority`) y fase (`identity.phase`): no encontradas. Sin autoridad no se puede juzgar si el riesgo y las incidencias exceden al gerente.
- Última reunión, compromisos y proveedores: la ficha no los trae.
- Cambios aprobados: ninguno registrado.

### Después
No hay desviación de fecha ni de costo sobre el umbral (10%), pero sí un hito vencido, un verde sin sustento y un cierre planeado ya cumplido con 40% de avance declarado. Puedo preparar el punto de comité (próximo: 2026-10-28). No hay cambio no formalizado que justifique una solicitud de cambio.

---
Pie: Criterio portfolio · ficha PRY-202 actualizada 2026-10-14 · campos inciertos: identity.authority, identity.phase · Términos: TERMS.md v1.0 (2026-09-18). Borrador de trabajo: verifícalo antes de decidir.
