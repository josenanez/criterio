**Fuentes y fecha:** ficha PRY-207 (actualizada 2026-10-14), construida sobre `20-seguimiento/2026-10-13-informe-avance.md` (corte 2026-10-13), `00-gobierno/2025-11-29-acta-constitucion.docx`, `10-plan/2025-11-29-cronograma-v1.xlsx` y `30-reuniones/2026-10-09-comite-semanal.md`. Cifras derivadas copiadas de `portafolio.py compute` con fecha 2026-10-14. Términos aceptados por José Francisco Ñáñez (v1.0, 2026-10-14).

## Presupuesto — PRY-207 Gemelo digital de la planta al 2026-10-14
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 9.500.000.000 | — | Informe de avance (declaración) | 2026-10-13 |
| Comprometido | 6.116.727.959 | 64.4% | Informe de avance (declaración) | 2026-10-13 |
| Ejecutado | 2.397.804.823 | 25.2% | Informe de avance (declaración) | 2026-10-13 |
| Proyección al cierre | 11.790.477.110 | 24.1% por encima del aprobado | Informe de avance (declaración) | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 3.383.272.041 COP

Las cuatro cifras salen de un solo documento, el informe de avance del gerente. Ninguna tiene respaldo en un documento de evidencia (contrato, factura, extracto contable): la ficha cuenta 0 fuentes de evidencia para este proyecto. La proyección es una declaración de la misma fecha del informe; no es más vieja que el último movimiento de presupuesto (no hay ninguno registrado).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | no declarado como línea base | 9.500.000.000 COP (informe 2026-10-13) | no calculable |
| Proyección vs aprobado | — | 11.790.477.110 vs 9.500.000.000 | 24.1% (umbral 10%) |

Replanificaciones de presupuesto: 0 registradas (ninguna solicitud de cambio en la ficha). Existe una sola versión de línea base, la de cronograma del 2025-11-29; ningún documento fija el presupuesto original, así que no se puede decir si 9.500.000.000 es el monto original o uno ya modificado.

### Ejecución frente a avance
Ejecutado 25.2% · Hitos cumplidos 4 de 4 (declarados) · Avance declarado 65%.
Lectura: la ejecución está muy por debajo del avance declarado y de los hitos. Dos explicaciones posibles, que los documentos no permiten distinguir: trabajo hecho y no causado (aparecerá de golpe), o hitos y avance sobrestimados. Hay base para la segunda duda: de los 4 hitos "cumplidos", 2 no tienen acta de recibo (Ingeniería de detalle aprobada, vencida el 2026-04-03; Montaje e instalación, vencido el 2026-07-28). Además, el plan terminaba el 2026-07-28 y el proyecto sigue en curso con 65% declarado y sin replanificación registrada; el plan sostiene 100% y el gerente declara 65%, una brecha de 35 puntos.

### Alertas
- **Proyección por encima del aprobado:** 24.1%, sobre el umbral de 10%. Es la señal principal.
- **Comprometido:** 64.4%, por debajo del umbral de 90%. Sin alerta; el disponible real es 3.383.272.041 COP, pero la proyección dice que no alcanzará.
- **Ejecución desalineada del avance:** 25.2% ejecutado contra 65% de avance declarado y 4/4 hitos.
- El informe del gerente declara el proyecto en rojo y no explica la proyección ni la brecha de avance.

### Sin dato
- Presupuesto original (línea base de costo) y fecha de su aprobación.
- Respaldo de evidencia de comprometido y ejecutado (contratos, facturas, causaciones). No hay proveedores registrados en la ficha.
- Fecha y autor de cualquier movimiento de presupuesto.
- Autoridad que aprueba y fase del proyecto (campos no encontrados en la ficha).

### Qué sigue
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). El comprometido no está cerca del tope, así que no corresponde el detalle por proveedor; además la ficha no registra proveedores.

---
**Pie de rigor:** todo lo anterior es lo que declara un solo informe del gerente; nada fue contrastado con evidencia contable. Las cifras derivadas vienen del script y los porcentajes no se redondearon por mi cuenta. No se convirtió moneda.
