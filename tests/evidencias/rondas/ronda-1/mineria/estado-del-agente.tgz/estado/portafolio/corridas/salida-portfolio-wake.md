## 2026-10-14

**Revisé:** 69 documentos · 0 cambiaron · 0 proyectos recalculados (no se corrió scan: nada que releer)

### Lo que cruzó un umbral
Nada nuevo por cambio de documentos: el barrido no encontró documentos nuevos, cambiados, renombrados ni borrados. Lo que sigue abierto en el cálculo vigente (no es novedad de hoy):
- **PRY-210** — atraso de 91 días (17,2 %) contra la línea base original, umbral 10 %. Compromiso vencido: Óscar Ramírez, «Entregar el punto 35», vencía el 2026-10-09 (`30-reuniones/2026-10-05-comite-semanal.md`).
- **PRY-202** — hito «Licencia y permisos obtenidos» vencido hace 3 días (2026-10-11). **PRY-206**, el mismo hito, vencido hace 4 días (2026-10-10).
- **PRY-203** y **PRY-208** — avance declarado (40 % y 75 %) por debajo de lo que sostiene el plan (100 %), con hitos declarados cumplidos sin evidencia.

### Hallazgo del índice: citas que no resuelven (PRY-208)
12 campos de la ficha del gerente (`pm_record`: identidad, plan, dinero y estado declarado) citan `00-gobierno/2025-07-26-acta-constitucion.md` y `2026-10-14-notas-reunion.txt`. Ambos archivos existen en la carpeta del proyecto, pero la cita está escrita sin el prefijo `PRY-208-trazabilidad-del-mineral/`, así que el índice no la resuelve. No toqué la ficha: corregir la ruta es de quien la escribe.

### Peticiones atendidas
No tocaba `requests` hoy. No las consulté.

### Preguntas (confirmación: cinco campos, sin respuesta en esta sesión)
Esta sesión no tiene interfaz y nadie responde; quedan preguntadas hoy, 2026-10-14, y no se repiten hasta la próxima confirmación:
1. **PRY-203, avance declarado 40 %:** el plan tiene 4 de 4 hitos cumplidos. ¿Cuál de los dos números está desactualizado?
2. **PRY-208, avance declarado 75 %:** 5 de 5 hitos cumplidos; «Ingeniería básica aprobada» (vencía 2025-10-07) figura cumplido sin acta de recibo. ¿Dónde está el acta?
3. **PRY-202, «Licencia y permisos obtenidos»:** vencido desde el 2026-10-11. ¿Nueva fecha y motivo?
4. **PRY-206, «Licencia y permisos obtenidos»:** vencido desde el 2026-10-10. ¿Nueva fecha y motivo?
5. **PRY-210, compromiso «Entregar el punto 35»:** vencido desde el 2026-10-09. ¿Se entregó? ¿Hay documento?

**Vuelvo el 2026-10-15.**
