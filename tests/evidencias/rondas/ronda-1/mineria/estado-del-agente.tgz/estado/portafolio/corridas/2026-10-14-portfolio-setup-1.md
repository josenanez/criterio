# Corrida del 2026-10-14 · portfolio-setup

3 proyectos · 69 documentos, 45 releídos y 24 sin cambio · 101 s · 18 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 8 |
| `progress_vs_plan` | 3 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_overdue` | 1 |
| `commitment_undated` | 1 |
| `vendor_deliverable_late` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (sesión sin interfaz, valores sugeridos); primer resultado en unos 15 pasos de conversación; 3 proyectos leídos (PRY-203, PRY-208, PRY-207), 18 señales, 1 verde contradicho (PRY-208)

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos mineros

**Miré:** 69 documentos en 13 proyectos · formatos: .md (28), .docx (14), .pdf (13), .xlsx (8), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-14
**Eres:** PMO del portafolio (13 proyectos)
**Te aviso:** dos días antes del comité del 2026-10-28, y cada dos semanas desde ahí (valor sugerido: no hubo a quién preguntarle la fecha real)
**En:** presentación (valor sugerido)
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-14 (prueba sin interfaz).
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/portafolio` (`estado/` ya tenía datos de producto y de un proyecto, y no los mezclé); informes en `reportes`.

### Probé con tres proyectos

Los de documentación más reciente: PRY-203, PRY-208 y PRY-207 (24 documentos).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-203 Despacho automático de flota | 7 | Gerente Óscar Ramírez, patrocinador Felipe Arango. Declara amarillo y 40 %. Presupuesto 2.400 M COP; proyección 2.419,8 M (+0,8 %). Cambio CC-01: +32 días y +64 M COP. | Facultad del gerente, fase, proveedor del contrato, acta del comité que autorizó CC-01. |
| PRY-208 Trazabilidad del mineral | 11 | Gerente y patrocinador son la misma persona (Gustavo Neira). Declara verde y 75 % (corte 2026-09-26). Presupuesto 3.300 M COP; proyección 3.290,9 M (−0,3 %). Contrato CT-462 con Equipos Pesados Andinos, 289,3 M facturados. | Facultad del gerente, fase, estado declarado en las notas del 2026-10-14. |
| PRY-207 Gemelo digital de la planta | 6 | Gerente Jorge Medina, patrocinadora Sandra Gil. Declara rojo y 65 %. Presupuesto 9.500 M COP; proyección 11.790 M (+24,1 %). | Facultad del gerente, fase, nombre del proveedor que no confirmó la entrega. |

### Lo que levantó el cálculo
Estas son las señales que levantó `compute`, con el nombre que les da portfolio-health. No agrego ninguna por lectura propia.

**PRY-208 (9 señales)**
- `declared_vs_evidence`: declara verde (2026-09-26) y los documentos muestran tres hitos sin acta, avance por debajo de lo que sostiene el plan y un entregable del proveedor atrasado.
- `milestone_met_without_evidence`: Ingeniería básica (2025-10-07), Montaje e instalación (2026-04-16) y Pruebas en operación (2026-06-19) se declaran cerrados y no hay acta de recibo.
- `progress_vs_plan`: declara 75 % y el cronograma tiene 5 de 5 hitos cerrados (25 puntos de diferencia).
- `vendor_deliverable_late`: la bolsa de horas de ingeniería de Equipos Pesados Andinos venció el 2026-03-26 (202 días) y sigue pendiente.
- `commitment_undated`: Laura Vélez, ajuste del presupuesto, «la otra semana».
- `pm_vs_pmo` (2): fecha de cierre (el acta dice 2026-07-21 y el cronograma 2026-06-19) y estado declarado (la ficha del gerente dice `not_found`).

**PRY-207 (5 señales)**
- `variance_cost`: la proyección supera el aprobado en 24,1 %.
- `commitment_overdue`: Laura Vélez, punto 36, venció el 2026-09-17 (27 días).
- `milestone_met_without_evidence`: Ingeniería de detalle y Montaje e instalación.
- `progress_vs_plan`: declara 65 % con 4 de 4 hitos cerrados.

**PRY-203 (4 señales)**
- `milestone_met_without_evidence`: Ingeniería básica, Ingeniería de detalle y Montaje e instalación.
- `progress_vs_plan`: declara 40 % con 4 de 4 hitos cerrados.
- El cambio CC-01 (+32 días) quedó reflejado en el cronograma v2 y no levantó señal.

Total: 18 señales en 3 proyectos. Un proyecto en verde contradicho por sus documentos (PRY-208).

### El portafolio completo
10 proyectos más (45 documentos), en un lote. Aproximadamente 20–30 minutos, en una sola conversación y uno tras otro (estimación mía, no medida).

### Lo que le falta a tu carpeta
Ninguno de estos puntos bloquea el análisis.
- Casi todos los hitos se declaran cerrados sin acta de recibo.
- Ningún proyecto declara la facultad del gerente para decidir sin subir a comité.
- Las actas de constitución no dicen la fase.
- Hay compromisos de comité con responsables que no asistieron (PRY-203, PRY-207) y compromisos sin fecha (PRY-208).
- PRY-208 tiene la misma persona como patrocinador y gerente.
- La autorización de CC-01 (PRY-203) dice «Autorizada por el comité» y ningún acta de comité la respalda.
- Los nombres de archivo ya traen fecha (AAAA-MM-DD), y eso ayudó.
- PRY-208 tiene una ficha del gerente (`ficha-pm.json`) que se conservó aparte, sin mezclarla con la mía.

**Siguiente paso:** ¿corro el portafolio completo? También puedo publicar el estándar en una carpeta compartida para que tus gerentes de proyecto usen los mismos criterios.
