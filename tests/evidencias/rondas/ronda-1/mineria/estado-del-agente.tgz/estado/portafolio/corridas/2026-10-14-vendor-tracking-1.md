# Corrida del 2026-10-14 · vendor-tracking

13 proyectos · 33 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `progress_vs_plan` | 5 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_undated` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Cruce CT-353 de PRY-206: 2 de 3 entregables aceptados con acta; facturado 177.240.348 contra aceptado 111.334.766 (diferencia 65.905.582). No se pudo decir vigencia, preaviso ni vencimiento: el contrato no los declara. Compromisos de Hoyos y Cárdenas no atribuibles al proveedor.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

**Sale de:** `config.json` (términos 1.0 aceptados por José Francisco Ñáñez, 2026-10-14), la ficha `records/PRY-206.json`, la salida de `compute` al 2026-10-14 y los documentos de PRY-206: contrato CT-353 (2026-04-18), acta de recibo del licenciamiento (2026-07-26), factura FV-1353 (2026-08-27), acta de recibo de la bolsa de horas (2026-09-29) y comité semanal (2026-10-13).

## Proveedores — PRY-206 Red privada LTE en mina al 2026-10-14

### Automatización de Procesos Ltda. — contrato CT-353
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato
Condición de pago (contrato): cada entregable se factura contra acta de recibo firmada por el gerente del proyecto.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (55.667.383 COP) | 2026-07-13 | Aceptado | Acta de recibo 2026-07-26, recibida por María Restrepo (`20-seguimiento/2026-07-26-acta-recibo-ct-353-licenciamiento-del-software.md`) | Dentro de FV-1353 (sin desglose) |
| Bolsa de horas de ingeniería (55.667.383 COP) | 2026-09-26 | Aceptado | Acta de recibo 2026-09-29, recibida por María Restrepo (`20-seguimiento/2026-09-29-acta-recibo-ct-353-bolsa-de-horas-de-ingeniería.pdf`) | Dentro de FV-1353 (sin desglose) |
| Calibración de sensores (55.667.383 COP) | 2026-12-10 | Pendiente (el contrato dice «en curso») | Ninguna; aún no vence | No consta |

Resumen del script: 3 entregables, 2 aceptados, 0 atrasados, 0 aceptados sin evidencia, montos declarados 3 de 3.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado contra aceptado | Se factura cada entregable contra acta de recibo | Facturado 177.240.348 COP; aceptado con acta 111.334.766 COP; diferencia 65.905.582 COP (señal `vendor_invoiced_over_accepted`) | `00-gobierno/2026-04-18-contrato-ct-353.docx`; `20-seguimiento/2026-08-27-factura-ct-353.pdf`; actas de recibo de 2026-07-26 y 2026-09-29 |
| Orden de la factura | Factura después del acta | FV-1353 es del 2026-08-27 y está radicada en cuentas por pagar. A esa fecha solo existía el acta del licenciamiento (2026-07-26); el acta de la bolsa de horas es del 2026-09-29 | Factura y actas citadas |

La factura dice «Entregables del contrato CT-353» sin desglosar, así que no se puede decir qué entregables cubre. Ninguna evidencia respalda lo facturado por encima de lo aceptado: ni la calibración de sensores (pendiente) ni otro documento.

### Sin evidencia de recibo
Ninguno. Los dos entregables marcados como recibidos en el contrato tienen acta.

### Compromisos vencidos y abiertos de la reunión del 2026-10-13
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Javier Hoyos — Entregar el punto 20 | `30-reuniones/2026-10-13-comite-semanal.docx` | 2026-09-26 | 18 vencido |
| Rubén Cárdenas — Entregar el punto 36 (abierto) | mismo comité | 2026-10-29 | no vence aún |

Ningún documento prueba la entrega del punto 20. Su fecha es anterior a la reunión que lo registra. Ninguno de los dos figura entre los asistentes (María Restrepo, Beatriz Cuéllar). El comité no dice si son del proveedor ni de qué contrato son esos puntos, así que **no puedo atribuirlos al proveedor**; los dejo como compromisos del proyecto para que alguien los ubique.

### Sin dato
- **Vencimiento del contrato:** el contrato CT-353 no trae fecha de terminación, renovación automática ni plazo de preaviso. No puedo decir si hay un preaviso por vencer.
- **Valor total del contrato:** no aparece, solo los tres montos por entregable.
- **Desglose de FV-1353:** no dice qué entregables cubre.
- **Riesgo abierto en el informe de avance del 2026-09-27:** «El proveedor no ha confirmado la fecha de la última entrega», sin dueño ni fecha. Cuadra con la calibración de sensores, pero el informe no lo dice.

### Después
No hay preaviso por vencer que reportar, porque el contrato no lo declara. Hay un entregable facturado sin acta por 65.905.582 COP. **Ofrezco llevarlo al comité del 2026-10-28** como decisión: retener o regularizar ese valor hasta que exista el acta de la calibración de sensores.

**Pie de rigor:** cifras copiadas de `compute` al 2026-10-14. Fuentes citadas por documento. Los PDF de las actas y de la factura se leyeron con el lector de PDF. No se verificó firma física: las actas dicen «recibido por María Restrepo», que es la gerente según el informe de avance. Sesión de prueba sin interfaz: ninguna pregunta se respondió por una persona.
