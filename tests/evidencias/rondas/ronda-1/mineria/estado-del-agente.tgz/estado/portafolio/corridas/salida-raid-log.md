*Sale de: las 13 fichas de `estado/portafolio/records` (PRY-199 a PRY-211) y de las minutas y notas de reunión de la carpeta de documentos (PRY-199, 200, 203, 206, 207, 208, 210, 211). Términos v1.0 aceptados por José Francisco Ñáñez el 2026-10-14. No se releyeron los informes de avance: su contenido entra por la ficha.*

## RAID — Portafolio de proyectos mineros al 2026-10-14
9 riesgos · 0 supuestos · 18 incidencias · 7 dependencias
34 sin doliente · 3 sin movimiento (>15 días) · 1 no registrado formalmente

Ningún ítem tiene probabilidad ni impacto en las fuentes (todos `not_found`). No los relleno: sin esos dos datos no puedo aplicar el criterio de escalamiento por valoración, y "Necesitan decisión ahora" se arma solo con lo que la evidencia sí sostiene.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-208 / R-nuevo | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-14 | Dicho en reunión, nadie lo anotó; el gerente decide si lo formaliza |
| PRY-199, 201, 205, 206, 207, 209 | Incidencia | "Hallazgo levantado en la auditoría de seguridad" (6 proyectos, uno por proyecto) | sin doliente | 2026-09-27 a 2026-10-12 (PRY-207: sin fecha) | Hallazgo de seguridad abierto sin responsable en seis proyectos |
| PRY-200, 201 | Incidencia | Equipos entregados en el campamento, pendientes de aceptación; no hay contrato ni acta de recibo en la carpeta | sin doliente | 2026-10-10 | Entrega sin aceptación documentada |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Riesgo | PRY-208, notas de reunión (`2026-10-14-notas-reunion.txt`): "nadie lo anotó como riesgo" | 2026-10-14 |

Es el único. Las demás minutas (PRY-199, 200, 203, 206, 207, 210, 211 y el comité de PRY-208 del 09-10) solo traen compromisos, sin riesgos dichos al pasar.

### Sin doliente o sin fecha
Los 34 ítems no tienen doliente. Los 9 riesgos y las 7 dependencias tampoco tienen fecha. Las incidencias no llevan fecha de cierre en la ficha; dos (PRY-207: lluvias y hallazgo de auditoría) tampoco tienen fecha de origen.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| PRY-200, 203, 209, 210 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | doliente, fecha, prob., impacto |
| PRY-201, 202 | Riesgo | Bloqueo de la vía de acceso a la mina | doliente, fecha, prob., impacto |
| PRY-205, 211 | Riesgo | Concentración del conocimiento en una sola persona | doliente, fecha, prob., impacto |
| PRY-208 | Riesgo | Proveedor podría no llegar con el equipo completo | doliente, fecha, prob., impacto |
| PRY-199 (×2), 202 (×2), 210 | Incidencia | Hallazgo de auditoría / reprogramación de la parada de planta | doliente |
| PRY-202, 205, 211 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | doliente |
| PRY-204 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | doliente |
| PRY-206, 207 | Incidencia | Lluvias detuvieron el montaje diez días | doliente (PRY-207 también fecha de origen) |
| PRY-211 | Incidencia | Equipos entregados, pendientes de aceptación | doliente |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (las 7 de abajo) | no consta en ninguna fuente | no | Ninguna lleva el código del proyecto del que depende, así que no puedo cruzar fechas entre proyectos. No es que ninguna esté en riesgo: es que no se puede saber. |

**Reclasificaciones (propuestas, la ficha no se tocó).** Siete ítems registrados como riesgo son dependencias, porque dependen de alguien fuera del proyecto y ya son un estado, no una posibilidad:
- "Ventana de parada de planta definida por operaciones" (PRY-201, 206, 208): depende de Operaciones.
- "El proveedor no ha confirmado la fecha de la última entrega" (PRY-199, 204, 206, 207): depende del proveedor.

No encontré supuestos en ninguna fuente. Eso es lo que hay: no sé si no hay supuestos o nadie los declaró.

### Registro completo
Probabilidad e impacto: `not_found` en todos. Doliente: `not_found` en todos.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de la última entrega | n/d | n/d | n/d | n/d | 2026-10-12 |
| PRY-199 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | desde 2026-10-12 | 2026-10-12 |
| PRY-199 | Incidencia | Reprogramación de la parada de planta | — | — | n/d | desde 2026-10-12 | 2026-10-12 |
| PRY-200 | Riesgo | Cambio en la licencia ambiental | n/d | n/d | n/d | n/d | 2026-10-10 |
| PRY-200 | Incidencia | Equipos entregados, pendientes de aceptación | — | — | n/d | desde 2026-10-10 | 2026-10-10 |
| PRY-201 | Riesgo | Bloqueo de la vía de acceso | n/d | n/d | n/d | n/d | 2026-10-10 |
| PRY-201 | Dependencia (antes riesgo) | Ventana de parada de planta (Operaciones) | n/d | n/d | n/d | n/d | 2026-10-10 |
| PRY-201 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | desde 2026-10-10 | 2026-10-10 |
| PRY-201 | Incidencia | Equipos entregados, pendientes de aceptación | — | — | n/d | desde 2026-10-10 | 2026-10-10 |
| PRY-202 | Riesgo | Bloqueo de la vía de acceso | n/d | n/d | n/d | n/d | 2026-10-09 |
| PRY-202 | Incidencia | Ensayo de disponibilidad no alcanzó lo pactado, se repite | — | — | n/d | desde 2026-10-09 | 2026-10-09 |
| PRY-202 | Incidencia | Reprogramación de la parada de planta | — | — | n/d | desde 2026-10-09 | 2026-10-09 |
| PRY-203 | Riesgo | Cambio en la licencia ambiental (registrado) | n/d | n/d | n/d | n/d | 2026-10-14 |
| PRY-204 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de la última entrega | n/d | n/d | n/d | n/d | 2026-10-10 |
| PRY-204 | Incidencia | Dos semanas perdidas por rotación de ingeniero clave | — | — | n/d | desde 2026-10-10 | 2026-10-10 |
| PRY-205 | Riesgo | Concentración del conocimiento en una persona | n/d | n/d | n/d | n/d | 2026-10-06 |
| PRY-205 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | desde 2026-10-06 | 2026-10-06 |
| PRY-205 | Incidencia | Ensayo de disponibilidad no alcanzó lo pactado, se repite | — | — | n/d | desde 2026-10-06 | 2026-10-06 |
| PRY-206 | Dependencia (antes riesgo) | Ventana de parada de planta (Operaciones) | n/d | n/d | n/d | n/d | **2026-09-27 (17 días)** |
| PRY-206 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de la última entrega | n/d | n/d | n/d | n/d | **2026-09-27 (17 días)** |
| PRY-206 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | desde 2026-09-27 | 2026-09-27 |
| PRY-206 | Incidencia | Lluvias detuvieron el montaje diez días | — | — | n/d | desde 2026-09-27 | 2026-09-27 |
| PRY-207 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de la última entrega (registrado) | n/d | n/d | n/d | n/d | 2026-10-13 |
| PRY-207 | Incidencia | Lluvias detuvieron el montaje diez días | — | — | n/d | sin fecha | 2026-10-13 |
| PRY-207 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | sin fecha | 2026-10-13 |
| PRY-208 | Dependencia (antes riesgo) | Ventana de parada de planta (Operaciones) (registrado) | n/d | n/d | n/d | n/d | **2026-09-26 (18 días)** |
| PRY-208 | Riesgo (no registrado formalmente) | Proveedor podría no llegar con el equipo completo | n/d | n/d | n/d | n/d | 2026-10-14 |
| PRY-209 | Riesgo | Cambio en la licencia ambiental | n/d | n/d | n/d | n/d | 2026-10-11 |
| PRY-209 | Incidencia | Hallazgo de la auditoría de seguridad | — | — | n/d | desde 2026-10-11 | 2026-10-11 |
| PRY-210 | Riesgo | Cambio en la licencia ambiental | n/d | n/d | n/d | n/d | 2026-10-11 |
| PRY-210 | Incidencia | Reprogramación de la parada de planta | — | — | n/d | desde 2026-10-11 | 2026-10-11 |
| PRY-211 | Riesgo | Concentración del conocimiento en una persona | n/d | n/d | n/d | n/d | 2026-10-11 |
| PRY-211 | Incidencia | Equipos entregados, pendientes de aceptación | — | — | n/d | desde 2026-10-11 | 2026-10-11 |
| PRY-211 | Incidencia | Ensayo de disponibilidad no alcanzó lo pactado, se repite | — | — | n/d | desde 2026-10-11 | 2026-10-11 |

"Sin movimiento" usa el umbral configurado de 15 días (`silent_days`), porque las fuentes no definen "período". Solo cuento `last_moved`; las incidencias traen fecha de origen y no de movimiento, así que no puedo decir si alguna está estancada.

## Después
- **Subir a comité (2026-10-28):** los seis hallazgos de auditoría de seguridad sin doliente y el riesgo del proveedor de PRY-208 cuando el gerente lo formalice. No los subo yo: sin probabilidad e impacto no cumplen el criterio de escalamiento por valoración, y la decisión es tuya.
- **Doliente:** no asigno a nadie. Para PRY-208 solo hay nombres que aparecen en las notas del 2026-10-14 (Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Óscar Ramírez), pero ninguna fuente dice quién lleva el riesgo del proveedor; la propuesta es del gerente. Para los demás no hay base para proponer a nadie.

**Pie de rigor:** lo que no sé. Probabilidad, impacto, doliente y fecha de los 34 ítems no constan en ninguna fuente. No hay supuestos registrados y las dependencias no nombran el proyecto del que dependen. No releí los informes de avance; busqué riesgos dichos en reuniones solo en las minutas y notas existentes. Las actas y PDF de recibo no se revisaron para este registro.
