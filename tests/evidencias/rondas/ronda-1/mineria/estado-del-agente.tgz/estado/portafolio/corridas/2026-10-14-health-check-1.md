# Corrida del 2026-10-14 · health-check

13 proyectos · 112 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 16 |
| `progress_vs_plan` | 5 |
| `declared_vs_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_deliverable_late` | 2 |
| `pm_vs_pmo` | 2 |
| `variance_cost` | 1 |
| `commitment_undated` | 1 |
| `variance_time` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Diagnóstico de PRY-208 desde cero: 17 afirmaciones (6 sostenidas, 5 sin sustento, 6 contradichas). Dijo que no sabe: autoridad del gerente, gasto real, si hubo montaje y pruebas, fecha de cierre vigente, qué es el punto 31. El script no marca la reprogramación de Elena Duarte que sí está en las minutas.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-208 Trazabilidad del mineral · 2026-10-14

**Leí:** 12 documentos · del 2025-07-26 al 2026-10-14 · formatos: .md (6), .txt (1), .json (1), .docx (1), .pdf (2), .xlsx (1). Once son la carpeta del proyecto; el duodécimo es la definición de producto PRD-304, que menciona "trazabilidad".
**No pude leer:** ninguno. Los 11 de la carpeta se convirtieron sin falla.
**Aviso de método:** `ficha-pm.json` la escribió el gerente. La traté como declaración, no como evidencia. Las cifras derivadas salen de `portafolio.py compute`, que lee la ficha del estado y no los documentos. Verifiqué contra los documentos lo que dice de este proyecto. Hay una discrepancia, anotada en "Lo que se dijo y nadie registró".

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 5 · **Contradicho:** 6 (17 afirmaciones dictaminadas; el detalle está al final)

La carpeta sostiene el acta de constitución, el presupuesto aprobado, el recibo del licenciamiento del software y la factura que lo cubre. También sostiene dos de los cinco hitos del cronograma, con actas de recibo firmadas, ambas fechadas meses después del hito. No sostiene el estado verde, ni el 75% de avance, ni el cierre de Ingeniería básica, Montaje y Pruebas. El cronograma dice 5 de 5 hitos cerrados y el informe de avance dice 75%. El mismo informe dice que los equipos están en el campamento "pendientes de aceptación", lo que no cuadra con un montaje y unas pruebas ya cerrados. Los gastos (ejecutado, comprometido, proyección) tienen una sola fuente: el informe del gerente. No hay documento que los respalde. Patrocinador, gerente y comité apuntan a la misma persona, y ningún documento declara la autoridad del gerente.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Gustavo Neira | 00-gobierno/2025-07-26-acta-constitucion.md |
| Gerente | Gustavo Neira | 00-gobierno/2025-07-26-acta-constitucion.md |
| Autoridad declarada | **No está en ningún documento.** Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. | — |
| Comité | Comité de Inversiones. La única minuta de comité (2026-10-09) lista como asistentes "Gustavo Neira, Gustavo Neira". Diana Molina y Elena Duarte, que tienen compromisos en esa minuta, no figuran como asistentes. | 00-gobierno/2025-07-26-acta-constitucion.md · 30-reuniones/2026-10-09-comite-semanal.md |

Otros vacíos del acta:
- El alcance es "Componente 1, 2, 3".
- El criterio de éxito ("Trazabilidad del mineral en producción y medido") no trae métrica ni meta.
- Las dependencias dicen "Ninguna declarada", pero hay un proveedor contratado y una ventana de parada de planta que define Operaciones.
- Control de cambios: ningún documento registra un cambio.

### Contra el plan
- **Línea base original:** `10-plan/2025-07-26-cronograma-v1.xlsx` (2025-07-26), 5 hitos, el último "Pruebas en operación" el 2026-06-19.
- **Vigente:** idéntica a la original. Replanificaciones: 0. Cambios aprobados: 0.
- **Conflicto sin resolver:** el acta fija el cierre el 2026-07-21 y el cronograma termina el 2026-06-19. Ningún documento posterior dice cuál rige.
- **Desviación:** el script da 0 días contra la original y contra la vigente. Esa cifra no es evidencia de cumplimiento. Ninguna fecha se movió en ningún documento, y el proyecto sigue activo, con avance declarado de 75%, después de ambas fechas de cierre. Una desviación aprobada no existe porque no hay autoridad ni control de cambios.
- **Avance:** declarado 75,0%. El cronograma sostiene 100% (5 de 5 hitos "cerrado"). Brecha: 25,0 puntos. Son dos documentos del propio proyecto que no coinciden, y ninguno es evidencia independiente.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-10-07 | 372 | Acta de aprobación o de recibo de la ingeniería básica |
| Montaje e instalación | 2026-04-16 | 181 | Acta de recibo del montaje, informe de comisionamiento |
| Pruebas en operación | 2026-06-19 | 117 | Protocolo y acta de pruebas; datos de operación para el criterio "medido" |

Con evidencia, pero con fecha muy posterior al hito (el script no da los días y no los escribo):
- **Licencia y permisos obtenidos:** hito 2026-02-11, acta de recibo 2026-10-02.
- **Ingeniería de detalle aprobada:** hito 2025-12-10, acta de recibo 2026-10-12. Se firmó dos semanas después del informe de avance que ya reportaba 75%.

Ambas actas las firma Gustavo Neira, el mismo patrocinador y gerente. Ningún acta identifica quién aprobó los entregables técnicos.

### Dinero
Fuente única: `20-seguimiento/2026-09-26-informe-avance.md`, declarado por el gerente. Moneda: COP.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 1.802.031.890 | 730.741.848 | 3.290.941.311 | 1.497.968.110 |

- Comprometido: 54,6% del aprobado.
- Ejecutado: 22,1% del aprobado.
- Proyección: −0,3% sobre el aprobado.
- Avance declarado: 75,0%. Con 22,1% ejecutado, la relación entre avance y gasto queda sin explicar.
- Ningún documento respalda el ejecutado: no hay extracto financiero ni orden de compra.
- El informe dice "se actualizó el presupuesto", pero el aprobado sigue en 3.300.000.000 y no hay control de cambios.

**Proveedor Equipos Pesados Andinos (CT-462):**
- Dos entregables, 289.334.112 COP cada uno.
- Licenciamiento del software: contractual 2025-11-29, acta de recibo 2025-12-14. Aceptado.
- Bolsa de horas de ingeniería: contractual 2026-03-26. El contrato la marca "en curso", y no hay acta ni reporte de horas. Está vencida 202 días sin recibo.
- Factura FV-1462 (2026-09-02) por 289.334.112 COP, radicada en cuentas por pagar. El monto coincide con un entregable aceptado, pero el concepto dice "Entregables" (plural) y no cita cuál.
- El contrato condiciona la factura a un acta de recibo firmada por el gerente. Esa condición se cumple para un solo entregable.

### Lo que se dijo y nadie registró
No existe ningún registro RAID en la carpeta.

**Riesgo no registrado.** Las notas del 2026-10-14 dicen que el proveedor podría no llegar con el equipo completo para la siguiente fase, y que nadie lo anotó. No tiene dueño, probabilidad, impacto ni fecha. Conecta con la bolsa de horas vencida y los equipos pendientes de aceptación.

**Dependencia no declarada.** El informe lista como "riesgo" la ventana de parada de planta que define Operaciones. Es una dependencia de otra área, que el acta declara como "Ninguna".

**Compromisos (4 abiertos):**
| Quién | Qué | Para | Nota |
|---|---|---|---|
| Diana Molina | Entregar el punto 31 | 2026-10-28 | Comité 2026-10-09. No se mencionó el 2026-10-14. |
| Elena Duarte | Entregar el punto 31 | 2026-10-31 → 2026-11-14 | Reprogramado una vez, el 2026-10-14 ("no alcanzó"). |
| Laura Vélez | Mandar el ajuste del presupuesto | "la otra semana" | Sin fecha. Es el único compromiso que toca el presupuesto, que el informe dice haber actualizado. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 | Sin otra referencia. |

- El mismo compromiso ("el punto 31") tiene dos dueños con fechas distintas.
- Ningún documento define qué es el "punto 31".
- Ninguno de los 4 compromisos está vencido hoy.
- Discrepancia con el script: devuelve 0 compromisos reprogramados, y la lectura de las dos minutas muestra 1 (Elena Duarte).

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-09-26: "Verde" | Contrato CT-462: bolsa de horas vencida 202 días sin recibo. Cronograma contra informe: 25,0 puntos de brecha |
| Avance 75% | Informe 2026-09-26: 75% | Cronograma v1: 5 de 5 hitos cerrados |
| Montaje e instalación y Pruebas en operación "cerrado" | Cronograma v1: ambos "cerrado" (2026-04-16 y 2026-06-19) | Informe 2026-09-26: "el proveedor entregó los equipos en el campamento, pendientes de aceptación" |
| Cierre del proyecto | Acta de constitución: 2026-07-21 | Cronograma v1: 2026-06-19 |
| Licenciamiento "recibido" en el contrato | Contrato CT-462, firmado 2025-07-27, lo marca "recibido" | Acta de recibo: 2025-12-14. Un contrato firmado en julio no puede registrar un recibo de diciembre, así que se editó después sin versión |

### Sin sustento
- **Ingeniería básica aprobada, "cerrado":** el cronograma lo dice y ninguna acta lo respalda.
- **"El proveedor entregó los equipos":** CT-462 no incluye equipos entre sus entregables (solo licenciamiento y bolsa de horas) y no hay acta de entrega.
- **Cifras de ejecución:** comprometido, ejecutado y proyección tienen como única fuente el informe del gerente.
- **"Se actualizó el presupuesto con compras":** el aprobado no cambia, no hay solicitud de cambio, y el ajuste sigue pendiente en las notas del 2026-10-14.
- **Bolsa de horas "en curso":** el contrato la marca así, sin reporte de horas ni acta.

**Preguntas para el gerente sobre otros documentos:**
- PRD-304 (Trazabilidad, segmento Mantenimiento) dice "Proyectos que lo construyen: Ninguno declarado". El acta de PRY-208 declara como producto "trazabilidad", y la dueña es Geología. No consta que construyan lo mismo.
- PRD-304 registra el supuesto "La licencia ambiental lo permite" como verificado el 2026-05-15. La Licencia y permisos de PRY-208 se recibió el 2026-10-02. No sé si son el mismo trámite.

### Lo que esta carpeta no permite saber
- **Quién autoriza qué:** sin autoridad del gerente declarada, no se puede decir si una fecha movida sería una desviación aprobada. Tampoco si el comité (una sola persona en la única minuta) aprobó algo.
- **Si el montaje y las pruebas ocurrieron:** sin actas ni datos de operación, el criterio de éxito "en producción y medido" no se puede evaluar.
- **El gasto real:** sin extracto financiero, el ejecutado de 730.741.848 COP es una declaración.
- **Qué entregó el proveedor:** sin acta de entrega, no sé si los equipos existen ni a qué contrato corresponden.
- **Cuál es la fecha de cierre vigente:** acta y cronograma discrepan.
- **Qué es el "punto 31"** y quién responde por él.
- **Cuántas horas se consumieron de la bolsa.**

### Después
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Lo que sí hay son 6 contradicciones y 5 afirmaciones sin sustento, y la carpeta no permite diagnosticar el avance real. Puedo preparar el punto de comité del 2026-10-28 con la lista de lo que falta, o llevar las contradicciones al gerente como preguntas, una por una.

### Detalle del dictamen (17 afirmaciones)
| # | Afirmación | Veredicto |
|---|---|---|
| 1 | Presupuesto aprobado 3.300.000.000 COP | Sostenida (acta e informe coinciden) |
| 2 | Patrocinador, gerente y comité nombrados | Sostenida (acta) |
| 3 | Licenciamiento del software recibido | Sostenida (acta PDF 2025-12-14 + contrato) |
| 4 | Hito Licencia y permisos cerrado | Sostenida (acta 2026-10-02) |
| 5 | Hito Ingeniería de detalle cerrado | Sostenida (acta 2026-10-12) |
| 6 | Factura FV-1462 corresponde a un entregable aceptado | Sostenida (monto = un entregable aceptado) |
| 7 | Hito Ingeniería básica cerrado | Sin sustento |
| 8 | Proveedor entregó equipos en el campamento | Sin sustento |
| 9 | Cifras de ejecución (comprometido, ejecutado, proyección) | Sin sustento |
| 10 | Presupuesto actualizado con compras | Sin sustento |
| 11 | Bolsa de horas "en curso" | Sin sustento |
| 12 | Hito Montaje e instalación cerrado | Contradicha (informe: equipos pendientes de aceptación) |
| 13 | Hito Pruebas en operación cerrado | Contradicha (ídem) |
| 14 | Avance 75% | Contradicha (cronograma: 5 de 5 hitos) |
| 15 | Estado verde | Contradicha (bolsa vencida 202 días; hitos) |
| 16 | Cierre 2026-07-21 | Contradicha (cronograma: 2026-06-19) |
| 17 | Licenciamiento "recibido" al firmar el contrato | Contradicha (acta 2025-12-14) |

---
Pie: Criterio portfolio · diagnóstico PRY-208 de 2026-10-14 · 12 documentos leídos · campos inciertos: identity.authority, identity.phase, declared.status de la ficha del gerente · Términos: TERMS.md v1.0 (2026-09-18), aceptados por José Francisco Ñáñez el 2026-10-14. Borrador de trabajo: verifícalo antes de decidir.
