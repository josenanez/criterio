## Carpeta al 2026-10-14

**Documentos:** 69 · **Sin cambio:** 69 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno. 0 documentos.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
12 citas, todas de PRY-208. La ficha cita la ruta sin la carpeta del proyecto (`PRY-208-trazabilidad-del-mineral/`), y el índice resuelve las rutas desde la raíz de documentos.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-208 | pm_record.identity.code | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.name | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.business_area | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.product | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.sponsor | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.manager | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.identity.committee | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.plan.start_date | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.plan.end_date | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.money.currency | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.money.approved | 00-gobierno/2025-07-26-acta-constitucion.md |
| PRY-208 | pm_record.declared.status | 2026-10-14-notas-reunion.txt |

Los dos archivos existen en disco bajo `PRY-208-trazabilidad-del-mineral/`. No se corrigió ninguna ficha: queda como propuesta.

### Formatos que no se pudieron leer
Este comando no lee documentos; no aplica.

### Siguiente paso
Nada que releer, así que no hace falta `/portfolio-scan`. Pendiente: decidir si se corrigen las 12 rutas de PRY-208 anteponiendo la carpeta del proyecto.
