## Historia · PRY-210 Programa de relacionamiento comunitario · 2026-03-26 a 2026-10-12

**Leí:** 7 documentos entre 2026-03-26 y 2026-10-12 (acta de constitución, cronograma v1, solicitud de cambio CC-01, acta del Comité Ambiental, informe de avance, cronograma v2, acta de recibo). El acta de recibo es un PDF sin texto extraíble por el índice; lo leí directamente.
**Trimestres sin un solo documento:** 2.º trimestre de 2026 (abr–jun) y 3.er trimestre de 2026 (jul–sep). Entre el 2026-03-26 y el 2026-10-05 no hay ningún documento: seis meses y medio de proyecto sin rastro escrito.

### En una línea
El proyecto se aprobó el 2026-03-26 con cierre del acta en 2027-11-09 y presupuesto de 9.500.000.000 COP. Después no hay documentos hasta el 2026-10-05, cuando una solicitud de cambio (CC-01) amplía el alcance y mueve "Pruebas en operación" de 2027-09-17 a 2027-12-17; una semana después el informe de avance declara amarillo con 26%. La aprobación de ese cambio dice estar "autorizada por el comité", pero el acta del comité de ese mismo día no la menciona.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 91 días (17.2 %) | No calculable: hay un solo estado declarado (2026-10-11), no una serie | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-03-26 | Acta de constitución | Aprobación: patrocinadora María Restrepo, gerente Diana Molina, Comité Ambiental; inicio 2026-04-05, cierre 2027-11-09; 9.500.000.000 COP. Dependencias: ninguna declarada |
| 2026-03-26 | Cronograma v1 (xlsx) | Línea base original; cierre de la ruta (Pruebas en operación) 2027-09-17. Ya trae "Ingeniería básica aprobada" como *cerrado* |
| 2026-10-05 | Solicitud de cambio CC-01 | Ampliación de alcance: +91 días y +182.000.000 COP. Dice "Autorizada por el comité", sin decir cuál ni cuándo |
| 2026-10-05 | Acta del Comité Ambiental | Asistentes: Diana Molina y María Restrepo. Temas: Avance y Compromisos. No recoge CC-01. Compromiso de Óscar Ramírez para el 2026-10-09 |
| 2026-10-11 | Cronograma v2 (csv) | Nueva línea base: Pruebas en operación pasa a 2027-12-17 |
| 2026-10-11 | Informe de avance | Amarillo, 26 %; presupuesto aprobado sigue en 9.500.000.000 |
| 2026-10-12 | Acta de recibo (pdf) | Diana Molina recibe "Ingeniería básica aprobada" |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-11 (v2); solicitada 2026-10-05 | 2027-12-17 | Ampliación de alcance (CC-01) | Ninguno localizado: CC-01 afirma autorización del comité, pero ningún acta de comité la recoge |

Atraso acumulado contra la línea base original: 91 días (17.2 %); contra la vigente: 0 días.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios detectados de patrocinador, gerente ni comité | — |

Sí hay un hueco: el campo "autoridad" no aparece en el acta de constitución, y por eso no se puede decir quién tenía la facultad de aprobar CC-01.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Óscar Ramírez | "Entregar el punto 35" | 1 (no se repite) | 2026-10-09; vencido 5 días sin documento posterior |

Ningún compromiso se ha reprogramado. Dos notas: Óscar Ramírez no figura entre los asistentes, y el acta no dice qué es el "punto 35".

### Desde cuándo lo declarado no se sostiene
No puedo fechar un deslizamiento: solo hay un informe de estado (2026-10-11) y no una serie contra la cual ver cuándo dejó de sostenerse. Lo que sí está documentado:

- **Primer hito con la evidencia detrás de lo declarado:** "Ingeniería básica aprobada" figura como *cerrado* en el cronograma v1 del 2026-03-26 (fecha del hito: 2026-07-20), en el v2 y en el informe del 2026-10-11. El único soporte, el acta de recibo, es del 2026-10-12, un día después de los dos últimos.
- **Qué se siguió reportando:** amarillo y 26 % (el plan sostiene entre 20 % y 40 %, así que el porcentaje no se contradice con el plan). Pero el informe aún afirma que se recibió el "permiso ambiental pendiente" y el hito "Licencia y permisos obtenidos" (2027-02-17) sigue pendiente; no sé si son lo mismo, ningún documento lo aclara.
- **Fechas que no cuadran sin que nadie las toque:** el cierre del acta (2027-11-09) quedó antes de la nueva fecha de Pruebas en operación (2027-12-17), y ningún documento actualiza el cierre. El presupuesto aprobado del informe no incorpora los 182.000.000 COP de CC-01.

### Lecciones ancladas a un hecho
- **Hecho:** CC-01 (2026-10-05) dice estar autorizada por el comité y el acta de ese día no la recoge. **Efecto:** la línea base v2 (2026-10-11) movió el cierre 91 días sin un documento de aprobación que se pueda citar.
- **Hecho:** el hito "Ingeniería básica aprobada" aparece cerrado en el cronograma desde el 2026-03-26 y su acta de recibo es del 2026-10-12. **Efecto:** el estado de ese hito en los informes no se pudo verificar hasta la última fecha.
- **Hecho:** el cronograma v2 (2026-10-11) pone Pruebas en operación en 2027-12-17 y el acta fija el cierre en 2027-11-09. **Efecto:** hoy el proyecto tiene dos fechas de fin incompatibles, sin documento que decida cuál rige.

No leo intención en nada de esto: lo que muestran los documentos son faltantes de registro, y quién los explica es una persona, con esta historia en la mano.

*Pie de rigor: borrador de trabajo. Se apoya solo en los 7 documentos de la carpeta; lo decidido fuera de ellos no lo conozco, y que algo no aparezca no prueba que no haya ocurrido. Verifica cada dato contra su fuente antes de usarlo en un comité. Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14 para esta prueba.*
