## Barrido — 2026-10-14

**Documentos:** 69 en la carpeta · 45 leídos · 24 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 200, 201, 202, 204, 205, 206, 209, 210, 211) · 0 sin carpeta propia
**Formatos:** .md 28 · .docx 14 · .pdf 13 · .xlsx 8 · .csv 4 · .json 1 · .txt 1
**Plan:** 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`); nada diferido. Términos 1.0 ya aceptados en la configuración (José Francisco Ñáñez, 2026-10-14).

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, declarado (verde, 20%), fechas, presupuesto, 5 hitos, contrato CT-199, 1 compromiso, 1 riesgo | autoridad, fase, facturado |
| PRY-200 Mantenimiento predictivo de camiones | 4 | identidad, declarado (rojo, 53%), fechas, presupuesto, 3 hitos, 1 compromiso, 1 riesgo | autoridad, fase |
| PRY-201 Ampliación de la relavera | 2 | identidad, declarado (amarillo, 64%), fechas, presupuesto, 2 riesgos | autoridad, fase, hitos (no hay cronograma) |
| PRY-202 Planta de tratamiento de agua | 3 | identidad, declarado (verde, 40%), fechas, presupuesto, 3 hitos, 1 riesgo | autoridad, fase |
| PRY-204 Monitoreo de taludes | 2 | identidad, declarado (verde, 54%), fechas, presupuesto, 1 riesgo | autoridad, fase, hitos |
| PRY-205 Sistema de gestión de seguridad | 2 | identidad, declarado (verde, 72%), fechas, presupuesto, 1 riesgo | autoridad, fase, hitos |
| PRY-206 Red privada LTE en mina | 8 | identidad, declarado (amarillo, 68%), fechas, presupuesto, 5 hitos, contrato CT-353 con 2 actas de recibo y 1 factura, 2 compromisos, 2 riesgos | autoridad, fase |
| PRY-209 Electrificación de equipos | 3 | identidad, declarado (amarillo, 37%), fechas, presupuesto, 3 hitos, 1 riesgo | autoridad, fase |
| PRY-210 Programa de relacionamiento comunitario | 7 | identidad, declarado (amarillo, 26%), fechas, presupuesto, 5 hitos, 2 líneas base, CC-01, 1 compromiso, 1 riesgo | autoridad, fase |
| PRY-211 Control de polvo en vías | 8 | identidad, declarado (verde, 88%), fechas, presupuesto, 5 hitos, contrato CT-263 con 1 factura, 1 compromiso, 1 riesgo | autoridad, fase |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-203, PRY-207, PRY-208 | Nada: sus 24 documentos no cambiaron por hash; no se abrieron ni se reescribieron sus fichas | `meta.documents_seen` |

### Qué hay que mirar (lo que salta a la vista al transcribir; el cálculo y las señales las hace el script)
- **Cambio sin presupuesto ni cierre actualizados, PRY-210.** CC-01 (ampliación de alcance, +91 días, +182.000.000 COP) figura «autorizada por el comité», pero la solicitud no dice cuál y ningún acta de comité la recoge. El cronograma v2 mueve Pruebas en operación a 2027-12-17, posterior al cierre del acta (2027-11-09), y el informe del 2026-10-11 sigue con 9.500.000.000 aprobados.
- **Facturado contra recibido, PRY-206.** Factura FV-1353 (2026-08-27) por 177.240.348 COP; solo hay dos actas de recibo (2026-07-26 y 2026-09-29), la segunda posterior a la factura, y el contrato pide factura contra acta. Los tres entregables suman 167.002.149 COP.
- **Facturado contra recibido, PRY-211.** Factura FV-1263 (2026-09-17) por 1.143.205.796 COP; el contrato da por «recibido» el Licenciamiento del software (956.244.198 COP) pero no hay acta de recibo. La Bolsa de horas (vencía 2026-09-09) sigue pendiente.
- **Hitos declarados cerrados sin acta:** PRY-200 (2), PRY-202 (2), PRY-206 (2), PRY-209 (1), PRY-211 (1: Ingeniería básica). Se registran `met` sin evidencia.
- **Fechas ya vencidas:** PRY-205 cierre 2026-08-01 con 72% reportado y estado verde; PRY-202 Licencia y permisos (2026-10-11) sigue en curso; PRY-206 Licencia y permisos (2026-10-10) sigue en curso.
- **Estado declarado contra cifras:** PRY-200 rojo con ejecutado (5.412.722.249) mayor que comprometido (4.586.233.839); PRY-209 proyecta 18.540.943.448 sobre 18.000.000.000 aprobados.
- **Compromisos vencidos:** PRY-210 (Óscar Ramírez, punto 35, 2026-10-09) y PRY-206 (Javier Hoyos, punto 20, 2026-09-26: la fecha es anterior a la reunión que lo registra). En todas las minutas, el responsable del compromiso no figura entre los asistentes.
- **Sin cronograma:** PRY-201, PRY-204 y PRY-205 no tienen hitos en la carpeta.
- **Autoridad del gerente y fase:** no aparecen en ninguna de las 10 actas.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | 69 de 69 convertidos a texto; los PDF con `pdftotext`, los Office por su XML |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` en la documentación |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-208-trazabilidad-del-mineral/2026-10-14-notas-reunion.txt` | Está suelto en la raíz del proyecto, fuera de `30-reuniones/`; no lo moví porque pertenece a PRY-208 sin ambigüedad pero su ficha no se tocó en esta corrida (sin cambio por hash) |

### Aviso del índice
La `ficha-pm.json` de PRY-208 cita 12 campos con rutas relativas a la carpeta del proyecto (`00-gobierno/2025-07-26-acta-constitucion.md`, `2026-10-14-notas-reunion.txt`) y no a la raíz de documentación; por eso el índice las marca como cita que no resuelve. El documento existe. Corrección en la ficha del gerente, no en la mía.

*Pie: criterio-portfolio · fichas tocadas: 10 (PRY-199, 200, 201, 202, 204, 205, 206, 209, 210, 211) · campos en `not_found`: autoridad y fase en las 10; hitos en PRY-201, 204 y 205; facturado en PRY-199 · Términos: TERMS.md v1.0.*
