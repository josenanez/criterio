# Rostrum — modo «para mirarlo un rato»

Términos: aceptados (versión 1.0, 2026-10-14, José Francisco Ñáñez). Configuración: `.criterio/portafolio/config.json`. Informe encontrado en `reportes/`. Elegí la forma «para mirarlo un rato» porque no se indicó otra: se levanta en diez segundos y no pide nada a seguridad.

Se levanta así:

    python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado/portafolio --config .criterio/portafolio/config.json

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

## Qué hay y a quién le sirve

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio mirado en conjunto | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | El comité y el patrocinador |
| `/proyectos` | Listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto (PRY-199 a PRY-211), con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos que no dicen cuál construyen | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El portal lleva el nombre «Portafolio de proyectos mineros» porque la configuración lo trae.

## Lo que Rostrum no hace

- No calcula: sirve lo que `informe.py` ya escribió. Dos personas ven lo mismo.
- No escribe fichas: solo crea la petición, en `estado/portafolio/peticiones/`.
- No autentica: esta forma solo escucha en el equipo local.
- No manda nada: ni correo ni notificaciones.

## Cierre

- El enlace `http://127.0.0.1:8787/` solo funciona en este equipo y mientras el proceso esté vivo. No sirve para pasárselo al patrocinador; para eso hace falta «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización, con host y puerto aprobados).
- El informe estará desactualizado desde la próxima corrida de `/portfolio-report`; la portada muestra su fecha. El comité siguiente es el 2026-10-28.
