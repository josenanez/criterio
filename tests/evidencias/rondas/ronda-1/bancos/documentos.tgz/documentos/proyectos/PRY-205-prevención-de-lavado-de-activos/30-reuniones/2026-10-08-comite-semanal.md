# Comité de Medios de Pago · Prevención de lavado de activos

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 37 | por definir |
