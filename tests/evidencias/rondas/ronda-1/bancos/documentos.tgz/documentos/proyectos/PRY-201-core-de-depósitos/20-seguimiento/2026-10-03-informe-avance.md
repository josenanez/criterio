# Informe de avance · Core de depósitos

**Código:** PRY-201
**Fecha de corte:** 2026-10-03
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **69%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- La prueba de carga no alcanzó el umbral pactado y se repite
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 975.705.100 |
| Ejecutado | 304.624.398 |
| Proyección al cierre | 1.165.586.238 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- El proveedor no ha confirmado la fecha de la última entrega
