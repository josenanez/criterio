# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-09
**Asistentes:** Carlos Peña, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 3 | 2026-09-22 |
| Andrés Lozano | Entregar el punto 29 | 2026-11-11 |
