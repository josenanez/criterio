# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Banca PyME
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2025-06-02

## Objetivo del negocio

Entregar onboarding pyme para Banca PyME.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Arquitectura el 2025-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-12 |
| Cierre | 2026-01-14 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
