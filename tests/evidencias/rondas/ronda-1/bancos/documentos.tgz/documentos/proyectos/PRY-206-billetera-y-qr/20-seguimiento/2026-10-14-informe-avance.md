# Informe de avance · Billetera y QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-14
**Gerente:** Carlos Peña

## Estado declarado

**Amarillo**

Avance reportado: **32%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se reprogramó la salida por ventana de cambio del área de operaciones
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 9.831.215.241 |
| Ejecutado | 3.216.437.976 |
| Proyección al cierre | 18.055.268.672 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio regulatorio en discusión que puede mover el alcance
