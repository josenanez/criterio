# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Amarillo**

Avance reportado: **56%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 5.086.273.404 |
| Ejecutado | 3.214.833.345 |
| Proyección al cierre | 6.406.465.976 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- Concentración del conocimiento en una sola persona
