# Comité de Riesgos · Core de depósitos

**Fecha:** 2026-10-01
**Asistentes:** Andrés Lozano, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 39 | por definir |
