# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-09
**Gerente:** Sandra Gil

## Estado declarado

**Rojo**

Avance reportado: **46%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se reprogramó la salida por ventana de cambio del área de operaciones
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.944.959.838 |
| Ejecutado | 1.177.688.077 |
| Proyección al cierre | 3.138.511.864 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
