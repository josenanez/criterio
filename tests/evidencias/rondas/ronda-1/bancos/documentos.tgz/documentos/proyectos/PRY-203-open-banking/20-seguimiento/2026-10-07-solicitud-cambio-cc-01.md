# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Open Banking
**Fecha:** 2026-10-07
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +112 días sobre la línea base vigente |
| Costo | 224.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
