# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de decisión
**Fecha:** 2026-10-07
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +21 días sobre la línea base vigente |
| Costo | 42.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
