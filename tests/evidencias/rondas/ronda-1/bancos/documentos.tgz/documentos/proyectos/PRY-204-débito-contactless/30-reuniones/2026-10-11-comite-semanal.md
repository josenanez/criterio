# Comité de Transformación Digital · Débito contactless

**Fecha:** 2026-10-11
**Asistentes:** Carlos Peña, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 19 | 2026-11-08 |
