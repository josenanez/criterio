# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **72%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se reprogramó la salida por ventana de cambio del área de operaciones
- El proveedor entregó el componente de integración, pendiente de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.194.692.657 |
| Ejecutado | 1.916.164.829 |
| Proyección al cierre | 4.055.804.996 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio regulatorio en discusión que puede mover el alcance
