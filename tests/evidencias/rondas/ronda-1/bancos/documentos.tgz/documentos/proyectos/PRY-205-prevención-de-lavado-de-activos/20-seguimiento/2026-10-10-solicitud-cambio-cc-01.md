# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-10
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +101 días sobre la línea base vigente |
| Costo | 202.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
