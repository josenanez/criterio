# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-10-07
**Asistentes:** Javier Hoyos, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 31 | 2026-10-16 |
