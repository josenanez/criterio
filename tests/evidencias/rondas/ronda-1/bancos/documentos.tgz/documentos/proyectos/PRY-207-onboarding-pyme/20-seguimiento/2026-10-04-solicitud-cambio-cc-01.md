# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-04
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +25 días sobre la línea base vigente |
| Costo | 50.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
