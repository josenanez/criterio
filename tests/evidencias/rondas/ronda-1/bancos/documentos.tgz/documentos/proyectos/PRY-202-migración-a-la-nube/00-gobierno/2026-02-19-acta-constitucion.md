# Acta de constitución · Migración a la nube

**Código:** PRY-202
**Área dueña:** Medios de Pago
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Banca Empresas
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-19

## Objetivo del negocio

Entregar migración a la nube para Medios de Pago.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Banca Empresas el 2026-02-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-01 |
| Cierre | 2026-10-16 |

## Criterio de éxito

Migración a la nube en producción y medido.

## Dependencias declaradas

- Ninguna declarada
