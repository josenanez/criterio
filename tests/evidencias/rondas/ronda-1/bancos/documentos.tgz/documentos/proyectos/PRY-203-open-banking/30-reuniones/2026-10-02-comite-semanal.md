# Comité de Banca Empresas · Open Banking

**Fecha:** 2026-10-02
**Asistentes:** María Restrepo, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 30 | 2026-10-28 |
