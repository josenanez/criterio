# Informe de avance · Originación digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-10
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **66%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se reprogramó la salida por ventana de cambio del área de operaciones

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 665.817.971 |
| Ejecutado | 687.650.908 |
| Proyección al cierre | 1.237.336.417 |

## Riesgos abiertos

- Cambio regulatorio en discusión que puede mover el alcance
- Disponibilidad del equipo de seguridad para la revisión final
