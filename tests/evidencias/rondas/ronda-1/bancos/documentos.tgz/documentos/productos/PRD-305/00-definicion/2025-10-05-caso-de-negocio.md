# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2025-10-05
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 112.665 | Caso de negocio, 2025-10-05 |

## Retorno esperado

Retorno esperado en 24 meses.
