# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2025-10-18
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 288.699 | Caso de negocio, 2025-10-18 |

## Retorno esperado

Retorno esperado en 24 meses.
