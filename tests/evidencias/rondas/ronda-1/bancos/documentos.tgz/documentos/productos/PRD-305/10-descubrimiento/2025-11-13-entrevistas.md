# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2025-11-13
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-11-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
