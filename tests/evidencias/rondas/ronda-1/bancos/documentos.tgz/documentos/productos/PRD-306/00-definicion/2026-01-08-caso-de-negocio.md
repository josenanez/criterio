# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-01-08
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 139.663 | Caso de negocio, 2026-01-08 |

## Retorno esperado

Retorno esperado en 24 meses.
