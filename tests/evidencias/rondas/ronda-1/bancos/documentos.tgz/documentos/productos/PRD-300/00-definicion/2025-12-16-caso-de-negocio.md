# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2025-12-16
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 252.330 | Caso de negocio, 2025-12-16 |

## Retorno esperado

Retorno esperado en 24 meses.
