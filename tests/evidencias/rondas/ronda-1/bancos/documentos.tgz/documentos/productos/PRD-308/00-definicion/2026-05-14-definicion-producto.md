# Definición de producto · Cuenta de ahorros joven

**Código:** PRD-308
**Gerente de producto:** Diana Molina
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-05-14

## El problema

El segmento Microcomercio no tiene cuenta de ahorros joven.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-08-24 · verificado

## Proyectos que lo construyen

- Ninguno declarado
