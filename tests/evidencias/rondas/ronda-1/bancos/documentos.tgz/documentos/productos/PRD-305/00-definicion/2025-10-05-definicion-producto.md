# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** María Restrepo
**Segmento:** PyME
**Fecha de la definición:** 2025-10-05

## El problema

El segmento PyME no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-04-18 · verificado

## Proyectos que lo construyen

- Ninguno declarado
