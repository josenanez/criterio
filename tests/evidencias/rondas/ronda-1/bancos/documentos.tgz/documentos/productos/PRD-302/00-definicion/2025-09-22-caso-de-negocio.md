# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-09-22
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 177.987 | Caso de negocio, 2025-09-22 |

## Retorno esperado

Retorno esperado en 24 meses.
