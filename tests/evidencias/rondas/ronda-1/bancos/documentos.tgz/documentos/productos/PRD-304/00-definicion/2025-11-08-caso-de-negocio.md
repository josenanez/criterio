# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2025-11-08
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 229.203 | Caso de negocio, 2025-11-08 |

## Retorno esperado

Retorno esperado en 24 meses.
