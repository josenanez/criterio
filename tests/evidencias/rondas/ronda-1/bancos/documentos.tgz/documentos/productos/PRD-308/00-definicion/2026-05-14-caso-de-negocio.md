# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-05-14
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 193.130 | Caso de negocio, 2026-05-14 |

## Retorno esperado

Retorno esperado en 24 meses.
