# Entrevistas · Cuenta PyME

**Ronda:** Ronda · 2025-10-23
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-10-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
