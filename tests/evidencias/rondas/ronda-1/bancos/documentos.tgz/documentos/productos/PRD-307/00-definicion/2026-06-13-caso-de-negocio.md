# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-06-13
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 177.321 | Caso de negocio, 2026-06-13 |

## Retorno esperado

Retorno esperado en 24 meses.
