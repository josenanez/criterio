# Definición de producto · Microseguros

**Código:** PRD-306
**Gerente de producto:** Camilo Beltrán
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-01-08

## El problema

El segmento Base de la pirámide no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-08-25 · verificado

## Proyectos que lo construyen

- Ninguno declarado
