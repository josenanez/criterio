# Tablero de métricas · Pagos QR comercios

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 244.108 | 2026-10-13 |
