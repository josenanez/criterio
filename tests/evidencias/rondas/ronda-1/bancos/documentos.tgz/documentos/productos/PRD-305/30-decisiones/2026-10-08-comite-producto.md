# Comité de producto · Recaudos y cobros

**Fecha:** 2026-10-08
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1050 | Requerimiento REQ-1050 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-1051 | Requerimiento REQ-1051 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-1052 | Requerimiento REQ-1052 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-28 | — |
| REQ-2024 | Requerimiento REQ-2024 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-10-09 | — |

## Decisiones

- Se mantiene el plan
