# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2025-09-16
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 65.386 | Caso de negocio, 2025-09-16 |

## Retorno esperado

Retorno esperado en 24 meses.
