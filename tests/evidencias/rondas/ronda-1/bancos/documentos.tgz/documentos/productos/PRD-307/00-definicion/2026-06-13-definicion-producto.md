# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Felipe Arango
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-06-13

## El problema

El segmento Microcomercio no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-06-18 · verificado

## Proyectos que lo construyen

- Ninguno declarado
