# Comité de producto · Cuenta de ahorros joven

**Fecha:** 2026-10-08
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-1080 | Requerimiento REQ-1080 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |
| REQ-1081 | Requerimiento REQ-1081 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-24 | — |
| REQ-1082 | Requerimiento REQ-1082 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-1083 | Requerimiento REQ-1083 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-08 | — |
| REQ-2018 | Requerimiento REQ-2018 | Rubén Cárdenas | se verifica en producción | — | propuesto | 2026-06-07 | — |

## Decisiones

- Se mantiene el plan
