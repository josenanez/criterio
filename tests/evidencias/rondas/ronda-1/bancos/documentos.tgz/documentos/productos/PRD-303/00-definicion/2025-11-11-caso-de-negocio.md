# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2025-11-11
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 163.747 | Caso de negocio, 2025-11-11 |

## Retorno esperado

Retorno esperado en 24 meses.
