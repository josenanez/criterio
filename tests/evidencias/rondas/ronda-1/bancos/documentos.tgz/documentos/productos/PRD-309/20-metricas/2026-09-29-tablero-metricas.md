# Tablero de métricas · Crédito de libre inversión

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 219.448 | 2026-09-29 |
