# Corrida · 2026-10-14-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-14T15:49:13 · **Fin:** 2026-10-14T15:50:09 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 33 | 54 | Revisión del acta PRY-200 (2025-09-23): falta autoridad del gerente, objetivo medible, exclusiones concretas, supuestos, hitos, criterio de éxito con medidor y cadencia. Dependencias 'ninguna' contradicha por el informe. Dije que no sé si el comité de Banca Empresas es el correcto ni quién mide el éxito. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

Revisé el acta de PRY-200 (Originación digital, aprobada el 2025-09-23). Le faltan varios campos, y el más grave es la autoridad del gerente.

Los términos están aceptados: José Francisco Ñáñez, versión 1.0, 2026-10-14. La corrida quedó registrada como `2026-10-14-project-charter-1`.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no existe. La proyección al cierre (1.237.336417 COP) ya supera lo aprobado (1.200.000.000) en 37.336.417 COP (3,1 %). Con un cambio regulatorio en discusión, cada decisión de monto o alcance sube al comité o se toma sin saber si le correspondía a Rubén Cárdenas.
- **Objetivo de negocio:** dice "Entregar originación digital", que es la solución, no un resultado medible.
- **Exclusiones:** "lo que otro proyecto cubre" no nombra qué ni cuál proyecto, así que no sirve para rechazar una petición de alcance.
- **Alcance:** "Componentes 1 a 3" sin detalle de cada uno.
- **Criterio de éxito:** "en producción y medido", sin meta ni quién mide.
- **Supuestos y restricciones:** ausentes.
- **Dependencias:** el acta dice "ninguna declarada", pero el informe del 2026-10-10 muestra una aprobación regulatoria y la revisión del equipo de seguridad. Esos vacíos ya dejaron dos riesgos sin dueño.
- **Hitos:** solo hay inicio y cierre, así que el 66 % de avance declarado no se puede verificar.
- **Comité y cadencia:** el comité es el de Banca Empresas y el área dueña es Banca de Personas. El acta no explica la diferencia ni dice la cadencia.
- **Patrocinador y gerente:** Javier Hoyos y Rubén Cárdenas, sin hallazgo.

**Fuera del acta**
- El informe reporta ejecutado (687.650.908) mayor que comprometido (665.817.971). Puede ser un error de captura o gasto sin compromiso, y los documentos no lo resuelven.
- Lo ejecutado es el 57,3 % de lo aprobado, contra un 66 % de avance declarado.

**Lo que no sé:** si el Comité de Banca Empresas es el correcto, quién mide el éxito, y si hubo algún acuerdo verbal sobre la autoridad del gerente. Esos campos quedaron como "pendiente de definir". Solo había dos documentos del proyecto, el acta y el informe de avance.

**Qué sigue**
- Llevar al comité la definición de la autoridad del gerente: es una decisión, no un trámite.
- Pasar al registro RAID los dos supuestos que salieron de la revisión: la aprobación regulatoria y la revisión del equipo de seguridad.

Archivos en `/home/claude/banco/ronda-1/bancos/espacio/estado/corridas/`:
- `salida-project-charter.md`
- `2026-10-14-project-charter-1.md`
