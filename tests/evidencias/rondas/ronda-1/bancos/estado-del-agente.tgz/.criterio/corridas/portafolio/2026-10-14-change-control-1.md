# Corrida · 2026-10-14-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-203 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-14T15:45:12 · **Fin:** 2026-10-14T15:46:15 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 42 | 54 | Solicitud +30 días a la salida a producción de PRY-203 (v2 -> 2027-04-07; +142 días vs original). Impacto en portafolio 0 alcanzados, pero el acta no declara dependencias: efecto desconocido, no nulo. No dije: motivo, solicitante, costo, alcance, holgura. Hallazgos: sin autoridad declarada; CC-01 sin acta de comité. Va a comité por defecto; no se registró línea base 3. |

Por señal (`change-control`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

Armé la solicitud de cambio para mover 30 días la salida a producción de PRY-203 (Open Banking). Queda en comité y no registré una línea base nueva. La solicitud no dice quién la pide, por qué, ni qué pasa con el alcance y el costo.

**Plazos**
- La salida pasaría del 2027-03-08 al 2027-04-07.
- Contra la línea base original (2026-11-16) el atraso sería de 142 días: 112 ya aprobados con CC-01 y 30 de este cambio.
- Contra la línea base vigente serían 30 días, y las replanificaciones pasarían de 1 a 2.

**Efecto en el portafolio**
- El cálculo da 0 proyectos alcanzados, pero eso no significa que no haya efecto.
- El acta declara «ninguna dependencia» y es poco probable que sea cierto para un proyecto de Open Banking. El efecto es desconocido, no nulo.
- Tampoco sé cuántos días se movería cada proyecto afectado, porque la ficha no tiene holgura por actividad.

**Quién decide**
- La ficha no tiene autoridad declarada: el acta no fija umbrales para aprobar cambios. Por eso el paquete va al Comité de Banca Empresas por defecto, y ese vacío es el hallazgo de fondo.
- CC-01 dice «autorizada por el comité», pero no hay acta de comité que lo respalde. El script reconcilia los 112 días con la solicitud (0 sin autorizar), pero esa autorización es solo la palabra de la propia solicitud. Este cambio se montaría sobre ella.

**Contexto del proyecto**
- Está en rojo, con 45 % de avance declarado frente al 80–100 % que sustenta el plan.
- Datacore tiene tres entregables vencidos (150, 80 y 11 días) y una factura de 631.036.273 COP sin entrega aceptada. Los 30 días pueden estar tapando un atraso que hoy no tiene nombre.

**Qué falta pedir:** a María Restrepo, el motivo, el impacto en alcance y costo, y las dependencias reales. Al comité, el acta que respalde CC-01.

Los términos (TERMS.md v1.0) ya estaban aceptados y la corrida quedó registrada.

Archivos en `/home/claude/banco/ronda-1/bancos/espacio/estado/corridas/`:
- `salida-change-control.md`
- `2026-10-14-change-control-1.md`
