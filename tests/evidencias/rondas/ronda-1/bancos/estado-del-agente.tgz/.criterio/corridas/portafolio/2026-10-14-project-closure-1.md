# Corrida · 2026-10-14-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-14T15:50:14 · **Fin:** 2026-10-14T15:51:10 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 36 | 54 | No se produjo acta de cierre: el proyecto sigue abierto (66% declarado, amarillo, cierre comprometido 2026-12-04, nadie declara que terminó). Dijo que no sabía: estado de los 3 componentes, métrica de 'medido', línea base y reprogramación, dolientes de los 2 riesgos, por qué ejecutado supera comprometido. Archivo no movido. |

Por señal (`project-closure`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

PRY-200 no se puede cerrar hoy, así que no produje el acta de cierre. Ningún documento dice que el proyecto terminó. El informe del 2026-10-10 lo reporta en amarillo, con 66% de avance, y el cierre comprometido es el 2026-12-04.

Los términos 1.0 ya estaban aceptados en la configuración (José Francisco Ñáñez, 2026-10-14). Leí la ficha de PRY-200, el acta de constitución del 2025-09-23, el informe de avance del 2026-10-10 y la salida de `compute`.

- **Criterio de éxito:** el acta dice "Originación digital en producción y medido". No define qué se mide ni contra qué. Ningún documento muestra que esté en producción ni que se haya medido nada.
- **Alcance:** el acta lista tres componentes sin detalle, y la ficha no tiene hitos. El 66% declarado no se puede contrastar con nada.
- **Línea base:** no existe, y hay 0 replanificaciones registradas. El informe dice que "se reprogramó la salida", pero la ficha conserva la fecha del acta. No se sabe cuánto se movió ni quién lo aprobó, así que no se puede calcular la desviación de fecha.
- **Presupuesto:** de los 1.200.000.000 COP aprobados, hay 665.817.971 comprometidos y 687.650.908 ejecutados (57,3%). La proyección es 1.237.336.417, un 3,1% sobre lo aprobado.
- **Ejecutado mayor que comprometido:** no debería pasar. No sé si es un error del informe o un gasto sin compromiso registrado; hay que preguntárselo al gerente, Rubén Cárdenas.
- **RAID:** los dos riesgos abiertos (cambio regulatorio y disponibilidad del equipo de seguridad) no tienen doliente. El acta declara "ninguna" dependencia, aunque el informe menciona la ventana de operaciones y el equipo de seguridad como pendientes.
- **Lecciones:** ninguna entra. No hay hechos con fecha y efecto a los que anclarlas.
- **Archivo:** tomé la respuesta "no". Mover la carpeta a `archivo/` sacaría del barrido diario a un proyecto que sigue activo.

La salida lista lo que haría falta para cerrarlo: una declaración de cierre de Rubén Cárdenas o de Javier Hoyos, evidencia de producción y medición, una línea base con el registro de la reprogramación, y un doliente con nombre para cada riesgo.

La corrida quedó registrada como `2026-10-14-project-closure-1`. Lo que te mostré está guardado en `estado/corridas/salida-project-closure.md`.
