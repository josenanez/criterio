# Corrida · 2026-10-14-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-301

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-301

**Inicio:** 2026-10-14T15:56:59 · **Fin:** 2026-10-14T15:57:07 · **Duración:** 8 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No existe la configuración de `PRD-301`: en `.criterio/producto/` solo está `PRD-306`, y la regla del comando es parar en vez de buscarla en otro sitio o inventarla.

No puedo correr `/product-overlap` para PRD-301. No ejecuté `corrida-inicio` ni ningún cruce, y no se registró ninguna corrida.

Para seguir, ejecuta `/criterio-product:product-setup` con el código PRD-301. Si querías `PRD-306`, que es el único configurado, vuelve a lanzar el comando con ese código.
