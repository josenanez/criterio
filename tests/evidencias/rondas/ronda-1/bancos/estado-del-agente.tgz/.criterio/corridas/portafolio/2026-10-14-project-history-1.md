# Corrida · 2026-10-14-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-14T15:46:21 · **Fin:** 2026-10-14T15:47:32 · **Duración:** 71 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 50 | 54 | Historia de PRY-203 sobre 8 documentos (2026-02-27 a 2026-10-12). No se pudo calcular meses declarando sin sustento (una sola declaración), ni confirmar que cronograma v1 sea la línea base original (fechado 02-27 pero con hitos cerrados), ni la autorización de CC-01 (sin acta de comité). Sin documentos abril-junio 2026. |

Por señal (`project-history`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

## Historia · PRY-203 Open Banking · 2026-02-27 a 2026-10-12

Leí 8 documentos de la carpeta del proyecto. Los términos quedaron aceptados (v1.0, 2026-10-14, José Francisco Ñáñez), como indicaste para esta prueba. Abril–junio de 2026 no tiene ningún documento, y julio–septiembre tiene solo la factura del 09-15.

**En una línea:** el proyecto se aprobó el 2026-02-27 con salida a producción el 2026-11-16. Después del contrato del 03-03 no hay nada hasta la factura del 09-15, y casi todo el rastro aparece entre el 10-02 y el 10-12. En ese tramo está CC-01, que pide +112 días y +224.000.000 COP y se declara "autorizada por el comité". El 10-12 el cronograma v2 mueve la salida al 2027-03-08 y el informe declara Rojo con 45%.

**Las cifras** (copiadas de `compute`):

| Replanificaciones | Atraso vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 112 días (44.4 %) | No calculable (una sola declaración) | 0 |

- **Hitos sin respaldo:** el cronograma marca 4 de 5 hitos como cerrados, el primero el 2026-04-28, y ninguno tiene documento que lo respalde. Ese cronograma sostiene entre 80 y 100% de avance; el informe reporta 45%, una brecha de 35 puntos.
- **Proveedor:** los 3 entregables de Datacore siguen pendientes, con 150, 80 y 11 días de atraso. Aun así se radicó el 09-15 una factura de 631.036.273 COP sin acta de recibo, que el contrato exige.
- **CC-01:** se autoriza a sí misma. No hay acta de comité que lo registre, y el comité del 10-02 es anterior a la solicitud y no lo menciona. La línea base v2 se publicó 5 días después de la solicitud.
- **Compromisos:** ninguno se repitió, porque hay una sola minuta. Hay uno abierto: Laura Vélez, "Entregar el punto 30", para el 10-28.

**Lo que no sé:**
- **Cronograma v1:** lleva fecha 2026-02-27 pero marca cuatro hitos como "cerrado" cuando esos hitos vencen entre abril y septiembre. No puedo afirmar que sea la línea base original.
- **Fechas del acta:** el cierre del acta (2026-12-12) y la salida a producción (2026-11-16) son fechas distintas, y la carpeta no explica la diferencia.
- **Intención:** nada de esto indica que alguien ocultara algo. Es la conversación a tener con la gerente y el comité, con estos datos delante.

Puedo llevar la historia al comité del 2026-10-20, donde hay dos decisiones que salen de ella (la factura sin acta de recibo y la autorización de CC-01), o al cierre del proyecto.

La corrida quedó registrada como `2026-10-14-project-history-1`, con el texto completo en `estado/corridas/salida-project-history.md`. Tardó 50 segundos y no pudo medir cuántos documentos se leyeron.
