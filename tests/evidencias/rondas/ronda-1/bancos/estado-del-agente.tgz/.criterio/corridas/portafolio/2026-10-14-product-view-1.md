# Corrida · 2026-10-14-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view recaudos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T15:53:17 · **Fin:** 2026-10-14T15:53:58 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 21 | 54 | Producto con un solo proyecto (PRY-211): sin seccion de producto, solo sus senales. Declaro que no se pudo medir autoridad ni fase, campos de identidad con 14 meses, y 4 proyectos sin producto (No aplica). |

Por señal (`product-view`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

## Productos al 2026-10-14: recaudos

Las cifras salen de las fichas del estado, recalculadas con `compute` hoy. Los términos están aceptados (versión 1.0, 2026-10-14).

**Recaudos tiene un solo proyecto, PRY-211 Cobranza digital.** La vista por producto no aporta nada con un solo proyecto, así que no armé la sección de producto. Esto es lo que el cálculo dice del proyecto:

- **Estado «verde» contra evidencia.** El informe del 2026-09-25 declara verde, pero dos señales quedan sin explicar (ver los dos puntos siguientes).
- **Avance.** Declara 33,0 % y el plan sustenta 100 % (4 de 4 hitos cumplidos), una brecha de 67,0 puntos.
- **Hitos sin evidencia.** «Diseño funcional aprobado» (vencía 2025-10-09, 370 días) e «Integración con el core» (vencía 2026-02-02, 254 días) figuran cumplidos sin evidencia.
- **Fecha.** El fin comprometido es 2026-04-01, anterior a hoy. No hay replanificaciones ni desviación contra la línea base. Un proyecto verde al 33 % con la fecha de fin vencida es una contradicción para el comité.
- **Dinero (COP).**
  - Aprobado: 18.000.000.000.
  - Comprometido: 10.376.957.039 (57,6 %).
  - Ejecutado: 10.387.931.433 (57,7 %).
  - Proyección: 18.661.301.307 (3,7 % sobre lo aprobado).
  - Disponible real: 7.623.042.961.
  - El proyecto trae las cuatro cifras. Lo ejecutado figura por encima de lo comprometido, así que hay que confirmar cuál de las dos está desactualizada.
- **Dependencias y proveedores.** No hay ninguna declarada ni registrada.
- **Lo que no sé.** Faltan autoridad y fase. Los campos de identidad y plan tienen 14 meses. Ninguna de las 15 fuentes está marcada como evidencia o declaración.

También reporto cuatro proyectos sin producto declarado (marcados «No aplica»): PRY-202, PRY-205, PRY-208 y PRY-210. Nadie puede responder por el conjunto al que sirven.

Dejé la salida en `estado/corridas/salida-product-view.md`. La corrida quedó registrada como `2026-10-14-product-view-1` (21 segundos, 13 proyectos, 54 hallazgos en el portafolio).
