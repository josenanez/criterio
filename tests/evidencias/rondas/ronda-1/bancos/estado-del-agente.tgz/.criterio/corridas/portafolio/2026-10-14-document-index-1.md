# Corrida · 2026-10-14-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T15:39:31 · **Fin:** 2026-10-14T15:40:11 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 26 | 54 | 69 documentos, 0 por releer. 10 citas de PRY-202 (pm_record) marcadas rotas por ruta sin prefijo de carpeta; el archivo existe. No se editó ninguna ficha. Términos v1.0 ya aceptados en config. |

Por señal (`document-index`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

## Carpeta al 2026-10-14

**Documentos:** 69 · **Sin cambio:** 69 · **Hay que releer:** 0

No cambió el contenido de ningún documento. No hay archivos reguardados, renombrados, movidos ni borrados. Tampoco hay formatos que no se pudieran leer. Este comando solo cuenta y compara hashes, y no abrió ningún documento.

**Citas que dejaron de resolver: 10, todas de PRY-202.** Son los campos `pm_record.identity.*` (code, name, business_area, sponsor, manager, committee), `pm_record.plan.*` (start_date, end_date) y `pm_record.money.*` (currency, approved). Todos citan `00-gobierno/2026-02-19-acta-constitucion.md`.

El documento no se perdió. Está en disco, en `PRY-202-migración-a-la-nube/00-gobierno/2026-02-19-acta-constitucion.md`. Esos 10 campos escriben la ruta sin el prefijo de la carpeta del proyecto. Los demás campos de la misma ficha sí lo llevan, y citan ese mismo acta en otros 10 campos. Es un problema de cómo está escrita la ruta, no de contenido.

No hace falta `/portfolio-scan`, porque no hay proyectos que recomputar. Dejé las fichas como estaban. Si quieres, corrijo las 10 rutas añadiendo el prefijo, una por una y mostrando el cambio.

La corrida quedó registrada como `2026-10-14-document-index-1`. Los términos v1.0 ya estaban aceptados en la configuración a nombre de José Francisco Ñáñez, con fecha 2026-10-14.

La salida completa está en `/home/claude/banco/ronda-1/bancos/espacio/estado/corridas/salida-document-index.md`.
