# Corrida · 2026-10-14-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-209

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-14T15:40:16 · **Fin:** 2026-10-14T15:41:05 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 26 | 54 | Informe de PRY-209: verde declarado contradicho en parte (3 hitos cumplidos sin evidencia, avance 80% vs plan 100%, 16 días de silencio). Dijo no saber: autoridad, fase, proveedores, reuniones, dueños de riesgos; cierre 2026-07-01 (cronograma) vs 2026-08-22 (acta) sin resolver. |

Por señal (`status-report`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

## PRY-209 · Nómina electrónica — estado al 2026-10-14

Este informe sale de la ficha `estado/records/PRY-209.json`, actualizada el 2026-10-14. Los términos (v1.0, aceptados por José Francisco Ñáñez el 2026-10-14) ya estaban registrados en la configuración.

**Declara el gerente (Paula Céspedes):** verde, 80 %, al 2026-09-28 (hace 16 días).
**Sustento documental:** contradicho en parte. El verde no explica tres señales:
- hitos cumplidos sin evidencia,
- avance menor que el que sostiene el plan,
- silencio.

**Último documento:** 2026-09-28 (16 días; el umbral es 15). **Última reunión:** sin dato, la ficha no registra ninguna.

**Contra el plan**
- **Cierre:** la línea base original y la vigente dicen 2026-07-01, con 0 días de desviación y 0 replanificaciones. Esa fecha pasó hace 105 días y nadie la movió, así que el cero mide contra una fecha que nadie actualizó.
- **Presupuesto:** COP 18.000.000.000 aprobados, con proyección de COP 18.485.959.643 (2,7 % sobre lo aprobado).
- **Ejecución:** ejecutado 16,6 %, comprometido 65,7 %.

**Hitos**
- Los tres figuran como cumplidos, sin evidencia (311, 208 y 105 días desde su fecha).
- El plan sostendría 100 % de avance y el gerente declara 80 %. Las dos cifras no pueden ser ciertas a la vez.

**Dónde no coincide**
- El cronograma dice cierre 2026-07-01 y el acta, según la ficha, 2026-08-22. El script no lo marcó como conflicto y no lo resolví a ojo.
- Todas las cifras de dinero salen solo del informe del gerente.

**Abierto**
- Hay dos riesgos sin dueño, del informe del 2026-09-28: un cambio regulatorio que puede mover el alcance y un proveedor que no confirmó la última entrega. La ficha no trae su fecha de apertura, así que no puedo dar días sin movimiento.
- No hay compromisos registrados, ni vencidos ni de otro tipo.
- No hay dependencias registradas.

**Sin dato**
- Autoridad, fase, proveedores y reuniones.
- Dueños de los riesgos.
- Los campos de identidad y plan tienen 14 meses de antigüedad, sobre el umbral de 12.

Puedo preparar el punto de comité para el 2026-10-20.

**Pie:** plugin criterio-portfolio 0.3.6 · ficha del 2026-10-14 · términos v1.0 (TERMS.md).

La corrida quedó registrada como `2026-10-14-status-report-1` (26 s, 1 caso). El texto completo está en `estado/corridas/salida-status-report.md`.
