# Corrida · 2026-10-14-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta TERMS.md para esta prueba, fecha 2026-10-14. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-14T15:54:03 · **Fin:** 2026-10-14T15:54:49 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 69 | 23 | 54 | 6 verdes contradichos; PRY-203 con proveedor facturado sin entrega |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 23, `progress_vs_plan` 9, `declared_vs_evidence` 6, `commitment_undated` 3, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `vendor_invoiced_without_delivery` 1, `commitment_overdue` 1, `variance_cost` 1, `change_without_baseline` 1, `silent` 1

## Lo que el agente mostró

Generé el informe de portafolio en HTML: 27 páginas para 13 proyectos, en `/home/claude/banco/ronda-1/bancos/espacio/reportes`. Los términos de uso ya estaban aceptados en la versión 1.0, así que no hubo que pedirlos de nuevo.

**Qué cargué:** las 13 fichas de `estado/records/`, todas con fecha 2026-10-14. Ninguna tiene más de una semana, así que no hizo falta un barrido previo.

**Qué cambió:** nada. La instantánea anterior es de hoy, así que esta corrida no tiene un punto de comparación real.

**Qué encontró:** 10 de 13 proyectos tienen hallazgos, 54 señales en total. Lo más grave:
- **Verde contradicho:** 6 proyectos se declaran en verde y la evidencia lo contradice (PRY-201, 207, 208, 209, 210 y 211).
- **Hitos sin evidencia:** hay 23 hitos declarados como cumplidos que no tienen evidencia. El más viejo es de PRY-210, con 415 días.
- **PRY-203:** lleva +112 días de atraso contra el plan original. Además, el proveedor Datacore Colombia tiene 3 entregables atrasados y 631.036.273 facturados sin entrega.
- **PRY-205:** +101 días de atraso, y el movimiento de línea base no tiene autorización. PRY-208 también replanificó sin autorización, por 21 días.
- **PRY-207:** proyecta un costo 22,9 % por encima del aprobado, y el cambio CC-01 no tiene línea base.
- **PRY-202:** la fecha de fin tiene dos valores, 2026-09-25 en el cronograma y 2026-10-16 en el acta.
- **PRY-209:** lleva 16 días en silencio.

**Qué vista va a quién:**
- `reportes/index.html` es la vista por campo, con la cadena de evidencia. Es para quien va a actuar.
- `reportes/decisiones.html` es la vista por decisión. Es para el patrocinador, antes del comité del 2026-10-20.

Para imprimir en PDF, se imprime el HTML.

**Pendientes y límites:**
- Ninguno de los 13 proyectos tiene una autoridad de aprobación registrada.
- No hice la confirmación mensual de cinco campos porque la sesión es sin interfaz.
- Dejé guardado lo que te muestro aquí en `estado/corridas/salida-portfolio-report.md` y registré la corrida como `2026-10-14-portfolio-report-1`.
