*Sale de la ficha `estado/records/PRY-203.json` (actualizada 2026-10-14), el acta de constitución, la solicitud CC-01 y el cronograma v2. Términos TERMS.md v1.0 aceptados por José Francisco Ñáñez el 2026-10-14.*

## Solicitud de cambio — PRY-203 Open Banking — 2026-10-14

**Qué se pide:** mover la salida a producción 30 días (de 2027-03-08 a 2027-04-07). · **Quién lo pide:** no consta en lo recibido (la orden no lo dice y no hay documento de solicitud). · **Por qué:** no consta. Sin motivo no hay base para una línea base nueva.

### Línea base de la que parte
- v1 (2026-02-27): salida a producción 2026-11-16. El acta declara además cierre 2026-12-12.
- v2 (2026-10-12), por CC-01 (ampliación de alcance, +112 días, +224.000.000 COP): salida a producción 2027-03-08. Es la vigente.
- Replanificaciones: 1. El proyecto ya declara estado rojo y 45 % de avance (informe del 2026-10-12).

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1 a 3 + ampliación de CC-01 (sin detalle) | No declarado | **No declarado.** |
| Tiempo | Salida a producción 2027-03-08 | 2027-04-07 | +30 días |
| Costo | Aprobado 6.800.000.000 COP; ejecutado 3.066.221.014; proyección 6.288.285.107 | No declarado | **No declarado.** No lo calculo: sin la estructura de costos no hay cifra que sostener. |

Una sola dimensión con impacto declarado (tiempo). Alcance y costo en blanco significan que alguien los va a absorber —en horas no pagadas, en calidad, o en presupuesto de una proyección que ya está a 7,5 % bajo lo aprobado— y la solicitud no dice quién. Dos sospechas, no hechos: los 30 días pueden ser el precio de un atraso que hoy no tiene nombre, y el contrato con Datacore (CT-948) tiene tres entregables vencidos (150, 80 y 11 días) y una factura de 631.036.273 COP sin entrega aceptada.

### Efecto en el portafolio
El cálculo (`impact`, 30 días) devuelve **0 proyectos alcanzados**, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar. El único hito por el que pasa el cambio es «Salida a producción» (2027-03-08).

**Esto no es «sin efecto».** El acta dice «Dependencias declaradas: ninguna» y el RAID de la ficha no tiene ninguna. Un proyecto de Open Banking que no depende de nadie ni nadie de él es poco probable; lo seguro es que **nadie lo declaró**. Hasta que alguien confirme lo contrario, el efecto en el portafolio es desconocido, no nulo.
Tampoco sé cuántos días se mueve cada afectado: la ficha no tiene holgura por actividad.

| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno declarado | — | María Restrepo (gerente de PRY-203) |

### Quién decide
**Autoridad requerida:** no determinable. La ficha tiene `identity.authority` en *no encontrado*: el acta no fija umbrales de tiempo ni de costo para aprobar cambios. · **Según:** acta 2026-02-27 (sin cláusula de autoridad). · **Va a comité:** **sí, por defecto**, el Comité de Banca Empresas (el del acta), porque sin autoridad declarada nadie por debajo puede aprobar.
Ese vacío es el hallazgo de fondo, antes que los 30 días.

**Hallazgo sobre CC-01 (el cambio anterior):** dice «Autorizada por el comité» y no hay acta de comité que lo registre. El script reconcilia los 112 días de la línea base contra los 112 aprobados (0 sin autorizar), pero esa autorización es solo la palabra de la propia solicitud. Si el comité no lo aprobó, la v2 no tiene respaldo y este cambio se monta sobre ella.

### Si no se aprueba
El proyecto sigue en v2: salida a producción 2027-03-08, 112 días sobre la original, 44,4 %. Con los entregables de Datacore vencidos y 35 puntos entre el avance declarado (45 %) y lo que sustenta el plan (80–100 %), no hay en los documentos nada que muestre que 2027-03-08 se sostiene.

### Si se aprueba
Línea base 3 — salida a producción **2027-04-07** · presupuesto **no declarado** (hoy 6.800.000.000 COP, incluidos los 224.000.000 de CC-01 según la ficha, que no lo recalcula) · motivo: **pendiente**.
Desviación acumulada contra la línea base **original** (2026-11-16): **+142 días** (112 + 30) · costo: +224.000.000 COP ya aprobados, más lo que este cambio agregue (no declarado).
Contra la vigente (v2): +30 días. Replanificaciones: de 1 a 2.

### Lo que no sé
Quién pide, por qué, cuánto cuesta, qué entra o sale de alcance, de quién depende el proyecto, y qué dice el acta del comité sobre CC-01. No inventé ninguno.

### Para avanzar
1. Pedir a María Restrepo motivo, impacto en alcance y costo, y las dependencias reales del proyecto.
2. Llevarlo al Comité de Banca Empresas junto con el acta que respalde CC-01 y la definición de autoridad. No registro línea base 3 hasta que lo apruebe quien pueda.

*Pie de rigor: cifras de `portafolio.py compute` e `impact` sobre la ficha del 2026-10-14. La holgura por actividad, el impacto en alcance y costo y el motivo no están en ninguna fuente y quedan declarados como no encontrados. Mi lectura puede equivocarse: confirmar con la gerente y el comité antes de decidir.*
