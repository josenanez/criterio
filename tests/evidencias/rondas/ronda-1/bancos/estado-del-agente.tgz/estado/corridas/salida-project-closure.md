Cierre de PRY-200 · Originación digital · 2026-10-14

Sale de: la ficha `estado/records/PRY-200.json`, el acta de constitución (`00-gobierno/2025-09-23-acta-constitucion.docx`), el informe de avance del 2026-10-10 (`20-seguimiento/2026-10-10-informe-avance.md`) y la salida de `compute` del 2026-10-14. Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14.

## Cierre — PRY-200 Originación digital — 2026-10-14

**Resultado: no se produce el acta de cierre.** Ningún documento declara que el proyecto terminó. El último informe (2026-10-10) lo reporta en **amarillo, con 66% de avance**, y la fecha de cierre comprometida es **2026-12-04**, que todavía no llega. Cerrarlo hoy sería cerrarlo por decisión de alguien, sin que ningún documento lo diga. Lo que sigue es lo que se puede decir hoy y lo que habría que tener para cerrarlo.

### Contra lo comprometido
**Criterio de éxito:** "Originación digital en producción y medido." (acta de constitución, 2025-09-23). Sí fue declarado, pero no trae métrica, umbral ni fecha de medición. "Medido" no dice qué se mide ni contra qué.
**Se cumplió:** no se puede determinar. Ningún documento muestra que esté en producción ni que se haya medido nada.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato | El acta lista "Componente 1" sin detalle |
| Componente 2 | Sin dato | El acta lista "Componente 2" sin detalle |
| Componente 3 | Sin dato | El acta lista "Componente 3" sin detalle |

La ficha no tiene hitos (`plan.milestones` vacío), así que el 66% declarado no se puede contrastar con nada.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta; no nombra el proyecto) | Sin dato | 2025-09-23 (fecha del acta) |

No hay solicitudes de cambio registradas (cambios: 0), por lo que no consta ningún recorte de alcance posterior al acta. El informe de avance dice que un cambio regulatorio "puede mover el alcance", pero eso es un riesgo, no una decisión.

### Números finales
No son finales: el proyecto sigue abierto. Son los números a la fecha de corte del 2026-10-10.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-12-04 (acta) | 2026-12-04 | Sin dato | No se puede calcular: no hay línea base registrada |
| Presupuesto aprobado | 1.200.000.000 COP | 1.200.000.000 COP | Sin dato | Sin dato |
| Comprometido | | 665.817.971 COP (55,5% del aprobado) | | |
| Ejecutado | | 687.650.908 COP (57,3% del aprobado) | | |
| Proyección al cierre | | 1.237.336.417 COP | | 3,1% sobre el aprobado (umbral: 10%) |

- Disponible real: 534.182.029 COP.
- Replanificaciones registradas: **0**. El informe del 2026-10-10 dice que "se reprogramó la salida por ventana de cambio del área de operaciones". No hay línea base ni cambio registrado que lo respalde, y la ficha sigue con la fecha del acta. No se sabe cuánto se movió la salida ni quién lo aprobó.
- El ejecutado (687.650.908) es mayor que el comprometido (665.817.971). Eso no debería pasar. No sé si es un error del informe o un gasto sin compromiso registrado. Hay que preguntárselo a Rubén Cárdenas.

### RAID al cierre
**Materializados:** sin dato. Nadie lo dice en los documentos.
**No materializados:** sin dato.
**Abiertos, con doliente:** ninguno tiene doliente.
- Cambio regulatorio en discusión que puede mover el alcance. Doliente: no consta (informe 2026-10-10).
- Disponibilidad del equipo de seguridad para la revisión final. Doliente: no consta (informe 2026-10-10).

El acta declara "ninguna" dependencia. El informe, en cambio, menciona una aprobación regulatoria recibida y la dependencia de una ventana de cambio de operaciones y del equipo de seguridad. Dos de ellas parecen dependencias y no están registradas como tales.
Sin doliente con nombre, estos dos no se pueden dar por cerrados ni dejar abiertos tras un cierre.

### Lecciones
No se registra ninguna. Las únicas que habría hoy serían genéricas ("registrar las dependencias", "documentar los cambios") y no se pueden anclar a un hecho con fecha y efecto. Hechos documentados que podrían volverse lección cuando el proyecto cierre:
- Salida reprogramada por la ventana de operaciones: sin fecha original ni nueva, sin efecto medible todavía.
- Aprobación regulatoria "pendiente desde el trimestre anterior" y recibida en el periodo del informe: no dice qué fecha era la esperada ni cuánto se perdió esperándola.

### Sin dato
- Declaración de que el proyecto terminó, y quién la hace.
- Qué son los Componentes 1, 2 y 3, y su estado.
- Métrica del criterio de éxito "medido".
- Línea base de fechas, hitos, y la fecha y el alcance de la salida reprogramada.
- Quién aprobó la reprogramación.
- Autoridad que decide sobre el proyecto (`identity.authority` no encontrada) y fase (`identity.phase`).
- Doliente de los dos riesgos abiertos.
- Explicación de que el ejecutado supere al comprometido.
- Proveedores y contratos: la ficha no trae ninguno.
- Otro punto: el acta pone al proyecto en Banca de Personas, pero lo aprueba el "Comité de Banca Empresas". Puede ser legítimo, pero el acta no lo explica.
- Los 15 campos de la ficha están sin marcar como evidencia o declaración (evidencia 0, declaración 0, sin marcar 15), y 11 tienen más de 12 meses de antigüedad (13 meses, todos del acta).

### Qué haría falta para cerrarlo
1. Que Rubén Cárdenas o Javier Hoyos declaren por escrito que terminó, contra el criterio de éxito del acta.
2. Evidencia de producción y de la medición.
3. Una línea base con la fecha de salida y el registro del cambio de la reprogramación.
4. Un doliente con nombre para cada riesgo abierto.

### Archivo
No se mueve la carpeta del proyecto a `archivo/` ni se congela la ficha. Respuesta tomada para esta prueba: no, porque el proyecto no está cerrado y sacarlo del barrido diario lo dejaría sin vigilancia con un 66% declarado, estado amarillo y 4 días de silencio.

---
Pie de rigor: ficha del 2026-10-14, informe de avance del 2026-10-10 (declarado por el gerente, sin evidencia que lo respalde). Cifras tomadas de la salida de `compute`. No se calculó ninguna cifra que el script no entregara. No se declaró cumplimiento ni cierre.
