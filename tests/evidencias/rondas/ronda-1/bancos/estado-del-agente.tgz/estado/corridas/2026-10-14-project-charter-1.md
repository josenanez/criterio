# Corrida del 2026-10-14 · project-charter

13 proyectos · 33 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

Revisión del acta PRY-200 (2025-09-23): falta autoridad del gerente, objetivo medible, exclusiones concretas, supuestos, hitos, criterio de éxito con medidor y cadencia. Dependencias 'ninguna' contradicha por el informe. Dije que no sé si el comité de Banca Empresas es el correcto ni quién mide el éxito.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

**Acta previa:** sí existe, aprobada el 2025-09-23 (`PRY-200-originación-digital/00-gobierno/2025-09-23-acta-constitucion.docx`). Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14.

## Acta — PRY-200 · Originación digital
**Estado:** existe, del 2025-09-23

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | **Ausente** | No hay monto ni tipo de cambio que Rubén Cárdenas pueda decidir solo. La proyección al cierre (1.237.336.417 COP) ya supera lo aprobado (1.200.000.000) en 37.336.417 COP (3,1 %), y el informe habla de una salida reprogramada y de un cambio regulatorio que puede mover el alcance. Sin autoridad escrita, cada una de esas decisiones sube al comité, o se toma sin que nadie pueda decir si le correspondía. |
| Objetivo de negocio | Describe la solución, no un resultado | "Entregar originación digital para Banca de Personas" es lo que se construye, no lo que el negocio gana. Sin resultado medible no se puede decidir si un recorte de alcance lo pone en riesgo. |
| Exclusiones | Declaradas pero vacías | "Lo que otro proyecto cubre" no nombra qué ni cuál proyecto. No impide que el trabajo se duplique ni que algo quede sin dueño, y no sirve para rechazar una petición de alcance. |
| Alcance | Sin detalle | "Componente 1, 2, 3" no dice qué es cada uno. Con el cambio regulatorio en discusión, nadie puede decir qué componente se movería. |
| Criterio de éxito | No medible, sin medidor | "En producción y medido": no dice qué se mide, con qué meta, ni quién mide. El cierre queda a juicio de quien lo declare. |
| Supuestos y restricciones | Ausentes | La aprobación regulatoria y la revisión del equipo de seguridad condicionan el proyecto y no están escritas como supuesto ni restricción. |
| Dependencias | Dice "ninguna declarada" | Contradice el informe del 2026-10-10: depende de una aprobación regulatoria y de la disponibilidad del equipo de seguridad. Ese vacío ya produjo dos riesgos sin dueño. |
| Hitos principales | Ausentes (solo inicio y cierre) | Con un 66 % declarado no hay contra qué verificarlo. Tampoco hay línea base de hitos para medir la reprogramación que menciona el informe. |
| Comité y cadencia | Comité nombrado, cadencia ausente | El comité es el de **Banca Empresas** y el área dueña es **Banca de Personas**. Puede ser correcto, pero el acta no lo explica. Sin cadencia no se sabe cuándo se rinde cuentas. |
| Patrocinador / Gerente | Presentes (Javier Hoyos / Rubén Cárdenas) | Sin hallazgo. |
| Presupuesto aprobado | Presente | Sin hallazgo en el acta. |

### Contenido
**Objetivo de negocio:** "Entregar originación digital para Banca de Personas." Es la solución, no un resultado medible. [acta]
**Alcance:** Componentes 1, 2 y 3, sin detalle de cada uno. [acta]
**Exclusiones:** "Lo que otro proyecto cubre", sin nombrar cuál. [acta]
**Patrocinador:** Javier Hoyos · **Gerente:** Rubén Cárdenas [acta]
**Autoridad del gerente:** **pendiente de definir.** No consta en ningún documento.
**Comité al que reporta:** Comité de Banca Empresas [acta] · **Cadencia:** pendiente de definir
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Originación digital en producción y medido" [acta] · **Lo mide:** pendiente de definir
**Hitos principales:** pendiente de definir. El acta solo trae inicio 2025-10-03 y cierre 2026-12-04. [acta]
**Presupuesto aprobado:** 1.200.000.000 COP, Comité de Banca Empresas, 2025-09-23 [acta]
**Dependencias declaradas:** "ninguna declarada" [acta], contradicha por el informe de avance 2026-10-10.

### Observaciones fuera del acta, para el comité
- El informe del 2026-10-10 reporta ejecutado (687.650.908) mayor que comprometido (665.817.971). Normalmente lo ejecutado es parte de lo comprometido, así que o hay un error de captura o hay gasto sin compromiso. No lo resuelvo desde los documentos.
- Ejecutado equivale al 57,3 % de lo aprobado y el avance declarado es 66 %. No se puede verificar sin hitos.
- Los dos riesgos del informe no tienen dueño.

### Qué sigue
1. **Autoridad del gerente.** El acta no la declara, así que conviene llevar esa definición al comité: es una decisión, no un trámite. La proyección ya excede lo aprobado, por lo que el comité tendrá que decidir esa parte de todos modos. Lo hago como paquete de comité si quieres.
2. **Supuestos.** De esta revisión salen la aprobación regulatoria y la revisión del equipo de seguridad. Puedo pasarlos al registro RAID.

---
**Pie de rigor.** Leí el acta (.docx, 2025-09-23) y el informe de avance (2026-10-10), los dos únicos documentos del proyecto. No hay minutas, contratos ni cambios aprobados posteriores al acta; si existen fuera de la carpeta, no los vi. No completé ningún campo con lo razonable: lo que no está dice "pendiente de definir". No sé si el Comité de Banca Empresas es el correcto, ni quién mide el éxito, ni si hubo un acuerdo verbal sobre la autoridad del gerente.
