## Definición — Microseguros (PRD-306) · contrastada al 2026-10-14
**Documento:** `00-definicion/2026-01-08-definicion-producto.md` (más `2026-01-08-caso-de-negocio.md`) · **del** 2026-01-08 · 5 afirmaciones

Términos: TERMS.md v1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (ya en la configuración). Sesión sin interfaz: las preguntas se tomaron con la respuesta sugerida.

### Lo que la evidencia contradice
Nada. Ningún documento dice lo contrario de lo que afirma la definición. Eso no la sostiene: casi no hay evidencia con la que contrastarla.

### El negocio y los datos
Ninguna. No hay serie medida, así que no se puede calcular una diferencia contra lo declarado (`claim_vs_metric` vacío).

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Volumen mensual de 139.663 | Caso de negocio, 2026-01-08 (se cita a sí mismo como fuente) | Nadie mide el volumen mensual; la cifra no tiene medición, estudio ni entrevista detrás |
| Retorno esperado en 24 meses | Caso de negocio, 2026-01-08 | Sin monto, inversión ni cálculo: no hay qué medir |

### No está dicho en ninguna parte
- Para quién es el producto y cuántos son: se nombra el segmento «Base de la pirámide», no un cliente concreto ni su tamaño.
- Qué es el producto: la propuesta es la línea «Propuesta principal», sin contenido.
- Cómo se sabrá que funcionó: no hay criterio de éxito.
- De dónde sale el 139.663 mensual.
- Qué significa «retorno esperado en 24 meses»: monto, inversión y cálculo.
- Qué verificó el supuesto «El canal actual soporta el volumen»: quién, cómo y con qué.
- Por qué «el segmento no tiene microseguros» es cierto más allá de un cliente: sin cifra de cuántos ni de qué segmento.
- Quién pidió los cinco requerimientos del comité: todos dicen «Cliente entrevistado», y la única entrevista no los nombra.
- Qué proyecto construye el producto: «Ninguno declarado», y los cinco requerimientos tienen «—».
- Qué decidió el comité del 2026-10-09: solo «Se mantiene el plan», con un asistente (el gerente); REQ-1062 sigue propuesto desde 2026-05-29 sin decisión.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El canal actual soporta el volumen | Está marcado «verificado» (declarado 2026-08-25, hace 50 días), pero no hay evidencia a la vista: se trata como supuesto | Una prueba de carga o la capacidad medida del canal, con fuente y fecha, y fijar el volumen contra el que se mide. Hoy ese volumen (139.663) no tiene sustento, así que el supuesto depende de otra cifra sin verificar |

Observación: el supuesto lleva fecha 2026-08-25, posterior a la fecha de la definición (2026-01-08). El documento se editó después de su fecha y no lo dice.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Base de la pirámide no tiene microseguros | Una entrevista a un cliente: «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2025-08-22-entrevistas.docx`) | 2025-08-22 | Débil: es lo que alguien dijo, no lo que alguien pagó; una sola persona, sin segmento ni cifra |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento Base de la pirámide no tiene microseguros | Entrevista del 2025-08-22 | 418 días (13,7 meses), sobre el umbral de 12 meses |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Actividad aseguradora y distribución de seguros | No declarado | Regulación de seguros y de microseguros | — | No tengo la norma a la vista |
| Datos personales de asegurados (segmento de base de la pirámide) | No declarado | Tratamiento y consentimiento | — | No tengo la norma a la vista |
| Cobro de primas por el canal | No declarado | Pagos y consumidor financiero | — | No tengo la norma a la vista |

Nombro lo que se roza; no digo si el producto cumple. Sin país declarado no cito norma. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Problema:** hay una frase, sin medida de cuánto duele ni a quién.
- **Para quién:** falta, el segmento no es un cliente.
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** el Comité de producto (de la configuración), pero la definición no lo dice y el acta del 2026-10-09 solo registra al gerente como asistente.

### Después
El supuesto del canal y la cifra de volumen sin respaldo son candidatos a riesgo con doliente (raid-taxonomy). La definición no está cerrada: no corresponde `/product-charter`.

*Borrador de trabajo, no certificado: verifica cada punto contra los documentos antes de decidir (TERMS.md v1.0).*
