*Fichas cargadas: 13 proyectos (PRY-199 a PRY-211), corte 2026-10-14, cifras de `portafolio.py compute` de hoy. Términos 1.0 aceptados por José Francisco Ñáñez el 2026-10-14. Criterios aplicados: raid-taxonomy, governance-artifacts, portfolio-health.*

# Comité de proyectos — 2026-10-20 (preparado el 2026-10-14)
6 decisiones · 5 escalamientos sin decisión · 10 de 13 proyectos con hallazgos (54 señales en total)

**Una advertencia antes de las decisiones.** En los 13 proyectos el campo `identity.authority` está vacío: ningún documento dice quién tiene la facultad de aprobar un cambio de línea base. Las actas nombran comités distintos (Arquitectura, Banca Empresas, y en las minutas también Riesgos, Medios de Pago y Transformación Digital). Por eso el punto 1 es quién decide. Los puntos 2 a 6 quedan condicionados a su respuesta.

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | No hay ninguna corrida previa de `steering-pack` ni decisión registrada en las fichas. Los comités semanales de cada proyecto no dejan decisiones, solo compromisos. | Ciclo anterior no verificable |

Dos solicitudes de cambio dicen "Autorizada por el comité" (PRY-203 y PRY-207), sin acta ni fecha de esa autorización. Se tratan como declaradas, no sustentadas.

## Decisiones de hoy

### [1] ¿Qué instancia tiene la facultad de aprobar cambios de línea base del portafolio, y se deja por escrito en cada acta?
**Proyecto:** todos (13) · **Quién decide:** patrocinadores y la PMO. No hay documento que lo establezca. · **Si no se decide hoy:** los puntos 2 a 6 se pueden votar, pero no se sabe si el voto vale. Los PM seguirán moviendo líneas base antes de que alguien las autorice, como ya pasó en PRY-205 y PRY-208.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un solo comité de portafolio aprueba todo cambio de línea base | Ninguno | Sin efecto en los proyectos | Sin costo directo |
| B. Cada comité de área aprueba los de su proyecto, con umbral de escalamiento al comité de portafolio | Ninguno | Más lento en los casos que escalan | Sin costo directo |
| C. Dejarlo como está | Ninguno | Sin efecto | Riesgo de líneas base movidas sin autorización |

**Recomendación:** B, con el umbral fijado por el comité. Los proyectos ya responden a comités de área distintos, y B no los reemplaza. No hay en los documentos ningún umbral que respalde un valor concreto, y no lo propongo.

### [2] PRY-205: ¿se aprueba CC-01 (+101 días, 202.000.000 COP adicionales, ampliación de alcance)?
**Proyecto:** PRY-205 Prevención de lavado de activos · **Quién decide:** sin establecer (ver punto 1). Solicitante: Andrés Lozano, que es también el gerente. · **Si no se decide hoy:** la línea base ya está movida 101 días sin autorización. La fecha de cierre vigente es 2027-02-20 y el atraso contra la original es de 101 días (39,3 %).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Se amplía | Cierre 2027-02-20 queda formalizado | +202.000.000 COP sobre 6.800.000.000 aprobados |
| B. Rechazar y volver a la línea base original | Sin ampliación | El cierre vuelve 101 días antes del vigente | Sin costo adicional |
| C. Diferir hasta recibir evidencia de los 2 hitos | Congelado | La línea base original rige mientras tanto | Sin costo adicional |

**Recomendación:** C. El informe del 2026-10-14 dice amarillo y 56 %, pero el plan solo sostiene entre 67 y 100 %, y los 2 hitos cumplidos (Diseño funcional, 2026-05-23; Ambiente de pruebas, 2026-08-17) no tienen acta de recibo. Pedir una ampliación sin poder mostrar lo ya entregado no se sostiene.

### [3] PRY-208: ¿se aprueba CC-01 (+21 días, 42.000.000 COP adicionales, ampliación de alcance)?
**Proyecto:** PRY-208 Motor de decisión · **Quién decide:** sin establecer (ver punto 1). Solicitante: Óscar Ramírez. · **Si no se decide hoy:** la línea base ya se movió 21 días (6,5 % contra la original) sin autorización, con cierre vigente 2026-11-11.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Se amplía | +21 días formalizados | +42.000.000 COP sobre 18.000.000.000 aprobados |
| B. Rechazar y revertir la línea base | Sin ampliación | Vuelve a la fecha original | Sin costo adicional |
| C. Diferir hasta recibir evidencia | Congelado | Rige la original | Sin costo adicional |

**Recomendación:** C, por el mismo motivo que PRY-205. El último informe (2026-09-25, hace 19 días) declara verde y 45 %. El plan sostiene entre 75 y 100 %, y 3 hitos "cumplidos" no tienen evidencia (Diseño funcional, 2026-02-20; Ambiente de pruebas, 2026-05-12; Integración con el core, 2026-08-01). La proyección al cierre está 4,1 % sobre lo aprobado.

### [4] PRY-207: ¿se exige una nueva línea base de tiempo y costo, y se retira el estado verde hasta tenerla?
**Proyecto:** PRY-207 Onboarding PyME · **Quién decide:** el Comité de Arquitectura aprobó el presupuesto el 2025-06-02. Patrocinador: Jorge Medina. · **Si no se decide hoy:** el proyecto sigue en verde con una proyección 22,9 % sobre lo aprobado (4.055.804.996 contra 3.300.000.000 COP). CC-01 cubre solo 50.000.000 COP y +25 días, y su autorización nunca llegó a la línea base: el cierre vigente sigue siendo 2026-01-14, ya vencido.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir línea base nueva y un CC-02 por el sobrecosto | Se redefine | Fecha de cierre nueva, justificada | Se formaliza el sobrecosto proyectado |
| B. Aceptar el estado actual y esperar al cierre | Sin cambio | El cierre vigente ya venció | El sobrecosto aparece al final, sin autorización |

**Recomendación:** A. El informe declara verde con 72 % de avance, pero la proyección de costo cruza el umbral de 10 % y el cierre vigente es anterior a hoy. Un proyecto vencido en verde no le sirve al comité para decidir.

### [5] PRY-203: ¿se retiene todo pago adicional a Datacore Colombia (CT-948) hasta que haya entregables aceptados?
**Proyecto:** PRY-203 Open Banking · **Quién decide:** sin establecer; el contrato CT-948 no se leyó para este paquete. Solicitante del cambio: María Restrepo. · **Si no se decide hoy:** los 3 entregables siguen pendientes (Licenciamiento del motor, 150 días de atraso; Bolsa de horas de desarrollo, 80; Parametrización del tarifario, 11), y hay 631.036.273 COP facturados con 0 aceptados. No sé si la factura está pagada: ningún documento lo dice.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos hasta aceptación | Sin cambio | Presiona la entrega | Evita pagar lo no recibido |
| B. Pago parcial contra lo realmente recibido | Sin cambio | Neutro | Lo pagado se limita a lo aceptado, hoy 0 |
| C. Seguir pagando | Sin cambio | Sin presión sobre el proveedor | Se paga por adelantado |

**Recomendación:** A. La aceptación es la única evidencia de que algo se recibió, y hoy no hay ninguna. Aparte, el CC-01 ya autorizó +112 días (cierre 2027-03-08, atraso contra la original de 44,4 %), y el informe del 2026-10-12 declara rojo.

### [6] ¿Se suspende el estado verde de los 6 proyectos cuyo verde contradice su propia evidencia, hasta que presenten las actas de recibo?
**Proyecto:** PRY-201, PRY-207, PRY-208, PRY-209, PRY-210, PRY-211 · **Quién decide:** la PMO y los patrocinadores. · **Si no se decide hoy:** el portafolio sigue mostrando verde en proyectos que ninguna evidencia sostiene. Además, PRY-209, PRY-210 y PRY-211 tienen fecha de cierre vigente anterior a hoy (2026-07-01, 2026-02-21 y 2026-04-01).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender el verde hasta recibir evidencia | Sin cambio | El PM dedica tiempo a conseguir las actas | Sin costo directo |
| B. Mantener y pedir evidencia en el próximo informe | Sin cambio | Una semana más con el estado sin sustento | Sin costo directo |

**Recomendación:** A. Esto no acusa a nadie: el estado declarado queda anotado como "declarado sin sustento" hasta que aparezca el acta. Detalle de cada caso en el anexo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-209 | Sin movimiento: 16 días, umbral 15. Último informe 2026-09-28, verde. | 2026-09-28 | Que el PM reporte, o que el patrocinador diga si el proyecto sigue vivo |
| PRY-206 | Compromiso vencido de Diana Molina, "Entregar el punto 3", sin evidencia de cumplimiento: 22 días. | 2026-09-22 | Fecha nueva o cierre del compromiso |
| PRY-202 | La fecha de cierre tiene dos versiones: 2026-10-16 en el acta y 2026-09-25 en el cronograma, ambas del 2026-02-19. El informe es rojo y declara cumplido el hito "Salida a producción", mientras dice que la prueba de carga no alcanzó el umbral. | 2026-02-19 | Qué fecha rige y si la salida a producción ocurrió |
| PRY-202 | Riesgo dicho en reunión y no registrado: "el proveedor podría no llegar con el equipo completo para la siguiente fase". Hay también un ajuste de presupuesto sin fecha (Laura Vélez) con 89,2 % del presupuesto comprometido, cerca del umbral de 90 %. | 2026-10-13 | Un dueño para el riesgo y la fecha del ajuste |
| PRY-201, PRY-202, PRY-205 | Compromisos sin fecha: Carlos Peña (punto 39), Laura Vélez (ajuste de presupuesto), Natalia Ospina (punto 37). | 2026-10-01 / 10-13 / 10-08 | Fecha para cada uno |

## Para conocimiento
- PRY-199 Renovación de cajeros: sin señales; verde, 20 %. Consultora Andina, 0 de 3 entregables aceptados, ninguno vencido.
- PRY-200 Originación digital: sin señales calculables, pero no tiene línea base (el único del portafolio) y sus datos de identidad y plan tienen 13 meses.
- PRY-204 Débito contactless: sin señales; amarillo, 67 %.
- PRY-206 Billetera y QR: amarillo, 32 % declarado frente a 50–75 % que sostiene el plan; un hito sin evidencia y un compromiso vencido (arriba).
- PRY-201 Core de depósitos: verde con 69 % declarado frente a 25–50 % que sostiene el plan (el informe va *por delante* del plan, caso inverso al resto); hay un compromiso sin fecha.
- PRY-210 y PRY-211: ver anexo; sus cierres vigentes ya vencieron.

## Anexo
**Hitos "cumplidos" sin acta de recibo, por proyecto** (cifras de `compute`): PRY-202, 5 (todos); PRY-203, 4; PRY-205, 2; PRY-206, 1; PRY-208, 3; PRY-209, 3 (todos); PRY-210, 3; PRY-211, 2.

**Avance declarado contra el que sostiene el plan**
| Proyecto | Declarado | Plan sostiene | Diferencia (puntos) |
|---|---|---|---|
| PRY-202 | 46 % | 100 % | 54,0 atrás |
| PRY-203 | 45 % | 80–100 % | 35,0 atrás |
| PRY-205 | 56 % | 67–100 % | 11,0 atrás |
| PRY-206 | 32 % | 50–75 % | 18,0 atrás |
| PRY-208 | 45 % | 75–100 % | 30,0 atrás |
| PRY-209 | 80 % | 100 % | 20,0 atrás |
| PRY-210 | 48 % | 100 % | 52,0 atrás |
| PRY-211 | 33 % | 100 % | 67,0 atrás |
| PRY-201 | 69 % | 25–50 % | 19,0 adelante |

**Dinero** (COP, de `compute`; proyección contra aprobado): PRY-207 +22,9 % · PRY-208 +4,1 % · PRY-211 +3,7 % · PRY-200 +3,1 % · PRY-209 +2,7 % · PRY-206 +0,3 % · PRY-199 0,0 % · PRY-204 −4,4 % · PRY-210 −2,5 % · PRY-202 −4,9 % · PRY-201 −2,9 % · PRY-205 −5,8 % · PRY-203 −7,5 %.

**Contradicciones abiertas:** PRY-202, fecha de cierre (acta contra cronograma) y fecha del compromiso "punto 3" (2026-11-02 en el acta del comité, 2026-10-28 en las notas de la misma reunión).

**Vacíos:**
- `identity.authority` e `identity.phase` faltan en los 13 proyectos.
- Ningún documento tiene marca de evidencia o declaración: las 15 (o 25) fuentes por proyecto figuran como "sin marcar".
- En PRY-200, PRY-203, PRY-204 y PRY-211 lo ejecutado es mayor que lo comprometido; no sé si es un error de captura.
- Los datos de identidad y plan están desactualizados (más de 12 meses) en PRY-200, 207, 209, 210 y 211.
- No leí los contratos CT-948 (PRY-203) y CT-199 (PRY-199), ni las actas en .docx y .pdf, salvo lo que ya traían las fichas.

**Proyectos con cierre vigente anterior a hoy:** PRY-207 (2026-01-14), PRY-210 (2026-02-21), PRY-211 (2026-04-01), PRY-209 (2026-07-01), PRY-202 (2026-09-25 por cronograma).

---
*Pie: paquete generado con plugin criterio-portfolio, términos v1.0 (aceptados 2026-10-14, por José Francisco Ñáñez). Fichas aplicadas: raid-taxonomy, governance-artifacts, portfolio-health. Campos inciertos: quién decide cada punto (`identity.authority` vacío en los 13), si la factura de PRY-203 está pagada, y la autorización de CC-01 en PRY-203 y PRY-207 (declarada, sin acta). Términos: /home/claude/banco/criterio/TERMS.md. Cifras derivadas copiadas de `compute`; los importes de las solicitudes de cambio y de las facturas son los que traen los documentos.*
