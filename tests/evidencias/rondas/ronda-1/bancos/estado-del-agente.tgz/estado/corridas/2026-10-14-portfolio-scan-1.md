# Corrida del 2026-10-14 · portfolio-scan

13 proyectos · 69 documentos, 0 releídos y 69 sin cambio · 285 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

10 fichas creadas (PRY-199..204, 208..211); 205-207 sin cambio. Nada movido: no existe entrada/. Omitido: nada ilegible. Mirar: hitos cerrados sin acta (202,203,208,209,210,211), factura PRY-203 sin actas, compromiso en conflicto PRY-202, CC-01 de 208 pendiente con plan v2 ya movido, cierres vencidos en 209,210,211.

Contra la corrida del 2026-10-14: +42 hallazgos.

## Lo que produjo

## Barrido — 2026-10-14

Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (coinciden con TERMS.md v1.0). Sesión sin interfaz: no se hizo ninguna pregunta.

**Documentos:** 69 en la carpeta · 55 leídos · 14 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha (10 creadas hoy, 3 sin cambio: PRY-205, PRY-206, PRY-207) · 10 nuevos · 1 con ficha del gerente (PRY-202) · 0 sin carpeta propia

Formatos: 25 .md, 14 .docx, 14 .pdf, 8 .xlsx, 6 .csv, 1 .txt, 1 .json. Plan: 1 lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes; nada diferido.

### Nuevos
| Proyecto | Qué se encontró | Fuente |
|---|---|---|
| PRY-199 Renovación de cajeros | Ficha completa. Declara verde 20%. Contrato CT-199 (3 entregables de 144 M, todos pendientes, nada facturado). Hito de diseño funcional con acta de recibo. | informe 2026-10-12, contrato, acta de recibo 2026-10-06 |
| PRY-200 Originación digital | Declara amarillo 66%. Sin cronograma: no hay hitos que cotejar. Ejecutado (687,7 M) supera lo comprometido (665,8 M). | informe 2026-10-10 |
| PRY-201 Core de depósitos | Declara verde 69% con 25% del aprobado ejecutado. Hallazgo de seguridad abierto y prueba de carga fallida. Compromiso sin fecha (Carlos Peña, punto 39). | informe 2026-10-03, comité 2026-10-01 |
| PRY-202 Migración a la nube | Declara rojo 46%. Ficha del gerente (`ficha-pm.json`) conservada aparte en `pm_record`, sin fusionar. Los cinco hitos figuran «cerrado» sin acta de recibo. Contrato CT-169: dos entregables con acta de recibo y factura por 597.877.110 COP (= suma de ambos). Tres compromisos y un riesgo dicho en la reunión del 13 de octubre que nadie registró. | informe 2026-10-09, notas y comité 2026-10-13, contrato, actas, factura |
| PRY-203 Open Banking | Declara rojo 45%. Plan v2 (2026-10-12) mueve «Salida a producción» de 2026-11-16 a 2027-03-08 por CC-01 (+112 días, +224 M, «autorizada por el comité», sin acta de comité). Factura por 631.036.273 COP contra un contrato cuyos tres entregables siguen pendientes o en curso y sin acta de recibo. Ejecutado supera lo comprometido. | v1, v2, CC-01, contrato CT-948, factura 2026-09-15 |
| PRY-204 Débito contactless | Declara amarillo 67%. Dos hitos con acta de recibo (diseño funcional y ambiente de pruebas), ambas de octubre aunque los hitos vencían en marzo y julio. Ejecutado (9.450 M) muy por encima de lo comprometido (6.170 M). | informe 2026-10-12, actas 2026-10-07 y 2026-10-08 |
| PRY-208 Motor de decisión | Declara verde 45%. Plan v2 (2026-09-25) mueve el piloto +21 días; CC-01 (+21 días, +42 M) es posterior y sigue pendiente de comité: el plan se movió antes de que se aprobara el cambio. Proyección (18.746 M) supera el aprobado. | v1, v2, CC-01, informe 2026-09-25 |
| PRY-209 Nómina electrónica | Declara verde 80%. Los tres hitos figuran «cerrado» sin acta. Cierre del acta (2026-08-22) ya vencido; ningún documento lo mueve. | informe 2026-09-28, cronograma v1 |
| PRY-210 Portal de proveedores | Declara verde 48%. Cuatro hitos «cerrado», solo uno con acta (ambiente de pruebas, firmada el 2026-10-03). Cierre del acta (2026-03-23) ya vencido. | informe 2026-10-05, cronograma v1 |
| PRY-211 Cobranza digital | Declara verde 33%. Cuatro hitos «cerrado», dos con acta (ambiente de pruebas y piloto, ambas de octubre). Cierre del acta (2026-04-30) ya vencido. Ejecutado supera lo comprometido. | informe 2026-09-25, actas 2026-10-03 y 2026-10-09 |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: PRY-205, 206 y 207 no tenían documentos nuevos ni cambiados (14 sin cambio). | — |

### Contradicciones y vacíos que conviene mirar
- **Lo declarado contra la evidencia.** PRY-202 declara los cinco hitos cerrados (incluida la salida a producción del 2026-09-25) y a la vez rojo al 46% con «se reprogramó la salida». Hitos cerrados sin acta: PRY-202 (5), PRY-203 (4), PRY-208 (3), PRY-209 (3), PRY-210 (3), PRY-211 (2). Se registró la declaración tal cual y la falta de prueba; no se cambió el estado.
- **Facturas.** PRY-203: factura de 631 M con tres entregables sin acta de recibo, y el contrato dice que cada uno se factura contra acta. PRY-202 está consistente (dos actas, dos entregables, factura por la suma).
- **Compromisos.** PRY-202: el punto 3 de Paula Céspedes figura al 2026-11-02 en el acta del comité y al 2026-10-28 en las notas de la misma reunión; además «no alcanzó» sugiere una promesa anterior que no está en los documentos. Quedó `ambiguous`. Sin fecha: Laura Vélez («la otra semana», PRY-202) y Carlos Peña (PRY-201, «por definir»). Carlos Peña no figura entre los asistentes de esa reunión.
- **Ejecutado por encima de lo comprometido:** PRY-200, PRY-203, PRY-204 y PRY-211. No lo calculé aquí; lo calcula el script.
- **Cambios:** PRY-208 CC-01 pendiente de comité; PRY-203 CC-01 «autorizada por el comité» sin acta que lo respalde.
- **Sin dato en ningún documento:** facultad del gerente (`authority`) y fase en las diez fichas; cronograma en PRY-200; contrato en PRY-200, 201, 204, 208, 209, 210, 211; reuniones en PRY-200, 208 y 209.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 69 se convirtieron a texto (14 PDF con pdftotext). |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` bajo `documentos/`; no se movió nada. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-202…/2026-10-13-notas-reunion.txt` | No es pendiente de proyecto (pertenece a PRY-202), pero está en la raíz de su carpeta y no en `30-reuniones/`; lo dejé donde está y lo leí. Proponer moverlo. |

---
criterio-portfolio · portfolio-scan · fichas tocadas: PRY-199, 200, 201, 202, 203, 204, 208, 209, 210, 211 (PRY-205, 206, 207 intactas) · campos en `not_found`: identity.authority e identity.phase en las 10; plan.milestones en PRY-200; money y vendors según la ficha (detalle en `meta.fields_not_found`) · Términos: TERMS.md v1.0
