## Descubrimiento — Microseguros (PRD-306) · 1 pieza de entrevista nueva al 2026-10-14

Material leído (4 documentos, todos nuevos): 1 de entrevistas (`10-descubrimiento/2025-08-22-entrevistas.docx`), 2 de definición y caso de negocio (`00-definicion/`), 1 acta de comité (`30-decisiones/2026-10-09-comite-producto.docx`). Solo la de entrevistas es material de descubrimiento. No hubo nada que no se pudiera leer.

### Temas
> **Necesidad principal** — 1 de 1 piezas
> — *«Lo necesito y hoy no lo tengo.»* · Cliente entrevistado (sin nombre ni segmento), 2025-08-22
> **En el registro:** **ninguno** (`estado/requirements` está vacío; el comité del 2026-10-09 lista REQ-1060, 1061, 1062, 1063 y 2025, pero ninguno está en el registro y ninguno dice qué necesidad recoge)

Una cita, una voz. El tema lo rotuló la propia entrevista («Tema: Necesidad principal»); la cita no dice qué es «lo» que necesita, así que no hay problema que agrupar todavía. No hay disidencia en el material.

### Dicho y nunca convertido en nada
| Tema | Veces | Desde | Ningún requerimiento lo recoge |
|---|---|---|---|
| Necesidad principal | 1 | 2025-08-22 (413 días antes del comité; 418 hasta hoy) | Sin demostrar: los 5 REQ del comité citan a «Cliente entrevistado» como quien los pidió, pero la única entrevista no contiene nada que permita atribuirles ese origen |

Con una sola cita no se puede decir que lleve meses dicho: lleva 418 días registrado y una sola vez.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| *«Lo necesito y hoy no lo tengo.»* | Cliente entrevistado | 2025-08-22 |

No se promueve ni se descarta: lo decide el gerente de producto.

### Afirmaciones numéricas de los entrevistados
| Lo que dijeron | Quién | ¿Hay serie que lo mida? |
|---|---|---|
| Ninguna | — | — |

(La única cifra del material, `volumen_mensual 139.663`, es del caso de negocio, no de un entrevistado; no hay serie medida en `estado/metrics`.)

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna: el registro está vacío, no hay contra qué contradecir. Lo que sí se observa, sin concluir nada: el comité muestra 4 REQ en `aceptado` sin proyecto que los ejecute y los 5 con «Cliente entrevistado» como origen, mientras la evidencia de entrevista es una frase.

### Qué no sé / qué no se hizo
- **No se creó ningún requerimiento.** Proponer uno en `propuesto` necesita un doliente que lo asuma; nadie respondió en esta sesión.
- **No se selló la lectura** (`sellar`): el script se negó porque `estado/producto.json` sigue siendo la plantilla vacía y no se escribió en esta corrida. La próxima corrida volverá a ver estos 4 documentos como nuevos.
- Los términos (v1.0, José Francisco Ñáñez, 2026-10-14) ya estaban en la configuración y coinciden con `TERMS.md`.

### Después
Sugerido: `/criterio-product:product-requirements` para ver el registro con sus vacíos, y `/criterio-product:product-setup` si se quiere llenar la ficha antes de volver a sellar.
