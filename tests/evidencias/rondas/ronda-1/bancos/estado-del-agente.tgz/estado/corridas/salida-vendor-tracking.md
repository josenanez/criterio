## Proveedores — PRY-203 Open Banking al 2026-10-14

**De qué documentos sale:** contrato `00-gobierno/2026-03-03-contrato-ct-948.md`, factura `20-seguimiento/2026-09-15-factura-ct-948.pdf`, informe de avance `20-seguimiento/2026-10-12-informe-avance.pdf`, minuta `30-reuniones/2026-10-02-comite-semanal.md`, y la salida de `portafolio.py compute` (as_of 2026-10-14). Términos: aceptados por José Francisco Ñáñez, v1.0, 2026-10-14.

### Datacore Colombia — contrato CT-948
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2026-03-03) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-05-17 (631.036.273 COP) | `pending`; el contrato dice "pendiente" · 150 días de atraso | Ninguna | Ver nota |
| Bolsa de horas de desarrollo | 2026-07-26 (631.036.273 COP) | `pending`; el contrato dice "en curso" · 80 días de atraso | Ninguna | Ver nota |
| Parametrización del tarifario | 2026-10-03 (631.036.273 COP) | `pending`; el contrato dice "en curso" · 11 días de atraso | Ninguna | Ver nota |

Cifras del cruce (script): 3 entregables, 0 aceptados, 3 con fecha pasada sin evidencia ni entrega declarada (`late`), 0 declarados entregados sin documento, facturado 631036273.0, monto aceptado 0.

**Nota sobre lo facturado:** la factura FV-1948 (2026-09-15) cobra 631.036.273 COP bajo el concepto genérico "Entregables del contrato CT-948". No dice a cuál entregable corresponde. Ese valor es igual al de cada uno de los tres, así que no se puede asignar a uno. Se deja a nivel de proveedor.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura sin entrega aceptada (`vendor_invoiced_without_delivery`) | Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto | Hay una factura por 631.036.273 COP y ningún acta de recibo en la carpeta. 0 entregables aceptados | contrato CT-948 (condición de pago); factura FV-1948 |
| Estado de los entregables | Licenciamiento "pendiente"; bolsa de horas y parametrización "en curso" | La ficha los tiene los tres en `pending`. Ninguno figura como entregado | contrato CT-948; ficha PRY-203 |
| Informe de avance | — | El informe de 2026-10-12 no menciona al proveedor, ni la factura, ni los atrasos. El script marca `vendor_deliverable_late` y `vendor_invoiced_without_delivery` como señales que el informe no explica | informe de avance 2026-10-12; compute |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del motor | `pending` (contrato: "pendiente") | vencido el 2026-05-17 (150 días) |
| Bolsa de horas de desarrollo | `pending` (contrato: "en curso") | vencido el 2026-07-26 (80 días) |
| Parametrización del tarifario | `pending` (contrato: "en curso") | vencido el 2026-10-03 (11 días) |

Ninguno está marcado como entregado o aceptado, así que no hay "aceptado sin evidencia" (`accepted_without_evidence` vacío). El hallazgo es otro: hay un pago radicado en cuentas por pagar y nada que lo sustente.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso registrado es de Laura Vélez, "Entregar el punto 30", para el 2026-10-28 (dicho en el comité del 2026-10-02). No vence todavía (`commitments_overdue` vacío). La minuta no dice a qué organización pertenece Laura Vélez, ni qué es el "punto 30"; no puedo afirmar que sea un compromiso del proveedor. Los asistentes fueron María Restrepo y Gustavo Neira, y no consta que el proveedor asistiera.

### Sin dato
- **Vigencia, terminación, renovación automática y preaviso de CT-948:** el contrato no los trae. No se puede decir si hay un preaviso por vencer antes del cierre. El cierre del proyecto pasó de 2026-11-16 a 2027-03-08 con CC-01 (+112 días), y la vigencia del contrato debería revisarse contra esa fecha.
- **Acta de recibo de cualquier entregable:** no existe en la carpeta.
- **A cuál entregable corresponde la factura FV-1948:** no lo dice.
- **Monto total del contrato:** el contrato no lo declara como total; solo hay el monto por entregable. No lo sumo porque el script no lo entrega.
- **Estado de pago de la factura:** solo dice "radicada en cuentas por pagar"; no hay dato de si ya se pagó.
- **Si la solicitud CC-01 toca el contrato con Datacore:** no lo verifiqué en este cruce.

### Después
Hay una factura de 631.036.273 COP sin ningún entregable aceptado y con tres entregables vencidos. Conviene llevarlo a comité (próximo: 2026-10-20) antes de que se pague, y pedirle a María Restrepo el acta de recibo, o confirmar que no existe. Además, pedir el contrato completo con su vigencia y preaviso.

---
**Pie de rigor:** las cifras derivadas vienen de `portafolio.py compute`. Los dos PDF (factura e informe) no tienen texto en la ficha; los leí con `pdftotext`. No abrí el acta de constitución (.docx). En la ficha ningún dato está marcado como evidencia (`evidence: 0`, `unmarked: 15`). No afirmé entrega, aceptación ni pago donde no hay documento.
