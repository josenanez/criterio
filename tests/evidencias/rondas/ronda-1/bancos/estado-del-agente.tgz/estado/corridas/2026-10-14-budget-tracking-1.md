# Corrida del 2026-10-14 · budget-tracking

13 proyectos · 25 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

Presupuesto de PRY-207: proyección 22.9% sobre el aprobado con estado declarado verde; CC-01 aprobado sin línea base nueva. Dijo que no sabe: presupuesto original, hitos, proveedores y si el aprobado incluye CC-01.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Sale de: `estado/records/PRY-207.json` y del cálculo de `portafolio.py compute` (as_of 2026-10-14). Fuente de las cuatro cifras: `20-seguimiento/2026-10-14-informe-avance.md`, fecha de corte 2026-10-14. Términos aceptados: José Francisco Ñáñez, v1.0, 2026-10-14.

## Presupuesto — PRY-207 Onboarding PyME al 2026-10-14
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | informe de avance | 2026-10-14 |
| Comprometido | 2.194.692.657 | 66.5% | informe de avance | 2026-10-14 |
| Ejecutado | 1.916.164.829 | 58.1% | informe de avance | 2026-10-14 |
| Proyección al cierre | 4.055.804.996 | 22.9% por encima del aprobado | informe de avance | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): 1.105.307.343 COP

Las cuatro cifras vienen de un solo documento, el informe del gerente. Ninguna está respaldada por un documento contable o contractual: son declaraciones. La proyección lleva la misma fecha que el resto; no hay fecha de último movimiento de presupuesto con la cual compararla.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | `not_found` | 3.300.000.000 COP (informe 2026-10-14) | no calculable |
| Proyección frente al aprobado vigente | | 4.055.804.996 | +22.9% |

Replanificaciones de presupuesto: 0 registradas. El acta de constitución (2025-06-02) no declara monto; solo hay línea base de fechas. No se puede decir si los 3.300.000.000 incluyen los 50.000.000 COP de CC-01.

### Ejecución frente a avance
Ejecutado 58.1% · Hitos cumplidos: sin dato (el plan no tiene hitos cargados, `plan.milestones` vacío) · Avance declarado 72% (declaración del gerente, sin evidencia).
Lectura: no se puede cruzar contra hitos porque no existen. El 72% declarado está por encima del 58.1% ejecutado; sin hitos no se puede decir si eso es eficiencia o avance sobrestimado.

### Alertas
- **Proyección excede el aprobado: 22.9%** (umbral 10%). Alerta `variance_cost`.
- **Estado declarado verde contra esa señal.** El informe declara verde, pero la proyección que él mismo reporta excede el aprobado. Alerta `declared_vs_evidence`.
- **CC-01 aprobado sin línea base nueva.** +25 días y +50.000.000 COP, "autorizada por el comité", sin acta que lo registre. La línea base de fechas sigue en 2026-01-14 (versión 1); esa fecha es anterior al corte del informe y no hay replanificación registrada.
- Comprometido 66.5%: por debajo del umbral de 90%, sin alerta.

### Sin dato
- Presupuesto original aprobado (no declarado en ningún documento).
- Hitos del plan.
- Contratos y proveedores: el informe menciona un componente de integración entregado y pendiente de aceptación, pero la ficha no tiene proveedor ni contrato, así que no hay detalle por proveedor.
- Autoridad de aprobación y fase del proyecto.
- Fecha de la aprobación de CC-01 en acta.

## Siguiente paso
La proyección excede el aprobado: queda ofrecida la preparación de la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`). No la preparé; en esta sesión nadie puede confirmar el alcance.

---
Pie de rigor: cifras derivadas copiadas de `compute`; ninguna estimada. Las cuatro cifras de dinero son declaraciones de un único informe; no hay evidencia independiente en la carpeta.
