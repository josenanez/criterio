No publiqué la ficha de PRD-306 (Microseguros). Corte al 2026-10-14.

Por qué:
- El estado del producto está vacío: `estado/producto.json` sin código, nombre, gerente, problema, segmento ni métricas; `estado/requirements/` y `estado/metrics/` sin archivos. `compute` da 0 requerimientos y 0 métricas afirmadas. Publicar eso dejaría una ficha vacía que los demás leerían como si fuera de hoy.
- La configuración no define carpeta de productos publicados (`paths` solo tiene documents, state y fichas). Sin un sitio común acordado no hay dónde escribir, y acordarlo es una conversación de la organización.

No escribí ningún `PRD-306.json` ni creé carpetas de publicación.

Qué falta: correr `/criterio-product:product-setup` para que lea los documentos de `documentos/productos/PRD-306` y llene el estado, y acordar la carpeta de publicados.

Términos: aceptados (v1.0, 2026-10-14, José Francisco Ñáñez).
