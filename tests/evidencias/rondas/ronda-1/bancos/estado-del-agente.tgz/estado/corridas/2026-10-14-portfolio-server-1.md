# Corrida del 2026-10-14 · portfolio-server

13 proyectos · 54 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

puerto 8787, informe en reportes/, modo rato

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Términos: aceptados (v1.0, 2026-10-14, José Francisco Ñáñez). Modo elegido: **rato** (sin interfaz, respuesta tomada de los argumentos).

Informe encontrado en `reportes/` (13 proyectos, 10 productos, decisiones, listados). Se sirve lo que `informe.py` ya escribió; abrir la página no lee documentos.

Escucha en `127.0.0.1:8787`, **solo en este equipo**. Se apaga con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula, no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda nada.

Cierre: en este modo el enlace `http://127.0.0.1:8787/` solo lo abre quien está en este equipo; el patrocinador no tiene un enlace que funcione mañana. El informe es del 2026-10-14 y queda desactualizado en cuanto cambie un documento o pase el próximo barrido; la portada muestra su fecha. Para un enlace estable hay que pasar a «que quede corriendo» (host, puerto y control de acceso de la organización).
