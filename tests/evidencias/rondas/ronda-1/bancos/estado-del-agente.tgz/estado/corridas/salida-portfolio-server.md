# Rostrum — modo «para mirarlo un rato»

Términos: aceptados (v1.0, 2026-10-14, José Francisco Ñáñez). Modo elegido: **rato** (sin interfaz, respuesta tomada de los argumentos).

Informe encontrado en `reportes/` (13 proyectos, 10 productos, decisiones, listados). Se sirve lo que `informe.py` ya escribió; abrir la página no lee documentos.

Escucha en `127.0.0.1:8787`, **solo en este equipo**. Se apaga con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula, no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda nada.

Cierre: en este modo el enlace `http://127.0.0.1:8787/` solo lo abre quien está en este equipo; el patrocinador no tiene un enlace que funcione mañana. El informe es del 2026-10-14 y queda desactualizado en cuanto cambie un documento o pase el próximo barrido; la portada muestra su fecha. Para un enlace estable hay que pasar a «que quede corriendo» (host, puerto y control de acceso de la organización).
