# RAID — portafolio al 2026-10-14

**De qué documentos sale:** las 13 fichas de `estado/records` (PRY-199 a PRY-211, cortes entre 2026-09-25 y 2026-10-14), los informes de avance que las sustentan (md y pdf), las minutas de comité de 9 proyectos (md y docx) y las notas de reunión de PRY-202 del 2026-10-13. Los PRY-207, 208, 209, 211 y 200 no tienen minuta de reunión en la carpeta.

11 riesgos · 0 supuestos · 11 incidencias · 13 dependencias (de ellas 13 reclasificadas desde riesgo)
35 ítems · 35 sin doliente · 35 sin fecha compromiso · sin movimiento: no medible (hay un solo corte, 2026-10-14) · 1 no registrado formalmente (ya capturado en la ficha de PRY-202)

Escala: no hay probabilidad/impacto en ninguna ficha ni escala definida en la configuración; no se inventaron. Los ids son provisionales (`código-n`): las fichas no traen id de ítem RAID.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-202-2 · PRY-204-2 · PRY-205-1 · PRY-211-1 | Dependencia | Calendario de liberaciones del core | sin doliente | informes del 2026-09-25 al 2026-10-14 | Afecta a 4 proyectos del portafolio. Ninguna ficha ni informe dice de qué proyecto o equipo del core depende; el acta de PRY-202 declara "Ninguna declarada". Decisión: designar un responsable del calendario del core y confirmar las fechas con él. |
| PRY-202-3 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-13 | PRY-202 está en rojo (46%); la revisión con el proveedor está fijada para 2026-10-24. Decisión: formalizarlo o descartarlo antes de esa fecha. |
| PRY-201-3 · PRY-205-3 · PRY-207-3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | sin doliente | 2026-10-03 / 2026-10-14 | Incidencia ya ocurrida sin doliente ni fecha de resolución, en tres proyectos. PRY-201 y PRY-207 se declaran en verde con esta incidencia abierta. |
| PRY-201-4 · PRY-202-4 · PRY-206-3 · PRY-210-3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin doliente | 2026-10-03 a 2026-10-14 | Cuatro proyectos, sin doliente ni fecha de la nueva prueba; PRY-202 en rojo. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | Riesgo | Notas de reunión de migración a la nube (PRY-202), "nadie lo anotó como riesgo" | 2026-10-13 |

Las otras minutas (PRY-199, 201, 203, 204, 205, 206, 210, 202-comité) solo traen temas genéricos y compromisos; no mencionan riesgos. No se inventó ninguno.

### Sin doliente o sin fecha
Los 35 ítems (24 riesgos o dependencias y 11 incidencias, ya contado el de la reunión) no tienen doliente ni fecha en la ficha. Se reporta como hallazgo, no se rellenó. Las fuentes (informes de avance) listan riesgos como texto, sin responsable ni fecha.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Todos (ver registro completo) | todos | — | doliente, fecha, probabilidad, impacto |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-202-2, PRY-204-2, PRY-205-1, PRY-211-1 | "el core" — **código de proyecto no declarado** | No | No se puede cruzar con la fecha de otro proyecto. PRY-201 (Core de depósitos) es candidato por nombre, pero ningún documento lo dice: no se asume. PRY-199 y PRY-201 informan además "historias fuera del sprint por dependencia con el core". |
| PRY-201-2, PRY-204-1, PRY-209-2 | Proveedor (sin contrato citado en el ítem) | No: el proveedor no confirmó la fecha de la última entrega | Declarada, no acordada. |
| PRY-199-1, 200-2, 201-1, 202-1, 208-1, 210-1 | Equipo de seguridad (fuera de cada proyecto) | No | Declarada, no acordada. Clasificada como dependencia por la prueba rápida (depende de alguien fuera del proyecto). |

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-12 |
| PRY-200-1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-10 |
| PRY-200-2 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-10 |
| PRY-201-1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-03 |
| PRY-201-2 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-03 |
| PRY-201-3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-03 |
| PRY-201-4 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-03 |
| PRY-202-1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-09 |
| PRY-202-2 | Dependencia | Dependencia del calendario de liberaciones del core *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-09 |
| PRY-202-3 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase *(no registrado formalmente)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-09 |
| PRY-202-4 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-09 |
| PRY-203-1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-12 |
| PRY-204-1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-12 |
| PRY-204-2 | Dependencia | Dependencia del calendario de liberaciones del core *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-12 |
| PRY-204-3 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-12 |
| PRY-205-1 | Dependencia | Dependencia del calendario de liberaciones del core *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-205-2 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-205-3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-206-1 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-206-2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-206-3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-206-4 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-207-1 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-207-2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-207-3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-14 |
| PRY-208-1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-25 |
| PRY-208-2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-25 |
| PRY-209-1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-28 |
| PRY-209-2 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-28 |
| PRY-210-1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-05 |
| PRY-210-2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-05 |
| PRY-210-3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-05 |
| PRY-210-4 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-10-05 |
| PRY-211-1 | Dependencia | Dependencia del calendario de liberaciones del core *(reclasificado: estaba como riesgo)* | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-25 |
| PRY-211-2 | Riesgo | Concentración del conocimiento en una sola persona | sin dato | sin dato | sin doliente | sin fecha | primer corte 2026-09-25 |

### Reclasificados
Los 13 ítems que las fichas llevaban como riesgos pasan a dependencia: dependen de un equipo o tercero fuera del proyecto (core, proveedor, equipo de seguridad). El cambio solo está en este reporte; la ficha no se tocó.

### Sin sustento / límites
- No hay supuestos registrados en ninguna ficha, y no se levantaron: ningún documento declara uno. Conviene preguntar por los típicos (equipo completo, aprobaciones, licencias).
- "Sin movimiento en dos períodos" y "mitigación vencida" no se pueden evaluar: hay un solo corte y ningún ítem trae mitigación.
- Informes con corte viejo: PRY-211 (2026-09-25), PRY-208 (2026-09-25), PRY-209 (2026-09-28), PRY-201 (2026-10-03), PRY-210 (2026-10-05).

## Después
Puedo subir a comité (2026-10-20) los cuatro grupos de "necesitan decisión ahora", y proponer doliente para cada uno — proponer, no asignar. No lo hice: dime si quieres.

*Pie de rigor: lo registrado viene de las fichas; lo clasificado es criterio de este reporte; lo ausente (dolientes, fechas, valoración) se declara ausente, no se rellena.*
