# Corrida del 2026-10-14 · project-history

13 proyectos · 50 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

Historia de PRY-203 sobre 8 documentos (2026-02-27 a 2026-10-12). No se pudo calcular meses declarando sin sustento (una sola declaración), ni confirmar que cronograma v1 sea la línea base original (fechado 02-27 pero con hitos cerrados), ni la autorización de CC-01 (sin acta de comité). Sin documentos abril-junio 2026.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Términos: aceptados en la configuración local (versión 1.0, 2026-10-14, José Francisco Ñáñez), coinciden con TERMS.md v1.0.

## Historia · PRY-203 Open Banking · 2026-02-27 a 2026-10-12

**Leí:** 8 documentos entre 2026-02-27 y 2026-10-12 (acta .docx, contrato, 2 cronogramas, factura PDF, solicitud de cambio, informe de avance PDF, 1 acta de comité).
**Trimestres sin un solo documento:** el segundo de 2026 (abril–junio) no tiene ninguno. El tercero (julio–septiembre) tiene uno: la factura del 2026-09-15.

### En una línea
El proyecto se aprobó el 2026-02-27 con salida a producción el 2026-11-16 y cierre declarado el 2026-12-12. Entre marzo y septiembre la carpeta casi no tiene rastro: no hay un solo documento entre el contrato (2026-03-03) y la factura (2026-09-15). Todo lo demás aparece en las últimas tres semanas: la factura del 09-15, el comité del 10-02, la solicitud de cambio CC-01 del 10-07 (+112 días, +224.000.000 COP, "autorizada por el comité") y, el 10-12, un cronograma v2 que mueve la salida al 2027-03-08 y un informe de avance que declara Rojo con 45%.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 112 días (44.4 %) | No calculable: hay una sola declaración (2026-10-12), no una serie | 0 en la salida del script |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-02-27 | `00-gobierno/2026-02-27-acta-constitucion.docx` | Aprobación: presupuesto 6.800.000.000 COP, inicio 2026-03-09, cierre 2026-12-12; patrocinador Gustavo Neira, gerente María Restrepo. Dependencias: "ninguna declarada". |
| 2026-02-27 | `10-plan/2026-02-27-cronograma-v1.csv` | Línea base v1: salida a producción 2026-11-16. Ver nota sobre este archivo abajo. |
| 2026-03-03 | `00-gobierno/2026-03-03-contrato-ct-948.md` | Contrato con Datacore Colombia: 3 entregables de 631.036.273 COP (05-17, 07-26, 10-03); cada uno se factura contra acta de recibo firmada por la gerente. |
| abril–agosto | (sin documento) | Los hitos del cronograma "Diseño funcional" (04-28), "Ambiente de pruebas" (06-18) e "Integración con el core" (08-07) vencen sin ningún documento de la carpeta que los respalde. |
| 2026-09-15 | `20-seguimiento/2026-09-15-factura-ct-948.pdf` | Factura FV-1948 por 631.036.273 COP, "Entregables del contrato CT-948", radicada en cuentas por pagar. No hay acta de recibo. |
| 2026-09-27 | (sin documento) | Vence el hito "Piloto con usuarios internos"; sin documento. |
| 2026-10-02 | `30-reuniones/2026-10-02-comite-semanal.md` | Comité con 2 asistentes. Un compromiso: Laura Vélez, "Entregar el punto 30", para el 10-28. No trata cambio de alcance ni de fechas. |
| 2026-10-03 | (sin documento) | Vence "Parametrización del tarifario" del contrato; sigue pendiente. |
| 2026-10-07 | `20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +112 días, +224.000.000 COP. "Autorizada por el comité". |
| 2026-10-12 | `10-plan/2026-10-12-cronograma-v2.csv` | Línea base v2: salida a producción pasa de 2026-11-16 a 2027-03-08. |
| 2026-10-12 | `20-seguimiento/2026-10-12-informe-avance.pdf` | Declara Rojo y 45%. Único hecho del periodo: "se ajustó el plan de pruebas con el área de seguridad". Riesgo abierto sin responsable: cambio regulatorio que puede mover el alcance. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-12 | 2027-03-08 (salida a producción) | Ampliación de alcance (CC-01) | Solo la solicitud CC-01, que dice "autorizada por el comité". No hay acta de comité que lo registre; el comité del 10-02 es anterior a la solicitud y no lo menciona. |

Contra la línea base original (2026-11-16) el atraso es de 112 días, 44.4 %. Contra la vigente es 0, porque la base se movió. La cifra de 112 días coincide con lo que CC-01 declara, de modo que el cambio explica el atraso aritméticamente. Lo que la carpeta no explica es por qué el alcance crece cuando, según el cronograma, 4 de 5 hitos ya estaban cerrados.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de patrocinador, gerente ni comité en los documentos leídos. Gustavo Neira y María Restrepo aparecen en el acta (02-27) y en el comité (10-02). | — |

Dos cosas que no se pueden afirmar: que el comité autorizó CC-01 (solo lo dice el propio formulario) y quién es la "autoridad" del proyecto (el campo no está en ningún documento).

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Laura Vélez | Entregar el punto 30 | 1 | 2026-10-28 |

Ninguno se repitió: hay una sola minuta, así que no hay forma de ver reprogramaciones. Dos observaciones: "el punto 30" no remite a nada que la carpeta defina, y Laura Vélez no figura entre los asistentes del 10-02.

### Desde cuándo lo declarado no se sostiene
- **Fecha:** no se puede fijar como un deslizamiento, porque no hay serie de estados declarados, solo el informe del 2026-10-12.
- **Primer hito sin evidencia:** "Diseño funcional aprobado" (2026-04-28), cerrado en el cronograma sin ningún documento que lo respalde, 169 días atrás. Igual ocurre con los otros tres hitos cerrados (06-18, 08-07, 09-27).
- **Lo que se declara hoy:** Rojo con 45%. El estado Rojo no contradice la evidencia. El 45% sí: el cronograma cierra 4 de 5 hitos, lo que sostiene entre 80 y 100%, una brecha de 35 puntos.
- **Proveedor:** los tres entregables de Datacore siguen pendientes, con 150, 80 y 11 días de atraso. Aun así, el 09-15 se radicó una factura de 631.036.273 COP sin acta de recibo.

### Lecciones ancladas a un hecho
1. **Hito cerrado sin documento.** Hecho: los cuatro hitos aparecen "cerrado" desde el cronograma, sin acta ni aceptación. Fecha: 2026-04-28 el primero. Efecto: el 45% reportado y el 80–100% que sostiene el plan no se pueden conciliar.
2. **Factura radicada sin acta de recibo.** Hecho: FV-1948 del 2026-09-15 contra un contrato que exige acta de recibo firmada, con los 3 entregables pendientes. Efecto: 631.036.273 COP en cuentas por pagar sin respaldo en la carpeta.
3. **Cambio aprobado sin acta de comité.** Hecho: CC-01 (2026-10-07) se autoriza a sí mismo y la línea base v2 se publica 5 días después. Efecto: la línea base se movió 112 días sin una decisión verificable.

### Lo que no sé y quedó fuera
- **El cronograma v1 no es de febrero:** el archivo lleva fecha 2026-02-27 pero marca cuatro hitos como "cerrado", y esos hitos vencen entre abril y septiembre. Esa versión se editó después, así que no puedo afirmar que sea la línea base original tal como se aprobó. Las fechas de línea base de los hitos sí coinciden con la v2.
- **Cierre del acta (2026-12-12) frente a salida a producción (2026-11-16):** son fechas distintas y la carpeta no explica la diferencia.
- **Meses declarando sin sustento:** falta una serie de informes de avance anteriores al del 10-12.
- **Abril–septiembre:** el vacío de documentos significa que no sé lo que pasó, no que no pasó nada.
- **Intención:** nada de lo anterior dice que alguien ocultara algo. Es la conversación a tener con María Restrepo y el comité, con estos datos delante.

**Siguiente paso:** puedo llevar esta historia al comité del 2026-10-20 (hay una decisión que sale de ella: la factura sin acta de recibo y la autorización de CC-01) o al cierre del proyecto.

---
*Rigor: cifras copiadas de `portafolio.py compute` (replanificaciones 1; atraso 112 días, 44.4 %; avance declarado 45 % frente a 80–100 % que sustenta el plan, brecha de 35 puntos; atrasos del proveedor 150, 80 y 11 días). Las fechas y los textos vienen de los 8 documentos citados. Los dos PDF se leyeron con Read; el acta .docx se extrajo con un script de texto. Esto es evidencia leída, no auditoría; los términos de TERMS.md v1.0 aplican.*
