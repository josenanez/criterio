# Corrida del 2026-10-14 · product-view

13 proyectos · 21 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

Producto con un solo proyecto (PRY-211): sin seccion de producto, solo sus senales. Declaro que no se pudo medir autoridad ni fase, campos de identidad con 14 meses, y 4 proyectos sin producto (No aplica).

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-14 — recaudos

**De qué sale:** fichas del estado (`estado/`), recalculadas con `portafolio.py compute` el 2026-10-14. Términos aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14.

**Recaudos tiene un solo proyecto: PRY-211 Cobranza digital.** La vista por producto no aporta nada aquí (no hay suma entre proyectos, ni dependencias internas, ni «fecha más tardía» distinta de la del proyecto), así que no armo sección de producto. Lo que sigue es lo que el cálculo dice de ese proyecto, en una línea por señal:

- **Estado declarado «verde»** (informe del 2026-09-25, `PRY-211-cobranza-digital/20-seguimiento/2026-09-25-informe-avance.pdf`, 19 días de antigüedad) con dos señales sin explicar: declarado contra evidencia.
- **Avance declarado 33,0 %** frente a un plan que sustenta 100 % (4 de 4 hitos cumplidos): brecha de 67,0 puntos, en el sentido de que el avance declarado va por detrás del plan.
- **Dos hitos «cumplidos» sin evidencia:** «Diseño funcional aprobado» (vencía 2025-10-09, 370 días) y «Integración con el core» (vencía 2026-02-02, 254 días).
- **Fecha comprometida:** fin **2026-04-01**, anterior a la fecha de hoy, sin replanificaciones (0) ni desviación contra la línea base (0 días). Un proyecto «verde» al 33 % con fecha de fin ya pasada es una contradicción que el comité debe ver.
- **Dinero (COP):** aprobado 18.000.000.000; comprometido 10.376.957.039 (57,6 %); ejecutado 10.387.931.433 (57,7 %); proyección 18.661.301.307 (3,7 % sobre lo aprobado); disponible real 7.623.042.961. Trae las cuatro cifras (1 de 1). Lo ejecutado figura por encima de lo comprometido; conviene confirmar con finanzas cuál de las dos cifras está desactualizada.
- **Dependencias:** ninguna declarada. **Proveedores:** ninguno registrado.
- **Lo que no sé:** `identity.authority` e `identity.phase` faltan; los campos de identidad y plan tienen 14 meses (fuente 2025-08-03, sobre el umbral de 12); ninguna de las 15 fuentes está marcada como evidencia o declaración.

**Fuera del producto pedido, para que conste:** 4 proyectos (PRY-202, PRY-205, PRY-208, PRY-210) figuran con producto «No aplica», es decir, sin producto declarado: nadie puede responder por el conjunto al que sirven. Los otros nueve productos declarados tienen un solo proyecto cada uno.

*Pie de rigor: cifras copiadas de la salida de `compute`; nada estimado. Dependencias internas: no aplica (un solo proyecto).*
