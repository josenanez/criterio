# Corrida del 2026-10-14 · document-index

13 proyectos · 26 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

69 documentos, 0 por releer. 10 citas de PRY-202 (pm_record) marcadas rotas por ruta sin prefijo de carpeta; el archivo existe. No se editó ninguna ficha. Términos v1.0 ya aceptados en config.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-14

**Documentos:** 69 · **Sin cambio:** 69 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-202 | pm_record.identity.code | 00-gobierno/2026-02-19-acta-constitucion.md |
| PRY-202 | pm_record.identity.name | (ídem) |
| PRY-202 | pm_record.identity.business_area | (ídem) |
| PRY-202 | pm_record.identity.sponsor | (ídem) |
| PRY-202 | pm_record.identity.manager | (ídem) |
| PRY-202 | pm_record.identity.committee | (ídem) |
| PRY-202 | pm_record.plan.start_date | (ídem) |
| PRY-202 | pm_record.plan.end_date | (ídem) |
| PRY-202 | pm_record.money.currency | (ídem) |
| PRY-202 | pm_record.money.approved | (ídem) |

Diagnóstico: el archivo SÍ existe en disco (`PRY-202-migración-a-la-nube/00-gobierno/2026-02-19-acta-constitucion.md`). La cita está escrita relativa a la carpeta del proyecto, sin el prefijo `PRY-202-migración-a-la-nube/` que usan las demás citas (esa misma ficha cita el mismo documento con prefijo en otros 10 campos). No es un documento perdido: es la forma de la ruta en los 10 campos del bloque `pm_record`. Corregirla es editar la ficha; no se hizo, se ofrece campo por campo.

### Formatos que no se pudieron leer
Ninguno: este comando no lee contenido, solo cuenta y compara hashes.

### Después
Nada que releer (`projects_to_recompute` vacío): no hace falta `/portfolio-scan`. Pendiente solo la corrección de las 10 citas de PRY-202, a confirmar.
