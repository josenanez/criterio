# Portafolio — 2026-10-14
13 proyectos · 10 con hallazgos (54 señales) · fichas cargadas: 13, todas con fecha 2026-10-14 (ninguna con más de una semana) · términos v1.0 aceptados el 2026-10-14 por José Francisco Ñáñez.

Formato `html`: se generó con `informe.py` (27 páginas, 13 proyectos, 10 productos) en `/home/claude/banco/ronda-1/bancos/espacio/reportes`.

## Qué cambió desde 2026-10-14
Sin cambios desde la corrida anterior (la instantánea previa es de hoy; 0 cambios).

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-202 Migración a la nube | plan.end_date | 2026-09-25 | 10-plan/2026-02-19-cronograma-v1.csv | 2026-10-16 | 00-gobierno/2026-02-19-acta-constitucion.md |

Además, 6 proyectos declaran verde y la evidencia lo contradice: PRY-201, PRY-207, PRY-208, PRY-209, PRY-210, PRY-211.

## Hitos vencidos sin evidencia
Hitos declarados cumplidos sin evidencia (los días son desde la fecha del hito):
| Proyecto | Hitos | Días (máx.) |
|---|---|---|
| PRY-202 | 5 (Diseño funcional … Salida a producción) | 186 |
| PRY-203 | 4 | 169 |
| PRY-205 | 2 | 144 |
| PRY-206 | 1 (Ambiente de pruebas certificado) | 44 |
| PRY-208 | 3 | 236 |
| PRY-209 | 3 | 311 |
| PRY-210 | 3 | 415 |
| PRY-211 | 2 | 370 |

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-209 Nómina electrónica | 16 | 2026-09-28 (informe de avance) |

## Dependencias en riesgo
Sin dependencias en riesgo detectadas entre proyectos. PRY-203 sí tiene riesgo con proveedor: Datacore Colombia con 3 entregables atrasados (150, 80 y 11 días) y 631.036.273 facturados sin entrega.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | 69 % de avance | el plan sostiene 25–50 % (adelantado, 1 de 4 hitos) |
| PRY-202 | 46 % | el plan sostiene 100 % (5 de 5 hitos marcados cumplidos sin evidencia) |
| PRY-203 | 45 % | plan 80–100 % |
| PRY-205 | 56 % | plan 67–100 % |
| PRY-206 | 32 % | plan 50–75 % |
| PRY-208 | 45 % | plan 75–100 % |
| PRY-209 | 80 % | plan 100 % |
| PRY-210 | 48 % | plan 100 % |
| PRY-211 | 33 % | plan 100 % |

Desviación de tiempo vs original: PRY-203 +112 días (44,4 %), PRY-205 +101 días (39,3 %), PRY-208 +21 días. PRY-205 y PRY-208 replanificaron sin autorización. Costo: PRY-207 proyecta 22,9 % sobre el aprobado (4.055.804.996 vs 3.300.000.000) con el cambio CC-01 sin línea base (25 días).

## Vacíos de información
- Ningún proyecto tiene autoridad de aprobación registrada (13 de 13).
- 1 proyecto sin línea base.
- Compromisos sin fecha: PRY-201 (Carlos Peña), PRY-202 (Laura Vélez), PRY-205 (Natalia Ospina). Vencido: PRY-206 (Diana Molina, 22 días).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199, 200, 204 | sin alertas | sustentado | 0 | 0 | 0 |
| PRY-201 | verde | contradicho | 0 | 0 | 0 |
| PRY-202 | — | contradicho | 0 | 0 | 0 |
| PRY-203 | — | contradicho | +112 d | — | 1 |
| PRY-205 | — | contradicho | +101 d | — | 1 |
| PRY-206 | — | contradicho | 0 | 0 | 0 |
| PRY-207 | verde | contradicho (costo) | 0 | 0 | 0 |
| PRY-208 | verde | contradicho | +21 d | — | 1 |
| PRY-209 | verde | contradicho | 0 | 0 | 0 |
| PRY-210 | verde | contradicho | 0 | 0 | 0 |
| PRY-211 | verde | contradicho | 0 | 0 | 0 |

## Necesito que confirmes
No toca confirmación periódica en esta corrida (sesión sin interfaz; no se hicieron preguntas).

---
Para el patrocinador: `decisiones.html`. Para quien actúa, con la cadena de evidencia por campo: `index.html`.

Pie: portfolio-report · fichas aplicadas: 13 (2026-10-14) · campos inciertos: 1 en ambigüedad (PRY-202 plan.end_date) · términos: TERMS.md v1.0.
