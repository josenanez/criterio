# Corrida del 2026-10-14 · product-business-case

? · 0 requerimientos · 32 s · 0 hallazgos

Caso de negocio armado: 0 de 2 cifras con fuente (volumen 139.663 y retorno 24 meses, ambas supuestas); sin costo de construir; sin criterio de éxito; sin serie medida ni fichas publicadas para cruzar. No se produjo ninguna cifra.

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Microseguros (PRD-306) · borrador del 2026-10-14
**Desde:** `00-definicion/2026-01-08-definicion-producto.md` y `00-definicion/2026-01-08-caso-de-negocio.md`, ambos del 2026-01-08 · **Cifras con fuente:** 0 de 2

Términos: TERMS.md v1.0 aceptados por José Francisco Ñáñez el 2026-10-14 (ya en la configuración). Sesión sin interfaz: las preguntas se tomaron con la respuesta sugerida.

**Lo primero:** no hay costo de construir en ningún documento, y ninguna de las dos cifras del caso tiene fuente. Con esto el documento es una propuesta, no un caso de negocio que se pueda evaluar.

## Qué problema resuelve, y para quién
«El segmento Base de la pirámide no tiene microseguros» (definición, 2026-01-08). Lo sostiene una sola entrevista del 2025-08-22: «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2025-08-22-entrevistas.docx`), con 418 días de antigüedad, sobre el umbral de 12 meses. No hay cifra de cuántas personas son. El segmento se nombra, no se dimensiona.

## Qué se construye
| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-1060 (doliente Ricardo Salas) | aceptado desde 2026-06-10 | «Cliente entrevistado»: la única entrevista no lo nombra |
| REQ-1061 (Gustavo Neira) | aceptado desde 2026-03-20 | Ídem |
| REQ-1063 (Felipe Arango) | aceptado desde 2026-06-26 | Ídem |
| REQ-2025 (Rubén Cárdenas) | aceptado desde 2026-10-06 | Ídem |

Fuente: acta del comité del 2026-10-09. REQ-1062 (Andrés Lozano) sigue **propuesto** desde 2026-05-29: queda fuera del alcance porque no está decidido. Los cuatro aceptados tienen «—» como proyecto que los ejecuta, y la definición dice «Ninguno declarado». La propuesta de la definición es la línea «Propuesta principal», sin contenido. El registro de requerimientos de `estado/` está vacío; esta tabla sale del acta, no del registro.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| Volumen mensual | 139.663 | **Supuesta** (aparece como declarada) | El caso de negocio se cita a sí mismo como fuente; no hay serie, estudio ni entrevista | 2026-01-08 |
| Retorno esperado | «en 24 meses» | **Supuesta** | Sin monto, inversión ni cálculo | 2026-01-08 |

Ninguna cifra es medida. Las dos se mueven a Vacíos y a Supuestos.

### Donde la cifra declarada y la medida no coinciden
Ninguno. `estado/metrics/` está vacío: no hay serie medida con la que contrastar el 139.663. Falta la serie, no la coincidencia.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | — | **No está en ningún documento** |
| Contratos, cotizaciones, costo del equipo | — | No hay ninguno a la vista |

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El volumen mensual es 139.663 | Todo lo que dependa del volumen (ingresos, capacidad, retorno) pierde base | El negocio (Camilo Beltrán), con una medición o estudio |
| El canal actual soporta el volumen (declarado 2026-08-25, marcado «verificado») | No hay con qué sostener el producto en producción | Quien tenga la capacidad medida del canal. No hay evidencia a la vista de la verificación; se trata como supuesto, y depende de la cifra anterior, que tampoco tiene sustento |
| Existe un segmento Base de la pirámide sin microseguros y dispuesto a pagarlos | No hay demanda | Descubrimiento nuevo: la evidencia es una entrevista de hace más de 12 meses, y es lo que alguien dijo, no lo que pagó |
| El retorno llega en 24 meses | El caso no se cumple | El negocio, con monto, inversión y cálculo |

Observación: el supuesto del canal lleva fecha 2026-08-25, posterior a la fecha de los dos documentos (2026-01-08). Se editaron después de su fecha y no lo dicen.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir | Sin él no hay caso que evaluar | Equipo y proveedores, por contrato o cotización |
| Origen del 139.663 | Es la única cifra y se cita a sí misma | El negocio |
| Qué significa «retorno esperado en 24 meses» | No es una cifra: no tiene monto ni inversión | El negocio |
| Tamaño del segmento | Sin él no se sabe cuántos son | Descubrimiento / negocio |
| Alternativas y qué pasa si no se hace | No están en el caso | El negocio |
| Qué proyecto construye el producto | Los cuatro requerimientos aceptados no tienen quien los ejecute | Comité de producto |
| Quién pidió los requerimientos | Todos dicen «Cliente entrevistado» y la entrevista no los nombra | Gerente de producto |
| Obligaciones normativas (seguros, datos personales, cobro de primas) | Se rozan, pero no hay país declarado ni norma a la vista | Revisión jurídica |

## Cómo se sabrá si funcionó
No está declarado: no hay criterio de éxito ni métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después, porque el cierre se juzga contra él.

## Si hay otros productos publicados
No hay ninguno publicado: `estado/fichas` no existe. Ningún otro documento de `documentos/productos/` afirma el 139.663. El cruce de `/product-overlap` no se pudo hacer con fichas, y no hay coincidencia visible en los documentos.

## Después
Los supuestos del volumen y del canal son candidatos para **assumption-tracking** (pasarlos al seguimiento con doliente). No corresponde `/product-charter`: el caso no tiene costos ni criterio de éxito, y no se recomienda aprobar ni rechazar; esa decisión es del Comité de producto.

*Borrador de trabajo, no certificado: verifica cada punto contra los documentos antes de decidir (TERMS.md v1.0).*
