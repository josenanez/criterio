# Corrida del 2026-10-14 · portfolio-wake

13 proyectos · 31 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 9 |
| `declared_vs_evidence` | 6 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `silent` | 1 |

Barrido: 69 documentos sin cambios; 10 citas de PRY-202 no resuelven por ruta relativa al proyecto (bloque de la PM, no tocado). Confirmación no ejecutada (sin interlocutor).

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

## 2026-10-14

**Revisé:** 69 documentos · 0 cambiaron · 0 proyectos recalculados

Términos 1.0 aceptados (José Francisco Ñáñez, 2026-10-14). Tocaban `sweep` y `confirmation`; no había peticiones.

### Hallazgo: citas que no resuelven (PRY-202)
10 campos del bloque `pm_record` de PRY-202 (identidad, plan.start/end, dinero) citan `00-gobierno/2026-02-19-acta-constitucion.md`. El archivo existe en la carpeta del proyecto, pero el índice no lo resuelve: la ruta está escrita relativa al proyecto y no a la raíz de documentos (`PRY-202-migración-a-la-nube/00-gobierno/…`). El bloque lo escribió la PM (ficha-pm.json); no lo toqué. Queda como pregunta para la PM: corregir la ruta de la cita. Ningún dato se recalculó por esto.

### Preguntas
Confirmación mensual (5 campos) **no ejecutada**: sesión sin nadie que responda. No se marca como hecha; vuelve a tocar mañana.

**Vuelvo el 2026-10-15.**
