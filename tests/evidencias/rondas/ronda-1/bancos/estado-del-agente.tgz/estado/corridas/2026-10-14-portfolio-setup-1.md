# Corrida del 2026-10-14 · portfolio-setup

3 proyectos · 69 documentos, 55 releídos y 14 sin cambio · 64 s · 12 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 3 |
| `progress_vs_plan` | 2 |
| `variance_time` | 1 |
| `commitment_undated` | 1 |
| `rebaseline_unauthorized` | 1 |
| `commitment_overdue` | 1 |
| `variance_cost` | 1 |
| `change_without_baseline` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); aprox. 10 minutos hasta el primer resultado; 3 proyectos (PRY-205, 206, 207), 14 documentos, 12 señales

Contra la corrida del 2026-10-14: +12 hallazgos.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 69 documentos en 13 proyectos · formatos: .md 25, .docx 14, .pdf 14, .xlsx 8, .csv 6, .json 1, .txt 1 · más reciente: 2026-10-14
**Eres:** PMO del portafolio (propuesto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; primer comité supuesto el 2026-10-20 (una semana después del último visto, 2026-10-13), así que el informe llega el 2026-10-18
**En:** presentación (la configuración lo guarda como página HTML)
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-14 (prueba sin interfaz).
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-205 Prevención de lavado de activos | 6 | Gerente Andrés Lozano, patrocinadora Sandra Gil. Declara amarillo, 56 %. Presupuesto 6.800 M COP, ejecutado 3.215 M. Cierre comprometido 2026-12-24; el cronograma v2 (2026-10-14) mueve la integración con el core a 2027-02-20 | Facultad del gerente, fase, proveedores. Dependencias: "ninguna declarada", aunque el informe cita el calendario de liberaciones del core |
| PRY-206 Billetera y QR | 5 | Gerente Carlos Peña, patrocinadora Laura Vélez. Declara amarillo, 32 %. Presupuesto 18.000 M COP, ejecutado 3.216 M. Un acta de recibo (diseño funcional, 2026-10-09) | Facultad del gerente, fase, proveedores, acta de recibo del ambiente de pruebas |
| PRY-207 Onboarding PyME | 3 | Gerente Beatriz Cuéllar, patrocinador Jorge Medina. Declara verde, 72 %. Presupuesto 3.300 M COP, proyección 4.056 M. CC-01 de +25 días y 50 M | Facultad del gerente, fase, cronograma, hitos, acta de comité |

### Hallazgos (todos levantados por el cálculo, 12 señales)

**PRY-205**
- Desviación de tiempo: +101 días (39,3 %) contra la línea base original.
- Línea base movida sin autorización: la CC-01 (+101 días, +202 M COP) sigue "pendiente de presentación al comité" y el cronograma v2 ya usa la fecha nueva.
- Avance declarado 56 % frente a lo que el plan sostiene (67–100 %): 11 puntos por debajo.
- Dos hitos declarados cerrados sin acta que lo pruebe: Diseño funcional aprobado (144 días desde su fecha) y Ambiente de pruebas certificado (58 días).
- Un compromiso sin fecha: Natalia Ospina, "Entregar el punto 37" (comité del 2026-10-08, plazo "por definir").

**PRY-206**
- Avance declarado 32 % frente a lo que el plan sostiene (50–75 %): 18 puntos por debajo.
- Hito Ambiente de pruebas certificado declarado cerrado sin acta de recibo (44 días).
- Compromiso vencido: Diana Molina, "Entregar el punto 3", plazo 2026-09-22, 22 días de atraso.

**PRY-207**
- Declarado verde, pero la proyección al cierre (4.056 M) supera el presupuesto aprobado (3.300 M) en 22,9 %. Es el verde que los documentos no sostienen.
- CC-01 (+25 días) figura como autorizada por el comité, pero no hay línea base nueva que la recoja.
- Varios datos de identidad y de plan se apoyan solo en el acta de 2025-06-02, con 16 meses sin confirmación posterior.

### El portafolio completo
10 proyectos más (53 documentos) · dos lotes, uno tras otro. Tomó pocos minutos leer estos tres; calculo unos 20 a 30 minutos para el resto.

### Lo que le falta a tu carpeta
- Ningún proyecto de la muestra tiene la facultad del gerente (hasta qué monto decide sin subir a comité) ni la fase.
- PRY-205 y PRY-206 tienen hitos cerrados sin acta de recibo: la prueba no está en la carpeta, no que no exista.
- PRY-207 no tiene cronograma ni acta de comité; no se puede juzgar su plan.
- Los compromisos de comité llegan con plazo "por definir" o sin dueño de seguimiento.
- Las actas de constitución traen alcance genérico ("Componente 1, 2, 3") y "Dependencias: ninguna declarada", así que los cruces entre proyectos no tienen de dónde salir.
- Ninguno es bloqueante.

**Siguiente:** ¿corro el portafolio completo? Si tu equipo tiene gerentes de proyecto, puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
