Informe sale de la ficha `estado/records/PRY-209.json`, actualizada el 2026-10-14, con cifras de `compute` al 2026-10-14.
Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (confirmado en la configuración).

## PRY-209 · Nómina electrónica — estado al 2026-10-14

**Declara el gerente (Paula Céspedes):** verde · 80 % · al 2026-09-28 (hace 16 días; no está vencida como declaración, el umbral es 30)
**Sustento documental:** contradicho en parte. Alerta `declared_vs_evidence` abierta: el verde no explica tres señales.
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `progress_vs_plan`, `silent`
**Último documento:** 2026-09-28 (16 días de silencio; umbral 15) · **Última reunión:** sin dato; la ficha no registra ninguna reunión ni compromiso

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-07-01 | 2026-07-01 | 0 días contra original y contra vigente |
| Presupuesto aprobado | COP 18.000.000.000 | COP 18.000.000.000 (sin línea base de costo separada) | proyección COP 18.485.959.643, **2,7 %** sobre lo aprobado |

Replanificaciones: 0. Ojo: la desviación en 0 días no significa «a tiempo». La fecha de cierre de la línea base (2026-07-01) ya pasó hace 105 días, nadie la movió, y el proyecto declara 80 %. El cálculo mide contra una fecha que nadie actualizó.

Dinero (de `compute`): comprometido COP 11.829.020.129 (65,7 %), ejecutado COP 2.981.801.263 (16,6 %), disponible real COP 6.170.979.871. Fuente: informe de avance del 2026-09-28.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-12-07 | 2025-12-07 | cumplido (declarado) | ninguna; 311 días desde la fecha |
| Ambiente de pruebas certificado | 2026-03-20 | 2026-03-20 | cumplido (declarado) | ninguna; 208 días |
| Integración con el core | 2026-07-01 | 2026-07-01 | cumplido (declarado) | ninguna; 105 días |

Los tres hitos del plan figuran como cumplidos sin evidencia documental. El plan respaldaría 100 % de avance; el gerente declara 80 %: 20 puntos de diferencia, en sentido de atraso respecto del plan. Los dos números no pueden ser ciertos a la vez: o el 80 % es correcto y algún hito no está cumplido, o los hitos están cumplidos y falta trabajo que el plan no contempla.

### Dónde no coincide
- **Declarado:** verde, 80 % (informe de avance, 2026-09-28). **Documentos:** ningún hito con evidencia de cumplimiento; cierre planificado 2026-07-01 vencido sin replanificación; 16 días sin documentos nuevos.
- **Fecha de cierre:** el cronograma v1 dice 2026-07-01; la ficha anota que el acta de constitución declara cierre 2026-08-22 (nota en la línea base v1, 2025-08-17). Dos fechas de cierre en dos documentos; el script no lo marcó como conflicto y no lo resuelvo a ojo.
- **Presupuesto:** el 18.000.000.000 aprobado y las demás cifras salen solo del informe de avance del gerente, no de un documento independiente.

### Abierto
**Riesgos e incidencias sin movimiento:** dos riesgos, ambos sin dueño, ambos del informe del 2026-09-28: (1) cambio regulatorio en discusión que puede mover el alcance; (2) el proveedor no ha confirmado la fecha de la última entrega. La ficha no trae fecha de apertura, así que no puedo dar días sin movimiento.
**Compromisos vencidos:** ninguno, porque no hay compromisos registrados (no es lo mismo que no tener vencidos).
**Dependencias sin confirmar:** ninguna registrada. Ojo: el riesgo del proveedor sugiere una dependencia externa, pero la ficha no tiene proveedores (`vendors` vacío).

### Sin dato
- Autoridad y fase del proyecto (`identity.authority`, `identity.phase`).
- Proveedores y contrato, aunque un riesgo menciona uno.
- Reuniones y compromisos: ninguno en la ficha.
- Dueño de los dos riesgos.
- Los 15 campos con fuente no están marcados como evidencia ni como declaración (`unmarked`: 15, `evidence`: 0).
- Datos de identidad y plan con 14 meses de antigüedad (acta del 2025-08-17), por encima del umbral de 12.

### Siguiente paso posible
El proyecto reporta verde con la fecha de cierre vencida y tres hitos sin evidencia. Puedo preparar el punto de comité (próximo comité: 2026-10-20). No hay cambio no formalizado registrado, así que no ofrezco solicitud de cambio.

---
Plugin criterio-portfolio 0.3.6 · Ficha PRY-209 del 2026-10-14 (esquema 0.2) · Campos inciertos: autoridad, fase, proveedores, reuniones, dueños de riesgos, fecha de cierre (cronograma vs. acta) · Términos: TERMS.md v1.0
