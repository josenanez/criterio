> **Borrador no generado.** Lo cerraría el gerente de producto (Camilo Beltrán, Comité de producto); aquí no hay nada que cerrar.

## Especificación — Microseguros (PRD-306) · 2026-10-14

**No hay especificación que escribir: el registro de requerimientos está vacío.**

- `estado/requirements/` no contiene ningún requerimiento, así que no hay ninguno en `aceptado` ni `en_construccion`. Especificar lo que nadie registró ni decidió sería inventarlo.
- La corrida anterior de `/product-requirements` (2026-10-14) ya lo dijo: 0 requerimientos y sin definición cargada.
- Términos: aceptados por José Francisco Ñáñez, versión 1.0, 2026-10-14 (TERMS.md v1.0).

**Qué no hice:** no saqué requerimientos de los documentos de `documentos/productos/PRD-306` (definición, descubrimiento, comité) para rellenar el registro. Registrarlos y aceptarlos es una decisión que viene antes de este comando.

**Siguiente paso:** correr `/criterio-product:product-requirements` para registrar los requerimientos, lograr que el comité acepte alguno, y volver a correr `/product-spec`.

---
Registro: `estado/requirements/` (vacío) · al 2026-10-14 · 0 requerimientos cubiertos · Términos: TERMS.md v1.0.
