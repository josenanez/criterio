## Trazabilidad — Microseguros (PRD-306) · al 2026-10-14

0 requerimientos registrados. No hay cadena que trazar.

- `estado/requirements/` está vacío y `estado/producto.json` no tiene identidad ni definición (problema, quién, éxito y autoridad sin dato). El cálculo devuelve 0 decididos, 0 con proyecto, 0 confirmados, 0 entregados.
- La carpeta de fichas configurada (`estado/fichas`) no existe, así que ninguna traza se podría haber confirmado de todos modos.
- Los registros de proyecto que hay en `estado/records/` (PRY-199 a PRY-211) no se usaron como fichas: la configuración no los señala y no se inventó la equivalencia.

Las dos brechas (lo decidido que nadie construye, y el proyecto cuya ficha dice ejecutar otro producto) no se pueden evaluar sin registro. Esto no es «todo en orden»: es «no hay nada que comparar».

Siguiente paso posible: `/criterio-product:product-requirements` para levantar el registro, y luego repetir `/product-trace`.
