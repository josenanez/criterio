## Diagnóstico · PRY-203 Open Banking · 2026-10-14

**Leí:** 8 documentos · 2026-02-27 a 2026-10-12 · formatos: .md (3), .csv (2), .pdf (2), .docx (1)
**No pude leer:** ninguno. Busqué además el código, el nombre, el proveedor y el contrato en los documentos de los otros 12 proyectos del portafolio: ninguno menciona PRY-203, Open Banking, Datacore ni CT-948. Esta carpeta es toda la evidencia que existe.

Términos: TERMS.md v1.0, aceptados por José Francisco Ñáñez el 2026-10-14 (figura en la configuración local).

### Dictamen
**Sostenido:** 7 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 3 (19 evaluadas)

De este proyecto se puede afirmar quién lo gobierna en el papel, cuánto presupuesto se aprobó, qué se firmó con el proveedor y que el gerente lo declara en rojo. Esa declaración sí la respalda la evidencia. No se puede afirmar que ninguno de los cuatro hitos "cerrados" ocurrió, que el cambio CC-01 lo autorizó alguien con facultad, que la línea base vigente (v2) está aprobada, ni que se recibió algo del proveedor al que ya se le radicó una factura. La carpeta no contiene un solo documento de evidencia de entrega, de aceptación ni de decisión.

*Sostenidas (7):* patrocinador, gerente y comité nombrados en el acta · presupuesto aprobado de 6.800.000.000 COP (acta e informe coinciden) · línea base v1 con salida a producción el 2026-11-16 · contrato CT-948 con tres entregables, fechas y montos · estado Rojo · los +112 días de CC-01 coinciden con el paso de 2026-11-16 a 2027-03-08 · compromiso abierto de Laura Vélez para el 2026-10-28.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Gustavo Neira | acta de constitución, 2026-02-27 |
| Gerente | María Restrepo | acta de constitución, 2026-02-27 |
| Autoridad declarada | **No aparece en ningún documento.** El acta no dice qué puede aprobar el gerente ni hasta dónde | — |
| Comité | Comité de Banca Empresas. Nota: el área dueña del proyecto es Banca Hipotecaria; el acta no explica por qué lo gobierna el comité de otra banca | acta de constitución, 2026-02-27 |

Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. Además, el acta declara "Dependencias: ninguna declarada" y no tiene fase.

### Contra el plan
- **Línea base original (v1):** salida a producción 2026-11-16 (`2026-02-27-cronograma-v1.csv`). El acta declara además un cierre el 2026-12-12; ningún documento explica la diferencia entre ambas fechas.
- **Línea base vigente (v2):** salida a producción 2027-03-08 (`2026-10-12-cronograma-v2.csv`).
- **Replanificaciones:** 1. Motivo: solicitud de cambio CC-01, ampliación de alcance, +112 días.
- **Desviación contra la original:** 112 días, 44.4 %. **Contra la vigente:** 0 días, porque la vigente es la que absorbió el cambio.
- **La v2 no tiene respaldo de aprobación.** No hay acta ni decisión fechada que la apruebe; el 2026-10-12 es solo la fecha del archivo. CC-01 dice "Autorizada por el comité" sin nombre, sin fecha de decisión y sin acta. La minuta de comité más cercana (2026-10-02) es anterior a la solicitud (2026-10-07) y no trata ningún cambio. Las dos únicas personas que figuran en ella son la solicitante del cambio y el patrocinador.
- **CC-01 costo:** 224.000.000 COP adicionales. El informe del 2026-10-12 sigue mostrando 6.800.000.000 COP como aprobado, así que el costo del cambio no está reflejado en el presupuesto.
- **Avance declarado frente al plan:** el informe declara 45 %. Los cronogramas marcan 4 de 5 hitos cerrados, lo que el plan sostiene como 80-100 %. Brecha: 35.0 puntos.

### Hitos vencidos sin evidencia
Los cuatro figuran como "cerrado" en el cronograma, con fecha vigente igual a la de línea base (ninguno se corrió). Ninguno tiene documento que lo pruebe.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-04-28 | 169 | Acta de aprobación del diseño funcional, firmada |
| Ambiente de pruebas certificado | 2026-06-18 | 118 | Certificado o acta de certificación del ambiente |
| Integración con el core | 2026-08-07 | 68 | Acta o informe de pruebas de integración |
| Piloto con usuarios internos | 2026-09-27 | 17 | Informe de resultados del piloto y cierre |

"Salida a producción" (2027-03-08, pendiente) no está vencido.

**Entregables del proveedor vencidos (CT-948, Datacore Colombia), ninguno con acta de recibo:**

| Entregable | Fecha | Días | Estado en el contrato |
|---|---|---|---|
| Licenciamiento del motor | 2026-05-17 | 150 | pendiente |
| Bolsa de horas de desarrollo | 2026-07-26 | 80 | en curso |
| Parametrización del tarifario | 2026-10-03 | 11 | en curso |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 3.046.727.673 | 3.066.221.014 | 6.288.285.107 | 3.753.272.327 |

Cifras de la salida de `compute`: ejecutado 45.1 % del aprobado, comprometido 44.8 %, proyección 7.5 % por debajo del aprobado. Moneda COP. Todas vienen del informe de avance del gerente; ninguna tiene un respaldo contable en la carpeta.

- **El ejecutado (3.066.221.014) es mayor que el comprometido (3.046.727.673)**, y no debería poder serlo. El disponible real se calculó restando el comprometido; si el ejecutado fuera la cifra firme, el disponible sería menor.
- **Facturado al proveedor:** 631.036.273 COP (factura FV-1948, 2026-09-15, radicada en cuentas por pagar) con **cero entregables aceptados**. El contrato dice que cada entregable se factura contra acta de recibo firmada por el gerente; no hay ninguna. La factura no dice a cuál de los tres entregables corresponde: "Entregables del contrato CT-948". No consta si se pagó ni si esa cifra está dentro del ejecutado.
- La proyección no trae método; no se puede saber si incluye el costo de CC-01.

### Lo que se dijo y nadie registró
No hay en la carpeta un registro de riesgos, de incidencias ni de dependencias. Lo que hay suelto:
- **Riesgo:** "Cambio regulatorio en discusión que puede mover el alcance" (informe, 2026-10-12). Sin dueño, sin probabilidad, sin impacto, sin fecha de revisión.
- **Dependencia no declarada:** el acta dice "ninguna", pero el proyecto depende de Datacore Colombia (contrato firmado el 2026-03-03) para licencia, horas de desarrollo y tarifario, con los tres entregables vencidos.
- **Incidencia no registrada:** una factura radicada sin acta de recibo, y un licenciamiento 150 días vencido.
- **Compromiso:** Laura Vélez, "Entregar el punto 30", para el 2026-10-28 (minuta 2026-10-02). Abierto, aún no vence. Dos problemas: "el punto 30" no tiene referente en ningún documento, y Laura Vélez no figura entre los asistentes.
- La minuta del 2026-10-02 solo lista dos temas ("Avance", "Compromisos") sin contenido, decisiones ni riesgos.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| El proyecto lleva 45 % de avance | Informe de avance 2026-10-12: "Avance reportado: 45 %" | Cronograma v2 2026-10-12: 4 de 5 hitos "cerrado" (el plan sostiene 80-100 %). Una de las dos cosas es falsa: el avance o los hitos cerrados |
| Se facturó por entregables del contrato | Factura FV-1948 2026-09-15: 631.036.273 COP "Entregables del contrato CT-948", radicada | Contrato CT-948: se factura contra acta de recibo firmada; los tres entregables están "pendiente" o "en curso"; no hay acta |
| Comprometido y ejecutado de la ejecución presupuestal | Informe 2026-10-12: Comprometido 3.046.727.673 | Mismo informe: Ejecutado 3.066.221.014 (mayor que lo comprometido) |

### Sin sustento
Afirmaciones que nada contradice y nada respalda (9):
1. Diseño funcional aprobado: cerrado, 2026-04-28.
2. Ambiente de pruebas certificado: cerrado, 2026-06-18.
3. Integración con el core: cerrado, 2026-08-07.
4. Piloto con usuarios internos: cerrado, 2026-09-27.
5. CC-01 autorizada por el comité (sin acta, nombre ni fecha de decisión).
6. La línea base v2 está aprobada y vigente desde el 2026-10-12.
7. Proyección al cierre de 6.288.285.107 COP (sin método ni cálculo).
8. Existe un riesgo regulatorio que puede mover el alcance (único respaldo: el propio informe).
9. "Se ajustó el plan de pruebas con el área de seguridad" (único hecho del periodo que reporta el informe). Queda una tensión sin resolver: el ambiente de pruebas figura certificado desde junio y el piloto cerrado en septiembre, y en octubre se está ajustando el plan de pruebas.

### Lo que esta carpeta no permite saber
- **Si los hitos se cumplieron.** Sin actas ni informes de resultados, el 45 % y el "4 de 5" no se pueden dar por buenos ni por falsos.
- **Quién autorizó CC-01 y con qué facultad.** Sin eso, los +112 días y los 224.000.000 COP no son una desviación aprobada.
- **Qué se pagó a Datacore y por qué.** Falta el acta de recibo, el soporte de pago y la relación entre la factura y los tres entregables.
- **Cuál es el avance real.** Falta cualquier informe de avance anterior al 2026-10-12: es el único. Entre el 2026-03-03 y el 2026-09-15 no hay un solo documento en la carpeta, así que el desarrollo de la desviación no se puede reconstruir.
- **Qué facultad tiene la gerente.** Sin autoridad declarada no se puede decir qué cambio le correspondía aprobar a ella.
- **Quién es Laura Vélez y qué es "el punto 30".**
- **Por qué gobierna el Comité de Banca Empresas un proyecto de Banca Hipotecaria.**
- **La diferencia entre el cierre del acta (2026-12-12) y la salida a producción del cronograma v1 (2026-11-16).**

### Siguiente paso posible
Sobre este dictamen no recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo (a) llevar las 3 contradicciones al gerente como preguntas, una por una, o (b) preparar el punto del comité del 2026-10-20 con la lista de lo que falta (actas de hitos, acta de decisión de CC-01, actas de recibo y soporte de la factura FV-1948).

---
Plugin criterio-portfolio 0.3.6 · Diagnóstico desde cero de PRY-203 con 8 documentos del 2026-02-27 al 2026-10-12 (sin usar la ficha previa como fuente) · Campos inciertos: autoridad, fase, aprobación de CC-01 y de la línea base v2, soporte del ejecutado, dueño del riesgo regulatorio · Cifras derivadas copiadas de `compute` · Términos: TERMS.md v1.0
