Términos: ya aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14), igual a la versión de TERMS.md. Sesión sin interfaz: no se hicieron preguntas. Sin tema en el argumento, se tomó lo marcado como escalable en la corrida anterior (`salida-pm-agenda.md`): la fecha de cierre.

## Para decisión — Migración a la nube (PRY-202) · 2026-10-14

### Primero: el acta no declara la autoridad del gerente
El acta del 2026-02-19 no dice qué puede decidir Sandra Gil ni qué debe subir (en la ficha, `identity.authority` está sin encontrar). Es el primer punto que escala, antes del de abajo: sin él, nadie puede decir si el cambio de fecha lo decide la gerente, el patrocinador o el comité. **Pregunta cerrada:** ¿el Comité de Banca Empresas confirma que todo cambio de la fecha de cierre o del presupuesto aprobado es suyo (y del patrocinador Camilo Beltrán), y que el resto lo decide la gerente? Sí / No / Otra distribución.

### ¿Se mueve el cierre del 2026-10-16 al 2026-11-02, o se mantiene el 16 de octubre?

**Quién decide:** no se puede decir con el acta (ver arriba). Lo más cercano que declara es que el presupuesto lo aprobó el Comité de Banca Empresas y que el patrocinador es Camilo Beltrán. Mover el cierre cambia la línea base, y eso excede a la gerente. · **Si no se decide hoy:** el 2026-10-16, dentro de 2 días, vence la fecha de cierre del acta con compromisos vivos hasta el 28/10 y el 02/11 y sin documento de replanificación. El proyecto quedaría vencido sin una línea base vigente que lo explique. La próxima instancia es el comité del 2026-10-20 según la configuración, aunque las notas del 13/10 dicen «en dos semanas» (≈ 2026-10-27); ese conflicto está sin resolver.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mover el cierre al 2026-11-02 (+17 días) | Sin cambio declarado | Cierre 2026-11-02, la fecha más tardía con respaldo en un documento (acta del comité del 13/10, compromiso de Paula Céspedes). Es un piso: la prueba de carga que «se repite» no tiene fecha en ningún documento | Sin cifra en los documentos. Proyección al cierre 3.138.511.864 COP contra 3.300.000.000 aprobados, pero se calculó para el cierre original |
| B. Mover a una fecha por definir, después de que Sandra Gil presente plan de repetición de la prueba de carga | Sin cambio declarado | Indeterminado hasta tener ese plan | Sin cifra |
| C. Mantener el 2026-10-16 y cerrar con lo entregado | Se recorta: el criterio de éxito («migración en producción y medido») no se cumple con una prueba de carga que no alcanzó el umbral | Cierre 2026-10-16 | Sin cifra; queda fuera el trabajo que sigue pendiente |

**Recomiendo:** A, tratada como fecha provisional y con la condición de que la gerente lleve la replanificación formal (control de cambios, línea base anterior intacta) al comité. Es la única fecha que hoy tiene un documento detrás; B no se puede decidir sin una fecha, y C declara incumplido un proyecto del que no consta que esté cerrado.

### A quién alcanza
Con `impact --days 17`: **0 proyectos alcanzados y 0 hitos tuyos.** Esto no demuestra que no haya efecto: el estado solo contiene la ficha de este proyecto, y el acta declara «Ninguna declarada» como dependencia. Falta saber si Medios de Pago u otro proyecto depende de esta salida. Eso lo tiene que confirmar la gerente. **Lo que el cálculo no dice:** cuántos días se mueve cada proyecto alcanzado, porque no hay holgura por actividad.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| — ninguno en el estado | — | — | Sin dependencias declaradas; no confirmado con el otro lado |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ninguno por delante | — | Los 5 hitos del cronograma v1 figuran «cerrados», el último («Salida a producción») el 2026-09-25 |

### Lo que no cuadra y conviene aclarar antes del comité
- El cronograma marca «Salida a producción» como cerrado el 2026-09-25, pero el informe del 2026-10-09 dice que se reprogramó la salida y que la prueba de carga se repite. No hay replanificación registrada.
- El informe declara Rojo y 46% de avance, con 1.177.688.077 COP ejecutados de 3.300.000.000.
- Paula Céspedes tiene dos fechas para «entregar el punto 3»: 2026-10-28 (notas) y 2026-11-02 (acta del comité). «No alcanzó» sugiere una promesa anterior que ningún documento muestra. Si la fecha del punto 3 es el 28/10, la opción A podría quedar en 12 días.
- Riesgo sin dueño: «el proveedor podría no llegar con el equipo completo para la siguiente fase» (notas del 13/10). No tiene probabilidad, impacto ni responsable, y no está en el informe. Si se materializa, empuja la opción A.

### De dónde sale esto
- Acta de constitución, `00-gobierno/2026-02-19-acta-constitucion.md`: cierre 2026-10-16, presupuesto aprobado, patrocinador, comité y la ausencia de autoridad declarada.
- Informe de avance, `20-seguimiento/2026-10-09-informe-avance.md`: Rojo, 46%, cifras de presupuesto, prueba de carga y reprogramación de la salida.
- Cronograma, `10-plan/2026-02-19-cronograma-v1.csv`: hitos todos cerrados.
- Acta del comité, `30-reuniones/2026-10-13-comite-semanal.docx` (compromiso al 2026-11-02; asistentes Sandra Gil y Camilo Beltrán) y `2026-10-13-notas-reunion.txt` (28/10, «no alcanzó», riesgo del proveedor, «próxima reunión en dos semanas»).
- Efecto del cambio: `portafolio.py impact --code PRY-202 --days 17`.

**No sé:** el costo de cada opción, la fecha de repetición de la prueba de carga, qué es el «punto 3», y si algún otro proyecto depende de este.

Llevar este paquete al comité es de la gerente. Si el comité decide, el cambio de línea base va por control de cambios, sin tocar la anterior.
