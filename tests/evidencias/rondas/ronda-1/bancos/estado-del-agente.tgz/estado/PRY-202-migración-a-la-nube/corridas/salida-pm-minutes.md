Términos: ya aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14), igual a la versión de TERMS.md.

# Acta — Migración a la nube (PRY-202) · 2026-10-13
**Asistieron (según las notas):** Paula Céspedes, Rubén Cárdenas, Sandra Gil, Laura Vélez, Óscar Ramírez · **Fuente:** `2026-10-13-notas-reunion.txt` (cruzada con `30-reuniones/2026-10-13-comite-semanal.docx`) · **Ausentes con tema en agenda:** no determinable; las notas no traen agenda.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 3 | **28/10/2026** según las notas (l. 4) · **2026-11-02** según el acta del comité | Fecha en conflicto, ver «Sin resolver». Las notas dicen que «no alcanzó», lo que sugiere una promesa anterior que no está en ningún documento leído; por eso **no** se cuenta como reprogramado (0 veces registradas). |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 (l. 6) | El 24/10/2026 es sábado; no se corrige, se anota. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dicho: «la otra semana» (l. 5). `due_date: no_declarada`. |

## Decisiones
Ninguna. Las notas no registran que alguien decidiera algo ni qué se descartó.

## Quedó sin decidir
Nada se discutió como decisión pendiente en las notas; no se inventa.

## Intenciones sin doliente
Ninguna. Rubén Cárdenas asistió y no aparece con ninguna intervención.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (l. 7; las notas añaden que «nadie lo anotó como riesgo») | No atribuido en las notas («se comentó») | Riesgo | **No.** El informe de avance del 2026-10-09 lista otros dos riesgos (disponibilidad del equipo de seguridad; calendario de liberaciones del core). Queda en la ficha con probabilidad, impacto y doliente sin declarar. |

## Cerrado en esta reunión
Nada (sección omitida: no hay documento que cierre algo).

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Fecha de Paula Céspedes | 2026-10-28 | 2026-11-02 | Notas, 2026-10-13 / acta del comité, 2026-10-13 (mismo día, ninguna anula a la otra) |
| Asistentes | Paula, Rubén, Sandra, Laura, Óscar | Sandra Gil y Camilo Beltrán | Notas / acta del comité, ambas 2026-10-13. Camilo (patrocinador) no figura en las notas; no es seguro que sean la misma sesión. |
| Próxima reunión | «en dos semanas» (≈ 2026-10-27) | Comité semanal, próximo 2026-10-20 | Notas, 2026-10-13 / configuración local, 2026-10-14 |
| Fecha de cierre | Ningún compromiso llega antes del 24/10; todos pasan del cierre | Cierre 2026-10-16 | Observación mía, no dicha en la reunión: acta de constitución, 2026-02-19. No hay documento de replanificación. |

## Sin resolver de la transcripción
- «Paula Céspedes dice que lo de «entregar el punto 3» no alcanzó, se compromete para el 28/10/2026»: no se sabe qué fue lo que «no alcanzó» ni cuál fue la fecha anterior.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-24»: no queda claro si Óscar se compromete a hacerla o solo se anota la fecha de una cita.
- «la otra semana» (Laura Vélez): relativo al 13/10, no se fija fecha.
- Quién comentó lo del proveedor.

---
Recalculo (`compute`, 2026-10-14): 1 alerta, `commitment_undated` (Laura Vélez); 0 vencidos, 0 reprogramados. El conflicto de fecha de Paula no lo detecta el cálculo; se declara aquí. La ficha `PRY-202.json` ya traía estos tres compromisos y el riesgo, así que no la modifiqué.

Siguiente: `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por ahora; ningún campo de la ficha cambió.
