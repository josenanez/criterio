# Corrida del 2026-10-14 · pm-commitments

1 proyectos · 24 s · 1 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 1 |

Nada reprogramado ni vencido; Laura Vélez sin fecha; fecha de Paula Céspedes en conflicto (28/10 vs 02/11)

Contra la corrida del 2026-10-14: +0 hallazgos.

## Lo que produjo

Términos: ya aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14), igual a la versión de TERMS.md. Sesión sin interfaz: no se hicieron preguntas.

## Compromisos — Migración a la nube (PRY-202) · al 2026-10-14

3 compromisos abiertos, todos dichos el 2026-10-13. Ninguno vencido, ninguno reprogramado según lo que hay en el expediente. Hay uno sin fecha y uno con dos fechas en conflicto.

### Se viene reprogramando
Nada registrado (0 reprogramaciones en la ficha). Una observación sobre Paula Céspedes, abajo.

### Vencidos sin evidencia
Ninguno.

### Vencen esta semana
Ninguno. El más próximo es el de Óscar Ramírez, el 2026-10-24.

### Con fecha en conflicto o por aclarar
| Quién | Qué | Fecha | Observación |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 3 | **2026-10-28** según las notas de la reunión (`2026-10-13-notas-reunion.txt`, l. 4) · **2026-11-02** según el acta del comité (`30-reuniones/2026-10-13-comite-semanal.docx`) | Los dos documentos son del mismo día y ninguno anula al otro. Las notas dicen que lo del punto 3 «no alcanzó», lo que sugiere una promesa anterior. Busqué en el acta de constitución y en el cronograma v1: no hay rastro de ella. No se cuenta como reprogramado (0 veces registradas), pero si esa promesa anterior existe, ya sería la segunda fecha y habría que reconstruirla. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 (notas, l. 6) | El 24/10/2026 es sábado; se anota, no se corrige. Las notas no aclaran si Óscar se compromete a hacerla o si solo es la fecha de una cita. |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-13 |

No puede estar vencido. Se cuenta aparte para que no desaparezca. «La otra semana» es relativo al 13/10 y no fija un día.

### Cerrados desde la última revisión
Ninguno. No hay documento en el expediente que cierre ningún compromiso.

### Lo que hay que mirar de fondo
- Ninguno de los tres compromisos con fecha llega antes del 24/10. El cierre del proyecto en el acta de constitución es el 2026-10-16, y no hay documento de replanificación. Es una observación mía, no se dijo en la reunión.
- Rubén Cárdenas asistió y no tiene ningún compromiso ni intervención en las notas.

Recalculo (`compute`, 2026-10-14): `commitments_overdue` 0, `commitments_undated` 1 (Laura Vélez), `commitments_rescheduled` 0. El conflicto de fecha de Paula no lo detecta el cálculo; se declara aquí.

Después: nada reprogramado tres veces, así que no hay decisión que subir al comité. La ficha no cambió, así que `/pm-publish` no hace falta. Perseguir las fechas de Paula y Laura es del gerente.
