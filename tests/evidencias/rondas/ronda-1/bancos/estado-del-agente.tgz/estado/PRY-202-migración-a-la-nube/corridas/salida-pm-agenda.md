Términos: ya aceptados en la configuración (v1.0, José Francisco Ñáñez, 2026-10-14), igual a la versión de TERMS.md. Sesión sin interfaz: no se hicieron preguntas; se tomó la fecha sugerida (comité semanal, 2026-10-20) y 30 minutos como tope.

## Reunión de seguimiento — Migración a la nube (PRY-202) · 2026-10-20
3 puntos · 20 minutos · 4 personas requeridas (Sandra Gil, Paula Céspedes, Laura Vélez, Óscar Ramírez)

Base de la agenda: es la primera corrida (no hay snapshot previo, así que `diff` no tiene con qué comparar). Se armó con la minuta del 2026-10-13 y la ficha. Nada reprogramado tres veces, nada vencido sin evidencia, ninguna decisión que haya quedado pendiente de la reunión anterior.

### Lo que no se destraba solo
Nada reprogramado ni vencido. La reunión es de seguimiento: los tres puntos son compromisos dichos el 13/10 que hoy no están bien definidos, y se arreglan con quien los dijo en la sala.

> **[1] Que quede una sola fecha para «entregar el punto 3», y qué fue lo que «no alcanzó»** · 8 min · **Paula Céspedes**
> Dos fechas el mismo día: 2026-10-28 (notas) y 2026-11-02 (acta del comité). Las notas dicen que «no alcanzó», lo que sugiere una promesa anterior que no está en ningún documento leído; si existe, esta ya sería la segunda fecha.
> Fuente: `2026-10-13-notas-reunion.txt` l. 4; `30-reuniones/2026-10-13-comite-semanal.docx`, ambos 2026-10-13.
> **Si no se resuelve hoy:** el compromiso queda con dos fechas, no se puede medir como vencido, y si hubo una promesa anterior se pierde el historial de reprogramaciones.

> **[2] Que la revisión con el proveedor tenga un responsable y un día hábil, y que el riesgo de «equipo incompleto» tenga doliente** · 8 min · **Óscar Ramírez** (y Sandra Gil para asignar el riesgo)
> El 2026-10-24 es sábado, y las notas no aclaran si Óscar se compromete a hacer la revisión o solo anota la fecha de una cita. Aparte: «el proveedor podría no llegar con el equipo completo para la siguiente fase» se comentó y nadie lo registró; está en la ficha sin probabilidad, impacto ni doliente. El informe del 2026-10-09 lista otros dos riesgos, no este.
> Fuente: notas 2026-10-13, l. 6 y 7; informe de avance 2026-10-09.
> **Si no se resuelve hoy:** la revisión del 24/10 puede no ocurrir y el riesgo seguiría sin dueño.

> **[3] Fecha del ajuste de presupuesto** · 4 min · **Laura Vélez**
> «La otra semana», relativo al 13/10: no fija un día. Sin fecha no puede estar vencido, y por eso no aparece en ninguna alerta de atraso.
> Fuente: notas 2026-10-13, l. 5.
> **Si no se resuelve hoy:** el compromiso sigue sin poder vencerse.

### Vencido sin evidencia
Ninguno.

### Se decide hoy o se atrasa
Ninguno. Las notas del 13/10 no registran decisiones ni temas pendientes de decidir.

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Óscar Ramírez | Revisión con el proveedor | 2026-10-24 (sábado) — después del 20/10, antes de una reunión posterior; está en el punto 2 |

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| El cierre del proyecto en el acta de constitución es el 2026-10-16, y los compromisos de la reunión llegan hasta el 28/10 o el 02/11. No hay documento de replanificación. | Mover la fecha de cierre cambia la línea base; excede la autoridad del gerente. Es observación de la corrida, no se dijo en la reunión. | `/pm-escalate` para formularlo como decisión; sube al comité y al patrocinador (Camilo Beltrán). Si él asiste el 20/10, pasa a «se decide hoy». |
| Rubén Cárdenas asistió el 13/10 y no tiene compromisos ni intervención | No hay nada que le toque en esta agenda; no se convoca por ella | — |

### Fecha de la reunión: dato en conflicto
La configuración dice comité semanal, próximo 2026-10-20; las notas del 13/10 dicen «próxima reunión en dos semanas» (≈ 2026-10-27). Se armó para el 20/10. Si es el 27/10, el cierre pasó hace 11 días y el punto de la fecha de cierre pesa más.

### Anexo — sin cambios desde la última reunión
No se puede armar: es la primera corrida y no hay snapshot anterior contra el cual decir qué siguió igual. Lo que sí se sabe sin cambio: ningún compromiso se cerró desde el 13/10 (no hay documento que lo cierre).

---
Convocar a la reunión es del gerente. Después de la reunión: `/pm-minutes` sobre las notas o transcripción.
