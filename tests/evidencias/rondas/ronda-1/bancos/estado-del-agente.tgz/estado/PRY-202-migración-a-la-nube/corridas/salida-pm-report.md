Términos: constan aceptados (v1.0, 2026-10-14, José Francisco Ñáñez); coincide con la versión de TERMS.md.
Declaración: sesión sin interfaz y este comando no propone estado, así que no hay respuesta sugerida que tomar; la línea sale en blanco.

# PRY-202 Migración a la nube — semana del 2026-10-07 al 2026-10-14

**Declara el gerente:** SIN DECLARAR · sin avance · sin fecha (Sandra Gil no declaró en esta corrida)
**Sustento documental:** no evaluable — sin declaración no hay con qué contrastar
**Lo que el semáforo no explica:** nada que computar sin declaración. Señal abierta del cálculo: `commitment_undated` (1).

## Qué cambió esta semana
No hay corrida anterior con la que comparar: el `diff` no encontró cambios (0) porque la primera foto de estado es la de hoy (2026-10-14). Lo que sigue es el punto de partida, no un cambio.

Lo nuevo en la ficha, de la reunión del 2026-10-13:
| Qué | Estaba | Está | |
|---|---|---|---|
| Compromiso Paula Céspedes, «Entregar el punto 3» | — | abierto; acta dice 2026-11-02, notas dicen 2026-10-28 | conflicto sin resolver |
| Compromiso Laura Vélez, «Mandar el ajuste del presupuesto» | — | abierto, sin fecha («la otra semana») | sin fecha |
| Compromiso Óscar Ramírez, «Revisión con el proveedor» | — | abierto, vence 2026-10-24 | |
| Riesgo: el proveedor podría no llegar con el equipo completo | — | dicho en reunión, nadie lo registró; sin probabilidad, impacto ni dueño | |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Sin línea base | siempre (no hay en la ficha) | no medible |
| Sin hitos en la ficha | siempre | no medible |

No hay historial de corridas para contar días.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | sin dato | 2026-10-16 (acta de constitución) | no calculable |
| Presupuesto | COP 3.300.000.000 aprobado | sin dato | no calculable |

Replanificaciones: 0 registradas. Sin línea base no se puede decir que no hubo atraso: el cierre vence en 2 días y la ficha no trae hitos ni avance.

### Hitos de las próximas cuatro semanas
Sin hitos en la ficha (`plan.milestones` sin dato). Existe `10-plan/2026-02-19-cronograma-v1.csv`, que esta ficha no ha leído.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| COP 3.300.000.000 | sin dato | sin dato | sin dato | no calculable (aprobado − comprometido) |

## Abierto
**Reprogramados:** ninguno registrado.
**Vencidos sin evidencia:** ninguno.
**Sin fecha:** Laura Vélez, ajuste del presupuesto («la otra semana», dicho el 2026-10-13).
**En conflicto:** Paula Céspedes, punto 3 — 2026-11-02 (acta) contra 2026-10-28 (notas). Las notas dicen «no alcanzó», lo que sugiere una promesa anterior que no se ha visto.
**RAID sin movimiento:** ninguno; el único riesgo es del 2026-10-13.
**Proveedor:** la ficha no lo lee todavía. Hay un contrato (CT-169), dos actas de recibo (2026-05-20 licenciamiento; 2026-08-18 bolsa de horas) y una factura (2026-09-27) sin procesar. No se puede decir si hay vencidos, aceptados sin documento o facturado sin entrega.

## Lo que necesito de alguien
- **Sandra Gil:** declarar estado y avance. Es lo que falta para cerrar este informe.
- **Laura Vélez:** fecha para el ajuste del presupuesto.
- **Paula Céspedes:** confirmar cuál fecha vale, 2026-10-28 o 2026-11-02, y si hubo una promesa anterior.
- **Quien lleve el RAID:** registrar el riesgo del equipo del proveedor, con dueño.

## Lo que no se sabe
**Sin dato:** autoridad, fase, declaración, hitos, comprometido, ejecutado, proyección. Además, de 10 fuentes ninguna está marcada como evidencia.
**Silencio:** último documento hace 1 día (2026-10-13) · última reunión hace 1 día (2026-10-13). No hay silencio, pero la ficha solo leyó 3 de los 10 documentos: no leyó el informe de avance del 2026-10-09, el cronograma, el contrato, las actas de recibo ni la factura.

---
Ficha: `estado/PRY-202-migración-a-la-nube/records/PRY-202.json`, actualizada 2026-10-14 · 7 campos sin dato · Términos: TERMS.md (v1.0)
