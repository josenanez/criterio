Términos: vigentes (v1.0, aceptados por José Francisco Ñáñez el 2026-10-14, constan en la configuración). Es un borrador de trabajo: verificarlo es tuyo.

# Plan — Migración a la nube (PRY-202) · borrador del 2026-10-14
**Desde:** acta de constitución del 2026-02-19 · **Criterio de éxito:** «Migración a la nube en producción y medido» (`00-gobierno/2026-02-19-acta-constitucion.md`). Está declarado, pero no se puede medir (ver abajo).

Una advertencia antes de empezar: el acta es de febrero y el cierre comprometido es el **2026-10-16**, dentro de dos días. Esto se parece más a un replanteamiento de un proyecto ya avanzado que a un primer plan. Si ese es el caso, `/pm-plan revisar` sobre un plan existente y un control de cambios serían el camino. Aquí hago lo que pides: descomponer desde el acta.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance con contenido.** Dice «Componente 1, 2, 3» y nada más (§Alcance). | No hay entregables que descomponer. La WBS de abajo tiene tres nodos sin nombre; nadie puede aceptar «Componente 2». |
| **Fuera de alcance vacío en la práctica.** «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué. | No hay frontera. Cualquier petición posterior se puede leer como dentro o como fuera. |
| **Criterio de éxito sin métrica.** «En producción y medido»: no dice qué se mide, contra qué umbral, ni quién lo mide. | El cierre no se puede declarar ni negar. Es el vacío más caro. El informe del 2026-10-09 habla de un «umbral pactado» para la prueba de carga, pero no consta en ningún documento que vi. |
| **Autoridad no declarada.** El acta no dice qué puede decidir la gerente y qué debe subir. | No sé qué puedes decidir al planificar. Todo lo que cambie fechas o presupuesto lo marco como decisión a subir. |
| **Objetivo tautológico.** «Entregar migración a la nube para Medios de Pago». | No orienta ningún compromiso de alcance. |
| **Dependencias: «Ninguna declarada».** El informe del 09-10 menciona la dependencia del calendario de liberaciones del core y la disponibilidad del equipo de seguridad. | El plan nace con dependencias reales que el acta niega. Las dejo como supuestos. |

Patrocinador sí está: Camilo Beltrán.

## WBS
Terminal = algo que alguien recibe y acepta. Duración vacía donde no hay de dónde sacarla; **no hay ninguna duración citable** en lo que leí.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 (sin nombre en el acta) | Sin definir | Del acta (§Alcance), contenido **sin definir** | — |
| 2 | Componente 2 (sin nombre en el acta) | Sin definir | Del acta (§Alcance), contenido **sin definir** | — |
| 3 | Componente 3 (sin nombre en el acta) | Sin definir | Del acta (§Alcance), contenido **sin definir** | — |
| 4 | Migración en producción | Sin definir | Del acta (§Criterio de éxito) | — |
| 5 | Medición de la migración en producción (qué, contra qué umbral) | Sin definir | Del acta («y medido»), pero indicador y umbral **sin definir** | — |
| 6 | CT-169: Licenciamiento del motor (Redes del Norte; 298.938.555 COP; comprometido 2026-05-16; consta «recibido») | El gerente del proyecto, con acta de recibo firmada (condición de pago del contrato) | Supuesto: que forma parte del alcance (el acta no menciona el contrato). Cita: `00-gobierno/2026-02-10-contrato-ct-169.docx` | — |
| 7 | CT-169: Bolsa de horas de desarrollo (298.938.555 COP; comprometido 2026-07-31; consta «recibido») | Ídem | Supuesto, misma cita | — |
| 8 | Repetición de la prueba de carga hasta alcanzar el umbral pactado | Sin definir | Supuesto: sale del informe del 2026-10-09 («no alcanzó el umbral pactado y se repite»); el umbral no consta | — |
| 9 | Revisión final de seguridad | Sin definir | Supuesto: sale del riesgo abierto del informe del 2026-10-09 | — |
| 10 | Diseño funcional aprobado | Sin definir | Supuesto: hito del cronograma v1 (`10-plan/2026-02-19-cronograma-v1.csv`) | — |
| 11 | Ambiente de pruebas certificado | Sin definir | Supuesto: ídem | — |
| 12 | Integración con el core | Sin definir | Supuesto: ídem | — |
| 13 | Piloto con usuarios internos | Sin definir | Supuesto: ídem | — |
| 14 | Salida a producción | Sin definir | Supuesto: ídem; el informe del 09-10 dice que se reprogramó | — |

Lo que el cronograma v1 y el informe no cuadran entre sí: el cronograma marca los cinco hitos como «cerrado» (incluida la salida a producción, 2026-09-25), y el informe del 2026-10-09, en rojo con 46 % de avance, dice que la salida se reprogramó y la prueba de carga se repite. Un plan nuevo hereda esa contradicción mientras no se aclare cuál es verdad. No elegí una.

No sé qué relación hay entre los Componentes 1 a 3 y los hitos 10 a 14. No los cruzo.

## Orden
Qué necesita qué, sin fechas. Todo es supuesto, salvo lo que dice el contrato.

- Los hitos del cronograma v1 vienen en este orden: diseño funcional → ambiente de pruebas → integración con el core → piloto → salida a producción. Supuesto: que cada uno necesita al anterior; el cronograma lo ordena, no dice que dependa.
- La repetición de la prueba de carga (8) y la revisión final de seguridad (9) van antes de la salida a producción (14). Supuesto.
- La salida a producción (14) depende de una ventana de cambio de operaciones (informe 09-10) y del calendario de liberaciones del core (riesgo abierto del informe, contradice el «ninguna» del acta).
- Producción (4) antes de la medición (5), porque no se mide lo que no está en producción. Supuesto.
- Los entregables 6 y 7 del contrato constan como recibidos y no bloquean nada que yo vea.
- Ordenar los Componentes 1 a 3 entre sí: **sin definir**.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los dos entregables de CT-169 forman parte del alcance del proyecto | Si el contrato cubre otro alcance, la WBS sobra dos nodos y el presupuesto tiene otro denominador |
| Los cinco hitos del cronograma v1 son entregables del proyecto y están en el orden de dependencia | Si no lo son, los nodos 10 a 14 sobran o falta ordenar otros |
| El estado real es el del informe del 09-10 (salida reprogramada, prueba de carga se repite) y no el «cerrado» del cronograma v1 | Si el cronograma es cierto, no hay nada que replanificar; si el informe es cierto, el cronograma v1 está obsoleto y el plan parte de una base equivocada |
| La repetición de la prueba de carga y la revisión de seguridad ocurren antes de la salida | Si la salida puede ir sin ellas, el camino crítico es otro |
| La medición en producción es posterior a la salida | Si el «medido» del criterio se cumple de otro modo (p. ej. con el piloto), el cierre no depende de la producción |
| El proveedor tendrá el equipo completo para la siguiente fase | Es justo lo que se dijo que podría no pasar (ver «Sin definir» y siguiente sección). Si falla, se mueve todo lo que dependa del proveedor |

## Sin definir
No lo completé con lo razonable.

| Qué | Quién lo define |
|---|---|
| Nombre y contenido de los Componentes 1, 2 y 3 | Sin dueño en el acta. Propuesta: el patrocinador (Camilo Beltrán) con la gerente (Sandra Gil) |
| Qué queda fuera de alcance, y qué proyecto lo cubre | Ídem |
| Indicador y umbral de «medido»; quién mide | Ídem |
| El umbral pactado de la prueba de carga y dónde consta | Sin dueño. Propuesta: la gerente |
| Quién acepta cada entregable salvo los del contrato | Sin dueño |
| Qué puede decidir la gerente al planificar (autoridad) | El patrocinador / el Comité de Banca Empresas |
| Si el cronograma v1 o el informe del 09-10 describe el estado real | La gerente |
| Duración de cualquier nodo | Los equipos que lo hacen (ver preguntas) |

## Proyectos análogos
Ninguno a la vista. La configuración no apunta a una carpeta de fichas de la PMO y en el espacio de trabajo no hay fichas de otros proyectos. Es la respuesta correcta aquí: no traigo un número de analogía que no existe.

## Preguntas para el equipo
Una por cada duración vacía; es lo que llevas a la primera reunión.
1. Componente 1: ¿qué es exactamente, quién lo recibe, cuánto toma?
2. Componente 2: ídem.
3. Componente 3: ídem. (En las notas del 2026-10-13, Paula Céspedes se compromete a «entregar el punto 3» el 28/10/2026 y el acta del comité dice 2026-11-02: ¿es este componente?)
4. Migración en producción: ¿cuánto toma, una vez resuelta la prueba de carga y la ventana de cambio?
5. Medición: ¿qué se mide, contra qué umbral, durante cuánto tiempo?
6. Repetición de la prueba de carga: ¿cuánto toma preparar, correr y analizar otra vez? ¿Qué cambia para que pase?
7. Revisión final de seguridad: ¿cuánto toma, y con qué disponibilidad del equipo de seguridad?
8. Los hitos 10 a 14: ¿cuáles están realmente cerrados y cuánto falta en los que no?
9. Contrato CT-169: ¿hay más entregables o fases con Redes del Norte? Las notas del 13-10 hablan de una «siguiente fase».

## Para comprometer una fecha falta
Nada de esto está en un documento que yo haya leído.
- **Disponibilidad real del equipo**, en particular el de seguridad para la revisión final (riesgo abierto del informe 09-10).
- **La fecha del proveedor**: la revisión con Redes del Norte está fijada por Óscar Ramírez para el 2026-10-24, y en la reunión del 13-10 se comentó que el proveedor podría no llegar con el equipo completo; nadie lo registró como riesgo.
- **La ventana de cambio de operaciones** para la salida a producción, y el calendario de liberaciones del core.
- El resultado de la repetición de la prueba de carga.
- Una decisión de quién tiene autoridad: un cierre distinto del 2026-10-16 es un cambio sobre lo aprobado y se sube al comité (próximo: 2026-10-20 según la configuración).

Ninguna fecha está comprometida en este borrador. La única fecha de cierre que aparece (2026-10-16) es la del acta.

## Después
Cuando el plan se apruebe, puedo registrarlo como **línea base original** y pasar los supuestos al RAID con doliente. Lo registrado hoy no está en el RAID: el riesgo del proveedor sigue sin dueño, probabilidad ni impacto. No lo hice porque no hay plan aprobado.
