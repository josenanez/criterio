Antes de escribir (recalculé con `compute`, corte 2026-10-14): la ficha lleva 10 campos con dato, 7 sin decir en ninguna parte (identity.authority, identity.phase, declared, plan.milestones, money.committed, money.executed, money.projection) y además identity.product no está en la ficha. El estado del proyecto **no está declarado**: no hay `declared.status` ni `declared.as_of`, así que la PMO lo verá vacío. Hay 1 conflicto abierto (fecha del compromiso de Paula Céspedes: 2026-11-02 en el acta, 2026-10-28 en las notas).

Publiqué la ficha en `/home/claude/banco/ronda-1/bancos/espacio/documentos/proyectos/PRY-202-migración-a-la-nube/00-gobierno/ficha-pm.json`, con corte al 2026-10-14.

**Lleva:** 10 campos con dato · 7 sin decir en ninguna parte · declara **nada** (sin estado declarado)

**Lo más viejo que va ahí:** identity/plan/money (todo sale del acta de constitución), del 2026-02-19 — unos ocho meses, no pasa de un año.

Notas de la prueba: términos 1.0 ya aceptados en la configuración (José Francisco Ñáñez, 2026-10-14); la carpeta de gobierno ya existía, no se creó nada. Es una copia tal cual de `records/PRY-202.json`; la ficha sigue sin sellar (`sealed: false`).
