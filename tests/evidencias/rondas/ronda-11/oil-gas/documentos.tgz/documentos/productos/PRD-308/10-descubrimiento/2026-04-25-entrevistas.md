# Entrevistas · Servicios de perforación

**Ronda:** Ronda · 2026-04-25
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-04-25

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
