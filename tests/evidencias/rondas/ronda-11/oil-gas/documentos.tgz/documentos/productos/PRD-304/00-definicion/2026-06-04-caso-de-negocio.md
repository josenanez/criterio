# Caso de negocio · Energía solar en campo

**Código:** PRD-304
**Fecha:** 2026-06-04
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 194.910 | Caso de negocio, 2026-06-04 |

## Retorno esperado

Retorno esperado en 24 meses.
