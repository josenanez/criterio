# Definición de producto · Energía solar en campo

**Código:** PRD-304
**Gerente de producto:** Jorge Medina
**Segmento:** Distribuidoras de gas
**Fecha de la definición:** 2026-06-04

## El problema

El segmento Distribuidoras de gas no tiene energía solar en campo.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-09-25 · verificado con el concepto jurídico de cumplimiento del 2026-10-07 (anexo «Verificación del supuesto» del 2026-10-07)

## Proyectos que lo construyen

- Ninguno declarado
