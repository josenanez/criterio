# Definición de producto · Servicios de perforación

**Código:** PRD-308
**Gerente de producto:** Natalia Ospina
**Segmento:** Industria
**Fecha de la definición:** 2026-03-04

## El problema

El segmento Industria no tiene servicios de perforación.

## La propuesta

- Propuesta principal

## Supuestos

- **El yacimiento responde como dice el modelo** · declarado el 2026-04-14 · verificado con la medición del piloto del 2026-06-11 (anexo «Verificación del supuesto» del 2026-06-11)

## Proyectos que lo construyen

- Ninguno declarado
