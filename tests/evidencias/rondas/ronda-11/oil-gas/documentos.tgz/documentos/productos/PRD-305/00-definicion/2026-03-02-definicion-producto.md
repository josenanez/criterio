# Definición de producto · Análisis de fluidos

**Código:** PRD-305
**Gerente de producto:** Liliana Torres
**Segmento:** Refinerías
**Fecha de la definición:** 2026-03-02

## El problema

El segmento Refinerías no tiene análisis de fluidos.

## La propuesta

- Propuesta principal

## Supuestos

- **El yacimiento responde como dice el modelo** · declarado el 2026-07-12 · verificado con el documento técnico del proveedor del 2026-09-17 (anexo «Verificación del supuesto» del 2026-09-17)

## Proyectos que lo construyen

- Ninguno declarado
