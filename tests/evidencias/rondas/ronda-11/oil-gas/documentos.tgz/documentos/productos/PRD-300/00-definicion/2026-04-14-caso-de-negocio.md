# Caso de negocio · Transporte de gas

**Código:** PRD-300
**Fecha:** 2026-04-14
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 109.993 | Caso de negocio, 2026-04-14 |

## Retorno esperado

Retorno esperado en 24 meses.
