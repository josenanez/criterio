# Caso de negocio · Tratamiento de agua de producción

**Código:** PRD-309
**Fecha:** 2026-07-24
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 102.070 | Caso de negocio, 2026-07-24 |

## Retorno esperado

Retorno esperado en 24 meses.
