# Verificación del supuesto · Venta de crudo pesado

**Fecha:** 2026-09-03

**Supuesto:** La comunidad respalda el proyecto

**Con qué se verificó:** la medición del piloto del 2026-09-03. Este anexo es esa evidencia: recoge la verificación completa y no remite a otro documento.

**Resultado:** se confirmó.
