# Comité de producto · Almacenamiento para terceros

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4301 | Requerimiento REQ-4301 | Jorge Medina | se verifica en producción | — | propuesto | 2026-07-16 | — |
| REQ-4302 | Requerimiento REQ-4302 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-24 | — |
| REQ-4303 | Requerimiento REQ-4303 | Paula Céspedes | se verifica en producción | — | propuesto | 2026-03-29 | — |
| REQ-4304 | Requerimiento REQ-4304 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-28 | — |
| REQ-4305 | Requerimiento REQ-4305 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-21 | — |
| REQ-4306 | Requerimiento REQ-4306 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-15 | — |
| REQ-4307 | Requerimiento REQ-4307 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4308 | Requerimiento REQ-4308 | sin asignar | se verifica en producción | — | propuesto | 2026-06-07 | — |
| REQ-4309 | Requerimiento REQ-4309 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4310 | Requerimiento REQ-4310 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4311 | Requerimiento REQ-4311 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-04-29 | — |
| REQ-4312 | Requerimiento REQ-4312 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4313 | Requerimiento REQ-4313 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-30 | — |
| REQ-2028 | Requerimiento REQ-2028 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-02 | — |

## Decisiones

- Se mantiene el plan
