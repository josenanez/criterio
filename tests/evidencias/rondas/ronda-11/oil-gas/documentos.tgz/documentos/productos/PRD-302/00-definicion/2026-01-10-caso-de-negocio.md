# Caso de negocio · Gas para generación

**Código:** PRD-302
**Fecha:** 2026-01-10
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 115.628 | Caso de negocio, 2026-01-10 |

## Retorno esperado

Retorno esperado en 24 meses.
