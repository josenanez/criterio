# Comité de producto · Suministro de GLP

**Fecha:** 2026-10-21
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-01 | — |
| REQ-4701 | Requerimiento REQ-4701 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-07 | — |
| REQ-4702 | Requerimiento REQ-4702 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-03 | — |
| REQ-4703 | Requerimiento REQ-4703 | Elena Duarte | se verifica en producción | — | aceptado | 2026-04-05 | — |
| REQ-4704 | Requerimiento REQ-4704 | Mauricio Pérez | — | — | propuesto | 2026-03-29 | — |
| REQ-4705 | Requerimiento REQ-4705 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-11 | — |
| REQ-4706 | Requerimiento REQ-4706 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-22 | — |
| REQ-4707 | Requerimiento REQ-4707 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-28 | — |
| REQ-4708 | Requerimiento REQ-4708 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-30 | — |
| REQ-4709 | Requerimiento REQ-4709 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-07 | — |
| REQ-4710 | Requerimiento REQ-4710 | Elena Duarte | se verifica en producción | — | aceptado | 2026-09-05 | — |
| REQ-4711 | Requerimiento REQ-4711 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-06-08 | — |
| REQ-4712 | Requerimiento REQ-4712 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-18 | — |
| REQ-4713 | Requerimiento REQ-4713 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-03-24 | — |

## Decisiones

- Se mantiene el plan
