# Tablero de métricas · Suministro de GLP

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 160.175 | 2026-10-13 |
