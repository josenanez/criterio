# Caso de negocio · Servicios de perforación

**Código:** PRD-308
**Fecha:** 2026-03-04
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 60.089 | Caso de negocio, 2026-03-04 |

## Retorno esperado

Retorno esperado en 24 meses.
