# Tablero de métricas · Gas para generación

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 98.962 | 2026-10-16 |
