# Tablero de métricas · Solicitud de dotación de campo

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 120.000 | 2026-10-16 |
