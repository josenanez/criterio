# Definición de producto · Solicitud de dotación de campo

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-24

## El problema

El segmento Personas no tiene solicitud de dotación de campo.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del crudo se sostiene** · declarado el 2026-09-02 · verificado con el documento técnico del proveedor del 2026-09-28 (anexo «Verificación del supuesto» del 2026-09-28)

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
