# Tablero de métricas · Transporte de gas

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 70.581 | 2026-10-13 |
