# Comité de producto · Venta de crudo pesado

**Fecha:** 2026-10-16
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-29 | — |
| REQ-4601 | Requerimiento REQ-4601 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4602 | Requerimiento REQ-4602 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4603 | Requerimiento REQ-4603 | Elena Duarte | se verifica en producción | — | aceptado | 2026-08-22 | — |
| REQ-4604 | Requerimiento REQ-4604 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-04-26 | — |
| REQ-4605 | Requerimiento REQ-4605 | Paula Céspedes | — | Cliente entrevistado | propuesto | 2026-05-05 | — |
| REQ-4606 | Requerimiento REQ-4606 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-31 | — |
| REQ-4607 | Requerimiento REQ-4607 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-03 | — |
| REQ-4608 | Requerimiento REQ-4608 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-07 | — |
| REQ-4609 | Requerimiento REQ-4609 | Elena Duarte | — | Cliente entrevistado | propuesto | 2026-08-03 | — |
| REQ-4610 | Requerimiento REQ-4610 | Carlos Peña | se verifica en producción | — | propuesto | 2026-04-26 | — |
| REQ-4611 | Requerimiento REQ-4611 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-18 | — |
| REQ-4612 | Requerimiento REQ-4612 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-07 | — |
| REQ-4613 | Requerimiento REQ-4613 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |

## Decisiones

- Se mantiene el plan
