# Tablero de métricas · Servicios de perforación

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 42.692 | 2026-10-08 |
