# Comité de producto · Gas para generación

**Fecha:** 2026-10-21
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4201 | Requerimiento REQ-4201 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-05-03 | — |
| REQ-4202 | Requerimiento REQ-4202 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-29 | — |
| REQ-4203 | Requerimiento REQ-4203 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-02 | — |
| REQ-4204 | Requerimiento REQ-4204 | sin asignar | — | — | aceptado | 2026-03-30 | — |
| REQ-4205 | Requerimiento REQ-4205 | Liliana Torres | se verifica en producción | — | aceptado | 2026-07-31 | — |
| REQ-4206 | Requerimiento REQ-4206 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4207 | Requerimiento REQ-4207 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-06-28 | — |
| REQ-4208 | Requerimiento REQ-4208 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-16 | — |
| REQ-4209 | Requerimiento REQ-4209 | Laura Vélez | se verifica en producción | — | aceptado | 2026-07-30 | — |
| REQ-4210 | Requerimiento REQ-4210 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-10 | — |
| REQ-4211 | Requerimiento REQ-4211 | Rubén Cárdenas | — | Cliente entrevistado | propuesto | 2026-08-09 | — |
| REQ-4212 | Requerimiento REQ-4212 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-06 | — |
| REQ-4213 | Requerimiento REQ-4213 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4214 | Requerimiento REQ-4214 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-07-29 | — |
| REQ-4215 | Requerimiento REQ-4215 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-04-11 | — |
| REQ-2030 | Requerimiento REQ-2030 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-05 | — |
| REQ-2038 | Requerimiento REQ-2038 | Carlos Peña | — | — | aceptado | 2026-10-14 | — |

## Decisiones

- Se mantiene el plan
