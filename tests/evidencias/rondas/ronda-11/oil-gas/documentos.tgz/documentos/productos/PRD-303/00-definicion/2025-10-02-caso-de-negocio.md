# Caso de negocio · Almacenamiento para terceros

**Código:** PRD-303
**Fecha:** 2025-10-02
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 293.928 | Caso de negocio, 2025-10-02 |

## Retorno esperado

Retorno esperado en 24 meses.
