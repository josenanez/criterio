# Tablero de métricas · Energía solar en campo

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 171.354 | 2026-10-07 |
