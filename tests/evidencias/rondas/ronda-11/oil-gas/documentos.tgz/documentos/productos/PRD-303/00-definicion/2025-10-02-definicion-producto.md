# Definición de producto · Almacenamiento para terceros

**Código:** PRD-303
**Gerente de producto:** Gustavo Neira
**Segmento:** Distribuidoras de gas
**Fecha de la definición:** 2025-10-02

## El problema

El segmento Distribuidoras de gas no tiene almacenamiento para terceros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-06-23 · verificado con el concepto jurídico de cumplimiento del 2026-08-05 (anexo «Verificación del supuesto» del 2026-08-05)

## Proyectos que lo construyen

- Ninguno declarado
