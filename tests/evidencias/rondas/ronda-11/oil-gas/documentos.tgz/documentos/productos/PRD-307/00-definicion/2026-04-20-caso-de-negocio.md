# Caso de negocio · Suministro de GLP

**Código:** PRD-307
**Fecha:** 2026-04-20
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 243.712 | Caso de negocio, 2026-04-20 |

## Retorno esperado

Retorno esperado en 24 meses.
