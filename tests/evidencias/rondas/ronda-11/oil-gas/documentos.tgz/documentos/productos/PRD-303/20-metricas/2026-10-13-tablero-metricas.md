# Tablero de métricas · Almacenamiento para terceros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 195.143 | 2026-10-13 |
