# Definición de producto · Suministro de GLP

**Código:** PRD-307
**Gerente de producto:** Camilo Beltrán
**Segmento:** Distribuidoras de gas
**Fecha de la definición:** 2026-04-20

## El problema

El segmento Distribuidoras de gas no tiene suministro de glp.

## La propuesta

- Propuesta principal

## Supuestos

- **La comunidad respalda el proyecto** · declarado el 2026-09-15 · verificado con el concepto jurídico de cumplimiento del 2026-09-19 (anexo «Verificación del supuesto» del 2026-09-19)

## Proyectos que lo construyen

- Ninguno declarado
