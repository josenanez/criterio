# Entrevistas · Transporte de gas

**Ronda:** Ronda · 2026-01-15
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-01-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
