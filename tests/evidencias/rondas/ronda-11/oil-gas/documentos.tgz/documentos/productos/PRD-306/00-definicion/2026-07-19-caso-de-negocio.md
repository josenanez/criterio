# Caso de negocio · Venta de crudo pesado

**Código:** PRD-306
**Fecha:** 2026-07-19
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 150.962 | Caso de negocio, 2026-07-19 |

## Retorno esperado

Retorno esperado en 24 meses.
