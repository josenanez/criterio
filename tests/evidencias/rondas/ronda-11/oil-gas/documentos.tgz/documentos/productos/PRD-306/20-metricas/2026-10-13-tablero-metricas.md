# Tablero de métricas · Venta de crudo pesado

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 134.129 | 2026-10-13 |
