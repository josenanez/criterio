# Acta de recibo · Pozos perforados

**Proyecto:** PRY-206 · Planta de tratamiento de crudo
**Fecha de recibo:** 2026-10-12
**Recibido por:** Elena Duarte

Se recibe a satisfacción el entregable **Pozos perforados**.
