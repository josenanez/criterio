# Comité de Inversiones · Adecuación del casino del campamento

**Fecha:** 2026-10-18
**Asistentes:** Andrés Lozano, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Presentar el cierre de la fase | 2026-11-11 |
