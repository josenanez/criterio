# Acta de recibo · Actualizar la matriz 6

**Proyecto:** PRY-200 · Campaña de perforación del bloque sur
**Fecha de recibo:** 2026-10-01
**Recibido por:** Carlos Peña

Se recibe a satisfacción: **Actualizar la matriz 6**, compromiso de Jorge Medina.
