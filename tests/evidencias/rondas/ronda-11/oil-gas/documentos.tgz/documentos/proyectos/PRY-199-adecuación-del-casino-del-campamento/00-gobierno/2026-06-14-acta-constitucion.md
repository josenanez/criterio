# Acta de constitución · Adecuación del casino del campamento

**Código:** PRY-199
**Área dueña:** Exploración
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Inversiones
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-14

## Objetivo del negocio

Entregar adecuación del casino del campamento para Exploración.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Inversiones el 2026-06-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-24 |
| Cierre | 2027-12-21 |

## Criterio de éxito

Adecuación del casino del campamento en producción y medido.

## Dependencias declaradas

- Ninguna declarada
