# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-09-10
**Asistentes:** Carlos Peña, Javier Hoyos, Jorge Medina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-09-30 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-09-15 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Validar el ambiente 4 | 2026-09-16 |
