# Comité de Integridad · Gasoducto de interconexión

**Fecha:** 2026-10-21
**Asistentes:** Natalia Ospina, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 24 | 2026-10-05 |
