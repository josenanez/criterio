# Acta de recibo · Pozos perforados

**Proyecto:** PRY-200 · Campaña de perforación del bloque sur
**Fecha de recibo:** 2026-10-22
**Recibido por:** Carlos Peña

Se recibe a satisfacción el entregable **Pozos perforados**.
