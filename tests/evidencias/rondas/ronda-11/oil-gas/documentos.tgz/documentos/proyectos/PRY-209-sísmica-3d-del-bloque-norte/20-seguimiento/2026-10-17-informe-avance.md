# Informe de avance · Sísmica 3D del bloque norte

**Código:** PRY-209
**Fecha de corte:** 2026-10-17
**Gerente:** Paula Céspedes

## Estado declarado

**Rojo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en espacios confinados
- La prueba hidrostática no alcanzó la presión pactada y se repite
- Se ajustó el plan de perforación con la geología del pozo vecino

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 607.798.319 |
| Ejecutado | 576.632.473 |
| Proyección al cierre | 1.252.338.485 |

## Riesgos abiertos

- Precio del crudo por debajo del supuesto del caso de negocio
- Bloqueos de la comunidad en la vía de acceso
