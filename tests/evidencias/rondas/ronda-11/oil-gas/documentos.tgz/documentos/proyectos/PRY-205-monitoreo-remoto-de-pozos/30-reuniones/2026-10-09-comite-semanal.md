# Comité de HSE · Monitoreo remoto de pozos

**Fecha:** 2026-10-09
**Asistentes:** Gustavo Neira, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 18 | 2026-11-11 |
