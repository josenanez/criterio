# Acta de constitución · Gasoducto de interconexión

**Código:** PRY-202
**Área dueña:** HSE
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Integridad
**Producto asociado:** transporte de gas
**Fecha de aprobación:** 2025-09-14

## Objetivo del negocio

Entregar gasoducto de interconexión para HSE.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Integridad el 2025-09-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-24 |
| Cierre | 2026-06-05 |

## Criterio de éxito

Gasoducto de interconexión en producción y medido.

## Dependencias declaradas

- Ninguna declarada
