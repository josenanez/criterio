# Acta de recibo · Pozos perforados

**Proyecto:** PRY-208 · Reducción de quema de gas
**Fecha de recibo:** 2026-10-15
**Recibido por:** Liliana Torres

Se recibe a satisfacción el entregable **Pozos perforados**.
