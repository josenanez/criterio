# Informe de avance · Gasoducto de interconexión

**Código:** PRY-202
**Fecha de corte:** 2026-10-17
**Gerente:** Natalia Ospina

## Estado declarado

**Amarillo**

Avance reportado: **75%**

## Lo que pasó en el periodo

- Se reprogramó la movilización del taladro por disponibilidad del contratista
- El equipo perdió dos semanas por rotación del supervisor de campo
- Se acordó con integridad cómo se inspeccionan las soldaduras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.240.656.534 |
| Ejecutado | 1.691.183.267 |
| Proyección al cierre | 4.804.009.661 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Precio del crudo por debajo del supuesto del caso de negocio
