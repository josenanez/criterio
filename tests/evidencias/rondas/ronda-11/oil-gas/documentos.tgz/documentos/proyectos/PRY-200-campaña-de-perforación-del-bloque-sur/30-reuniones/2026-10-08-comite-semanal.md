# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-10-08
**Asistentes:** Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Natalia Ospina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-12-18 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-20 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-25 |
| Camilo Beltrán | Entregar el punto 8 | por definir |
| María Restrepo | Enviar el documento 9 | 2026-10-21 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-15 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-05 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 |
| Rubén Cárdenas | Entregar el punto 16 | por definir |
| Laura Vélez | Enviar el documento 17 | por definir |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-22 |
| Rubén Cárdenas | Revisar el anexo 19 | por definir |
| Laura Vélez | Validar el ambiente 20 | 2026-10-21 |

## Cerrados en esta reunión

- Revisar el anexo 11 (María Restrepo): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- Liliana Torres dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Mauricio Pérez dice que ya entregó «confirmar la fecha 15». No se presentó acta.
