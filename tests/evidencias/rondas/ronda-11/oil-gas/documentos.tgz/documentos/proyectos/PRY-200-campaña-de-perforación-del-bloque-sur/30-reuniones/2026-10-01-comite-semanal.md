# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-10-01
**Asistentes:** Camilo Beltrán, Carlos Peña, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-29 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-02 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-04 |
| Camilo Beltrán | Entregar el punto 8 | por definir |
| María Restrepo | Enviar el documento 9 | 2026-10-21 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-31 |
| María Restrepo | Revisar el anexo 11 | 2026-11-06 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-15 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-05 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-27 |
| Rubén Cárdenas | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Jorge Medina): recibido, acta de recibo del 2026-10-01.

## Lo que se dijo

- Felipe Arango dice que ya entregó «aprobar el diseño 5». No se presentó acta.
