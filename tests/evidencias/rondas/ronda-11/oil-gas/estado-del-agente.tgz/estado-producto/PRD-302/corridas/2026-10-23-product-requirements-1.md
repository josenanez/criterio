# Corrida del 2026-10-23 · product-requirements

PRD-302 · 18 requerimientos · 43 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `requirement_accepted_without_evidence` | 7 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

7 aceptados sin evidencia, 4 sin criterio, 1 sin doliente (REQ-4204), 2 propuestos sin decidir (REQ-4202, REQ-4211); traza no confirmada: no hay fichas de proyecto

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Registro — Gas para generación (PRD-302) · al 2026-10-23
18 requerimientos · 16 decididos · 56,2 % con evidencia · 0 % con proyecto que lo ejecute (no hay carpeta de fichas de proyecto; la traza no se pudo confirmar)

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió (7 de 16 decididos).
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2038 | Requerimiento REQ-2038 (el acta no dice más) | aceptado | Carlos Peña |
| REQ-4203 | Requerimiento REQ-4203 (el acta no dice más) | aceptado | Elena Duarte |
| REQ-4204 | Requerimiento REQ-4204 (el acta no dice más) | aceptado | — (sin doliente) |
| REQ-4205 | Requerimiento REQ-4205 (el acta no dice más) | aceptado | Liliana Torres |
| REQ-4207 | Requerimiento REQ-4207 (el acta no dice más) | aceptado | Ricardo Salas |
| REQ-4209 | Requerimiento REQ-4209 (el acta no dice más) | aceptado | Laura Vélez |
| REQ-4215 | Requerimiento REQ-4215 (el acta no dice más) | aceptado | Paula Céspedes |

### Decidido y nadie lo está construyendo
Los 16 aceptados carecen de proyecto que los ejecute. Hay que leerlo con cautela: no existe carpeta de fichas de proyecto, así que el vacío es «sin traza confirmada», no «confirmado que nadie construye».
| REQ | Decidido el |
|---|---|
| REQ-4204 | 2026-03-30 |
| REQ-4201 | 2026-05-03 |
| REQ-4206 | 2026-04-17 |
| REQ-4215 | 2026-04-11 |
| REQ-4213 | 2026-04-21 |
| REQ-4200 | 2026-05-27 |
| REQ-4203 | 2026-06-02 |
| REQ-4207 | 2026-06-28 |
| REQ-4210 | 2026-07-10 |
| REQ-4208 | 2026-07-16 |
| REQ-4214 | 2026-07-29 |
| REQ-4209 | 2026-07-30 |
| REQ-4205 | 2026-07-31 |
| REQ-4212 | 2026-09-06 |
| REQ-2038 | 2026-10-14 |
| REQ-2030 | 2026-10-05 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4204 | Requerimiento REQ-4204 (el acta no dice más) | Doliente no encontrado en el acta del 2026-10-21 |

### Sin criterio de aceptación
Solo los decididos (4).
| REQ | Título | Estado |
|---|---|---|
| REQ-2038 | Requerimiento REQ-2038 | aceptado |
| REQ-4201 | Requerimiento REQ-4201 | aceptado |
| REQ-4204 | Requerimiento REQ-4204 | aceptado |
| REQ-4214 | Requerimiento REQ-4214 | aceptado |

(REQ-4211 también carece de criterio, pero está propuesto: no se le exige.)

### Decidido sin documento que lo respalde
Ninguno: los 16 decididos citan un documento de decisión. Una observación: en ninguno consta **quién** decidió (el campo está vacío en el registro), aunque la autoridad configurada es el Comité de producto.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4202 | Requerimiento REQ-4202 (el acta no dice más) | 116 días (desde 2026-06-29) | Comité de producto (doliente: Rubén Cárdenas) |
| REQ-4211 | Requerimiento REQ-4211 (el acta no dice más) | 75 días (desde 2026-08-09) | Comité de producto (doliente: Rubén Cárdenas) |

Se propone decidirlos (aceptar o descartar), no cerrarlos por viejos.

### Evidencia vieja
Ninguna. Lo más nuevo que sostiene los requerimientos es del 2026-05-20, con un umbral de 12 meses.

### Fuera del registro, pero a la vista
- Supuesto «La comunidad respalda el proyecto»: sin verificar hace 124 días (umbral 30).
- Caso de negocio: volumen mensual declarado 115.628 contra 98.962 medido (2026-10-16), brecha de 14,4 %; está bajo el umbral de 20 %, así que no es hallazgo.
- La definición no declara criterio de éxito.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 16 | 0 | 0 | 0 |
