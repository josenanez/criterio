# Corrida del 2026-10-23 · product-trace

PRD-302 · 18 requerimientos · 29 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `requirement_accepted_without_evidence` | 7 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

16 requerimientos decididos sin proyecto; PRY-208 declara «gas para generación» y ningún REQ lo nombra

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Gas para generación (PRD-302) · al 2026-10-23
18 registrados · 16 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Se cruzó contra las 13 fichas de `estado/records` (PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Los 16 requerimientos aceptados (señal `requirement_untraced`): ninguno nombra un proyecto. El acta del comité del 2026-10-21 trae «—» en la columna «Proyecto que lo ejecuta» para todos. El acta no dice quién decidió cada uno (campo «quién» sin encontrar); «Decidido el» es la fecha desde la que figuran como aceptados.

| REQ | Doliente | Decidido el | Días | Nota |
|---|---|---|---|---|
| REQ-4204 | sin asignar | 2026-03-30 | 207 | además sin doliente, sin criterio de aceptación y sin evidencia |
| REQ-4215 | Paula Céspedes | 2026-04-11 | 195 | sin evidencia de demanda |
| REQ-4206 | Jorge Medina | 2026-04-17 | 189 | |
| REQ-4213 | Ricardo Salas | 2026-04-21 | 185 | |
| REQ-4201 | Camilo Beltrán | 2026-05-03 | 173 | sin criterio de aceptación |
| REQ-4200 | Mauricio Pérez | 2026-05-27 | 149 | |
| REQ-4203 | Elena Duarte | 2026-06-02 | 143 | sin evidencia de demanda |
| REQ-4207 | Ricardo Salas | 2026-06-28 | 117 | sin evidencia de demanda |
| REQ-4210 | Gustavo Neira | 2026-07-10 | 105 | |
| REQ-4208 | Ricardo Salas | 2026-07-16 | 99 | |
| REQ-4214 | Natalia Ospina | 2026-07-29 | 86 | sin criterio de aceptación |
| REQ-4209 | Laura Vélez | 2026-07-30 | 85 | sin evidencia de demanda |
| REQ-4205 | Liliana Torres | 2026-07-31 | 84 | sin evidencia de demanda |
| REQ-4212 | Sandra Gil | 2026-09-06 | 47 | |
| REQ-2030 | Carlos Peña | 2026-10-05 | 18 | |
| REQ-2038 | Carlos Peña | 2026-10-14 | 9 | sin criterio de aceptación y sin evidencia |

Fuera de esta lista, REQ-4202 y REQ-4211 siguen en «propuesto» (116 y 75 días): no están decididos, así que no son esta brecha sino la de «sin decidir».

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar, porque ningún REQ dice qué proyecto lo ejecuta (`trace_not_confirmed` no se emitió).

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-208 Reducción de quema de gas | Producto «gas para generación» (acta de constitución 2025-06-23, `PRY-208-reducción-de-quema-de-gas/00-gobierno/2025-06-23-acta-constitucion.docx`) | Sí: ninguno de los 18 REQ lo nombra |

El nombre coincide con el del producto, pero la ficha no trae el código PRD-302, así que es una coincidencia por nombre. Hay que ir a ver si PRY-208 es en realidad un proyecto de este producto. Si lo es, alguien está construyendo algo que no está en el registro. Si no lo es, el desacuerdo es de nombres entre las dos fichas. No se decide desde aquí.

### La cadena completa
Ningún eslabón llega al proyecto. La cadena de los 16 es REQ → decisión del comité (2026-10-21) → proyecto: **roto en el tercer eslabón**. Sin proyecto no hay entregables que citar. Los 16 quedan sin confirmar contra ficha.

### Sin fichas a la vista
Hay 13 fichas, pero ninguna se confirma contra un REQ. Las otras fichas que traen producto declarado son PRY-199 (PRD-299), PRY-202 («transporte de gas») y PRY-205 («monitoreo de pozos»), y apuntan a otros productos. Diez fichas no dicen qué producto ejecutan, y eso es un hallazgo del lado del proyecto: PRY-200, 201, 203, 204, 206, 207, 209, 210, 211. Cualquiera de ellas podría estar construyendo algo de este producto y no se puede saber.
