## Listo — Gas para generación (PRD-302)

**Respuestas por defecto (sin interfaz):** carpeta raíz = el argumento `documentos/productos/PRD-302`; quién eres = Diana Molina, gerente de producto (la definición y el caso de negocio); quién decide = «Comité de producto» (propuesta por defecto: ningún documento dice quién decide, y el único asistente al comité del 2026-10-21 fue Diana Molina); estado en `estado-producto/PRD-302`, hermana de la documentación; no dejé la marca `_CRITERIO_PRODUCTO.txt` en la carpeta (no escribo en tus documentos sin un sí claro).

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, `.docx`, 2026-05-20) · la definición y el caso de negocio del 2026-01-10 · lo más reciente: el tablero del 2026-10-16 y el acta del comité del 2026-10-21. Todos los formatos se pudieron leer.

**Términos (versión 1.2 de los términos, plugin 0.8.0):** Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se prueba antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
**Aceptados** por José Francisco Ñáñez (sí dado en el argumento de la sesión de prueba) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 del .md `d1497e5f9c2847335b…` · nota: el script registró la fecha 2026-10-23 (la del reloj de la sesión), no la 2026-10-22 del argumento.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Industria no tiene gas para generación» | Una sola frase de un «Cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo» (no dice que sea de Industria ni de qué volumen). Sostenida débilmente | 2026-05-20 |
| La demanda es de 115.628 de `volumen_mensual` | El tablero mide 98.962, 14,4 % por debajo (corte 2026-10-16). Por debajo del umbral de 20 %: imprecisión, no contradicción; pero es un solo punto, no una serie | caso 2026-01-10 · tablero 2026-10-16 |
| «La comunidad respalda el proyecto» | Un supuesto declarado el 2026-06-21, sin verificar (124 días) | 2026-06-21 |
| «Retorno esperado en 24 meses» | Nada: ni cifra de inversión ni de ingreso ni método | — |

### Lo que no está dicho en ninguna parte
- **Qué ofrece el producto:** la propuesta dice «Propuesta principal»; es un marcador sin contenido.
- **Cuándo la definición tiene éxito:** no hay criterio de éxito en ningún documento.
- **Cuántos clientes de Industria, cuáles, y cuánto gas:** una entrevista, sin nombre de cliente.
- **De dónde sale el retorno de 24 meses.**
- **Qué «plan» mantuvo el comité:** el acta dice «Se mantiene el plan» y no existe ningún plan ni proyecto declarado («Ninguno declarado»).
- **Quién decide:** el comité tuvo un solo asistente, Diana Molina, que es también quien prepara el caso de negocio.
- **Qué pide cada requerimiento:** los 18 se llaman «Requerimiento REQ-xxxx»; ningún documento dice la necesidad en palabras de quien la tiene.

### Los 18 requerimientos del acta (16 aceptados, 2 propuestos)
- **16 aceptados sin proyecto que los ejecute** (0,0 % con traza).
- **7 aceptados sin ninguna evidencia de demanda** (no dice quién los pidió): REQ-2038, 4203, 4204, 4205, 4207, 4209, 4215. Solo 9 de 18 (56,2 %) llevan evidencia, y esa evidencia es la misma entrevista, que no nombra ninguno de ellos.
- **4 aceptados sin criterio de aceptación:** REQ-2038, 4201, 4204, 4214. Los demás tienen «se verifica en producción», idéntico en todos y que no es un criterio verificable.
- **1 sin doliente:** REQ-4204 («sin asignar»), aceptado desde 2026-03-30 sin evidencia ni criterio: fallan sus tres exigencias.
- **2 propuestos sin decidir:** REQ-4202 (116 días) y REQ-4211 (75 días), sobre un umbral de 60.
- **Decisión sin quién:** el acta no dice quién aceptó cada uno.
- **Numeración:** REQ-2030 y REQ-2038 siguen otra serie (2xxx vs 4xxx) y son del mismo doliente, Carlos Peña; confirma que son de este producto.

### Supuestos sobre los que está escrita
Uno declarado: «La comunidad respalda el proyecto», fechado 2026-06-21 (cinco meses después de la definición de enero), sin verificar hace 124 días. Ninguna otra premisa está declarada, y una definición para generación de gas con «la comunidad» como único supuesto no menciona obligación normativa ni permisos.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: más entrevistas, con nombre del cliente y su volumen (hay una); la serie de `volumen_mensual` (hay un solo punto); un documento con el criterio de éxito; el acta del comité con quién decide cada requerimiento; y el plan que el comité dice mantener. No moví ni creé nada en `documentos/`.

### Después
`/product-discovery` sobre la entrevista (y las que consigas) para que los temas se vuelvan requerimientos con la cita de quién los pidió.
