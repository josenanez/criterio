## Gas para generación (PRD-302) · 2026-10-23

**Primera corrida: no hay corte anterior.** Tocó `review`; no hay señales «cruzadas desde el corte», porque todavía no hay corte. Lo que sigue es el estado del registro hoy, y queda como línea base para la próxima corrida.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 días) | REQ-4202 | 116 días (desde 2026-06-29) | Que el Comité de producto lo decida o lo descarte | Doliente: Rubén Cárdenas |
| Propuesto sin decidir | REQ-4211 | 75 días (desde 2026-08-09), sin criterio de aceptación | Lo mismo, y definir criterio de aceptación | Doliente: Rubén Cárdenas |
| Supuesto sin verificar: «La comunidad respalda el proyecto» (umbral 30 días) | — | 124 días | Evidencia de respaldo de la comunidad; si no existe, tratarlo como riesgo (assumption-tracking) | Sin dueño registrado |
| Aceptado sin doliente | REQ-4204 | Aceptado el 2026-03-30; además sin criterio de aceptación ni evidencia | Que alguien lo asuma o se revise la decisión | Comité de producto |

### Contradicción entre lo declarado y lo medido
`volumen_mensual`: el caso de negocio (2026-01-10) declara 115.628; el tablero (2026-10-16) mide 98.962. Brecha de 14,4 %, por debajo del umbral de 20 %: no es hallazgo todavía, pero se vigila.

### Aceptados con huecos
- Sin criterio de aceptación (4): REQ-2038, REQ-4201, REQ-4204, REQ-4214.
- Sin evidencia de demanda (7): REQ-2038, REQ-4203, REQ-4204, REQ-4205, REQ-4207, REQ-4209, REQ-4215.

### Las trazas
**Ninguna traza se da por confirmada**: la configuración no apunta a una carpeta de fichas de proyecto, y sin ellas no puedo decir si algún proyecto ejecuta este producto. Los 16 requerimientos aceptados figuran sin proyecto (`requirement_untraced`). Eso puede ser cierto o puede ser falta de fichas; esta corrida no distingue.

### Del descubrimiento
Sin documentos de descubrimiento nuevos que haya podido distinguir: no hay corte previo contra el cual comparar. No releí documentos.

### No sé
- Si hay fichas de proyecto que nombren este producto.
- Qué mide «éxito» para el producto: la definición no lo dice (`success` desconocido).
- Cuántas empresas del segmento Industria están afectadas: la definición no da cifra.

**Vuelvo el 2026-11-22.**
