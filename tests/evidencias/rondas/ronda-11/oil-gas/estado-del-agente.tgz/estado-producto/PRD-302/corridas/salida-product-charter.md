**Comprobación previa (REQ-4200).** Antes de redactar, esto es lo que el registro sí y no sostiene. Como nadie puede responder en esta sesión, tomo la respuesta sugerida —seguir marcando cada falta como vacío del acta, sin rellenarla— y lo dejo dicho aquí.

| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | **Cumple a medias.** Figura «aceptado» desde 2026-05-27, pero el acta del comité no dice quién lo aceptó (`decision.who` = no encontrado). La única decisión escrita es «Se mantiene el plan», que no nombra este requerimiento. | `documentos/productos/PRD-302/30-decisiones/2026-10-21-comite-producto.md` |
| Criterios de aceptación verificables | **Falta.** El único criterio es «se verifica en producción»: no dice qué se mide, con qué umbral ni quién lo verifica. | ídem |
| Evidencia de demanda con cita | **Débil.** Una entrevista del 2026-05-20 a «Cliente entrevistado» («Lo necesito y hoy no lo tengo.»). No nombra el requerimiento ni a una persona, y no dice qué es lo que se necesita. | `documentos/productos/PRD-302/10-descubrimiento/2026-05-20-entrevistas.docx` |
| Autoridad declarada en la definición | **Falta.** El acta nombra «Comité de producto» pero no dice quién decide. El único asistente es Diana Molina. Qué puede decidir el gerente del proyecto no está dicho en ninguna parte. | `documentos/productos/PRD-302/30-decisiones/2026-10-21-comite-producto.md` |
| Necesidad del requerimiento | **No encontrada.** El título es un marcador («Requerimiento REQ-4200 (el acta no dice más)»). | `estado-producto/PRD-302/requirements/REQ-4200.json` |

---

# Acta de constitución — Gas para generación · REQ-4200 · borrador del 2026-10-23
**Producto:** PRD-302 · Gas para generación · **Requerimientos:** REQ-4200

## Qué problema resuelve
«El segmento Industria no tiene gas para generación.» (`documentos/productos/PRD-302/00-definicion/2026-01-10-definicion-producto.md`, 2026-01-10).
Es el problema del **producto**. Lo que REQ-4200 en concreto resuelve **no está dicho**: su necesidad es «no encontrada» y el acta del comité solo lo llama «Requerimiento REQ-4200». La propuesta de la definición es un marcador («Propuesta principal»): no dice qué se ofrece.

## Criterio de éxito
| Criterio | Cómo se verifica | Cita |
|---|---|---|
| «se verifica en producción» | **Sin cómo.** No hay métrica, umbral, fecha ni responsable de la verificación. | comité de producto, 2026-10-21 |

La definición del producto tampoco declara criterio de éxito (`definition.success` = no encontrado). **El cierre del proyecto no se podrá juzgar contra esto.**

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 (el acta no dice más) | Entrevista 2026-05-20, «Cliente entrevistado», tema «Necesidad principal». **No nombra el requerimiento.** |

### No entra
No hay razón escrita en ningún documento para dejar fuera ninguno de los demás. Lo que sigue es el estado que muestra el comité del 2026-10-21, no una decisión de exclusión; la razón la pone quien firma.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4202, REQ-4211 | Marcadores | Siguen en «propuesto»: nadie los ha aceptado. |
| REQ-4204 | Marcador | Sin doliente y sin criterio de aceptación. |
| REQ-4201, REQ-4214, REQ-2038 | Marcadores | Sin criterio de aceptación. |
| REQ-4203, 4205, 4206, 4207, 4208, 4209, 4210, 4212, 4213, 4215, 2030 | Marcadores | Aceptados, pero el acta de este borrador no los trae. **Razón de exclusión: no está escrita.** |

Ninguno tiene proyecto asignado (columna «Proyecto que lo ejecuta» = «—» en todos).

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no hay a quién proponer con sustento. Ningún documento nombra a un candidato; asignarlo es de quien tiene la autoridad. Diana Molina es la gerente del **producto**, no del proyecto.
- **Comité:** «Comité de producto» (2026-10-21), con Diana Molina como único asistente.
- **Autoridad del gerente:** no dicha.
- **Doliente del requerimiento:** Mauricio Pérez (comité de producto, 2026-10-21).
- **Quién pidió el requerimiento:** «Cliente entrevistado» (anónimo).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| La comunidad respalda el proyecto (declarado 2026-06-21) | **No.** 124 días sin verificar al 2026-10-23; el umbral configurado es 30. | **Sin doliente.** Lo registra el gerente del proyecto al asumir la ficha, con `raid-taxonomy`. |

Observación: el supuesto lleva fecha de declaración 2026-06-21, posterior a la fecha de la definición (2026-01-10). Hay que preguntar quién lo agregó.

Contraste de cifras (no es hallazgo): el caso de negocio declara `volumen_mensual` 115.628 y el tablero del 2026-10-16 mide 98.962, una brecha del 14,4 %, por debajo del umbral de 20 %. El caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| — | — | — | **No evaluado.** La definición es un marcador y no dice qué se ofrece; no hay con qué saber qué obligaciones toca. No se hizo barrido normativo ni se opina sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4200 y cuándo | El proyecto arranca sin una decisión de la que colgarse. | Comité de producto |
| Necesidad y propuesta concretas | No se puede decir qué se construye; el alcance es un nombre. | Diana Molina, con Mauricio Pérez |
| Criterio de éxito verificable | El cierre no se podrá juzgar. | Diana Molina |
| Evidencia de demanda que nombre el requerimiento | El proyecto descansa en una frase de un cliente sin nombre. | Diana Molina |
| Patrocinador, gerente y autoridad del gerente | El proyecto escala todo o no escala nada. | Comité de producto |
| Verificación del supuesto «la comunidad respalda el proyecto» | Queda como riesgo abierto sin doliente. | A designar |
| Razón de exclusión de los demás requerimientos | La discusión del tercer mes. | Quien firma |
| Restricciones normativas | Sin evaluar. | A designar |

---
**Esto es un borrador.** Lo firma [quién decide por el Comité de producto: no está dicho]. La ficha del proyecto se crea después de la firma.

**Qué sigue.** No se creó la ficha del proyecto ni se escribió estado declarado alguno. Con el acta firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella y Alba sabrá si PRD-302 se está construyendo sin preguntarle a nadie.
