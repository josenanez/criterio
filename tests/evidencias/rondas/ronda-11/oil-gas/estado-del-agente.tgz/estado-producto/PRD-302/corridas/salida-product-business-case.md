# Caso de negocio — Gas para generación (PRD-302) · borrador del 2026-10-23
**Desde:** la definición y el caso de negocio, ambos del 2026-01-10 · **Cifras con fuente:** 2 de 2 cifras numéricas (más un plazo, «24 meses», que no trae monto) · **Costos con fuente:** 0 de 0

*Términos vigentes (v1.2, plugin 0.8.0), ya aceptados por José Francisco Ñáñez con comprobante del 2026-10-23; no se registraron de nuevo. Se pidió la fecha 2026-10-22; el comprobante lleva la del reloj de la sesión.*

**Este documento no tiene todavía lo que hace falta para evaluarse como caso de negocio: no hay ningún costo en ningún documento. Hoy es una propuesta.** Las cifras son del negocio; aquí no se proyectó ni se calculó nada.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Industria no tiene gas para generación.» (`00-definicion/2026-01-10-definicion-producto.md`, 2026-01-10). Sin magnitud.
- **Para quién:** «Industria». Sin cuántos clientes, cuáles ni cuánto gas necesitan.
- **Éxito:** no declarado en ningún documento.

## Qué se construye
La propuesta de la definición dice «Propuesta principal»: es un marcador, no dice qué se ofrece. La definición declara «Ninguno» en proyectos que lo construyen.

Registro de requerimientos (acta del comité, 2026-10-21): 18 en total, 16 aceptados y 2 propuestos (REQ-4202, REQ-4211, fuera del alcance por no estar decididos). Ninguno tiene proyecto que lo ejecute. Todos se llaman «Requerimiento REQ-xxxx»: el registro no dice qué pide cada uno.

| Requerimiento | Estado | Evidencia de demanda (quién lo pidió) |
|---|---|---|
| REQ-4200, 4201, 4206, 4208, 4210, 4212, 4213, 4214, 2030 | aceptado | «Cliente entrevistado» (sin nombre; entrevista 2026-05-20) |
| REQ-4203, 4204, 4205, 4207, 4209, 4215, 2038 | aceptado | **Nadie lo pidió según el acta** (7 de 16 aceptados) |

Además: REQ-4204 no tiene doliente («sin asignar»), y REQ-4201, 4204, 4214 y 2038 no tienen criterio de aceptación.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 115.628 | Declarada | Caso de negocio, Diana Molina | 2026-01-10 |
| volumen_mensual | 98.962 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-16-tablero-metricas.md`) | corte 2026-10-16 |
| Retorno esperado | «en 24 meses» | Declarada, **sin monto, sin base y sin método** | Caso de negocio | 2026-01-10 |

Cifras supuestas: ninguna numérica. Lo que está implícito sin declarar: que el volumen declarado corresponde a clientes de Industria, y que existe un retorno medible; ninguno de los dos está en un documento.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 115.628 | 98.962 | Caso de negocio, 2026-01-10 · tablero, corte 2026-10-16 |

La medida está 14,4 % por debajo de la declarada (16.666 unidades). No pasa el umbral de 20 % configurado, pero entra al caso porque el caso afirma un número y la serie mide otro. La serie tiene **un solo punto**: no dice hacia dónde va, y las dos fechas están separadas por nueve meses. Tampoco se sabe si las dos cifras miden lo mismo (el caso de negocio no define la unidad).

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No existe en ningún documento** | — |
| Costo de operar | No existe | — |
| Contratos, cotizaciones, costo del equipo | No hay ninguno a la vista | — |

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La comunidad respalda el proyecto» (declarado 2026-06-21, 124 días sin verificar; umbral 30) | No se sabe: no está dicho qué comunidad ni qué cuenta como respaldo, así que hoy no se puede desmentir. La fecha del supuesto es posterior a la del documento (enero). | Sin doliente. Propongo pasarlo a assumption-tracking. |
| Que el volumen de 115.628 corresponde al producto y al segmento Industria | Las cifras del caso no describen este producto | Quien produce la cifra en el negocio; no se nombra |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| **Costo de construir y de operar** | Sin él no hay caso que evaluar: hay una propuesta | Diana Molina / finanzas; no hay documento |
| Monto, base y método del «retorno en 24 meses» | Es la única afirmación de beneficio y no se puede medir ni contradecir | Diana Molina (autora del caso) |
| Qué ofrece el producto («Propuesta principal») | No hay qué costear | Diana Molina |
| Cuántos clientes de Industria, cuáles y cuánto gas | El volumen declarado no tiene demanda que lo respalde; hay una sola entrevista, sin nombre del cliente | Descubrimiento con clientes |
| Definición de volumen_mensual (unidad, qué cuenta) y serie con más de un punto | No se sabe si 115.628 y 98.962 son comparables ni la tendencia | Dueño del tablero de producto |
| País de operación | Sin país no se puede revisar lo normativo; no se miró contra ninguna norma | Diana Molina |
| Quién decide | El acta del 2026-10-21 tiene un solo asistente, quien también preparó el caso | Comité de producto |
| Qué «plan» se mantiene | El acta dice «Se mantiene el plan» y no hay plan ni proyecto declarado | Diana Molina |
| Qué pide cada requerimiento; quién pidió 7 de los 16 aceptados | El alcance del caso no se puede describir | Dolientes del registro |

## Cómo se sabrá si funcionó
**No está declarado.** Ni criterio de éxito, ni métrica, ni fecha de corte. Lo más cercano es `volumen_mensual`, que tiene medición pero ningún umbral que diga cuánto es éxito, y «retorno en 24 meses», que no tiene métrica. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno publicado a la vista: en la carpeta de estado solo existe PRD-302 (hay carpetas de documentos de PRD-299 a PRD-309, pero sin ficha publicada), así que no se pudo hacer el cruce de `/product-overlap`. Queda pendiente hasta que otros productos publiquen.

## Después
Ofrezco pasar los supuestos a assumption-tracking (el de «la comunidad» como riesgo con doliente). `/product-charter` no corresponde todavía: no hay costo, ni criterio de éxito, ni autoridad identificada.
