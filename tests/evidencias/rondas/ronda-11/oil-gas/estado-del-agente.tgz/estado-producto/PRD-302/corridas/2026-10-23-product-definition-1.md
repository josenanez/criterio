# Corrida del 2026-10-23 · product-definition

PRD-302 · 18 requerimientos · 42 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `requirement_accepted_without_evidence` | 7 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

La evidencia no contradice la definición, pero la sostiene débilmente: una entrevista, un supuesto de 124 días y ningún criterio de éxito

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Definición — Gas para generación (PRD-302) · contrastada al 2026-10-23
**Documento:** `00-definicion/2026-01-10-definicion-producto.md` (más el caso de negocio, mismo día) · **del** 2026-01-10 · 6 afirmaciones

*Términos vigentes (v1.2, plugin 0.8.0), ya aceptados por José Francisco Ñáñez con comprobante del 2026-10-23; no se registraron de nuevo. Se pidió fecha 2026-10-22; el comprobante lleva la del reloj de la sesión.*

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. La única diferencia numérica (abajo) no pasa del umbral.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa el umbral de 20 %. `volumen_mensual`: 115.628 declarado (caso de negocio, 2026-01-10) contra 98.962 medido (tablero, corte 2026-10-16) = 14,4 % por debajo. Es imprecisión, no contradicción, y es **un solo punto**, no una serie: no se puede decir hacia dónde va. |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-01-10 | No hay métrica de retorno, ni inversión, ni ingreso, ni método con qué medirla |

(`volumen_mensual` sí tiene medición, pero de un solo corte.)

### No está dicho en ninguna parte
- **Qué ofrece el producto:** la propuesta dice «Propuesta principal»; es un marcador sin contenido.
- **Cuándo la definición tiene éxito:** no hay criterio de éxito en ningún documento.
- **Cuántos clientes de Industria, cuáles y cuánto gas necesitan:** el segmento se nombra sin cifra; hay una sola entrevista y no nombra al cliente.
- **De dónde sale el retorno de 24 meses.**
- **Quién decide:** el acta del comité (2026-10-21) tuvo un solo asistente, Diana Molina, que también preparó la definición y el caso de negocio.
- **Qué «plan» se mantiene:** el acta dice «Se mantiene el plan»; no hay plan y la definición declara «Ninguno» en proyectos que lo construyen.
- **Qué pide cada uno de los 18 requerimientos:** todos se llaman «Requerimiento REQ-xxxx»; 7 aceptados no dicen quién los pidió (REQ-2038, 4203, 4204, 4205, 4207, 4209, 4215).

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La comunidad respalda el proyecto» (declarado el 2026-06-21) | 124 (umbral 30) | Decir **qué comunidad** y **qué cuenta como respaldo** (acta, carta, consulta). Hoy está escrito de una forma que no se puede desmentir, y por eso nadie lo va a verificar. Además la fecha del supuesto (junio) es posterior a la fecha del documento (enero): se agregó después sin que el documento cambiara de fecha. Candidato a riesgo con doliente (raid-taxonomy). |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Industria no tiene gas para generación» | Una entrevista a un «Cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo» | 2026-05-20 | Débil. Es lo que alguien dijo, no lo que alguien hizo; no dice que sea de Industria ni de qué volumen; es una sola voz. |
| Volumen mensual del orden de 115.628 | Tablero de producto: 98.962 | 2026-10-16 | Dato medido, pero un solo punto. Sostiene el orden de magnitud, no la tendencia. |

No hay evidencia de pago, de piloto ni de compromiso (lo más alto de la jerarquía de demand-evidence).

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| — | Nada pasa el umbral de 12 meses. La entrevista del 2026-05-20 tiene 5 meses; el tablero, 7 días. | — |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Suministro de gas para generación | No declarado en ningún documento | No identificada | — | **No tengo la norma a la vista.** Ningún documento dice el país, y la definición no roza datos personales, pagos ni retención de información, que son los temas de este barrido. Esto no es un cumplimiento: es que no se miró contra ninguna norma. Va a revisión jurídica una vez se declare el país. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. **Sin él el producto no se puede cerrar**, porque el cierre se juzga contra él meses después.
- **Problema:** dicho en una línea, sin magnitud.
- **Para quién:** «Industria», sin cuántos ni cuáles.
- **Quién decide:** nombrado como «Comité de producto», sin decisores identificados.
- **Propuesta:** hoy es un marcador.

*No se decide si la demanda alcanza ni se reescribe la definición; eso es de su autora.*

**Después:** ofrezco convertir el supuesto de «la comunidad» en un riesgo con doliente (`raid-taxonomy`). La definición no está cerrada (sin criterio de éxito ni autoridad), así que no corresponde `/product-charter` todavía.
