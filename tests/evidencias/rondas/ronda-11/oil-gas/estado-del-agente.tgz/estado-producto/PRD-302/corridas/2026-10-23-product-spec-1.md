# Corrida del 2026-10-23 · product-spec

PRD-302 · 18 requerimientos · 65 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 16 |
| `requirement_accepted_without_evidence` | 7 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador sobre 18 requerimientos (16 aceptados, 2 propuestos). No se redactó comportamiento: need en not_found en todos. 12 aceptados con criterio genérico, 4 sin criterio, 0 con proyecto, 7 sin evidencia. No sé qué obligaciones normativas aplican ni qué plan 'se mantiene'.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Borrador de trabajo, no una especificación cerrada. Lo cierra Diana Molina (gerente de producto, PRD-302) con la firma que este agente no puede dar.**

# Especificación — Gas para generación (PRD-302) · borrador del 2026-10-23

Registro de origen: `estado-producto/PRD-302/requirements/` (18 requerimientos: 16 `aceptado`, 2 `propuesto`), con corte en el acta del comité del 2026-10-21.

**Resultado en una línea:** el registro no permite redactar comportamiento. Ninguno de los 16 requerimientos aceptados tiene el problema que resuelve (`need` en `not_found`) ni título más allá de «el acta no dice más». Rellenarlo con lo razonable sería decidir por el comité, así que no se rellena.

## Qué problema resuelve

La definición dice una sola frase: «El segmento Industria no tiene gas para generación.» (`00-definicion/2026-01-10-definicion-producto.md`). La sección «La propuesta» de esa definición contiene solo «Propuesta principal»: no dice qué se propone. La definición tampoco declara proyecto alguno («Ninguno declarado»).

## Alcance

### Entra
Entran los 16 requerimientos aceptados por el comité, **solo como identificadores**, porque el registro no dice qué pide ninguno:
REQ-2030, REQ-2038, REQ-4200, REQ-4201, REQ-4203, REQ-4204, REQ-4205, REQ-4206, REQ-4207, REQ-4208, REQ-4209, REQ-4210, REQ-4212, REQ-4213, REQ-4214, REQ-4215.
Fuente: `30-decisiones/2026-10-21-comite-producto.md`.

### No entra
- **REQ-4202 y REQ-4211:** están `propuesto`. Nadie ha decidido nada sobre ellos, y especificar lo no decidido es escribir el documento dos veces.
- **Todo comportamiento, interfaz, volumen, plazo o regla de negocio:** ningún documento lo dice. Esta especificación no lo propone.
- **Diseño, estimación, costo y fecha:** no son de este comando.

## Comportamiento

**No se redacta ninguna sección.** Cada sección tendría que citar requerimientos que cubre, y los 16 tienen `need: not_found`. Una sección escrita ahora sería contenido del agente sin rastro en el registro.

## Criterios de aceptación

El único criterio que existe en el registro es «se verifica en producción». Aparece en 12 aceptados y no pasa la prueba: dos personas mirando lo construido no tienen cómo llegar a la misma respuesta, porque no dice qué se mide ni con qué umbral.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4200, 4203, 4205, 4206, 4207, 4208, 4209, 4210, 4212, 4213, 4215, 2030 | No está dicho: sin magnitud, umbral ni método | **No verificable todavía.** El único dato medido del producto es `volumen_mensual = 98.962` (tablero, corte 2026-10-16), sin unidad ni meta, y no está atado a ningún requerimiento |
| — (sin criterio) | REQ-4201, REQ-4204, REQ-4214, REQ-2038 | — | — |

Recuento: 12 aceptados con el texto genérico y 4 sin criterio, 16 en total.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La comunidad respalda el proyecto» (declarado 2026-06-21, definición de producto) | No. Lleva unos 124 días sin verificar, por encima del umbral de 30 días de la configuración | Diana Molina; el documento no nombra a otra persona |
| La entrevista del 2026-05-20 («Lo necesito y hoy no lo tengo») respalda la demanda de los requerimientos que la citan | No. La propia entrevista **no nombra ninguno** de esos requerimientos y el entrevistado figura solo como «Cliente entrevistado» | Diana Molina, con quien hizo la entrevista (no consta quién) |

Los requerimientos no declaran supuestos propios (`assumptions` vacío en los 18). Que no estén escritos no significa que no existan.

Nota de fecha: la definición está fechada 2026-01-10, pero su supuesto se declara el 2026-06-21. Alguien la editó después, sin que quede constancia de quién.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| El problema que resuelve cada requerimiento (`need`), y su título real. Faltan en los 16 aceptados | No se puede redactar comportamiento ni criterio alguno | El doliente de cada uno (ver abajo) con Diana Molina |
| Criterio de aceptación en REQ-4201, REQ-4204, REQ-4214, REQ-2038 | Aceptados sin criterio: nadie sabrá cuándo están hechos | Camilo Beltrán (4201), Natalia Ospina (4214), Carlos Peña (2038); **REQ-4204 no tiene doliente**, lo asigna Diana Molina |
| Sustituir «se verifica en producción» por un criterio medible en los otros 12 | Se construye y se discute después si quedó bien | Los dolientes: Mauricio Pérez (4200), Elena Duarte (4203), Liliana Torres (4205), Jorge Medina (4206), Ricardo Salas (4207, 4208, 4213), Laura Vélez (4209), Gustavo Neira (4210), Sandra Gil (4212), Paula Céspedes (4215), Carlos Peña (2030) |
| Quién mide, con qué fuente y desde cuándo: hoy solo hay `volumen_mensual`, sin unidad ni meta | Ningún criterio de rendimiento o cobertura puede verificarse | Diana Molina |
| Doliente de REQ-4204 | Aceptado desde el 2026-03-30 sin persona responsable | Diana Molina / Comité de producto |
| Proyecto que ejecuta cada requerimiento: los 16 aceptados dicen «—» y la definición dice «Ninguno declarado» | Aceptado sin proyecto: nadie construye lo decidido. No hay traza que confirmar | Comité de producto; Diana Molina |
| Quién decidió: ninguna decisión registra `who` (el acta solo lista a Diana Molina como asistente). El acta cierra con «Se mantiene el plan» sin decir qué plan | No hay constancia de quién aceptó, ni de qué plan se mantiene | Diana Molina |
| Casos borde (sin suministro, interrupción, cantidad no entregada, etc.) | Ningún documento define comportamiento en falla | Diana Molina con los dolientes. Este agente no los propone |
| Lo que otro equipo tiene que hacer | Ningún documento menciona dependencias con otros equipos; no hay nada acordado, ni se sabe si hace falta | Diana Molina |
| Obligaciones normativas | El barrido solo mira lo que los documentos dicen: ni la definición ni el acta mencionan datos personales, pagos, consumidor financiero ni retención. **Eso no prueba que no haya obligaciones** del sector del gas o de generación; nadie las ha revisado | Diana Molina, con quien en la organización lleve lo regulatorio (no consta quién) |
| REQ-4202 (desde 2026-06-29, unos 116 días) y REQ-4211 (desde 2026-08-09, unos 75 días) siguen en `propuesto`, sobre el umbral de 60 días sin decidir | Se quedan en limbo | Comité de producto (doliente de ambos: Rubén Cárdenas) |
| Evidencia de demanda: 7 aceptados no tienen ninguna (REQ-2038, 4203, 4204, 4205, 4207, 4209, 4215); los otros 9 comparten la misma entrevista anónima del 2026-05-20, que no nombra el requerimiento | Un aceptado exige evidencia de demanda; hoy no está sustentado | Diana Molina |

## Requerimientos aceptados que esta especificación no cubre

Ninguna sección cubre ninguno de los 16, porque ninguno dice qué pide. Entran solo como identificadores en el alcance.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-2038 | (el acta no dice más) | `need` no encontrado; sin criterio; sin evidencia; sin proyecto |
| REQ-4200 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4201 | (el acta no dice más) | `need` no encontrado; sin criterio; sin proyecto |
| REQ-4203 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin evidencia; sin proyecto |
| REQ-4204 | (el acta no dice más) | `need` no encontrado; sin criterio; sin doliente; sin evidencia; sin proyecto |
| REQ-4205 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin evidencia; sin proyecto |
| REQ-4206 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4207 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin evidencia; sin proyecto |
| REQ-4208 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4209 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin evidencia; sin proyecto |
| REQ-4210 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4212 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4213 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin proyecto |
| REQ-4214 | (el acta no dice más) | `need` no encontrado; sin criterio; sin proyecto |
| REQ-4215 | (el acta no dice más) | `need` no encontrado; criterio genérico; sin evidencia; sin proyecto |

## Después

No corresponde ofrecer `/product-charter`: la especificación tiene los vacíos abiertos y ningún requerimiento tiene criterio de éxito medible.

---
**Pie.** Sale del registro `estado-producto/PRD-302/requirements/`, con corte en el acta del comité del 2026-10-21 (borrador del 2026-10-23). Cubre 0 de 16 requerimientos aceptados en comportamiento; los 16 entran solo como identificadores. Borrador: lo cierra Diana Molina. Términos aceptados por José Francisco Ñáñez (versión 1.2, comprobante en `.criterio/terminos/`); nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
