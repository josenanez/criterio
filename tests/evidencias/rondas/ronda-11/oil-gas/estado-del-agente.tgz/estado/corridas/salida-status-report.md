Ficha aplicada: `estado/records/PRY-210.json`, actualizada el 2026-10-23. Cifras recalculadas con `portafolio.py compute` al 2026-10-23.

## PRY-210 Mantenimiento predictivo de bombas — estado al 2026-10-23

**Declara el gerente (Paula Céspedes):** verde · 49 % · al 2026-10-02 (hace 21 días). Fuente: `20-seguimiento/2026-10-02-informe-avance.pdf`
**Sustento documental:** sin sustento. Hay 0 fuentes de evidencia, 3 de declaración y 15 sin marcar.
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (4 hitos), `progress_vs_plan`, `silent`. Alerta `declared_vs_evidence`: el gerente reporta verde y esas tres señales siguen abiertas.
**Último documento:** 2026-10-02 · **Última reunión:** sin dato. No hay ninguna acta ni transcripción en la ficha.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-09-01 | 2026-09-01 | 0 días contra la original y contra la vigente |
| Presupuesto (COP) | 800.000.000 aprobado | proyección 778.806.214 | −2,6 % (por debajo de lo aprobado) |

Presupuesto: comprometido 400.319.666 (50,0 %), ejecutado 317.173.964 (39,6 %), disponible real 399.680.334.
Replanificaciones: 0. Solo existe la línea base v1, aprobada el 2025-09-23. Sin solicitudes de cambio.
La fecha de cierre (2026-09-01) pasó hace 52 días y el proyecto sigue declarando 49 %. El script no da una desviación en días, porque la fecha no se movió. La señal es el avance contra el plan, no un atraso de calendario.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2025-12-25 | 2025-12-25 | marcado «cumplido» | ninguna (302 días) |
| Licencia ambiental otorgada | 2026-03-18 | 2026-03-18 | marcado «cumplido» | ninguna (219 días) |
| Pozos perforados | 2026-06-10 | 2026-06-10 | marcado «cumplido» | ninguna (135 días) |
| Montaje de facilidades | 2026-09-01 | 2026-09-01 | marcado «cumplido» | ninguna (52 días) |

Los 4 hitos figuran como cumplidos y solo el cronograma v1 de 2025-09-23 los cita, así que ningún documento posterior los respalda. El script los marca como cumplidos sin evidencia.

### Dónde no coincide
- **Avance:** el gerente declara 49 % (2026-10-02). Con 4 de 4 hitos cumplidos, el plan sostiene 100 %. La brecha es de 51,0 puntos (`progress_vs_plan`, dirección «behind»). Lo declarado y los hitos marcados no pueden ser ciertos a la vez, y no hay documento que desempate.
- **Semáforo:** declara verde con cierre planificado vencido hace 52 días, 4 hitos sin evidencia y 21 días sin documentos.
- **Declaración vigente:** tiene 21 días, por debajo del umbral de 30, así que no está vencida (`declaration_stale` no se activó).

### Abierto
**Riesgos sin movimiento** (último movimiento 2026-10-02, 21 días; probabilidad, impacto, responsable y fecha «no declarada»):
- El proveedor no ha confirmado la fecha de la última entrega.
- Bloqueos de la comunidad en la vía de acceso.

**Incidencias** (sin responsable ni fecha de inicio):
- Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior.
- Se ajustó el plan de perforación con la geología del pozo vecino.
- La prueba hidrostática no alcanzó la presión pactada y se repite.

El informe las lista como incidencias, pero las dos primeras se leen como novedades ya resueltas. No las reclasifico sin el documento que lo diga.

**Compromisos vencidos:** ninguno. La ficha no tiene compromisos registrados, lo que no equivale a que no existan.
**Dependencias sin confirmar:** ninguna registrada. Aun así, el riesgo del proveedor apunta a una dependencia externa que no está formalizada.

### Sin dato
- Autoridad de decisión (`identity.authority`), fase (`identity.phase`) y producto (`identity.product`): no encontrados.
- Fecha de la última reunión: sin dato.
- Evidencia de cumplimiento de los 4 hitos: ninguna.
- Responsable, probabilidad, impacto y fecha de cada riesgo e incidencia: no declarados.
- Proveedores y contratos: ninguno registrado, aunque el riesgo habla de un proveedor.
- Los campos del acta de constitución (2025-09-23) tienen 13 meses, por encima del umbral de 12. Esto incluye sponsor Rubén Cárdenas, gerente, comité (Comité de HSE), alcance y presupuesto aprobado.
- Texto del informe de avance en PDF: `text_hash` nulo. Los datos de ese informe pueden requerir verificación manual.

### Después
Hay una brecha de 51,0 puntos entre avance declarado y plan, y 4 hitos sin evidencia. Puedo preparar el punto de comité (`/steering-pack`) con la pregunta cerrada de si se verifican esos hitos. No hay cambio no formalizado que justifique una solicitud de cambio.

---
**Pie:** criterio-portfolio 0.8.0 · ficha PRY-210 del 2026-10-23 (declaración del 2026-10-02) · campos inciertos: autoridad, fase, producto, última reunión, evidencia de los 4 hitos · términos v1.2 aceptados por José Francisco Ñáñez el 2026-10-23: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
