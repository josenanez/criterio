**Acta previa:** sí, una: `00-gobierno/2025-05-21-acta-constitucion.docx`, aprobada el 2025-05-21. No hay versiones posteriores ni solicitudes de cambio en la carpeta.
**Términos:** vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Criterio produce borradores de trabajo; la verificación es suya.

## Acta — PRY-201 Facilidades de producción temprana
**Estado:** existe, del 2025-05-21

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance decide Carlos Peña sin subir al comité. | Cualquier ajuste (la repetición de la prueba hidrostática, por ejemplo) no tiene a quién decidirle por defecto, así que todo cae en el Comité de Integridad. |
| Objetivo de negocio | **Describe la solución, no el resultado.** Dice "Entregar facilidades de producción temprana para Tecnología". | No hay un resultado contra el cual juzgar si el proyecto valió la pena. El informe cita un "caso de negocio" cuyo supuesto de precio del crudo está en riesgo, y ese caso no está en la carpeta. |
| Alcance | **Vacío en la práctica.** "Componente 1; Componente 2; Componente 3", sin nombres ni contenido. | No se puede decir qué está dentro y qué no. El 71 % reportado no se puede ligar a ningún entregable. |
| Exclusiones | **Sin contenido.** "Lo que otro proyecto cubre", sin nombrar ese proyecto. | El comité no puede detectar traslapes con otros proyectos del portafolio. |
| Criterio de éxito | **No es medible.** "En producción y medido" no trae métrica, umbral ni fecha. | El cierre queda a juicio de quien lo declare. |
| Quién mide el éxito | **No está.** | Quien reporta el avance es también quien podría declarar el éxito. |
| Supuestos | **No están en el acta.** El informe menciona un supuesto de precio del crudo del caso de negocio. | Un supuesto que condiciona el valor del proyecto no está registrado ni tiene responsable. |
| Restricciones | **No están.** | No hay límites declarados de plazo, regulatorios ni de acceso. El informe reporta bloqueos de la comunidad en la vía de acceso. |
| Hitos principales | **No hay.** Solo inicio (2025-05-31) y cierre (2026-04-24). | Entre inicio y cierre no hay con qué medir atraso. |
| Cadencia del comité | **No está.** | No se sabe cada cuánto debe revisarse el proyecto. |
| Dependencias | "Ninguna declarada". | Es una declaración explícita, pero no dice si se verificó. Es poco creíble en un proyecto con vía de acceso y comunidad. |
| Producto asociado | "No aplica". | Se acepta como declarado; no es vacío. |
| Patrocinador / Gerente / Comité | **Presentes:** Beatriz Cuéllar, Carlos Peña, Comité de Integridad. | Ninguna. |
| Presupuesto y fechas | **Presentes:** 1.200.000.000 COP, 2025-05-31 a 2026-04-24. | Ninguna sobre el acta. Ver el hallazgo siguiente. |

### Hallazgo que sale de contrastar acta e informe
- La fecha de cierre comprometida (2026-04-24) está casi seis meses vencida a la fecha de corte del informe (2026-10-19). El proyecto declara **verde** con 71 % de avance.
- No hay una línea base nueva ni una solicitud de cambio. La única línea base vigente es la del acta.
- Lo que no puedo decir con los documentos: si hubo una replanificación aprobada fuera de la carpeta. Si existe, no está en la evidencia.
- Presupuesto, sin juicio de desviación: ejecutado 266.640.706 (22 % de lo aprobado), comprometido 473.553.018 (39 %), proyección al cierre 1.114.843.551.
- El informe reporta que la prueba hidrostática no alcanzó la presión pactada y se repite, sin responsable ni fecha declarados.

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar facilidades de producción temprana para Tecnología" (acta, 2025-05-21), que describe la solución.
**Alcance:** "Componente 1; Componente 2; Componente 3" (acta). Sin detalle: pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (acta). Sin proyecto nombrado: pendiente de definir.
**Patrocinador:** Beatriz Cuéllar · **Gerente:** Carlos Peña (acta)
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento.
**Comité al que reporta:** Comité de Integridad (acta) · **Cadencia:** pendiente de definir
**Supuestos:** pendiente de definir. El informe de avance (2026-10-19) menciona un supuesto de precio del crudo en el caso de negocio, pero no lo detalla.
**Restricciones:** pendiente de definir.
**Criterio de éxito:** "Facilidades de producción temprana en producción y medido" (acta). Sin métrica ni umbral. · **Lo mide:** pendiente de definir
**Hitos principales:** pendiente de definir. Solo existen inicio 2025-05-31 y cierre 2026-04-24 (acta).

### Después
- **Autoridad del gerente:** el acta quedó sin autoridad declarada. Lo propio es llevar esa definición al Comité de Integridad: es una decisión, no un trámite. Propongo hacerlo en el comité del 2026-10-29. No lo he llevado a ninguna parte.
- **RAID:** de la revisión salen un supuesto (precio del crudo) y los riesgos y la incidencia que ya están en el informe, sin probabilidad, impacto ni responsable. Puedo pasarlos al registro RAID con `/raid-log`.

---
**Pie de rigor:** revisé el acta (docx) y el informe de avance (PDF), los dos únicos documentos de la carpeta de PRY-201. No vi minutas, el caso de negocio ni el contrato; lo hablado fuera de estos documentos no lo sé. No completé ningún campo con lo razonable: lo que no está queda como pendiente de definir. Cada dato se cita al documento del que sale; la verificación es suya.
