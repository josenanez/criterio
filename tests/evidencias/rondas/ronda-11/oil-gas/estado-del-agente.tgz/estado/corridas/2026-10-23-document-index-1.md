# Corrida del 2026-10-23 · document-index

13 proyectos · 9 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

66 documentos, ninguno cambió, sin citas rotas; no se produjo informe. El índice no reporta formatos ilegibles en esta corrida.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-23: 66 documentos, 66 sin cambio, 0 por releer, 0 citas rotas. No hay nada que hacer.
