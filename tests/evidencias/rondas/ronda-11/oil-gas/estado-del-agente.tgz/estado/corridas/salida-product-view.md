## Productos al 2026-10-23

Sale de las fichas en `estado/` (13 proyectos), recalculadas hoy con `portafolio.py compute`. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

**Producto pedido: «gas para generación».** Tiene un solo proyecto, PRY-208 «Reducción de quema de gas». La vista por producto no aporta nada con un solo proyecto, así que no armo sección de producto: lo que hay que ver es la lectura del proyecto, y esa vive en su ficha (`/status-report` o `/health-check` sobre PRY-208). Dato de contexto del cálculo: 7 alertas abiertas (progreso contra plan, 3 hitos «cumplidos» sin evidencia, 1 compromiso vencido, 1 entregable de proveedor atrasado y estado declarado «verde» contradicho por las anteriores). Sin dependencias internas ni con otros proyectos declaradas.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| gas para generación | PRY-208 | 7 | 2026-11-23 (PRY-208) | COP 800.000.000 (1 de 1 con la cifra) | COP 622.315.470 (1 de 1) |

Los otros tres productos del portafolio, también de un solo proyecto cada uno: PRD-299 (PRY-199, 0 alertas), «monitoreo de pozos» (PRY-205, 2), «transporte de gas» (PRY-202, 6). Tampoco merecen sección.

### Proyectos sin producto declarado
9 de 13 proyectos no declaran `identity.product`:

| Proyecto | Nombre | Área dueña |
|---|---|---|
| PRY-200 | Campaña de perforación del bloque sur | no la entrega el cálculo |
| PRY-201 | Facilidades de producción temprana | no la entrega el cálculo |
| PRY-203 | Recobro mejorado con agua | no la entrega el cálculo |
| PRY-204 | Integridad de ductos | no la entrega el cálculo |
| PRY-206 | Planta de tratamiento de crudo | no la entrega el cálculo |
| PRY-207 | Gemelo digital de la estación | no la entrega el cálculo |
| PRY-209 | Sísmica 3D del bloque norte | no la entrega el cálculo |
| PRY-210 | Mantenimiento predictivo de bombas | no la entrega el cálculo |
| PRY-211 | Estación de compresión | no la entrega el cálculo |

Consecuencia: nadie puede responder por el conjunto al que sirven, y si alguno alimenta «gas para generación» (por ejemplo PRY-211 o PRY-201, por nombre; **es una conjetura, ningún documento lo dice**), la vista de ese producto está incompleta sin que se vea. Falta el área dueña de cada uno: léela de las fichas si la necesitas.

### Lo que no sé
- Si alguno de los 9 proyectos sin producto pertenece a «gas para generación».
- El área dueña de cada proyecto sin producto (el cálculo no la trae).
- Los 13 proyectos tienen la autoridad (`identity.authority`) sin declarar.
