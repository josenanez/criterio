# Corrida del 2026-10-23 · portfolio-report

13 proyectos · 66 documentos, 0 releídos y 66 sin cambio · 31 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

El informe quedó en `reportes/index.html`.

5 proyectos en verde contradichos por la evidencia (PRY-200, 204, 205, 208, 210); sobrecosto proyectado en PRY-202 y PRY-204; PRY-210 en silencio 21 días

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-23
13 proyectos · 9 con hallazgos (54 señales) · fichas cargadas: 13, todas con fecha 2026-10-23 (frescas, no hace falta barrido previo).
Términos v1.2 vigentes (aceptados por José Francisco Ñáñez, 2026-10-23): https://www.josenanez.com/es/agents/criterio-pmo/legal

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea 2026-10-23 es el punto de partida: 0 diferencias).

## Contradicciones abiertas
Vacía: ningún campo en conflicto. Sí hay 5 proyectos declarados en verde que la evidencia contradice (ver Sin sustento).

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-209 Sísmica 3D bloque norte | Pozos perforados | 2026-10-13 | 10 |

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-210 Mantenimiento predictivo de bombas | 21 | 2026-10-02 (informe de avance) |

## Dependencias en riesgo
Sin dependencias en riesgo detectadas por el script.

## Sin sustento (verde declarado, evidencia en contra)
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 Campaña de perforación | verde (2026-10-19) | 2 hitos "cumplidos" sin evidencia, avance 16 pts por detrás, 9 compromisos vencidos, 2 reprogramados 5–6 veces |
| PRY-204 Integridad de ductos | verde (2026-10-22) | 2 hitos sin evidencia, 15 pts por detrás, sobrecosto proyectado 20,5 % |
| PRY-205 Monitoreo remoto de pozos | verde (2026-10-21) | hito "Ingeniería básica" sin evidencia (102 días) |
| PRY-208 Reducción de quema de gas | verde (2026-10-14) | 3 hitos sin evidencia, 29 pts por detrás, proveedor 291 días tarde |
| PRY-210 Mantenimiento predictivo | verde (2026-10-02) | 4 hitos sin evidencia, 51 pts por detrás, 21 días en silencio |
Además, hitos "cumplidos" sin evidencia en PRY-202, 206, 209 y 211.

## Vacíos de información
Ninguna ficha tiene autoridad aprobadora registrada (13 de 13). 9 proyectos no están asignados a un producto (PRY-200, 201, 203, 204, 206, 207, 209, 210, 211). Compromisos sin fecha en PRY-200 (3).

## Estado general
| Proyecto | Señales | Sobrecosto proy. | Desv. vs original / vigente | Replan. |
|---|---|---|---|---|
| PRY-199, 201, 203, 207 | 0 | — | 0 / 0 | 0 |
| PRY-200 | 16 | — | 0 / 0 | 0 |
| PRY-202 | 6 | +14,4 % (supera umbral 10 %) | 0 / 0 | 0 |
| PRY-204 | 4 | +20,5 % (supera umbral) | 0 / 0 | 0 |
| PRY-205, 206 | 2 | — | 0 / 0 | 0 |
| PRY-208 | 6 | — | 0 / 0 | 0 |
| PRY-209 | 4 | — | 0 / 0 | 0 |
| PRY-210 | 6 | — | 0 / 0 | 0 |
| PRY-211 | 4 | — | 0 / 0 | 0 |

## Necesito que confirmes
Este mes no se generaron los cinco campos de confirmación por el script; sin preguntas pendientes en esta corrida (prueba sin interfaz).

---
Pie: criterio-portfolio 0.8.0 · fichas aplicadas: 13, fecha 2026-10-23 · campos inciertos: ninguno en conflicto; autoridad sin registrar en 13 fichas · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
