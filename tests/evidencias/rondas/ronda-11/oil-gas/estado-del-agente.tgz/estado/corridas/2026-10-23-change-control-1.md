# Corrida del 2026-10-23 · change-control

13 proyectos · 34 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

Solicitud +30 días a PRY-205 evaluada: sin solicitante, motivo, impacto en alcance/costo ni autoridad declarada; sin dependencias declaradas, el cálculo no alcanza a otros proyectos; no sé cuántos días se mueve cada hito (sin holgura).

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Ficha de origen: `estado/records/PRY-205.json` (actualizada 2026-10-23). Términos vigentes (v0.8.0, aceptados por José Francisco Ñáñez).

## Solicitud de cambio — PRY-205 Monitoreo remoto de pozos — 2026-10-23

**Qué se pide:** mover 30 días la salida a producción: de 2027-06-08 a 2027-07-08. (Lo leo como el hito «Primer crudo o gas» y la fecha de cierre del acta; el cronograma no tiene un hito llamado «salida a producción».)
**Quién lo pide:** no consta en ningún documento.
**Por qué:** no consta. El informe del 2026-10-21 menciona dos semanas perdidas por rotación del supervisor, una prueba hidrostática que se repite y ocho días de bloqueo comunitario, pero no los liga a esta solicitud; no los uso como motivo.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, 2026-04-12) | No declarado | Sin impacto declarado |
| Tiempo | Cierre 2027-06-08 (línea base 1) | 2027-07-08 | +30 días (≈ 7,3 % de los 412 días del plan) |
| Costo | Aprobado 4.200.000.000 COP; proyección declarada 4.387.704.676 COP | No declarado | Sin impacto declarado |

**Quién absorbe lo que no se declaró:** si 30 días más no traen costo ni alcance, alguien los absorbe en horas no pagadas o en calidad. Hay un indicio: la proyección al cierre (informe 2026-10-21) ya supera el aprobado en 187.704.676 COP (+4,5 %), y esa proyección no dice si cuenta un cierre más tardío. Comprometido 2.963.246.724 COP (70,6 % del aprobado); ejecutado 2.023.878.778 COP (48,2 %) contra un avance declarado de 53 %.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`) no encuentra proyectos alcanzados, directa ni indirectamente | — |

Eso **no significa que no haya efecto**: el acta dice «Dependencias declaradas: ninguna» y la ficha no tiene dependencias. Sin dependencias declaradas, nada sale del cálculo. Sin proyectos con fecha que no se pueda sostener (`cannot_hold_date` = 0) ni dependencias sin confirmar (0).
El cambio pasa por tres hitos: Pozos perforados (2026-12-25, a 63 días), Montaje de facilidades (2027-03-18, a 146 días) y Primer crudo o gas (2027-06-08, a 228 días). **No sé cuántos días se mueve cada uno**: eso necesita holgura por actividad y la ficha no la tiene.

### Quién decide
**Autoridad requerida:** no determinable. La autoridad para aprobar cambios **no está declarada** en el acta (campo `authority` no encontrado). Ese es el hallazgo de fondo.
**Según:** el acta nombra al Comité de HSE (aprobó el presupuesto el 2026-04-12) y al patrocinador Carlos Peña, pero no dice qué cambios puede aprobar cada uno ni umbrales.
**Va a comité:** sí, por defecto. Sin autoridad declarada, no hay base para decir que el gerente (Gustavo Neira) pueda aprobarlo solo; lo prudente es llevarlo al Comité de HSE (próximo comité de la PMO: 2026-10-29).

### Si no se aprueba
El proyecto sigue con cierre 2027-06-08. Los problemas ya reportados (dos semanas perdidas, prueba hidrostática repetida, ocho días de bloqueo) siguen sin reflejarse en las fechas: hoy las cinco fechas vigentes son idénticas a las de línea base, con estado declarado «verde». Mantener la fecha implica sostenerla con el atraso ya conocido.

### Si se aprueba
Línea base 2 — cierre 2027-07-08 · presupuesto 4.200.000.000 COP (sin cambio declarado; la proyección de 4.387.704.676 COP queda por encima) · motivo: **sin motivo documentado; debe aportarlo quien solicita**. La línea base 1 (2026-04-12, cierre 2027-06-08) no se toca.
Desviación acumulada contra la línea base original: **tiempo +30 días (cierre 2027-07-08 vs 2027-06-08)** · **costo +187.704.676 COP sobre lo aprobado (+4,5 %), según la proyección declarada**. Hoy no hay replanificaciones; esta sería la primera.
Registros de cambio en la carpeta: ninguno; nada documentado autoriza hasta ahora ningún movimiento de fechas.

### Faltan para completar la solicitud
Quién la pide, el motivo, el impacto declarado en alcance y costo, la autoridad de aprobación y las dependencias reales del proyecto (el acta declara ninguna). Declararlo es de la persona; no lo inferí.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de la ficha PRY-205 y de sus documentos (acta 2026-04-12, cronograma v1, informe 2026-10-21, comité 2026-10-09); la verificación es suya. No sé lo que se haya hablado fuera de esos documentos.
