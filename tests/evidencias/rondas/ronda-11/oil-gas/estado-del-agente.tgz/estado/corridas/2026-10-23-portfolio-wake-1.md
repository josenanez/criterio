# Corrida del 2026-10-23 · portfolio-wake

13 proyectos · 21 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

Barrido: 66 documentos sin cambios, nada que recalcular. Confirmación: 5 preguntas formuladas, sin respuesta (prueba sin interfaz). No se atendieron peticiones (no tocaban). No sé si los 'verde' declarados se sostienen con documentos fuera de la carpeta.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## 2026-10-23

**Revisé:** 66 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada nuevo desde la última corrida: sin documentos cambiados no hay nada que recalcular. Lo abierto sigue siendo lo del informe de portafolio de hoy (PRY-209 hito "Pozos perforados" vencido 10 días sin evidencia; PRY-210 en silencio 21 días).

### Peticiones atendidas
Ninguna (no tocaba `requests`).

### Preguntas
Prueba sin interfaz: nadie responde; se dejan preguntadas una sola vez y sin respuesta. Una por campo, dato actual de la ficha del 2026-10-23:
1. PRY-200: estado "verde" (declarado 2026-10-19). ¿Se mantiene con 2 hitos sin evidencia y 9 compromisos vencidos?
2. PRY-204: estado "verde" (declarado 2026-10-22). ¿Se confirma con sobrecosto proyectado de 20,5 %?
3. PRY-210: estado "verde" (declarado 2026-10-02). ¿Sigue vigente tras 21 días sin documentos?
4. PRY-209: hito "Pozos perforados" (fecha 2026-10-13). ¿Se cumplió? ¿Qué documento lo sustenta?
5. Autoridad aprobadora: sin registrar en las 13 fichas. ¿Quién es, empezando por PRY-200?

**Vuelvo el 2026-10-24.**
