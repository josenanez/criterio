# Corrida del 2026-10-23 · project-closure

13 proyectos · 72 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

Cierre no sustentado: proyecto al 84% declarado en verde, criterio de éxito sin evidencia de producción ni medición, 2 de 4 hitos sin evidencia, 0 replanificaciones con fecha de cierre vencida. Dijo que no sabe: componentes del alcance, costo y fecha finales, aceptación del cliente. No se movió a archivo.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Cierre de PRY-200 · Campaña de perforación del bloque sur. Sale de la ficha `estado/records/PRY-200.json`, de la salida de `portafolio.py compute` (corte 2026-10-23) y de los documentos de `documentos/proyectos/PRY-200-campaña-de-perforación-del-bloque-sur/`. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23): no se registraron de nuevo.

## Cierre — PRY-200 Campaña de perforación del bloque sur — 2026-10-23

**Veredicto: no se puede dar por cumplido, y el proyecto no está declarado terminado.** El último informe (2026-10-19) lo reporta en **verde, con avance de 84%**. Un proyecto al 84% no está cerrado. Si se cierra hoy, es por decisión del comité, no por cumplimiento del criterio de éxito. Esa decisión no existe en ningún documento.

### Contra lo comprometido
**Criterio de éxito** (acta de constitución, 2025-10-21, `00-gobierno/2025-10-21-acta-constitucion.docx`): «Campaña de perforación del bloque sur en producción y medido».
**Se cumplió:** no se puede determinar. Ningún documento muestra producción ni medición. El criterio es además vago: no dice qué se mide, con qué umbral ni quién lo certifica.

Alcance del acta: Componente 1, Componente 2 y Componente 3. Los componentes no se describen en ningún documento, así que no se puede contrastar entregado contra comprometido por componente. La única unidad verificable son los 4 hitos del cronograma.

| Entregable comprometido (hito) | Fecha línea base | Estado | Evidencia |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-01-24 | cumplido | Acta de recibo del 2026-10-09 (`20-seguimiento/2026-10-09-acta-recibo-ingeniería-básica-aprobada.pdf`), firmada por Carlos Peña, el gerente |
| Licencia ambiental otorgada | 2026-04-19 | declarado cumplido | **Sin evidencia.** El compute lo marca como `milestone_met_without_evidence` (187 días vencido) |
| Pozos perforados | 2026-07-13 | cumplido | Acta de recibo del 2026-10-22 (`20-seguimiento/2026-10-22-acta-recibo-pozos-perforados.md`), firmada por Carlos Peña |
| Montaje de facilidades | 2026-10-06 | declarado cumplido | **Sin evidencia.** El compute lo marca como `milestone_met_without_evidence` (17 días vencido) |

Las dos actas existentes las recibe el propio gerente. Ningún documento muestra quién representa al cliente interno (Ambiental) ni al patrocinador (Paula Céspedes) aceptando.

El compute señala además `progress_vs_plan`: el cronograma tiene 4 de 4 hitos cumplidos, y el plan sostiene 100%. El informe declara 84%, es decir **16.0 puntos por debajo** de lo que el plan sostiene. El informe y el cronograma no se pueden reconciliar con lo que hay en la carpeta. O el 84% es cierto y hay hitos marcados cumplidos que no lo están, o el 84% está desactualizado.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Nada registrado | — | — |

No hay solicitudes de cambio (`changes: 0`). El acta solo dice «Lo que otro proyecto cubre» como exclusión. Un recorte de alcance no se puede descartar ni confirmar, porque los componentes nunca se describieron.

### Números finales
Los números **no son finales**: son los del informe del 2026-10-19 (declaración, no evidencia). Cifras copiadas del compute.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-10-06 | 2026-10-06 | sin dato (no hay fecha real de cierre) | Planificada: 0 días. Pero la fecha original ya pasó (17 días) y el proyecto sigue abierto |
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | sin dato | — |
| Comprometido | | | 1.025.532.379 COP (31.1% del aprobado) | |
| Ejecutado | | | 537.252.237 COP (16.3% del aprobado) | |
| Proyección al cierre | | | 3.453.463.040 COP | **+4.7% sobre lo aprobado** |

Replanificaciones: **0**. La línea base es una sola (v1, 2025-10-21). La desviación en fechas contra la original y contra la vigente es 0 días, porque nunca se replanificó. Eso no significa que el proyecto vaya a tiempo: el cierre planificado venció el 2026-10-06, no se declaró terminado, y nadie aprobó mover la fecha. Es un atraso sin línea base nueva. El umbral de desviación en costo es 10%; la proyección (+4.7%) no lo cruza. Sí es una proyección declarada por el gerente, sin respaldo de facturas ni de contrato: la ficha no tiene proveedores registrados (`vendors: []`).

### RAID al cierre
**Materializados:**
- Incidencia: «Un bloqueo de la comunidad detuvo el transporte de equipos ocho días» (informe 2026-10-19). Sin doliente, sin fecha de inicio, sin efecto declarado en el cronograma.

**No materializados:** ninguno se puede afirmar. Ningún riesgo del registro tiene probabilidad, impacto, doliente ni fecha.

**Abiertos, con doliente:** ninguno tiene doliente nombrado, así que ninguno está cerrado.
- Riesgo: «El proveedor no ha confirmado la fecha de la última entrega» (informe 2026-10-19). Sin doliente.
- Riesgo: «El proveedor podría no llegar con el equipo completo para la siguiente fase» (notas de reunión del 2026-10-22). Se dijo en la reunión y **nadie lo anotó**. Sin doliente. Dice «la siguiente fase», o sea que hay trabajo por venir; eso contradice un cierre.

**Compromisos de reunión abiertos al cierre** (compute; la minuta del 2026-10-22 es la última):
- 8 vencidos sin evidencia: Felipe Arango «Aprobar el diseño 5» (9 días), Beatriz Cuéllar «Confirmar la fecha 7» (28), María Restrepo «Enviar el documento 9» (2), Ricardo Salas «Aprobar el diseño 13» (18), Laura Vélez «Actualizar la matriz 14» (19), Elena Duarte «Cerrar la prueba 18» (1), Laura Vélez «Validar el ambiente 20» (2), Óscar Ramírez «Aprobar el diseño 21» (2).
- 3 sin fecha: Camilo Beltrán «Entregar el punto 8», Rubén Cárdenas «Entregar el punto 16», Laura Vélez «Mandar el ajuste del presupuesto» (dicho como «la otra semana»).
- 2 reprogramados varias veces: Ricardo Salas «Enviar el documento 1» (6 veces: de 2026-09-30 a 2027-01-15) y «Cerrar la prueba 2» (5 veces: de 2026-09-15 a 2026-11-29).
- Varios dicen «ya lo entregué» en minuta sin acta: Felipe Arango, Beatriz Cuéllar, Camilo Beltrán, Liliana Torres, Mauricio Pérez.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| «Enviar el documento 1» se reprogramó 6 veces, una por reunión semanal, de 2026-09-30 a 2027-01-15 | 2026-09-17 a 2026-10-22 | La fecha vigente (2027-01-15) queda después del cierre planificado (2026-10-06) | Pasada la 3.ª reprogramación del mismo compromiso, subirlo al comité como decisión, no como línea de la tabla |
| «Cerrar la prueba 2» se reprogramó 5 veces, de 2026-09-15 a 2026-11-29 | 2026-09-17 a 2026-10-15 | Prueba sin cerrar a la fecha de cierre planificada | Igual que el anterior; ambos tienen el mismo responsable (Ricardo Salas) |
| Las actas de recibo de «Ingeniería básica aprobada» y «Pozos perforados» son del 2026-10-09 y del 2026-10-22; los hitos vencían el 2026-01-24 y el 2026-07-13 | 2026-10 | La evidencia llegó después del cierre planificado. Durante meses el avance solo se sostuvo con la palabra del gerente | Exigir el acta de recibo en la fecha del hito, no al final |
| Dos hitos figuran cumplidos sin ningún documento (licencia ambiental, montaje de facilidades) | desde 2026-04-19 y 2026-10-06 | No se puede probar la licencia, que es el hito de mayor riesgo regulatorio del proyecto | No marcar un hito como cumplido sin evidencia adjunta |
| Un riesgo de proveedor se comentó en reunión y nadie lo registró | 2026-10-22 | Queda fuera del RAID y sin doliente | Revisar las notas de cada reunión contra el RAID antes de cerrarla |

Sin lección sobre el bloqueo de ocho días: ningún documento dice qué efecto tuvo en fechas o costos, y sin efecto no se puede sustentar una lección.

### Sin dato
- Descripción de los Componentes 1, 2 y 3; qué entregable corresponde a cada uno.
- Si la campaña está «en producción y medido»: ninguna medición.
- Fecha real de término y costo final.
- Quién representa al cliente interno y acepta los entregables; aceptación por el patrocinador.
- Evidencia de la licencia ambiental y del montaje de facilidades.
- Efecto del bloqueo de ocho días en el plan.
- Proveedores y contratos (`vendors` vacío): no se puede contrastar lo facturado.
- Producto asociado, autoridad y fase: no encontrados (el acta dice «No aplica» para producto).
- Los campos de identidad, plan y presupuesto aprobado vienen del acta del 2025-10-21 y están a 12 meses, en el límite de vigencia (`stale_field_months: 12`).
- Si el 84% o el 100% del cronograma es el avance real.
- Los dos informes en PDF (informe de avance, acta de ingeniería) se leyeron del texto extraído; los originales no se revisaron a mano.

### Recomendación y qué sigue
1. No cerrar. Seguir como proyecto abierto y pedirle a Carlos Peña (gerente) que explique la diferencia entre 84% y 4 de 4 hitos. Pedirle también que cargue las dos evidencias que faltan.
2. Si el comité (Comité de Tecnología, próximo 2026-10-29) quiere cerrar de todos modos, que lo decida como **cierre por decisión**, con registro y con doliente para cada compromiso y riesgo abierto.
3. La fecha de cierre (2026-10-06) ya venció sin solicitud de cambio. Hace falta una replanificación formal, con línea base nueva sin borrar la v1.
4. Registrar en el RAID el riesgo del 2026-10-22 con doliente.

**Archivo.** Se ofrece mover la carpeta a `archivo/` y congelar la ficha. En esta sesión sin interfaz nadie confirma. Con el proyecto abierto no se mueve nada, y se deja la carpeta donde está.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados; la verificación es de quien lo lee. Lo que se habló fuera de los documentos no se conoce.*
