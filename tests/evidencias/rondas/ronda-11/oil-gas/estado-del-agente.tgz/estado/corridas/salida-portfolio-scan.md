## Barrido — 2026-10-23

Términos vigentes (versión 1.2, aceptados por José Francisco Ñáñez; comprobante en `.criterio/terminos/`). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

**Documentos:** 66 en la carpeta · 41 leídos · 25 sin cambio desde la corrida anterior · 0 ilegibles (el inventario marcó 4 XML como ilegibles; el conversor sí extrajo su texto, ver abajo)
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Formatos del inventario: .md 28, .docx 15, .pdf 11, .csv 3, .xlsx 3, .xml 4, .json 1, .txt 1. Un solo lote de 10 proyectos, uno tras otro, sin subagentes. No hay carpeta `entrada/`.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Adecuación del casino del campamento | 6 | identidad, plan, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 2 riesgos, 2 incidencias, 1 compromiso | autoridad, fase, facturado (no hay factura) |
| PRY-201 Facilidades de producción temprana | 2 | identidad, fechas del acta, presupuesto, avance declarado, 2 riesgos | autoridad, fase, cronograma e hitos (no hay), producto («No aplica») |
| PRY-203 Recobro mejorado con agua | 2 | ídem | autoridad, fase, cronograma e hitos, producto |
| PRY-205 Monitoreo remoto de pozos | 5 | identidad, plan, 5 hitos, presupuesto, 2 riesgos, 3 incidencias, 1 compromiso | autoridad, fase |
| PRY-206 Planta de tratamiento de crudo | 5 | identidad, plan, 4 hitos, presupuesto, 2 riesgos, 2 incidencias | autoridad, fase, producto |
| PRY-207 Gemelo digital de la estación | 2 | identidad, fechas del acta, presupuesto, 1 riesgo, 2 incidencias | autoridad, fase, cronograma e hitos, producto |
| PRY-208 Reducción de quema de gas | 8 | identidad, plan, 5 hitos, presupuesto, contrato CT-751 (2 entregables), factura FV-1751, 2 riesgos, 3 incidencias, 1 compromiso | autoridad, fase |
| PRY-209 Sísmica 3D del bloque norte | 4 | identidad, plan, 4 hitos, presupuesto, 2 riesgos, 3 incidencias, 2 compromisos | autoridad, fase, producto |
| PRY-210 Mantenimiento predictivo de bombas | 3 | identidad, plan, 4 hitos, presupuesto, 2 riesgos, 3 incidencias | autoridad, fase, producto |
| PRY-211 Estación de compresión | 4 | identidad, plan, 5 hitos, presupuesto, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase, producto |

Ninguna acta declara la autoridad del gerente ni la fase: `not_found` en las diez. Ninguna declara dependencias de otros proyectos.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-200, PRY-202, PRY-204 | Nada: sus 25 documentos tienen el mismo hash; no se abrieron ni se tocaron sus fichas | — |

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | El inventario marcó 4 cronogramas `.xml` como «formato que no se lee sin instalar algo» (PRY-204, 206, 209, 210), pero `texto.py` los convirtió como Microsoft Project. Leí los de PRY-206, 209 y 210. El de PRY-204 no estaba en el plan (sin cambio) y no lo abrí. Las fichas no aclaran si la conversión de XML es fiable; conviene que alguien confirme un hito contra el original. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe `entrada/` |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

### Lo que hay que mirar (lo que dicen los documentos, sin juicio mío)
- **Hitos declarados «cerrado» sin acta de recibo (15):** PRY-205 (1), PRY-206 (2), PRY-208 (3), PRY-209 (2), PRY-210 (4, todos), PRY-211 (3). Con acta quedan 4: PRY-199 Ingeniería básica, PRY-205 Licencia, PRY-206 Ingeniería básica y Pozos, PRY-208 Pozos. Las actas llevan fecha de octubre de 2026, mucho después de la fecha del hito (p. ej. PRY-206 Ingeniería básica: hito 2025-08-10, acta 2026-10-20).
- **Cierre comprometido ya pasado con proyecto en ejecución:** PRY-201 (cierre 2026-04-24, verde, 71 %), PRY-206 (2026-03-13, rojo, 93 %), PRY-210 (2026-09-01, verde, 49 % aunque el cronograma da sus 4 hitos por cerrados). Ninguno tiene una línea base nueva.
- **Ejecutado mayor que comprometido:** PRY-206 (4.005.821.807 frente a 2.685.859.507) y PRY-211 (262.348.271 frente a 218.981.244).
- **Avance frente a gasto:** PRY-207 declara 87 % con 215.253.435 ejecutados de 1.200.000.000 aprobados.
- **Hito vencido y abierto:** PRY-209 Pozos perforados, fecha 2026-10-13, «en curso».
- **Compromisos vencidos sin evidencia (2):** PRY-208 Ricardo Salas, «Entregar el punto 12», 2026-10-19; PRY-209 María Restrepo, «Entregar el punto 6», 2026-10-03 (fecha anterior a la reunión del 2026-10-19 que la lista). Los otros 5 están abiertos.
- **Proveedores:** PRY-208 CT-751: «Alquiler del taladro» (2026-01-05) sigue pendiente, vencido; la factura FV-1751 (50.106.103) coincide con el valor de «Bolsa de horas», que sí tiene acta (2026-07-18). PRY-199 CT-199: tres entregables pendientes, sin facturas.
- **Mismas personas en varios roles:** Andrés Lozano gerente de PRY-199 y PRY-211 y patrocinador de PRY-207; Paula Céspedes gerente de PRY-209 y PRY-210 y patrocinadora de PRY-211. Es dato, no hallazgo.
- Los textos de «lo que pasó» y los riesgos se repiten casi idénticos entre proyectos distintos (p. ej. «La prueba hidrostática no alcanzó la presión pactada y se repite» en 6 informes). No lo interpreto.

### Pie
criterio-portfolio 0.8.0 · fichas tocadas: 10 (PRY-199, 201, 203, 205, 206, 207, 208, 209, 210, 211), selladas con 41 documentos · campos en `not_found`: `identity.authority` e `identity.phase` en las 10; además producto en 7 proyectos donde el acta dice «No aplica», facturado en PRY-199, y cronograma/hitos en PRY-201, 203, 207 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
