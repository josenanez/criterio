Fichas cargadas: 13 (PRY-199 a PRY-211), `estado/records/`, actualizadas el 2026-10-23; cifras recalculadas con `compute` al 2026-10-23. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Además leí las salidas de hoy de raid-log y change-control.

# Comité de proyectos — 2026-10-29 (material preparado el 2026-10-23)
6 decisiones · 6 escalamientos sin decisión asociada · 9 de 13 proyectos con hallazgos (54 señales)

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | No hay acta ni decisión de un comité anterior en la carpeta de estado, ni solicitudes de cambio registradas en las fichas (0 cambios en los 13 proyectos). No sé qué se decidió fuera de documentos. | Sin información |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo, y con qué umbrales?
**Proyecto:** los 13 · **Quién decide:** el propio comité (o quien lo convoca); es el primer punto porque los demás dependen de él · **Si no se decide hoy:** los puntos 2 a 6 quedan sin un destinatario con facultad demostrable y cada cambio seguirá yendo a comité «por defecto».

Dato: la autoridad de aprobación no está declarada en ninguna de las 13 fichas (`no_authority` = 13 de 13).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité fija una matriz única de autoridad (gerente / patrocinador / comité) con umbrales | Ninguno | Una sesión de comité | No declarado |
| B. Cada proyecto la declara en una enmienda a su acta | Ninguno | Más lento: 13 actas; sin fecha propuesta | No declarado |
| C. Todo cambio va a comité (situación actual de hecho) | Ninguno | Cada cambio espera la sesión semanal | No declarado |

**Recomendación:** A, con los umbrales de la PMO como punto de partida (10 % en tiempo y en costo, según la configuración), y B solo para los proyectos que necesiten una excepción. Razón: sin una regla única, el comité no puede comprobar si un punto llegó al destinatario correcto.

### [2] ¿Se aprueba, se rechaza o se devuelve la solicitud de mover 30 días la salida a producción de PRY-205 (de 2027-06-08 a 2027-07-08)?
**Proyecto:** PRY-205 Monitoreo remoto de pozos (gerente: Gustavo Neira) · **Quién decide:** no determinable hasta resolver el punto 1; el acta nombra al Comité de HSE y al patrocinador Carlos Peña sin decir qué cambios aprueba cada uno · **Si no se decide hoy:** el cierre sigue en 2027-06-08, con estado declarado «verde» y las cinco fechas vigentes idénticas a la línea base, pese a dos semanas perdidas, una prueba hidrostática repetida y ocho días de bloqueo reportados.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | No declarado | +30 días (≈ 7,3 % de los 412 días del plan); línea base 2, primera replanificación | No declarado; la proyección declarada (4.387.704.676 COP) ya supera lo aprobado (4.200.000.000 COP) en 4,5 % |
| B. Rechazar | Ninguno | Se mantiene 2027-06-08 | Sin cambio; el atraso conocido se absorbe sin respaldo en las fechas |
| C. Devolver para completarla | Ninguno | Sin cambio hasta que vuelva | Sin cambio |

**Recomendación:** C. La solicitud no dice quién la pide, por qué, ni su impacto en alcance y costo; el informe menciona los hechos pero no los liga a la solicitud, y yo no los usé como motivo. Un comité no debería aprobar un cambio sin solicitante ni motivo. Si el solicitante responde, se puede decidir en la sesión siguiente.

### [3] ¿Se exige replanificación formal a los cinco proyectos cuya fecha de fin de línea base ya pasó sin que nadie haya replanificado?
**Proyectos:** PRY-200, PRY-201, PRY-202, PRY-206, PRY-210 · **Quién decide:** el comité, tras el punto 1 · **Si no se decide hoy:** las fechas vigentes siguen siendo las originales, la desviación calculada es 0 días en todos (`replans` = 0), y el portafolio muestra atraso nulo en proyectos cuya fecha ya venció.

| Proyecto | Fin en línea base | Avance declarado | Estado declarado |
|---|---|---|---|
| PRY-206 Planta de tratamiento de crudo | 2026-03-13 | 93 % | rojo |
| PRY-201 Facilidades de producción temprana | 2026-04-24 | 71 % | verde |
| PRY-202 Gasoducto de interconexión | 2026-06-05 | 75 % | amarillo |
| PRY-210 Mantenimiento predictivo de bombas | 2026-09-01 | 49 % | verde |
| PRY-200 Campaña de perforación del bloque sur | 2026-10-06 | 84 % | verde |

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada gerente presenta una solicitud de cambio con fecha nueva y motivo | No declarado | Fija la fecha real y deja línea base 2 | No declarado; se mide contra la original y la vigente |
| B. Se mantiene la fecha y se pide solo un informe de estado | Ninguno | Sin cambio | Sin cambio |

**Recomendación:** A. Los avances son declaraciones: ninguna de las 13 fichas tiene una sola fuente marcada como evidencia (`evidence` = 0), así que el porcentaje no sustenta que el cierre esté cerca. Sin replanificar, no hay forma de medir el atraso.

### [4] PRY-204 Integridad de ductos: la proyección supera lo aprobado en 20,5 %, ¿se pide aumento de presupuesto, recorte de alcance o revisión de la proyección?
**Proyecto:** PRY-204 (gerente: Javier Hoyos) · **Quién decide:** no determinable (punto 1) · **Si no se decide hoy:** el proyecto sigue declarado «verde» con proyección de 2.893.029.654 COP contra 2.400.000.000 COP aprobados, 78,6 % comprometido y 31,7 % ejecutado; el umbral configurado es 10 %.

Contexto: avance declarado 35 % contra 50–75 % que sustentan los hitos (2 de 4 cumplidos, ambos sin evidencia de cumplimiento: Ingeniería básica aprobada y Licencia ambiental otorgada).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aumentar el presupuesto aprobado | Se mantiene | Sin cambio declarado | Aprobado pasa a cubrir la proyección de 2.893.029.654 COP |
| B. Recortar alcance hasta ajustar a 2.400.000.000 COP | Se reduce; no sé cuánto | No declarado | Se mantiene el aprobado |
| C. Pedir al gerente que sustente la proyección antes de decidir | Sin cambio | Una semana de comité | Sin cambio |

**Recomendación:** C. La proyección es declarada y los hitos que la sostienen no tienen evidencia; decidir A o B sobre ella es decidir sobre una cifra no verificada. Si en una semana el gerente no la sustenta, pasar a A o B.

### [5] PRY-202 Gasoducto de interconexión: la proyección supera lo aprobado en 14,4 %, ¿qué se hace?
**Proyecto:** PRY-202 (gerente: Natalia Ospina) · **Quién decide:** no determinable (punto 1) · **Si no se decide hoy:** el proyecto sigue en «amarillo» con proyección de 4.804.009.661 COP contra 4.200.000.000 COP aprobados; 77,2 % comprometido, 40,3 % ejecutado, y el fin de línea base (2026-06-05) ya pasó.

Contexto: avance declarado 75 % contra 100 % que sustentan los hitos (4 de 4 cumplidos; 3 sin evidencia). Hay un compromiso de Rubén Cárdenas («Entregar el punto 24») vencido hace 18 días.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aumentar el presupuesto aprobado | Se mantiene | Se resuelve junto con el punto 3 | Aprobado pasa a cubrir 4.804.009.661 COP |
| B. Recortar alcance | Se reduce; no sé cuánto | No declarado | Se mantiene el aprobado |
| C. Pedir sustento de la proyección y de la contradicción entre hitos y avance | Sin cambio | Una semana de comité | Sin cambio |

**Recomendación:** C, y resolverlo junto con el punto 3, porque la fecha de fin ya venció. Misma razón que en el punto 4.

### [6] PRY-208: el entregable «Alquiler del taladro» (contrato CT-751) lleva 291 días vencido, ¿qué se le exige al proveedor?
**Proyecto:** PRY-208 Reducción de quema de gas (gerente: Liliana Torres); proveedor Integridad y Corrosión S.A.S. · **Quién decide:** quien contrata; en los documentos no consta quién es, así que primero hay que identificarlo · **Si no se decide hoy:** un entregable pendiente desde 2026-01-05 sigue sin acta de recibo mientras el contrato avanza; el proyecto está «verde» con avance declarado 51 % contra 80–100 % que sustentan los hitos.

Contexto: de 2 entregables, 1 aceptado; lo facturado (50.106.103 COP) coincide con lo aceptado (50.106.103 COP), es decir, no hay facturación adelantada visible en las fichas. Las fichas no cuentan cuánto vale el entregable pendiente. La relación con la incidencia «Se reprogramó la movilización del taladro» es mía; los documentos no la establecen.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir fecha de entrega y acta de recibo por escrito | Sin cambio | Fecha a acordar con el proveedor | No declarado |
| B. Condicionar nuevas facturas a la aceptación del entregable | Sin cambio | Sin cambio | Retiene pagos futuros; monto no declarado |
| C. Dar el entregable por no vigente y renegociar el contrato | Puede cambiar | Fecha de fin 2026-11-23 en riesgo | No declarado |

**Recomendación:** A y B juntas; C solo si el proveedor no responde. Razón: lo pendiente es un entregable ya vencido, y exigir evidencia de recibo es lo mínimo antes de pagar más.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-210 Mantenimiento predictivo de bombas | Sin informe nuevo: 21 días de silencio (umbral 15). Declarado «verde» el 2026-10-02 con 49 % de avance, 4 de 4 hitos cumplidos (todos sin evidencia) y fin de línea base vencido el 2026-09-01. | 2026-10-02 | Que la gerente (Paula Céspedes) responda por el estado real; entra también en el punto 3. |
| PRY-200 Campaña de perforación del bloque sur | 8 compromisos vencidos (el más antiguo, «Confirmar la fecha 7», Beatriz Cuéllar, 28 días); 3 sin fecha; 2 de Ricardo Salas reprogramados 6 y 5 veces. Declarado «verde» con 17 señales abiertas. | Desde 2026-09-25 el más antiguo | Que el gerente (Carlos Peña) confirme quién responde por cada compromiso o los cierre. |
| PRY-209 Sísmica 3D del bloque norte | Hito «Pozos perforados» vencido hace 10 días (2026-10-13); compromiso de María Restrepo vencido hace 20 días. Declarado «rojo». | 2026-10-03 | Que la gerente (Paula Céspedes) diga qué desbloquea el hito. |
| PRY-206, PRY-207, PRY-209 | Hallazgo de seguridad en espacios confinados, el mismo texto en tres proyectos, sin doliente ni fecha. Puede ser un hecho copiado. | Sin fecha | Que alguien confirme si son tres hallazgos y quién los cierra. Por ser de seguridad, no esperar. |
| Los 5 proyectos en «verde» con señales abiertas (PRY-200, 204, 205, 208, 210) | El estado declarado no está sustentado por la evidencia. | Informes del 2026-10-02 al 2026-10-22 | Que cada gerente reafirme o corrija su estado. |
| Portafolio | Ninguna ficha declara dependencias con otro proyecto, aunque comparten temas (taladro, licencia ambiental, bloqueos). 49 de 49 ítems RAID sin doliente y sin fecha. | — | Una persona que confirme si hay dependencias que nadie escribió y nombre dolientes. |

## Para conocimiento
- PRY-199 Adecuación del casino: sin señales; 20 % declarado, 1 de 5 hitos, presupuesto 45,0 % comprometido.
- PRY-201 Facilidades de producción temprana: sin señales de la herramienta; fin de línea base vencido (punto 3).
- PRY-203 Recobro mejorado con agua: sin señales; 48 % declarado; proyección 4,6 % sobre lo aprobado (bajo el umbral).
- PRY-207 Gemelo digital de la estación: sin señales; declarado «rojo» sin señales que lo expliquen; 87,7 % comprometido de lo aprobado.
- PRY-211 Estación de compresión: «amarillo»; avance 49 % contra 60–80 % sustentado; 3 hitos sin evidencia.

## Anexo
**Estado por proyecto** (al 2026-10-23; «declarado» es lo que dice el informe, no lo que muestra la evidencia)
| Proyecto | Declarado | Avance declarado | Señales | Proyección vs. aprobado |
|---|---|---|---|---|
| PRY-199 | verde | 20,0 % | 0 | 0,0 % |
| PRY-200 | verde | 84,0 % | 17 | 4,7 % |
| PRY-201 | verde | 71,0 % | 0 | -7,1 % |
| PRY-202 | amarillo | 75,0 % | 6 | 14,4 % |
| PRY-203 | verde | 48,0 % | 0 | 4,6 % |
| PRY-204 | verde | 35,0 % | 5 | 20,5 % |
| PRY-205 | verde | 53,0 % | 2 | 4,5 % |
| PRY-206 | rojo | 93,0 % | 2 | 0,1 % |
| PRY-207 | rojo | 87,0 % | 0 | -1,7 % |
| PRY-208 | verde | 51,0 % | 7 | -3,2 % |
| PRY-209 | rojo | 78,0 % | 4 | 4,4 % |
| PRY-210 | verde | 49,0 % | 7 | -2,6 % |
| PRY-211 | amarillo | 49,0 % | 4 | -5,8 % |

Totales: 13 proyectos, 9 con alertas, 54 alertas, 5 verdes contradichos, 0 sin línea base, 13 sin autoridad declarada, 0 problemas de ficha.

**Contradicciones abiertas:** el cálculo no registra conflictos entre documentos (`conflicts` vacío en los 13). Las contradicciones son entre lo declarado y lo sustentado (ver arriba).

**Vacíos de información**
- Autoridad de aprobación y fase: faltan en los 13.
- Producto: falta en 9 fichas (PRY-200, 201, 203, 204, 206, 207, 209, 210, 211).
- PRY-199: no se declara lo facturado del contrato CT-199.
- Campos de identidad y plan con más de 12 meses de antigüedad en PRY-200, 201, 202, 206, 208 y 210 (de 12 a 17 meses).
- Faltan actas de comité de PRY-201, 203, 206, 207 y 210: de esos cinco no se puede decir que no haya riesgos dichos y no anotados.
- Riesgo dicho y no registrado en PRY-200 (notas del 2026-10-22): el proveedor podría no llegar con el equipo completo para la siguiente fase. Sin proveedor ni fase identificados.
- Todos los avances y estados son declaraciones: 0 fuentes marcadas como evidencia en las 13 fichas.

---
Pie: criterio-portfolio 0.8.0 · términos v1.2 aceptados el 2026-10-23 por José Francisco Ñáñez · fichas aplicadas: 13 (2026-10-23) · borrador de trabajo, no decisión ni asesoría; la verificación es suya con las citas de cada ficha.
Campos inciertos: quién decide en los puntos 2 a 6; la relación entre el taladro de PRY-208 y el contrato CT-751 (es mía); el valor del entregable pendiente de CT-751; si el hallazgo de espacios confinados son tres hechos o uno; no sé qué se habló fuera de los documentos.
Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

Después: cuando el comité sesione, puedo registrar sus decisiones en las fichas. Sin nadie que responda en esta sesión tomo la respuesta sugerida: no registré nada en las fichas.
