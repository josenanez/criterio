## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-23

**De qué documentos sale:** las fichas de los 13 proyectos (`estado/records/`), construidas en el barrido de hoy sobre 66 documentos (informes de avance, actas de recibo, contratos y 14 documentos de reuniones: 13 actas de comité y las notas del 2026-10-22 de PRY-200). Para esta corrida releí las minutas y notas de reunión; no abrí de nuevo los informes. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez; nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0).

Escala de probabilidad e impacto: ninguna de las 13 fichas declara una. Si se usa una, será alta/media/baja, y la pone el doliente, no yo.

**23 riesgos · 0 supuestos · 26 incidencias · 0 dependencias** (tal como están en las fichas)
**49 de 49 sin doliente · 49 de 49 sin fecha · 0 con mitigación declarada · 1 no registrado formalmente**
Sin movimiento: no se puede medir (ver más abajo).

Si acepta las reclasificaciones propuestas: 18 riesgos · 5 dependencias · 24 incidencias abiertas · 2 incidencias que el propio texto da por resueltas.

> Los Id (`PRY-208·R1`, `·I1`) son etiquetas de este informe, en el orden de la ficha. Ni el RAID de las fichas ni los documentos traen Id propio. No escribí nada en las fichas: lo que sigue son propuestas.

### Necesitan decisión ahora
Ningún ítem cumple de forma demostrable con el criterio de escalamiento, y lo digo porque los documentos no permiten comprobarlo: no hay doliente, ni fecha, ni mitigación declarada, así que no se sabe qué venció ni quién respondió. Los dos grupos de abajo sí merecen que alguien los mire primero, y la razón es la que dan los documentos.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-206·I2, PRY-207·I1, PRY-209·I1 | Incidencia | Se levantó un hallazgo de seguridad en espacios confinados | sin doliente | sin fecha | Es una incidencia (ya ocurrió) en tres proyectos, es de seguridad y ninguna ficha dice quién la resuelve ni si está cerrada. El texto es idéntico en los tres informes; confirme que son tres hallazgos y no uno copiado. |
| PRY-208·I1 (y 199·I1, 202·I1, 203·I1, 204·I1, 206·I1, 211·I2) | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | sin doliente | sin fecha | En PRY-208 coincide en tema con el contrato CT-751: «Alquiler del taladro» (vence 2026-01-05) sigue pendiente, sin acta de recibo, mientras «Bolsa de horas de ingeniería» se recibió el 2026-07-18 y se facturó. Los documentos no relacionan una cosa con la otra; la relación es mía y hay que confirmarla. Si es cierta, la decisión es del que contrata, no del gerente. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-200·R2) | Riesgo (futuro, incierto, depende de un tercero). Sin proveedor nombrado ni fase identificada. | `PRY-200-campaña-de-perforación-del-bloque-sur/2026-10-22-notas-reunion.txt`, línea 7 | 2026-10-22 |

Es el único. Leí además las minutas de PRY-199, 202, 204, 205, 208, 209 y 211 y las seis de PRY-200 (septiembre-octubre). Solo traen compromisos y, en PRY-200, frases del tipo «dice que ya entregó… no se presentó acta». Eso es de seguimiento de compromisos, no RAID, y no lo convertí en riesgos. Las minutas de PRY-201, 203, 206, 207 y 210 no existen en la carpeta, así que de esos cinco proyectos no se puede decir que no haya riesgos dichos y no anotados: simplemente no hay reunión que leer.

### Sin doliente o sin fecha
Los 49 ítems. Se reporta como hallazgo y no relleno nada. Dos precisiones:
- **Riesgos (23):** además de doliente y fecha, ninguno trae probabilidad, impacto ni mitigación.
- **Incidencias (26):** ninguna trae doliente ni fecha de inicio, de modo que «desde cuándo» no existe en ningún caso.

Los ítems son los de la tabla del registro completo. Proponer doliente, no asignarlo: el gerente de cada proyecto, según la ficha, es PRY-199 Andrés Lozano, 200 Carlos Peña, 201 Carlos Peña, 202 Natalia Ospina, 203 Rubén Cárdenas, 204 Javier Hoyos, 205 Gustavo Neira, 206 Elena Duarte, 207 María Restrepo, 208 Liliana Torres, 209 Paula Céspedes, 210 Paula Céspedes, 211 Andrés Lozano. Es el candidato natural, no una asignación.

### Reclasificaciones propuestas
| Id | Estaba | Propongo | Por qué |
|---|---|---|---|
| PRY-199·R1, 200·R1, 205·R1, 206·R2, 210·R1 | Riesgo | Dependencia | «El proveedor no ha confirmado la fecha de la última entrega» no es incierto en el futuro: ya es un hecho presente, y depende de alguien fuera del proyecto. |
| PRY-210·I1, PRY-211·I1 | Incidencia | Resuelta | «Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior»: según su propio texto ya se recibió. Falta el documento de la aprobación para cerrarla con evidencia; no lo encontré en la carpeta. |
| Precio del crudo por debajo del supuesto del caso de negocio (PRY-201·R1, 202·R2, 204·R1, 207·R1, 209·R1) | Riesgo | Se queda como riesgo, pero hay un supuesto sin registrar | El «supuesto del caso de negocio» es el precio asumido. Ninguna ficha lo registra como supuesto ni dice su valor ni si se verificó. |

Duda abierta que no reclasifico: «Se ajustó el plan de perforación con la geología del pozo vecino» (PRY-209·I3, PRY-210·I2) está registrada como incidencia pero describe un cambio ya hecho. Si cambió alcance o fechas, corresponde a control de cambios. En proyectos de sísmica y mantenimiento predictivo de bombas el texto llama la atención, pero no lo interpreto.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199·R1 | «El proveedor» (sin nombre ni código; el contrato de la ficha es CT-199) | No: declarada, no acordada | El proveedor no ha confirmado la fecha de la última entrega (informe del 2026-10-20) |
| PRY-200·R1 | ídem (informe del 2026-10-19) | No | ídem |
| PRY-205·R1 | ídem (informe del 2026-10-21) | No | ídem |
| PRY-206·R2 | ídem (informe del 2026-10-20) | No | ídem |
| PRY-210·R1 | ídem (informe del 2026-10-02) | No | ídem |

**El cruce entre proyectos no se pudo hacer:** ninguna ficha declara una dependencia de otro proyecto del portafolio, y ninguna acta de constitución las trae. Que ningún proyecto dependa de otro es poco creíble en un portafolio donde hay personas en varios roles y comparten tema (taladro, licencia ambiental, bloqueos de comunidad), pero ahí no hay dato y no lo invento. Pregunta para el comité: ¿hay dependencias entre proyectos que nadie ha escrito?

**Los mismos textos se repiten entre proyectos distintos** (por ejemplo, el cambio de licencia ambiental en 5 riesgos, los bloqueos de comunidad en 6 riesgos y 2 incidencias, y la prueba hidrostática repetida en 6 incidencias). No sé si es un mismo hecho que afecta a varios o texto copiado de una plantilla. Lo dejo dicho; no lo interpreto.

### Registro completo
Doliente y fecha en todos: no declarados. «Último movimiento» es la fecha del informe donde aparece el ítem, no una fecha en que alguien lo haya movido. Todos los riesgos tienen fecha de octubre (el 2026-10-02 el más antiguo), así que por fecha no hay riesgo con dos períodos sin movimiento; las incidencias no tienen fecha y no se puede decir.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199·R1 | Riesgo → dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-199·R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-199·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-199·I2 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-200·R1 | Riesgo → dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | sin doliente | sin fecha | 2026-10-19 |
| PRY-200·R2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase; se comentó en la reunión y nadie lo anotó como riesgo (no registrado formalmente) | no declarada | no declarada | sin doliente | sin fecha | 2026-10-22 |
| PRY-200·I1 | Incidencia | Un bloqueo de la comunidad detuvo el transporte de equipos ocho días | — | — | sin doliente | sin fecha | sin fecha |
| PRY-201·R1 | Riesgo | Precio del crudo por debajo del supuesto del caso de negocio | no declarada | no declarada | sin doliente | sin fecha | 2026-10-19 |
| PRY-201·R2 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-19 |
| PRY-201·I1 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-202·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no declarada | no declarada | sin doliente | sin fecha | 2026-10-17 |
| PRY-202·R2 | Riesgo | Precio del crudo por debajo del supuesto del caso de negocio | no declarada | no declarada | sin doliente | sin fecha | 2026-10-17 |
| PRY-202·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-202·I2 | Incidencia | El equipo perdió dos semanas por rotación del supervisor de campo | — | — | sin doliente | sin fecha | sin fecha |
| PRY-203·R1 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-203·R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-203·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-204·R1 | Riesgo | Precio del crudo por debajo del supuesto del caso de negocio | no declarada | no declarada | sin doliente | sin fecha | 2026-10-22 |
| PRY-204·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-205·R1 | Riesgo → dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | sin doliente | sin fecha | 2026-10-21 |
| PRY-205·R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no declarada | no declarada | sin doliente | sin fecha | 2026-10-21 |
| PRY-205·I1 | Incidencia | El equipo perdió dos semanas por rotación del supervisor de campo | — | — | sin doliente | sin fecha | sin fecha |
| PRY-205·I2 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-205·I3 | Incidencia | Un bloqueo de la comunidad detuvo el transporte de equipos ocho días | — | — | sin doliente | sin fecha | sin fecha |
| PRY-206·R1 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-206·R2 | Riesgo → dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-206·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-206·I2 | Incidencia | Se levantó un hallazgo de seguridad en espacios confinados | — | — | sin doliente | sin fecha | sin fecha |
| PRY-207·R1 | Riesgo | Precio del crudo por debajo del supuesto del caso de negocio | no declarada | no declarada | sin doliente | sin fecha | 2026-10-20 |
| PRY-207·I1 | Incidencia | Se levantó un hallazgo de seguridad en espacios confinados | — | — | sin doliente | sin fecha | sin fecha |
| PRY-207·I2 | Incidencia | El equipo perdió dos semanas por rotación del supervisor de campo | — | — | sin doliente | sin fecha | sin fecha |
| PRY-208·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no declarada | no declarada | sin doliente | sin fecha | 2026-10-14 |
| PRY-208·R2 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-14 |
| PRY-208·I1 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |
| PRY-208·I2 | Incidencia | El equipo perdió dos semanas por rotación del supervisor de campo | — | — | sin doliente | sin fecha | sin fecha |
| PRY-208·I3 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-209·R1 | Riesgo | Precio del crudo por debajo del supuesto del caso de negocio | no declarada | no declarada | sin doliente | sin fecha | 2026-10-17 |
| PRY-209·R2 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-17 |
| PRY-209·I1 | Incidencia | Se levantó un hallazgo de seguridad en espacios confinados | — | — | sin doliente | sin fecha | sin fecha |
| PRY-209·I2 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-209·I3 | Incidencia | Se ajustó el plan de perforación con la geología del pozo vecino | — | — | sin doliente | sin fecha | sin fecha |
| PRY-210·R1 | Riesgo → dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | sin doliente | sin fecha | 2026-10-02 |
| PRY-210·R2 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-02 |
| PRY-210·I1 | Incidencia → resuelta | Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior | — | — | sin doliente | sin fecha | sin fecha |
| PRY-210·I2 | Incidencia | Se ajustó el plan de perforación con la geología del pozo vecino | — | — | sin doliente | sin fecha | sin fecha |
| PRY-210·I3 | Incidencia | La prueba hidrostática no alcanzó la presión pactada y se repite | — | — | sin doliente | sin fecha | sin fecha |
| PRY-211·R1 | Riesgo | Bloqueos de la comunidad en la vía de acceso | no declarada | no declarada | sin doliente | sin fecha | 2026-10-21 |
| PRY-211·I1 | Incidencia → resuelta | Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior | — | — | sin doliente | sin fecha | sin fecha |
| PRY-211·I2 | Incidencia | Se reprogramó la movilización del taladro por disponibilidad del contratista | — | — | sin doliente | sin fecha | sin fecha |

### Después
Quedan dos ofertas para el gerente de la PMO: (1) subir a comité (siguiente: 2026-10-29) los dos grupos de «Necesitan decisión ahora», con la decisión formulada; (2) proponer doliente para los 49 ítems. En esta sesión no hay quién responda, así que tomo la respuesta sugerida: no escalé ni propuse nada más allá de lo escrito arriba; queda como oferta.

### Pie de rigor
Sale de las fichas de 13 proyectos, que a su vez salen de 66 documentos del barrido de hoy, y de 14 documentos de reuniones leídos en esta corrida. No sé nada de lo que se habló fuera de esos documentos. No hay RAID previo con historial de movimiento: las fichas guardan solo la fecha del informe. No hay Id propios, probabilidades, impactos, dolientes, fechas ni mitigaciones, y no inventé ninguno. Faltan reuniones de PRY-201, 203, 206, 207 y 210. La relación entre el taladro de PRY-208 y el contrato CT-751 es mía y no está en los documentos. Es un borrador para que lo verifique una persona con las citas de cada ficha.

criterio-portfolio 0.8.0 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
