## Historia · PRY-205 Monitoreo remoto de pozos · 2026-04-12 a 2026-10-21

**Leí:** 5 documentos entre 2026-04-12 y 2026-10-21 (acta de constitución, cronograma v1, acta de recibo, informe de avance, minuta de comité). Cifras derivadas: salida de `compute` del 2026-10-23.
**Trimestres sin un solo documento:** 2026-T3 (julio a septiembre). Justo el trimestre en que vencía "Ingeniería básica aprobada".

### En una línea
Del proyecto hay documentos de su arranque (2026-04-12) y de las últimas tres semanas (2026-10-09 a 2026-10-21), y nada en medio. El 2026-10-21 el gerente declara **verde, 53 %**, mientras el mismo informe cuenta una prueba hidrostática que se repite, dos semanas perdidas y ocho días de bloqueo; el cronograma no tiene una sola fecha movida desde la línea base. El hito "Ingeniería básica aprobada" (vence 2026-07-13) figura cerrado y no hay acta de recibo que lo sustente.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 0 | 0 días | No calculable: hay una sola declaración en los documentos (2026-10-21). El hito sin evidencia lleva 102 días vencido. | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-12 | `00-gobierno/2026-04-12-acta-constitucion.md` | Se aprueba el proyecto: 4.200.000.000 COP, inicio 2026-04-22, cierre 2027-06-08. Patrocinador Carlos Peña, gerente Gustavo Neira, Comité de HSE. Alcance escrito como "Componente 1/2/3"; sin dependencias declaradas. |
| 2026-04-12 | `10-plan/2026-04-12-cronograma-v1.xlsx` | Línea base de 5 hitos. Fecha base y vigente son iguales en todos. Ver nota sobre el estado de los hitos más abajo. |
| 2026-10-09 | `30-reuniones/2026-10-09-comite-semanal.md` | Comité con Gustavo Neira y Carlos Peña. Un compromiso: Felipe Arango, "Entregar el punto 18", para 2026-11-11. |
| 2026-10-18 | `20-seguimiento/2026-10-18-acta-recibo-licencia-ambiental-otorgada.pdf` | Gustavo Neira recibe "Licencia ambiental otorgada". El hito vencía el 2026-10-04. |
| 2026-10-21 | `20-seguimiento/2026-10-21-informe-avance.md` | Declara verde y 53 %. Cuenta dos semanas perdidas, prueba hidrostática repetida y 8 días de bloqueo. Proyección al cierre 4.387.704.676 COP, 4,5 % sobre lo aprobado. Dos riesgos abiertos. |

**Fecha del documento contra fecha de lo que dice.** El cronograma está fechado 2026-04-12, pero marca como "cerrado" dos hitos que vencían el 2026-07-13 y el 2026-10-04. Ese archivo no pudo escribirse en abril con esos estados: se editó después sin cambiar el nombre ni dejar versión. No sé cuándo. Es un dato pendiente de confirmar con quien lo mantiene.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| — | — | — | Ninguna: cierre vigente 2027-06-08 = original | — |

Cero replanificaciones y 0 días de atraso contra la línea base original y contra la vigente. Los documentos no explican cómo un proyecto con una prueba repetida, dos semanas perdidas y ocho días de bloqueo conserva intactas todas sus fechas. No hay solicitud de cambio, ni acta que diga que se absorbió el efecto.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios: patrocinador, gerente y comité son los del acta y los de la minuta del 2026-10-09 | — |

Faltan dos campos de identidad en la ficha: la autoridad y la fase. Sin minutas entre abril y octubre no se puede descartar un cambio en ese lapso.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Felipe Arango | Entregar el punto 18 | 1 | 2026-11-11 |

Ninguno repetido, vencido ni sin fecha. Con una sola minuta no hay serie para ver repeticiones; el compromiso no dice qué es el "punto 18".

### Desde cuándo lo declarado no se sostiene
- **Primer hito sin evidencia:** "Ingeniería básica aprobada", vencido el 2026-07-13, declarado cumplido, sin acta de recibo en la carpeta. A la fecha lleva 102 días.
- **Qué se siguió reportando:** el informe del 2026-10-21 declara verde y 53 %. El plan sustenta entre 40 % y 60 % (2 de 5 hitos cerrados), así que el porcentaje no sale como contradicción. Lo que no tiene sustento es que ese avance incluya la ingeniería básica.
- **Una incoherencia más:** el informe del 2026-10-21 deja abierto el riesgo "Cambio en la licencia ambiental que puede mover el alcance", tres días después de recibir la licencia (2026-10-18). Puede ser un riesgo ya vencido o un cambio posterior a la licencia; el documento no lo aclara.
- **Desde qué fecha exacta:** no puedo dar una fecha de inicio del deslizamiento. Solo hay una declaración (2026-10-21) y ninguna serie anterior. Lo máximo que sostienen los documentos es "desde 2026-07-13 hay un hito cerrado sin evidencia".

### Lecciones ancladas a un hecho
- **Hecho:** hito "Ingeniería básica aprobada" cerrado en el cronograma sin acta de recibo; vencía el 2026-07-13. **Efecto:** 102 días después, el verde del 2026-10-21 descansa en un hito que no se puede verificar. Hay un acta de recibo para la licencia (2026-10-18) y ninguna para este hito.
- **Hecho:** el cronograma "v1" fechado 2026-04-12 contiene estados posteriores a abril. **Efecto:** la línea base y el estado viven en el mismo archivo; no se puede reconstruir cuándo cambió cada cosa.
- **Hecho:** cero documentos de julio a septiembre de 2026. **Efecto:** el período en que vencía la ingeniería básica no tiene minutas ni informes, y la historia de esos tres meses no se puede reconstruir.

No atribuyo intención a nada de lo anterior. Esta historia sirve para preguntarle a Gustavo Neira, con fechas, dónde está el acta de la ingeniería básica y si las fechas se mantienen por decisión documentada.

**Qué no sé:** cuándo se editó el cronograma; si existió un informe de avance previo al del 2026-10-21; qué es el "punto 18"; si la prueba hidrostática y los días perdidos entraron en algún cálculo de fechas.

**Siguiente paso, si lo quieres:** llevar esta historia al comité del 2026-10-29, con la pregunta de la ingeniería básica como punto de decisión, o al cierre del proyecto cuando llegue.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los cinco documentos citados; la verificación es de quien lo usa. Las cifras derivadas vienen del cálculo del script y no se redondearon.*
