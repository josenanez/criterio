# Corrida del 2026-10-23 · vendor-tracking

13 proyectos · 39 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `commitment_overdue` | 11 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `silent` | 1 |

Cruce de CT-751 (Integridad y Corrosión): factura FV-1751 cuadra con la bolsa de horas aceptada; taladro 291 días vencido sin evidencia ni cambio; sin dato de vigencia, preaviso ni renovación del contrato.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Sale de:** contrato CT-751 (`00-gobierno/2025-06-26-contrato-ct-751.docx`), acta de recibo de la bolsa de horas (`20-seguimiento/2026-07-18-acta-recibo-ct-751-bolsa-de-horas-de-ingeniería.md`), factura FV-1751 (`20-seguimiento/2026-09-23-factura-ct-751.md`), informe de avance (`20-seguimiento/2026-10-14-informe-avance.md`), comité semanal (`30-reuniones/2026-10-14-comite-semanal.docx`), la ficha `estado/records/PRY-208.json` y la salida de `portafolio.py compute` al 2026-10-23. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez, 2026-10-23).

## Proveedores — PRY-208 Reducción de quema de gas al 2026-10-23

### Integridad y Corrosión S.A.S. — contrato CT-751
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-06-26) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Alquiler del taladro (50.106.103 COP) | 2026-01-05 | `pending`, vencido hace 291 días | Ninguna | No (la factura cubre un solo monto) |
| Bolsa de horas de ingeniería (50.106.103 COP) | 2026-07-10 | `accepted` (recibida el 2026-07-18, 8 días después de lo comprometido) | Acta de recibo firmada por Liliana Torres, 2026-07-18 | Sí, FV-1751 del 2026-09-23 por 50.106.103 COP |

Del script: 2 entregables, 1 aceptado, 1 tardío, 0 aceptados sin evidencia, facturado 50.106.103 COP, monto aceptado 50.106.103 COP. No se levantó `vendor_invoiced_without_delivery`.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura vs. aceptado | Cada entregable se factura contra acta de recibo firmada por el gerente | Lo facturado (50.106.103) es igual a lo aceptado (50.106.103): cuadra en monto con la bolsa de horas | contrato CT-751; acta 2026-07-18; FV-1751 |
| Concepto de la factura | — | FV-1751 dice «Entregables del contrato CT-751», en plural y sin nombrar cuál. El monto coincide con la bolsa de horas, pero también con el del taladro, porque ambos valen lo mismo. Solo el acta de recibo permite atribuirla a la bolsa de horas | FV-1751 |
| Informe de avance vs. taladro | Alquiler del taladro era para 2026-01-05 | El informe del 2026-10-14 declara que «se reprogramó la movilización del taladro por disponibilidad del contratista». No hay solicitud de cambio ni nueva fecha contractual; el proyecto declara **verde** | informe de avance; contrato |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Ninguno de los entregables de CT-751 está marcado como entregado o aceptado sin acta | — | — |

El taladro figura `pendiente` en el contrato y en la ficha, y no se afirma entregado.

### Compromisos del proveedor vencidos
Ninguno atribuible al proveedor. El único compromiso abierto del comité del 2026-10-14 es de Ricardo Salas, «Entregar el punto 12», para el 2026-10-19, vencido hace 4 días. Ningún documento dice que Ricardo Salas sea del proveedor, así que no se cuenta aquí.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-751. El contrato no los trae, por lo que no se puede decir si algún preaviso vence antes del cierre del proyecto (2026-11-23).
- Total contractual de CT-751. Solo constan los dos montos de los entregables (100.212.206 COP entre ambos).
- Si el taladro tiene nueva fecha acordada con el proveedor. No hay documento que lo diga.
- Si el proyecto tiene otros proveedores. Solo hay uno en la ficha.

### Después
- El taladro lleva 291 días vencido, sin cambio aprobado. Hay que decidir si se lleva a comité, porque la fecha de fin del proyecto (2026-11-23) no se ha movido.
- No hay entregables facturados sin evidencia, así que no hay nada que escalar por facturación.
- Esto es un hallazgo del proyecto, no del proveedor: el informe de avance declara verde con cuatro señales sin explicar: compromiso vencido, hitos «cumplidos» sin evidencia (Ingeniería básica, Licencia ambiental y Montaje de facilidades), avance de 51% frente a 80–100% que sostiene el plan, y el taladro tardío.

**Pie de rigor:** las cifras salen de `portafolio.py compute`. Los textos del contrato y del comité se leyeron directamente de los .docx. Criterio produce borradores de trabajo, no decisiones ni asesoría. La verificación contra los documentos citados es de quien lo lea.
