Documentos de los que sale: acta de constitución de PRY-202 (2025-09-14) e informe de avance de PRY-202 (2026-10-17). Cifras derivadas: salida de `portafolio.py compute`, al 2026-10-23.

## Presupuesto — PRY-202 Gasoducto de interconexión al 2026-10-23
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 4.200.000.000 | 100 | 00-gobierno/2025-09-14-acta-constitucion.md | 2025-09-14 |
| Comprometido | 3.240.656.534 | 77.2 | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Ejecutado | 1.691.183.267 | 40.3 | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Proyección al cierre (declaración del gerente, no dato duro) | 4.804.009.661 | 14.4 por encima del aprobado | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |

**Disponible real** (aprobado menos comprometido): COP 959.343.466

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 4.200.000.000 | 4.200.000.000 | 0 |

Replanificaciones de presupuesto: 0 (ninguna solicitud de cambio registrada). La línea base de plazo tampoco se ha movido: fin 2026-06-05, versión 1.

### Ejecución frente a avance
Ejecutado 40.3% · Hitos cumplidos 4 de 4 (declarados), solo 1 con evidencia · Avance declarado 75% (informe del 2026-10-17).
Lectura: las dos medidas del avance no se parecen. El plan sustenta 100% (4 de 4 hitos) y el gerente declara 75%, una brecha de 25.0 puntos. Con 40.3% ejecutado, el gasto no confirma ninguna de las dos lecturas. Tres hitos figuran cumplidos sin acta de recibo: Licencia ambiental otorgada (vencía 2026-01-29), Pozos perforados (2026-04-02) y Montaje de facilidades (2026-06-05). El único con evidencia es Ingeniería básica aprobada (acta de recibo del 2026-10-10).

### Alertas
- **Proyección excede el aprobado:** 14.4% sobre los 4.200.000.000, por encima del umbral de 10%. Es una declaración, con fuente y fecha 2026-10-17; no es más vieja que el último movimiento de presupuesto, porque no hay ninguno.
- **Comprometido:** 77.2%, por debajo del umbral de 90%. No hay alerta de comprometido, pero la holgura real es el disponible de arriba, no lo que queda sin ejecutar del aprobado.
- **Ejecución desalineada del avance:** brecha de 25.0 puntos entre avance declarado y lo que sustenta el plan, y tres hitos cumplidos sin evidencia (267, 204 y 140 días después de su fecha).
- **Fuera del presupuesto, pero relevante:** compromiso vencido hace 18 días, Rubén Cárdenas, "Entregar el punto 24" (vencía 2026-10-05; acta del comité del 2026-10-21).

### Sin dato
- Proveedores y contratos: ninguno registrado para PRY-202, así que no hay desglose del comprometido por proveedor.
- Desglose del comprometido y del ejecutado por rubro: no está en los documentos leídos.
- Cifras sin respaldo de evidencia: las tres de seguimiento (comprometido, ejecutado, proyección) vienen de un informe de avance, es decir, de una declaración; ningún documento contable las respalda (evidencia: 0, declaraciones: 3).
- Ficha: faltan autoridad y fase; los campos de identidad y el aprobado tienen 13 meses de antigüedad (umbral 12), porque todos salen del acta de 2025-09-14.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio con `/criterio-portfolio:change-control`. El comprometido no está cerca del tope, así que no ofrezco el detalle por proveedor.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra viene de los documentos citados y de `portafolio.py compute`; la verificación es suya. No sé lo que se habló fuera de esos documentos.
