## Listo — Portafolio Oil & Gas (prueba)

**Miré:** 66 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md (28), .docx (15), .pdf (11), .csv (3), .xlsx (3), .xml (4), .json (1), .txt (1) · más reciente: 2026-10-22
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo, el 2026-10-29 (fecha propuesta por mí: tus carpetas traen actas de comité semanal, pero ninguna dice cuándo es el siguiente)
**En:** presentación (el valor por defecto)
**Términos:** aceptados para la versión 0.8.0 (términos 1.2) por José Francisco Ñáñez, 2026-10-23 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 fe830b9a4eee0bc9…

La carpeta quedó marcada con `_CRITERIO_PORTAFOLIO.txt`. Preguntas hechas: ninguna; todas las respuestas fueron el valor sugerido.

### Probé con tres proyectos

Los tres con documentación más reciente: PRY-200 y PRY-204 (2026-10-22) y PRY-202 (2026-10-21, empate con otros dos).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Campaña de perforación del bloque sur | 16 | Gerente Carlos Peña, patrocinador Paula Céspedes, 3.300 M COP aprobados. El gerente declara verde y 84 % (informe del 2026-10-19). Cierre vigente: 2026-10-06 (ya pasó). 26 compromisos extraídos de 6 comités y de las notas del 2026-10-22. | Producto (el acta dice «No aplica»), facultad del gerente, etapa. Acta de recibo de 2 de los 4 hitos. |
| PRY-204 Integridad de ductos | 4 | Gerente Javier Hoyos, patrocinador Carlos Peña, 2.400 M COP. Declara verde y 35 %. Cierre: 2027-01-13. Un compromiso abierto (Ricardo Salas, punto 12, 2026-11-10). | Producto, facultad, etapa. Acta de recibo de los 2 hitos ya cerrados. |
| PRY-202 Gasoducto de interconexión | 5 | Gerente Natalia Ospina, patrocinador Rubén Cárdenas, 4.200 M COP, producto «transporte de gas». Declara amarillo y 75 %. Cierre: 2026-06-05 (ya pasó). | Facultad, etapa. Acta de recibo de 3 de los 4 hitos. |

### Lo que encontré (lo que levantó el cálculo)

**PRY-200 — declara verde y no se sostiene** (`declared_vs_evidence`):
- Avance declarado 84 % con los cuatro hitos cerrados en el cronograma, que respaldarían 100 % (`progress_vs_plan`, 16 puntos).
- Dos hitos declarados cerrados sin acta que lo pruebe: «Licencia ambiental otorgada» (2026-04-19) y «Montaje de facilidades» (2026-10-06) (`milestone_met_without_evidence`).
- 8 compromisos vencidos sin evidencia de entrega (`commitment_overdue`). El más viejo: «Confirmar la fecha 7», Beatriz Cuéllar, vencido desde el 2026-09-25. En cinco compromisos (puntos 5, 7, 8, 10 y 15) la persona dijo en el comité que ya entregó y nadie presentó acta; dos de ellos (5 y 7) figuran vencidos.
- Ricardo Salas ha reprogramado «Enviar el documento 1» 6 veces (de 2026-09-30 a 2027-01-15) y «Cerrar la prueba 2» 5 veces (de 2026-09-15 a 2026-11-29) (`commitment_rescheduled`).
- 3 compromisos sin fecha (`commitment_undated`): puntos 8 y 16, y el ajuste del presupuesto («la otra semana»).
- En las notas del 2026-10-22 se comentó que el proveedor podría no llegar con el equipo completo; nadie lo anotó como riesgo. Lo dejé en la ficha como riesgo sin dueño ni fecha.

**PRY-204 — declara verde y no se sostiene** (`declared_vs_evidence`):
- Costo: la proyección al cierre (2.893 M) supera lo aprobado (2.400 M) en 20,5 % (`variance_cost`).
- Avance declarado 35 %; el cronograma respalda entre 50 % y 75 % (`progress_vs_plan`, 15 puntos; este proyecto va por debajo de lo que dice el plan).
- Dos hitos cerrados sin acta: «Ingeniería básica aprobada» (2026-06-13) y «Licencia ambiental otorgada» (2026-08-23).

**PRY-202 — amarillo declarado** (el cálculo no lo contradice, pero hay más):
- La proyección (4.804 M) supera lo aprobado (4.200 M) en 14,4 % (`variance_cost`).
- La fecha de cierre (2026-06-05) pasó hace 140 días y el proyecto declara 75 %; los cuatro hitos figuran cerrados y respaldarían 100 % (`progress_vs_plan`, 25 puntos).
- Tres hitos cerrados sin acta: licencia ambiental, pozos perforados y montaje de facilidades (`milestone_met_without_evidence`). La única acta de recibo (ingeniería básica) está fechada 2026-10-10, once meses después del hito.
- Un compromiso (Rubén Cárdenas, punto 24) vencido hace 18 días; la minuta del 2026-10-21 lo lista con fecha 2026-10-05, anterior a la propia reunión.

**Los tres:** ninguna ficha trae la facultad del gerente (hasta qué monto decide sin subir a comité), y en PRY-200 y PRY-204 el acta dice «Producto asociado: No aplica». En PRY-200 y PRY-202 los datos del acta tienen más de 12 meses sin confirmación posterior.

La ficha que publicó el gerente de PRY-200 (`ficha-pm.json`) quedó guardada aparte, sin mezclar con mi lectura. Los compromisos los saqué yo de las minutas.

### El portafolio completo
10 proyectos más (PRY-199, 201, 203, 205, 206, 207, 208, 209, 210, 211) · aproximadamente 15 minutos, en dos lotes, uno tras otro. Son 55 documentos por leer.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- **Cuatro cronogramas en .xml** (PRY-204, 206, 209, 210) no se leen sin instalar algo. Yo pude leer el de PRY-204 como texto; no quedan en el sello de lo leído, así que si cambian no lo detectaré solo.
- **Tres proyectos solo tienen acta e informe, sin cronograma ni reuniones** (PRY-201, 203, 207): no hay contra qué contrastar el avance que declaran.
- **Actas de recibo que no están:** siete hitos declarados cerrados en estos tres proyectos y sin acta (dos en PRY-200, dos en PRY-204, tres en PRY-202).
- **Ningún acta dice hasta dónde decide el gerente** sin subir a comité (monto y cambios de alcance).
- **Notas fuera de lugar:** `2026-10-22-notas-reunion.txt` está en la raíz de PRY-200 y no en `30-reuniones/`. Está leída; solo conviene que quede donde se espera.
- **Una sola versión de cronograma (v1) en todos los proyectos:** si hubo replanificaciones, no están en la carpeta, y el cálculo no puede medir atraso contra una línea base distinta de la original.
- Estructura recomendada (`document-intake`): una carpeta por proyecto con `00-gobierno`, `10-plan`, `20-seguimiento`, `30-reuniones`. Ya la tienes. No moví ni renombré nada.

Dónde quedó todo: configuración en `.criterio/portafolio/config.json`; fichas en `estado/records/`; informes irán a `reportes/`. Siguiente paso: correr el portafolio completo con `/portfolio-scan`. Si tienes gerentes de proyecto, puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
