## Diagnóstico · PRY-208 · Reducción de quema de gas · 2026-10-23

**Leí:** 8 documentos · de 2025-06-23 a 2026-10-15 · formatos: docx (3), md (4), csv (1). Busqué además menciones de PRY-208, "quema de gas" y CT-751 en el resto de `documentos/` (otros proyectos y productos): no aparece en ningún otro documento.
**No pude leer:** nada quedó sin leer. Lo que no hay en la carpeta: ver el último bloque.

### Dictamen
**Sostenido:** 7 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 3 (17 afirmaciones verificables contra documentos; los riesgos e incidencias del informe se tratan aparte, en "Lo que se dijo y nadie registró").

Desde esta carpeta se puede afirmar quién gobierna el proyecto, el presupuesto aprobado, que se recibió la bolsa de horas de ingeniería de CT-751 y se facturó solo ese entregable, y que se recibió el hito "Pozos perforados" el 2026-10-15. No se puede afirmar que el proyecto esté en verde: el informe del 2026-10-14 (la única fuente del estado, el 51 % y las cifras de dinero) queda contradicho por el cronograma y por su propio texto, y tres hitos "cerrados" y las tres cifras de dinero no tienen ningún documento detrás. No hay autoridad del gerente declarada.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Jorge Medina | acta de constitución, 2025-06-23 |
| Gerente | Liliana Torres | acta de constitución, 2025-06-23 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente en tiempo, costo o alcance | acta de constitución, 2025-06-23 |
| Comité | Comité de Tecnología (aprobó el presupuesto el 2025-06-23); sesión del 2026-10-14 con Liliana Torres y Jorge Medina; temas "Avance" y "Compromisos"; no registra decisiones | acta, 2025-06-23; comité semanal, 2026-10-14 |

Observaciones: sin autoridad declarada no hay desviación aprobada, solo fechas que alguien escribió. El acta no muestra firmas en el texto leído. El alcance son tres "Componente 1/2/3" sin descripción y el criterio de éxito ("Reducción de quema de gas en producción y medido") no trae métrica ni meta.

### Contra el plan
- **Línea base original:** v1, aprobada 2025-06-23 con el acta; cierre 2026-11-23 (`2025-06-23-cronograma-v1.csv`).
- **Vigente:** igual a la original en los cinco hitos. Replanificaciones: 0. Solicitudes de cambio: 0. Desviación contra la original y contra la vigente: 0 días (script).
- Esa desviación en cero convive con lo que el propio informe del 2026-10-14 cuenta: movilización del taladro reprogramada, dos semanas perdidas por rotación del supervisor de campo y prueba hidrostática repetida. Nada de eso quedó en una línea base nueva ni en un control de cambios.
- "Pozos perforados": línea base y vigente 2026-05-03; el acta de recibo es del 2026-10-15.
- Hito pendiente: "Primer crudo o gas", 2026-11-23.

### Hitos vencidos sin evidencia
Marcados "cerrado" en el cronograma; ningún documento de la carpeta los respalda.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-10-12 | 376 | Acta de recibo o de aprobación de la ingeniería básica |
| Licencia ambiental otorgada | 2026-01-22 | 274 | Resolución o acta de la licencia ambiental |
| Montaje de facilidades | 2026-08-13 | 71 | Acta de recibo del montaje |

Hitos vencidos sin cerrar: ninguno. "Pozos perforados" sí tiene acta (2026-10-15).

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 COP (acta) | 622.315.470 (77,8 %) | 179.592.613 (22,4 %) | 774.566.698 (−3,2 % frente al aprobado) | 177.684.530 |

- Comprometido, ejecutado y proyección salen únicamente del informe de avance (declaración). Lo comprobable en la carpeta: el contrato CT-751 con dos entregables de 50.106.103 COP cada uno, y una factura FV-1751 de 50.106.103 COP radicada el 2026-09-23. Del resto del comprometido y del ejecutado no hay documento.
- La factura corresponde al único entregable recibido (bolsa de horas, acta del 2026-07-18, posterior a la fecha comprometida del 2026-07-10). La condición de pago del contrato (acta firmada por el gerente) se cumple para ese entregable.
- Umbral de comprometido (90 %): no alcanzado.

### Lo que se dijo y nadie registró
- **Riesgos del informe, sin probabilidad, impacto, dueño ni fecha:** cambio en la licencia ambiental que puede mover el alcance; bloqueos de la comunidad en la vía de acceso.
- **Incidencias del informe, sin dueño ni desde cuándo:** movilización del taladro reprogramada por el contratista; dos semanas perdidas por rotación del supervisor de campo; prueba hidrostática que no alcanzó la presión pactada y se repite.
- **Dependencias:** el acta dice "Ninguna declarada"; los bloqueos de la comunidad y la licencia ambiental son dependencias externas que el informe sí menciona.
- **Compromiso vencido:** Ricardo Salas, "Entregar el punto 12", para el 2026-10-19 (comité del 2026-10-14); 4 días vencido, sin evidencia de entrega. Ricardo Salas no figura entre los asistentes de esa sesión y "el punto 12" no está definido en ningún documento.
- **Entregable de proveedor atrasado:** "Alquiler del taladro" (CT-751), comprometido para el 2026-01-05, sigue pendiente, 291 días.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado **verde** | Informe 2026-10-14: "Verde" | El mismo informe (taladro reprogramado, prueba hidrostática fallida, dos semanas perdidas), más compromiso vencido, hitos sin evidencia y entregable de proveedor atrasado: 4 señales que el informe no recoge |
| Avance **51 %** | Informe 2026-10-14: 51 % | Cronograma: 4 de 5 hitos cerrados, lo que sostiene entre 80 y 100 %; diferencia de 29 puntos (script). La contradicción es de los dos documentos entre sí: no se sabe cuál está equivocado |
| **Sin desviación**: fechas vigentes = línea base | Cronograma: "Pozos perforados" vigente 2026-05-03; ningún cambio ni replanificación | Acta de recibo de "Pozos perforados" del 2026-10-15; informe del 2026-10-14 con movilización del taladro reprogramada; CT-751 con "Alquiler del taladro" pendiente desde 2026-01-05 (dudoso que los pozos estén perforados sin taladro, pero ningún documento lo explica) |

### Sin sustento
1. Ingeniería básica aprobada, cerrada (sin acta).
2. Licencia ambiental otorgada, cerrada (sin documento; además el informe habla de un cambio en la licencia).
3. Montaje de facilidades, cerrado (sin acta).
4. Primer crudo o gas el 2026-11-23: nada respalda que se alcance con una prueba hidrostática por repetir.
5. Comprometido 622.315.470 COP: solo se ven en CT-751 dos entregables de 50.106.103 COP cada uno; el resto no tiene documento (la suma no la da el script, no se escribe).
6. Ejecutado 179.592.613 COP: solo hay una factura visible, de 50.106.103 COP.
7. Proyección al cierre 774.566.698 COP: sin cálculo ni soporte, y menor que el aprobado pese a una prueba por repetir.

### Lo que esta carpeta no permite saber
- **Si el gerente podía mover fechas o gasto:** sin autoridad declarada, ningún cambio de plan tiene aprobación verificable.
- **Cuánto se atrasó realmente:** hay un solo cronograma, sin versiones; la desviación real no es calculable.
- **Si la ingeniería básica, la licencia y el montaje existen:** faltan sus actas o resoluciones.
- **Cuánto se ha gastado de verdad:** falta el detalle del comprometido y del ejecutado (órdenes, contratos distintos de CT-751, facturas, extracto del ERP).
- **Qué decidió el comité:** el acta del 2026-10-14 solo lista temas y un compromiso.
- **Si el proyecto está en silencio:** no lo está (último documento 2026-10-15, 8 días), pero el único informe de avance es de quien está siendo evaluado.
- **Fase del proyecto:** no declarada en ningún documento.
- **Qué es "el punto 12":** sin definición.

### Pie de rigor
Cada dato sale de los 8 documentos citados por nombre; las cifras derivadas (días, porcentajes, brecha, disponible real) se copiaron de la salida de `compute` del 2026-10-23, no se recalcularon a mano. Lo declarado (informe del gerente) y lo probado (actas, contrato, factura) se separan arriba. No se recomienda detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. La verificación contra los originales es de quien lea esto.

**Siguientes pasos que puedo preparar:** el punto de comité con la lista de lo que falta, y las contradicciones llevadas a la gerente como preguntas, una por una.
