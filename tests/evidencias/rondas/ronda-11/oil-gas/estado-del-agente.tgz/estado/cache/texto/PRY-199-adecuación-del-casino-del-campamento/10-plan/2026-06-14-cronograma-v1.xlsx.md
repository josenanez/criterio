<!-- origen: PRY-199-adecuación-del-casino-del-campamento/10-plan/2026-06-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-10-11 | 2026-10-11 | cerrado
Licencia ambiental otorgada | 2027-01-28 | 2027-01-28 | en curso
Pozos perforados | 2027-05-17 | 2027-05-17 | en curso
Montaje de facilidades | 2027-09-03 | 2027-09-03 | en curso
Primer crudo o gas | 2027-12-21 | 2027-12-21 | en curso
