<!-- origen: PRY-201-facilidades-de-producción-temprana/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Facilidades de producción temprana
Código: PRY-201
Fecha de corte: 2026-10-19
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 71%

Lo que pasó en el periodo
- La prueba hidrostática no alcanzó la presión pactada y se repite

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 473.553.018
Ejecutado 266.640.706
Proyección al cierre 1.114.843.551

Riesgos abiertos
- Precio del crudo por debajo del supuesto del caso de negocio
- Bloqueos de la comunidad en la vía de acceso
