<!-- origen: PRY-203-recobro-mejorado-con-agua/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Recobro mejorado con agua
Código: PRY-203
Fecha de corte: 2026-10-20
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 48%

Lo que pasó en el periodo
- Se reprogramó la movilización del taladro por disponibilidad del contratista

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 11.973.408.702
Ejecutado 9.451.590.301
Proyección al cierre 18.832.500.154

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio en la licencia ambiental que puede mover el alcance
