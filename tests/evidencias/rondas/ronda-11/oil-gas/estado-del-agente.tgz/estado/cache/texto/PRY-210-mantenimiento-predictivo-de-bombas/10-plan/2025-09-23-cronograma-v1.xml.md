<!-- origen: PRY-210-mantenimiento-predictivo-de-bombas/10-plan/2025-09-23-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2025-12-25 | 2025-12-25 | 2025-12-25 | 100% | hito | — | — |
| 2 | 2 | Licencia ambiental otorgada | 2026-03-18 | 2026-03-18 | 2026-03-18 | 100% | hito | 1FS | — |
| 3 | 3 | Pozos perforados | 2026-06-10 | 2026-06-10 | 2026-06-10 | 100% | hito | 2FS | — |
| 4 | 4 | Montaje de facilidades | 2026-09-01 | 2026-09-01 | 2026-09-01 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-12-25 | 2025-12-25 | cerrado |
| Licencia ambiental otorgada | 2026-03-18 | 2026-03-18 | cerrado |
| Pozos perforados | 2026-06-10 | 2026-06-10 | cerrado |
| Montaje de facilidades | 2026-09-01 | 2026-09-01 | cerrado |
