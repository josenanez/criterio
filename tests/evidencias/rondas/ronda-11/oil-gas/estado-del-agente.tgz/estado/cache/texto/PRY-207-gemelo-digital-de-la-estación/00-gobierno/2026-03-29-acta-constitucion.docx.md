<!-- origen: PRY-207-gemelo-digital-de-la-estación/00-gobierno/2026-03-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la estación

Código: PRY-207

Área dueña: Ambiental

Patrocinador: Andrés Lozano

Gerente de proyecto: María Restrepo

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2026-03-29

Objetivo del negocio

Entregar gemelo digital de la estación para Ambiental.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Operaciones el 2026-03-29.

Fechas comprometidas

Fecha

Inicio

2026-04-08

Cierre

2027-06-22

Criterio de éxito

Gemelo digital de la estación en producción y medido.

Dependencias declaradas

• Ninguna declarada
