<!-- origen: PRY-205-monitoreo-remoto-de-pozos/00-gobierno/2026-04-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Monitoreo remoto de pozos

**Código:** PRY-205
**Área dueña:** HSE
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de HSE
**Producto asociado:** monitoreo de pozos
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar monitoreo remoto de pozos para HSE.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de HSE el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2027-06-08 |

## Criterio de éxito

Monitoreo remoto de pozos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
