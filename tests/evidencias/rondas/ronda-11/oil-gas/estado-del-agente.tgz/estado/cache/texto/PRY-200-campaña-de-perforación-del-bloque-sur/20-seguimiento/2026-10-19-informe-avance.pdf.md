<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Campaña de perforación del bloque sur
Código: PRY-200
Fecha de corte: 2026-10-19
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 84%

Lo que pasó en el periodo
- Un bloqueo de la comunidad detuvo el transporte de equipos ocho días

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.025.532.379
Ejecutado 537.252.237
Proyección al cierre 3.453.463.040

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
