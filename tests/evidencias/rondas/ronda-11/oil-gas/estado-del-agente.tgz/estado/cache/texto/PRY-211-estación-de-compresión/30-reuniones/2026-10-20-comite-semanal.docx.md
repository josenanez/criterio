<!-- origen: PRY-211-estación-de-compresión/30-reuniones/2026-10-20-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Integridad · Estación de compresión

Fecha: 2026-10-20

Asistentes: Andrés Lozano, Paula Céspedes

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Gustavo Neira

Entregar el punto 3

2026-11-19
