<!-- origen: PRY-204-integridad-de-ductos/00-gobierno/2026-03-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Integridad de ductos

Código: PRY-204

Área dueña: Producción

Patrocinador: Carlos Peña

Gerente de proyecto: Javier Hoyos

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2026-03-24

Objetivo del negocio

Entregar integridad de ductos para Producción.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Operaciones el 2026-03-24.

Fechas comprometidas

Fecha

Inicio

2026-04-03

Cierre

2027-01-13

Criterio de éxito

Integridad de ductos en producción y medido.

Dependencias declaradas

• Ninguna declarada
