<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/2026-10-22-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión campaña de perforación del bloque sur — 2026-10-22
estuvieron: Beatriz Cuéllar, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

- Ricardo Salas dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 15/01/2027
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
