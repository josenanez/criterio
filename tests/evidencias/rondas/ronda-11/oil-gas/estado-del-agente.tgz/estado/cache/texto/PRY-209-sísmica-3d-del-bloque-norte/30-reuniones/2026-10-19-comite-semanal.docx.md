<!-- origen: PRY-209-sísmica-3d-del-bloque-norte/30-reuniones/2026-10-19-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Inversiones · Sísmica 3D del bloque norte

Fecha: 2026-10-19

Asistentes: Paula Céspedes, Carlos Peña

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Mauricio Pérez

Entregar el punto 19

2026-11-02

María Restrepo

Entregar el punto 6

2026-10-03
