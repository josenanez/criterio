<!-- origen: PRY-205-monitoreo-remoto-de-pozos/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de HSE · Monitoreo remoto de pozos

**Fecha:** 2026-10-09
**Asistentes:** Gustavo Neira, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 18 | 2026-11-11 |
