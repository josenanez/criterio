<!-- origen: PRY-199-adecuación-del-casino-del-campamento/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Adecuación del casino del campamento
Código: PRY-199
Fecha de corte: 2026-10-20
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Se reprogramó la movilización del taladro por disponibilidad del contratista
- La prueba hidrostática no alcanzó la presión pactada y se repite

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
