<!-- origen: PRY-210-mantenimiento-predictivo-de-bombas/20-seguimiento/2026-10-02-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Mantenimiento predictivo de bombas
Código: PRY-210
Fecha de corte: 2026-10-02
Gerente: Paula Céspedes

Estado declarado
Verde
Avance reportado: 49%

Lo que pasó en el periodo
- Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior
- Se ajustó el plan de perforación con la geología del pozo vecino
- La prueba hidrostática no alcanzó la presión pactada y se repite

Presupuesto
COP
Aprobado 800.000.000
Comprometido 400.319.666
Ejecutado 317.173.964
Proyección al cierre 778.806.214

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Bloqueos de la comunidad en la vía de acceso
