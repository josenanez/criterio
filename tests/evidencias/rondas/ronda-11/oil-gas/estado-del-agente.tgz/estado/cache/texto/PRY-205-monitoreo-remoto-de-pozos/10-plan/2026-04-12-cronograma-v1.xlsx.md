<!-- origen: PRY-205-monitoreo-remoto-de-pozos/10-plan/2026-04-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-07-13 | 2026-07-13 | cerrado
Licencia ambiental otorgada | 2026-10-04 | 2026-10-04 | cerrado
Pozos perforados | 2026-12-25 | 2026-12-25 | en curso
Montaje de facilidades | 2027-03-18 | 2027-03-18 | en curso
Primer crudo o gas | 2027-06-08 | 2027-06-08 | en curso
