<!-- origen: PRY-204-integridad-de-ductos/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Integridad de ductos
Código: PRY-204
Fecha de corte: 2026-10-22
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 35%

Lo que pasó en el periodo
- Se reprogramó la movilización del taladro por disponibilidad del contratista

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.886.527.921
Ejecutado 761.272.520
Proyección al cierre 2.893.029.654

Riesgos abiertos
- Precio del crudo por debajo del supuesto del caso de negocio
