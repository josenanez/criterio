<!-- origen: PRY-202-gasoducto-de-interconexión/10-plan/2025-09-14-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-11-26,2025-11-26,cerrado
Licencia ambiental otorgada,2026-01-29,2026-01-29,cerrado
Pozos perforados,2026-04-02,2026-04-02,cerrado
Montaje de facilidades,2026-06-05,2026-06-05,cerrado
