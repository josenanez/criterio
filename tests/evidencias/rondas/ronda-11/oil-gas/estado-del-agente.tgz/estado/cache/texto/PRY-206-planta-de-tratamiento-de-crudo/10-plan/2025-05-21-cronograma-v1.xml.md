<!-- origen: PRY-206-planta-de-tratamiento-de-crudo/10-plan/2025-05-21-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2025-08-10 | 2025-08-10 | 2025-08-10 | 100% | hito | — | — |
| 2 | 2 | Licencia ambiental otorgada | 2025-10-21 | 2025-10-21 | 2025-10-21 | 100% | hito | 1FS | — |
| 3 | 3 | Pozos perforados | 2025-12-31 | 2025-12-31 | 2025-12-31 | 100% | hito | 2FS | — |
| 4 | 4 | Montaje de facilidades | 2026-03-13 | 2026-03-13 | 2026-03-13 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-08-10 | 2025-08-10 | cerrado |
| Licencia ambiental otorgada | 2025-10-21 | 2025-10-21 | cerrado |
| Pozos perforados | 2025-12-31 | 2025-12-31 | cerrado |
| Montaje de facilidades | 2026-03-13 | 2026-03-13 | cerrado |
