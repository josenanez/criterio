<!-- origen: PRY-206-planta-de-tratamiento-de-crudo/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de crudo
Código: PRY-206
Fecha de corte: 2026-10-20
Gerente: Elena Duarte

Estado declarado
Rojo
Avance reportado: 93%

Lo que pasó en el periodo
- Se acordó con integridad cómo se inspeccionan las soldaduras
- Se reprogramó la movilización del taladro por disponibilidad del contratista
- Se levantó un hallazgo de seguridad en espacios confinados

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.685.859.507
Ejecutado 4.005.821.807
Proyección al cierre 6.804.436.813

Riesgos abiertos
- Bloqueos de la comunidad en la vía de acceso
- El proveedor no ha confirmado la fecha de la última entrega
