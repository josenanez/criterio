<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/10-plan/2025-10-21-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-01-24,2026-01-24,cerrado
Licencia ambiental otorgada,2026-04-19,2026-04-19,cerrado
Pozos perforados,2026-07-13,2026-07-13,cerrado
Montaje de facilidades,2026-10-06,2026-10-06,cerrado
