<!-- origen: PRY-208-reducción-de-quema-de-gas/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Reducción de quema de gas

**Código:** PRY-208
**Fecha de corte:** 2026-10-14
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **51%**

## Lo que pasó en el periodo

- Se reprogramó la movilización del taladro por disponibilidad del contratista
- El equipo perdió dos semanas por rotación del supervisor de campo
- La prueba hidrostática no alcanzó la presión pactada y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 622.315.470 |
| Ejecutado | 179.592.613 |
| Proyección al cierre | 774.566.698 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueos de la comunidad en la vía de acceso
