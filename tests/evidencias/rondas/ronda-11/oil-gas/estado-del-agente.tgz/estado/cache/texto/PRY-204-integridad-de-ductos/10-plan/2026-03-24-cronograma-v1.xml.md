<!-- origen: PRY-204-integridad-de-ductos/10-plan/2026-03-24-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-06-13 | 2026-06-13 | 2026-06-13 | 100% | hito | — | — |
| 2 | 2 | Licencia ambiental otorgada | 2026-08-23 | 2026-08-23 | 2026-08-23 | 100% | hito | 1FS | — |
| 3 | 3 | Pozos perforados | 2026-11-03 | 2026-11-03 | 2026-11-03 | 50% | hito | 2FS | — |
| 4 | 4 | Montaje de facilidades | 2027-01-13 | 2027-01-13 | 2027-01-13 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-06-13 | 2026-06-13 | cerrado |
| Licencia ambiental otorgada | 2026-08-23 | 2026-08-23 | cerrado |
| Pozos perforados | 2026-11-03 | 2026-11-03 | en curso |
| Montaje de facilidades | 2027-01-13 | 2027-01-13 | en curso |
