<!-- origen: PRY-211-estación-de-compresión/10-plan/2026-01-26-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-04-19 | 2026-04-19 | cerrado
Licencia ambiental otorgada | 2026-07-02 | 2026-07-02 | cerrado
Pozos perforados | 2026-09-13 | 2026-09-13 | cerrado
Montaje de facilidades | 2026-11-26 | 2026-11-26 | en curso
Primer crudo o gas | 2027-02-08 | 2027-02-08 | en curso
