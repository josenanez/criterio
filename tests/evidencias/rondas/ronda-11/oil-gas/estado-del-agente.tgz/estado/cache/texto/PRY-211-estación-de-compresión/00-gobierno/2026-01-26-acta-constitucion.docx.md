<!-- origen: PRY-211-estación-de-compresión/00-gobierno/2026-01-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Estación de compresión

Código: PRY-211

Área dueña: Relacionamiento con comunidades

Patrocinador: Paula Céspedes

Gerente de proyecto: Andrés Lozano

Comité: Comité de Integridad

Producto asociado: No aplica

Fecha de aprobación: 2026-01-26

Objetivo del negocio

Entregar estación de compresión para Relacionamiento con comunidades.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Integridad el 2026-01-26.

Fechas comprometidas

Fecha

Inicio

2026-02-05

Cierre

2027-02-08

Criterio de éxito

Estación de compresión en producción y medido.

Dependencias declaradas

• Ninguna declarada
