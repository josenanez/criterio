<!-- origen: PRY-203-recobro-mejorado-con-agua/00-gobierno/2026-06-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Recobro mejorado con agua

Código: PRY-203

Área dueña: HSE

Patrocinador: Sandra Gil

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Integridad

Producto asociado: No aplica

Fecha de aprobación: 2026-06-25

Objetivo del negocio

Entregar recobro mejorado con agua para HSE.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Integridad el 2026-06-25.

Fechas comprometidas

Fecha

Inicio

2026-07-05

Cierre

2027-02-01

Criterio de éxito

Recobro mejorado con agua en producción y medido.

Dependencias declaradas

• Ninguna declarada
