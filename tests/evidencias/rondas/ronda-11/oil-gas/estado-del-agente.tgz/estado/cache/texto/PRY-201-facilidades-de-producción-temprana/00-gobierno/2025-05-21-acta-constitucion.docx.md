<!-- origen: PRY-201-facilidades-de-producción-temprana/00-gobierno/2025-05-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Facilidades de producción temprana

Código: PRY-201

Área dueña: Tecnología

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: Carlos Peña

Comité: Comité de Integridad

Producto asociado: No aplica

Fecha de aprobación: 2025-05-21

Objetivo del negocio

Entregar facilidades de producción temprana para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Integridad el 2025-05-21.

Fechas comprometidas

Fecha

Inicio

2025-05-31

Cierre

2026-04-24

Criterio de éxito

Facilidades de producción temprana en producción y medido.

Dependencias declaradas

• Ninguna declarada
