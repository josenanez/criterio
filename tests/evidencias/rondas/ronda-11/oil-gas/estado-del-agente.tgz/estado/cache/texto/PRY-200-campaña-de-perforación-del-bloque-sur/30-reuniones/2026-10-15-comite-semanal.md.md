<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-10-15
**Asistentes:** Beatriz Cuéllar, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2027-01-01 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-29 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-24 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-25 |
| María Restrepo | Enviar el documento 9 | 2026-10-21 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-05 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 |
| Rubén Cárdenas | Entregar el punto 16 | por definir |
| Laura Vélez | Enviar el documento 17 | 2026-10-30 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-22 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-23 |
| Laura Vélez | Validar el ambiente 20 | 2026-10-21 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-21 |
| Beatriz Cuéllar | Actualizar la matriz 22 | 2026-11-12 |
| Beatriz Cuéllar | Confirmar la fecha 23 | 2026-10-31 |
| Paula Céspedes | Entregar el punto 24 | 2026-11-07 |

## Cerrados en esta reunión

- Validar el ambiente 12 (Natalia Ospina): recibido, acta de recibo del 2026-10-15.

## Lo que se dijo

- Camilo Beltrán dice que ya entregó «entregar el punto 8». No se presentó acta.
