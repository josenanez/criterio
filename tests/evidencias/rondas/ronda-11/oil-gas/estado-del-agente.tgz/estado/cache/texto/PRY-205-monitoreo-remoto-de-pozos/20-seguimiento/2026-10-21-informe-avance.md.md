<!-- origen: PRY-205-monitoreo-remoto-de-pozos/20-seguimiento/2026-10-21-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Monitoreo remoto de pozos

**Código:** PRY-205
**Fecha de corte:** 2026-10-21
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **53%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación del supervisor de campo
- La prueba hidrostática no alcanzó la presión pactada y se repite
- Un bloqueo de la comunidad detuvo el transporte de equipos ocho días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.963.246.724 |
| Ejecutado | 2.023.878.778 |
| Proyección al cierre | 4.387.704.676 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
