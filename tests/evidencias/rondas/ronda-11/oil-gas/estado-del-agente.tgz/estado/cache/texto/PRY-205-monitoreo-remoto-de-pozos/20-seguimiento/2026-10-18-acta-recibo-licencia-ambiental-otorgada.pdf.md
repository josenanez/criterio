<!-- origen: PRY-205-monitoreo-remoto-de-pozos/20-seguimiento/2026-10-18-acta-recibo-licencia-ambiental-otorgada.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licencia ambiental otorgada
Proyecto: PRY-205 · Monitoreo remoto de pozos
Fecha de recibo: 2026-10-18
Recibido por: Gustavo Neira
Se recibe a satisfacción el entregable Licencia ambiental otorgada.
