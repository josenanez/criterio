<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-09-24
**Asistentes:** Camilo Beltrán, Carlos Peña, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Natalia Ospina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-09 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-10-13 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-04 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-14 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-10 |
| Camilo Beltrán | Entregar el punto 8 | por definir |
| María Restrepo | Enviar el documento 9 | 2026-10-21 |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-22 |
| María Restrepo | Revisar el anexo 11 | 2026-10-22 |
| Natalia Ospina | Validar el ambiente 12 | 2026-10-15 |

## Lo que se dijo

- Beatriz Cuéllar dice que ya entregó «confirmar la fecha 7». No se presentó acta.
