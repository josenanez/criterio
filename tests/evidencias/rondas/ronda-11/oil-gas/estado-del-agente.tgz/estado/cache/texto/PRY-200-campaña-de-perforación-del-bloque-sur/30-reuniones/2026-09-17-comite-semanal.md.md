<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Campaña de perforación del bloque sur

**Fecha:** 2026-09-17
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Javier Hoyos, Jorge Medina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-21 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-09-24 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-04 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-14 |
| Jorge Medina | Actualizar la matriz 6 | 2026-09-20 |
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-09-25 |
| Camilo Beltrán | Entregar el punto 8 | por definir |
