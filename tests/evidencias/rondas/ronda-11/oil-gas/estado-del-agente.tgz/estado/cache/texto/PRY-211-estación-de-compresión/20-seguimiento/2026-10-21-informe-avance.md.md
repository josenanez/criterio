<!-- origen: PRY-211-estación-de-compresión/20-seguimiento/2026-10-21-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Estación de compresión

**Código:** PRY-211
**Fecha de corte:** 2026-10-21
**Gerente:** Andrés Lozano

## Estado declarado

**Amarillo**

Avance reportado: **49%**

## Lo que pasó en el periodo

- Se recibió la aprobación de la consulta previa pendiente desde el trimestre anterior
- Se reprogramó la movilización del taladro por disponibilidad del contratista

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 218.981.244 |
| Ejecutado | 262.348.271 |
| Proyección al cierre | 753.768.866 |

## Riesgos abiertos

- Bloqueos de la comunidad en la vía de acceso
