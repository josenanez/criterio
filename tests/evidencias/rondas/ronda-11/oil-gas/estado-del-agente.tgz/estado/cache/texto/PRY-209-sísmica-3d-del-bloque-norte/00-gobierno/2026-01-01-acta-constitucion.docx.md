<!-- origen: PRY-209-sísmica-3d-del-bloque-norte/00-gobierno/2026-01-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sísmica 3D del bloque norte

Código: PRY-209

Área dueña: Finanzas

Patrocinador: Carlos Peña

Gerente de proyecto: Paula Céspedes

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2026-01-01

Objetivo del negocio

Entregar sísmica 3d del bloque norte para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Inversiones el 2026-01-01.

Fechas comprometidas

Fecha

Inicio

2026-01-11

Cierre

2027-01-13

Criterio de éxito

Sísmica 3D del bloque norte en producción y medido.

Dependencias declaradas

• Ninguna declarada
