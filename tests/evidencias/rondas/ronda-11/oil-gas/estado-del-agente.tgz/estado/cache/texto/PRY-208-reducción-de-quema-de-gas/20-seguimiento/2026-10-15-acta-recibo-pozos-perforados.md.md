<!-- origen: PRY-208-reducción-de-quema-de-gas/20-seguimiento/2026-10-15-acta-recibo-pozos-perforados.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Pozos perforados

**Proyecto:** PRY-208 · Reducción de quema de gas
**Fecha de recibo:** 2026-10-15
**Recibido por:** Liliana Torres

Se recibe a satisfacción el entregable **Pozos perforados**.
