<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/20-seguimiento/2026-10-09-acta-recibo-ingeniería-básica-aprobada.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Ingeniería básica aprobada
Proyecto: PRY-200 · Campaña de perforación del bloque sur
Fecha de recibo: 2026-10-09
Recibido por: Carlos Peña
Se recibe a satisfacción el entregable Ingeniería básica aprobada.
