<!-- origen: PRY-208-reducción-de-quema-de-gas/00-gobierno/2025-06-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Reducción de quema de gas

Código: PRY-208

Área dueña: Cadena de suministro

Patrocinador: Jorge Medina

Gerente de proyecto: Liliana Torres

Comité: Comité de Tecnología

Producto asociado: gas para generación

Fecha de aprobación: 2025-06-23

Objetivo del negocio

Entregar reducción de quema de gas para Cadena de suministro.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Tecnología el 2025-06-23.

Fechas comprometidas

Fecha

Inicio

2025-07-03

Cierre

2026-11-23

Criterio de éxito

Reducción de quema de gas en producción y medido.

Dependencias declaradas

• Ninguna declarada
