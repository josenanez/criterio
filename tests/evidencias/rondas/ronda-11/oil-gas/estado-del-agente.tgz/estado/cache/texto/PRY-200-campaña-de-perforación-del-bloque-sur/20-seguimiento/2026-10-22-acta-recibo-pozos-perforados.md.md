<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/20-seguimiento/2026-10-22-acta-recibo-pozos-perforados.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Pozos perforados

**Proyecto:** PRY-200 · Campaña de perforación del bloque sur
**Fecha de recibo:** 2026-10-22
**Recibido por:** Carlos Peña

Se recibe a satisfacción el entregable **Pozos perforados**.
