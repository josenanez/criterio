<!-- origen: PRY-210-mantenimiento-predictivo-de-bombas/00-gobierno/2025-09-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de bombas

Código: PRY-210

Área dueña: Ambiental

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Paula Céspedes

Comité: Comité de HSE

Producto asociado: No aplica

Fecha de aprobación: 2025-09-23

Objetivo del negocio

Entregar mantenimiento predictivo de bombas para Ambiental.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de HSE el 2025-09-23.

Fechas comprometidas

Fecha

Inicio

2025-10-03

Cierre

2026-09-01

Criterio de éxito

Mantenimiento predictivo de bombas en producción y medido.

Dependencias declaradas

• Ninguna declarada
