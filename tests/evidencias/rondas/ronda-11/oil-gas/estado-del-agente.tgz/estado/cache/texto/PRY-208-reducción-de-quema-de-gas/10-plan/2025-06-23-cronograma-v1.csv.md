<!-- origen: PRY-208-reducción-de-quema-de-gas/10-plan/2025-06-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-10-12,2025-10-12,cerrado
Licencia ambiental otorgada,2026-01-22,2026-01-22,cerrado
Pozos perforados,2026-05-03,2026-05-03,cerrado
Montaje de facilidades,2026-08-13,2026-08-13,cerrado
Primer crudo o gas,2026-11-23,2026-11-23,en curso
