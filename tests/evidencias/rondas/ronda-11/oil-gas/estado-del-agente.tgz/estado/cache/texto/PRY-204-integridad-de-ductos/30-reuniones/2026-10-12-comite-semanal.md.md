<!-- origen: PRY-204-integridad-de-ductos/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Integridad de ductos

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 12 | 2026-11-10 |
