<!-- origen: PRY-208-reducción-de-quema-de-gas/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Reducción de quema de gas

Fecha: 2026-10-14

Asistentes: Liliana Torres, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Ricardo Salas

Entregar el punto 12

2026-10-19
