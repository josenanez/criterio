<!-- origen: PRY-206-planta-de-tratamiento-de-crudo/00-gobierno/2025-05-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Planta de tratamiento de crudo

Código: PRY-206

Área dueña: Tecnología

Patrocinador: Sandra Gil

Gerente de proyecto: Elena Duarte

Comité: Comité de HSE

Producto asociado: No aplica

Fecha de aprobación: 2025-05-21

Objetivo del negocio

Entregar planta de tratamiento de crudo para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de HSE el 2025-05-21.

Fechas comprometidas

Fecha

Inicio

2025-05-31

Cierre

2026-03-13

Criterio de éxito

Planta de tratamiento de crudo en producción y medido.

Dependencias declaradas

• Ninguna declarada
