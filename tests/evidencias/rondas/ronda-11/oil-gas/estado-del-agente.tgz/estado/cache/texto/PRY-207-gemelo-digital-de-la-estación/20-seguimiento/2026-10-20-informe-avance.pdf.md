<!-- origen: PRY-207-gemelo-digital-de-la-estación/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Gemelo digital de la estación
Código: PRY-207
Fecha de corte: 2026-10-20
Gerente: María Restrepo

Estado declarado
Rojo
Avance reportado: 87%

Lo que pasó en el periodo
- Se ajustó el plan de perforación con la geología del pozo vecino
- Se levantó un hallazgo de seguridad en espacios confinados
- El equipo perdió dos semanas por rotación del supervisor de campo

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 1.052.818.651
Ejecutado 215.253.435
Proyección al cierre 1.179.826.781

Riesgos abiertos
- Precio del crudo por debajo del supuesto del caso de negocio
