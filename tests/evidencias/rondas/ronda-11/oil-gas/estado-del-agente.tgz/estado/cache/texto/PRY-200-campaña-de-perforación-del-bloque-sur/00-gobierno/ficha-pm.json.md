<!-- origen: PRY-200-campaña-de-perforación-del-bloque-sur/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "name": {
 "value": "Campaña de perforación del bloque sur",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Ambiental",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Paula Céspedes",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "manager": {
 "value": "Carlos Peña",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Tecnología",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 84,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-19",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-10-31",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "end_date": {
 "value": "2026-10-06",
 "source": "10-plan/2025-10-21-cronograma-v1.csv",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-10-21",
 "start_date": "2025-10-31",
 "end_date": "2026-10-06",
 "reason": "Aprobación del acta de constitución",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2026-01-24",
 "current_date": "2026-01-24",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-ingeniería-básica-aprobada.pdf",
 "source": "10-plan/2025-10-21-cronograma-v1.csv"
 },
 {
 "name": "Licencia ambiental otorgada",
 "baseline_date": "2026-04-19",
 "current_date": "2026-04-19",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2025-10-21-cronograma-v1.csv"
 },
 {
 "name": "Pozos perforados",
 "baseline_date": "2026-07-13",
 "current_date": "2026-07-13",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-22-acta-recibo-pozos-perforados.md",
 "source": "10-plan/2025-10-21-cronograma-v1.csv"
 },
 {
 "name": "Montaje de facilidades",
 "baseline_date": "2026-10-06",
 "current_date": "2026-10-06",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2025-10-21-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found"
 },
 "approved": {
 "value": 3300000000,
 "source": "00-gobierno/2025-10-21-acta-constitucion.docx",
 "source_date": "2025-10-21",
 "state": "found"
 },
 "committed": {
 "value": 1025532379,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found"
 },
 "executed": {
 "value": 537252237,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found"
 },
 "projection": {
 "value": 3453463040,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-19",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; se comentó en la reunión y nadie lo anotó como riesgo",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Un bloqueo de la comunidad detuvo el transporte de equipos ocho días",
 "since": "no_declarada",
 "owner": "no_declarada",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Ricardo Salas",
 "what": "Enviar el documento 1",
 "due_date": "2027-01-15",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-12-18",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2027-01-01",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 },
 {
 "due_date": "2027-01-15",
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-29",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-24",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-25",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "nota": "En la minuta del 2026-10-01 dice que ya lo entregó; no se presentó acta. Desde la del 2026-10-08 ya no figura en la tabla."
 },
 {
 "who": "Jorge Medina",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-10",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-6.md"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "nota": "En la minuta del 2026-09-24 dice que ya lo entregó; no se presentó acta. Desde la del 2026-10-01 ya no figura en la tabla."
 },
 {
 "who": "Camilo Beltrán",
 "what": "Entregar el punto 8",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "Sin fecha desde que se dijo. En la minuta del 2026-10-15 dice que ya lo entregó; no se presentó acta."
 },
 {
 "who": "María Restrepo",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "nota": "En la minuta del 2026-10-08 dice que ya lo entregó; no se presentó acta. Desde esa minuta no figura en la tabla."
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 11",
 "due_date": "2026-11-06",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-11.md"
 },
 {
 "who": "Natalia Ospina",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-15-acta-recibo-12.md"
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-05",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "En la minuta del 2026-10-08 dice que ya lo entregó; no se presentó acta. Desde esa minuta no figura en la tabla."
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 16",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-30",
 "original_due_date": "2026-10-30",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "Se prometió «por definir» el 2026-10-08; la fecha se puso el 2026-10-15 (primera fecha, no reprogramación)."
 },
 {
 "who": "Elena Duarte",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "Se prometió «por definir» el 2026-10-08; la fecha se puso el 2026-10-15 (primera fecha, no reprogramación)."
 },
 {
 "who": "Laura Vélez",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-12",
 "original_due_date": "2026-11-12",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-31",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-07",
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "nota": "Dicho como «la otra semana»; no es una fecha."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
