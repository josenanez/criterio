<!-- origen: PRY-206-planta-de-tratamiento-de-crudo/20-seguimiento/2026-10-12-acta-recibo-pozos-perforados.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Pozos perforados

**Proyecto:** PRY-206 · Planta de tratamiento de crudo
**Fecha de recibo:** 2026-10-12
**Recibido por:** Elena Duarte

Se recibe a satisfacción el entregable **Pozos perforados**.
