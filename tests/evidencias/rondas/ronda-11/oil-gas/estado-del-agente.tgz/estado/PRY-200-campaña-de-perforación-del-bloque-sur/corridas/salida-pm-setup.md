## Listo — PRY-200 · Campaña de perforación del bloque sur

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 15 documentos · 6 minutas (del 2026-09-10 al 2026-10-15) más las notas de la reunión del 2026-10-22 · 5 actas de recibo · la más reciente es del 2026-10-22. Los leí todos, de la más vieja a la más nueva; no hay formatos ilegibles.
**Preguntas:** 4, y las cuatro con la respuesta sugerida (sesión de prueba sin interfaz). Gerente: Carlos Peña (acta de constitución). Reunión de seguimiento: jueves, semanal; las notas del 2026-10-22 dicen que la próxima es en dos semanas, así que quedó para el 2026-11-05. Estado en `estado/PRY-200-campaña-de-perforación-del-bloque-sur`. No dejé la marca `_CRITERIO_PROYECTO.txt`: nadie autorizó escribir en los documentos.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-22 para la versión 0.8.0 (términos 1.2) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 97ef3d7200b125fa… (el del texto de los términos). Los comprobantes tienen las huellas 828fdb02ffd2726d… (.md) y 2272166e64d8fd11… (.pdf).

### Lo que está abierto, y cuántas veces se ha movido
26 compromisos en total: 3 cumplidos con acta (matriz 6, anexo 11, ambiente 12), 8 vencidos sin evidencia, 3 sin fecha y 12 vigentes. Cita = minuta donde se dijo por primera vez.

| Quién | Qué | Para cuándo | Movimientos y estado |
|---|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2027-01-15 | **Reprogramado 6 veces**: 09-30 → 10-21 → 11-09 → 11-29 → 12-18 → 2027-01-01 → 2027-01-15 (`30-reuniones/2026-09-10-comite-semanal.md`; última fecha: `2026-10-22-notas-reunion.txt`) |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-29 | **Reprogramado 5 veces**: 09-15 → 09-24 → 10-13 → 11-02 → 11-20 → 11-29 (`2026-09-10`) |
| Jorge Medina | Validar el ambiente 4 | 2026-10-25 | Reprogramado 2 veces: 09-16 → 10-04 → 10-25 (`2026-09-10`) |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-24 | Reprogramado 1 vez: 10-03 → 10-24; la fecha del 10-03 se arrastró cuatro minutas sin cambio (`2026-09-10`) |
| Liliana Torres | Cerrar la prueba 10 | 2026-10-31 | Reprogramado 1 vez: 10-22 → 10-31. Dijo el 10-08 que ya lo entregó; no hay acta (`2026-09-24`) |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-14 | **Vencido 9 días sin evidencia.** Dijo el 10-01 que ya lo entregó; no hay acta (`2026-09-17`) |
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-09-25 | **Vencido 28 días sin evidencia.** Dijo el 09-24 que ya lo entregó; no hay acta (`2026-09-17`) |
| María Restrepo | Enviar el documento 9 | 2026-10-21 | **Vencido 2 días sin evidencia** (`2026-09-24`) |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-05 | **Vencido 18 días sin evidencia** (`2026-10-01`) |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 | **Vencido 19 días sin evidencia** (`2026-10-01`) |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-22 | **Vencido 1 día sin evidencia** (`2026-10-08`) |
| Laura Vélez | Validar el ambiente 20 | 2026-10-21 | **Vencido 2 días sin evidencia** (`2026-10-08`) |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-21 | **Vencido 2 días sin evidencia** (`2026-10-15`) |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-27 | Vigente. Dijo el 10-08 que ya lo entregó; no hay acta (`2026-10-01`) |
| Laura Vélez | Enviar el documento 17 | 2026-10-30 | Vigente; primera fecha puesta el 10-15 (`2026-10-08`) |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-23 | Vigente; primera fecha puesta el 10-15 (`2026-10-08`) |
| Beatriz Cuéllar | Confirmar la fecha 23 | 2026-10-31 | Vigente (`2026-10-15`) |
| Beatriz Cuéllar | Actualizar la matriz 22 | 2026-11-12 | Vigente (`2026-10-15`) |
| Paula Céspedes | Entregar el punto 24 | 2026-11-07 | Vigente (`2026-10-15`) |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-01 | Vigente (`2026-10-22-notas-reunion.txt`) |

Nota: «dijo que ya lo entregó» no cierra un compromiso; solo lo cierra un acta. Los vencidos son hechos del registro, no un juicio sobre las personas: casi siempre detrás hay un insumo que falta.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y son los que desaparecen de los informes:
- Camilo Beltrán · Entregar el punto 8: «por definir» desde el 2026-09-17 (`30-reuniones/2026-09-17-comite-semanal.md`). El 10-15 dijo que ya lo entregó; no hay acta.
- Rubén Cárdenas · Entregar el punto 16: «por definir» desde el 2026-10-01 (`30-reuniones/2026-10-01-comite-semanal.md`).
- Laura Vélez · Mandar el ajuste del presupuesto: «la otra semana» (`2026-10-22-notas-reunion.txt`). Eso no es una fecha.

### Lo que dice el proyecto de sí mismo, y lo que muestran los documentos
El informe del 2026-10-19 declara **verde**, avance **84 %** (`20-seguimiento/2026-10-19-informe-avance.pdf`). Las señales que `compute` levantó contra esa declaración:
- **Hitos declarados cerrados sin acta:** «Licencia ambiental otorgada» (2026-04-19, 187 días) y «Montaje de facilidades» (2026-10-06, 17 días). Con acta: «Ingeniería básica aprobada» y «Pozos perforados».
- **Avance contra plan:** el cronograma tiene 4 de 4 hitos cerrados y el informe dice 84 %; diferencia de 16 puntos.
- **El cierre pasó:** la fecha de cierre vigente es 2026-10-06 (cronograma y acta de constitución coinciden) y el proyecto sigue con compromisos abiertos.
- **Compromisos:** 8 vencidos, 3 sin fecha, 2 reprogramados 5 y 6 veces.
- **Presupuesto (COP):** aprobado 3.300.000.000; comprometido 1.025.532.379 (31,1 %); ejecutado 537.252.237 (16,3 %); proyección al cierre 3.453.463.040, que es 4,7 % sobre lo aprobado.
- **Riesgo que nadie registró:** las notas del 2026-10-22 dicen que el proveedor podría no llegar con el equipo completo para la siguiente fase y que nadie lo anotó. El informe solo registra que el proveedor no ha confirmado la fecha de la última entrega.
- El bloqueo de la comunidad (ocho días sin transporte de equipos) está en el informe como lo que pasó en el periodo.

Total: 17 señales; el verde queda contradicho por 4 tipos de ellas.

### Qué le falta a tu carpeta
- Actas de recibo de «Licencia ambiental otorgada» y «Montaje de facilidades»: sin ellas un hito cerrado se ve igual que uno que no lo está.
- Actas de recibo de lo que dicen haber entregado Felipe Arango (diseño 5), Beatriz Cuéllar (fecha 7), Liliana Torres (prueba 10), Mauricio Pérez (fecha 15) y Camilo Beltrán (punto 8).
- Un cronograma posterior al v1: el único es del 2025-10-21 y no se ha movido nunca, ni con el cierre vencido.
- El acta de constitución no dice hasta qué monto puede decidir el gerente (autoridad) ni la etapa del proyecto; quedaron sin dato. Tampoco trae dependencias, y los componentes del alcance se llaman «Componente 1, 2 y 3».
- Los documentos ya vienen ordenados en `00-gobierno`, `10-plan`, `20-seguimiento` y `30-reuniones`; no moví ni creé nada ahí. Las notas del 2026-10-22 están sueltas en la raíz del proyecto; irían en `30-reuniones`.

**Cuándo vuelvo:** el jueves 2026-11-05, la reunión de seguimiento que dicen las notas. La ficha no está sellada: leí todo el proyecto, pero el sello lo da quien la confirma.
