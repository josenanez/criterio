# Acta — Campaña de perforación del bloque sur (PRY-200) · 2026-10-22
**Asistieron (11):** Beatriz Cuéllar, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez · **Fuente:** `2026-10-22-notas-reunion.txt` (notas de 8 líneas) · **Ausentes con tema en agenda:** las notas no traen agenda, así que no se puede decir. Ausentes con compromisos abiertos en la ficha: Felipe Arango, Camilo Beltrán, Liliana Torres, Mauricio Pérez, Natalia Ospina (nadie los mencionó en la reunión).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Ricardo Salas | Enviar el documento 1 (*«no alcanzó»*, línea 4) | 2027-01-15 | **Reprogramado por 6.ª vez.** Promesa original 2026-09-30; fechas sucesivas 10-21, 11-09, 11-29, 12-18, 2027-01-01 y ahora 2027-01-15. Es la fecha más lejana hasta ahora: 107 días después de la promesa original. |
| Óscar Ramírez | Revisión con el proveedor (*«queda para el 2026-11-01»*, línea 6) | 2026-11-01 | Nuevo. Ojo: 2026-11-01 es domingo. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dicho como *«la otra semana»* (línea 5); no es una fecha y no se convirtió en una. |

Con este compromiso, la ficha tiene 3 compromisos sin fecha en total (los otros dos: Camilo Beltrán, «punto 8», desde 2026-09-17; Rubén Cárdenas, «punto 16», desde 2026-10-01).

## Decisiones
Ninguna. Las notas no registran una sola decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace con el documento 1 de Ricardo Salas, ya 6 veces reprogramado | Las notas solo recogen la nueva fecha; nadie cuestionó ni decidió nada sobre la reprogramación | No está dicho en las notas; el patrocinador (Paula Céspedes, presente) o el comité |
| Si el posible retraso del proveedor se trata como riesgo | Se comentó y *«nadie lo anotó como riesgo»* (línea 7) | No está dicho |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| *«el proveedor podría no llegar con el equipo completo para la siguiente fase»* (línea 7) | No se atribuye a nadie en las notas | Riesgo (probabilidad, impacto, doliente y fecha: sin declarar) | **No.** Lo más cercano es *«el proveedor no ha confirmado la fecha de la última entrega»* (informe 2026-10-19), que es otro asunto: fecha de entrega, no equipo completo. Entra a la ficha hoy con `owner: no_declarada`. |

## Cerrado en esta reunión
Nada. Ninguna frase de las notas se apoya en un documento de cierre.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | *«próxima reunión en dos semanas»* (≈ 2026-11-05) | Configuración: comité semanal; las seis reuniones previas (09-10 a 10-15) fueron semanales | Notas 2026-10-22, línea 8 · `config.json` (`committee: weekly`, `committee_next: 2026-11-05`) y actas de 30-reuniones. La fecha de próximo comité coincide; la cadencia no. Si el comité pasó a quincenal, la configuración está vieja. |

Ningún campo del acta de constitución (patrocinador, gerente, comité, fechas) cambia en esta reunión; Paula Céspedes y Carlos Peña asistieron en sus roles.

## Sin resolver de la transcripción
- *«lo de “enviar el documento 1” no alcanzó»* (línea 4): no dice qué no alcanzó ni por qué la fecha vuelve a moverse.
- *«el proveedor podría no llegar con el equipo completo»* (línea 7): no dice qué proveedor, a qué «siguiente fase» se refiere ni quién lo comentó.
- *«queda para el 2026-11-01»* (línea 6): no queda claro si la fecha es la de la revisión o la de entregar su resultado; se registró como fecha de la revisión.

---
**Cálculo (`compute`, sin `record_issues`):** 17 alertas; 8 compromisos vencidos, 3 sin fecha, 2 reprogramados 3 veces o más (documento 1: 6; prueba 2: 5); el informe declara verde contra 4 señales que no lo sostienen. La reunión no cerró ni movió ningún vencido: Laura Vélez (matriz 14, ambiente 20), Óscar Ramírez (diseño 21) y Elena Duarte (prueba 18) estaban presentes y las notas no registran nada sobre sus vencidos.

**Tú lo guardas:** el acta está solo en la conversación y en el registro de la corrida; no se escribió en 30-reuniones.
Siguiente: `/pm-commitments` para el seguimiento completo, y `/pm-publish` si quieres que la PMO vea la ficha con el riesgo nuevo.
