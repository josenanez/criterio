Publiqué la ficha en `documentos/proyectos/PRY-200-campaña-de-perforación-del-bloque-sur/00-gobierno/ficha-pm.json`, con corte al 2026-10-23.

**Antes de publicar:** recalculé la ficha (`compute`, corte 2026-10-23). La fecha de cierre vigente es 2026-10-06; no hay un cronograma más nuevo que `10-plan/2025-10-21-cronograma-v1.csv`, así que `plan.end_date` coincide con `plan.baseline` v1 y no hay diferencia que explicar. Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22).

**Lleva:** 18 campos con dato · 3 sin decir en ninguna parte (`identity.product`, `identity.authority`, `identity.phase`) · declara **verde** al 2026-10-19 (84 % de avance, `20-seguimiento/2026-10-19-informe-avance.pdf`)

**Lo más viejo que va ahí:** identidad, patrocinador, gerente, comité, fechas de inicio y fin, alcance y presupuesto aprobado, todos del acta de constitución del 2025-10-21 — pasa de un año (12 meses cumplidos).

**Lo que la PMO va a mirar primero:** la declaración «verde» no la sostiene el cómputo. Quedan sin explicar cuatro señales:
- Avance declarado 84 % contra 100 % que sustenta el plan (4 de 4 hitos cerrados): 16 puntos de diferencia.
- Dos hitos marcados cumplidos sin acta de recibo: «Licencia ambiental otorgada» (vencía 2026-04-19) y «Montaje de facilidades» (vencía 2026-10-06).
- 8 compromisos vencidos sin evidencia, el más viejo con 28 días (Beatriz Cuéllar, «Confirmar la fecha 7»).
- 2 compromisos de Ricardo Salas reprogramados 6 y 5 veces.

De los ocho campos que Vera contrasta, `identity.product` va sin decir en ninguna parte; los otros siete van con dato.

La ficha sigue siendo tu declaración, marcada como declarada. No avisé a nadie: Vera la lee en su próximo barrido.
