## Reunión de seguimiento — Campaña de perforación del bloque sur (PRY-200) · 2026-11-05
10 puntos y una ronda de confirmación · 37 minutos · 11 personas requeridas (Carlos Peña, Paula Céspedes, Ricardo Salas, Beatriz Cuéllar, Laura Vélez, María Restrepo, Óscar Ramírez, Elena Duarte, Jorge Medina, Javier Hoyos, Rubén Cárdenas)

Supuestos míos, porque nadie los dio: la fecha es el `committee_next` de la configuración (2026-11-05); el tiempo es 40 minutos (la suma de abajo es 37); y los asistentes son los 11 de la reunión del 2026-10-22, porque no hay convocatoria. El estado está calculado al 2026-10-23: para el 11-05 habrá más vencidos, y la agenda se rehace ese día antes de entrar.
El `diff` no tiene foto anterior (es la primera corrida), así que no puedo decir «qué cambió desde la reunión pasada» con el cálculo; usé como ancla la minuta del 2026-10-22.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea a Ricardo Salas y quién lo destraba — documento 1, prueba 2 y diseño 13 — y salir con una sola fecha por cada uno, o con una reasignación** · 12 min · **Ricardo Salas, con Paula Céspedes (patrocinadora) y Carlos Peña**
> Documento 1: prometido para el 2026-09-30, y antes para 10-21, 11-09, 11-29, 12-18, 2027-01-01 y ahora 2027-01-15 (seis reprogramaciones; la última, el 10-22: *«no alcanzó»*).
> Prueba 2: prometida para el 2026-09-15, y antes para 09-24, 10-13, 11-02, 11-20 y ahora 11-29 (cinco reprogramaciones).
> Diseño 13: prometido para el 2026-10-05, vencido sin evidencia (18 días al 10-23).
> Los tres son de la misma persona y se mueven en cada comité desde el 09-17: lo que se mueve es una capacidad o una dependencia suya, no cada tarea. Los documentos no dicen cuál.
> Fuente: comités 2026-09-10, 09-17, 09-24, 10-01, 10-08, 10-15 y notas 2026-10-22 (línea 4); acta de comité 2026-10-01 para el diseño 13.
> **Si no se resuelve hoy:** la fecha del documento 1 ya está 107 días después de la promesa original y la siguiente reprogramación la lleva más lejos. No sé qué depende de ese documento: no está dicho en lo que leí. Si Paula no puede moverlo en la sala, sube como decisión de comité con `/pm-escalate`.

### Vencido sin evidencia
Más viejo primero. Ninguno tiene acta de recibo en el expediente.
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-09-25 | Dijo el 09-24 que ya lo entregó: el acta de recibo, o una fecha nueva | 2 |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 | Entrega o fecha | 1 |
| María Restrepo | Enviar el documento 9 | 2026-10-21 | Entrega o fecha | 1 |
| Laura Vélez | Validar el ambiente 20 | 2026-10-21 | Entrega o fecha. Con la matriz 14, son dos vencidos de ella que el 10-22 no se mencionaron | 2 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-21 | Entrega o fecha | 1 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-22 | Entrega o fecha | 2 |
Fuente: comités 2026-09-17 (fecha 7), 2026-10-01 (matriz 14), 2026-09-24 (documento 9), 2026-10-08 (ambiente 20, prueba 18), 2026-10-15 (diseño 21); notas 2026-10-22: sin registro sobre ninguno.
Subtotal: 9 min.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Si *«el proveedor podría no llegar con el equipo completo para la siguiente fase»* es un riesgo registrado, y quién es su doliente (probabilidad, impacto y fecha sin declarar). Fuente: notas 2026-10-22, línea 7. No dice qué proveedor ni qué fase | Carlos Peña (registrarlo) y Paula Céspedes (asignar doliente) | Sigue en la ficha con `owner: no_declarada`; nadie lo mira | 5 |
| Cadencia del comité: semanal (configuración y seis reuniones previas) o quincenal (*«en dos semanas»*, notas 2026-10-22, línea 8) | Paula Céspedes y Carlos Peña | La configuración queda con una cadencia que no se cumple y los vencimientos se miden contra una reunión que no existe | 2 |
| Fecha para el ajuste del presupuesto de Laura Vélez, dicho como *«la otra semana»* (notas 2026-10-22, línea 5). Contexto: la proyección del informe 2026-10-19 es COP 3.453.463.040 contra COP 3.300.000.000 aprobados (≈ COP 153,5 millones, 4,7 % sobre lo aprobado) | Laura Vélez da la fecha; Paula Céspedes decide si el ajuste cambia el aprobado | Un compromiso sin fecha no puede vencer, y el sobrecosto proyectado queda sin ajuste | 3 |
Subtotal: 10 min.

### Vence antes de la próxima
Cada uno vence antes del 11-05; ronda rápida de confirmación, no discusión. Estado al 10-23: confirmar en la sala cuáles se cumplieron.
| Quién | Qué | Para cuándo |
|---|---|---|
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-23 |
| Javier Hoyos | Revisar el anexo 3 (reprogramado una vez; original 10-03) | 2026-10-24 |
| Jorge Medina | Validar el ambiente 4 (reprogramado dos veces; original 09-16: una más es el umbral de tres) | 2026-10-25 |
| Laura Vélez | Enviar el documento 17 | 2026-10-30 |
| Beatriz Cuéllar | Confirmar la fecha 23 | 2026-10-31 |
| Óscar Ramírez | Revisión con el proveedor (2026-11-01 es domingo; no queda claro si esa es la fecha de la revisión o la de su resultado: notas 2026-10-22, línea 6) | 2026-11-01 |
Subtotal: 6 min.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Felipe Arango: Aprobar el diseño 5 (vence 2026-10-14) | Dijo el 10-01 que ya lo entregó, sin acta, y no estuvo el 10-22 | Mensaje de Carlos antes del 11-05 pidiendo el acta de recibo; si no aparece, volverlo punto con él convocado |
| Camilo Beltrán: Entregar el punto 8 (sin fecha desde 2026-09-17; dijo el 10-15 que ya lo entregó, sin acta) | No estuvo el 10-22 | Mismo mensaje: acta o fecha |
| Mauricio Pérez: Confirmar la fecha 15 (2026-10-27; dijo el 10-08 que ya lo entregó, sin acta) | No estuvo el 10-22 | Mismo mensaje |
| Liliana Torres: Cerrar la prueba 10 (2026-10-31; dijo el 10-08 que ya lo entregó, sin acta) | No estuvo el 10-22 | Mismo mensaje |
| Rubén Cárdenas: Entregar el punto 16 (sin fecha desde 2026-10-01) | Se le pide fecha en la ronda de «Vence antes» solo si hay tiempo; si no, por mensaje | Mensaje, o `/pm-commitments` |
| El informe del 2026-10-19 declara el proyecto en verde; el cálculo lo marca contradicho (8 vencidos, 2 reprogramados 3 veces o más, y dos hitos —licencia ambiental y montaje de facilidades— dados por cumplidos sin acta) | El estado lo declara Carlos, no la sala | `/pm-report` |

### Anexo — sin cambios desde la reunión del 2026-10-22
No se repasa en la reunión. (No hay foto anterior para decir «sin cambios» por cálculo: lo que sigue es lo que la minuta del 10-22 y la ficha muestran sin movimiento ni vencimiento antes del 11-05.)
- Beatriz Cuéllar: Actualizar la matriz 22 (2026-11-12).
- Paula Céspedes: Entregar el punto 24 (2026-11-07).
- Cerrados con documento: Jorge Medina, matriz 6 (`20-seguimiento/2026-10-01-acta-recibo-6.md`); María Restrepo, anexo 11 (`2026-10-08-acta-recibo-11.md`); Natalia Ospina, ambiente 12 (`2026-10-15-acta-recibo-12.md`).
- Riesgo *«el proveedor no ha confirmado la fecha de la última entrega»* e incidencia del bloqueo de la comunidad (ocho días), ambos del informe 2026-10-19, ambos sin doliente declarado.

Quedó fuera por tiempo: nada. Lo que quedó fuera por no ser de la sala está en «No es de esta reunión».
No convoqué a nadie. Después de la reunión, `/pm-minutes` sobre las notas.
