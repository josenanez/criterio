<!-- origen: 00-gobierno/2025-10-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Campaña de perforación del bloque sur

Código: PRY-200

Área dueña: Ambiental

Patrocinador: Paula Céspedes

Gerente de proyecto: Carlos Peña

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2025-10-21

Objetivo del negocio

Entregar campaña de perforación del bloque sur para Ambiental.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Tecnología el 2025-10-21.

Fechas comprometidas

Fecha

Inicio

2025-10-31

Cierre

2026-10-06

Criterio de éxito

Campaña de perforación del bloque sur en producción y medido.

Dependencias declaradas

• Ninguna declarada
