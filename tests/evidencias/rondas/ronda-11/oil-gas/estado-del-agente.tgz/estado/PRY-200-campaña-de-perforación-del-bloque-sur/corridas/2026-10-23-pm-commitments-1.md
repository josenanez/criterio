# Corrida del 2026-10-23 · pm-commitments

1 proyectos · 31 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `commitment_undated` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |

Ricardo Salas reprogramó dos compromisos (6 y 5 veces) y tiene un tercero vencido; 8 vencidos sin evidencia, 3 sin fecha.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-200 Campaña de perforación del bloque sur · al 2026-10-23

23 compromisos abiertos: 2 reprogramados más de tres veces, 8 vencidos sin evidencia, 5 que vencen esta semana, 3 sin fecha y 5 más adelante. Cerrados con documento: 3.

### Se viene reprogramando

> **Ricardo Salas** · Enviar el documento 1
> Prometido para el 2026-09-30, y luego para el 10-21, 11-09, 11-29, 12-18, 2027-01-01 y 2027-01-15 (la última se dijo el 2026-10-22). Seis reprogramaciones.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Ricardo Salas** · Cerrar la prueba 2
> Prometido para el 2026-09-15, y luego para el 09-24, 10-13, 11-02, 11-20 y 11-29 (la última se dijo el 2026-10-15). Cinco reprogramaciones.
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

Los dos compromisos son de la misma persona y se mueven en cada comité desde el 2026-09-17. Además, Ricardo Salas tiene vencido «Aprobar el diseño 13» (ver abajo). Eso sugiere que lo que se mueve es su capacidad o una dependencia suya, y no cada tarea por separado.

### Vencidos sin evidencia

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Beatriz Cuéllar | Confirmar la fecha 7 | 2026-09-25 | 28 días |
| Laura Vélez | Actualizar la matriz 14 | 2026-10-04 | 19 días |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-05 | 18 días |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-14 | 9 días |
| María Restrepo | Enviar el documento 9 | 2026-10-21 | 2 días |
| Laura Vélez | Validar el ambiente 20 | 2026-10-21 | 2 días |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-21 | 2 días |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-22 | 1 día |

Dos de ellos tienen una nota que conviene leer con cuidado:
- **Beatriz Cuéllar (fecha 7):** en la minuta del 2026-09-24 dice que ya lo entregó. No hay acta de recibo en el expediente, y desde la minuta del 10-01 ya no figura en la tabla. Sigue abierto.
- **Felipe Arango (diseño 5):** en la minuta del 2026-10-01 dice que ya lo entregó. No hay acta de recibo, y desde la del 10-08 ya no figura. Sigue abierto.

Laura Vélez tiene dos compromisos vencidos y uno sin fecha (ver abajo).

### Vencen esta semana

| Quién | Qué | Para cuándo |
|---|---|---|
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-23 (hoy) |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-24 (reprogramado una vez; original 10-03) |
| Jorge Medina | Validar el ambiente 4 | 2026-10-25 (reprogramado dos veces; original 09-16) |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-27 |
| Laura Vélez | Enviar el documento 17 | 2026-10-30 |

Mauricio Pérez dijo en la minuta del 2026-10-08 que ya lo entregó. No hay acta de recibo y desde esa minuta no figura en la tabla. Sigue abierto.

Jorge Medina lleva dos reprogramaciones. Una más lo llevaría al umbral de tres.

### Sin fecha

| Quién | Qué | Dicho el |
|---|---|---|
| Camilo Beltrán | Entregar el punto 8 | 2026-09-17 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-01 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-22 |

No pueden estar vencidos, y por eso se cuentan aparte. El de Camilo Beltrán lleva 36 días sin fecha; en la minuta del 2026-10-15 dijo que ya lo entregó, y no hay acta. El de Laura Vélez se dijo como «la otra semana», que no es una fecha.

### Cerrados desde la última revisión

| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Jorge Medina | Actualizar la matriz 6 | 20-seguimiento/2026-10-01-acta-recibo-6.md |
| María Restrepo | Revisar el anexo 11 | 20-seguimiento/2026-10-08-acta-recibo-11.md |
| Natalia Ospina | Validar el ambiente 12 | 20-seguimiento/2026-10-15-acta-recibo-12.md |

### Lo que cruza con el informe de avance

El informe del 2026-10-19 declara el proyecto en **verde**. `compute` lo marca como contradicho, y estos compromisos son una de las razones: ocho vencidos y dos reprogramados más de tres veces. Esos números no están en el informe.

### Después

- **Ricardo Salas, documento 1 y prueba 2:** puedo formularlos como decisión para el comité del 2026-11-05 con `/pm-escalate`: qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente, por eso sube.
- No cambié la ficha en esta corrida, así que no hace falta `/pm-publish` por esto.
