# PRY-200 Campaña de perforación del bloque sur — semana del 2026-10-16 al 2026-10-23

*Sesión sin interfaz: no hubo pregunta de declaración. Se usa la declaración ya registrada por el gerente (Carlos Peña) en su informe de avance; el agente no propone ni cambia ningún estado.*

**Declara el gerente:** verde · 84% · al 2026-10-19 (hace 4 días; fuente: 20-seguimiento/2026-10-19-informe-avance.pdf)
**Sustento documental:** contradicho — 0 fuentes de evidencia, 3 de declaración, 15 sin marcar
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos cumplidos sin evidencia, avance contra el plan

## Qué cambió esta semana
Sin comparación posible: es la primera corrida y el diff no tiene snapshot anterior (0 cambios). Desde la próxima semana esta sección tendrá contenido.

## Lo que sigue igual y sigue mal
No medible todavía (sin corrida previa). Las edades de abajo son días desde el vencimiento.

| Qué | Desde | Días así |
|---|---|---|
| Beatriz Cuéllar: Confirmar la fecha 7 | 2026-09-25 | 28 |
| Laura Vélez: Actualizar la matriz 14 | 2026-10-04 | 19 |
| Ricardo Salas: Aprobar el diseño 13 | 2026-10-05 | 18 |
| Hito «Montaje de facilidades» cumplido sin evidencia | 2026-10-06 | 17 |
| Hito «Licencia ambiental otorgada» cumplido sin evidencia | 2026-04-19 | 187 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-06 | 2026-10-06 | 0 días (ya pasó hace 17 días) |
| Presupuesto | 3.300.000.000 COP | 3.300.000.000 COP | proyección 3.453.463.040 COP, +4,7% |

Replanificaciones: 0 (sin solicitudes de cambio registradas).
Avance declarado 84% frente a 4 de 4 hitos cumplidos (el plan sustenta 100%): brecha de 16 puntos. La fecha de cierre ya venció con el avance declarado por debajo de 100%.

### Hitos de las próximas cuatro semanas
Ninguno: los 4 hitos figuran como cumplidos; dos sin evidencia documental.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 1.025.532.379 (31,1%) | 537.252.237 (16,3%) | 3.453.463.040 | 2.274.467.621 (aprobado − comprometido) |

Nota: con la fecha de cierre vencida, solo 16,3% ejecutado y 31,1% comprometido, las cifras no cuadran con un 84% de avance; hay que revisarlo.

## Abierto
**Reprogramados:**
- Ricardo Salas, «Enviar el documento 1»: 6 veces; original 2026-09-30, última 2027-01-15.
- Ricardo Salas, «Cerrar la prueba 2»: 5 veces; original 2026-09-15, última 2026-11-29.

**Vencidos sin evidencia (8):**
- Beatriz Cuéllar, Confirmar la fecha 7: 28 días
- Laura Vélez, Actualizar la matriz 14: 19 días
- Ricardo Salas, Aprobar el diseño 13: 18 días
- Felipe Arango, Aprobar el diseño 5: 9 días
- María Restrepo, Enviar el documento 9: 2 días
- Laura Vélez, Validar el ambiente 20: 2 días
- Óscar Ramírez, Aprobar el diseño 21: 2 días
- Elena Duarte, Cerrar la prueba 18: 1 día

**Sin fecha (3):** Camilo Beltrán (punto 8), Rubén Cárdenas (punto 16), Laura Vélez (ajuste del presupuesto, de las notas del 2026-10-22).

**RAID sin movimiento:** no hay registro RAID en la ficha.
**Proveedor:** sin proveedores en la ficha.

## Lo que necesito de alguien
- Carlos Peña: declarar de nuevo el estado a la vista de las señales de arriba, o sustentar el verde con documentos. Es decisión suya; este informe no la propone.
- Ricardo Salas: fecha firme o escalamiento para dos compromisos reprogramados 5 y 6 veces. Que siga reprogramándose pasa de lo que puede resolver el gerente; es material de comité (próximo: 2026-11-05).
- Responsables de los 8 compromisos vencidos: evidencia de cierre o nueva fecha.
- Quien tenga la licencia ambiental y el acta de montaje de facilidades: subir el documento a la carpeta.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto. Tampoco hay evidencia documental de ningún hito. Once campos de identidad, plan y presupuesto tienen 12 meses de antigüedad (fuente del 2025-10-21).
**Silencio:** no calculable por el cálculo (días de silencio sin dato) · la última reunión registrada es el comité del 2026-10-15 (8 días) y hay notas del 2026-10-22.

---
Ficha de PRY-200 al 2026-10-23 · 3 campos sin dato · términos v1.2 aceptados el 2026-10-22: https://www.josenanez.com/es/agents/criterio-pmo/legal
