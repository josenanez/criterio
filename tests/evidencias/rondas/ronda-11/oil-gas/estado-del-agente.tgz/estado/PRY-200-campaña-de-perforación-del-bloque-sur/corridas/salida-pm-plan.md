# Plan — Campaña de perforación del bloque sur (PRY-200) · borrador del 2026-10-23
**Desde:** acta de constitución del 2025-10-21 (`00-gobierno/2025-10-21-acta-constitucion.docx`) · **Criterio de éxito:** «Campaña de perforación del bloque sur en producción y medido.» (acta, sección Criterio de éxito)

> Nota de contexto: el acta tiene un año y el cierre comprometido (2026-10-06) ya pasó. Este es un plan retroactivo sobre un proyecto en ejecución, no el primer plan de uno que arranca. Existe un cronograma v1 (`10-plan/2025-10-21-cronograma-v1.csv`) con cuatro hitos y la línea base v1 de la ficha. Este comando no toca esa línea base ni crea otra. Las preguntas de la última parte sirven igual para un re-plan, pero esa decisión es de quien aprueba.

*Sesión de prueba sin interfaz: no hubo preguntas al gerente. Donde el comando habría preguntado, tomé la respuesta sugerida: planificar sobre el acta tal cual, sin rellenar huecos.*

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| Alcance escrito como «Componente 1; Componente 2; Componente 3», sin decir qué es cada uno | No se pueden derivar entregables del alcance. Los tres componentes entran a la WBS como «sin definir». Cualquier nombre que les ponga yo sería inventado. |
| «Producto asociado: No aplica» y ninguna dependencia declarada («Ninguna declarada») | El orden por dependencia no tiene base escrita. El proyecto necesita licencia ambiental, proveedor, transporte de equipos y una sala de producción, y el acta no registra ninguno como dependencia. |
| Sin autoridad declarada del gerente (la ficha lo marca `not_found`) | No consta qué puede decidir quien planifica y qué debe subir. Las excepciones van a la patrocinadora (Paula Céspedes) por defecto, y eso es un supuesto mío. |
| Sin quién acepta cada entregable | La WBS no puede decir quién recibe cada nodo. La patrocinadora no queda como aceptante por omisión. |
| Criterio de éxito sin medida: «en producción y medido» | No dice medido contra qué, ni cuándo cuenta como «en producción». El nodo de cierre no tiene condición verificable. |
| Fuera de alcance: «Lo que otro proyecto cubre» | No nombra el otro proyecto. El borde del alcance no se puede trazar. |
| Proveedor ausente del acta | El informe de avance y las notas del 2026-10-22 hablan de un proveedor. El acta no lo nombra ni fija su contrato, y no hay contrato en la carpeta. |

Sí están: patrocinadora (Paula Céspedes), gerente (Carlos Peña), comité (Comité de Tecnología), presupuesto aprobado (3.300.000.000 COP), inicio 2025-10-31 y cierre 2026-10-06. Sigo marcando los huecos sin rellenarlos.

## WBS
Nodos terminales por entregable. Ninguna duración tiene fuente citable, así que todas van vacías. Las fechas del cronograma v1 son fechas de hito de la línea base, no duraciones, y las pongo como referencia en la columna de origen.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | sin definir | del acta/cronograma v1: hito, línea base 2026-01-24. Existe `acta-recibo-ingeniería-básica-aprobada.pdf` (2026-10-09) | vacía |
| 2 | Licencia ambiental otorgada | sin definir | del cronograma v1: hito, línea base 2026-04-19. El hito figura cerrado, pero la ficha no registra evidencia de recibo | vacía |
| 3 | Pozos perforados | sin definir | del cronograma v1: hito, línea base 2026-07-13. Existe `acta-recibo-pozos-perforados.md` (2026-10-22) | vacía |
| 4 | Montaje de facilidades | sin definir | del cronograma v1: hito, línea base 2026-10-06. El hito figura cerrado, pero la ficha no registra evidencia de recibo | vacía |
| 5 | Componente 1 | sin definir | del acta (Alcance), solo el nombre. No dice qué entrega | vacía |
| 6 | Componente 2 | sin definir | del acta (Alcance), solo el nombre | vacía |
| 7 | Componente 3 | sin definir | del acta (Alcance), solo el nombre | vacía |
| 8 | Campaña «en producción y medido» (cierre) | sin definir | del acta (Criterio de éxito). Medida y umbral sin definir | vacía |

Supuesto: los nodos 1 a 4 son entregables y no solo hitos de calendario. Se leen como «algo que se recibe», pero el cronograma v1 solo los llama hitos. Los nodos 5 a 7 pueden solaparse con los cuatro hitos, y el acta no permite saberlo.

## Orden
Sin fechas. El acta declara «Ninguna dependencia», así que lo que sigue es un supuesto, no un hecho del acta.

- Supuesto: 1 (ingeniería básica) → 2 (licencia) → 3 (pozos) → 4 (facilidades) → 8 (producción y medición). Es el orden en que el cronograma v1 lista los hitos y el que sugiere el oficio. No consta como dependencia en ningún documento.
- Sin definir: dónde caen los componentes 1 a 3 en esa cadena.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son entregables de la campaña | Si son solo marcas de calendario, la WBS pierde sus nodos concretos |
| El orden 1 → 2 → 3 → 4 → 8 refleja las dependencias reales | Si hay trabajo en paralelo o la licencia se necesita antes, el orden y la ruta crítica cambian |
| Los Componentes 1 a 3 son entregables distintos de los hitos | Si son los mismos hitos con otro nombre, hay nodos duplicados |
| Las excepciones suben a la patrocinadora | Si la autoridad está en el Comité de Tecnología u otra persona, las escaladas van mal dirigidas |
| El plan se hace sobre el acta de 2025 y sigue vigente | Si hubo cambios de alcance o presupuesto después, parte del plan sería obsoleto. La ficha no registra ninguna solicitud de cambio |

Cuando el plan se apruebe, estos supuestos pasan al RAID con doliente (raid-taxonomy). La ficha hoy no tiene ningún supuesto registrado.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Patrocinadora o gerente. El acta no lo dice |
| Quién acepta cada entregable | La patrocinadora, que debe designarlo |
| Qué significa «en producción y medido» (métrica, umbral, fecha) | Patrocinadora y área dueña (Ambiental) |
| Dependencias del proyecto (licencia, proveedor, transporte, sala de producción) | Gerente, con el equipo |
| Autoridad del gerente al planificar | Patrocinadora / Comité de Tecnología |
| Proyecto que cubre lo «fuera de alcance» | Gerente |
| Contrato y alcance del proveedor | Gerente y compras |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-200 no apunta a una carpeta de fichas de la PMO, y en el espacio de trabajo solo hay esta ficha. No traigo referencias de otros proyectos ni estimo por analogía, para evitar una falsa precisión.

Referencia propia, de este mismo proyecto: el cierre comprometido era 2026-10-06 y el informe del 2026-10-19 declara 84 % de avance y estado verde. La proyección de costo declarada es 3.453.463.040 COP contra 3.300.000.000 aprobados. Son datos declarados por el informe, no estimaciones mías. Este comando no contrasta el informe con la evidencia; eso lo hace `/pm-report`.

## Preguntas para el equipo
Una por cada duración vacía:
1. Ingeniería básica: ¿cuánto tomó de principio a fin y cuánto de eso fue espera de aprobación?
2. Licencia ambiental: ¿cuánto toma el trámite y quién lo controla? ¿Hay recibo del hito cerrado?
3. Pozos perforados: ¿cuánto toma por pozo, y cuántos pozos son? El acta no da el número.
4. Montaje de facilidades: ¿cuánto toma, y qué la condiciona? ¿Hay recibo del hito cerrado?
5. Componente 1: ¿qué se entrega y cuánto toma?
6. Componente 2: ¿qué se entrega y cuánto toma?
7. Componente 3: ¿qué se entrega y cuánto toma?
8. Producción y medición: ¿qué se mide, durante cuánto tiempo y quién da el visto bueno?

Además: ¿quién acepta cada entregable? ¿Cuál es el proveedor y qué fecha confirmó para la última entrega? (riesgo abierto en el informe de avance del 2026-10-19).

## Para comprometer una fecha falta
- Disponibilidad real del equipo. Hoy hay 11 asistentes a la reunión del 2026-10-22 y no hay asignación documentada.
- Fecha del proveedor. El informe del 2026-10-19 dice que no ha confirmado la fecha de la última entrega, y las notas del 2026-10-22 dicen que podría no llegar con el equipo completo para la siguiente fase (riesgo no registrado).
- Ventana de la sala de producción. No está en ningún documento.
- Decisión sobre la línea base. Reemplazar la v1 o mantenerla es un acto de autoridad del gerente y la patrocinadora, y este comando no lo ejecuta.

*No se comprometió ninguna fecha, no se asignó ninguna persona y no se creó línea base.*
