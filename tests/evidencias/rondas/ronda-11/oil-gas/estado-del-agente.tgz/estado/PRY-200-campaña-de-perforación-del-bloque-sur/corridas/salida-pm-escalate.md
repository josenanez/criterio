## Para decisión — PRY-200 Campaña de perforación del bloque sur · 2026-10-23

Sin argumento, tomé lo que ya estaba marcado como escalable en la ficha y en la agenda. Los términos estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22); no hubo nada que registrar. No hay cambio de fecha pedido, así que no corrí `impact`: nadie dio un número de días.

### Punto 1 — ¿Qué puede decidir Carlos Peña por sí solo en este proyecto?

**Es el primer punto que escala, antes que cualquier otro.** El acta del 2025-10-21 no declara la autoridad del gerente (ficha: `identity.authority` = no_declarada). Declara patrocinador (Paula Céspedes), comité (Comité de Tecnología), presupuesto aprobado, fechas y «Dependencias declaradas: Ninguna». No dice quién aprueba cambios de fecha, de presupuesto ni de proveedor, ni hasta qué monto decide el gerente.

**Pregunta cerrada:** ¿Paula Céspedes confirma por escrito, como adenda al acta, la autoridad del gerente (opción A) o la deja como está y cada punto sube al Comité de Tecnología (opción B)?

**Quién decide:** Paula Céspedes (patrocinadora) y el Comité de Tecnología, que aprobó el acta. Es el único que puede enmendarla; la facultad no se infiere.
**Si no se decide hoy:** no tiene fecha dura en los documentos. Lo que sí hay es que el cierre comprometido (2026-10-06) ya pasó hace 17 días sin línea base nueva (`changes` vacío), y el comité siguiente es el 2026-11-05 (configuración; las notas del 10-22 dicen «en dos semanas»). Cualquier decisión de fecha o presupuesto que se tome antes puede resultar sin facultad. Es lo único que puedo decir con fecha; no inventé una consecuencia mayor.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda con la autoridad del gerente | Sin cambio | Una firma de la patrocinadora; no sé cuánto tarda | Sin costo directo |
| B. Todo sube al comité | Sin cambio | Cada punto espera al comité (semanal o quincenal, sin definir) | Sin costo directo; el atraso es el costo |

**Recomiendo:** A — un gerente que no sabe qué puede decidir escala todo o nada, y hoy hay seis compromisos reprogramados y un sobrecosto proyectado sin dueño de la decisión.

### Punto 2 — Ricardo Salas: documento 1 (no está listo para llevarse como decisión)

Documento 1 reprogramado seis veces (original 2026-09-30 → 2027-01-15), prueba 2 cinco veces (original 2026-09-15 → 2026-11-29) y diseño 13 vencido sin evidencia (2026-10-05). Cumple el criterio de escalar (reprogramado más de tres veces).

**Lo que falta para formularlo:** los documentos no dicen qué depende de ese documento 1 ni qué bloquea a Ricardo. Sin eso no puedo poner costo en alcance, tiempo y costo, y no lo invento. La pregunta cerrada sería: ¿se acepta el 2027-01-15 como fecha firme (A), o se reasigna el trabajo (B)? Antes de llevarla, Carlos debe hablar con Ricardo y con Paula; esa llamada es suya y casi siempre resuelve el punto.

**Quién decide:** no se puede decir hasta resolver el Punto 1.
**Si no se decide:** la fecha sigue corriéndose en cada comité; es lo que muestran las seis reprogramaciones.

### A quién alcanza
No calculado: `impact` necesita un cambio de fecha en días y no se dio. Dependencias declaradas en el acta: ninguna; riesgo abierto «el proveedor no ha confirmado la fecha de la última entrega», sin dueño.

### Mis hitos por los que pasa
No calculado, por lo mismo. Contexto: «Montaje de facilidades» (2026-10-06) y «Licencia ambiental otorgada» (2026-04-19) figuran como cumplidos sin acta de recibo.

### De dónde sale esto
- Autoridad no declarada y «Dependencias: Ninguna»: `00-gobierno/2025-10-21-acta-constitucion.docx`.
- Reprogramaciones y diseño 13: comités 2026-09-10, 09-17, 09-24, 10-01, 10-08, 10-15 y `2026-10-22-notas-reunion.txt` (línea 4).
- Cierre 2026-10-06 y `changes` vacío: `10-plan/2025-10-21-cronograma-v1.csv` y la ficha.
- Cadencia «en dos semanas»: notas 2026-10-22 (línea 8).

Esto es un paquete para que lo lleves tú; no escala solo ni le escribe a nadie.
