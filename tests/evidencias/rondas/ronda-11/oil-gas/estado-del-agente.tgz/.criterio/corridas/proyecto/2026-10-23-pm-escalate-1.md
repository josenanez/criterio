# Corrida · 2026-10-23-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T06:27:01 · **Fin:** 2026-10-23T06:27:47 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 28 | 17 | Escaló la autoridad no declarada en el acta (primer punto); el escalamiento de Ricardo Salas queda sin formular porque los documentos no dicen qué depende del documento 1. No se corrió impact: no hay días de cambio. |

Por señal (`pm-escalate`): `commitment_overdue` 8, `commitment_undated` 3, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé un paquete de escalamiento con dos puntos: uno listo para llevar al comité y otro que no se puede formular todavía. El segundo es el de Ricardo Salas, y le falta un dato que los documentos no traen.

Los términos ya estaban vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-22), así que no registré nada nuevo. El comando no traía un tema, así que tomé lo que la ficha y la agenda ya marcaban como escalable.

1. **Autoridad del gerente.** El acta del 2025-10-21 no declara qué puede decidir Carlos Peña. Por eso es el primer punto, antes de cualquier otro.
   - **Pregunta:** ¿Paula Céspedes confirma esa autoridad por escrito como adenda al acta (opción A), o cada punto sube al Comité de Tecnología (opción B)?
   - **Recomiendo A.** Hoy hay seis compromisos reprogramados y un sobrecosto proyectado sin nadie que tenga clara la facultad de decidir.
   - **Qué pasa si no se decide:** no encontré una fecha dura en los documentos, así que no inventé una consecuencia. Lo que sí consta es que el cierre comprometido (2026-10-06) ya pasó hace 17 días sin línea base nueva.
2. **Ricardo Salas.** Tiene el documento 1 reprogramado seis veces (de 2026-09-30 a 2027-01-15), la prueba 2 cinco veces y el diseño 13 vencido sin evidencia. Ya cumple el criterio para escalar. Pero los documentos no dicen qué depende del documento 1, y sin eso no puedo poner el costo de cada opción. La llamada de Carlos con Ricardo y Paula viene antes del comité.

No corrí el cálculo de impacto sobre otros proyectos porque nadie dio un cambio de fecha en días, y no estimé nada por mi cuenta.

La salida completa está en `estado/PRY-200-campaña-de-perforación-del-bloque-sur/corridas/salida-pm-escalate.md`. La corrida quedó registrada como `2026-10-23-pm-escalate-1`.
