# Corrida · 2026-10-23-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T06:11:12 · **Fin:** 2026-10-23T06:12:25 · **Duración:** 73 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 18 | — | 43 | 31 | 7 aceptados sin evidencia, 4 sin criterio, 1 sin doliente (REQ-4204), 2 propuestos sin decidir (REQ-4202, REQ-4211); traza no confirmada: no hay fichas de proyecto |

Por señal (`product-requirements`): `requirement_untraced` 16, `requirement_accepted_without_evidence` 7, `requirement_without_acceptance` 4, `requirement_undecided` 2, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Registro — Gas para generación (PRD-302) · al 2026-10-23

El registro tiene 18 requerimientos: 16 aceptados y 2 propuestos. De los 16 decididos, el 56,2 % tiene evidencia. No pude medir cuántos tienen un proyecto que los ejecute: no existe carpeta de fichas de proyecto, así que la traza quedó sin confirmar.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez), así que no los registré otra vez.

**Orden de lectura**
1. **Se va a construir y nadie lo pidió (7):** REQ-2038, 4203, 4204, 4205, 4207, 4209 y 4215 están aceptados sin una sola cita de quien los pidió.
2. **Decidido y nadie lo construye (16):** ningún aceptado tiene proyecto confirmado. Es «sin traza confirmada», no «confirmado que nadie lo construye». Falta la carpeta de fichas de proyecto. Si me dice dónde está, lo recalculo y puedo ofrecer `/product-trace`.
3. **Sin doliente (1):** REQ-4204 no tiene doliente en el acta del 21-oct.
4. **Sin criterio de aceptación (4):** REQ-2038, 4201, 4204 y 4214. REQ-4211 también carece de criterio, pero está propuesto y no se le exige.
5. **Lleva meses sin decidirse (2):** REQ-4202 (116 días) y REQ-4211 (75 días), ambos de Rubén Cárdenas. Quien tiene la facultad de decidir es el Comité de producto. Lo que corresponde es decidirlos, no cerrarlos por viejos.
6. **Decidido sin documento:** ninguno. Los 16 decididos citan un documento, pero en ninguno consta quién decidió.
7. **Evidencia vieja:** ninguna. Lo más reciente es del 20-may, y el umbral es de 12 meses.

**Fuera del registro**
- El supuesto «La comunidad respalda el proyecto» lleva 124 días sin verificar, con un umbral de 30.
- Volumen mensual del caso de negocio: 115.628 declarado contra 98.962 medido, una brecha de 14,4 %. Está bajo el umbral de 20 %, así que no es hallazgo.
- La definición no declara criterio de éxito.

La corrida quedó registrada como `2026-10-23-product-requirements-1`: 31 hallazgos, 43 segundos. La salida completa está en `estado-producto/PRD-302/corridas/salida-product-requirements.md`.

Como ningún aceptado tiene todo en orden (evidencia, criterio y doliente), no ofrezco `/product-charter`.
