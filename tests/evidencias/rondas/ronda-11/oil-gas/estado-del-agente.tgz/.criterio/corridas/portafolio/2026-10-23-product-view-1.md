# Corrida · 2026-10-23-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view gas para generación

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T06:51:22 · **Fin:** 2026-10-23T06:52:08 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 33 | 54 | Producto con un solo proyecto (PRY-208), sin sección; 9 proyectos sin producto declarado reportados; no sé si alguno sirve a este producto ni el área dueña de cada uno. |

Por señal (`product-view`): `milestone_met_without_evidence` 22, `commitment_overdue` 11, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `milestone_overdue` 1, `silent` 1

## Lo que el agente mostró

**Productos al 2026-10-23.** Esta vista sale de las fichas de `estado/` (13 proyectos), recalculadas hoy. Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los volví a registrar.

**«gas para generación» tiene un solo proyecto, PRY-208 «Reducción de quema de gas».** Con un solo proyecto la vista por producto no aporta nada, así que no armé una sección aparte. Esto es lo que dice el cálculo de PRY-208:
- **Alertas:** 7 abiertas. Son un avance declarado del 51 % contra un plan que respalda entre 80 y 100 %, y tres hitos dados por cumplidos sin evidencia (Ingeniería básica aprobada, Licencia ambiental otorgada y Montaje de facilidades). Se suman un compromiso vencido hace 4 días (Ricardo Salas, «Entregar el punto 12») y un entregable atrasado del proveedor Integridad y Corrosión S.A.S. («Alquiler del taladro», pendiente desde 2026-01-05). La séptima es el estado «verde» declarado el 2026-10-14, que las anteriores contradicen.
- **Fecha más tardía:** 2026-11-23, sin desviación frente a la línea base.
- **Dinero:** 800.000.000 COP aprobados y 622.315.470 comprometidos. El proyecto trae las cifras completas (1 de 1).
- **Dependencias:** no hay ninguna declarada.

**Otros productos:** PRD-299 (PRY-199, 0 alertas), «monitoreo de pozos» (PRY-205, 2) y «transporte de gas» (PRY-202, 6) también tienen un solo proyecto cada uno.

**Proyectos sin producto declarado:** son 9 de 13: PRY-200, 201, 203, 204, 206, 207, 209, 210 y 211. Nadie puede responder por el conjunto al que sirven. Si alguno alimenta «gas para generación», esta vista está incompleta sin que se note. Que PRY-211 o PRY-201 lo hagan es solo una conjetura por el nombre, y ningún documento lo dice. Tampoco tengo el área dueña de cada uno, porque el cálculo no la trae.

Los 13 proyectos tienen la autoridad sin declarar.

Dejé la salida completa en `estado/corridas/salida-product-view.md`. La corrida quedó registrada como `2026-10-23-product-view-1` (33 segundos, 13 proyectos, 54 hallazgos abiertos en el portafolio).
