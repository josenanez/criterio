# Corrida · 2026-10-23-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T06:53:01 · **Fin:** 2026-10-23T06:54:47 · **Duración:** 106 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 21 | 54 | Barrido: 66 documentos sin cambios, nada que recalcular. Confirmación: 5 preguntas formuladas, sin respuesta (prueba sin interfaz). No se atendieron peticiones (no tocaban). No sé si los 'verde' declarados se sostienen con documentos fuera de la carpeta. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 22, `commitment_overdue` 11, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `milestone_overdue` 1, `silent` 1

## Lo que el agente mostró

## 2026-10-23

**Revisé:** 66 documentos. Ninguno cambió, así que no recalculé ningún proyecto. Hoy tocaban el barrido y la confirmación mensual. Los términos v1.2 ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta registrarlos de nuevo.

### Lo que cruzó un umbral
Nada nuevo desde la última corrida. Sigue abierto lo del informe de portafolio de hoy:
- **PRY-209:** el hito "Pozos perforados" lleva 10 días vencido sin evidencia.
- **PRY-210:** lleva 21 días en silencio.

### Peticiones atendidas
Ninguna. Hoy no tocaba revisar peticiones.

### Preguntas
Nadie responde en esta prueba sin interfaz. Dejé las preguntas formuladas una sola vez y sin respuesta, con el dato actual de la ficha del 2026-10-23:
1. **PRY-200:** estado "verde" (declarado el 2026-10-19). ¿Se mantiene con 2 hitos sin evidencia y 9 compromisos vencidos?
2. **PRY-204:** estado "verde" (declarado el 2026-10-22). ¿Se confirma con un sobrecosto proyectado de 20,5 %?
3. **PRY-210:** estado "verde" (declarado el 2026-10-02). ¿Sigue vigente tras 21 días sin documentos?
4. **PRY-209:** hito "Pozos perforados" (fecha 2026-10-13). ¿Se cumplió y qué documento lo sustenta?
5. **Autoridad aprobadora:** no está registrada en las 13 fichas. ¿Quién es, empezando por PRY-200?

No sé si los "verde" declarados se sostienen con documentos que estén fuera de la carpeta.

Dejé registrados el barrido, la confirmación y la corrida (21 s). La salida está en `estado/corridas/salida-portfolio-wake.md`.

**Vuelvo el 2026-10-24.**

## Respuesta 2

El mapa de Rostrum quedó escrito con 3 agentes de la familia pmo: Vera (portafolio), Samuel (PRY-200) y Alba (PRD-302). No dejé ninguno fuera. El comando para levantar el portal es `/criterio-server:server-start`.

- **Términos:** la versión 1.2 quedó aceptada a nombre de José Francisco Ñáñez. Los comprobantes están en `.criterio/terminos/aceptacion-criterio-server-0.8.0-2026-10-23.md` y `.pdf`, y llevan la fecha 2026-10-23, la del sistema, no la 2026-10-22 de la instrucción.
- **Orden del flujo:** guardé el mapa antes de revisar los términos, al revés de lo previsto. `terminos` exige el `config.json` de Rostrum, que solo crea `guardar`.
- **Nombre de la organización:** no pasé `--organizacion`, y no sé si la configuración de la PMO lo trae. Si falta, `guardar` se puede repetir con ese dato.
- **Carpetas sin marca:** las de PRY-200 y PRD-302 siguen sin marca. Se marcan con `/criterio-project:pm-setup` y `/criterio-product:product-setup`.

## Respuesta 3

Arrancó bien y la prueba de 8 segundos lo cortó, como se esperaba. Era una verificación y no queda nada corriendo.

## Rostrum, para mirarlo un rato

Levantó sin problemas. El mapa y el disco coinciden: no hay entradas nuevas ni sin estado. Los términos (v1.2) estaban vigentes, así que no hubo que registrar aceptación.

El mapa tiene 3 entradas: el portafolio (Vera), PRY-200 (Samuel) y PRD-302 (Alba), todas de la familia PMO.

Para volver a levantarlo y dejarlo abierto:

```
python3 "/home/claude/banco/plugins/criterio-server/scripts/servidor.py" --mapa /tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/oil-gas/espacio/.criterio/rostrum/config.json
```

Escucha en `127.0.0.1:8787`, solo en ese equipo. Si el puerto está ocupado, agrega `--puerto 8788`. Se detiene con Ctrl-C.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con los agentes, una puerta por familia y el formulario de peticiones | Todos |
| `/pmo` | Informes de la PMO | La PMO y el patrocinador |
| `/decisiones` | Material del comité | El comité |
| `/proyectos` | 13 proyectos | La PMO |
| `/productos` | 4 productos | Producto y la PMO |
| `/corridas` | 33 corridas de los agentes | Quien audita |
| `/estado.json` | De cuándo es cada cosa y cuántas peticiones hay abiertas | Un mecanismo, no una persona |

Rutas como `/caso/<código>`, `/vence` o `/familia/…` solo aparecen si el mapa tiene esas familias. Aquí solo hay PMO.

**Qué enlace pasarle a quién:**
- Al patrocinador: `/`.
- Al comité: `/decisiones`.
- A quien audita: `/corridas`.

Cada página dice de cuándo es lo que muestra. Los informes en `reportes/` son del 2026-10-23, 06:52. Conviene decírselo a quien reciba el enlace.

**Límites:**
- Rostrum sirve lo que los agentes ya escribieron. No calcula, no autentica y no manda correos.
- El único archivo que crea es la petición, en `peticiones/` del agente elegido en el formulario. Esa petición espera hasta que ese agente despierte.
- Un enlace que funcione mañana requiere la otra forma, «que quede corriendo». Esa forma necesita un host y puerto internos, y que lo publiquen detrás de su control de acceso. Esa pregunta no se hizo en esta sesión.
