# Corrida · 2026-10-23-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T06:55:06 · **Fin:** 2026-10-23T06:55:54 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 18 | — | 29 | 31 | 16 requerimientos decididos sin proyecto; PRY-208 declara «gas para generación» y ningún REQ lo nombra |

Por señal (`product-trace`): `requirement_untraced` 16, `requirement_accepted_without_evidence` 7, `requirement_without_acceptance` 4, `requirement_undecided` 2, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Trazabilidad: Gas para generación (PRD-302), al 2026-10-23

De 18 requerimientos, 16 están decididos y ninguno tiene proyecto. No hay trazas que confirmar, porque ningún requerimiento dice qué proyecto lo ejecuta. Se cruzó contra las 13 fichas de `estado/records`.

**Decidido y nadie lo está construyendo.** Son los 16 requerimientos aceptados. El acta del comité del 2026-10-21 trae «—» en la columna «Proyecto que lo ejecuta» para todos. Los más antiguos:
- REQ-4204 lleva 207 días aceptado, sin doliente, sin criterio de aceptación y sin evidencia.
- REQ-4215 lleva 195 días, sin evidencia de demanda.
- REQ-4206 lleva 189 días.
- REQ-4213 lleva 185 días.

El acta no dice quién decidió cada uno. En la tabla, «Decidido el» es la fecha desde la que figuran como aceptados. REQ-4202 y REQ-4211 siguen en «propuesto» (116 y 75 días), así que son otra brecha, la de lo que nadie decide.

**Lo que un proyecto construye y el registro no tiene.** La ficha de PRY-208 (Reducción de quema de gas) dice que su producto es «gas para generación». Ningún requerimiento lo nombra. La coincidencia es solo por nombre, porque la ficha no trae el código PRD-302. Hay que ir a ver si PRY-208 es en realidad un proyecto de este producto. No lo decido desde aquí.

**Cadena.** Cada requerimiento llega hasta la decisión del comité y ahí se rompe, porque no hay proyecto. Sin proyecto no hay entregables que citar.

**Fichas.**
- Diez fichas no dicen qué producto ejecutan: PRY-200, 201, 203, 204, 206, 207, 209, 210 y 211. Eso es un hallazgo del lado de cada proyecto. Cualquiera podría estar construyendo algo de este producto y no se puede saber.
- Otras tres declaran producto y apuntan a otros: PRY-199 (PRD-299), PRY-202 («transporte de gas») y PRY-205 («monitoreo de pozos»).

**Después.** Con los 16 decididos sin proyecto, `/criterio-product:product-charter` sirve para el requerimiento que ya esté listo para volverse proyecto. Lo de PRY-208 y las diez fichas sin producto es una conversación con esos gerentes de proyecto.

**Términos y corrida.** Los términos de la versión 0.8.0 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-23, así que no hubo que registrarlos de nuevo. La corrida quedó registrada como `2026-10-23-product-trace-1`: 31 hallazgos, 29 segundos. El texto completo está en `estado-producto/PRD-302/corridas/salida-product-trace.md`.
