# Corrida · 2026-10-23-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-23T06:47:47 · **Fin:** 2026-10-23T06:49:18 · **Duración:** 91 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 72 | 54 | Cierre no sustentado: proyecto al 84% declarado en verde, criterio de éxito sin evidencia de producción ni medición, 2 de 4 hitos sin evidencia, 0 replanificaciones con fecha de cierre vencida. Dijo que no sabe: componentes del alcance, costo y fecha finales, aceptación del cliente. No se movió a archivo. |

Por señal (`project-closure`): `milestone_met_without_evidence` 22, `commitment_overdue` 11, `progress_vs_plan` 6, `declared_vs_evidence` 5, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `milestone_overdue` 1, `silent` 1

## Lo que el agente mostró

**PRY-200 no se puede cerrar contra su criterio de éxito.** El último informe, del 2026-10-19, lo declara en verde con 84% de avance. Si el comité lo cierra, será por decisión suya y no por cumplimiento.

- **Criterio de éxito:** el acta dice «en producción y medido». Ningún documento muestra producción ni medición, así que no se puede decir que se cumplió.
- **Hitos:** el cronograma marca los 4 como cumplidos, pero dos no tienen evidencia: la licencia ambiental y el montaje de facilidades.
- **Avance:** el plan sostiene 100% y el informe dice 84%, una diferencia de 16.0 puntos que no se puede reconciliar con lo que hay en la carpeta.
- **Fecha:** el cierre planificado era el 2026-10-06 y ya pasó. No hubo replanificaciones ni solicitudes de cambio, así que es un atraso sin línea base nueva.
- **Presupuesto:** de 3.300.000.000 COP aprobados, el informe declara 537.252.237 ejecutados (16.3%) y 1.025.532.379 comprometidos (31.1%). La proyección al cierre es 3.453.463.040, un 4.7% sobre lo aprobado. Estas cifras no son finales, y no hay proveedores registrados para contrastarlas con lo facturado.
- **RAID y compromisos:** hay 2 riesgos de proveedor sin doliente. Uno se comentó en la reunión del 2026-10-22 y nadie lo registró. Hay 8 compromisos vencidos, 3 sin fecha y 2 reprogramados 6 y 5 veces.
- **Lecciones:** solo incluí las que se pueden anclar a un hecho documentado. No incluí ninguna sobre el bloqueo de ocho días, porque ningún documento dice qué efecto tuvo.

No sé qué son los componentes 1, 2 y 3 del alcance, ni el costo o la fecha finales, ni quién aceptó los entregables por parte del cliente.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los registré de nuevo. No moví la carpeta a `archivo/` porque el proyecto sigue abierto. Mi recomendación es no cerrar, pedirle a Carlos Peña (el gerente) que explique la diferencia entre 84% y 4 de 4 hitos y que cargue las dos evidencias que faltan, y llevar una replanificación formal al comité del 2026-10-29.

La corrida quedó registrada como `2026-10-23-project-closure-1`. El texto completo está en `estado/corridas/salida-project-closure.md`.
