# Corrida · 2026-10-23-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-302

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-302

**Inicio:** 2026-10-23T08:31:21 · **Fin:** 2026-10-23T08:31:31 · **Duración:** 10 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No existe `.criterio/producto/PRD-302/config.json`: el único producto configurado aquí es PRD-309, no PRD-302. No busco la configuración en otro sitio ni la invento, así que me detengo. `/product-overlap` no se ejecutó, y tampoco los términos, el arranque de la corrida ni el cruce.

Si quieres cruzar PRD-309, vuelve a lanzar el comando con ese código. Si PRD-302 es un producto nuevo, ejecuta antes `/criterio-product:product-setup`.
