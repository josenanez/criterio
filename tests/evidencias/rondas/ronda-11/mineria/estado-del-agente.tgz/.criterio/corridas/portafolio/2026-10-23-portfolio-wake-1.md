# Corrida · 2026-10-23-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T08:27:59 · **Fin:** 2026-10-23T08:30:04 · **Duración:** 125 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 44 | 80 | Barrido sin cambios (93 documentos); confirmación: 5 preguntas sobre identity.authority (PRY-207, 210, 201, 211, 204), sin respuesta por sesión sin interfaz. No se atendieron peticiones (no había). |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 18, `declared_vs_evidence` 9, `commitment_overdue` 8, `vendor_deliverable_late` 7, `commitment_undated` 6, `variance_time` 6, `progress_vs_plan` 5, `vendor_accepted_without_evidence` 4, `rebaseline_unauthorized` 4, `variance_cost` 3, `commitment_rescheduled` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_invoiced_without_delivery` 2, `budget_committed` 1

## Lo que el agente mostró

Hoy tocaban el barrido diario y la confirmación periódica, y ya quedaron registrados. La corrida quedó guardada con el id `2026-10-23-portfolio-wake-1` y tardó 44 segundos.

- **Términos:** ya estaban vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no pedí aceptarlos de nuevo.
- **Barrido:** revisé 93 documentos y ninguno cambió. No hay nuevos, renombrados ni borrados, ni citas rotas, así que no recalculé ningún proyecto.
- **Peticiones:** no había ninguna en el servidor.
- **Confirmación:** elegí cinco campos. Pregunto por la autoridad que aprueba (`identity.authority`), que figura como no encontrada en los 13 proyectos. Elegí los proyectos por importancia:
  - **PRY-207:** Gemelo digital de la planta, el único en rojo.
  - **PRY-210:** Programa de relacionamiento comunitario, en amarillo y de los tres mayores presupuestos.
  - **PRY-201:** Ampliación de la relavera, de los tres mayores presupuestos.
  - **PRY-211:** Control de polvo en vías, de los tres mayores presupuestos.
  - **PRY-204:** Monitoreo de taludes, cuarto en presupuesto.
- **Sin respuesta:** en esta sesión nadie podía contestar. Las cinco quedan como «preguntada el 2026-10-23, sin respuesta» y no escribí nada en las fichas. La próxima corrida no las repite.

Las 80 señales abiertas de la corrida (por ejemplo, hitos cumplidos sin evidencia) vienen de fichas ya calculadas. Este barrido no las produjo ni las revisó.

Vuelvo el 2026-10-24. El informe de comité toca el 2026-10-27, para el comité del 2026-10-29.

Lo que mostré está en `estado/corridas/salida-portfolio-wake.md`.

## Respuesta 2

El mapa quedó con 3 entradas de la familia pmo: Vera (portafolio), Samuel (PRY-204) y Alba (PRD-309). No dejé ninguna fuera. El mapa está en `.criterio/rostrum/config.json`, con rutas relativas a la carpeta de trabajo. Para levantar el portal, usa `/criterio-server:server-start`.

- **Términos:** quedaron aceptados a nombre de José Francisco Ñáñez (versión 1.2, criterio-server 0.8.0). Las instrucciones decían fecha 2026-10-22, pero el comprobante lleva la fecha real del sistema, 2026-10-23. Los comprobantes están en `.criterio/terminos/aceptacion-criterio-server-0.8.0-2026-10-23.md` y `.pdf`.
- **Cambio de orden:** guardé el mapa antes de mostrar los términos, porque `terminos` falla mientras `config.json` no existe.
- **Organización:** no puse `--organizacion`, porque en esta sesión nadie podía darme el nombre. Queda sin nombre en el mapa.

## Respuesta 3

Rostrum está corriendo en `http://127.0.0.1:8787/`, solo en este equipo y en modo «para mirarlo un rato». Lo dejé en segundo plano, con el registro en `/tmp/claude-0/-tmp-claude-0--home-claude-692b0e4d-0e89-5e8d-a391-2cabbf233557-scratchpad-r11-mineria-espacio/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/rostrum.log`.

**Términos.** Ya estaban vigentes (versión 1.2, aceptada para 0.8.0) y registrados a nombre de José Francisco Ñáñez con fecha 2026-10-23. No volví a registrar nada. Los términos completos están en https://www.josenanez.com/es/agents/criterio-pmo/legal. En corto, Criterio produce borradores, no decisiones ni asesoría, y cada dato lleva la cita del documento de donde sale, así que la verificación es de quien lo usa.

**Mapa contra disco.** No hay entradas nuevas, ni desaparecidas, ni sin estado. Las tres entradas son Vera (`portafolio`), Samuel (`proyecto/PRY-204`) y Alba (`producto/PRD-309`), todas de la familia PMO.

**Qué hay y para quién:**
- **`/`**: la portada, con los tres agentes y el formulario de peticiones. Es para todos.
- **`/pmo`, `/decisiones`**: el informe de la PMO y el material del comité. Es para la PMO, el comité y el patrocinador.
- **`/proyectos`**: 13 proyectos (PRY-199 a PRY-211).
- **`/productos`**: 6 productos.
- **`/corridas`**: 33 corridas registradas, para quien audita.
- **`/estado.json`**: para un mecanismo, no para una persona.
- **`/caso/<código>`**: todo lo que los agentes hicieron sobre un caso.
- **`/vence`**: lo pendiente con fecha. No aparece en las direcciones que imprimió el servidor y no lo probé.
- **`/familia/cfo` y `/familia/clo`**: no existen aquí, porque el mapa solo tiene la familia PMO.

**Frescura.** El informe de la PMO es del 2026-10-23, 13:27 UTC. Los tres agentes aparecen con `ultimo: null` (sin corrida registrada), con 0 peticiones abiertas y sin próxima corrida programada. El portal los muestra como pendientes y no les inventa nada.

**Qué enlace pasar a quién.** Con este modo, ninguno funciona fuera de este equipo ni mañana:
- Patrocinador: `/`, o `/pmo` si solo quiere el informe.
- Comité: `/decisiones`.
- Gerencia: `/vence`, si abre.

Para tener un enlace estable hay que cambiar a «que quede corriendo». Se pide un host y un puerto dentro de la red y publicarlo detrás del control de acceso que la organización ya usa, porque el servidor no autentica. No necesita nada más. Con el servidor funcionando, se arranca con `--abierto`.

Para pararlo: `pkill -f servidor.py`.
