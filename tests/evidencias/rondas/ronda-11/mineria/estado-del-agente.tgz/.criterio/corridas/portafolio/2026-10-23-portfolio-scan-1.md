# Corrida · 2026-10-23-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T07:58:52 · **Fin:** 2026-10-23T08:06:11 · **Duración:** 439 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 93 | 418 | 80 | Leídos 69 de 93 documentos en 10 proyectos (PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210); PRY-202, 209 y 211 sin cambio. Nada movido: no existe entrada/. Ningún archivo ilegible (los 9 xml se convirtieron). Mirar: hitos cerrados sin acta (PRY-206, 210, 200), cronograma v2 con CC-01 sin decisión (PRY-204, 208), facturas sin acta (PRY-204, 208, 200), compromisos vencidos y reprogramados en PRY-204. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 18, `declared_vs_evidence` 9, `commitment_overdue` 8, `vendor_deliverable_late` 7, `commitment_undated` 6, `variance_time` 6, `progress_vs_plan` 5, `vendor_accepted_without_evidence` 4, `rebaseline_unauthorized` 4, `variance_cost` 3, `commitment_rescheduled` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_invoiced_without_delivery` 2, `budget_committed` 1

## Lo que el agente mostró

Terminé el barrido. Leí 69 de los 93 documentos y escribí y sellé 10 fichas nuevas: PRY-199, 200, 201, 203, 204, 205, 206, 207, 208 y 210. PRY-202, 209 y 211 no tuvieron cambios y no se releyeron.

- **Términos:** vigentes en la versión 0.8.0, a nombre de José Francisco Ñáñez, 2026-10-23.
- **No se pudo leer:** nada. El inventario marcó 9 cronogramas `.xml` como no legibles, pero el conversor los leyó todos. Leí 6 de ellos.
- **`entrada/`:** no existe, así que no moví ni dejé pendiente ningún archivo.
- **Campos sin dato:** 24 en `not_found`. La autoridad y la fase no aparecen en ningún documento de los 10 proyectos. El producto falta en PRY-201, 205, 206 y 210, porque el acta dice «No aplica».
- **Tiempo:** la corrida midió 418 segundos. El script cuenta 80 hallazgos en los 13 proyectos, incluidos PRY-202, 209 y 211.

Lo principal que dejó el barrido:
- **Hitos cerrados sin acta:** PRY-206 (los 3 hitos), PRY-210 (los 4) y PRY-200 (3 de 5).
- **Cierre comprometido ya pasado:** PRY-200, 203, 205 y 210. Los tres primeros declaran verde y PRY-210 amarillo.
- **Cronograma v2 con la solicitud de cambio sin decisión:** PRY-204 y PRY-208. PRY-205 tiene dos solicitudes pendientes y ningún cronograma.
- **Facturas sin respaldo de acta:**
  - PRY-208 radicó una factura con los tres entregables aún pendientes.
  - PRY-204 radicó dos facturas antes de la fecha del entregable, y una supera su valor.
  - PRY-200 radicó una factura que no nombra los entregables, y solo uno tiene acta.
- **Compromisos de PRY-204:** son 26: 3 cumplidos con acta, 8 vencidos y 15 abiertos. «Cerrar la prueba 2» se reprogramó 6 veces. La última fecha sale de las notas como «02/01/2027»: la leí día/mes (2027-01-02) y falta confirmarla con el gerente.
- **`ficha-pm.json` de PRY-204:** la guardé entera en `pm_record`, sin fusionarla con mi lectura.

Dejé la salida completa y el rastro de la corrida en `estado/corridas/`, y la instantánea en `estado/snapshots/2026-10-23.json`. Con más de un proyecto con ficha, puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`.

Archivos en `estado/corridas/`:
- `salida-portfolio-scan.md`
- `2026-10-23-portfolio-scan-1.md`
