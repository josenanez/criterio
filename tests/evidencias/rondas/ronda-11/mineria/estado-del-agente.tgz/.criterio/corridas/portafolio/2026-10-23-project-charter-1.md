# Corrida · 2026-10-23-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-205 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-23T08:17:51 · **Fin:** 2026-10-23T08:18:45 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 30 | 80 | Revisión del acta de PRY-205 (2025-11-19): sin autoridad del gerente, supuestos, restricciones, hitos ni cadencia; objetivo, alcance y exclusiones son marcadores vacíos. No se supo si existe delegación verbal fuera de los documentos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 18, `declared_vs_evidence` 9, `commitment_overdue` 8, `vendor_deliverable_late` 7, `commitment_undated` 6, `variance_time` 6, `progress_vs_plan` 5, `vendor_accepted_without_evidence` 4, `rebaseline_unauthorized` 4, `variance_cost` 3, `commitment_rescheduled` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_invoiced_without_delivery` 2, `budget_committed` 1

## Lo que el agente mostró

## Acta de PRY-205, Sistema de gestión de seguridad

El acta existe y es del 2025-11-19. Hice la revisión con las 4 carpetas de documentos del proyecto: el acta, CC-01, CC-02 y el informe de avance del 2026-10-19. Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez), así que no registré nada nuevo.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente.** Falta, y es el vacío principal. No hay umbral de monto ni de cambio de alcance que Óscar Ramírez pueda decidir sin comité. Por eso CC-01 (+170.000.000 COP, +85 días) y CC-02 (+92.000.000 COP, +46 días) están pendientes de comité. Juntas son 262.000.000 COP y +131 días.
- **Objetivo, alcance y exclusiones.** El objetivo describe la solución ("Entregar sistema de gestión de seguridad"). El alcance es "Componente 1, 2, 3" y las exclusiones son "Lo que otro proyecto cubre". Sin alcance real no hay contra qué medir que CC-01 y CC-02 sean una ampliación.
- **Supuestos, restricciones, hitos y cadencia del comité.** No están en el acta. El informe de avance reporta 43% sin hitos contra los cuales verificarlo.
- **Criterio de éxito.** Solo dice "en producción y medido". No dice qué se mide, con qué meta ni quién lo mide.
- **Dependencias.** El acta dice "Ninguna declarada", pero el informe menciona un plan de arranque acordado con operaciones.
- **Fecha de cierre.** El cierre comprometido era el 2026-08-12 y ya pasaron 72 días sin una línea base nueva aprobada. Aun así el informe declara "verde". Esto no es un vacío del acta, pero conviene verlo en un `/health-check`.

**Lo que no sé:** si existe alguna delegación verbal o un acta ampliada fuera de estos documentos.

**Siguientes pasos que ofrezco:**
- Llevar la definición de la autoridad del gerente al comité con `/steering-pack`.
- Pasar los supuestos y riesgos sin dueño al registro RAID con `/raid-log`.

La salida completa está en `estado/corridas/salida-project-charter.md`. La corrida quedó registrada con el id `2026-10-23-project-charter-1`.
