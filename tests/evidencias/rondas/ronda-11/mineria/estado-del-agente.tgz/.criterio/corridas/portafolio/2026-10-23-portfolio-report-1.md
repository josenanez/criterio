# Corrida · 2026-10-23-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T08:26:31 · **Fin:** 2026-10-23T08:27:53 · **Duración:** 82 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 93 | 42 | 80 | Primera instantánea, sin delta. 9 proyectos en verde contradichos por la evidencia; mirar PRY-209, PRY-204 y PRY-208 primero. Ninguno de los 13 tiene autoridad registrada. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 18, `declared_vs_evidence` 9, `commitment_overdue` 8, `vendor_deliverable_late` 7, `commitment_undated` 6, `variance_time` 6, `progress_vs_plan` 5, `vendor_accepted_without_evidence` 4, `rebaseline_unauthorized` 4, `variance_cost` 3, `commitment_rescheduled` 3, `milestone_overdue` 2, `vendor_invoiced_over_accepted` 2, `vendor_invoiced_without_delivery` 2, `budget_committed` 1

## Lo que el agente mostró

Generé el informe en HTML (23 páginas) y dejé la corrida registrada. Cargué las 13 fichas, todas del 2026-10-23, así que no hay fichas viejas que advertir. Los términos ya estaban vigentes: versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23.

**Qué cambió:** nada. Solo existe la instantánea de hoy, así que esta corrida es el punto de partida y no hay delta.

**Qué encontró:** 11 de 13 proyectos tienen hallazgos, con 80 señales en total. En 9 de ellos el informe de avance declara verde y la evidencia lo contradice: PRY-200, 201, 202, 203, 204, 206, 208, 209 y 211. Mirar primero estos tres:
- **PRY-209 Electrificación de equipos:** va 211 días atrasado (77 %), con costo +15,8 % y la línea base movida 96 días sin autorización. Tiene entregables de proveedores vencidos y facturación por encima de lo aceptado.
- **PRY-204 Monitoreo de taludes:** va 84 días atrasado y +19,6 % en costo. Tiene 8 compromisos vencidos y Montajes Industriales facturó 291,5 M COP sobre lo aceptado.
- **PRY-208 Trazabilidad del mineral:** declara 83 % de avance cuando el plan sostiene entre 20 y 40 %, y hay 555,2 M COP facturados sin entregables recibidos.

**Secciones vacías:** no hay contradicciones abiertas, proyectos en silencio ni dependencias en riesgo. Las fichas no declaran dependencias por código. No toca confirmación mensual hoy.

**Vacíos de información:**
- Ninguno de los 13 proyectos tiene autoridad registrada.
- 7 proyectos no tienen producto asociado: PRY-201, 202, 205, 206, 209, 210 y 211.

**Qué vista va a quién** (en `reportes/`):
- **`index.html`:** va para quien actúa. Está organizada por campo y trae la cadena de evidencia completa.
- **`decisiones.html`:** va para el patrocinador. Está organizada por decisión y solo trae lo que excede la facultad de quien gerencia.
- **PDF:** sale de imprimir el HTML.
- **Otras páginas:** hay una por proyecto y una por producto.

El resumen que dejé como evidencia de la corrida está en `estado/corridas/salida-portfolio-report.md`. Quedó registrada como `2026-10-23-portfolio-report-1`.

Pie: criterio-portfolio 0.8.0, 13 fichas del 2026-10-23, 0 campos inciertos. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

Puedo armar el material de comité para el 2026-10-29 o entrar al detalle de los tres proyectos de arriba.
