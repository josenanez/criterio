# Corrida · 2026-10-23-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T07:46:19 · **Fin:** 2026-10-23T07:47:26 · **Duración:** 68 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 39 | 21 | Reprogramados: Andrés Lozano (6), Elena Duarte (5), Sandra Gil (4); 8 vencidos sin evidencia, 4 sin fecha |

Por señal (`pm-commitments`): `commitment_overdue` 8, `commitment_undated` 4, `commitment_rescheduled` 3, `vendor_accepted_without_evidence` 2, `variance_time` 1, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — Monitoreo de taludes (PRY-204) · al 2026-10-23

Los términos ya estaban vigentes (v1.2, aceptados el 2026-10-22), así que no los registré de nuevo. No pasaste ninguna minuta, así que revisé lo abierto con la ficha que ya existía. `compute` no trajo `record_issues`.

**Se viene reprogramando.** Tres compromisos han cambiado de fecha 3 veces o más. Ninguno es un problema de seguimiento: son bloqueos que nadie ha nombrado.
- **Andrés Lozano, "Cerrar la prueba 2":** 6 reprogramaciones. Pasó del 2026-10-08 al 2027-01-02. Esa última fecha viene de las notas del 22-oct («02/01/2027»), que leí como día/mes; falta confirmarla con el gerente. El responsable es el propio gerente del proyecto.
- **Elena Duarte, "Revisar el anexo 3":** 5 reprogramaciones. Pasó del 2026-09-13 al 2026-12-08.
- **Sandra Gil, "Enviar el documento 1":** 4 reprogramaciones. Pasó del 2026-09-25 al 2026-12-02.

**Vencidos sin evidencia (8).**
- **Sandra Gil, documento 9:** 22 días.
- **Rubén Cárdenas, punto 8:** 21 días.
- **Beatriz Cuéllar, prueba 10:** 14 días.
- **Javier Hoyos, fecha 7:** 12 días.
- **Felipe Arango, punto 16:** 11 días.
- **Jorge Medina, matriz 6:** 8 días.
- **Óscar Ramírez, ambiente 20:** 2 días.
- **Jorge Medina, anexo 11:** 1 día.

Cuatro de esos (Rubén Cárdenas, Beatriz Cuéllar, Jorge Medina y Javier Hoyos) dicen haber entregado, pero no hay acta en el expediente. Siguen abiertos hasta que haya un documento. Desde el 8-oct ya no aparecían en la lista de abiertos del comité.

**Vencen esta semana (hasta el 30-oct).** Carlos Peña, anexo 19, y Paula Céspedes, punto 24, ambos hoy. María Restrepo, matriz 22, el 29-oct. Rubén Cárdenas, prueba 18, el 30-oct.

**Sin fecha (4).** Andrés Lozano tiene dos (matriz 14 y documento 17), Javier Hoyos una (diseño 21) y Laura Vélez una (ajuste del presupuesto, "la otra semana"). No pueden estar vencidos, por eso van aparte.

**Cerrados desde la última revisión:** ninguno nuevo.

La ficha declara el proyecto en verde (informe del 22-oct). Contra ese verde hay 8 compromisos vencidos y 3 reprogramados 4 veces o más.

**Siguiente paso:** puedo formular los tres reprogramados como decisión para el comité con `/criterio-project:pm-escalate`: qué se pide, qué pasa si no se decide y quién tiene la facultad. Como uno de ellos es del gerente, conviene que lo suba otra persona. No cambié la ficha, así que `/pm-publish` no hace falta.

La salida completa está en `estado/PRY-204-monitoreo-de-taludes/corridas/salida-pm-commitments.md`. La corrida quedó registrada como `2026-10-23-pm-commitments-1`: 21 hallazgos y 39 segundos medidos.
