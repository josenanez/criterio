## Trazabilidad — Inspección con drones (PRD-309) · al 2026-10-23
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: 13 (`estado/records`, PRY-199 a PRY-211). Ninguna nombra PRD-309.

### Decidido y nadie lo está construyendo
Los 13 requerimientos aceptados tienen `traces.project = null`. Todos citan como fuente de la decisión `30-decisiones/2026-10-17-comite-producto.docx`. En ningún requerimiento consta quién decidió (`decision.who` = not_found), así que la columna «Por quién» queda con el dueño del requerimiento, no con quien decidió.

| REQ | Título | Decidido el (fecha en el registro) | Dueño |
|---|---|---|---|
| REQ-4905 | Requerimiento REQ-4905 | 2026-03-31 | Rubén Cárdenas |
| REQ-4910 | Requerimiento REQ-4910 | 2026-04-22 | Carlos Peña |
| REQ-4911 | Requerimiento REQ-4911 | 2026-06-08 | Ricardo Salas |
| REQ-4913 | Requerimiento REQ-4913 | 2026-06-11 | Paula Céspedes |
| REQ-4907 | Requerimiento REQ-4907 | 2026-06-26 | Elena Duarte |
| REQ-4909 | Requerimiento REQ-4909 | 2026-07-01 | Beatriz Cuéllar |
| REQ-4906 | Requerimiento REQ-4906 | 2026-07-02 | Ricardo Salas |
| REQ-4903 | Requerimiento REQ-4903 | 2026-07-06 | Liliana Torres |
| REQ-4902 | Requerimiento REQ-4902 | 2026-07-09 | Rubén Cárdenas |
| REQ-4901 | Requerimiento REQ-4901 | 2026-08-05 | Mauricio Pérez |
| REQ-4900 | Requerimiento REQ-4900 | 2026-08-15 | Beatriz Cuéllar |
| REQ-4908 | Requerimiento REQ-4908 | 2026-09-03 | Liliana Torres |
| REQ-2028 | Requerimiento REQ-2028 | 2026-10-13 | María Restrepo |

Los más viejos llevan entre 6 y 7 meses decididos sin proyecto (REQ-4905, 206 días; REQ-4910, 184). Hay una incoherencia en el registro que conviene mirar: las fechas de decisión van de marzo a octubre, pero el único acta que las respalda es del 2026-10-17.

### La traza no se confirma
Ninguna. No hay requerimiento que diga ejecutarlo un proyecto, así que no hay traza que contrastar con una ficha. Ninguna traza se da por confirmada.

### Lo que un proyecto construye y el registro no tiene
Ninguno. De las 13 fichas, ninguna dice ejecutar PRD-309 ni nada de inspección con drones. Lo que declaran: PRY-199 → PRD-299; PRY-200 «monitoreo de flota»; PRY-203 «despacho de flota»; PRY-204 «alerta de taludes»; PRY-207 «gemelo digital»; PRY-208 «trazabilidad»; las otras siete (PRY-201, 202, 205, 206, 209, 210, 211) dejan el campo vacío. Esa vacuidad es un hallazgo del lado de esas fichas, no de este producto: no se puede descartar que alguna ejecute PRD-309 sin decirlo.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 13 aceptados (tabla de arriba) | aceptado | comité del 2026-10-17, cita en cada uno | — | no | — |
| REQ-4904, REQ-4912 | propuesto | sin decisión (183 y 208 días) | — | no | — |

La cadena se rompe en el segundo eslabón en los 13: hay decisión con cita y no hay proyecto.

### Sin fichas a la vista
No falta ninguna ficha por acceso: se leyeron las 13 de `estado/records`. Lo que falta es el vínculo: ningún proyecto está asociado a este producto, ni desde el registro ni desde una ficha.

Cobertura: de lo decidido, 0 de 13 con proyecto, 0 con entregable con evidencia, 0 entregados.
