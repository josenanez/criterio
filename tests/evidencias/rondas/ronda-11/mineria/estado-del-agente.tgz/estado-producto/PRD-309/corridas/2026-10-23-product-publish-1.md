# Corrida del 2026-10-23 · product-publish

PRD-309 · 15 requerimientos · 14 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

No se publicó: no hay carpeta de productos publicados configurada

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-309 (Inspección con drones): no hay carpeta de productos publicados configurada.

La configuración (`.criterio/producto/PRD-309/config.json`) solo trae `documents` y `state`; no hay una ruta de publicación, y no encontré ninguna carpeta `productos/publicados` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la inventé ni escribí en otro lado.

**Lo que habría publicado (corte 2026-10-23, gerente Laura Vélez):**
- Requerimientos: 15 (13 aceptados, 2 propuestos), todos con proyecto sin asignar.
- Proyectos: 0.
- Segmento declarado: Supervisores.
- Métricas afirmadas: 1 con cifra, `volumen_mensual` = 270035.0, de `00-definicion/2026-03-17-caso-de-negocio.md` (2026-03-17). Otras 3 afirmaciones de la definición y del caso de negocio no traen métrica nombrada ni cifra.

Cuando se acuerde la carpeta común, se añade su ruta a la configuración y se vuelve a correr.
