Términos: vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-22; comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-22.md`). No hizo falta volver a registrarlos.

**Paso 1 · ¿Hay con qué?** REQ-4900 no cumple todo lo que el acta exige:
- Aceptado: **sí** (2026-08-15, comité de producto del 2026-10-17). Pero el documento no dice quién lo decidió.
- Criterio de aceptación: existe uno, «se verifica en producción». No dice qué se mide ni con qué umbral, así que no es verificable en sentido estricto.
- Evidencia de demanda: **falta**. El registro no trae ninguna cita, y en el comité la columna «Quién lo pidió» dice «—».
- Autoridad del gerente: **falta** (`authority` es null en la configuración y la definición no la declara).

Se sigue sin ellos, marcándolos como vacíos del acta y sin rellenarlos (respuesta sugerida, tomada en esta prueba sin interfaz).

---

# Acta de constitución — REQ-4900 · borrador del 2026-10-23
**Producto:** PRD-309 · Inspección con drones · **Requerimientos:** REQ-4900

## Qué problema resuelve
«El segmento Supervisores no tiene inspección con drones.» (`00-definicion/2026-03-17-definicion-producto.md`).
Es el problema del producto, no el de REQ-4900. La necesidad propia de REQ-4900 **no está dicha en ningún documento**: su título es solo «Requerimiento REQ-4900» (`30-decisiones/2026-10-17-comite-producto.docx`).

## Criterio de éxito
| Criterio | Cita | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `30-decisiones/2026-10-17-comite-producto.docx` | No está dicho: sin métrica, umbral ni responsable de verificar. |

La definición del producto tampoco declara criterio de éxito (`success`: no encontrado).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | **Ninguna.** La única entrevista del producto (2025-08-21, «Lo necesito y hoy no lo tengo.») no nombra este requerimiento ni dice que el entrevistado sea Supervisor, y además es de hace 14 meses. El registro no la asocia a REQ-4900. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028, 4901, 4902, 4903, 4904, 4905, 4906, 4907, 4908, 4909, 4910, 4911, 4912, 4913 | «Requerimiento REQ-xxxx» (todos con ese título genérico) | Esta acta se pidió solo para REQ-4900. **No hay en los documentos una razón de exclusión por requerimiento**; no la invento. Quien firme debe decir cuáles se quedan fuera y por qué, o pedir un acta que los incluya. |

## Gobierno
**Patrocinador:** no está dicho en ningún documento.
**Gerente propuesto:** no está dicho. Laura Vélez figura como gerente del *producto* (`00-definicion/2026-03-17-definicion-producto.md`), no como gerente de un proyecto; este comando no nombra gerente.
**Comité:** comité de producto, mensual (configuración); el del 2026-10-17 tuvo como único asistente a Laura Vélez. No hay comité de proyecto definido.
**Autoridad del gerente:** no está dicha (`authority` null). Doliente del requerimiento: Beatriz Cuéllar (`30-decisiones/2026-10-17-comite-producto.docx`).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La licencia ambiental lo permite» (declarado 2026-05-15, `00-definicion/2026-03-17-definicion-producto.md`) | No | Riesgo del proyecto. **Doliente sin asignar**; lo asigna el gerente del proyecto al registrarlo con `raid-taxonomy`. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Operación de drones / licencia ambiental | No determinada | Ninguna citada en los documentos; no se hizo barrido normativo | Sin resolver. Lo único que hay es el supuesto de la licencia ambiental, sin verificar. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Evidencia de demanda propia de REQ-4900 | El proyecto arranca sobre un pedido que nadie ha citado; el cierre no podrá decir si resolvió algo pedido | Beatriz Cuéllar (doliente) |
| Quién decidió la aceptación | No se sabe quién tiene la facultad si se discute el alcance | Laura Vélez |
| Criterio de aceptación verificable | «Se verifica en producción» no permite juzgar el cierre meses después | Beatriz Cuéllar |
| Necesidad y título propios de REQ-4900 | Nadie puede decir qué se construye | Beatriz Cuéllar |
| Criterio de éxito del producto | Sin referencia contra la cual medir | Laura Vélez |
| Autoridad del gerente | Escala todo o no escala nada | Quien nombre al gerente (no identificado) |
| Patrocinador y gerente del proyecto | El acta no tiene quién la firme ni quién la reciba | No identificado |
| Verificación de la licencia ambiental | El proyecto puede construir algo que no se puede operar | Gerente del proyecto, con doliente por nombrar |
| Razón de exclusión de los otros 14 REQ | Discusión de alcance en el tercer mes | Quien firme |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (no identificada en los documentos). La ficha del proyecto se crea después de la firma; **no se ha creado ninguna ficha ni se ha escrito `declared`**.

**Después:** firmada el acta, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella. Recomendación: cerrar antes la evidencia, el criterio de aceptación y la autoridad; con tantos vacíos, firmar hoy sería arrancar a medias.
