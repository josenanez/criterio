## Registro — Inspección con drones (PRD-309) · al 2026-10-23
15 requerimientos · 13 decididos · 84.6% con evidencia · 0.0% con proyecto que lo ejecuta

Nota de alcance: no hay carpeta de fichas de proyecto en este espacio, así que `compute` corrió sin `--fichas`. Ningún requerimiento tiene proyecto asignado; no es que una ficha lo niegue, es que no hay ficha que lo confirme.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | aceptado (2026-08-15) | Beatriz Cuéllar |
| REQ-4907 | Requerimiento REQ-4907 | aceptado (2026-06-26) | Elena Duarte |

Ninguno tiene una sola cita de quien lo pidió. Los dos tienen criterio de aceptación.

### Decidido y nadie lo está construyendo
Los 13 aceptados, ninguno con proyecto que lo ejecute:
| REQ | Decidido el | Doliente |
|---|---|---|
| REQ-4905 | 2026-03-31 | Rubén Cárdenas |
| REQ-4910 | 2026-04-22 | Carlos Peña |
| REQ-4911 | 2026-06-08 | Ricardo Salas |
| REQ-4913 | 2026-06-11 | Paula Céspedes |
| REQ-4907 | 2026-06-26 | Elena Duarte |
| REQ-4909 | 2026-07-01 | Beatriz Cuéllar |
| REQ-4906 | 2026-07-02 | Ricardo Salas |
| REQ-4903 | 2026-07-06 | Liliana Torres |
| REQ-4902 | 2026-07-09 | Rubén Cárdenas |
| REQ-4901 | 2026-08-05 | Mauricio Pérez |
| REQ-4900 | 2026-08-15 | Beatriz Cuéllar |
| REQ-4908 | 2026-09-03 | Liliana Torres |
| REQ-2028 | 2026-10-13 | María Restrepo |

REQ-4905 y REQ-4910 llevan más de seis meses aceptados sin proyecto.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4912 | Requerimiento REQ-4912 | Sin doliente (no aparece en ningún documento). Estado: propuesto |

### Sin criterio de aceptación
Solo decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-4901 | Requerimiento REQ-4901 | aceptado |
| REQ-4903 | Requerimiento REQ-4903 | aceptado |
| REQ-4913 | Requerimiento REQ-4913 | aceptado |

REQ-4904 (propuesto) tampoco lo tiene, y no se le exige.

### Decidido sin documento que lo respalde
No calculado: `compute` no emite esta señal y el registro no trae el documento de decisión como campo comprobable. No lo afirmo ni lo descarto; hay que mirarlo requerimiento por requerimiento (`/product-requirements REQ-xxxx`).

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4912 | Requerimiento REQ-4912 | 208 días (desde 2026-03-29) | No está definido: `authority` es null en la configuración |
| REQ-4904 | Requerimiento REQ-4904 | 183 días (desde 2026-04-23) | No está definido: `authority` es null en la configuración |

Esto no se cierra por viejo: se propone decidirlo. Antes hay que nombrar quién tiene la facultad; hoy nadie la tiene escrita. La gerente de producto es Laura Vélez, y además es doliente de REQ-4904.

### Evidencia vieja
Los 13 requerimientos que tienen evidencia (11 aceptados y 2 propuestos) se apoyan en lo mismo: una entrevista del 2025-08-21, de hace 14 meses, con la cita «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). El registro marca que esa cita no nombra ninguno de los requerimientos. Es una sola fuente repetida, no 13 pedidos.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2028, 4901, 4902, 4903, 4904, 4905, 4906, 4908, 4909, 4910, 4911, 4912, 4913 | 2025-08-21 | 14 meses |

### Fuera de los requerimientos
Supuesto sin verificar en la definición: «La licencia ambiental lo permite», 161 días. No tiene a quién cerrarlo asignado.
Desconocidos en la definición: criterio de éxito y autoridad.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 13 | 0 | 0 | 0 |

Quién cierra cada vacío: los dolientes de la tabla (cada uno el suyo) para evidencia, criterio y proyecto; Laura Vélez para nombrar la autoridad que decida REQ-4904 y REQ-4912.

Después: hay 13 decididos que nadie construye, así que corresponde `/product-trace`. Un `/product-charter` solo es posible para un aceptado con evidencia y criterio, y todos los que lo cumplen tienen evidencia vieja y un único origen; habría que renovarla antes.
