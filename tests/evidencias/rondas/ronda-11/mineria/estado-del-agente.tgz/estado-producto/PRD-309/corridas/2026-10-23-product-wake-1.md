# Corrida del 2026-10-23 · product-wake

PRD-309 · 15 requerimientos · 35 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Primera revisión, sin corte previo: reporté lo vigente. No pude confirmar trazas (no hay carpeta de fichas). No sé quién decide (authority vacío) ni el criterio de éxito. Sin fecha de comité.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Inspección con drones (PRD-309) · 2026-10-23

**Desde el corte anterior:** no hay corte anterior. Esta es la primera revisión, así que todo lo de abajo es lo que hay hoy, no lo que cambió. Desde el próximo corte solo se reportará lo nuevo.

**Términos:** ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22). No hubo que pedir nada.

**Qué tocaba:** solo `review` (cada 30 días, sin corrida previa). El comité no tiene fecha (`committee_next` vacío), así que no hay informe de comité.

### Lo que lleva tiempo sin decidirse
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto, sin decisión | REQ-4912 | 208 días (desde 2026-03-29) | Un doliente y una decisión. Además no tiene doliente. | **Falta el dato.** La configuración tampoco nombra quién tiene la facultad de decidir (`authority`: vacío). |
| Propuesto, sin decisión | REQ-4904 | 183 días (desde 2026-04-23) | Una decisión | Laura Vélez (doliente) |

Dato que falta en ambos: quién decide. Se puede llevar al comité cuando tenga fecha.

### Supuesto sin verificar
- «La licencia ambiental lo permite»: 161 días sin verificar. Verificarlo requiere la licencia ambiental vigente o la confirmación escrita de quien la gestiona, contrastada con la operación con drones. A 161 días ya conviene tratarlo como riesgo registrado (assumption-tracking). Este comando no lo verifica.

### Evidencia que ya no sostiene la definición
- 13 de 15 requerimientos se apoyan solo en las entrevistas del 2025-08-21, que cumplen 14 meses. La cita («Lo necesito y hoy no lo tengo.», tema «Necesidad principal») no nombra ningún requerimiento en concreto. La afirmación de la definición que se queda sin sustento reciente es que Supervisores necesita inspección con drones.

### Aceptados sin sustento propio
- Sin evidencia de demanda: REQ-4900 y REQ-4907.
- Sin criterio de aceptación: REQ-4901, REQ-4903 y REQ-4913.

### Las trazas
Ninguna se da por confirmada. No hay carpeta de fichas configurada, y ningún documento de proyectos nombra PRD-309. Los 13 requerimientos aceptados figuran sin proyecto, es decir, 13 decisiones que nadie está construyendo, o cuya construcción no consta.

### Del descubrimiento
No hay documentos nuevos. Sigue siendo la entrevista del 2025-08-21. La definición y el caso de negocio son del 2026-03-17 y no declaran criterio de éxito. La cifra de volumen mensual (270.035) no tiene medición contra la cual contrastarla.

### Desconocido
Criterio de éxito de la definición, y quién tiene la autoridad de decidir sobre el producto.

**Vuelvo el 2026-11-22.**
