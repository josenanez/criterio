# Corrida del 2026-10-23 · product-setup

PRD-309 · 15 requerimientos · 26 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); una sola conversación hasta el primer resultado; 15 requerimientos levantados, 13 alertas de evidencia vieja, 13 aceptados sin proyecto, quién decide no está en ningún documento

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Inspección con drones (PRD-309)

**Lo que miré:** 4 documentos · 1 de descubrimiento (entrevistas del 2025-08-21) · la definición del 2026-03-17 · lo más reciente, el acta del comité del 2026-10-17 · todos legibles (el .docx del comité lo leí extrayendo su texto).
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2, fecha 2026-10-22) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 97ef3d7200b125fa…
**Configuración:** `.criterio/producto/PRD-309/config.json` · estado en `estado-producto/PRD-309` · carpeta marcada con `_CRITERIO_PRODUCTO.txt`.
**Registro levantado:** la ficha del producto y 15 requerimientos (13 aceptados, 2 propuestos) tomados del acta del comité.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Supervisores no tiene inspección con drones» | Una sola entrevista: «Lo necesito y hoy no lo tengo.» No dice que quien habla sea Supervisor ni qué es «lo» | 2025-08-21 (14 meses) |
| Volumen mensual de 270.035 | Solo el propio caso de negocio; ninguna serie medida | 2026-03-17 |
| Retorno esperado en 24 meses | Nada: no trae cifra, base ni cálculo | 2026-03-17 |
| Propuesta principal | Nada: la propuesta no tiene contenido escrito | 2026-03-17 |

### Lo que no está dicho en ninguna parte
- **Quién decide qué se construye.** Ningún documento lo nombra; el acta del comité solo lista a Laura Vélez como asistente. Sin él no hay acta de constitución posible.
- **El criterio de éxito del producto.** La definición no lo trae.
- **En qué consiste la propuesta.** Dice «Propuesta principal» y nada más.
- **De dónde sale el 270.035 mensual y cómo se llega al retorno en 24 meses.** Y no hay ninguna serie medida a la vista: nadie está midiendo lo que el caso de negocio afirmó.
- **Qué proyecto construye algo.** La definición dice «Ninguno declarado» y el acta no pone proyecto en ninguno de los 15 requerimientos: de 13 aceptados, 0 tienen traza (0,0 %).
- **Quién pidió REQ-4900 y REQ-4907** (aceptados sin evidencia de demanda), **qué criterio de aceptación tienen REQ-4901, REQ-4903 y REQ-4913** (aceptados sin criterio), y **quién es el doliente de REQ-4912** («sin asignar»).
- **Qué dice cada requerimiento:** el acta solo les pone el título «Requerimiento REQ-49xx»; el problema de cada uno queda sin escribir.
- **Quién los pidió, en concreto.** El acta dice «Cliente entrevistado» en 11 de 13; la única entrevista es una frase genérica que no nombra ninguno de ellos.

### Supuestos sobre los que está escrita
- **«La licencia ambiental lo permite»** · declarado el 2026-05-15 · sin verificar · 161 días así.
- Es el único que el documento declara. No declara supuesto alguno sobre el volumen, el retorno ni la demanda.

### Lo que el cálculo marca en el registro
- Evidencia vieja (14 meses, entrevista del 2025-08-21): 13 requerimientos.
- Aceptados sin proyecto que los ejecute: 13.
- Aceptados sin evidencia de demanda: 2 · sin criterio de aceptación: 3.
- Propuestos sin decidir: 2 (REQ-4904, 183 días; REQ-4912, desde 2026-03-29) · sin doliente: 1.
- Acta del 2026-10-17: «Se mantiene el plan», sin decisión por requerimiento ni quién decidió.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas: hoy hay una sola frase de un solo cliente, de hace 14 meses.
- La serie medida de la métrica principal (volumen mensual) con su fuente.
- Las decisiones del comité con quién decide y qué decidió sobre cada requerimiento; sin ellas un descartado se ve igual que uno que nadie miró.
- Estructura recomendada, solo como sugerencia: `00-definicion/`, `10-descubrimiento/`, `20-metricas/`, `30-decisiones/` (ya tienes tres de cuatro; falta `20-metricas/`). No moví ni creé nada en tu carpeta.

### Siguiente
`/product-discovery` sobre las entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
