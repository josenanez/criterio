# Corrida del 2026-10-23 · product-definition

PRD-309 · 15 requerimientos · 26 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

De 4 afirmaciones, 1 sostenida por una entrevista débil y vieja (14 meses), 3 no están dichas en ninguna parte; 1 supuesto sin verificar 161 días; faltan criterio de éxito y autoridad

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Definición — Inspección con drones (PRD-309) · contrastada al 2026-10-23
**Documento:** 00-definicion/2026-03-17-definicion-producto.md y 2026-03-17-caso-de-negocio.md · **del** 2026-03-17 · 4 afirmaciones

### Lo que la evidencia contradice
Nada. No hay una fuente que diga lo contrario de lo que la definición afirma.

### El negocio y los datos
Ninguna métrica pasa del umbral: no hay serie medida contra la cual comparar.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Volumen mensual de 270.035 | 00-definicion/2026-03-17-caso-de-negocio.md (2026-03-17) | Sin serie medida ni fuente más allá del propio caso. No es contradicción: nadie está midiendo esta cifra. |

### No está dicho en ninguna parte
- «Retorno esperado en 24 meses» (caso de negocio, 2026-03-17): sin cifra, base ni cálculo.
- «Propuesta principal» (definición, 2026-03-17): la propuesta no tiene contenido.
- El volumen mensual de 270.035: ninguna fuente lo respalda salvo el propio caso (ver arriba).
- Criterio de éxito: no declarado.
- Quién decide (autoridad): no declarado.
- Proyectos que lo construyen: «Ninguno declarado»; los 13 requerimientos aceptados no tienen proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La licencia ambiental lo permite (declarado 2026-05-15) | 161 | Un documento de la autoridad ambiental competente, o un concepto jurídico, que cubra la operación con drones en el segmento. Además está escrito sin alcance (¿qué licencia, qué sitios?), lo que dificulta verificarlo. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Supervisores no tiene inspección con drones | Entrevista a un cliente: «Lo necesito y hoy no lo tengo» (10-descubrimiento/2025-08-21-entrevistas.md) | 2025-08-21 | Débil: es una sola persona, lo que dijo es que lo usaría (no que pagó) y el documento no dice que sea Supervisor. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento Supervisores no tiene inspección con drones | Entrevista del 2025-08-21 | 14 meses |

### Lo normativo que toca
No tengo la norma a la vista. El barrido cubre datos personales, pagos, consumidor financiero y retención de información, y la definición no los menciona. Sí menciona una licencia ambiental (el supuesto de arriba). El país no consta en la configuración y no cito normas de memoria. Esto es para revisión jurídica; no dice si cumple.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él la definición no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** no declarado (autoridad sin asignar).
- Problema y para quién: están dichos (Supervisores), pero con evidencia débil y vieja.
- El comité del 2026-10-17 decidió «Se mantiene el plan» con la definición en este estado.
