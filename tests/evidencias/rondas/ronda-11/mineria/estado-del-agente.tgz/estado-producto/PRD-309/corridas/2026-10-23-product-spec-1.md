# Corrida del 2026-10-23 · product-spec

PRD-309 · 15 requerimientos · 50 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador sin comportamiento redactable: 13 aceptados sin necesidad/titulo, 10 con criterio 'se verifica en producción' no verificable, 3 sin criterio, 0 con proyecto, 2 sin evidencia; sin pais para barrido normativo; no se rellenó ningún vacío.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

> **Esto es un borrador de trabajo, no una especificación aprobada.** Lo escribió el agente desde el registro; lo cierra Laura Vélez (gerente de producto). El agente no decide el alcance, no diseña, no estima y no aprueba.

# Especificación — Inspección con drones (PRD-309) · borrador del 2026-10-23

**Resultado en una línea:** con el registro actual **no se puede redactar comportamiento para ningún requerimiento**. Los 15 registros tienen el título vacío («Requerimiento REQ-49xx») y la necesidad en `not_found`. Rellenarlo con lo razonable sería decidir por el equipo; por eso las secciones de comportamiento quedan a la vista como vacías.

## Qué problema resuelve
«El segmento Supervisores no tiene inspección con drones.» (`00-definicion/2026-03-17-definicion-producto.md`). Es una ausencia declarada, no un problema descrito: no dice qué hace hoy el Supervisor ni qué le cuesta no tenerlo.
- Sustento: una sola entrevista genérica (2025-08-21), «Lo necesito y hoy no lo tengo.» No dice que el entrevistado sea Supervisor y no nombra ningún requerimiento. Tiene 14 meses.
- Criterio de éxito del producto: no está dicho en ninguna parte.
- La «Propuesta principal» de la definición no tiene contenido.

## Alcance
### Entra
Nada se puede declarar con sustento. Candidatos por estado en el registro (la decisión de alcance es del gerente de producto):
- 13 requerimientos `aceptado` (comité 2026-10-17): REQ-4900, 4901, 4902, 4903, 4905, 4906, 4907, 4908, 4909, 4910, 4911, 4913 y REQ-2028.

### No entra
- REQ-4904 y REQ-4912: están `propuesto`. El comité no decidió nada sobre ellos; especificarlos sería escribir el documento dos veces. REQ-4912 además no tiene doliente («sin asignar»).
- Todo lo que no figura en el registro. La definición no lista proyectos que lo construyan («Ninguno declarado»).
- Diseño técnico, estimación de esfuerzo, costo y fechas (no son de este documento).

## Comportamiento
**Sin contenido.** Ningún requerimiento aceptado dice qué necesidad cubre (`need` = `not_found` en los 13). No se redacta ninguna sección de comportamiento porque cualquier texto sería del agente y no del registro.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-17) | REQ-4900, 4902, 4905, 4906, 4907, 4908, 4909, 4910, 4911, 2028 | **No pasa la prueba:** no dice qué se observa ni con qué umbral, así que dos personas pueden llegar a respuestas distintas. Es dónde se verifica, no qué. | No verificable todavía. Ningún documento muestra qué medición existe |
| Sin criterio en el acta | REQ-4901, 4903, 4913 | — | — |

Todavía no hay criterio verificable para ninguno de los 13. Redactar uno (p. ej. un umbral de tiempo o de cobertura) sería inventar la necesidad.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La licencia ambiental lo permite» (declarado 2026-05-15) | No. Sin cita de verificación. Lleva 5 meses sin verificarse y por ser de la definición, si cae, cae el producto entero. Además: la fecha 2026-05-15 es posterior a la de la definición (2026-03-17), sin explicación en los documentos | Sin dueño en los documentos. Propongo a Laura Vélez asignarlo |
| Que el entrevistado de 2025-08-21 representa a Supervisores | No dicho en ninguna parte; no está declarado como supuesto por el autor | Laura Vélez (realizó la ronda) |

Los 13 requerimientos no declaran supuestos propios (`assumptions` vacío).

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Necesidad** de cada requerimiento aceptado (13 sin título ni `need`) | No hay qué especificar ni qué construir | Cada doliente: Beatriz Cuéllar (4900, 4909), Mauricio Pérez (4901), Rubén Cárdenas (4902, 4905), Liliana Torres (4903, 4908), Ricardo Salas (4906, 4911), Elena Duarte (4907), Carlos Peña (4910), Paula Céspedes (4913), María Restrepo (2028) |
| **Criterio de aceptación** ausente en REQ-4901, 4903, 4913 y no verificable en los otros 10 | Nadie podrá decir si quedó bien sin discutir | Dolientes anteriores, con Laura Vélez |
| **Evidencia de demanda**: REQ-4900 y REQ-4907 no tienen ninguna; los otros 11 apoyan en la misma entrevista genérica de 2025-08-21 que no nombra el requerimiento | Aceptados sin que nadie lo haya pedido de forma comprobable | Laura Vélez |
| **Proyecto que ejecute** cada aceptado: ninguno tiene (`traces.project` vacío; la columna del acta está en «—») | Lo decidido nadie lo construye; no se puede pasar a `/product-charter` | Laura Vélez / comité de producto |
| **Quién decidió** la aceptación: el acta solo lista como asistente a Laura Vélez y su única decisión es «Se mantiene el plan» | Decisión sin autoridad identificable (la configuración tampoco tiene `authority`) | Comité de producto; definir la autoridad en la configuración |
| **Casos borde** (sin conexión, falla del dron, datos duplicados, clima, etc.) | Sin comportamiento definido; ningún documento los menciona | Laura Vélez con los dolientes, tras definir la necesidad |
| **Lo que otro equipo tiene que hacer** (operación de drones, ambiental, TI): ningún documento nombra equipos ni acuerdos | Dependencias sin acordar quedan ocultas | Laura Vélez |
| **Propuesta principal** y **criterio de éxito** de la definición vacíos | No hay contra qué medir el producto | Laura Vélez |
| **Cifras del caso de negocio**: «volumen mensual 270.035» sin serie ni fuente (más allá del propio caso) y «retorno esperado en 24 meses» sin cifra ni cálculo | Cualquier criterio de volumen o desempeño quedaría sin base | Laura Vélez (preparó el caso) |
| REQ-2028 sale de la serie (REQ-49xx) y es el más reciente (2026-10-13) | Posible registro ajeno o de otro origen; sin comprobar | Laura Vélez |
| REQ-4912 sin doliente y REQ-4904 propuestos pendientes | Siguen sin decisión | Laura Vélez / comité |

### Obligaciones normativas (barrido, sin opinar sobre cumplimiento)
**No hay país declarado** en la definición ni en el caso de negocio, así que no se cita ninguna norma.
| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Operar drones en las instalaciones | no dicho | Autorización/reglas de aviación civil para operar aeronaves no tripuladas | — | no tengo la norma a la vista |
| «La licencia ambiental lo permite» | no dicho | Condiciones de la licencia ambiental del sitio | — | sin resolver (es el supuesto no verificado) |
| Imágenes/datos captados por dron (puede incluir personas) | no dicho | Tratamiento de datos personales, si se capta a personas | — | no tengo la norma a la vista |
| Conservación de imágenes de inspección | no dicho | Retención y trazabilidad | — | no tengo la norma a la vista |

Todo esto va a revisión jurídica; es el insumo, no el dictamen.

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4900 | sin título (no dice qué pide) | Necesidad `not_found`; sin evidencia; criterio no verificable |
| REQ-4901 | ídem | Necesidad `not_found`; sin criterio de aceptación |
| REQ-4902 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4903 | ídem | Necesidad `not_found`; sin criterio |
| REQ-4905 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4906 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4907 | ídem | Necesidad `not_found`; sin evidencia; criterio no verificable |
| REQ-4908 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4909 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4910 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4911 | ídem | Necesidad `not_found`; criterio no verificable |
| REQ-4913 | ídem | Necesidad `not_found`; sin criterio |
| REQ-2028 | ídem | Necesidad `not_found`; criterio no verificable; fuera de la serie |

**Cobertura: 0 de 13 requerimientos aceptados.** Ninguno tiene proyecto.

## Después
No se ofrece `/product-charter`: los vacíos no están cerrados, no hay criterio de éxito del producto y ningún requerimiento tiene criterio verificable.

---
**Pie:** sale del registro `estado-producto/PRD-309/requirements/` (15 requerimientos leídos: 13 aceptados, 2 propuestos), con comité de producto del 2026-10-17, definición y caso de negocio del 2026-03-17 y entrevistas del 2025-08-21; registro actualizado el 2026-10-23. Cubre 0 requerimientos con comportamiento. Términos aceptados (v1.2, criterio-product 0.8.0, por José Francisco Ñáñez el 2026-10-22): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
