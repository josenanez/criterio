# Corrida del 2026-10-23 · product-business-case

PRD-309 · 15 requerimientos · 33 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada sin serie, retorno sin cifra, costos ausentes (primer vacío), 3 supuestos, 9 vacíos; no se produjo ninguna cifra.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Inspección con drones (PRD-309) · borrador del 2026-10-23
**Desde:** definición del 2026-03-17 (00-definicion/2026-03-17-definicion-producto.md) y caso de negocio del 2026-03-17 · **Cifras con fuente:** 0 de 1 (la única cifra tiene fuente, pero es el propio caso: ninguna fuente independiente)

Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22). Este borrador es de trabajo, no una decisión; la verificación es de quien lo lee. Las cifras son del negocio: aquí no se proyecta, calcula ni estima nada.

## Qué problema resuelve, y para quién
«El segmento Supervisores no tiene inspección con drones.» (definición, 2026-03-17). Sustento: una entrevista a un cliente del 2025-08-21, «Lo necesito y hoy no lo tengo» (10-descubrimiento/2025-08-21-entrevistas.md). Es débil: una sola persona, el documento no dice que sea Supervisor, y tiene 14 meses.

## Qué se construye
Los decididos son 13 aceptados, según el comité del 2026-10-17 (30-decisiones/2026-10-17-comite-producto.docx). Ninguno tiene proyecto que lo ejecute. Los 2 propuestos (REQ-4904, REQ-4912) quedan fuera del caso.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4900 | aceptado 2026-08-15 | Nadie lo pidió (sin cita) |
| REQ-4901 | aceptado 2026-08-05 | «Cliente entrevistado», 2025-08-21 |
| REQ-4902 | aceptado 2026-07-09 | «Cliente entrevistado», 2025-08-21 |
| REQ-4903 | aceptado 2026-07-06 | «Cliente entrevistado», 2025-08-21 |
| REQ-4905 | aceptado 2026-03-31 | «Cliente entrevistado», 2025-08-21 |
| REQ-4906 | aceptado 2026-07-02 | «Cliente entrevistado», 2025-08-21 |
| REQ-4907 | aceptado 2026-06-26 | Nadie lo pidió (sin cita) |
| REQ-4908 | aceptado 2026-09-03 | «Cliente entrevistado», 2025-08-21 |
| REQ-4909 | aceptado 2026-07-01 | «Cliente entrevistado», 2025-08-21 |
| REQ-4910 | aceptado 2026-04-22 | «Cliente entrevistado», 2025-08-21 |
| REQ-4911 | aceptado 2026-06-08 | «Cliente entrevistado», 2025-08-21 |
| REQ-4913 | aceptado 2026-06-11 | «Cliente entrevistado», 2025-08-21 |
| REQ-2028 | aceptado 2026-10-13 | «Cliente entrevistado», 2025-08-21 |

La demanda de los 11 con cita es una sola entrevista repetida, que no nombra ningún requerimiento: no son 11 pedidos.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| Volumen mensual | 270.035 | **Declarada** | Caso de negocio (00-definicion/2026-03-17-caso-de-negocio.md), autoría de Laura Vélez. Sin serie medida, sin base de cálculo | 2026-03-17 |
| Retorno esperado en 24 meses | sin cifra | **Supuesta** (la frase está, el número no) | Mismo caso de negocio; sin cifra, base ni cálculo | 2026-03-17 |

### Donde la cifra declarada y la medida no coinciden
Ninguna: no hay serie medida (estado-producto/PRD-309/metrics está vacío). No es coincidencia ni contradicción: nadie mide el volumen de 270.035.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | No consta | Ningún documento |
| Contratos, cotizaciones, costo del equipo | No constan | Ningún documento |

**Este es el primer vacío.** Sin costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La licencia ambiental lo permite (declarado 2026-05-15, sin verificar, 161 días; sin alcance: ¿qué licencia, qué sitios?) | No se puede operar con drones y los 13 requerimientos pierden su base | Sin asignar; requiere un documento de la autoridad ambiental o un concepto jurídico |
| El volumen mensual de 270.035 es alcanzable | El caso se sostiene sobre una cifra sin origen | Quien la declaró (Laura Vélez) debe indicar de dónde sale |
| Los Supervisores son quienes piden el producto | La entrevista no dice que lo sean | Quien produzca nueva evidencia de demanda |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no se puede evaluar | Sin asignar (finanzas / quien contrate) |
| Origen del volumen de 270.035 | Única cifra del caso, sin respaldo | Laura Vélez |
| Cifra y base del «retorno esperado en 24 meses» | Es una frase, no una cifra | El negocio; sin asignar |
| Propuesta principal: sin contenido | No se sabe qué se ofrece | Laura Vélez |
| Criterio de éxito y fecha de corte | Sin él el producto no se puede cerrar | Sin asignar |
| Qué pasa si no se hace; alternativas consideradas | El caso no las menciona | El negocio |
| Autoridad que decide | No declarada en la configuración | Por nombrar |
| Proyecto que ejecute cada requerimiento | 13 decididos, ninguno con proyecto | Los dolientes de cada requerimiento |
| Demanda actual (la única entrevista es de 2025-08-21) | Evidencia vieja y de una sola fuente | Laura Vélez |

## Cómo se sabrá si funcionó
No está declarado: ni criterio de éxito ni métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno publicado a la vista: `estado-producto` solo contiene PRD-309 y no hay fichas publicadas. Las carpetas de documentos PRD-299 a PRD-308 existen, pero ninguna otra repite la cifra 270.035 (búsqueda textual). No es un cruce completo.

## Siguiente
Pasar los tres supuestos al seguimiento con assumption-tracking. `/product-charter` no corresponde todavía: el caso no tiene costo ni criterio de éxito.
