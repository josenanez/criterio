*Sesión sin interfaz: términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22), no hubo que volver a pedirlos. Sin tiempo indicado, tomé 60 minutos; la fecha, 2026-11-05, es la del próximo comité en la configuración y coincide con «próxima reunión en dos semanas» de las notas del 22-oct.*

## Reunión de seguimiento — Monitoreo de taludes (PRY-204) · 2026-11-05
13 puntos · 58 minutos · 11 personas requeridas

Calculada con lo que hay **al 2026-10-23**. `diff` no tiene corrida anterior, así que no puedo decir «qué cambió»: partí de los compromisos y las actas ya procesados. Los plazos del 23, 29 y 30 de octubre vencerán antes de la reunión; conviene volver a correr `/pm-agenda` el día anterior.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Cerrar la prueba 2» y quién lo quita** · 10 min · **Andrés Lozano**
> Prometido para el 2027-01-02, y antes para el 2026-12-19, el 2026-11-28, el 2026-11-12, el 2026-10-29 y el 2026-10-18. Primera promesa: 2026-10-08. Seis reprogramaciones.
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 2026-10-22-notas-reunion.txt («no alcanzó»). La nota dice «02/01/2027»: leída como 2 de enero de 2027, falta confirmar con Andrés si es el 1 de febrero.
> **Si no se resuelve hoy:** otra fecha corrida. Es el ensayo de disponibilidad que el informe del 22-oct dice que «se repite», con el proyecto declarado en verde. Qué tiene que quedar resuelto: la causa del bloqueo, quién la quita y una fecha con condición, o la decisión de subirlo.

> **[2] Nombrar qué bloquea «Revisar el anexo 3»** · 7 min · **Elena Duarte**
> Prometido para el 2026-12-08, y antes para el 2026-11-19, el 2026-10-31, el 2026-10-14 y el 2026-10-03. Primera promesa: 2026-09-13. Cinco reprogramaciones.
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 30-reuniones/2026-10-15-comite-semanal.md.
> **Si no se resuelve hoy:** sexta fecha corrida. Qué tiene que quedar resuelto: qué le falta a Elena para revisarlo y quién se lo da.

> **[3] Nombrar qué bloquea «Enviar el documento 1»** · 7 min · **Sandra Gil**
> Prometido para el 2026-12-02, y antes para el 2026-11-12, el 2026-10-24 y el 2026-10-11. Primera promesa: 2026-09-25 (el 09-10 se había dicho «por definir»). Cuatro reprogramaciones.
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 30-reuniones/2026-10-15-comite-semanal.md.
> **Si no se resuelve hoy:** quinta fecha corrida. Qué tiene que quedar resuelto: qué falta para enviarlo y quién lo destraba.

### Vencido sin evidencia
Más viejo primero, contado al 2026-10-23. Todos los plazos son de las minutas del 09-24 al 10-15.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Sandra Gil | Enviar el documento 9 | 2026-10-01 (22 días); sigue con la misma fecha en las listas del 10-01, 10-08 y 10-15 | El documento, o una fecha y la causa | 3 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 (21 días); dice haberlo entregado el 10-08 | El acta de recibo; si no existe, vuelve a abierto con fecha | 2 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-11 (12 días); dice haberlo entregado el 10-01 | El acta de recibo; si no existe, vuelve a abierto con fecha | 2 |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 (11 días); sin ninguna reprogramación ni mención | Entrega o fecha y causa | 3 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-15, antes 2026-10-01 (8 días); dice haberlo entregado el 10-08 | El acta de recibo | 2 |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-21 (2 días). El 10-22 anotó «revisión con el proveedor, para el 2026-11-01» sin nombrar el ambiente 20 | Decir si esa revisión es este compromiso. Si lo es, se une y el 11-01 (domingo) pasa a lunes 11-02 o se confirma | 3 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 (1 día) | Entrega o fecha | 2 |

Fuente de todos: 30-reuniones/ (minutas 2026-09-17 a 2026-10-15) y 2026-10-22-notas-reunion.txt.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[11] Aceptación de «Licenciamiento del software» sin documento.** La ficha lo tiene como aceptado (vencía el 2026-10-01) en CT-950 y en CT-307, sin acta de recibo en ninguno. Las facturas FV-2950 (2026-09-06, 861.859.911 COP) y FV-1307 (2026-09-04, 1.310.271.638 COP) son de antes de la fecha de entrega. La de CT-307 supera en 291.464.449 COP el valor de ese entregable (1.018.807.189). Falta decir cuál es el otro entregable que explica la diferencia, si lo hay. | Andrés Lozano pide el acta a los dos proveedores. Quién la firma por el proyecto no figura en los documentos | Se paga contra entregables sin documento, y la diferencia de CT-307 queda sin sustento. Cuentas por pagar ya las radicó | 8 |
| **[12] Dueño y valoración del riesgo del proveedor.** Las notas del 22-oct: «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». Hay además otro, «el proveedor no ha confirmado la fecha de la última entrega» (informe 22-oct). Ambos sin dueño, probabilidad ni impacto. | Andrés Lozano nombra dueño; el valor lo da quien lo asuma | Siguen sin dueño mientras el informe dice verde | 5 |

Fuente: 20-seguimiento/2026-09-04-factura-ct-307.md; 20-seguimiento/2026-09-06-factura-ct-950.md; ficha PRY-204 (proveedores, riesgos); 2026-10-22-notas-reunion.txt; 20-seguimiento/2026-10-22-informe-avance.pdf. No leí los contratos CT-307 y CT-950: los montos y fechas de los entregables son los de la ficha.

### Vence antes de la próxima
Un solo punto preventivo, **[13]**, 4 min en bloque: cada uno responde «¿llega?».

| Quién | Qué | Para cuándo |
|---|---|---|
| Carlos Peña | Revisar el anexo 19 | 2026-10-23 (hoy) |
| Paula Céspedes | Entregar el punto 24 | 2026-10-23 (hoy) |
| María Restrepo | Actualizar la matriz 22 | 2026-10-29 |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-30 |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-01 (domingo) |
| Carlos Peña | Confirmar la fecha 15 | 2026-11-03 (reprogramada 1 vez, original 2026-10-24) |

Sin fecha, y vencen en cuanto se ponga una: Laura Vélez · Mandar el ajuste del presupuesto («la otra semana», 10-22). Se pide el día en el mismo bloque.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| **CC-01** (ampliación de alcance, +84 días, +168.000.000 COP) | «Pendiente de presentación al comité» (2026-10-19). Excede la autoridad del gerente. El patrocinador, Gustavo Neira, no figura en las listas del 10-15 ni del 10-22. Las minutas llevan el título «Comité de Inversiones», que es el comité de la ficha; no puedo decir si esta reunión tiene facultad para decidirlo | `/criterio-project:pm-escalate`, para el comité del 2026-11-05 si es el mismo |
| **Beatriz Cuéllar · Cerrar la prueba 10** (venció el 2026-10-09, 14 días; dijo haberlo entregado el 10-08) | No figura en las listas del 10-15 ni del 10-22, así que nadie en la sala puede responder por ella | Andrés Lozano confirma si asiste. Si no, se le pide el acta por escrito antes |
| **Confirmar la lectura de «02/01/2027»** | No es un tema de reunión: se resuelve en una línea con Andrés | Antes del 11-05 |
| **Cadencia**: las notas dicen «dos semanas»; la configuración y las seis minutas, semanal | Quien convoca decide cuál es | Gerente |

### Anexo — sin cambios desde el 2026-10-22
No se repasa en la reunión. `diff` no tenía corrida anterior, así que «sin cambios» es contra las actas, no contra un registro previo.
- Javier Hoyos · Aprobar el diseño 5: 2026-11-06 (reprogramado 2 veces, original 2026-10-11). Cae un día después del comité.
- Camilo Beltrán · Confirmar la fecha 23: 2026-11-07.
- Javier Hoyos · Aprobar el diseño 21: sin fecha (10-15).
- Andrés Lozano · Actualizar la matriz 14: sin fecha (10-01).
- Andrés Lozano · Enviar el documento 17: sin fecha (10-08).
- Cerrados con acta: Validar el ambiente 4 (Jorge Medina), Validar el ambiente 12 y Aprobar el diseño 13 (María Restrepo).

Esta agenda no convoca a nadie ni decide la prioridad real entre puntos que compitan por el tiempo. Cuando termine la reunión: `/pm-minutes` sobre la transcripción o las notas.
