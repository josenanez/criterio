# Plan — PRY-204 · Monitoreo de taludes · borrador del 2026-10-23
**Desde:** acta de constitución del 2026-03-22 (`00-gobierno/2026-03-22-acta-constitucion.docx`) · **Criterio de éxito:** «Monitoreo de taludes en producción y medido.» (acta). No dice qué se mide, con qué umbral ni quién lo acepta.

*Nota de la corrida: sesión de prueba sin interfaz. Los términos (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22) ya estaban vigentes; no hubo que registrarlos de nuevo. Donde el comando pedía una respuesta, tomé la sugerida.*

**Este proyecto ya tiene plan.** Hay un cronograma v1 (2026-03-22) y uno v2 (2026-10-22), y dos hitos ya cerrados. Esto no es un plan desde cero: es una lectura del plan desde el acta, para ver qué lo sostiene y qué no.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** lista «Componente 1, Componente 2, Componente 3». | No se puede descomponer por entregable. Cualquier WBS que ponga nombre a los componentes lo inventa el agente o el gerente, no el acta. |
| **Fuera de alcance:** «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué. | No hay frontera. La solicitud CC-01 (ampliación de alcance, +84 días, +168.000.000 COP) no se puede evaluar contra un alcance que no está escrito. |
| **Criterio de éxito sin medida:** «en producción y medido». | No se sabe qué entra en el alcance ni cuándo se acepta el último entregable. Es el hueco más caro. |
| **Autoridad del gerente no declarada.** | No sé qué puede decidir quien planifica y qué hay que subir. En particular, quién aprueba CC-01 y cuánta holgura tiene el gerente. |
| **Dependencias: «Ninguna declarada».** | El plan existente encadena hitos entre sí, pero no hay ninguna dependencia externa escrita (permisos, proveedor, sala/ventana de operación). El hito «Licencia y permisos obtenidos» depende de un tercero por definición. |
| **Objetivo del negocio de una línea** («Entregar monitoreo de taludes para Geología»). | No hay beneficio esperado contra el cual priorizar si hay que recortar. |
| **Patrocinador:** sí está (Gustavo Neira). Comité: Comité de Inversiones. | Sin hallazgo. |

Marco estos huecos y **no los relleno**. Sigo adelante con ellos a la vista.

## WBS
Lo único que el acta sostiene como entregable son sus fechas de inicio y cierre y el criterio de éxito. Lo demás sale de contratos o del cronograma existente, y lo marco así.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | Sin definir (el acta no dice quién aprueba) | cronograma v1/v2, hito cerrado; existe `acta-recibo-ingeniería-básica-aprobada.pdf` (2026-10-12) | — (ya cerrado; no la estimo) |
| 2 | Ingeniería de detalle aprobada | Sin definir | cronograma v1/v2, hito cerrado; existe `acta-recibo-ingeniería-de-detalle-aprobada.pdf` (2026-10-19) | — (ya cerrado) |
| 3 | Licencia y permisos obtenidos | Sin definir; el emisor es un tercero | cronograma v1/v2 (50 %). **No está en el acta** | vacía |
| 4 | Montaje e instalación | Sin definir | cronograma v1/v2 (50 %). **No está en el acta** | vacía |
| 5 | Pruebas en operación (monitoreo en producción y medido) | Sin definir | acta (criterio de éxito) + cronograma | vacía |
| 6 | Licenciamiento del software — contrato CT-950 (Geotecnia Aplicada S.A.S.) | gerente del proyecto firma el acta de recibo (cláusula de pago) | contrato CT-950, comprometido 2026-10-01, estado «recibido» | del contrato: fecha comprometida 2026-10-01 |
| 7 | Bolsa de horas de ingeniería — CT-950 | gerente del proyecto (acta de recibo) | contrato CT-950, comprometido 2027-04-03, «pendiente» | del contrato: fecha comprometida 2027-04-03 |
| 8 | Licenciamiento del software — contrato CT-307 (Montajes Industriales Ltda.) | gerente del proyecto (acta de recibo) | contrato CT-307, comprometido 2026-10-01, «recibido» | del contrato: fecha comprometida 2026-10-01 |
| 9 | Bolsa de horas de ingeniería — CT-307 | gerente del proyecto (acta de recibo) | contrato CT-307, comprometido 2027-04-03, «pendiente» | del contrato: fecha comprometida 2027-04-03 |
| 10 | Componentes 1, 2 y 3 del alcance | Sin definir | acta (solo los rótulos) | vacía |
| 11 | Ampliación de alcance (CC-01) | Comité, **pendiente de presentación** | solicitud CC-01 (2026-10-19) | +84 días declarados en CC-01; no es duración del entregable |

Dos cosas que no cuadran y no resuelvo:
- **CT-950 y CT-307 listan exactamente los mismos dos entregables, con las mismas fechas, con distinto proveedor.** Es raro que una empresa de montajes entregue «licenciamiento del software» y que dos proveedores entreguen lo mismo. Puede ser plantilla copiada o doble contratación. Lo tiene que aclarar quien firmó los contratos.
- **Los entregables 1 a 5 no están en el acta; los contratos 6 a 9 no calzan con ellos.** No sé a qué hito del cronograma responde cada entregable contractual.

## Orden
Sin fechas. Lo que está escrito:
- 1 → 2 → 3 → 4 → 5, como cadena fin-a-inicio. Es el encadenamiento del cronograma v2 (`PredecessorLink`), no del acta.
- Los entregables contractuales de licenciamiento (6 y 8) tienen fecha anterior a «Ingeniería de detalle aprobada»: se recibieron el 2026-10-01 y esa ingeniería se cerró el 2026-10-18. **No sé si el licenciamiento debía precederla o era independiente.** El plan no lo dice.
- Las bolsas de horas (7 y 9) caen el 2027-04-03, antes de «Montaje e instalación»; ninguna dependencia las liga a nada.
- CC-01 no tiene lugar en el orden hasta que se sepa qué amplía.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos 3, 4 y 5 del cronograma son la descomposición vigente del alcance, aunque el acta no los nombra. | Hay alcance en «Componentes 1–3» que no tiene entregable, o entregables que no son alcance. |
| Los entregables de ingeniería los acepta quien firmó las actas de recibo en PDF. | No tengo el nombre en el texto; si la aceptación formal es de otra persona o del comité, los hitos 1 y 2 no están cerrados en rigor. |
| El gerente (Andrés Lozano) firma todas las actas de recibo contractuales, como dice la cláusula de pago. | Si el contrato exige otra firma, hay facturas pagadas sin aceptación válida. |
| CT-950 y CT-307 son dos contratos distintos con alcance distinto, y la identidad de entregables es un error de captura. | Si son realmente iguales, hay un pago duplicado de ~1.880 millones COP entre ambos (861.859.911 + 1.018.807.189 por cada entregable). Es una consecuencia, no una conclusión. |
| El cierre comprometido en el acta (2027-08-14) sigue siendo la referencia original. | El cronograma v2 ya muestra «Pruebas en operación» el 2027-11-06, **84 días** después. Coincide con los +84 días de CC-01, que sigue sin autorizar. Es decir, v2 podría estar incorporando un cambio que el comité no ha aprobado. |
| El proveedor tendrá el equipo completo para la siguiente fase. | Las notas del 2026-10-22 dicen que podría no llegar completo y que «nadie lo anotó como riesgo». Si falla, afecta montaje (4). |

Estos supuestos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Gustavo Neira) con el gerente |
| Qué proyecto cubre lo «fuera de alcance» | Patrocinador / PMO |
| Qué se mide y con qué umbral para «medido» | Geología (área dueña) con el patrocinador |
| Quién acepta cada entregable de los hitos 1–5 | Patrocinador |
| Autoridad del gerente al planificar | Patrocinador / Comité de Inversiones |
| Dependencias externas (permisos, proveedor, ventana de operación) | Gerente, con quien emite cada una |
| Si CC-01 está dentro o fuera de v2 | Comité |
| Duplicidad aparente de entregables CT-950 / CT-307 | Quien firmó los contratos; no el agente |

## Proyectos análogos
La configuración de PRY-204 no apunta a una carpeta de fichas de la PMO, así que **no hay análogos a la vista** y no los busco por mi cuenta. En `documentos/proyectos/` hay otros doce proyectos (PRY-199 a PRY-211), pero sin fichas no puedo decir cuál tiene el mismo producto ni qué les pasó. Es la respuesta correcta y evita una falsa precisión. Si se configura la carpeta de fichas, se repite este paso.

Referencia propia del proyecto, que sí está documentada: entre línea base y vigente, el cierre pasó de 2027-08-14 a 2027-11-06 (**+84 días**) en el cronograma v2; los demás hitos no se movieron.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto toma obtener la licencia y los permisos (hito 3), y qué entidad los emite?
2. ¿Cuánto toma el montaje e instalación (4), y con qué equipo del proveedor?
3. ¿Cuánto toman las pruebas en operación (5) y qué debe medirse para darlas por buenas?
4. ¿Qué incluyen los Componentes 1, 2 y 3, y cuánto toma cada uno?
5. ¿Cuántos días trae CC-01 sobre qué entregables, y por qué +84 y +168.000.000 COP?
6. ¿CT-950 y CT-307 entregan lo mismo? Si no, ¿qué entrega cada uno?
7. ¿Quién firma la aceptación de las ingenierías básica y de detalle?
8. ¿El equipo completo del proveedor está confirmado para la fase siguiente?

## Para comprometer una fecha falta
- **Disponibilidad real del equipo.** No está en ningún documento.
- **La fecha del proveedor para la fase siguiente**, con confirmación de que llega con el equipo completo (las notas del 2026-10-22 dicen que puede no ser así).
- **La ventana de la sala o el sitio de operación** para pruebas.
- **La decisión del comité sobre CC-01**: sin ella no se sabe si el cierre es 2027-08-14 o 2027-11-06.
- **La emisión de la licencia y los permisos**, de un tercero.

Ninguna fecha queda comprometida en este borrador. Esa es una decisión del gerente.
