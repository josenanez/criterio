## Compromisos — Monitoreo de taludes (PRY-204) · al 2026-10-23

Revisión de lo abierto, sobre la ficha vigente (no se pasó minuta nueva). Cifras de `portafolio.py compute`: 8 vencidos, 4 sin fecha, 3 reprogramados 3 veces o más. Términos vigentes (v1.2, aceptados el 2026-10-22).

### Se viene reprogramando

> **Andrés Lozano** · Cerrar la prueba 2
> Prometido para el 2027-01-02, y antes para el 2026-12-19, el 2026-11-28, el 2026-11-12, el 2026-10-29 y el 2026-10-18. Primera promesa: 2026-10-08. **Seis reprogramaciones.**
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 2026-10-22-notas-reunion.txt. La fecha de las notas dice «02/01/2027»; se leyó día/mes (2 de enero de 2027) y está pendiente de confirmar con el gerente. El doliente es el propio gerente del proyecto.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Elena Duarte** · Revisar el anexo 3
> Prometido para el 2026-12-08, y antes para el 2026-11-19, el 2026-10-31, el 2026-10-14 y el 2026-10-03. Primera promesa: 2026-09-13. **Cinco reprogramaciones.**
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 30-reuniones/2026-10-15-comite-semanal.md.
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Sandra Gil** · Enviar el documento 1
> Prometido para el 2026-12-02, y antes para el 2026-11-12, el 2026-10-24 y el 2026-10-11. Primera promesa: 2026-09-25 (el 2026-09-10 se había dicho «por definir»). **Cuatro reprogramaciones.**
> Fuente: 30-reuniones/2026-09-10-comite-semanal.md; última fecha en 30-reuniones/2026-10-15-comite-semanal.md.
> **Cuatro veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

En seguimiento, aún bajo el umbral de 3: Javier Hoyos · Aprobar el diseño 5, reprogramado 2 veces (original 2026-10-11, vigente 2026-11-06).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Sandra Gil | Enviar el documento 9 | 2026-10-01 | 22 días |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 | 21 días |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-09 | 14 días |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-11 | 12 días |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 | 11 días |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-15 (antes 2026-10-01) | 8 días |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-21 | 2 días |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 | 1 día |

Cuatro de estos ya fueron dados por entregados de palabra, sin ningún documento que lo respalde en el expediente, y desde el 2026-10-08 dejaron de aparecer en la lista de abiertos del comité:
- Rubén Cárdenas dice que entregó el punto 8 (2026-10-08); no hay acta.
- Beatriz Cuéllar dice que entregó la prueba 10 (2026-10-08); no hay acta.
- Jorge Medina dice que entregó la matriz 6 (2026-10-08); no hay acta.
- Javier Hoyos dice que entregó la fecha 7 (2026-10-01); no hay acta.

Siguen abiertos hasta que haya un documento. Sandra Gil (documento 9) sigue en las listas del 10-01, 10-08 y 10-15 con la misma fecha ya pasada.

Óscar Ramírez: las notas del 2026-10-22 dicen «revisión con el proveedor, queda para el 2026-11-01». No nombran el ambiente 20, así que se registró aparte y **no** se trata como reprogramación de ese compromiso.

### Vencen esta semana (hasta el 2026-10-30)
| Quién | Qué | Para cuándo |
|---|---|---|
| Carlos Peña | Revisar el anexo 19 | 2026-10-23 (hoy) |
| Paula Céspedes | Entregar el punto 24 | 2026-10-23 (hoy) |
| María Restrepo | Actualizar la matriz 22 | 2026-10-29 |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-30 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Andrés Lozano | Actualizar la matriz 14 | 2026-10-01 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-08 |
| Javier Hoyos | Aprobar el diseño 21 | 2026-10-15 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-22 («la otra semana») |

No pueden estar vencidos; se cuentan aparte. «La otra semana» no se convirtió en fecha.

### Cerrados desde la última revisión
Ninguno nuevo en esta revisión. Los ya cerrados antes, con su acta: Jorge Medina · Validar el ambiente 4 (20-seguimiento/2026-09-17-acta-recibo-4.md), María Restrepo · Validar el ambiente 12 (…/2026-10-01-acta-recibo-12.md) y María Restrepo · Aprobar el diseño 13 (…/2026-10-08-acta-recibo-13.md).

### Contexto
La ficha declara el proyecto en verde (informe del 2026-10-22). Contra ese verde, los compromisos suman 8 vencidos y 3 reprogramados 4 o más veces; el cómputo también marca desviación de tiempo (84 días, 16,8 %) y de costo (19,6 % sobre lo aprobado).

### Lo que sigue
- **Hay tres compromisos reprogramados más de tres veces.** Puedo formularlos como decisión para el comité (`/criterio-project:pm-escalate`): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente. Con el doliente de uno de ellos siendo el gerente, conviene que lo suba otra persona.
- No se cambió nada en la ficha, así que `/pm-publish` no es necesario por ahora.
- Pendiente de confirmar con el gerente: la lectura de «02/01/2027».
