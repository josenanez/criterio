Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

*Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.*
- Carpeta: la que vino en el argumento, `documentos/proyectos/PRY-204-monitoreo-de-taludes` (candidata 5 de 10; una carpeta distinta de la lista no tenía por qué elegirla).
- Quién y qué proyecto: Andrés Lozano, gerente de PRY-204 · Monitoreo de taludes (acta de constitución, 2026-03-22).
- Reunión de seguimiento: los jueves (las seis minutas y las notas caen en jueves); la próxima, en dos semanas según las notas del 22-oct: 2026-11-05.
- Estado: `estado/PRY-204-monitoreo-de-taludes`, junto a la carpeta de documentos y fuera de ella.
- Términos: texto que se mostró tal cual (abajo). Aceptados por José Francisco Ñáñez el 2026-10-22, según lo indicado para esta prueba.
- Marca `_CRITERIO_PROYECTO.txt` en la carpeta: sí (respuesta sugerida).

> Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se prueba antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

## Listo — PRY-204 · Monitoreo de taludes

**Lo que miré:** 21 documentos · 6 minutas del comité semanal (2026-09-10 a 2026-10-15, leídas todas, de la más vieja a la más nueva) + las notas del 2026-10-22 · la más reciente es del 2026-10-22. El cronograma v2 es XML; el plan de lectura lo marcó como no legible sin instalar nada, pero es texto y lo leí directamente.
**Términos:** aceptados para la versión 0.8.0 (términos 1.2) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 828fdb02ffd2726d…

### Lo que está abierto, y cuántas veces se ha movido

26 compromisos distintos en total: **3 cerrados con acta, 8 vencidos sin evidencia, 4 sin fecha, 11 abiertos con fecha vigente.** Las fechas son las que dice cada minuta; las de «Veces» cuentan solo las veces que una fecha ya dada se volvió a mover.

**Movidos varias veces (el hallazgo central)**

| Quién | Qué | Fecha original → vigente | Veces | |
|---|---|---|---|---|
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-08 → 2027-01-02 | 6 | 10-18, 10-29, 11-12, 11-28, 12-19, 2027-01-02 (minutas 09-17 a 10-15; notas 10-22) |
| Elena Duarte | Revisar el anexo 3 | 2026-09-13 → 2026-12-08 | 5 | 10-03, 10-14, 10-31, 11-19, 12-08 |
| Sandra Gil | Enviar el documento 1 | 2026-09-25 → 2026-12-02 | 4 | 10-11, 10-24, 11-12, 12-02. El 09-10 se prometió «por definir»; ponerle fecha no cuenta como mover |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-11 → 2026-11-06 | 2 | 10-25, 11-06 |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-24 → 2026-11-03 | 1 | |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-01 → 2026-10-15 | 1 | vencido, ver abajo |

La prueba 2 coincide con lo que dice el informe de avance del 22-oct: «el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite». Su última fecha viene de las notas como «02/01/2027»; la leí día/mes (2 de enero de 2027) y conviene confirmarla con Andrés.

**Vencidos sin evidencia** (a hoy, 2026-10-23)

| Quién | Qué | Para | Días | |
|---|---|---|---|---|
| Sandra Gil | Enviar el documento 9 | 2026-10-01 | 22 | misma fecha ya pasada en cuatro minutas seguidas (09-24 a 10-15) |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 | 21 | 10-08: «ya entregó», sin acta; desde ahí no aparece en la lista |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-09 | 14 | 10-08: «ya entregó», sin acta; desde ahí no aparece |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-11 | 12 | 10-01: «ya entregó», sin acta; desde 10-08 no aparece |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 | 11 | sigue en la lista del 10-15 sin cambio |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-15 | 8 | 10-08: «ya entregó», sin acta; desde ahí no aparece |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-21 | 2 | |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 | 1 | |

Cuatro de estos (puntos 6, 7, 8 y 10) salieron de la lista después de que alguien dijo en la reunión que ya los había entregado. Sin acta de recibo no cuentan como cumplidos: quedan vencidos sin evidencia, y el silencio no los cierra.

**Abiertos con fecha vigente:** Rubén Cárdenas, cerrar la prueba 18 (2026-10-30) · Carlos Peña, revisar el anexo 19 (2026-10-23) · Paula Céspedes, entregar el punto 24 (2026-10-23) · María Restrepo, actualizar la matriz 22 (2026-10-29) · Camilo Beltrán, confirmar la fecha 23 (2026-11-07) · Óscar Ramírez, revisión con el proveedor (2026-11-01, notas 10-22).

**Cerrados con acta:** validar el ambiente 4 (Jorge Medina, acta 2026-09-17) · validar el ambiente 12 (María Restrepo, acta 2026-10-01) · aprobar el diseño 13 (María Restrepo, acta 2026-10-08).

### Sin fecha
Nadie los fechó, así que no pueden figurar como vencidos y es fácil que desaparezcan:
- Andrés Lozano, actualizar la matriz 14: «por definir» desde el 10-01 (tres minutas).
- Andrés Lozano, enviar el documento 17: «por definir» desde el 10-08.
- Javier Hoyos, aprobar el diseño 21: «por definir» desde el 10-15.
- Laura Vélez, mandar el ajuste del presupuesto: «la otra semana» (notas 10-22); no la convertí en fecha.

### Otras señales que salieron de la cuenta
- **El informe declara verde (corte 2026-10-22)** con cinco señales encima: compromisos vencidos, compromisos reprogramados, sobrecosto, atraso y factura por encima de lo aceptado. Tú declaras el estado; esto es contra qué.
- **Atraso:** el cronograma v2 mueve «Pruebas en operación» de 2027-08-14 a 2027-11-06: 84 días, 16,8 % sobre la línea base. La solicitud de cambio CC-01 pide +84 días y 168.000.000 COP y figura «pendiente de presentación al comité»: el cronograma ya muestra una fecha que nadie ha autorizado.
- **Costo:** la proyección al cierre del informe, 11.362.933.575 COP, queda 19,6 % sobre los 9.500.000.000 aprobados. Comprometido 52,3 %, ejecutado 46,7 %.
- **Proveedores:** los dos contratos dicen «recibido» en el licenciamiento y ninguno trae acta de recibo, aunque la condición de pago es factura contra acta. La factura FV-1307 de Montajes Industriales (CT-307) es de 1.310.271.638 COP contra 1.018.807.189 del entregable: 291.464.449 COP por encima de lo aceptado. Ambas facturas son de principios de septiembre, antes de la fecha del entregable (2026-10-01).
- **Riesgo que nadie anotó:** en las notas del 22-oct se comentó que el proveedor podría no llegar con el equipo completo en la siguiente fase. Lo dejé en la ficha como riesgo con la cita; el informe tiene un riesgo cercano («el proveedor no ha confirmado la fecha de la última entrega»).
- Hitos: dos cerrados (ingeniería básica y de detalle), con acta de recibo cada uno; avance declarado 56 %, dentro de lo que sostiene el plan (40–60 %).

### Qué le falta a tu carpeta
- Actas de recibo de los dos licenciamientos de proveedor (CT-950 y CT-307): sin ellas el «recibido» del contrato no tiene prueba y las facturas no se sostienen.
- Actas de recibo de lo que se dijo entregado en las reuniones (puntos 6, 7, 8 y 10).
- La decisión del comité sobre CC-01 y, si se aprueba, una línea base nueva que la recoja.
- Minutas de fechas anteriores al 2026-09-10 (la primera que hay ya trae compromisos abiertos) y una minuta del 22-oct en el formato de las demás: hoy son notas sueltas en la raíz del proyecto.
- El acta de constitución no declara autoridad del gerente ni fase, y sus componentes y alcance son genéricos («Componente 1, 2, 3»).
- Estructura sugerida (`document-intake`): la carpeta ya sigue `00-gobierno/`, `10-plan/`, `20-seguimiento/`, `30-reuniones/`; solo faltaría mover las notas a `30-reuniones/`. No moví nada.

**Cuándo vuelvo:** en el comité de los jueves; la próxima reunión es el 2026-11-05 (dos semanas, según las notas), así que me toca el miércoles 4 de noviembre.
