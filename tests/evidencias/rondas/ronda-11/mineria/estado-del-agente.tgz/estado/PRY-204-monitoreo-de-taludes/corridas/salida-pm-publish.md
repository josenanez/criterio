**Antes de publicar:** términos v1.2 vigentes (aceptados el 2026-10-22 por José Francisco Ñáñez); no hubo que registrar nada. Ficha recalculada con corte al 2026-10-23. `plan.end_date` = 2027-11-06, tomada del cronograma v2 (2026-10-22), el más nuevo; la fecha del acta (2027-08-14) va en `plan.baseline`.

**Qué se publica:** 18 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · el estado que declara el proyecto es **verde** al 2026-10-22 (informe de avance), y es declaración del gerente, no de la PMO.

**Aviso para la PMO:** la ficha lleva 21 alertas calculadas, entre ellas desviación de tiempo de +84 días (16,8 %) contra la línea base original, proyección de costo 19,6 % sobre lo aprobado, 8 compromisos vencidos, 3 reprogramados varias veces y una factura de Montajes Industriales Ltda. por encima de lo aceptado (COP 291.464.449). El «verde» declarado no las recoge.

Publiqué la ficha en `documentos/proyectos/PRY-204-monitoreo-de-taludes/00-gobierno/ficha-pm.json`, con corte al 2026-10-23.

**Lleva:** 18 campos con dato · 2 sin decir en ninguna parte · declara **verde** al 2026-10-22

**Lo más viejo que va ahí:** `identity.*` y `plan.start_date`, del 2026-03-22 (acta de constitución); el contrato CT-950, del 2026-03-19. Ninguno pasa de un año.
