# Monitoreo de taludes (PRY-204) — semana del 2026-10-16 al 2026-10-23

*Declaración (paso 2): no hay quien responda en esta sesión. El gerente (Andrés Lozano) ya declaró por escrito en su informe de avance del 2026-10-22, y esa es la declaración que se usa. Samuel no propone ni cambia el estado.*

**Declara el gerente:** verde · 56 % · al 2026-10-22 (hace 1 día; `20-seguimiento/2026-10-22-informe-avance.pdf`)
**Sustento documental:** contradicho. El verde tiene 5 señales de evidencia que no explica; los documentos sin marcar de origen son 128 y las evidencias marcadas son 0, así que el sustento es débil.
**Lo que el semáforo no explica:** atrasos de compromisos (8 vencidos), compromisos reprogramados (3), desviación de tiempo (+84 días, 16,8 %), desviación de costo (+19,6 %), proveedor facturado por encima de lo aceptado (Montajes Industriales).

## Qué cambió esta semana
Primera corrida registrada sobre esta ficha: el diff contra la anterior da 0 cambios porque no existe una corrida previa con la que comparar (el snapshot de hoy es el primero). Lo que sí entró esta semana en los documentos:
| Qué | Estaba | Está | |
|---|---|---|---|
| Ingeniería de detalle aprobada | pendiente (base 2026-10-18) | cumplida, con acta de recibo del 2026-10-19 | cerrado |
| Solicitud de cambio CC-01 (2026-10-19) | — | pendiente de decisión: ampliación de alcance, +84 días, +168.000.000 COP | nuevo |
| Cronograma v2 (2026-10-22) | fin 2027-08-14 | fin 2027-11-06 | movido |
| Notas de reunión 2026-10-22 | — | riesgo de proveedor sin registrar y compromiso de Laura Vélez sin fecha | nuevo |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Entregar el punto 8 (Rubén Cárdenas), vencido sin evidencia | 2026-10-02 | 21 |
| Enviar el documento 9 (Sandra Gil), vencido sin evidencia | 2026-10-01 | 22 |
| Cerrar la prueba 10 (Beatriz Cuéllar) | 2026-10-09 | 14 |
| Confirmar la fecha 7 (Javier Hoyos) | 2026-10-11 | 12 |
| Entregar el punto 16 (Felipe Arango) | 2026-10-12 | 11 |
| Actualizar la matriz 6 (Jorge Medina) | 2026-10-15 | 8 |
| Validar el ambiente 20 (Óscar Ramírez) | 2026-10-21 | 2 |
| Revisar el anexo 11 (Jorge Medina) | 2026-10-22 | 1 |
| Licenciamiento del software «aceptado» sin documento de recibo (Geotecnia Aplicada y Montajes Industriales) | sin fecha en la ficha | sin dato |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-08-14 | 2027-11-06 | +84 días (16,8 %) contra la original y contra la vigente |
| Presupuesto | 9.500.000.000 COP | 9.500.000.000 COP | proyección 11.362.933.575 COP: +19,6 % |

Replanificaciones: 0 registradas. Aun así la fecha de cierre del cronograma v2 ya corre 84 días, y CC-01, que pide esos mismos 84 días, sigue pendiente de decisión y sin aprobador. La línea base vigente no se ha movido, así que la desviación contra las dos sale igual (84 días). Esto es un vacío de gobierno, no una estabilidad.

### Hitos de las próximas cuatro semanas
Ninguno cae entre 2026-10-23 y 2026-11-20. El más cercano es el que sigue.
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Licencia y permisos obtenidos | 2027-01-26 | 2027-01-26 | ninguna aún |

Hitos cumplidos: 2 de 5, con acta cada uno. El avance declarado (56 %) queda dentro del rango que el plan sostiene (40–60 %).

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 4.969.453.075 (52,3 %) | 4.437.292.727 (46,7 %) | 11.362.933.575 | 4.530.546.925 |

Disponible real = aprobado − comprometido. La proyección supera lo aprobado en 1.862.933.575.

## Abierto
**Reprogramados:**
- Andrés Lozano, «Cerrar la prueba 2»: 6 veces. Original 2026-10-08, hoy 2027-01-02.
- Elena Duarte, «Revisar el anexo 3»: 5 veces. Original 2026-09-13, hoy 2026-12-08.
- Sandra Gil, «Enviar el documento 1»: 4 veces. Original 2026-09-25, hoy 2026-12-02.

**Vencidos sin evidencia:** 8, listados arriba.
**Sin fecha:** Andrés Lozano (matriz 14; documento 17), Javier Hoyos (diseño 21), Laura Vélez (ajuste del presupuesto).
**RAID sin movimiento:** la ficha no trae días de movimiento. Lo abierto es:
- proveedor sin confirmar la fecha de la última entrega;
- riesgo de equipo incompleto del proveedor, que se dijo en reunión y nadie registró;
- ensayo de disponibilidad que no alcanzó lo pactado y se repite;
- lluvias que detuvieron el montaje 10 días;
- ventana de parada de planta sin confirmar.

Ninguno tiene responsable.
**Proveedor:**
- Montajes Industriales (CT-307): facturado 1.310.271.638 contra aceptado 1.018.807.189. Diferencia: 291.464.449 COP facturados sin aceptación.
- Geotecnia Aplicada (CT-950): facturado igual a lo aceptado (861.859.911), pero el licenciamiento figura aceptado sin documento.
- Entregables vencidos: ninguno.

## Lo que necesito de alguien
- Gustavo Neira (sponsor) y el Comité de Inversiones: decidir CC-01 (+84 días, +168.000.000 COP). Excede la autoridad del gerente; es material de comité.
- Quien apruebe pagos de CT-307: aclarar los 291.464.449 COP facturados por encima de lo aceptado.
- Responsables de los 8 compromisos vencidos: evidencia de cumplimiento o nueva fecha.
- Andrés Lozano: fecha para los 4 compromisos sin fecha, y asignar responsable a los 5 puntos RAID abiertos.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto (quién aprueba, `identity.authority`) y fase (`identity.phase`).
**Silencio:** último documento hace 1 día (2026-10-22) · última reunión hace 1 día (notas del 2026-10-22; último comité formal el 2026-10-15, hace 8 días).

---
Ficha: PRY-204 (`estado/PRY-204-monitoreo-de-taludes/records/PRY-204.json`), actualizada el 2026-10-23, corte a 2026-10-23 · 2 campos sin dato · Términos v1.2, aceptados el 2026-10-22: https://www.josenanez.com/es/agents/criterio-pmo/legal
