# Corrida del 2026-10-23 · pm-escalate

1 proyectos · 70 s · 21 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_accepted_without_evidence` | 2 |
| `variance_time` | 1 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `declared_vs_evidence` | 1 |

Paquete de decisión: autoridad no declarada en el acta (punto 0) y CC-01. El v2 ya trae los 84 días de CC-01, así que el 2028-01-29 de impact está duplicado. Proyección 1.862.933.575 COP sobre lo aprobado con estado verde. No supe qué amplía CC-01, qué pasa si no se decide ni el costo de rechazarlo.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

*Sesión sin interfaz: términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22), no hubo que pedirlos de nuevo. Sin tema en el argumento, tomé lo ya marcado como escalable: CC-01 y la autoridad que el acta no declara.*

## Para decisión — Monitoreo de taludes (PRY-204) · 2026-10-23

### Punto 0 (el primero): ¿quién puede decidir qué en este proyecto?

El acta de constitución (2026-03-22) no tiene sección de autoridad del gerente: nombra patrocinador (Gustavo Neira), gerente (Andrés Lozano) y comité (Comité de Inversiones), y solo dice que el presupuesto lo aprobó ese comité. La ficha lo registra como `authority: no encontrada`. Sin eso no puedo decir qué excede la autoridad de Andrés; lo que sigue se apoya en lo único que el acta sí dice (el presupuesto lo aprobó el Comité de Inversiones).

**Pregunta cerrada:** ¿El patrocinador firma un anexo al acta con los límites del gerente (tiempo, costo, alcance), sí o no?
**Quién decide:** Gustavo Neira, patrocinador (según el acta) · **Si no se decide:** CC-01 sigue sin destinatario verificable; la decisión del 2026-11-05 podría tomarla quien no tiene la facultad y habría que repetirla.

### CC-01: ¿Se aprueba la ampliación de alcance, con línea base v2 al 2027-11-06 y 168.000.000 COP adicionales, o no?

**Quién decide:** el acta solo documenta que el Comité de Inversiones aprobó el presupuesto; no dice quién aprueba cambios. Lo razonable es llevarlo a ese comité, pero eso depende del Punto 0. · **Si no se decide hoy:** lleva pendiente desde el 2026-10-19 («Pendiente de presentación al comité»). El próximo comité es el 2026-11-05, en 13 días. **No encuentro en los documentos una fecha en la que se pierda algo si se aplaza** (oferta, permiso, contrato). Andrés debe aportarla; sin ella este punto se aplaza.

**Dato que cambia la pregunta:** el cronograma v2 (2026-10-22) ya pone «Pruebas en operación» el 2027-11-06 contra una línea base de 2027-08-14: exactamente 84 días, lo mismo que pide CC-01. La ficha solo tiene la línea base v1 (2027-08-14); no hay v2 aprobada. O el plan ya corre con un cambio no aprobado, o es coincidencia. No lo sé; lo confirma Andrés. Por eso `impact` da un nuevo cierre de 2028-01-29: suma 84 días a una fecha que ya los incluye. **Si la coincidencia es cierta, ese 2028-01-29 está duplicado y el cierre correcto es el 2027-11-06.**

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliación de alcance (la solicitud no dice cuál) | Cierre 2027-08-14 → 2027-11-06 (+84 d) si el v2 ya lo incluye; 2028-01-29 si no | +168.000.000 COP: presupuesto 9.500.000.000 → 9.668.000.000 |
| B. No aprobarlo | Se queda el alcance del acta | Hay que revertir el v2 a 2027-08-14; la ficha no dice si el avance lo permite | Sin costo declarado en ningún documento; no lo estimo |

**Recomiendo:** A, pero con la línea base v2 registrada aparte (la v1 no se toca) y dos aclaraciones de Andrés antes del 11-05 — qué amplía el alcance y si los 84 días ya están en el v2. La razón: el plan ya trabaja con esas fechas y revertirlo no tiene costo declarado. Es provisional: no tengo el sustento de negocio de la ampliación.

### Lo que el comité debe ver junto a CC-01

- **Presupuesto:** el informe del 2026-10-22 proyecta 11.362.933.575 COP contra 9.500.000.000 aprobados: 1.862.933.575 por encima (19,6 %), con el estado declarado en **verde**. CC-01 explica 168.000.000; quedan **1.694.933.575 sin ninguna solicitud de cambio**. Es dato declarado, no verificado.
- **Dependencia sin confirmar:** «Ventana de parada de planta» definida por operaciones (informe 2026-10-22), `confirmada: no`, sin fecha de necesidad. El acta dice «Ninguna declarada».
- **Patrocinador:** Gustavo Neira no figura entre los asistentes del 10-15 ni del 10-22.

### A quién alcanza
`impact` no encuentra otro proyecto alcanzado: 0 directos, 0 indirectos, 0 sin poder sostener su fecha, 0 dependencias sin confirmar. Eso es lo que hay en las fichas, no la certeza de que no haya nadie: el acta no declara dependencias y la de la parada de planta no apunta a ningún proyecto. Cuántos días se mueve cada alcanzado no se calcula (falta holgura por actividad).

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Licencia y permisos obtenidos | 2027-01-26 | 95 |
| Montaje e instalación | 2027-05-06 | 195 |
| Pruebas en operación | 2027-11-06 | 379 |

Solo «Pruebas en operación» está desplazada hoy en el v2 (de 2027-08-14). Licencia y Montaje conservan su fecha de la línea base.

### De dónde sale esto
- Autoridad no declarada, comité y presupuesto: 00-gobierno/2026-03-22-acta-constitucion.docx (leído); ficha PRY-204, `authority`.
- CC-01 (alcance, +84 días, 168.000.000 COP, pendiente): 20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md.
- Fechas v2 y línea base de «Pruebas en operación»: 10-plan/2026-10-22-cronograma-v2.xml. Resta de fechas verificada: 84 días.
- Proyección y estado verde: 20-seguimiento/2026-10-22-informe-avance.pdf, según la ficha (no lo releí).
- Próximo comité 2026-11-05: .criterio/proyecto/PRY-204/config.json.
- Efecto por hitos: `portafolio.py impact --days 84`.
- Patrocinador ausente: salida de pm-agenda del 2026-10-23, que cita las listas del 10-15 y 10-22.

### Lo que no sé
Qué amplía CC-01; si el v2 ya lo incluye; qué pasa y cuándo si no se decide; el costo de la opción B; quién aprueba cambios. La llamada a Andrés y al patrocinador es suya; este paquete no escala ni decide.
