## PRY-204 Monitoreo de taludes · 2026-10-23

**Revisé:** 22 documentos · 22 nuevos para el índice (es la primera vez que se indexa la carpeta) · 0 minutas sin extraer: las 6 actas de comité y las notas del 22 de octubre ya estaban en la ficha, con 26 compromisos.

Los términos están vigentes (versión 1.2, aceptados el 2026-10-22 por José Francisco Ñáñez); no hubo que registrarlos de nuevo.

### Lo que se venció solo
Ocho compromisos vencidos sin evidencia de cumplimiento en la ficha:
- Rubén Cárdenas, «Entregar el punto 8»: venció el 2026-10-02, 21 días (30-reuniones/2026-09-17-comite-semanal.md).
- Sandra Gil, «Enviar el documento 9»: venció el 2026-10-01, 22 días (30-reuniones/2026-09-24-comite-semanal.md).
- Beatriz Cuéllar, «Cerrar la prueba 10»: venció el 2026-10-09, 14 días (30-reuniones/2026-09-24-comite-semanal.md).
- Javier Hoyos, «Confirmar la fecha 7»: venció el 2026-10-11, 12 días (30-reuniones/2026-09-17-comite-semanal.md).
- Felipe Arango, «Entregar el punto 16»: venció el 2026-10-12, 11 días (30-reuniones/2026-10-01-comite-semanal.md).
- Jorge Medina, «Actualizar la matriz 6»: venció el 2026-10-15, 8 días (30-reuniones/2026-09-17-comite-semanal.md).
- Óscar Ramírez, «Validar el ambiente 20»: venció el 2026-10-21, 2 días (30-reuniones/2026-10-08-comite-semanal.md).
- Jorge Medina, «Revisar el anexo 11»: venció el 2026-10-22, 1 día (30-reuniones/2026-09-24-comite-semanal.md).

Tres compromisos llevan 3 o más reprogramaciones:
- Andrés Lozano, «Cerrar la prueba 2»: 6 veces, de 2026-10-08 a 2027-01-02.
- Elena Duarte, «Revisar el anexo 3»: 5 veces, de 2026-09-13 a 2026-12-08.
- Sandra Gil, «Enviar el documento 1»: 4 veces, de 2026-09-25 a 2026-12-02.

Cuatro compromisos no tienen fecha: «Actualizar la matriz 14» y «Enviar el documento 17» (Andrés Lozano), «Aprobar el diseño 21» (Javier Hoyos) y «Mandar el ajuste del presupuesto» (Laura Vélez).

Otras señales abiertas en el recálculo:
- Atraso de 84 días (16,8 %) contra la línea base original.
- Proyección de costo 19,6 % sobre lo aprobado: 11.362.933.575 contra 9.500.000.000 COP.
- Montajes Industriales Ltda. (CT-307) facturó 291.464.449 COP por encima de lo aceptado.
- «Licenciamiento del software» figura aceptado sin evidencia de recibo, con los dos proveedores.
- El informe de avance del 2026-10-22 declara **verde**, y las señales anteriores no están contabilizadas en esa declaración.

Todas estas señales quedan abiertas en la ficha. No se las escribí a nadie.

### La reunión
El próximo comité es el 2026-11-05, dentro de 13 días. Todavía no toca la agenda (falta un día o menos) y el informe sale el 2026-11-04. No hay una reunión pasada sin acta: la última es del 2026-10-15 y su acta está en la carpeta.

### Tu ficha publicada
Hoy corrió `/pm-publish` y la ficha no ha cambiado desde entonces, así que no está vieja.

**Vuelvo el 2026-10-24.**
