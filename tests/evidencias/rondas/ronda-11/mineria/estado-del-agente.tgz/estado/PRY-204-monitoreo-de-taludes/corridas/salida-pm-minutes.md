*Sesión sin interfaz: términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-22, versión 0.8.0; comprobante en `.criterio/terminos/`), no hubo que volver a pedirlos.*

# Acta — PRY-204 · Monitoreo de taludes · 2026-10-22
**Asistieron (13):** Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-22-notas-reunion.txt` · **Ausentes con tema en agenda:** las notas no traen agenda, no puedo decirlo. Beatriz Cuéllar, que estaba en la reunión del 15-oct, no figura en la lista (tiene vencido «Cerrar la prueba 10»; no se habló de él).

Las notas son cinco líneas. Todo lo de abajo sale de ellas; lo que no está, no se rellenó.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Andrés Lozano | Cerrar la prueba 2 («no alcanzó») | 2027-01-02 (la nota dice «02/01/2027»; ver «Sin resolver») | **Reprogramado por 6.ª vez.** Original 2026-10-08 → 10-18 → 10-29 → 11-12 → 11-28 → 12-19 → 2027-01-02. Línea de las notas: «lo de “cerrar la prueba 2” no alcanzó, se compromete para el 02/01/2027» |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-01 | Nuevo. Línea: «revisión con el proveedor, queda para el 2026-11-01» |

Se cruzó contra los compromisos de las seis minutas anteriores: el de Andrés es el mismo doliente prometiendo lo mismo con fecha nueva, así que es reprogramación y no uno nuevo. El de Óscar **no se ató** a «Validar el ambiente 20» (suyo, vencido el 10-21): la nota no nombra el ambiente y no se le inventa la relación. Si es lo mismo, se une en la próxima reunión; si no, el ambiente 20 sigue vencido sin evidencia.

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; no la convertí en fecha) |

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Las notas no dicen qué quedó pendiente de decisión. Lo único que se acerca es la ausencia de dueño para el riesgo del proveedor (sección siguiente).

## Intenciones sin doliente
Ninguna. «Próxima reunión en dos semanas» es una cadencia, no una intención de nadie.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | No atribuido: la nota dice «se comentó» | Riesgo (probabilidad e impacto sin valorar; sin dueño) | **No.** Lo más cercano es el riesgo del informe del 22-oct «el proveedor no ha confirmado la fecha de la última entrega»: parecido, pero no es el mismo (aquel es la fecha; este, el equipo completo). Queda en la ficha con la cita y `owner: no_identificado` |

## Cerrado en esta reunión
Nada. Se omite el detalle.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» | Comité semanal | notas 2026-10-22 vs configuración del proyecto y las seis minutas, todas con una semana entre sí |

No toca sponsor, fecha de cierre ni comité. Lo que sí queda a la vista: «la prueba 2 no alcanzó» y su sexta fecha corrida a 2027 conviven con el estado **verde** del informe del 22-oct, en el que Samuel ya había encontrado cinco señales encima (la prueba 2 es el ensayo de disponibilidad que el informe dice que «se repite»). El estado lo declaras tú.

## Sin resolver de la transcripción
- **«02/01/2027»** (Andrés Lozano, prueba 2): puede ser 2 de enero de 2027 (lectura día/mes, la usada) o 1 de febrero de 2027. Las demás fechas de las notas son ISO. Hay que confirmarlo con Andrés. El 2 de enero es sábado y el 1 de febrero, lunes.
- **«la otra semana»** (Laura Vélez): sin día.
- **2026-11-01** (Óscar Ramírez): es domingo; no queda claro si es esa fecha o la del lunes 11-02.
- **«se comentó…»**: no se sabe quién lo dijo.

## Recalculo
`compute` sin `record_issues`. Compromisos al 2026-10-23: 26 distintos; 3 cerrados con acta; 8 vencidos sin evidencia; 4 sin fecha (uno nuevo hoy: Laura Vélez); 3 reprogramados 3 o más veces (Lozano ×6, Duarte ×5, Gil ×4).

Sugiero `/pm-commitments` para el seguimiento completo, y `/pm-publish` cuando decidas qué se confirma de este acta. No escribí el acta en tu carpeta de reuniones: guárdala tú.
