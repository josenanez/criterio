<!-- origen: PRY-209-electrificación-de-equipos/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Electrificación de equipos
Código: PRY-209
Fecha de corte: 2026-10-22
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 70%

Lo que pasó en el periodo
- Se acordó con operaciones el plan de arranque de los equipos

Presupuesto
COP
Aprobado 800.000.000
Comprometido 593.282.872
Ejecutado 400.304.076
Proyección al cierre 926.517.799

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
