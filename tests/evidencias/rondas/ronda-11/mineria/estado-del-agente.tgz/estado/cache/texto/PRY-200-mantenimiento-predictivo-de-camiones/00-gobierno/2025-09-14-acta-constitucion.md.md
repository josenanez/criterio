<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-09-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Área dueña:** Mina
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Operaciones
**Producto asociado:** monitoreo de flota
**Fecha de aprobación:** 2025-09-14

## Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Operaciones el 2025-09-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-24 |
| Cierre | 2026-04-06 |

## Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

## Dependencias declaradas

- Ninguna declarada
