import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-208-trazabilidad-del-mineral/"
ACTA = P + "00-gobierno/2026-06-12-acta-constitucion.docx"
CT = P + "00-gobierno/2026-06-12-contrato-ct-644.docx"
V1 = P + "10-plan/2026-06-12-cronograma-v1.xml"
V2 = P + "10-plan/2026-10-17-cronograma-v2.xml"
FAC = P + "20-seguimiento/2026-09-24-factura-ct-644.pdf"
CC1 = P + "20-seguimiento/2026-10-12-solicitud-cambio-cc-01.md"
INF = P + "20-seguimiento/2026-10-17-informe-avance.md"
COM = P + "30-reuniones/2026-10-11-comite-semanal.md"

ident = {
    "code": F("PRY-208", ACTA), "name": F("Trazabilidad del mineral", ACTA), "aliases": [],
    "business_area": F("Seguridad y Salud", ACTA), "product": F("trazabilidad", ACTA), "authority": F(None),
    "sponsor": F("Natalia Ospina", ACTA), "manager": F("Paula Céspedes", INF),
    "committee": F("Comité Ambiental", COM), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(83, INF), "as_of": D("2026-10-17", INF), "source": INF}
ms = lambda n, b, c, st: {"name": n, "baseline_date": b, "current_date": c, "state": st, "evidence": "", "source": V2}
plan = {
    "start_date": F("2026-06-22", ACTA), "end_date": F("2028-01-14", V2),
    "baseline": [
        {"version": 1, "approved_on": "2026-06-12", "start_date": "2026-06-22", "end_date": "2027-12-11",
         "baseline_end_date": "2027-12-11", "source": V1, "reason": "Línea base original del acta de constitución"},
        {"version": 2, "approved_on": "2026-10-17", "start_date": None, "end_date": "2028-01-14",
         "baseline_end_date": "2027-12-11", "source": V2,
         "reason": "Cronograma v2 mueve Pruebas en operación +34 días; la CC-01 (+34 días) figura «pendiente de presentación al comité», sin decisión en ningún documento"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-10-07", "2026-10-07", "met"),
        ms("Ingeniería de detalle aprobada", "2027-01-22", "2027-01-22", "pending"),
        ms("Licencia y permisos obtenidos", "2027-05-10", "2027-05-10", "pending"),
        ms("Montaje e instalación", "2027-08-25", "2027-08-25", "pending"),
        ms("Pruebas en operación", "2027-12-11", "2028-01-14", "pending"),
    ],
    "scope_summary": F("Entregar trazabilidad del mineral para Seguridad y Salud (tres componentes sin detallar; CC-01 pendiente lo amplía)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(6800000000, INF), "committed": F(4004860656, INF),
         "executed": F(1889383315, INF), "projection": F(6959303783, INF)}
dl = lambda n, d: {"name": n, "due_date": d, "amount": 555209101, "state": "pending", "evidence": ""}
vendors = [{"name": "Automatización de Procesos Ltda.", "contract_ref": "CT-644",
            "deliverables": [dl("Licenciamiento del software", "2026-11-16"), dl("Bolsa de horas de ingeniería", "2027-04-13"),
                             dl("Calibración de sensores", "2027-09-08")],
            "invoiced": F(555209101, FAC), "source": CT}]
raid = {"risks": [{"what": "Ventana de parada de planta definida por operaciones", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [], "issues": [], "dependencies": []}
changes = [{"ref": "CC-01", "requested_on": "2026-10-12", "scope_impact": "Ampliación de alcance",
            "time_impact": "+34 días sobre la línea base vigente", "cost_impact": "68.000.000 COP adicionales",
            "decision": "pending", "decided_by": None, "source": CC1}]
commitments = [{"who": "Elena Duarte", "what": "Entregar el punto 25", "due_date": "2026-11-07", "original_due_date": "2026-11-07",
                "stated_on": "2026-10-11", "source": COM, "state": "open", "reschedules": []}]
build("PRY-208", ident, declared, plan, money, vendors, raid, changes, commitments)
