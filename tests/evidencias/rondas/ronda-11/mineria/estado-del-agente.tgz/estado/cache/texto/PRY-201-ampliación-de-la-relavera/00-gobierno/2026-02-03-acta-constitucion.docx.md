<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2026-02-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Medio Ambiente

Patrocinador: Jorge Medina

Gerente de proyecto: Diana Molina

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2026-02-03

Objetivo del negocio

Entregar ampliación de la relavera para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Operaciones el 2026-02-03.

Fechas comprometidas

Fecha

Inicio

2026-02-13

Cierre

2027-04-21

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
