<!-- origen: PRY-211-control-de-polvo-en-vías/00-gobierno/2025-06-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Control de polvo en vías

Código: PRY-211

Área dueña: Mantenimiento

Patrocinador: Andrés Lozano

Gerente de proyecto: Liliana Torres

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2025-06-16

Objetivo del negocio

Entregar control de polvo en vías para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité Ambiental el 2025-06-16.

Fechas comprometidas

Fecha

Inicio

2025-06-26

Cierre

2026-04-22

Criterio de éxito

Control de polvo en vías en producción y medido.

Dependencias declaradas

• Ninguna declarada
