<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/2026-03-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Monitoreo de taludes

Código: PRY-204

Área dueña: Geología

Patrocinador: Gustavo Neira

Gerente de proyecto: Andrés Lozano

Comité: Comité de Inversiones

Producto asociado: alerta de taludes

Fecha de aprobación: 2026-03-22

Objetivo del negocio

Entregar monitoreo de taludes para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Inversiones el 2026-03-22.

Fechas comprometidas

Fecha

Inicio

2026-04-01

Cierre

2027-08-14

Criterio de éxito

Monitoreo de taludes en producción y medido.

Dependencias declaradas

• Ninguna declarada
