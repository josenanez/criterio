<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2026-10-22-cronograma-v3.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-04-28 | 2026-04-28 | 2026-04-28 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-06-22 | 2026-06-22 | 2026-06-22 | 100% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2026-08-16 | 2026-08-16 | 2026-08-16 | 100% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2026-10-09 | 2026-10-09 | 2026-10-09 | 50% | hito | 3FS | — |
| 5 | 5 | Pruebas en operación | 2027-07-02 | 2027-07-02 | 2026-12-03 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-04-28 | 2026-04-28 | cerrado |
| Ingeniería de detalle aprobada | 2026-06-22 | 2026-06-22 | cerrado |
| Licencia y permisos obtenidos | 2026-08-16 | 2026-08-16 | cerrado |
| Montaje e instalación | 2026-10-09 | 2026-10-09 | en curso |
| Pruebas en operación | 2026-12-03 | 2027-07-02 | en curso |
