<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Gemelo digital de la planta
Código: PRY-207
Fecha de corte: 2026-10-18
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 40%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave
- Las lluvias detuvieron el montaje durante diez días
- Se levantó un hallazgo en la auditoría de seguridad

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.914.905.948
Ejecutado 1.363.750.954
Proyección al cierre 6.573.275.532

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Ventana de parada de planta definida por operaciones
