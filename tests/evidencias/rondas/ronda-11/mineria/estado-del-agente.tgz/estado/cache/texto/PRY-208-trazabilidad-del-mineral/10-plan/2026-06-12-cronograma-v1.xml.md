<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2026-06-12-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-10-07 | 2026-10-07 | 2026-10-07 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2027-01-22 | 2027-01-22 | 2027-01-22 | 50% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2027-05-10 | 2027-05-10 | 2027-05-10 | 50% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2027-08-25 | 2027-08-25 | 2027-08-25 | 50% | hito | 3FS | — |
| 5 | 5 | Pruebas en operación | 2027-12-11 | 2027-12-11 | 2027-12-11 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-10-07 | 2026-10-07 | cerrado |
| Ingeniería de detalle aprobada | 2027-01-22 | 2027-01-22 | en curso |
| Licencia y permisos obtenidos | 2027-05-10 | 2027-05-10 | en curso |
| Montaje e instalación | 2027-08-25 | 2027-08-25 | en curso |
| Pruebas en operación | 2027-12-11 | 2027-12-11 | en curso |
