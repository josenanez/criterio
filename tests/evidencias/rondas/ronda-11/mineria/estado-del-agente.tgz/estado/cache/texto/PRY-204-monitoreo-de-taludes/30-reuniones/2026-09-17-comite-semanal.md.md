<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-09-17
**Asistentes:** Andrés Lozano, Elena Duarte, Javier Hoyos, Jorge Medina, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-09-25 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-18 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-03 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-11 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-01 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-11 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Jorge Medina): recibido, acta de recibo del 2026-09-17.
