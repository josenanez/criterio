<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-204",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "name": {
 "value": "Monitoreo de taludes",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Geología",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "product": {
 "value": "alerta de taludes",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Gustavo Neira",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "manager": {
 "value": "Andrés Lozano",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Inversiones",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 56,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-22",
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-04-01",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "end_date": {
 "value": "2027-11-06",
 "source": "10-plan/2026-10-22-cronograma-v2.xml",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-03-22",
 "start_date": "2026-04-01",
 "end_date": "2027-08-14",
 "reason": "línea base original, aprobada con el acta de constitución",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2026-07-10",
 "current_date": "2026-07-10",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-12-acta-recibo-ingeniería-básica-aprobada.pdf",
 "source": "10-plan/2026-10-22-cronograma-v2.xml"
 },
 {
 "name": "Ingeniería de detalle aprobada",
 "baseline_date": "2026-10-18",
 "current_date": "2026-10-18",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-19-acta-recibo-ingeniería-de-detalle-aprobada.pdf",
 "source": "10-plan/2026-10-22-cronograma-v2.xml"
 },
 {
 "name": "Licencia y permisos obtenidos",
 "baseline_date": "2027-01-26",
 "current_date": "2027-01-26",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-22-cronograma-v2.xml"
 },
 {
 "name": "Montaje e instalación",
 "baseline_date": "2027-05-06",
 "current_date": "2027-05-06",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-22-cronograma-v2.xml"
 },
 {
 "name": "Pruebas en operación",
 "baseline_date": "2027-08-14",
 "current_date": "2027-11-06",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-22-cronograma-v2.xml"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "exclusions": [
 {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 }
 ]
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2026-03-22-acta-constitucion.docx",
 "source_date": "2026-03-22",
 "state": "found"
 },
 "committed": {
 "value": 4969453075,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 4437292727,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 11362933575,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf",
 "source_date": "2026-10-22",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Geotecnia Aplicada S.A.S.",
 "source": "00-gobierno/2026-03-19-contrato-ct-950.docx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-950",
 "source": "00-gobierno/2026-03-19-contrato-ct-950.docx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del software",
 "source": "00-gobierno/2026-03-19-contrato-ct-950.docx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "due_date": "2026-10-01",
 "amount": 861859911,
 "state": "accepted",
 "evidence": null
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería",
 "source": "00-gobierno/2026-03-19-contrato-ct-950.docx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "due_date": "2027-04-03",
 "amount": 861859911,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": 861859911,
 "source": "20-seguimiento/2026-09-06-factura-ct-950.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "source": "00-gobierno/2026-03-19-contrato-ct-950.docx"
 },
 {
 "name": {
 "value": "Montajes Industriales Ltda.",
 "source": "00-gobierno/2026-03-26-contrato-ct-307.docx",
 "source_date": "2026-03-26",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-307",
 "source": "00-gobierno/2026-03-26-contrato-ct-307.docx",
 "source_date": "2026-03-26",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del software",
 "source": "00-gobierno/2026-03-26-contrato-ct-307.docx",
 "source_date": "2026-03-26",
 "state": "found"
 },
 "due_date": "2026-10-01",
 "amount": 1018807189,
 "state": "accepted",
 "evidence": null
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería",
 "source": "00-gobierno/2026-03-26-contrato-ct-307.docx",
 "source_date": "2026-03-26",
 "state": "found"
 },
 "due_date": "2027-04-03",
 "amount": 1018807189,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": 1310271638,
 "source": "20-seguimiento/2026-09-04-factura-ct-307.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "source": "00-gobierno/2026-03-26-contrato-ct-307.docx"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; en la reunión se comentó y nadie lo registró como riesgo",
 "probability": null,
 "impact": null,
 "owner": "no_identificado",
 "due_date": null,
 "last_moved": null,
 "source": "2026-10-22-notas-reunion.txt"
 },
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": "2026-10-22",
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite",
 "since": "2026-10-22",
 "owner": null,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf"
 },
 {
 "what": "Las lluvias detuvieron el montaje durante diez días",
 "since": "2026-10-22",
 "owner": null,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf"
 }
 ],
 "dependencies": [
 {
 "on_project": null,
 "what": "Ventana de parada de planta definida por operaciones",
 "needed_by": null,
 "confirmed": false,
 "source": "20-seguimiento/2026-10-22-informe-avance.pdf"
 }
 ]
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-19",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+84 días sobre la línea base vigente",
 "cost_impact": "168.000.000 COP adicionales",
 "decision": "pending",
 "decided_by": null,
 "source": "20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-02",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-25",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-02",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ],
 "note": "el 2026-09-10 se prometió «por definir»; la primera fecha (2026-09-25) se puso el 2026-09-17"
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2027-01-02",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-19",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 },
 {
 "due_date": "2027-01-02",
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt"
 }
 ],
 "note": "notas del 2026-10-22: «02/01/2027»; leída día/mes (2 de enero de 2027), pendiente de confirmar con el gerente"
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-08",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-13",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-08",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-17-acta-recibo-4.md"
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ],
 "declared_delivered": {
 "text": "Jorge Medina dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08"
 },
 "note": "desde el 2026-10-08 ya no aparece en la lista de abiertos y no hay acta que lo cierre"
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "declared_delivered": {
 "text": "Javier Hoyos dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01"
 },
 "note": "desde el 2026-10-08 ya no aparece en la lista de abiertos y no hay acta que lo cierre"
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "declared_delivered": {
 "text": "Rubén Cárdenas dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08"
 },
 "note": "desde el 2026-10-08 ya no aparece en la lista de abiertos y no hay acta que lo cierre"
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "sigue en las listas del 2026-10-01, 2026-10-08 y 2026-10-15 con la misma fecha, ya pasada"
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "declared_delivered": {
 "text": "Beatriz Cuéllar dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08"
 },
 "note": "desde el 2026-10-08 ya no aparece en la lista de abiertos y no hay acta que lo cierre"
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-12.md"
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-04",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-04",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-13.md"
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-30",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-30",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "las notas del 2026-10-22 dicen «Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01»; no nombran el ambiente 20, por eso se registra aparte y no como reprogramación"
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-07",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-07",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "raw_due_text": "la otra semana"
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-01",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-01",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-23"
 }
}
