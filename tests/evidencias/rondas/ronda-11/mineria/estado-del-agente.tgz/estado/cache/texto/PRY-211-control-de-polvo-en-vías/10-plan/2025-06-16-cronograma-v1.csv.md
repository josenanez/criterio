<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2025-06-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-09-09,2025-09-09,cerrado
Ingeniería de detalle aprobada,2025-11-23,2025-11-23,cerrado
Licencia y permisos obtenidos,2026-02-06,2026-02-06,cerrado
Montaje e instalación,2026-04-22,2026-04-22,cerrado
