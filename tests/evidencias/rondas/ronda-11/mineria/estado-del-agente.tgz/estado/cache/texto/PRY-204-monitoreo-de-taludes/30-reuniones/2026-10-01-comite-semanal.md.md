<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-10-01
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Carlos Peña, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, María Restrepo, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-10-24 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-11-12 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-31 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-25 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-15 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 |
| Sandra Gil | Enviar el documento 9 | 2026-10-01 |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-09 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-04 |
| Andrés Lozano | Actualizar la matriz 14 | por definir |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-24 |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 |

## Cerrados en esta reunión

- Validar el ambiente 12 (María Restrepo): recibido, acta de recibo del 2026-10-01.

## Lo que se dijo

- Javier Hoyos dice que ya entregó «confirmar la fecha 7». No se presentó acta.
