<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Monitoreo de taludes
Código: PRY-204
Fecha de corte: 2026-10-22
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 56%

Lo que pasó en el periodo
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 4.969.453.075
Ejecutado 4.437.292.727
Proyección al cierre 11.362.933.575

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Ventana de parada de planta definida por operaciones
