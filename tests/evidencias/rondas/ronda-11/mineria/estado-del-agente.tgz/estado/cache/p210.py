import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-210-programa-de-relacionamiento-comunitario/"
ACTA = P + "00-gobierno/2025-10-05-acta-constitucion.docx"
V1 = P + "10-plan/2025-10-05-cronograma-v1.xlsx"
INF = P + "20-seguimiento/2026-10-15-informe-avance.pdf"

ident = {
    "code": F("PRY-210", ACTA), "name": F("Programa de relacionamiento comunitario", ACTA), "aliases": [],
    "business_area": F("Mina", ACTA), "product": F(None), "authority": F(None),
    "sponsor": F("Óscar Ramírez", ACTA), "manager": F("Jorge Medina", INF),
    "committee": F("Comité de Inversiones", ACTA), "phase": F(None),
}
declared = {"status": D("amarillo", INF), "progress_pct": D(76, INF), "as_of": D("2026-10-15", INF), "source": INF}
ms = lambda n, d: {"name": n, "baseline_date": d, "current_date": d, "state": "met", "evidence": "", "source": V1}
plan = {
    "start_date": F("2025-10-15", ACTA), "end_date": F("2026-08-29", V1),
    "baseline": [{"version": 1, "approved_on": "2025-10-05", "start_date": "2025-10-15", "end_date": "2026-08-29",
                  "baseline_end_date": "2026-08-29", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-01-02"), ms("Ingeniería de detalle aprobada", "2026-03-23"),
        ms("Licencia y permisos obtenidos", "2026-06-10"), ms("Montaje e instalación", "2026-08-29"),
    ],
    "scope_summary": F("Entregar programa de relacionamiento comunitario para Mina (tres componentes sin detallar)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(18000000000, INF), "committed": F(12381554857, INF),
         "executed": F(6740699703, INF), "projection": F(17670441375, INF)}
raid = {"risks": [{"what": "El proveedor no ha confirmado la fecha de la última entrega", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [],
        "issues": [
            {"what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite", "since": None, "owner": None, "source": INF},
            {"what": "El equipo perdió dos semanas por rotación de un ingeniero clave", "since": None, "owner": None, "source": INF}],
        "dependencies": []}
build("PRY-210", ident, declared, plan, money, [], raid, [], [])
