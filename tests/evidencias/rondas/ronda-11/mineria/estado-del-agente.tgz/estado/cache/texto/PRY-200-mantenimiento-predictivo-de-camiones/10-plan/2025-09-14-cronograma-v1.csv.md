<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-09-14-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-11-01,2025-11-01,cerrado
Ingeniería de detalle aprobada,2025-12-10,2025-12-10,cerrado
Licencia y permisos obtenidos,2026-01-18,2026-01-18,cerrado
Montaje e instalación,2026-02-26,2026-02-26,cerrado
Pruebas en operación,2026-04-06,2026-04-06,cerrado
