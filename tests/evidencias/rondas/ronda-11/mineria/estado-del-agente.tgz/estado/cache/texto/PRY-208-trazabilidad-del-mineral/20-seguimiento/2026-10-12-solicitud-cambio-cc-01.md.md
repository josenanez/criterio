<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-12-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-12
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +34 días sobre la línea base vigente |
| Costo | 68.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
