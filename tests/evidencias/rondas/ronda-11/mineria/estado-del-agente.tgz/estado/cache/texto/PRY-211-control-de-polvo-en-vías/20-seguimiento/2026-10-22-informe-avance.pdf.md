<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Control de polvo en vías
Código: PRY-211
Fecha de corte: 2026-10-22
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 58%

Lo que pasó en el periodo
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 11.447.019.333
Ejecutado 10.548.829.409
Proyección al cierre 17.889.833.959

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
