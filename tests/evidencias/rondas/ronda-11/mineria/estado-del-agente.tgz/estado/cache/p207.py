import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-207-gemelo-digital-de-la-planta/"
ACTA = P + "00-gobierno/2026-06-19-acta-constitucion.md"
V1 = P + "10-plan/2026-06-19-cronograma-v1.xml"
INF = P + "20-seguimiento/2026-10-18-informe-avance.pdf"

ident = {
    "code": F("PRY-207", ACTA), "name": F("Gemelo digital de la planta", ACTA), "aliases": [],
    "business_area": F("Medio Ambiente", ACTA), "product": F("gemelo digital", ACTA), "authority": F(None),
    "sponsor": F("Laura Vélez", ACTA), "manager": F("Jorge Medina", INF),
    "committee": F("Comité de Operaciones", ACTA), "phase": F(None),
}
declared = {"status": D("rojo", INF), "progress_pct": D(40, INF), "as_of": D("2026-10-18", INF), "source": INF}
ms = lambda n, d, st, ev="": {"name": n, "baseline_date": d, "current_date": d, "state": st, "evidence": ev, "source": V1}
plan = {
    "start_date": F("2026-06-29", ACTA), "end_date": F("2027-06-04", V1),
    "baseline": [{"version": 1, "approved_on": "2026-06-19", "start_date": "2026-06-29", "end_date": "2027-06-04",
                  "baseline_end_date": "2027-06-04", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-09-05", "met"),
        ms("Ingeniería de detalle aprobada", "2026-11-12", "pending"),
        ms("Licencia y permisos obtenidos", "2027-01-19", "pending"),
        ms("Montaje e instalación", "2027-03-28", "pending"),
        ms("Pruebas en operación", "2027-06-04", "pending"),
    ],
    "scope_summary": F("Entregar gemelo digital de la planta para Medio Ambiente (tres componentes sin detallar)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(6800000000, INF), "committed": F(4914905948, INF),
         "executed": F(1363750954, INF), "projection": F(6573275532, INF)}
rk = lambda w: {"what": w, "probability": None, "impact": None, "owner": None, "due_date": None, "last_moved": None, "source": INF}
iss = lambda w: {"what": w, "since": None, "owner": None, "source": INF}
raid = {"risks": [rk("El proveedor no ha confirmado la fecha de la última entrega"), rk("Ventana de parada de planta definida por operaciones")],
        "assumptions": [],
        "issues": [iss("El equipo perdió dos semanas por rotación de un ingeniero clave"),
                   iss("Las lluvias detuvieron el montaje durante diez días (el hito de montaje está previsto para 2027-03-28)"),
                   iss("Se levantó un hallazgo en la auditoría de seguridad")],
        "dependencies": []}
build("PRY-207", ident, declared, plan, money, [], raid, [], [])
