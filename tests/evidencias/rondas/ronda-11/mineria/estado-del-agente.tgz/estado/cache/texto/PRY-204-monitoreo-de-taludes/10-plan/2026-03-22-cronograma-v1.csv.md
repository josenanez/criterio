<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-03-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-10,2026-07-10,cerrado
Ingeniería de detalle aprobada,2026-10-18,2026-10-18,cerrado
Licencia y permisos obtenidos,2027-01-26,2027-01-26,en curso
Montaje e instalación,2027-05-06,2027-05-06,en curso
Pruebas en operación,2027-08-14,2027-08-14,en curso
