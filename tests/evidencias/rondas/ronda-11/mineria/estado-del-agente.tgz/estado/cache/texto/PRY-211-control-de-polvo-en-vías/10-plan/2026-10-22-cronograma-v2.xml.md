<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2026-10-22-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2025-09-09 | 2025-09-09 | 2025-09-09 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2025-11-23 | 2025-11-23 | 2025-11-23 | 100% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2026-02-06 | 2026-02-06 | 2026-02-06 | 100% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2026-06-04 | 2026-06-04 | 2026-04-22 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-09-09 | 2025-09-09 | cerrado |
| Ingeniería de detalle aprobada | 2025-11-23 | 2025-11-23 | cerrado |
| Licencia y permisos obtenidos | 2026-02-06 | 2026-02-06 | cerrado |
| Montaje e instalación | 2026-04-22 | 2026-06-04 | cerrado |
