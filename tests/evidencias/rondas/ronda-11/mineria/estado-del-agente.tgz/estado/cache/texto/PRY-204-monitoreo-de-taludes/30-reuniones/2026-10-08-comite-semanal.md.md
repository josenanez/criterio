<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-11-12 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-11-28 |
| Elena Duarte | Revisar el anexo 3 | 2026-11-19 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-11-06 |
| Sandra Gil | Enviar el documento 9 | 2026-10-01 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| Andrés Lozano | Actualizar la matriz 14 | por definir |
| Carlos Peña | Confirmar la fecha 15 | 2026-11-03 |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 |
| Andrés Lozano | Enviar el documento 17 | por definir |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-30 |
| Carlos Peña | Revisar el anexo 19 | 2026-10-23 |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-21 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (María Restrepo): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- Jorge Medina dice que ya entregó «actualizar la matriz 6». No se presentó acta.
- Rubén Cárdenas dice que ya entregó «entregar el punto 8». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «cerrar la prueba 10». No se presentó acta.
