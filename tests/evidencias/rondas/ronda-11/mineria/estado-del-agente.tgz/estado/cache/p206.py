import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-206-red-privada-lte-en-mina/"
ACTA = P + "00-gobierno/2025-08-30-acta-constitucion.docx"
V1 = P + "10-plan/2025-08-30-cronograma-v1.csv"
V2 = P + "10-plan/2026-10-22-cronograma-v2.xml"
INF = P + "20-seguimiento/2026-10-22-informe-avance.pdf"
CC1 = P + "20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md"
COM = P + "30-reuniones/2026-10-15-comite-semanal.md"

ident = {
    "code": F("PRY-206", ACTA), "name": F("Red privada LTE en mina", ACTA), "aliases": [],
    "business_area": F("Seguridad y Salud", ACTA), "product": F(None), "authority": F(None),
    "sponsor": F("Elena Duarte", ACTA), "manager": F("Carlos Peña", INF),
    "committee": F("Comité de Tecnología", COM), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(87, INF), "as_of": D("2026-10-22", INF), "source": INF}
ms = lambda n, b, c: {"name": n, "baseline_date": b, "current_date": c, "state": "met", "evidence": "", "source": V2}
plan = {
    "start_date": F("2025-09-09", ACTA), "end_date": F("2026-10-07", V2),
    "baseline": [
        {"version": 1, "approved_on": "2025-08-30", "start_date": "2025-09-09", "end_date": "2026-06-27",
         "baseline_end_date": "2026-06-27", "source": ACTA, "reason": "Línea base original del acta de constitución"},
        {"version": 2, "approved_on": "2026-10-22", "start_date": None, "end_date": "2026-10-07",
         "baseline_end_date": "2026-06-27", "source": V2,
         "reason": "Solicitud de cambio CC-01: ampliación de alcance, +102 días, autorizada por el comité"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2025-12-15", "2025-12-15"),
        ms("Ingeniería de detalle aprobada", "2026-03-22", "2026-03-22"),
        ms("Licencia y permisos obtenidos", "2026-06-27", "2026-10-07"),
    ],
    "scope_summary": F("Entregar red privada LTE en mina para Seguridad y Salud (tres componentes sin detallar; CC-01 lo amplía)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(800000000, INF), "committed": F(640096825, INF),
         "executed": F(217765546, INF), "projection": F(801553455, INF)}
rk = lambda w: {"what": w, "probability": None, "impact": None, "owner": None, "due_date": None, "last_moved": None, "source": INF}
raid = {"risks": [rk("Bloqueo de la vía de acceso a la mina"), rk("El proveedor no ha confirmado la fecha de la última entrega")],
        "assumptions": [],
        "issues": [
            {"what": "Se levantó un hallazgo en la auditoría de seguridad", "since": None, "owner": None, "source": INF},
            {"what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite", "since": None, "owner": None, "source": INF}],
        "dependencies": []}
changes = [{"ref": "CC-01", "requested_on": "2026-10-15", "scope_impact": "Ampliación de alcance",
            "time_impact": "+102 días sobre la línea base vigente", "cost_impact": "204.000.000 COP adicionales",
            "decision": "approved", "decided_by": "el comité (sin nombre; el acta del comité del 2026-10-15 no la menciona)", "source": CC1}]
commitments = [{"who": "Gustavo Neira", "what": "Entregar el punto 24", "due_date": "2026-10-23", "original_due_date": "2026-10-23",
                "stated_on": "2026-10-15", "source": COM, "state": "open", "reschedules": []}]
build("PRY-206", ident, declared, plan, money, [], raid, changes, commitments)
