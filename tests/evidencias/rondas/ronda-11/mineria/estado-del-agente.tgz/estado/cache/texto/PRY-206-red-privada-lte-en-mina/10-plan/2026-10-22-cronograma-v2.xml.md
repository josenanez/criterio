<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2026-10-22-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2025-12-15 | 2025-12-15 | 2025-12-15 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-03-22 | 2026-03-22 | 2026-03-22 | 100% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2026-10-07 | 2026-10-07 | 2026-06-27 | 100% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-12-15 | 2025-12-15 | cerrado |
| Ingeniería de detalle aprobada | 2026-03-22 | 2026-03-22 | cerrado |
| Licencia y permisos obtenidos | 2026-06-27 | 2026-10-07 | cerrado |
