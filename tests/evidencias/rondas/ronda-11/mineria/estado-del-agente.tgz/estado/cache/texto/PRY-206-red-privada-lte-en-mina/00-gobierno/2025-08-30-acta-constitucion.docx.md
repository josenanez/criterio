<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2025-08-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Seguridad y Salud

Patrocinador: Elena Duarte

Gerente de proyecto: Carlos Peña

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2025-08-30

Objetivo del negocio

Entregar red privada lte en mina para Seguridad y Salud.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Tecnología el 2025-08-30.

Fechas comprometidas

Fecha

Inicio

2025-09-09

Cierre

2026-06-27

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
