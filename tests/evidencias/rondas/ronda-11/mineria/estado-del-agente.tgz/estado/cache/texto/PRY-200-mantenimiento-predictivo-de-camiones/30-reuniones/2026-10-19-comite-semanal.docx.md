<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-19-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Operaciones · Mantenimiento predictivo de camiones

Fecha: 2026-10-19

Asistentes: Carlos Peña, Andrés Lozano

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Liliana Torres

Entregar el punto 4

2026-10-23

Beatriz Cuéllar

Entregar el punto 33

por definir
