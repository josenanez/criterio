<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2026-06-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-08-17 | 2026-08-17 | cerrado
Ingeniería de detalle aprobada | 2026-10-22 | 2026-10-22 | en curso
Licencia y permisos obtenidos | 2026-12-28 | 2026-12-28 | en curso
Montaje e instalación | 2027-03-04 | 2027-03-04 | en curso
