<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-10-22-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-07-10 | 2026-07-10 | 2026-07-10 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-10-18 | 2026-10-18 | 2026-10-18 | 100% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2027-01-26 | 2027-01-26 | 2027-01-26 | 50% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2027-05-06 | 2027-05-06 | 2027-05-06 | 50% | hito | 3FS | — |
| 5 | 5 | Pruebas en operación | 2027-11-06 | 2027-11-06 | 2027-08-14 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-07-10 | 2026-07-10 | cerrado |
| Ingeniería de detalle aprobada | 2026-10-18 | 2026-10-18 | cerrado |
| Licencia y permisos obtenidos | 2027-01-26 | 2027-01-26 | en curso |
| Montaje e instalación | 2027-05-06 | 2027-05-06 | en curso |
| Pruebas en operación | 2027-08-14 | 2027-11-06 | en curso |
