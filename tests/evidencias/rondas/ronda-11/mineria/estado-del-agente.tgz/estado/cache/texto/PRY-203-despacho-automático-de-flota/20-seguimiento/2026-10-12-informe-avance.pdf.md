<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Despacho automático de flota
Código: PRY-203
Fecha de corte: 2026-10-12
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 38%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.597.010.251
Ejecutado 2.894.328.076
Proyección al cierre 8.503.714.527

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
