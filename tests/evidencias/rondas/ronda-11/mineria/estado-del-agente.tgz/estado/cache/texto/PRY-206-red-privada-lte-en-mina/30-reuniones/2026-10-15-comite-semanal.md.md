<!-- origen: PRY-206-red-privada-lte-en-mina/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Red privada LTE en mina

**Fecha:** 2026-10-15
**Asistentes:** Carlos Peña, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 24 | 2026-10-23 |
