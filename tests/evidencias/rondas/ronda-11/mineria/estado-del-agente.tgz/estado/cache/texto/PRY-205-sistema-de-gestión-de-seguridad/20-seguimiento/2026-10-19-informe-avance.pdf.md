<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Sistema de gestión de seguridad
Código: PRY-205
Fecha de corte: 2026-10-19
Gerente: Óscar Ramírez

Estado declarado
Verde
Avance reportado: 43%

Lo que pasó en el periodo
- Se acordó con operaciones el plan de arranque de los equipos

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.948.969.722
Ejecutado 1.257.515.457
Proyección al cierre 6.802.912.497

Riesgos abiertos
- Concentración del conocimiento en una sola persona
