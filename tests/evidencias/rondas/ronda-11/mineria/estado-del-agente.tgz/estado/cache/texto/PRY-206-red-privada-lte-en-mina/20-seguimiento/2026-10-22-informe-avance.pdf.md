<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-22
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 87%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

Presupuesto
COP
Aprobado 800.000.000
Comprometido 640.096.825
Ejecutado 217.765.546
Proyección al cierre 801.553.455

Riesgos abiertos
- Bloqueo de la vía de acceso a la mina
- El proveedor no ha confirmado la fecha de la última entrega
