import sys, json
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

DOCS = "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/documentos/proyectos/"
P = "PRY-204-monitoreo-de-taludes/"
ACTA = P + "00-gobierno/2026-03-22-acta-constitucion.docx"
V1 = P + "10-plan/2026-03-22-cronograma-v1.csv"
V2 = P + "10-plan/2026-10-22-cronograma-v2.xml"
INF = P + "20-seguimiento/2026-10-22-informe-avance.pdf"
CC1 = P + "20-seguimiento/2026-10-19-solicitud-cambio-cc-01.md"
CT950 = P + "00-gobierno/2026-03-19-contrato-ct-950.docx"
CT307 = P + "00-gobierno/2026-03-26-contrato-ct-307.docx"
F950 = P + "20-seguimiento/2026-09-06-factura-ct-950.md"
F307 = P + "20-seguimiento/2026-09-04-factura-ct-307.md"
NOTAS = P + "2026-10-22-notas-reunion.txt"
A_BAS = P + "20-seguimiento/2026-10-12-acta-recibo-ingeniería-básica-aprobada.pdf"
A_DET = P + "20-seguimiento/2026-10-19-acta-recibo-ingeniería-de-detalle-aprobada.pdf"
M = lambda d: P + "30-reuniones/%s-comite-semanal.md" % d

ident = {
    "code": F("PRY-204", ACTA), "name": F("Monitoreo de taludes", ACTA), "aliases": [],
    "business_area": F("Geología", ACTA), "product": F("alerta de taludes", ACTA), "authority": F(None),
    "sponsor": F("Gustavo Neira", ACTA), "manager": F("Andrés Lozano", INF),
    "committee": F("Comité de Inversiones", M("2026-10-15")), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(56, INF), "as_of": D("2026-10-22", INF), "source": INF}
ms = lambda n, b, c, st, ev="": {"name": n, "baseline_date": b, "current_date": c, "state": st, "evidence": ev, "source": V2}
plan = {
    "start_date": F("2026-04-01", ACTA), "end_date": F("2027-11-06", V2),
    "baseline": [
        {"version": 1, "approved_on": "2026-03-22", "start_date": "2026-04-01", "end_date": "2027-08-14",
         "baseline_end_date": "2027-08-14", "source": ACTA, "reason": "Línea base original del acta de constitución"},
        {"version": 2, "approved_on": "2026-10-22", "start_date": None, "end_date": "2027-11-06",
         "baseline_end_date": "2027-08-14", "source": V2,
         "reason": "Cronograma v2 mueve Pruebas en operación +84 días; la CC-01 (+84 días) figura «pendiente de presentación al comité», sin decisión en ningún documento"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-07-10", "2026-07-10", "met", A_BAS),
        ms("Ingeniería de detalle aprobada", "2026-10-18", "2026-10-18", "met", A_DET),
        ms("Licencia y permisos obtenidos", "2027-01-26", "2027-01-26", "pending"),
        ms("Montaje e instalación", "2027-05-06", "2027-05-06", "pending"),
        ms("Pruebas en operación", "2027-08-14", "2027-11-06", "pending"),
    ],
    "scope_summary": F("Entregar monitoreo de taludes para Geología (tres componentes sin detallar; CC-01 pendiente lo amplía)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(9500000000, INF), "committed": F(4969453075, INF),
         "executed": F(4437292727, INF), "projection": F(11362933575, INF)}
dl = lambda n, d, amt, st: {"name": n, "due_date": d, "amount": amt, "state": st, "evidence": ""}
vendors = [
    {"name": "Geotecnia Aplicada S.A.S.", "contract_ref": "CT-950",
     "deliverables": [dl("Licenciamiento del software", "2026-10-01", 861859911, "accepted"),
                      dl("Bolsa de horas de ingeniería", "2027-04-03", 861859911, "pending")],
     "invoiced": F(861859911, F950), "source": CT950},
    {"name": "Montajes Industriales Ltda.", "contract_ref": "CT-307",
     "deliverables": [dl("Licenciamiento del software", "2026-10-01", 1018807189, "accepted"),
                      dl("Bolsa de horas de ingeniería", "2027-04-03", 1018807189, "pending")],
     "invoiced": F(1310271638, F307), "source": CT307},
]
rk = lambda w, src, owner=None: {"what": w, "probability": None, "impact": None, "owner": owner,
                                 "due_date": None, "last_moved": None, "source": src}
raid = {"risks": [
    rk("El proveedor no ha confirmado la fecha de la última entrega", INF),
    rk("Ventana de parada de planta definida por operaciones", INF),
    rk("El proveedor podría no llegar con el equipo completo para la siguiente fase; se comentó en la reunión y nadie lo anotó como riesgo", NOTAS, "no_identificado")],
    "assumptions": [],
    "issues": [
        {"what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite", "since": None, "owner": None, "source": INF},
        {"what": "Las lluvias detuvieron el montaje durante diez días (el cronograma ubica el montaje en 2027-05-06)", "since": None, "owner": None, "source": INF}],
    "dependencies": []}
changes = [{"ref": "CC-01", "requested_on": "2026-10-19", "scope_impact": "Ampliación de alcance",
            "time_impact": "+84 días sobre la línea base vigente", "cost_impact": "168.000.000 COP adicionales",
            "decision": "pending", "decided_by": None, "source": CC1}]


def C(who, what, orig, stated, src, state, res=(), due=None, **extra):
    r = [{"due_date": d, "stated_on": s, "source": (NOTAS if s == "2026-10-22" else M(s))} for d, s in res]
    c = {"who": who, "what": what, "due_date": due or (r[-1]["due_date"] if r else orig), "original_due_date": orig,
         "stated_on": stated, "source": (NOTAS if stated == "2026-10-22" else M(stated)), "state": state, "reschedules": r}
    c.update(extra)
    return c


ND = "no_declarada"
dd = lambda who, s: {"text": "%s dice que ya entregó; no se presentó acta" % who, "source": M(s), "source_date": s}
commitments = [
    C("Sandra Gil", "Enviar el documento 1", "2026-09-25", "2026-09-10", None, "open",
      [("2026-10-11", "2026-09-24"), ("2026-10-24", "2026-10-01"), ("2026-11-12", "2026-10-08"), ("2026-12-02", "2026-10-15")],
      note="el 2026-09-10 se prometió «por definir»; la primera fecha (2026-09-25) se puso el 2026-09-17, así que no cuenta como reprogramación"),
    C("Andrés Lozano", "Cerrar la prueba 2", "2026-10-08", "2026-09-10", None, "open",
      [("2026-10-18", "2026-09-17"), ("2026-10-29", "2026-09-24"), ("2026-11-12", "2026-10-01"), ("2026-11-28", "2026-10-08"),
       ("2026-12-19", "2026-10-15"), ("2027-01-02", "2026-10-22")],
      note="notas del 2026-10-22: «02/01/2027»; leída día/mes (2027-01-02), por confirmar con el gerente"),
    C("Elena Duarte", "Revisar el anexo 3", "2026-09-13", "2026-09-10", None, "open",
      [("2026-10-03", "2026-09-17"), ("2026-10-14", "2026-09-24"), ("2026-10-31", "2026-10-01"), ("2026-11-19", "2026-10-08"), ("2026-12-08", "2026-10-15")]),
    C("Jorge Medina", "Validar el ambiente 4", "2026-09-30", "2026-09-10", None, "met",
      evidence=P + "20-seguimiento/2026-09-17-acta-recibo-4.md"),
    C("Javier Hoyos", "Aprobar el diseño 5", "2026-10-11", "2026-09-17", None, "open",
      [("2026-10-25", "2026-10-01"), ("2026-11-06", "2026-10-08")]),
    C("Jorge Medina", "Actualizar la matriz 6", "2026-10-01", "2026-09-17", None, "overdue",
      [("2026-10-15", "2026-09-24")], declared_delivered=dd("Jorge Medina", "2026-10-08"),
      note="desde el 2026-10-08 ya no aparece en la lista de abiertos; no hay acta que lo cierre"),
    C("Javier Hoyos", "Confirmar la fecha 7", "2026-10-11", "2026-09-17", None, "overdue",
      declared_delivered=dd("Javier Hoyos", "2026-10-01"),
      note="desde el 2026-10-08 ya no aparece en la lista de abiertos; no hay acta que lo cierre"),
    C("Rubén Cárdenas", "Entregar el punto 8", "2026-10-02", "2026-09-17", None, "overdue",
      declared_delivered=dd("Rubén Cárdenas", "2026-10-08"),
      note="desde el 2026-10-08 ya no aparece en la lista de abiertos; no hay acta que lo cierre"),
    C("Sandra Gil", "Enviar el documento 9", "2026-10-01", "2026-09-24", None, "overdue",
      note="sigue en las listas del 2026-10-01, 2026-10-08 y 2026-10-15 con la misma fecha, ya pasada"),
    C("Beatriz Cuéllar", "Cerrar la prueba 10", "2026-10-09", "2026-09-24", None, "overdue",
      declared_delivered=dd("Beatriz Cuéllar", "2026-10-08"),
      note="desde el 2026-10-08 ya no aparece en la lista de abiertos; no hay acta que lo cierre"),
    C("Jorge Medina", "Revisar el anexo 11", "2026-10-22", "2026-09-24", None, "overdue",
      note="vencía el 2026-10-22; sigue en la lista del 2026-10-15 y las notas del 2026-10-22 no lo mencionan"),
    C("María Restrepo", "Validar el ambiente 12", "2026-10-09", "2026-09-24", None, "met",
      evidence=P + "20-seguimiento/2026-10-01-acta-recibo-12.md"),
    C("María Restrepo", "Aprobar el diseño 13", "2026-10-04", "2026-10-01", None, "met",
      evidence=P + "20-seguimiento/2026-10-08-acta-recibo-13.md"),
    C("Andrés Lozano", "Actualizar la matriz 14", ND, "2026-10-01", None, "open", note="«por definir» en las tres reuniones en que aparece"),
    C("Carlos Peña", "Confirmar la fecha 15", "2026-10-24", "2026-10-01", None, "open", [("2026-11-03", "2026-10-08")]),
    C("Felipe Arango", "Entregar el punto 16", "2026-10-12", "2026-10-01", None, "overdue",
      note="sigue en las listas del 2026-10-08 y 2026-10-15 con la misma fecha, ya pasada"),
    C("Andrés Lozano", "Enviar el documento 17", ND, "2026-10-08", None, "open"),
    C("Rubén Cárdenas", "Cerrar la prueba 18", "2026-10-30", "2026-10-08", None, "open"),
    C("Carlos Peña", "Revisar el anexo 19", "2026-10-23", "2026-10-08", None, "open", note="vence el día de la corrida"),
    C("Óscar Ramírez", "Validar el ambiente 20", "2026-10-21", "2026-10-08", None, "overdue",
      note="las notas del 2026-10-22 dicen «revisión con el proveedor, queda para el 2026-11-01» sin nombrar el ambiente 20; se registra aparte y no como reprogramación"),
    C("Javier Hoyos", "Aprobar el diseño 21", ND, "2026-10-15", None, "open"),
    C("María Restrepo", "Actualizar la matriz 22", "2026-10-29", "2026-10-15", None, "open"),
    C("Camilo Beltrán", "Confirmar la fecha 23", "2026-11-07", "2026-10-15", None, "open"),
    C("Paula Céspedes", "Entregar el punto 24", "2026-10-23", "2026-10-15", None, "open", note="vence el día de la corrida"),
    C("Laura Vélez", "Mandar el ajuste del presupuesto", ND, "2026-10-22", None, "open", raw_due_text="la otra semana"),
    C("Óscar Ramírez", "Revisión con el proveedor", "2026-11-01", "2026-10-22", None, "open"),
]
for c in commitments:
    c.pop("src", None)
pm = json.load(open(DOCS + P + "00-gobierno/ficha-pm.json"))
build("PRY-204", ident, declared, plan, money, vendors, raid, changes, commitments, {"pm_record": pm})
