import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-201-ampliación-de-la-relavera/"
ACTA = P + "00-gobierno/2026-02-03-acta-constitucion.docx"
V1 = P + "10-plan/2026-02-03-cronograma-v1.xlsx"
V2 = P + "10-plan/2026-10-21-cronograma-v2.xml"
INF = P + "20-seguimiento/2026-10-21-informe-avance.md"
COM = P + "30-reuniones/2026-10-16-comite-semanal.md"
CC1 = P + "20-seguimiento/2026-10-16-solicitud-cambio-cc-01.md"

ident = {
    "code": F("PRY-201", ACTA), "name": F("Ampliación de la relavera", ACTA), "aliases": [],
    "business_area": F("Medio Ambiente", ACTA),
    "product": F(None),  # el acta dice «No aplica»: no sirve a un producto
    "authority": F(None), "sponsor": F("Jorge Medina", ACTA), "manager": F("Diana Molina", INF),
    "committee": F("Comité de Operaciones", COM), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(67, INF), "as_of": D("2026-10-21", INF), "source": INF}
ms = lambda n, b, c, st, ev="": {"name": n, "baseline_date": b, "current_date": c, "state": st, "evidence": ev, "source": V2}
plan = {
    "start_date": F("2026-02-13", ACTA), "end_date": F("2027-06-21", V2),
    "baseline": [
        {"version": 1, "approved_on": "2026-02-03", "start_date": "2026-02-13", "end_date": "2027-04-21",
         "baseline_end_date": "2027-04-21", "source": V1, "reason": "Línea base original del acta de constitución"},
        {"version": 2, "approved_on": "2026-10-21", "start_date": None, "end_date": "2027-06-21",
         "baseline_end_date": "2027-04-21", "source": V2,
         "reason": "Solicitud de cambio CC-01: ampliación de alcance, +61 días, autorizada por el comité"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-07-07", "2026-07-07", "met"),
        ms("Ingeniería de detalle aprobada", "2026-11-28", "2026-11-28", "pending"),
        ms("Licencia y permisos obtenidos", "2027-04-21", "2027-06-21", "pending"),
    ],
    "scope_summary": F("Entregar ampliación de la relavera para Medio Ambiente (tres componentes sin detallar; CC-01 lo amplía)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(18000000000, INF), "committed": F(16735307598, INF),
         "executed": F(6108769631, INF), "projection": F(18209304767, INF)}
raid = {"risks": [{"what": "El proveedor no ha confirmado la fecha de la última entrega", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [],
        "issues": [
            {"what": "El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite", "since": None, "owner": None, "source": INF},
            {"what": "Se levantó un hallazgo en la auditoría de seguridad", "since": None, "owner": None, "source": INF},
            {"what": "Las lluvias detuvieron el montaje durante diez días (el cronograma no tiene hito de montaje)", "since": None, "owner": None, "source": INF}],
        "dependencies": []}
changes = [{"ref": "CC-01", "requested_on": "2026-10-16", "scope_impact": "Ampliación de alcance",
            "time_impact": "+61 días sobre la línea base vigente", "cost_impact": "122.000.000 COP adicionales",
            "decision": "approved", "decided_by": "el comité (sin nombre ni acta de comité que la cite)", "source": CC1}]
commitments = [{"who": "Paula Céspedes", "what": "Entregar el punto 19", "due_date": "2026-11-02", "original_due_date": "2026-11-02",
                "stated_on": "2026-10-16", "source": COM, "state": "open", "reschedules": []}]
build("PRY-201", ident, declared, plan, money, [], raid, changes, commitments)
