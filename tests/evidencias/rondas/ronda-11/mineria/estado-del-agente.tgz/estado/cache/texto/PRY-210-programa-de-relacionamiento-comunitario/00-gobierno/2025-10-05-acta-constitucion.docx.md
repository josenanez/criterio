<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/00-gobierno/2025-10-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de relacionamiento comunitario

Código: PRY-210

Área dueña: Mina

Patrocinador: Óscar Ramírez

Gerente de proyecto: Jorge Medina

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2025-10-05

Objetivo del negocio

Entregar programa de relacionamiento comunitario para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Inversiones el 2025-10-05.

Fechas comprometidas

Fecha

Inicio

2025-10-15

Cierre

2026-08-29

Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

Dependencias declaradas

• Ninguna declarada
