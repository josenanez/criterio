<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-10-15
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, María Restrepo, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-12-02 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-12-19 |
| Elena Duarte | Revisar el anexo 3 | 2026-12-08 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-11-06 |
| Sandra Gil | Enviar el documento 9 | 2026-10-01 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| Andrés Lozano | Actualizar la matriz 14 | por definir |
| Carlos Peña | Confirmar la fecha 15 | 2026-11-03 |
| Felipe Arango | Entregar el punto 16 | 2026-10-12 |
| Andrés Lozano | Enviar el documento 17 | por definir |
| Rubén Cárdenas | Cerrar la prueba 18 | 2026-10-30 |
| Carlos Peña | Revisar el anexo 19 | 2026-10-23 |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-21 |
| Javier Hoyos | Aprobar el diseño 21 | por definir |
| María Restrepo | Actualizar la matriz 22 | 2026-10-29 |
| Camilo Beltrán | Confirmar la fecha 23 | 2026-11-07 |
| Paula Céspedes | Entregar el punto 24 | 2026-10-23 |
