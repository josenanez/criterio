<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-01-07-acta-recibo-ct-326-bolsa-de-horas-de-ingeniería.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de ingeniería
Proyecto: PRY-200 · Mantenimiento predictivo de camiones
Fecha de recibo: 2026-01-07
Recibido por: Carlos Peña
Se recibe a satisfacción el entregable Bolsa de horas de ingeniería.
Contrato CT-326 · Equipos Pesados Andinos.
