<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-02-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-07-07 | 2026-07-07 | cerrado
Ingeniería de detalle aprobada | 2026-11-28 | 2026-11-28 | en curso
Licencia y permisos obtenidos | 2027-04-21 | 2027-04-21 | en curso
