<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-21-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-21
**Gerente:** Diana Molina

## Estado declarado

**Verde**

Avance reportado: **67%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se levantó un hallazgo en la auditoría de seguridad
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 16.735.307.598 |
| Ejecutado | 6.108.769.631 |
| Proyección al cierre | 18.209.304.767 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
