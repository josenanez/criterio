import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-205-sistema-de-gestión-de-seguridad/"
ACTA = P + "00-gobierno/2025-11-19-acta-constitucion.md"
INF = P + "20-seguimiento/2026-10-19-informe-avance.pdf"
CC1 = P + "20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md"
CC2 = P + "20-seguimiento/2026-10-16-solicitud-cambio-cc-02.md"

ident = {
    "code": F("PRY-205", ACTA), "name": F("Sistema de gestión de seguridad", ACTA), "aliases": [],
    "business_area": F("Mina", ACTA), "product": F(None), "authority": F(None),
    "sponsor": F("Camilo Beltrán", ACTA), "manager": F("Óscar Ramírez", INF),
    "committee": F("Comité de Operaciones", ACTA), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(43, INF), "as_of": D("2026-10-19", INF), "source": INF}
plan = {
    "start_date": F("2025-11-29", ACTA), "end_date": F("2026-08-12", ACTA),
    "baseline": [{"version": 1, "approved_on": "2025-11-19", "start_date": "2025-11-29", "end_date": "2026-08-12",
                  "baseline_end_date": "2026-08-12", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [],
    "scope_summary": F("Entregar sistema de gestión de seguridad para Mina (tres componentes sin detallar; CC-01 y CC-02 pendientes lo amplían)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(6800000000, INF), "committed": F(4948969722, INF),
         "executed": F(1257515457, INF), "projection": F(6802912497, INF)}
raid = {"risks": [{"what": "Concentración del conocimiento en una sola persona", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [], "issues": [], "dependencies": []}
cc = lambda ref, d, t, c, src: {"ref": ref, "requested_on": d, "scope_impact": "Ampliación de alcance", "time_impact": t,
                                "cost_impact": c, "decision": "pending", "decided_by": None, "source": src}
changes = [cc("CC-01", "2026-10-09", "+85 días sobre la línea base vigente", "170.000.000 COP adicionales", CC1),
           cc("CC-02", "2026-10-16", "+46 días sobre la línea base vigente", "92.000.000 COP adicionales", CC2)]
build("PRY-205", ident, declared, plan, money, [], raid, changes, [])
