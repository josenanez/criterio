<!-- origen: PRY-204-monitoreo-de-taludes/2026-10-22-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión monitoreo de taludes — 2026-10-22
estuvieron: Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Andrés Lozano dice que lo de «cerrar la prueba 2» no alcanzó, se compromete para el 02/01/2027
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
