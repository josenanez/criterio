<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2026-10-22-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-08-17 | 2026-08-17 | 2026-08-17 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-10-22 | 2026-10-22 | 2026-10-22 | 50% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2026-12-28 | 2026-12-28 | 2026-12-28 | 50% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2027-04-28 | 2027-04-28 | 2027-03-04 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-08-17 | 2026-08-17 | cerrado |
| Ingeniería de detalle aprobada | 2026-10-22 | 2026-10-22 | en curso |
| Licencia y permisos obtenidos | 2026-12-28 | 2026-12-28 | en curso |
| Montaje e instalación | 2027-03-04 | 2027-04-28 | en curso |
