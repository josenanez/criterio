<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2025-10-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-01-02 | 2026-01-02 | cerrado
Ingeniería de detalle aprobada | 2026-03-23 | 2026-03-23 | cerrado
Licencia y permisos obtenidos | 2026-06-10 | 2026-06-10 | cerrado
Montaje e instalación | 2026-08-29 | 2026-08-29 | cerrado
