<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Red privada LTE en mina
**Fecha:** 2026-10-15
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +102 días sobre la línea base vigente |
| Costo | 204.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
