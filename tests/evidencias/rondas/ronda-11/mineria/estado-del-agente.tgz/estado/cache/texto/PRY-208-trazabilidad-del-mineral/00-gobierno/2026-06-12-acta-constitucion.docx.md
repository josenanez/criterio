<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2026-06-12-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Seguridad y Salud

Patrocinador: Natalia Ospina

Gerente de proyecto: Paula Céspedes

Comité: Comité Ambiental

Producto asociado: trazabilidad

Fecha de aprobación: 2026-06-12

Objetivo del negocio

Entregar trazabilidad del mineral para Seguridad y Salud.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Ambiental el 2026-06-12.

Fechas comprometidas

Fecha

Inicio

2026-06-22

Cierre

2027-12-11

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
