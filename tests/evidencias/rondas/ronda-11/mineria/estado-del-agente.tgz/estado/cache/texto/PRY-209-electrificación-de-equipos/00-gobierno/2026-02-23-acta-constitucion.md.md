<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2026-02-23-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Geología
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-23

## Objetivo del negocio

Entregar electrificación de equipos para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité Ambiental el 2026-02-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-05 |
| Cierre | 2026-12-03 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
