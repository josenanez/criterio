import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-203-despacho-automático-de-flota/"
ACTA = P + "00-gobierno/2025-07-03-acta-constitucion.md"
INF = P + "20-seguimiento/2026-10-12-informe-avance.pdf"

ident = {
    "code": F("PRY-203", ACTA), "name": F("Despacho automático de flota", ACTA), "aliases": [],
    "business_area": F("Tecnología", ACTA), "product": F("despacho de flota", ACTA), "authority": F(None),
    "sponsor": F("Carlos Peña", ACTA), "manager": F("Javier Hoyos", INF),
    "committee": F("Comité de Operaciones", ACTA), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(38, INF), "as_of": D("2026-10-12", INF), "source": INF}
plan = {
    "start_date": F("2025-07-13", ACTA), "end_date": F("2026-04-13", ACTA),
    "baseline": [{"version": 1, "approved_on": "2025-07-03", "start_date": "2025-07-13", "end_date": "2026-04-13",
                  "baseline_end_date": "2026-04-13", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [],
    "scope_summary": F("Entregar despacho automático de flota para Tecnología (tres componentes sin detallar)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(6800000000, INF), "committed": F(3597010251, INF),
         "executed": F(2894328076, INF), "projection": F(8503714527, INF)}
raid = {"risks": [{"what": "Cambio en la licencia ambiental que puede mover el alcance", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [],
        "issues": [{"what": "Se levantó un hallazgo en la auditoría de seguridad", "since": None, "owner": None, "source": INF}],
        "dependencies": []}
build("PRY-203", ident, declared, plan, money, [], raid, [], [])
