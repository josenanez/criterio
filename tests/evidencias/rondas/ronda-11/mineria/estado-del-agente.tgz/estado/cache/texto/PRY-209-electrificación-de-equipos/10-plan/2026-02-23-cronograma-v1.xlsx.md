<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2026-02-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-04-28 | 2026-04-28 | cerrado
Ingeniería de detalle aprobada | 2026-06-22 | 2026-06-22 | cerrado
Licencia y permisos obtenidos | 2026-08-16 | 2026-08-16 | cerrado
Montaje e instalación | 2026-10-09 | 2026-10-09 | en curso
Pruebas en operación | 2026-12-03 | 2026-12-03 | en curso
