<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-09-24
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Elena Duarte, Javier Hoyos, Jorge Medina, María Restrepo, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-10-11 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-29 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-14 |
| Javier Hoyos | Aprobar el diseño 5 | 2026-10-11 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-15 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-11 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 |
| Sandra Gil | Enviar el documento 9 | 2026-10-01 |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-09 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| María Restrepo | Validar el ambiente 12 | 2026-10-09 |
