<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-15
Gerente: Jorge Medina

Estado declarado
Amarillo
Avance reportado: 76%

Lo que pasó en el periodo
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 12.381.554.857
Ejecutado 6.740.699.703
Proyección al cierre 17.670.441.375

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
