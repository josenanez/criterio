import json, re, os

ROOT = "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/records"


def sd(src):
    if not src:
        return None
    m = re.search(r"(\d{4}-\d{2}-\d{2})", os.path.basename(src))
    return m.group(1) if m else None


def F(value, src=None, date=None, state=None, kind=None, conflict=None):
    if value is None:
        return {"value": None, "source": None, "source_date": None, "state": "not_found"}
    d = {"value": value, "source": src, "source_date": date or sd(src),
         "state": state or "found"}
    if kind:
        d["source_kind"] = kind
    if conflict:
        d["conflict"] = conflict
    return d


def D(value, src, date=None):
    return F(value, src, date, kind="declaration")


def build(code, ident, declared, plan, money, vendors, raid, changes, commitments, extra=None):
    rec = {"schema_version": "0.2", "identity": ident, "declared": declared, "plan": plan,
           "money": money, "vendors": vendors, "raid": raid, "changes": changes,
           "commitments": commitments}
    if extra:
        rec.update(extra)
    nf, oc = [], []

    def walk(o, p):
        if isinstance(o, dict):
            if "state" in o and "source" in o and "value" in o:
                if o["state"] == "not_found":
                    nf.append(p)
                elif o["state"] == "ambiguous":
                    oc.append(p)
                return
            for k, v in o.items():
                walk(v, p + "." + k if p else k)
    for sec in ("identity", "declared", "plan", "money"):
        walk(rec[sec], sec)
    rec["meta"] = {"record_updated": "2026-10-23", "fields_not_found": nf,
                   "open_conflicts": oc, "documents_seen": []}
    with open(os.path.join(ROOT, code + ".json"), "w") as fh:
        json.dump(rec, fh, ensure_ascii=False, indent=2)
    print(code, "escrita; not_found:", len(nf), "ambiguos:", len(oc))
