import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-199-cambio-de-luminarias-del-campamento/"
ACTA = P + "00-gobierno/2026-06-14-acta-constitucion.md"
CRON = P + "10-plan/2026-06-14-cronograma-v1.xlsx"
CT = P + "00-gobierno/2026-06-14-contrato-ct-199.docx"
INF = P + "20-seguimiento/2026-10-20-informe-avance.pdf"
COM = P + "30-reuniones/2026-10-18-comite-semanal.md"
REC = P + "20-seguimiento/2026-10-14-acta-recibo-ingeniería-básica-aprobada.md"

ident = {
    "code": F("PRY-199", ACTA), "name": F("Cambio de luminarias del campamento", ACTA), "aliases": [],
    "business_area": F("Mina", ACTA), "product": F("PRD-299", ACTA), "authority": F(None),
    "sponsor": F("María Restrepo", ACTA), "manager": F("Andrés Lozano", INF),
    "committee": F("Comité de Inversiones", COM), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(20, INF), "as_of": D("2026-10-20", INF), "source": INF}
ms = lambda n, b, c, st, ev="": {"name": n, "baseline_date": b, "current_date": c, "state": st, "evidence": ev, "source": CRON}
plan = {
    "start_date": F("2026-06-24", ACTA), "end_date": F("2027-12-21", CRON),
    "baseline": [{"version": 1, "approved_on": "2026-06-14", "start_date": "2026-06-24", "end_date": "2027-12-21",
                  "baseline_end_date": "2027-12-21", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2026-10-11", "2026-10-11", "met", REC),
        ms("Ingeniería de detalle aprobada", "2027-01-28", "2027-01-28", "pending"),
        ms("Licencia y permisos obtenidos", "2027-05-17", "2027-05-17", "pending"),
        ms("Montaje e instalación", "2027-09-03", "2027-09-03", "pending"),
        ms("Pruebas en operación", "2027-12-21", "2027-12-21", "pending"),
    ],
    "scope_summary": F("Entregar cambio de luminarias del campamento para Mina (tres componentes sin detallar)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(2400000000, INF), "committed": F(1080000000, INF),
         "executed": F(720000000, INF), "projection": F(2400000000, INF)}
dl = lambda n, d: {"name": n, "due_date": d, "amount": 144000000, "state": "pending", "evidence": ""}
vendors = [{"name": "Ingeniería Minera del Sur S.A.S.", "contract_ref": "CT-199",
            "deliverables": [dl("Licenciamiento del software", "2026-11-21"), dl("Bolsa de horas de ingeniería", "2027-04-20"),
                             dl("Calibración de sensores", "2027-09-17")],
            "invoiced": F(None), "source": CT}]
raid = {"risks": [{"what": "Concentración del conocimiento en una sola persona", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [],
        "issues": [{"what": "Las lluvias detuvieron el montaje durante diez días (el cronograma ubica el montaje en 2027-09-03)",
                    "since": None, "owner": None, "source": INF}],
        "dependencies": []}
commitments = [{"who": "Carlos Peña", "what": "Presentar el cierre de la fase", "due_date": "2026-11-11",
                "original_due_date": "2026-11-11", "stated_on": "2026-10-18", "source": COM, "state": "open", "reschedules": []}]
build("PRY-199", ident, declared, plan, money, vendors, raid, [], commitments)
