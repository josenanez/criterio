import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/mineria/espacio/estado/cache")
from fb import *

P = "PRY-200-mantenimiento-predictivo-de-camiones/"
ACTA = P + "00-gobierno/2025-09-14-acta-constitucion.md"
CRON = P + "10-plan/2025-09-14-cronograma-v1.csv"
CT = P + "00-gobierno/2025-09-04-contrato-ct-326.docx"
INF = P + "20-seguimiento/2026-10-18-informe-avance.pdf"
COM = P + "30-reuniones/2026-10-19-comite-semanal.docx"
FAC = P + "20-seguimiento/2026-09-02-factura-ct-326.pdf"
R_BOLSA = P + "20-seguimiento/2026-01-07-acta-recibo-ct-326-bolsa-de-horas-de-ingeniería.pdf"
R_PRUEBAS = P + "20-seguimiento/2026-10-11-acta-recibo-pruebas-en-operación.pdf"
R_MONTAJE = P + "20-seguimiento/2026-10-21-acta-recibo-montaje-e-instalación.md"

ident = {
    "code": F("PRY-200", ACTA), "name": F("Mantenimiento predictivo de camiones", ACTA), "aliases": [],
    "business_area": F("Mina", ACTA), "product": F("monitoreo de flota", ACTA), "authority": F(None),
    "sponsor": F("Andrés Lozano", ACTA), "manager": F("Carlos Peña", INF),
    "committee": F("Comité de Operaciones", COM), "phase": F(None),
}
declared = {"status": D("verde", INF), "progress_pct": D(77, INF), "as_of": D("2026-10-18", INF), "source": INF}
ms = lambda n, b, ev="": {"name": n, "baseline_date": b, "current_date": b, "state": "met", "evidence": ev, "source": CRON}
plan = {
    "start_date": F("2025-09-24", ACTA), "end_date": F("2026-04-06", CRON),
    "baseline": [{"version": 1, "approved_on": "2025-09-14", "start_date": "2025-09-24", "end_date": "2026-04-06",
                  "baseline_end_date": "2026-04-06", "source": ACTA, "reason": "Línea base original del acta de constitución"}],
    "milestones": [
        ms("Ingeniería básica aprobada", "2025-11-01"),
        ms("Ingeniería de detalle aprobada", "2025-12-10"),
        ms("Licencia y permisos obtenidos", "2026-01-18"),
        ms("Montaje e instalación", "2026-02-26", R_MONTAJE),
        ms("Pruebas en operación", "2026-04-06", R_PRUEBAS),
    ],
    "scope_summary": F("Entregar mantenimiento predictivo de camiones para Mina (tres componentes sin detallar)", ACTA),
    "exclusions": F("Lo que otro proyecto cubre", ACTA),
}
money = {"currency": "COP", "approved": F(2400000000, INF), "committed": F(1356662777, INF),
         "executed": F(446036134, INF), "projection": F(2479870475, INF)}
dl = lambda n, d, st, ev="": {"name": n, "due_date": d, "amount": 275896256, "state": st, "evidence": ev}
vendors = [{"name": "Equipos Pesados Andinos", "contract_ref": "CT-326",
            "deliverables": [dl("Licenciamiento del software", "2025-11-05", "pending"),
                             dl("Bolsa de horas de ingeniería", "2025-12-18", "accepted", R_BOLSA),
                             dl("Calibración de sensores", "2026-01-30", "accepted"),
                             dl("Soporte del primer trimestre", "2026-03-14", "pending")],
            "invoiced": F(551792512, FAC), "source": CT}]
raid = {"risks": [{"what": "El proveedor no ha confirmado la fecha de la última entrega", "probability": None, "impact": None,
                   "owner": None, "due_date": None, "last_moved": None, "source": INF}],
        "assumptions": [],
        "issues": [{"what": "Se levantó un hallazgo en la auditoría de seguridad", "since": None, "owner": None, "source": INF}],
        "dependencies": []}
commitments = [
    {"who": "Liliana Torres", "what": "Entregar el punto 4", "due_date": "2026-10-23", "original_due_date": "2026-10-23",
     "stated_on": "2026-10-19", "source": COM, "state": "open", "reschedules": []},
    {"who": "Beatriz Cuéllar", "what": "Entregar el punto 33", "due_date": "no_declarada", "original_due_date": "no_declarada",
     "stated_on": "2026-10-19", "source": COM, "state": "open", "reschedules": []},
]
build("PRY-200", ident, declared, plan, money, vendors, raid, [], commitments)
