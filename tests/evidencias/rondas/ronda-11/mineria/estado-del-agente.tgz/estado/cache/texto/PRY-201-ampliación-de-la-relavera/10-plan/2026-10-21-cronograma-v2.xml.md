<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-10-21-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-07-07 | 2026-07-07 | 2026-07-07 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-11-28 | 2026-11-28 | 2026-11-28 | 50% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2027-06-21 | 2027-06-21 | 2027-04-21 | 50% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-07-07 | 2026-07-07 | cerrado |
| Ingeniería de detalle aprobada | 2026-11-28 | 2026-11-28 | en curso |
| Licencia y permisos obtenidos | 2027-04-21 | 2027-06-21 | en curso |
