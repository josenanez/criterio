<!-- origen: PRY-208-trazabilidad-del-mineral/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Trazabilidad del mineral

**Fecha:** 2026-10-11
**Asistentes:** Paula Céspedes, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 25 | 2026-11-07 |
