<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-22
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 56%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Las lluvias detuvieron el montaje durante diez días
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.153.096.035
Ejecutado 1.712.834.466
Proyección al cierre 7.057.069.997

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
