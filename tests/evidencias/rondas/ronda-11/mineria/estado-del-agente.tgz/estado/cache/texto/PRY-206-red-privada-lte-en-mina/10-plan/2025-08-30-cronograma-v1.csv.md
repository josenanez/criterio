<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2025-08-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-12-15,2025-12-15,cerrado
Ingeniería de detalle aprobada,2026-03-22,2026-03-22,cerrado
Licencia y permisos obtenidos,2026-06-27,2026-06-27,cerrado
