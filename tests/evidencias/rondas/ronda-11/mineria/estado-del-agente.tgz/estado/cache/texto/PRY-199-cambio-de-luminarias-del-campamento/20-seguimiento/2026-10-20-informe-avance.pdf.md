<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cambio de luminarias del campamento
Código: PRY-199
Fecha de corte: 2026-10-20
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días
- Se acordó con operaciones el plan de arranque de los equipos
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- Concentración del conocimiento en una sola persona
