<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2026-06-19-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Ingeniería básica aprobada | 2026-09-05 | 2026-09-05 | 2026-09-05 | 100% | hito | — | — |
| 2 | 2 | Ingeniería de detalle aprobada | 2026-11-12 | 2026-11-12 | 2026-11-12 | 50% | hito | 1FS | — |
| 3 | 3 | Licencia y permisos obtenidos | 2027-01-19 | 2027-01-19 | 2027-01-19 | 50% | hito | 2FS | — |
| 4 | 4 | Montaje e instalación | 2027-03-28 | 2027-03-28 | 2027-03-28 | 50% | hito | 3FS | — |
| 5 | 5 | Pruebas en operación | 2027-06-04 | 2027-06-04 | 2027-06-04 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Ingeniería básica aprobada | 2026-09-05 | 2026-09-05 | cerrado |
| Ingeniería de detalle aprobada | 2026-11-12 | 2026-11-12 | en curso |
| Licencia y permisos obtenidos | 2027-01-19 | 2027-01-19 | en curso |
| Montaje e instalación | 2027-03-28 | 2027-03-28 | en curso |
| Pruebas en operación | 2027-06-04 | 2027-06-04 | en curso |
