<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Mantenimiento predictivo de camiones
Código: PRY-200
Fecha de corte: 2026-10-18
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 77%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.356.662.777
Ejecutado 446.036.134
Proyección al cierre 2.479.870.475

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
