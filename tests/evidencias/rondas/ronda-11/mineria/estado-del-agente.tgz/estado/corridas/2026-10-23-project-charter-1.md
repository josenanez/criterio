# Corrida del 2026-10-23 · project-charter

13 proyectos · 30 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Revisión del acta de PRY-205 (2025-11-19): sin autoridad del gerente, supuestos, restricciones, hitos ni cadencia; objetivo, alcance y exclusiones son marcadores vacíos. No se supo si existe delegación verbal fuera de los documentos.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Términos: vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hubo que registrar nada nuevo.

## Acta — PRY-205 · Sistema de gestión de seguridad
**Estado:** existe, del 2025-11-19 (`PRY-205-…/00-gobierno/2025-11-19-acta-constitucion.md`). Modo revisar.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** (la ficha lo marca `not_found`) | Nada dice hasta qué monto ni qué cambio de alcance puede decidir Óscar Ramírez sin comité. Hoy CC-01 (+170.000.000 COP, +85 días) y CC-02 (+92.000.000 COP, +46 días) están "pendientes de presentación al comité" desde el 2026-10-09 y el 2026-10-16: todo sube al comité porque no hay umbral. Juntos suman 262.000.000 COP y +131 días. |
| Objetivo de negocio | Presente pero es la solución: "Entregar sistema de gestión de seguridad para Mina" | No hay resultado de negocio que el proyecto deba mover (incidentes, cumplimiento, etc.). No se puede juzgar si las ampliaciones de alcance lo sirven. |
| Alcance | Marcador vacío: "Componente 1, 2, 3" | No hay alcance contra el cual medir que CC-01 y CC-02 sean realmente "ampliación". Cualquier cambio queda sin referencia. |
| Exclusiones | Marcador vacío: "Lo que otro proyecto cubre" | No nombra qué proyecto ni qué. No protege contra solapes ni contra que las ampliaciones absorban trabajo ajeno. |
| Patrocinador | Presente: Camilo Beltrán | — |
| Supuestos y restricciones | **No están** | Nada declarado que verificar; los riesgos solo aparecen en el informe de avance (concentración del conocimiento en una persona, sin dueño ni fecha). |
| Dependencias | "Ninguna declarada" | Se afirma sin sustento; un sistema de seguridad para Mina rara vez no depende de operaciones. El informe del 2026-10-19 menciona un plan de arranque acordado con operaciones. |
| Criterio de éxito | Parcial: "en producción y medido" | No dice qué se mide, con qué meta ni quién lo mide. |
| Hitos principales | **No están** (la ficha tiene `milestones` vacío) | Con 43% de avance declarado no hay con qué verificarlo. |
| Comité y cadencia | Comité de Operaciones; cadencia no declarada | Sin cadencia, nada obliga a que CC-01 y CC-02 se traten en una fecha. |
| Vigencia de fechas | Cierre comprometido 2026-08-12, ya vencido (72 días al 2026-10-23); no hay línea base nueva aprobada | El informe del 2026-10-19 dice "verde" con 43% y la fecha de cierre ya pasó. El acta no basta para sostener ese verde; es asunto de control de cambios y de `/health-check`. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe la solución).
**Alcance:** pendiente de definir (acta: tres "componentes" sin nombre). Fuente: acta 2025-11-19.
**Exclusiones:** pendiente de definir (acta: "Lo que otro proyecto cubre", sin proyecto ni tema).
**Patrocinador:** Camilo Beltrán · **Gerente:** Óscar Ramírez (acta 2025-11-19; informe 2026-10-19).
**Autoridad del gerente:** pendiente de definir. No hay fuente.
**Comité al que reporta:** Comité de Operaciones (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Sistema de gestión de seguridad en producción y medido" (acta); métrica y meta pendientes · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir.
**Presupuesto aprobado:** 6.800.000.000 COP, Comité de Operaciones, 2025-11-19 (acta). Fechas: inicio 2025-11-29, cierre 2026-08-12.

### Después
- El acta quedó sin autoridad declarada. Ofrezco llevar esa definición al comité (`/steering-pack`): es una decisión, no un trámite, y destraba CC-01 y CC-02.
- Del acta y del informe salen supuestos y riesgos sin dueño (concentración del conocimiento, dependencia con operaciones). Ofrezco pasarlos al registro RAID (`/raid-log`).

**Pie de rigor:** esto es un borrador de trabajo basado en cuatro documentos de la carpeta del proyecto (acta, CC-01, CC-02 e informe de avance). No sé qué se habló fuera de ellos; puede haber un acta ampliada o una delegación verbal que no aparece aquí. Verifique cada dato contra la fuente citada.
