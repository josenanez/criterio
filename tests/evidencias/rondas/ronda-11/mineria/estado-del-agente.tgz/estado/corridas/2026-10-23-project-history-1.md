# Corrida del 2026-10-23 · project-history

13 proyectos · 76 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Historia de PRY-209 sobre 11 documentos (2026-02-23 a 2026-10-22): 1 replanificación, 211 días de atraso vs original (77,3 %), 96 días sin autorización. No se pudo calcular meses declarando sin sustento (una sola declaración); sin minutas, sin acta de comité de CC-02, sin cronograma v2.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Historia · PRY-209 Electrificación de equipos · 2026-02-23 a 2026-10-22

**Leí:** 11 documentos entre 2026-02-23 y 2026-10-22 (acta de constitución, 2 contratos, cronograma v1 y v3, 2 facturas, 2 solicitudes de cambio, 1 acta de recibo, 1 informe de avance). Las cifras derivadas salen de `compute` con corte 2026-10-23.
**Trimestres sin un solo documento:** ninguno completo. Pero **no hay ningún documento entre 2026-03-04 (contrato CT-611) y 2026-09-09 (factura CT-576)**: abril, mayo, junio, julio y agosto están en silencio. En ese hueco vencían la Ingeniería básica (2026-04-28), la Ingeniería de detalle (2026-06-22) y la Licencia y permisos (2026-08-16).

*Términos: ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez); no hubo que registrar nada nuevo.*

### En una línea
El proyecto se aprobó el 2026-02-23 con cierre el 2026-12-03 y 800.000.000 COP. Durante cinco meses la carpeta no contiene nada; en septiembre aparecen dos facturas sin actas de recibo y en octubre, entre el 10-14 y el 10-22, aparecen dos solicitudes de cambio, un acta de recibo, un cronograma v3 que mueve el cierre al 2027-07-02 y un informe de avance en verde con 70 %. De los 211 días que se movió la fecha de cierre, el comité autorizó 115 (CC-02); los otros 96 corresponden a CC-01, que sigue «pendiente de presentación al comité».

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 211 días (77,3 %): cierre 2026-12-03 → 2027-07-02 | No se puede calcular: hay una sola declaración (2026-10-22) | 0 visibles (no hay minutas ni actas de comité que lo confirmen o lo descarten) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-02-23 | `00-gobierno/2026-02-23-acta-constitucion.md` | Se aprueba el proyecto: patrocinadora Beatriz Cuéllar, gerente Sandra Gil, Comité Ambiental; 800.000.000 COP; inicio 2026-03-05, cierre 2026-12-03. |
| 2026-02-23 | `10-plan/2026-02-23-cronograma-v1.xlsx` | Línea base de cinco hitos. Ojo: el archivo, fechado en febrero, ya marca como «cerrado» los hitos previstos para abril, junio y agosto; su contenido se escribió o editó después de la fecha del nombre. |
| 2026-02-27 | `00-gobierno/2026-02-27-contrato-ct-576.docx` | Contrato con Servicios Ambientales del Norte: 4 entregables de 69.149.721 COP. Se factura contra acta de recibo firmada por el gerente. |
| 2026-03-04 | `00-gobierno/2026-03-04-contrato-ct-611.md` | Contrato con Equipos Pesados Andinos: 3 entregables de 32.663.188 COP. Mismo requisito de acta. Ya marca «Licenciamiento del software» como «recibido» (previsto 2026-05-19). |
| — | *(sin documentos de 2026-03-05 a 2026-09-08)* | Vencen 3 hitos y 5 entregables de proveedor sin rastro documental. |
| 2026-09-09 | `20-seguimiento/2026-09-09-factura-ct-576.pdf` | FV-1576 por 69.149.721 COP, radicada. No existe acta de recibo de CT-576. |
| 2026-09-28 | `20-seguimiento/2026-09-28-factura-ct-611.pdf` | FV-2611 por 48.285.164 COP, radicada. Los entregables aceptados de CT-611 suman 32.663.188 COP. |
| 2026-10-14 | `20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +96 días, +192.000.000 COP. Autorización: «Pendiente de presentación al comité». |
| 2026-10-19 | `20-seguimiento/2026-10-19-solicitud-cambio-cc-02.md` | CC-02: ampliación de alcance, +115 días, +230.000.000 COP. «Autorizada por el comité» (el acta del comité no está en la carpeta). |
| 2026-10-22 | `20-seguimiento/2026-10-22-acta-recibo-licencia-y-permisos-obtenidos.md` | Primera acta de recibo de toda la carpeta. Recibe «Licencia y permisos obtenidos», hito previsto para 2026-08-16. |
| 2026-10-22 | `10-plan/2026-10-22-cronograma-v3.xml` | «Pruebas en operación» pasa de 2026-12-03 a 2027-07-02; la línea base original se conserva en su columna. |
| 2026-10-22 | `20-seguimiento/2026-10-22-informe-avance.pdf` | Estado declarado: verde, 70 %. Proyección al cierre 926.517.799 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-22 | 2027-07-02 (original 2026-12-03) | **Ninguno en el cronograma v3.** CC-01 y CC-02 son de «ampliación de alcance» y suman 96 + 115 = 211 días, que es lo que se movió la fecha, pero ningún documento vincula una con la otra. | Solo respalda 115 de los 211 días: CC-02 («autorizada por el comité», sin acta del comité en la carpeta). Los 96 restantes son de CC-01, sin autorización. |

No hay cronograma v2 en la carpeta (se pasa de v1 a v3). Si existió una replanificación intermedia, esta carpeta no la muestra.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Nada visible. Patrocinadora, gerente y comité son los mismos en el acta (2026-02-23) y en las solicitudes de cambio (octubre). | — |

Sin minutas ni correos no se puede saber si hubo cambios que no quedaron escritos. Además, el acta no declara hasta dónde llega la autoridad de la gerente para mover fechas.

### Compromisos que se repitieron
No hay minutas ni notas de reunión en la carpeta, así que no hay compromisos que rastrear ni se puede decir que alguno se repitiera. Lo más cercano son las fechas de proveedor que vencieron sin cambio de fecha: Licenciamiento del software de CT-576 (2026-05-04), Bolsa de horas de CT-576 (2026-07-03), Bolsa de horas de CT-611 (2026-08-02) y Calibración de sensores de CT-576 (2026-09-01) y CT-611 (2026-10-16). Todas siguen «pendiente» o «en curso» en el contrato.

### Desde cuándo lo declarado no se sostiene
- **Primer punto sin sustento: 2026-04-28.** «Ingeniería básica aprobada» figura «cerrado» (cronograma v1 y v3, 100 %) y no hay acta ni documento que lo muestre. Lo mismo con «Ingeniería de detalle aprobada» (2026-06-22).
- **Montaje e instalación** estaba previsto para 2026-10-09, sigue «en curso» al 50 % y venció sin replanificar en el cronograma v3 (solo se movió el último hito).
- **Lo que se siguió reportando:** el informe del 2026-10-22 declara verde y 70 %, sin mencionar el hito vencido, los entregables vencidos, el exceso proyectado (926.517.799 contra 800.000.000 COP aprobados, 15,8 %) ni los 96 días sin autorizar. Su sección «Lo que pasó en el periodo» habla de un plan de arranque.
- **Lo que esta carpeta no deja medir:** cuántos meses se declaró sin sustento. Hay una sola declaración, y sin la serie anterior no se puede ubicar el deslizamiento. Lo que sí se ve es el silencio de marzo a septiembre, que no es lo mismo que haber declarado sin sustento.
- **Pagos:** las facturas de septiembre se radicaron sin acta de recibo, que el contrato exige para facturar. CT-576: 69.149.721 COP facturados, 0 aceptado con evidencia. CT-611: 48.285.164 facturados contra 32.663.188 aceptados, una diferencia de 15.621.976 COP; y ese aceptado (Licenciamiento) tampoco tiene acta.

### Lecciones ancladas a un hecho
1. **Facturar sin acta.** Hecho: FV-1576 radicada el 2026-09-09 y FV-2611 el 2026-09-28; la primera acta de recibo de la carpeta es del 2026-10-22 y es de otro entregable. Efecto: dos facturas (69.149.721 y 48.285.164 COP) sin el acta que el contrato exige; en CT-611, 15.621.976 COP por encima de lo aceptado.
2. **Mover la línea base por encima de lo autorizado.** Hecho: el cronograma v3 del 2026-10-22 mueve el cierre 211 días mientras CC-02 autoriza 115 y CC-01 (96) sigue sin presentarse al comité. Efecto: 96 días de la fecha vigente sin autoridad que los respalde.
3. **Hitos cerrados sin acta.** Hecho: Ingeniería básica (2026-04-28) e Ingeniería de detalle (2026-06-22) figuran cerradas y no hay documento que lo muestre. Efecto: el 70 % del informe se apoya en dos hitos que no se pueden verificar.
4. **Hueco documental de cinco meses.** Hecho: ningún documento entre 2026-03-04 y 2026-09-09, con tres hitos previstos en medio. Efecto: lo que ocurrió en esos meses solo se conoce por el estado que alguien anotó después.

**Qué no sé:** si la CC-01 se presentó al comité; qué decidió el comité sobre la CC-02 (no está su acta); por qué se pidieron dos ampliaciones de alcance entre el 10-14 y el 10-19 y cuál es el alcance (el acta lo define como «Componente 1, 2 y 3»); si existió un cronograma v2; si las facturas ya se pagaron. Tampoco atribuyo intención: que el atraso apareciera en un solo cronograma en octubre no dice que alguien lo ocultara.

**Siguiente paso posible:** llevar esta historia al comité del 2026-10-29 como apoyo a una decisión sobre CC-01 y sobre el pago de las facturas, o llevarla al cierre del proyecto cuando llegue. Quién lo decide es una persona.

*Pie de rigor: esta historia es un borrador de trabajo, no una decisión ni una asesoría. Se basa solo en los 11 documentos leídos y no sabe lo que se habló fuera de ellos. Cada dato está citado al documento de donde sale. Verificarlo es responsabilidad de quien lo use. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
