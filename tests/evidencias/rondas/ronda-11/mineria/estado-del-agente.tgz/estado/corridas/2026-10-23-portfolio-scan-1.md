# Corrida del 2026-10-23 · portfolio-scan

13 proyectos · 93 documentos, 0 releídos y 93 sin cambio · 418 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Leídos 69 de 93 documentos en 10 proyectos (PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210); PRY-202, 209 y 211 sin cambio. Nada movido: no existe entrada/. Ningún archivo ilegible (los 9 xml se convirtieron). Mirar: hitos cerrados sin acta (PRY-206, 210, 200), cronograma v2 con CC-01 sin decisión (PRY-204, 208), facturas sin acta (PRY-204, 208, 200), compromisos vencidos y reprogramados en PRY-204.

Contra la corrida del 2026-10-23: +54 hallazgos.

## Lo que produjo

## Barrido — 2026-10-23

Términos de la versión 0.8.0 vigentes (aceptados por José Francisco Ñáñez, 2026-10-23). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita de su documento y la verificación es de quien lo usa. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Qué encontré:** 93 documentos en 13 carpetas de proyecto (PRY-199 a PRY-211): 40 `.md`, 20 `.pdf`, 13 `.docx`, 9 `.xml`, 5 `.xlsx`, 4 `.csv`, 1 `.json` y 1 `.txt`. El plan de lectura pidió leer 69 de 93 y dejó 24 sin tocar por no haber cambiado (los de PRY-202, PRY-209 y PRY-211, que ya tenían ficha).

**Documentos:** 93 en la carpeta · 69 leídos · 24 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, declarado, plan, 5 hitos, dinero, 1 contrato (CT-199), RAID, 1 compromiso | autoridad, fase |
| PRY-200 Mantenimiento predictivo de camiones | 9 | ídem, 1 contrato (CT-326) con 1 factura, 2 compromisos | autoridad, fase |
| PRY-201 Ampliación de la relavera | 6 | ídem, 2 líneas base, CC-01, 1 compromiso | producto (el acta dice «No aplica»), autoridad, fase |
| PRY-203 Despacho automático de flota | 2 | acta e informe; sin cronograma | autoridad, fase |
| PRY-204 Monitoreo de taludes | 22 | ídem, 2 contratos (CT-950, CT-307) con 2 facturas, CC-01, 26 compromisos, `ficha-pm.json` íntegra en `pm_record` | autoridad, fase |
| PRY-205 Sistema de gestión de seguridad | 4 | acta, 2 solicitudes de cambio, informe; sin cronograma | producto («No aplica»), autoridad, fase |
| PRY-206 Red privada LTE en mina | 6 | ídem, 2 líneas base, CC-01, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-207 Gemelo digital de la planta | 3 | acta, cronograma, informe | autoridad, fase |
| PRY-208 Trazabilidad del mineral | 8 | ídem, 2 líneas base, 1 contrato (CT-644) con 1 factura, CC-01, 1 compromiso | autoridad, fase |
| PRY-210 Programa de relacionamiento comunitario | 3 | acta, cronograma, informe | producto («No aplica»), autoridad, fase |

Total: 24 campos en `not_found`. `identity.authority` e `identity.phase` no aparecen en ningún documento de ninguno de los 10 proyectos.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguna ficha previa se actualizó: PRY-202, PRY-209 y PRY-211 no tuvieron documentos nuevos ni cambiados y no se releyeron. | `plan-lectura` |

### Lo que hay que mirar
Hechos de los documentos, con su fuente; no son juicios sobre las personas.

**Hitos cerrados sin acta que lo pruebe** (el cronograma declara `cerrado`, no hay acta de recibo en la carpeta):
- PRY-206: los 3 hitos (`2025-08-30-cronograma-v1.csv`, `2026-10-22-cronograma-v2.xml`).
- PRY-210: los 4 hitos (`2025-10-05-cronograma-v1.xlsx`).
- PRY-200: 3 de 5 (ingeniería básica, ingeniería de detalle, licencia y permisos). Sí hay acta de Montaje e instalación (2026-10-21) y de Pruebas en operación (2026-10-11).
- PRY-201, PRY-207 y PRY-208: el hito de ingeniería básica está cerrado y no hay acta.
- Con acta: PRY-199 (ingeniería básica, 2026-10-14) y PRY-204 (sus 2 hitos cerrados, 2026-10-12 y 2026-10-19).

**Cierre comprometido ya pasado con el proyecto sin terminar y en verde/amarillo:** PRY-200 (cierre 2026-04-06, avance 77 %, verde), PRY-203 (2026-04-13, 38 %, verde, sin cronograma), PRY-205 (2026-08-12, 43 %, verde, sin cronograma), PRY-210 (2026-08-29, 76 %, amarillo). PRY-206 declara cierre vigente 2026-10-07 y 87 %.

**Cronograma v2 adoptado con la solicitud de cambio sin decisión:** PRY-204 (+84 días, CC-01 «pendiente de presentación al comité») y PRY-208 (+34 días, CC-01 pendiente). PRY-205 tiene dos solicitudes pendientes (CC-01 +85 días, CC-02 +46 días) y ningún cronograma.

**Cambios «autorizados por el comité» sin nombre ni acta que los cite:** PRY-201 (CC-01), PRY-206 (CC-01) y PRY-202 (CC-01, ya registrada). Las minutas del comité del 2026-10-16 (PRY-201) y del 2026-10-15 (PRY-206) no los mencionan. En PRY-206 el informe sigue mostrando presupuesto aprobado de 800.000.000 COP y la solicitud suma 204.000.000 COP adicionales.

**Proveedores, facturas y actas:**
- PRY-204: FV-2950 (CT-950, 861.859.911 COP, 2026-09-06) y FV-1307 (CT-307, 1.310.271.638 COP, 2026-09-04) están radicadas antes de la fecha comprometida del único entregable recibido (2026-10-01) y no hay acta de recibo del licenciamiento. El valor de FV-1307 es mayor que el de ese entregable (1.018.807.189 COP).
- PRY-208: FV-1644 (555.209.101 COP, 2026-09-24) está radicada con los tres entregables de CT-644 en `pendiente` (primer vencimiento 2026-11-16) y sin actas.
- PRY-200: FV-1326 (551.792.512 COP, 2026-09-02) cubre «Entregables del contrato CT-326» sin nombrarlos; el contrato marca dos como recibidos y solo hay acta de la bolsa de horas (2026-01-07), ninguna de la calibración de sensores.

**Proyección sobre lo aprobado:** PRY-203 declara proyección 8.503.714.527 COP contra 6.800.000.000 COP aprobados; PRY-204, 11.362.933.575 contra 9.500.000.000. (La comparación formal la calcula el script.)

**Compromisos (PRY-204, 26 en total: 3 cumplidos con acta, 8 vencidos, 15 abiertos):**
- «Cerrar la prueba 2» (Andrés Lozano) se reprogramó 6 veces desde el 2026-10-08 hasta el 2027-01-02. La última fecha sale de las notas del 2026-10-22 como «02/01/2027»; la leí día/mes y falta confirmarla con el gerente.
- Otros reprogramados: «Revisar el anexo 3» (5 veces), «Enviar el documento 1» (4), «Aprobar el diseño 5» (2).
- Cuatro compromisos tienen la declaración «ya entregó» en una minuta, sin acta (matriz 6, fecha 7, punto 8, prueba 10); los dejé como vencidos con esa declaración anotada. Un quinto vencido, «Enviar el documento 9», repite la misma fecha pasada en cuatro minutas seguidas.
- Las notas del 2026-10-22 recogen un riesgo que «nadie anotó» (que el proveedor no llegue con el equipo completo) y dicen que la próxima reunión es «en dos semanas», cuando las anteriores fueron semanales.
- «Mandar el ajuste del presupuesto» (Laura Vélez) quedó sin fecha: el texto dice «la otra semana» y no lo convertí en fecha.
- Otros: PRY-200 tiene un compromiso sin fecha («Entregar el punto 33», `por definir`); PRY-199, PRY-201, PRY-206 y PRY-208 un compromiso abierto cada uno, ninguno vencido hoy.

**Declaración del gerente frente a documentos (PRY-204):** el proyecto publica `ficha-pm.json`. La guardé entera en `pm_record` sin fusionarla con mi lectura; el contraste entre las dos lo calcula el código.

**Mismo texto en varios informes:** «Las lluvias detuvieron el montaje durante diez días» aparece en PRY-199, PRY-201, PRY-204 y PRY-207, cuyos cronogramas ponen el montaje entre 2027-03-28 y 2027-09-03 (PRY-201 no tiene hito de montaje). Lo registré como incidencia citada, sin darlo por cierto.

**Estado declarado:** 1 rojo (PRY-207, 40 %), 1 amarillo (PRY-210), 8 verdes.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno. El inventario marcó 9 `.xml` de cronograma como «formato que no se lee sin instalar algo», pero el conversor los leyó todos (0 ilegibles de 93). Leí 6 de ellos en este barrido (PRY-201 v2, PRY-204 v2, PRY-206 v2, PRY-207 v1, PRY-208 v1 y v2); los otros 3 (PRY-202, PRY-209, PRY-211) no cambiaron y no se releyeron. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` en `documentos/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Nada pendiente. `2026-10-22-notas-reunion.txt` está en la raíz de PRY-204, no en `30-reuniones/`; la leí como notas de ese proyecto y la cité por su ruta real. |

---
criterio-portfolio 0.8.0 · fichas tocadas: 10 (PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210) · campos en `not_found`: 24 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** hay más de un proyecto con ficha; puedo generar el informe consolidado (`/criterio-portfolio:portfolio-report`). Las contradicciones y los compromisos vencidos de arriba entrarían ahí.
