Ficha aplicada: `estado/records/PRY-209.json`, actualizada el 2026-10-23. Cifras recalculadas con `portafolio.py compute` al 2026-10-23. Términos v1.2 vigentes, aceptados por José Francisco Ñáñez (comprobante en `.criterio/terminos/`).

## PRY-209 · Electrificación de equipos — estado al 2026-10-23

**Declara el gerente (Sandra Gil):** verde · 70% · al 2026-10-22 (1 día de antigüedad; fuente: `20-seguimiento/2026-10-22-informe-avance.pdf`)
**Sustento documental:** contradicho. Ningún documento de evidencia sustenta el verde; el cálculo lo marca como `declared_vs_evidence`.
**Lo que el semáforo no explica:** hito cumplido sin evidencia, hito vencido, replanificación no autorizada, desviación de costo, desviación de tiempo, entregable de proveedor atrasado, facturado sobre lo aceptado, facturado sin entrega.
**Último documento:** 2026-10-22 (1 día de silencio) · **Última reunión:** sin dato. La ficha no tiene ninguna acta ni minuta de reunión, y no hay compromisos registrados.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-03 | 2027-07-02 | +211 días contra la original (77.3%); 0 días contra la vigente |
| Presupuesto | sin dato (la ficha solo trae 800.000.000 COP aprobados, sin historial de línea base de costo) | 800.000.000 COP aprobados · proyección 926.517.799 COP | proyección 15.8% sobre lo aprobado (umbral 10%) |

Ejecutado: 400.304.076 COP (50.0%). Comprometido: 593.282.872 COP (74.2%). Disponible real: 206.717.128 COP.

Replanificaciones: 1. La v3 del cronograma, fechada 2026-10-22, mueve el cierre del 2026-12-03 al 2027-07-02. El motivo no está en ningún documento (`not_found`).

Avance declarado 70% frente a 3 de 5 hitos cumplidos: el plan sustenta entre 60% y 80%, así que la cifra de avance es compatible con el cronograma. El problema es el resto.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-04-28 | 2026-04-28 | declarado cumplido | ninguna (178 días) |
| Ingeniería de detalle aprobada | 2026-06-22 | 2026-06-22 | declarado cumplido | ninguna (123 días) |
| Licencia y permisos obtenidos | 2026-08-16 | 2026-08-16 | cumplido | `2026-10-22-acta-recibo-licencia-y-permisos-obtenidos.md` |
| Montaje e instalación | 2026-10-09 | 2026-10-09 | pendiente, vencido 14 días | — |
| Pruebas en operación | 2026-12-03 | 2027-07-02 | pendiente | — |

### Dónde no coincide
- **Semáforo.** El informe de avance del 2026-10-22 dice verde. El mismo día, el cronograma v3 mueve el cierre 211 días y el montaje lleva 14 días vencido.
- **Línea base.** El cierre se movió 211 días y solo hay 115 autorizados (CC-02). Quedan 96 días sin autorizar, que coinciden con el CC-01 (+96 días), todavía pendiente. CC-02 figura aprobado por «el comité» sin nombre ni acta que lo cite.
- **Costo.** CC-01 (192.000.000 COP) y CC-02 (230.000.000 COP) piden ampliar el alcance. La proyección del informe (926.517.799 COP) no es comparable con esos montos y no se concilió. Hace falta confirmar con el gerente si la proyección los incluye.
- **Proveedor CT-576, Servicios Ambientales del Norte.** Facturó 69.149.721 COP (2026-09-09) y tiene 0 de 4 entregables aceptados. Licenciamiento lleva 172 días de atraso, bolsa de horas 112 y calibración 52.
- **Proveedor CT-611, Equipos Pesados Andinos.** Facturó 48.285.164 COP (2026-09-28) contra 32.663.188 COP aceptados, una diferencia de 15.621.976 COP. El licenciamiento figura aceptado sin evidencia de recibo. Bolsa de horas lleva 82 días de atraso y calibración 7.

### Abierto
**Riesgos e incidencias sin movimiento:** hay un riesgo registrado (ventana de parada de planta definida por operaciones) sin probabilidad, impacto, responsable, fecha ni último movimiento. No se pueden contar días sin movimiento.
**Compromisos vencidos:** ninguno, porque no hay compromisos registrados. No hay actas de reunión, así que no es lo mismo que «no hay pendientes».
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
Producto, autoridad y fase del proyecto. Motivo de la replanificación v3. Última reunión. Línea base original de presupuesto. Evidencia de aprobación de ingeniería básica y de detalle. Acta del comité que aprobó CC-02. Responsable, probabilidad e impacto del riesgo registrado.

### Después
La desviación de tiempo (77.3%) y la de costo (15.8%) superan el umbral del 10%, y el cambio CC-01 sigue sin decisión. Puedo preparar el punto de comité (próximo: 2026-10-29) y la solicitud de cambio formal de la línea base. No lo he hecho sin que lo pidan.

---
Criterio Portfolio v0.8.0 · ficha PRY-209 del 2026-10-23 · campos inciertos: producto, autoridad, fase, motivo de replanificación · términos v1.2: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
