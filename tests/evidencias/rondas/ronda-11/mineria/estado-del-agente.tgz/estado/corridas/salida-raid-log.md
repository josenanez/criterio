## RAID — Portafolio de proyectos (13 proyectos) al 2026-10-23

**De qué documentos sale.** El RAID ya registrado en las 13 fichas (`estado/records/PRY-199…211`, tomado de los informes de avance de cada proyecto, fechas de corte 2026-10-12 a 2026-10-22). Leídos para esta corrida: las 13 actas de constitución (sección «Dependencias declaradas»), las 12 minutas de comité (`30-reuniones/`: PRY-199, 200, 201, 202, 206, 208 y las seis de PRY-204), las notas de reunión de PRY-204 del 2026-10-22 y el informe de avance de PRY-204. Los otros 12 informes de avance no se volvieron a abrir: sus ítems vienen de la ficha.

**Escala.** No hay escala de probabilidad/impacto definida en la configuración; se usaría alta/media/baja, pero ningún ítem trae valoración, así que no se inventó ninguna.

6 riesgos · 0 supuestos · 17 incidencias · 12 dependencias (35 ítems)
35 sin doliente · 35 sin fecha · 35 sin dato de movimiento · 1 no registrado formalmente

Los ids (`199-R1`, `204-D2`…) son de este informe; las fichas no traen ids de RAID. R = riesgo, I = incidencia, D = dependencia.

### Reclasificados, y por qué
Doce ítems estaban como riesgo en los informes de avance y aquí pasan a dependencia, por la prueba rápida («si depende de alguien fuera del proyecto, es dependencia»):
- «El proveedor no ha confirmado la fecha de la última entrega» (200, 201, 204, 206, 207, 210): la entrega es de un tercero y el propio texto dice que no está confirmada.
- «Ventana de parada de planta definida por operaciones» (202, 204, 207, 208, 209, 211): la ventana la fija Operaciones, no el proyecto.

Ninguna de las dos lleva código de proyecto porque la contraparte es un proveedor o Operaciones, no otro proyecto del portafolio. Es un criterio mío: si el gerente lo ve distinto, se devuelven a riesgo. Los 12 ítems se pueden volver a riesgo sin perder nada; la cita sigue siendo el informe de avance.

### Necesitan decisión ahora
Ningún ítem cumple de forma demostrable un criterio de escalamiento: no hay fecha de último movimiento (no se puede probar «más de dos períodos sin movimiento»), no hay mitigaciones registradas (no hay una vencida) y ninguna dependencia apunta a otro proyecto. Lo que sigue necesita decisión por otras razones:

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 200-I1, 201-I2, 203-I1, 206-I1, 207-I3 | Incidencia | «Se levantó un hallazgo en la auditoría de seguridad» | no consta | no consta | Hallazgo de seguridad abierto en cinco proyectos, ninguno con doliente ni fecha; cuatro de los cinco declaran verde. Hay que asignar doliente y fecha. |
| 204-R1 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | `no_identificado` | 2026-10-22 | Dicho en reunión y nadie lo anotó; hay que decidir si se formaliza y quién lo lleva. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Riesgo (también tiene forma de dependencia del proveedor) | `PRY-204-monitoreo-de-taludes/2026-10-22-notas-reunion.txt` | 2026-10-22 |

Es el único. Las otras 11 minutas de comité traen solo temas y compromisos; ninguna menciona un riesgo, un supuesto ni una dependencia dichos al pasar. La nota no dice quién lo comentó. Cercano: en esa misma reunión «Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01»; la nota no lo une a este riesgo, así que no se afirma que sea su mitigación. Tampoco hay un proveedor por nombre en la nota (la ficha de PRY-204 lista Geotecnia Aplicada S.A.S. y Montajes Industriales Ltda.; no se sabe cuál).

### Sin doliente o sin fecha
Los 35 ítems no tienen doliente ni fecha. No se rellenó ninguno. Por proyecto:

| Proyecto | Ítems | Qué falta |
|---|---:|---|
| PRY-199 | 2 | doliente, fecha |
| PRY-200 | 2 | doliente, fecha |
| PRY-201 | 4 | doliente, fecha |
| PRY-202 | 4 | doliente, fecha |
| PRY-203 | 2 | doliente, fecha |
| PRY-204 | 5 | doliente, fecha (204-R1 con doliente `no_identificado`) |
| PRY-205 | 1 | doliente, fecha |
| PRY-206 | 4 | doliente, fecha |
| PRY-207 | 5 | doliente, fecha |
| PRY-208 | 1 | doliente, fecha |
| PRY-209 | 1 | doliente, fecha |
| PRY-210 | 3 | doliente, fecha |
| PRY-211 | 1 | doliente, fecha |

### Dependencias en riesgo
Ningún proyecto declara dependencia de otro: las 13 actas de constitución dicen «Ninguna declarada». El cruce entre proyectos no tiene nada que cruzar, y eso no significa que no haya dependencias: significa que nadie las declaró. Lo que sí hay son 12 dependencias de terceros (reclasificadas arriba):

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| 200-D1, 201-D1, 204-D1, 206-D1, 207-D1, 210-D1 | Proveedor (sin nombre en el informe) | No: el informe dice «no ha confirmado la fecha de la última entrega» | Declarada, no acordada. |
| 202-D1, 204-D2, 207-D2, 208-D1, 209-D1, 211-D1 | Operaciones (ventana de parada de planta) | No consta | El informe no dice si Operaciones ya fijó la ventana. |

Dato a tener en cuenta: la misma frase aparece palabra por palabra en seis informes. No se puede saber con estos documentos si es el mismo proveedor, ni si es el mismo asunto.

### Incongruencias que afectan la lectura de las incidencias
- «Las lluvias detuvieron el montaje durante diez días» figura en 199, 201, 202, 204 y 207, pero el cronograma ubica el montaje en 2027-09-03 (199), 2027-05-06 (204) y 2027-03-28 (207); el de 201 no tiene hito de montaje. Un montaje que parece no haber empezado no pudo detenerse: o la incidencia está mal descrita o el cronograma no refleja lo que se está haciendo. No se corrigió; hay que preguntarlo a cada gerente.
- 17 incidencias abiertas en 9 proyectos, pero 11 de los 13 proyectos declaran verde (207 rojo, 210 amarillo).
- Varias frases idénticas en proyectos distintos (hallazgo de auditoría ×5, ensayo de disponibilidad ×4, rotación de ingeniero ×3). Puede ser coincidencia o texto copiado entre informes; los documentos no lo aclaran.

### Registro completo
Prob., Impacto, Doliente, Fecha y Último movimiento: «no consta» en todos los ítems (así viene en las fichas). Fuente: informe de avance del proyecto salvo que se indique.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| 199-R1 | Riesgo | Concentración del conocimiento en una sola persona (informe 2026-10-20) | no consta | no consta | no consta | no consta | no consta |
| 199-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días (montaje en cronograma: 2027-09-03) | — | no consta | no consta | no consta | no consta |
| 200-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega (informe 2026-10-18) | — | no consta | no consta | no consta | no consta |
| 200-I1 | Incidencia | Hallazgo en la auditoría de seguridad | — | no consta | no consta | no consta | no consta |
| 201-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega (informe 2026-10-21) | — | no consta | no consta | no consta | no consta |
| 201-I1 | Incidencia | Primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | no consta | no consta | no consta | no consta |
| 201-I2 | Incidencia | Hallazgo en la auditoría de seguridad | — | no consta | no consta | no consta | no consta |
| 201-I3 | Incidencia | Lluvias detuvieron el montaje diez días (el cronograma no tiene hito de montaje) | — | no consta | no consta | no consta | no consta |
| 202-D1 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones (informe 2026-10-22) | — | no consta | no consta | no consta | no consta |
| 202-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | no consta | no consta | no consta | no consta | no consta |
| 202-I1 | Incidencia | Lluvias detuvieron el montaje diez días | — | no consta | no consta | no consta | no consta |
| 202-I2 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | no consta | no consta | no consta | no consta |
| 203-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance (informe 2026-10-12) | no consta | no consta | no consta | no consta | no consta |
| 203-I1 | Incidencia | Hallazgo en la auditoría de seguridad | — | no consta | no consta | no consta | no consta |
| 204-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega (informe 2026-10-22) | — | no consta | no consta | no consta | no consta |
| 204-D2 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones | — | no consta | no consta | no consta | no consta |
| 204-R1 | Riesgo, **no registrado formalmente** | El proveedor podría no llegar con el equipo completo para la siguiente fase (notas de reunión 2026-10-22) | no consta | no consta | `no_identificado` | no consta | no consta |
| 204-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | — | no consta | no consta | no consta | no consta |
| 204-I2 | Incidencia | Lluvias detuvieron el montaje diez días (montaje en cronograma: 2027-05-06) | — | no consta | no consta | no consta | no consta |
| 205-R1 | Riesgo | Concentración del conocimiento en una sola persona (informe 2026-10-19) | no consta | no consta | no consta | no consta | no consta |
| 206-R1 | Riesgo | Bloqueo de la vía de acceso a la mina (informe 2026-10-22) | no consta | no consta | no consta | no consta | no consta |
| 206-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega | — | no consta | no consta | no consta | no consta |
| 206-I1 | Incidencia | Hallazgo en la auditoría de seguridad | — | no consta | no consta | no consta | no consta |
| 206-I2 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | — | no consta | no consta | no consta | no consta |
| 207-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega (informe 2026-10-18) | — | no consta | no consta | no consta | no consta |
| 207-D2 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones | — | no consta | no consta | no consta | no consta |
| 207-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | no consta | no consta | no consta | no consta |
| 207-I2 | Incidencia | Lluvias detuvieron el montaje diez días (hito de montaje: 2027-03-28) | — | no consta | no consta | no consta | no consta |
| 207-I3 | Incidencia | Hallazgo en la auditoría de seguridad | — | no consta | no consta | no consta | no consta |
| 208-D1 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones (informe 2026-10-17) | — | no consta | no consta | no consta | no consta |
| 209-D1 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones (informe 2026-10-22) | — | no consta | no consta | no consta | no consta |
| 210-D1 | Dependencia (ex riesgo) | Proveedor no ha confirmado fecha de la última entrega (informe 2026-10-15) | — | no consta | no consta | no consta | no consta |
| 210-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | — | no consta | no consta | no consta | no consta |
| 210-I2 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | no consta | no consta | no consta | no consta |
| 211-D1 | Dependencia (ex riesgo) | Ventana de parada de planta definida por operaciones (informe 2026-10-22) | — | no consta | no consta | no consta | no consta |

### Lo que este registro no sabe
- **Supuestos: cero.** Ningún documento los declara. Eso no quiere decir que no haya: en estos proyectos los candidatos habituales (persona clave disponible, proveedor entrega a tiempo, ventana de planta, licencia) aparecen hoy como riesgos o dependencias.
- **Movimiento:** las fichas no guardan cuándo se movió cada ítem; hoy hay una sola corrida de estado, así que «dos períodos sin movimiento» no se puede evaluar. Se vuelve evaluable desde la próxima corrida.
- **Mitigaciones:** ninguna registrada; no se puede decir cuáles vencieron.
- Lo que se habló fuera de estos documentos no está aquí.

### Siguiente paso, si lo quieres
- Subir a comité los hallazgos de auditoría de seguridad sin doliente (200, 201, 203, 206, 207), con la decisión formulada: «¿quién es el doliente de cada uno y para qué fecha se cierra?».
- Proponer doliente (proponer, no asignar) para los 35 ítems: el gerente de cada proyecto es el candidato natural, pero eso lo decide cada comité.
- Pedir a cada gerente que formalice o descarte 204-R1.

---
Rigor: cada ítem cita el documento de donde sale; nada se rellenó. Los datos que faltan se dicen como «no consta». La reclasificación de 12 ítems es criterio mío y está explicada arriba. Este borrador no sustituye la decisión del gerente ni del comité; la verificación contra los documentos es tuya.
