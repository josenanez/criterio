# Corrida del 2026-10-23 · portfolio-setup

3 proyectos · 93 documentos, 69 releídos y 24 sin cambio · 26 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_time` | 3 |
| `declared_vs_evidence` | 3 |
| `milestone_overdue` | 2 |
| `rebaseline_unauthorized` | 2 |
| `commitment_undated` | 1 |
| `variance_cost` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `progress_vs_plan` | 1 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); 118 s hasta el primer resultado; 3 proyectos (PRY-202, 209, 211): 26 señales, los 3 verdes contradichos por la evidencia

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 93 documentos en 13 proyectos · formatos: .md (40), .pdf (20), .docx (13), .xml (9), .xlsx (5), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-22
**Eres:** PMO del portafolio (propuesta por defecto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo, propuesto, el 2026-10-29 (es una propuesta mía: los documentos traen actas de comité semanal y no hay una fecha dicha, corrígela si es otra)
**En:** página (HTML). Propuesta mía; la plantilla del plugin la trae por defecto. Si prefieres presentación o PDF, dímelo y lo cambio.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 fe830b9a4eee0bc9… (la fecha del comprobante es la del sistema, 2026-10-23; la aceptación que indicaste era del 2026-10-22)

Tuve que tomar yo estas decisiones, porque nadie respondía preguntas: carpeta de documentos `documentos/proyectos` (la del argumento, única candidata); estado en `estado`; informes en `reportes`; archivo `_CRITERIO_PORTAFOLIO.txt` dejado en la carpeta de documentos. Preguntas hechas a la persona: 0. Tiempo medido por la corrida registrada: 118 segundos.

### Probé con tres proyectos

PRY-202, PRY-209 y PRY-211, los de documentación del 2026-10-22 con lectura más corta. Los tres reportan **verde** el 2026-10-22 y los tres tienen señales que lo contradicen (`declared_vs_evidence`).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | 7 | Patrocinadora Sandra Gil, gerente Ricardo Salas, Comité de Inversiones. Aprobado 6.800.000.000 COP; ejecutado 1.712.834.466 (25,2 %); proyección 7.057.069.997 (+3,8 %). Cierre 2027-03-04 → 2027-04-28 por CC-01. Declara verde y 56 %. | Producto, facultad del gerente, fase. Dueño con fecha para el compromiso del punto 37. |
| PRY-209 Electrificación de equipos | 11 | Patrocinadora Beatriz Cuéllar, gerente Sandra Gil, Comité Ambiental. Aprobado 800.000.000 COP; ejecutado 400.304.076 (50 %); proyección 926.517.799 (+15,8 %). Dos contratos (CT-576, CT-611). Cierre 2026-12-03 → 2027-07-02. Declara verde y 70 %. | Producto, facultad, fase. Actas de comité (CC-02 dice «autorizada por el comité» y no hay acta). Actas de recibo de los proveedores. |
| PRY-211 Control de polvo en vías | 6 | Patrocinador Andrés Lozano, gerente Liliana Torres, Comité Ambiental. Aprobado 18.000.000.000 COP; ejecutado 10.548.829.409 (58,6 %); proyección 17.889.833.959 (−0,6 %). Cierre 2026-04-22 → 2026-06-04. Declara verde y 58 %. | Producto, facultad, fase. Actas de recibo de 3 de 4 hitos. Ninguna acta de comité. |

**Señales que levantó el cálculo** (con el nombre de portfolio-health):

- **PRY-202** (4): `variance_time` +55 días (20,8 % sobre la original, autorizado por CC-01); `milestone_overdue` «Ingeniería de detalle aprobada», vencido el 2026-10-22; `commitment_undated` Carlos Peña, «Entregar el punto 37», «por definir», dicho en el comité del 2026-10-22; `declared_vs_evidence`: verde contra las dos primeras.
- **PRY-209** (15): `variance_time` +211 días (77,3 %); `milestone_overdue` «Montaje e instalación», 14 días; `milestone_met_without_evidence` en «Ingeniería básica» y «Ingeniería de detalle» (cerradas en el cronograma, sin acta); `variance_cost` +15,8 % de proyección sobre lo aprobado; `vendor_deliverable_late` ×5; `vendor_invoiced_without_delivery` CT-576, 69.149.721 COP facturados sin ningún entregable aceptado; `vendor_accepted_without_evidence` CT-611; `vendor_invoiced_over_accepted` CT-611, 48.285.164 facturados contra 32.663.188 aceptados (diferencia 15.621.976); `rebaseline_unauthorized`: el cronograma se movió 211 días y solo 115 están autorizados (CC-02); los 96 restantes coinciden con CC-01, que sigue pendiente de comité; `declared_vs_evidence`: verde contra 8 señales.
- **PRY-211** (7): `variance_time` +43 días (14,3 %); `progress_vs_plan`: declara 58 % con los 4 hitos de 4 cerrados, 42 puntos de diferencia; `milestone_met_without_evidence` ×3 (Ingeniería de detalle, Licencia y permisos, Montaje); `rebaseline_unauthorized`: se movió 43 días y no hay autorización, CC-01 sigue pendiente de comité; `declared_vs_evidence`: verde contra 4 señales.

Total: 26 señales; 3 de 3 proyectos con el verde contradicho. Las fichas están en `estado/records/PRY-202.json`, `PRY-209.json` y `PRY-211.json`.

**Qué no pude leer:** los 9 cronogramas `.xml` los clasificó el script como ilegibles sin instalar algo. Los de estos tres proyectos son texto plano y los leí directamente, pero el inventario los sigue marcando como no leíbles; el índice de cambios (hash de texto) no los cubre.

### El portafolio completo
10 proyectos más (PRY-199, 200, 201, 203, 204, 205, 206, 207, 208, 210), unos 66 documentos, en un solo lote de 10 proyectos, uno tras otro. Estimación mía, no medida: de 30 a 45 minutos. PRY-204 es el más grande (21 documentos), trae `ficha-pm.json` y ya tiene estado propio del agente de proyecto en `estado/PRY-204-monitoreo-de-taludes/`; su ficha del portafolio irá aparte y la del gerente en `pm_record`.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.

- **Actas de comité:** PRY-209 y PRY-211 no tienen carpeta `30-reuniones`. Hay cambios «autorizados por el comité» y proyectos sin ninguna acta que lo sustente. PRY-203, PRY-205 y PRY-210 tampoco la tienen.
- **Actas de recibo:** los hitos que el cronograma da por cerrados tienen acta solo en parte (PRY-209: 1 de 3; PRY-211: 1 de 4).
- **Compromisos sin fecha:** el comité de PRY-202 deja «por definir» como fecha.
- **Producto, facultad del gerente y fase:** ninguna de las tres actas los trae (en las tres, «Producto asociado: No aplica»).
- **Contenido de las actas:** el alcance dice «Componente 1, 2, 3» y «lo que otro proyecto cubre»; no se puede contrastar contra nada.
- **Formato:** los cronogramas en `.xml` conviene dejarlos también en `.xlsx` o `.csv`.
- **Estructura:** hay una carpeta por proyecto con `00-gobierno`, `10-plan`, `20-seguimiento`, `30-reuniones`, y fecha en el nombre; está bien. PRY-204 tiene un `2026-10-22-notas-reunion.txt` suelto fuera de `30-reuniones`.
