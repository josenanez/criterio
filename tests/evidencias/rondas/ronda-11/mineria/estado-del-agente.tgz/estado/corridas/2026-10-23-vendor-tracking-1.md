# Corrida del 2026-10-23 · vendor-tracking

13 proyectos · 34 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Cruce de CT-326 en PRY-200: Calibración de sensores aceptada sin acta, 2 entregables atrasados, factura FV-1326 sin desglose. No dijo: vigencia/preaviso del contrato y qué cubre la factura.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha PRY-200 y salida de `portafolio.py compute` (corte 2026-10-23); contrato CT-326 (2025-09-04), acta de constitución (2025-09-14), cronograma v1, actas de recibo del 2026-01-07, 2026-10-11 y 2026-10-21, factura FV-1326 (2026-09-02), informe de avance (2026-10-18) y comité del 2026-10-19. Términos vigentes (v1.2), aceptados por José Francisco Ñáñez.

## Proveedores — PRY-200 Mantenimiento predictivo de camiones al 2026-10-23

### Equipos Pesados Andinos — contrato CT-326
**Vigencia:** firmado el 2025-09-04; fin de vigencia no declarado · **Preaviso de no renovación:** no declarado · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2025-11-05 | pendiente (352 días de atraso) | ninguna | no hay desglose |
| Bolsa de horas de ingeniería | 2025-12-18 | aceptado | acta de recibo 2026-01-07 (Carlos Peña) | no hay desglose |
| Calibración de sensores | 2026-01-30 | aceptado | **ninguna** (solo lo dice la columna "Estado" del propio contrato: "recibido") | no hay desglose |
| Soporte del primer trimestre | 2026-03-14 | pendiente (223 días de atraso) | ninguna | no hay desglose |

Cada entregable vale 275.896.256 COP. Facturado: 551.792.512 COP (FV-1326, 2026-09-02, radicada en cuentas por pagar). Del script: 4 entregables, 2 aceptados, 2 atrasados, 1 aceptado sin evidencia.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturación contra acta | "Cada entregable se factura contra acta de recibo firmada por el gerente" | Hay un acta de recibo de CT-326 (Bolsa de horas, 275.896.256). La factura cubre 551.792.512; el monto de un entregable (275.896.256) no tiene acta | contrato CT-326; acta 2026-01-07; factura FV-1326 |
| Calibración de sensores | "recibido" | No hay acta, correo ni minuta que lo pruebe | contrato CT-326 (tabla) |
| Factura sin desglose | — | El concepto es "Entregables del contrato CT-326", sin decir cuáles cubre. Se asume que son los dos aceptados, pero la factura no lo dice | factura FV-1326 |

El script no levantó `vendor_invoiced_without_delivery` porque cuenta 2 entregables aceptados; esa aceptación de Calibración es una declaración, no evidencia.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Calibración de sensores | aceptado / "recibido" en el contrato | contrato 2025-09-04 (fecha comprometida 2026-01-30) |

### Compromisos del proveedor vencidos
Ninguno vencido. Del comité del 2026-10-19 hay dos compromisos abiertos, de Liliana Torres (punto 4, para 2026-10-23) y Beatriz Cuéllar (punto 33, sin fecha: "por definir"). Ninguna de las dos aparece vinculada al proveedor, así que no puedo atribuirlas a Equipos Pesados Andinos. El informe de avance sí registra un riesgo: "El proveedor no ha confirmado la fecha de la última entrega".

### Sin dato
- Vigencia, renovación automática y preaviso de CT-326: el contrato no los declara. No puedo decir si hay un preaviso por vencer.
- Qué entregables cubre FV-1326.
- Las actas de recibo de "Montaje e instalación" (2026-10-21) y "Pruebas en operación" (2026-10-11) no corresponden a ningún entregable de CT-326; son hitos del proyecto y no los cruzo contra el proveedor.
- Contexto: tres hitos del cronograma figuran cerrados sin acta (Ingeniería básica, Ingeniería de detalle, Licencia y permisos); es un hallazgo de proyecto, no de proveedor.

### Para comité
Hay una factura de 551.792.512 COP radicada con un entregable sin acta y dos entregables sin entregar (el de licenciamiento lleva 352 días de atraso). Antes de pagar conviene pedir el acta de Calibración de sensores o el desglose de la factura. Lo ofrezco para llevarlo a comité (próximo 2026-10-29).

---
*Rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados; verifíquelo contra ellos. Lo que se habló fuera de los documentos no está aquí.*
