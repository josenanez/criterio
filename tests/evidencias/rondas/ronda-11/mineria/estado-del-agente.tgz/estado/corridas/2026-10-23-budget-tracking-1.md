# Corrida del 2026-10-23 · budget-tracking

13 proyectos · 39 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Presupuesto de PRY-201 con las cuatro cifras citadas al informe del 2026-10-21. Alertas: comprometido 93,0 %, proyección 1,2 % sobre el aprobado, verde declarado con tres señales abiertas. Dijo que no sabía: línea base de presupuesto original frente a vigente, si los 122.000.000 COP de CC-01 están dentro del aprobado, el detalle por proveedor y la evidencia del hito cumplido.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Documentos de origen: `20-seguimiento/2026-10-21-informe-avance.md` (corte 2026-10-21), `20-seguimiento/2026-10-16-solicitud-cambio-cc-01.md`, `10-plan/2026-10-21-cronograma-v2.xml` y `10-plan/2026-02-03-cronograma-v1.xlsx`. Cifras recalculadas con `portafolio.py compute` al 2026-10-23.

## Presupuesto — PRY-201 · Ampliación de la relavera al 2026-10-23
**Moneda:** COP (no hay contratos en otra moneda; no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 18.000.000.000 | 100 % | informe de avance | 2026-10-21 |
| Comprometido | 16.735.307.598 | 93,0 % | informe de avance | 2026-10-21 |
| Ejecutado | 6.108.769.631 | 33,9 % | informe de avance | 2026-10-21 |
| Proyección al cierre | 18.209.304.767 | 1,2 % por encima del aprobado | informe de avance (declaración del gerente) | 2026-10-21 |

**Disponible real** (aprobado menos comprometido): 1.264.692.402 COP

La proyección es una declaración de la gerente (Diana Molina), no un dato medido. Tiene la misma fecha que las otras tres cifras, así que no está más vieja que el último movimiento de presupuesto que consta en los documentos.

### Contra la línea base
No hay una línea base de presupuesto original y otra vigente en ningún documento: el informe da un solo "Aprobado" de 18.000.000.000 COP. Por eso no se calcula desviación de costo contra ninguna de las dos.

Lo que sí consta: la solicitud CC-01 (2026-10-16) pide **122.000.000 COP adicionales**. Ningún documento dice si esos 122.000.000 están dentro de los 18.000.000.000 o van encima. La proyección ya excede el aprobado en 1,2 %, y esa diferencia no se puede explicar solo con CC-01 por falta de ese dato.

Replanificaciones de presupuesto: 0 registradas como línea base nueva. Hay 1 solicitud de cambio con impacto de costo (CC-01), sin nueva línea base de presupuesto asociada. (La línea base de fechas sí tuvo 1 replanificación: v1 → v2, +61 días, fin 2027-04-21 → 2027-06-21.)

### Ejecución frente a avance
Ejecutado 33,9 % · Hitos cumplidos 1 de 3 · Avance declarado 67 %.
La ejecución y los hitos van juntos, en torno a un tercio. Lo que se aparta es el 67 % declarado, que el plan solo respalda en su extremo alto (el plan sustenta entre 33 % y 67 %). Y el único hito cumplido, "Ingeniería básica aprobada" (vence 2026-07-07), consta como cumplido sin evidencia en ningún documento.

### Alertas
- **Comprometido en 93,0 %**, por encima del umbral de 90 %. Con 33,9 % ejecutado, la holgura que parece haber (66,1 % sin ejecutar) no existe: solo quedan 1.264.692.402 COP sin comprometer. Lo comprometido y no causado todavía va a aparecer como ejecución.
- **Proyección por encima del aprobado**, 1,2 % (18.209.304.767 frente a 18.000.000.000 COP).
- **Estado declarado "verde" con tres señales abiertas** que el informe no menciona: comprometido sobre el umbral, hito cumplido sin evidencia y desviación de tiempo de 61 días (14,1 % contra la línea base original).
- **CC-01 aprobada sin trazabilidad:** dice "autorizada por el comité", sin nombre ni acta de comité que la cite.
- El informe menciona un ensayo de disponibilidad repetido, un hallazgo de seguridad, diez días de lluvias y un proveedor sin fecha de última entrega, y nada de eso aparece en las cifras de costo.

### Sin dato
- Presupuesto aprobado original frente al vigente (no hay dos versiones en ningún documento).
- Si los 122.000.000 COP de CC-01 están incluidos en el aprobado de 18.000.000.000.
- Desglose del comprometido por proveedor: la ficha no tiene proveedores ni contratos registrados.
- Fecha propia de la proyección, distinta de la del informe.
- Evidencia de cumplimiento del hito "Ingeniería básica aprobada".

---
*Pie de rigor:* borrador de trabajo, no decisión ni asesoría. Cada cifra sale del informe de avance del 2026-10-21 y se calculó con `portafolio.py compute`; la verificación contra el original es de quien lo lea. Criterio no sabe lo que se habló fuera de estos documentos.

**Siguiente paso posible:** la proyección excede el aprobado, así que puedo preparar la solicitud de cambio de presupuesto; y como el comprometido está cerca del tope, puedo armar el detalle por proveedor si se aportan los contratos.
