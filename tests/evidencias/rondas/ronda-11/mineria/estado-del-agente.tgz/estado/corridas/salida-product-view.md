Fuente: cálculo de `portafolio.py compute` sobre las fichas de `estado/records` (13 proyectos), al 2026-10-23. Términos vigentes (v1.2), aceptados por José Francisco Ñáñez.

## Productos al 2026-10-23 — producto: trazabilidad

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| trazabilidad | 1 (PRY-208) | 1 (5 señales) | 2028-01-14 (PRY-208) | COP 6.800.000.000 | COP 4.004.860.656 (58,9 %) |

**«trazabilidad» tiene un solo proyecto (PRY-208, Trazabilidad del mineral).** La vista por producto no aporta nada aquí: no hay otros proyectos con los que cruzar dependencias ni con los que tomar una fecha más tardía. No armo sección de producto; lo que sigue es lo que dice la ficha de PRY-208. Las cifras vienen del cálculo y las cuatro cifras de dinero están completas.

**Lo que hay que ver en PRY-208** (todo es contra el informe de avance del 2026-10-17, que declara «verde»; ver `20-seguimiento/2026-10-17-informe-avance.md`):
- **Avance:** declara 83 %, pero los hitos sustentan entre 20 % y 40 % (1 de 5 hitos cumplido). La diferencia es de 43 puntos.
- **Hito sin evidencia:** «Ingeniería básica aprobada» (vencía 2026-10-07, hace 16 días) figura como cumplido y no hay documento que lo sustente.
- **Proveedor:** Automatización de Procesos Ltda. (CT-644) lleva COP 555.209.101 facturados y 0 de 3 entregables aceptados.
- **Línea base:** se movió 34 días (6,3 % sobre la original) con 0 días autorizados; hay un solo cambio visto y no lo aprueba nadie.
- **Contradicción:** el «verde» declarado no explica ninguna de estas cuatro señales.
- **Dinero:** ejecutado 27,8 %; la proyección es COP 6.959.303.783, 2,3 % por encima de lo aprobado (por debajo del umbral de 10 %).
- **Dependencias:** no hay ninguna registrada, ni interna ni externa.
- **Sin dato en la ficha:** `identity.authority` e `identity.phase`.

No hay decisión de producto que llevar al comité de producto: sin dependencias internas no hay nada que unificar. Los cuatro puntos de arriba son de proyecto y van como tales.

### Proyectos sin producto declarado
Siete de los 13 proyectos no declaran a qué producto sirven. Nadie puede responder por el conjunto al que sirven, y eso es un hallazgo de gobierno por sí solo.

| Proyecto | Área dueña (según el acta de constitución) |
|---|---|
| PRY-201 Ampliación de la relavera | Medio Ambiente |
| PRY-202 Planta de tratamiento de agua | Seguridad y Salud |
| PRY-205 Sistema de gestión de seguridad | Mina |
| PRY-206 Red privada LTE en mina | Seguridad y Salud |
| PRY-209 Electrificación de equipos | Geología |
| PRY-210 Programa de relacionamiento comunitario | Mina |
| PRY-211 Control de polvo en vías | Mantenimiento |

Dos observaciones sobre el resto, sin ampliarlas: PRY-199 declara el código «PRD-299» como producto, que parece un código y no un nombre de producto, y ninguno de los 13 proyectos tiene `authority` declarada.

## Pie de rigor
- Lo que no sé: si alguno de los siete proyectos sin producto sirve en realidad a «trazabilidad» (no lo puedo inferir de la ficha; lo tendría que confirmar el dueño del producto); si el hito «Ingeniería básica aprobada» está aprobado fuera de la carpeta; ni quién autorizó el movimiento de 34 días.
- Este es un borrador de trabajo, no una decisión. Cada dato cita su ficha y su documento fuente; la verificación es de quien lo lee.
