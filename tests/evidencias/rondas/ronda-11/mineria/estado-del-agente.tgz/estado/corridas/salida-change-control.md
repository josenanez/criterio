*Sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-23) y de los documentos citados. Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-23.*

## Solicitud de cambio — PRY-200 Mantenimiento predictivo de camiones — 2026-10-23

**Qué se pide:** mover la salida a producción 30 días. La ficha no tiene un hito llamado «salida a producción»; el criterio de éxito del acta es «en producción y medido» y la fecha comprometida es el cierre (2026-04-06). Tomo el pedido como mover el cierre 30 días: 2026-04-06 → 2026-05-06. Si se refería a otra fecha, dígalo.
**Quién lo pide:** no consta en ningún documento. **Por qué:** no consta; la solicitud no trae motivo.

### Hallazgo previo: la fecha nueva ya pasó
Hoy es 2026-10-23. El cierre vigente (2026-04-06) venció hace 200 días y la fecha pedida (2026-05-06) venció hace 170. Los 30 días no son un movimiento hacia adelante: serían una aprobación retroactiva que no cubre el atraso real.
- No hay línea base 2 ni cambios registrados (`changes: []`). Solo existe la línea base 1 (acta, 2025-09-14).
- El hito «Pruebas en operación» figura con fecha vigente 2026-04-06, igual a la de la línea base, pero su acta de recibo es del 2026-10-11, 188 días después. «Montaje e instalación» (base 2026-02-26) tiene acta del 2026-10-21, 237 días después. Nadie documentó esa diferencia.
- El informe del 2026-10-18 declara **verde** y 77 % de avance, con el cierre ya vencido.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | 3 componentes, sin detallar (acta) | Sin impacto declarado | Ninguna declarada |
| Tiempo | Cierre 2026-04-06 | 2026-05-06 (ya vencida) | +30 días declarados; el atraso real contra la original es de al menos 200 días y sigue abierto |
| Costo | Aprobado 2.400.000.000 COP; proyección 2.479.870.475 | Sin impacto declarado | La proyección ya supera lo aprobado en 79.870.475 COP (+3,3 %, bajo el umbral de 10 %) |

Dos dimensiones quedan sin impacto declarado. Alguien las absorbe y la solicitud no dice quién: alcance y costo no se mueven en el papel, mientras que el calendario sí. Si el costo no cambia, se absorbe en horas no pagadas o en calidad, y debe decirse.

Otras señales de la ficha (no son parte del cambio, pero un comité las va a preguntar):
- Ejecutado 446.036.134 COP (18,6 % de lo aprobado) frente a 77 % de avance reportado.
- Facturado a CT-326: 551.792.512 COP, más que lo ejecutado. De los dos entregables aceptados, solo la bolsa de horas tiene acta de recibo; «Calibración de sensores» figura aceptado sin evidencia. Licenciamiento (vencido 2025-11-05) y soporte del primer trimestre (vencido 2026-03-14) siguen pendientes.
- Riesgo abierto: el proveedor no ha confirmado la fecha de la última entrega. Hallazgo abierto de auditoría de seguridad, sin dueño ni fecha.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` devuelve 0 alcanzados (0 directos, 0 indirectos, 0 sin poder sostener fecha, 0 dependencias sin confirmar) | n/a |

Esto significa que **no hay dependencias declaradas** (el acta dice «Ninguna declarada»). No prueba que no existan. El producto asociado es «monitoreo de flota», y no se verificó quién más lo construye. Tampoco sé cuántos días se mueve ningún otro proyecto, porque la ficha no trae holgura por actividad.

### Quién decide
**Autoridad requerida:** no declarada. La ficha marca `identity.authority` como no encontrada: ningún documento dice quién aprueba cambios de fecha o presupuesto. Es el hallazgo de fondo.
**Según:** el acta solo muestra que el presupuesto lo aprobó el Comité de Operaciones el 2025-09-14. Sirve de indicio, no de cláusula de autoridad.
**Va a comité:** sí, por defecto, ya que sin autoridad declarada el gerente no puede aprobarlo solo. Comité de Operaciones; próxima fecha de comité del portafolio: 2026-10-29.

### Si no se aprueba
El proyecto sigue con un cierre (2026-04-06) vencido hace 200 días y estado verde declarado, sin línea base vigente que lo respalde. Se reporta contra la original como atraso sin autorizar.

### Si se aprueba
Línea base 2 (borrador, **no registrada**): cierre 2026-05-06 · presupuesto 2.400.000.000 COP (sin cambio declarado) · motivo: no consta. No la registro, porque nadie la ha aprobado y su fecha ya pasó. Lo coherente es pedir una fecha futura, con motivo y con quién lo aprueba.
Desviación acumulada contra la línea base original: **tiempo** ≥ 200 días a hoy (30 de ellos autorizados si se aprobara lo pedido, 170 sin documento que los autorice) · **costo** +79.870.475 COP proyectados (+3,3 %).
Conteo de replanificaciones: pasaría de 0 a 1.

### Qué no sé
- Qué fecha quiere mover realmente quien pide el cambio, ni su motivo.
- Quién tiene autoridad para aprobar.
- Si el costo cambia con el atraso.
- Qué proyectos dependen de este sin haberlo declarado.

**Siguiente paso:** llevar el paquete al Comité de Operaciones, con una fecha nueva futura y la autoridad definida, o registrar la línea base 2 si ya la aprobó quien podía.
