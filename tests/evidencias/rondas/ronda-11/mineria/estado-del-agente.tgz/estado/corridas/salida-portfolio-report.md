# Portafolio — 2026-10-23
13 proyectos · 11 con hallazgos · 80 señales · último barrido 2026-10-23 (13 fichas, todas del día, ninguna con más de una semana)

Términos vigentes: aceptados por José Francisco Ñáñez, versión 1.2, 2026-10-23.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (2026-10-23): es el punto de partida, no hay delta.

## Contradicciones abiertas
Vacía. Ninguna ficha tiene campos en `ambiguous` ni problemas de ficha (`record_issues` = 0).

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | Ingeniería de detalle aprobada | 2026-10-22 | 1 |
| PRY-209 Electrificación de equipos | Montaje e instalación | 2026-10-09 | 14 |

Además hay hitos declarados "cumplidos" sin evidencia en PRY-200, 201, 206, 207, 208, 209, 210 y 211.

## Proyectos en silencio
Vacía. Ningún proyecto supera 15 días sin documentos (el mayor es PRY-203, con 11).

## Dependencias en riesgo
Las fichas no declaran dependencias entre proyectos por código. Vacía.

## Sin sustento (declarado verde, evidencia en contra): 9 proyectos
PRY-200, 201, 202, 203, 204, 206, 208, 209, 211.
- PRY-209: 8 señales, entre ellas atraso de 211 días (77 %), 96 días de línea base movida sin autorización, costo +15,8 %, proveedores con entregables vencidos y facturación sobre lo aceptado o sin entrega.
- PRY-204: atraso de 84 días y costo +19,6 %, 84 días de línea base movida sin autorización, 7 compromisos vencidos, 3 reprogramados 4 a 6 veces, Montajes Industriales facturó 291,5 M COP sobre lo aceptado.
- PRY-208: avance declarado 83 % contra 20-40 % que sostiene el plan, 34 días de línea base movida sin autorización, factura de 555,2 M COP sin entregables recibidos.
- PRY-206: atraso de 102 días (35 %) y avance declarado 87 % con el plan sosteniendo 100 %, con tres hitos cumplidos sin evidencia.
- PRY-203: costo proyectado +25,1 % (8.503,7 M contra 6.800 M aprobados).
- PRY-201 (+61 días, 93 % comprometido), PRY-202 (+55 días), PRY-200 y PRY-211: ver la página de cada proyecto.

## Vacíos de información
- Ningún proyecto tiene autoridad registrada (13 de 13).
- 7 proyectos sin producto asociado: PRY-201, 202, 205, 206, 209, 210 y 211.
- Compromisos sin fecha en PRY-200, 202 y 204.

## Estado general
Sin hallazgos: PRY-199 y PRY-205. Con hallazgos: los otros 11. El detalle por campo y la cadena de evidencia están en `index.html`; los proyectos tienen una página cada uno.

## Necesito que confirmes
Hoy no toca confirmación mensual: es la primera corrida y no hay campos viejos (umbral 12 meses).

## Dónde quedó
Carpeta `reportes/`, 23 páginas:
- `reportes/index.html` — vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión, para el patrocinador. Solo lo que excede la facultad de quien gerencia.
- Una página por proyecto, una por producto, más `productos.html` y `proyectos.html`.
- Para PDF, imprimir el HTML (está construido para eso).

Pie: criterio-portfolio 0.8.0 · 13 fichas del 2026-10-23 · campos inciertos: 0 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
