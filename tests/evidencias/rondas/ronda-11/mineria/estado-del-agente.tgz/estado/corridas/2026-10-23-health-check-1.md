# Corrida del 2026-10-23 · health-check

13 proyectos · 120 s · 80 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `declared_vs_evidence` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 7 |
| `commitment_undated` | 6 |
| `variance_time` | 6 |
| `progress_vs_plan` | 5 |
| `vendor_accepted_without_evidence` | 4 |
| `rebaseline_unauthorized` | 4 |
| `variance_cost` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `vendor_invoiced_without_delivery` | 2 |
| `budget_committed` | 1 |

Diagnóstico de PRY-200 sobre 9 documentos (2025-09-04 a 2026-10-21). Dictamen: 9 sostenidas, 9 sin sustento, 3 contradichas. Dijo que no sabe: si está en verde, el gasto real, la autoridad del gerente, el alcance, el hallazgo de seguridad y qué pasó entre 2026-01-07 y 2026-09-02.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-200 Mantenimiento predictivo de camiones · 2026-10-23

Términos: ya estaban vigentes (v0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23, comprobante en `.criterio/terminos/`). No hubo que registrarlos de nuevo.

**Leí:** 9 documentos · de 2025-09-04 a 2026-10-21 · formatos: 4 PDF, 2 DOCX, 2 MD, 1 CSV. Además busqué el proyecto por código, por nombre, por proveedor y por contrato en el resto del portafolio. Solo apareció el proveedor, en PRY-209 (CT-611), y ningún documento lo vincula con PRY-200.
**No pude leer:** nada quedó sin leer. Los PDF y DOCX los leí por su texto convertido (caché). Las citas apuntan a los originales.

### Dictamen
**Sostenido:** 9 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 3 (conteo propio sobre 21 afirmaciones; las listas están abajo y se pueden verificar una por una).

Sostenido: presupuesto aprobado, patrocinador, gerente, comité, Montaje e instalación recibido, Pruebas en operación recibido, Licenciamiento pendiente, Soporte del primer trimestre pendiente y Bolsa de horas recibida.

Desde esta carpeta se puede afirmar quién gobierna el proyecto (nombres), cuál fue el presupuesto aprobado, que existen actas de recibo de dos hitos y de un entregable del proveedor, y que dos entregables del contrato siguen pendientes con fecha vencida. No se puede afirmar que el proyecto esté en verde, que el avance sea 77%, ni ninguna de las cifras de compromiso, ejecución y proyección: el informe de avance es la única fuente de esas cifras y es una declaración. Las fuentes del proyecto, por tipo: 0 evidencia, 3 declaración, 16 sin marcar.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Andrés Lozano | `00-gobierno/2025-09-14-acta-constitucion.md` |
| Gerente | Carlos Peña | misma acta; también informe de avance, actas de recibo y minuta |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente en fechas, dinero o alcance | — |
| Comité | Comité de Operaciones (aprobó el presupuesto el 2025-09-14, según el acta) | acta; minuta `30-reuniones/2026-10-19-comite-semanal.docx` |

Sin autoridad declarada no hay desviación aprobada. Además:
- El alcance del acta son «Componente 1, 2, 3» y la exclusión es «lo que otro proyecto cubre». Ninguno de los dos se puede verificar.
- El criterio de éxito («en producción y medido») no tiene métrica.
- El acta declara «Ninguna» dependencia.
- El contrato CT-326 se firmó el 2025-09-04, antes de la aprobación del acta (2025-09-14) y del inicio (2025-09-24).
- No hay acta del comité que apruebe el presupuesto. Lo dice solo el acta de constitución.

### Contra el plan
- **Línea base original:** versión 1, aprobada el 2025-09-14, cierre 2026-04-06 (`10-plan/2025-09-14-cronograma-v1.csv`).
- **Vigente:** la misma. Replanificaciones: 0. Control de cambios: 0 solicitudes en la carpeta.
- **El script reporta desviación 0 días** contra la original y la vigente. Ese 0 solo dice que nadie movió las fechas. No dice que se cumplieron: el cierre planeado (2026-04-06) ya pasó.
- Las actas de recibo de los dos últimos hitos tienen fecha muy posterior a la planeada. Por eso el cronograma deja de describir la realidad (ver Contradicho). El script no calcula esos días y no los escribo.
- El CSV se llama v1 y está fechado 2025-09-14, pero marca como «cerrado» hitos que vencen hasta abril de 2026. Esa columna se editó después, sin fecha ni autor.

### Hitos vencidos sin evidencia
Son hitos que el cronograma marca como cerrados y para los que no hay ningún documento de cierre.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-11-01 | 356 | Acta o aprobación de ingeniería básica |
| Ingeniería de detalle aprobada | 2025-12-10 | 317 | Acta o aprobación de ingeniería de detalle |
| Licencia y permisos obtenidos | 2026-01-18 | 278 | Licencia o resolución de permisos |

Entregables del proveedor (CT-326, Equipos Pesados Andinos), contra la condición de pago «cada entregable se factura contra acta de recibo firmada por el gerente»:

| Entregable | Vence | Días | Estado en el contrato | Acta de recibo |
|---|---|---|---|---|
| Licenciamiento del software | 2025-11-05 | 352 | pendiente | no hay |
| Bolsa de horas de ingeniería | 2025-12-18 | — | recibido | sí, 2026-01-07 |
| Calibración de sensores | 2026-01-30 | — | recibido | **no hay** |
| Soporte del primer trimestre | 2026-03-14 | 223 | pendiente | no hay |

Los hitos Montaje e instalación y Pruebas en operación sí tienen acta de recibo (2026-10-21 y 2026-10-11). Estas actas no citan el contrato ni nombran a quien ejecutó el trabajo. El contrato tampoco tiene esos hitos como entregables.

### Dinero
COP, del informe de avance 2026-10-18 (declaración) y del cálculo del script.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.356.662.777 (56,5 %) | 446.036.134 (18,6 %) | 2.479.870.475 (3,3 % sobre lo aprobado) | 1.043.337.223 |

- Facturado a CT-326: **551.792.512** (FV-1326, 2026-09-02, «radicada en cuentas por pagar»). Cada entregable del contrato vale 275.896.256, y solo hay acta de recibo de uno.
- El ejecutado declarado (446.036.134) es menor que esa sola factura (551.792.512). Puede ser que la factura esté radicada pero no pagada. Ningún documento lo aclara.
- Ninguna de las cuatro cifras del informe cita un libro, un contrato o una orden. No pude reconstruirlas desde los documentos.
- La proyección ya supera lo aprobado. El proyecto no tiene autoridad declarada para absorber ese exceso, aunque no pase el umbral del 10 %.

### Lo que se dijo y nadie registró
- **Incidencia sin dueño ni fecha:** «Se levantó un hallazgo en la auditoría de seguridad» (informe 2026-10-18). No hay informe de auditoría ni plan de cierre. Nadie lo registra en un RAID. En la carpeta tampoco hay un registro RAID.
- **Riesgo mal clasificado:** «El proveedor no ha confirmado la fecha de la última entrega». Dos entregables ya vencieron (352 y 223 días). Eso es una incidencia materializada, no un riesgo. No tiene dueño, probabilidad ni impacto.
- **Compromisos de la minuta del 2026-10-19:**
  - Liliana Torres: «Entregar el punto 4», para 2026-10-23 (vence hoy; todavía no está vencido).
  - Beatriz Cuéllar: «Entregar el punto 33», fecha «por definir» (sin fecha, así que no puede vencer).
  - Ninguna de las dos personas aparece en el acta ni en otro documento del proyecto. «Punto 4» y «punto 33» no se resuelven a ningún documento.
- La minuta lista «Avance» como tema pero no registra qué se dijo. No menciona los entregables vencidos, el hallazgo de seguridad, la fecha de cierre ya pasada ni la factura.
- Dependencias: ninguna registrada. El proveedor es, de hecho, una dependencia crítica.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado «Verde» | `2026-10-18-informe-avance.pdf`: Verde, sin mencionar atrasos | `2025-09-04-contrato-ct-326.docx`: dos entregables pendientes con fecha vencida (352 y 223 días). El script marca la declaración como no respaldada por la evidencia. |
| Avance 77 % | Informe de avance: 77 % | `2025-09-14-cronograma-v1.csv`: 5 de 5 hitos «cerrado». El plan sostendría 100 %, una diferencia de 23 puntos. Ojo: ese estado del CSV tampoco tiene fecha ni sustento propio. |
| Las fechas vigentes (2026-02-26 y 2026-04-06) son las reales | Cronograma: fecha vigente = línea base, sin replanificación | Actas de recibo: Montaje e instalación 2026-10-21; Pruebas en operación 2026-10-11. Además, las pruebas se recibieron antes que el montaje, al revés del orden del plan. |

### Sin sustento
Ninguna de estas afirmaciones tiene un documento que la contradiga o la respalde:
1. Comprometido 1.356.662.777: no hay contratos ni órdenes que sumen eso. El script no suma los montos del contrato y no escribo esa cifra.
2. Ejecutado 446.036.134: no hay libro ni comprobantes.
3. Proyección 2.479.870.475: no hay método ni supuestos.
4. Ingeniería básica aprobada: no hay documento.
5. Ingeniería de detalle aprobada: no hay documento.
6. Licencia y permisos obtenidos: no hay documento.
7. Calibración de sensores «recibido»: no hay acta, y el contrato lo exige para facturar. Este estado además figura en un contrato fechado antes de la entrega.
8. Que la factura FV-1326 (551.792.512) esté respaldada por actas de recibo, como pide CT-326: hay un acta (Bolsa de horas) y la factura cubre dos entregables.
9. Que exista un hallazgo de auditoría de seguridad, su alcance y su estado: solo lo dice el informe.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en verde.** Solo hay una declaración. Los hechos documentados (dos entregables vencidos, cierre planeado vencido y sin replanificar) apuntan en otra dirección. Cualquier semáforo que se presente al comité hoy no tendría sustento.
- **Cuánto se ha gastado de verdad.** Sin libro ni comprobantes, el ejecutado y el comprometido no se verifican, y tampoco si la factura de 551.792.512 ya se pagó. Si se aprobara su pago sin actas, se pagaría un entregable sin recibo.
- **Quién autoriza qué.** El acta no declara la autoridad del gerente. Una replanificación o un exceso sobre lo aprobado no tendría a quién atribuirse.
- **Qué incluye el proyecto.** El alcance son tres «componentes» sin nombre. Sin eso no se puede decir qué significa «terminado» ni medir el 77 %.
- **Quién hizo el montaje y las pruebas, y bajo qué contrato.** Las actas no lo dicen.
- **Qué pasó entre 2026-01-07 y 2026-09-02.** No hay ningún documento en ese periodo (silencio del proyecto, no solo de quien reporta). La carpeta se reactiva después, con las facturas, actas e informe de septiembre y octubre.
- **Qué es el hallazgo de seguridad y si bloquea el cierre.**
- **Si PRY-200 comparte proveedor, personal o recursos con PRY-209** (mismo proveedor, contrato CT-611): ningún documento lo dice.

Los conteos y las cifras salen del script `compute` (con corte 2026-10-23), salvo el conteo de afirmaciones, que es mío. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

**Siguiente paso posible:** preparar el punto de comité con la lista de lo que falta, o llevar al gerente las contradicciones como preguntas, una por una.

*Pie de rigor: este diagnóstico es un borrador de trabajo, no una decisión ni una asesoría. Se basa solo en los 9 documentos leídos y no sabe lo que se habló fuera de ellos. Cada dato está citado al documento de donde sale. Verificarlo es responsabilidad de quien lo use. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
