**Sale de:** la ficha `estado/records/PRY-200.json` (actualizada 2026-10-23), el cálculo de `portafolio.py compute` (corte 2026-10-23) y los 9 documentos de la carpeta del proyecto: acta de constitución, contrato CT-326, cronograma v1, informe de avance del 2026-10-18, factura FV-1326, tres actas de recibo y el comité del 2026-10-19. Términos v1.2 vigentes, aceptados por José Francisco Ñáñez (2026-10-23).

## Cierre — PRY-200 Mantenimiento predictivo de camiones — 2026-10-23

**Veredicto: el cierre no se puede declarar por cumplimiento.** El criterio de éxito sí fue declarado, pero ningún documento permite decir si se cumplió. Si el proyecto se cierra ahora, se cierra por decisión de quien tenga la autoridad (la ficha no la encuentra), no contra el criterio pactado. El estado declarado sigue en verde (informe del 2026-10-18), y el cálculo lo contradice con 3 señales abiertas.

### Contra lo comprometido
**Criterio de éxito:** "Mantenimiento predictivo de camiones en producción y medido." (acta de constitución, 2025-09-14, `00-gobierno/2025-09-14-acta-constitucion.md`)
**Se cumplió:** **no se puede determinar.** No hay ningún documento que muestre el sistema en producción ni una medición. El acta de "Pruebas en operación" (2026-10-11) dice solo "se recibe a satisfacción", sin resultados ni métrica. Pruebas en operación no equivale a producción medida.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato: el acta no los nombra | Ninguna |
| Componente 2 | Sin dato | Ninguna |
| Componente 3 | Sin dato | Ninguna |

El acta lista "Componente 1, 2 y 3" sin describirlos. Por eso no se puede contrastar entregado contra comprometido en alcance. Lo único contrastable son los 5 hitos del cronograma v1:

| Hito | Línea base | Estado en el cronograma | Evidencia de cierre |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-11-01 | cerrado | **Ninguna** |
| Ingeniería de detalle aprobada | 2025-12-10 | cerrado | **Ninguna** |
| Licencia y permisos obtenidos | 2026-01-18 | cerrado | **Ninguna** |
| Montaje e instalación | 2026-02-26 | cerrado | Acta de recibo del 2026-10-21 (Carlos Peña) |
| Pruebas en operación | 2026-04-06 | cerrado | Acta de recibo del 2026-10-11 (Carlos Peña) |

Tres de los cinco hitos figuran cumplidos sin un solo documento que lo sustente. Los dos con acta se recibieron con meses de diferencia sobre la fecha comprometida (2026-10-21 contra 2026-02-26, y 2026-10-11 contra 2026-04-06). Además, el acta de Montaje es posterior a la de Pruebas en operación y posterior al informe del 2026-10-18; el orden no es el del plan. El cronograma sigue mostrando como "vigente" la fecha original en los cinco hitos.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato: el acta solo dice "Lo que otro proyecto cubre", sin nombrar qué ni qué proyecto | — | — |

Control de cambios: 0 solicitudes registradas. No hay alcance recortado con decisión registrada, y tampoco se puede descartar que se haya recortado: sin el detalle de los 3 componentes no hay contra qué compararlo.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-04-06 | 2026-04-06 | Sin dato (el último hito con acta es 2026-10-11, y Montaje, 2026-10-21, es posterior) | El script da 0 días porque compara fechas planeadas, no recibidas. La desviación real no está calculada |
| Presupuesto (COP) | 2.400.000.000 aprobado | 2.400.000.000 | Sin cierre contable. Al corte del 2026-10-18: ejecutado 446.036.134; comprometido 1.356.662.777; proyección 2.479.870.475 | Proyección 3.3 % sobre lo aprobado |

Replanificaciones: **0**. Hay una sola línea base (v1, 2025-09-14), y la fecha comprometida ya pasó hace más de seis meses sin ningún cambio registrado ni aprobado.

Ejecutado 18.6 % y comprometido 56.5 % del aprobado, mientras el informe reporta 77 % de avance y el plan da 100 % por hitos. Las dos cifras no cuadran entre sí (brecha de 23.0 puntos). Además, el proveedor tiene facturados 551.792.512 COP (FV-1326, 2026-09-02), que es más que el ejecutado reportado de 446.036.134; ese informe no explica la diferencia.

### RAID al cierre
**Materializados:** ninguno documentado como tal. El informe dice "Se levantó un hallazgo en la auditoría de seguridad" (incidencia, sin fecha, sin responsable).
**No materializados:** sin dato; nadie registró qué riesgos se evaluaron.
**Abiertos, sin doliente (por eso no están cerrados):**
- Riesgo: "El proveedor no ha confirmado la fecha de la última entrega". Sin probabilidad, impacto, responsable ni fecha. El informe no dice cuál es esa última entrega.
- Incidencia: hallazgo de la auditoría de seguridad. Sin responsable, sin fecha de apertura ni estado de resolución.
- Compromiso de Liliana Torres, "Entregar el punto 4", vence hoy (2026-10-23), sin evidencia aún. Liliana Torres no figura entre los asistentes al comité.
- Compromiso de Beatriz Cuéllar, "Entregar el punto 33", sin fecha ("por definir"). Tampoco asistió al comité del 2026-10-19.
- "Punto 4" y "punto 33" no se pueden ubicar en ningún documento.

**Proveedor Equipos Pesados Andinos (CT-326):** 2 de 4 entregables pendientes y vencidos: Licenciamiento del software (comprometido 2025-11-05, 352 días de atraso) y Soporte del primer trimestre (2026-03-14, 223 días). El contrato no se puede cerrar con esto pendiente.
- Calibración de sensores figura aceptada, pero no hay acta de recibo. El contrato condiciona la facturación a un acta firmada por el gerente.
- Solo hay acta para la Bolsa de horas (2026-01-07). Sin embargo, la factura de 551.792.512 COP equivale a dos entregables.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marcó como "cerrados" 3 hitos sin acta ni evidencia (ingeniería básica, de detalle y licencia) | Fechas comprometidas 2025-11-01, 2025-12-10 y 2026-01-18; sin evidencia al 2026-10-23 | El avance se reporta como 100 % por hitos y 77 % declarado, sin documento que decida entre ambos | Exigir un acta o un documento de aprobación enlazado a cada hito antes de marcarlo cerrado |
| La calibración de sensores se aceptó y se facturó junto con la bolsa de horas, con un solo acta de recibo | Entrega comprometida 2026-01-30; factura 2026-09-02 | Se facturaron 551.792.512 COP contra una sola acta; el efecto sobre el pago es lo que debe verificar quien apruebe | Verificar la existencia del acta firmada de cada entregable antes de radicar la factura (condición del propio contrato) |
| El acta definió el alcance como "Componente 1, 2 y 3" y la exclusión como "lo que otro proyecto cubre" | 2025-09-14 | Hoy no es posible decir qué se entregó ni qué quedó por fuera | Describir cada componente y nombrar cada exclusión en el acta, antes de aprobarla |
| Pasó la fecha de cierre sin replanificar, sin solicitud de cambio y sin nueva línea base | 2026-04-06 en adelante | Los hitos se recibieron en octubre con la fecha de abril aún vigente; el atraso real no consta en ningún registro | Abrir un cambio y fijar nueva línea base cuando el plan vigente ya no se sostiene |

No incluyo lecciones sobre causas (por qué hubo atraso o por qué no se recibió Licenciamiento): ningún documento lo explica.

### Sin dato
- Si el sistema está en producción y qué se midió (el criterio de éxito).
- Qué son los 3 componentes del alcance y qué se excluyó.
- Evidencia de los hitos Ingeniería básica, Ingeniería de detalle y Licencia y permisos.
- Fecha real de cada hito y la desviación real en días contra la línea base original.
- Costo final y cierre contable; por qué lo facturado supera lo ejecutado.
- Acta de recibo de la Calibración de sensores; estado de Licenciamiento y Soporte.
- Quién tiene autoridad para declarar el cierre (campo `identity.authority` no encontrado) y la fase actual (`identity.phase`).
- Responsables y fechas del riesgo y la incidencia abiertos.
- Qué son el "punto 4" y el "punto 33".

### Después
Ofrezco **no** mover la carpeta a `archivo/` todavía: con riesgo e incidencia sin doliente y 2 entregables del proveedor pendientes, sacarlo del barrido diario lo dejaría en silencio. Tomo esa opción por defecto, porque no hay quien responda. Para cerrar hace falta: (1) evidencia del criterio de éxito o una decisión expresa de cerrar sin él, (2) doliente para el riesgo y la incidencia, (3) el estado de CT-326, (4) la autoridad que firma el cierre.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados y la verificación es de quien lo lea. Las cifras derivadas se copiaron de `portafolio.py compute`; las que el script no da (días de atraso real, costo final) quedan declaradas como sin dato.*
