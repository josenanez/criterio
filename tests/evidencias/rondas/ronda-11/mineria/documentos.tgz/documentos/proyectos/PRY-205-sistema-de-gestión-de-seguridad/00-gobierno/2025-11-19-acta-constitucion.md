# Acta de constitución · Sistema de gestión de seguridad

**Código:** PRY-205
**Área dueña:** Mina
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-19

## Objetivo del negocio

Entregar sistema de gestión de seguridad para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Operaciones el 2025-11-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-29 |
| Cierre | 2026-08-12 |

## Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

## Dependencias declaradas

- Ninguna declarada
