# Comité de Operaciones · Ampliación de la relavera

**Fecha:** 2026-10-16
**Asistentes:** Diana Molina, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 19 | 2026-11-02 |
