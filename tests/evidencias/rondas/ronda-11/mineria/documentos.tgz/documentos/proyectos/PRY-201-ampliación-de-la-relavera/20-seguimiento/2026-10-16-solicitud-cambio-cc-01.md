# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Ampliación de la relavera
**Fecha:** 2026-10-16
**Solicitante:** Diana Molina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +61 días sobre la línea base vigente |
| Costo | 122.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
