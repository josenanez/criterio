# Comité de Inversiones · Planta de tratamiento de agua

**Fecha:** 2026-10-22
**Asistentes:** Ricardo Salas, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 37 | por definir |
