# Comité de Inversiones · Monitoreo de taludes

**Fecha:** 2026-09-10
**Asistentes:** Andrés Lozano, Elena Duarte, Jorge Medina, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | por definir |
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-08 |
| Elena Duarte | Revisar el anexo 3 | 2026-09-13 |
| Jorge Medina | Validar el ambiente 4 | 2026-09-30 |
