# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-12
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +34 días sobre la línea base vigente |
| Costo | 68.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
