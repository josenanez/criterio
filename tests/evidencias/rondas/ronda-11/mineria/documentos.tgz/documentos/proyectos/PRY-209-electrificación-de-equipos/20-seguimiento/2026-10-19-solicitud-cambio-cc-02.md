# Solicitud de cambio CC-02

**Proyecto:** PRY-209 · Electrificación de equipos
**Fecha:** 2026-10-19
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +115 días sobre la línea base vigente |
| Costo | 230.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
