# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Seguridad y Salud
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-06-02

## Objetivo del negocio

Entregar planta de tratamiento de agua para Seguridad y Salud.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Inversiones el 2026-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-12 |
| Cierre | 2027-03-04 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
