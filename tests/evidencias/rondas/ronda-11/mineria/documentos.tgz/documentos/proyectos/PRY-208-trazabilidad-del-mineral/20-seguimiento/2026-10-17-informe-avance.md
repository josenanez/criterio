# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-17
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **83%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se acordó con operaciones el plan de arranque de los equipos

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.004.860.656 |
| Ejecutado | 1.889.383.315 |
| Proyección al cierre | 6.959.303.783 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
