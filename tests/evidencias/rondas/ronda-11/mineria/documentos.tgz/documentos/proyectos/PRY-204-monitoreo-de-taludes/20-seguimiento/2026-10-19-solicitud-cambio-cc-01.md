# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Monitoreo de taludes
**Fecha:** 2026-10-19
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +84 días sobre la línea base vigente |
| Costo | 168.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
