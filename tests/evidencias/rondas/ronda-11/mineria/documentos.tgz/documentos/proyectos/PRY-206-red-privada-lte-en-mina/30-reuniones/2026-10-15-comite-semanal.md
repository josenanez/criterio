# Comité de Tecnología · Red privada LTE en mina

**Fecha:** 2026-10-15
**Asistentes:** Carlos Peña, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 24 | 2026-10-23 |
