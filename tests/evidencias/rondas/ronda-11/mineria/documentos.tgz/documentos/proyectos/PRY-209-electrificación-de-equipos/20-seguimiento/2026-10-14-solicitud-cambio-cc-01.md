# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Electrificación de equipos
**Fecha:** 2026-10-14
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +96 días sobre la línea base vigente |
| Costo | 192.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
