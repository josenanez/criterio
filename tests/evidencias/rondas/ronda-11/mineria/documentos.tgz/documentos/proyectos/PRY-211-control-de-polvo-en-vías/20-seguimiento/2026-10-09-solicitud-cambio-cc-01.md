# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Control de polvo en vías
**Fecha:** 2026-10-09
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +43 días sobre la línea base vigente |
| Costo | 86.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
