# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Tecnología
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Operaciones
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-07-03

## Objetivo del negocio

Entregar despacho automático de flota para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Operaciones el 2025-07-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-13 |
| Cierre | 2026-04-13 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
