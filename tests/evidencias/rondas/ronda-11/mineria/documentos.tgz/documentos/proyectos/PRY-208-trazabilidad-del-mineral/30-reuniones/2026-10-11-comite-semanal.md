# Comité Ambiental · Trazabilidad del mineral

**Fecha:** 2026-10-11
**Asistentes:** Paula Céspedes, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 25 | 2026-11-07 |
