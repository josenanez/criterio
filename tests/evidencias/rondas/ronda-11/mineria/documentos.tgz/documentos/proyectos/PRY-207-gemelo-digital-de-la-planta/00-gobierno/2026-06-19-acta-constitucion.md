# Acta de constitución · Gemelo digital de la planta

**Código:** PRY-207
**Área dueña:** Medio Ambiente
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Operaciones
**Producto asociado:** gemelo digital
**Fecha de aprobación:** 2026-06-19

## Objetivo del negocio

Entregar gemelo digital de la planta para Medio Ambiente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Operaciones el 2026-06-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-29 |
| Cierre | 2027-06-04 |

## Criterio de éxito

Gemelo digital de la planta en producción y medido.

## Dependencias declaradas

- Ninguna declarada
