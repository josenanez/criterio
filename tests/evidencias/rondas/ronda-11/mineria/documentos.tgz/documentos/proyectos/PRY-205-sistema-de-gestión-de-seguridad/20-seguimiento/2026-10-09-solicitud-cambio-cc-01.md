# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-09
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +85 días sobre la línea base vigente |
| Costo | 170.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
