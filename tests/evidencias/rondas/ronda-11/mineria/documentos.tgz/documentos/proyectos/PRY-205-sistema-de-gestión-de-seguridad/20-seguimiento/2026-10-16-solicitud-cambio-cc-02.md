# Solicitud de cambio CC-02

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-16
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +46 días sobre la línea base vigente |
| Costo | 92.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
