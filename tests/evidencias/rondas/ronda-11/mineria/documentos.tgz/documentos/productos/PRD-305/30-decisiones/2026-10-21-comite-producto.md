# Comité de producto · Alerta de fatiga

**Fecha:** 2026-10-21
**Asistentes:** Natalia Ospina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-13 | — |
| REQ-4501 | Requerimiento REQ-4501 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-25 | — |
| REQ-4502 | Requerimiento REQ-4502 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4503 | Requerimiento REQ-4503 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-02 | — |
| REQ-4504 | Requerimiento REQ-4504 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4506 | Requerimiento REQ-4506 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-20 | — |
| REQ-4507 | Requerimiento REQ-4507 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-06 | — |
| REQ-4508 | Requerimiento REQ-4508 | Jorge Medina | se verifica en producción | — | aceptado | 2026-08-28 | — |
| REQ-4509 | Requerimiento REQ-4509 | Laura Vélez | se verifica en producción | — | propuesto | 2026-05-16 | — |
| REQ-4510 | Requerimiento REQ-4510 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4511 | Requerimiento REQ-4511 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-28 | — |
| REQ-4512 | Requerimiento REQ-4512 | Paula Céspedes | — | — | aceptado | 2026-04-18 | — |
| REQ-4513 | Requerimiento REQ-4513 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-23 | — |

## Decisiones

- Se mantiene el plan
