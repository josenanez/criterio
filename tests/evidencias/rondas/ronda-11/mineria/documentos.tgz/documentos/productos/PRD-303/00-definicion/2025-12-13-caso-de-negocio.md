# Caso de negocio · Gemelo digital

**Código:** PRD-303
**Fecha:** 2025-12-13
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 121.511 | Caso de negocio, 2025-12-13 |

## Retorno esperado

Retorno esperado en 24 meses.
