# Comité de producto · Alerta de taludes

**Fecha:** 2026-10-16
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | sin asignar | — | Cliente entrevistado | aceptado | 2026-04-23 | — |
| REQ-4101 | Requerimiento REQ-4101 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4102 | Requerimiento REQ-4102 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-06-07 | — |
| REQ-4103 | Requerimiento REQ-4103 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-20 | — |
| REQ-4104 | Requerimiento REQ-4104 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-06-24 | — |
| REQ-4105 | Requerimiento REQ-4105 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-16 | — |
| REQ-4106 | Requerimiento REQ-4106 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-16 | — |
| REQ-4107 | Requerimiento REQ-4107 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-4108 | Requerimiento REQ-4108 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-04 | — |
| REQ-4109 | Requerimiento REQ-4109 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-24 | — |
| REQ-4110 | Requerimiento REQ-4110 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-08-09 | — |
| REQ-4111 | Requerimiento REQ-4111 | Sandra Gil | — | — | aceptado | 2026-09-04 | — |
| REQ-4112 | Requerimiento REQ-4112 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-27 | — |
| REQ-4113 | Requerimiento REQ-4113 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-22 | — |
| REQ-4114 | Requerimiento REQ-4114 | sin asignar | se verifica en producción | — | aceptado | 2026-05-22 | — |
| REQ-4115 | Requerimiento REQ-4115 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-04-29 | — |
| REQ-2030 | Requerimiento REQ-2030 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-26 | — |
| REQ-2038 | Requerimiento REQ-2038 | Diana Molina | se verifica en producción | — | aceptado | 2026-10-04 | — |

## Decisiones

- Se mantiene el plan
