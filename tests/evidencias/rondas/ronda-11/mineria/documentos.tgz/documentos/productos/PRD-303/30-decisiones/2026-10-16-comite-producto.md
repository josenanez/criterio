# Comité de producto · Gemelo digital

**Fecha:** 2026-10-16
**Asistentes:** Liliana Torres

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-04-29 | — |
| REQ-4301 | Requerimiento REQ-4301 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4302 | Requerimiento REQ-4302 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-29 | — |
| REQ-4303 | Requerimiento REQ-4303 | Paula Céspedes | — | — | aceptado | 2026-04-13 | — |
| REQ-4304 | Requerimiento REQ-4304 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4305 | Requerimiento REQ-4305 | Andrés Lozano | se verifica en producción | — | propuesto | 2026-08-21 | — |
| REQ-4306 | Requerimiento REQ-4306 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-05-03 | — |
| REQ-4307 | Requerimiento REQ-4307 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4308 | Requerimiento REQ-4308 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-23 | — |
| REQ-4309 | Requerimiento REQ-4309 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-21 | — |
| REQ-4310 | Requerimiento REQ-4310 | Óscar Ramírez | — | Cliente entrevistado | propuesto | 2026-08-26 | — |
| REQ-4311 | Requerimiento REQ-4311 | Sandra Gil | — | — | aceptado | 2026-04-11 | — |
| REQ-4312 | Requerimiento REQ-4312 | Jorge Medina | se verifica en producción | — | aceptado | 2026-06-07 | — |
| REQ-4313 | Requerimiento REQ-4313 | sin asignar | — | Cliente entrevistado | aceptado | 2026-08-16 | — |

## Decisiones

- Se mantiene el plan
