# Comité de producto · Reporte ambiental

**Fecha:** 2026-10-20
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4701 | Requerimiento REQ-4701 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-05-11 | — |
| REQ-4702 | Requerimiento REQ-4702 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4703 | Requerimiento REQ-4703 | sin asignar | se verifica en producción | — | aceptado | 2026-08-22 | — |
| REQ-4704 | Requerimiento REQ-4704 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-08 | — |
| REQ-4705 | Requerimiento REQ-4705 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-01 | — |
| REQ-4706 | Requerimiento REQ-4706 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4707 | Requerimiento REQ-4707 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4708 | Requerimiento REQ-4708 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4709 | Requerimiento REQ-4709 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-08-26 | — |
| REQ-4710 | Requerimiento REQ-4710 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-30 | — |
| REQ-4711 | Requerimiento REQ-4711 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-06-29 | — |
| REQ-4712 | Requerimiento REQ-4712 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-26 | — |
| REQ-4713 | Requerimiento REQ-4713 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-04 | — |

## Decisiones

- Se mantiene el plan
