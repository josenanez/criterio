# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-04-27
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.318 | Caso de negocio, 2026-04-27 |

## Retorno esperado

Retorno esperado en 24 meses.
