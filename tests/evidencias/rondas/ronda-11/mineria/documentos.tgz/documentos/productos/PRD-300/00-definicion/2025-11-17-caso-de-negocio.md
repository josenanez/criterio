# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2025-11-17
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 56.157 | Caso de negocio, 2025-11-17 |

## Retorno esperado

Retorno esperado en 24 meses.
