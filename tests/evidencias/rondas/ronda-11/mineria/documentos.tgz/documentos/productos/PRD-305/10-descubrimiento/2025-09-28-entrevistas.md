# Entrevistas · Alerta de fatiga

**Ronda:** Ronda · 2025-09-28
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2025-09-28

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
