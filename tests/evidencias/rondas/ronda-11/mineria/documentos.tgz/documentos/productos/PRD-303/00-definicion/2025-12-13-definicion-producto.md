# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Liliana Torres
**Segmento:** Supervisores
**Fecha de la definición:** 2025-12-13

## El problema

El segmento Supervisores no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-06-27 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
