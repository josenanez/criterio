# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-10-10
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 266.071 | Caso de negocio, 2025-10-10 |

## Retorno esperado

Retorno esperado en 24 meses.
