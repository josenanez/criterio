# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-03-17
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 270.035 | Caso de negocio, 2026-03-17 |

## Retorno esperado

Retorno esperado en 24 meses.
