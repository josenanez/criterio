# Tablero de métricas · Almacén de repuestos

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 153.763 | 2026-10-06 |
