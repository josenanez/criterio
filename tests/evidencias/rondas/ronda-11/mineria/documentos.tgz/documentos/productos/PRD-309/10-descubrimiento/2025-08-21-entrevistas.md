# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2025-08-21
**Realizadas por:** Laura Vélez

### Cliente entrevistado · 2025-08-21

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
