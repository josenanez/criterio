# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Laura Vélez
**Segmento:** Supervisores
**Fecha de la definición:** 2026-03-17

## El problema

El segmento Supervisores no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-05-15 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
