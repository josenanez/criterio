# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2025-09-04
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 288.668 | Caso de negocio, 2025-09-04 |

## Retorno esperado

Retorno esperado en 24 meses.
