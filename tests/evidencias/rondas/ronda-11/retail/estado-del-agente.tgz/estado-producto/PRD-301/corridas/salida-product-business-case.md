# Caso de negocio — Puntos de fidelización (PRD-301) · borrador del 2026-10-23
**Desde:** la definición del 2025-12-18 y el caso de negocio del 2025-12-18 · **Cifras con fuente:** 2 de 2 cifras numéricas (1 declarada, 1 medida). El retorno esperado no tiene cifra: va a vacíos.

Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Es un borrador de trabajo: la verificación de cada cita es de quien lo lee.

## Qué problema resuelve, y para quién
«El segmento Jóvenes no tiene puntos de fidelización.» (`00-definicion/2025-12-18-definicion-producto.md`, 2025-12-18). Propuesta: «Propuesta principal», sin más detalle. Evidencia de demanda a la vista: una sola entrevista, de un cliente (sin segmento indicado), del 2025-08-29: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-29-entrevistas.docx`). Tiene 14 meses y no dice que el cliente sea del segmento Jóvenes.

## Qué se construye
Decididos = requerimientos en estado aceptado: 12 de 17 (los otros 5 están propuestos y no entran al caso). Fuente: `30-decisiones/2026-10-20-comite-producto.md`.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4100, 4101, 4102, 4103, 4106, 4107, 4109, 4110, 4111, 4112 | aceptado | «Cliente entrevistado» (comité); la entrevista de 2025-08-29 no nombra ninguno de estos requerimientos |
| REQ-4115, REQ-2030 | aceptado | Sin quién lo pidió (comité: «—») ni evidencia |

Ninguno tiene proyecto que lo ejecute (columna «Proyecto» del comité: «—»; la definición dice «Ninguno declarado»). REQ-4103 no tiene doliente. Sin criterio de aceptación: REQ-4101, 4103, 4106, 4109, 4110. El comité no registra quién decidió cada aceptación.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (caso) | 297.074 | Declarada | `00-definicion/2025-12-18-caso-de-negocio.md` (Beatriz Cuéllar) | 2025-12-18 |
| volumen_mensual (serie) | 310.136 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-11-tablero-metricas.md`) | corte 2026-10-11 |
| Retorno esperado | «en 24 meses», sin valor | — (no es cifra) | Caso de negocio, 2025-12-18 | 2025-12-18 |
| Tiendas soportan el volumen | — | Supuesta | Definición, declarado 2026-06-26 | sin verificar |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 297.074 | 310.136 | Caso de negocio 2025-12-18 · tablero de producto, corte 2026-10-11 |

La diferencia es de 13.062 (4,4 % sobre lo declarado), por debajo del umbral de 20 % de la configuración: no es hallazgo por umbral, pero va dentro del caso. La serie medida tiene un solo punto: no hay tendencia y no se puede decir si 297.074 era una proyección o una medición de entonces. Además, el producto aún no tiene proyecto declarado y el caso habla de «volumen mensual» sin decir de qué (transacciones, puntos, clientes): ese es un vacío.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | No existe en ningún documento | — |
| Costo del equipo, contratos, cotizaciones | No existe en ningún documento | — |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta. Es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| Las tiendas soportan el volumen (declarado 2026-06-26, sin verificar; 119 días a la fecha, umbral 30) | Sin dato en los documentos | Sin dueño nombrado; lo debe asignar la gerente de producto |
| El segmento Jóvenes es el de la entrevista (implícito) | La demanda a la vista no sería de este segmento | Quien hizo la ronda de entrevistas (Beatriz Cuéllar) |
| Cada requerimiento aceptado responde a demanda (implícito) | Se construiría sin pedido | Los dolientes de cada requerimiento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso evaluable | Beatriz Cuéllar / finanzas, por confirmar |
| Valor del retorno esperado y qué se mide como retorno | «Retorno en 24 meses» no es una cifra; no se calcula aquí | El negocio |
| Qué cuenta el «volumen mensual» y de dónde salió 297.074 | Sin definición no se sabe si declarada y medida son la misma cosa | Beatriz Cuéllar |
| Qué pasa si no se hace; alternativas consideradas | El comité no tiene contra qué comparar | El negocio |
| Cuándo se sabrá si funcionó (métrica de éxito y fecha de corte) | No hay criterio verificable meses después | Comité de producto |
| Proyecto que construye el producto | Ningún requerimiento tiene proyecto; sin él no hay costo ni plazo | Comité de producto |
| Dolientes y criterios de aceptación faltantes (ver arriba) | Requerimientos aceptados sin poder verificarse | Dolientes respectivos |

## Cómo se sabrá si funcionó
No está declarado. El caso solo dice «Retorno esperado en 24 meses», sin métrica ni fecha de corte. El único candidato con serie es volumen_mensual, pero ningún documento lo declara como criterio de éxito. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno a la vista (la carpeta de fichas `estado/records` no existe), así que no se hizo el cruce de métricas con otros productos. Cuando se publiquen, hay que revisar si afirman el mismo volumen_mensual.

## Después
Se ofrece pasar los 3 supuestos al seguimiento con assumption-tracking, y, si el caso se aprueba, `/criterio-product:product-charter`. Este documento no recomienda aprobar ni rechazar.
