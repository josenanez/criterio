<!-- origen: 20-metricas/2026-10-11-tablero-metricas.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Tablero de métricas · Puntos de fidelización

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 310.136 | 2026-10-11 |
