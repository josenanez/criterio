# Corrida del 2026-10-23 · product-requirements

PRD-301 · 17 requerimientos · 29 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

12 aceptados sin proyecto ni decisor registrado; 2 sin evidencia; 5 sin criterio; 2 sin doliente; 4 propuestos sin decidir; evidencia de 13 meses

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Registro — Puntos de fidelización (PRD-301) · al 2026-10-23
17 requerimientos · 12 decididos · 83.3% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió.

| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado (2026-10-03) | Javier Hoyos |
| REQ-4115 | Requerimiento REQ-4115 | aceptado (2026-08-17) | Liliana Torres |

### Decidido y nadie lo está construyendo
Los 12 aceptados: ninguno tiene proyecto que lo ejecute (la columna «Proyecto» del acta del 2026-10-20 es «—» en todos y no hay fichas de proyecto en `estado/records`).

| REQ | Decidido el |
|---|---|
| REQ-4112 | 2026-04-04 |
| REQ-4103 | 2026-05-01 |
| REQ-4107 | 2026-05-17 |
| REQ-4106 | 2026-05-29 |
| REQ-4101 | 2026-08-05 |
| REQ-4111 | 2026-08-05 |
| REQ-4100 | 2026-08-06 |
| REQ-4102 | 2026-08-10 |
| REQ-4115 | 2026-08-17 |
| REQ-4109 | 2026-08-26 |
| REQ-4110 | 2026-09-02 |
| REQ-2030 | 2026-10-03 |

### Sin doliente, o con un área en vez de una persona
| REQ | Estado | Dice |
|---|---|---|
| REQ-4103 | aceptado | «sin asignar» |
| REQ-4105 | propuesto | «sin asignar» |

Quién lo cierra: Beatriz Cuéllar (gerente de producto) asigna la persona.

### Sin criterio de aceptación
Solo los decididos.

| REQ | Estado |
|---|---|
| REQ-4101 | aceptado |
| REQ-4103 | aceptado |
| REQ-4106 | aceptado |
| REQ-4109 | aceptado |
| REQ-4110 | aceptado |

Quién lo cierra: el doliente de cada uno (REQ-4103 no tiene; lo asigna Beatriz Cuéllar primero).

### Decidido sin documento que lo respalde
Los 12 aceptados tienen estado y fecha en el acta del 2026-10-20, pero ninguno registra quién decidió. El acta solo dice «Se mantiene el plan» y lista a Beatriz Cuéllar como única asistente.

| REQ | Quién decidió | Cuándo |
|---|---|---|
| Los 12 aceptados (lista arriba) | sin registrar | las fechas de arriba |

### Lleva meses y nadie lo decide
Umbral: 60 días. Quién tiene la facultad: el Comité de producto (autoridad configurada).

| REQ | Propuesto hace | Quién tiene la facultad |
|---|---|---|
| REQ-4104 | 186 días (2026-04-20) | Comité de producto |
| REQ-4108 | 117 días (2026-06-28) | Comité de producto |
| REQ-4105 | 113 días (2026-07-02) | Comité de producto |
| REQ-4113 | 75 días (2026-08-09) | Comité de producto |

Se propone decidirlos (aceptar o descartar). Ninguno se cierra por viejo.

### Evidencia vieja
Umbral: 12 meses. Toda la evidencia es la misma ronda de entrevistas del 2025-08-29, de hace 13 meses, y no nombra ningún requerimiento.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4100, 4101, 4102, 4103, 4106, 4107, 4109, 4110, 4111, 4112 | entrevista 2025-08-29 | 13 meses |
| REQ-4105, 4108, 4113, 4114 (propuestos) | entrevista 2025-08-29 | 13 meses |

### Además
- Supuesto sin verificar: «Las tiendas soportan el volumen», 119 días.
- La definición no tiene criterio de éxito (`success` sin dato).
- Volumen mensual: el caso de negocio declara 297.074 y el tablero del 2026-10-11 mide 310.136 (diferencia 4.4%, bajo el umbral de 20%).

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 12 | 0 | 0 | 0 |

Siguiente paso posible: `/product-trace` para los 12 decididos que nadie construye. Para pasar a `/product-charter` hay que elegir un aceptado con evidencia y criterio; los candidatos son REQ-4100, 4102, 4107, 4111 y 4112 (evidencia vieja incluida).
