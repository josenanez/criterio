## Puntos de fidelización (PRD-301) · 2026-10-23

**Primera corrida del reloj: no había corte anterior, así que no hay "nuevas desde". Esto es la línea base; desde la próxima corrida solo se reportará lo que cruce un umbral después de hoy.** Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Tocaba `review`; próximo despertar: 2026-11-22.

### Lo que necesita decisión (umbral cruzado)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4104 | 186 días (desde 2026-04-20) | Que el comité lo acepte o lo descarte | Dueño: Javier Hoyos; decide el Comité de producto |
| Propuesto sin decidir | REQ-4108 | 117 días | Ídem; además su evidencia tiene 13 meses | Dueña: Laura Vélez; Comité |
| Propuesto sin decidir y sin dueño | REQ-4105 | 113 días | Asignar dueño antes de decidir | Quien tiene la facultad de asignarlo: sin dato; Comité |
| Propuesto sin decidir | REQ-4113 | 75 días | Decisión del comité; evidencia de 13 meses | Dueña: Natalia Ospina; Comité |
| Supuesto sin verificar: "Las tiendas soportan el volumen" | (definición) | 119 días (umbral 30) | Una verificación de capacidad de tiendas contra el volumen medido (310.136/mes); ya pasó el punto de tratarlo como riesgo registrado | Sin dueño nombrado en el registro |

### Aceptados sin sustento
- **Sin evidencia de demanda:** REQ-2030 (Javier Hoyos), REQ-4115 (Liliana Torres).
- **Sin criterio de aceptación:** REQ-4101, 4103, 4106, 4109, 4110.
- **Sin dueño:** REQ-4103 (aceptado, sin dueño y sin criterio de aceptación) y REQ-4105.
- **Evidencia vencida (13 meses, umbral 12):** 14 requerimientos. Toda se apoya en una única ronda de entrevistas del 2025-08-29 («Lo necesito y hoy no lo tengo»), que no nombra ninguno de ellos. Se queda sin sustento la afirmación de que Jóvenes necesita cada uno de esos requerimientos, no solo un documento viejo.

### Las trazas
**Ninguno de los 12 requerimientos aceptados tiene proyecto** (0 % trazado). Ninguna de las 13 fichas de `estado/records` nombra PRD-301. Con la carpeta de fichas a la vista, no hay traza que confirmar ni que se haya perdido: lo decidido no lo está construyendo nadie que lo declare.

### Del descubrimiento y de la definición
- Sin documentos de descubrimiento nuevos (la única ronda sigue siendo 2025-08-29).
- Declarado vs medido: volumen mensual 297.074 declarado (2025-12-18) vs 310.136 medido (2026-10-11), brecha 4,4 %, bajo el umbral de 20 %. No es hallazgo.
- La definición no declara criterio de éxito: no está dicho en ninguna parte.

Nada se decidió, verificó ni se le escribió a nadie. **Vuelvo el 2026-11-22.**
