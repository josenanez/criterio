<!-- origen: 00-definicion/2025-12-18-definicion-producto.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Definición de producto · Puntos de fidelización

**Código:** PRD-301
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-12-18

## El problema

El segmento Jóvenes no tiene puntos de fidelización.

## La propuesta

- Propuesta principal

## Supuestos

- **Las tiendas soportan el volumen** · declarado el 2026-06-26 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
