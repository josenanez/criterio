## Listo — Puntos de fidelización (PRD-301)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una sola entrevista, ronda del 2025-08-29) · la definición y el caso de negocio del 2025-12-18 · lo más reciente es el acta del comité del 2026-10-20. Los 5 se pudieron leer (el .docx lo convertí a texto).
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2), el 2026-10-23 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 97ef3d7200b125fa…
**Preguntas:** 0 (sesión sin interfaz; tomé las respuestas sugeridas: carpeta = la del argumento, gerente = Beatriz Cuéllar según la definición, estado en `estado-producto/PRD-301`, autoridad = «Comité de producto»). No dejé el archivo `_CRITERIO_PRODUCTO.txt` en tu carpeta de documentos: esa pregunta no tenía respuesta sugerida y no escribo ahí sin un sí.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Jóvenes no tiene puntos de fidelización» | Solo la entrevista: «Lo necesito y hoy no lo tengo». No dice quién es el entrevistado ni de qué producto habla | 2025-08-29 |
| Volumen mensual de 297.074 | La medición: 310.136 (bodega de datos, corte 2026-10-11). Diferencia de 4,4 %, por debajo del umbral de 20 % | declarado 2025-12-18 · medido 2026-10-11 |
| «Retorno esperado en 24 meses» | Nada: no hay cifra de retorno | 2025-12-18 |
| «Propuesta principal» | Nada: la propuesta está sin contenido | 2025-12-18 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento dice cómo se sabrá que el producto funcionó. El cierre se juzgará contra algo que no existe.
- **Quién decide.** Ningún documento lo dice. El acta del 2026-10-20 solo lista como asistente a Beatriz Cuéllar, que además es doliente de dos requerimientos aceptados. «Comité de producto» es mi propuesta, no un dato.
- **De dónde sale la cifra de 297.074.** El caso de negocio se cita a sí mismo como fuente.
- **El retorno esperado, en pesos.** Solo dice «en 24 meses».
- **Qué es la propuesta.** Dice «Propuesta principal» y nada más.
- **El problema real.** «Jóvenes no tiene puntos» describe la ausencia de la solución, no lo que le pasa al joven.
- **Para quién es cada requerimiento.** Los 17 se titulan «Requerimiento REQ-xxxx» y ninguno tiene el problema escrito; no hay forma de saber qué piden.
- **Un solo proyecto que los construya.** La definición dice «Ninguno declarado» y el acta tiene «—» en los 17.

### Lo que dice el registro (17 requerimientos del acta del 2026-10-20)
- 12 aceptados y 5 propuestos.
- **12 de 12 aceptados sin proyecto que los ejecute** (0 %): se decidió construir y nadie lo construye.
- **10 de 12 aceptados con evidencia** (83,3 %): REQ-4115 y REQ-2030 se aceptaron sin que nadie los haya pedido.
- **5 aceptados sin criterio de aceptación:** REQ-4101, 4103, 4106, 4109 y 4110. Y el criterio de los demás es siempre el mismo: «se verifica en producción», que no dice qué se mide.
- **2 sin doliente** (REQ-4103 aceptado desde 2026-05-01, y REQ-4105).
- **14 con evidencia envejecida:** toda la demanda sale de la misma entrevista, de hace 13 meses (umbral: 12), y no nombra ningún requerimiento en particular. Es una cita genérica puesta como evidencia de 14 cosas distintas.
- **4 propuestos sin decidir hace más de 60 días:** REQ-4104 (186 días), REQ-4108 (117), REQ-4105 (113), REQ-4113 (75).
- El acta termina con «Se mantiene el plan». No decide nada sobre ninguno de estos puntos.

### Supuestos sobre los que está escrita
- **«Las tiendas soportan el volumen»**: declarado el 2026-06-26, sin verificar desde hace 119 días. Además, el volumen medido ya está 4,4 % por encima del declarado, así que el supuesto se está poniendo a prueba sin que nadie lo mire. (Nota: la definición es del 2025-12-18 pero el supuesto lleva fecha de junio de 2026; alguien editó el documento sin cambiarle la fecha.)
- No hay más supuestos declarados.

### Qué le falta a tu carpeta
- Las transcripciones de más entrevistas: hay una sola, de 2025, con una frase.
- Una serie de la métrica, no un solo corte: el tablero trae un único punto (2026-10-11), así que no se ve la tendencia.
- Las decisiones del comité con quién decidió: el acta solo muestra el estado actual de cada requerimiento.
- Un criterio de éxito escrito.

**Ofrezco** `/product-discovery` sobre el material de entrevistas. Ojo: con una sola entrevista de una frase no va a salir mucho; lo útil sería conseguir más.
