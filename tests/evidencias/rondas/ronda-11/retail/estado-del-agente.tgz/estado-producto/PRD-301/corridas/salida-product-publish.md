No publiqué la ficha de PRD-301 (Puntos de fidelización). La configuración no define una carpeta de productos publicados: solo trae `documents`, `state` y `fichas`, y `productos/publicados/` no existe. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé la carpeta y no escribí ningún archivo de ficha.

Lo que habría llevado la ficha (corte al 2026-10-23):

**Lleva:** 17 requerimientos · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Jóvenes
**Métricas:** volumen_mensual, 297074.0 declarado, de 00-definicion/2025-12-18-caso-de-negocio.md (2025-12-18)

Ningún requerimiento tiene proyecto asignado. Para publicar hay que acordar la carpeta común y registrarla en la configuración.
