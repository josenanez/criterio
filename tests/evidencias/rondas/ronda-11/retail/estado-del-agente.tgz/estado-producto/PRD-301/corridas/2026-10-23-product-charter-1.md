# Corrida del 2026-10-23 · product-charter

PRD-301 · 17 requerimientos · 28 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

Borrador de acta para REQ-4100; ficha no creada (sin firma). Vacíos: quién aceptó, criterio de éxito medible, demanda que no nombra el requerimiento y de 14 meses, autoridad, patrocinador, gerente, barrido normativo.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Acta de constitución — REQ-4100 (Puntos de fidelización) · borrador del 2026-10-23
**Producto:** PRD-301 · Puntos de fidelización · **Requerimientos:** REQ-4100

**Verificación previa (paso 1).** El acta se puede redactar, pero REQ-4100 no pasa limpio las cuatro condiciones. Se sigue marcando cada falta como vacío del acta (respuesta sugerida), sin rellenarla:
- Aceptado: sí, "aceptado" desde 2026-08-06 (30-decisiones/2026-10-20-comite-producto.md). Pero **no consta quién lo aceptó** (`decision.who` vacío): el acta del comité solo lista como asistente a Beatriz Cuéllar.
- Criterios de aceptación: uno solo, "se verifica en producción" (misma fuente). Es un lugar de verificación, no un criterio medible.
- Evidencia de demanda: una cita, «Lo necesito y hoy no lo tengo.» (10-descubrimiento/2025-08-29-entrevistas.docx). **No nombra este requerimiento** y tiene unos 14 meses, por encima del umbral de 12.
- Autoridad: **sin declarar** en ningún documento. "Comité de producto" es una propuesta de la instalación, no confirmada.

## Qué problema resuelve
"El segmento Jóvenes no tiene puntos de fidelización." (00-definicion/2025-12-18-definicion-producto.md). La necesidad propia de REQ-4100 no se encontró en ningún documento (`need`: not_found).

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| "se verifica en producción" (30-decisiones/2026-10-20-comite-producto.md) | **No dicho.** No hay métrica, umbral ni fecha. El éxito del producto (`definition.success`) tampoco está en la definición. |

Contexto, sin ser criterio de éxito de este requerimiento: el caso de negocio declara volumen_mensual 297.074 (00-definicion/2025-12-18-caso-de-negocio.md) y el tablero mide 310.136 al 2026-10-11 (20-metricas/2026-10-11-tablero-metricas.md), 4,4 % por encima. Ningún documento liga esa cifra a REQ-4100.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 (el título es genérico en el acta) | Entrevista 2025-08-29, que no lo nombra. Evidencia débil. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4101 a REQ-4115 y REQ-2030 | Aparecen en el mismo acta de comité | Este acta cubre solo REQ-4100. No hay decisión que los agrupe en este proyecto. Varios están en `propuesto` (4104, 4105, 4108, 4113, 4114) o sin criterio de aceptación (4101, 4103, 4106, 4109, 4110, 4114). Cada uno con su razón queda para su propia acta o para pedir su inclusión. |

## Gobierno
**Patrocinador:** no dicho en ningún documento.
**Gerente propuesto:** no dicho. Es un cargo por asignar; la gerente de producto, Beatriz Cuéllar (00-definicion/2025-12-18-definicion-producto.md), no es la gerente del proyecto.
**Doliente del requerimiento:** Elena Duarte (30-decisiones/2026-10-20-comite-producto.md).
**Comité:** Comité de producto, mensual (configuración). Su acta no dice quién decide.
**Autoridad del gerente:** no dicho.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| "Las tiendas soportan el volumen", declarado el 2026-06-26 (00-definicion/2025-12-18-definicion-producto.md) | No, sin verificar | El gerente del proyecto, por designar. Hasta entonces, sin doliente. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Programa de puntos para el segmento Jóvenes: datos personales de clientes, posiblemente menores | No barrida | No citada; ningún documento la menciona | Sin barrido. Se recomienda `regulatory-sweep` antes de firmar. Esto no es una afirmación de cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4100 | La decisión de qué se construye no tiene autor verificable | Comité de producto / gerente de producto |
| Criterio de éxito medible | El cierre no se podrá juzgar meses después | Elena Duarte con Beatriz Cuéllar |
| Demanda que nombre el requerimiento y esté vigente | Se construye sobre una cita genérica de hace 14 meses | Beatriz Cuéllar |
| Autoridad del gerente | El proyecto escala todo o no escala nada | Comité de producto |
| Patrocinador y gerente | No hay quién reciba la ficha | Quien tenga autoridad de asignar |
| Necesidad de REQ-4100 (`need`) | El problema del requerimiento es el del producto, no el suyo | Elena Duarte |
| Supuesto de las tiendas sin verificar | Riesgo sin doliente desde el día uno | Gerente del proyecto |
| Barrido normativo | Obligaciones sin ver | Beatriz Cuéllar |

---
**Esto es un borrador.** Lo firma quien tenga autoridad sobre el Comité de producto; hoy ningún documento lo dice. **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`, con `identity.product` = PRD-301. El estado declarado (`declared`) queda vacío por diseño.

**Después:** el gerente del proyecto, cuando se nombre, instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
