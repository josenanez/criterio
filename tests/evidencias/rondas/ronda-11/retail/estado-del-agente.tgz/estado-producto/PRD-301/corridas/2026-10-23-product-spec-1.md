# Corrida del 2026-10-23 · product-spec

PRD-301 · 17 requerimientos · 45 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

Borrador sin sección de comportamiento: 12 aceptados sin necesidad ni criterio verificable (7 vagos, 5 ausentes). Dijo que no sabe: país y norma aplicable, criterio de éxito, quién decidió, qué hace cada requerimiento.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Especificación — Puntos de fidelización (PRD-301) · borrador del 2026-10-23

> **Es un borrador. Lo cierra Beatriz Cuéllar (gerente de producto), con la autoridad que el acta no nombra (propuesta: Comité de producto).** Este agente no aprueba ni decide alcance. Antes de la revisión jurídica no es insumo de construcción.

Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

**Resumen honesto:** el registro tiene 17 requerimientos; 12 están `aceptado`, 5 `propuesto`. Ninguno de los 12 tiene necesidad escrita, ninguno tiene proyecto que lo ejecute, y ninguno tiene un criterio de aceptación verificable (7 dicen «se verifica en producción», 5 no dicen nada). Los títulos son marcadores («Requerimiento REQ-xxxx»). **Por eso esta especificación no tiene sección de Comportamiento: escribirla sería inventar lo que el registro no dice.**

## Qué problema resuelve

«El segmento Jóvenes no tiene puntos de fidelización.» (`00-definicion/2025-12-18-definicion-producto.md`, 2025-12-18). La propuesta de la definición es «Propuesta principal», sin contenido. El criterio de éxito del producto **no está dicho en ninguna parte**.

## Alcance

### Entra (12 requerimientos aceptados, sin descripción de qué hacen)
REQ-2030, REQ-4100, REQ-4101, REQ-4102, REQ-4103, REQ-4106, REQ-4107, REQ-4109, REQ-4110, REQ-4111, REQ-4112, REQ-4115 — todos citados al acta `30-decisiones/2026-10-20-comite-producto.md`. Solo se sabe de ellos ID, doliente, estado y fecha; **qué hacen no consta**.

### No entra
- REQ-4104, REQ-4105, REQ-4108, REQ-4113, REQ-4114: están `propuesto`, nadie los decidió. Especificarlos sería escribir el documento dos veces.
- Cualquier comportamiento, regla de acumulación/redención, canal o integración: ningún documento los define.
- Diseño, estimación, costo y fecha: no son de este documento.

## Comportamiento

**Sin contenido a propósito.** Ningún requerimiento aceptado trae su necesidad (`need: not_found` en los 12) y la propuesta de la definición está vacía. Rellenarlo con lo razonable para un programa de puntos dejaría decidido por el agente lo que nadie decidió.

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-2030, 4100, 4102, 4107, 4111, 4112, 4115 | **No es verificable:** no dice qué se observa ni con qué umbral; dos personas no llegarían a la misma respuesta | No — hay que reescribirlo |
| *(ninguno escrito)* | REQ-4101, 4103, 4106, 4109, 4110 | Sin criterio | No |

Único criterio que el tablero podría sostener si alguien lo decide: algo sobre `volumen_mensual` (hoy medido: 310.136 al 2026-10-11, bodega de datos). **No se propone un umbral**; es decisión del dueño. Cualquier criterio de latencia o percentiles: no hay evidencia de que alguien los mida; se marcaría no medible hoy.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «Las tiendas soportan el volumen» (declarado 2026-06-26, sin verificar desde hace más de 30 días; el umbral configurado es 30) | No | Sin dueño nombrado → propuesta: Beatriz Cuéllar asigna (¿operación de tiendas?) |
| El caso de negocio declara `volumen_mensual` 297.074 (2025-12-18); el tablero mide 310.136 (+4,4 %, por debajo del umbral de 20 %) | Contrastado, dentro del umbral | Beatriz Cuéllar |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Criterio de éxito del producto (no existe) | No hay contra qué verificar ningún requerimiento | Beatriz Cuéllar |
| Criterio de aceptación verificable en los 12 aceptados (7 vagos, 5 ausentes) | No se puede decir «terminado» sin discutir | Cada doliente: Javier Hoyos (2030), Elena Duarte (4100), Natalia Ospina (4101), Jorge Medina (4102, 4110), Andrés Lozano (4106), Mauricio Pérez (4107), Diana Molina (4109), Beatriz Cuéllar (4111, 4112), Liliana Torres (4115) |
| REQ-4103 sin doliente | Nadie responde por él | Beatriz Cuéllar |
| Necesidad y descripción de cada requerimiento (títulos son marcadores) | No hay qué construir | Cada doliente |
| Quién decidió cada aceptación: `decision.who` vacío en los 12; el acta solo lista como asistente a Beatriz Cuéllar | Aceptaciones sin autoridad rastreable | Comité de producto / Beatriz Cuéllar (la autoridad está sin confirmar) |
| REQ-4115 y REQ-2030 aceptados sin «quién lo pidió» ni evidencia | Aceptados sin demanda a la vista | Liliana Torres, Javier Hoyos |
| Evidencia de demanda: una sola ronda de entrevistas (2025-08-29, >12 meses), «Lo necesito y hoy no lo tengo», que **no nombra ningún requerimiento** | La demanda de cada requerimiento no está sustentada | Beatriz Cuéllar (nuevo descubrimiento) |
| Casos borde (puntos duplicados, vencimiento, devoluciones, sin conexión en tienda, cliente que se va antes de confirmar) | Comportamiento indefinido | Dolientes con gerente de producto |
| Lo que otros equipos deben hacer (tiendas, bodega de datos): nada acordado; «Proyectos que lo construyen: Ninguno declarado» | Requerimientos aceptados que nadie construye | Beatriz Cuéllar con esos equipos |
| Segmento Jóvenes: no hay definición de edad ni de si incluye menores | Cambia la obligación sobre datos | Beatriz Cuéllar + jurídico |

### Barrido normativo (primer barrido, sin opinar sobre cumplimiento)

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Programa de puntos ligado a clientes: casi seguro recoge datos personales (identidad, compras) | No declarado | Autorización y finalidad declarada | — | no tengo la norma a la vista (y el país no consta) |
| Segmento «Jóvenes»: puede incluir menores | No declarado | Tratamiento de datos de menores | — | no tengo la norma a la vista |
| Puntos con valor canjeable / promociones | No declarado | Protección al consumidor; información de condiciones | — | no tengo la norma a la vista |
| Retención y trazabilidad de saldos | No declarado | Conservación | — | sin resolver |

Ningún documento de la organización resuelve estos puntos. Dueño de llevarlos a revisión jurídica: Beatriz Cuéllar. Deben entrar al registro como restricción de los requerimientos o como riesgo con doliente.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | Sin necesidad ni descripción; criterio no verificable; sin evidencia ni quien lo pidió |
| REQ-4100 | Requerimiento REQ-4100 | Sin necesidad ni descripción; criterio no verificable |
| REQ-4101 | Requerimiento REQ-4101 | Sin necesidad ni descripción; sin criterio |
| REQ-4102 | Requerimiento REQ-4102 | Sin necesidad ni descripción; criterio no verificable |
| REQ-4103 | Requerimiento REQ-4103 | Sin doliente, sin necesidad, sin criterio |
| REQ-4106 | Requerimiento REQ-4106 | Sin necesidad ni descripción; sin criterio |
| REQ-4107 | Requerimiento REQ-4107 | Sin necesidad ni descripción; criterio no verificable |
| REQ-4109 | Requerimiento REQ-4109 | Sin necesidad ni descripción; sin criterio |
| REQ-4110 | Requerimiento REQ-4110 | Sin necesidad ni descripción; sin criterio |
| REQ-4111 | Requerimiento REQ-4111 | Sin necesidad ni descripción; criterio no verificable |
| REQ-4112 | Requerimiento REQ-4112 | Sin necesidad ni descripción; criterio no verificable |
| REQ-4115 | Requerimiento REQ-4115 | Sin necesidad ni descripción; criterio no verificable; sin evidencia ni quien lo pidió |

Los 12 quedan sin sección de comportamiento: el registro no dice qué hacen. Es la lista completa de los aceptados.

## Después

**No se ofrece `/product-charter`:** los vacíos no están cerrados y el producto no tiene criterio de éxito.

---
*Pie:* sale del registro `estado-producto/PRD-301/requirements/` (17 requerimientos; cubre 0 con comportamiento, 12 en alcance), construido sobre el acta del Comité de producto del 2026-10-20; ficha del producto actualizada 2026-10-23. Borrador; lo cierra Beatriz Cuéllar. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
