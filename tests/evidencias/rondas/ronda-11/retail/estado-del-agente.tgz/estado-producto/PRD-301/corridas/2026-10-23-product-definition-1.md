# Corrida del 2026-10-23 · product-definition

PRD-301 · 17 requerimientos · 40 s · 40 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

La definición solo se sostiene en una entrevista de hace 13 meses; sin criterio de éxito; supuesto de tiendas sin verificar 119 días; volumen declarado vs medido dentro del umbral (4,4 %)

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Definición — Puntos de fidelización (PRD-301) · contrastada al 2026-10-23
**Documento:** 00-definicion/2025-12-18-definicion-producto.md, con el caso de negocio 00-definicion/2025-12-18-caso-de-negocio.md · **del** 2025-12-18 · 5 afirmaciones

### Lo que la evidencia contradice
Nada. Ninguna afirmación tiene en contra una fuente posterior.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %). Lo único contrastable es `volumen_mensual`: declarado 297.074 (caso de negocio, 2025-12-18) contra medido 310.136 (tablero de métricas, bodega de datos, corte 2026-10-11). La diferencia es de 4,4 %, en la dirección de que el medido es mayor. Es imprecisión, no contradicción. La serie tiene un solo punto, así que no dice tendencia.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | caso de negocio, 2025-12-18 | No trae cifra ni métrica de retorno, y no hay serie que lo mida. |

### No está dicho en ninguna parte
- **El criterio de éxito.** El cálculo lo trae en `unknown`. Sin él, el cierre del producto no se puede juzgar.
- **La propuesta.** El documento solo dice «Propuesta principal», sin contenido.
- **Cuántos jóvenes son ni cómo se define «Jóvenes».** No hay rango de edad, tamaño del segmento ni si incluye menores.
- **De qué es el `volumen_mensual`.** El caso de negocio no dice qué se cuenta (transacciones, afiliados, puntos), y de eso depende el supuesto de las tiendas.
- **Cuánto es el retorno ni cómo se mide.** El caso de negocio solo dice «en 24 meses».
- **Cuánto pagaría o cuánto usaría el cliente.** Ningún documento lo afirma ni lo niega.
- **Qué proyecto lo construye.** El documento dice «Ninguno declarado».
- **Quién decide.** «Comité de producto» es una propuesta de la instalación, sin confirmar: el acta de 2026-10-20 solo lista como asistente a Beatriz Cuéllar.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «Las tiendas soportan el volumen» (declarado el 2026-06-26, sin verificar; el umbral es 30 días) | 119 | Definir qué es «soportar» (capacidad por tienda y pico aceptable). Medir la carga por tienda contra esa capacidad con el volumen real, hoy 310.136. Alguien con nombre debe aceptar el resultado. Hoy ningún documento da la capacidad de las tiendas. |

Dos observaciones. El supuesto lleva fecha 2026-06-26 dentro de un documento fechado 2025-12-18, así que la definición se editó después de su fecha y esa edición no tiene versión propia. Y el supuesto, tal como está escrito, no define el criterio de «soportar», lo que lo acerca a los que nadie va a verificar.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Jóvenes no tiene puntos de fidelización» | Una entrevista, «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» Tema: Necesidad principal (10-descubrimiento/2025-08-29-entrevistas.docx) | 2025-08-29 | Débil. Es una sola persona, anónima, que dijo y no pagó. No dice que sea del segmento Jóvenes ni nombra puntos de fidelización. |
| `volumen_mensual` ≈ 297.074 | Tablero de métricas, 310.136 (20-metricas/2026-10-11-tablero-metricas.md) | 2026-10-11 | Medida, no declarada, pero con un solo punto. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema (Jóvenes sin puntos) y la «necesidad principal» | Entrevista del 2025-08-29, la única a la vista | 13 meses (umbral 12) |

Es la misma entrevista que el registro cita para 14 de los 17 requerimientos, sin nombrar ninguno. Eso es tema de `/product-requirements`, no de este comando.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de afiliados a un programa de puntos, con posibles menores de edad si «Jóvenes» los incluye | No consta en la configuración ni en la definición | — | — | No tengo la norma a la vista |

La definición no menciona datos personales, pagos ni retención. Que el programa los toque es lectura de este barrido, no lo dice el documento. No se nombra ni se cita una norma porque no se sabe el país. Esto va a revisión jurídica, no la reemplaza, y no dice si cumple.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Es el bloqueante.
- **Quién decide:** sin confirmar.
- **Problema:** está dicho, pero con evidencia débil y vencida.
- **Para quién:** «Jóvenes», sin definir.

La definición no está para cerrar y, por eso, no se ofrece `/product-charter`.

### Después
El supuesto de las tiendas lleva 119 días sin verificar. Conviene convertirlo en riesgo con doliente (raid-taxonomy). Queda ofrecido y no creado.
