## Trazabilidad — Puntos de fidelización (PRD-301) · al 2026-10-23
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Se pasaron las 13 fichas de `estado/records` (PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Ninguno de los 12 requerimientos aceptados tiene proyecto en el registro. Ordenados del más antiguo al más nuevo:

| REQ | Título | Decidido el | Dueño en el registro |
|---|---|---|---|
| REQ-4112 | Requerimiento REQ-4112 | 2026-04-04 | Beatriz Cuéllar |
| REQ-4103 | Requerimiento REQ-4103 | 2026-05-01 | sin dueño |
| REQ-4107 | Requerimiento REQ-4107 | 2026-05-17 | Mauricio Pérez |
| REQ-4106 | Requerimiento REQ-4106 | 2026-05-29 | Andrés Lozano |
| REQ-2030 | Requerimiento REQ-2030 | 2026-10-03 | Javier Hoyos |
| REQ-4101 | Requerimiento REQ-4101 | 2026-08-05 | Natalia Ospina |
| REQ-4111 | Requerimiento REQ-4111 | 2026-08-05 | Beatriz Cuéllar |
| REQ-4100 | Requerimiento REQ-4100 | 2026-08-06 | Elena Duarte |
| REQ-4102 | Requerimiento REQ-4102 | 2026-08-10 | Jorge Medina |
| REQ-4115 | Requerimiento REQ-4115 | 2026-08-17 | Liliana Torres |
| REQ-4109 | Requerimiento REQ-4109 | 2026-08-26 | Diana Molina |
| REQ-4110 | Requerimiento REQ-4110 | 2026-09-02 | Jorge Medina |

«Por quién» se decidió: el cálculo no trae quién decidió cada uno. La autoridad configurada es el Comité de producto; el acta de cada decisión no está en lo calculado. La columna es el dueño del requerimiento, no quien lo decidió.

Los cinco requerimientos en estado propuesto (REQ-4104, 4105, 4108, 4113, 4114) no están decididos y no entran en este conteo.

### La traza no se confirma
Ninguna. No hay trazas que confirmar porque ningún requerimiento declara proyecto. No hay `trace_not_confirmed`.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-201 Programa de fidelización | «puntos de fidelización», según el acta de constitución del 2025-10-05 (`PRY-201-programa-de-fidelización/00-gobierno/2025-10-05-acta-constitucion.docx`) | Ninguno de los 17 REQ nombra PRY-201 |

La ficha lo nombra por texto, no por el código PRD-301. Parece ser este producto, pero lo confirma una persona. Es la única ficha de las 13 que lo menciona. Si es el mismo, hay un proyecto construyendo este producto desde octubre de 2025 y el registro no lo sabe: los 12 decididos figuran sin proyecto.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2030 | aceptado | 2026-10-03 | — | no | — |
| REQ-4100 | aceptado | 2026-08-06 | — | no | — |
| REQ-4101 | aceptado | 2026-08-05 | — | no | — |
| REQ-4102 | aceptado | 2026-08-10 | — | no | — |
| REQ-4103 | aceptado | 2026-05-01 | — | no | — |
| REQ-4106 | aceptado | 2026-05-29 | — | no | — |
| REQ-4107 | aceptado | 2026-05-17 | — | no | — |
| REQ-4109 | aceptado | 2026-08-26 | — | no | — |
| REQ-4110 | aceptado | 2026-09-02 | — | no | — |
| REQ-4111 | aceptado | 2026-08-05 | — | no | — |
| REQ-4112 | aceptado | 2026-04-04 | — | no | — |
| REQ-4115 | aceptado | 2026-08-17 | — | no | — |

La cadena se rompe en el eslabón decisión → proyecto, en los 12.

### Sin fichas a la vista
Hay 13 fichas y ninguna se pudo cruzar con un REQ, porque ningún REQ nombra proyecto. Seis fichas no dicen qué producto ejecutan: PRY-202 (el acta dice «No aplica»), PRY-203, PRY-206, PRY-209, PRY-210 y PRY-211. Eso es un hallazgo de esos proyectos, no de este registro. PRY-199 dice PRD-299, otro producto.
