# Corrida · 2026-10-23-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-207

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-207

**Inicio:** 2026-10-23T11:49:31 · **Fin:** 2026-10-23T11:50:39 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 46 | 58 | Informe de estado de PRY-207: verde declarado sin sustento (3 hitos cumplidos sin evidencia, despliegue reprogramado sin cambio formalizado, prueba de carga fallida). Sin dato: autoridad, fase, responsables de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 23, `commitment_overdue` 9, `vendor_deliverable_late` 6, `progress_vs_plan` 5, `variance_time` 3, `commitment_rescheduled` 3, `declared_vs_evidence` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 2, `change_without_baseline` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## PRY-207 · Marca propia de alimentos — estado al 2026-10-23

El gerente declara verde, pero ningún documento lo sustenta. El informe sale de la ficha `estado/records/PRY-207.json` (actualizada el 2026-10-23) y del recálculo de `compute` de hoy.

**Declara el gerente (Gustavo Neira):** verde, 70%, al 2026-09-30 (hace 23 días).
**Sustento documental:** sin sustento. Hay 0 fuentes de evidencia.
**Lo que el semáforo no explica:** tres hitos declarados cumplidos sin evidencia. El script marca además la alerta `declared_vs_evidence`.
**Último documento y última reunión:** ambos del 2026-10-18, es decir 5 días de silencio.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Cierre | 2026-11-18 | 2026-11-18 | 0 días |
| Presupuesto aprobado | 800.000.000 COP | 800.000.000 COP | La proyección declarada es 742.507.103 COP, un -7,2% |

- **Replanificaciones:** 0 registradas.
- **Despliegue reprogramado:** el informe del 2026-09-30 dice que se reprogramó por el congelamiento de fin de año, pero el cronograma vigente sigue siendo el v1. No hay solicitud de cambio.
- **Avance:** declara 70%. El plan sustenta entre 75% y 100%, con 3 de 4 hitos cumplidos, así que la brecha es de 5,0 puntos.

### Hitos
| Hito | Fecha | Estado declarado | Evidencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-06-13 | cumplido | ninguna (132 días) |
| Ambiente de pruebas certificado | 2026-08-05 | cumplido | ninguna (79 días) |
| Integración con el ERP | 2026-09-27 | cumplido | ninguna (26 días) |
| Piloto en tiendas | 2026-11-18 | pendiente | — |

### Dónde no coincide
- **Verde contra su propio informe:** el mismo documento dice que la prueba de carga no alcanzó el umbral y se repite. También dice que se reprogramó el despliegue. El semáforo no menciona ninguna de las dos cosas.
- **Plan contra informe:** el cronograma mantiene las fechas originales y el informe habla de una reprogramación. No hay documento que lo formalice.

### Abierto
- **Riesgo:** congelamiento de cambios en temporada alta, sin responsable ni valoración.
- **Incidencias:** la prueba de carga fallida y el despliegue reprogramado, ambas desde el 2026-09-30 y sin responsable.
- **Compromisos vencidos:** ninguno. Hay uno abierto, el de Beatriz Cuéllar, «Entregar el punto 40», para el 2026-11-19. Ella no figura entre los asistentes de la minuta, que lista a Gustavo Neira dos veces. El compromiso tampoco dice qué es el «punto 40» y vence un día después del cierre.
- **Dependencias:** ninguna registrada.

### Sin dato
- Autoridad que aprueba y fase del proyecto.
- Responsables de las incidencias, y probabilidad e impacto del riesgo.
- Historial de línea base de costo: solo hay la cifra aprobada del acta.

### Siguiente paso
Puedo preparar la solicitud de cambio por la reprogramación y el punto de comité para el 2026-11-06. No lo hago hasta que lo pidas.

La corrida quedó registrada como `2026-10-23-status-report-1`, con la salida en `estado/corridas/salida-status-report.md`.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no hubo nada que registrar de nuevo.

*Criterio Portfolio v0.8.0 · ficha PRY-207 del 2026-10-23 · campos inciertos: autoridad y fase · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
