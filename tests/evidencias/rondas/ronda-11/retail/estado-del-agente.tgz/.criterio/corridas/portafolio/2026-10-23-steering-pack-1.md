# Corrida · 2026-10-23-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T12:03:24 · **Fin:** 2026-10-23T12:07:07 · **Duración:** 223 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 189 | 58 | Paquete de comité 2026-11-06: 7 decisiones, 6 escalamientos, 10 de 13 proyectos con hallazgos. No hay comité anterior en el estado, el ciclo no se pudo cerrar. No sé quién tiene facultad en ningún proyecto, ni los días de atraso de 5 proyectos con fin vencido, ni si las proyecciones incluyen las CC-01. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 23, `commitment_overdue` 9, `vendor_deliverable_late` 6, `progress_vs_plan` 5, `variance_time` 3, `commitment_rescheduled` 3, `declared_vs_evidence` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 2, `change_without_baseline` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Preparé el material del comité del 2026-11-06 con 7 decisiones, 6 escalamientos y 10 de 13 proyectos con hallazgos. Los términos v1.2 ya estaban aceptados a nombre de José Francisco Ñáñez el 2026-10-23, así que no los registré de nuevo. No pasaste fecha y tomé la del próximo comité de la configuración, 2026-11-06.

No hay comité anterior en `estado`, así que no pude cerrar el ciclo. Las solicitudes de cambio (CC-01) de PRY-201 y PRY-205 dicen «Autorizada por el comité», pero ninguna acta lo registra.

**Decisiones**
1. **Autoridad:** ¿fija el comité por escrito hasta dónde decide el gerente en cada proyecto? Los 13 proyectos tienen la autoridad sin declarar. Recomiendo una regla única para el portafolio.
2. **PRY-209, CC-01 (+95 días, 190.000.000 COP):** la línea base ya se movió 95 días sin autorización, aunque la solicitud está pendiente de presentar. Recomiendo aprobarla solo con el detalle del alcance y la evidencia de los hitos.
3. **PRY-201, CC-01 (+82 días, 164.000.000 COP):** dice «Autorizada por el comité» sin nombre ni acta que lo respalde. Recomiendo ratificarla con esa misma condición.
4. **PRY-205, CC-01 (+42 días, 84.000.000 COP):** autorizada sin acta y sin línea base nueva. Recomiendo lo mismo que en el punto 3.
5. **PRY-206:** la proyección supera lo aprobado en 17,5 % (el umbral es 10 %). Recomiendo congelar compromisos nuevos hasta que el gerente traiga la causa y opciones costeadas.
6. **Seguridad en medios de pago:** el mismo hallazgo aparece en PRY-200, 204, 206 y 211, sin doliente. Recomiendo nombrar un doliente único; no pude confirmar con los documentos que sea un solo hallazgo.
7. **Cinco proyectos con fecha de fin ya pasada y avance bajo 100 %:** PRY-204, 205, 206, 208 y 211. Recomiendo pedir primero la evidencia de los hitos que declaran cumplidos.

**Lo que el material declara como no sabido**
- Quién decide en cada comité.
- Los días de atraso de los cinco proyectos del punto 7.
- Si las proyecciones de PRY-201, 205 y 209 ya incluyen sus CC-01.
- Qué hito es la «salida a producción» de PRY-201.
- En PRY-205, lo ejecutado (339.846.720 COP) supera lo comprometido (236.283.277 COP); no sé cuál de las dos cifras está mal.

Una vez el comité sesione, puedo registrar sus decisiones en las fichas para que el siguiente material cierre el ciclo.

Los términos están en https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0. La corrida quedó registrada como `2026-10-23-steering-pack-1`.

Archivos están en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/retail/espacio/estado/corridas`:
- `salida-steering-pack.md`
