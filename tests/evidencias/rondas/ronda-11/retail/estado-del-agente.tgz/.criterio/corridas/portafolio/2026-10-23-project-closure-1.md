# Corrida · 2026-10-23-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-23T12:02:09 · **Fin:** 2026-10-23T12:03:18 · **Duración:** 69 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 45 | 58 | Cierre de PRY-204 no declarable: criterio de éxito (en producción y medido) sin evidencia; 3 de 4 hitos sin acta de recibo; piloto recibido 2026-10-23 contra 2026-08-14 sin replanificación; incidencia de seguridad y riesgo sin dueño. No sé si hay producción ni quién decide el cierre. |

Por señal (`project-closure`): `milestone_met_without_evidence` 23, `commitment_overdue` 9, `vendor_deliverable_late` 6, `progress_vs_plan` 5, `variance_time` 3, `commitment_rescheduled` 3, `declared_vs_evidence` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 2, `change_without_baseline` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**PRY-204 (Cajas de autopago) no se puede cerrar contra lo pactado.** Solo se podría cerrar por decisión de alguien, y esa decisión no está registrada en ningún documento.

- **Términos:** ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los registré de nuevo.
- **Criterio de éxito:** el acta pide "Cajas de autopago en producción y medido". Ningún documento muestra producción ni medición, así que no puedo determinar si se cumplió. El cronograma tampoco tiene un hito para ese criterio; el último hito es el piloto.
- **Entregables:** el piloto en tiendas se recibió el 2026-10-23, contra una fecha comprometida de 2026-08-14. Lo recibió la propia gerente, Paula Céspedes. Los otros tres hitos están marcados como cerrados sin acta de recibo: llevan 381, 277 y 174 días vencidos sin soporte.
- **Atraso:** el cálculo da 0 días porque el cronograma sigue en v1, sin replanificación. Esa cifra refleja que nadie registró el atraso, no que no lo haya habido.
- **Avance y presupuesto:**
  - El informe del 2026-10-20 declara 48 % de avance, estado Rojo y 4 de 4 hitos cumplidos, una brecha de 52 puntos.
  - Presupuesto aprobado: 3.300.000.000 COP. Ejecutado declarado: 1.312.457.340 (39,8 %). Proyección declarada: 3.171.678.820, que queda 3,9 % por debajo de lo aprobado.
  - No hay ejecutado final con soporte.
- **RAID:** dos ítems siguen abiertos sin dueño: una incidencia de seguridad en los medios de pago y el riesgo de disponibilidad de los jefes de tienda. También sigue abierto el compromiso de Felipe Arango "Entregar el punto 24", para el 2026-10-26.
- **Lecciones:** solo incluí tres, las que tienen hecho y fecha detrás: hitos cerrados sin acta, atraso no registrado y criterio de éxito sin hito.
- **Archivo:** no moví la carpeta a `archivo/` ni congelé la ficha, porque el cierre no está declarado y hay ítems abiertos sin dueño. Tomé esa respuesta por la sesión sin interfaz.
- **Sin dato:** quién decide el cierre, y qué son los componentes 1 a 3 y el "punto 24".

La corrida quedó registrada con el id `2026-10-23-project-closure-1`. La salida completa está en `estado/corridas/salida-project-closure.md`.
