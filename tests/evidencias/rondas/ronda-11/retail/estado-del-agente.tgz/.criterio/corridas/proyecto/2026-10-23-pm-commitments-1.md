# Corrida · 2026-10-23-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T11:32:27 · **Fin:** 2026-10-23T11:33:11 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 24 | 12 | Reprogramados: Óscar Ramírez (6), Mauricio Pérez (5), Camilo Beltrán (3); 6 vencidos sin evidencia; 2 sin fecha |

Por señal (`pm-commitments`): `commitment_overdue` 6, `commitment_rescheduled` 3, `commitment_undated` 2, `milestone_met_without_evidence` 1

## Lo que el agente mostró

## Compromisos — Centro de distribución norte (PRY-202) · al 2026-10-23

Los términos v1.2 ya estaban aceptados por José Francisco Ñáñez el 2026-10-23, así que no pedí un sí nuevo. El registro tiene 26 compromisos: 3 cumplidos con documento y 23 abiertos. De los abiertos, 6 están vencidos, 2 no tienen fecha y 3 se han reprogramado tres veces o más.

### Se viene reprogramando
Tres veces o más no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.
- **Óscar Ramírez, enviar el documento 1:** 6 reprogramaciones. Se prometió para el 10-02 y hoy está para el 12-22. Hoy dijo que «no alcanzó».
- **Mauricio Pérez, cerrar la prueba 2:** 5 reprogramaciones. Se prometió para el 09-30 y hoy está para el 12-21.
- **Camilo Beltrán, entregar el punto 8:** 3 reprogramaciones. Se prometió para el 10-10 y hoy está para el 11-17.

### Vencidos sin evidencia
| Quién | Qué | Hace |
|---|---|---|
| Javier Hoyos | Cerrar la prueba 10 | 17 días |
| Javier Hoyos | Revisar el anexo 3 | 14 días |
| Jorge Medina | Validar el ambiente 4 | 7 días |
| Rubén Cárdenas | Enviar el documento 9 | 3 días |
| Jorge Medina | Revisar el anexo 11 | 1 día |
| Gustavo Neira | Revisar el anexo 19 | 1 día |

Jorge Medina dijo que ya entregó el ambiente 4, pero ningún documento lo respalda. El acta de recibo del 10-20 es de «Ambiente de pruebas certificado» y no nombra el ambiente 4, así que no lo cierra.

### Dichos como entregados, sin documento
Siguen abiertos porque no hay acta que los respalde:
- Javier Hoyos, punto 16.
- Elena Duarte, ambiente 12.

### Vencen en los próximos 7 días
Hay cinco: matriz 6 (María Restrepo), fecha 23 (Javier Hoyos), punto 24 (Óscar Ramírez), ambiente 12 (Elena Duarte) y ambiente 20 (Gustavo Neira).

### Sin fecha
- Liliana Torres, cerrar la prueba 18. Está en «por definir» y no estuvo en la reunión de hoy.
- Laura Vélez, mandar el ajuste del presupuesto. Dijo «la otra semana» y nadie dio fecha.

### Cerrados con documento
Son tres: fecha 7 (Gustavo Neira), fecha 15 (Camilo Beltrán) y documento 17 (Elena Duarte).

### Después
El documento 1 y la prueba 2 superan el umbral de 3 reprogramaciones y su fecha vigente cae en diciembre. Puedo formularlos como decisión para el comité con `/pm-escalate`. `/pm-publish` no hace falta: ningún compromiso cambió un campo de la ficha.

La corrida quedó registrada con 12 hallazgos. El informe completo está en `estado/PRY-202-centro-de-distribución-norte/corridas/salida-pm-commitments.md`.
