# Corrida · 2026-10-23-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-23T12:01:14 · **Fin:** 2026-10-23T12:02:03 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 27 | 58 | Revisión del acta 2026-03-21: sin autoridad del gerente, objetivo descrito como solución, alcance y exclusiones de plantilla, criterio de éxito sin métrica ni medidor, sin supuestos, hitos ni cadencia. No sé si hay decisiones de comité posteriores que definan la autoridad. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `commitment_overdue` 9, `vendor_deliverable_late` 6, `progress_vs_plan` 5, `variance_time` 3, `commitment_rescheduled` 3, `declared_vs_evidence` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 2, `change_without_baseline` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**Revisión del acta de PRY-203 (Reposición automática):** el acta existe, es del 2026-03-21 y tiene la forma completa, pero el fondo es de plantilla sin completar. Su salida completa quedó en `estado/corridas/salida-project-charter.md`.

Los términos ya estaban vigentes (versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los registré de nuevo.

**Lo que falta y su consecuencia**
- **Autoridad del gerente:** no está. No se sabe qué monto ni qué cambio de alcance puede decidir Andrés Lozano sin comité. Importa ahora: la proyección al cierre (6.959.550.295 COP) supera el aprobado (6.800.000.000) en 159.550.295 COP, un 2,3 %. Por debajo del umbral de desviación de costo (10 %), pero nadie sabe quién decide ese sobrecosto.
- **Objetivo de negocio:** describe la solución ("Entregar reposición automática para Logística"), no el problema de negocio.
- **Alcance:** solo "Componente 1, 2 y 3", sin contenido. No hay contra qué medir un cambio de alcance.
- **Exclusiones:** "Lo que otro proyecto cubre", sin nombrar cuál.
- **Criterio de éxito:** "en producción y medido", sin métrica ni umbral, y sin quién lo mide.
- **Supuestos, restricciones, hitos y cadencia:** no hay ninguno. Sin hitos no se puede contrastar el avance.

Lo que sí está bien: patrocinador (Elena Duarte), gerente, comité, presupuesto aprobado y fechas.

**Una pregunta para el gerente:** el informe del 2026-10-18 declara 74 % de avance, pero lo ejecutado es el 25,0 % del aprobado y lo comprometido el 35,1 %. Con un acta sin hitos no puedo decir cuál lectura es la correcta.

**Lo que no sé:** si existen decisiones de comité posteriores que definan la autoridad del gerente. No hay otros documentos de gobierno en la carpeta.

**Siguiente paso:** como el acta quedó sin autoridad declarada, puedo llevar esa definición al comité (`/steering-pack`). También puedo pasar al registro RAID los supuestos por declarar y el riesgo y la incidencia sin responsable del informe (`/raid-log`).

La corrida quedó registrada como `2026-10-23-project-charter-1`.
