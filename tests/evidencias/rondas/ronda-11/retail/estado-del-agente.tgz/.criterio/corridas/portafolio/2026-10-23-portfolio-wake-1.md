# Corrida · 2026-10-23-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T12:10:43 · **Fin:** 2026-10-23T12:12:59 · **Duración:** 136 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 27 | 58 | Barrido: 86 documentos, 0 cambios, nada que recalcular. Confirmación: las 5 preguntas ya estaban hechas hoy en el informe de portafolio, sin respuesta; no se repitieron ni se marcó la confirmación como corrida. Informe de comité no toca (comité 2026-11-06). No se consultaron peticiones (no tocaban). |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 23, `commitment_overdue` 9, `vendor_deliverable_late` 6, `progress_vs_plan` 5, `variance_time` 3, `commitment_rescheduled` 3, `declared_vs_evidence` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 2, `change_without_baseline` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## 2026-10-23

**Revisé:** 86 documentos. Ninguno cambió y no recalculé ningún proyecto.

Los términos v1.2 ya estaban aceptados por José Francisco Ñáñez el 2026-10-23, así que no los pedí de nuevo.

**Barrido:** no hay documentos nuevos, cambiados, renombrados ni borrados, ni citas rotas. Nada cruzó un umbral. Las 58 señales abiertas son las del informe de portafolio de hoy.

**Confirmación mensual:** tocaba, pero las cinco preguntas ya las hizo hoy el informe de portafolio y siguen sin respuesta. No las repetí: quedan como *preguntadas el 23, sin respuesta*.
- **PRY-200:** ¿existe el acta de recibo de "Diseño de la experiencia aprobado"?
- **PRY-207:** ¿existe el acta de recibo de "Integración con el ERP"?
- **PRY-209:** ¿el cambio CC-01 de 95 días lo aprobó alguien con facultad?
- **PRY-205:** ¿el cambio CC-01 de 42 días fue aprobado y tiene línea base nueva?
- **PRY-209:** ¿se recibió a satisfacción el Licenciamiento de la plataforma de Sistemas Comerciales del Norte?

**Lo que no hice:**
- **Informe de comité:** no toca todavía. El comité es el 2026-11-06 y el informe sale el 2026-11-04.
- **Peticiones:** no las consulté, porque hoy no tocaban.
- **Registro:** dejé constancia solo del barrido. La confirmación no la marqué como corrida, porque no preguntó nada nuevo.

La corrida quedó registrada con su salida en `estado/corridas/salida-portfolio-wake.md`. Tardó 27 segundos y no pude medir el número de documentos.

**Vuelvo el 2026-10-24.**

## Respuesta 2

Estoy verificando el mapa guardado. Está completo, así que cierro.

**Cierre:** quedaron 3 entradas en el mapa, todas de la familia pmo: Vera (portafolio), Samuel (PRY-202) y Alba (PRD-301). No se dejó ninguna fuera. La organización quedó como "Portafolio retail", que es el nombre de la configuración de la PMO. Los términos 1.2 quedaron aceptados a nombre de José Francisco Ñáñez el 2026-10-23, con comprobante en `.criterio/terminos/`.

Pendiente, desde el setup de cada agente: marcar las carpetas de documentos de Vera (portafolio) y de Alba (PRD-301).

Para levantar el portal: `/criterio-server:server-start`.

## Respuesta 3

Rostrum está corriendo en **http://127.0.0.1:8789/**. Escucha solo en este equipo y no tiene autenticación.

Los puertos 8787 y 8788 ya los usan otros servidores. Esos tienen mapas distintos (otros productos, PRD-302 y PRD-306), así que no son este espacio. Levanté el mío en el 8789 y el `/estado.json` de ese puerto muestra los agentes de este mapa: Vera, Samuel (PRY-202) y Alba (PRD-301). El servidor sigue en segundo plano. Para pararlo, mata el proceso del puerto 8789.

**Términos:** están vigentes (versión 1.2, aceptada en 0.8.0). Quedó registrado a nombre de José Francisco Ñáñez, con fecha 2026-10-23. El recibo está en `.criterio/terminos/aceptacion-criterio-server-0.8.0-2026-10-23.md` y en PDF.

**Forma elegida:** «para mirarlo un rato», que es lo que indicó el argumento `rato`. No pedí ninguna infraestructura.

**Mapa contra el disco:** no hay entradas nuevas, desaparecidas ni sin estado. El informe de la PMO ya existe en `reportes/`, así que no hizo falta correr `portfolio-report`.

**Qué hay en cada ruta:**
| Ruta | Para quién |
|---|---|
| `/` | Todos: los 3 agentes del mapa y el formulario de peticiones |
| `/pmo`, `/decisiones` | PMO, comité y patrocinador |
| `/proyectos` (13), `/productos` (7) | Quien pregunta por un proyecto o un producto |
| `/caso/<código>` | Todo lo que los agentes hicieron sobre un caso, juntando familias |
| `/corridas` (33) | Quien audita |
| `/estado.json` | Un mecanismo, no una persona |

No aparecen `/familia/cfo`, `/familia/clo` ni `/vence`, porque este mapa solo tiene la familia PMO.

**Qué enlace pasarle a quién:**
- **Patrocinador:** `/` y `/decisiones`.
- **Gerencia:** `/proyectos`.

Esos enlaces solo funcionan mientras este equipo siga encendido y el servidor corriendo. Cada página dice de cuándo es lo que muestra. El informe se generó hoy, 2026-10-23, y ningún agente tiene todavía una corrida registrada, porque `ultimo` sale en `null` para los tres.

**Lo que Rostrum no hace:** no calcula, no escribe fichas, no autentica y no manda correos. Lo único que crea son las peticiones, en `peticiones/` del agente elegido, y no puede correr al agente.

**Para dejarlo corriendo:** hay que pedirle a la organización un host con puerto dentro de la red, publicarlo detrás de su control de acceso (`--abierto`) y que el equipo siga encendido. No necesita base de datos, certificado ni salida a internet.
