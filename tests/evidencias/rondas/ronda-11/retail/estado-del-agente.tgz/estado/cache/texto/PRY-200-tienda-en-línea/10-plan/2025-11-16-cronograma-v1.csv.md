<!-- origen: PRY-200-tienda-en-línea/10-plan/2025-11-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-04-05,2026-04-05,cerrado
Ambiente de pruebas certificado,2026-08-13,2026-08-13,cerrado
Integración con el ERP,2026-12-21,2026-12-21,en curso
