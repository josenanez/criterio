<!-- origen: PRY-199-iluminación-led-en-bodegas/20-seguimiento/2026-10-21-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Iluminación LED en bodegas

**Código:** PRY-199
**Fecha de corte:** 2026-10-21
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Congelamiento de cambios en temporada alta
