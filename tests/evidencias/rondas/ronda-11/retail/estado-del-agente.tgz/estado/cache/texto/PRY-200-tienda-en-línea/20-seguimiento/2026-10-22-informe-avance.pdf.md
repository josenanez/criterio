<!-- origen: PRY-200-tienda-en-línea/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tienda en línea
Código: PRY-200
Fecha de corte: 2026-10-22
Gerente: Beatriz Cuéllar

Estado declarado
Verde
Avance reportado: 65%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.773.884.950
Ejecutado 3.151.861.161
Proyección al cierre 6.409.425.869

Riesgos abiertos
- Concentración del conocimiento en una sola persona
