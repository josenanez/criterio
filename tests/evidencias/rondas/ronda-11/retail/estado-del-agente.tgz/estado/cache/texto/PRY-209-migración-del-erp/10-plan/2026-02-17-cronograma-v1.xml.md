<!-- origen: PRY-209-migración-del-erp/10-plan/2026-02-17-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño de la experiencia aprobado | 2026-04-07 | 2026-04-07 | 2026-04-07 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-05-16 | 2026-05-16 | 2026-05-16 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el ERP | 2026-06-25 | 2026-06-25 | 2026-06-25 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto en tiendas | 2026-08-03 | 2026-08-03 | 2026-08-03 | 100% | hito | 3FS | — |
| 5 | 5 | Despliegue en la cadena | 2026-09-12 | 2026-09-12 | 2026-09-12 | 100% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-04-07 | 2026-04-07 | cerrado |
| Ambiente de pruebas certificado | 2026-05-16 | 2026-05-16 | cerrado |
| Integración con el ERP | 2026-06-25 | 2026-06-25 | cerrado |
| Piloto en tiendas | 2026-08-03 | 2026-08-03 | cerrado |
| Despliegue en la cadena | 2026-09-12 | 2026-09-12 | cerrado |
