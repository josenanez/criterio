<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-10-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Pago con QR en caja
**Fecha:** 2026-10-10
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +42 días sobre la línea base vigente |
| Costo | 84.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
