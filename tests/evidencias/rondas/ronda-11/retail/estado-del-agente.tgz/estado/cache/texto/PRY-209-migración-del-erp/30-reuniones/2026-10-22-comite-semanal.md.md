<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-22-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Migración del ERP

**Fecha:** 2026-10-22
**Asistentes:** Liliana Torres, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 6 | 2026-11-07 |
