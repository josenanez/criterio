<!-- origen: PRY-203-reposición-automática/00-gobierno/2026-03-21-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Logística
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-03-21

## Objetivo del negocio

Entregar reposición automática para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-03-21.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-31 |
| Cierre | 2027-05-29 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
