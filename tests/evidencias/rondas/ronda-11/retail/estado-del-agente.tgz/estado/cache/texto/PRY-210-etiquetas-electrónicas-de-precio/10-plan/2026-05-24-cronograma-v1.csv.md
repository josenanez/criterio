<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2026-05-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-07-23,2026-07-23,cerrado
Ambiente de pruebas certificado,2026-09-12,2026-09-12,cerrado
Integración con el ERP,2026-11-02,2026-11-02,en curso
Piloto en tiendas,2026-12-22,2026-12-22,en curso
Despliegue en la cadena,2027-02-11,2027-02-11,en curso
