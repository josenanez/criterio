<!-- origen: PRY-209-migración-del-erp/10-plan/2026-10-19-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-07 | 2026-04-07 | cerrado
Ambiente de pruebas certificado | 2026-05-16 | 2026-05-16 | cerrado
Integración con el ERP | 2026-06-25 | 2026-06-25 | cerrado
Piloto en tiendas | 2026-08-03 | 2026-08-03 | cerrado
Despliegue en la cadena | 2026-09-12 | 2026-12-16 | cerrado
