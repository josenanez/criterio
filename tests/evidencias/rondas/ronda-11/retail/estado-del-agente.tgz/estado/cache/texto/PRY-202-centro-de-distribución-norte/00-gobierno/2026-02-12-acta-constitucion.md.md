<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2026-02-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Centro de distribución norte

**Código:** PRY-202
**Área dueña:** Tecnología
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-12

## Objetivo del negocio

Entregar centro de distribución norte para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité Comercial el 2026-02-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-22 |
| Cierre | 2027-03-05 |

## Criterio de éxito

Centro de distribución norte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
