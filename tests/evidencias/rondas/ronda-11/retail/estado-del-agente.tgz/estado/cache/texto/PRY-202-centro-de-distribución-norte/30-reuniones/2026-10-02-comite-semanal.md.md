<!-- origen: PRY-202-centro-de-distribución-norte/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-10-02
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-11-05 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-19 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 |
| Gustavo Neira | Aprobar el diseño 5 | 2026-11-14 |
| María Restrepo | Actualizar la matriz 6 | 2026-10-05 |
| Camilo Beltrán | Entregar el punto 8 | 2026-11-07 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| Elena Duarte | Validar el ambiente 12 | 2026-10-27 |
| Beatriz Cuéllar | Aprobar el diseño 13 | 2026-10-27 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-10-15 |
| Camilo Beltrán | Confirmar la fecha 15 | 2026-10-06 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-13 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Gustavo Neira): recibido, acta de recibo del 2026-10-02.

## Lo que se dijo

- Jorge Medina dice que ya entregó «validar el ambiente 4». No se presentó acta.
