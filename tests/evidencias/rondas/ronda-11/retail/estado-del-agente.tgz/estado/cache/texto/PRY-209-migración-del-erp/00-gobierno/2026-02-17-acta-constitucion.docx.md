<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-02-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración del ERP

Código: PRY-209

Área dueña: Tiendas

Patrocinador: Andrés Lozano

Gerente de proyecto: Liliana Torres

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-02-17

Objetivo del negocio

Entregar migración del erp para Tiendas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Expansión el 2026-02-17.

Fechas comprometidas

Fecha

Inicio

2026-02-27

Cierre

2026-09-12

Criterio de éxito

Migración del ERP en producción y medido.

Dependencias declaradas

• Ninguna declarada
