<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2025-06-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Tecnología

Patrocinador: Carlos Peña

Gerente de proyecto: Andrés Lozano

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2025-06-16

Objetivo del negocio

Entregar precios dinámicos para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Comercial el 2025-06-16.

Fechas comprometidas

Fecha

Inicio

2025-06-26

Cierre

2026-06-09

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
