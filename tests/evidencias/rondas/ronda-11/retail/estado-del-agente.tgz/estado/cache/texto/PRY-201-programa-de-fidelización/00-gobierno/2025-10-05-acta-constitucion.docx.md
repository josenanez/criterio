<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-10-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de fidelización

Código: PRY-201

Área dueña: Comercial

Patrocinador: Gustavo Neira

Gerente de proyecto: Diana Molina

Comité: Comité de Expansión

Producto asociado: puntos de fidelización

Fecha de aprobación: 2025-10-05

Objetivo del negocio

Entregar programa de fidelización para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Expansión el 2025-10-05.

Fechas comprometidas

Fecha

Inicio

2025-10-15

Cierre

2026-12-22

Criterio de éxito

Programa de fidelización en producción y medido.

Dependencias declaradas

• Ninguna declarada
