<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-10-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Tienda en línea

**Fecha:** 2026-10-18
**Asistentes:** Beatriz Cuéllar, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 21 | 2026-10-26 |
