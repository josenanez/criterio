<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2025-08-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pronóstico de demanda

**Código:** PRY-211
**Área dueña:** Mercadeo
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-09

## Objetivo del negocio

Entregar pronóstico de demanda para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-08-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-19 |
| Cierre | 2026-02-14 |

## Criterio de éxito

Pronóstico de demanda en producción y medido.

## Dependencias declaradas

- Ninguna declarada
