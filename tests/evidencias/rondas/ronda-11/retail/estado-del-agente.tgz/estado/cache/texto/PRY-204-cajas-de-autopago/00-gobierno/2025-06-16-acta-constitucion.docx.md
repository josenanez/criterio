<!-- origen: PRY-204-cajas-de-autopago/00-gobierno/2025-06-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cajas de autopago

Código: PRY-204

Área dueña: Comercio electrónico

Patrocinador: Ricardo Salas

Gerente de proyecto: Paula Céspedes

Comité: Comité de Arquitectura

Producto asociado: autopago en tienda

Fecha de aprobación: 2025-06-16

Objetivo del negocio

Entregar cajas de autopago para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2025-06-16.

Fechas comprometidas

Fecha

Inicio

2025-06-26

Cierre

2026-08-14

Criterio de éxito

Cajas de autopago en producción y medido.

Dependencias declaradas

• Ninguna declarada
