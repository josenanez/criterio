<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pronóstico de demanda
Código: PRY-211
Fecha de corte: 2026-10-15
Gerente: Carlos Peña

Estado declarado
Amarillo
Avance reportado: 25%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 800.000.000
Comprometido 590.473.314
Ejecutado 198.184.573
Proyección al cierre 797.057.248

Riesgos abiertos
- Concentración del conocimiento en una sola persona
