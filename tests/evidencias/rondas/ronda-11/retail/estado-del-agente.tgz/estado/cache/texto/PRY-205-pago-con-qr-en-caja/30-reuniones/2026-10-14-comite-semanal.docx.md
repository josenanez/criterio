<!-- origen: PRY-205-pago-con-qr-en-caja/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cadena de Abastecimiento · Pago con QR en caja

Fecha: 2026-10-14

Asistentes: Carlos Peña, Beatriz Cuéllar

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Diana Molina

Entregar el punto 13

2026-09-29
