<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-10-01-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-10-20,2025-10-20,cerrado
Ambiente de pruebas certificado,2025-11-27,2025-11-27,cerrado
Integración con el ERP,2026-01-04,2026-01-04,cerrado
Piloto en tiendas,2026-02-11,2026-02-11,cerrado
Despliegue en la cadena,2026-03-21,2026-05-02,cerrado
