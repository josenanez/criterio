<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-10-19
Gerente: Liliana Torres

Estado declarado
Rojo
Avance reportado: 58%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 1.797.792.500
Ejecutado 1.718.414.780
Proyección al cierre 6.340.008.359

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Cambio en la regulación de datos personales que puede mover el alcance
