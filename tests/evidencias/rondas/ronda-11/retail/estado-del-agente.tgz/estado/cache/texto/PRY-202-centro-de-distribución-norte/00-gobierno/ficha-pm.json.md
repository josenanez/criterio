<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-202",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "name": {
 "value": "Centro de distribución norte",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Tecnología",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "product": {
 "value": "",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "not_found",
 "note": "El acta dice «No aplica»"
 },
 "authority": {
 "value": "",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "not_found"
 },
 "sponsor": {
 "value": "Felipe Arango",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "manager": {
 "value": "Sandra Gil",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "committee": {
 "value": "Comité Comercial",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "phase": {
 "value": "",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "rojo",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 52,
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-18",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-02-22",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "end_date": {
 "value": "2027-03-05",
 "source": "10-plan/2026-02-12-cronograma-v1.xlsx",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-02-12",
 "start_date": "2026-02-22",
 "end_date": "2027-03-05",
 "reason": "Aprobación inicial del Comité Comercial",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño de la experiencia aprobado",
 "baseline_date": "2026-05-27",
 "current_date": "2026-05-27",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-02-12-cronograma-v1.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-08-29",
 "current_date": "2026-08-29",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-20-acta-recibo-ambiente-de-pruebas-certificado.pdf",
 "source": "10-plan/2026-02-12-cronograma-v1.xlsx"
 },
 {
 "name": "Integración con el ERP",
 "baseline_date": "2026-12-01",
 "current_date": "2026-12-01",
 "state": "pending",
 "evidence": "",
 "source": "10-plan/2026-02-12-cronograma-v1.xlsx"
 },
 {
 "name": "Piloto en tiendas",
 "baseline_date": "2027-03-05",
 "current_date": "2027-03-05",
 "state": "pending",
 "evidence": "",
 "source": "10-plan/2026-02-12-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "exclusions": [
 {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 }
 ]
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 2400000000,
 "source": "00-gobierno/2026-02-12-acta-constitucion.md",
 "source_date": "2026-02-12",
 "state": "found"
 },
 "committed": {
 "value": 1644951364,
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 955775977,
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 2392525628,
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Congelamiento de cambios en temporada alta",
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18"
 },
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf",
 "source_date": "2026-10-18"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo",
 "owner": "no_declarado",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "La prueba de carga de temporada no alcanzó el umbral pactado y se repite",
 "since": "2026-10-18",
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf"
 },
 {
 "what": "Se reprogramó el despliegue por el congelamiento de temporada de fin de año; el cronograma vigente sigue siendo el v1",
 "since": "2026-10-18",
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-18-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Óscar Ramírez",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-22",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-08",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 {
 "due_date": "2026-12-22",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt"
 }
 ],
 "nota": "En las notas del 2026-10-23 dijo que «no alcanzó» y se comprometió para el 22/12/2026"
 },
 {
 "who": "Mauricio Pérez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-21",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-12-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-21",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-09",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "nota": "Sigue listado con 2026-10-09 en la minuta del 2026-10-16; ningún acta lo cierra"
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-16",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ],
 "nota": "El 2026-10-02 dijo que ya lo entregó; no se presentó acta y dejó de aparecer en la lista"
 },
 {
 "who": "Gustavo Neira",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-11-14",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ],
 "nota": "La fecha 2026-10-05 pasó y siguió listada igual en tres minutas antes de moverse"
 },
 {
 "who": "Gustavo Neira",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-7.md"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Entregar el punto 8",
 "due_date": "2026-11-17",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "nota": "El 2026-10-16 dijo que ya lo entregó; no se presentó acta y dejó de aparecer en la lista"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-11-08",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-11-03",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Camilo Beltrán",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-16-acta-recibo-15.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-02",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "nota": "El 2026-10-16 dijo que ya lo entregó; no se presentó acta y dejó de aparecer en la lista"
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-16-acta-recibo-17.md"
 },
 {
 "who": "Liliana Torres",
 "what": "Cerrar la prueba 18",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "«por definir» en las minutas del 2026-10-09 y 2026-10-16"
 },
 {
 "who": "Gustavo Neira",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-29",
 "original_due_date": "2026-10-29",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-13",
 "original_due_date": "2026-11-13",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-06",
 "original_due_date": "2026-11-06",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "nota": "Dijo «la otra semana»; nadie dio fecha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-11-02",
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "nota": "Las notas dicen «queda para el 2026-11-02»; no nombran una promesa anterior"
 }
 ],
 "meta": {
 "record_updated": "2026-10-23",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
