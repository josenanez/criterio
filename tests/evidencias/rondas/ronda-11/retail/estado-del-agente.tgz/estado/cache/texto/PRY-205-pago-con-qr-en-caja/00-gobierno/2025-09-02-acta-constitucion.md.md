<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2025-09-02-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Mercadeo
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2025-09-02

## Objetivo del negocio

Entregar pago con qr en caja para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-09-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-12 |
| Cierre | 2026-03-21 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
