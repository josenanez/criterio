<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-20
Gerente: Carlos Peña

Estado declarado
Amarillo
Avance reportado: 35%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- La validación con dos tiendas se extendió una semana por el conteo de inventario

Presupuesto
COP
Aprobado 800.000.000
Comprometido 607.882.357
Ejecutado 365.683.825
Proyección al cierre 819.476.936

Riesgos abiertos
- Congelamiento de cambios en temporada alta
