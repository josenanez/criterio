<!-- origen: PRY-202-centro-de-distribución-norte/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de distribución norte
Código: PRY-202
Fecha de corte: 2026-10-18
Gerente: Sandra Gil

Estado declarado
Rojo
Avance reportado: 52%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.644.951.364
Ejecutado 955.775.977
Proyección al cierre 2.392.525.628

Riesgos abiertos
- Congelamiento de cambios en temporada alta
- Concentración del conocimiento en una sola persona
