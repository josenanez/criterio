<!-- origen: PRY-211-pronóstico-de-demanda/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Pronóstico de demanda

**Fecha:** 2026-10-12
**Asistentes:** Carlos Peña, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 25 | 2026-10-18 |
