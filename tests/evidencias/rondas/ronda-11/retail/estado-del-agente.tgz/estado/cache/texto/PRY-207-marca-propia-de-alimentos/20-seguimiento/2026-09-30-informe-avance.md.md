<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-09-30-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-09-30
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **70%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 283.314.415 |
| Ejecutado | 132.453.350 |
| Proyección al cierre | 742.507.103 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
