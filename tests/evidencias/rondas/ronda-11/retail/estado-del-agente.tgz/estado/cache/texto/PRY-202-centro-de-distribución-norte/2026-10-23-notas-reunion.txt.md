<!-- origen: PRY-202-centro-de-distribución-norte/2026-10-23-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión centro de distribución norte — 2026-10-23
estuvieron: Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Óscar Ramírez dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 22/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-02
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
