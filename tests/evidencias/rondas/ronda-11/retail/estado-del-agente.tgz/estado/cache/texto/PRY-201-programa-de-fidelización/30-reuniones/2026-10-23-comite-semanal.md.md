<!-- origen: PRY-201-programa-de-fidelización/30-reuniones/2026-10-23-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Programa de fidelización

**Fecha:** 2026-10-23
**Asistentes:** Diana Molina, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 3 | 2026-10-23 |
| Laura Vélez | Entregar el punto 36 | 2026-10-12 |
