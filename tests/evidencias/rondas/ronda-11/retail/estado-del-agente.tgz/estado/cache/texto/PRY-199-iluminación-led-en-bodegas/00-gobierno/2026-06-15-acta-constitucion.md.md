<!-- origen: PRY-199-iluminación-led-en-bodegas/00-gobierno/2026-06-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Iluminación LED en bodegas

**Código:** PRY-199
**Área dueña:** Comercial
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Expansión
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-15

## Objetivo del negocio

Entregar iluminación led en bodegas para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Expansión el 2026-06-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-25 |
| Cierre | 2027-12-22 |

## Criterio de éxito

Iluminación LED en bodegas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
