<!-- origen: PRY-201-programa-de-fidelización/10-plan/2026-10-23-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-09 | 2026-01-09 | cerrado
Ambiente de pruebas certificado | 2026-04-06 | 2026-04-06 | cerrado
Integración con el ERP | 2026-07-02 | 2026-07-02 | cerrado
Piloto en tiendas | 2026-09-26 | 2026-09-26 | cerrado
Despliegue en la cadena | 2026-12-22 | 2027-03-14 | en curso
