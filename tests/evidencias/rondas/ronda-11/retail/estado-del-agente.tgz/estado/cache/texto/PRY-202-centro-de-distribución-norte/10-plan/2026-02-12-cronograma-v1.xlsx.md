<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2026-02-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-05-27 | 2026-05-27 | cerrado
Ambiente de pruebas certificado | 2026-08-29 | 2026-08-29 | cerrado
Integración con el ERP | 2026-12-01 | 2026-12-01 | en curso
Piloto en tiendas | 2027-03-05 | 2027-03-05 | en curso
