<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Amarillo**

Avance reportado: **60%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.549.637.864 |
| Ejecutado | 2.471.333.613 |
| Proyección al cierre | 7.989.396.294 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
