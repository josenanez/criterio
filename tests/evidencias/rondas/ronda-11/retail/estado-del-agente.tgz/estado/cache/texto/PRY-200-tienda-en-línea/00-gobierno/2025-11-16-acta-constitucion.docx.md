<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2025-11-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tienda en línea

Código: PRY-200

Área dueña: Servicio al cliente

Patrocinador: Elena Duarte

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Expansión

Producto asociado: venta en línea

Fecha de aprobación: 2025-11-16

Objetivo del negocio

Entregar tienda en línea para Servicio al cliente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Expansión el 2025-11-16.

Fechas comprometidas

Fecha

Inicio

2025-11-26

Cierre

2026-12-21

Criterio de éxito

Tienda en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
