<!-- origen: PRY-202-centro-de-distribución-norte/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-09-25
**Asistentes:** Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Mauricio Pérez, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-21 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-07 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-16 |
| Gustavo Neira | Aprobar el diseño 5 | 2026-10-29 |
| María Restrepo | Actualizar la matriz 6 | 2026-10-05 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-04 |
| Camilo Beltrán | Entregar el punto 8 | 2026-10-25 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-07 |
| Elena Duarte | Validar el ambiente 12 | 2026-10-11 |
