<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Reposición automática
Código: PRY-203
Fecha de corte: 2026-10-18
Gerente: Andrés Lozano

Estado declarado
Rojo
Avance reportado: 74%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.386.886.242
Ejecutado 1.702.813.595
Proyección al cierre 6.959.550.295

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
