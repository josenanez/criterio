<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cajas de autopago
Código: PRY-204
Fecha de corte: 2026-10-20
Gerente: Paula Céspedes

Estado declarado
Rojo
Avance reportado: 48%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.007.409.712
Ejecutado 1.312.457.340
Proyección al cierre 3.171.678.820

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
