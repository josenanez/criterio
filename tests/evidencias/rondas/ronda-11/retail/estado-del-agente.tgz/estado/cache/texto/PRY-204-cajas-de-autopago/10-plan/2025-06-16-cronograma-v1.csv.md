<!-- origen: PRY-204-cajas-de-autopago/10-plan/2025-06-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-10-07,2025-10-07,cerrado
Ambiente de pruebas certificado,2026-01-19,2026-01-19,cerrado
Integración con el ERP,2026-05-02,2026-05-02,cerrado
Piloto en tiendas,2026-08-14,2026-08-14,cerrado
