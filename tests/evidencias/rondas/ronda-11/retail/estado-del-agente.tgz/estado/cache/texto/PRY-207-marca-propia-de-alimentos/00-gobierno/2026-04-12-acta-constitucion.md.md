<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-04-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Tiendas
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** marca propia
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar marca propia de alimentos para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2026-11-18 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
