<!-- origen: PRY-199-iluminación-led-en-bodegas/10-plan/2026-06-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-10-12 | 2026-10-12 | cerrado
Ambiente de pruebas certificado | 2027-01-29 | 2027-01-29 | en curso
Integración con el ERP | 2027-05-18 | 2027-05-18 | en curso
Piloto en tiendas | 2027-09-04 | 2027-09-04 | en curso
Despliegue en la cadena | 2027-12-22 | 2027-12-22 | en curso
