<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Domicilios en dos horas
Código: PRY-208
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Amarillo
Avance reportado: 60%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.130.672.330
Ejecutado 1.069.088.079
Proyección al cierre 4.044.502.668

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
