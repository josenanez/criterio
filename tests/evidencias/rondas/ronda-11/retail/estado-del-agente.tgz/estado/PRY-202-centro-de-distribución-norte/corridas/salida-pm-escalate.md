## Para decisión — Centro de distribución norte (PRY-202) · 2026-10-23

Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23. Sin tema en el argumento: revisé lo ya marcado como escalable (agenda del 10-23, ficha, acta, minutas, notas del 10-23, informe del 10-18).

**Resultado: un punto está listo para subir (autoridad no declarada). El segundo (fechas de diciembre contra el congelamiento) no se puede formular como decisión todavía: faltan datos que ningún documento trae. Lo digo abajo en vez de rellenarlo.**

---

### 1. ¿Qué puede decidir la gerente de proyecto en PRY-202: se le delega por escrito (alcance, fechas y recursos dentro del presupuesto aprobado), o toda decisión que mueva fecha o alcance va al Comité Comercial?

**Quién decide:** el acta no lo dice. Nombra al patrocinador (Felipe Arango), a la gerente (Sandra Gil) y al Comité Comercial como el que aprobó el presupuesto el 2026-02-12, pero no declara quién decide qué. Por la regla del comando, este es el primer punto que escala. Lo razonable es que decida el patrocinador, con el comité como instancia; esa es una inferencia, no un dato del acta.
**Si no se decide hoy:** la revisión con el proveedor es el 2026-11-02 (Óscar Ramírez), cuatro días antes del comité del 2026-11-06. Se hace sin saber si quien la lleva puede comprometer fechas o recursos, y cualquier acuerdo de esa revisión puede devolverse con un «eso no lo decide usted». Los compromisos de diciembre (documento 1 el 12-22, prueba 2 el 12-21) quedan sin quien pueda moverlos o protegerlos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Delegar por escrito a la gerente, con tope (p. ej. fechas hasta N días, recursos hasta el presupuesto aprobado) | Sin cambio | Decisiones en la semana, sin esperar comité | Ninguno en COP. El riesgo es de control: decisiones que mueven la línea base sin pasar por control de cambios |
| B. Confirmar que todo lo que mueva fecha, alcance o presupuesto lo decide el Comité Comercial | Sin cambio | Cada decisión espera al comité (el próximo es el 2026-11-06) | Ninguno en COP. Costo en días de espera por cada decisión |
| C. Dejarlo sin declarar | — | — | Es lo que hay hoy. Un gerente que no sabe qué puede decidir escala todo o no escala nada |

El monto del tope en A no sale de ningún documento; lo fija quien delega. Los costos en COP de A y B no se pueden calcular y no los estimo.

**Recomiendo: A, con tope escrito y registrado en el acta.** Cuesta una hoja y evita que la revisión del 11-02 y los compromisos de diciembre dependan de una decisión sin dueño. Es una recomendación sobre gobierno; el contenido del tope es de quien delega.

---

### 2. Fechas de diciembre contra el congelamiento de temporada — NO listo para escalar

La agenda del 10-23 lo marcó como el punto probable del comité. Para formularlo faltan datos que no están en ningún documento:

- **Fechas del congelamiento:** el informe del 10-18 lo menciona («se reprogramó el despliegue por el congelamiento de temporada de fin de año») sin decir desde cuándo ni hasta cuándo.
- **Nueva fecha del despliegue:** no se declara. El cronograma vigente sigue siendo el v1 (hito «Integración con el ERP» 2026-12-01, cierre 2027-03-05). No hay solicitud de cambio.
- **Qué bloquea «Enviar el documento 1» y «Cerrar la prueba 2»:** las minutas solo registran las fechas movidas, seis veces (Óscar Ramírez) y cinco (Mauricio Pérez), sin causa.
- **Opciones y costo:** ningún documento del proveedor ni del presupuesto da una alternativa con costo. La nota del 10-23 «Laura Vélez manda el ajuste del presupuesto la otra semana» no tiene fecha; no he visto ese ajuste.

**Qué sí se sabe y cuenta:** presupuesto aprobado 2.400.000.000 COP, proyección declarada 2.392.525.628 COP (8,6 millones de margen, 0,3 %); comprometido 1.644.951.364 (68,5 %); estado declarado rojo, avance 52 %. Cualquier opción de dinero casi no tiene holgura.

**Efecto en otros proyectos:** no calculado. `impact` necesita los días que se mueve la fecha y nadie los ha declarado. Si el despliegue se mueve, será control de cambios, no un escalamiento, y ahí se corre `impact` con los días reales. Tampoco hay dependencias declaradas en el acta («Ninguna declarada»), así que el cálculo no tendría con qué cruzar los proyectos alcanzados.

**Para que este punto esté listo antes del 11-06:**
1. Sandra Gil obtiene de Óscar Ramírez y Mauricio Pérez la causa del bloqueo, en la revisión del 11-02 como límite.
2. Se consigue la ventana exacta del congelamiento.
3. Se consigue la propuesta del proveedor con su costo, si hay.
Con esas tres cosas se formula como pregunta cerrada y se corre `impact` si mueve una fecha.

---

### Lo que no escala
- **Riesgos e incidencias sin doliente** del informe del 10-18 (congelamiento, conocimiento concentrado, prueba de carga bajo el umbral) y el riesgo del proveedor que nadie anotó el 10-23: asignarlos es de la gerente. No es una decisión de comité.
- **Presupuesto:** proyección dentro del aprobado; no excede nada.
- **Vencidos sin evidencia** (anexo 3, prueba 10, ambiente 4, anexo 11, documento 9, anexo 19): se destraban con una llamada o un acta; van a la agenda de seguimiento, no al comité.
- **Camilo Beltrán, «Entregar el punto 8»:** tres reprogramaciones (umbral), pero el doliente está en el proyecto y no hay efecto fuera de él.

### A quién alcanza
No se puede decir: el acta no declara dependencias y no hay días declarados. Para el punto 1 no aplica (es una decisión de gobierno interna).

### Mis hitos por los que pasa
Sin días de movimiento no se calculó. Hitos pendientes vigentes: Integración con el ERP 2026-12-01 y Piloto en tiendas 2027-03-05 (cronograma v1).

### De dónde sale esto
- Autoridad no declarada, patrocinador, comité, presupuesto aprobado, fechas, dependencias «ninguna declarada»: `00-gobierno/2026-02-12-acta-constitucion.md`.
- Estado rojo, 52 %, cifras de presupuesto, congelamiento, prueba de carga, riesgos abiertos: `20-seguimiento/2026-10-18-informe-avance.pdf`.
- Reprogramaciones de «documento 1» y «prueba 2»: minutas `30-reuniones/2026-09-11` a `2026-10-16-comite-semanal.md` y `2026-10-23-notas-reunion.txt`.
- Revisión con el proveedor 11-02, ajuste de presupuesto sin fecha, riesgo del proveedor: `2026-10-23-notas-reunion.txt`.
- Hitos y versión de línea base: `10-plan/2026-02-12-cronograma-v1.xlsx` (vía la ficha `records/PRY-202.json`).
- Fecha del comité 2026-11-06: `config.json`.

El comando no escala solo ni llama al patrocinador: llevar el punto 1 al comité o al patrocinador es de Sandra Gil.
