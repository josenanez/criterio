# Plan — Centro de distribución norte (PRY-202) · borrador del 2026-10-23
**Desde:** acta de constitución del 2026-02-12 (`00-gobierno/2026-02-12-acta-constitucion.md`) · **Criterio de éxito:** «Centro de distribución norte en producción y medido» (acta).

Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Hay dos configuraciones en la carpeta (`producto/PRD-301` y `proyecto/PRY-202`); este comando usó la de proyecto, PRY-202.

> Nota de contexto: el proyecto ya está en curso (inicio 2026-02-22, informe rojo al 2026-10-18). Esto es un plan **retroactivo** sobre un acta que ya existe; no es una línea base nueva.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance real.** Dice «Componente 1, Componente 2, Componente 3» y, como exclusión, «Lo que otro proyecto cubre» | No hay entregables que descomponer. Cualquier WBS construida sobre esto inventa el alcance; aquí solo se usan los hitos del cronograma v1 y el criterio de éxito. La exclusión no nombra a qué proyecto, así que no se puede verificar |
| **Autoridad del gerente** (no declarada; la ficha lo marca `not_found`) | No se sabe qué puede decidir Sandra Gil al planificar y qué debe subir. Todo cambio de plan queda sin ruta de aprobación clara |
| **Criterio de éxito sin medida.** «En producción y medido»: ¿medido contra qué métrica y qué umbral? | No se puede saber cuándo se termina el último nodo, ni quién acepta |
| **Objetivo del negocio genérico** («Entregar centro de distribución norte para Tecnología») | No hay beneficio que priorice qué recortar si el plan se aprieta |
| **Dependencias: «Ninguna declarada»**, aunque hay un proveedor (notas del 2026-10-23) y un congelamiento de temporada (informe del 2026-10-18) | El orden de abajo omite dependencias externas que ya existen en la práctica |
| **Producto asociado: «No aplica»** | Sin producto, no hay requerimiento aceptado del que trazar los entregables |

Patrocinador (Felipe Arango) y comité (Comité Comercial) sí están declarados. Sigo con el plan marcando los huecos; no los relleno.

## WBS
Los nodos salen del cronograma v1 (`10-plan/2026-02-12-cronograma-v1.xlsx`), no del acta: el acta no tiene entregables. Eso se declara en cada fila.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado (hito 2026-05-27, cerrado) | Sin definir | Cronograma v1. Sin evidencia de aceptación en la carpeta | Vacía |
| 2 | Ambiente de pruebas certificado (hito 2026-08-29, cerrado) | Sin definir | Cronograma v1; recibo en `20-seguimiento/2026-10-20-acta-recibo-ambiente-de-pruebas-certificado.pdf` | Vacía |
| 3 | Prueba de carga de temporada que alcance el umbral pactado | Sin definir (el umbral tampoco está en la carpeta) | Informe de avance 2026-10-18: «no alcanzó el umbral pactado y se repite» | Vacía |
| 4 | Integración con el ERP (hito 2026-12-01, en curso) | Sin definir | Cronograma v1 | Vacía |
| 5 | Despliegue (reprogramado por el congelamiento de temporada) | Sin definir | Informe 2026-10-18; **supuesto** de que es un entregable propio, el cronograma v1 no lo lista | Vacía |
| 6 | Piloto en tiendas (hito 2027-03-05, en curso) | Sin definir | Cronograma v1; coincide con el cierre del acta | Vacía |
| 7 | Centro en producción y medido | Sin definir (patrocinador: Felipe Arango, **supuesto** de quién acepta) | Criterio de éxito del acta | Vacía |

«Componente 1/2/3» del acta no se mapea a ningún nodo: no hay forma de saber cuál corresponde a cuál.

## Orden
Sin fechas; solo qué necesita qué.
- 1 → 2 → 4 (cronograma v1, secuencia de hitos; que el diseño preceda al ambiente es **supuesto**).
- 3 necesita 2 (el ambiente de pruebas certificado) y es previo al despliegue (5) (**supuesto**).
- 5 necesita 3 y 4, y una ventana fuera del congelamiento de temporada (informe 2026-10-18).
- 6 necesita 5. 7 necesita 6.
- Dependencia externa sin registrar: el equipo completo del proveedor para la siguiente fase (notas 2026-10-23).

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v1 equivalen a los entregables del proyecto | Si «Componente 1-3» son otra cosa, la WBS entera está mal |
| El despliegue es un entregable propio entre la integración y el piloto | Si está dentro del piloto, el nodo 5 sobra y el congelamiento afecta al piloto |
| La secuencia 1→2→4 y 3→5→6→7 es correcta | Cambia la ruta crítica y las dependencias |
| El patrocinador acepta el entregable final | Si acepta otro rol, el nodo 7 no tiene doliente real |
| El cronograma v1 sigue siendo la referencia vigente (la ficha lo registra así: fechas vigentes = base) | El informe dice que hubo reprogramación sin que haya cronograma nuevo; el plan real pudo moverse |

## Sin definir
| Qué | Quién lo define |
|---|---|
| Alcance de «Componente 1, 2, 3» | Felipe Arango (patrocinador) con Sandra Gil |
| Quién acepta cada entregable | Felipe Arango / Comité Comercial |
| Umbral de la prueba de carga y su fuente | Sandra Gil con el equipo técnico |
| Qué es «medido» en el criterio de éxito | Felipe Arango |
| Autoridad de la gerente de proyecto | Felipe Arango |
| Fecha y duración del congelamiento de temporada | No nombrado en ningún documento |
| Qué proyecto cubre lo excluido | Sandra Gil / PMO |

## Proyectos análogos
Ninguno a la vista: la configuración no apunta a una carpeta de fichas de la PMO. Es la respuesta correcta; no hay referencia para estimar.

## Preguntas para el equipo
Una por cada duración vacía:
1. Diseño de la experiencia: ¿cuánto tomó y quién lo aceptó? ¿Hay acta?
2. Ambiente de pruebas: el hito era 2026-08-29 y el acta de recibo es del 2026-10-20. ¿Cuál es la fecha real de certificación?
3. Prueba de carga: ¿cuánto toma repetirla y cuál es el umbral pactado?
4. Integración con el ERP: ¿cuánto falta, con el hito del 2026-12-01 y estado «en curso»?
5. Despliegue: ¿cuánto toma y en qué ventana cabe respecto del congelamiento de fin de año?
6. Piloto en tiendas: ¿cuántas tiendas, cuánto dura y cuándo se mide?
7. Producción y medición: ¿qué se mide, durante cuánto tiempo y contra qué valor?

## Para comprometer una fecha falta
- Disponibilidad real del equipo (la ficha ya marca «concentración del conocimiento en una sola persona» sin doliente).
- La fecha del proveedor y su confirmación del equipo completo (notas 2026-10-23; no registrado como riesgo).
- La ventana del congelamiento de temporada: no está en ningún documento.
- Un cronograma vigente: el único es el v1 y el informe dice que ya hubo reprogramación.
- El resultado de la repetición de la prueba de carga.

## Después
Si el plan se aprueba, ofrezco registrarlo como línea base original **(la v1 de la ficha ya existe: habría que decidir si esto la reemplaza o es una v2 con su motivo)** y pasar los supuestos al RAID con doliente. Hoy el RAID de la ficha tiene tres riesgos sin doliente y cero supuestos.

*No se comprometió ninguna fecha, no se asignó a nadie y no se estimó por analogía.*
