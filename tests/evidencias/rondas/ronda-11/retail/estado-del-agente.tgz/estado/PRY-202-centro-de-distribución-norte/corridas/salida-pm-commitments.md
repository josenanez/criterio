## Compromisos — Centro de distribución norte (PRY-202) · al 2026-10-23

Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23. 26 compromisos en el registro: 3 cumplidos con documento, 23 abiertos (6 vencidos, 2 sin fecha, 3 reprogramados 3 veces o más).

### Se viene reprogramando

> **Óscar Ramírez** · Enviar el documento 1
> Prometido hoy para el 2026-12-22, y antes para el 12-08, 11-17, 11-05, 10-21 y 10-09. La primera promesa fue el 2026-10-02: **6 reprogramaciones**. Hoy dijo que «no alcanzó».
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Mauricio Pérez** · Cerrar la prueba 2
> Prometido para el 2026-12-21, y antes para el 12-01, 11-19, 11-07 y 10-19. La primera promesa fue el 2026-09-30: **5 reprogramaciones**.
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Camilo Beltrán** · Entregar el punto 8
> Prometido para el 2026-11-17, y antes para el 11-07 y 10-25. La primera promesa fue el 2026-10-10: **3 reprogramaciones**.
> **Tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 | 17 días |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 | 14 días |
| Jorge Medina | Validar el ambiente 4 | 2026-10-16 (antes 10-02) | 7 días |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 | 3 días |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 (antes 10-07) | 1 día |
| Gustavo Neira | Revisar el anexo 19 | 2026-10-22 | 1 día |

Jorge Medina dijo el 2026-10-02 que ya había entregado el ambiente 4, pero no hay acta que lo respalde y desapareció de la lista. El acta de recibo del 2026-10-20 es del «Ambiente de pruebas certificado» y no nombra el ambiente 4, así que no lo cierra.

### Dicho como entregado, sin documento (siguen abiertos)
| Quién | Qué | Fecha vigente | Nota |
|---|---|---|---|
| Javier Hoyos | Entregar el punto 16 | 2026-11-02 | El 10-16 dijo que ya lo entregó; no hay acta |
| Elena Duarte | Validar el ambiente 12 | 2026-10-27 | El 10-16 dijo que ya lo entregó; no hay acta |

### Vencen en los próximos 7 días
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Actualizar la matriz 6 (antes 10-05) | 2026-10-26 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-26 |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-27 |
| Elena Duarte | Validar el ambiente 12 (ver arriba) | 2026-10-27 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-29 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Liliana Torres | Cerrar la prueba 18 («por definir»; no estuvo en la reunión de hoy) | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», nadie dio fecha) | 2026-10-23 |

### Cerrados desde la última revisión
| Quién | Qué | Documento |
|---|---|---|
| Gustavo Neira | Confirmar la fecha 7 | 20-seguimiento/2026-10-02-acta-recibo-7.md |
| Camilo Beltrán | Confirmar la fecha 15 | 20-seguimiento/2026-10-16-acta-recibo-15.md |
| Elena Duarte | Enviar el documento 17 | 20-seguimiento/2026-10-16-acta-recibo-17.md |

## Después
- **Decisión para el comité (propuesta):** el documento 1 de Óscar Ramírez y la prueba 2 de Mauricio Pérez superan el umbral de 3 reprogramaciones y su fecha vigente cae en diciembre, cerca del congelamiento de temporada que el informe del 10-18 ya menciona. Si quieres, lo formulo con `/pm-escalate`: qué se pide, qué pasa si nadie decide y quién tiene la facultad.
- `/pm-publish` es opcional: ningún compromiso cambió un campo de la ficha.
