## Listo — PRY-202 · Centro de distribución norte

**Lo que miré:** 14 documentos · 6 minutas (2026-09-11 a 2026-10-16) más las notas de hoy 2026-10-23 · la última minuta es del 2026-10-16. Leí las seis en orden, de la más vieja a la más nueva, y las tres actas de recibo de compromisos. Todo se pudo leer.
**Configuración:** gerente Sandra Gil (acta de constitución) · reunión de seguimiento los viernes (así están fechadas las minutas) · estado en `estado/PRY-202-centro-de-distribución-norte` · carpeta marcada con `_CRITERIO_PROYECTO.txt`.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-23 para la versión 0.8.0 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 c83631fe2c4cd4b0… (md) y e1748c5331c09218… (pdf).

Son 26 compromisos en total: 3 cerrados con acta, 6 vencidos sin evidencia, 2 sin fecha y 15 abiertos (la tabla de abajo trae los 21 que siguen sin cerrar, con fecha o sin ella aparte). Esta sesión no tenía a quién preguntarle, así que tomé la respuesta sugerida en cada pregunta.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-12-22 (original 2026-10-02) | **6 reprogramaciones**: 10-09, 10-21, 11-05, 11-17, 12-08, 12-22. Cita: minuta 2026-09-11, y notas 2026-10-23 («no alcanzó… 22/12/2026») |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-12-21 (original 2026-09-30) | **5 reprogramaciones**: 10-19, 11-07, 11-19, 12-01, 12-21. Cita: minuta 2026-09-11 |
| Camilo Beltrán | Entregar el punto 8 | 2026-11-17 (original 2026-10-10) | **3 reprogramaciones**: 10-25, 11-07, 11-17. Cita: minuta 2026-09-18 |
| Gustavo Neira | Aprobar el diseño 5 | 2026-11-14 (original 2026-10-08) | 2 reprogramaciones. Cita: minuta 2026-09-18 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-16 (original 2026-10-02) | 1. **Vencido sin evidencia.** El 10-02 dijo que ya lo entregó; no se presentó acta |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 (original 2026-10-07) | 1. **Vencido sin evidencia** (1 día) |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 | **Vencido sin evidencia** (14 días); sigue listado igual el 10-16 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 | **Vencido sin evidencia** (17 días) |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 | **Vencido sin evidencia** (3 días) |
| Gustavo Neira | Revisar el anexo 19 | 2026-10-22 | **Vencido sin evidencia** (1 día) |
| María Restrepo | Actualizar la matriz 6 | 2026-10-26 (original 2026-10-05) | 1; la fecha 10-05 pasó y se repitió en tres minutas antes de moverse |
| Elena Duarte | Validar el ambiente 12 | 2026-10-27 (original 2026-10-11) | 1. El 10-16 dijo que ya lo entregó; no se presentó acta |
| Javier Hoyos | Entregar el punto 16 | 2026-11-02 (original 2026-10-13) | 1. El 10-16 dijo que ya lo entregó; no se presentó acta |
| Beatriz Cuéllar | Aprobar el diseño 13 | 2026-11-08 (original 2026-10-27) | 1 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-11-03 (original 2026-10-15) | 1 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-29 | — |
| Elena Duarte | Aprobar el diseño 21 | 2026-11-13 | — |
| Jorge Medina | Actualizar la matriz 22 | 2026-11-06 | — |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-26 | — |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-27 | — |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | Nuevo, de las notas de hoy |

Cerrados con acta de recibo: Confirmar la fecha 7 (Gustavo Neira, acta 2026-10-02), Confirmar la fecha 15 (Camilo Beltrán, acta 2026-10-16) y Enviar el documento 17 (Elena Duarte, acta 2026-10-16).

El compromiso de Óscar Ramírez y el de Mauricio Pérez no son seis y cinco compromisos vencidos: cada uno es un solo compromiso que se ha vuelto a prometer con fecha nueva en cada reunión. Eso apunta a un bloqueo que nadie ha nombrado.

### Sin fecha
- Liliana Torres — Cerrar la prueba 18: «por definir» desde la minuta del 2026-10-09. Hoy no estuvo en la reunión.
- Laura Vélez — Mandar el ajuste del presupuesto: dijo «la otra semana» (notas 2026-10-23). No es una fecha y no la calculé.

No pueden vencer, y por eso son los que desaparecen de los informes.

### Otras señales que levantó el cálculo
- **Hito declarado cerrado sin acta:** «Diseño de la experiencia aprobado» (2026-05-27) figura `cerrado` en el cronograma y no hay acta de recibo (149 días). El acta del 2026-10-20 prueba solo el «Ambiente de pruebas certificado».
- **Estado declarado:** rojo, 52 % de avance (informe del 2026-10-18). El plan sustenta entre 50 % y 75 %, con 2 de 4 hitos cerrados. Las señales de arriba no figuran en el informe.
- **Presupuesto (COP):** aprobado 2.400.000.000 · comprometido 1.644.951.364 (68,5 %) · ejecutado 955.775.977 (39,8 %) · proyección al cierre 2.392.525.628 (−0,3 % sobre el aprobado). Las cifras vienen del informe, que es una declaración.
- **Riesgo que nadie anotó:** en las notas de hoy se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. Lo dejé en la ficha, sin dueño.
- **Sin autoridad de decisión:** el acta no dice hasta qué monto o cambio de alcance decide la gerente sin subir a comité.

### Qué le falta a tu carpeta
- **Cronograma vigente:** el informe dice que se reprogramó el despliegue, pero el único cronograma es el v1 del 2026-02-12 y su cierre (2027-03-05) coincide con el acta. Falta el v2, o no se puede medir ningún atraso.
- **Actas de recibo** de lo que dicen haber entregado Jorge Medina (ambiente 4), Elena Duarte (ambiente 12) y Javier Hoyos (punto 16), y del hito «Diseño de la experiencia aprobado». Sin ellas, lo cumplido se ve igual que lo incumplido.
- **Acta de constitución:** alcance de tres «Componentes» sin nombre, «Ninguna declarada» en dependencias, y sin autoridad ni fase.
- **Minutas:** la carpeta tiene seis, todas del 2026-09-11 en adelante. Las anteriores, si existen, permitirían ver desde cuándo se mueven las fechas de Óscar Ramírez y Mauricio Pérez.
- **Notas de hoy:** están sueltas en la raíz del proyecto. Pasarlas a `30-reuniones/` las deja donde las busca el barrido.

**Cuándo vuelvo:** las notas de hoy dicen «próxima reunión en dos semanas», así que apunté el viernes 2026-11-06, con cadencia semanal de los viernes. La ficha quedó sin sellar: leí todo lo que había, y el sello lo pone el comando que la publica.
