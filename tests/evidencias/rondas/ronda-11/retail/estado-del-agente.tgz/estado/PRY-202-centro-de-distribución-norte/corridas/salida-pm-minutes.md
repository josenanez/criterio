# Acta — Centro de distribución norte (PRY-202) · 2026-10-23
**Asistieron (13):** Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-23-notas-reunion.txt` (notas de 5 líneas, no transcripción) · **Ausentes con tema en agenda:** no hay agenda en el expediente. Liliana Torres estuvo en los comités del 10-09 y 10-16 y hoy no figura; tiene abierto «Cerrar la prueba 18» (sin fecha).

Los términos vigentes (v1.2) están aceptados por José Francisco Ñáñez, 2026-10-23.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-12-22 | **Reprogramado por 6.ª vez.** Original 2026-10-02 → 10-09 → 10-21 → 11-05 → 11-17 → 12-08 → 12-22. Dijo que lo anterior «no alcanzó». Pasa el umbral de 3 reprogramaciones. |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | Nuevo. Ver «Sin resolver»: no queda claro si es promesa suya o una cita agendada. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dijo «la otra semana», nadie dio fecha (`due_date: no_declarada`) |

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Las notas no dicen qué quedó pendiente de decisión. Dos puntos que implican una decisión que nadie tomó:

| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace con el ajuste del presupuesto | Laura Vélez lo va a mandar, pero el presupuesto aprobado sigue en 2.400.000.000 COP (acta del 2026-02-12) y no hay solicitud de cambio | El Comité Comercial, por el acta de constitución |
| Cada cuánto se reúne el comité | Se dijo «próxima reunión en dos semanas»; la configuración y los comités previos son semanales | No consta en el expediente |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | No atribuido: las notas dicen «se comentó» | Riesgo (dependencia del proveedor) | **No.** El acta de constitución declara «Ninguna» dependencia y la ficha no tiene proveedor ni dependencias. Queda en la ficha como riesgo sin doliente |

## Cerrado en esta reunión
Se omite: ningún compromiso se cerró con documento.

## Lo que esta reunión contradice
Ningún campo de la ficha (patrocinador, fechas, comité, presupuesto). Dos puntos para vigilar:

| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Frecuencia del comité | «Próxima reunión en dos semanas» | Comité semanal, próximo 2026-11-06 | Notas 2026-10-23 / `config.json` |
| Presupuesto | Habrá un «ajuste» | 2.400.000.000 COP, sin cambio registrado | Notas 2026-10-23 / acta de constitución 2026-02-12 |

## Sin resolver de la transcripción
- «la otra semana» (Laura Vélez): no queda claro si es la semana siguiente o la subsiguiente. No se eligió.
- «revisión con el proveedor, queda para el 2026-11-02» (Óscar Ramírez): no queda claro si Óscar se comprometió a hacer la revisión o solo quedó agendada con él. Se registró como compromiso suyo, a confirmar.
- «lo de enviar el documento 1 no alcanzó»: se tomó como «Enviar el documento 1», único compromiso de Óscar con ese nombre.
- «22/12/2026»: leído día/mes/año (22 no puede ser mes).
- «se comentó…»: nadie quedó como autor del comentario sobre el proveedor.

## Lo que sigue pesando del expediente (no se habló hoy)
Seis compromisos vencidos sin acta que los cierre: Javier Hoyos (anexo 3, 14 días; prueba 10, 17 días), Jorge Medina (ambiente 4, 7 días; anexo 11, 1 día), Rubén Cárdenas (documento 9, 3 días), Gustavo Neira (anexo 19, 1 día). Las notas de hoy no los mencionan. Además, Mauricio Pérez lleva 5 reprogramaciones («Cerrar la prueba 2», hoy 12-21) y Camilo Beltrán 3 («Entregar el punto 8», hoy 11-17).

Siguiente paso: `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por ahora: el acta no cambia ningún campo de la ficha.
