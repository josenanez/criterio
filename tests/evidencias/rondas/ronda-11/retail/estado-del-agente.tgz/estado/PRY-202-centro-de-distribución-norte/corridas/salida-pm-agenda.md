## Reunión de seguimiento — Centro de distribución norte (PRY-202) · 2026-11-06
11 puntos · 35 minutos · 10 personas requeridas

Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23.

Supuestos de esta agenda: la fecha es la del comité configurado (2026-11-06; las notas del 10-23 dicen «próxima reunión en dos semanas», que coincide). Sin tiempo indicado, tomé 45 minutos y la suma es 35. Es la **primera corrida**: no hay foto previa, así que «qué cambió» se leyó contra la minuta del 10-16 y las notas del 10-23, y el anexo no puede decir «sin cambios desde». Las antigüedades se cuentan a hoy, 2026-10-23; para el 11-06 serán 14 días mayores.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y salir con una fecha que no sea una estimación** · 8 min · **Óscar Ramírez**
> Prometido para el 2026-12-22, y antes para el 12-08, 11-17, 11-05, 10-21, 10-09 y 10-02. Seis reprogramaciones. El 10-23 dijo que «no alcanzó».
> Fuente: minutas 2026-09-11, 09-18, 09-25, 10-02, 10-09, 10-16 y notas 2026-10-23.
> **Si no se resuelve hoy:** la entrega cae el 12-22, dentro de la ventana del congelamiento de temporada que menciona el informe del 10-18, y cualquier reprogramación posterior no tiene margen.

> **[2] Nombrar qué bloquea «Cerrar la prueba 2» y qué se necesita de otros para cerrarla** · 8 min · **Mauricio Pérez**
> Prometido para el 2026-12-21, y antes para el 12-01, 11-19, 11-07, 10-19 y 09-30. Cinco reprogramaciones.
> Fuente: minutas 2026-09-11, 09-18, 09-25, 10-02, 10-09, 10-16.
> **Si no se resuelve hoy:** misma ventana de diciembre. El informe del 10-18 también registra que la prueba de carga no alcanzó el umbral y se repite; el registro no dice si es la misma prueba, y conviene preguntarlo aquí.

> **[3] Nombrar qué bloquea «Entregar el punto 8»** · 4 min · **Camilo Beltrán**
> Prometido para el 2026-11-17, y antes para el 11-07, 10-25 y 10-10. Tres reprogramaciones (el umbral para marcarlo).
> Fuente: minutas 2026-09-18, 09-25, 10-02, 10-16.
> **Si no se resuelve hoy:** pasa a ser el tercer compromiso con fecha que ya no se sostiene.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 | Acta de cierre o fecha nueva | 3 (junto con el anexo 3) |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 | Sigue listado con 10-09 en la minuta del 10-16; ningún acta lo cierra | — |
| Jorge Medina | Validar el ambiente 4 | 2026-10-16 (antes 10-02) | El 10-02 dijo que ya lo entregó; falta el acta. El acta del 10-20 es del «Ambiente de pruebas certificado» y no nombra el ambiente 4 | 3 (junto con el anexo 11) |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 (antes 10-07) | Acta o fecha nueva | — |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 | Documento o fecha nueva | 1 |
| Gustavo Neira | Revisar el anexo 19 | 2026-10-22 | Revisión o fecha nueva | 1 |

Fuente: minutas 2026-09-11, 09-25, 10-09, 10-16 y notas 2026-10-23.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar como riesgo que el proveedor podría no llegar con el equipo completo para la siguiente fase, con doliente y fecha de revisión (se comentó el 10-23 y nadie lo anotó). Óscar Ramírez tiene la revisión con el proveedor el 11-02, antes de esta reunión: qué se lleva a esa revisión | Sandra Gil, con Óscar Ramírez | Un riesgo hablado en voz alta y sin dueño; la revisión del 11-02 se hace sin saber qué preguntar. Fuente: notas 2026-10-23 | 3 |
| Fecha para «Mandar el ajuste del presupuesto» («la otra semana», nadie dio fecha) | Laura Vélez | Compromiso sin fecha que no puede vencer ni verificarse. Fuente: notas 2026-10-23 | 1 |
| Fecha para «Cerrar la prueba 18» («por definir» desde el 10-09; no estuvo el 10-23) | Liliana Torres (si no asiste, se fija por escrito antes) | Igual: sin fecha no vence. Fuente: minutas 2026-10-09 y 10-16 | 1 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Actualizar la matriz 6 (antes 10-05) | 2026-10-26 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-26 |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-27 |
| Elena Duarte | Validar el ambiente 12 — el 10-16 dijo que ya lo entregó, sin acta | 2026-10-27 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-29 |
| Javier Hoyos | Entregar el punto 16 — el 10-16 dijo que ya lo entregó, sin acta | 2026-11-02 |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-11-03 |
| Jorge Medina | Actualizar la matriz 22 | 2026-11-06 |

Dos minutos para pedir el acta de los dos «ya entregado» (Elena Duarte, Javier Hoyos); el resto se revisa por escrito, no en la sala. Fuente: minutas 2026-10-02, 10-09, 10-16 y notas 2026-10-23.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Fechas de diciembre de «documento 1» y «prueba 2» frente al congelamiento de temporada | Si el bloqueo de los puntos 1 y 2 no se destraba en la sala, la decisión (mover el congelamiento, recursos, alcance) excede lo que puede decidir la gerente de proyecto | Comité: `/pm-escalate` para formularla |
| El despliegue se reprogramó por el congelamiento, pero el cronograma vigente sigue siendo el v1 | Cambiar la línea base es control de cambios, no un punto de seguimiento. Fuente: informe de avance 2026-10-18 | Control de cambios / Comité Comercial |
| Riesgos e incidencias sin doliente en el informe del 10-18 (congelamiento en temporada alta, conocimiento concentrado en una persona, prueba de carga bajo el umbral) | Asignar dolientes es del gerente; no necesita a la sala completa | Sandra Gil, por escrito |

### Anexo — lo que no entra a la sala
No hay referencia previa, así que esto es lo que no entra a la sala por fecha, no «lo que no cambió»:
- Gustavo Neira · Aprobar el diseño 5 — 2026-11-14 (antes 10-29 y 10-08).
- Beatriz Cuéllar · Aprobar el diseño 13 — 2026-11-08 (antes 10-27).
- Elena Duarte · Aprobar el diseño 21 — 2026-11-13.
- Cerrados con documento: Confirmar la fecha 7 (Gustavo Neira), Confirmar la fecha 15 (Camilo Beltrán), Enviar el documento 17 (Elena Duarte).

---
Esta agenda no convoca a nadie ni decide prioridades entre puntos que compitan; la política del patrocinador (Felipe Arango, no asistió el 10-23) la lee la gerente. Cuando la reunión termine, `/pm-minutes` sobre las notas o la transcripción.
