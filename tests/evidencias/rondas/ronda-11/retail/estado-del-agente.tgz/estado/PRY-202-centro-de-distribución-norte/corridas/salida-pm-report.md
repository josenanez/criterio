# Centro de distribución norte (PRY-202) — semana del 2026-10-17 al 2026-10-23

**Declara el gerente:** rojo · 52 % · al 2026-10-18 (5 días; vigente, el umbral es 14). Fuente: `20-seguimiento/2026-10-18-informe-avance.pdf`.
*Sesión sin interfaz: nadie declaró hoy. Se usa la última declaración que consta en la ficha, tal cual está, y no se propone otra.*
**Sustento documental:** no contradicho, pero sin sustento independiente. No hay verde que la evidencia desmienta. Aun así, las 5 cifras y declaraciones de la ficha salen del propio informe de avance, y no hay ninguna fuente de evidencia que las corrobore (evidencia 0 · declaración 5 · sin marcar 14).
**Lo que el semáforo no explica:** tres señales que el informe no menciona: compromisos vencidos (6), compromisos reprogramados (3) e hito declarado cumplido sin evidencia (1).

## Qué cambió esta semana
No hay informe anterior contra el cual comparar. La foto de hoy es la primera de este informe, y el diff contra sí misma da 0 cambios. Eso no quiere decir que no haya cambiado nada: quiere decir que **esta corrida no puede decir qué cambió**. Lo que sí consta en los documentos de la semana:

| Qué | Estaba | Está | |
|---|---|---|---|
| Hito «Ambiente de pruebas certificado» (base 2026-08-29) | pendiente | cumplido, con acta de recibo del 2026-10-20 (52 días después de la fecha base) | cerrado |
| Compromisos «Confirmar la fecha 15» y «Enviar el documento 17» | abiertos | cumplidos, con acta de recibo del 2026-10-16 | cerrados |
| Compromiso «Enviar el documento 1» (Óscar Ramírez) | 2026-12-08 | 2026-12-22 (sexto movimiento, notas del 2026-10-23) | se movió |
| Compromiso nuevo: «Mandar el ajuste del presupuesto» (Laura Vélez) | no existía | «la otra semana», sin fecha | nuevo |
| Compromiso nuevo: «Revisión con el proveedor» (Óscar Ramírez) | no existía | 2026-11-02 | nuevo |
| Riesgo nuevo: el proveedor podría no llegar con el equipo completo; nadie lo había anotado | no estaba | en la ficha, sin dueño | nuevo |
| Incidencia: la prueba de carga de temporada no alcanzó el umbral y se repite | — | abierta desde 2026-10-18 | nueva en el informe |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Javier Hoyos — «Cerrar la prueba 10» (vencido, sin reprogramar) | 2026-10-06 | 17 |
| Javier Hoyos — «Revisar el anexo 3» (sigue listado con la fecha vieja el 10-16) | 2026-10-09 | 14 |
| Jorge Medina — «Validar el ambiente 4» (dijo el 10-02 que ya lo entregó; sin acta) | 2026-10-16 | 7 |
| Rubén Cárdenas — «Enviar el documento 9» | 2026-10-20 | 3 |
| Jorge Medina — «Revisar el anexo 11» | 2026-10-22 | 1 |
| Gustavo Neira — «Revisar el anexo 19» | 2026-10-22 | 1 |
| Hito «Diseño de la experiencia aprobado»: figura cumplido, sin evidencia en la carpeta del proyecto | 2026-05-27 | 149 |
| Liliana Torres — «Cerrar la prueba 18»: «por definir» en dos minutas seguidas | 2026-10-09 | 14 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-03-05 | 2027-03-05 | 0 días / 0 días |
| Presupuesto | 2.400.000.000 COP | 2.400.000.000 COP | proyección 2.392.525.628 COP (−0,3 %) |

Replanificaciones: **0** registradas. El cronograma vigente sigue siendo el v1 y no hay solicitudes de cambio. Pero el propio informe del 2026-10-18 dice que «se reprogramó el despliegue por el congelamiento de temporada» y que la prueba de carga se repite. Ese movimiento no está en la línea base. Un 0 de desviación con un despliegue reprogramado no es estabilidad: es una línea base que todavía no refleja lo que ya se sabe.

Avance: declarado 52 %; el plan sustenta entre 50 % y 75 % (2 de 4 hitos cumplidos). Brecha: 0 puntos.

### Hitos de las próximas cuatro semanas (hasta 2026-11-20)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno vence en la ventana | — | — | — |

Los siguientes son «Integración con el ERP» (2026-12-01, a 39 días) y «Piloto en tiendas» (2027-03-05). Ambos están pendientes.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.644.951.364 (68,5 %) | 955.775.977 (39,8 %) | 2.392.525.628 | **755.048.636** (aprobado − comprometido) |

Moneda: COP. El ejecutado no es el disponible: el 68,5 % ya está comprometido aunque solo se haya ejecutado el 39,8 %. El avance declarado es 52 %, y 12 puntos por encima de lo ejecutado no se explican solos. Todas las cifras salen del informe de avance (declaración); el aprobado, del acta de constitución. La proyección queda a 7,5 millones del aprobado, y el «ajuste del presupuesto» que prometió Laura Vélez, sin fecha, es justo lo que podría moverla.

## Abierto
**Reprogramados** (umbral: 3 veces):
- Óscar Ramírez — «Enviar el documento 1»: **6 veces**. Original 2026-10-02, hoy 2026-12-22 (81 días de corrimiento). En las notas del 10-23 dijo que «no alcanzó».
- Mauricio Pérez — «Cerrar la prueba 2»: **5 veces**. Original 2026-09-30, hoy 2026-12-21 (82 días).
- Camilo Beltrán — «Entregar el punto 8»: **3 veces**. Original 2026-10-10, hoy 2026-11-17 (38 días).

**Vencidos sin evidencia:** los seis de la tabla anterior. Además, tres personas dicen que ya entregaron y no hay acta: Jorge Medina («Validar el ambiente 4»), Elena Duarte («Validar el ambiente 12», vence 10-27) y Javier Hoyos («Entregar el punto 16», vence 11-02). Mientras no haya acta, siguen abiertos.

**Sin fecha:** Liliana Torres («Cerrar la prueba 18») y Laura Vélez («Mandar el ajuste del presupuesto»).

**RAID sin movimiento:** 2 riesgos del informe del 10-18 (congelamiento de cambios en temporada alta; concentración del conocimiento en una sola persona), 1 riesgo de las notas del 10-23 y 2 incidencias (desde el 10-18, 5 días). **Ninguno tiene dueño.** No hay fecha de revisión que permita contar días sin movimiento.

**Proveedor:** la ficha no tiene proveedores ni contratos registrados, y sin embargo las notas del 10-23 hablan de una revisión con el proveedor y de que su equipo podría no llegar completo. Sin contrato en la carpeta no hay entregables que contrastar contra lo facturado.

## Lo que necesito de alguien
- **Sandra Gil:** declarar el estado y el avance de esta semana. Hoy no se pudo pedir. La declaración usada es la del 10-18.
- **Sandra Gil:** decidir si el despliegue reprogramado exige un cambio de línea base. Hoy el plan dice 0 replanificaciones.
- **Óscar Ramírez, Mauricio Pérez, Camilo Beltrán:** una fecha que se sostenga, o decir que no hay. Llevan 6, 5 y 3 movimientos.
- **Laura Vélez:** fecha para el ajuste del presupuesto.
- **Liliana Torres:** fecha para la prueba 18.
- **Jorge Medina, Elena Duarte, Javier Hoyos:** el acta de recibo de lo que dicen haber entregado.
- **Felipe Arango (patrocinador):** dueño para los 3 riesgos y 2 incidencias. La ficha no tiene autoridad de aprobación (campo sin dato), por lo que no se puede marcar qué excede al gerente. Eso queda para el comité.

## Lo que no se sabe
**Sin dato:** producto (el acta dice «No aplica»), autoridad de aprobación y fase del proyecto. La autoridad importa: sin ella no se sabe quién decide un cambio de línea base.
**Silencio:** último documento hace 0 días (notas del 2026-10-23); último documento formal (acta de recibo) hace 3 días; última minuta de comité hace 7 días (2026-10-16). No hay silencio. Pero el hito «Diseño de la experiencia aprobado» no tiene acta propia en la carpeta de este proyecto.

---
*Origen: ficha `estado/PRY-202-centro-de-distribución-norte/records/PRY-202.json`, actualizada el 2026-10-23, con corte al 2026-10-23. 3 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0 (aceptados el 2026-10-23 por José Francisco Ñáñez).*
