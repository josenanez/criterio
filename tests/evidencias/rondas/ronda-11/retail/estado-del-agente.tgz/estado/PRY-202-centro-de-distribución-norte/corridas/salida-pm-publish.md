Publiqué la ficha en `documentos/proyectos/PRY-202-centro-de-distribución-norte/00-gobierno/ficha-pm.json`, con corte al 2026-10-23.

**Lleva:** 15 campos con dato · 3 sin decir en ninguna parte (producto, autoridad, fase) · declara **rojo** al 2026-10-18 (declaración de Sandra Gil, marcada como declarada; 52 % de avance)

**Lo más viejo que va ahí:** acta de constitución, del 2026-02-12 (patrocinador, gerente, comité, presupuesto aprobado, fechas) — unos ocho meses, no pasa de un año.

**Fecha de cierre:** `plan.end_date` = 2027-03-05, del cronograma v1. No hay un cronograma más nuevo en la carpeta, así que coincide con la línea base y con el acta; no hay diferencia que explicar.

**Antes de publicar:** recalculé con `compute`. Salen 12 alertas (1 hito dado por cumplido sin evidencia: «Diseño de la experiencia aprobado»; 6 compromisos vencidos; 2 sin fecha; 3 reprogramados). Van en la ficha como compromisos e hitos; la declaración de rojo no las explica todas.

Términos: vigentes (aceptados por José Francisco Ñáñez el 2026-10-23); no hizo falta registrarlos de nuevo. La carpeta de gobierno ya existía. No avisé a nadie: Vera la leerá en su próximo barrido.
