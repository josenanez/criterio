# Corrida del 2026-10-23 · status-report

13 proyectos · 46 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Informe de estado de PRY-207: verde declarado sin sustento (3 hitos cumplidos sin evidencia, despliegue reprogramado sin cambio formalizado, prueba de carga fallida). Sin dato: autoridad, fase, responsables de RAID.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-207.json` (actualizada el 2026-10-23) y el recálculo de `portafolio.py compute` al 2026-10-23.

## PRY-207 · Marca propia de alimentos — estado al 2026-10-23

**Declara el gerente (Gustavo Neira):** verde · 70% · al 2026-09-30 (hace 23 días; por debajo de los 30 del umbral de declaración vencida)
**Sustento documental:** sin sustento — 0 fuentes de evidencia; 5 campos son declaración y 10 no están marcados
**Lo que el semáforo no explica:** `milestone_met_without_evidence` — tres hitos declarados cumplidos sin evidencia de cumplimiento. Alerta `declared_vs_evidence`: verde declarado con evidencia que ese verde no cubre.
**Último documento:** 2026-10-18 (5 días en silencio) · **Última reunión:** 2026-10-18

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-11-18 | 2026-11-18 | 0 días contra la original y contra la vigente |
| Presupuesto | 800.000.000 COP aprobado | 800.000.000 COP aprobado | Proyección declarada 742.507.103 COP: -7,2% sobre lo aprobado |

Replanificaciones: 0 registradas. Sin embargo, el informe del 2026-09-30 dice que «se reprogramó el despliegue por el congelamiento de temporada de fin de año» y que el cronograma vigente sigue siendo el v1. No hay solicitud de cambio ni línea base nueva (cambios registrados: 0).

Dinero (COP, declarado al 2026-09-30): comprometido 283.314.415 (35,4%), ejecutado 132.453.350 (16,6%), disponible real 516.685.585.

Avance frente al plan: declara 70%; el plan sustenta entre 75 y 100% con 3 de 4 hitos cumplidos; brecha de 5,0 puntos.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-06-13 | 2026-06-13 | cumplido (declarado) | ninguna — 132 días desde la fecha |
| Ambiente de pruebas certificado | 2026-08-05 | 2026-08-05 | cumplido (declarado) | ninguna — 79 días |
| Integración con el ERP | 2026-09-27 | 2026-09-27 | cumplido (declarado) | ninguna — 26 días |
| Piloto en tiendas | 2026-11-18 | 2026-11-18 | pendiente | — |

### Dónde no coincide
- **Verde frente a lo que el mismo informe cuenta** (informe de avance, 2026-09-30): declara verde y 70%, y en el mismo documento dice que la prueba de carga de temporada no alcanzó el umbral pactado y se repite, y que se reprogramó el despliegue. El semáforo no menciona ninguna de las dos cosas.
- **Plan frente a informe:** el cronograma v1 (2026-04-12) mantiene todas las fechas originales; el informe dice que el despliegue se reprogramó. Una de las dos fuentes no refleja la realidad, y no hay documento que lo formalice.
- **Hitos cumplidos sin soporte:** ninguno de los tres hitos marcados como cumplidos tiene acta, aceptación ni otro documento que lo pruebe en la carpeta.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: congelamiento de cambios en temporada alta — sin probabilidad, impacto, responsable ni fecha (informe 2026-09-30).
- Incidencia: la prueba de carga de temporada no alcanzó el umbral pactado y se repite — desde 2026-09-30, sin responsable.
- Incidencia: despliegue reprogramado por el congelamiento de fin de año — desde 2026-09-30, sin responsable.

**Compromisos vencidos:** ninguno. Hay uno abierto: Beatriz Cuéllar, «Entregar el punto 40», para 2026-11-19 (dicho el 2026-10-18). Ojo: la minuta no la lista entre los asistentes —figura Gustavo Neira dos veces— y el compromiso no dice qué es el «punto 40». Además vence un día después del cierre del proyecto (2026-11-18).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad que aprueba (`identity.authority`): no encontrada.
- Fase del proyecto (`identity.phase`): no encontrada.
- Probabilidad, impacto, responsable y fecha del riesgo abierto.
- Responsable de las dos incidencias.
- Presupuesto: solo existe la cifra aprobada del acta; sin historial de línea base de costo, no se puede medir desviación contra una línea base original distinta de la vigente.
- Proveedores: ninguno registrado.

### Siguiente paso
El verde no está sustentado y el despliegue se reprogramó sin cambio formalizado: ofrezco preparar la solicitud de cambio y el punto de comité (próximo comité: 2026-11-06). No lo hago sin que lo pidan.

---
*Criterio Portfolio v0.8.0 · ficha PRY-207 aplicada, actualizada el 2026-10-23 · campos inciertos: identity.authority, identity.phase · términos v1.2 aceptados por José Francisco Ñáñez el 2026-10-23: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
