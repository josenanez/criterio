## Listo — Portafolio retail

**Miré:** 86 documentos en 13 proyectos · formatos: .md (43), .pdf (16), .docx (12), .xlsx (8), .csv (4), .json (1), .txt (1), .xml (1) · más reciente: 2026-10-23
**Eres:** PMO del portafolio (valor sugerido)
**Te aviso:** dos días antes del comité (supuse comité cada dos semanas, próximo 2026-11-06; corrígeme si es otro)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2, 2026-10-23) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 fe830b9a4eee0bc9…
No dejé el archivo `_CRITERIO_PORTAFOLIO.txt` en la carpeta de documentos: nadie respondió a esa pregunta y no escribo en tus documentos sin un sí.

### Probé con tres proyectos
Los de documentación más reciente: PRY-201, PRY-204 y PRY-210. Los tres tienen fecha 2026-10-20 o posterior.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Programa de fidelización | 14 | Gerente Diana Molina, patrocinador Gustavo Neira, amarillo declarado con 69 % (informe 2026-10-23). Presupuesto 2.400 M COP; comprometido 1.476 M; ejecutado 444 M. Cierre movido de 2026-12-22 a 2027-03-14 por CC-01 (+82 días, +164 M COP). | Facultad del gerente, fase |
| PRY-204 Cajas de autopago | 5 | Gerente Paula Céspedes, patrocinador Ricardo Salas, rojo declarado con 48 % (informe 2026-10-20). Presupuesto 3.300 M COP. Hallazgo de seguridad en medios de pago. | Facultad del gerente, fase |
| PRY-210 Etiquetas electrónicas de precio | 8 | Gerente Carlos Peña, patrocinador Jorge Medina, amarillo declarado con 35 % (informe 2026-10-20). Presupuesto 800 M COP; proyección 819 M. Prueba de carga repetida. | Producto («No aplica»), facultad del gerente, fase |

### Hallazgos (los que levantó el cálculo, 14 señales)
- **PRY-201 (9):**
  - `variance_time`: 82 días contra la línea base original (18,9 %).
  - `progress_vs_plan`: declara 69 %; los hitos sostienen 80–100 %.
  - `milestone_met_without_evidence` ×3: Diseño de la experiencia, Ambiente de pruebas y Piloto en tiendas están cerrados en el cronograma, sin acta de recibo. Solo Integración con el ERP tiene acta (2026-10-11).
  - `commitment_overdue`: Laura Vélez, punto 36, vencido el 2026-10-12 (comité 2026-10-23).
  - `vendor_deliverable_late` ×3: Licenciamiento CT-137 (278 días) y CT-293 (254 días), y Configuración del catálogo CT-293 (16 días).
  - El informe en amarillo no da cuenta de ninguna de estas señales.
- **PRY-204 (4):**
  - `progress_vs_plan`: declara 48 %, mientras los 4 hitos del cronograma figuran cerrados.
  - `milestone_met_without_evidence` ×3: Diseño, Ambiente de pruebas e Integración con el ERP, sin acta. El Piloto sí tiene acta (2026-10-23), 70 días después de su fecha de cierre original (2026-08-14).
- **PRY-210 (1):** `vendor_deliverable_late`: Bolsa de horas CT-548, 3 días de atraso.
- **Sin facultad del gerente** (`no_authority`) en los 3 proyectos: el acta no dice hasta qué monto decide sin subir a comité.
- Varios campos tomados del acta de 2025 tienen 12 meses o más sin confirmación (PRY-201 y PRY-204).

### El portafolio completo
10 proyectos más (73 documentos de 86; PRY-202 trae `ficha-pm.json`). Calculo unos 20–30 minutos en 1 lote de proyectos, uno tras otro. La configuración los reparte en 2 lotes: PRY-199 a PRY-208, y PRY-209 y PRY-211.

### Lo que le falta a tu carpeta
- `PRY-209-migración-del-erp/10-plan/2026-02-17-cronograma-v1.xml` está en formato que no leo sin instalar algo. Expórtalo a CSV o XLSX si quieres que cuente.
- PRY-202 tiene `2026-10-23-notas-reunion.txt` suelto en la raíz del proyecto, fuera de `30-reuniones/`, y una carpeta de estado previa en `estado/` de otra familia.
- PRY-203, PRY-206 y PRY-208 solo tienen acta e informe: sin cronograma ni reuniones, no se les puede medir atraso.
- Las actas de los tres proyectos probados describen el alcance como «Componente 1, 2, 3», sin nombres.
- Ninguna acta dice la facultad del gerente.

Preguntas que hice: 0 (todas con el valor sugerido). Tiempo hasta el primer resultado: unos pocos minutos.
