# Corrida del 2026-10-23 · document-index

13 proyectos · 11 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Índice sin cambios: 86 documentos iguales, 0 por releer, 0 citas rotas. No se leyó ningún documento.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-23: 86 documentos, todos sin cambio. Nada que releer y ninguna cita rota.
