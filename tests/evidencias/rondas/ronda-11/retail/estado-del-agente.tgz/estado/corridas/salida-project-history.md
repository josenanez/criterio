## Historia · PRY-201 Programa de fidelización · 2025-09-27 a 2026-10-23

**Leí:** 15 documentos entre 2025-09-27 y 2026-10-23 (de 15 en la carpeta del proyecto; 2 PDF, leídos desde su texto extraído)
**Trimestres sin un solo documento:** 2026-T1 (enero a marzo de 2026)

### En una línea
El proyecto nació el 2025-10-05 con cierre el 2026-12-22 y presupuesto de 2.400.000.000 COP. Durante casi un año la carpeta guarda contratos, actas de recibo de proveedores y facturas; el 2026-10-23 aparecen el mismo día el informe de avance (amarillo, 69%), la solicitud de cambio CC-01 (+82 días, +164.000.000 COP, "autorizada por el comité") y el cronograma v2 con cierre en 2027-03-14. La única replanificación consta, entonces, antes del cierre original del 2026-12-22 y no deja más rastro de aprobación que una frase.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 82 días (18.9%) | No calculable: hay una sola declaración de estado (2026-10-23), no una serie | 0 en los documentos |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-09-27 | contrato-ct-293.docx | Se firma CT-293 con Sistemas Comerciales del Norte: 3 entregables de 104.794.999 COP |
| 2025-10-05 | acta-constitucion.docx | Se aprueba el proyecto: 2.400.000.000 COP, inicio 2025-10-15, cierre 2026-12-22; patrocinador Gustavo Neira, gerente Diana Molina; sin dependencias declaradas |
| 2025-10-05 | cronograma-v1.xlsx | Línea base v1. Nota: el archivo ya muestra cuatro hitos con fechas de 2026 como "cerrado" |
| 2025-10-13 | contrato-ct-137.docx | Se firma CT-137 con Tecnología para Tiendas Ltda.: 4 entregables de 132.658.021 COP |
| 2026-05-03 | acta-recibo-ct-137 (Bolsa de horas) | Se recibe a satisfacción; comprometido para 2026-04-23 |
| 2026-06-23 | acta-recibo-ct-293 (Bolsa de horas) | Se recibe a satisfacción; comprometido para 2026-06-10 |
| 2026-08-07 | acta-recibo-ct-137 (Configuración del catálogo) | Se recibe a satisfacción; comprometido para 2026-07-28 |
| 2026-09-01 | factura-ct-137 | Factura FV-2137 por 265.316.042 COP, radicada |
| 2026-10-08 | factura-ct-293 | Factura FV-1293 por 104.794.999 COP, radicada |
| 2026-10-11 | acta-recibo (Integración con el ERP) | Se recibe a satisfacción el hito comprometido para 2026-07-02. Es el único hito con acta |
| 2026-10-23 | informe-avance | Amarillo, 69%; comprometido 1.475.958.924, ejecutado 443.784.230, proyección 2.512.609.121 COP |
| 2026-10-23 | solicitud-cambio-cc-01 | Ampliación de alcance, +82 días, +164.000.000 COP; "Autorizada por el comité" |
| 2026-10-23 | cronograma-v2.xlsx | Despliegue en la cadena pasa de 2026-12-22 a 2027-03-14 |
| 2026-10-23 | comité semanal | Asisten Diana Molina y Gustavo Neira; temas "Avance" y "Compromisos"; dos compromisos |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-23 | 2027-03-14 | CC-01: ampliación de alcance, sin detallar qué se amplía | CC-01, que dice "Autorizada por el comité" sin nombrar quién. El acta del comité del mismo día no menciona CC-01 |

Atraso acumulado contra la línea base original: 82 días (18.9%), sobre el umbral de 10%. Contra la vigente: 0 días, porque la línea base v2 se fijó con la nueva fecha. El presupuesto aprobado sigue en 2.400.000.000 COP en el informe; la proyección es 4.7% mayor. El informe no dice si esa proyección incluye los 164.000.000 COP de CC-01.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente ni comité consta en los documentos. Sponsor y gerente del acta (2025-10-05) siguen siéndolo el 2026-10-23 | acta-constitucion, informe-avance, comité semanal |

El comité aparece una sola vez en la carpeta (2026-10-23). No hay actas de comité anteriores, así que no se puede saber si el comité se reunió antes ni qué decidió.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno repetido | Con un solo acta de comité no hay repetición que medir | 1 cada uno | Javier Hoyos, "Entregar el punto 3": 2026-10-23 (abierto). Laura Vélez, "Entregar el punto 36": 2026-10-12 (vencido hace 11 días; se anotó el 2026-10-23 con fecha ya pasada) |

Los compromisos no dicen qué son "el punto 3" ni "el punto 36".

### Desde cuándo lo declarado no se sostiene
No se puede fechar un deslizamiento: la carpeta tiene una sola declaración de estado (2026-10-23), no una serie. Lo que sí se puede decir:

- **Primer hito sin evidencia:** Diseño de la experiencia aprobado, comprometido para 2026-01-09 y declarado cerrado, sin acta ni otro soporte (287 días). Le siguen Ambiente de pruebas certificado (2026-04-06, 200 días) y Piloto en tiendas (2026-09-26, 27 días).
- **Lo que se siguió reportando:** el 2026-10-23 el informe declara amarillo y 69%, con cuatro de cinco hitos cerrados, de los cuales tres sin evidencia. El plan respaldaría 80% a 100% por hitos cerrados; esa cifra descansa en hitos que no tienen soporte, y el 69% tampoco se explica en el informe.
- **Qué no recoge el informe:** el único avance que cuenta es la llegada del concepto de Jurídica. No menciona CC-01, la replanificación, los entregables vencidos de proveedores ni el acta del ERP.
- **Señales sin explicar en el estado amarillo:** compromiso vencido, hitos cerrados sin evidencia, avance vs. plan, atraso vs. original y entregables de proveedor tardíos.
- **Fecha del documento vs. contenido:** el cronograma v1 lleva fecha 2025-10-05 pero muestra como "cerrado" hitos de 2026. Su fecha no es confiable como línea base de aquel día; hay que confirmar con quien lo guardó.

### Lecciones ancladas a un hecho
1. **Hito cerrado antes que su acta.** Integración con el ERP estaba comprometido para 2026-07-02 y su acta de recibo es del 2026-10-11. Efecto: durante ese lapso el estado "cerrado" no tenía soporte. Se pide el acta en la fecha del hito.
2. **Replanificación sin acta de decisión.** CC-01 se pidió, se autorizó y se reflejó en el cronograma v2 el 2026-10-23, y el acta de ese comité no la registra. Efecto: la línea base se movió 82 días sin que conste quién decidió. Se exige acta del comité con nombre y fecha antes de mover la línea base.
3. **Mismo entregable en dos contratos.** "Licenciamiento de la plataforma" está en CT-137 (2026-01-18) y en CT-293 (2026-02-11), ambos pendientes; "Configuración del catálogo" está recibido en CT-137 (2026-08-07) y pendiente en CT-293 (2026-10-07). Efecto: el licenciamiento figura contratado dos veces (132.658.021 y 104.794.999 COP) y sin recibir, y el catálogo ya recibido de un proveedor puede estar duplicado en el otro. Hay que revisar con el gerente si son alcances distintos o el mismo. No sé cuál de los dos casos es.

### Lo que no sé
- Si hubo reuniones de comité, decisiones o replanificaciones informales antes del 2026-10-23: la carpeta no tiene nada de enero a abril de 2026.
- Quién autorizó CC-01 y si la proyección incluye sus 164.000.000 COP.
- Cuándo se cerraron realmente los tres hitos sin evidencia.
- Si el mismo entregable en dos contratos es un error de carga o una duplicación real.

Esto es un borrador de trabajo con la cita del documento de cada dato; la verificación contra los originales es suya. No atribuyo intención a nadie: la historia sirve para tener la conversación con datos.

Puedo llevar esta historia al cierre del proyecto o al comité del 2026-11-06, donde CC-01 y la duplicación de contratos son decisiones que salen de ella.
