# Corrida del 2026-10-23 · change-control

13 proyectos · 51 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Solicitud PRY-201 +30 días al despliegue (supuesto: 'salida a producción' = Despliegue en la cadena). Sin autoridad declarada, sin dependencias declaradas, sin impacto en alcance ni costo, sin motivo ni solicitante. No sabe holgura, vigencia de contratos ni dependencias reales.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

*Sale de la ficha `estado/records/PRY-201.json` (corte 2026-10-23), el cálculo `impact` y `compute`. Términos vigentes: v1.2, aceptados por José Francisco Ñáñez el 2026-10-23.*

## Solicitud de cambio — PRY-201 Programa de fidelización — 2026-10-23

**Qué se pide:** mover 30 días la salida a producción. La ficha no tiene un hito llamado «salida a producción»; tomo **«Despliegue en la cadena»** (2027-03-14), que es el último y el que fija el cierre. Si se trataba de otro hito, hay que decirlo.
**Quién lo pide:** no consta en la instrucción. En los documentos, la gerente es Diana Molina y el patrocinador es Gustavo Neira.
**Por qué:** no se dio motivo. Sin motivo no hay solicitud completa.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Ampliación de CC-01, sin detallar | Sin declarar | **No declarado** |
| Tiempo | Cierre 2027-03-14 (línea base v2) | **2027-04-13** | +30 días |
| Costo | Aprobado 2.400.000.000 COP; proyección 2.512.609.121 COP | **Sin declarar** | **No declarado** |

**Quién absorbe lo que no se declaró.** Mover 30 días sin tocar alcance ni presupuesto significa que alguien lo absorbe en horas del equipo o en costo de proveedor, y nadie lo ha nombrado. El informe ya advierte «concentración del conocimiento en una sola persona» como riesgo abierto, sin dueño ni valoración. Un mes más cae sobre esa persona.

**El costo ya parte por encima del aprobado.** La proyección supera lo aprobado en 112.609.121 COP (4,7 %). CC-01 habla de 164.000.000 COP adicionales, pero la ficha sigue mostrando 2.400.000.000 COP como aprobado. No sé si ese monto ya los incluye. No lo doy por incluido.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El cálculo no encuentra dependencias declaradas hacia PRY-201 (0 directas, 0 indirectas, 0 que no puedan sostener su fecha, 0 sin confirmar) | — |

- **Pasa por un hito:** «Despliegue en la cadena», a 142 días.
- **Cero no significa sin efecto.** El registro de dependencias de PRY-201 está vacío, y el acta dice que se excluye «lo que otro proyecto cubre» sin decir cuál. Que nadie haya declarado dependencias no prueba que no existan.
- **No sé cuántos días se mueve cada tarea.** La ficha no tiene holgura por actividad, y no pongo un número que parezca cálculo.
- **Proveedores.** No tengo la vigencia de los contratos CT-137 y CT-293, y hay que mirarla. Mover 30 días puede sacar entregables de ese plazo. Ya hay 3 entregables vencidos y sin aceptación:
  - Licenciamiento CT-137, 278 días.
  - Licenciamiento CT-293, 254 días.
  - Configuración del catálogo CT-293, 16 días.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta de constitución no declara autoridad (`identity.authority`: no encontrado).
**Según:** ningún documento. La CC-01 dice «Autorizada por el comité» sin nombrar a nadie, y el acta del Comité de Expansión del 2026-10-23 (asistentes: Diana Molina y Gustavo Neira) no menciona CC-01 en sus temas.
**Va a comité:** **sí**, por defecto. Sin autoridad declarada, el hallazgo de fondo es que nadie puede decir quién aprueba. Propongo llevarlo al Comité de Expansión con un acta que sí registre la decisión, y a la vez pedir que el acta declare la autoridad.

### Si no se aprueba
El proyecto sigue con cierre el 2027-03-14 (línea base v2). Hoy lleva **82 días de atraso contra la original** (2026-12-22, 18,9 %). Declara 69 % de avance y el plan sustenta entre 80 % y 100 %, así que el atraso no es de más trabajo sino de un avance que el plan no respalda. Hay tres hitos dados por cumplidos sin evidencia («Diseño de la experiencia aprobado», «Ambiente de pruebas certificado», «Piloto en tiendas»), un compromiso vencido (Laura Vélez, punto 36, 11 días) y una proyección de costo por encima de lo aprobado.

### Si se aprueba
Línea base **3** — cierre **2027-04-13** · presupuesto **sin cambio declarado: 2.400.000.000 COP, a confirmar** · motivo: **por escribir**, no se dio. Debe citar el documento que la aprueba.
Desviación acumulada contra la línea base original (2026-12-22): **112 días (≈ 25,9 %)**, hoy 82 · costo: proyección +4,7 % sobre lo aprobado, más lo que declare esta solicitud.
La línea base v2 no se toca. El conteo de replanificaciones pasa de 1 a 2.

### Control de CC-01 (referencia)
Los 82 días de la línea base v2 coinciden con los 82 días autorizados en CC-01: **0 días sin autorizar**. Pero esa autorización no tiene quién la dio, ni un acta del comité que la registre. Línea base v2 y CC-01 llevan la misma fecha, 2026-10-23, la de esta solicitud: la ampliación y el siguiente corrimiento caen el mismo día.

### Lo que esta salida no sabe
Quién lo pide y por qué. Qué hito es «salida a producción». El impacto en alcance y en costo. La autoridad de aprobación. Las dependencias reales con otros proyectos. La holgura por actividad. La vigencia de los contratos con proveedores.

### Y después
Llevarlo al Comité de Expansión (próximo comité del portafolio: 2026-11-06). Registrar la línea base 3 solo cuando exista un documento de quien podía aprobarla.

*Pie de rigor: borrador de trabajo; cada dato sale de la ficha de PRY-201 y de los documentos citados en ella. La verificación es suya. Lo que no figura en los documentos queda dicho como no sabido.*
