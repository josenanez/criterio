Sale de: las 13 fichas (`estado/records/PRY-199` a `PRY-211`), sus informes de avance, las 6 actas de constitución en .md y las 5 en .docx, las minutas de comité en `30-reuniones` (PRY-199, 200, 201, 202, 204, 205, 207, 209, 211) y las notas de reunión de PRY-202 del 2026-10-23. Términos vigentes (versión 1.2), aceptados por José Francisco Ñáñez el 2026-10-23.

## RAID — Portafolio retail al 2026-10-23
15 riesgos · 0 supuestos · 17 incidencias · 4 dependencias
36 sin doliente · sin movimiento: no se puede medir · 1 no registrado formalmente

Escala: no hay una definida en la configuración, así que sería alta/media/baja. Ningún ítem trae probabilidad ni impacto en sus documentos y no los inventé. Los ids PRY-nnn-R/D/I son **provisionales**, solo para citar en esta salida: el registro de origen no los trae.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-202-R3 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-23 | PRY-202 está en rojo y la fase siguiente depende de ese equipo. Nadie lo registró y sigue sin doliente. |
| PRY-200-I1, 204-I1, 206-I1, 211-I1 | Incidencia | Hallazgo de seguridad en los medios de pago | sin doliente | 2026-10-14 a 2026-10-22 | Aparece en 4 proyectos con la misma redacción. Si es un solo hallazgo, afecta a otros proyectos del portafolio y cumple el criterio de escalamiento. Ninguno tiene doliente. **No puedo confirmar con los documentos que sea el mismo hallazgo**, hay que preguntarlo. |
| PRY-202-I2, 207-I2, 209-I1 | Incidencia | Se reprogramó el despliegue por el congelamiento de fin de año | sin doliente | 2026-09-30 a 2026-10-19 | En PRY-202 y PRY-207 el cronograma vigente sigue siendo el v1 (PRY-209 ya tiene v2). Una reprogramación sin línea base nueva debería pasar por control de cambios (`/change-control`). |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo" (PRY-202) | Riesgo | `PRY-202-centro-de-distribución-norte/2026-10-23-notas-reunion.txt` | 2026-10-23 |

Es el único. Las demás minutas (PRY-199, 200, 201, 204, 205, 207, 209, 211 y las 6 de PRY-202 en `30-reuniones`) solo traen compromisos, sin riesgos dichos al pasar. No inventé ninguno.

### Sin doliente o sin fecha
Los 36 ítems no tienen doliente. Los 15 riesgos y las 4 dependencias tampoco tienen fecha. A las 17 incidencias solo se les conoce el "desde", que es la fecha del informe donde aparecen. Todos se reportan como hallazgo y no se rellenaron. El detalle está en el registro completo, abajo.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199-D1 | Proveedor (sin código de proyecto) | No | "no ha confirmado la fecha de la última entrega" (informe 2026-10-21) |
| PRY-203-D1 | Proveedor | No | ídem (informe 2026-10-18) |
| PRY-205-D1 | Proveedor | No | ídem (informe 2026-10-01, el más viejo de los cuatro) |
| PRY-208-D1 | Proveedor | No | ídem (informe 2026-10-12) |

**Reclasificadas:** el registro de origen las tenía como riesgos. Una entrega que depende de un tercero y no está confirmada es dependencia declarada, no acordada, según la prueba rápida. Siguen abiertas y sin confirmar.

**Cruce entre proyectos:** ninguna acta de constitución declara dependencias ("Ninguna declarada" en los 13) y ningún ítem apunta al código de otro proyecto. Así que el cruce no puede detectar que un proyecto movió su fecha y arrastró a otro. Eso no prueba que no existan: PRY-209 es la migración del ERP y varios proyectos tienen un hito "Integración con el ERP", pero ningún documento dice que dependan de ella. No lo registro como dependencia.

### Registro completo
Prob. e Impacto vacíos en los 36. Último movimiento: "—" en todos, ningún documento lo trae, y solo hay una versión del registro, así que "sin movimiento en dos períodos" no se puede determinar. Doliente: "—" en todos.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| 199-D1 | Dependencia | Proveedor sin confirmar fecha de última entrega | — | — | — | — | — |
| 199-R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | — | — | — |
| 199-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave (desde 2026-10-21) | | | — | — | — |
| 199-I2 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-21) | | | — | — | — |
| 200-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| 200-I1 | Incidencia | Hallazgo de seguridad en medios de pago (desde 2026-10-22) | | | — | — | — |
| 201-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| 202-R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | — | — | — |
| 202-R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| 202-R3 | Riesgo (no registrado) | Proveedor podría no llegar con el equipo completo | — | — | — | — | — |
| 202-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-18) | | | — | — | — |
| 202-I2 | Incidencia | Despliegue reprogramado por congelamiento; cronograma vigente sigue en v1 (desde 2026-10-18) | | | — | — | — |
| 203-D1 | Dependencia | Proveedor sin confirmar fecha de última entrega | — | — | — | — | — |
| 203-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-18) | | | — | — | — |
| 204-R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | — |
| 204-I1 | Incidencia | Hallazgo de seguridad en medios de pago (desde 2026-10-20) | | | — | — | — |
| 205-D1 | Dependencia | Proveedor sin confirmar fecha de última entrega | — | — | — | — | — |
| 205-R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | — |
| 206-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | — | — | — |
| 206-I1 | Incidencia | Hallazgo de seguridad en medios de pago (desde 2026-10-14) | | | — | — | — |
| 207-R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | — | — | — |
| 207-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-09-30) | | | — | — | — |
| 207-I2 | Incidencia | Despliegue reprogramado por congelamiento; cronograma vigente sigue en v1 (desde 2026-09-30) | | | — | — | — |
| 208-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| 208-D1 | Dependencia | Proveedor sin confirmar fecha de última entrega | — | — | — | — | — |
| 208-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-12) | | | — | — | — |
| 208-I2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave (desde 2026-10-12) | | | — | — | — |
| 209-R1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | — |
| 209-R2 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | — | — | — |
| 209-I1 | Incidencia | Despliegue reprogramado por congelamiento (desde 2026-10-19) | | | — | — | — |
| 209-I2 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-19) | | | — | — | — |
| 209-I3 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave (desde 2026-10-19) | | | — | — | — |
| 210-R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | — | — | — |
| 210-I1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite (desde 2026-10-20) | | | — | — | — |
| 211-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | — |
| 211-I1 | Incidencia | Hallazgo de seguridad en medios de pago (desde 2026-10-15) | | | — | — | — |

Fuente de cada ítem: el informe de avance del proyecto (sección "Riesgos abiertos" o "Lo que pasó en el periodo"), con la fecha y el nombre de archivo que cita su ficha en `raid.*.source`. La excepción es 202-R3, que sale de la nota de reunión.

### Lo que no sé, o conviene verificar
- **Texto idéntico entre proyectos.** "Prueba de carga…" aparece en 7 proyectos, "rotación de un desarrollador clave" en 3, "concentración del conocimiento" en 5, "jefes de tienda" en 3. Puede ser coincidencia, una plantilla de informe copiada o una causa compartida. Los documentos no permiten distinguirlo.
- **Supuestos.** Hay 0 levantados. Los informes no declaran ninguno, y no los inventé. Si se busca algo a vigilar, los candidatos típicos son la disponibilidad de las personas clave y la entrega del proveedor, pero eso es una sugerencia mía, no un hallazgo.
- **Productos.** Hay verificaciones de supuestos en `documentos/productos/PRD-*`. Son de producto y están fuera de este registro de proyectos.
- **Compromisos.** En las minutas de PRY-202, "Enviar el documento 1" pasó de 2026-10-02 a 2026-12-22. Eso es de `/commitment-tracking`, no un riesgo que alguien haya dicho.

### Siguiente paso, si lo quieres
- Subir a comité los 3 grupos de "Necesitan decisión ahora". El comité de PRY-202 es el 2026-11-06 según la configuración.
- Proponer doliente para los 36 ítems. Propongo, no asigno.
- Formalizar 202-R3.

*Rigor: este registro es un borrador de trabajo hecho a partir de los documentos citados. No sé lo que se habló fuera de ellos. La verificación de cada dato es de la persona que lo use.*
