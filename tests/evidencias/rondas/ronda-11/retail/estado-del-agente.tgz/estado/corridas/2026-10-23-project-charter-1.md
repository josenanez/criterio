# Corrida del 2026-10-23 · project-charter

13 proyectos · 27 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Revisión del acta 2026-03-21: sin autoridad del gerente, objetivo descrito como solución, alcance y exclusiones de plantilla, criterio de éxito sin métrica ni medidor, sin supuestos, hitos ni cadencia. No sé si hay decisiones de comité posteriores que definan la autoridad.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Acta previa:** sí, del 2026-03-21 (`PRY-203-reposición-automática/00-gobierno/2026-03-21-acta-constitucion.md`). Modo revisar.

## Acta — PRY-203 Reposición automática
**Estado:** existe, del 2026-03-21. Está firmada en forma (patrocinador, gerente, comité, presupuesto, fechas), pero el contenido de fondo es de plantilla sin completar.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Andrés Lozano sin comité. | Todo cambio sube al Comité de Cadena de Abastecimiento, o se decide sin cobertura. Hoy importa: la proyección al cierre (6.959.550.295 COP) supera el aprobado (6.800.000.000) en 159.550.295 COP (+2,3 %), y nadie puede decir con el acta si eso lo resuelve el gerente o el comité. |
| Objetivo de negocio | Descrito como la solución: "Entregar reposición automática para Logística". No dice qué problema de negocio resuelve ni cuánto. | No hay forma de juzgar si el proyecto vale lo que cuesta ni si la entrega, aunque ocurra, sirvió. |
| Alcance | "Componente 1 / 2 / 3", sin descripción. | Nada permite decidir si un pedido nuevo es cambio de alcance o parte del original. El control de cambios no tiene contra qué medir. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar cuál. | Es una exclusión aparente: no hay un límite que defender ni un proyecto contra el cual coordinar. Las dependencias aparecen como "Ninguna declarada", lo que encaja mal con una exclusión que supone otro proyecto. |
| Criterio de éxito | "Reposición automática en producción y medido." No hay métrica, umbral ni plazo. | "Medido" no dice qué se mide. El cierre no se puede evaluar contra nada pactado. |
| Quién mide el éxito | No está. | Sin medidor, el éxito lo declara el mismo gerente que lo ejecuta. |
| Supuestos y restricciones | No hay sección. | Los riesgos reales (proveedor sin fecha de entrega, prueba de carga de temporada) no tienen supuesto de origen contra el cual compararse. |
| Hitos principales | No hay. La ficha tiene `plan.milestones` vacío. | El avance declarado (74 %) no se puede contrastar con ningún hito. |
| Cadencia de reporte | No está (solo se nombra el comité). | No hay frecuencia pactada con la cual medir el silencio del proyecto. |
| Patrocinador, gerente, comité | Presentes: Elena Duarte, Andrés Lozano, Comité de Cadena de Abastecimiento. | Sin hallazgo. |
| Presupuesto y fechas | Presentes: 6.800.000.000 COP (aprobado 2026-03-21); inicio 2026-03-31, cierre 2027-05-29. | Sin hallazgo. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo trae la solución ("Entregar reposición automática para Logística").
**Alcance:** pendiente de definir. El acta lista "Componente 1, 2 y 3" sin contenido.
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre", sin nombrar el proyecto.
**Patrocinador:** Elena Duarte · **Gerente:** Andrés Lozano (acta 2026-03-21)
**Autoridad del gerente:** pendiente de definir (no está en ningún documento).
**Comité al que reporta:** Comité de Cadena de Abastecimiento (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Reposición automática en producción y medido" (acta); sin métrica ni umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir.

### Lo que el informe de avance (2026-10-18) agrega y no cuadra con el acta
- El gerente declara **rojo** y **74 %** de avance. Lo ejecutado es 1.702.813.595 COP, el 25,0 % del aprobado, y lo comprometido 2.386.886.242 COP, el 35,1 %. Con un acta sin hitos, no hay manera de saber cuál de las dos lecturas es la correcta; es una pregunta para el gerente, no una conclusión.
- La proyección (+2,3 %) está por debajo del umbral de desviación de costo configurado (10 %); no es alerta por sí sola. Lo que sí es hallazgo es que el acta no dice quién decide ese sobrecosto.
- La incidencia de la prueba de carga y el riesgo del proveedor no tienen responsable en el informe.

Lo que no sé: si existe una versión posterior del acta o decisiones de comité que definan la autoridad del gerente; no hay otros documentos de gobierno en la carpeta.

### Qué sigue
- El acta quedó **sin autoridad declarada**: se ofrece llevar esa definición al comité (`/steering-pack`). Es una decisión, no un trámite.
- Del informe salen un riesgo y una incidencia sin responsable, y un conjunto de supuestos por declarar: se ofrece pasarlos al registro RAID (`/raid-log`).

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato viene del acta de constitución (2026-03-21) o del informe de avance (2026-10-18); la verificación es suya.*
