# Corrida del 2026-10-23 · portfolio-scan

13 proyectos · 86 documentos, 0 releídos y 86 sin cambio · 296 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

10 fichas nuevas (PRY-199,200,202,203,205,206,207,208,209,211); 59 de 86 documentos leídos, 27 sin cambio. Nada movido: no existe entrada/. El .xml de PRY-209 lo convirtió texto.py y se leyó. Mirar: 18 hitos cerrados sin acta, PRY-209 con cronograma v2 y CC-01 pendiente, CT-140 facturado sin actas de recibo, PRY-202 con 6 compromisos vencidos y dos reprogramados 5-6 veces.

Contra la corrida del 2026-10-23: +44 hallazgos.

## Lo que produjo

## Barrido — 2026-10-23

**Términos:** vigentes (v1.2, familia 0.8.0), aceptados por José Francisco Ñáñez el 2026-10-23. Nadie respondió preguntas en esta sesión; en cada una tomé la respuesta sugerida.

**Documentos:** 86 en la carpeta · 59 leídos · 27 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta · 10 con ficha nueva (esta corrida) · 3 sin tocar (PRY-201, PRY-204, PRY-210: sus 27 documentos no cambiaron) · 0 sin carpeta propia

El plan marcó como ilegible el cronograma `.xml` de PRY-209 («formato que no se lee sin instalar algo»). `texto.py` sí lo convirtió (formato Microsoft Project), así que lo leí. Eso va en la ficha.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, declarado, plan, dinero, 1 contrato, riesgos, 1 compromiso | `authority`, `phase`, `invoiced` (sin facturas) |
| PRY-200 Tienda en línea | 4 | ídem, 3 hitos, 1 compromiso | `authority`, `phase` |
| PRY-202 Centro de distribución norte | 15 | ídem, 4 hitos, 26 compromisos, `pm_record` (ficha-pm.json) | `authority`, `phase`, `product` («No aplica») |
| PRY-203 Reposición automática | 2 | identidad, declarado, dinero, riesgos | `authority`, `phase`, `product`, hitos (sin cronograma) |
| PRY-205 Pago con QR en caja | 7 | ídem, 5 hitos, 2 líneas base, CC-01, 1 compromiso | `authority`, `phase` |
| PRY-206 Precios dinámicos | 2 | identidad, declarado, dinero, riesgos | `authority`, `phase`, `product`, hitos (sin cronograma) |
| PRY-207 Marca propia de alimentos | 4 | ídem, 4 hitos, 1 compromiso | `authority`, `phase` |
| PRY-208 Domicilios en dos horas | 2 | identidad, declarado, dinero, riesgos | `authority`, `phase`, hitos (sin cronograma) |
| PRY-209 Migración del ERP | 12 | ídem, 5 hitos, 2 líneas base, 2 contratos, CC-01, 1 compromiso | `authority`, `phase`, `product` |
| PRY-211 Pronóstico de demanda | 5 | ídem, 4 hitos, 1 compromiso | `authority`, `phase`, `product` |

`authority` y `phase` no aparecen en ningún documento de ninguno de los 10 proyectos. Va `not_found` en todos.

### Actualizados
Ninguno. Los tres proyectos con ficha previa no tuvieron documentos nuevos ni cambiados.

### Lo que hay que mirar
La señal la calcula el código; esto es lo que vi al leer.

**Hitos que el cronograma declara cerrados sin acta que lo pruebe** (el estado queda como se declaró, `evidence` vacío): PRY-200 (2 de 2 cerrados), PRY-202 (1 de 2), PRY-205 (4 de 5), PRY-207 (3 de 3), PRY-209 (5 de 5), PRY-211 (3 de 4). PRY-199 tiene 1 cerrado y sí tiene acta. Cada acta de recibo cuenta solo para el hito que nombra:
- PRY-202: el acta del 2026-10-20 del «Ambiente de pruebas certificado» llegó casi dos meses después de la fecha del hito (2026-08-29).
- PRY-211: el acta de «Integración con el ERP» es del 2026-10-12; el hito era del 2025-12-31.

**Proyectos pasados de su fecha de cierre sin replanificar el cierre en un documento:** PRY-206 (cierre 2026-06-09, declara 60 %), PRY-208 (2026-04-28, 60 %), PRY-211 (2026-02-14, 25 %). PRY-205 sí tiene cronograma v2 con cierre 2026-05-02, también pasado, y declara 35 %.

**PRY-209, línea base v2 antes de la decisión.** El cronograma v2 (2026-10-19) ya mueve el despliegue de 2026-09-12 a 2026-12-16 (+95 días, lo que pide CC-01). CC-01 (2026-10-17) está «pendiente de presentación al comité». Registré la v2 como línea base con esa salvedad en su motivo. Además hay dos hallazgos de contratos:
- CT-140 (Sistemas Comerciales del Norte): el contrato marca dos entregables «recibido», pero no hay ningún acta de recibo de CT-140 en la carpeta. La factura FV-2140 (596.779.430 COP, 2026-09-04) cubre los dos montos.
- CT-431 (Logística del Valle): dos actas de recibo (licenciamiento, catálogo) y una factura de 807.514.656 COP, que son los dos montos. Ahí cuadra.

**PRY-205, el cronograma v2 (2026-10-01) precede a CC-01 (2026-10-10)**, que lo justifica (+42 días). CC-01 dice «autorizada por el comité», sin nombrar cuál ni quién. La ejecución declarada (339.846.720) supera lo comprometido declarado (236.283.277) en el mismo informe.

**PRY-202.** Es el único con ficha-pm.json; va entera en `pm_record`, aparte de mi lectura. Mi lectura de las seis minutas y las notas del 2026-10-23 coincide con la del gerente en los 26 compromisos:
- 3 cerrados con acta, 6 vencidos, 17 abiertos.
- «Enviar el documento 1» (Óscar Ramírez): prometido para 2026-10-02, reprogramado 6 veces, hoy 2026-12-22.
- «Cerrar la prueba 2» (Mauricio Pérez): original 2026-09-30, reprogramado 5 veces, hoy 2026-12-21.
- Tres personas dijeron «ya lo entregué» sin acta: Jorge Medina (ambiente 4), Elena Duarte (ambiente 12), Javier Hoyos (punto 16). Los tres compromisos dejaron de aparecer en la lista.
- Dos compromisos sin fecha: Liliana Torres («por definir») y Laura Vélez («la otra semana»).
- Riesgo dicho el 2026-10-23 y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase.
- El informe del 2026-10-18 dice que se reprogramó el despliegue, y el cronograma vigente sigue siendo el v1. PRY-207 y PRY-209 tienen el mismo texto en su informe. PRY-209 sí tiene v2; PRY-207 no.

**Gobierno.** En PRY-207 y PRY-208 el patrocinador y el gerente son la misma persona (Gustavo Neira, Mauricio Pérez). En la minuta de PRY-207 el asistente Gustavo Neira aparece dos veces.

**Compromisos con dueño ausente o fecha incoherente.** El responsable no figura entre los asistentes de la reunión en PRY-199 (Carlos Peña), PRY-200 (Andrés Lozano), PRY-205 (Diana Molina), PRY-207 (Beatriz Cuéllar) y PRY-209 (Javier Hoyos). En PRY-205 el compromiso de Diana Molina vence el 2026-09-29 y se dijo el 2026-10-14.

**Declarado contra dinero**, solo como lo declaran los informes (la desviación la calcula el código): PRY-199 declara verde, 20 % de avance y 720.000.000 ejecutados de 2.400.000.000. PRY-203 declara rojo y proyecta 6.959.550.295 sobre 6.800.000.000 aprobados. PRY-206 proyecta 7.989.396.294 sobre 6.800.000.000.

### No pude leer
Nada quedó sin leer. El `.xml` de PRY-209 lo convirtió `texto.py` (ver arriba).

### Movidos desde entrada/
No existe carpeta `entrada/` en `documentos/`. No moví nada.

### Pendientes de clasificar
Ninguno.

---
*Pie: criterio-portfolio, familia 0.8.0 · fichas tocadas: 10 (PRY-199, 200, 202, 203, 205, 206, 207, 208, 209, 211) · campos en `not_found`: `identity.authority` y `identity.phase` en las 10; `identity.product` en 202, 203, 206, 209 y 211; `plan.milestones` en 203, 206 y 208; `invoiced` de PRY-199 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
