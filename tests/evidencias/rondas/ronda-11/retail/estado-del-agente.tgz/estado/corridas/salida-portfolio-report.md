# Portafolio — 2026-10-23
13 proyectos · 10 con hallazgos (58 señales) · último barrido 2026-10-23 (fichas del día, snapshot 2026-10-23; el silencio máximo es de 11 días, ninguna ficha supera la semana sin barrido de forma que invalide el informe)

Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya registrado; no se pidió de nuevo). Formato: html.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. El diff se calculó contra la instantánea del mismo día (2026-10-23) y dio 0 cambios.

## Contradicciones abiertas
Declarado en verde pero contradicho por la evidencia (2):

| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-200 Tienda en línea | Estado | verde (informe 2026-10-22) | 20-seguimiento/2026-10-22-informe-avance.pdf | dos hitos "cumplidos" sin acta de recibo | — |
| PRY-207 Marca propia de alimentos | Estado | verde (informe 2026-09-30) | 20-seguimiento/2026-09-30-informe-avance.md | tres hitos "cumplidos" sin acta de recibo | — |

## Hitos vencidos sin evidencia
Hitos declarados cumplidos sin acta que lo sustente:

| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-200 | Diseño de la experiencia aprobado | 2026-04-05 | 201 |
| PRY-200 | Ambiente de pruebas certificado | 2026-08-13 | 71 |
| PRY-201 | Diseño de la experiencia aprobado | 2026-01-09 | 287 |
| PRY-201 | Ambiente de pruebas certificado | 2026-04-06 | 200 |
| PRY-201 | Piloto en tiendas | 2026-09-26 | 27 |
| PRY-202 | Diseño de la experiencia aprobado | 2026-05-27 | 149 |
| PRY-204 | Diseño de la experiencia aprobado | 2025-10-07 | 381 |
| PRY-204 | Ambiente de pruebas certificado | 2026-01-19 | 277 |
| PRY-204 | Integración con el ERP | 2026-05-02 | 174 |
| PRY-205 | Ambiente de pruebas certificado | 2025-11-27 | 330 |
| PRY-205 | Integración con el ERP | 2026-01-04 | 292 |
| PRY-205 | Piloto en tiendas | 2026-02-11 | 254 |
| PRY-205 | Despliegue en la cadena | 2026-05-02 | 174 |
| PRY-207 | Diseño de la experiencia aprobado | 2026-06-13 | 132 |
| PRY-207 | Ambiente de pruebas certificado | 2026-08-05 | 79 |
| PRY-207 | Integración con el ERP | 2026-09-27 | 26 |
| PRY-209 | Diseño de la experiencia aprobado | 2026-04-07 | 199 |
| PRY-209 | Ambiente de pruebas certificado | 2026-05-16 | 160 |
| PRY-209 | Integración con el ERP | 2026-06-25 | 120 |
| PRY-209 | Piloto en tiendas | 2026-08-03 | 81 |
| PRY-211 | Diseño de la experiencia aprobado | 2025-10-02 | 386 |
| PRY-211 | Ambiente de pruebas certificado | 2025-11-16 | 341 |
| PRY-211 | Piloto en tiendas | 2026-02-14 | 251 |

También hay compromisos vencidos: PRY-202 (6 vencidos, 2 sin fecha, 3 reprogramados 3 a 6 veces; el peor, "Enviar el documento 1" de Óscar Ramírez, va por la sexta fecha), PRY-201 (1), PRY-205 (1, 24 días), PRY-211 (1).

## Proyectos en silencio
Vacía: ningún proyecto supera el umbral de 15 días. El mayor silencio es PRY-208 con 11 días.

## Dependencias en riesgo
Entregables de proveedor atrasados:

| Proyecto | Depende de | Qué pasó |
|---|---|---|
| PRY-201 | Tecnología para Tiendas Ltda. — Licenciamiento de la plataforma | Pendiente, venció 2026-01-18 (278 días) |
| PRY-201 | Sistemas Comerciales del Norte — Licenciamiento de la plataforma | Pendiente, venció 2026-02-11 (254 días) |
| PRY-201 | Sistemas Comerciales del Norte — Configuración del catálogo | Pendiente, venció 2026-10-07 (16 días) |
| PRY-209 | Sistemas Comerciales del Norte y Logística del Valle Ltda. — Bolsa de horas de desarrollo | Pendiente, venció 2026-06-15 (130 días) |
| PRY-210 | Sistemas Comerciales del Norte — Bolsa de horas de desarrollo | Pendiente, venció 2026-10-20 (3 días) |

Sistemas Comerciales del Norte aparece atrasado en tres proyectos (PRY-201, 209, 210).

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-209 | Licenciamiento de la plataforma y Configuración del catálogo aceptados | Sin evidencia de aceptación |
| PRY-209 | Replanificación de 95 días | Ningún cambio autorizado (rebaseline sin autorizar; se vio 1 cambio, 0 días autorizados) |
| PRY-205 | CC-01 (42 días) | Cambio aplicado sin línea base nueva |
| PRY-204 | Avance 48 % | El plan sostiene 100 % (4 de 4 hitos), 52 puntos de brecha |
| PRY-205 | Avance 35 % | El plan sostiene 100 %, 65 puntos de brecha |
| PRY-209 | Avance 58 % | El plan sostiene 100 %, 42 puntos de brecha |
| PRY-211 | Avance 25 % | El plan sostiene 100 %, 75 puntos de brecha |
| PRY-201 | Avance 69 % | El plan sostiene 80–100 %, 11 puntos de brecha |

Nota: en estos cinco la brecha sale de que los hitos figuran como cumplidos, así que puede ser el avance declarado el que está bajo o los hitos los que están sobredeclarados; el script no lo resuelve.

## Vacíos de información
- Los 13 proyectos no tienen autoridad (patrocinador/aprobador) registrada.
- 6 proyectos sin producto asociado: PRY-202, 203, 206, 209, 210, 211.
- PRY-199, PRY-203, PRY-208: sin señales; ver su ficha para campos inciertos.

## Estado general
| Proyecto | Declarado | Desviación vs original | Replanificaciones | Señales |
|---|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | verde | — | 0 | 0 |
| PRY-200 Tienda en línea | verde (contradicho) | — | 0 | 3 |
| PRY-201 Programa de fidelización | amarillo | +82 d (18,9 %) | 1 | 9 |
| PRY-202 Centro de distribución norte | rojo | — | 0 | 12 |
| PRY-203 Reposición automática | rojo | — | 0 | 0 |
| PRY-204 Cajas de autopago | rojo | — | 0 | 4 |
| PRY-205 Pago con QR en caja | amarillo | +42 d (22,1 %) | 1 | 8 |
| PRY-206 Precios dinámicos | amarillo | costo +17,5 % (proyección 7.989.396.294 vs 6.800.000.000 COP) | 0 | 1 |
| PRY-207 Marca propia de alimentos | verde (contradicho) | — | 0 | 4 |
| PRY-208 Domicilios en dos horas | amarillo | — | 0 | 0 |
| PRY-209 Migración del ERP | rojo | +95 d (48,2 %) | 1 | 11 |
| PRY-210 Etiquetas electrónicas de precio | amarillo | — | 0 | 1 |
| PRY-211 Pronóstico de demanda | amarillo | — | 0 | 4 |

## Necesito que confirmes
Toca la confirmación mensual (primera vez, sin registro previo). Cinco preguntas cerradas; en esta sesión sin interfaz quedan sin responder:
1. PRY-200: ¿existe acta de recibo de "Diseño de la experiencia aprobado" (vencido 2026-04-05)? Sí / No
2. PRY-207: ¿existe acta de recibo de "Integración con el ERP" (vencido 2026-09-27)? Sí / No
3. PRY-209: ¿el cambio CC-01 de 95 días fue aprobado por alguien con facultad? Sí / No
4. PRY-205: ¿el cambio CC-01 de 42 días fue aprobado y tiene línea base nueva? Sí / No
5. PRY-209: ¿se recibió a satisfacción el Licenciamiento de la plataforma de Sistemas Comerciales del Norte? Sí / No

## Dónde quedó
Carpeta `reportes/` (la que sirve Rostrum), 24 páginas:
- `reportes/index.html` — vista por campo con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión. Para el patrocinador y el comité (próximo: 2026-11-06).
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), más páginas de productos.
- Para PDF: imprimir el HTML desde el navegador.

Pie: criterio-portfolio v0.8.0 · fichas aplicadas: 13, con fecha 2026-10-23 · campos inciertos: sin autoridad registrada en los 13 proyectos; 6 proyectos sin producto · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

Después: puedo preparar el material de comité del 2026-11-06 (`/steering-pack`) o entrar al detalle de PRY-202, PRY-209 y PRY-201.
