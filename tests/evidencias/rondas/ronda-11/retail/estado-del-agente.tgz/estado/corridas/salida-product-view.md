# Vista por producto: pago con QR — al 2026-10-23

Sale de las fichas en `estado/` y del cálculo de hoy (`portafolio.py compute`). Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23.

## Productos al 2026-10-23 (consulta: pago con QR)

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| pago con QR | 1 (PRY-205) | 1 de 1 (8 alertas) | 2026-05-02 (PRY-205) — ya vencida | COP 800.000.000 | COP 236.283.277 |

**Este producto tiene un solo proyecto, PRY-205 «Pago con QR en caja».** La vista por producto no suma nada sobre la vista de proyecto, así que no armo sección de producto. Esto es lo que dicen las fichas de ese proyecto:

- **Dinero (1 de 1 proyectos con las cuatro cifras):** aprobado COP 800.000.000; comprometido 236.283.277 (29,5 %); ejecutado 339.846.720 (42,5 %); proyección 760.057.716 (−5,0 % frente al aprobado).
- **Fecha:** fin comprometido 2026-05-02, 42 días (22,1 %) sobre la línea base original; 0 días sobre la vigente.
- **Cambio CC-01 (42 días):** aprobado sin línea base nueva registrada.
- **Avance:** declarado 35 % (informe amarillo del 2026-10-01, 22 días de antigüedad). El plan marca 5 de 5 hitos cumplidos, o sea que sostiene 100 %: brecha de 65 puntos.
- **Hitos «cumplidos» sin evidencia:** Ambiente de pruebas certificado (vencía 2025-11-27), Integración con el ERP (2026-01-04), Piloto en tiendas (2026-02-11), Despliegue en la cadena (2026-05-02).
- **Compromiso vencido:** Diana Molina, «Entregar el punto 13», para 2026-09-29, 24 días vencido (comité semanal del 2026-10-14).
- **Dependencias internas:** ninguna (un solo proyecto). Dependencias declaradas: ninguna.
- **Proveedores:** ninguno registrado.

El informe amarillo no da cuenta de ninguna de las cuatro señales: compromiso vencido, hitos sin evidencia, avance contra plan y variación de tiempo.

**Lo que no sé:** si el avance real es 35 % o el plan está mal marcado (no hay evidencia de recibo de ningún hito); si CC-01 sí movió la línea base; quién tiene la autoridad del proyecto (campo vacío, igual que en los 13 proyectos); y la fase.

### Proyectos sin producto declarado (aparte de la consulta, pero es un hallazgo de gobierno)

Seis de los 13 proyectos del portafolio no declaran producto. Nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | Tecnología |
| PRY-203 Reposición automática | Logística |
| PRY-206 Precios dinámicos | Tecnología |
| PRY-209 Migración del ERP | Tiendas |
| PRY-210 Etiquetas electrónicas de precio | Tiendas |
| PRY-211 Pronóstico de demanda | Mercadeo |

Además, PRY-199 declara el producto «PRD-299», un código y no un nombre como los demás: conviene confirmar que es el mismo catálogo.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale del cálculo de hoy sobre las fichas y cada dato de la ficha cita su documento; la verificación es de quien lo lea.
