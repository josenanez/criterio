# Corrida del 2026-10-23 · budget-tracking

13 proyectos · 47 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Informe de presupuesto de PRY-206: proyección 17.5% sobre el aprobado (alerta), comprometido 66.9%. Dijo que no sabe: hitos (ninguno registrado), proveedores, cambios de presupuesto y evidencia que respalde las cifras declaradas; fecha de fin 2026-06-09 vencida sin replanificar.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Fuentes:** acta de constitución `PRY-206-precios-dinámicos/00-gobierno/2025-06-16-acta-constitucion.docx` (2025-06-16) e informe de avance `PRY-206-precios-dinámicos/20-seguimiento/2026-10-14-informe-avance.md` (corte 2026-10-14). Cifras derivadas: salida de `portafolio.py compute`, al 2026-10-23. Términos vigentes (v0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23).

## Presupuesto — PRY-206 Precios dinámicos al 2026-10-23
**Moneda:** COP (única; no hay otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100% | Acta de constitución | 2025-06-16 |
| Comprometido | 4.549.637.864 | 66.9% | Informe de avance (declaración del gerente) | 2026-10-14 |
| Ejecutado | 2.471.333.613 | 36.3% | Informe de avance (declaración del gerente) | 2026-10-14 |
| Proyección al cierre | 7.989.396.294 | 117.5% (17.5% sobre el aprobado) | Informe de avance (declaración del gerente) | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): COP 2.250.362.136

Lectura: el ejecutado (36.3%) no es la holgura. Contra el comprometido (66.9%) lo que queda sin comprometer es el disponible real de arriba, y la proyección dice que aun eso no alcanza.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | 0 (no hay cambio de presupuesto registrado) |
| Proyección frente al aprobado | | | +17.5% (umbral de la configuración: 10%) |

Replanificaciones de presupuesto: 0. La línea base registrada (v1, 2025-06-16) solo guarda fechas; el presupuesto original sale del acta, único documento que lo fija.

### Ejecución frente a avance
Ejecutado 36.3% · Hitos cumplidos: no se puede decir, la ficha no tiene hitos (0 registrados) · Avance declarado 60%.
Lectura: el avance declarado (60%) está muy por encima del ejecutado (36.3%); el script no calcula la brecha en puntos porque no hay hitos. Los documentos no permiten decir cuál de las dos cosas pasa: avance sobrestimado, o trabajo hecho que aún no se ha causado y que aparecerá de golpe. Sin hitos ni facturas no hay con qué decidirlo.

### Alertas
- **Proyección excede el aprobado en 17.5%** (7.989.396.294 contra 6.800.000.000), por encima del umbral de 10%. El informe lo declara en amarillo y no menciona este exceso; el script lo marca como señal sin explicar.
- **Comprometido 66.9%**: por debajo del umbral de 90%, sin alerta.
- **Fecha de fin vencida sin replanificar:** el plan termina el 2026-06-09, anterior a hoy, con 0 replanificaciones y 0 cambios aprobados. El script reporta atraso 0 contra la línea base; no se escribe un número de días porque no sale de él.
- **Las tres cifras de movimiento y la proyección son declaración**, ninguna con evidencia (facturas, contratos, ejecución contable). Todas llevan la misma fecha, 2026-10-14, así que la proyección no es más vieja que el último movimiento de presupuesto registrado.
- **El aprobado tiene 16 meses** (acta de 2025-06-16), por encima del umbral de 12 meses para dato envejecido.

### Sin dato
- Hitos del plan (no hay cronograma en los documentos): no se puede cruzar ejecución contra hitos cumplidos.
- Detalle por proveedor / contratos: ninguno registrado, no hay desglose del comprometido.
- Cambios de presupuesto o solicitudes de cambio: ninguno en los documentos.
- Soporte de evidencia (no declaración) para comprometido, ejecutado y proyección.

### Siguiente paso posible
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). Queda a decisión de quien lo pida; no la preparé.

---
*Pie de rigor:* informe de borrador de trabajo, no decisión ni asesoría. Cada cifra viene del documento citado y del cálculo del script; la verificación es de quien lo lee. No sé lo que se habló fuera de esos dos documentos.
