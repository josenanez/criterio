## Diagnóstico · PRY-209 Migración del ERP · 2026-10-23

**Leí:** 12 documentos · 2026-02-09 a 2026-10-22 · formatos: docx (3), pdf (4), md (3), xml (1), xlsx (1). Los leí en su conversión a texto (caché); las citas apuntan al original.
**No pude leer:** nada falló. Ninguna otra minuta o documento del portafolio menciona PRY-209 ni "Migración del ERP" (búsqueda en `documentos/`), así que no hay fuente externa que lo corrobore o lo contradiga.

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 12 · **Contradicho:** 5

Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuánto se aprobó, que el estado declarado es rojo y que un contrato (CT-431) tiene recibo y factura que se corresponden. No se puede afirmar que algún hito del plan se haya cumplido: ninguno tiene acta de recibo, y el propio informe de avance contradice el cronograma. El plan se movió 95 días (cierre de 2026-09-12 a 2026-12-16) sin ninguna autorización registrada, y una factura de 596.779.430 COP (FV-2140) está radicada sin las actas de recibo que el contrato exige. Todo lo financiero del informe (comprometido, ejecutado, proyección) es declaración sin documento que lo respalde. Del conteo de fuentes: 0 de evidencia, 5 de declaración, 11 sin marcar.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Andrés Lozano | Acta de constitución, 2026-02-17 |
| Gerente | Liliana Torres | Acta de constitución; informe de avance 2026-10-19 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede decidir el gerente (fechas, presupuesto, cambios); la ficha lo registra como campo faltante. Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. | Acta de constitución (ausencia) |
| Comité | Comité de Expansión; aprobó el presupuesto el 2026-02-17. Sesión del 2026-10-22 con Liliana Torres y Andrés Lozano; temas "Avance" y "Compromisos", sin contenido. | Acta; minuta 2026-10-22 |

Otras observaciones de gobierno, todas del acta o de los contratos:
- Alcance escrito como "Componente 1, 2, 3"; objetivo "Entregar migración del erp para Tiendas"; criterio de éxito "en producción y medido" sin métrica. No hay contra qué medir "hecho".
- Dependencias declaradas: "Ninguna". El informe de avance cita dos riesgos externos (ver Contradicho).
- Los contratos se firmaron antes de la aprobación del acta: CT-140 el 2026-02-09 y CT-431 el 2026-02-14; el acta y el presupuesto son del 2026-02-17.
- Campos que la ficha no puede llenar: producto asociado (el acta dice "No aplica"), autoridad, fase.

### Contra el plan
- **Línea base original** (cronograma v1, 2026-02-17): Despliegue en la cadena, 2026-09-12. Es también la fecha de cierre del acta.
- **Vigente** (cronograma v2, 2026-10-19): Despliegue en la cadena, 2026-12-16. Los otros cuatro hitos no cambian.
- **Desviación:** 95 días, 48,2 % contra la línea base original; 0 días contra la vigente (la vigente es la que se movió). Umbral de la configuración: 10 %.
- **Replanificaciones:** 1. Motivo según el informe: congelamiento de temporada de fin de año. Motivo según la solicitud CC-01: ampliación de alcance. Los dos motivos no coinciden.
- **Autorización:** la solicitud CC-01 (2026-10-17, +95 días, +190.000.000 COP) dice "Pendiente de presentación al comité". El cronograma v2 es del 2026-10-19, dos días después, y ya aplica el movimiento. Cambios aprobados: 0; días movidos sin autorización: 95. La minuta del comité del 2026-10-22 no menciona CC-01.
- La solicitud dice "+95 días sobre la línea base vigente"; el cronograma v2 conserva la línea base en 2026-09-12 y mueve solo la vigente. Quien la lea no sabe contra cuál de las dos se pidió.
- El cronograma v1 trae los cinco hitos en 100 % y "cerrado" con fecha del 2026-02-17, cuando ninguno había ocurrido. No es una línea base original limpia: fue editado después, o es otra cosa. La fecha de estado del archivo está vacía.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-04-07 | 199 | Acta de aprobación o de recibo del diseño |
| Ambiente de pruebas certificado | 2026-05-16 | 160 | Certificación del ambiente / acta de recibo |
| Integración con el ERP | 2026-06-25 | 120 | Acta de recibo de la integración |
| Piloto en tiendas | 2026-08-03 | 81 | Acta de recibo del piloto con resultados |

Los cuatro figuran "cerrado" en el plan. En la carpeta de seguimiento no hay ninguna acta de hito: las actas que existen son de entregables de proveedor. Del quinto hito, Despliegue en la cadena, el plan dice "cerrado" con fecha vigente 2026-12-16 que aún no llega; eso se trata abajo como contradicción.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 COP (acta) | 1.797.792.500 (informe) | 1.718.414.780 (informe) | 6.340.008.359 (informe) | 5.002.207.500 |

Ejecutado: 25,3 %. Comprometido: 26,4 %. Proyección: 6,8 % por debajo de lo aprobado. Las tres cifras del medio son del informe del gerente; ninguna está respaldada por un documento de la carpeta.

Lo que sí hay en documentos, por separado:
- **CT-140 Sistemas Comerciales del Norte:** 3 entregables de 298.389.715 COP cada uno. Factura FV-2140 (2026-09-04) por 596.779.430 COP, que equivale a dos entregables. Actas de recibo en la carpeta: **0**. El contrato exige acta firmada por el gerente para facturar.
- **CT-431 Logística del Valle Ltda.:** 3 entregables de 403.757.328 COP cada uno. Factura FV-1431 (2026-09-17) por 807.514.656 COP, equivalente a dos entregables. Actas: Licenciamiento (2026-05-10) y Configuración del catálogo (2026-08-22), ambas firmadas por Liliana Torres. Aquí factura y actas cuadran.
- **Bolsa de horas de desarrollo**, en ambos contratos: comprometida para 2026-06-15, 130 días de atraso, estado "en curso", sin acta ni factura.
- Los dos contratos tienen los mismos tres entregables y las mismas fechas comprometidas, con proveedores distintos.
- El script no suma contratos ni facturas, así que no escribo totales. Con lo que hay, no puedo conciliar "comprometido" ni "ejecutado" del informe con los contratos y facturas.
- CC-01 pide 190.000.000 COP adicionales. El informe no dice si la proyección los incluye.

### Lo que se dijo y nadie registró
No hay registro RAID ni de dependencias en la carpeta. Está solo en el informe de avance, sin dueño ni fecha:
- Riesgo: disponibilidad de los jefes de tienda para el piloto.
- Riesgo: cambio en la regulación de datos personales que puede mover el alcance.
- Incidencia: la prueba de carga de temporada no alcanzó el umbral pactado y se repite. No hay umbral documentado ni resultado de la prueba.
- Incidencia: dos semanas perdidas por rotación de un desarrollador clave.
- Dependencia implícita: congelamiento de temporada de fin de año, que justifica la reprogramación y no figura entre las dependencias del acta.

Compromisos de la minuta del 2026-10-22: uno. Javier Hoyos, "Entregar el punto 6", para 2026-11-07. Javier Hoyos no figura como asistente. La minuta solo lista dos temas, así que no existe un "punto 6". Aún no vence, pero no se sabe qué debe entregar. Ningún otro documento del portafolio lo relaciona con PRY-209.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 58 % | Informe 2026-10-19: "Avance reportado: 58 %" | Cronograma v2 2026-10-19: los 5 hitos "cerrado" (100 %) |
| Despliegue en la cadena cerrado | Cronograma v2: "cerrado", fecha vigente 2026-12-16 | Informe: el despliegue se reprogramó y la prueba de carga se repite |
| Piloto en tiendas cerrado (2026-08-03) | Cronograma v2: "cerrado" | Informe 2026-10-19: riesgo abierto "disponibilidad de los jefes de tienda para el piloto" |
| Sin dependencias | Acta: "Ninguna declarada" | Informe: riesgos de jefes de tienda y de regulación de datos personales que puede mover el alcance |
| Motivo de los +95 días | Informe: congelamiento de temporada | CC-01: ampliación de alcance |

### Sin sustento
12 afirmaciones que nada contradice y nada respalda:
1. Diseño de la experiencia aprobado: cerrado.
2. Ambiente de pruebas certificado: cerrado.
3. Integración con el ERP: cerrada.
4. CT-140, Licenciamiento de la plataforma: recibido. Sin acta.
5. CT-140, Configuración del catálogo: recibido. Sin acta.
6. FV-2140 radicada "contra" los entregables recibidos de CT-140, que el contrato condiciona a acta firmada.
7. Ejecutado 1.718.414.780 COP.
8. Comprometido 1.797.792.500 COP.
9. Proyección al cierre 6.340.008.359 COP, sin método ni supuestos.
10. La prueba de carga no alcanzó el umbral.
11. Dos semanas perdidas por rotación de un desarrollador.
12. Bolsa de horas "en curso" en ambos contratos, 130 días después de su fecha comprometida.

### Lo que esta carpeta no permite saber
- **Si algún hito ocurrió.** Sin actas de hito, el 58 % y el 100 % del plan son dos declaraciones que no se pueden dirimir. Consecuencia: el comité no puede saber cuánto falta.
- **Quién aprobó el movimiento de 95 días.** No hay autoridad declarada ni cambio aprobado. Consecuencia: el cierre vigente (2026-12-16) no es una fecha comprometida, es una fecha que alguien escribió.
- **Si el cambio es de calendario o de alcance.** Los dos documentos dan motivos distintos. Consecuencia: no se sabe si lo que se pide aprobar es 95 días, 190.000.000 COP de alcance nuevo, o ambos.
- **Si FV-2140 se pagó contra algo recibido.** Consecuencia: 596.779.430 COP radicados en cuentas por pagar sin el soporte que el contrato exige.
- **Cuánto se ha gastado en realidad.** Consecuencia: el disponible real (5.002.207.500 COP) y la proyección dependen de dos cifras sin soporte.
- **Por qué hay dos contratos con los mismos tres entregables y fechas.** Puede ser división de trabajo o duplicación; la carpeta no lo dice.
- **Qué pasó en el comité del 2026-10-22.** La minuta no tiene discusión ni decisiones, y no menciona el estado rojo ni CC-01.
- **Qué es el "punto 6" de Javier Hoyos.**

### Pie de rigor
Cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-23); cifras de dinero del informe marcadas como declaración. No se recomienda detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. La verificación de cada cita es de quien lee. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

### Siguiente paso
La carpeta permite diagnosticar solo en parte. Puedo preparar el punto de comité con la lista de lo que falta, y llevar al gerente las contradicciones como preguntas, una por una: ¿qué acta respalda cada hito?, ¿cuál es el motivo real de los +95 días?, ¿qué acta respalda FV-2140?
