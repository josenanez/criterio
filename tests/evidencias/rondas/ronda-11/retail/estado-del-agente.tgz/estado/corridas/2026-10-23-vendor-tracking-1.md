# Corrida del 2026-10-23 · vendor-tracking

13 proyectos · 68 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 9 |
| `vendor_deliverable_late` | 6 |
| `progress_vs_plan` | 5 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `change_without_baseline` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Dos proveedores (CT-137, CT-293): 3 entregables sin acta y vencidos, 0 aceptados sin evidencia, facturas cuadran en monto con las actas. Dijo que no sabe: vigencia y preaviso de ambos contratos, qué cubre cada factura, y si el compromiso de Laura Vélez es de un proveedor.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Sale de:** ficha PRY-201 (`estado/records/PRY-201.json`), contratos CT-137 y CT-293 (`00-gobierno`), cuatro actas de recibo y dos facturas (`20-seguimiento`), el comité del 2026-10-23 y el cálculo de `portafolio.py compute` al 2026-10-23. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

## Proveedores — PRY-201 Programa de fidelización al 2026-10-23

### Tecnología para Tiendas Ltda. — contrato CT-137
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-10-13) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-01-18 · 132.658.021 | `unknown` — vencido hace 278 días | Ninguna. El contrato lo marca "en curso" | Sin dato por entregable |
| Bolsa de horas de desarrollo | 2026-04-23 · 132.658.021 | `accepted` (recibido 2026-05-03, 10 días después de la fecha) | `2026-05-03-acta-recibo-ct-137-bolsa-de-horas-de-desarrollo.md` | Sí, dentro de FV-2137 |
| Configuración del catálogo | 2026-07-28 · 132.658.021 | `accepted` (recibido 2026-08-07, 10 días después) | `2026-08-07-acta-recibo-ct-137-configuración-del-catálogo.pdf` | Sí, dentro de FV-2137 |
| Soporte del primer trimestre | 2026-10-31 · 132.658.021 | `unknown` — vence en 8 días, aún no atrasado | Ninguna | No |

Facturado: **265.316.042 COP** (FV-2137, 2026-09-01). Aceptado con acta: 265.316.042 COP. Cuadra.

### Sistemas Comerciales del Norte — contrato CT-293
**Vigencia:** sin dato (solo fecha de firma, 2025-09-27) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-02-11 · 104.794.999 | `unknown` — vencido hace 254 días | Ninguna. El contrato lo marca "pendiente" | No |
| Bolsa de horas de desarrollo | 2026-06-10 · 104.794.999 | `accepted` (recibido 2026-06-23, 13 días después) | `2026-06-23-acta-recibo-ct-293-bolsa-de-horas-de-desarrollo.md` | Sí, dentro de FV-1293 |
| Configuración del catálogo | 2026-10-07 · 104.794.999 | `unknown` — vencido hace 16 días | Ninguna. El contrato lo marca "en curso" | No |

Facturado: **104.794.999 COP** (FV-1293, 2026-10-08). Aceptado con acta: 104.794.999 COP. Cuadra.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturas CT-137 y CT-293 | Cada entregable se factura contra acta de recibo firmada por el gerente | Los montos facturados coinciden con los entregables que sí tienen acta (2 de CT-137, 1 de CT-293). El script no levanta `vendor_invoiced_without_delivery`. Pero las dos facturas dicen solo "Entregables del contrato" y no nombran cuáles cubren; el emparejamiento sale de sumar montos, no de la factura | Contratos; FV-2137; FV-1293; actas de recibo |
| Dos licenciamientos de la plataforma (CT-137 y CT-293) | Dos contratos distintos comprometen el mismo entregable, con el mismo nombre, y otro tanto con "Bolsa de horas" y "Configuración del catálogo" | Ninguno de los dos licenciamientos tiene acta. No puedo decir si es duplicidad de alcance o reparto legítimo; el acta de constitución no lo aclara | Contratos CT-137 y CT-293 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento de la plataforma (CT-137) | "en curso" en el contrato; `pending` en la ficha | 2026-01-18 (278 días) |
| Licenciamiento de la plataforma (CT-293) | "pendiente" en el contrato; `pending` en la ficha | 2026-02-11 (254 días) |
| Configuración del catálogo (CT-293) | "en curso" en el contrato; `pending` en la ficha | 2026-10-07 (16 días) |

Aceptados sin evidencia: 0 en ambos proveedores. Cada entregable aceptado tiene su acta.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Laura Vélez — "Entregar el punto 36" | `30-reuniones/2026-10-23-comite-semanal.md` | 2026-10-12 | 11 |

El acta del comité no dice a qué organización pertenece Laura Vélez, ni qué es el "punto 36". No puedo afirmar que sea un compromiso de proveedor. Se lista por si lo es. El otro compromiso (Javier Hoyos, "punto 3", para hoy 2026-10-23) está abierto y tampoco se puede atribuir a un proveedor.

### Sin dato
- **Vigencia, renovación automática y preaviso de ambos contratos.** Ninguno de los dos documentos los trae. No puedo decir si hay un preaviso por vencer antes del cierre. El cierre cambió de 2026-12-22 a 2027-03-14 con CC-01. Conviene pedir los contratos completos o sus anexos.
- **Qué entregables cubre cada factura.** Las dos facturas no los nombran.
- **Si CC-01 (ampliación de alcance, 164.000.000 COP adicionales, aprobada por "el comité" sin nombrar) toca a alguno de los dos proveedores.** La ficha no lo dice.
- El contrato CT-137 trae el estado de cada entregable ("recibido", "en curso") escrito por quien lo redactó. Eso no cuenta como evidencia de aceptación; solo cuentan las actas.

### Para llevar a comité
1. Los dos licenciamientos de la plataforma llevan 278 y 254 días vencidos sin acta, y no hay constancia de que alguien los haya reclamado. Esta corrida no encontró ninguna factura contra ellos. Aun así, el contrato condiciona el pago al acta. Conviene confirmar con cuentas por pagar que no se paguen sin ella.
2. Configuración del catálogo (CT-293) está vencido hace 16 días, y el proveedor ya facturó 104.794.999 COP el día siguiente al vencimiento. Esa factura coincide en monto con la bolsa de horas ya recibida, pero ver el desglose de la factura lo confirmaría.
3. El soporte del primer trimestre (CT-137) vence el 2026-10-31, dentro de 8 días.

Fuera de proveedores, el script marca tres hitos declarados cumplidos sin evidencia (Diseño de la experiencia, Ambiente de pruebas, Piloto en tiendas). Es tema de `/status-report`, pero cuenta para la lectura global.

---
**Rigor:** cifras de `portafolio.py compute` al 2026-10-23, copiadas sin redondeo propio. Cada línea cita el documento del que sale. Lo que no está en la carpeta se declara como "sin dato". Es un borrador de trabajo; la verificación contra los originales es de quien lo lea.
