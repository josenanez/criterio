Cierre de PRY-204 (Cajas de autopago), a 2026-10-23. Sale de la ficha `estado/records/PRY-204.json`, de la salida de `portafolio.py compute` y de los 5 documentos de la carpeta del proyecto: acta de constitución (2025-06-16), cronograma v1 (2025-06-16), informe de avance (2026-10-20), acta de recibo del piloto (2026-10-23) y comité semanal (2026-10-19). Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

## Cierre — PRY-204 Cajas de autopago — 2026-10-23

**Conclusión: no se puede cerrar contra lo pactado.** Hoy solo se podría cerrar por decisión de alguien, no por cumplimiento. Esa decisión no está registrada en ningún documento.

### Contra lo comprometido
**Criterio de éxito:** "Cajas de autopago en producción y medido" (acta de constitución, 2025-06-16, `00-gobierno/2025-06-16-acta-constitucion.docx`).
**Se cumplió:** no se puede determinar. Ningún documento muestra producción ni medición. Lo único recibido es el piloto.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño de la experiencia aprobado (hito 2025-10-07) | Declarado cerrado | Sin evidencia de recibo. Es una de las 3 alertas `milestone_met_without_evidence`; el hito lleva 381 días vencido sin soporte. |
| Ambiente de pruebas certificado (hito 2026-01-19) | Declarado cerrado | Sin evidencia de recibo (277 días). |
| Integración con el ERP (hito 2026-05-02) | Declarado cerrado | Sin evidencia de recibo (174 días). |
| Piloto en tiendas (hito 2026-08-14) | Recibido | `20-seguimiento/2026-10-23-acta-recibo-piloto-en-tiendas.pdf`: recibido a satisfacción por Paula Céspedes, la gerente del proyecto. El acta no la firma nadie de fuera del proyecto. |
| Cajas en producción y medido (criterio de éxito) | Sin entregable ni hito en el cronograma | Ninguna. |

El acta nombra el alcance como "Componente 1, 2, 3" sin describirlos. Por eso no se puede contrastar qué se entregó contra qué se prometió más allá de los 4 hitos del cronograma.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Nada registrado. La única exclusión del acta es "lo que otro proyecto cubre", sin nombrar a qué proyecto. | Sin dato | Sin dato |

No hay solicitudes de cambio (`changes.total` = 0). No consta que se haya recortado alcance, pero tampoco hay una decisión que lo descarte.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-14 | 2026-08-14 | Sin dato: el cierre no está declarado | 0 días según `compute`. Ver nota. |
| Presupuesto aprobado (COP) | 3.300.000.000 | 3.300.000.000 | Proyección declarada: 3.171.678.820 | -3,9 % (proyección por debajo de lo aprobado) |

Replanificaciones: 0.

**Nota:** el hito Piloto en tiendas tenía fecha 2026-08-14 y el acta de recibo lleva fecha 2026-10-23. El cronograma sigue en v1, sin línea base nueva ni replanificación. Por eso `compute` da 0 días de atraso. Esa cifra sale de que nadie registró el atraso, no de que no lo haya habido. No escribo los días de diferencia porque el script no los calcula; lo que falta es la fecha final real de cierre.

**Presupuesto (COP, declarado por el gerente el 2026-10-20):** comprometido 2.007.409.712 (60,8 %); ejecutado 1.312.457.340 (39,8 %); disponible real 1.292.590.288. Son declaraciones del informe de avance, sin factura ni soporte contable en la carpeta. No hay un ejecutado final.

**Avance declarado:** 48 %, contra 4 de 4 hitos marcados como cumplidos, que es una brecha de 52 puntos. El informe declara Rojo. El plan por sí solo sostendría 100 %, así que alguno de los dos números está mal. Las alertas `progress_vs_plan` y `milestone_met_without_evidence` siguen sin explicación en el informe.

### RAID al cierre
**Materializados:** el hallazgo de seguridad en los medios de pago, abierto como incidencia el 2026-10-20.
**No materializados:** ninguno se puede dar por descartado con la documentación disponible.
**Abiertos, con doliente:** ninguno tiene doliente con nombre, salvo el compromiso de la reunión.
- Riesgo "Disponibilidad de los jefes de tienda para el piloto" (informe 2026-10-20). Sin dueño, probabilidad, impacto ni fecha. Sigue listado como abierto aunque el piloto ya se recibió.
- Incidencia "Hallazgo de seguridad en los medios de pago" (desde 2026-10-20). Sin dueño y sin plan.
- Compromiso de Felipe Arango, "Entregar el punto 24", para 2026-10-26 (comité 2026-10-19). Abierto. El acta no dice qué es el "punto 24".

Lo que queda abierto necesita doliente con nombre o no está cerrado. Aquí ninguna de las dos incidencias o riesgos lo tiene.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marca 3 hitos como "cerrado" sin acta de recibo en la carpeta. | Hitos del 2025-10-07, 2026-01-19 y 2026-05-02 | El avance (48 %) y los hitos (4 de 4) no se pueden conciliar, y no hay forma de saber qué se entregó de verdad. | Exigir el acta de recibo con fecha como condición para marcar un hito como cumplido. |
| El piloto, fechado para 2026-08-14, se recibió el 2026-10-23 sin replanificación registrada. | 2026-08-14 al 2026-10-23 | El atraso aparece como 0 días en el cálculo y el cierre se mide contra una fecha que ya no era real. | Registrar la línea base nueva sin borrar la original cuando una fecha se mueve. |
| El criterio de éxito ("en producción y medido") no tiene hito ni entregable en el cronograma. El último hito es el piloto. | Acta del 2025-06-16 | El proyecto puede recibir su último hito y seguir sin cumplir lo que se pactó. | Convertir el criterio de éxito en un hito con fecha y quién lo mide. |

Dejo fuera cualquier otra lección. No hay hecho documentado que la sostenga.

### Sin dato
- Si hay producción y medición: ningún documento lo dice.
- Evidencia de recibo de los hitos 1 a 3.
- Quién decide el cierre. La ficha no tiene autoridad (`identity.authority`) ni fase (`identity.phase`).
- A qué proyecto corresponde "lo que otro proyecto cubre".
- Qué son los componentes 1, 2 y 3, y el "punto 24".
- Presupuesto ejecutado final con soporte.
- Campos de la ficha con más de 12 meses de antigüedad, todos del acta del 2025-06-16: área, producto, patrocinador, fechas, alcance, exclusiones y presupuesto aprobado.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha. Mi recomendación, que es la respuesta que tomo en esta sesión sin interfaz, es esperar. El cierre no está declarado, y hay una incidencia de seguridad sin dueño y un compromiso abierto. Un proyecto con eso abierto no sale del barrido diario.

**Pie de rigor:** borrador de trabajo. Toda cifra viene de `portafolio.py compute` o de la cita del documento. La verificación es de quien lo lea. Criterio no sabe lo que se habló fuera de estos 5 documentos.
