*Fichas cargadas: las 13 de `estado/records/` (PRY-199 a PRY-211), corte 2026-10-23, con el cálculo de `portafolio.py compute` de esa misma fecha. Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-23. No pasaste fecha: tomé la del próximo comité de la configuración, 2026-11-06.*

# Comité de proyectos — 2026-11-06 (datos al 2026-10-23)
7 decisiones · 6 escalamientos · 10 de 13 proyectos con hallazgos (58 señales abiertas)

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | No hay en `estado` material ni acta de un comité de portafolio anterior, así que no puedo cerrar el ciclo. Lo único parecido son tres solicitudes CC-01 que dicen «Autorizada por el comité» (PRY-201, PRY-205) o «Pendiente de presentación al comité» (PRY-209); ninguna minuta de comité las registra (ver decisiones 2, 3 y 4). | No se puede determinar |

## Decisiones de hoy

### [1] ¿Fija el comité por escrito, para cada proyecto, hasta dónde decide el gerente (monto, alcance, fechas) y qué decide el comité?
**Proyecto:** los 13 · **Quién decide:** el comité del portafolio; ninguna acta declara la facultad de nadie · **Si no se decide hoy:** los puntos 2, 3 y 4 de este paquete seguirán sin poder decirse bien hechos o mal hechos, porque no hay regla contra la cual medirlos.

La ficha de los 13 proyectos tiene `identity.authority` sin dato. Cada CC-01 dice que lo autorizó «el comité» sin nombrar a nadie.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Regla única de portafolio, escrita y anexada a cada acta | Ninguno | Una sesión; aplica desde ya | Ninguno en COP |
| B. Regla por proyecto, la fija cada comité (Expansión, Cadena de Abastecimiento, Comercial, Arquitectura, Transformación Digital) | Ninguno | Más lenta: cinco comités | Ninguno en COP; riesgo de reglas distintas para lo mismo |
| C. No declararla | — | — | Es lo de hoy: todo cambio termina en comité o se aprueba sin quien pueda |

**Recomendación:** A, y que cada acta la cite. Cuesta una hoja y desbloquea los puntos siguientes. Los montos y plazos del tope no salen de ningún documento: los fija el comité.

### [2] ¿Aprueba el Comité de Expansión la CC-01 de PRY-209 (ampliación de alcance, +95 días, 190.000.000 COP), o se devuelve el cronograma a la línea base original?
**Proyecto:** PRY-209 Migración del ERP · **Quién decide:** Comité de Expansión (facultad no declarada) · **Si no se decide hoy:** el proyecto sigue trabajando con una línea base que corrió 95 días sin autorización, y el atraso real contra lo aprobado no se ve.

Hechos: la solicitud (2026-10-17, Liliana Torres) dice «Pendiente de presentación al comité», pero la línea base ya se movió 95 días (fin 2026-12-16; `rebaseline_unauthorized`, 95 días sin autorizar, 48,2 % contra la original). Declara rojo y 58 % de avance; el plan sustenta 100 %, con 4 hitos cumplidos sin evidencia. La solicitud no detalla qué alcance se amplía.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base nueva con su acta | Se amplía; sin detalle en el documento | +95 días, ya reflejados en el cronograma v2 | +190.000.000 COP. Proyección declarada hoy: 6.340.008.359 COP contra 6.800.000.000 aprobados; no sé si ya incluye la CC-01 |
| B. No aprobar y volver a la línea base original | Sin ampliación | Se pierde el cronograma v2; el atraso real queda a la vista | 0 COP adicionales |
| C. Aprobar solo si traen el detalle del alcance y la evidencia de los 4 hitos | A definir | Sin cambio hasta entonces | Sin cambio hasta entonces |

**Recomendación:** C. La autorización no puede ser retroactiva sobre un alcance que no está descrito, ni sobre hitos que no tienen acta. Si el 11-06 no hay detalle, B.

### [3] ¿Ratifica el Comité de Expansión en acta la CC-01 de PRY-201 (ampliación de alcance, +82 días, 164.000.000 COP), o la desconoce?
**Proyecto:** PRY-201 Programa de fidelización · **Quién decide:** Comité de Expansión (facultad no declarada) · **Si no se decide hoy:** la línea base v2 (fin 2027-03-14) se queda apoyada en una autorización que ningún acta respalda.

Hechos: la solicitud (2026-10-23, Diana Molina) dice «Autorizada por el comité» sin nombrar a quién. El acta del Comité de Expansión del mismo día (Diana Molina y Gustavo Neira) trata «Avance» y «Compromisos» y no menciona la CC-01. La línea base se movió 82 días, los mismos que pide la solicitud. Atraso contra la original: 82 días, 18,9 %. Declara amarillo y 69 %; el plan sustenta entre 80 % y 100 %.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar en acta con quién decidió | Ampliación sin detallar | Fin 2027-03-14, 82 días sobre la original | +164.000.000 COP. Aprobado 2.400.000.000; proyección 2.512.609.121 (+4,7 %); no sé si la proyección incluye la CC-01 |
| B. Desconocerla | Vuelve al alcance original | Vuelve a 2026-12-22, con el proyecto ya atrasado | 0 COP adicionales |
| C. Ratificar con condición: detalle del alcance y costo antes de cerrar el acta | A definir | Igual que A | Igual que A |

**Recomendación:** C. La ampliación ya está corriendo; lo que falta es que alguien con nombre la haya decidido y que se sepa qué se amplió. Si es A, que el acta diga quién y con qué autoridad.

### [4] ¿Ratifica el Comité de Cadena de Abastecimiento la CC-01 de PRY-205 (ampliación de alcance, +42 días, 84.000.000 COP) y manda registrar la línea base nueva?
**Proyecto:** PRY-205 Pago con QR en caja · **Quién decide:** Comité de Cadena de Abastecimiento (facultad no declarada) · **Si no se decide hoy:** la desviación sigue medida contra un cronograma que ya no se usa.

Hechos: solicitud del 2026-10-10 (Carlos Peña), «Autorizada por el comité». El acta del comité del 2026-10-14 (Carlos Peña y Beatriz Cuéllar) solo trae un compromiso y no la menciona. Señal `change_without_baseline`: 42 días aprobados sin línea base nueva. Variación contra la original: 42 días, 22,1 %. Declara amarillo y 35 % (corte 2026-10-01); el plan sustenta 100 %, con 5 de 5 hitos cumplidos y 4 sin evidencia.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y registrar línea base v3 con acta | Ampliación sin detallar | +42 días | +84.000.000 COP. Aprobado 800.000.000; proyección 760.057.716 (−5,0 %) |
| B. Desconocerla | Sin ampliación | Vuelve a la línea base original | 0 COP adicionales |
| C. Ratificar con condición: detalle del alcance y evidencia de hitos | A definir | Igual que A | Igual que A |

**Recomendación:** C, por la misma razón que el punto 3. Además, el hito «Despliegue en la cadena» figura cumplido (2026-05-02) con 35 % de avance declarado: alguna de las dos cosas no es cierta.

### [5] ¿Cómo se trata el sobrecosto proyectado de PRY-206 Precios dinámicos: se amplía el presupuesto, se recorta el alcance o se congelan los compromisos nuevos hasta tener una opción costeada?
**Proyecto:** PRY-206 · **Quién decide:** Comité Comercial (aprobó el presupuesto el 2025-06-16; facultad no declarada) · **Si no se decide hoy:** el proyecto sigue comprometiendo contra un presupuesto que su propia proyección supera.

Hechos: aprobado 6.800.000.000 COP; comprometido 4.549.637.864 (66,9 %); ejecutado 2.471.333.613 (36,3 %); proyección 7.989.396.294, **17,5 %** sobre lo aprobado (umbral 10 %). Declara amarillo, 60 %. El informe del 2026-10-14 no explica el desvío ni lo lista entre sus riesgos. Sin comprometer hoy: 2.250.362.136 COP.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar el presupuesto hasta la proyección | Sin cambio | Sin cambio | +17,5 % sobre lo aprobado |
| B. Recortar alcance para volver a 6.800.000.000 | Se reduce; ningún documento dice qué | Sin dato | Sin cambio sobre lo aprobado |
| C. Congelar compromisos nuevos hasta que el gerente traiga la causa y A o B costeadas | Sin cambio | Posible atraso por la espera | Frena hasta 2.250.362.136 COP aún sin comprometer |

**Recomendación:** C. Hoy no hay causa del desvío ni contenido que recortar, así que A o B serían decidir a ciegas.

### [6] ¿Nombra el comité un doliente único para el hallazgo de seguridad en medios de pago que aparece en cuatro proyectos?
**Proyecto:** PRY-200, PRY-204, PRY-206, PRY-211 · **Quién decide:** el comité del portafolio (cruza cuatro proyectos y tres comités; ninguna acta dice quién decide) · **Si no se decide hoy:** el mismo hallazgo se queda en cuatro informes sin dueño, con fechas entre 2026-10-14 y 2026-10-22.

Hechos: la redacción es idéntica en los cuatro informes y ninguno tiene doliente. **No puedo confirmar con los documentos que sea un solo hallazgo**; puede ser texto copiado entre informes. PRY-205 (Pago con QR) no lo reporta; no sé si le aplica.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un doliente único para todo el portafolio | Cubre los 4 y los que se sumen | Se activa de inmediato | Sin dato |
| B. Un doliente por proyecto | Cada gerente atiende el suyo | Más lento si es el mismo hallazgo | Sin dato; riesgo de cuatro soluciones |
| C. Primero confirmar si es uno solo, y luego decidir | Sin cambio | Una semana más con el hallazgo sin dueño | Ninguno |

**Recomendación:** A, y que su primera tarea sea confirmar si es uno o son cuatro. Un hallazgo de seguridad en pagos no debería esperar a una discusión de alcance. No sé quién debe ser el doliente y no propongo un nombre.

### [7] Para los cinco proyectos con fecha de fin vigente ya pasada y avance declarado por debajo de 100 %, ¿se les exige evidencia de los hitos antes de decidir si se replanifican, o se les exige replanificar de una vez?
**Proyecto:** PRY-204, PRY-205, PRY-206, PRY-208, PRY-211 · **Quién decide:** el comité del portafolio · **Si no se decide hoy:** cinco proyectos siguen reportando contra una fecha que ya pasó sin que nadie haya movido la línea base.

| Proyecto | Fin vigente | Avance declarado | Plan sustenta | Hitos cumplidos |
|---|---|---|---|---|
| PRY-204 Cajas de autopago | 2026-08-14 | 48 % | 100 % | 4 de 4 (3 sin evidencia) |
| PRY-205 Pago con QR en caja | 2026-05-02 | 35 % | 100 % | 5 de 5 (4 sin evidencia) |
| PRY-206 Precios dinámicos | 2026-06-09 | 60 % | sin hitos medidos | sin dato |
| PRY-208 Domicilios en dos horas | 2026-04-28 | 60 % | sin hitos medidos | sin dato |
| PRY-211 Pronóstico de demanda | 2026-02-14 | 25 % | 100 % | 4 de 4 (3 sin evidencia) |

No sé cuántos días de atraso son: el cálculo no los entrega y no los pongo a mano. Tampoco sé si el campo «fin vigente» es la fecha de la línea base o el último hito.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir evidencia de los hitos declarados cumplidos | Sin cambio | Define si el error está en el plan o en el avance declarado | Ninguno |
| B. Exigir replanificación por control de cambios en los cinco | Posible recorte o ampliación | Fecha nueva con motivo | A calcular por proyecto |
| C. Dejarlo | — | — | — |

**Recomendación:** A primero. En cuatro casos el plan dice 100 % y el gerente declara entre 25 % y 60 %; sin la evidencia de los hitos no se sabe cuál de los dos números está mal, y replanificar sobre el equivocado repite el problema.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-202 | Fechas de diciembre contra el congelamiento: 6 reprogramaciones de «Enviar el documento 1» (Óscar Ramírez) y 5 de «Cerrar la prueba 2» (Mauricio Pérez). Proyección 2.392.525.628 contra 2.400.000.000 aprobados, 52 %, rojo | Compromisos desde 2026-09-30 | No se puede formular: faltan la ventana del congelamiento, la causa del bloqueo y la propuesta del proveedor con su costo. La revisión con el proveedor es el 2026-11-02, antes del comité |
| PRY-202, PRY-207, PRY-209 | «Despliegue reprogramado por el congelamiento»; en PRY-202 y PRY-207 el cronograma vigente sigue en v1 | 2026-09-30 a 2026-10-19 | Control de cambios por proyecto. PRY-209 se ve en el punto 2 |
| PRY-201 | Licenciamiento CT-137 (278 días) y CT-293 (254 días) sin acta de recibo; Configuración del catálogo CT-293, 16 días. Vigencia de ambos contratos: sin dato | 2026-01-18, 2026-02-11 y 2026-10-07 | Confirmar con cuentas por pagar que no se paguen sin acta. Soporte del primer trimestre CT-137 vence el 2026-10-31 |
| PRY-209 | «Bolsa de horas» vencida 130 días con dos proveedores (CT-140 y CT-431). Licenciamiento y Configuración del catálogo (CT-140) aceptados sin acta | 2026-06-15 | Las actas de recibo, o la reversión del estado |
| PRY-202 | Riesgo dicho en la reunión del 2026-10-23: el proveedor podría no llegar con el equipo completo. Nadie lo registró ni tiene doliente | 2026-10-23 | Que la gerente lo formalice y nombre doliente |
| PRY-199, PRY-203, PRY-205, PRY-208 | Dependencia de proveedor sin fecha confirmada (la de PRY-205 viene del informe más viejo, 2026-10-01) | Informes del 2026-10-01 al 2026-10-21 | Confirmación escrita de cada proveedor |

## Para conocimiento
- **PRY-199 Iluminación LED en bodegas:** verde, 20 %, sin señales abiertas.
- **PRY-200 Tienda en línea:** verde contradicho: 2 hitos cumplidos sin evidencia (65 % declarado, plan sustenta 67 %–100 %).
- **PRY-203 Reposición automática:** rojo declarado, 74 %, sin señales calculadas; el informe no dice qué lo pone en rojo.
- **PRY-207 Marca propia de alimentos:** verde contradicho: 3 hitos cumplidos sin evidencia; declaración de 23 días.
- **PRY-208 Domicilios en dos horas:** amarillo, 60 %; sin señales calculadas.
- **PRY-210 Etiquetas electrónicas:** amarillo, 35 %; una bolsa de horas del proveedor con 3 días de vencida (CT-548).
- **PRY-211 Pronóstico de demanda:** ver punto 7. Un compromiso vencido (Carlos Peña, «punto 25», 5 días).

## Anexo

### Estado por proyecto
| Proyecto | Declarado | Corte | Señales | Proyección contra aprobado |
|---|---|---|---|---|
| PRY-199 | verde · 20 % | 2026-10-21 | 0 | 0,0 % |
| PRY-200 | verde · 65 % | 2026-10-22 | 3 | −5,7 % |
| PRY-201 | amarillo · 69 % | 2026-10-23 | 9 | +4,7 % |
| PRY-202 | rojo · 52 % | 2026-10-18 | 12 | −0,3 % |
| PRY-203 | rojo · 74 % | 2026-10-18 | 0 | +2,3 % |
| PRY-204 | rojo · 48 % | 2026-10-20 | 4 | −3,9 % |
| PRY-205 | amarillo · 35 % | 2026-10-01 | 8 | −5,0 % |
| PRY-206 | amarillo · 60 % | 2026-10-14 | 1 | **+17,5 %** |
| PRY-207 | verde · 70 % | 2026-09-30 | 4 | −7,2 % |
| PRY-208 | amarillo · 60 % | 2026-10-12 | 0 | −3,7 % |
| PRY-209 | rojo · 58 % | 2026-10-19 | 11 | −6,8 % |
| PRY-210 | amarillo · 35 % | 2026-10-20 | 1 | +2,4 % |
| PRY-211 | amarillo · 25 % | 2026-10-15 | 5 | −0,4 % |

### Contradicciones abiertas
- Verde contra evidencia: PRY-200 y PRY-207.
- Avance declarado por debajo de lo que el plan sustenta: PRY-201 (11 puntos), PRY-204 (52), PRY-205 (65), PRY-209 (42), PRY-211 (75).
- Cambio aprobado sin línea base nueva: PRY-205 (CC-01, 42 días).
- Línea base movida sin cambio autorizado: PRY-209 (95 días).

### Compromisos vencidos o reprogramados
- PRY-202: 6 vencidos (Javier Hoyos ×2, Jorge Medina ×2, Rubén Cárdenas, Gustavo Neira); 2 sin fecha (Liliana Torres, «prueba 18»; Laura Vélez, «ajuste del presupuesto»); 3 reprogramados (Óscar Ramírez 6 veces, Mauricio Pérez 5, Camilo Beltrán 3).
- PRY-201: Laura Vélez, «punto 36», 11 días. PRY-205: Diana Molina, «punto 13», 24 días. PRY-211: Carlos Peña, «punto 25», 5 días.

### Solicitud en curso sin datos para decidir
PRY-201: mover 30 días la salida a producción. No consta quién la pide, el motivo ni el impacto en alcance y costo. Quien la lleve debe completarla antes de que sea punto de comité.

### Vacíos de información
- `identity.authority` sin dato en los 13. `identity.phase` sin dato en los 13. `identity.product` sin dato en PRY-202, 203, 206, 209, 210 y 211.
- Campos con fuente de más de 12 meses en PRY-201, 204, 205, 206, 208 y 211 (el presupuesto aprobado, en 204, 205, 206, 208 y 211).
- Las 13 fichas traen 0 datos marcados como evidencia: sus cifras de dinero son declaradas, no verificadas contra un documento contable.
- PRY-205: ejecutado (339.846.720 COP) mayor que comprometido (236.283.277 COP). No sé cuál de las dos cifras está mal.
- Ningún acta declara dependencias entre proyectos («Ninguna declarada» en los 13), así que el cruce de portafolio no puede ver arrastres. Eso no prueba que no existan.
- RAID: 36 ítems, ninguno con doliente. Asignarlos es del gerente de cada proyecto y no va a comité.

---
**Pie:** borrador de trabajo de criterio-portfolio 0.8.0 (términos v1.2). Fichas aplicadas: PRY-199 a PRY-211, corte 2026-10-23. Cifras derivadas copiadas de `portafolio.py compute`; no recalculé ninguna a mano. Campos inciertos: autoridad de cada comité, hito de «salida a producción» de PRY-201, si las proyecciones de PRY-201, 205 y 209 incluyen sus CC-01, días de atraso de los cinco proyectos del punto 7, y si el hallazgo de seguridad es uno solo. La verificación contra los originales es de quien lo use. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

**Después:** cuando el comité sesione, puedo registrar sus decisiones en las fichas (autoridad, líneas base nuevas, doliente del hallazgo) para que el material del siguiente comité cierre el ciclo.
