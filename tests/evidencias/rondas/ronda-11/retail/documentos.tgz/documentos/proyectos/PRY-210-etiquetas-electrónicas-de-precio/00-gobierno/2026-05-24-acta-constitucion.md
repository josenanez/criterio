# Acta de constitución · Etiquetas electrónicas de precio

**Código:** PRY-210
**Área dueña:** Tiendas
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-24

## Objetivo del negocio

Entregar etiquetas electrónicas de precio para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-05-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-03 |
| Cierre | 2027-02-11 |

## Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

## Dependencias declaradas

- Ninguna declarada
