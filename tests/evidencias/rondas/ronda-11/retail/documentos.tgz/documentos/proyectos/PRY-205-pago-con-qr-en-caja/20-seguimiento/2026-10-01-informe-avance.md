# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-01
**Gerente:** Carlos Peña

## Estado declarado

**Amarillo**

Avance reportado: **35%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 236.283.277 |
| Ejecutado | 339.846.720 |
| Proyección al cierre | 760.057.716 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
