# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-10-16
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-12-08 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-12-21 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 |
| Gustavo Neira | Aprobar el diseño 5 | 2026-11-14 |
| María Restrepo | Actualizar la matriz 6 | 2026-10-26 |
| Camilo Beltrán | Entregar el punto 8 | 2026-11-17 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-06 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-22 |
| Beatriz Cuéllar | Aprobar el diseño 13 | 2026-11-08 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-11-03 |
| Liliana Torres | Cerrar la prueba 18 | por definir |
| Gustavo Neira | Revisar el anexo 19 | 2026-10-22 |
| Gustavo Neira | Validar el ambiente 20 | 2026-10-29 |
| Elena Duarte | Aprobar el diseño 21 | 2026-11-13 |
| Jorge Medina | Actualizar la matriz 22 | 2026-11-06 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-26 |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-27 |

## Cerrados en esta reunión

- Confirmar la fecha 15 (Camilo Beltrán): recibido, acta de recibo del 2026-10-16.
- Enviar el documento 17 (Elena Duarte): recibido, acta de recibo del 2026-10-16.

## Lo que se dijo

- Elena Duarte dice que ya entregó «validar el ambiente 12». No se presentó acta.
- Javier Hoyos dice que ya entregó «entregar el punto 16». No se presentó acta.
