# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-23
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **69%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.475.958.924 |
| Ejecutado | 443.784.230 |
| Proyección al cierre | 2.512.609.121 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
