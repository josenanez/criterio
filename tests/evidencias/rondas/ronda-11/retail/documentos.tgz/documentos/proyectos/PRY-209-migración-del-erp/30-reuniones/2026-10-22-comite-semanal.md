# Comité de Expansión · Migración del ERP

**Fecha:** 2026-10-22
**Asistentes:** Liliana Torres, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 6 | 2026-11-07 |
