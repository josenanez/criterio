# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Pago con QR en caja
**Fecha:** 2026-10-10
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +42 días sobre la línea base vigente |
| Costo | 84.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
