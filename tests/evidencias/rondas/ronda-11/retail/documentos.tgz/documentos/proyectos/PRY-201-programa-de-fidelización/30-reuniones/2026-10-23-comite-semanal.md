# Comité de Expansión · Programa de fidelización

**Fecha:** 2026-10-23
**Asistentes:** Diana Molina, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 3 | 2026-10-23 |
| Laura Vélez | Entregar el punto 36 | 2026-10-12 |
