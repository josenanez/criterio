# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-09-11
**Asistentes:** Javier Hoyos, Jorge Medina, Mauricio Pérez, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-02 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-30 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-02 |
