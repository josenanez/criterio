# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Migración del ERP
**Fecha:** 2026-10-17
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +95 días sobre la línea base vigente |
| Costo | 190.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
