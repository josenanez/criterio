# Comité de Transformación Digital · Pronóstico de demanda

**Fecha:** 2026-10-12
**Asistentes:** Carlos Peña, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 25 | 2026-10-18 |
