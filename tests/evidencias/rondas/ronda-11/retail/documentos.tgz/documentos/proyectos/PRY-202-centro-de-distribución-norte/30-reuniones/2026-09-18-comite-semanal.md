# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-09-18
**Asistentes:** Camilo Beltrán, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Mauricio Pérez, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Enviar el documento 1 | 2026-10-09 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-19 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-09 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-02 |
| Gustavo Neira | Aprobar el diseño 5 | 2026-10-08 |
| María Restrepo | Actualizar la matriz 6 | 2026-10-05 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-04 |
| Camilo Beltrán | Entregar el punto 8 | 2026-10-10 |
