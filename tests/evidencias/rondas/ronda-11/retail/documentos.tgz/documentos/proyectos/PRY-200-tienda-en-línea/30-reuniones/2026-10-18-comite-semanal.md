# Comité de Expansión · Tienda en línea

**Fecha:** 2026-10-18
**Asistentes:** Beatriz Cuéllar, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 21 | 2026-10-26 |
