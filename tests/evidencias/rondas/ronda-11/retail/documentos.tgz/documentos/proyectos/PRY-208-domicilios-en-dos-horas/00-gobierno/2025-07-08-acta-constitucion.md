# Acta de constitución · Domicilios en dos horas

**Código:** PRY-208
**Área dueña:** Finanzas
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Expansión
**Producto asociado:** entrega rápida
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar domicilios en dos horas para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Expansión el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2026-04-28 |

## Criterio de éxito

Domicilios en dos horas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
