# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-23
**Solicitante:** Diana Molina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +82 días sobre la línea base vigente |
| Costo | 164.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
