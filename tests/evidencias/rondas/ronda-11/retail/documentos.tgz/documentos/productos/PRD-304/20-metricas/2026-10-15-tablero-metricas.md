# Tablero de métricas · Marca propia

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 141.742 | 2026-10-15 |
