# Comité de producto · Venta en línea

**Fecha:** 2026-10-21
**Asistentes:** Liliana Torres

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-08 | — |
| REQ-4001 | Requerimiento REQ-4001 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-18 | — |
| REQ-4002 | Requerimiento REQ-4002 | Óscar Ramírez | se verifica en producción | — | propuesto | 2026-04-05 | — |
| REQ-4003 | Requerimiento REQ-4003 | Sandra Gil | — | Cliente entrevistado | propuesto | 2026-05-14 | — |
| REQ-4004 | Requerimiento REQ-4004 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-13 | — |
| REQ-4005 | Requerimiento REQ-4005 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4006 | Requerimiento REQ-4006 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-31 | — |
| REQ-4007 | Requerimiento REQ-4007 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4008 | Requerimiento REQ-4008 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4009 | Requerimiento REQ-4009 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-28 | — |
| REQ-4010 | Requerimiento REQ-4010 | Laura Vélez | se verifica en producción | — | aceptado | 2026-06-08 | — |
| REQ-4011 | Requerimiento REQ-4011 | Gustavo Neira | — | — | aceptado | 2026-08-19 | — |
| REQ-4012 | Requerimiento REQ-4012 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-15 | — |
| REQ-4013 | Requerimiento REQ-4013 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-06-06 | — |

## Decisiones

- Se mantiene el plan
