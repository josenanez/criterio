# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2026-07-12
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 218.898 | Caso de negocio, 2026-07-12 |

## Retorno esperado

Retorno esperado en 24 meses.
