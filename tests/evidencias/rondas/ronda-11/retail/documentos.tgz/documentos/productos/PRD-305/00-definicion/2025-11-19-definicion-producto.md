# Definición de producto · Entrega rápida

**Código:** PRD-305
**Gerente de producto:** Javier Hoyos
**Segmento:** Hogares
**Fecha de la definición:** 2025-11-19

## El problema

El segmento Hogares no tiene entrega rápida.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-07-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
