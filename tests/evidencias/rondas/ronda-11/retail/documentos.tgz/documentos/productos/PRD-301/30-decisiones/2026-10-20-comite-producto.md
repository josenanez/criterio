# Comité de producto · Puntos de fidelización

**Fecha:** 2026-10-20
**Asistentes:** Beatriz Cuéllar

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4101 | Requerimiento REQ-4101 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4102 | Requerimiento REQ-4102 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4103 | Requerimiento REQ-4103 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4104 | Requerimiento REQ-4104 | Javier Hoyos | se verifica en producción | — | propuesto | 2026-04-20 | — |
| REQ-4105 | Requerimiento REQ-4105 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-02 | — |
| REQ-4106 | Requerimiento REQ-4106 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4107 | Requerimiento REQ-4107 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-4108 | Requerimiento REQ-4108 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-28 | — |
| REQ-4109 | Requerimiento REQ-4109 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4110 | Requerimiento REQ-4110 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4111 | Requerimiento REQ-4111 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4112 | Requerimiento REQ-4112 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-04 | — |
| REQ-4113 | Requerimiento REQ-4113 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-09 | — |
| REQ-4114 | Requerimiento REQ-4114 | Paula Céspedes | — | Cliente entrevistado | propuesto | 2026-09-05 | — |
| REQ-4115 | Requerimiento REQ-4115 | Liliana Torres | se verifica en producción | — | aceptado | 2026-08-17 | — |
| REQ-2030 | Requerimiento REQ-2030 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-10-03 | — |

## Decisiones

- Se mantiene el plan
