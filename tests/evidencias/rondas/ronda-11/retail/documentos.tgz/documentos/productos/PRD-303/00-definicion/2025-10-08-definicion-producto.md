# Definición de producto · Pago con QR

**Código:** PRD-303
**Gerente de producto:** Felipe Arango
**Segmento:** Hogares
**Fecha de la definición:** 2025-10-08

## El problema

El segmento Hogares no tiene pago con qr.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-04-28 · verificado con la medición del piloto del 2026-07-24 (anexo «Verificación del supuesto» del 2026-07-24)

## Proyectos que lo construyen

- Ninguno declarado
