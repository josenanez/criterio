# Verificación del supuesto · Compra y recoge

**Fecha:** 2026-10-05

**Supuesto:** La demanda se sostiene sin descuento

**Con qué se verificó:** la medición del piloto del 2026-10-05. Este anexo es esa evidencia: recoge la verificación completa y no remite a otro documento.

**Resultado:** se confirmó.
