# Definición de producto · Bolsas reutilizables

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-25

## El problema

El segmento Personas no tiene bolsas reutilizables.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-09-03 · verificado con el documento técnico del proveedor del 2026-09-29 (anexo «Verificación del supuesto» del 2026-09-29)

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
