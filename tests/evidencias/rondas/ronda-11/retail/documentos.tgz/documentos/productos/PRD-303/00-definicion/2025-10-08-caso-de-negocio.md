# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2025-10-08
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 203.089 | Caso de negocio, 2025-10-08 |

## Retorno esperado

Retorno esperado en 24 meses.
