# Definición de producto · Marca propia

**Código:** PRD-304
**Gerente de producto:** María Restrepo
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-08-04

## El problema

El segmento Jóvenes no tiene marca propia.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-09-27 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
