# Tablero de métricas · Puntos de fidelización

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 310.136 | 2026-10-11 |
