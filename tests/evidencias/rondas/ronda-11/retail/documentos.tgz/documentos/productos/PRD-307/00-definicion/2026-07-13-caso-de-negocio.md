# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-07-13
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 182.611 | Caso de negocio, 2026-07-13 |

## Retorno esperado

Retorno esperado en 24 meses.
