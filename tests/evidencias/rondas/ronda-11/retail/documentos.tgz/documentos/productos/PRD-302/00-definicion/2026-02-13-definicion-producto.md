# Definición de producto · Autopago en tienda

**Código:** PRD-302
**Gerente de producto:** Diana Molina
**Segmento:** Empresas
**Fecha de la definición:** 2026-02-13

## El problema

El segmento Empresas no tiene autopago en tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-06-16 · verificado con el documento técnico del proveedor del 2026-07-19 (anexo «Verificación del supuesto» del 2026-07-19)

## Proyectos que lo construyen

- Ninguno declarado
