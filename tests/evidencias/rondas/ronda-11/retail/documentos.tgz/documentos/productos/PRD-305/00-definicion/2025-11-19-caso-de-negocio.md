# Caso de negocio · Entrega rápida

**Código:** PRD-305
**Fecha:** 2025-11-19
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 114.720 | Caso de negocio, 2025-11-19 |

## Retorno esperado

Retorno esperado en 24 meses.
