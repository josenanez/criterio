# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Sandra Gil
**Segmento:** Empresas
**Fecha de la definición:** 2026-04-04

## El problema

El segmento Empresas no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-04-24 · verificado con el concepto jurídico de cumplimiento del 2026-05-14 (anexo «Verificación del supuesto» del 2026-05-14)

## Proyectos que lo construyen

- Ninguno declarado
