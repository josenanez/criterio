# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2025-12-18
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 297.074 | Caso de negocio, 2025-12-18 |

## Retorno esperado

Retorno esperado en 24 meses.
