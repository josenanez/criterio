# Tablero de métricas · Pago con QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 206.918 | 2026-10-14 |
