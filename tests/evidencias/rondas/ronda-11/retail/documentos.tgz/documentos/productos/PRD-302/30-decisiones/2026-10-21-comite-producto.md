# Comité de producto · Autopago en tienda

**Fecha:** 2026-10-21
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4201 | Requerimiento REQ-4201 | Jorge Medina | se verifica en producción | — | aceptado | 2026-07-08 | — |
| REQ-4202 | Requerimiento REQ-4202 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4203 | Requerimiento REQ-4203 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-15 | — |
| REQ-4204 | Requerimiento REQ-4204 | sin asignar | se verifica en producción | — | aceptado | 2026-07-28 | — |
| REQ-4205 | Requerimiento REQ-4205 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-26 | — |
| REQ-4206 | Requerimiento REQ-4206 | sin asignar | se verifica en producción | — | aceptado | 2026-05-31 | — |
| REQ-4207 | Requerimiento REQ-4207 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-05-17 | — |
| REQ-4208 | Requerimiento REQ-4208 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-03-30 | — |
| REQ-4209 | Requerimiento REQ-4209 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-08 | — |
| REQ-4210 | Requerimiento REQ-4210 | Liliana Torres | — | — | aceptado | 2026-08-03 | — |
| REQ-4211 | Requerimiento REQ-4211 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4212 | Requerimiento REQ-4212 | Gustavo Neira | — | — | aceptado | 2026-07-31 | — |
| REQ-4213 | Requerimiento REQ-4213 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-09 | — |
| REQ-4214 | Requerimiento REQ-4214 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-03 | — |
| REQ-4215 | Requerimiento REQ-4215 | Laura Vélez | se verifica en producción | — | aceptado | 2026-03-29 | — |
| REQ-2037 | Requerimiento REQ-2037 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-09 | — |

## Decisiones

- Se mantiene el plan
