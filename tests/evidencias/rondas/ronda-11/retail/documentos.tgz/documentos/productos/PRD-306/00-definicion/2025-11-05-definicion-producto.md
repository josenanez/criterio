# Definición de producto · App de clientes

**Código:** PRD-306
**Gerente de producto:** Felipe Arango
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2025-11-05

## El problema

El segmento Pequeños negocios no tiene app de clientes.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-08-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
