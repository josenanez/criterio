# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2025-12-06
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 186.854 | Caso de negocio, 2025-12-06 |

## Retorno esperado

Retorno esperado en 24 meses.
