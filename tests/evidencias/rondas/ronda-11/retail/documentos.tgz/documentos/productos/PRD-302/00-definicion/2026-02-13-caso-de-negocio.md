# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-02-13
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 148.816 | Caso de negocio, 2026-02-13 |

## Retorno esperado

Retorno esperado en 24 meses.
