# Entrevistas · Marca propia

**Ronda:** Ronda · 2025-12-31
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-12-31

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
