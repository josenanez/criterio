# Entrevistas · Tarjeta de la tienda

**Ronda:** Ronda · 2026-02-07
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-02-07

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
