# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2025-11-05
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 274.549 | Caso de negocio, 2025-11-05 |

## Retorno esperado

Retorno esperado en 24 meses.
