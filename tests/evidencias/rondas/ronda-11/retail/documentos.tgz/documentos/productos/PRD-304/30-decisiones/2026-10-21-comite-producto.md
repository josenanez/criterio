# Comité de producto · Marca propia

**Fecha:** 2026-10-21
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Beatriz Cuéllar | se verifica en producción | — | propuesto | 2026-06-07 | — |
| REQ-4401 | Requerimiento REQ-4401 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-19 | — |
| REQ-4402 | Requerimiento REQ-4402 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-08-21 | — |
| REQ-4403 | Requerimiento REQ-4403 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4404 | Requerimiento REQ-4404 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4405 | Requerimiento REQ-4405 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4406 | Requerimiento REQ-4406 | Diana Molina | se verifica en producción | — | propuesto | 2026-08-13 | — |
| REQ-4407 | Requerimiento REQ-4407 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-05-06 | — |
| REQ-4408 | Requerimiento REQ-4408 | Elena Duarte | se verifica en producción | — | aceptado | 2026-04-04 | — |
| REQ-4409 | Requerimiento REQ-4409 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-28 | — |
| REQ-4410 | Requerimiento REQ-4410 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4411 | Requerimiento REQ-4411 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-06 | — |
| REQ-2033 | Requerimiento REQ-2033 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-10-14 | — |

## Decisiones

- Se mantiene el plan
