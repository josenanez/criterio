# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2026-08-04
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 180.423 | Caso de negocio, 2026-08-04 |

## Retorno esperado

Retorno esperado en 24 meses.
