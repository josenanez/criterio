# Tablero de métricas · Entrega rápida

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 72.974 | 2026-10-16 |
