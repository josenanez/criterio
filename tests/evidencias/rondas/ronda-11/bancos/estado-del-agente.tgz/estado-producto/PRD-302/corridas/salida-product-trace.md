## Trazabilidad — Crédito hipotecario digital (PRD-302) · al 2026-10-23
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Los términos vigentes (v1.2) quedaron aceptados a nombre de José Francisco Ñáñez, 2026-10-23.
Fichas leídas: las 13 del portafolio (`estado/records`, PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Los 13 requerimientos aceptados tienen el campo «Proyecto que lo ejecuta» vacío («—» en el acta del comité). Ninguno tiene proyecto, ni entregable.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4204 | Requerimiento REQ-4204 (Jorge Medina) | 2026-05-01 | no consta |
| REQ-4213 | Requerimiento REQ-4213 (Jorge Medina) | 2026-05-01 | no consta |
| REQ-4201 | Requerimiento REQ-4201 (Natalia Ospina) | 2026-05-07 | no consta |
| REQ-4211 | Requerimiento REQ-4211 (Natalia Ospina) | 2026-04-08 | no consta |
| REQ-4210 | Requerimiento REQ-4210 (Beatriz Cuéllar) | 2026-05-15 | no consta |
| REQ-4200 | Requerimiento REQ-4200 (María Restrepo) | 2026-05-24 | no consta |
| REQ-4206 | Requerimiento REQ-4206 (Liliana Torres) | 2026-05-24 | no consta |
| REQ-4202 | Requerimiento REQ-4202 (María Restrepo) | 2026-05-25 | no consta |
| REQ-4203 | Requerimiento REQ-4203 (Natalia Ospina) | 2026-06-03 | no consta |
| REQ-4215 | Requerimiento REQ-4215 (Camilo Beltrán) | 2026-06-06 | no consta |
| REQ-4209 | Requerimiento REQ-4209 (Andrés Lozano) | 2026-06-17 | no consta |
| REQ-4212 | Requerimiento REQ-4212 (Andrés Lozano) | 2026-07-08 | no consta |
| REQ-4205 | Requerimiento REQ-4205 (Óscar Ramírez) | 2026-08-10 | no consta |

Fuente de todos: `documentos/productos/PRD-302/30-decisiones/2026-10-22-comite-producto.docx`. El campo «por quién» está vacío en cada registro (`decision.who`), así que no se atribuye.
Hay que mirar con más atención REQ-4211 (198 días decidido sin proyecto) y REQ-4204 y REQ-4213 (175 días).

Los 3 requerimientos en estado *propuesto* (REQ-4207, REQ-4208, REQ-4214) no están decididos y no cuentan en esta brecha. Su problema es otro (llevan 92, 208 y 96 días sin decidirse) y es de `/criterio-product:product-requirements`.

### La traza no se confirma
Ninguna. No hay traza declarada que confirmar, porque ningún REQ nombra un proyecto. Tampoco hay desacuerdo entre registro y ficha: el registro no dice nada y las fichas tampoco.

### Lo que un proyecto construye y el registro no tiene
Ninguna de las 13 fichas dice ejecutar PRD-302 ni «crédito hipotecario digital».
- 9 nombran otro producto: PRY-199 (PRD-299), PRY-200 (crédito de consumo), PRY-201 (cuenta de ahorros), PRY-203 (APIs de datos), PRY-204 (tarjeta débito), PRY-206 (pagos QR), PRY-207 (cuenta PyME), PRY-209 (nómina empresarial), PRY-211 (recaudos).
- 4 no dicen qué producto ejecutan: PRY-202, PRY-205, PRY-208 y PRY-210. Ese campo vacío es un hallazgo del lado de esos proyectos. Aquí no se llena.
- PRY-208 (motor de decisión) y PRY-200 (originación digital) son los vecinos temáticos más cercanos. Ninguna ficha los une con PRD-302, y esa conexión no se infiere.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4200 | aceptado | comité 2026-05-24 | — | no | — |
| REQ-4201 | aceptado | comité 2026-05-07 | — | no | — |
| REQ-4202 | aceptado | comité 2026-05-25 | — | no | — |
| REQ-4203 | aceptado | comité 2026-06-03 | — | no | — |
| REQ-4204 | aceptado | comité 2026-05-01 | — | no | — |
| REQ-4205 | aceptado | comité 2026-08-10 | — | no | — |
| REQ-4206 | aceptado | comité 2026-05-24 | — | no | — |
| REQ-4209 | aceptado | comité 2026-06-17 | — | no | — |
| REQ-4210 | aceptado | comité 2026-05-15 | — | no | — |
| REQ-4211 | aceptado | comité 2026-04-08 | — | no | — |
| REQ-4212 | aceptado | comité 2026-07-08 | — | no | — |
| REQ-4213 | aceptado | comité 2026-05-01 | — | no | — |
| REQ-4215 | aceptado | comité 2026-06-06 | — | no | — |

La cadena se rompe en el segundo eslabón: la decisión está citada, pero no hay proyecto. Sin proyecto no hay entregables.

### Sin fichas a la vista
Se vieron las 13 fichas. No falta ninguna.

### Después
Los 13 decididos están listos para pasar a `/criterio-product:product-charter`, empezando por los más antiguos. Antes conviene resolver con quien corresponda a cuál de los 13 le falta criterio de aceptación o evidencia: REQ-4203, REQ-4204 y REQ-4209 no tienen criterio de aceptación; REQ-4202 y REQ-4213 no tienen evidencia. La evidencia de los demás es una sola entrevista de 2025-10-15, que no nombra el requerimiento y tiene 12 meses.
Para los 4 proyectos con el campo de producto vacío (PRY-202, PRY-205, PRY-208, PRY-210) la salida es una conversación con cada gerente de proyecto.
