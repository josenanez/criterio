> **Borrador.** Lo escribe el agente; lo cierra Elena Duarte, gerente del producto. Ningún documento dice quién aprueba qué se construye (`authority: not_found`), así que la firma de cierre está sin dueño confirmado. Es insumo de la revisión jurídica, no su sustituto.

# Especificación — Crédito hipotecario digital (PRD-302) · borrador del 2026-10-23

**Lo primero que hay que saber:** este borrador **no puede describir comportamiento**. Los 13 requerimientos aceptados llevan el título «Requerimiento REQ-42xx» y `need: not_found`. Ningún documento dice qué problema resuelve cada uno. Escribir qué hace el producto sería inventarlo, y no lo hago. Lo que sí entrega es el mapa de lo que falta decidir, con dueño.

## Qué problema resuelve
«El segmento Empresas no tiene crédito hipotecario digital» (definición, 2026-05-08, `documentos/productos/PRD-302/00-definicion/2026-05-08-definicion-producto.docx`). Eso es todo lo que la definición dice.
- **Criterio de éxito del producto: no está dicho en ninguna parte.**
- **Proyectos que lo construyen: «Ninguno declarado»** (misma definición).
- La única entrevista (2025-10-15, «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.») no nombra ni un requerimiento ni el segmento Empresas, y es anterior a la definición.

## Alcance
Se toma lo que sale del registro y del acta del comité del 2026-10-22 (`30-decisiones/2026-10-22-comite-producto.docx`). El comité solo registra «Se mantiene el plan».

### Entra (13 requerimientos en estado `aceptado`)
REQ-4200, 4201, 4202, 4203, 4204, 4205, 4206, 4209, 4210, 4211, 4212, 4213, 4215.
Entran como **lista**, sin sección de comportamiento: ver «Requerimientos aceptados que esta especificación no cubre».

### No entra
- **REQ-4207, REQ-4208, REQ-4214:** siguen en `propuesto`. Llevan 92, 208 y 96 días sin decisión (umbral: 60). Nadie decidió que se hacen. REQ-4214 además no tiene doliente.
- **Todo lo que ningún requerimiento nombre.** El registro no tiene requerimientos de seguridad, desempeño, atención al cliente, reportes ni migración. Eso no quiere decir que no hagan falta. Quiere decir que nadie los pidió por escrito.
- **Diseño, estimación, fechas y aprobación.** No son de este documento.

## Comportamiento
**Sin contenido.** Un requerimiento solo aporta título genérico, doliente, estado, fecha y la frase «se verifica en producción». Ninguno aporta el problema, así que no hay nada que redactar sin completar por mi cuenta lo que nadie decidió. Cuando cada doliente escriba su necesidad, esta sección se redacta, citando REQ por REQ.

## Criterios de aceptación
Prueba: dos personas, mirando lo construido, llegan a la misma respuesta. «Se verifica en producción» no la pasa. No dice qué se mide, contra qué valor, ni quién lo mide. Es una frase vacía: sirve igual para cualquier cosa.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-22) | REQ-4200, 4201, 4202, 4205, 4206, 4210, 4211, 4212, 4213, 4215 (10) | No definido: sin métrica, sin umbral, sin responsable | **No.** No es verificable todavía |
| **No hay criterio** | REQ-4203 (Natalia Ospina), REQ-4204 (Jorge Medina), REQ-4209 (Andrés Lozano) | — | **No.** Falta |

Lo único que la organización mide hoy de este producto es `volumen_mensual` (tablero, bodega de datos, corte 2026-10-13: 235.072). Ningún criterio se apoya en eso. Tampoco hay medición de tiempos, percentiles ni conversión. Cualquier criterio de ese tipo que se escriba va a necesitar que alguien empiece a medirlo, y eso es un hallazgo.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-06-02) | Declarado «se confirmó» el 2026-09-04, **sin dato citable**. El anexo dice ser la evidencia completa, pero no recoge ninguna cifra, prueba ni entrevista. Remite a un «documento técnico del proveedor» que no está en la carpeta. Un documento técnico de proveedor, además, no es la evidencia natural de que un segmento pague. Tampoco coincide la fecha: el supuesto se declara el 2026-06-02, casi un mes después de la definición del 2026-05-08. | Elena Duarte: aportar el documento o los datos, o retirar el «verificado» |
| «La entrevista del 2025-10-15 sostiene los 13 aceptados» (implícito en el registro, no declarado en ningún documento) | No. Es una sola entrevista de hace 12 meses (en el umbral de 12), sin nombre del entrevistado, que no nombra ningún requerimiento | Elena Duarte (realizó la ronda) |
| Volumen mensual esperado de 289.875 (caso de negocio, 2026-05-08) | El tablero mide 235.072 al 2026-10-13: brecha de 18,9 % (umbral 20 %, no lo cruza, pero está cerca). Las dos fuentes quedan a la vista; ninguna gana por defecto | Elena Duarte; no se dice qué cuenta ese «volumen» |

No agrego supuestos que nadie declaró. La definición no declara ningún otro.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Qué problema resuelve cada uno de los 13 requerimientos** (`need: not_found` en todos; títulos genéricos) | No se puede escribir ni comportamiento ni criterio; se construiría lo que cada quien entienda | Cada doliente: M. Restrepo (4200, 4202), N. Ospina (4201, 4203, 4211), J. Medina (4204, 4213), Ó. Ramírez (4205), L. Torres (4206), A. Lozano (4209, 4212), B. Cuéllar (4210), C. Beltrán (4215) |
| **Criterio de aceptación** ausente en REQ-4203, 4204, 4209, y vacío («se verifica en producción») en los otros 10 | Nadie podrá decir si quedó bien sin discutir | El doliente de cada uno, con Elena Duarte |
| **Quién pidió REQ-4202 y REQ-4213.** No tienen evidencia alguna y están aceptados | Se construye lo que nadie pidió | Elena Duarte; dolientes M. Restrepo y J. Medina |
| **Evidencia de los otros 11 aceptados:** la misma entrevista de 2025-10-15, que no los nombra | La demanda no está sustentada por requerimiento | Elena Duarte |
| **Documento de la decisión.** El acta del 2026-10-22 es la única fuente. No dice quién decidió (`who` vacío) y registra a Elena Duarte como única asistente. Las fechas «desde» (2026-04-08 a 2026-08-10) no tienen acta propia | Aceptados sin decisión documentada; no se puede reconstruir quién los aceptó | Comité de producto (según la configuración; ningún documento lo confirma) |
| **Criterio de éxito del producto:** no está dicho | No hay contra qué medir si el producto funcionó | Elena Duarte |
| **Casos borde:** no se pueden enumerar sin saber qué hace cada requerimiento (solicitud incompleta, abandono a medias, documento rechazado, caída del servicio, duplicados) | Cada caso lo decidirá quien programe | Doliente de cada REQ |
| **Lo que otro equipo tiene que hacer.** Ningún documento nombra a otro equipo. Tampoco hay proyecto ni ficha (`estado/` sin fichas), así que no puedo afirmar que no haya dependencias | Dependencias descubiertas durante la construcción | Elena Duarte, al abrir el acta de constitución |
| **Proyecto que ejecute los 13.** Todos con «—» en el acta | Decididos y nadie los construye. Más de 5 meses en el caso más antiguo (REQ-4211, 2026-04-08) | Elena Duarte / comité |
| **Brecha de volumen** 289.875 declarado contra 235.072 medido (18,9 %) | La cifra del caso de negocio puede estar sobrevaluada | Elena Duarte |

### Obligaciones normativas (barrido de primera línea, sin opinar sobre cumplimiento)
**País:** no está dicho en ningún documento. Sin país, no cito norma ninguna.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Crédito hipotecario (producto financiero) a personas jurídicas | no dicho | Reglas de crédito, información previa, reclamos y cobros: si aplican a empresas es un juicio jurídico | — | no tengo la norma a la vista |
| Recoge datos de la empresa y, necesariamente, de sus representantes y garantes (el registro no lo dice) | no dicho | Tratamiento de datos personales: autorización y finalidad | — | no tengo la norma a la vista |
| Garantía hipotecaria digital: firma y prueba del consentimiento | no dicho | Firma electrónica y evidencia de aceptación | — | no tengo la norma a la vista |
| Conservación de expedientes y trazabilidad | no dicho | Retención | — | no tengo la norma a la vista |
| Infraestructura y transferencia de datos a otro país | no dicho | Transferencia internacional | — | no tengo la norma a la vista |

Ningún requerimiento nombra una obligación, y ningún documento de la organización dice cómo se atiende ninguna. Dueño de cerrarlo: Elena Duarte con Jurídico (nombre no consta en ningún documento). Lo que quede sin resolver debería entrar al registro como restricción del requerimiento o como riesgo con doliente.

## Requerimientos aceptados que esta especificación no cubre
**Ninguno tiene sección de comportamiento.** La razón común: `need: not_found`. Los 13 aparecen por rastreo y no porque estén especificados.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Sin problema dicho. Doliente M. Restrepo. Criterio genérico |
| REQ-4201 | Requerimiento REQ-4201 | Sin problema dicho. Doliente N. Ospina. Criterio genérico |
| REQ-4202 | Requerimiento REQ-4202 | Sin problema dicho. **Sin evidencia de demanda.** Doliente M. Restrepo |
| REQ-4203 | Requerimiento REQ-4203 | Sin problema dicho. **Sin criterio.** Doliente N. Ospina |
| REQ-4204 | Requerimiento REQ-4204 | Sin problema dicho. **Sin criterio.** Doliente J. Medina |
| REQ-4205 | Requerimiento REQ-4205 | Sin problema dicho. Doliente Ó. Ramírez. Criterio genérico |
| REQ-4206 | Requerimiento REQ-4206 | Sin problema dicho. Doliente L. Torres. Criterio genérico |
| REQ-4209 | Requerimiento REQ-4209 | Sin problema dicho. **Sin criterio.** Doliente A. Lozano |
| REQ-4210 | Requerimiento REQ-4210 | Sin problema dicho. Doliente B. Cuéllar. Criterio genérico |
| REQ-4211 | Requerimiento REQ-4211 | Sin problema dicho. Doliente N. Ospina. Criterio genérico |
| REQ-4212 | Requerimiento REQ-4212 | Sin problema dicho. Doliente A. Lozano. Criterio genérico |
| REQ-4213 | Requerimiento REQ-4213 | Sin problema dicho. **Sin evidencia de demanda.** Doliente J. Medina. Criterio genérico |
| REQ-4215 | Requerimiento REQ-4215 | Sin problema dicho. Doliente C. Beltrán. Criterio genérico |

## Después
No ofrezco `/product-charter` todavía. El criterio de éxito del producto no existe, tres aceptados no tienen criterio, diez tienen uno que no se puede verificar y ninguno dice qué problema resuelve. El camino es: que cada doliente escriba su necesidad y su criterio, y volver a correr este comando.

---
**Pie.** Sale del registro `estado-producto/PRD-302/requirements/` (16 requerimientos; **13 aceptados cubiertos como lista, 0 con comportamiento especificado**; 3 propuestos fuera de alcance), contrastado con la definición y el caso de negocio (2026-05-08), la verificación de supuesto (2026-09-04), el tablero de métricas (2026-10-13) y el acta del comité (2026-10-22). Registro al 2026-10-23. Términos (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23, vigentes): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0. Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación de cada cita es de quien lo lea.
