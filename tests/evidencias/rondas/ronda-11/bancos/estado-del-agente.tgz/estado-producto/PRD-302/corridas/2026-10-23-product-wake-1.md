# Corrida del 2026-10-23 · product-wake

PRD-302 · 16 requerimientos · 22 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |

Primera revisión, sin corte previo: línea base. 16 REQ, 3 sin decidir (208/96/92 días), 13 aceptados sin traza, evidencia de 12 meses. No dije nada sobre trazas (sin fichas), criterio de éxito ni autoridad.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Crédito hipotecario digital (PRD-302) · 2026-10-23

Primera revisión del registro (`review` nunca se había corrido). No existía corte anterior, así que nada "cruzó un umbral desde" otra fecha: lo siguiente es la línea base, y a partir de este corte solo se reportará lo nuevo.

**Registro:** 16 requerimientos (13 aceptados, 3 propuestos). 11 con evidencia (84,6 %), 0 con traza a un proyecto.

### Lo que necesita decisión del comité
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4208 | 208 días (desde 2026-03-29) | Que alguien con facultad lo decida | Doliente: Carlos Peña. Quién decide: la configuración dice «Comité de producto», pero el cálculo la reporta como desconocida |
| Propuesto sin decidir | REQ-4214 | 96 días (desde 2026-07-19) | Asignar doliente y decidir | **Sin doliente** |
| Propuesto sin decidir | REQ-4207 | 92 días (desde 2026-07-23) | Decidir | Jorge Medina |
| Aceptado sin evidencia de demanda | REQ-4202, REQ-4213 | — | Evidencia o revisar la aceptación | María Restrepo, Jorge Medina |
| Aceptado sin criterio de aceptación | REQ-4203, REQ-4204, REQ-4209 | — | Escribir el criterio | Natalia Ospina, Jorge Medina, Andrés Lozano |

### Lo aceptado que nadie está construyendo
13 de 13 requerimientos aceptados no tienen proyecto asociado (`requirement_untraced`). Sin la carpeta de fichas de proyectos, no se puede decir si alguien los construye bajo otro nombre.

### Evidencia que envejeció
13 requerimientos se sustentan solo en la entrevista del 2025-10-15, que cumple 12 meses. Esa entrevista no nombra ningún requerimiento en concreto: la definición y los requerimientos se quedan sin sustento de demanda vigente hasta que haya descubrimiento nuevo.

### Negocio contra datos
Volumen mensual: el caso de negocio (2026-05-08) declara 289.875; el tablero (2026-10-13) mide 235.072. Brecha de 18,9 %, por debajo del umbral configurado de 20 %. No es hallazgo todavía, pero está a 1,1 puntos.

### Lo que no sé
- **Trazas:** sin carpeta de fichas, ninguna traza se da por confirmada.
- **Criterio de éxito** del producto: no está dicho en ninguna parte.
- **Autoridad de decisión:** configurada, pero no resuelta en el cálculo.
- No releí los documentos de la carpeta en esta corrida; trabajé sobre el estado ya construido hoy.

**Vuelvo el 2026-11-22.**
