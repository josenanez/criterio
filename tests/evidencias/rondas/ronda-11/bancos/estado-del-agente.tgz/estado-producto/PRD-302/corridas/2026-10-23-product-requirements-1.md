# Corrida del 2026-10-23 · product-requirements

PRD-302 · 16 requerimientos · 35 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 13 |
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |

REQ-4202 y REQ-4213 aceptados sin evidencia; 13 aceptados sin proyecto (no hay fichas); REQ-4208 sin decidir hace 208 días

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Registro — Crédito hipotecario digital (PRD-302) · al 2026-10-23
16 requerimientos · 13 decididos · 84.6% con evidencia · 0% con proyecto que lo ejecuta

Nota de alcance: no hay fichas de proyecto en `estado/` (la carpeta está vacía), así que ningún requerimiento puede confirmarse contra un proyecto. El 0% es «no hay ficha que lo confirme», no «se comprobó que nadie lo construye».

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4202 | Requerimiento REQ-4202 | aceptado el 2026-05-25 | María Restrepo |
| REQ-4213 | Requerimiento REQ-4213 | aceptado el 2026-05-01 | Jorge Medina |

Ninguno tiene una sola cita de quien lo pidió. Van primero.

### Decidido y nadie lo está construyendo
Los 13 aceptados, sin proyecto asociado ni ficha que lo confirme:
| REQ | Decidido el | Doliente |
|---|---|---|
| REQ-4211 | 2026-04-08 | Natalia Ospina |
| REQ-4204 | 2026-05-01 | Jorge Medina |
| REQ-4213 | 2026-05-01 | Jorge Medina |
| REQ-4201 | 2026-05-07 | Natalia Ospina |
| REQ-4210 | 2026-05-15 | Beatriz Cuéllar |
| REQ-4200 | 2026-05-24 | María Restrepo |
| REQ-4206 | 2026-05-24 | Liliana Torres |
| REQ-4202 | 2026-05-25 | María Restrepo |
| REQ-4203 | 2026-06-03 | Natalia Ospina |
| REQ-4215 | 2026-06-06 | Camilo Beltrán |
| REQ-4209 | 2026-06-17 | Andrés Lozano |
| REQ-4212 | 2026-07-08 | Andrés Lozano |
| REQ-4205 | 2026-08-10 | Óscar Ramírez |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4214 | Requerimiento REQ-4214 | Sin doliente (propuesto) |

Quién lo cerraría: Elena Duarte, gerente del producto, asignando a una persona.

### Sin criterio de aceptación
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4203 | Requerimiento REQ-4203 | aceptado | Natalia Ospina |
| REQ-4204 | Requerimiento REQ-4204 | aceptado | Jorge Medina |
| REQ-4209 | Requerimiento REQ-4209 | aceptado | Andrés Lozano |

Solo decididos. A los propuestos no se les exige.

### Decidido sin documento que lo respalde
No evaluado en esta corrida: el cálculo no trae esta señal. Sin ese dato no afirmo ni descarto el vacío.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4208 | Requerimiento REQ-4208 | 208 días (2026-03-29) | Comité de producto (según la configuración) |
| REQ-4214 | Requerimiento REQ-4214 | 96 días (2026-07-19) | Comité de producto |
| REQ-4207 | Requerimiento REQ-4207 | 92 días (2026-07-23) | Comité de producto |

El comité es mensual; en tres meses o más no se decidió ninguno de los tres. Se propone decidirlos (aceptar o descartar), no cerrarlos por viejos. El cálculo devolvió `authority: null` aunque la configuración dice «Comité de producto»; conviene confirmar que ese es el órgano con la facultad.

### Evidencia vieja
Toda la evidencia es la misma entrevista del 2025-10-15, de hace 12 meses (en el umbral). Esa entrevista, además, no nombra ningún requerimiento.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4200, 4201, 4203, 4204, 4205, 4206, 4209, 4210, 4211, 4212, 4215 | entrevista 2025-10-15 | 12 meses |
| REQ-4207, 4214 (propuestos; solo informativo) | entrevista 2025-10-15 | 12 meses |

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

Otros datos del cálculo: la definición declara un volumen mensual de 289 875 (caso de negocio, 2026-05-08) y el tablero del 2026-10-13 mide 235 072, una brecha de 18.9% (umbral 20%, no la cruza). El criterio de éxito de la definición no está dicho en ningún documento.
