## Listo — Crédito hipotecario digital (PRD-302)

**Lo que miré:** 6 documentos · 1 de descubrimiento (una ronda de entrevistas, 2025-10-15) · la definición del 2026-05-08 (`.docx`, leída) y su caso de negocio del mismo día · lo más reciente es el acta del comité de producto del 2026-10-22. Formatos que no pude leer: ninguno.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 d1497e5f9c2847335b0298b009db9431fb9b962cdbe4af601aa9c0a850851c0e (md) / 1972f5ac032ba1ef… (pdf)
**Respuestas tomadas por defecto (sesión sin interfaz):** carpeta `documentos/productos/PRD-302` (la del argumento) · gerente Elena Duarte (la que firma el caso de negocio y la definición) · quién decide: «Comité de producto» como propuesta, porque ningún documento lo dice · estado en `estado-producto/PRD-302` (hermana de la documentación, no la `estado/` de otro agente) · carpeta marcada con `_CRITERIO_PRODUCTO.txt`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Alguien necesita esto y hoy no lo tiene | Una entrevista: «Lo necesito y hoy no lo tengo.» (cliente sin nombre) · evidencia media | 2025-10-15 · **12 meses**, en el umbral de vencimiento |
| El segmento paga por esto (supuesto) | El anexo «Verificación del supuesto» dice «se confirmó» y remite a un documento técnico del proveedor | 2026-09-04 · el documento técnico **no está en la carpeta** y el anexo no recoge ningún dato |
| Volumen mensual de 289.875 | Solo el caso de negocio. Contra la serie medida (235.072, tablero de producto, corte 2026-10-13) la diferencia es **18.9 %**, declarado por encima | declarado 2026-05-08 · medido 2026-10-13 |

El 18.9 % queda por debajo del umbral de 20 %: el cálculo no lo levanta como alerta, pero va dicho. Los cortes están a cinco meses uno del otro.

### Lo que no está dicho en ninguna parte
- **Que quien respondió la entrevista sea del segmento Empresas.** El problema dice «el segmento Empresas»; la entrevista no dice quién es el cliente ni a qué segmento pertenece.
- **El criterio de éxito.** Ningún documento lo escribe.
- **La propuesta.** La definición dice «Propuesta principal» y nada más: no hay contenido.
- **El retorno esperado.** El caso de negocio dice «Retorno esperado en 24 meses» sin cifra, sin fuente y sin supuestos.
- **De dónde sale 289.875.** La fuente citada es el propio caso de negocio: no hay serie ni estudio detrás.
- **Quién decide qué se construye.** El comité del 2026-10-22 solo registra a Elena Duarte como asistente.
- **Qué proyecto construye algo de esto.** La definición dice «Ninguno declarado»; el acta pone «—» en los 16 requerimientos. Traza: 0 de 13 aceptados (0.0 %).
- **Un doliente para REQ-4214.** Aparece como «sin asignar».

### Supuestos sobre los que está escrita
Uno declarado: *«El segmento paga por esto»* (declarado 2026-06-02, marcado verificado 2026-09-04). Está marcado como verificado, pero lo que lo verifica no se puede leer: el anexo se presenta como la evidencia completa y contiene solo «se confirmó». Lo tomo como verificado según el documento, y lo señalo para que lo mires tú. Es además la única afirmación sobre disposición a pagar: la entrevista habla de necesidad, no de pago.

### El registro de requerimientos, con lo que dice el acta
16 requerimientos: 13 aceptados y 3 propuestos. 11 de los 13 aceptados tienen evidencia (84.6 %). Señales:
- **Evidencia vencida (12 meses): 13.** Toda la demanda sale de la misma entrevista del 2025-10-15, y el acta solo dice «Cliente entrevistado»: la entrevista no nombra ningún REQ. Citada tal cual.
- **Aceptados sin proyecto que los ejecute: 13.**
- **Aceptados sin criterio de aceptación: 3** (REQ-4203, REQ-4204, REQ-4209).
- **Aceptados sin nadie que los haya pedido: 2** (REQ-4202, REQ-4213).
- **Propuestos sin decisión: 3**, entre 92 y 208 días (REQ-4208 lleva 208).
- **Sin doliente: 1** (REQ-4214).
- Los 16 se llaman «Requerimiento REQ-42xx»: el acta no dice qué se pide en ninguno.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Material de descubrimiento posterior a octubre de 2025: hay una sola ronda y no identifica al entrevistado.
- El documento técnico del proveedor del 2026-09-04.
- La serie histórica de `volumen_mensual`: hay un solo punto medido.
- Una fuente para las cifras del caso de negocio y el retorno.
- La decisión del comité sobre cada requerimiento: «Se mantiene el plan» no dice cuál.

### Después
Cuando quieras, `/product-discovery` sobre la entrevista: ahí se ve qué temas hay y cuáles requerimientos tienen la cita de quien los pidió.
