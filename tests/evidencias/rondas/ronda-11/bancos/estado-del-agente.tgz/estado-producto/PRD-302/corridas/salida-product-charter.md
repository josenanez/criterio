# Acta de constitución — Crédito hipotecario digital (REQ-4200) · borrador del 2026-10-23
**Producto:** PRD-302 · Crédito hipotecario digital · **Requerimientos:** REQ-4200

*Términos: ya vigentes (versión 0.8.0), aceptados por José Francisco Ñáñez el 2026-10-23; no hizo falta pedirlos de nuevo.*

## Verificación previa (requirement-record)
| Condición | Resultado |
|---|---|
| Aceptado | Sí: estado «aceptado» desde 2026-05-24 (comité de producto 2026-10-22). **Pero** no consta quién lo decidió (`decision.who` vacío): el único asistente registrado es Elena Duarte. |
| Criterios de aceptación verificables | **Débil:** el único criterio es «se verifica en producción». Es un lugar, no un criterio medible. |
| Evidencia de demanda con cita | **Parcial:** la entrevista del 2025-10-15 («Lo necesito y hoy no lo tengo.») está citada como origen pero no nombra este requerimiento; la necesidad concreta queda «not_found». |
| Autoridad declarada | **No:** ningún documento dice quién decide qué se construye (producto.json, `identity.authority`). |

Falta autoridad, y los criterios y la demanda son insuficientes. Se sigue sin ellos, marcados como vacíos del acta (respuesta sugerida tomada: no se rellenan).

## Qué problema resuelve
«El segmento Empresas no tiene crédito hipotecario digital.» (documentos/productos/PRD-302/00-definicion/2026-05-08-definicion-producto.docx)

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No está dicho.** No hay métrica, umbral ni fecha. Vacío del acta. | 30-decisiones/2026-10-22-comite-producto.docx |

La definición tampoco declara un criterio de éxito del producto (`definition.success`: not_found).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 (el título es genérico; el comité no da otro) | Entrevista 2025-10-15, «Lo necesito y hoy no lo tengo.», que no nombra el requerimiento. Doliente: María Restrepo. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4201 a REQ-4215 | Los otros 15 requerimientos del registro | Este acta cubre solo REQ-4200, que es lo que se pidió. No se evaluó a ninguno de los otros; no es un juicio sobre ellos. Si deben ir en el mismo proyecto, se vuelve a correr el comando con sus códigos. |

## Gobierno
**Patrocinador:** no está dicho en ningún documento. · **Gerente propuesto:** ninguno; Elena Duarte es gerente de *producto* (definición, 2026-05-08), no hay evidencia de que lo sea del proyecto. · **Comité:** comité de producto (configuración y acta del 2026-10-22); la composición no consta, solo asistió Elena Duarte. · **Autoridad del gerente:** no está dicha.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-06-02) | Dice «se confirmó» (anexo 2026-09-04), apoyado en un documento técnico del proveedor del 2026-09-04 que **no está en la carpeta**; el anexo no recoge ningún dato. Verificación no comprobable. | Por asignar con el gerente del proyecto. |
| Volumen mensual: el caso de negocio declara 289.875 (2026-05-08) | El tablero mide 235.072 (corte 2026-10-13): −18,9 %, por debajo del umbral de 20 % de la configuración. No es hallazgo, pero conviene vigilarlo. | Por asignar. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito hipotecario: datos personales, consumidor financiero | No levantada: ningún documento de la carpeta cita obligaciones y en esta corrida no se hizo el barrido normativo. | — | Sin resolver; sin opinión sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad y decisor de la aceptación | El gerente del proyecto no sabrá qué puede decidir: escala todo o nada. | Comité de producto |
| Criterio de éxito medible | El cierre no se podrá juzgar meses después. | Elena Duarte / María Restrepo (doliente) |
| Demanda que nombre REQ-4200 | El proyecto se apoya en una cita genérica. | Elena Duarte |
| Patrocinador y gerente del proyecto | La ficha no tendría dueño. | Quien tenga autoridad para asignarlos |
| Documento técnico del proveedor (2026-09-04) | El supuesto de pago sigue sin comprobarse. | Elena Duarte |
| Proyecto que ejecuta (el acta dice «—») | No hay traza requerimiento → proyecto. | Gerente del proyecto |

---
**Esto es un borrador.** Lo firma quien tenga autoridad sobre el producto; hoy no consta quién es. **La ficha del proyecto no se creó:** se crea después de la firma.

**Qué sigue:** el gerente del proyecto, cuando se nombre, instala `criterio-project` y corre `/pm-setup`; al publicar su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
