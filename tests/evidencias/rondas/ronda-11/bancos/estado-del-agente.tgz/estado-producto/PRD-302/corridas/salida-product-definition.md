## Definición — Crédito hipotecario digital (PRD-302) · contrastada al 2026-10-23
**Documento:** `00-definicion/2026-05-08-definicion-producto.docx` (con `2026-05-08-caso-de-negocio.md` y `2026-09-04-verificacion-supuesto.md`) · **del** 2026-05-08 · 7 afirmaciones

Es una definición corta: casi todo lo que afirma está sin sustento o sin decir. Eso es lo que muestra el contraste, no un juicio sobre la calidad del producto.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que la definición afirma. Lo único que se acerca es la cifra de volumen, y queda por debajo del umbral (ver la sección siguiente).

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 289.875 | 235.072 | −18,9 % (medido por debajo de lo declarado) | Caso de negocio, 2026-05-08 · Tablero de métricas (bodega de datos), corte 2026-10-13 |

La diferencia de 18,9 % **no pasa el umbral de 20 %** de la configuración, así que se lee como imprecisión y no como contradicción. Está a 1,1 puntos del umbral. La serie medida tiene **un solo punto**, por lo que no se puede decir si la cifra sube o baja.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-05-08 | No trae cifra, solo el plazo. No hay nada que medir ni con qué contrastar. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara.
- **Quién decide qué se construye.** El comité del 2026-10-22 solo registra a Elena Duarte como asistente. La configuración nombra al «Comité de producto» como autoridad, pero ningún documento lo confirma.
- **Cuánto es el retorno esperado.** Hay plazo (24 meses) y no hay monto, ni la base de cálculo.
- **Qué es la «Propuesta principal».** Es el único contenido de la sección de propuesta.
- **Por qué *Empresas* y por qué *hipotecario*.** La única voz de cliente es genérica: «Lo necesito y hoy no lo tengo». No menciona segmento ni producto.
- **Cuánto pagaría el segmento.** El supuesto dice que paga y no dice cuánto.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado», y los 13 requerimientos aceptados tampoco tienen proyecto.
- **En qué país opera.** Ningún documento lo dice. Es lo que condiciona la sección normativa.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-06-02) | 0 sin verificar; el anexo del 2026-09-04 lo marca «se confirmó», 94 días después | Que el documento técnico del proveedor del 2026-09-04 entre a la carpeta. El anexo dice que recoge la verificación completa, pero solo dice «se confirmó» y no trae ningún dato. Además, un documento técnico de proveedor no muestra que alguien pague. Por la jerarquía de demanda, lo que lo sostendría es un cobro, un precio aceptado o un compromiso firmado del segmento. |

Se trata como verificado en el papel y **sin evidencia a la vista**. Además, el supuesto es del 2026-06-02 y la definición es del 2026-05-08: se declaró después de la definición que sostiene.

Una nota sobre el escrito: «el segmento paga por esto» se puede refutar con un precio y un cobro, así que se puede verificar. Falta que alguien lo haga.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Empresas no tiene crédito hipotecario digital» | Una cita de «Cliente entrevistado» en `10-descubrimiento/2025-10-15-entrevistas.md`: «Lo necesito y hoy no lo tengo.» | 2025-10-15 | Débil. Es una persona sin identificar que dijo que lo necesita (nivel «dijo», el más bajo). No dice a qué segmento pertenece ni de qué producto habla. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema y el segmento (arriba) | Entrevista del 2025-10-15, la única ronda que hay | 12 meses (373 días). Está en el umbral de 12 meses configurado. |

Ese mismo dato es el origen citado de 13 requerimientos, y el cálculo marca los 13 como con evidencia envejecida. La entrevista no nombra a ninguno de ellos. El detalle está en la corrida de requerimientos.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Recoge datos personales y financieros de solicitantes de crédito | sin país declarado | Autorización previa y finalidad declarada | — | no tengo la norma a la vista |
| Producto financiero: información previa, reclamos y cobros al consumidor financiero | sin país declarado | Obligaciones de quien atiende consumidor financiero | — | no tengo la norma a la vista |
| Retención y trazabilidad de la solicitud y del consentimiento | sin país declarado | Plazos de conservación | — | no tengo la norma a la vista |
| Firma y prueba del consentimiento al aceptar un crédito digital | sin país declarado | Validez de la firma electrónica | — | no tengo la norma a la vista |
| Si el dato corre en nube de otro país | sin país declarado | Transferencia internacional de datos | — | no tengo la norma a la vista |

No cito ninguna norma porque ningún documento dice el país y no tengo la norma a la vista. Esto nombra lo que toca y **no dice si el producto cumple**. Va a revisión jurídica y no la reemplaza. Lo primero que la revisión necesita es el país.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. **Sin él el producto no se puede cerrar**, porque el cierre se juzga contra él meses después.
- **Quién decide:** falta (ver arriba).
- **Problema:** está declarado, con sustento débil y envejecido.
- **Para quién:** declarado (Segmento Empresas), con el mismo sustento.

---
**Después:** hay un supuesto con la verificación sin respaldo y varias afirmaciones sin sustento. Si quieres, los convierto en riesgos con doliente (raid-taxonomy). `/product-charter` todavía no aplica, porque la definición no está cerrada.
