# Caso de negocio — Crédito hipotecario digital (PRD-302) · borrador del 2026-10-23
**Desde:** la definición de producto del 2026-05-08 y el caso de negocio del 2026-05-08 · **Cifras con fuente:** 1 de 1 (y esa una está en contradicción con la medida; ver más abajo)

Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-23. Documentos leídos: 6 (más 16 registros de requerimiento y la serie `volumen_mensual`).

## Qué problema resuelve, y para quién
«El segmento Empresas no tiene crédito hipotecario digital.» Segmento: Empresas. (Definición de producto, `00-definicion/2026-05-08-definicion-producto.docx`, 2026-05-08.)

## Qué se construye
Entran los 13 requerimientos en estado **aceptado** del acta del comité del 2026-10-22 (`30-decisiones/2026-10-22-comite-producto.docx`). Los 3 **propuestos** (REQ-4207, REQ-4208, REQ-4214) quedan fuera del caso hasta que alguien los decida.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4200, 4201, 4203, 4204, 4205, 4206, 4209, 4210, 4211, 4212, 4215 | aceptado | «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (entrevista del 2025-10-15, que no nombra ningún requerimiento) |
| REQ-4202, REQ-4213 | aceptado | **Ninguna.** El acta no dice quién lo pidió |

Sobre estos 13:
- Ninguno tiene proyecto que lo ejecute («—» en el acta), y la definición declara «Ninguno» como proyecto que lo construye.
- REQ-4203, REQ-4204 y REQ-4209 no tienen criterio de aceptación.
- Ningún documento dice quién decidió aceptarlos.
- La necesidad de cada uno está sin redactar (`need: not_found`).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 289.875 | Declarada | Caso de negocio, `00-definicion/2026-05-08-caso-de-negocio.md` (Elena Duarte) | 2026-05-08 |
| volumen_mensual | 235.072 | Medida | Bodega de datos, tablero de producto, `20-metricas/2026-10-13-tablero-metricas.md` | corte 2026-10-13 |
| «El segmento paga por esto» (supuesto) | — | Supuesta, con verificación declarada pero no sustentada | Definición, declarado el 2026-06-02 | ver Supuestos |
| «Retorno esperado en 24 meses» | sin valor | Sin cifra | Caso de negocio | 2026-05-08 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 289.875 | 235.072 | Declarada: caso de negocio, 2026-05-08. Medida: tablero de la bodega de datos, corte 2026-10-13. |

La diferencia es de 54.803, un 18,9 % por debajo de lo declarado. Queda **por debajo** del umbral configurado de 20 % (`claim_gap_pct`), así que no es hallazgo por umbral, pero el caso lo muestra igual. La serie medida tiene **un solo punto**, así que no dice si el volumen sube o baja. Tampoco hay documento que diga si «volumen_mensual» es una proyección para cuando el producto esté en operación o una medición de hoy. Sin eso no se sabe si la brecha es un error del caso o la etapa en que está el producto.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento: ni contrato, ni cotización, ni costo declarado del equipo |
| Costo de operar | **No hay** | Ningún documento |

Este es el primer vacío. Sin el costo de construir lo que hay es una propuesta, no un caso de negocio evaluable.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El segmento paga por esto» (declarado 2026-06-02) | No habría ingreso del segmento y el volumen declarado no tendría base. El caso entero depende de este supuesto. | Marcado «se confirmó» el 2026-09-04, pero el anexo remite al documento técnico del proveedor de esa fecha, **que no está en la carpeta**, y no recoge ningún dato. No hay verificación que se pueda leer. Hay que conseguir el documento del proveedor o hacer la verificación con datos. |
| El volumen mensual declarado (289.875) se alcanzará | Es la base de cualquier ingreso o retorno futuro; hoy la serie medida marca 235.072. | El negocio: declarar si es meta o línea actual. Datos: más cortes de la serie. |
| Que «Cliente entrevistado» representa al segmento Empresas | La demanda de los 11 requerimientos con esa evidencia descansa en una sola cita, de una persona. | Descubrimiento: más entrevistas, con requerimientos nombrados. |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | El negocio (Elena Duarte) con quien cotice o presupueste |
| El valor del «retorno esperado en 24 meses» y su método | El caso lo nombra sin cifra: no se puede verificar ni refutar | El negocio. **Este agente no lo calcula.** |
| Beneficio esperado (ingresos, ahorro) | Es lo que justifica el costo | El negocio |
| Qué pasa si no se hace | Sin esto el comité no puede comparar contra el estado actual | El negocio |
| Alternativas consideradas | Ninguna documentada | El negocio |
| Criterio de éxito (`success: not_found`) | El producto no se podrá cerrar meses después ni saber si funcionó | Elena Duarte y el comité |
| Fecha de corte y métrica con que se sabrá si funcionó | Ídem | Ídem |
| Documento técnico del proveedor (2026-09-04) | Es la única evidencia de que el segmento paga | Elena Duarte / proveedor |
| Quién decide qué se construye (`authority: not_found` en la carpeta; la configuración dice «Comité de producto») | Los 13 aceptados no tienen decisor registrado | El comité |
| Qué mide `volumen_mensual` (proyección o medición) y su serie histórica | Ver brecha de arriba | Bodega de datos / negocio |
| Proyecto que ejecute los 13 requerimientos aceptados | El caso aprueba algo que nadie construye | El comité |

## Cómo se sabrá si funcionó
**No está declarado.** El caso no trae criterio de éxito, métrica de éxito ni fecha de corte. Lo más cercano es «retorno esperado en 24 meses», que no tiene cifra ni métrica. Hasta que alguien lo declare, el producto no se puede cerrar con un resultado verificable.

## Si hay otros productos publicados
No hay ningún otro producto publicado a la vista (solo PRD-302 está configurado), así que no se pudo cruzar la métrica `volumen_mensual` con otros casos. El cruce queda pendiente hasta que haya más.

## Resumen para quien decide
- No se produjo ninguna cifra nueva: no hay ingresos, retorno ni periodo de recuperación calculados.
- No se recomienda aprobar ni rechazar. Decide el Comité de producto.
- Las 2 cifras que existen (289.875 declarada y 235.072 medida) están a 18,9 % una de otra.
- Faltan los costos, el beneficio, el criterio de éxito y la verificación legible del supuesto central.

**Después:** pasar los 3 supuestos de arriba a seguimiento con assumption-tracking. Si el caso se aprueba, `/criterio-product:product-charter`.
