**Sale de:** la ficha `estado/records/PRY-202.json` y los documentos de `documentos/proyectos/PRY-202-migración-a-la-nube/` (acta de constitución 2025-08-13, cronogramas v1 y v2, solicitud CC-01, informe de avance 2026-10-16, comité 2026-10-18). Cifras de `portafolio.py compute` al 2026-10-23. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no se volvió a registrar nada.

## Cierre — PRY-202 Migración a la nube — 2026-10-23

**Veredicto:** no hay base para cerrar por cumplimiento. El proyecto no ha terminado: su propio informe (2026-10-16) lo declara en **rojo, 41 %**, y el último hito (piloto) está planificado para 2026-11-22, posterior a hoy. Si se cierra, sería **por decisión**, no por cumplimiento, y esa decisión no está registrada en ningún documento.

### Contra lo comprometido
**Criterio de éxito:** «Migración a la nube en producción y medido.» (acta de constitución, 2025-08-13, sección «Criterio de éxito»)
**Se cumplió:** no se puede determinar; la evidencia disponible apunta a que no. Ningún documento muestra puesta en producción ni medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Alcance: «Componente 1; Componente 2; Componente 3» (acta) | No verificable: el acta no dice qué es cada componente | Ninguna |
| Hito: Diseño funcional aprobado (2025-11-27) | «cerrado» según cronograma v2 | Sin evidencia de cumplimiento (330 días desde la fecha) |
| Hito: Ambiente de pruebas certificado (2026-03-04) | «cerrado» según cronograma v2 | Sin evidencia (233 días) |
| Hito: Integración con el core (2026-06-09) | «cerrado» según cronograma v2 | Sin evidencia (136 días) |
| Hito: Piloto con usuarios internos (línea base 2026-09-14; vigente 2026-11-22) | «cerrado» según cronograma v2, con fecha futura | Sin evidencia; contradice el informe del mismo día (rojo, 41 %) |

El cronograma v2 declara los cuatro hitos cerrados y al 100 %; lo declarado en el informe de avance es 41 %. La brecha es de 59 puntos y ningún documento la explica.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Ningún recorte registrado | — | — |

No hay recorte de alcance. Hay lo contrario: CC-01 (2026-10-11, solicitante María Restrepo) pide una **ampliación de alcance**, con +69 días y 138.000.000 COP adicionales. Su autorización dice «Pendiente de presentación al comité»; no hay decisión.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-14 | 2026-11-22 | Sin fecha final: el proyecto no ha terminado | +69 días (17.8 %) |
| Presupuesto (COP) | 800.000.000 | 800.000.000 (CC-01 no aprobado) | Ejecutado 175.437.818 (21.9 %); comprometido 364.802.812 (45.6 %); proyección al cierre 881.586.671 | +10.2 % sobre lo aprobado (proyección) |

Desviación contra la vigente: 0 días (la vigente ya absorbe los 69). Replanificaciones: **1**, y es la v2 del 2026-10-16, publicada **sin autorización**: 69 días movidos, 0 autorizados, y CC-01 sigue pendiente. La línea base v2 no tiene motivo escrito.

Ejecutado, comprometido y proyección son lo declarado en el informe de avance (declaración, no evidencia contable). El script no calcula cómo se relaciona la proyección con los 138.000.000 COP de CC-01, así que no se afirma.

### RAID al cierre
**Materializados** (incidencias del informe del 2026-10-16, ninguna con responsable ni fecha de inicio):
- La prueba de carga no alcanzó el umbral pactado y se repite.
- El equipo perdió dos semanas por rotación de un desarrollador clave.
- Se levantó un hallazgo de seguridad en la revisión de arquitectura.
- Cronograma v2 con hitos «cerrados» y 100 % frente a informe en rojo y 41 %.
- Cronograma v2 con +69 días sin línea base aprobada (CC-01 pendiente).

**No materializados:** no se puede determinar; el informe los lista como abiertos, no como superados.

**Abiertos, con doliente:** **ninguno tiene doliente.** Los dos riesgos y las cinco incidencias no tienen responsable en ningún documento; por tanto no están cerrados:
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega. Sin responsable. (No hay proveedor registrado en la ficha.)
- Riesgo: concentración del conocimiento en una sola persona. Sin responsable.
- Compromisos del comité del 2026-10-18: Beatriz Cuéllar, «Entregar el punto 30», para 2026-10-29 (abierto; no asistió). Ricardo Salas, «Entregar el punto 28», **sin fecha** (no asistió). El acta no dice qué son los puntos 28 y 30.

### Lecciones
Solo entran las que se sostienen en un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v2 movió el piloto de 2026-09-14 a 2026-11-22 antes de que el comité decidiera CC-01 | CC-01: 2026-10-11; v2: 2026-10-16 | 69 días (17.8 %) de atraso sobre la línea base original, sin autorización | No publicar un cronograma con fechas nuevas hasta que el comité decida el cambio |
| Se marcaron cuatro hitos como «cerrados» y 100 % sin evidencia, el mismo día en que el informe decía rojo y 41 % | 2026-10-16 | No se puede saber qué se hizo; la brecha es de 59 puntos | Exigir evidencia de recibo para cerrar un hito |
| Rotación de un desarrollador clave (dos semanas perdidas) con un riesgo de concentración del conocimiento ya listado | Informe del 2026-10-16 | Dos semanas perdidas; el riesgo quedó sin responsable | Asignar responsable al riesgo cuando se registra |

No se escribe más: el resto de aprendizajes no se puede anclar a un hecho con fecha en la documentación.

### Sin dato
- Si hay migración en producción y si se midió (criterio de éxito).
- Qué son los Componentes 1, 2 y 3 y si se entregaron.
- Evidencia de cumplimiento de los tres primeros hitos y del piloto.
- Fecha real de término; no existe.
- Motivo de la línea base v2 y decisión del comité sobre CC-01.
- Responsables de todos los riesgos e incidencias; fecha de inicio de cada incidencia.
- Qué son los puntos 28 y 30 del comité; fecha del compromiso de Ricardo Salas.
- Fase del proyecto, autoridad y producto (campos vacíos en la ficha; el acta dice «No aplica» para producto).
- Los campos de identidad y plan de la ficha vienen del acta de hace 14 meses (2025-08-13) y no se han reconfirmado.

### Después
**Archivo:** no se mueve la carpeta ni se congela la ficha. El proyecto está en rojo, con 5 incidencias y 2 riesgos sin responsable, un cambio sin decidir y un criterio de éxito sin comprobar. Archivarlo lo sacaría del barrido diario justo cuando más se necesita. Si el comité decide cerrarlo por decisión, esa decisión se registra primero (quién, cuándo, por qué) y entonces se archiva.

### Pie de rigor
Borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado y la verificación es de quien lo lee. Lo que se habló fuera de los documentos no está aquí. Todas las cifras de avance, presupuesto y proyección son declaradas por la gerencia y el cierre no las contrasta contra contabilidad.
