# Corrida del 2026-10-23 · portfolio-report

13 proyectos · 77 documentos, 0 releídos y 77 sin cambio · 80 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

El informe quedó en `reportes/index.html`.

Primera corrida del informe: 4 verdes contradichos (PRY-203, 204, 206, 211), facturación de PRY-209 por encima de lo aceptado, rebaseline sin autorización en PRY-202, PRY-207 en silencio 20 días. Los 13 proyectos sin autoridad declarada.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-23

13 proyectos · 11 con hallazgos (71 señales) · fichas de `estado/records/` (PRY-199 a PRY-211) con fecha de barrido 2026-10-23, la misma de hoy, así que no hay fichas con más de una semana sin barrido. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

## Qué cambió desde 2026-10-23
Sin cambios desde la corrida anterior. La única instantánea previa es de hoy (`estado/snapshots/2026-10-23.json`) y el diff dio 0 cambios. No hay un delta histórico; esto es un punto de partida.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en `ambiguous` ni conflictos entre fuentes. Tampoco hay cambios de gobierno respecto de la corrida anterior.

## Hitos vencidos sin evidencia
Vacía en hitos vencidos sin marcar. Lo que sí hay son hitos **declarados cumplidos sin documento que los respalde** (ver "Sin sustento"): PRY-201 (4), PRY-202 (3), PRY-203 (2), PRY-204 (2), PRY-205 (4), PRY-206 (2), PRY-207 (3), PRY-209 (2), PRY-210 (4), PRY-211 (2).

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-207 Onboarding PyME | 20 (umbral 15) | 2026-10-03, informe de avance |

PRY-204 lleva 13 días sin movimiento: no cruza el umbral, pero su declaración de estado tiene 21 días de antigüedad.

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias entre proyectos.

## Sin sustento
Estados **verdes contradichos por la evidencia (4)**:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-203 Open Banking | verde, 31 % (2026-10-20) | Avance 36 puntos por debajo de lo que sostiene el plan; 2 hitos "cumplidos" sin evidencia |
| PRY-204 Débito contactless | verde, 20 % (2026-10-02) | 47 puntos por debajo del plan; 2 hitos sin evidencia; compromiso sin fecha |
| PRY-206 Billetera y QR | verde, 84 % (2026-10-20) | 4 compromisos vencidos, 3 reprogramados 4–6 veces, 2 hitos sin evidencia, 2 entregables de proveedor atrasados |
| PRY-211 Cobranza digital | verde, 36 % (2026-10-21) | 64 puntos por debajo del plan; 2 hitos sin evidencia |

Otros hallazgos de sustento:
- PRY-209 Nómina electrónica: Núcleo Financiero facturó COP 3.670.816.836 contra COP 2.720.905.022 aceptados, una diferencia de COP 949.911.814. Además, un entregable aceptado sin evidencia y dos atrasados (196 y 13 días).
- PRY-202 Migración a la nube: replanificación de 69 días sin autorización registrada (`rebaseline_unauthorized`).
- PRY-201 Core de depósitos: proyección de costo 17,2 % sobre lo aprobado y dos entregables de Redes del Norte atrasados (204 y 44 días).
- PRY-206: entregable de Integra Sistemas aceptado sin evidencia.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | `identity.authority` (quién tiene la facultad de aprobar) y `identity.phase` |
| Casi todos | Dolientes de riesgos e incidencias (`raid.*.owner`) |
| PRY-199, PRY-206 | Monto facturado de proveedor (`vendors[].invoiced`) |
| PRY-202, 205, 208, 210 | Producto asociado; no entran en la vista por producto |
| PRY-202, 205, 207, 208, 209 | Campos de identidad, plan y dinero con fuente de hace más de 12 meses (13 a 17 meses) |
| PRY-206 | Compromiso sin fecha: "Mandar el ajuste del presupuesto" (Laura Vélez, notas del 2026-10-23) |

Nota: PRY-205, 208, 210 y 211 tienen fecha final ya vencida (2026-04-25, 2026-05-21, 2026-09-12, 2026-09-20) y siguen declarando avance menor al 100 % o sin cierre.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Cajeros | verde 20 % | sin alertas | 0 d | 0 d | 0 |
| PRY-200 Originación digital | amarillo 55 % | 2 compromisos vencidos; avance sobre lo que sostiene el plan | +78 d (18,5 %) | 0 d | 1 |
| PRY-201 Core de depósitos | rojo 90 % | 4 hitos sin evidencia; costo +17,2 % | 0 d | 0 d | 0 |
| PRY-202 Migración a la nube | rojo 41 % | rebaseline sin autorización; costo +10,2 % | +69 d (17,8 %) | 0 d | 1 |
| PRY-203 Open Banking | verde 31 % | **contradicho** | 0 d | 0 d | 0 |
| PRY-204 Débito contactless | verde 20 % | **contradicho** | 0 d | 0 d | 0 |
| PRY-205 Prevención de lavado | rojo 56 % | 4 hitos sin evidencia; 1 compromiso vencido (12 d) | 0 d | 0 d | 0 |
| PRY-206 Billetera y QR | verde 84 % | **contradicho** (16 señales) | 0 d | 0 d | 0 |
| PRY-207 Onboarding PyME | amarillo 22 % | en silencio 20 d; 3 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-208 Motor de decisión | verde 63 % | sin alertas | 0 d | 0 d | 0 |
| PRY-209 Nómina electrónica | rojo 39 % | facturado sobre lo aceptado | 0 d | 0 d | 0 |
| PRY-210 Portal de proveedores | rojo 63 % | 4 hitos sin evidencia; 1 compromiso vencido (18 d) | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | verde 36 % | **contradicho** | 0 d | 0 d | 0 |

## Necesito que confirmes
Hoy es la corrida de partida del mes, así que toca la confirmación periódica (5 campos). Esta sesión no tiene interfaz, así que quedan como preguntas para la próxima sesión interactiva:
1. ¿Quién es la autoridad (`identity.authority`) de PRY-206 Billetera y QR?
2. ¿Quién es el doliente del riesgo principal de PRY-201 Core de depósitos?
3. ¿PRY-207 Onboarding PyME sigue activo, o su silencio de 20 días es un cierre no registrado?
4. ¿El cambio de fecha de 69 días de PRY-202 Migración a la nube fue aprobado por alguien? ¿Dónde consta?
5. ¿Los hitos "cumplidos" de PRY-205 tienen acta de aceptación? Su fecha final fue el 2026-04-25.

## Archivos del informe
Escritos en `reportes/` (26 páginas: índice, decisiones, una página por cada uno de los 13 proyectos, una por cada uno de los 9 productos, y los listados `proyectos.html` y `productos.html`):
- `reportes/index.html` — vista por campo con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión. Para el patrocinador y el comité del 2026-10-30.
- El PDF sale de imprimir el HTML.

---
Criterio Portfolio v0.8.0 · fichas aplicadas: 13 (PRY-199 a PRY-211), barrido 2026-10-23 · campos inciertos: ninguno marcado `ambiguous`; 13 proyectos sin autoridad declarada y 5 con campos de más de 12 meses · Términos v1.2: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
