# Corrida del 2026-10-23 · portfolio-wake

13 proyectos · 42 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Barrido: 77 documentos sin cambios, nada que recalcular. Confirmación: 5 campos preguntados (2 facturados de proveedor, quién firmó CC-01 de PRY-200, 2 riesgos sin dueño); sesión sin interfaz, sin respuesta. No sé si los facturados existen fuera de los documentos.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## 2026-10-23

**Revisé:** 77 documentos · 0 cambiaron · 0 proyectos recalculados. Sin peticiones pendientes. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

### Lo que cruzó un umbral
Nada. El barrido corrió y no había noticia.

### Peticiones atendidas
Ninguna.

### Preguntas
Confirmación mensual (primera corrida), cinco campos por importancia. Sesión sin interfaz: nadie las responde, quedan preguntadas hoy, sin respuesta.

1. **PRY-206** — facturado a la fecha de Talento Digital S.A.S. (CT-127). Fuente del contrato: `PRY-206-billetera-y-qr/00-gobierno/2026-04-21-contrato-ct-127.md` (2026-04-21). Dato actual: no encontrado.
2. **PRY-199** — facturado a la fecha de Consultora Andina S.A.S. (CT-199). Fuente: `PRY-199-renovación-de-cajeros-automáticos/00-gobierno/2026-06-15-contrato-ct-199.md` (2026-06-15). Dato actual: no encontrado.
3. **PRY-200** — quién firmó la aprobación de CC-01 (+78 días, +156.000.000 COP). Fuente: `PRY-200-originación-digital/20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md` (2026-10-15). El documento dice solo «el comité».
4. **PRY-199** — responsable del riesgo «Disponibilidad del equipo de seguridad para la revisión final». Fuente: informe de avance 2026-10-21. Dato actual: sin dueño.
5. **PRY-200** — responsable del mismo riesgo de seguridad. Fuente: informe de avance 2026-10-20. Dato actual: sin dueño.

**Vuelvo el 2026-10-24.**
