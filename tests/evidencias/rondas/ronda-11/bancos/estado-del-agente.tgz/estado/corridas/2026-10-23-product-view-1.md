# Corrida del 2026-10-23 · product-view

13 proyectos · 32 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Producto con un solo proyecto (PRY-207): sin sección de producto, solo lectura del proyecto. 5 alertas: silencio 20 días, avance 22% contra 75-100% del plan, 3 hitos cumplidos sin evidencia. 4 proyectos sin producto declarado (PRY-202, 205, 208, 210). No se sabe el área dueña de esos 4 ni qué se habló fuera de los documentos.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-23 — cuenta PyME

Sale de las fichas del portafolio en `estado`, recalculadas hoy (`compute`, 13 proyectos). Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23.

**La cuenta PyME tiene un solo proyecto (PRY-207, Onboarding PyME), así que la vista por producto no aporta nada aquí.** No armo sección de producto: no hay señales que sumar entre proyectos ni dependencias internas que cruzar. Lo que sigue es la lectura de ese proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| cuenta PyME | 1 (PRY-207) | 5 | 2027-01-13 (PRY-207) | COP 6.800.000.000 | COP 5.550.704.544 |

Dinero de PRY-207: ejecutado COP 1.525.989.422 (22,4 %), comprometido 81,6 % de lo aprobado, proyección COP 6.883.597.700 (1,2 % sobre lo aprobado). El proyecto trae las cuatro cifras.

**Lo que hay que ver en PRY-207**
- En silencio: 20 días desde el 2026-10-03, último informe de avance (umbral: 15).
- Avance declarado 22 % contra un plan que sustenta entre 75 % y 100 % (3 de 4 hitos cumplidos): 53 puntos de diferencia. Una de las dos cifras está mal y los documentos no dicen cuál.
- Tres hitos declarados como cumplidos sin evidencia: «Diseño funcional aprobado» (vencía 2025-12-17), «Ambiente de pruebas certificado» (2026-04-27) e «Integración con el core» (2026-09-05).
- Estado declarado: amarillo. Ninguna de estas tres señales aparece explicada en el informe.
- Faltan autoridad y fase, y los dueños de un riesgo y dos incidencias. Los campos de identidad y plan se leyeron de un documento del 2025-07-30 (15 meses).

**Dependencias internas:** ninguna, y no podría haberlas con un solo proyecto. Las dependencias de PRY-207 con otros productos no son parte de esta vista.

### Proyectos sin producto declarado
| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | no la da el cálculo |
| PRY-205 Prevención de lavado de activos | no la da el cálculo |
| PRY-208 Motor de decisión | no la da el cálculo |
| PRY-210 Portal de proveedores | no la da el cálculo |

Consecuencia: nadie puede responder por el conjunto al que sirven. Es un hallazgo de gobierno. Ninguno puede contarse en la vista de la cuenta PyME ni en la de otro producto, y no asumo que alguno sirva a la cuenta PyME.

Pie de rigor: borrador de trabajo con base en las fichas; la verificación contra los documentos citados es de la persona. No sé qué se habló fuera de los documentos.
