# Corrida del 2026-10-23 · document-index

13 proyectos · 11 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Índice sin cambios: 77 documentos iguales, nada que releer, sin citas rotas. No se leyó ningún documento.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-23: 77 documentos, 77 sin cambio, 0 por releer, 0 citas rotas. No hay nada que hacer.
