Sale de: las 13 fichas de `estado/records` (PRY-199 a PRY-211), sus 13 actas de constitución («Dependencias declaradas»), los informes de avance citados en cada ítem y las minutas de comité de `30-reuniones` (PRY-199, 200, 201, 202, 204, 205, 206, 210) más `PRY-206/2026-10-23-notas-reunion.txt`. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-23.

## RAID — Portafolio al 2026-10-23
7 riesgos · 0 supuestos · 21 incidencias · 13 dependencias (41 ítems, tras reclasificar; 1 hecho más que no es RAID)
41 sin doliente · 41 sin fecha · sin movimiento: no medible (solo hay una corrida) · 1 no registrado formalmente

Los ítems no traen identificador en la ficha. Los de abajo (`199-D1`, `202-I3`…) son rótulos míos para poder referirlos: proyecto, tipo y orden. No existen en ningún documento. Probabilidad e impacto no están declarados en ningún ítem y no los inferí.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 203-D1, 207-D1, 209-D2 + 203-I2, 208-I1, 211-I1 | Dependencia + incidencia | Calendario de liberaciones del core; en tres proyectos ya costó historias fuera del sprint | no encontrado | no declarada | Afecta a seis proyectos. Ninguna acta declara dependencia ni dice de qué proyecto es el «core». Decisión: que el comité diga quién es la contraparte y confirme fechas |
| 202-I5 + 202-I4 | Incidencia | El cronograma v2 (2026-10-16) corre el piloto +69 días (2026-09-14 → 2026-11-22) y declara los hitos cerrados al 100 %, pero CC-01 está «pendiente de presentación al comité» y el informe del mismo día dice rojo y 41 % | no encontrado | no declarada | La línea base v2 no está aprobada. Decisión: aprobar o rechazar CC-01 y qué cronograma rige |
| 205-I2 | Incidencia | El cronograma da «Salida a producción» por cerrada (2026-04-25); el informe del 2026-10-21 dice rojo y 56 %; el acta de «Integración con el core» es del 2026-10-15, diez meses después de la fecha vigente (2025-12-18) | no encontrado | no declarada | El plan no refleja la realidad que reporta el propio proyecto |
| 202-I3, 203-I1, 205-I1, 208-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura, en cuatro proyectos | no encontrado | no declarada | Mismo hallazgo en cuatro lugares. No sé si es el mismo. Si lo es, es de seguridad y no de cada proyecto |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» — nadie lo anotó como riesgo (`206-R2`) | Riesgo | `PRY-206-billetera-y-qr/2026-10-23-notas-reunion.txt` | 2026-10-23 |

Las minutas de comité de PRY-199, 200, 201, 202, 204, 205 y 210 solo traen compromisos: ningún riesgo dicho al pasar. En PRY-206 reviso el resto de sus seis comités por palabras de riesgo y no hay ninguna. PRY-203, 207, 208, 209 y 211 no tienen minuta en la carpeta, así que de ellos no puedo decir nada.

### Sin doliente o sin fecha
Los 41 ítems no tienen doliente ni fecha de inicio (ver el registro completo). No los rellené ni propongo un doliente aquí. Que el gerente de cada proyecto los asigne.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| 203-D1, 207-D1, 209-D2 | «el core» (sin código de proyecto) | No: declarada por el proyecto, sin confirmación de la contraparte | No puedo cruzar. Si fuera PRY-201 Core de depósitos, está en rojo (90 %) con salida a producción el 2026-10-30, sin cambio de fecha registrado. Es una hipótesis mía, no un dato |
| 199-D1, 200-D1, 201-D1, 209-D1 | Equipo de seguridad (área, no proyecto) | No | Ningún documento dice que haya respondido |
| 200-D2, 202-D1, 204-D1, 205-D1, 206-D1, 208-D1 | Proveedor (en la ficha: «no ha confirmado la fecha de la última entrega») | No | Seis proyectos con la misma frase. No sé si es el mismo proveedor |

Las 13 actas dicen «Ninguna declarada» en Dependencias declaradas. Las 13 dependencias de este registro salen de informes de avance, que las llamaron riesgos o las citaron de pasada.

### Reclasificados
- Pasan de riesgo a dependencia (13): dependen de alguien fuera del proyecto. Calendario del core (203, 207, 209), fecha de entrega del proveedor (200, 202, 204, 205, 206, 208) y disponibilidad del equipo de seguridad (199, 200, 201, 209). Esta última también podría ser un supuesto. La dejo como dependencia porque es un área ajena, y el gerente puede cambiarla.
- Sale del registro (1): «Se ajustó el plan de pruebas con el área de seguridad» (PRY-210, informe 2026-10-19). Es algo ya hecho y no dice qué daño causa. No es incidencia ni riesgo.
- Sigue como incidencia, pero es un hallazgo sobre la evidencia y no un hecho del proyecto (5): 199-I1, 202-I4, 202-I5, 205-I2, 211-I2 (el informe de PRY-211 reporta ejecutado 2.803.145.619 mayor que comprometido 2.225.619.522).

### Registro completo
Prob. e Impacto: «no declarada» en todos. Doliente: «no encontrado» en todos. Fecha: «no declarada» en todos. «Último movimiento»: fecha del documento de donde sale; no hay historial previo.

| Id | Tipo | Qué | Último movimiento |
|---|---|---|---|
| 199-D1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-21 |
| 199-I1 | Incidencia | El informe dice «se reprogramó la salida por ventana de cambio» pero el cronograma v1, único, sigue en 2027-12-22 | 2026-10-21 |
| 200-D1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-20 |
| 200-D2 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-20 |
| 200-I1 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-20 |
| 201-D1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-21 |
| 202-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-16 |
| 202-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-16 |
| 202-I1 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-16 |
| 202-I2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-16 |
| 202-I3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | 2026-10-16 |
| 202-I4 | Incidencia | Cronograma v2 con hitos «cerrado» al 100 % y piloto movido a 2026-11-22; el informe del mismo día dice rojo y 41 % | 2026-10-16 |
| 202-I5 | Incidencia | El cronograma v2 recoge +69 días, pero CC-01 está pendiente de comité: no hay línea base v2 aprobada | 2026-10-11 |
| 203-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-20 |
| 203-D1 | Dependencia | Calendario de liberaciones del core | 2026-10-20 |
| 203-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | 2026-10-20 |
| 203-I2 | Incidencia | Dos historias fuera del alcance del sprint por dependencia con el core | 2026-10-20 |
| 203-I3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-20 |
| 204-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-02 |
| 204-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-02 |
| 205-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-21 |
| 205-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | 2026-10-21 |
| 205-I2 | Incidencia | «Salida a producción» cerrada en el cronograma frente a rojo y 56 % en el informe; acta de «Integración con el core» diez meses tarde | 2026-10-15 |
| 206-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-20 |
| 206-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-20 |
| 206-R2 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (no registrado formalmente) | 2026-10-23 |
| 206-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-20 |
| 207-D1 | Dependencia | Calendario de liberaciones del core | 2026-10-03 |
| 207-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 2026-10-03 |
| 207-I2 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-03 |
| 208-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-23 |
| 208-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-23 |
| 208-I1 | Incidencia | Dos historias fuera del alcance del sprint por dependencia con el core | 2026-10-23 |
| 208-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | 2026-10-23 |
| 209-D1 | Dependencia | Disponibilidad del equipo de seguridad para la revisión final | 2026-10-19 |
| 209-D2 | Dependencia | Calendario de liberaciones del core | 2026-10-19 |
| 209-I1 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 2026-10-19 |
| 210-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | 2026-10-19 |
| 211-R1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-21 |
| 211-I1 | Incidencia | Dos historias fuera del alcance del sprint por dependencia con el core | 2026-10-21 |
| 211-I2 | Incidencia | El informe reporta ejecutado mayor que comprometido | 2026-10-21 |

### Lo que no sé
- Quién es el doliente de cualquier ítem, y desde cuándo está abierto cada uno: ningún documento lo dice.
- Si «el core», «el proveedor» y «el hallazgo de seguridad» son uno solo o varios. Las frases se repiten palabra por palabra entre proyectos, lo que puede ser el mismo hecho o texto de plantilla.
- Si algo lleva dos períodos sin moverse: hay una sola corrida y ninguna fecha de apertura.
- Supuestos: no hay ninguno registrado ni dicho en reuniones. No inventé ninguno.

## Después
Puedo subir a comité los cuatro grupos de «Necesitan decisión ahora», que cumplen el criterio de escalamiento (afectan a otros proyectos o dependen de una aprobación pendiente). También puedo proponer un doliente para cada ítem sin él. Propongo, no asigno. ¿Cuál de las dos hago primero?

---
Rigor: cada ítem sale de la ficha y de su informe de avance; la reclasificación y los rótulos son míos y están marcados. No hay riesgos inventados. Lo que ningún documento dice queda dicho arriba.
