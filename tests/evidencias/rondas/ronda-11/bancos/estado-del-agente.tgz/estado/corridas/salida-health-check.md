## Diagnóstico · PRY-202 Migración a la nube · 2026-10-23

**Leí:** 6 documentos · del 2025-08-13 al 2026-10-18 · formatos: docx, xlsx, xml (MS Project), md, pdf
**No pude leer:** ninguno. Busqué «PRY-202» y «migración a la nube» en las demás carpetas de proyectos y de productos: ningún otro documento lo menciona. El PDF del informe lo contrasté contra el original, no solo contra el caché.

*Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23, comprobante ya registrado).*

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 14 · **Contradicho:** 3

Desde esta carpeta se puede afirmar quién es el patrocinador, quién gerencia, cuánto se aprobó, y que el proyecto declara estar en rojo con una desviación de +69 días (17.8 % sobre la línea base original) y una proyección 10.2 % sobre el presupuesto. No se puede afirmar el avance real: el informe dice 41 % y el cronograma publicado el mismo día dice que los cuatro hitos están cerrados al 100 %. Tampoco hay evidencia de recibo de ningún hito ni respaldo de ninguna cifra de dinero; todo lo que hay es declaración del gerente. La línea base v2 existe como archivo, pero el cambio que la justifica no ha sido presentado al comité.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Sandra Gil | acta de constitución, 2025-08-13 |
| Gerente | María Restrepo | acta de constitución, 2025-08-13 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente. Sin ella no hay desviación aprobada: hay fechas que alguien escribió. | acta de constitución, 2025-08-13 |
| Comité | Comité de Banca Empresas (aprobó 800.000.000 COP el 2025-08-13). Única minuta: 2026-10-18, asisten María Restrepo y Sandra Gil. | acta, 2025-08-13; comité semanal, 2026-10-18 |

Además: el acta no declara dependencias («Ninguna declarada»), el criterio de éxito («en producción y medido») no trae umbral medible, y el alcance es «Componente 1, 2, 3» sin descripción. Los campos de identidad vienen del acta, con 14 meses de antigüedad.

### Contra el plan
- **Línea base original (v1, 2025-08-13):** cierre 2026-09-14; piloto con usuarios internos 2026-09-14. Fuente: `cronograma-v1.xlsx`, acta.
- **Cronograma v2 (2026-10-16):** piloto movido a 2026-11-22. Desviación contra la original: **69 días (17.8 %)**, por encima del umbral de 10 %. Contra la vigente: 0 días, porque la vigente es la que se movió. Fuente: `cronograma-v2.xml`.
- **Replanificaciones:** 1. Motivo escrito en la v2: no figura. La solicitud CC-01 (2026-10-11, María Restrepo: ampliación de alcance, +69 días, +138.000.000 COP) dice «Pendiente de presentación al comité».
- **Resultado:** los 69 días movidos tienen 0 días autorizados. La v2 no es una línea base aprobada; es un archivo.
- **Avance vs plan:** declarado 41 %; el plan publicado sostiene 100 % (4 de 4 hitos cerrados). Brecha: 59 puntos.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2025-11-27 | 330 | Acta de recibo del diseño funcional aprobado |
| Ambiente de pruebas certificado | 2026-03-04 | 233 | Acta de recibo del ambiente certificado |
| Integración con el core | 2026-06-09 | 136 | Acta de recibo de la integración |

Los tres están «cerrado» en el cronograma y no hay ninguna acta de recibo en la carpeta (otros proyectos del portafolio sí las tienen). El cuarto, **Piloto con usuarios internos**, figura «cerrado»/100 % con fecha vigente 2026-11-22, posterior a hoy; no puede estar cerrado con una fecha que no ha llegado.

### Dinero
Todo salvo el aprobado es declaración del informe del 2026-10-16; no hay factura, contrato ni libro que lo respalde, y no hay proveedor registrado.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 COP | 364.802.812 (45.6 %) | 175.437.818 (21.9 %) | 881.586.671 (10.2 % sobre lo aprobado) | 435.197.188 |

Por encima del umbral de 10 % de costo. El presupuesto aprobado no cambió; los 138.000.000 COP de CC-01 no están aprobados y no están en el aprobado. No calculo el total «con CC-01»: nadie lo ha aprobado.

### Lo que se dijo y nadie registró
- **Compromiso de Beatriz Cuéllar:** «Entregar el punto 30», para 2026-10-29. Abierto. No asistió al comité del 2026-10-18 y no figura en el acta. No sé a qué se refiere «el punto 30».
- **Compromiso de Ricardo Salas:** «Entregar el punto 28», fecha «por definir». Sin fecha, no puede vencer ni cumplirse. Tampoco asistió.
- **Riesgos del informe sin registro ni dueño:** el proveedor no ha confirmado la fecha de la última entrega (hay una dependencia con un proveedor que el acta no declara y de la que no hay contrato en la carpeta); concentración del conocimiento en una persona.
- **Incidencias del informe sin dueño ni fecha de inicio:** la prueba de carga no alcanzó el umbral y se repite; dos semanas perdidas por rotación de un desarrollador clave; hallazgo de seguridad en la revisión de arquitectura.
- **La minuta del 2026-10-18 no trata** el estado rojo, CC-01, la prueba de carga ni el hallazgo de seguridad. Solo dice «Avance» y «Compromisos».

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance del proyecto | Informe 2026-10-16: 41 %, rojo | Cronograma v2 2026-10-16: 4 de 4 hitos cerrados al 100 % |
| Piloto con usuarios internos cerrado | Cronograma v2: «cerrado», 100 %, fecha 2026-11-22 (futura) | Informe: prueba de carga se repite, hallazgo de seguridad abierto, rojo |
| La línea base vigente es la v2 (cierre 2026-11-22) | Cronograma v2, fechado 2026-10-16 | CC-01 (2026-10-11): «Pendiente de presentación al comité» |

### Sin sustento
Lo que nada contradice y nada respalda (14):
1. a 3. Los tres hitos cerrados (diseño funcional, ambiente de pruebas, integración con el core): sin acta de recibo.
4. a 6. Comprometido, ejecutado y proyección al cierre: solo las dice el informe.
7. Los 138.000.000 COP adicionales de CC-01: sin desglose.
8. y 9. Los dos riesgos abiertos del informe.
10. a 12. Las tres incidencias del informe.
13. y 14. Los compromisos de Beatriz Cuéllar y Ricardo Salas: los dueños no estuvieron en la sala ni los confirmaron en ningún documento.

Sostenidas (4), para que el conteo cuadre: patrocinador, gerente y comité (acta); presupuesto aprobado de 800.000.000 COP (acta, con comité y fecha); el +69 días de CC-01 coincide con el movimiento del piloto entre v1 y v2; el estado rojo coincide con las señales de tiempo y costo.

### Lo que esta carpeta no permite saber
- **Si el proyecto avanzó 41 % o más:** no hay actas de recibo ni entregables. Consecuencia: el comité no puede decidir sobre CC-01 con un avance que dos documentos del mismo día cuentan distinto.
- **Quién autorizó mover el piloto:** el acta no declara la autoridad del gerente y CC-01 no está decidida. Consecuencia: los 69 días no están aprobados.
- **Cuánto se ha gastado de verdad:** ninguna cifra tiene factura ni contrato. Consecuencia: la proyección de 881.586.671 COP no se puede contrastar y no se sabe si el sobrecosto ya ocurrió.
- **Quién es el proveedor y qué debe entregar:** no hay contrato en la carpeta. Consecuencia: el riesgo de la fecha de la última entrega no se puede valorar.
- **Qué son los puntos 28 y 30:** consecuencia: dos compromisos que nadie puede dar por cumplidos.
- **Quién es dueño de cada riesgo e incidencia:** ninguno tiene dueño. Consecuencia: nadie responde por la prueba de carga ni por el hallazgo de seguridad.
- **Qué pasó entre las dos únicas fechas de seguimiento (2026-10-11 y 2026-10-16/18):** no hay historia previa de informes ni de minutas; hay una sola de cada una. Consecuencia: no se puede ver el momento en que dejó de sostenerse lo reportado.

**Siguiente paso posible:** preparo el punto de comité con esta lista de faltantes, o llevo las tres contradicciones a la gerente como preguntas, una por una. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

---
*Pie de rigor: 6 documentos leídos; cada dato viene del documento citado y la verificación es de quien lo lea. Las cifras derivadas (69 días, 17.8 %, 10.2 %, 45.6 %, 21.9 %, 59 puntos, 435.197.188) salen del cálculo del script `compute` del 2026-10-23. Lo declarado por el gerente no se tomó como prueba. Decisiones: de quien tiene la facultad.*
