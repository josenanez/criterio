*Ficha: `estado/records/PRY-207.json`, actualizada el 2026-10-23. Cifras de `portafolio.py compute` con corte 2026-10-23.*

## PRY-207 · Onboarding PyME — estado al 2026-10-23

**Declara el gerente (Javier Hoyos):** amarillo · 22% · al 2026-10-03 (declaración de hace 20 días, dentro del umbral de 30)
**Sustento documental:** sin sustento. Hay 0 datos con fuente de evidencia; los 5 marcados como declaración vienen del mismo informe de avance.
**Lo que el semáforo no explica:**
- `silent`: 20 días sin documentos (umbral 15).
- `progress_vs_plan`: el gerente declara 22% y el plan, con 3 de 4 hitos marcados como cumplidos, sostiene entre 75% y 100%. Diferencia: 53 puntos. El avance declarado está por debajo del plan; los dos números no pueden ser ciertos a la vez.
- `milestone_met_without_evidence`: 3 hitos «cumplidos» sin evidencia de cumplimiento.

**Último documento:** 2026-10-03 (informe de avance) · **Última reunión:** sin dato (no hay actas ni transcripciones en la carpeta)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-13 | 2027-01-13 | 0 días (0 contra la original, 0 contra la vigente) |
| Presupuesto (COP) | 6.800.000.000 aprobado | 6.883.597.700 proyección al cierre | +1,2% de la proyección sobre lo aprobado |

Replanificaciones: 0. La línea base es la v1, aprobada el 2025-07-30 por el Comité de Riesgos.

Presupuesto declarado al 2026-10-03: comprometido 5.550.704.544 (81,6%), ejecutado 1.525.989.422 (22,4%), disponible real 1.249.295.456. Los tres montos y la proyección son declaración del gerente, no evidencia.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-12-17 | 2025-12-17 | cumplido (según el cronograma) | ninguna; 310 días desde la fecha |
| Ambiente de pruebas certificado | 2026-04-27 | 2026-04-27 | cumplido (según el cronograma) | ninguna; 179 días desde la fecha |
| Integración con el core | 2026-09-05 | 2026-09-05 | cumplido (según el cronograma) | ninguna; 48 días desde la fecha |
| Piloto con usuarios internos | 2027-01-13 | 2027-01-13 | pendiente | no aplica |

El estado «cumplido» sale del cronograma v1 fechado el 2025-07-30. Un documento de hace 15 meses no puede acreditar hitos que vencían después de esa fecha, así que no cuenta como evidencia.

### Dónde no coincide
- El informe del 2026-10-03 dice 22% y amarillo. El cronograma v1 (2025-07-30) marca 3 de 4 hitos como cumplidos, lo que sostiene entre 75% y 100%. Ninguna de las dos fuentes lleva evidencia de cumplimiento. No sé cuál es la correcta; hay que preguntárselo al gerente.
- El informe cuenta que la prueba de carga no alcanzó el umbral y que el equipo perdió dos semanas, pero la fecha de cierre no se movió y no hay replanificación ni solicitud de cambio. Con «Ambiente de pruebas certificado» marcado como cumplido desde abril, una prueba de carga fallida entra en tensión con ese hito.

### Abierto
**Riesgos e incidencias sin movimiento** (todas del informe del 2026-10-03, sin dueño ni fecha de inicio):
- Riesgo: dependencia del calendario de liberaciones del core.
- Incidencia: pérdida de dos semanas por rotación de un desarrollador clave.
- Incidencia: la prueba de carga no alcanzó el umbral pactado y se repite.

Los días sin movimiento no se pueden calcular: ninguno tiene fecha de inicio.
**Compromisos vencidos:** ninguno registrado. No hay actas, así que tampoco se puede decir que no existan.
**Dependencias sin confirmar:** ninguna registrada en la ficha. El riesgo sobre las liberaciones del core sugiere una dependencia que no está declarada como tal.

### Sin dato
- `identity.authority`: nadie figura como autoridad del proyecto, y eso importa para saber a quién escalar.
- `identity.phase`.
- Dueño de los 3 elementos RAID.
- Fecha de inicio de las 2 incidencias.
- Última reunión.
- Evidencia de cumplimiento de los hitos.
- Antigüedad de los datos de identidad, plan y presupuesto aprobado: todos vienen del acta y del cronograma del 2025-07-30, con 15 meses, por encima del umbral de 12.

### Después
La desviación de plazo y de costo está por debajo del umbral del 10%, pero hay tres señales sin explicar, un hito de piloto a 82 días del cierre y ningún riesgo con dueño. Puedo preparar el punto de comité (el próximo es el 2026-10-30). No hay un cambio no formalizado que justifique una solicitud de cambio.

---
*criterio-portfolio 0.8.0 · ficha PRY-207 del 2026-10-23 · campos inciertos: authority, phase, dueños RAID, evidencia de hitos · términos v1.2 aceptados el 2026-10-23 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
