# Corrida del 2026-10-23 · project-charter

13 proyectos · 41 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Revisión del acta PRY-208 (2025-05-28): falta autoridad del gerente, objetivo es la solución, alcance con marcadores, éxito no medible sin quien mida, sin supuestos/restricciones/hitos/cadencia; cierre 2026-05-21 vencido hace 155 días con estado verde sin línea base nueva. No sé si hay replanificación o política de autoridad fuera de la carpeta.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Acta previa: sí, existe — acta de constitución aprobada el 2025-05-28 (`PRY-208-motor-de-decisión/00-gobierno/2025-05-28-acta-constitucion.docx`). Términos v1.2 ya vigentes (aceptados por José Francisco Ñáñez, 2026-10-23); no se re-registraron.

## Acta — PRY-208 · Motor de decisión
**Estado:** existe, del 2025-05-28 · Modo: revisar

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente (monto y cambios sin comité) | **No está** en el acta ni en el informe | Rubén Cárdenas no tiene un límite escrito; cualquier cambio de fecha o de presupuesto sube al Comité de Riesgos, o se decide sin cobertura. Hoy hay dos historias fuera del sprint y un hallazgo de seguridad, y no se sabe quién puede decidir qué. |
| Objetivo de negocio | **Es la solución, no el objetivo**: «Entregar motor de decisión para Tecnología» | No dice qué problema resuelve ni qué cambia en el negocio; no se puede juzgar si 63 % de avance acerca al objetivo ni defender el presupuesto de 18.000 MM COP. |
| Alcance | **Marcadores sin contenido**: «Componente 1; Componente 2; Componente 3» | Nada permite decidir si las dos historias que quedaron fuera son alcance o cambio de alcance. |
| Exclusiones | Declaradas, pero vacías: «Lo que otro proyecto cubre» (sin nombrar proyecto) | No sirven para frenar una discusión de alcance ni para detectar solapes con otro proyecto. |
| Patrocinador | Con nombre: Felipe Arango | — |
| Gerente | Con nombre: Rubén Cárdenas | — |
| Comité y cadencia | Comité de Riesgos; **cadencia no declarada** | No se sabe cada cuánto debe ver el proyecto, así que no hay forma de decir si está desatendido. |
| Supuestos | **No hay** | El plan descansa en supuestos que nadie escribió (p. ej. la entrega del proveedor, la integración con el core); no se pueden verificar ni se vuelven riesgo a tiempo. |
| Restricciones | **No hay** | Sin ellas no se sabe qué límites (técnicos, regulatorios, de capacidad) condicionan el plan. |
| Dependencias | «Ninguna declarada», y el informe del 2026-10-23 cita una dependencia con el core y un proveedor pendiente de confirmar | El acta ya no describe el proyecto real: las dependencias existen y no están registradas ni tienen doliente. |
| Criterio de éxito | «Motor de decisión en producción y medido» — **no medible** (sin indicador, umbral ni fecha) | «Medido» no dice contra qué; el cierre quedaría a juicio de quien lo declare. |
| Quién mide el éxito | **No está** | Nadie queda obligado a certificar el cierre. |
| Hitos principales | **No hay** (solo inicio 2025-06-07 y cierre 2026-05-21) | No se puede medir avance por entregables; el 63 % declarado no tiene contra qué compararse. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo dice «Entregar motor de decisión para Tecnología», que es la solución). Fuente: acta.
**Alcance:** «Componente 1; Componente 2; Componente 3» (sin descripción). Fuente: acta.
**Exclusiones:** «Lo que otro proyecto cubre» (sin proyecto nombrado). Fuente: acta.
**Patrocinador:** Felipe Arango · **Gerente:** Rubén Cárdenas. Fuente: acta.
**Autoridad del gerente:** pendiente de definir. No consta en ningún documento.
**Comité al que reporta:** Comité de Riesgos (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «Motor de decisión en producción y medido» (acta; no medible) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-06-07 y cierre 2026-05-21 (acta).
**Presupuesto aprobado:** 18.000.000.000 COP, aprobado por el Comité de Riesgos el 2025-05-28 (acta).

### Lo que el acta ya no sostiene (contraste con el informe del 2026-10-23)
- **El cierre comprometido, 2026-05-21, venció hace 155 días** (≈ 45 % de la duración planificada de 348 días; el umbral configurado es 10 %). El informe declara **Verde** con 63 % de avance. No hay solicitud de cambio ni línea base posterior: la ficha solo tiene la versión 1. Consecuencia: o hay una replanificación que nadie documentó, o el «verde» no se sostiene contra el acta. Esto no lo resuelve una revisión del acta; hay que ponérselo al gerente y al comité.
- Presupuesto (declarado en el informe, no verificado): comprometido 12.114 MM (67 %), ejecutado 8.527 MM (47 %), proyección al cierre 17.554 MM (97,5 % del aprobado). Sin autoridad definida, no está claro quién decide si la proyección cabe o no dentro del margen restante.
- Riesgos e incidencias del informe sin doliente: proveedor sin fecha de última entrega, concentración de conocimiento en una persona, dos historias fuera del sprint, hallazgo de seguridad.

### Lo que no sé
- Si existe una replanificación o aprobación de nueva fecha fuera de los documentos de la carpeta.
- Si hay una definición de la autoridad del gerente en otro documento (política de la organización) que no esté en la carpeta.
- Qué «Componente 1, 2, 3» significan.

### Después
- El acta quedó **sin autoridad declarada**: se ofrece llevar esa definición al comité (/steering-pack). Es una decisión, no un trámite.
- De la revisión salen supuestos implícitos (entrega del proveedor, dependencia con el core): se ofrece pasarlos al registro RAID (/raid-log).
- Se ofrece también un control de cambios (/change-control) sobre la fecha de cierre vencida.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato viene del documento citado; la verificación es suya. Fuentes leídas: el acta (2025-05-28) y el informe de avance (2026-10-23). Nada se completó por lo razonable: lo que no está figura como pendiente de definir.*
