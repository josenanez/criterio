## Barrido — 2026-10-23

Encontré 77 documentos en 13 carpetas de proyecto. Leí 51 (los de 10 proyectos, ninguno con ficha previa) y dejé 26 sin abrir porque no cambiaron desde la corrida anterior (los de PRY-201, PRY-206 y PRY-208). Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23.

**Documentos:** 77 en la carpeta · 51 leídos · 26 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | identidad, plan, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 1 riesgo | autoridad, fase, facturado CT-199 |
| PRY-200 Originación digital | 7 | identidad, plan v1 y v2, 4 hitos, presupuesto, CC-01, 2 riesgos, 2 compromisos | autoridad, fase |
| PRY-202 Migración a la nube | 6 | identidad, plan v1 y v2, 4 hitos, presupuesto, CC-01, 2 riesgos, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-203 Open Banking | 3 | identidad, plan, 3 hitos, presupuesto, 2 riesgos | autoridad, fase |
| PRY-204 Débito contactless | 4 | identidad, plan, 3 hitos, presupuesto, 1 riesgo, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 5 | identidad, plan, 5 hitos, presupuesto, 1 riesgo, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-207 Onboarding PyME | 3 | identidad, plan, 4 hitos, presupuesto, 1 riesgo | autoridad, fase |
| PRY-209 Nómina electrónica | 8 | identidad, plan, 5 hitos, presupuesto, contrato CT-181 (4 entregables) y factura FV-1181, 2 riesgos | autoridad, fase |
| PRY-210 Portal de proveedores | 4 | identidad, plan, 4 hitos, presupuesto, 1 riesgo, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 5 | identidad, plan, 4 hitos, presupuesto, 1 riesgo | autoridad, fase |

En todos los proyectos, además, el dueño de cada riesgo e incidencia quedó `not_found`: ningún informe lo nombra.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-201, PRY-206, PRY-208 | Nada: sus documentos no cambiaron, la ficha se conserva | — |

### Lo que hay que mirar (señales calculadas por el script, no opinión mía)
- **Hitos declarados cerrados sin acta de recibo** (`milestone_met_without_evidence`) en 8 de 10 proyectos: PRY-202 (3), PRY-203 (2), PRY-204 (2), PRY-205 (4 de 5), PRY-207 (3), PRY-209 (2), PRY-210 (4 de 4), PRY-211 (2). Solo PRY-199 y PRY-200 tienen acta para su único hito cerrado. Registré la declaración como `met` y la evidencia como vacía.
- **Avance declarado muy por debajo de lo que sostiene el cronograma** (`progress_vs_plan`): PRY-210 reporta 63% con los 4 hitos cerrados; PRY-211, 36% con 4 de 4; PRY-205, 56% con 5 de 5 (incluida «Salida a producción» de 2026-04-25); PRY-202, 41% con 4 de 4.
- **Estado verde que la evidencia no sostiene** (`declared_vs_evidence`): PRY-203, PRY-204 y PRY-211.
- **PRY-202**: el cronograma v2 (2026-10-16) ya mueve el piloto +69 días (a 2026-11-22), pero la CC-01 está «pendiente de presentación al comité»: cambio de línea base sin autorización (`rebaseline_unauthorized`). Además la proyección (881.586.671) supera en 10,2% el presupuesto aprobado, y un hito «cerrado» tiene fecha vigente futura.
- **PRY-200**: CC-01 autorizada «por el comité» (el documento no dice cuál ni quién firmó); +78 días (18,5% contra la original) y 156.000.000 COP adicionales. Registré la línea base v2.
- **PRY-209**: facturado 3.670.816.836 COP contra 2.720.905.022 de entregables aceptados (diferencia 949.911.814); «Licenciamiento del motor» figura recibido en el contrato sin acta; «Bolsa de horas» (196 días) y «Mesa de ayuda» (13 días) vencidos y pendientes. El patrocinador y el gerente del acta son la misma persona (Sandra Gil).
- **PRY-199**: el informe dice que se reprogramó la salida, pero el único cronograma conserva 2027-12-22 igual a la línea base; no hay documento que recoja la reprogramación.
- **PRY-211**: ejecutado (2.803.145.619) mayor que comprometido (2.225.619.522) en el mismo informe.
- **Compromisos vencidos sin evidencia**: PRY-200 (2: Camilo Beltrán, 3 días; Mauricio Pérez, 11 días), PRY-205 (Beatriz Cuéllar, 12 días), PRY-210 (Elena Duarte, 18 días). Sin fecha: PRY-202 (Ricardo Salas) y PRY-204 (Andrés Lozano). En ninguno de los siete el responsable figura entre los asistentes del comité que lo registró.
- **PRY-207 en silencio**: 20 días desde su último documento (2026-10-03).

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | El plan marcó como no legibles 4 cronogramas `.xml` (PRY-202 v2, PRY-207, PRY-210, PRY-211), pero `texto.py` los convirtió sin instalar nada y los leí; la cita va al `.xml` original. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | — | No existe carpeta `entrada/` en la documentación |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

---
Pie: criterio-portfolio 0.8.0 · términos v1.2 vigentes · 10 fichas escritas y selladas (PRY-199, 200, 202, 203, 204, 205, 207, 209, 210, 211); 3 intactas · campos en `not_found`: `identity.authority` y `identity.phase` en las 10; `identity.product` en 3 (PRY-202, 205, 210); `vendors[0].invoiced` en PRY-199 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

Siguiente paso: hay más de un proyecto, así que puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`.
