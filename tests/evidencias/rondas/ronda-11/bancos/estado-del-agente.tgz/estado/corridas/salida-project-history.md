Términos vigentes (versión 0.8.0, aceptados el 2026-10-23 por José Francisco Ñáñez): no hizo falta registrarlos de nuevo.

## Historia · PRY-200 Originación digital · 2026-03-25 a 2026-10-20

**Leí:** 7 documentos entre 2026-03-25 y 2026-10-20
**Trimestres sin un solo documento:** Q2 2026 (abr–jun) y Q3 2026 (jul–sep). Entre el acta de constitución y el siguiente documento hay un vacío del 2026-03-25 al 2026-10-14.

### En una línea
Del 2026-03-25 al 2026-10-14 no hay un solo documento. Todo lo demás se escribió entre el 14 y el 20 de octubre de 2026: el recibo del diseño funcional (14), la solicitud de cambio CC-01 (15), el comité (17) y el informe de avance con el cronograma v2 (20). La historia entre abril y septiembre no se puede reconstruir desde estos documentos; solo se ve cómo quedó. El proyecto tiene una replanificación (CC-01, +78 días, fin de 2027-05-30 a 2027-08-16) y declara amarillo con 55 % de avance.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 78 días (18.5 %) | No calculable: hay una sola declaración (2026-10-20) | 0 detectados, pero sin documentos entre marzo y octubre no se habría visto uno |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-03-25 | Acta de constitución (.docx) | Nace el proyecto: patrocinadora Beatriz Cuéllar, gerente María Restrepo, Comité de Banca Empresas, presupuesto aprobado 3.300.000.000 COP |
| 2026-03-25 | Cronograma v1 (.csv) | Línea base original: fin 2027-05-30. Cuatro hitos; "Diseño funcional aprobado" figura con fecha 2026-07-18 y estado "cerrado" |
| 2026-10-14 | Acta de recibo del diseño funcional (.pdf) | María Restrepo recibe a satisfacción "Diseño funcional aprobado" |
| 2026-10-15 | Solicitud de cambio CC-01 (.md) | María Restrepo pide ampliación de alcance: +78 días y 156.000.000 COP adicionales; dice "Autorizada por el comité" |
| 2026-10-17 | Comité semanal (.md) | Asisten María Restrepo y Beatriz Cuéllar. Temas: avance y compromisos. Dos compromisos, ambos para personas que no asistieron |
| 2026-10-20 | Cronograma v2 (.xlsx) | Nueva línea base: fin 2027-08-16 (piloto), por CC-01 |
| 2026-10-20 | Informe de avance (.pdf) | Declara amarillo, 55 %. Ejecutado 918.301.849 y proyección 3.420.922.062 COP |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-20 (cronograma v2; solicitud del 2026-10-15) | 2027-08-16 | Ampliación de alcance, +78 días (CC-01) | Solo la propia solicitud CC-01, que dice "Autorizada por el comité" sin decir cuál comité ni quién firmó. El acta del comité del 2026-10-17 no menciona CC-01 |

El atraso contra la línea base original es de 78 días (18.5 %), por encima del umbral de 10 %. Contra la línea base vigente es 0. Solo se movió el hito "Piloto con usuarios internos" (2027-05-30 a 2027-08-16); los otros hitos conservan sus fechas.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | No se detectó ningún cambio de patrocinador, gerente ni comité | — |

Sin documentos entre el 2026-03-25 y el 2026-10-14, esto significa "no se ve", no "no hubo".

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno se repitió | — | 1 | — |

Hay un solo comité, así que no hay forma de ver repeticiones. Quedaron dos compromisos vencidos, ambos registrados el 2026-10-17 a nombre de personas que no figuran como asistentes:
- Camilo Beltrán, "Entregar el punto 4", para el 2026-10-20, 3 días vencido.
- Mauricio Pérez, "Entregar el punto 30", para el 2026-10-12, 11 días vencido. La fecha es anterior al comité en que se registró.

### Desde cuándo lo declarado no se sostiene
No se puede fechar. Hay una sola declaración (2026-10-20), no una serie, y la serie es lo que permite ver el deslizamiento.

Sobre esa declaración:
- No hay hitos cumplidos sin evidencia. El único hito cumplido, "Diseño funcional aprobado", tiene el acta de recibo del 2026-10-14.
- Ese hito tenía fecha 2026-07-18 en la línea base y su recibo se firmó el 2026-10-14. La distancia entre las dos fechas es 88 días; ese número lo calculé yo, `compute` no lo da, y hay que verificarlo.
- El informe declara amarillo, pero el sistema marca dos señales que el informe no explica: el atraso de 78 días y los compromisos vencidos.
- Avance declarado 55 %; el plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplido).
- El informe reporta una prueba de carga que no alcanzó el umbral y se repite. El hito "Ambiente de pruebas certificado" vence el 2026-10-31 y no tiene evidencia todavía.

### Lecciones ancladas a un hecho
- **Hecho:** el cronograma v1, fechado 2026-03-25, muestra como "cerrado" un hito con fecha 2026-07-18, y el recibo de ese hito es del 2026-10-14. **Efecto:** la fecha del archivo y su contenido no coinciden, así que el v1 se editó después o está mal fechado. Con ese archivo no se puede saber cuál era la línea base original en marzo. Hay que preguntar quién lo modificó.
- **Hecho:** CC-01 (2026-10-15) dice "autorizada por el comité" y el comité del 2026-10-17 no la trata. **Efecto:** la línea base v2 (2026-10-20) quedó sin un documento que la apruebe, solo con la afirmación de la propia solicitud.
- **Hecho:** el presupuesto aprobado sigue en 3.300.000.000 COP en el informe del 2026-10-20, y CC-01 pide 156.000.000 COP adicionales. **Efecto:** no consta si esos 156.000.000 entraron al presupuesto aprobado; la proyección declarada es 3.420.922.062 COP (3.7 % sobre lo aprobado).

No se dice quién ocultó ni quién se equivocó. Que el atraso quede en un solo mes de documentos es un dato para la conversación con la gerente, no un juicio sobre ella.

Se puede llevar esta historia al comité del 2026-10-30, donde hay una decisión que sale de ella: quién autorizó CC-01 y si la línea base v2 se ratifica.

---
**Rigor:** cifras copiadas de `portafolio.py compute` (2026-10-23), salvo los 88 días, que son cálculo mío. Cada dato sale de los 7 documentos citados. Los .docx, .xlsx y .pdf los leí a través de la ficha PRY-200, y el informe y el acta de recibo también directamente con pdftotext. Lo que se habló fuera de estos documentos no lo sé.
