# Corrida del 2026-10-23 · budget-tracking

13 proyectos · 33 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Presupuesto de PRY-202: proyección 10,2% sobre el aprobado; comprometido 45,6%, ejecutado 21,9%. Dijo que no sabe si la proyección incluye CC-01 (138 M, pendiente) y que comprometido, ejecutado y proyección son declaración sin evidencia.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Sale de: ficha PRY-202 (`estado/records/PRY-202.json`), el acta de constitución (2025-08-13), el informe de avance (2026-10-16), la solicitud de cambio CC-01 (2026-10-11) y el recálculo de `portafolio.py compute` al 2026-10-23.

## Presupuesto — PRY-202 Migración a la nube al 2026-10-23
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | 100% | Acta de constitución | 2025-08-13 |
| Comprometido | 364.802.812 | 45,6% | Informe de avance (declaración) | 2026-10-16 |
| Ejecutado | 175.437.818 | 21,9% | Informe de avance (declaración) | 2026-10-16 |
| Proyección al cierre | 881.586.671 | 110,2% | Informe de avance (declaración) | 2026-10-16 |

**Disponible real** (aprobado menos comprometido): 435.197.188 COP

Las tres últimas cifras son declaración del gerente; ningún documento de evidencia las respalda (0 fuentes de evidencia, 5 declaraciones en la ficha). La proyección es posterior al último movimiento de presupuesto (no hay ninguno aprobado), así que no está desactualizada frente a él. El aprobado tiene 14 meses de antigüedad (umbral: 12).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 800.000.000 | 800.000.000 | 0 |
| Fecha de cierre | — | 2026-11-22 | +69 días contra la original (17,8%); 0 contra la vigente |

Replanificaciones de presupuesto: 0. Hay 1 replanificación de fechas (+69 días) y no tiene cambio aprobado que la autorice (`rebaseline_unauthorized`: 69 días movidos, 0 autorizados).

La solicitud CC-01 (2026-10-11) pide 138.000.000 COP adicionales y ampliación de alcance. Su decisión está pendiente, así que no es parte del aprobado vigente.

### Ejecución frente a avance
Ejecutado 21,9% · Hitos cumplidos 4 de 4 · Avance declarado 41%.
Las tres medidas no coinciden: el plan marca los 4 hitos como cumplidos (100%), el gerente declara 41% (brecha de 59 puntos) y la plata ejecutada va en 21,9%. Tres de esos hitos están marcados cumplidos sin evidencia (Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core). La ejecución baja respecto del avance declarado puede ser trabajo hecho y no causado, pero con estos datos no se puede afirmar.

### Alertas
- **Proyección por encima del aprobado:** 881.586.671 frente a 800.000.000, 10,2% sobre el aprobado (umbral: 10%). Es la cifra que supera el umbral de desviación de costo.
- **Comprometido:** 45,6%, por debajo del umbral de 90%. No hay alerta.
- **Reprogramación sin autorización:** +69 días sin cambio aprobado.
- **Ejecución desalineada del avance:** ver arriba; 3 hitos "cumplidos" sin evidencia.
- **Compromiso sin fecha:** Ricardo Salas, "Entregar el punto 28" (comité semanal del 2026-10-18). No es de presupuesto, pero quedó abierto.

### Sin dato
- No hay cifra de presupuesto respaldada por un documento de evidencia (contrato, orden de compra, extracto contable) para comprometido, ejecutado ni proyección.
- No se sabe si la proyección de 881.586.671 incluye los 138.000.000 de CC-01: el informe no lo dice. Si los incluyera, el aprobado más el cambio sería 938.000.000, y no lo derivo porque el cambio no está aprobado.
- No hay proveedores registrados en la ficha, así que no hay detalle por proveedor.

## Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio, o evaluar CC-01 con `/criterio-portfolio:change-control`, que sigue pendiente. El comprometido no está cerca del tope, así que no ofrezco el detalle por proveedor.

---
Criterio produce borradores de trabajo, no decisiones ni asesoría. Cada cifra sale de los documentos citados y de `portafolio.py compute`; la verificación es suya.
