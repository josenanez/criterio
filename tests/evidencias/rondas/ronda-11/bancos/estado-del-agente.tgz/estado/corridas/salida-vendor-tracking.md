## Proveedores — PRY-201 Core de depósitos al 2026-10-23

**De qué documentos sale:** contrato CT-600 (`00-gobierno/2025-12-31-contrato-ct-600.docx`), acta de recibo de la bolsa de horas (`20-seguimiento/2026-07-03-acta-recibo-ct-600-bolsa-de-horas-de-desarrollo.pdf`), factura FV-1600 (`20-seguimiento/2026-10-03-factura-ct-600.pdf`), acta de constitución, informe de avance del 2026-10-21 y comité del 2026-10-22. Las cifras derivadas salen de `portafolio.py compute`.

### Redes del Norte Ltda. — contrato CT-600
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato. El contrato solo trae fecha de firma (2025-12-31), tres entregables y la condición de pago.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-04-02 | pending (el contrato dice «en curso»); 204 días vencido | ninguna | no identificable |
| Bolsa de horas de desarrollo | 2026-06-21 | accepted | acta de recibo 2026-07-03, recibido por Carlos Peña | no identificable |
| Parametrización del tarifario | 2026-09-09 | pending (el contrato dice «en curso»); 44 días vencido | ninguna | no identificable |

Cada entregable vale 252.141.177 COP. Facturado a la fecha: 252.141.177 COP (FV-1600, 2026-10-03). Aceptado con evidencia: 252.141.177 COP. Entregables: 3. Aceptados: 1.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Qué cubre la factura | Cada entregable se factura contra acta de recibo firmada por el gerente | FV-1600 dice «Entregables del contrato CT-600» (plural) y no nombra ninguno. Su valor es el de un solo entregable, y el único con acta es la bolsa de horas | contrato CT-600; FV-1600; acta de recibo 2026-07-03 |

El monto facturado coincide con lo aceptado y el script no levanta `vendor_invoiced_without_delivery`. Lo que no puedo afirmar es que la factura corresponda a la bolsa de horas: el concepto no lo dice. Por eso la sé consistente en monto, pero no atada a un entregable. Que alguien de cuentas por pagar confirme a cuál se refiere.

Las dos facturas que faltan no existen aún. Si llegan por los otros dos entregables, hoy no tendrían acta que las respalde.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del motor | pending (sin declarar entrega) | vencido desde 2026-04-02 |
| Parametrización del tarifario | pending (sin declarar entrega) | vencido desde 2026-09-09 |

Ninguno está marcado como entregado o aceptado sin acta, así que `accepted_without_evidence` queda vacío. Los dos son atrasos, no aceptaciones sin soporte. El proyecto tiene cierre comprometido el 2026-10-30 y el informe del 2026-10-21 no menciona a ninguno de los dos.

### Compromisos del proveedor vencidos
Ninguno vencido. El único compromiso del comité del 2026-10-22 es «Entregar el punto 18», de Rubén Cárdenas, para el 2026-10-25. El acta no dice a qué organización pertenece Rubén ni qué es el «punto 18», así que no puedo decir si es del proveedor. Tampoco está entre los asistentes (Carlos Peña, Óscar Ramírez). No hay nada más de Redes del Norte en las reuniones.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-600: el contrato en la carpeta no los trae. No puedo decir si el preaviso vence antes del cierre; hace falta el contrato completo o sus condiciones generales.
- Qué entregable cubre la factura FV-1600 (ver arriba).
- Si el acta de recibo está firmada: el texto extraído del PDF dice «Recibido por: Carlos Peña», pero no permite ver una firma.
- El contrato fechado 2025-12-31 ya marca la bolsa de horas como «recibido», aunque el acta es de 2026-07-03. La columna de estado parece actualizada después de la firma y el contrato no indica cuándo.
- Los amounts_declared del script son 3 de 3; el monto de los entregables está declarado en el contrato.

### Contexto, fuera del cruce del proveedor
El script marca además 4 hitos del plan declarados cumplidos sin evidencia, y una proyección de costo 17.2 % sobre lo aprobado (2.812.334.652 contra 2.400.000.000 COP). Con el avance declarado en 90 % y los dos entregables del proveedor sin recibir, el atraso del licenciamiento y de la parametrización merece llevarse al comité.

**Pie de rigor:** borrador de trabajo hecho solo con los documentos citados. No recoge lo hablado fuera de ellos y la verificación es de quien lo lee.
