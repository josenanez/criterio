Cargué las 13 fichas de `estado/records` (PRY-199 a PRY-211), recalculadas el 2026-10-23 con `portafolio.py compute`, y las salidas de las corridas de hoy (RAID y control de cambios). Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-23.

# Comité de proyectos — 2026-10-30 (próximo comité según la configuración; material preparado el 2026-10-23)
6 decisiones · 3 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (71 señales en total)

## Decisiones del comité anterior
No hay registro. En `estado/` no existe una corrida anterior de `steering-pack` ni ninguna ficha con decisiones de comité registradas, y los 13 proyectos tienen 0 cambios aprobados salvo PRY-200 (1 cambio, +78 días autorizados). No sé qué se decidió en el comité pasado. Ese ciclo queda sin cerrar hasta que alguien aporte el acta.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de fecha y de presupuesto en el portafolio, y con qué umbrales?
**Proyecto:** los 13 (`identity.authority` sin dato en 13 de 13) · **Quién decide:** el patrocinador ejecutivo del portafolio; no consta en ningún documento quién es · **Si no se decide hoy:** los puntos 2 y 3 se deciden sin saber si este comité puede decidirlos. En PRY-201 la autoridad que aprobó la línea base fue el Comité de Arquitectura (acta 2026-01-02), pero el acta no dice que pueda aprobar cambios.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité de proyectos aprueba cambios sobre umbrales fijos (10 % tiempo, 10 % costo, los de la configuración) y lo deja escrito en cada acta | Sin cambio | Se pueden decidir 2 y 3 hoy | Sin costo directo |
| B. Cada comité de origen (p. ej. Arquitectura en PRY-201) conserva la autoridad | Sin cambio | Los puntos 2 y 3 se aplazan hasta consultarlos | No declarado |

**Recomendación:** A. Con la autoridad sin declarar, hoy ningún gerente puede probar que tiene permiso para mover una fecha; los dos cambios pendientes ya muestran el efecto. Es una recomendación mía y el comité puede preferir B.

### [2] ¿Se aprueba CC-01 de PRY-202 (piloto +69 días, 2026-09-14 → 2026-11-22) y qué cronograma rige?
**Proyecto:** PRY-202 Migración a la nube · **Quién decide:** por el punto 1 · **Si no se decide hoy:** el cronograma v2 (2026-10-16) sigue circulando con +69 días sin autorización (`unauthorized_days` = 69) y con hitos en «cerrado» al 100 % frente a un informe del mismo día que dice rojo y 41 %.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar la línea base 2 con motivo y documento | Sin cambio declarado | +69 días contra la original (17,8 %) | Proyección 881.586.671 COP sobre 800.000.000 aprobados (+10,2 %); sin aprobar |
| B. Rechazar CC-01; rige la línea base v1 y el proyecto reporta contra ella | Sin cambio | 2026-09-14 ya vencido; atraso queda a la vista | Igual: el sobrecosto de 10,2 % existe con o sin el cambio |
| C. Devolver CC-01 hasta que el gerente presente motivo y sustento de los tres hitos «cumplidos» | Sin cambio | El tiempo corre sin referencia vigente | Igual |

**Recomendación:** C. El cambio está pendiente, el cronograma ya se movió sin él, y los 3 hitos declarados cumplidos (diseño funcional, ambiente de pruebas, integración con el core) no tienen evidencia. Aprobar sin sustento convierte una declaración en línea base.

### [3] ¿Se mueve la salida de PRY-201 del 2026-10-30 al 2026-11-29 (+30 días)?
**Proyecto:** PRY-201 Core de depósitos · **Quién decide:** por el punto 1 (hoy, por defecto, el comité) · **Si no se decide hoy:** la salida sigue fijada el 2026-10-30, que es la fecha del propio comité; si se espera a esa sesión, la decisión llega el día de la salida.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar +30 días y registrar línea base 2 | Sin cambio declarado | 2026-11-29 (domingo) | Sobre una proyección ya 17,2 % por encima de lo aprobado (2.812.334.652 vs 2.400.000.000 COP); el costo del mes extra no está declarado |
| B. No aprobar; la salida se mantiene el 2026-10-30 | Sin cambio | Se mantiene | Sin costo del mes extra; el informe del 2026-10-21 declara rojo y el 90 % de avance no tiene sustento |
| C. Aplazar hasta que se declare quién lo pide, el motivo, el costo del mes extra y la vigencia del contrato CT-600 | Sin cambio | Decisión a más tardar el 2026-10-30 | Sin impacto hasta decidir |

**Recomendación:** C, con tope en la sesión del 2026-10-30. La solicitud no dice quién la hace ni por qué, y la línea base nueva exige motivo. Si la salida se mueve sin documento de aprobación, quedarán 30 días sin autorizar.

### [4] ¿Se retiene el pago a Núcleo Financiero S.A. (CT-181, PRY-209) hasta sustentar lo facturado sobre lo aceptado?
**Proyecto:** PRY-209 Nómina electrónica · **Quién decide:** por el punto 1 y quien apruebe pagos al proveedor (no consta) · **Si no se decide hoy:** lo facturado supera lo aceptado en 949.911.814 COP (facturado 3.670.816.836; aceptado 2.720.905.022) y la siguiente factura se pagaría sobre esa base.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener nuevos pagos hasta que el proveedor entregue lo pendiente y exista acta de recibo | Sin cambio | Puede aumentar la fricción con 2 entregables vencidos (Bolsa de horas, 196 días; Mesa de ayuda, 13 días) | Evita pagar 949.911.814 COP sin aceptación |
| B. Pagar y pedir regularización posterior | Sin cambio | Sin efecto | Expone 949.911.814 COP |

**Recomendación:** A. Además, «Licenciamiento del motor» figura aceptado sin evidencia de recibo; no se debe contar como aceptado hasta que aparezca el documento.
### [5] ¿Quién es la contraparte del «calendario de liberaciones del core» y quién confirma las fechas?
**Proyecto:** PRY-203, PRY-207, PRY-209 (dependencia declarada) y PRY-208, PRY-211 (historias fuera del sprint por esa dependencia) · **Quién decide:** el patrocinador del portafolio · **Si no se decide hoy:** cinco proyectos siguen sin saber de quién dependen. Ninguna de las 13 actas declara la dependencia («Ninguna declarada»).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar un dueño del calendario del core y exigir confirmación de fechas a los proyectos dependientes | Sin cambio | Plazo por fijar por el comité | No declarado |
| B. Cada proyecto negocia por separado | Sin cambio | Sin plazo | No declarado |

**Recomendación:** A. Hipótesis mía, no dato: si «el core» es PRY-201, ese proyecto está en rojo con salida el 2026-10-30; el punto 3 sería entonces un movimiento que afecta a estos cinco proyectos y hoy ninguna ficha lo refleja.

### [6] ¿Quién es el dueño del hallazgo de seguridad de la revisión de arquitectura y de la disponibilidad del equipo de seguridad?
**Proyecto:** el hallazgo aparece en PRY-202, 203, 205 y 208; la dependencia del equipo de seguridad en PRY-199, 200, 201 y 209 · **Quién decide:** el patrocinador del portafolio · **Si no se decide hoy:** ocho proyectos cargan lo mismo sin dueño. No sé si el hallazgo es uno solo o cuatro: la frase se repite palabra por palabra.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Consolidar en un solo hallazgo con un dueño de seguridad y fecha de respuesta | Sin cambio | Una sola respuesta para ocho proyectos | No declarado |
| B. Mantenerlo por proyecto | Sin cambio | Ninguna respuesta de seguridad consta | No declarado |

**Recomendación:** A. Primero confirmar con el área si es el mismo hallazgo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-206 Billetera y QR | Verde declarado (2026-10-20) con 16 señales abiertas: 4 compromisos vencidos (entre 8 y 17 días), 3 compromisos reprogramados 4, 6 y 5 veces, 2 entregables vencidos de Talento Digital S.A.S. (108 y 31 días), un entregable aceptado sin evidencia (Integra Sistemas Ltda.) y un riesgo dicho en reunión (2026-10-23) sin registrar | Primer compromiso vencido: 2026-10-06 | Que el gerente reclasifique el estado o sustente el verde; dueño para el riesgo 206-R2 |
| PRY-207 Onboarding PyME | En silencio 20 días (desde 2026-10-03; umbral 15). Declara 22 % frente a un plan que sostiene entre 75 y 100 % | 2026-10-03 | Que el gerente informe; si no, que el comité lo cite |
| PRY-205, PRY-208, PRY-210, PRY-211 | La fecha de cierre vigente ya pasó (2026-04-25, 2026-05-21, 2026-09-12 y 2026-09-20) y no hay solicitud de cambio registrada (0 cambios en los cuatro) | Desde cada fecha | Línea base nueva con motivo, o declaración de que el proyecto está atrasado |

## Para conocimiento
- PRY-199: verde, 0 señales abiertas; ejecutado 30,0 % de lo aprobado, comprometido 45,0 %.
- PRY-200: amarillo; +78 días ya autorizados y registrados; 2 compromisos vencidos (3 y 11 días).
- PRY-203: verde declarado con 2 hitos cumplidos sin evidencia y 36,0 puntos de avance por debajo de lo que sostiene el plan.
- PRY-204: verde declarado (informe del 2026-10-02, 21 días); 2 hitos sin evidencia; 47,0 puntos por debajo del plan; 1 compromiso sin fecha.
- PRY-208: verde, sin señales; cierre vigente 2026-05-21 (ver escalamientos).
- PRY-209: rojo; ver punto 4.
- Cuatro proyectos con verde contradicho por la evidencia: PRY-203, 204, 206 y 211.

## Anexo
**Estado por proyecto (declarado, avance declarado, señales):** PRY-199 verde 20 % · 0 | PRY-200 amarillo 55 % · 3 | PRY-201 rojo 90 % · 7 | PRY-202 rojo 41 % · 8 | PRY-203 verde 31 % · 4 | PRY-204 verde 20 % · 5 | PRY-205 rojo 56 % · 6 | PRY-206 verde 84 % · 16 | PRY-207 amarillo 22 % · 5 | PRY-208 verde 63 % · 0 | PRY-209 rojo 39 % · 7 | PRY-210 rojo 63 % · 6 | PRY-211 verde 36 % · 4.

**Contradicciones abiertas:** el avance declarado queda muy por debajo de lo que sostiene el plan en PRY-202 (59,0 puntos), 203 (36,0), 204 (47,0), 205 (44,0), 207 (53,0), 209 (41,0), 210 (37,0) y 211 (64,0); PRY-211 reporta ejecutado 2.803.145.619 COP mayor que comprometido 2.225.619.522 COP. En ningún proyecto hay hitos «cumplidos» con evidencia (0 fuentes de evidencia en las 13 fichas; todo es declaración).

**Vacíos de información:** autoridad de aprobación (13 de 13); fase (13 de 13); dueño de todos los riesgos e incidencias (41 ítems); quién solicita el cambio de PRY-201 y su costo; vigencia de CT-600; si «el core», «el proveedor» y «el hallazgo de seguridad» son uno solo o varios; PRY-203, 207, 208, 209 y 211 sin minuta de comité en la carpeta. Fichas con datos de más de 12 meses: PRY-202, 205, 207, 208 y 209.

**Cifras a las que no llegué:** cuánto cuesta cada opción de los puntos 2, 5 y 6 y qué pasa con el contrato CT-600 después del 2026-10-30: ninguna ficha ni documento lo declara.

---
Pie: Criterio Portfolio 0.8.0 · términos v1.2 aceptados el 2026-10-23 · fichas aplicadas: PRY-199 a PRY-211 (13) · campos inciertos: autoridad, fase, dolientes, cifras de costo por opción · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
