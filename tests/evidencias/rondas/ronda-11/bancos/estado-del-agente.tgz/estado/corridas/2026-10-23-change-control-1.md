# Corrida del 2026-10-23 · change-control

13 proyectos · 58 s · 71 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 28 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 8 |
| `vendor_deliverable_late` | 6 |
| `commitment_undated` | 5 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `rebaseline_unauthorized` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Solicitud de mover 30 días la salida a producción de PRY-201. No consta quién la pide, el motivo, el costo del mes extra ni la autoridad que decide. Sin dependencias declaradas. Proyección ya 17,2 % sobre lo aprobado. No se registró línea base nueva.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Parto de la ficha `estado/records/PRY-201.json` (corte 2026-10-21) y de los documentos de PRY-201. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-23 (versión 0.8.0).

## Solicitud de cambio — PRY-201 Core de depósitos — 2026-10-23

**Qué se pide:** mover la salida a producción 30 días (del 2026-10-30 al 2026-11-29).
**Quién lo pide:** no consta en ningún documento ni en la solicitud.
**Por qué:** no consta. Sin motivo no se puede aprobar la línea base nueva, que lo exige.

### Línea base vigente
Una sola: v1, aprobada el 2026-01-02 por el Comité de Arquitectura (`10-plan/2026-01-02-cronograma-v1.xlsx`). Cierre 2026-10-30, presupuesto 2.400.000.000 COP. Replanificaciones hasta hoy: 0. Cambios aprobados registrados: 0.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, 2026-01-02) | Sin cambio declarado | 0 declarado |
| Tiempo | Salida a producción y cierre: 2026-10-30 | 2026-11-29 (domingo) | +30 días, 7 días antes de que venza la fecha actual |
| Costo | Aprobado 2.400.000.000; proyección declarada 2.812.334.652 | No declarado | No se sabe: nadie dijo cuánto cuesta un mes más |

**Quién absorbe lo que no se declaró.**
- Alcance sin cambio y tiempo +30 días: el mes extra lo absorbe el presupuesto o el equipo. La solicitud no dice cuál de los dos.
- La proyección declarada (2.812.334.652) ya supera lo aprobado en 412.334.652 COP (17,2 %, sobre el umbral de 10 %) **antes** de este cambio. Si el mes extra tiene costo, se suma a un sobrecosto que ningún documento autoriza.
- Hay un contrato con proveedor: CT-600, Redes del Norte. Su vencimiento no figura en la ficha y no sé si cubre hasta el 2026-11-29. Si vence antes, el mes extra queda sin cobertura contractual.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` no alcanza a otro proyecto | — |

`impact` devuelve 0 proyectos alcanzados, 0 que no puedan sostener su fecha y 0 dependencias sin confirmar. Ese cero **no** significa que nada dependa de PRY-201. Significa que **ninguna ficha declara una dependencia** con él: el acta dice «Ninguna declarada» y el RAID no tiene dependencias. Un core de depósitos para Banca Empresas, con la cuenta de ahorros como producto asociado, sin una sola dependencia declarada, es un hallazgo en sí mismo. Si alguien depende de esta salida, hoy no lo sabe.

Hito por el que pasa el cambio: «Salida a producción» (2026-10-30). Cuántos días se mueve cada otra actividad no se puede calcular: la ficha no tiene holgura por actividad.

### Quién decide
**Autoridad requerida:** no se puede determinar. `identity.authority` está **no encontrada**: el acta no declara quién aprueba cambios de fecha ni de presupuesto, ni umbrales.
**Según:** acta de constitución 2026-01-02, sin cláusula de autoridad.
**Va a comité:** sí, por defecto. La línea base y el presupuesto los aprobó el Comité de Arquitectura. Con la autoridad sin declarar, no hay base para decir que el gerente puede aprobar esto solo. Que sea el Comité de Arquitectura el que decida es una inferencia mía y no algo escrito.
Próximo comité semanal: 2026-10-30, el mismo día en que vence la fecha actual. Si se espera a ese comité, la decisión llega el día de la salida.

### Si no se aprueba
La salida sigue el 2026-10-30, 7 días después de hoy. El informe del 2026-10-21 declara el proyecto en **rojo**. Lo que respalda el informe se limita a una línea: «Se recibió la aprobación regulatoria pendiente desde el trimestre anterior». Su único riesgo abierto es la «Disponibilidad del equipo de seguridad para la revisión final», sin dueño. El 90 % de avance es una declaración: el ejecutado es 494.176.690 COP (20,6 % de lo aprobado) y ningún documento sustenta el 90 %.

### Si se aprueba
Línea base 2 (propuesta, no registrada) — cierre 2026-11-29 · presupuesto: sin cambio declarado (2.400.000.000 COP) · motivo: **sin motivo** · documento de aprobación: **ninguno**.
Desviación acumulada contra la línea base original: **tiempo +30 días** · **costo +412.334.652 COP (+17,2 %) en la proyección ya declarada, más lo que cueste el mes extra (no declarado)**.
Replanificaciones: 0 → 1. Desde ese momento toda desviación se reporta contra dos referencias. Hoy `baseline_moved_days` es 0, `approved_time_days` es 0 y `unauthorized_days` es 0; si se mueve la fecha sin un documento que lo autorice, quedarán 30 días sin autorizar.

### Lo que no sé
- Quién lo pide y por qué.
- Cuánto cuesta el mes extra.
- Hasta cuándo cubre el contrato CT-600.
- Quién tiene autoridad para aprobarlo.
- Si algo depende de esta salida.

### Siguiente paso
Llevar el paquete al comité. Una vez aprobado por quien tenga la autoridad, registrar la línea base 2 con su motivo y el documento que la aprobó. No registro nada hoy.
