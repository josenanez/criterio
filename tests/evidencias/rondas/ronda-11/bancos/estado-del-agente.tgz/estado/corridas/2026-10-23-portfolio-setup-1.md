# Corrida del 2026-10-23 · portfolio-setup

3 proyectos · 77 documentos, 51 releídos y 26 sin cambio · 182 s · 23 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `vendor_deliverable_late` | 4 |
| `commitment_overdue` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); tiempo hasta el primer resultado no cronometrado; 3 proyectos (PRY-206, 201, 208), 26 documentos; 23 señales: PRY-206 verde contradicho, PRY-201 con 4 hitos sin acta y proyección +17,2 %, PRY-208 sin señales; 4 cronogramas XML ilegibles; carpeta no marcada

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 77 documentos en 13 proyectos · formatos: .md 30, .pdf 17, .docx 14, .xlsx 7, .csv 3, .xml 4, .json 1, .txt 1 · más reciente: 2026-10-23
**Eres:** PMO del portafolio *(sugerido: hay varios proyectos)*
**Te aviso:** dos días antes del comité del 2026-10-30, cada semana *(las carpetas hablan de «comité semanal»; la fecha del próximo la supuse, nadie la dijo)*
**En:** presentación (HTML), informes en `reportes/`, lo que voy encontrando en `estado/`
**Términos:** aceptados para la versión 1.2 (familia 0.8.0) por José Francisco Ñáñez, 2026-10-23 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 fe830b9a4eee0bc9…

Configuración en `.criterio/portafolio/config.json`. Nadie contestó preguntas en esta sesión: tomé la respuesta sugerida en cada una. El nombre de la organización quedó como «Portafolio de proyectos» porque no aparece en los documentos. No dejé el archivo `_CRITERIO_PORTAFOLIO.txt` en la carpeta de documentos: no hubo un sí y no escribo ahí sin él.

### Probé con tres proyectos

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-206 Billetera y QR | 17 (+ la ficha que publicó su gerente, guardada aparte) | Gerente Gustavo Neira, patrocinadora Laura Vélez, presupuesto 800.000.000 COP, cierre 2027-01-25; declara **verde, 84%** (informe 2026-10-20) | autoridad, fase, dolientes de los 4 riesgos/incidencias |
| PRY-201 Core de depósitos | 7 | Gerente Carlos Peña, patrocinador Óscar Ramírez, presupuesto 2.400.000.000 COP, cierre 2026-10-30; declara **rojo, 90%** (informe 2026-10-21) | autoridad, fase, doliente del riesgo |
| PRY-208 Motor de decisión | 2 | Gerente Rubén Cárdenas, patrocinador Felipe Arango, presupuesto 18.000.000.000 COP; declara **verde, 63%** (informe 2026-10-23) | producto (el acta dice «No aplica»), autoridad, fase, hitos (no hay cronograma), dolientes de 4 riesgos/incidencias |

### Hallazgos (todos levantados por el cálculo, cada uno con su cita en la ficha)

**PRY-206 — el verde queda contradicho por los documentos** (`declared_vs_evidence`)
- 4 compromisos vencidos sin evidencia: Aprobar el diseño 5 (17 días), Validar el ambiente 12 (13), Aprobar el diseño 13 (14), Cerrar la prueba 10 (8). Sobre el diseño 5, el 2026-10-09 se dijo que ya estaba entregado; no hay acta de ese compromiso.
- 3 compromisos reprogramados una y otra vez: «Cerrar la prueba 2» 6 veces (de 2026-10-07 a 2027-01-09), «Validar el ambiente 4» 5 veces, «Enviar el documento 1» 4 veces. Es un bloqueo que nadie ha nombrado, no tres olvidos.
- 3 compromisos sin fecha, entre ellos el ajuste del presupuesto que Laura Vélez quedó de mandar «la otra semana».
- 2 hitos declarados cerrados sin acta que lo pruebe: Ambiente de pruebas certificado (vencía 2026-08-11) e Integración con el core (2026-10-05).
- Proveedores: Talento Digital (CT-127) lleva sin entregar Licenciamiento del motor (108 días) y Bolsa de horas (31 días). Integra Sistemas (CT-360) tiene el Licenciamiento como recibido sin acta de recibo y ya está facturado (FV-1360, 71.307.259 COP).
- Una lectura de fecha a confirmar: las notas del 2026-10-23 dicen «09/01/2027»; la leí como 9 de enero de 2027.

**PRY-201 — rojo declarado, con más detrás**
- 4 hitos declarados cerrados sin acta (el más viejo, Diseño funcional aprobado, vencía el 2026-03-11).
- Proyección al cierre 2.812.334.652 COP contra 2.400.000.000 aprobados: 17,2 % por encima.
- Proveedor Redes del Norte (CT-600): Licenciamiento del motor sin entregar hace 204 días y Parametrización del tarifario hace 44. Lo facturado (252.141.177 COP) coincide con lo aceptado con acta (Bolsa de horas).

**PRY-208 — sin señales levantadas**
- Doce campos salen del acta de 2025-05-28, sin confirmación posterior en 17 meses (patrocinador, gerente, presupuesto, fechas, alcance).
- Su única fecha de cierre es la del acta (2026-05-21); sin cronograma ni minutas que la actualicen. El cálculo no la levantó como señal, así que no la presento como hallazgo; la anoto como vacío de documentación.

### El portafolio completo
10 proyectos más (51 documentos), en 2 lotes uno tras otro. Estimo unos 20 minutos, por proporción con los 26 documentos de esta prueba (es una estimación, no una medida). El tiempo hasta el primer resultado no se cronometró en esta sesión.

### Lo que le falta a tu carpeta
- 4 cronogramas en XML (PRY-202, 207, 210, 211) no se leen sin instalar algo; guardados como .xlsx o .csv entrarían.
- PRY-203, 207 y 208 no tienen minutas; PRY-208 tampoco tiene cronograma. Sin ellos no hay compromisos ni hitos que contrastar.
- Las actas de recibo existen para pocos hitos: en los proyectos leídos, 6 de los 7 hitos declarados cerrados no tienen prueba.
- Ningún proyecto declara autoridad (hasta qué monto decide el gerente sin subir a comité) ni fase.
- Solo PRY-206 tiene `ficha-pm.json` (la del gerente); el resto lo leo solo de los documentos.
- Las notas del 2026-10-23 de PRY-206 están sueltas en la raíz del proyecto, fuera de `30-reuniones/`. No moví nada.

### Siguiente
¿Corro el portafolio completo? Si tienes equipo de gerentes, puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
