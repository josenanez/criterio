# Corrida del 2026-10-23 · pm-commitments

1 proyectos · 30 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_met_without_evidence` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Reprogramados 3 o más veces: Camilo Beltrán (6), Beatriz Cuéllar (5), Ricardo Salas (4); 4 vencidos sin evidencia; 3 sin fecha

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Compromisos — Billetera y QR (PRY-206) · al 2026-10-23

Términos: vigentes para la versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya existente).
24 compromisos abiertos de 26 registrados: 3 reprogramados 3 veces o más, 4 vencidos sin evidencia, 6 que vencen esta semana y 3 sin fecha. (Cifras de `compute`.)

### Se viene reprogramando

> **Camilo Beltrán** · Cerrar la prueba 2
> Prometido para el 2027-01-09, y antes para el 2026-12-26, el 12-13, el 11-24, el 11-10 y el 10-25; la primera promesa fue el 2026-10-07. **Seis reprogramaciones.**
> Fuente: actas del 09-18, 09-25, 10-02, 10-09, 10-16 y notas del 10-23. La fecha de la última viene como «09/01/2027»; se lee día/mes (9 de enero de 2027). Confírmalo con Camilo: leída mes/día caería después del cierre del proyecto (2027-01-25).

> **Beatriz Cuéllar** · Validar el ambiente 4
> Prometido para el 2026-11-30, y antes para el 11-18, el 11-08, el 10-29 y el 10-22; la primera promesa fue el 2026-10-07. **Cinco reprogramaciones.**
> Fuente: actas del 09-18, 09-25, 10-02, 10-09 y 10-16.

> **Ricardo Salas** · Enviar el documento 1
> Prometido para el 2026-11-30, y antes para el 11-15, el 10-26 y el 10-17; la primera promesa fue el 2026-09-26. **Cuatro reprogramaciones.**
> Fuente: actas del 09-25, 10-02, 10-09 y 10-16.

**Tres personas con tres o más reprogramaciones no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Las actas registran la fecha nueva, no el motivo; qué lo está trabando no consta en ningún documento.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Camilo Beltrán | Aprobar el diseño 5 | 2026-10-06 | 17 días |
| María Restrepo | Aprobar el diseño 13 | 2026-10-09 | 14 días |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-10 | 13 días |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-15 | 8 días |

Sobre el diseño 5: salió de la tabla el 2026-10-09 con la nota «dice que ya entregó… No se presentó acta». El acta de recibo del 2026-10-14 nombra el entregable «Diseño funcional aprobado», no este compromiso, así que no lo cierra. Camilo dice que lo entregó; no hay nada en el expediente que lo respalde.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Revisar el anexo 19 | 2026-10-23 (hoy) |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-23 (hoy) |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-24 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-25 |
| Jorge Medina | Enviar el documento 17 | 2026-10-28 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-30 |

Las notas del 10-23 no mencionan los dos que vencían hoy; sin nota ni documento siguen abiertos. Varios de esta lista ya se movieron: Liliana Torres (fecha 7, original 10-05), Beatriz Cuéllar (documento 9, dos veces) y Paula Céspedes (anexo 11, una vez); Andrés Lozano (anexo 19) también ya se había movido una vez.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Diana Molina | Actualizar la matriz 6 | 2026-09-18 |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-02 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-23 |

No pueden estar vencidos y por eso se cuentan aparte. Diana Molina «dice que ya entregó» (acta del 09-25) sin acta que lo respalde, y no estuvo en la reunión del 10-23. Beatriz Cuéllar lleva «por definir» desde el 10-02. Laura Vélez dijo «la otra semana», que no es una fecha; no se le inventó una.

### Cerrados desde la última revisión
| Quién | Qué | Documento que lo cierra |
|---|---|---|
| María Restrepo | Entregar el punto 8 | `20-seguimiento/2026-10-02-acta-recibo-8.md` |
| Javier Hoyos | Validar el ambiente 20 | `20-seguimiento/2026-10-16-acta-recibo-20.md` |

### Contexto
El informe de avance del 2026-10-20 declara verde; las señales de compromisos (vencidos y reprogramados) lo contradicen.

### Lo que sigue
- Hay tres compromisos reprogramados 3 o más veces. **¿Lo formulo como decisión para el comité** (`/criterio-project:pm-escalate`): qué se pide, qué pasa si no se decide y quién tiene la facultad? Eso excede la autoridad del gerente y por eso sube. Próximo comité: 2026-11-06.
- Este comando no cambió la ficha, así que no hace falta `/pm-publish`.
