# Acta — Billetera y QR (PRY-206) · 2026-10-23
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `documentos/proyectos/PRY-206-billetera-y-qr/2026-10-23-notas-reunion.txt` (5 líneas de notas, sin transcripción) · **Ausentes con tema en agenda:** no hay agenda escrita; la única persona con compromiso abierto que no estuvo es Diana Molina («Actualizar la matriz 6», sin fecha desde el 2026-09-18).

Términos: vigentes para la versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya existente; no hubo que registrarlo de nuevo).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Camilo Beltrán | Cerrar la prueba 2 | 2027-01-09 | **Reprogramado por 6.ª vez** (original 2026-10-07; luego 10-25, 11-10, 11-24, 12-13, 12-26 y 2027-01-09). Cita: «lo de "cerrar la prueba 2" no alcanzó, se compromete para el 09/01/2027» |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-11-02». Las notas no dicen de cuál proveedor se trata (el proyecto tiene dos: Integra Sistemas, CT-360, y Talento Digital, CT-127) |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana». «La otra semana» no es una fecha; se registra `no_declarada` y no se le inventa una |

## Decisiones
Ninguna. Las notas no registran ninguna decisión.

## Quedó sin decidir
Nada se registró como pendiente de decisión.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («se comentó…, nadie lo anotó como riesgo») | No dicho: «se comentó» no atribuye la frase a nadie | Riesgo | No. Ningún documento del proyecto lo recoge. Lo más cercano es el riesgo del informe de avance del 2026-10-20, «el proveedor no ha confirmado la fecha de la última entrega», que es otra cosa. Queda en la ficha como riesgo dicho en reunión, **sin dueño**. Tampoco se sabe de cuál proveedor habla |

## Cerrado en esta reunión
Nada. Las notas no traen ningún documento que cierre un compromiso, así que no se cerró ninguno.

## Lo que esta reunión contradice
Nada contra el expediente. Laura Vélez sigue siendo la patrocinadora que consta en el acta de constitución. Una observación sobre la cadencia: «próxima reunión en dos semanas» (2026-11-06) coincide con `committee_next` de la configuración, pero el comité estaba configurado como semanal y las seis minutas anteriores son de viernes consecutivos.

## Sin resolver de la transcripción
- «09/01/2027»: leído día/mes (9 de enero de 2027), como el resto de las fechas del proyecto; leído mes/día sería el 1 de septiembre de 2027, después del cierre del proyecto (2027-01-25). Hay que confirmarlo con Camilo Beltrán.
- «la otra semana» (Laura Vélez): sin fecha.
- «el proveedor» (Óscar Ramírez y el riesgo del equipo incompleto): sin nombre.
- «se comentó…»: sin autor. Quién lo dijo no se puede atribuir.
- Las notas no mencionan los compromisos que vencían hoy: Andrés Lozano «Revisar el anexo 19» y Ricardo Salas «Confirmar la fecha 23» (ambos 2026-10-23). Sin nota ni documento, siguen abiertos.

---
**Recalculado** (`compute`, sin `record_issues`): 4 compromisos vencidos, 3 sin fecha (Diana Molina, Beatriz Cuéllar, Laura Vélez) y 3 movidos 3 veces o más (Ricardo Salas ×4, Camilo Beltrán ×6, Beatriz Cuéllar ×5). La ficha ya tenía estas entradas desde `/pm-setup`, que leyó las mismas notas; el acta no la cambió. El informe del 2026-10-20 declara verde y sigue contradicho por esas señales.

**Siguiente:** `/pm-commitments` para el seguimiento completo. No hace falta `/pm-publish` por esta reunión: ningún campo de la ficha cambió. El acta sale en la conversación y la guardas tú; no escribí nada en la carpeta de reuniones.
