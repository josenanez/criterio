## Billetera y QR (PRY-206) · 2026-10-23

Términos vigentes para la versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya existente; no se registró de nuevo).

**Revisé:** 17 documentos · 17 nuevos para el índice (es el primer barrido: ninguno estaba sellado) · 0 minutas sin extraer. Las seis actas del comité (09-11 a 10-16) y las notas del 10-23 ya estaban en la ficha desde las corridas de hoy (`pm-minutes`, `pm-commitments`); no las volví a extraer.

### Lo que se venció solo
Nada nuevo desde la corrida de `pm-commitments` de hoy; `compute` da las mismas cifras. Sigue abierto, con su cita en la ficha:

- **Vencidos sin evidencia (4):** Camilo Beltrán, aprobar el diseño 5 (17 días); María Restrepo, aprobar el diseño 13 (14); Rubén Cárdenas, validar el ambiente 12 (13); Andrés Lozano, cerrar la prueba 10 (8).
- **Reprogramados 3 o más veces (3):** Camilo Beltrán, cerrar la prueba 2 (6 veces); Beatriz Cuéllar, validar el ambiente 4 (5); Ricardo Salas, enviar el documento 1 (4).
- **Vencen hoy o mañana:** Andrés Lozano, anexo 19 (hoy); Ricardo Salas, fecha 23 (hoy); Liliana Torres, fecha 7 (10-24).
- **Hitos dados por cumplidos sin evidencia:** «Ambiente de pruebas certificado» (73 días) e «Integración con el core» (18 días).
- **Proveedor Talento Digital (CT-127):** licenciamiento del motor, 108 días tarde; bolsa de horas, 31 días tarde.
- **Estado declarado:** el informe del 2026-10-20 dice verde; cuatro tipos de señal lo contradicen.

### La reunión
El comité es el 2026-11-06, dentro de 14 días, y el informe toca el 2026-11-05. Todavía no corresponde ofrecer `/pm-agenda`. Las notas del 10-23 ya están tratadas, así que no falta acta.

### Tu ficha publicada
No se quedó vieja: `/pm-publish` corrió hoy y la ficha no cambió desde entonces.

### Lo que no sé
- El índice no quedó sellado: `meta.documents_seen` sigue vacío. Mañana el índice volverá a listar los 17 documentos como nuevos hasta que una lectura completa los selle.
- La fecha «09/01/2027» de Camilo Beltrán se leyó día/mes; sigue por confirmar con él.

**Vuelvo el 2026-10-24.**
