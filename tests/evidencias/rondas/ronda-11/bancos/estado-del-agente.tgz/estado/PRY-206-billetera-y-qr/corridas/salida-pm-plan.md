# Plan — Billetera y QR (PRY-206) · borrador del 2026-10-23
**Desde:** acta de constitución del 2026-04-12 (`00-gobierno/2026-04-12-acta-constitucion.md`) · **Criterio de éxito:** «Billetera y QR en producción y medido» (acta, sección Criterio de éxito). No dice qué se mide, con qué umbral ni cuándo.

Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hizo falta volver a pedirlos.

**Contexto que cambia cómo leer este borrador:** el proyecto ya está en ejecución (inicio 2026-04-22, tres hitos cerrados según `10-plan/2026-04-12-cronograma-v1.xlsx`). Esto no es un plan previo al arranque, sino la WBS que el acta y los documentos sostienen hoy. Sirve para ver qué quedó sin definir y se construyó igual.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío:** «Componente 1 / 2 / 3» son marcadores, no componentes | No se puede descomponer el alcance desde el acta. La WBS de abajo sale de los hitos del cronograma y de los contratos, no del acta. |
| **Objetivo del negocio circular:** «Entregar billetera y qr para Canales Digitales» | No dice qué problema resuelve. No hay nada contra qué decidir qué entra y qué no. |
| **Fuera de alcance vacío:** «Lo que otro proyecto cubre» | No dice cuál proyecto ni qué cubre. Un entregable puede estar duplicado o huérfano sin que nadie lo vea. |
| **Criterio de éxito sin métrica:** «en producción y medido» | «Medido» no tiene indicador, línea de base ni plazo. Nadie puede declarar el cierre sin discutir qué se midió. |
| **Autoridad del gerente no declarada** | No se sabe qué puede decidir quien planifica y qué debe subir al Comité de Medios de Pago. |
| **Dependencias: «Ninguna declarada»**, con dos contratos de proveedor en curso (CT-127 y CT-360) | Los dos contratos son dependencias externas de hecho. El plan las hereda como ocultas. |
| Patrocinador: Laura Vélez | Declarado. No falta. |

Sigo adelante marcando cada hueco y sin rellenarlo.

## WBS
Nodos terminales = algo que alguien recibe y acepta.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Recibido por Gustavo Neira (acta de recibo 2026-10-14). El aprobador de negocio: **sin definir** | Cronograma v1 (hito). **No está en el acta.** | vacía |
| 2 | Ambiente de pruebas certificado | **Sin definir** (no hay acta de recibo en la carpeta) | Cronograma v1 (hito) | vacía |
| 3 | Integración con el core | **Sin definir** (no hay acta de recibo en la carpeta) | Cronograma v1 (hito) | vacía |
| 4 | Licenciamiento del motor — Integra Sistemas (CT-360) | Gerente del proyecto firma el recibo (cláusula de pago de CT-360) | Contrato CT-360 · fecha contractual 2026-08-02 · estado «recibido» | Fecha contractual, no duración |
| 5 | Licenciamiento del motor — Talento Digital (CT-127) | Gerente del proyecto firma el recibo (cláusula de pago de CT-127) | Contrato CT-127 · fecha contractual 2026-07-07 · estado «pendiente» | Fecha contractual, no duración |
| 6 | Bolsa de horas de desarrollo — Talento Digital (CT-127) | Gerente del proyecto | Contrato CT-127 · fecha contractual 2026-09-22 · «pendiente» | Fecha contractual, no duración |
| 7 | Bolsa de horas de desarrollo — Integra (CT-360) | Gerente del proyecto | Contrato CT-360 · fecha contractual 2026-11-12 · «en curso» | Fecha contractual, no duración |
| 8 | Parametrización del tarifario — Talento Digital (CT-127) | Gerente del proyecto | Contrato CT-127 · fecha contractual 2026-12-07 · «en curso» | Fecha contractual, no duración |
| 9 | Piloto con usuarios internos | **Sin definir** | Cronograma v1 (hito) | vacía |
| 10 | Salida a producción | **Sin definir** (el patrocinador es Laura Vélez, pero el acta no dice que ella acepte) | Acta: cierre 2027-01-25 · cronograma v1 | vacía |
| 11 | Medición en producción | **Sin definir** | Acta (criterio «medido»). Indicador y plazo: **sin definir** | vacía |
| 12 | Componentes 1, 2 y 3 del alcance | **Sin definir** | Acta, pero son marcadores sin contenido | vacía |

Los nodos 4 a 8 son entregables de proveedor, aceptables por definición contractual. Los nodos 1 a 3 y 9 a 11 son hitos del cronograma. Que un hito tenga fecha no quiere decir que alguien lo haya definido como entregable aceptable.

## Orden
Es una propiedad del trabajo, sin fechas. Ninguna dependencia está declarada en el acta, así que todo lo de abajo es **supuesto**.
- 1 antes que 2 y 3: el diseño funcional precede a lo que se construye y certifica. (Supuesto)
- 4/5 (licenciamiento) antes que 6/7 (bolsa de horas) y que 8 (tarifario): sin motor licenciado no hay desarrollo ni parametrización. (Supuesto)
- 2 y 3 antes que 9: el piloto necesita ambiente certificado e integración con el core. (Supuesto)
- 6, 7 y 8 antes que 9. (Supuesto)
- 9 antes que 10, y 10 antes que 11. (Supuesto)

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| El orden de dependencias de arriba es el real | La ruta crítica está mal y el cierre del 2027-01-25 se evalúa contra una secuencia que no es. |
| Los cinco entregables de proveedor son los de este proyecto y ninguno es duplicado: «Licenciamiento del motor» aparece en CT-360 y en CT-127, y «Bolsa de horas» también | Si es el mismo producto contratado dos veces, hay costo duplicado (CT-360 suma 142.614.518 COP y CT-127 285.628.749 COP, 428.243.267 COP en total, que es el 53,5 % del presupuesto de 800.000.000). |
| Las fechas contractuales de los proveedores siguen vigentes | Un nodo que figura «pendiente» con fecha vencida (CT-127 licenciamiento, 2026-07-07; bolsa de horas, 2026-09-22) arrastra a todos los que dependen de él. |
| El «Diseño funcional aprobado» del cronograma y el del acta de recibo del 2026-10-14 son el mismo entregable | El cronograma lo marca cerrado el 2026-06-16, pero el acta de recibo es del 2026-10-14. Si son el mismo, el hito se cerró cuatro meses antes de recibirse. |
| Gustavo Neira puede firmar los recibos de proveedor sin otra aprobación | El acta no declara su autoridad. Si hay un tope, hay recibos firmados sin autoridad. |

Pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 del alcance | Patrocinador (Laura Vélez) con el gerente |
| Qué queda fuera de alcance y qué proyecto lo cubre | Patrocinador / Comité de Medios de Pago |
| Indicador, umbral y plazo de «medido» | Patrocinador / Canales Digitales |
| Quién acepta cada hito de negocio (nodos 1, 2, 3, 9, 10) | Patrocinador |
| Autoridad del gerente al planificar y al recibir | Comité de Medios de Pago |
| Dependencias externas del proyecto | Gerente, con el patrocinador |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-206 no apunta a una carpeta de fichas de la PMO, y no fui a buscar proyectos por el disco. Es la respuesta correcta y evita una falsa precisión: no hay un «a otros les tomó N días» que citar.

## Preguntas para el equipo
Una por cada duración vacía.
1. ¿Cuánto toma certificar el ambiente de pruebas (nodo 2)? ¿Existe acta de recibo?
2. ¿Cuánto toma la integración con el core (nodo 3) y quién la acepta?
3. ¿Cuánto dura el piloto con usuarios internos (nodo 9), y qué resultado lo da por aceptado?
4. ¿Cuánto toma pasar de piloto a salida a producción (nodo 10), con qué ventana?
5. ¿Cuánto tiempo hay que medir en producción (nodo 11) para dar el criterio por cumplido, y con qué indicador?
6. ¿Cuánto toma cada componente del alcance (nodo 12)? Primero, ¿cuáles son?
7. Para los nodos de proveedor: ¿las fechas contractuales siguen vigentes? ¿Cuántas semanas de trabajo implica cada una?
8. ¿«Licenciamiento del motor» de CT-127 y de CT-360 es el mismo licenciamiento? ¿Por qué hay dos contratos?
9. ¿Por qué el cronograma cierra «Diseño funcional aprobado» el 2026-06-16 si el acta de recibo es del 2026-10-14?

## Para comprometer una fecha falta
- La **disponibilidad real del equipo**. El informe de avance del 2026-10-20 menciona una rotación que costó dos semanas y concentración del conocimiento en una sola persona; no hay un documento con la capacidad actual.
- La **confirmación de fecha de cada proveedor**. El mismo informe dice que el proveedor no ha confirmado la fecha de su última entrega. En la reunión del 2026-10-23 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo anotó como riesgo.
- La **ventana del ambiente de producción** y del piloto.
- La definición del criterio «medido», porque sin ella no se sabe cuándo termina el último nodo.

Ninguna de las cuatro está en un documento. La fecha de cierre del 2027-01-25 sigue siendo la del acta; este borrador no la confirma ni la mueve. Comprometer una fecha es decisión del gerente.

## Después
Si el plan se aprueba, puede registrarse como línea base y los supuestos pasar al RAID con doliente. Hoy la línea base vigente es el cronograma v1, con fecha de línea base igual a fecha vigente en los cinco hitos. Este borrador no la toca.
