Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

(Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta y la digo en una línea.)
- Carpeta: la que vino en el argumento, `documentos/proyectos/PRY-206-billetera-y-qr`.
- Quién eres y qué proyecto es: Gustavo Neira, gerente de PRY-206 · Billetera y QR (acta de constitución del 2026-04-12).
- Reunión de seguimiento: los viernes (todas las minutas son de viernes). La notas del 2026-10-23 dicen «próxima reunión en dos semanas»: la anoté para el 2026-11-06.
- Dónde guardo lo que encuentro: `estado/PRY-206-billetera-y-qr`, junto a los documentos y fuera de `.criterio/`.
- Marca de carpeta (`_CRITERIO_PROYECTO.txt`): no la dejé; nadie autorizó escribir dentro de los documentos. Se puede pedir después.

**Términos** (versión 1.2, plugin 0.8.0):
Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se prueba antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
Aceptación: José Francisco Ñáñez, 2026-10-23, indicada en la instrucción de esta prueba.

## Listo — PRY-206 · Billetera y QR

**Lo que miré:** 16 documentos (.md 11, .pdf 2, .docx 1, .xlsx 1, .txt 1) · 7 reuniones (6 minutas del comité semanal, 2026-09-11 a 2026-10-16, y las notas del 2026-10-23) · la última del 2026-10-23. Leí todas, de la más vieja a la más nueva. Ninguna sin poder leer.
**Términos:** aceptados para la versión 0.8.0 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 c83631fe2c4cd4b0… (md) y e1748c5331c09218… (pdf)

Ficha escrita en `estado/PRY-206-billetera-y-qr/records/PRY-206.json`: 26 compromisos, 2 cumplidos con acta, 24 en pie. No la sellé: leí las reuniones, no el proyecto entero.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Camilo Beltrán | Cerrar la prueba 2 | 2027-01-09 (era 2026-10-07) | **Movido 6 veces**: 10-25, 11-10, 11-24, 12-13, 12-26, 2027-01-09. Última en las notas del 2026-10-23, escrita «09/01/2027» (la leí día/mes; confírmalo). La salida a producción es el 2027-01-25 |
| Ricardo Salas | Enviar el documento 1 | 2026-11-30 (era 2026-09-26) | **Movido 4 veces**: 10-17, 10-26, 11-15, 11-30 (minutas del 09-18 al 10-16; nació «por definir» el 09-11) |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-11-30 (era 2026-10-07) | **Movido 5 veces**: 10-22, 10-29, 11-08, 11-18, 11-30 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-10-06 | **Vencido hace 17 días sin acta.** El 10-09 salió de la tabla con «dice que ya entregó… No se presentó acta». El acta del 10-14 nombra el entregable «Diseño funcional aprobado», no este compromiso |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-15 | **Vencido hace 8 días**, sin acta (minuta 2026-10-16) |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-10 | **Vencido hace 13 días**, sin acta (minuta 2026-10-16) |
| María Restrepo | Aprobar el diseño 13 | 2026-10-09 | **Vencido hace 14 días**, sin acta (minuta 2026-10-16) |
| Gustavo Neira | Revisar el anexo 3 | 2026-11-06 (era 2026-09-29) | 1 vez; la fecha original ya estaba vencida en las minutas del 10-02 y 10-09 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-24 (era 2026-10-05) | 1 vez; vence mañana |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-25 (era 2026-10-01) | 2 veces: 10-14, 10-25 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-30 (era 2026-10-22) | 1 vez |
| Carlos Peña | Actualizar la matriz 14 | 2026-11-01 (era 2026-10-19) | 1 vez |
| Carlos Peña | Entregar el punto 16 | 2026-11-05 (era 2026-10-29) | 1 vez |
| Liliana Torres | Cerrar la prueba 18 | 2026-11-14 (era 2026-11-04) | 1 vez |
| Andrés Lozano | Revisar el anexo 19 | 2026-10-23 (era 2026-10-13) | 1 vez; vence hoy |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-23 | vence hoy |
| Jorge Medina | Enviar el documento 17 | 2026-10-28 | — |
| Jorge Medina | Aprobar el diseño 21 | 2026-11-07 | — |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-10 | — |
| Javier Hoyos | Entregar el punto 24 | 2026-11-06 | — |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | notas 2026-10-23 |

Cumplidos con acta: Entregar el punto 8 (María Restrepo, acta de recibo 2026-10-02) y Validar el ambiente 20 (Javier Hoyos, acta de recibo 2026-10-16). Los cierres los pruebó un acta, no la palabra de nadie.

### Sin fecha
Nadie las fechó; no pueden estar vencidas, y por eso mismo se pierden en los informes:
- Diana Molina — Actualizar la matriz 6 (desde 2026-09-18). El 09-25 dijo que ya la entregó; no hay acta.
- Beatriz Cuéllar — Confirmar la fecha 15 (3 reuniones seguidas «por definir», desde 2026-10-02).
- Laura Vélez — Mandar el ajuste del presupuesto («la otra semana», notas 2026-10-23).

### Lo que la ficha muestra contra el informe del 2026-10-20 (Verde, 84%)
Esto es lo que declaras tú; yo te muestro contra qué. No lo cambié.
- Verde con 4 grupos de señales que el informe no menciona: compromisos vencidos, compromisos movidos 3 veces o más, hitos cerrados sin acta y entregables de proveedor atrasados.
- El cronograma sostiene entre 60 % y 80 % con 3 de 5 hitos cerrados; el informe dice 84 %.
- Hitos declarados «cerrado» sin un acta que lo pruebe: **Ambiente de pruebas certificado** (2026-08-11) e **Integración con el core** (2026-10-05). El acta del 2026-10-16 es de «Validar el ambiente 20», un compromiso, no de ese hito. El acta del 2026-10-14 sí prueba «Diseño funcional aprobado».
- Proveedores: Talento Digital S.A.S. (CT-127) tiene «Licenciamiento del motor» (vencía 2026-07-07, 108 días) y «Bolsa de horas de desarrollo» (vencía 2026-09-22, 31 días) sin entregar. Integra Sistemas (CT-360) tiene «Licenciamiento del motor» declarado recibido sin acta.
- Presupuesto, tal como lo dice el informe: aprobado 800.000.000 COP, comprometido 286.830.892, ejecutado 261.382.619 (32,7 %), proyección 739.687.135 (7,5 % por debajo del aprobado).
- En las notas del 2026-10-23 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y nadie lo anotó como riesgo; lo dejé en la ficha como riesgo dicho en reunión, sin dueño.

### Qué le falta a tu carpeta
- Acta de recibo del Licenciamiento del motor de CT-360: el contrato factura cada entregable contra acta firmada y la factura FV-1360 (71.307.259 COP, 2026-09-24) ya está radicada.
- Actas de recibo de los hitos «Ambiente de pruebas certificado» e «Integración con el core».
- Actas o correos que cierren los 4 compromisos vencidos y los 2 que dicen «ya entregué».
- Un cronograma vigente: el único es la v1 del 2026-04-12 y no tiene una sola fecha movida, mientras los compromisos se mueven cada semana.
- El acta de constitución trae alcance de relleno («Componente 1, 2, 3»), sin facultad del gerente (hasta qué monto decide sin subir a comité) ni etapa. Quedaron como «no encontrado».
- Estructura recomendada (`document-intake`): ya la tienes; `00-gobierno`, `10-plan`, `20-seguimiento`, `30-reuniones`. Solo `2026-10-23-notas-reunion.txt` está suelto en la raíz; su sitio es `30-reuniones/`. No lo moví.

**Cuándo vuelvo:** el viernes 2026-11-06, la próxima reunión que dijeron las notas; antes, el jueves 2026-11-05 para dejarte el informe.
