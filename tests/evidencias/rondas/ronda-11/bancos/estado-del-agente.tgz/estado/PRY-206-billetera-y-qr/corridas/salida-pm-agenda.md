## Reunión de seguimiento — Billetera y QR (PRY-206) · 2026-11-06
11 puntos (3 de fondo, 5 vencidos, 2 decisiones breves, 1 renglón preventivo) · 60 minutos · 9 personas requeridas

Términos: vigentes para la versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya existente; no hubo que registrarlo de nuevo).

Supuestos que tomé, porque nadie los dijo: la fecha es la del próximo comité configurado (2026-11-06, `committee_next`), el tiempo es 60 minutos (no se pidió límite) y la próxima reunión después de esa sería dos semanas más tarde (2026-11-20). Las cifras son **al 2026-10-23**: no hay corrida anterior, así que `diff` no tiene con qué comparar y no puedo decir qué cambió desde la reunión pasada. Vuelve a correr el comando el 11-05 para que la agenda refleje lo que se movió esta semana.

### Lo que no se destraba solo

> **1. Camilo Beltrán: un cierre de la prueba 2 con fecha que se sostenga, y el diseño 5 con acta o sin ella** · 10 min · **Camilo Beltrán**
> Prometido para el 2027-01-09, y antes para el 2026-12-26, el 12-13, el 11-24, el 11-10 y el 10-25; la primera promesa fue el 2026-10-07. **Seis reprogramaciones.** Además, «Aprobar el diseño 5» venció el 2026-10-06 (hoy 17 días); Camilo dice que lo entregó y no hay acta que lo respalde.
> Fuente: actas del 09-18, 09-25, 10-02, 10-09, 10-16 y notas del 10-23 (`2026-10-23-notas-reunion.txt`). Sobre el diseño 5: acta del 10-09.
> **Qué tiene que quedar resuelto:** el motivo por el que la prueba 2 no cierra (las actas registran la fecha nueva, nunca el motivo); si es un bloqueo ajeno a Camilo, quién lo quita; y la fecha «09/01/2027» confirmada como 9 de enero (leída mes/día caería después del cierre del proyecto, 2027-01-25). Del diseño 5: el acta, o que se diga que no existe.
> **Si no se resuelve hoy:** la prueba 2 llega a la séptima promesa, y el piloto del 2026-11-30 y la salida del 2027-01-25 dependen de pruebas que nadie sabe cuándo cierran.

> **2. Beatriz Cuéllar: qué trabó el ambiente 4** · 10 min · **Beatriz Cuéllar**
> Prometido para el 2026-11-30, y antes para el 11-18, el 11-08, el 10-29 y el 10-22; la primera promesa fue el 2026-10-07. **Cinco reprogramaciones.** Lleva además «Enviar el documento 9» (movido dos veces, vence el 10-25) y «Confirmar la fecha 15», sin fecha desde el 10-02.
> Fuente: actas del 09-18, 09-25, 10-02, 10-09 y 10-16.
> **Qué tiene que quedar resuelto:** el motivo del atraso del ambiente 4, y si es la misma causa que frena la prueba 2 de Camilo (no consta); fecha real para la fecha 15, que lleva tres reuniones en «por definir».
> **Si no se resuelve hoy:** tres compromisos de una misma persona siguen avanzando sin que nadie sepa qué los frena.

> **3. Ricardo Salas: el documento 1** · 6 min · **Ricardo Salas**
> Prometido para el 2026-11-30, y antes para el 11-15, el 10-26 y el 10-17; la primera promesa fue el 2026-09-26. **Cuatro reprogramaciones.** «Confirmar la fecha 23» vencía el 10-23 y las notas de ese día no lo mencionan.
> Fuente: actas del 09-25, 10-02, 10-09 y 10-16.
> **Qué tiene que quedar resuelto:** qué falta para enviarlo y quién lo está reteniendo; estado de la fecha 23.
> **Si no se resuelve hoy:** queda a cuatro semanas de la primera fecha y sin motivo registrado.

Tres personas con tres o más reprogramaciones no son un problema de seguimiento. Si en estos puntos aparece un bloqueo que no se puede quitar desde la sala, no se resuelve aquí: sube como decisión (ver «No es de esta reunión»).

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Talento Digital S.A.S. (CT-127), vía **Óscar Ramírez** | Licenciamiento del motor (vencía 2026-07-07) y bolsa de horas de desarrollo (vencía 2026-09-22), ambos «pendiente» | 108 y 31 días | Fecha firme del proveedor o decisión de qué hacer con el contrato; no hay nada facturado a este proveedor | 8 |
| **Gustavo Neira** | Hitos «Ambiente de pruebas certificado» (2026-08-11) e «Integración con el core» (2026-10-05) declarados cumplidos sin documento; y el «Licenciamiento del motor» de Integra Sistemas (CT-360) aceptado y facturado (COP 71.307.259) sin acta de recibo | 73, 18 días | El documento que respalda cada uno, o la corrección del estado | 4 |
| **María Restrepo** | Aprobar el diseño 13 | 2026-10-09 (14 días) | Aprobación con acta, o fecha nueva dicha por ella | 4 |
| **Rubén Cárdenas** | Validar el ambiente 12 | 2026-10-10 (13 días) | Evidencia de la validación, o fecha nueva dicha por él | 4 |
| **Andrés Lozano** | Cerrar la prueba 10 | 2026-10-15 (8 días) | Cierre con evidencia, o fecha nueva dicha por él | 4 |

Fuentes: Talento Digital y Integra, `00-gobierno/2026-04-21-contrato-ct-127.md` y `2026-04-20-contrato-ct-360.docx`, factura `20-seguimiento/2026-09-24-factura-ct-360.md`; hitos, `10-plan/2026-04-12-cronograma-v1.xlsx` (la única acta de recibo del expediente cubre «Diseño funcional aprobado», 2026-10-14); compromisos vencidos, actas del 09-25 (prueba 10, ambiente 12) y 10-02 (diseño 13). Óscar Ramírez tiene «Revisión con el proveedor» para el 2026-11-02 y las notas no dicen de cuál proveedor; ese dato es lo primero que hay que preguntarle.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha del ajuste del presupuesto: Laura Vélez dijo «la otra semana» el 10-23 y nadie dijo una fecha | **Laura Vélez** | Seguirá sin fecha y sin poder vencerse. La proyección declarada es COP 739.687.135 de COP 800.000.000 aprobados | 3 |
| Dueño y proveedor del riesgo «podría no llegar con el equipo completo para la siguiente fase», dicho el 10-23 («se comentó», sin autor) y no registrado; tampoco lo tienen los otros tres riesgos y la incidencia de rotación | **Gustavo Neira** | Cuatro registros RAID sin dueño; nadie responde si se materializan | 3 |

### Vence antes de la próxima
Calculado contra el 2026-11-20 (supuesto).

| Quién | Qué | Para cuándo |
|---|---|---|
| Jorge Medina | Aprobar el diseño 21 | 2026-11-07 |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-10 |
| Integra Sistemas (CT-360) | Bolsa de horas de desarrollo (pendiente) | 2026-11-12 |
| Liliana Torres | Cerrar la prueba 18 (ya movida una vez, desde el 11-04) | 2026-11-14 |

Va en la agenda como un solo renglón de 2 minutos: preguntar a cada uno si llega.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Causa del bloqueo si la tienen fuera de la sala (puntos 1 a 3) | Las actas no registran el motivo; si lo que frena a Camilo, Beatriz o Ricardo es una decisión o un recurso que no tiene el gerente, excede su autoridad | `/criterio-project:pm-escalate`; el comité sigue siendo el del 2026-11-06 si es el mismo |
| Diana Molina: «Actualizar la matriz 6», sin fecha desde el 2026-09-18 | No estuvo el 10-23 y no consta que vaya a estar el 11-06; sin ella nadie en la sala puede mover el punto. Dijo que ya entregó (acta del 09-25), sin acta | Se le pregunta por fuera de la reunión antes del 11-06; entra solo si confirma asistencia |
| Declaración «verde» del informe del 2026-10-20 contra las señales de compromisos, hitos e hitos de proveedor | El estado lo declara el gerente; la reunión no lo decide | `/criterio-project:pm-report`, línea de estado |
| Quién es la autoridad del proyecto y la fase | `identity.authority` e `identity.phase` no constan en ningún documento | Gustavo Neira, o el acta de constitución |

### Anexo — sin comparación previa
No hay corrida anterior; lo siguiente no es punto de agenda porque su doliente no la necesita para avanzar, no porque se haya verificado que está igual que la semana pasada. Una línea cada uno, no se repasa.
- Gustavo Neira: Revisar el anexo 3, 2026-11-06 (movida una vez, del 09-29).
- Carlos Peña: Actualizar la matriz 14, 2026-11-01 (movida una vez); Entregar el punto 16, 2026-11-05 (movida una vez).
- Paula Céspedes: Revisar el anexo 11, 2026-10-30 (movida una vez).
- Jorge Medina: Enviar el documento 17, 2026-10-28.
- Liliana Torres: Confirmar la fecha 7, 2026-10-24 (movida una vez).
- Javier Hoyos: Entregar el punto 24, 2026-11-06.
- Andrés Lozano: Revisar el anexo 19, 2026-10-23 (movida una vez; vencía hoy y las notas no lo mencionan).
- Cerrados con documento: Entregar el punto 8 (María Restrepo, `20-seguimiento/2026-10-02-acta-recibo-8.md`) y Validar el ambiente 20 (Javier Hoyos, `20-seguimiento/2026-10-16-acta-recibo-20.md`).

### Tiempo
Puntos 1 a 3: 26 min. Vencido: 24 min. Decisiones: 6 min. Vence antes de la próxima: 2 min. Cierre y acuerdos: 2 min. **Total 60 min.** Nada quedó fuera por tiempo.

**Observación sobre la cadencia:** la configuración dice comité semanal y las seis actas previas son de viernes consecutivos, pero las notas del 10-23 dicen «próxima reunión en dos semanas», que es el 2026-11-06. Si pasa a quincenal, conviene cambiar la configuración; hoy `due` sigue calculando semanal.

**Lo que no sé:** si los dolientes estarán el 11-06, de cuál proveedor habla Óscar, y por qué se mueve cada fecha. El comando no convoca a nadie: citar es del gerente.

**Después de la reunión:** `/criterio-project:pm-minutes` sobre la transcripción o las notas, para que los compromisos entren a `/criterio-project:pm-commitments` con su cita.
