# Billetera y QR (PRY-206) — semana del 2026-10-16 al 2026-10-23

**Declara el gerente (Gustavo Neira):** *sin declaración esta semana.* En esta sesión nadie respondió la pregunta de declaración, así que la línea queda en blanco y este informe no propone ningún estado.
**Última declaración en la ficha (no es de esta semana):** verde · 84 % · al 2026-10-20, de `20-seguimiento/2026-10-20-informe-avance.pdf` (3 días de antigüedad, vigente).
**Sustento documental de esa última declaración:** contradicho en parte. Hay 0 fuentes de evidencia y 5 de declaración; las otras 244 no están marcadas.
**Lo que el semáforo declarado no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia y entregables de proveedor vencidos.

## Qué cambió esta semana
No se puede decir qué cambió. Esta es la primera corrida de informe sobre este proyecto: solo existe la foto de hoy (`snapshots/2026-10-23.json`) y la comparación contra ella misma da 0 cambios. La comparación empieza con la próxima corrida.

## Lo que sigue igual y sigue mal
Sin corrida anterior no hay días acumulados «así». Lo que sigue mal, con los días medidos hasta hoy:
| Qué | Desde | Días así |
|---|---|---|
| Hito «Ambiente de pruebas certificado» declarado cumplido, sin evidencia | vence 2026-08-11 | 73 |
| Hito «Integración con el core» declarado cumplido, sin evidencia | vence 2026-10-05 | 18 |
| Entregable «Licenciamiento del motor» (Talento Digital), pendiente | vence 2026-07-07 | 108 |
| Entregable «Bolsa de horas de desarrollo» (Talento Digital), pendiente | vence 2026-09-22 | 31 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-25 | 2027-01-25 | 0 días / 0 días |
| Presupuesto | COP 800.000.000 | COP 800.000.000 | proyección 739.687.135 (−7,5 %) |

Replanificaciones: 0. Las dos líneas coinciden porque nunca se movió la base, no porque el plan se haya cumplido. Los hitos «cumplidos» sin evidencia quitan fuerza a esa coincidencia.

Avance declarado 84 %. El plan sostiene entre 60 y 80 % (3 de 5 hitos cumplidos), y 2 de esos 3 no tienen evidencia. Sin esos dos, el plan sostiene menos.

### Hitos de las próximas cuatro semanas
Ninguno vence hasta el 2026-11-20. El siguiente es «Piloto con usuarios internos»: base 2026-11-30, vigente 2026-11-30, pendiente, sin evidencia (38 días). Después viene «Salida a producción», 2027-01-25.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 286.830.892 (35,9 %) | 261.382.619 (32,7 %) | 739.687.135 | **513.169.108** (aprobado − comprometido) |

Las cifras de comprometido, ejecutado y proyectado salen del informe de avance del gerente (declaración), no de un documento contable.

## Abierto
**Reprogramados:**
- Camilo Beltrán, «Cerrar la prueba 2»: 6 veces. Original 2026-10-07, hoy 2027-01-09.
- Beatriz Cuéllar, «Validar el ambiente 4»: 5 veces. Original 2026-10-07, hoy 2026-11-30.
- Ricardo Salas, «Enviar el documento 1»: 4 veces. Original 2026-09-26, hoy 2026-11-30.

**Vencidos sin evidencia:**
- Camilo Beltrán, «Aprobar el diseño 5»: venció 2026-10-06, 17 días (comité del 2026-09-18).
- María Restrepo, «Aprobar el diseño 13»: venció 2026-10-09, 14 días (comité del 2026-10-02).
- Rubén Cárdenas, «Validar el ambiente 12»: venció 2026-10-10, 13 días (comité del 2026-09-25).
- Andrés Lozano, «Cerrar la prueba 10»: venció 2026-10-15, 8 días (comité del 2026-09-25).

**Sin fecha:** Diana Molina, «Actualizar la matriz 6»; Beatriz Cuéllar, «Confirmar la fecha 15»; Laura Vélez, «Mandar el ajuste del presupuesto».

**RAID:** la ficha trae 3 riesgos y 1 incidencia, ninguno con dueño, y no puedo medir los días sin movimiento. Dos puntos merecen atención:
- La incidencia «el equipo perdió dos semanas por rotación de un desarrollador clave» no tiene fecha de inicio.
- «El proveedor podría no llegar con el equipo completo» se dijo en la reunión del 2026-10-23 y nadie lo registró.

**Proveedor:**
- Talento Digital (CT-127): 0 de 3 entregables aceptados, 2 vencidos (arriba), facturado sin dato.
- Integra Sistemas (CT-360): «Licenciamiento del motor» figura aceptado sin documento de aceptación. Facturado COP 71.307.259, igual al monto aceptado.
- Los dos contratos registran un entregable llamado «Licenciamiento del motor». Conviene confirmar si es el mismo ítem con dos proveedores.

## Lo que necesito de alguien
- **Gustavo Neira:** declarar el estado y el avance de esta semana. La línea está en blanco.
- **Gustavo Neira:** aportar la evidencia de los hitos «Ambiente de pruebas certificado» e «Integración con el core», o corregir su estado.
- **Camilo Beltrán:** decir qué bloquea «Cerrar la prueba 2», que lleva 6 reprogramaciones.
- **Gustavo Neira:** poner dueño a los 3 riesgos y a la incidencia.
- **Quien administre el contrato CT-360:** aportar el documento de aceptación del licenciamiento.
- **Material de comité, no de este informe:** hay compromisos reprogramados 3 o más veces (el umbral es 3). Puedo armar el punto de comité con la decisión formulada.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto y fase; facturado de Talento Digital; dueños de los 3 riesgos y de la incidencia; fecha de inicio de la incidencia.
**Silencio:** el cálculo no entrega los días de silencio (`days_silent` vacío). El documento más reciente es de 2026-10-23 (notas de reunión) y el último comité con acta es el de 2026-10-02.

---
**Origen:** ficha `estado/PRY-206-billetera-y-qr/records/PRY-206.json`, actualizada el 2026-10-23. Campos sin dato: 7. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
