# Corrida del 2026-10-23 · pm-escalate

1 proyectos · 64 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_met_without_evidence` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Dos paquetes: autoridad del gerente no declarada en el acta, y Talento Digital CT-127 vencido. Dijo que no formula el escalamiento de Camilo, Beatriz y Ricardo porque las actas no registran la causa, que no calculó impact porque no recibió días de cambio, y que no tiene cláusulas de penalidad de CT-127.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Para decisión — Billetera y QR (PRY-206) · 2026-10-23

Términos: vigentes para la versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23 (comprobante ya existente). No pasaste un tema ni un cambio, así que revisé lo que las corridas anteriores dejaron como escalable. Salen **dos paquetes** y **un tercer punto que todavía no escala**.

---

## Paquete 1 — La autoridad del gerente (es el primero, y va antes que cualquier otro)

### ¿El Comité de Medios de Pago declara por escrito, antes del 2026-11-06, qué puede decidir Gustavo Neira sin subir al comité —monto máximo para cambios, para firmar recibos de proveedor y para reprogramar hitos—, sí o no, y con qué topes?

**Quién decide:** el Comité de Medios de Pago, que aprobó el acta el 2026-04-12 (acta de constitución). El acta no dice quién puede ampliarla; que sea el comité y no la patrocinadora Laura Vélez sola es una inferencia mía: confírmala. · **Si no se decide hoy:** el 2026-11-12 vence la «Bolsa de horas de desarrollo» de Integra Sistemas (CT-360, COP 71.307.259) y habría que firmar o negar un recibo sin saber si Gustavo puede. Antes de eso, Laura Vélez mandará «la otra semana» el ajuste del presupuesto, sin fecha, y no hay tope contra el cual medirlo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité fija los topes en el comité del 2026-11-06 y lo deja en acta | Sin cambio al alcance del proyecto | Ninguno si se hace el 11-06; la bolsa de CT-360 (11-12) ya queda cubierta | Sin costo directo. Hay una sesión de comité que dedicarle |
| B. Gustavo propone los topes y el comité los ratifica | Igual | Se pierde el 11-06 si la propuesta no está lista antes; el recibo del 11-12 quedaría sin cobertura | Sin costo directo; el trabajo de redactarla es de Gustavo |
| C. Seguir sin facultad declarada | Igual | Ninguno hoy | No consta. Cada recibo y cada reprogramación quedan sin respaldo; el contrato CT-127 dice que cada entregable «se factura contra acta de recibo firmada por el gerente», o sea que esa firma ya está comprometiendo pagos |

**Recomiendo A.** El acta no dice nada de la facultad, el contrato exige la firma de Gustavo para facturar, y el comité del 11-06 cae antes del 11-12. Resolverlo ahí cuesta una línea en el acta.

**Lo que no sé:** qué topes piensa el comité. Tampoco sé si ya existe una política de facultades de la entidad fuera de este expediente; si existe, el paquete se reduce a «aplica esa política» y se cierra con una cita.

---

## Paquete 2 — Talento Digital (CT-127): licenciamiento y bolsa de horas sin entregar

### ¿Se le da a Talento Digital una fecha firme y por escrito para el licenciamiento y la bolsa de horas, o se inicia el trámite de incumplimiento del CT-127?

**Quién decide:** no consta en ningún documento. Si lo que se discute es terminar o renegociar el contrato, excede lo que un gerente puede firmar solo, y por eso el paquete 1 va primero. · **Si no se decide hoy:** el 2026-11-30 es el piloto con usuarios internos y el 2026-12-07 vence «Parametrización del tarifario» del mismo contrato (COP 95.209.583), que depende de un motor aún sin licenciar. Sin decisión antes del 11-06, ese entregable vence con el motor todavía «pendiente».

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fecha firme por escrito, con revisión el 11-06 | Igual | Licenciamiento ya lleva 108 días vencido (era el 2026-07-07) y la bolsa 31 (era el 09-22); la fecha nueva la pone el proveedor, no yo | Nada facturado a Talento Digital (CT-127 no tiene factura en el expediente). No consta costo extra |
| B. Trámite de incumplimiento / cambio de proveedor | El del licenciamiento y la parametrización pasa a otro | No consta. Un proveedor nuevo no cabe entre hoy y el piloto del 11-30 salvo que ya exista | No consta. El contrato CT-127 que tengo no trae cláusula de penalidad ni de terminación, así que no sé qué cuesta salir |

**Recomiendo A,** pero con la fecha de revisión puesta en el comité del 11-06, no abierta. No tengo contrato completo ni causa del atraso; esta recomendación se apoya solo en que B no tiene costo conocido y A no cuesta nada que consten los documentos.

**Antes de llevarlo:** las notas del 10-23 dicen «revisión con el proveedor» para Óscar Ramírez el 2026-11-02 sin nombrar cuál. Si es Talento Digital, esa revisión cae antes del comité y puede cambiar el paquete.

---

## Lo que no escala todavía: los atrasos de Camilo Beltrán, Beatriz Cuéllar y Ricardo Salas

Camilo (prueba 2, seis reprogramaciones), Beatriz (ambiente 4, cinco) y Ricardo (documento 1, cuatro) tienen compromisos movidos 3 o más veces. Eso cumple el criterio de escalar. **Pero no puedo formular la pregunta**: las actas registran la fecha nueva y nunca el motivo, y sin motivo no sé si lo que falta es una decisión, un recurso o solo una llamada. Un punto sin causa conocida es un tema y el comité lo deja para después. Primer paso, tuyo: preguntar a cada uno qué lo frena antes del 2026-11-06. Si el motivo es una decisión o un recurso que no controlas, vuelve a correr este comando con eso en la mano.

También quedó sin resolver una duda de lectura: las notas del 10-23 traen la fecha de Camilo como «09/01/2027». La leí día/mes (9 de enero de 2027), como el resto del proyecto. Leída mes/día cae después del cierre del 2027-01-25. Confírmalo.

---

## A quién alcanza
No lo calculé. `impact` necesita un cambio de fecha con sus días y no recibí ninguno: no inventé uno. El expediente tampoco declara dependencias (el acta dice «Ninguna declarada»). Si el comité acepta mover el piloto del 2026-11-30 o la salida del 2027-01-25, corre `/pm-escalate cambio <fecha>` y ahí sale a quién alcanza.

## Mis hitos por los que pasa
Tampoco calculados, por la misma razón. Hitos pendientes hoy: «Piloto con usuarios internos» (2026-11-30, 38 días) y «Salida a producción» (2027-01-25, 94 días).

## De dónde sale esto
- Autoridad no declarada: acta de constitución `00-gobierno/2026-04-12-acta-constitucion.md` (no trae el campo); la ficha lo marca «no encontrado».
- Comité aprobador y presupuesto de COP 800.000.000: la misma acta.
- Condición de firma del gerente, entregables vencidos y montos de CT-127: `00-gobierno/2026-04-21-contrato-ct-127.md`. Bolsa de horas de CT-360: contrato `00-gobierno/2026-04-20-contrato-ct-360.docx` según la ficha.
- Reprogramaciones y fechas: actas de comité del 09-11 al 10-16 y `2026-10-23-notas-reunion.txt` (presupuesto «la otra semana», revisión con el proveedor del 11-02, fecha 09/01/2027).
- Proyección COP 739.687.135: informe de avance `20-seguimiento/2026-10-20-informe-avance.pdf` (declaración del gerente, no verificada).
- Días de atraso: calculados contra el 2026-10-23.

**Esto no escala solo ni decide.** Llevarlo al comité del 2026-11-06 es tuyo, y la llamada a Talento Digital y a los tres dolientes también.
