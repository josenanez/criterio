Publiqué la ficha en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/bancos/espacio/documentos/proyectos/PRY-206-billetera-y-qr/00-gobierno/ficha-pm.json`, con corte al 2026-10-23.

**Lleva:** 65 campos con dato · 7 sin decir en ninguna parte · declara **verde** al 2026-10-20

**Lo más viejo que va ahí:** identidad (código, nombre, área, producto, patrocinador, gerente, comité) y presupuesto aprobado, del 2026-04-12 (acta de constitución), con menos de un año.

**Antes de publicar:**
- Recalculé la ficha el 2026-10-23.
- `plan.end_date` (2027-01-25) coincide con el único cronograma (v1, 2026-04-12) y con la línea base; no hay cronograma más nuevo.
- Los 7 campos sin decir: `identity.authority`, `identity.phase`, `vendors[1].invoiced`, `raid.risks[0..2].owner`, `raid.issues[0].owner`.

**Lo que la PMO verá y conviene que sepas:** la declaración «verde» es tuya (informe del 2026-10-20) y va marcada como declarada. Los datos calculados la contradicen en cuatro señales: compromisos vencidos y reprogramados, hitos «cumplidos» sin evidencia (Ambiente de pruebas certificado, Integración con el core) y entregables de proveedor atrasados.
