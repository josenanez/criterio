<!-- origen: PRY-206-billetera-y-qr/10-plan/2026-04-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-16 | 2026-06-16 | cerrado
Ambiente de pruebas certificado | 2026-08-11 | 2026-08-11 | cerrado
Integración con el core | 2026-10-05 | 2026-10-05 | cerrado
Piloto con usuarios internos | 2026-11-30 | 2026-11-30 | en curso
Salida a producción | 2027-01-25 | 2027-01-25 | en curso
