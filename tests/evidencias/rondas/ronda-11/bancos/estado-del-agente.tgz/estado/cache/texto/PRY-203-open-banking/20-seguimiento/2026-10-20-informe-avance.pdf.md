<!-- origen: PRY-203-open-banking/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Open Banking
Código: PRY-203
Fecha de corte: 2026-10-20
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 31%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.213.874.130
Ejecutado 1.305.296.383
Proyección al cierre 7.108.979.659

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Dependencia del calendario de liberaciones del core
