<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-07-03-acta-recibo-ct-600-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-201 · Core de depósitos
Fecha de recibo: 2026-07-03
Recibido por: Carlos Peña
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-600 · Redes del Norte Ltda..
