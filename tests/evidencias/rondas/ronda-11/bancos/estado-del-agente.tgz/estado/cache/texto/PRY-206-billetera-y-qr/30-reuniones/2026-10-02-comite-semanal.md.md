<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Gustavo Neira, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-26 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-11-24 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-11-08 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-10-06 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-24 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-14 |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-15 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-30 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-10 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-09 |
| Carlos Peña | Actualizar la matriz 14 | 2026-10-19 |
| Beatriz Cuéllar | Confirmar la fecha 15 | por definir |
| Carlos Peña | Entregar el punto 16 | 2026-10-29 |

## Cerrados en esta reunión

- Entregar el punto 8 (María Restrepo): recibido, acta de recibo del 2026-10-02.
