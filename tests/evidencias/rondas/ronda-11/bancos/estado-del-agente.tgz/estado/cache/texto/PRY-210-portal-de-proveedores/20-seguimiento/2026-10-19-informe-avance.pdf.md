<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de proveedores
Código: PRY-210
Fecha de corte: 2026-10-19
Gerente: Camilo Beltrán

Estado declarado
Rojo
Avance reportado: 63%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.586.790.577
Ejecutado 1.865.371.622
Proyección al cierre 4.224.069.574

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
