<!-- origen: PRY-200-originación-digital/00-gobierno/2026-03-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Banca PyME

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: María Restrepo

Comité: Comité de Banca Empresas

Producto asociado: crédito de consumo

Fecha de aprobación: 2026-03-25

Objetivo del negocio

Entregar originación digital para Banca PyME.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Banca Empresas el 2026-03-25.

Fechas comprometidas

Fecha

Inicio

2026-04-04

Cierre

2027-05-30

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
