<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-09-25
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Gustavo Neira, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-17 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-11-10 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-10-29 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-10-06 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-24 |
| María Restrepo | Entregar el punto 8 | 2026-10-01 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-01 |
| Andrés Lozano | Cerrar la prueba 10 | por definir |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-22 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-10 |

## Lo que se dijo

- Diana Molina dice que ya entregó «actualizar la matriz 6». No se presentó acta.
