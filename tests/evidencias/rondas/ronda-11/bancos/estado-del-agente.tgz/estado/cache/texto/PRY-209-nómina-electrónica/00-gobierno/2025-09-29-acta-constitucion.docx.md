<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-09-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Nómina electrónica

Código: PRY-209

Área dueña: Canales Digitales

Patrocinador: Sandra Gil

Gerente de proyecto: Sandra Gil

Comité: Comité de Medios de Pago

Producto asociado: nómina empresarial

Fecha de aprobación: 2025-09-29

Objetivo del negocio

Entregar nómina electrónica para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Medios de Pago el 2025-09-29.

Fechas comprometidas

Fecha

Inicio

2025-10-09

Cierre

2026-11-29

Criterio de éxito

Nómina electrónica en producción y medido.

Dependencias declaradas

• Ninguna declarada
