<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-19
Gerente: Sandra Gil

Estado declarado
Rojo
Avance reportado: 39%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.496.015.039
Ejecutado 3.284.820.578
Proyección al cierre 17.391.533.403

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
