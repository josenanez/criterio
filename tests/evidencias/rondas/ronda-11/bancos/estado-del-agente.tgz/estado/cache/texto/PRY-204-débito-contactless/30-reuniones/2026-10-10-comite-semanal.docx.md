<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Débito contactless

Fecha: 2026-10-10

Asistentes: Liliana Torres, Mauricio Pérez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Andrés Lozano

Entregar el punto 35

por definir
