<!-- origen: PRY-209-nómina-electrónica/10-plan/2025-09-29-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-12-31,2025-12-31,cerrado
Ambiente de pruebas certificado,2026-03-24,2026-03-24,cerrado
Integración con el core,2026-06-15,2026-06-15,cerrado
Piloto con usuarios internos,2026-09-07,2026-09-07,cerrado
Salida a producción,2026-11-29,2026-11-29,en curso
