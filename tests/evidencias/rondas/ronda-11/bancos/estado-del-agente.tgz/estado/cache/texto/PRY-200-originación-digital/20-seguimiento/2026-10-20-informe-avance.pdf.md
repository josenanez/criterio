<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-10-20
Gerente: María Restrepo

Estado declarado
Amarillo
Avance reportado: 55%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 918.795.629
Ejecutado 918.301.849
Proyección al cierre 3.420.922.062

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- El proveedor no ha confirmado la fecha de la última entrega
