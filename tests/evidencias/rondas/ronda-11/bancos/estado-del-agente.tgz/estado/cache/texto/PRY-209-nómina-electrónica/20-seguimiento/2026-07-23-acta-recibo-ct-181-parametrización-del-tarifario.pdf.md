<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-07-23-acta-recibo-ct-181-parametrización-del-tarifario.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Parametrización del tarifario
Proyecto: PRY-209 · Nómina electrónica
Fecha de recibo: 2026-07-23
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Parametrización del tarifario.
Contrato CT-181 · Núcleo Financiero S.A..
