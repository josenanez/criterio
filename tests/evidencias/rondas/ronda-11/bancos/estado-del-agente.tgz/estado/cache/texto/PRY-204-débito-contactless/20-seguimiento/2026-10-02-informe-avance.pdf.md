<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-02-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-02
Gerente: Liliana Torres

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 5.414.991.060
Ejecutado 3.518.966.738
Proyección al cierre 9.140.519.741

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
