<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-09-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-09-11
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Gustavo Neira, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | por definir |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-10-07 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-10-07 |
