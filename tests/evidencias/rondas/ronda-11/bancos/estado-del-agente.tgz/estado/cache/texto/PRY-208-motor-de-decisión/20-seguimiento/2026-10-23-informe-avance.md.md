<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Motor de decisión

**Código:** PRY-208
**Fecha de corte:** 2026-10-23
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **63%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 12.114.491.860 |
| Ejecutado | 8.526.681.039 |
| Proyección al cierre | 17.554.004.770 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
