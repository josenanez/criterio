<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-05-31-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Banca de Personas

Patrocinador: Paula Céspedes

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-05-31

Objetivo del negocio

Entregar prevención de lavado de activos para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Transformación Digital el 2025-05-31.

Fechas comprometidas

Fecha

Inicio

2025-06-10

Cierre

2026-04-25

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
