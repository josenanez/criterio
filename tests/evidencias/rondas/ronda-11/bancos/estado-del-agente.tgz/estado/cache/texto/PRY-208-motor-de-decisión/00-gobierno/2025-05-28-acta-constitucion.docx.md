<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2025-05-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Tecnología

Patrocinador: Felipe Arango

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-05-28

Objetivo del negocio

Entregar motor de decisión para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2025-05-28.

Fechas comprometidas

Fecha

Inicio

2025-06-07

Cierre

2026-05-21

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
