<!-- origen: PRY-202-migración-a-la-nube/10-plan/2026-10-16-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2025-11-27 | 2025-11-27 | 2025-11-27 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-03-04 | 2026-03-04 | 2026-03-04 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core | 2026-06-09 | 2026-06-09 | 2026-06-09 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con usuarios internos | 2026-11-22 | 2026-11-22 | 2026-09-14 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2025-11-27 | 2025-11-27 | cerrado |
| Ambiente de pruebas certificado | 2026-03-04 | 2026-03-04 | cerrado |
| Integración con el core | 2026-06-09 | 2026-06-09 | cerrado |
| Piloto con usuarios internos | 2026-09-14 | 2026-11-22 | cerrado |
