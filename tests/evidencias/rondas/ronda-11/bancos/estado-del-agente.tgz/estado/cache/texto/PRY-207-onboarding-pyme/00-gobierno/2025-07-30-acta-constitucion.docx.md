<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2025-07-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Onboarding PyME

Código: PRY-207

Área dueña: Banca Hipotecaria

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Javier Hoyos

Comité: Comité de Riesgos

Producto asociado: cuenta PyME

Fecha de aprobación: 2025-07-30

Objetivo del negocio

Entregar onboarding pyme para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Riesgos el 2025-07-30.

Fechas comprometidas

Fecha

Inicio

2025-08-09

Cierre

2027-01-13

Criterio de éxito

Onboarding PyME en producción y medido.

Dependencias declaradas

• Ninguna declarada
