<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-11-23-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Portal de proveedores

**Código:** PRY-210
**Área dueña:** Banca Empresas
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Medios de Pago
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-23

## Objetivo del negocio

Entregar portal de proveedores para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-11-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-03 |
| Cierre | 2026-09-12 |

## Criterio de éxito

Portal de proveedores en producción y medido.

## Dependencias declaradas

- Ninguna declarada
