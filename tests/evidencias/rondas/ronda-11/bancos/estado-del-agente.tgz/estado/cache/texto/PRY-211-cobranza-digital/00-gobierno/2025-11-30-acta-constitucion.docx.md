<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-11-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Banca Hipotecaria

Patrocinador: Javier Hoyos

Gerente de proyecto: Gustavo Neira

Comité: Comité de Banca Empresas

Producto asociado: recaudos

Fecha de aprobación: 2025-11-30

Objetivo del negocio

Entregar cobranza digital para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Banca Empresas el 2025-11-30.

Fechas comprometidas

Fecha

Inicio

2025-12-10

Cierre

2026-09-20

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
