<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Originación digital
**Fecha:** 2026-10-15
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +78 días sobre la línea base vigente |
| Costo | 156.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
