<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-10-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-10-18
**Asistentes:** María Restrepo, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 30 | 2026-10-29 |
| Ricardo Salas | Entregar el punto 28 | por definir |
