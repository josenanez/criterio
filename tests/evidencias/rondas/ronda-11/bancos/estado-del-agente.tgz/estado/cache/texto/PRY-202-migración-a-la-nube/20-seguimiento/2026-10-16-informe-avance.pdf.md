<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración a la nube
Código: PRY-202
Fecha de corte: 2026-10-16
Gerente: María Restrepo

Estado declarado
Rojo
Avance reportado: 41%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 800.000.000
Comprometido 364.802.812
Ejecutado 175.437.818
Proyección al cierre 881.586.671

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
