<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-20
Gerente: Gustavo Neira

Estado declarado
Verde
Avance reportado: 84%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 800.000.000
Comprometido 286.830.892
Ejecutado 261.382.619
Proyección al cierre 739.687.135

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
