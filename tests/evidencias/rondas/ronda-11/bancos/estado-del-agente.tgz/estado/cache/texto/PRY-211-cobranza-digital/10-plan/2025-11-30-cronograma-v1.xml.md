<!-- origen: PRY-211-cobranza-digital/10-plan/2025-11-30-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2026-02-19 | 2026-02-19 | 2026-02-19 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-05-01 | 2026-05-01 | 2026-05-01 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core | 2026-07-11 | 2026-07-11 | 2026-07-11 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con usuarios internos | 2026-09-20 | 2026-09-20 | 2026-09-20 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2026-02-19 | 2026-02-19 | cerrado |
| Ambiente de pruebas certificado | 2026-05-01 | 2026-05-01 | cerrado |
| Integración con el core | 2026-07-11 | 2026-07-11 | cerrado |
| Piloto con usuarios internos | 2026-09-20 | 2026-09-20 | cerrado |
