<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2025-05-31-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-08-12 | 2025-08-12 | cerrado
Ambiente de pruebas certificado | 2025-10-15 | 2025-10-15 | cerrado
Integración con el core | 2025-12-18 | 2025-12-18 | cerrado
Piloto con usuarios internos | 2026-02-20 | 2026-02-20 | cerrado
Salida a producción | 2026-04-25 | 2026-04-25 | cerrado
