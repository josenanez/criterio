<!-- origen: PRY-203-open-banking/10-plan/2025-12-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-25 | 2026-04-25 | cerrado
Ambiente de pruebas certificado | 2026-08-25 | 2026-08-25 | cerrado
Integración con el core | 2026-12-25 | 2026-12-25 | en curso
