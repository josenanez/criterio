<!-- origen: PRY-204-débito-contactless/10-plan/2026-02-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-06-13,2026-06-13,cerrado
Ambiente de pruebas certificado,2026-10-06,2026-10-06,cerrado
Integración con el core,2027-01-29,2027-01-29,en curso
