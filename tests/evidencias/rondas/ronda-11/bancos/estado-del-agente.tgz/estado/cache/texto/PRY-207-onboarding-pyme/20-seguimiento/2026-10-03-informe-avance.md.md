<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-10-03-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-03
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **22%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 5.550.704.544 |
| Ejecutado | 1.525.989.422 |
| Proyección al cierre | 6.883.597.700 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
