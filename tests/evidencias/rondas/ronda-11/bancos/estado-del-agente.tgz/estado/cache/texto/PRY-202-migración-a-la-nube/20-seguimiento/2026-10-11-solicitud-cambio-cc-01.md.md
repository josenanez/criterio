<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Migración a la nube
**Fecha:** 2026-10-11
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +69 días sobre la línea base vigente |
| Costo | 138.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
