<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2026-01-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core de depósitos

Código: PRY-201

Área dueña: Banca Empresas

Patrocinador: Óscar Ramírez

Gerente de proyecto: Carlos Peña

Comité: Comité de Arquitectura

Producto asociado: cuenta de ahorros

Fecha de aprobación: 2026-01-02

Objetivo del negocio

Entregar core de depósitos para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Arquitectura el 2026-01-02.

Fechas comprometidas

Fecha

Inicio

2026-01-12

Cierre

2026-10-30

Criterio de éxito

Core de depósitos en producción y medido.

Dependencias declaradas

• Ninguna declarada
