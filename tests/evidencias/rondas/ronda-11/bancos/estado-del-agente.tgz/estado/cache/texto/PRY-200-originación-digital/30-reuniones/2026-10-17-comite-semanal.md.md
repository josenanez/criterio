<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Originación digital

**Fecha:** 2026-10-17
**Asistentes:** María Restrepo, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 4 | 2026-10-20 |
| Mauricio Pérez | Entregar el punto 30 | 2026-10-12 |
