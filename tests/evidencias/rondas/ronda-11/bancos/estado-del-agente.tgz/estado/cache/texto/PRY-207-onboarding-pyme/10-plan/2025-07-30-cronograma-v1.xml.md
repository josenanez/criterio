<!-- origen: PRY-207-onboarding-pyme/10-plan/2025-07-30-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2025-12-17 | 2025-12-17 | 2025-12-17 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-04-27 | 2026-04-27 | 2026-04-27 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core | 2026-09-05 | 2026-09-05 | 2026-09-05 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con usuarios internos | 2027-01-13 | 2027-01-13 | 2027-01-13 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2025-12-17 | 2025-12-17 | cerrado |
| Ambiente de pruebas certificado | 2026-04-27 | 2026-04-27 | cerrado |
| Integración con el core | 2026-09-05 | 2026-09-05 | cerrado |
| Piloto con usuarios internos | 2027-01-13 | 2027-01-13 | en curso |
