<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Prevención de lavado de activos

**Fecha:** 2026-10-15
**Asistentes:** Rubén Cárdenas, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 11 | 2026-10-11 |
