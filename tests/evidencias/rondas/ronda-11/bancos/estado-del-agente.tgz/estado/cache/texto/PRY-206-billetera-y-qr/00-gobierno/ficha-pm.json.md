<!-- origen: PRY-206-billetera-y-qr/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-206",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "name": {
 "value": "Billetera y QR",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Canales Digitales",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "product": {
 "value": "pagos QR",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "authority": {
 "value": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Laura Vélez",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "manager": {
 "value": "Gustavo Neira",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Medios de Pago",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "phase": {
 "value": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 84,
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-20",
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-04-22",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "end_date": {
 "value": "2027-01-25",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-04-12",
 "start_date": "2026-04-22",
 "end_date": "2027-01-25",
 "reason": "Aprobación inicial del Comité de Medios de Pago",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-06-16",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-06-16",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-14-acta-recibo-diseño-funcional-aprobado.pdf",
 "source": "20-seguimiento/2026-10-14-acta-recibo-diseño-funcional-aprobado.pdf",
 "source_date": "2026-10-14",
 "state": "found"
 }
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-08-11",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-08-11",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Integración con el core",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-05",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-05",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Piloto con usuarios internos",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-11-30",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-11-30",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Salida a producción",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-01-25",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "current_date": {
 "value": "2027-01-25",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-12-cronograma-v1.xlsx",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "approved": {
 "value": 800000000,
 "source": "00-gobierno/2026-04-12-acta-constitucion.md",
 "source_date": "2026-04-12",
 "state": "found"
 },
 "committed": {
 "value": 286830892,
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 261382619,
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 739687135,
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Integra Sistemas Ltda.",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-360",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del motor",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "due_date": {
 "value": "2026-08-02",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "amount": {
 "value": 71307259,
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "state": {
 "value": "accepted",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de desarrollo",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-12",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "amount": {
 "value": 71307259,
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx",
 "source_date": "2026-04-20",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "invoiced": {
 "value": 71307259,
 "source": "20-seguimiento/2026-09-24-factura-ct-360.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "source": "00-gobierno/2026-04-20-contrato-ct-360.docx"
 },
 {
 "name": {
 "value": "Talento Digital S.A.S.",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-127",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del motor",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-07-07",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "amount": {
 "value": 95209583,
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de desarrollo",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-22",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "amount": {
 "value": 95209583,
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Parametrización del tarifario",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-07",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "amount": {
 "value": 95209583,
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md",
 "source_date": "2026-04-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "invoiced": {
 "value": null,
 "state": "not_found"
 },
 "source": "00-gobierno/2026-04-21-contrato-ct-127.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": {
 "value": null,
 "state": "not_found"
 },
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20"
 },
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "owner": {
 "value": null,
 "state": "not_found"
 },
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión; nadie lo registró como riesgo)",
 "owner": {
 "value": null,
 "state": "not_found"
 },
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": "no_declarada",
 "owner": {
 "value": null,
 "state": "not_found"
 },
 "source": "20-seguimiento/2026-10-20-informe-avance.pdf",
 "source_date": "2026-10-20"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Enviar el documento 1"
 },
 "due_date": {
 "value": "2026-11-30"
 },
 "original_due_date": {
 "value": "2026-09-26"
 },
 "stated_on": {
 "value": "2026-09-11"
 },
 "source": {
 "value": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Cerrar la prueba 2"
 },
 "due_date": {
 "value": "2027-01-09"
 },
 "original_due_date": {
 "value": "2026-10-07"
 },
 "stated_on": {
 "value": "2026-09-11"
 },
 "source": {
 "value": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-12-13",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-26",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 {
 "due_date": "2027-01-09",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt"
 }
 ],
 "note": "En las notas del 2026-10-23 la fecha viene como «09/01/2027»; se lee día/mes (9 de enero de 2027), como el resto de las fechas del proyecto. Confírmalo."
 },
 {
 "who": {
 "value": "Gustavo Neira"
 },
 "what": {
 "value": "Revisar el anexo 3"
 },
 "due_date": {
 "value": "2026-11-06"
 },
 "original_due_date": {
 "value": "2026-09-29"
 },
 "stated_on": {
 "value": "2026-09-11"
 },
 "source": {
 "value": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Validar el ambiente 4"
 },
 "due_date": {
 "value": "2026-11-30"
 },
 "original_due_date": {
 "value": "2026-10-07"
 },
 "stated_on": {
 "value": "2026-09-11"
 },
 "source": {
 "value": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán"
 },
 "what": {
 "value": "Aprobar el diseño 5"
 },
 "due_date": {
 "value": "2026-10-06"
 },
 "original_due_date": {
 "value": "2026-10-06"
 },
 "stated_on": {
 "value": "2026-09-18"
 },
 "source": {
 "value": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "Salió de la tabla el 2026-10-09 con la nota «dice que ya entregó… No se presentó acta». El acta de recibo del 2026-10-14 nombra el entregable «Diseño funcional aprobado», no este compromiso."
 },
 {
 "who": {
 "value": "Diana Molina"
 },
 "what": {
 "value": "Actualizar la matriz 6"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-09-18"
 },
 "source": {
 "value": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "El 2026-09-25 «dice que ya entregó… No se presentó acta»; sin fecha y sin acta no se puede dar por cumplido ni por vencido."
 },
 {
 "who": {
 "value": "Liliana Torres"
 },
 "what": {
 "value": "Confirmar la fecha 7"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": {
 "value": "2026-10-05"
 },
 "stated_on": {
 "value": "2026-09-18"
 },
 "source": {
 "value": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Entregar el punto 8"
 },
 "due_date": {
 "value": "2026-10-01"
 },
 "original_due_date": {
 "value": "2026-10-01"
 },
 "stated_on": {
 "value": "2026-09-18"
 },
 "source": {
 "value": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-02-acta-recibo-8.md"
 },
 "note": "Cerrado en la reunión del 2026-10-02."
 },
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Enviar el documento 9"
 },
 "due_date": {
 "value": "2026-10-25"
 },
 "original_due_date": {
 "value": "2026-10-01"
 },
 "stated_on": {
 "value": "2026-09-25"
 },
 "source": {
 "value": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Cerrar la prueba 10"
 },
 "due_date": {
 "value": "2026-10-15"
 },
 "original_due_date": {
 "value": "2026-10-15"
 },
 "stated_on": {
 "value": "2026-09-25"
 },
 "source": {
 "value": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Paula Céspedes"
 },
 "what": {
 "value": "Revisar el anexo 11"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": {
 "value": "2026-10-22"
 },
 "stated_on": {
 "value": "2026-09-25"
 },
 "source": {
 "value": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Rubén Cárdenas"
 },
 "what": {
 "value": "Validar el ambiente 12"
 },
 "due_date": {
 "value": "2026-10-10"
 },
 "original_due_date": {
 "value": "2026-10-10"
 },
 "stated_on": {
 "value": "2026-09-25"
 },
 "source": {
 "value": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Aprobar el diseño 13"
 },
 "due_date": {
 "value": "2026-10-09"
 },
 "original_due_date": {
 "value": "2026-10-09"
 },
 "stated_on": {
 "value": "2026-10-02"
 },
 "source": {
 "value": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Actualizar la matriz 14"
 },
 "due_date": {
 "value": "2026-11-01"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": {
 "value": "2026-10-02"
 },
 "source": {
 "value": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Beatriz Cuéllar"
 },
 "what": {
 "value": "Confirmar la fecha 15"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-10-02"
 },
 "source": {
 "value": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Tres reuniones seguidas «por definir»."
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Entregar el punto 16"
 },
 "due_date": {
 "value": "2026-11-05"
 },
 "original_due_date": {
 "value": "2026-10-29"
 },
 "stated_on": {
 "value": "2026-10-02"
 },
 "source": {
 "value": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Jorge Medina"
 },
 "what": {
 "value": "Enviar el documento 17"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-28"
 },
 "stated_on": {
 "value": "2026-10-09"
 },
 "source": {
 "value": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Liliana Torres"
 },
 "what": {
 "value": "Cerrar la prueba 18"
 },
 "due_date": {
 "value": "2026-11-14"
 },
 "original_due_date": {
 "value": "2026-11-04"
 },
 "stated_on": {
 "value": "2026-10-09"
 },
 "source": {
 "value": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Revisar el anexo 19"
 },
 "due_date": {
 "value": "2026-10-23"
 },
 "original_due_date": {
 "value": "2026-10-13"
 },
 "stated_on": {
 "value": "2026-10-09"
 },
 "source": {
 "value": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Validar el ambiente 20"
 },
 "due_date": {
 "value": "2026-11-06"
 },
 "original_due_date": {
 "value": "2026-11-06"
 },
 "stated_on": {
 "value": "2026-10-09"
 },
 "source": {
 "value": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-16-acta-recibo-20.md"
 },
 "note": "Cerrado en la reunión del 2026-10-16."
 },
 {
 "who": {
 "value": "Jorge Medina"
 },
 "what": {
 "value": "Aprobar el diseño 21"
 },
 "due_date": {
 "value": "2026-11-07"
 },
 "original_due_date": {
 "value": "2026-11-07"
 },
 "stated_on": {
 "value": "2026-10-16"
 },
 "source": {
 "value": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Sandra Gil"
 },
 "what": {
 "value": "Actualizar la matriz 22"
 },
 "due_date": {
 "value": "2026-11-10"
 },
 "original_due_date": {
 "value": "2026-11-10"
 },
 "stated_on": {
 "value": "2026-10-16"
 },
 "source": {
 "value": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Ricardo Salas"
 },
 "what": {
 "value": "Confirmar la fecha 23"
 },
 "due_date": {
 "value": "2026-10-23"
 },
 "original_due_date": {
 "value": "2026-10-23"
 },
 "stated_on": {
 "value": "2026-10-16"
 },
 "source": {
 "value": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Entregar el punto 24"
 },
 "due_date": {
 "value": "2026-11-06"
 },
 "original_due_date": {
 "value": "2026-11-06"
 },
 "stated_on": {
 "value": "2026-10-16"
 },
 "source": {
 "value": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-10-23"
 },
 "source": {
 "value": "2026-10-23-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Las notas dicen «la otra semana»; nadie dijo una fecha."
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisión con el proveedor"
 },
 "due_date": {
 "value": "2026-11-02"
 },
 "original_due_date": {
 "value": "2026-11-02"
 },
 "stated_on": {
 "value": "2026-10-23"
 },
 "source": {
 "value": "2026-10-23-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-23",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
