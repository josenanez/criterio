<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2026-04-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Canales Digitales
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Medios de Pago
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar billetera y qr para Canales Digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Medios de Pago el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2027-01-25 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
