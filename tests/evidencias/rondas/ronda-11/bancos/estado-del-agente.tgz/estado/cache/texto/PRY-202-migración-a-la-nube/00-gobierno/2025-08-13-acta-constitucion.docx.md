<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-08-13-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Operaciones

Patrocinador: Sandra Gil

Gerente de proyecto: María Restrepo

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2025-08-13

Objetivo del negocio

Entregar migración a la nube para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Banca Empresas el 2025-08-13.

Fechas comprometidas

Fecha

Inicio

2025-08-23

Cierre

2026-09-14

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
