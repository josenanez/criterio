<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-01-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-11 | 2026-03-11 | cerrado
Ambiente de pruebas certificado | 2026-05-08 | 2026-05-08 | cerrado
Integración con el core | 2026-07-06 | 2026-07-06 | cerrado
Piloto con usuarios internos | 2026-09-02 | 2026-09-02 | cerrado
Salida a producción | 2026-10-30 | 2026-10-30 | en curso
