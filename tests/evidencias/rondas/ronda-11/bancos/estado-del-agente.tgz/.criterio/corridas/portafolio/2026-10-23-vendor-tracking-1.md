# Corrida · 2026-10-23-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-23T09:59:44 · **Fin:** 2026-10-23T10:01:15 · **Duración:** 91 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 55 | 71 | Cruce de CT-600 de PRY-201: 1 de 3 entregables aceptados con acta; 2 vencidos sin evidencia; factura FV-1600 coincide en monto con lo aceptado pero no nombra el entregable. Sin dato: vigencia y preaviso del contrato. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Hice el cruce de proveedores de PRY-201 y lo dejé guardado en `estado/corridas/salida-vendor-tracking.md`. La corrida quedó registrada como `2026-10-23-vendor-tracking-1`.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-23, así que no los volví a registrar.

El único proveedor es Redes del Norte, con el contrato CT-600 (3 entregables de 252.141.177 COP cada uno).

- **Aceptado con evidencia:** 1 de 3, la bolsa de horas, con acta de recibo del 2026-07-03 firmada por Carlos Peña.
- **Vencidos sin evidencia:** el licenciamiento del motor (comprometido para el 2026-04-02, 204 días) y la parametrización del tarifario (2026-09-09, 44 días). Ninguno está declarado como entregado.
- **Factura:** FV-1600 por 252.141.177 COP coincide en monto con lo aceptado, así que no hay factura sin entrega. Pero dice «Entregables del contrato CT-600» sin nombrar ninguno, y no puedo afirmar que corresponda a la bolsa de horas. Hay que confirmarlo con cuentas por pagar.
- **Compromisos del proveedor:** ninguno vencido. El único del comité del 2026-10-22 es de Rubén Cárdenas («punto 18», para el 2026-10-25), y no consta que sea del proveedor.
- **Sin dato:** el contrato en la carpeta no trae vigencia, renovación ni preaviso, así que no sé si el preaviso vence antes del cierre del 2026-10-30. El texto del PDF del acta no permite ver la firma.

Aparte del cruce, el script marca 4 hitos declarados cumplidos sin evidencia y una proyección de costo 17.2 % sobre lo aprobado. Con el avance declarado en 90 %, los dos entregables atrasados merecen llevarse al comité del 2026-10-30.

La corrida registró 71 hallazgos en los 13 proyectos, porque `compute` recorre todo el portafolio. Los de este informe son solo los de PRY-201.
