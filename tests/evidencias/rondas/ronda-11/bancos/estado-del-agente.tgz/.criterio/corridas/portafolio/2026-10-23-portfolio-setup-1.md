# Corrida · 2026-10-23-portfolio-setup-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-setup documentos/proyectos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T09:47:16 · **Fin:** 2026-10-23T09:51:17 · **Duración:** 241 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-setup` | 3 | 77 | 182 | 23 | 0 preguntas (sesión sin interfaz, respuestas sugeridas); tiempo hasta el primer resultado no cronometrado; 3 proyectos (PRY-206, 201, 208), 26 documentos; 23 señales: PRY-206 verde contradicho, PRY-201 con 4 hitos sin acta y proyección +17,2 %, PRY-208 sin señales; 4 cronogramas XML ilegibles; carpeta no marcada |

Por señal (`portfolio-setup`): `milestone_met_without_evidence` 6, `vendor_deliverable_late` 4, `commitment_overdue` 4, `commitment_undated` 3, `commitment_rescheduled` 3, `variance_cost` 1, `vendor_accepted_without_evidence` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Vera quedó configurada y probé con tres proyectos: PRY-206, PRY-201 y PRY-208.

**Cómo se configuró.** Nadie contestó preguntas, así que tomé la respuesta sugerida en cada una.
- **Rol:** PMO del portafolio.
- **Comité:** semanal, con el próximo el 2026-10-30. Esa fecha la supuse, porque ningún documento la dice.
- **Informe:** en HTML, como presentación.
- **Organización:** quedó como «Portafolio de proyectos», porque no aparece en los documentos.
- **Marca de la carpeta:** no dejé `_CRITERIO_PORTAFOLIO.txt` en `documentos/proyectos`, porque no hubo un sí y no escribo ahí sin él.

La configuración está en `.criterio/portafolio/config.json`. Registré los términos (versión 1.2) a nombre de José Francisco Ñáñez, con comprobante en `.criterio/terminos/` (`.md` y `.pdf`, SHA-256 `fe830b9a4eee0bc9…`).

**Qué encontré.** El inventario son 77 documentos en 13 proyectos. De estos hallazgos, 22 de 23 son de PRY-206 y PRY-201:
- **PRY-206 (declara verde, 84%):** los documentos lo contradicen.
  - Hay 4 compromisos vencidos sin evidencia.
  - Hay 3 compromisos reprogramados entre 4 y 6 veces.
  - Hay 3 compromisos sin fecha y 2 hitos cerrados sin acta.
  - El proveedor Talento Digital tiene 2 entregables atrasados.
  - Una factura de Integra Sistemas (71.307.259 COP) cobra un entregable que figura como recibido sin acta.
- **PRY-201 (declara rojo, 90%):**
  - 4 hitos cerrados sin acta.
  - Proyección al cierre 17,2 % por encima del presupuesto aprobado.
  - 2 entregables del proveedor atrasados.
- **PRY-208 (declara verde, 63%):** el cálculo no levantó ninguna señal. Sus datos salen de un acta de hace 17 meses. Tampoco tiene cronograma ni minutas, y su única fecha de cierre (2026-05-21) ya pasó. No lo presento como hallazgo porque el cálculo no lo marcó.

**Una fecha a confirmar.** En PRY-206, las notas del 2026-10-23 dicen «09/01/2027». La leí como 9 de enero de 2027.

**Lo que le falta a la carpeta:**
- Cuatro cronogramas en XML no se leen sin instalar algo; los proyectos son PRY-202, 207, 210 y 211.
- PRY-203, 207 y 208 no tienen minutas.
- Ningún proyecto declara autoridad ni fase.

**Una corrección a lo que escribí.** El informe estima unos 20 minutos para los 10 proyectos que faltan. Esa cifra salió de una proporción y no la medí. La corrida de los tres proyectos tardó 182 segundos, así que el resto debería tomar unos 6 minutos. El informe guardado conserva la estimación vieja. Tampoco cronometré el tiempo hasta el primer resultado.

**Dónde quedó:**
- `estado/records/` (las tres fichas)
- `estado/corridas/salida-portfolio-setup.md` (el informe completo)
- La corrida `2026-10-23-portfolio-setup-1` quedó registrada.

¿Corro el portafolio completo?
