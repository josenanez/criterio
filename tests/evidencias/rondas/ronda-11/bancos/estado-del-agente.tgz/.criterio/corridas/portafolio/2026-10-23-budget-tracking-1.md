# Corrida · 2026-10-23-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-23T09:58:41 · **Fin:** 2026-10-23T09:59:35 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 33 | 71 | Presupuesto de PRY-202: proyección 10,2% sobre el aprobado; comprometido 45,6%, ejecutado 21,9%. Dijo que no sabe si la proyección incluye CC-01 (138 M, pendiente) y que comprometido, ejecutado y proyección son declaración sin evidencia. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

**Presupuesto de PRY-202 (Migración a la nube) al 2026-10-23:** la proyección al cierre supera el aprobado en 10,2%, justo por encima del umbral de 10%. Dejé el informe y el registro de la corrida guardados.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no registré nada nuevo.

| COP | Monto | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | 100% | Acta de constitución | 2025-08-13 |
| Comprometido | 364.802.812 | 45,6% | Informe de avance (declaración) | 2026-10-16 |
| Ejecutado | 175.437.818 | 21,9% | Informe de avance (declaración) | 2026-10-16 |
| Proyección al cierre | 881.586.671 | 110,2% | Informe de avance (declaración) | 2026-10-16 |

- **Disponible real:** 435.197.188 COP (aprobado menos comprometido). El comprometido está lejos del umbral de 90%.
- **Línea base:** el presupuesto original y el vigente son iguales (800.000.000), sin replanificaciones de presupuesto. Sí hay una replanificación de fechas de +69 días contra la original, que ningún cambio aprobado autoriza.
- **Cambio pendiente:** CC-01 pide 138.000.000 COP adicionales y no está decidido, así que no cuenta en el aprobado.
- **Ejecución frente a avance:** el plan marca 4 de 4 hitos cumplidos, el gerente declara 41% de avance y la plata ejecutada va en 21,9%. Tres de esos hitos están marcados como cumplidos sin evidencia.
- **Sin dato:**
  - Comprometido, ejecutado y proyección son declaración del gerente, sin documento de evidencia detrás.
  - El informe no dice si la proyección incluye los 138 M de CC-01.
  - La ficha no tiene proveedores, así que no hay detalle por proveedor.

Puedo preparar la solicitud de cambio, o evaluar CC-01 con `/criterio-portfolio:change-control`.

La corrida quedó como `2026-10-23-budget-tracking-1` (33 segundos).

Archivos en `estado/corridas/`:
- `salida-budget-tracking.md`
