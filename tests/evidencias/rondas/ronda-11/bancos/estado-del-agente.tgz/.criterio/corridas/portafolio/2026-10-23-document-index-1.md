# Corrida · 2026-10-23-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T09:55:14 · **Fin:** 2026-10-23T09:55:41 · **Duración:** 28 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 11 | 71 | Índice sin cambios: 77 documentos iguales, nada que releer, sin citas rotas. No se leyó ningún documento. |

Por señal (`document-index`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

No cambió nada en la carpeta: 77 documentos, los 77 iguales, ninguno por releer y ninguna cita rota. No hace falta correr `/portfolio-scan`.

- **Términos:** ya estaban vigentes (versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los volví a registrar.
- **Registro:** la corrida quedó guardada con lo mostrado en `estado/corridas/salida-document-index.md`.
- **Hallazgos abiertos de corridas anteriores:** el registro de la corrida cuenta 71, que vienen de las fichas y no de este índice.
