# Corrida · 2026-10-23-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:14:01 · **Fin:** 2026-10-23T10:16:53 · **Duración:** 172 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 42 | 71 | Barrido: 77 documentos sin cambios, nada que recalcular. Confirmación: 5 campos preguntados (2 facturados de proveedor, quién firmó CC-01 de PRY-200, 2 riesgos sin dueño); sesión sin interfaz, sin respuesta. No sé si los facturados existen fuera de los documentos. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Hoy tocaban el barrido diario y la confirmación mensual. El barrido no encontró cambios y la confirmación quedó sin respuesta, porque nadie contesta en esta sesión.

- **Términos:** ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). No registré una aceptación nueva.
- **Barrido:** 77 documentos y ninguno cambió. No hay proyectos que recalcular, ni citas rotas, ni peticiones pendientes. Nada cruzó un umbral.
- **Confirmación:** pregunté cinco campos, elegidos por importancia, y quedaron sin respuesta:
  1. PRY-206: cuánto ha facturado Talento Digital (CT-127).
  2. PRY-199: cuánto ha facturado Consultora Andina (CT-199).
  3. PRY-200: quién firmó la aprobación de CC-01 (+78 días, +156.000.000 COP). El documento dice solo «el comité».
  4. PRY-199: responsable del riesgo «Disponibilidad del equipo de seguridad para la revisión final».
  5. PRY-200: responsable de ese mismo riesgo.
- **Corrida:** quedó registrada como 2026-10-23-portfolio-wake-1 y tardó 42 segundos. La salida completa está en `estado/corridas/salida-portfolio-wake.md`.

Vuelvo el 2026-10-24.

## Respuesta 2

El mapa quedó escrito en `.criterio/rostrum/config.json` con 3 agentes de una sola familia, pmo: Vera (portafolio), Samuel (PRY-206) y Alba (PRD-302). Ninguna entrada quedó fuera. Los términos 1.2 quedaron aceptados a nombre de José Francisco Ñáñez para la versión 0.8.0, con comprobante en `.criterio/terminos/`.

- **Nombre de la organización:** la configuración de la PMO no lo trae y nadie podía darlo en esta sesión. El mapa quedó sin ese dato; se agrega volviendo a guardar con `--organizacion`.
- **Orden de los pasos:** `terminos` no devuelve el texto mientras el mapa no existe. Por eso escribí el mapa antes de mostrar los términos, al revés del orden del comando. La aceptación se registró sobre el mapa ya escrito y no volví a guardar, para no pisarla.
- **Marcas pendientes:** las carpetas de Vera y de Samuel siguen sin marca. Se marcan con `/criterio-portfolio:portfolio-setup` y `/criterio-project:pm-setup`.

Para levantar el portal: `/criterio-server:server-start`.

## Respuesta 3

Rostrum está corriendo en `http://127.0.0.1:8787/`, solo en este equipo. Para pararlo hay que matar el proceso en segundo plano. Los términos 1.2 ya estaban vigentes y registrados a nombre de José Francisco Ñáñez el 2026-10-23, así que no hubo que registrarlos de nuevo. El mapa y el disco coinciden: no hay entradas nuevas ni agentes sin estado.

**Qué hay**
- **Mapa:** tres entradas. Vera (portafolio), Samuel (proyecto PRY-206) y Alba (producto PRD-302), todas de la familia PMO.
- **Portada** (`/`): los tres agentes y el formulario de peticiones.
- **Informe de la PMO** (`/pmo`): ya estaba generado, con fecha 2026-10-23T15:13 UTC.
  - **Comité:** `/decisiones`.
  - **Proyectos:** `/proyectos`, con 13 proyectos.
  - **Productos:** `/productos`, con 9 productos.
- **Corridas** (`/corridas`): 33 corridas en la historia.
- **Frescura** (`/estado.json`): para un mecanismo, no para una persona.
- **Peticiones:** 0 abiertas.

**Un hallazgo**
- `/estado.json` muestra `ultimo: null` para los tres agentes y `proxima_corrida: null`.
- Es decir, el portal no sabe decir de cuándo es lo último de cada agente. Por eso el único dato con fecha es el del informe de la PMO.

**Qué enlace pasar a quién**
- Al patrocinador y al comité: `/` o `/decisiones`.
- La PMO usa `/pmo` y `/proyectos`.
- No hay familia CFO ni CLO en el mapa, así que `/familia/…` y `/vence` no tienen contenido para esta organización.

**Lo que no hace**
- Sirve lo que los agentes ya escribieron: no calcula ni procesa documentos.
- No escribe fichas; solo crea peticiones en la carpeta `peticiones/` del agente elegido.
- No autentica y no manda correos.

**Para que el patrocinador tenga un enlace que funcione mañana**
- Esta forma solo vive mientras el proceso esté activo y solo se ve desde este equipo.
- Para eso hay que pasar a la forma «que quede corriendo» (`--abierto`). Habría que pedirle a la organización un host con puerto dentro de la red, publicarlo detrás de su control de acceso y mantener el equipo encendido.
- No necesita base de datos, certificado ni salida a internet.
