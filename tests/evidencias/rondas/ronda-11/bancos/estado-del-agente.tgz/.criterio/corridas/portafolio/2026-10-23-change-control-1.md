# Corrida · 2026-10-23-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-23T10:01:21 · **Fin:** 2026-10-23T10:02:46 · **Duración:** 85 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 58 | 71 | Solicitud de mover 30 días la salida a producción de PRY-201. No consta quién la pide, el motivo, el costo del mes extra ni la autoridad que decide. Sin dependencias declaradas. Proyección ya 17,2 % sobre lo aprobado. No se registró línea base nueva. |

Por señal (`change-control`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Preparé la solicitud de cambio de PRY-201, pero no está lista para decidirse. No consta quién la pide, el motivo ni cuánto cuesta el mes extra. La corrida quedó registrada, y no creé ninguna línea base nueva.

**Qué pide:** mover la salida a producción del 2026-10-30 al 2026-11-29, que es un domingo. Faltan 7 días para la fecha actual.

- **Impacto:**
  - **Alcance:** sin cambio declarado.
  - **Tiempo:** +30 días.
  - **Costo:** nadie lo declaró. La proyección ya está 17,2 % sobre lo aprobado (2.812.334.652 contra 2.400.000.000 COP), antes de este cambio.
- **Efecto en el portafolio:** el cálculo no alcanza a ningún otro proyecto. Eso no prueba que nadie dependa de PRY-201. Ninguna ficha declara una dependencia con él: el acta dice «Ninguna declarada» y el registro de riesgos no tiene dependencias.
- **Quién decide:** no se puede determinar, porque el acta no declara autoridad. Por eso el paquete va a comité. El Comité de Arquitectura aprobó la línea base y el presupuesto, pero que él decida este cambio es inferencia mía, no algo escrito. El próximo comité semanal es el 2026-10-30, el mismo día en que vence la fecha actual.
- **Si se aprueba:** habría una línea base 2 con cierre el 2026-11-29. Contra la original, el atraso acumulado sería de 30 días más el sobrecosto ya proyectado. Sin un documento que lo autorice, esos 30 días quedarían como no autorizados.
- **Lo que no sé:** hasta cuándo cubre el contrato CT-600 con Redes del Norte, porque la ficha no trae su vencimiento. Tampoco sé si el 90 % de avance declarado se sostiene: el ejecutado es 20,6 % de lo aprobado y ningún documento respalda ese avance.

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-23), así que no hubo que registrarlos de nuevo.

Archivos en `estado/corridas/` (dentro de la carpeta de trabajo):
- `salida-change-control.md` — la solicitud completa
- `2026-10-23-change-control-1` — el registro de la corrida
