# Corrida · 2026-10-23-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view cuenta PyME

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:11:15 · **Fin:** 2026-10-23T10:12:14 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 32 | 71 | Producto con un solo proyecto (PRY-207): sin sección de producto, solo lectura del proyecto. 5 alertas: silencio 20 días, avance 22% contra 75-100% del plan, 3 hitos cumplidos sin evidencia. 4 proyectos sin producto declarado (PRY-202, 205, 208, 210). No se sabe el área dueña de esos 4 ni qué se habló fuera de los documentos. |

Por señal (`product-view`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## Productos al 2026-10-23: cuenta PyME

Esto sale de las fichas del portafolio (13 proyectos), recalculadas hoy. Los términos v1.2 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-23, y no hizo falta registrarlos de nuevo.

**La cuenta PyME tiene un solo proyecto, PRY-207 Onboarding PyME.** Por eso la vista por producto no aporta nada y no armé una sección de producto. No hay señales que sumar entre proyectos ni dependencias internas que cruzar. Lo que sigue es la lectura de ese proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| cuenta PyME | 1 (PRY-207) | 5 | 2027-01-13 (PRY-207) | COP 6.800.000.000 | COP 5.550.704.544 |

- **Dinero:** ejecutado COP 1.525.989.422 (22,4 %). Lo comprometido es el 81,6 % de lo aprobado. La proyección es COP 6.883.597.700, un 1,2 % sobre lo aprobado. El proyecto trae las cuatro cifras.
- **Silencio:** 20 días desde el 2026-10-03, que es el último informe de avance. El umbral es 15.
- **Avance contra plan:** declara 22 %, pero el plan sustenta entre 75 % y 100 % (3 de 4 hitos cumplidos), una diferencia de 53 puntos. Los documentos no dicen cuál de las dos cifras está mal.
- **Hitos sin evidencia:** tres hitos figuran como cumplidos sin evidencia:
  - «Diseño funcional aprobado» (vencía 2025-12-17).
  - «Ambiente de pruebas certificado» (vencía 2026-04-27).
  - «Integración con el core» (vencía 2026-09-05).
- **Estado declarado:** amarillo. El informe no explica ninguna de las tres señales anteriores.
- **Campos que faltan:** autoridad, fase, y los dueños de un riesgo y dos incidencias. Los campos de identidad y plan se leyeron de un documento del 2025-07-30, de hace 15 meses.

**Proyectos sin producto declarado:** PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión y PRY-210 Portal de proveedores. Nadie puede responder por el conjunto al que sirven, y eso es un hallazgo de gobierno. No asumo que alguno sirva a la cuenta PyME, y el cálculo no me da el área dueña de ninguno.

Esto es un borrador de trabajo hecho con las fichas. La verificación contra los documentos citados es de usted, y no sé qué se habló fuera de ellos.

La corrida quedó registrada (`2026-10-23-product-view-1`, 32 segundos). Tiene un límite: el script no midió cuántos documentos leyó. El texto completo está en `estado/corridas/salida-product-view.md`.
