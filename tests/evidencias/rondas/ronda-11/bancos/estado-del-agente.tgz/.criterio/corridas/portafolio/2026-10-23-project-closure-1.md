# Corrida · 2026-10-23-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-23T10:07:59 · **Fin:** 2026-10-23T10:09:17 · **Duración:** 78 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 55 | 71 | Cierre de PRY-202 no sustentado: criterio de éxito sin evidencia de producción ni medición, proyecto en rojo 41 %, v2 sin autorización (+69 días), 7 RAID sin responsable. No se archivó. Sin dato: componentes, evidencia de hitos, motivo de v2, decisión de CC-01. |

Por señal (`project-closure`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

**PRY-202 (Migración a la nube) no se puede cerrar por cumplimiento.** El proyecto sigue en rojo, con 41 % de avance según su propio informe del 2026-10-16. El último hito (piloto) está planificado para 2026-11-22, posterior a hoy. Si se cierra, sería por decisión y no hay ninguna registrada.

- **Términos:** ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no los volví a registrar.
- **Criterio de éxito:** el acta dice «Migración a la nube en producción y medido». Ningún documento muestra puesta en producción ni medición, así que no se puede determinar si se cumplió, y la evidencia apunta a que no.
- **Hitos:** el cronograma v2 declara los cuatro hitos cerrados y al 100 %. Tres de ellos no tienen evidencia, y el informe del mismo día reporta 41 %.
- **Fecha:** +69 días (17.8 %) contra la línea base original y 0 contra la vigente. Hubo una replanificación, la v2, sin autorización: la solicitud de cambio CC-01 sigue pendiente de presentarse al comité.
- **Presupuesto (COP):** aprobado 800.000.000, ejecutado 175.437.818 (21.9 %), comprometido 364.802.812 (45.6 %). La proyección al cierre es 881.586.671, un 10.2 % por encima de lo aprobado. CC-01 pide 138.000.000 adicionales, sin decisión. Estas cifras son las que declara el informe de avance, no las contrasté contra contabilidad.
- **RAID:** los 2 riesgos y las 5 incidencias abiertos no tienen responsable, así que no están cerrados. Los dos compromisos del comité del 2026-10-18 están abiertos y ninguno de sus responsables asistió. El de Ricardo Salas no tiene fecha.
- **Lecciones:** dejé tres, cada una anclada a un hecho con fecha. Descarté el resto porque no se podían sustentar.
- **Archivo:** no moví la carpeta ni congelé la ficha. Archivarlo lo sacaría del barrido diario con todo esto abierto. Primero habría que registrar la decisión de cerrarlo.
- **Sin dato:** lo que no se pudo determinar está en la sección «Sin dato» del acta.

La corrida quedó registrada en `estado/corridas/2026-10-23-project-closure-1.md`. El acta completa que le mostré está en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/bancos/espacio/estado/corridas/salida-project-closure.md`.
