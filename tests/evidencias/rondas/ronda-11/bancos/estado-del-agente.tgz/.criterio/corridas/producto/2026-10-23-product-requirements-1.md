# Corrida · 2026-10-23-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T09:24:50 · **Fin:** 2026-10-23T09:25:51 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 16 | — | 35 | 35 | REQ-4202 y REQ-4213 aceptados sin evidencia; 13 aceptados sin proyecto (no hay fichas); REQ-4208 sin decidir hace 208 días |

Por señal (`product-requirements`): `evidence_stale` 13, `requirement_untraced` 13, `requirement_without_acceptance` 3, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1

## Lo que el agente mostró

Corrida registrada y el informe está guardado en `estado-producto/PRD-302/corridas/salida-product-requirements.md`. Los términos ya estaban vigentes, así que no hizo falta aceptarlos de nuevo.

## Registro — Crédito hipotecario digital (PRD-302) · al 2026-10-23
16 requerimientos · 13 decididos · 84.6% con evidencia · 0% con proyecto que lo ejecuta

El 0% significa que no hay fichas de proyecto: `estado/` está vacío. No prueba que nadie lo construya.

**Se va a construir y nadie lo pidió:**
- REQ-4202 (María Restrepo) y REQ-4213 (Jorge Medina) están aceptados sin ninguna cita de quien los pidió.

**Decidido y nadie lo está construyendo:**
- Los 13 aceptados, sin ficha de proyecto que los confirme. El más viejo es REQ-4211, aceptado el 2026-04-08.

**Sin doliente:**
- REQ-4214 es propuesto y no tiene dueño. Elena Duarte, gerente del producto, lo cerraría asignando a una persona.

**Sin criterio de aceptación:**
- REQ-4203, REQ-4204 y REQ-4209, los tres ya aceptados.

**Decidido sin documento que lo respalde:**
- No lo evalué: el cálculo no trae esa señal, así que no afirmo ni descarto el vacío.

**Lleva meses y nadie lo decide** (umbral de 60 días):
- REQ-4208 lleva 208 días propuesto, REQ-4214 lleva 96 y REQ-4207 lleva 92.
- Quien tiene la facultad es el Comité de producto, según la configuración. El cálculo devolvió `authority: null`, así que conviene confirmar que ese es el órgano.
- Se propone decidirlos, no cerrarlos por viejos.

**Evidencia vieja:**
- 13 requerimientos se apoyan en la misma entrevista del 2025-10-15, de hace 12 meses, justo en el umbral.
- Esa entrevista no nombra ningún requerimiento.

| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

La definición declara un volumen mensual de 289 875 y el tablero mide 235 072. La brecha es de 18.9%, por debajo del umbral de 20%. El criterio de éxito de la definición no está escrito en ningún documento.

**Siguiente paso:** hay 13 requerimientos decididos que nadie construye. Puedo correr `/product-trace` cuando existan las fichas. Entre los aceptados ninguno tiene a la vez evidencia, criterio y una cita de quien lo pidió, así que no ofrezco `/product-charter` todavía.
