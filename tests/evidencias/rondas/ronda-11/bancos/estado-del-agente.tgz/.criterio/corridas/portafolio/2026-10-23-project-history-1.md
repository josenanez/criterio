# Corrida · 2026-10-23-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-23T10:02:52 · **Fin:** 2026-10-23T10:04:12 · **Duración:** 80 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 59 | 71 | Historia de PRY-200 sobre 7 documentos (2026-03-25 a 2026-10-20). Trimestres Q2 y Q3 2026 sin documentos. No pude fechar el punto de separación (hay una sola declaración), ni los meses sin sustento; no vi quién autorizó CC-01. Los 88 días entre la fecha base y el recibo del hito son cálculo mío, no de compute. |

Por señal (`project-history`): `milestone_met_without_evidence` 28, `commitment_overdue` 8, `progress_vs_plan` 8, `vendor_deliverable_late` 6, `commitment_undated` 5, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_time` 2, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `rebaseline_unauthorized` 1, `silent` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Reconstruí la historia de PRY-200 (Originación digital) con los 7 documentos que hay, entre 2026-03-25 y 2026-10-20. La corrida quedó registrada como `2026-10-23-project-history-1`, con la salida completa en `estado/corridas/salida-project-history.md`.

Los términos ya estaban vigentes (versión 0.8.0, aceptados el 2026-10-23 por José Francisco Ñáñez), así que no los registré de nuevo.

- **Documentos:** no hay ninguno entre el 2026-03-25 y el 2026-10-14. Los trimestres Q2 y Q3 de 2026 están vacíos, y casi todo lo demás se escribió entre el 14 y el 20 de octubre.
- **Replanificación:** hay una, la CC-01 (+78 días). El fin pasa del 2027-05-30 al 2027-08-16, un atraso de 78 días (18.5 %) contra la línea base original.
- **Aprobación de CC-01:** la solicitud dice "Autorizada por el comité", pero no dice cuál comité ni quién firmó. El acta del comité del 2026-10-17 no la trata.
- **Estado declarado:** amarillo, con 55 % de avance. El plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplido).
- **Compromisos vencidos:** hay dos, de Camilo Beltrán y de Mauricio Pérez. Ninguno de los dos figura entre los asistentes del comité.
- **Cronograma v1:** está fechado el 2026-03-25 pero marca como "cerrado" un hito con fecha 2026-07-18. Con ese archivo no se puede saber cuál era la línea base en marzo.

No pude fechar desde cuándo lo declarado dejó de sostenerse, ni calcular los meses declarando sin sustento. Hay una sola declaración, no una serie. Tampoco pude ver cambios de gobierno, porque no hay documentos de esos meses.

Los 88 días entre la fecha base del hito de diseño funcional y su recibo son un cálculo mío: `compute` no lo da, así que hay que verificarlo. Todas las demás cifras salen de `compute`.

Ofrezco llevar la historia al comité del 2026-10-30, para decidir quién autorizó CC-01 y si se ratifica la línea base v2.
