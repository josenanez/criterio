# Corrida · 2026-10-23-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:17:16 · **Fin:** 2026-10-23T10:18:24 · **Duración:** 68 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 16 | — | 48 | 35 | 13 requerimientos decididos y ninguno tiene proyecto; ninguna de las 13 fichas dice ejecutar PRD-302 |

Por señal (`product-trace`): `evidence_stale` 13, `requirement_untraced` 13, `requirement_without_acceptance` 3, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1

## Lo que el agente mostró

**Trazabilidad — Crédito hipotecario digital (PRD-302), al 2026-10-23**

Ninguno de los 13 requerimientos decididos tiene proyecto, y ninguna de las 13 fichas del portafolio dice ejecutar este producto. Por eso no hay trazas que confirmar ni entregables.

- **Términos:** ya estaban vigentes (v1.2), aceptados a nombre de José Francisco Ñáñez el 2026-10-23.
- **Fichas usadas:** las 13 que hay en `estado/records` (PRY-199 a PRY-211). Las traté como las fichas de proyecto, porque el comando no indica dónde están.
- **Decididos sin proyecto:** los 13 requerimientos aceptados tienen «—» en el campo del proyecto que los ejecuta (acta del comité). Los más antiguos son REQ-4211 (decidido el 2026-04-08), REQ-4204 y REQ-4213 (2026-05-01). El campo «por quién» está vacío en todos y no lo inferí.
- **Propuestos:** REQ-4207, REQ-4208 y REQ-4214 no están decididos y no cuentan en esta brecha. Su problema es que llevan entre 92 y 208 días sin decisión.
- **Lo que un proyecto construye y el registro no tiene:** no hay ningún caso. Nueve fichas nombran otro producto, y PRY-202, PRY-205, PRY-208 y PRY-210 no dicen cuál ejecutan. Ese campo vacío es un hallazgo de esos proyectos y no lo llené.
- **Antes de abrir actas de constitución:** REQ-4203, REQ-4204 y REQ-4209 no tienen criterio de aceptación, y REQ-4202 y REQ-4213 no tienen evidencia. La evidencia de los demás es una sola entrevista de 2025-10-15, que no nombra el requerimiento.
- **Siguiente paso:** `/criterio-product:product-charter` para los 13 decididos, empezando por los más antiguos. Para los 4 proyectos con el producto vacío, la salida es hablar con cada gerente de proyecto.

La corrida quedó registrada como `2026-10-23-product-trace-1`, con 35 hallazgos y 48 segundos. La salida completa está en `estado-producto/PRD-302/corridas/salida-product-trace.md`.
