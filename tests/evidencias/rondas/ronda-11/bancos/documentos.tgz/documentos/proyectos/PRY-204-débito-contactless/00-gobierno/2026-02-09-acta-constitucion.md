# Acta de constitución · Débito contactless

**Código:** PRY-204
**Área dueña:** Tesorería
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Medios de Pago
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2026-02-09

## Objetivo del negocio

Entregar débito contactless para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Medios de Pago el 2026-02-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-19 |
| Cierre | 2027-01-29 |

## Criterio de éxito

Débito contactless en producción y medido.

## Dependencias declaradas

- Ninguna declarada
