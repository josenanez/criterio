# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-15 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-12-13 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-11-18 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-24 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-25 |
| Andrés Lozano | Cerrar la prueba 10 | 2026-10-15 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-30 |
| Rubén Cárdenas | Validar el ambiente 12 | 2026-10-10 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-09 |
| Carlos Peña | Actualizar la matriz 14 | 2026-11-01 |
| Beatriz Cuéllar | Confirmar la fecha 15 | por definir |
| Carlos Peña | Entregar el punto 16 | 2026-10-29 |
| Jorge Medina | Enviar el documento 17 | 2026-10-28 |
| Liliana Torres | Cerrar la prueba 18 | 2026-11-04 |
| Andrés Lozano | Revisar el anexo 19 | 2026-10-13 |
| Javier Hoyos | Validar el ambiente 20 | 2026-11-06 |

## Lo que se dijo

- Camilo Beltrán dice que ya entregó «aprobar el diseño 5». No se presentó acta.
