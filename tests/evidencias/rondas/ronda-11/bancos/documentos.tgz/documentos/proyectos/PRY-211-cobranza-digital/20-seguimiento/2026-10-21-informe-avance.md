# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-21
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.225.619.522 |
| Ejecutado | 2.803.145.619 |
| Proyección al cierre | 6.873.110.762 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
