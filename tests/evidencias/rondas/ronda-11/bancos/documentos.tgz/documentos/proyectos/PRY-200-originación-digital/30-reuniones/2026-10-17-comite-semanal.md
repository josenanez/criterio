# Comité de Banca Empresas · Originación digital

**Fecha:** 2026-10-17
**Asistentes:** María Restrepo, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 4 | 2026-10-20 |
| Mauricio Pérez | Entregar el punto 30 | 2026-10-12 |
