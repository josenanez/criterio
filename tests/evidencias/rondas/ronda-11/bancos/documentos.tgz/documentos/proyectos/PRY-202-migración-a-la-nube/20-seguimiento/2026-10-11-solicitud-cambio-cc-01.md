# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Migración a la nube
**Fecha:** 2026-10-11
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +69 días sobre la línea base vigente |
| Costo | 138.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
