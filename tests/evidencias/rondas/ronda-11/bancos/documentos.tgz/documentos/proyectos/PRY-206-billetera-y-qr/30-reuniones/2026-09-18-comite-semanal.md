# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-09-18
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Gustavo Neira, Liliana Torres, María Restrepo, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-09-26 |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-10-25 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-10-22 |
| Camilo Beltrán | Aprobar el diseño 5 | 2026-10-06 |
| Diana Molina | Actualizar la matriz 6 | por definir |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-05 |
| María Restrepo | Entregar el punto 8 | 2026-10-01 |
