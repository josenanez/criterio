# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-21
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **56%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.202.185.958 |
| Ejecutado | 5.402.665.002 |
| Proyección al cierre | 9.357.294.710 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
