# Informe de avance · Core de depósitos

**Código:** PRY-201
**Fecha de corte:** 2026-10-21
**Gerente:** Carlos Peña

## Estado declarado

**Rojo**

Avance reportado: **90%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.504.098.273 |
| Ejecutado | 494.176.690 |
| Proyección al cierre | 2.812.334.652 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
