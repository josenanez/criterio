# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-09-11
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Gustavo Neira, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | por definir |
| Camilo Beltrán | Cerrar la prueba 2 | 2026-10-07 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-29 |
| Beatriz Cuéllar | Validar el ambiente 4 | 2026-10-07 |
