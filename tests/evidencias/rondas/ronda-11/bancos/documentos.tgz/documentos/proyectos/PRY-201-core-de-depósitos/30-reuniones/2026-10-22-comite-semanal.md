# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-22
**Asistentes:** Carlos Peña, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 18 | 2026-10-25 |
