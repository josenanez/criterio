# Acta de recibo · Integración con el core

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha de recibo:** 2026-10-15
**Recibido por:** Rubén Cárdenas

Se recibe a satisfacción el entregable **Integración con el core**.
