# Comité de Banca Empresas · Migración a la nube

**Fecha:** 2026-10-18
**Asistentes:** María Restrepo, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 30 | 2026-10-29 |
| Ricardo Salas | Entregar el punto 28 | por definir |
