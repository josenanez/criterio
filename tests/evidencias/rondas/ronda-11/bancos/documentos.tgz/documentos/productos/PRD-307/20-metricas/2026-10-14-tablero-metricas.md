# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 51.318 | 2026-10-14 |
