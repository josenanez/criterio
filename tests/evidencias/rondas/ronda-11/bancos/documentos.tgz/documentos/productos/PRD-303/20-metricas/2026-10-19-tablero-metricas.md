# Tablero de métricas · Cuenta PyME

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-19

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 189.221 | 2026-10-19 |
