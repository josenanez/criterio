# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Liliana Torres
**Segmento:** Personas
**Fecha de la definición:** 2026-02-16

## El problema

El segmento Personas no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-07-31 · verificado con el concepto jurídico de cumplimiento del 2026-09-22 (anexo «Verificación del supuesto» del 2026-09-22)

## Proyectos que lo construyen

- Ninguno declarado
