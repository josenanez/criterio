# Tablero de métricas · Cuenta de ahorros joven

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 152.244 | 2026-10-14 |
