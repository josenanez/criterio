# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-05-21
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 84.814 | Caso de negocio, 2026-05-21 |

## Retorno esperado

Retorno esperado en 24 meses.
