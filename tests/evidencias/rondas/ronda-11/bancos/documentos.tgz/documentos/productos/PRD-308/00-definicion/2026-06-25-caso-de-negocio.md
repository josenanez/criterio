# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-06-25
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 245.619 | Caso de negocio, 2026-06-25 |

## Retorno esperado

Retorno esperado en 24 meses.
