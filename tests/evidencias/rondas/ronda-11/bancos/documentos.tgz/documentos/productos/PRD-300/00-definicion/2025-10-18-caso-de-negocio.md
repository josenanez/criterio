# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2025-10-18
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 113.868 | Caso de negocio, 2025-10-18 |

## Retorno esperado

Retorno esperado en 24 meses.
