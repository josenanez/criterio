# Entrevistas · Crédito de libre inversión

**Ronda:** Ronda · 2026-04-15
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-04-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
