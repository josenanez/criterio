# Tablero de métricas · Crédito de libre inversión

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 158.812 | 2026-10-13 |
