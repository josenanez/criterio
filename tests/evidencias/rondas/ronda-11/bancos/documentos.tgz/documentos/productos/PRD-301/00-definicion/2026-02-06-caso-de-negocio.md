# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-02-06
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 158.952 | Caso de negocio, 2026-02-06 |

## Retorno esperado

Retorno esperado en 24 meses.
