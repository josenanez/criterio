# Comité de producto · Crédito de libre inversión

**Fecha:** 2026-10-21
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-02 | — |
| REQ-4901 | Requerimiento REQ-4901 | Diana Molina | se verifica en producción | — | propuesto | 2026-08-10 | — |
| REQ-4902 | Requerimiento REQ-4902 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4903 | Requerimiento REQ-4903 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-18 | — |
| REQ-4904 | Requerimiento REQ-4904 | Jorge Medina | se verifica en producción | — | aceptado | 2026-07-21 | — |
| REQ-4905 | Requerimiento REQ-4905 | Mauricio Pérez | se verifica en producción | — | propuesto | 2026-05-08 | — |
| REQ-4906 | Requerimiento REQ-4906 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-05 | — |
| REQ-4907 | Requerimiento REQ-4907 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-26 | — |
| REQ-4908 | Requerimiento REQ-4908 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-01 | — |
| REQ-4909 | Requerimiento REQ-4909 | Sandra Gil | — | Cliente entrevistado | propuesto | 2026-04-10 | — |
| REQ-4910 | Requerimiento REQ-4910 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4911 | Requerimiento REQ-4911 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-25 | — |
| REQ-4912 | Requerimiento REQ-4912 | Andrés Lozano | — | — | aceptado | 2026-08-09 | — |
| REQ-4913 | Requerimiento REQ-4913 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4914 | Requerimiento REQ-4914 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4915 | Requerimiento REQ-4915 | sin asignar | se verifica en producción | — | propuesto | 2026-07-14 | — |

## Decisiones

- Se mantiene el plan
