# Comité de producto · Microseguros

**Fecha:** 2026-10-20
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | sin asignar | se verifica en producción | — | aceptado | 2026-03-30 | — |
| REQ-4601 | Requerimiento REQ-4601 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4602 | Requerimiento REQ-4602 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4603 | Requerimiento REQ-4603 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-08 | — |
| REQ-4604 | Requerimiento REQ-4604 | Elena Duarte | — | Cliente entrevistado | propuesto | 2026-05-21 | — |
| REQ-4605 | Requerimiento REQ-4605 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4606 | Requerimiento REQ-4606 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-25 | — |
| REQ-4607 | Requerimiento REQ-4607 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4608 | Requerimiento REQ-4608 | Andrés Lozano | — | Cliente entrevistado | propuesto | 2026-04-29 | — |
| REQ-4609 | Requerimiento REQ-4609 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-29 | — |
| REQ-4610 | Requerimiento REQ-4610 | sin asignar | — | — | aceptado | 2026-05-04 | — |
| REQ-4611 | Requerimiento REQ-4611 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4612 | Requerimiento REQ-4612 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4613 | Requerimiento REQ-4613 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-05-13 | — |

## Decisiones

- Se mantiene el plan
