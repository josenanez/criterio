# Tablero de métricas · Pagos QR comercios

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-17

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 115.595 | 2026-10-17 |
