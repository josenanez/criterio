# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-07-13
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 198.421 | Caso de negocio, 2026-07-13 |

## Retorno esperado

Retorno esperado en 24 meses.
