# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-02-02
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 207.837 | Caso de negocio, 2026-02-02 |

## Retorno esperado

Retorno esperado en 24 meses.
