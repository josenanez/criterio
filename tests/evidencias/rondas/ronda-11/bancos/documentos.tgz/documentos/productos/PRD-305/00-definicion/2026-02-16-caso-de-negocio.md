# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-02-16
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 149.327 | Caso de negocio, 2026-02-16 |

## Retorno esperado

Retorno esperado en 24 meses.
