# Tablero de métricas · Crédito hipotecario digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 235.072 | 2026-10-13 |
