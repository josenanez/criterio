# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Felipe Arango
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-05-31

## El problema

El segmento Base de la pirámide no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-10-01 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
