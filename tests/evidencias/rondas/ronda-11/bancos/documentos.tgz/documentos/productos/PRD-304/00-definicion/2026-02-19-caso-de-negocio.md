# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-02-19
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 174.386 | Caso de negocio, 2026-02-19 |

## Retorno esperado

Retorno esperado en 24 meses.
