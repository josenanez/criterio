# Tablero de métricas · Recaudos y cobros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-17

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 134.756 | 2026-10-17 |
