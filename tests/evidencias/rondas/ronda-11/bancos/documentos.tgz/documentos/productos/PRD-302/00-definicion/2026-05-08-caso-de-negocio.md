# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2026-05-08
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 289.875 | Caso de negocio, 2026-05-08 |

## Retorno esperado

Retorno esperado en 24 meses.
