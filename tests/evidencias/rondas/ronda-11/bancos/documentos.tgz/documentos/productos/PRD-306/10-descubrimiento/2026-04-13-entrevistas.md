# Entrevistas · Microseguros

**Ronda:** Ronda · 2026-04-13
**Realizadas por:** Laura Vélez

### Cliente entrevistado · 2026-04-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
