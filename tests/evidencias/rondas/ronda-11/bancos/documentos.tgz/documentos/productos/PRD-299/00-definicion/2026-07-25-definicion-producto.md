# Definición de producto · Ahorro programado

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-25

## El problema

El segmento Personas no tiene ahorro programado.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-09-03 · verificado con el documento técnico del proveedor del 2026-09-29 (anexo «Verificación del supuesto» del 2026-09-29)

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
