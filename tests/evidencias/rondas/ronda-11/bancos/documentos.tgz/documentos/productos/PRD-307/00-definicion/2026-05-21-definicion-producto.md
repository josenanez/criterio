# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Mauricio Pérez
**Segmento:** PyME
**Fecha de la definición:** 2026-05-21

## El problema

El segmento PyME no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-19 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
