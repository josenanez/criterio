# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-05-31
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 232.487 | Caso de negocio, 2026-05-31 |

## Retorno esperado

Retorno esperado en 24 meses.
