# Corrida del 2026-10-23 · product-definition

PRD-306 · 16 requerimientos · 33 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

La definición no tiene criterio de éxito; la única evidencia (una entrevista de 2025-09-23) tiene 13 meses; las cifras del caso de negocio no tienen serie.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Definición — Recaudos (PRD-306) · contrastada al 2026-10-23
**Documento:** 00-definicion/2026-05-20-definicion-producto.md (con el caso de negocio y el anexo de verificación) · **del** 2026-05-20 · 6 afirmaciones

### Lo que la evidencia contradice
Nada. No hay ninguna fuente que diga lo contrario de lo que afirma la definición.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa del umbral (20 %): no hay medición contra la cual comparar |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 214.523 | Caso de negocio, 2026-05-20 | No hay serie medida para `volumen_mensual`. No es contradicción: nadie está midiendo lo que el caso de negocio afirmó. |
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-05-20 | Sin cifra, sin base de cálculo y sin serie. Ni siquiera hay un número que contrastar. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara (`success` en `unknown`).
- **Qué es «Propuesta principal».** La propuesta de la definición es solo ese rótulo; no dice qué se construye.
- **Cuántos microempresarios son ni cuántos no tienen recaudos.** El problema («el segmento Microempresarios no tiene recaudos») se afirma sin tamaño ni país.
- **De dónde sale el 214.523.** El caso de negocio lo cita a sí mismo como fuente.
- **Qué proyecto construye el producto.** La definición dice «Ninguno declarado»; el cálculo no encuentra requerimiento con proyecto (0 de 14 aceptados trazados).
- **Qué significa «el tiempo pactado»** del proveedor, ni con qué proveedor ni qué plazo.
- **Quién decide.** El comité de producto figura como autoridad, pero el acta del 2026-10-23 solo registra a un asistente (Camilo Beltrán), que es también el autor de la definición, del caso de negocio y de las entrevistas.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado | 0: figura verificado el 2026-10-01 | Está marcado como verificado, pero el anexo se declara a sí mismo la evidencia y no recoge qué decía el documento técnico del proveedor. Ese documento no está en la carpeta. Para que la verificación se pueda comprobar: incorporar el documento técnico del 2026-10-01 y escribir el plazo pactado y el plazo medido. Además, el supuesto aparece «declarado el 2026-09-29» dentro de una definición fechada el 2026-05-20, es decir, la definición se editó después de su fecha. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene recaudos (problema) | Una entrevista a un cliente sin nombre: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | 2025-09-23 | Débil. Es lo que alguien dijo, no algo que pagó. Una sola voz, no nombra «recaudos», y no consta que sea microempresario. |
| Hay quien lo pidió (los 16 requerimientos) | La misma entrevista: el acta los atribuye a «Cliente entrevistado» | 2025-09-23 | Débil. La cita no nombra ningún requerimiento. 10 de 14 aceptados la usan; 4 (REQ-4604, 4606, 4608, 4614) están aceptados sin ninguna. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema y 12 requerimientos que se apoyan en esa entrevista | Entrevista del 2025-09-23 | 13 meses (umbral: 12) |

No hay evidencia de demanda posterior a esa entrevista en la carpeta.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Recaudos implica mover dinero de terceros y tratar datos personales de quien paga | No declarado en la definición | No puedo nombrarla sin saber el país | — | **No tengo la norma a la vista.** Esto no es un cumplimiento: es un vacío del barrido. Va a revisión jurídica una vez se declare el país. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Problema:** está escrito, pero sin tamaño ni evidencia vigente.
- **Para quién:** «Microempresarios»; sin criterio de quién cuenta como tal.
- **Quién decide:** el Comité de producto, con un solo asistente registrado en el acta.

Con la ficha como está, quedan además 5 requerimientos aceptados sin criterio de aceptación, 2 propuestos sin decidir hace 142 y 208 días, y 14 aceptados que ningún proyecto ejecuta. Eso corresponde a `/product-requirements` y `/product-trace`.
