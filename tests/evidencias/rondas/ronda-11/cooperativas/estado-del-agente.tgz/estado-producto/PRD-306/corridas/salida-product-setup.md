## Listo — Recaudos (PRD-306)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas, 2025-09-23, una sola cita) · la definición del 2026-05-20 · lo más reciente es el acta del comité del 2026-10-23. Todos legibles (4 `.md`, 1 `.docx`). No hay serie de métricas (la carpeta `20-metricas/` no existe).
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2), fecha 2026-10-23 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 d1497e5f9c284733… (md) y 1972f5ac032ba1ef… (pdf)

**Configuración tomada por defecto (nadie respondió):** gerente de producto Camilo Beltrán (firma la definición y el caso de negocio); quien decide: «Comité de producto» (el acta que decide lleva ese nombre; en ella el único asistente es Camilo Beltrán); estado en `estado-producto/PRD-306`, hermana de la documentación y distinta de `estado/`, que es de otro agente.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Microempresarios no tiene recaudos» | Una cita: cliente entrevistado, «Lo necesito y hoy no lo tengo.» No dice quién es, de qué segmento, ni qué es «lo» | 2025-09-23 (13 meses) |
| «El proveedor cumple el tiempo pactado» (supuesto) | Un supuesto, verificado según el anexo «Verificación del supuesto»: «se confirmó» | 2026-10-01 |
| Volumen mensual de 214.523 | Solo el propio caso de negocio. No hay serie medida con la que contrastarlo | 2026-05-20 |
| «Retorno esperado en 24 meses» | Nada: no trae cifra ni cálculo | — |
| 16 requerimientos en el acta: 14 aceptados, 2 propuestos | 10 de los 14 aceptados (71,4 %) citan «cliente entrevistado»; 4 no citan a nadie | acta 2026-10-23 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito del producto.** Ninguno de los cinco documentos lo dice; el cierre no tendrá contra qué juzgarse.
- **De dónde sale 214.523 al mes**, y qué mide. No hay medición a la vista: nadie está midiendo lo que el caso de negocio afirmó.
- **Qué es la «Propuesta principal».** La propuesta de la definición es solo ese título.
- **El retorno esperado:** una frase sin monto.
- **Qué pidió cada requerimiento.** El acta los llama «Requerimiento REQ-46xx» y no dice qué necesidad cubre ninguno.
- **Qué proyecto ejecuta alguno de los 14 aceptados.** Ninguno tiene proyecto (0,0 % trazado), y la definición declara «Ninguno declarado».
- **Cuál es «el plan»** que el comité decidió mantener («Se mantiene el plan»): no hay plan en la carpeta.
- **Criterio de aceptación** en 5 aceptados: REQ-4601, 4603, 4610, 4611, 4613.
- **Evidencia de demanda** en 4 aceptados: REQ-4604, 4606, 4608, 4614 (el acta no dice quién los pidió).
- **Algo que decida los 2 propuestos:** REQ-4602 lleva 208 días sin decisión y REQ-4607 lleva 142.

### Supuestos sobre los que está escrita
Uno solo declarado: «El proveedor cumple el tiempo pactado», declarado el 2026-09-29 y verificado el 2026-10-01. Dos reparos: (1) la definición está fechada 2026-05-20 pero recoge un supuesto de septiembre, así que se editó después de su fecha; (2) el anexo dice haberse verificado con un documento técnico del proveedor que no está en la carpeta, y no dice qué tiempo se pactó ni qué se midió. Lo cito como verificado porque el anexo se declara completo, pero la evidencia es una línea.
No declara ningún supuesto sobre la demanda: que los microempresarios usarían el producto no figura como supuesto, y por eso nadie lo ha verificado.

### Qué le falta a tu carpeta
- Más descubrimiento: hay una sola cita, de hace 13 meses (`evidence_stale` en 12 requerimientos), para sostener 16. Y las 12 citas del acta como «cliente entrevistado» apuntan a esa misma cita, que no menciona ningún requerimiento.
- La serie de la métrica principal con su fuente (volumen mensual), para contrastar 214.523.
- Un criterio de aceptación que diga qué se verifica: «se verifica en producción» figura en 11 requerimientos y no dice qué mirar.
- El acta de constitución de algún proyecto: sin proyecto que lo ejecute, 14 decisiones del comité no se están construyendo.
- Las decisiones del comité, con quién decidió y cuándo. El acta del 2026-10-23 solo dice «Se mantiene el plan».

**Señales (del cálculo):** `requirement_untraced` 14 · `evidence_stale` 12 · `requirement_without_acceptance` 5 · `requirement_accepted_without_evidence` 4 · `requirement_undecided` 2.

**Lo que no pude hacer:** `sellar` rechazó la lectura («no hay una corrida abierta: va después de `corrida-inicio`»), y este comando dice que aquí no va `corrida-inicio`; la lectura queda sin sellar. Tampoco dejé la marca `_CRITERIO_PRODUCTO.txt` en tu carpeta: es la única escritura dentro de los documentos y nadie respondió que sí.

**Siguiente paso:** `/product-discovery` sobre las entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
