<!-- origen: 30-decisiones/2026-10-23-comite-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de producto · Recaudos

Fecha: 2026-10-23

Asistentes: Camilo Beltrán

Requerimientos revisados

ID

Requerimiento

Doliente

Criterio de aceptación

Quién lo pidió

Estado

Desde

Proyecto que lo ejecuta

REQ-4600

Requerimiento REQ-4600

Elena Duarte

se verifica en producción

Cliente entrevistado

aceptado

2026-08-01

—

REQ-4601

Requerimiento REQ-4601

Liliana Torres

—

Cliente entrevistado

aceptado

2026-07-29

—

REQ-4602

Requerimiento REQ-4602

Gustavo Neira

se verifica en producción

Cliente entrevistado

propuesto

2026-03-29

—

REQ-4603

Requerimiento REQ-4603

Carlos Peña

—

Cliente entrevistado

aceptado

2026-05-13

—

REQ-4604

Requerimiento REQ-4604

Felipe Arango

se verifica en producción

—

aceptado

2026-03-25

—

REQ-4605

Requerimiento REQ-4605

Laura Vélez

se verifica en producción

Cliente entrevistado

aceptado

2026-08-06

—

REQ-4606

Requerimiento REQ-4606

Óscar Ramírez

se verifica en producción

—

aceptado

2026-06-22

—

REQ-4607

Requerimiento REQ-4607

Elena Duarte

se verifica en producción

Cliente entrevistado

propuesto

2026-06-03

—

REQ-4608

Requerimiento REQ-4608

Ricardo Salas

se verifica en producción

—

aceptado

2026-07-25

—

REQ-4609

Requerimiento REQ-4609

Carlos Peña

se verifica en producción

Cliente entrevistado

aceptado

2026-08-23

—

REQ-4610

Requerimiento REQ-4610

Rubén Cárdenas

—

Cliente entrevistado

aceptado

2026-03-25

—

REQ-4611

Requerimiento REQ-4611

Ricardo Salas

—

Cliente entrevistado

aceptado

2026-04-29

—

REQ-4612

Requerimiento REQ-4612

Laura Vélez

se verifica en producción

Cliente entrevistado

aceptado

2026-07-16

—

REQ-4613

Requerimiento REQ-4613

Jorge Medina

—

Cliente entrevistado

aceptado

2026-06-09

—

REQ-4614

Requerimiento REQ-4614

Óscar Ramírez

se verifica en producción

—

aceptado

2026-04-27

—

REQ-4615

Requerimiento REQ-4615

Liliana Torres

se verifica en producción

Cliente entrevistado

aceptado

2026-05-12

—

Decisiones

• Se mantiene el plan
