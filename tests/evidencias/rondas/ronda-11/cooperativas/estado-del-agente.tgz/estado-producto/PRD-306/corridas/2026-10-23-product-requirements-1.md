# Corrida del 2026-10-23 · product-requirements

PRD-306 · 16 requerimientos · 18 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

4 aceptados sin evidencia (4604, 4606, 4608, 4614); 14 aceptados sin proyecto; 5 sin criterio; 2 propuestos sin decidir (4602, 4607)

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Registro — Recaudos (PRD-306) · al 2026-10-23
16 requerimientos · 14 decididos · 71.4% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió (4 de 14 decididos):
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4604 | Requerimiento REQ-4604 | aceptado (2026-03-25) | Felipe Arango |
| REQ-4614 | Requerimiento REQ-4614 | aceptado (2026-04-27) | Óscar Ramírez |
| REQ-4606 | Requerimiento REQ-4606 | aceptado (2026-06-22) | Óscar Ramírez |
| REQ-4608 | Requerimiento REQ-4608 | aceptado (2026-07-25) | Ricardo Salas |

### Decidido y nadie lo está construyendo
Los 14 aceptados tienen proyecto vacío; ninguno está trazado a un proyecto (0%).
REQ-4604, 4610 (2026-03-25), 4614 (04-27), 4611 (04-29), 4603 (05-13), 4615 (05-12), 4606 (06-22), 4613 (06-09), 4612 (07-16), 4608 (07-25), 4601 (07-29), 4600 (08-01), 4605 (08-06), 4609 (08-23).

### Sin doliente, o con un área en vez de una persona
Ninguno: los 16 tienen una persona como doliente.

### Sin criterio de aceptación
Solo decididos:
| REQ | Estado | Doliente |
|---|---|---|
| REQ-4601 | aceptado | Liliana Torres |
| REQ-4603 | aceptado | Carlos Peña |
| REQ-4610 | aceptado | Rubén Cárdenas |
| REQ-4611 | aceptado | Ricardo Salas |
| REQ-4613 | aceptado | Jorge Medina |

### Decidido sin documento que lo respalde
El cálculo no emite esta señal; no la afirmo. Existe un acta de comité (30-decisiones/2026-10-23-comite-producto.docx) que no se contrastó requerimiento por requerimiento en esta corrida.

### Lleva meses y nadie lo decide
Umbral: 60 días. Tiene la facultad de decidir: Comité de producto (autoridad del producto; gerente: Camilo Beltrán).
| REQ | Propuesto hace | Quién tiene la facultad |
|---|---|---|
| REQ-4602 (Gustavo Neira) | 208 días (2026-03-29) | Comité de producto |
| REQ-4607 (Elena Duarte) | 142 días (2026-06-03) | Comité de producto |

### Evidencia vieja
Umbral: 12 meses. 12 requerimientos se sostienen en la misma entrevista del 2025-09-23 (hace 13 meses): REQ-4600, 4601, 4602, 4603, 4605, 4607, 4609, 4610, 4611, 4612, 4613, 4615. La cita («Lo necesito y hoy no lo tengo.») no nombra ninguno de ellos: el acta dice que lo pidió «Cliente entrevistado».

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 14 | 0 | 0 | 0 |

Nota: a los 2 propuestos no se les exige evidencia ni criterio de aceptación. La definición no declara criterio de éxito (desconocido).
