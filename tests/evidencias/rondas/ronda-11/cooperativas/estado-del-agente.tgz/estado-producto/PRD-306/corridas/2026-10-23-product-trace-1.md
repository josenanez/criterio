# Corrida del 2026-10-23 · product-trace

PRD-306 · 16 requerimientos · 40 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

14 decididos y ninguno tiene proyecto; PRY-211 dice ejecutar «recaudos» y ningún REQ lo nombra

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Recaudos (PRD-306) · al 2026-10-23
14 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

(Hay 16 requerimientos en el registro; 2 siguen en «propuesto» y no cuentan como decididos.)

### Decidido y nadie lo está construyendo
Ninguno de los 14 requerimientos aceptados declara proyecto: en el acta del comité (`30-decisiones/2026-10-23-comite-producto.docx`) la traza dice «Ninguno declarado», y la definición del producto dice lo mismo en «Proyectos que lo construyen» (`00-definicion/2026-05-20-definicion-producto.md`). El acta no registra quién decidió ninguno («Por quién» vacío en los 14).

| REQ | Decidido el | Por quién | Dueño |
|---|---|---|---|
| REQ-4604 | 2026-03-25 | no consta | Felipe Arango |
| REQ-4610 | 2026-03-25 | no consta | Rubén Cárdenas |
| REQ-4614 | 2026-04-27 | no consta | Óscar Ramírez |
| REQ-4611 | 2026-04-29 | no consta | Ricardo Salas |
| REQ-4615 | 2026-05-12 | no consta | Liliana Torres |
| REQ-4603 | 2026-05-13 | no consta | Carlos Peña |
| REQ-4613 | 2026-06-09 | no consta | Jorge Medina |
| REQ-4606 | 2026-06-22 | no consta | Óscar Ramírez |
| REQ-4612 | 2026-07-16 | no consta | Laura Vélez |
| REQ-4608 | 2026-07-25 | no consta | Ricardo Salas |
| REQ-4601 | 2026-07-29 | no consta | Liliana Torres |
| REQ-4600 | 2026-08-01 | no consta | Elena Duarte |
| REQ-4605 | 2026-08-06 | no consta | Laura Vélez |
| REQ-4609 | 2026-08-23 | no consta | Carlos Peña |

El más antiguo lleva 212 días decidido sin proyecto (REQ-4604 y REQ-4610).

### La traza no se confirma
Nada que confirmar: ningún REQ dice ejecutarlo un proyecto. Se compararon contra las 13 fichas de `estado/records` (PRY-199 a PRY-211).

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-211 Cobranza digital | Campo «producto» = «recaudos» (acta de constitución del 2025-06-24) | Sí: ninguno de los 16 REQ lo nombra |

Cautela: la ficha dice «recaudos», no el código PRD-306; el cruce es por nombre. Hay que confirmar con quien lleve PRY-211 que es este producto. Si lo es, PRY-211 puede ser el proyecto de varios de los 14 decididos, pero eso no se puede asumir desde aquí: ni la ficha ni el registro lo dicen.

Otras fichas: 4 declaran otro producto (PRY-200, 201, 203, 204, 206, 207 con productos distintos; PRY-199 declara PRD-299) y PRY-202, 205, 208, 209, 210 no dicen qué producto ejecutan (hallazgo de esas fichas, no de este registro). Ninguna menciona PRD-306.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4600 | aceptado | comité, 2026-08-01 | — | no | — |
| REQ-4601 | aceptado | comité, 2026-07-29 | — | no | — |
| REQ-4602 | propuesto | sin decidir (208 días) | — | no | — |
| REQ-4603 | aceptado | comité, 2026-05-13 | — | no | — |
| REQ-4604 | aceptado | comité, 2026-03-25 | — | no | — |
| REQ-4605 | aceptado | comité, 2026-08-06 | — | no | — |
| REQ-4606 | aceptado | comité, 2026-06-22 | — | no | — |
| REQ-4607 | propuesto | sin decidir (142 días) | — | no | — |
| REQ-4608 | aceptado | comité, 2026-07-25 | — | no | — |
| REQ-4609 | aceptado | comité, 2026-08-23 | — | no | — |
| REQ-4610 | aceptado | comité, 2026-03-25 | — | no | — |
| REQ-4611 | aceptado | comité, 2026-04-29 | — | no | — |
| REQ-4612 | aceptado | comité, 2026-07-16 | — | no | — |
| REQ-4613 | aceptado | comité, 2026-06-09 | — | no | — |
| REQ-4614 | aceptado | comité, 2026-04-27 | — | no | — |
| REQ-4615 | aceptado | comité, 2026-05-12 | — | no | — |

La cadena se rompe en el segundo eslabón: la decisión existe y está citada; el proyecto no. Con evidencia de demanda: 10 de 14 decididos (71,4 %); los otros 4 (REQ-4604, 4606, 4608, 4614) están aceptados sin evidencia.

### Sin fichas a la vista
Se leyeron las 13 fichas disponibles. No hay ficha de ningún proyecto declarado por el registro, porque el registro no declara ninguno.

### Después
Hay 14 decididos sin proyecto. Cuando alguno esté listo, `/criterio-product:product-charter`. Sobre PRY-211, la salida es una conversación con su gerente de proyecto para saber si construye Recaudos.
