# Corrida del 2026-10-23 · product-spec

PRD-306 · 16 requerimientos · 39 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

Borrador sin secciones de comportamiento: los 14 aceptados no tienen título ni necesidad en el registro. Dijo que no sabe: qué pide cada requerimiento, criterios verificables, casos borde, dependencias con otros equipos; no corrió el barrido normativo.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribe el agente; lo cierra Camilo Beltrán (gerente de producto), con la autoridad del Comité de producto. Este agente no aprueba.

# Especificación — Recaudos (PRD-306) · borrador del 2026-10-23

**Resultado en una línea:** el registro no alcanza para especificar comportamiento. Los 14 requerimientos aceptados tienen solo un identificador: sin título, sin necesidad, sin prioridad. Escribir qué hace cada uno sería inventarlo, así que este borrador deja los huecos a la vista y no rellena ninguno.

## Qué problema resuelve
«El segmento Microempresarios no tiene recaudos.» (`00-definicion/2026-05-20-definicion-producto.md`). La definición no dice qué es un «recaudo» para este producto ni qué lo haría resuelto. El criterio de éxito del producto no está en ningún documento.

## Alcance
### Entra
Los 14 requerimientos en estado `aceptado`, citados al acta `30-decisiones/2026-10-23-comite-producto.docx`: REQ-4600, 4601, 4603, 4604, 4605, 4606, 4608, 4609, 4610, 4611, 4612, 4613, 4614, 4615. Entran solo como identificadores: el registro no dice qué piden.

### No entra
- **REQ-4602 y REQ-4607**: están en `propuesto` (desde 2026-03-29 y 2026-06-03). Nadie los decidió, y especificarlos sería decidirlos.
- Todo lo que no esté en el registro. La definición dice «Propuesta principal» como propuesta, y eso tampoco es contenido especificable.
- Diseño técnico, estimación, costo y fechas: no son de este documento.

## Comportamiento
**Sin secciones.** Ningún requerimiento tiene título ni necesidad en el registro (`need: no encontrado`; el título es el propio identificador). Escribir una sección de comportamiento sería agregar algo que no sale del registro. Hasta que el doliente diga qué pide cada requerimiento, cada uno queda en la última tabla.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (tal cual el acta) | REQ-4600, 4604, 4605, 4606, 4608, 4609, 4612, 4614, 4615 | No se puede decir: no dice qué se observa, ni qué valor cuenta como cumplido. Dos personas mirando lo construido no tienen cómo coincidir. | **No.** Es un lugar donde verificar, no un criterio. Hallazgo. |
| **Sin criterio** | REQ-4601, 4603, 4610, 4611, 4613 | — | — |

No redacto criterios sustitutos. Hacerlo exigiría saber qué pide cada requerimiento. Cuando el doliente lo diga, la forma verificable es «qué se mide, con qué umbral, en qué condiciones», por ejemplo «llega en menos de X s en el percentil 95», y entonces habrá que comprobar que alguien mide ese percentil.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» | Sí, el 2026-10-01 (`00-definicion/2026-10-01-verificacion-supuesto.md`, resultado «se confirmó»). Dos reparos: el anexo cita un «documento técnico del proveedor» que no está entre los documentos, y la definición (2026-05-20) registra el supuesto como declarado el 2026-09-29, posterior a su propia fecha. | Camilo Beltrán: aportar el documento del proveedor y aclarar la fecha. |
| Cifra del caso de negocio: volumen mensual 214.523 | **No hay medición** en la carpeta; es una cifra declarada (`00-definicion/2026-05-20-caso-de-negocio.md`). Ningún criterio de volumen puede apoyarse en ella todavía. | Camilo Beltrán: fuente medida o confirmar que es una proyección. |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada uno de los 14 requerimientos (título y necesidad) | No hay nada que especificar | Cada doliente: Elena Duarte (4600), Liliana Torres (4601, 4615), Carlos Peña (4603, 4609), Felipe Arango (4604), Laura Vélez (4605, 4612), Óscar Ramírez (4606, 4614), Ricardo Salas (4608, 4611), Rubén Cárdenas (4610), Jorge Medina (4613) |
| Criterio de aceptación de 5 requerimientos y reescritura de los otros 9 («se verifica en producción») | Se construye sin poder decir si quedó bien | Los mismos dolientes, con Camilo Beltrán |
| Criterio de éxito del producto | Nada permite decir que Recaudos funcionó | Camilo Beltrán / Comité de producto |
| Casos borde (sin conexión, pago duplicado, cliente que se va antes de la confirmación, recaudo parcial o rechazado) | Los decide quien construye, sin que nadie los haya pedido | Dolientes de los requerimientos de pago; Camilo Beltrán |
| Quién aceptó cada requerimiento: el acta dice «aceptado» pero no quién | No se sabe quién tiene la autoridad que sostiene la aceptación | Comité de producto |
| Evidencia de demanda: la única es una entrevista del 2025-09-23 (más de 12 meses, vencida), con la cita «Lo necesito y hoy no lo tengo», que no nombra ningún requerimiento. REQ-4604, 4606, 4608 y 4614 no tienen evidencia alguna. | Se aceptó sin sustento citable | Camilo Beltrán |
| Qué proyecto construye cada requerimiento: ninguno declarado, y la definición lista «Ninguno» | Lo aceptado no tiene quién lo construya. El acta dice «Se mantiene el plan» y no hay plan en los documentos. | Camilo Beltrán |
| **Otros equipos:** ningún documento nombra a otros equipos, pero un recaudo suele depender de pagos, core y el proveedor. Nada de eso está acordado con nadie. | Dependencias descubiertas durante la construcción | Camilo Beltrán |
| **Obligaciones normativas:** el producto mueve dinero y datos de microempresarios. **No corrí el barrido normativo en esta corrida**, así que no hay obligaciones citadas ni puedo decir que no las haya. | Riesgo de incumplimiento sin ver | Camilo Beltrán, con Cumplimiento/Jurídico; correr `regulatory-sweep` |

## Requerimientos aceptados que esta especificación no cubre
| ID | Título | Por qué no |
|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Sin necesidad en el registro; criterio no verificable |
| REQ-4601 | Requerimiento REQ-4601 | Sin necesidad; sin criterio de aceptación |
| REQ-4603 | Requerimiento REQ-4603 | Sin necesidad; sin criterio de aceptación |
| REQ-4604 | Requerimiento REQ-4604 | Sin necesidad; criterio no verificable; sin evidencia |
| REQ-4605 | Requerimiento REQ-4605 | Sin necesidad; criterio no verificable |
| REQ-4606 | Requerimiento REQ-4606 | Sin necesidad; criterio no verificable; sin evidencia |
| REQ-4608 | Requerimiento REQ-4608 | Sin necesidad; criterio no verificable; sin evidencia |
| REQ-4609 | Requerimiento REQ-4609 | Sin necesidad; criterio no verificable |
| REQ-4610 | Requerimiento REQ-4610 | Sin necesidad; sin criterio de aceptación |
| REQ-4611 | Requerimiento REQ-4611 | Sin necesidad; sin criterio de aceptación |
| REQ-4612 | Requerimiento REQ-4612 | Sin necesidad; criterio no verificable |
| REQ-4613 | Requerimiento REQ-4613 | Sin necesidad; sin criterio de aceptación |
| REQ-4614 | Requerimiento REQ-4614 | Sin necesidad; criterio no verificable; sin evidencia |
| REQ-4615 | Requerimiento REQ-4615 | Sin necesidad; criterio no verificable |

Cobertura: **0 de 14** aceptados con comportamiento especificado.

---
**Pie.** Sale del registro de requerimientos de PRD-306 (16 requerimientos: 14 aceptados, 2 propuestos), al 2026-10-23, a partir del acta del comité de producto del 2026-10-23, la definición y el caso de negocio del 2026-05-20, la verificación del supuesto del 2026-10-01 y las entrevistas del 2025-09-23. Cubre 0 requerimientos con comportamiento; 14 quedan listados como no cubiertos. Términos v1.2, aceptados por José Francisco Ñáñez el 2026-10-23: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** no ofrezco `/product-charter`. Los vacíos no están cerrados y el producto no tiene criterio de éxito.
