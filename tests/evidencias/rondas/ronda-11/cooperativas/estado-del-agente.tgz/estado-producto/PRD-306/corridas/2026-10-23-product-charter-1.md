# Corrida del 2026-10-23 · product-charter

PRD-306 · 16 requerimientos · 40 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

Borrador de acta para REQ-4600, sin firma ni ficha creada. Dijo que no sabe: quién aceptó el requerimiento, patrocinador, gerente y autoridad del proyecto, criterio de éxito medible, necesidad, y barrido normativo no hecho.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Recaudos · borrador del 2026-10-23
**Producto:** PRD-306 Recaudos · **Requerimientos:** REQ-4600

> Términos: vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23). No hubo que pedirlos de nuevo.
> Sesión sin interfaz: las preguntas se respondieron con la opción sugerida. La única fue si seguir con los vacíos de abajo: se sigue, marcándolos como vacíos del acta, sin rellenarlos.

## Verificación previa (requirement-record)
| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | Sí, estado «aceptado» desde 2026-08-01. **Quién lo aceptó no está dicho.** | 30-decisiones/2026-10-23-comite-producto.docx |
| Criterios de aceptación | Hay uno, «se verifica en producción». No dice qué se mide ni contra qué umbral. | 30-decisiones/2026-10-23-comite-producto.docx |
| Evidencia de demanda con cita | Hay una, con reservas: no nombra el requerimiento y tiene 13 meses. | 10-descubrimiento/2025-09-23-entrevistas.md |
| Autoridad declarada | Solo la del producto (Comité de producto). **La del gerente del proyecto no está declarada.** | 30-decisiones/2026-10-23-comite-producto.docx |

Faltan dos condiciones completas (quién aceptó, autoridad del gerente) y dos están flojas (criterio y demanda). Se sigue marcándolas como vacíos del acta.

## Qué problema resuelve
«El segmento Microempresarios no tiene recaudos.» (00-definicion/2026-05-20-definicion-producto.md). La necesidad concreta de REQ-4600 **no está dicha en ningún documento** (campo «necesidad»: no encontrado). El título del requerimiento es genérico, «Requerimiento REQ-4600».

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| «se verifica en producción» (30-decisiones/2026-10-23-comite-producto.docx) | **No está dicho.** Falta qué se observa en producción, quién lo observa y con qué umbral. Tal como está, el cierre no se puede juzgar meses después. |

El criterio de éxito del producto tampoco existe (`definition.success`: no encontrado en la definición del 2026-05-20).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 (doliente: Elena Duarte) | Entrevista del 2025-09-23: «Lo necesito y hoy no lo tengo.» (10-descubrimiento/2025-09-23-entrevistas.md). La cita no nombra el requerimiento; el comité dice que lo pidió «Cliente entrevistado». |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4601 a REQ-4615 | Los otros 15 requerimientos revisados por el comité | Esta acta cubre solo REQ-4600 por el argumento del comando. Ninguno tiene proyecto asignado (columna «Proyecto que lo ejecuta» en «—», 30-decisiones/2026-10-23-comite-producto.docx). Si deben entrar en este proyecto, se agregan como argumento y se redacta de nuevo. REQ-4602 y REQ-4607 además siguen «propuesto», así que no podrían entrar. |

No hay un motivo de exclusión dicho por nadie en los documentos; el de arriba es el del alcance de este comando, no una decisión del comité.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Camilo Beltrán es el gerente del *producto* (00-definicion/2026-05-20-definicion-producto.md); no hay base para proponerlo como gerente del proyecto. Nombrarlo es de quien tiene la autoridad.
- **Comité:** Comité de producto, mensual (30-decisiones/2026-10-23-comite-producto.docx; configuración del producto). Asistente de la sesión del 2026-10-23: solo Camilo Beltrán.
- **Autoridad del gerente del proyecto:** no está dicha.
- **Doliente del requerimiento:** Elena Duarte (30-decisiones/2026-10-23-comite-producto.docx).
- **Quién decidió aceptarlo:** no está dicho (`decision.who` vacío). El acta del comité solo registra la decisión «Se mantiene el plan».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-09-29) | Sí, el 2026-10-01 con el documento técnico del proveedor (00-definicion/2026-10-01-verificacion-supuesto.md) | Sin riesgo abierto mientras siga verificado. Aun así, la verificación se hizo contra un documento del proveedor, no contra entregas, y se lleva como dependencia (proveedor) del proyecto. |

REQ-4600 no declara supuestos propios (`assumptions`: vacío). No hay supuestos sin verificar que pasen a ser riesgos, y eso no prueba que no existan.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Recaudos puede rozar pagos y datos personales | No evaluada | Ninguna citada en los documentos | **No se hizo el barrido normativo.** Ningún documento de la carpeta nombra normas. No se afirma que no haya obligaciones. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4600 | La decisión de construir no tiene autor al que acudir | Comité de producto / Camilo Beltrán |
| Autoridad del gerente del proyecto | El proyecto escala todo o no escala nada | Quien nombre al gerente |
| Patrocinador y gerente del proyecto | La ficha nace sin dueño | Comité de producto |
| Criterio de éxito medible | El cierre no se puede juzgar | Elena Duarte con Camilo Beltrán |
| La necesidad de REQ-4600 | No hay qué construir con precisión | Elena Duarte |
| Demanda ligada al requerimiento y vigente | Una cita genérica de hace 13 meses (umbral de 12) sostiene la decisión | Camilo Beltrán |
| Éxito del producto (`definition.success`) | Sin referencia contra la que medir el proyecto | Camilo Beltrán |
| Cifra sin medición: volumen_mensual 214.523, solo declarada (00-definicion/2026-05-20-caso-de-negocio.md) | El caso de negocio no tiene un dato medido que lo sostenga | Camilo Beltrán |
| Prioridad del requerimiento | Sin orden frente a los otros 15 | Comité de producto |
| Barrido normativo | Obligaciones sin descubrir | Quien tenga la función de cumplimiento |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad de patrocinar el proyecto; hoy no está dicho quién es. **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`. El estado declarado no lo escribe este agente en ningún caso.

## Qué sigue
Una vez firmada el acta, el gerente que se nombre instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si el producto se está construyendo sin preguntarle a nadie.
