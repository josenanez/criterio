# Corrida del 2026-10-23 · product-discovery

PRD-306 · 16 requerimientos · 38 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 14 |
| `evidence_stale` | 12 |
| `requirement_without_acceptance` | 5 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 2 |

5 piezas leídas, una sola de descubrimiento (1 entrevista, 1 voz, 1 cita): ningún tema agrupable, registrado como dicho una sola vez; ningún REQ vinculado a la cita. No se pudo sellar porque la ficha no se escribió en esta corrida. Sin cifras de entrevistados ni fuentes públicas.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Descubrimiento — Recaudos (PRD-306) · 1 pieza de descubrimiento al 2026-10-23

Se leyeron las 5 piezas del producto (ninguna se había procesado antes). Solo una es material de descubrimiento: `10-descubrimiento/2025-09-23-entrevistas.md`, una ronda con una sola persona entrevistada. Las otras cuatro son definición, caso de negocio, verificación de supuesto y acta de comité; no contienen voz de cliente.

### Temas
> **Necesidad principal** (título tomado del propio documento) — 1 de 1 piezas, 1 voz
> — *«Lo necesito y hoy no lo tengo.»* · Cliente entrevistado (sin nombre ni segmento en el documento), 2025-09-23, entrevista de Camilo Beltrán
> **En el registro:** **ninguno la nombra.** El acta del 2026-10-23 atribuye a «Cliente entrevistado» el origen de 12 de los 16 requerimientos, pero la cita no nombra ninguno. No se vinculó la cita a ningún REQ.

Con una sola voz no hay tema agrupado: esto es el caso de «dicho una sola vez» y se registra así. La cita no dice qué es «lo» que necesita. No hay problema identificable para agrupar.

### Dicho y nunca convertido en nada
Ninguno demostrable. Un solo dicho no cuenta como tema repetido.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | Cliente entrevistado (anónimo) | 2025-09-23 |

No se promueve ni se descarta; decide el gerente. Lleva 13 meses sin otra entrevista.

### Afirmaciones numéricas de los entrevistados
Ninguna. La única cifra del material, `volumen_mensual` = 214.523, es del caso de negocio (Camilo Beltrán, 2026-05-20), no de un entrevistado; no tiene serie medida que la contraste (`measured` vacío).

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna. La entrevista no contradice ningún requerimiento. Sí hay un hecho para el gerente: el registro cita esta misma entrevista de 2025-09-23 como única evidencia de 12 de los 16 requerimientos. Está vencida (13 meses, umbral de 12). Lo dice el cálculo, no yo.

### Estado del registro tras recalcular (script)
- 16 requerimientos: 14 aceptados, 2 propuestos. 12 con evidencia en total (10 de los 14 aceptados, 71,4 %), 0 con proyecto (0 %).
- Señales: 12 evidencia vencida, 14 aceptados sin proyecto, 5 aceptados sin criterio de aceptación, 4 aceptados sin evidencia (REQ-4604, 4606, 4608, 4614), 2 propuestos sin decidir (REQ-4602 a 208 días, REQ-4607 a 142 días).
- Sin definir en la definición: criterio de éxito.

### Lo que este comando no pudo hacer
- No creó requerimientos: no hay tema con doliente que alguien asuma.
- El script `sellar` se negó: la ficha `producto.json` no se escribió en esta corrida. Las 5 piezas quedan **sin sellar** y la próxima corrida las volverá a leer.

**Siguiente paso sugerido:** más entrevistas antes de sacar temas; `/product-requirements` para el registro con sus vacíos.
