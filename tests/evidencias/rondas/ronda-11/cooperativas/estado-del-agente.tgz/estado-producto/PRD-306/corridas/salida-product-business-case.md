# Caso de negocio — Recaudos (PRD-306) · borrador del 2026-10-23
**Desde:** definición del 2026-05-20 y caso de negocio del 2026-05-20 · **Cifras con fuente:** 0 de 1 con origen propio (la única cifra cita al propio caso de negocio)

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-23 (v1.2); no se registraron de nuevo.

## Qué problema resuelve, y para quién
"El segmento Microempresarios no tiene recaudos." (`00-definicion/2026-05-20-definicion-producto.md`, 2026-05-20). Segmento: Microempresarios. La propuesta dice solo "Propuesta principal": no describe qué se construye. El criterio de éxito no está declarado en ningún documento.

## Qué se construye
Fuente: `30-decisiones/2026-10-23-comite-producto.docx` (2026-10-23). 16 requerimientos: 14 aceptados, 2 propuestos (REQ-4602, REQ-4607; quedan fuera del caso hasta que se decidan). Ninguno tiene proyecto que lo ejecute. Los títulos son genéricos ("Requerimiento REQ-46xx"): el documento no dice qué es cada uno.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4600, 4605, 4609, 4612, 4615 | aceptado | "Cliente entrevistado" (Entrevistas 2025-09-23); criterio: "se verifica en producción" |
| REQ-4601, 4603, 4610, 4611, 4613 | aceptado | "Cliente entrevistado"; **sin criterio de aceptación** |
| REQ-4604, 4606, 4608, 4614 | aceptado | **Nadie lo pidió** (campo vacío); criterio: "se verifica en producción" |

La única evidencia de demanda de la carpeta es una cita anónima del 2025-09-23: "Lo necesito y hoy no lo tengo." (tema: necesidad principal). No se asocia a ningún requerimiento y tiene 13 meses (umbral: 12), así que está vencida.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 214.523 | Declarada | Caso de negocio (Camilo Beltrán); la fuente que cita es el propio caso, sin documento de origen | 2026-05-20 |
| Retorno esperado | "en 24 meses" | Declarada, sin cifra | Caso de negocio; no tiene monto, base ni método | 2026-05-20 |

No hay ninguna cifra medida. El volumen no dice si es transacciones, recaudos o pesos, ni si es el volumen esperado del producto o el del segmento.

### Donde la cifra declarada y la medida no coinciden
No aplica: no existe serie medida del producto. No se puede contrastar `volumen_mensual`, y eso es un vacío (ver abajo).

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | — | **No está en ningún documento** |
| Costo operativo / equipo / contratos | — | No hay contratos ni cotizaciones en la carpeta |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-09-29; verificado 2026-10-01 con el documento técnico del proveedor; el anexo `2026-10-01-verificacion-supuesto.md` lo da por confirmado) | No se dice. Tampoco se dice qué tiempo se pactó ni quién es el proveedor. | Ya verificado. El documento técnico del proveedor no está en la carpeta; solo el anexo que lo resume. |
| Supuesto implícito: el volumen mensual de 214.523 se alcanzará | El retorno deja de tener base | Nadie todavía → pasa a assumption-tracking |
| Supuesto implícito: el retorno ocurre en 24 meses | La decisión de aprobar cambia | Nadie todavía → pasa a assumption-tracking |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso | Camilo Beltrán / finanzas del negocio |
| Origen de `volumen_mensual` 214.523 y su unidad | La cifra se cita a sí misma | Camilo Beltrán |
| Monto y método del retorno esperado | "Retorno en 24 meses" no se puede evaluar | Camilo Beltrán / finanzas |
| Criterio de éxito con métrica y fecha de corte | Sin él el producto no se puede cerrar meses después | Comité de producto |
| Serie medida del volumen | Permite contrastar lo declarado | Sistema donde vive el producto |
| Qué pasa si no se hace; alternativas consideradas | El caso no dice ninguna | Camilo Beltrán |
| Qué se construye (propuesta real) | "Propuesta principal" no es una propuesta | Camilo Beltrán |
| Demanda vinculada a los 14 aceptados; 4 sin quien los pida, 5 sin criterio de aceptación | Aceptados sin sustento | Doliente de cada REQ / comité |
| Proyecto que construye el producto | "Ninguno declarado"; el comité mantiene el plan sin proyecto | Comité de producto |

## Cómo se sabrá si funcionó
Sin declarar. El criterio de éxito es el vacío que decide: no hay métrica ni fecha de corte contra la cual verificar el caso meses después. El único número disponible (volumen_mensual) podría ser esa métrica, pero nadie lo ha dicho.

## Si hay otros productos publicados
No hay otros productos publicados a la vista en esta carpeta; no se pudo hacer el cruce de métricas con product-overlap.

## Después
Ofrezco pasar los dos supuestos implícitos a assumption-tracking. `/product-charter` queda en espera: el caso no tiene costo ni criterio de éxito.
