# Corrida · 2026-10-23-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:23:40 · **Fin:** 2026-10-23T10:24:19 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 16 | — | 18 | 37 | 4 aceptados sin evidencia (4604, 4606, 4608, 4614); 14 aceptados sin proyecto; 5 sin criterio; 2 propuestos sin decidir (4602, 4607) |

Por señal (`product-requirements`): `requirement_untraced` 14, `evidence_stale` 12, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 4, `requirement_undecided` 2

## Lo que el agente mostró

## Registro — Recaudos (PRD-306) · al 2026-10-23
16 requerimientos · 14 decididos · 71.4% con evidencia · 0% con proyecto que lo ejecuta

Los términos (v1.2) ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-23, así que no los registré otra vez.

### Se va a construir y nadie lo pidió
Cuatro requerimientos aceptados no tienen ninguna cita de quien los pidió.

| REQ | Aceptado | Doliente |
|---|---|---|
| REQ-4604 | 2026-03-25 | Felipe Arango |
| REQ-4614 | 2026-04-27 | Óscar Ramírez |
| REQ-4606 | 2026-06-22 | Óscar Ramírez |
| REQ-4608 | 2026-07-25 | Ricardo Salas |

### Decidido y nadie lo está construyendo
Ninguno de los 14 aceptados tiene un proyecto que lo ejecute. Van del REQ-4604 y el REQ-4610 (2026-03-25) al REQ-4609 (2026-08-23).

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 16 tienen una persona como doliente.

### Sin criterio de aceptación
Solo cuentan los decididos: REQ-4601 (Liliana Torres), REQ-4603 (Carlos Peña), REQ-4610 (Rubén Cárdenas), REQ-4611 (Ricardo Salas) y REQ-4613 (Jorge Medina).

### Decidido sin documento que lo respalde
El cálculo no emite esta señal, así que no afirmo nada. Hay un acta de comité del 2026-10-23, pero no la contrasté requerimiento por requerimiento.

### Lleva meses y nadie lo decide
El umbral es de 60 días. Quien tiene la facultad de decidir es el Comité de producto, cuyo gerente es Camilo Beltrán.

| REQ | Propuesto hace | Doliente |
|---|---|---|
| REQ-4602 | 208 días | Gustavo Neira |
| REQ-4607 | 142 días | Elena Duarte |

### Evidencia vieja
Doce requerimientos se sostienen en la misma entrevista del 2025-09-23, de hace 13 meses (el umbral es 12). Son los REQ-4600, 4601, 4602, 4603, 4605, 4607, 4609, 4610, 4611, 4612, 4613 y 4615. La cita («Lo necesito y hoy no lo tengo.») no nombra ninguno de ellos. El acta solo dice que lo pidió «Cliente entrevistado».

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 14 | 0 | 0 | 0 |

A los 2 propuestos no les exigí evidencia ni criterio de aceptación. La definición del producto tampoco declara un criterio de éxito.

La corrida quedó registrada como `2026-10-23-product-requirements-1`, con 37 hallazgos en 18 segundos. Lo que te mostré arriba está guardado en `estado-producto/PRD-306/corridas/salida-product-requirements.md`.

Hay 14 requerimientos decididos que nadie construye. Puedo seguir con `/product-trace` para trazarlos. Ninguno cumple a la vez aceptado, con evidencia vigente y con criterio, así que `/product-charter` no tiene todavía un candidato claro. Los más cercanos son los REQ-4600, 4605, 4609, 4612 y 4615, que tienen criterio y evidencia, aunque vieja.
