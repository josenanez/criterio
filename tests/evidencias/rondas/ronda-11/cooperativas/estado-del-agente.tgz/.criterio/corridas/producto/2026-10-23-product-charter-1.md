# Corrida · 2026-10-23-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4600

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4600

**Inicio:** 2026-10-23T10:27:36 · **Fin:** 2026-10-23T10:28:38 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 40 | 37 | Borrador de acta para REQ-4600, sin firma ni ficha creada. Dijo que no sabe: quién aceptó el requerimiento, patrocinador, gerente y autoridad del proyecto, criterio de éxito medible, necesidad, y barrido normativo no hecho. |

Por señal (`product-charter`): `requirement_untraced` 14, `evidence_stale` 12, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 4, `requirement_undecided` 2

## Lo que el agente mostró

El borrador del acta de REQ-4600 está escrito, pero no se creó la ficha del proyecto. Esa se crea después de que una persona firme el acta. Hoy no se sabe quién puede firmarla, porque no hay patrocinador nombrado.

Los términos de esta versión ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-23, así que no hubo que pedirlos de nuevo.

REQ-4600 está aceptado y tiene doliente (Elena Duarte), pero se arrastran estos vacíos, que marqué sin rellenar:
- **Quién lo aceptó:** el acta del comité solo registra «Se mantiene el plan».
- **Criterio de éxito:** «se verifica en producción» no dice qué se mide ni contra qué umbral, y el producto tampoco tiene criterio de éxito.
- **Demanda:** la única cita («Lo necesito y hoy no lo tengo.») no nombra el requerimiento y tiene 13 meses. El umbral configurado es de 12.
- **Gobierno:** no están dichos el patrocinador, el gerente del proyecto ni su autoridad. Camilo Beltrán es gerente del producto, no del proyecto.
- **Normas:** no se hizo el barrido, porque ningún documento nombra normas. No afirmo que no haya obligaciones.

También pesa que el volumen mensual de 214.523 del caso de negocio es una cifra declarada, sin medición que la sostenga.

Del supuesto verificado («El proveedor cumple el tiempo pactado») no sale ningún riesgo abierto. Pasa al proyecto como dependencia del proveedor. REQ-4601 a REQ-4615 quedan fuera, porque el comando recibió solo REQ-4600. REQ-4602 y REQ-4607 siguen en «propuesto», así que no podrían entrar.

Después de la firma, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Con su ficha publicada, `/product-trace` podrá confirmar la traza.

La corrida quedó registrada como `2026-10-23-product-charter-1`.

Archivos en `estado-producto/PRD-306/corridas/`:
- `salida-product-charter.md`
