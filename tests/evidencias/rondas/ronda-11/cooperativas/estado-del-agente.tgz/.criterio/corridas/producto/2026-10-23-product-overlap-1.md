# Corrida · 2026-10-23-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-300

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-300

**Inicio:** 2026-10-23T11:16:49 · **Fin:** 2026-10-23T11:17:15 · **Duración:** 25 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

The argument asked for PRD-300, but the only configured product here is PRD-306. There's no `.criterio/producto/PRD-300/config.json`.

**No hay configuración para PRD-300.** La única que existe es `.criterio/producto/PRD-306/config.json`. No la usé en su lugar ni inventé una para PRD-300, así que me detengo aquí. No corrí `terminos`, `corrida-inicio`, `overlap` ni `corrida`, y no escribí ninguna salida.

Para continuar, elige una de estas dos:
- Corre `/criterio-product:product-setup PRD-300` para crear su configuración.
- Corre `/criterio-product:product-overlap PRD-306` si ese era el producto que querías.
