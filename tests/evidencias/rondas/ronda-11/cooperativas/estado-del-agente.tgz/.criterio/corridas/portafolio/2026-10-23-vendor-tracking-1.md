# Corrida · 2026-10-23-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-23T10:56:44 · **Fin:** 2026-10-23T10:57:39 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 30 | 67 | Proveedor Talento Solidario (CT-989): 2 entregables vencidos sin recibo, 0 aceptados; sin facturación, vencimiento ni preaviso en los documentos; estado declarado Verde sin sustento. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

## Lo que el agente mostró

Terminé el informe de proveedores de PRY-203 (Aportes sociales en línea). El hallazgo central: el proveedor Talento Solidario (contrato CT-989) tiene dos entregables vencidos sin recibo, y el proyecto aparece en Verde.

- **Términos:** ya estaban vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23). No hubo que registrar nada.
- **Entregables:**
  - Licenciamiento del módulo: vencido hace 150 días.
  - Bolsa de horas de desarrollo: vencida hace 49 días.
  - Ninguno tiene acta de recibo en la carpeta, y hay 0 aceptados. Cada uno vale 395.187.394 COP.
  - Un tercero, Parametrización de líneas de crédito, vence el 2026-12-14.
- **Estado declarado:** el informe de avance del 2026-10-22 dice Verde, 65 %, sin mencionar al proveedor. Tres hitos del proyecto figuran como cumplidos sin evidencia.
- **Contrato:** el contrato dice "en curso" para Parametrización, y la ficha lo registra como pendiente. Es una discrepancia menor.
- **Compromisos vencidos:** ninguno. El único compromiso (Camilo Beltrán, para 2026-11-13) sigue abierto, y la minuta no dice si Camilo Beltrán es del proveedor.
- **Lo que no pude saber:**
  - El contrato no trae fecha de terminación, renovación ni preaviso, así que no puedo decir si hay un preaviso por vencer.
  - No hay ningún documento con montos facturados, así que el cruce contra lo facturado no se pudo hacer.
  - Falta la autoridad del proyecto y su fase.

El informe sugiere llevar esto al comité del 2026-10-30, con la pregunta de si se facturó algo contra esos entregables.

La corrida quedó registrada como `2026-10-23-vendor-tracking-1`. Lo que te mostré está en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/cooperativas/espacio/estado/corridas/salida-vendor-tracking.md`.

El registro cuenta los 13 proyectos del portafolio (67 hallazgos), porque `compute` los recorre todos. El informe cubre solo PRY-203.
