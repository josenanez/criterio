# Corrida · 2026-10-23-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view recaudos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T11:09:43 · **Fin:** 2026-10-23T11:11:12 · **Duración:** 89 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 38 | 67 | Producto recaudos con un solo proyecto (PRY-211): sin vista de producto, se reportó el proyecto. Verde declarado contradicho por 3 hitos sin evidencia, 63 puntos de brecha de avance y proyección +25,7 %. No se sabe: autoridad, fase, cuál de avance o hitos es el erróneo; fuentes sin marcar. 5 proyectos sin producto declarado. |
| `product-view` | 13 | — | — | 67 | Producto recaudos con un solo proyecto (PRY-211): sin vista de producto, se reportó el proyecto. Verde declarado contradicho por 3 hitos sin evidencia, 63 puntos de brecha de avance y proyección +25,7 %. No se sabe: autoridad, fase, cuál de avance o hitos es el erróneo; fuentes sin marcar. 5 proyectos sin producto declarado. Segundo registro: el primero salió sin archivo de salida por una ruta mal escrita. |

Por señal (`product-view`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

Por señal (`product-view`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

## Lo que el agente mostró

## Producto «recaudos» al 2026-10-23

Cifras de `portafolio.py compute` al 2026-10-23. Los términos v1.2, aceptados por José Francisco Ñáñez el 2026-10-23, ya estaban vigentes, así que no los registré de nuevo.

**Recaudos tiene un solo proyecto: PRY-211 «Cobranza digital».** La vista por producto no aporta nada con un solo proyecto, así que reporto el proyecto.

- **Dinero:** el proyecto trae las cuatro cifras, así que la suma está completa (1 de 1).
  - Aprobado: COP 4.200.000.000.
  - Comprometido: COP 3.403.064.146 (81,0 %).
  - Ejecutado: COP 1.718.932.257.
  - Proyección: COP 5.280.911.293, **25,7 % sobre lo aprobado**.
- **Fecha:** el fin del plan es 2026-03-07 y no hay desviación contra la línea base.
- **El verde declarado no se sostiene.** El informe del 2026-10-19 dice «verde» y 37 % de avance.
  - Los tres hitos están declarados cumplidos sin evidencia (394, 312 y 230 días desde su vencimiento).
  - El plan respalda 100 % y el informe dice 37 %, una brecha de 63 puntos.
  - Los documentos no permiten decidir cuál de las dos cifras está mal.
- **Compromiso sin fecha:** Óscar Ramírez, «Entregar el punto 13», del comité del 2026-10-10.
- **Dependencias:** no tiene, ni con otros proyectos ni internas.
- **Lo que no sé:** la ficha no trae autoridad ni fase. Los campos de identidad, plan y presupuesto aprobado tienen 16 meses. Las 15 fuentes están sin marcar como evidencia o declaración.
- **Proyectos sin producto declarado:** son 5 de los 13: PRY-202, 205, 208, 209 y 210. Nadie puede responder por el conjunto al que sirven, y no puedo descartar que alguno toque recaudos. No leí el área dueña en esta corrida.
- **Para el comité del 2026-10-30:** PRY-211 merece llegar como proyecto, no como decisión de producto.

**Registro:** la primera vez escribí la salida en una ruta equivocada, y esa corrida (`2026-10-23-product-view-1`) quedó sin archivo de salida. Copié el archivo a `estado/corridas/salida-product-view.md` y volví a registrar la corrida como `2026-10-23-product-view-2`, que sí tiene la salida. El segundo registro no midió el tiempo (`segundos` quedó vacío), porque la medición se hizo en el primero. Dejé ambos registros en `estado/corridas/`.
