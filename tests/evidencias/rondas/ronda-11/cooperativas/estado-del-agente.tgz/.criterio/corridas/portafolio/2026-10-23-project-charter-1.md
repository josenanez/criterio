# Corrida · 2026-10-23-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-208 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-208

**Inicio:** 2026-10-23T11:03:44 · **Fin:** 2026-10-23T11:04:57 · **Duración:** 74 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 45 | 67 | Revisión del acta 2025-08-12: sin autoridad del gerente, objetivo = solución, alcance y exclusiones con marcador de posición, criterio de éxito sin métrica ni quién mide, sin supuestos/hitos/cadencia, dependencias 'ninguna' contradichas por el informe del 2026-10-20. No sé si hay versiones posteriores o delegaciones fuera de la carpeta. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

## Lo que el agente mostró

**Revisión del acta de PRY-208 (Motor de crédito).** El acta existe, es del 2025-08-12, y le falta la autoridad del gerente más otros campos clave. La corrida quedó registrada.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no hubo que pedirlos de nuevo. No encontré una revisión anterior de esta acta. Solo hay dos documentos de PRY-208: el acta y el informe de avance del 2026-10-20.

| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | No está | No hay umbral de monto ni de cambio de alcance que Jorge Medina pueda decidir sin comité. El ajuste de reglamento que pidió el Consejo y el posible cambio normativo del supervisor suben al comité por defecto, o se deciden sin saber si había facultad. |
| Objetivo de negocio | Es la solución: «Entregar motor de crédito…» | No dice qué resultado de negocio se busca. Sin eso no se puede juzgar si un cambio de alcance sigue sirviendo al fin. |
| Alcance | «Componente 1, 2, 3» | El 79% reportado no se puede contrastar contra componentes sin nombre ni contenido. |
| Exclusiones | «Lo que otro proyecto cubre» | No nombra el proyecto ni lo excluido. Cualquier solicitud de cambio puede alegar estar dentro o fuera con igual derecho. |
| Criterio de éxito | «En producción y medido» | No tiene métrica, umbral ni quién mide. No se puede incumplir, así que el cierre no tiene contra qué evaluarse. |
| Supuestos y restricciones | No están | El riesgo regulatorio y el ajuste de reglamento no tienen un supuesto de origen con el que compararse. |
| Dependencias | «Ninguna» | Contradice el informe del 2026-10-20, donde el piloto depende de un ajuste del reglamento y hay un riesgo regulatorio. |
| Hitos y cadencia | No están | Solo hay fecha de inicio y de cierre, así que el atraso no se veía antes del cierre. Nadie está obligado a reportar en una fecha dada. |
| Comité | Comité de Educación | A confirmar: el acta no explica por qué ese comité aprobó 18.000 millones COP para un motor de crédito. |
| Fechas | Cierre pactado 2026-03-17 | Venció hace más de siete meses y el informe sigue en rojo al 79%, sin una línea base nueva en los documentos. |

Patrocinador (Camilo Beltrán), gerente y presupuesto (18.000.000.000 COP) sí están completos.

No sé si existe una versión posterior del acta, una delegación de autoridad o una aprobación de cambio de fechas fuera de la carpeta.

**Siguientes pasos que ofrezco:**
- **Autoridad del gerente:** llevar su definición al comité del 2026-10-30. Es una decisión de gobierno, no un trámite.
- **Registro RAID:** pasar dos supuestos implícitos a `/raid-log PRY-208`: que no habría cambio normativo y que el reglamento no exigiría ajuste antes del piloto.

Archivos en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/cooperativas/espacio/estado/corridas/`:
- `salida-project-charter.md` (la revisión completa)
- `2026-10-23-project-charter-1.md` (el registro de la corrida; el id es `2026-10-23-project-charter-1`)
