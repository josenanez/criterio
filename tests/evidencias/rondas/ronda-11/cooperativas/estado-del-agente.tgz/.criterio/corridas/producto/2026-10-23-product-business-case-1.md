# Corrida · 2026-10-23-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:25:19 · **Fin:** 2026-10-23T10:26:23 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 16 | — | 39 | 37 | Borrador del caso de negocio: 1 cifra declarada (volumen_mensual 214.523, se cita a sí misma), 0 medidas, 0 costos. Dije que no sabía: costo de construir, origen y unidad del volumen, monto del retorno, criterio de éxito, alternativas. Sin otros productos publicados para cruzar. |

Por señal (`product-business-case`): `requirement_untraced` 14, `evidence_stale` 12, `requirement_without_acceptance` 5, `requirement_accepted_without_evidence` 4, `requirement_undecided` 2

## Lo que el agente mostró

Armé el borrador del caso de negocio de Recaudos (PRD-306). Está listo como estructura, pero el caso en sí está casi vacío. Tiene una sola cifra, ninguna cifra medida y ningún costo.

Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-23, así que no los registré de nuevo.

**Lo que dice el borrador**
- **Cifras:** la única es `volumen_mensual` = 214.523, declarada por Camilo Beltrán el 2026-05-20. La fuente que cita es el propio caso de negocio, y no dice si cuenta transacciones, recaudos o pesos. El retorno aparece solo como "en 24 meses", sin monto ni método.
- **Contraste con la serie medida:** no hay serie medida del producto, así que no pude contrastar lo declarado contra lo medido. Lo dejé como vacío.
- **Costos:** no hay ninguno en los documentos, y ese es el primer vacío. Sin el costo de construir hay una propuesta, no un caso de negocio que evaluar.
- **Requerimientos:** de los 16 del registro, 14 están aceptados y 2 propuestos. De los aceptados, 4 no tienen quién los pidió y 5 no tienen criterio de aceptación. Ninguno tiene proyecto que lo ejecute.
- **Demanda:** la única evidencia es una cita anónima de la ronda de entrevistas del 2025-09-23. No se ata a ningún requerimiento y ya pasó el umbral de 12 meses.
- **Supuestos:** "el proveedor cumple el tiempo pactado" está verificado el 2026-10-01. El documento técnico del proveedor no está en la carpeta, solo el anexo que lo resume. Agregué dos supuestos implícitos, el volumen y el plazo del retorno, que quedan sin responsable y listos para pasar a assumption-tracking.
- **Éxito:** el criterio de éxito no está declarado en ningún documento.
- **Otros productos:** no hay otros productos publicados, así que no hice el cruce de métricas.

La corrida quedó registrada con 16 casos, 37 señales abiertas y 39 segundos medidos.

Archivos en `estado-producto/PRD-306/corridas/`:
- `salida-product-business-case.md`
- `2026-10-23-product-business-case-1.md`
