# Corrida · 2026-10-23-portfolio-setup-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-setup documentos/proyectos

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:42:08 · **Fin:** 2026-10-23T10:44:49 · **Duración:** 161 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-setup` | 3 | 79 | 113 | 18 | 0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); tiempo hasta el primer resultado no medido; 3 proyectos leídos (PRY-205, PRY-209, PRY-204), 18 señales, 2 verdes contradichos por la evidencia |

Por señal (`portfolio-setup`): `milestone_met_without_evidence` 6, `progress_vs_plan` 3, `commitment_overdue` 2, `declared_vs_evidence` 2, `vendor_deliverable_late` 1, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `commitment_undated` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Vera quedó instalada y probada con tres de tus 13 proyectos. Esos tres dieron 18 señales, y dos de ellos declaran verde con evidencia en contra. Esto es lo que quedó:

- **Carpeta y aviso:** usé `documentos/proyectos` y la marqué con `_CRITERIO_PORTAFOLIO.txt`. Quedaste como PMO. El comité es semanal y el próximo es el viernes 2026-10-30, así que el informe llega el miércoles 28, en presentación.
- **Términos:** quedó registrada la aceptación de José Francisco Ñáñez (términos 1.2, versión 0.8.0). El comprobante, en Markdown y PDF, está en `.criterio/terminos/`.
- **Qué asumí:** en esta sesión nadie respondía, así que tomé las respuestas sugeridas. El nombre de la organización, «Cooperativas», lo tomé del nombre de la carpeta de trabajo; cámbialo si no es el correcto.

**Los tres proyectos:**
- **PRY-209 (declara verde, 35%):**
  - Tiene 118 días de atraso contra la línea base original.
  - El cronograma v2 ya mueve la salida a producción a 2027-03-05, pero la solicitud de cambio CC-01 sigue sin autorización.
  - Tres hitos aparecen cerrados sin acta de recibo.
  - El avance declarado (35%) queda lejos de lo que el plan sostiene (80–100%).
- **PRY-204 (declara verde, 37%):**
  - Se pagó la factura FV-1222, por COP 1.064.377.272, sin acta de recibo, aunque el contrato la exige.
  - El licenciamiento del módulo lleva 60 días vencido.
  - Dos compromisos vencieron sin evidencia: el punto 20, de Jorge Medina (hace 9 días), y el punto 11, de Elena Duarte (hace 5).
- **PRY-205 (declara rojo, 67%):** el plan solo sostiene 25–50% de avance, y el hito de diseño funcional aparece cerrado sin acta.

**Pendientes:** quedan 10 proyectos y 61 documentos por leer. Estimo que tomarían unas tres veces lo que tomó esta prueba. Ocho cronogramas `.xml` no los lee el lector estándar y habrá que leerlos como texto. Ninguna acta dice cuánto puede decidir el gerente sin subir a comité.

Registré la corrida (`2026-10-23-portfolio-setup-1`). El tiempo hasta el primer resultado no se midió, porque esta sesión no tenía interfaz. ¿Corro el portafolio completo?

Los archivos están en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/cooperativas/espacio/`:
- `estado/corridas/salida-portfolio-setup.md`
- `estado/records/`
- `.criterio/portafolio/config.json`
