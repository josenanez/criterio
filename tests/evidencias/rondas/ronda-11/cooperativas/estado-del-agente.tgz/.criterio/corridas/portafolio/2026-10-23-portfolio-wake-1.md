# Corrida · 2026-10-23-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T11:12:37 · **Fin:** 2026-10-23T11:15:15 · **Duración:** 159 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 41 | 67 | Barrido sin cambios (79 documentos); confirmación: 5 preguntas (PRY-205 y PRY-208), sin respuesta en sesión desatendida; no sé producto, autoridad ni fase de esos dos proyectos. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

## Lo que el agente mostró

Hoy tocaban el barrido y la confirmación. El barrido no encontró cambios en los 79 documentos, así que no recalculé ningún proyecto. La confirmación quedó en cinco preguntas sin respuesta, porque nadie contesta en esta sesión.

- **Términos:** ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no hubo que registrarlos de nuevo.
- **Peticiones:** no había ninguna en el servidor.
- **Umbrales:** ninguno cruzó nada hoy, porque no cambió ningún documento.
- **Preguntas de confirmación:** son cinco, sobre los dos proyectos en rojo, PRY-205 y PRY-208. Son el producto y la autoridad de cada uno, y la fase de PRY-205. Ninguno de esos datos aparece en los documentos. Los dejé como «no encontrado», sin inventar valores. No se repiten: quedan reportadas como preguntadas el 2026-10-23, sin respuesta.
- **Registro:** dejé constancia del barrido y de la confirmación, y registré la corrida (41 segundos). La salida está en `estado/corridas/salida-portfolio-wake.md`.

Vuelvo el 2026-10-24. El comité del 2026-10-30 pide el informe el 2026-10-28.

## Respuesta 2

El mapa quedó escrito en `.criterio/rostrum/config.json`, y los términos 1.2 quedaron aceptados por José Francisco Ñáñez el 2026-10-23. Los comprobantes en Markdown y PDF están en `.criterio/terminos/`.

El mapa tiene 3 entradas de la familia `pmo`: Vera (portafolio de Cooperativas), Samuel (PRY-206) y Alba (PRD-306). No se dejó ninguna fuera. Falta marcar la carpeta de documentos de PRD-306 con `/criterio-product:product-setup`. El portal se levanta con `/criterio-server:server-start`.

Guardé el mapa antes de mostrar los términos, al revés del orden del flujo. La consulta de términos no devuelve el texto mientras `config.json` no exista, y ese archivo lo crea el paso de guardar. Los términos se mostraron completos antes de registrar la aceptación.

## Respuesta 3

Rostrum está corriendo en **http://127.0.0.1:8788/** y responde 200. Lo levanté en la forma «para mirarlo un rato». El 8787 ya estaba ocupado, así que usé el 8788.

**Términos:** están vigentes (versión 1.2). José Francisco Ñáñez los aceptó para esta prueba el 2026-10-23, y el registro y su comprobante ya estaban en el mapa. Lo que Criterio le dice a quien lo usa:
- Produce borradores de trabajo, no decisiones ni asesoría.
- Solo lee los documentos que usted le indique, y puede equivocarse. Cada dato lleva su cita, y la verificación es suya.
- Los documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo.
- Garantía y responsabilidad: licencia Apache 2.0.
- Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Mapa:** el mapa revisado contra el disco no tiene entradas nuevas, desaparecidas ni sin estado. Tiene tres: el portafolio (Vera), el proyecto PRY-206 (Samuel) y el producto PRD-306 (Alba). Todos son de la familia PMO. El informe de la PMO ya existía en `reportes/`, así que no hizo falta correr `portfolio-report`.

**Qué hay y para quién:**

| Ruta | Para quién |
|---|---|
| `/` (portada y formulario de peticiones) | Todos |
| `/pmo` y `/decisiones` (informes PMO y comité) | La PMO, el comité y el patrocinador |
| `/proyectos` (13) y `/productos` (8) | Quien responde por cada proyecto o producto |
| `/corridas` (33 corridas) | Quien audita |
| `/estado.json` | Un mecanismo, no una persona |

No aparecen `/familia/cfo`, `/familia/clo` ni `/vence`, porque el mapa solo trae la familia PMO.

**Qué enlace pasar a quién:**
- **Patrocinador:** `/`, y `/decisiones` si necesita el material del comité.
- **PMO:** `/pmo`.
- **Gerencia:** `/proyectos` y `/productos`.

Hoy esos enlaces solo abren en este equipo (`127.0.0.1`) y dejan de funcionar cuando se apague el servidor. Cada página dice de cuándo es lo que muestra, y conviene avisar a quien reciba el enlace.

**Lo que Rostrum no hace:**
- No calcula; solo sirve lo que los agentes ya escribieron.
- No escribe ninguna ficha. Lo único que crea son las peticiones, en la carpeta `peticiones/` del agente elegido, donde esperan a que ese agente despierte.
- No autentica.
- No manda correos ni notificaciones.

**Para que quede corriendo:** hay que pedirle a la organización un host y un puerto dentro de la red, y publicarlo detrás de su control de acceso (`--abierto`). Con eso basta: no necesita base de datos, certificado ni salida a internet. Cuando haya un host, puedo dar la unidad de `systemd` con las rutas reales del mapa.
