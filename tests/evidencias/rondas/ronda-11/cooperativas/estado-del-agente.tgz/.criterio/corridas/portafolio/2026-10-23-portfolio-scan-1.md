# Corrida · 2026-10-23-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-23; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-23T10:44:54 · **Fin:** 2026-10-23T10:51:11 · **Duración:** 376 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 79 | 358 | 67 | 10 fichas nuevas de 61 documentos leídos; 18 sin cambio (PRY-204, 205, 209 intactas). Nada que mover desde entrada/ (no existe). Mirar: PRY-210 línea base v2 sin CC-01 aprobada; PRY-203 CT-989 con 2 entregables vencidos; PRY-206 compromisos vencidos y reprogramados; hitos cerrados sin acta; PRY-207 en silencio. Los 8 .xml figuran como no legibles en el inventario pero se leyeron. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 23, `progress_vs_plan` 8, `commitment_overdue` 8, `declared_vs_evidence` 7, `commitment_undated` 7, `commitment_rescheduled` 4, `vendor_deliverable_late` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `vendor_invoiced_without_delivery` 1, `silent` 1, `variance_cost` 1

## Lo que el agente mostró

Barrido terminado: leí 61 de los 79 documentos y dejé 10 fichas nuevas. Quedaron selladas y la corrida está registrada (`2026-10-23-portfolio-scan-1`, 358 s medidos).

Los términos ya estaban vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23), así que no hubo que registrarlos de nuevo.

- **Documentos:** los 18 restantes no cambiaron desde la corrida anterior y no se abrieron. Eran los de PRY-204, PRY-205 y PRY-209, cuyas fichas quedaron intactas.
- **Fichas nuevas:** PRY-199, 200, 201, 202, 203, 206, 207, 208, 210 y 211.
- **PRY-206:** la ficha del gerente (`ficha-pm.json`) está guardada entera en `pm_record`, sin mezclarla con mi lectura. El código no emitió discrepancias entre las dos.
- **Hallazgos:** el código calculó 67, la mayoría hitos declarados cerrados sin acta de recibo (23).
- **Qué mirar:**
  - **PRY-210:** el cronograma v2 ya mueve el piloto 28 días, pero la solicitud de cambio CC-01 sigue «pendiente de presentación al comité».
  - **PRY-203:** el contrato CT-989 tiene dos entregables vencidos sin acta.
  - **PRY-206:** hay 4 compromisos vencidos, 5 sin fecha y 4 reprogramados; uno se movió 6 veces.
  - **PRY-207:** lleva días sin documentos nuevos y su cierre comprometido (2026-07-17) ya pasó.
- **Ilegibles:** ninguno. El inventario marcó 8 cronogramas .xml como no legibles, pero `texto.py` los convirtió y los leí; lo dejé dicho en la salida.
- **Carpeta `entrada/`:** no existe, así que no moví ni dejé pendiente ningún archivo.

La salida completa quedó en `estado/corridas/salida-portfolio-scan.md`. Con más de un proyecto, el siguiente paso es `/criterio-portfolio:portfolio-report`.

Criterio produce borradores de trabajo; la verificación es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
