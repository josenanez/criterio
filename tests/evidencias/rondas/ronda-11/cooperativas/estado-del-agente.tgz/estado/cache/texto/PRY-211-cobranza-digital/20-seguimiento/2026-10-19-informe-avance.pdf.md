<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-19
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 37%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.403.064.146
Ejecutado 1.718.932.257
Proyección al cierre 5.280.911.293

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
