<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Crédito de libranza digital
Código: PRY-200
Fecha de corte: 2026-10-18
Gerente: Ricardo Salas

Estado declarado
Amarillo
Avance reportado: 76%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió el concepto pendiente del ente supervisor
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 548.775.948
Ejecutado 524.552.530
Proyección al cierre 1.227.187.227

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
