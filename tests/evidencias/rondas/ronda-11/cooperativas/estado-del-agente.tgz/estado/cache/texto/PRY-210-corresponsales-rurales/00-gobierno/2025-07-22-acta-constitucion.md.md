<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/2025-07-22-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-22

## Objetivo del negocio

Entregar corresponsales rurales para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Tecnología el 2025-07-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-01 |
| Cierre | 2026-09-15 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
