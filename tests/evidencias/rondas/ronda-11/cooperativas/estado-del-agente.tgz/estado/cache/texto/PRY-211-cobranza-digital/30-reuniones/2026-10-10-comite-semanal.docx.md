<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Consejo de Administración · Cobranza digital

Fecha: 2026-10-10

Asistentes: Mauricio Pérez, Camilo Beltrán

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 13

por definir
