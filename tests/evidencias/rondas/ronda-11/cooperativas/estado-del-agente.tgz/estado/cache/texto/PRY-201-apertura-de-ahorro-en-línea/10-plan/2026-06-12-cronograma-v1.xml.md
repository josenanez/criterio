<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2026-06-12-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2026-08-16 | 2026-08-16 | 2026-08-16 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-10-10 | 2026-10-10 | 2026-10-10 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2026-12-04 | 2026-12-04 | 2026-12-04 | 50% | hito | 2FS | — |
| 4 | 4 | Piloto con asociados | 2027-01-28 | 2027-01-28 | 2027-01-28 | 50% | hito | 3FS | — |
| 5 | 5 | Salida a producción | 2027-03-24 | 2027-03-24 | 2027-03-24 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2026-08-16 | 2026-08-16 | cerrado |
| Ambiente de pruebas certificado | 2026-10-10 | 2026-10-10 | cerrado |
| Integración con el core cooperativo | 2026-12-04 | 2026-12-04 | en curso |
| Piloto con asociados | 2027-01-28 | 2027-01-28 | en curso |
| Salida a producción | 2027-03-24 | 2027-03-24 | en curso |
