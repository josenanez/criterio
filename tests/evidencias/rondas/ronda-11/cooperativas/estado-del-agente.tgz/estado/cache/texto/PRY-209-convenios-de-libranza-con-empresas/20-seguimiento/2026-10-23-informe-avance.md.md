<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Convenios de libranza con empresas

**Código:** PRY-209
**Fecha de corte:** 2026-10-23
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.279.342.312 |
| Ejecutado | 1.632.928.205 |
| Proyección al cierre | 3.138.649.409 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del proveedor del core cooperativo
