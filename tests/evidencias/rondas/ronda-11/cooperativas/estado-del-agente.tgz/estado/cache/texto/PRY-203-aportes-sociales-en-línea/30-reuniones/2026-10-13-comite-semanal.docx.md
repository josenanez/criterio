<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Aportes sociales en línea

Fecha: 2026-10-13

Asistentes: Rubén Cárdenas, Sandra Gil

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 4

2026-11-13
