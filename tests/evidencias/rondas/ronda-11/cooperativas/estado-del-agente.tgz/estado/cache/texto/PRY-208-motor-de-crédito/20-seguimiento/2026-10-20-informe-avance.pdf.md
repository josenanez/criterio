<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de crédito
Código: PRY-208
Fecha de corte: 2026-10-20
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 79%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.233.189.668
Ejecutado 6.747.710.727
Proyección al cierre 17.386.572.826

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
