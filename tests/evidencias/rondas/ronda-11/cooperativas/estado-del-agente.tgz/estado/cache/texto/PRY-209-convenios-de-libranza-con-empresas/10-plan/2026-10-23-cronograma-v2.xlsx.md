<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-10-23-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-10-06 | 2025-10-06 | cerrado
Ambiente de pruebas certificado | 2026-01-13 | 2026-01-13 | cerrado
Integración con el core cooperativo | 2026-04-22 | 2026-04-22 | cerrado
Piloto con asociados | 2026-07-31 | 2026-07-31 | cerrado
Salida a producción | 2026-11-07 | 2027-03-05 | en curso
