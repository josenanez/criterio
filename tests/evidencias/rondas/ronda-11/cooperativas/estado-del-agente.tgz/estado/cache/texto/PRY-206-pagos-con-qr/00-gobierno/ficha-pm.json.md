<!-- origen: PRY-206-pagos-con-qr/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-206",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "name": {
 "value": "Pagos con QR",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Bienestar social",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "product": {
 "value": "pagos QR",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "manager": {
 "value": "Laura Vélez",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Riesgos",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 79,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-19",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-06-16",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "end_date": {
 "value": "2025-12-31",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-06-06",
 "start_date": "2025-06-16",
 "end_date": "2025-12-31",
 "reason": "Aprobación inicial del acta de constitución",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-08-21",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "current_date": {
 "value": "2025-08-21",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-06-06-cronograma-v1.xml"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-10-26",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "current_date": {
 "value": "2025-10-26",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-06-06-cronograma-v1.xml"
 },
 {
 "name": {
 "value": "Integración con el core cooperativo",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-12-31",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "current_date": {
 "value": "2025-12-31",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2025-06-06-cronograma-v1.xml",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2025-06-06-cronograma-v1.xml"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3 (el acta no los describe)",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "exclusions": [
 {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 }
 ]
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "approved": {
 "value": 18000000000,
 "source": "00-gobierno/2025-06-06-acta-constitucion.md",
 "source_date": "2025-06-06",
 "state": "found"
 },
 "committed": {
 "value": 8536248082,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 10213765153,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 18497117057,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": {
 "value": "Dependencia del proveedor del core cooperativo",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "owner": "no_declarada",
 "registered": true,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 },
 {
 "what": {
 "value": "Aprobación del reglamento por el Consejo de Administración",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "owner": "no_declarada",
 "registered": true,
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 },
 {
 "what": {
 "value": "El proveedor podría no llegar con el equipo completo a la siguiente fase",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "owner": "no_declarada",
 "registered": false,
 "note": "se comentó en la reunión; nadie lo anotó como riesgo",
 "source": "2026-10-23-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": {
 "value": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf",
 "source_date": "2026-10-19",
 "state": "found",
 "source_kind": "declaration"
 },
 "since": "no_declarada",
 "owner": "no_declarada",
 "source": "20-seguimiento/2026-10-19-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-14",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 },
 {
 "due_date": "2026-12-14",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-24",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-09-14",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-14",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-28",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-11",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-5.md"
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-01",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-16-acta-recibo-6.md"
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "declared_delivered": {
 "on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta, no se cierra"
 }
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-07",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-25-acta-recibo-8.md"
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-16",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-9.md"
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "declared_delivered": {
 "on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta, no se cierra"
 }
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "declared_delivered": {
 "on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta, no se cierra"
 }
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "declared_delivered": {
 "on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta, no se cierra"
 }
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-13",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-29",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-15.md"
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "declared_delivered": {
 "on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta, no se cierra"
 }
 },
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-10-29",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-16-acta-recibo-18.md"
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-11-04",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "se prometió «por definir» el 2026-10-09; la primera fecha puesta es la del 2026-10-16 (no cuenta como reprogramación)"
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-12",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-11-12",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-09",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-11-09",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-16",
 "source": "30-reuniones/2026-10-16-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana»: no es una fecha; se deja no_declarada"
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "activity": {
 "last_document_date": {
 "value": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 },
 "last_meeting_date": {
 "value": "2026-10-23",
 "source": "2026-10-23-notas-reunion.txt",
 "source_date": "2026-10-23",
 "state": "found"
 }
 },
 "meta": {
 "record_updated": "2026-10-23",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "plan.milestones[*].evidence",
 "vendors"
 ],
 "open_conflicts": [],
 "lectura": "minutas 2026-09-11 a 2026-10-16, notas 2026-10-23, 6 actas de recibo, informe 2026-10-19, acta de constitución y cronograma v1; no sellada"
 }
}
