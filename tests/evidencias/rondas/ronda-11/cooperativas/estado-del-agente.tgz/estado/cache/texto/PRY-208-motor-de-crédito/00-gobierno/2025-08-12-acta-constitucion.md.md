<!-- origen: PRY-208-motor-de-crédito/00-gobierno/2025-08-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Servicio al asociado
**Patrocinador:** Camilo Beltrán
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Educación
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-12

## Objetivo del negocio

Entregar motor de crédito para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Educación el 2025-08-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-22 |
| Cierre | 2026-03-17 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
