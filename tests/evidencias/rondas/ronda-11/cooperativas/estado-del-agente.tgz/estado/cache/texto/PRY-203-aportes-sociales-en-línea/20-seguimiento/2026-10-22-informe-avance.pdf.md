<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Aportes sociales en línea
Código: PRY-203
Fecha de corte: 2026-10-22
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 65%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.771.948.711
Ejecutado 608.518.136
Proyección al cierre 3.263.594.053

Riesgos abiertos
- Concentración del conocimiento en una sola persona
