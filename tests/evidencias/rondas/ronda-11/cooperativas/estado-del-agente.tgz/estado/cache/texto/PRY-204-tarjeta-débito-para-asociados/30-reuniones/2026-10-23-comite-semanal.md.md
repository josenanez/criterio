<!-- origen: PRY-204-tarjeta-débito-para-asociados/30-reuniones/2026-10-23-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Tarjeta débito para asociados

**Fecha:** 2026-10-23
**Asistentes:** Sandra Gil, Diana Molina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 20 | 2026-10-14 |
| Elena Duarte | Entregar el punto 11 | 2026-10-18 |
