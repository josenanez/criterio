<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-06-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Cartera y cobranza

Patrocinador: Camilo Beltrán

Gerente de proyecto: Mauricio Pérez

Comité: Consejo de Administración

Producto asociado: recaudos

Fecha de aprobación: 2025-06-24

Objetivo del negocio

Entregar cobranza digital para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Consejo de Administración el 2025-06-24.

Fechas comprometidas

Fecha

Inicio

2025-07-04

Cierre

2026-03-07

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
