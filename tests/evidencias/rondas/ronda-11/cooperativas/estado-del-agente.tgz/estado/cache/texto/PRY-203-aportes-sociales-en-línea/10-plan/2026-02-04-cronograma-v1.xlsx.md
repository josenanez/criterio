<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2026-02-04-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | cerrado
Ambiente de pruebas certificado | 2026-07-10 | 2026-07-10 | cerrado
Integración con el core cooperativo | 2026-09-22 | 2026-09-22 | cerrado
Piloto con asociados | 2026-12-04 | 2026-12-04 | en curso
Salida a producción | 2027-02-16 | 2027-02-16 | en curso
