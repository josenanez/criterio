<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-20
Gerente: Camilo Beltrán

Estado declarado
Verde
Avance reportado: 33%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 6.143.519.688
Ejecutado 5.700.631.678
Proyección al cierre 18.824.193.276

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
