<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-06-20-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-09 | 2025-11-09 | cerrado
Ambiente de pruebas certificado | 2026-03-22 | 2026-03-22 | cerrado
Integración con el core cooperativo | 2026-08-02 | 2026-08-02 | cerrado
