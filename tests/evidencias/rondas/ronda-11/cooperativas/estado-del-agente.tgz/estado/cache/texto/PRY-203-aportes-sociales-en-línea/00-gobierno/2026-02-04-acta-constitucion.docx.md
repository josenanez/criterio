<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2026-02-04-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Aportes sociales en línea

Código: PRY-203

Área dueña: Servicio al asociado

Patrocinador: Sandra Gil

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Tecnología

Producto asociado: aportes sociales

Fecha de aprobación: 2026-02-04

Objetivo del negocio

Entregar aportes sociales en línea para Servicio al asociado.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Tecnología el 2026-02-04.

Fechas comprometidas

Fecha

Inicio

2026-02-14

Cierre

2027-02-16

Criterio de éxito

Aportes sociales en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
