<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pagos con QR
Código: PRY-206
Fecha de corte: 2026-10-19
Gerente: Laura Vélez

Estado declarado
Amarillo
Avance reportado: 79%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 8.536.248.082
Ejecutado 10.213.765.153
Proyección al cierre 18.497.117.057

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
