<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-10-16
**Asistentes:** Diana Molina, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-30 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-24 |
| María Restrepo | Revisar el anexo 3 | 2026-11-14 |
| Laura Vélez | Validar el ambiente 4 | 2026-11-11 |
| Jorge Medina | Validar el ambiente 12 | 2026-11-06 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-13 |
| Liliana Torres | Enviar el documento 17 | 2026-10-19 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Gustavo Neira | Validar el ambiente 20 | 2026-11-04 |
| Gustavo Neira | Aprobar el diseño 21 | 2026-11-12 |
| Ricardo Salas | Actualizar la matriz 22 | 2026-11-09 |
| Diana Molina | Confirmar la fecha 23 | 2026-10-19 |
| Elena Duarte | Entregar el punto 24 | 2026-10-20 |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Elena Duarte): recibido, acta de recibo del 2026-10-16.
- Cerrar la prueba 18 (Andrés Lozano): recibido, acta de recibo del 2026-10-16.

## Lo que se dijo

- Liliana Torres dice que ya entregó «aprobar el diseño 13». No se presentó acta.
