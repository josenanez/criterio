<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-04-25-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-04,2026-09-04,cerrado
Ambiente de pruebas certificado,2027-01-05,2027-01-05,en curso
Integración con el core cooperativo,2027-05-08,2027-05-08,en curso
Piloto con asociados,2027-09-07,2027-09-07,en curso
