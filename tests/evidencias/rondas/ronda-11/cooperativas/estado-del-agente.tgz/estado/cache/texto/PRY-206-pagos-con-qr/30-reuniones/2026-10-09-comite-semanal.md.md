<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-18 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-07 |
| María Restrepo | Revisar el anexo 3 | 2026-10-26 |
| Laura Vélez | Validar el ambiente 4 | 2026-11-11 |
| Elena Duarte | Actualizar la matriz 6 | 2026-11-01 |
| Jorge Medina | Validar el ambiente 12 | 2026-11-06 |
| Liliana Torres | Aprobar el diseño 13 | por definir |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-29 |
| Liliana Torres | Enviar el documento 17 | 2026-10-19 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-29 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Gustavo Neira | Validar el ambiente 20 | por definir |

## Cerrados en esta reunión

- Aprobar el diseño 5 (María Restrepo): recibido, acta de recibo del 2026-10-09.
- Enviar el documento 9 (Sandra Gil): recibido, acta de recibo del 2026-10-09.
- Confirmar la fecha 15 (Liliana Torres): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Gustavo Neira dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Javier Hoyos dice que ya entregó «revisar el anexo 11». No se presentó acta.
- Carlos Peña dice que ya entregó «entregar el punto 16». No se presentó acta.
