<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2026-01-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Cartera y cobranza

Patrocinador: Laura Vélez

Gerente de proyecto: Sandra Gil

Comité: Comité de Tecnología

Producto asociado: microcrédito

Fecha de aprobación: 2026-01-01

Objetivo del negocio

Entregar microcrédito rural para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Tecnología el 2026-01-01.

Fechas comprometidas

Fecha

Inicio

2026-01-11

Cierre

2026-07-17

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
