<!-- origen: PRY-210-corresponsales-rurales/10-plan/2026-10-12-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2025-11-11 | 2025-11-11 | 2025-11-11 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-02-22 | 2026-02-22 | 2026-02-22 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2026-06-05 | 2026-06-05 | 2026-06-05 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con asociados | 2026-10-13 | 2026-10-13 | 2026-09-15 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2025-11-11 | 2025-11-11 | cerrado |
| Ambiente de pruebas certificado | 2026-02-22 | 2026-02-22 | cerrado |
| Integración con el core cooperativo | 2026-06-05 | 2026-06-05 | cerrado |
| Piloto con asociados | 2026-09-15 | 2026-10-13 | cerrado |
