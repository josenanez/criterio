<!-- origen: PRY-206-pagos-con-qr/2026-10-23-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión pagos con qr — 2026-10-23
estuvieron: Diana Molina, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Óscar Ramírez

- Paula Céspedes dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 14/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-02
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
