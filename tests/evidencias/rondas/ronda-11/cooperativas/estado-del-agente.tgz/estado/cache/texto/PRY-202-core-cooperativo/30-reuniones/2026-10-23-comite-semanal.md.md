<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-23-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Core cooperativo

**Fecha:** 2026-10-23
**Asistentes:** Javier Hoyos, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 26 | 2026-11-19 |
