<!-- origen: PRY-211-cobranza-digital/10-plan/2025-06-24-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2025-09-24 | 2025-09-24 | 2025-09-24 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2025-12-15 | 2025-12-15 | 2025-12-15 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2026-03-07 | 2026-03-07 | 2026-03-07 | 100% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2025-09-24 | 2025-09-24 | cerrado |
| Ambiente de pruebas certificado | 2025-12-15 | 2025-12-15 | cerrado |
| Integración con el core cooperativo | 2026-03-07 | 2026-03-07 | cerrado |
