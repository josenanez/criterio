<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-23
**Gerente:** Carlos Peña

## Estado declarado

**Rojo**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.639.904.877 |
| Ejecutado | 841.054.466 |
| Proyección al cierre | 4.193.828.636 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Concentración del conocimiento en una sola persona
