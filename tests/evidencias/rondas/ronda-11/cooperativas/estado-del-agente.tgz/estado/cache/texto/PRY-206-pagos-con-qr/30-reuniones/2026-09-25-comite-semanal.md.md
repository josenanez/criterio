<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-09-25
**Asistentes:** Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-23 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-14 |
| María Restrepo | Revisar el anexo 3 | 2026-10-19 |
| Laura Vélez | Validar el ambiente 4 | 2026-10-14 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-14 |
| Elena Duarte | Actualizar la matriz 6 | 2026-09-21 |
| Sandra Gil | Enviar el documento 9 | 2026-10-16 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-02 |
| Javier Hoyos | Revisar el anexo 11 | por definir |
| Jorge Medina | Validar el ambiente 12 | 2026-09-30 |

## Cerrados en esta reunión

- Entregar el punto 8 (Gustavo Neira): recibido, acta de recibo del 2026-09-25.

## Lo que se dijo

- Carlos Peña dice que ya entregó «confirmar la fecha 7». No se presentó acta.
