<!-- origen: PRY-201-apertura-de-ahorro-en-línea/30-reuniones/2026-10-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Apertura de ahorro en línea

**Fecha:** 2026-10-18
**Asistentes:** Camilo Beltrán, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 29 | 2026-10-08 |
