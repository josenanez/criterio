<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-10-02
**Asistentes:** Carlos Peña, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-06 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-31 |
| María Restrepo | Revisar el anexo 3 | 2026-10-19 |
| Laura Vélez | Validar el ambiente 4 | 2026-10-29 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-14 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-17 |
| Sandra Gil | Enviar el documento 9 | 2026-10-16 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-21 |
| Javier Hoyos | Revisar el anexo 11 | por definir |
| Jorge Medina | Validar el ambiente 12 | 2026-10-23 |
| Liliana Torres | Aprobar el diseño 13 | por definir |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-29 |
| Liliana Torres | Confirmar la fecha 15 | 2026-10-23 |
| Carlos Peña | Entregar el punto 16 | por definir |
