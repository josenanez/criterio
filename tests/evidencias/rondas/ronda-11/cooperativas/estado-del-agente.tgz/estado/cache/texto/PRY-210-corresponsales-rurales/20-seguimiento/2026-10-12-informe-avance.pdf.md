<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Corresponsales rurales
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 63%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.133.549.892
Ejecutado 1.108.890.133
Proyección al cierre 7.125.458.903

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio normativo del supervisor que puede mover el alcance
