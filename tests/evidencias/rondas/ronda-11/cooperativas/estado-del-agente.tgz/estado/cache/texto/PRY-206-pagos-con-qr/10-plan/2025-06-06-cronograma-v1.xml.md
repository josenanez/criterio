<!-- origen: PRY-206-pagos-con-qr/10-plan/2025-06-06-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2025-08-21 | 2025-08-21 | 2025-08-21 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2025-10-26 | 2025-10-26 | 2025-10-26 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2025-12-31 | 2025-12-31 | 2025-12-31 | 100% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2025-08-21 | 2025-08-21 | cerrado |
| Ambiente de pruebas certificado | 2025-10-26 | 2025-10-26 | cerrado |
| Integración con el core cooperativo | 2025-12-31 | 2025-12-31 | cerrado |
