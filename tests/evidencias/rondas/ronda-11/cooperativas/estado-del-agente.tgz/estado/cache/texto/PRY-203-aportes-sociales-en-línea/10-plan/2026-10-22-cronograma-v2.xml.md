<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2026-10-22-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | 2026-04-28 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-07-10 | 2026-07-10 | 2026-07-10 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2026-09-22 | 2026-09-22 | 2026-09-22 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con asociados | 2026-12-04 | 2026-12-04 | 2026-12-04 | 50% | hito | 3FS | — |
| 5 | 5 | Salida a producción | 2027-05-12 | 2027-05-12 | 2027-02-16 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | cerrado |
| Ambiente de pruebas certificado | 2026-07-10 | 2026-07-10 | cerrado |
| Integración con el core cooperativo | 2026-09-22 | 2026-09-22 | cerrado |
| Piloto con asociados | 2026-12-04 | 2026-12-04 | en curso |
| Salida a producción | 2027-02-16 | 2027-05-12 | en curso |
