<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core cooperativo
Código: PRY-202
Fecha de corte: 2026-10-19
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 80%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 635.785.527
Ejecutado 346.169.562
Proyección al cierre 1.173.863.262

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Dependencia del proveedor del core cooperativo
