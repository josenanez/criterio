<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2026-06-06-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2026-07-23 | 2026-07-23 | 2026-07-23 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-08-30 | 2026-08-30 | 2026-08-30 | 100% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2026-10-06 | 2026-10-06 | 2026-10-06 | 100% | hito | 2FS | — |
| 4 | 4 | Piloto con asociados | 2026-11-13 | 2026-11-13 | 2026-11-13 | 50% | hito | 3FS | — |
| 5 | 5 | Salida a producción | 2026-12-21 | 2026-12-21 | 2026-12-21 | 50% | hito | 4FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2026-07-23 | 2026-07-23 | cerrado |
| Ambiente de pruebas certificado | 2026-08-30 | 2026-08-30 | cerrado |
| Integración con el core cooperativo | 2026-10-06 | 2026-10-06 | cerrado |
| Piloto con asociados | 2026-11-13 | 2026-11-13 | en curso |
| Salida a producción | 2026-12-21 | 2026-12-21 | en curso |
