<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2025-06-19-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Convenios de libranza con empresas

Código: PRY-209

Área dueña: Riesgo y Cumplimiento

Patrocinador: Carlos Peña

Gerente de proyecto: Liliana Torres

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2025-06-19

Objetivo del negocio

Entregar convenios de libranza con empresas para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Tecnología el 2025-06-19.

Fechas comprometidas

Fecha

Inicio

2025-06-29

Cierre

2026-11-07

Criterio de éxito

Convenios de libranza con empresas en producción y medido.

Dependencias declaradas

• Ninguna declarada
