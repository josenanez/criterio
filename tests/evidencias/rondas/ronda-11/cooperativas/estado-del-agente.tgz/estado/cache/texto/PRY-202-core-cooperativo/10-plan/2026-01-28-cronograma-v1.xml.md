<!-- origen: PRY-202-core-cooperativo/10-plan/2026-01-28-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseño funcional aprobado | 2026-06-29 | 2026-06-29 | 2026-06-29 | 100% | hito | — | — |
| 2 | 2 | Ambiente de pruebas certificado | 2026-11-18 | 2026-11-18 | 2026-11-18 | 50% | hito | 1FS | — |
| 3 | 3 | Integración con el core cooperativo | 2027-04-09 | 2027-04-09 | 2027-04-09 | 50% | hito | 2FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseño funcional aprobado | 2026-06-29 | 2026-06-29 | cerrado |
| Ambiente de pruebas certificado | 2026-11-18 | 2026-11-18 | en curso |
| Integración con el core cooperativo | 2027-04-09 | 2027-04-09 | en curso |
