<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Corresponsales rurales

Fecha: 2026-10-14

Asistentes: Camilo Beltrán, Andrés Lozano

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Beatriz Cuéllar

Entregar el punto 15

2026-11-06
