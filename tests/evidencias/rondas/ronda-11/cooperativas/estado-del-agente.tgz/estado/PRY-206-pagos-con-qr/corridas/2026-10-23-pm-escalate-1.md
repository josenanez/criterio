# Corrida del 2026-10-23 · pm-escalate

1 proyectos · 53 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 5 |
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 4 |
| `milestone_met_without_evidence` | 3 |
| `progress_vs_plan` | 1 |

Tres puntos: autoridad no declarada en el acta, nueva línea base (cierre 2025-12-31 vencido, proyección +497M COP), compromiso de Paula Céspedes reprogramado 6 veces. No se calculó impact: ninguna fecha propuesta y dependencias no declaradas. No sé la autoridad real, la nueva fecha ni el efecto en otros proyectos.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-206 · Pagos con QR · 2026-10-23

Sin argumento, tomé lo marcado como escalable. Salen tres puntos, en este orden. El primero es el que destraba a los otros dos.

### 1. ¿Confirma el Comité de Riesgos, por escrito y antes de su próxima sesión, qué puede decidir la gerente (Laura Vélez) en alcance, tiempo y costo, sí o no?

**Quién decide:** Comité de Riesgos, que aprobó el acta (2025-06-06), con el patrocinio de Liliana Torres · **Si no se decide hoy:** el comité siguiente es el 2026-10-30. Hasta entonces no hay vara contra la que decir si los puntos 2 y 3 son de la gerente o del comité. El 2026-11-02 está la revisión con el proveedor (Óscar Ramírez), y se haría sin saber quién puede aceptar lo que salga de ahí.

El acta de constitución no declara la autoridad del gerente (`identity.authority`: no encontrada). Por eso este punto va primero. Sin esa autoridad, los otros dos no se pueden dirigir a quien los pueda decidir.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se emite una adenda al acta con los límites de autoridad (umbral de costo, de fecha y de alcance) | Sin cambio | Queda para el comité del 2026-10-30 | Sin costo presupuestal |
| B. Se declara que todo cambio de línea base pasa por el comité | Sin cambio | Cada cambio espera la sesión semanal | Sin costo presupuestal; más carga al comité |

**Recomiendo:** A. Es una sola decisión y sirve para el resto de la vida del proyecto. Con B el comité sigue resolviendo por cada caso lo que una regla ya resolvería.

### 2. ¿Se aprueba una nueva línea base para el proyecto (cierre y presupuesto), sí o no?

**Quién decide:** no se puede decir según el acta (ver punto 1). El presupuesto y las fechas los aprobó el Comité de Riesgos, así que ahí se lleva mientras no haya otra cosa · **Si no se decide hoy:** la fecha ya se pasó, así que no hay plazo que se pierda. El costo es de seguir sin línea base vigente: el reporte compara contra una fecha de hace diez meses.

Lo que muestran los documentos:
- Cierre comprometido: **2025-12-31**. Hoy es 2026-10-23 y la ficha no registra ningún cambio aprobado (`changes`: vacío). La línea base sigue siendo la versión 1.
- Presupuesto aprobado: 18.000.000.000 COP. Proyección declarada en el informe del 2026-10-19: **18.497.117.057 COP**, es decir 497.117.057 COP por encima (2,76 %). Es una cifra que declara el gerente, no una que sustente un documento contable.
- Laura Vélez quedó de mandar «el ajuste del presupuesto la otra semana» (notas del 2026-10-23), sin fecha.
- El informe del 2026-10-19 declara estado amarillo y 79 % de avance.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar nueva línea base cuando llegue el ajuste de Laura Vélez, conservando la v1 | Sin cambio declarado | Nueva fecha de cierre: **no la sé**, ningún documento la propone | La que traiga el ajuste. Hoy solo está la proyección de 18.497.117.057 COP |
| B. Pedir primero un replan sustentado y decidir con él | Sin cambio declarado | Sin fecha todavía | Sin costo propio; el proyecto sigue sin línea base vigente hasta entonces |

**Recomiendo:** B, y A cuando llegue el replan. Hoy no hay ni fecha ni cifra sustentadas que aprobar, y aprobar sin ellas fija una línea base que habría que volver a cambiar.

### 3. ¿Se mantiene a Paula Céspedes como responsable de «Enviar el documento 1», o se reasigna, sí o no?

**Quién decide:** no se puede decir (ver punto 1) · **Si no se decide hoy:** la fecha vigente pasa a 2026-12-14. Con el patrón actual, el comité del 2026-10-30 vuelve a reprogramar o a dejarlo pasar.

El compromiso se dijo el 2026-09-11 para el 2026-09-21 y se ha reprogramado **seis veces**: 10-06, 10-23, 11-06, 11-18, 11-30 y 12-14. Va 84 días corridos más tarde que la fecha original. Las notas del 2026-10-23 dicen que «no alcanzó». No hay acta de recibo.

No sé si el documento 1 bloquea algo ni si Paula es de dentro o de fuera del proyecto. Las minutas no lo dicen.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se mantiene con 2026-12-14 | Sin cambio | 84 días más tarde que la fecha original | No lo sé |
| B. Se reasigna a quien el comité nombre | Sin cambio | No lo sé | No lo sé |

**Recomiendo:** B, pero con una condición. Antes de sentarse, la gerente llama a Paula y pregunta qué lo traba. Si es algo que se destraba con una llamada, no es un escalamiento. Eso no lo sé yo.

### Lo que no escala
- «El proveedor podría no llegar con el equipo completo» (notas del 2026-10-23): hoy es un riesgo sin registrar y sin doliente. Se registra; no se escala todavía. Tiene plan vigente: la revisión con el proveedor del 2026-11-02.
- Los compromisos de Gustavo Neira, Jorge Medina, María Restrepo y los demás: tienen una o dos reprogramaciones o ninguna. Quedan dentro de la gestión normal.

### A quién alcanza
No lo calculé. El comando `impact` necesita un número de días y esta corrida no tiene ninguna fecha nueva propuesta (las opciones del punto 2 no traen fecha). El acta declara **«Ninguna declarada»** como dependencias, y la ficha tiene `dependencies` vacío. Con lo que hay, no puedo decir qué otros proyectos se ven alcanzados, ni su gerente, ni si la dependencia está confirmada. Cuando el comité elija una fecha, corre `/pm-escalate cambio <fecha>`.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Integración con el core cooperativo | 2025-12-31 | Sin calcular (ver arriba) |

Los tres hitos de la ficha figuran como cumplidos en el cronograma v1 y ninguno trae evidencia (`evidence`: no encontrada).

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2025-06-06-acta-constitucion.md` (no la contiene) y `identity.authority` de la ficha.
- Fechas y presupuesto aprobados: `00-gobierno/2025-06-06-acta-constitucion.md`.
- Proyección, avance y estado: `20-seguimiento/2026-10-19-informe-avance.pdf` (declaración).
- Compromiso de Paula Céspedes y sus seis reprogramaciones: `30-reuniones/2026-09-11-comite-semanal.md` a `30-reuniones/2026-10-16-comite-semanal.md` y `2026-10-23-notas-reunion.txt`.
- Ajuste del presupuesto, revisión con el proveedor y riesgo del equipo: `2026-10-23-notas-reunion.txt`.
- Comité siguiente: `.criterio/proyecto/PRY-206/config.json`.

**Qué no sé:** la autoridad real de Laura Vélez, la nueva fecha de cierre, el efecto en otros proyectos, y si el documento 1 bloquea algo.
