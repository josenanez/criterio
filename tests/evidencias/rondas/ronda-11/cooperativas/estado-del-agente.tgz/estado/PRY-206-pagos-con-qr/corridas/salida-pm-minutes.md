# Acta — PRY-206 · Pagos con QR · 2026-10-23

**Asistieron:** Diana Molina, Elena Duarte, Gustavo Neira, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Óscar Ramírez · **Fuente:** `2026-10-23-notas-reunion.txt` (notas de la reunión, 8 líneas) · **Ausentes con compromisos abiertos:** Carlos Peña (2 sin fecha), Javier Hoyos (1 sin fecha). Las notas no traen agenda, así que no puedo decir quién estaba citado a un tema.

*Términos: vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hizo falta registrarlos otra vez.*

## Compromisos

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-12-14 | **Reprogramado por 6.ª vez.** Original 2026-09-21; luego 10-06, 10-23, 11-06, 11-18, 11-30 y ahora 12-14. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 14/12/2026» (línea 4). |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-11-02» (línea 6). Ver la duda abajo. |

### Sin fecha

| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — «la otra semana» (línea 5). Es una referencia relativa, no una fecha; queda `no_declarada` y no la convierto en el 30 de octubre. |

Con este van **5 compromisos sin fecha** en el proyecto; los otros cuatro son de Carlos Peña (2), Javier Hoyos y Liliana Torres, y ninguno aparece hoy.

## Decisiones

Ninguna. Las notas no registran que alguien haya decidido algo ni qué se descartó.

## Quedó sin decidir

Las notas no dicen que algo haya quedado pendiente de decisión. No lo invento.

## Intenciones sin doliente

Ninguna. Todas las líneas con una acción traen una persona nombrada.

## Dicho al pasar y no registrado

| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No atribuido: las notas dicen «se comentó» | Riesgo (es una posibilidad futura, no algo que ya ocurrió) | **No.** El RAID tiene «Dependencia del proveedor del core cooperativo», que es parecido pero no es lo mismo: aquel habla de depender del proveedor y este habla de que no llegue con el equipo completo. Sin dueño ni «siguiente fase» identificada en ningún documento. |

Va al RAID como riesgo **no registrado antes**, sin dueño. Nadie se comprometió a gestionarlo. La revisión con el proveedor del 2026-11-02 (Óscar Ramírez) sería el sitio natural para tratarlo, pero eso es una sugerencia mía: las notas no lo vinculan.

## Cerrado en esta reunión

Nada. Las notas no citan ningún documento de recibo. (Se omite el detalle.)

## Lo que esta reunión contradice

| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité / próxima reunión | «Próxima reunión en dos semanas» (≈ 2026-11-06) | Configuración: comité semanal, próximo 2026-10-30 | Notas 2026-10-23 vs. `config.json` |

No es un campo de la ficha del proyecto, sino de la configuración de Samuel. Si el comité pasó a ser quincenal, la configuración está desactualizada; si no, el 30 de octubre sigue en pie. Lo decide quien convoca el comité. **Patrocinador, comité, fechas de cierre y presupuesto aprobado: la reunión no los cambia.**

## Sin resolver de la transcripción

- «Revisión con el proveedor, queda para el 2026-11-02»: no queda claro si Óscar Ramírez se comprometió a hacer la revisión o solo se fijó la fecha de una reunión con el proveedor. Lo registro como compromiso suyo, porque su nombre encabeza la línea.
- «Se comentó que el proveedor podría no llegar…»: no dice quién lo comentó, ni de qué proveedor ni de qué fase se habla.
- «Ajuste del presupuesto»: no dice de cuánto ni por qué. La proyección declarada el 2026-10-19 (18.497.117.057 COP) supera el aprobado (18.000.000.000 COP) en 2,8 %, pero las notas no relacionan las dos cosas.
- «14/12/2026» se lee como 14 de diciembre de 2026 (el 14 no puede ser mes).

## Lo que el recálculo muestra tras esta acta

`compute` corrió sin `record_issues`. Estado de los compromisos del proyecto: 4 vencidos sin evidencia (Gustavo Neira «Cerrar la prueba 10», Liliana Torres «Enviar el documento 17», Diana Molina «Confirmar la fecha 23», Elena Duarte «Entregar el punto 24»; **ninguno se mencionó en esta reunión**), 5 sin fecha y 4 reprogramados 3 veces o más (Paula Céspedes 6, María Restrepo 5 y 4, Laura Vélez 3). Estos cálculos son del script; las cifras de arriba no son mías.

## Después

`/pm-commitments` para ver el seguimiento completo con lo que entró hoy. `/pm-publish` solo si quieres que la ficha llegue a la PMO; esta acta no cambió ningún campo de la ficha de gobierno.

*El acta sale en la conversación y la guardas tú: Samuel no la escribe en tu carpeta de reuniones.*
