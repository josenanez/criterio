## Listo — PRY-206 · Pagos con QR

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Respuestas tomadas por defecto (sesión sin interfaz, nadie contestó):**
- Quién y qué proyecto: Laura Vélez, gerente de PRY-206 · Pagos con QR (acta de constitución del 2025-06-06).
- Reunión de seguimiento: viernes, semanal (las seis minutas caen en viernes). Próxima: 2026-10-30 por la cadencia; las notas del 2026-10-23 dicen «en dos semanas», es decir 2026-11-06 — confírmalo.
- Estado guardado en `estado/PRY-206-pagos-con-qr`, fuera de la documentación y de `.criterio/`.
- Carpeta marcada con `_CRITERIO_PROYECTO.txt` (autoriza José Francisco Ñáñez).

**Lo que miré:** 16 documentos · 7 de reunión (6 minutas del comité, del 2026-09-11 al 2026-10-16, más las notas del 2026-10-23) · la última del 2026-10-23. Leí las 7 y las 6 actas de recibo. El cronograma `.xml` lo leí como texto; el informe PDF también.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2), 2026-10-23 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 c83631fe2c4cd4b0…
Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0

**En total:** 26 compromisos seguidos · 6 cumplidos con acta · 20 abiertos.

### Lo que está abierto, y cuántas veces se ha movido
| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-12-14 (original 2026-09-21) | **6** — 10-06, 10-23, 11-06, 11-18, 11-30, 12-14 · notas 2026-10-23 |
| María Restrepo | Cerrar la prueba 2 | 2026-11-24 (original 2026-09-14) | **5** · minuta 2026-10-16 |
| María Restrepo | Revisar el anexo 3 | 2026-11-14 (original 2026-09-16) | **4** · minuta 2026-10-16 |
| Laura Vélez | Validar el ambiente 4 | 2026-11-11 (original 2026-10-05) | **3** · minuta 2026-10-16 |
| Jorge Medina | Validar el ambiente 12 | 2026-11-06 (original 2026-09-30) | 2 · minuta 2026-10-16 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-13 (original 2026-10-29) | 1 · minuta 2026-10-16 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-21 (original 2026-10-02) | 1 · **vencido hace 2 días, sin acta**; el 10-09 se dijo que ya estaba entregado |
| Liliana Torres | Enviar el documento 17 | 2026-10-19 | 0 · **vencido hace 4 días, sin acta** · minuta 2026-10-16 |
| Diana Molina | Confirmar la fecha 23 | 2026-10-19 | 0 · **vencido hace 4 días, sin acta** · minuta 2026-10-16 |
| Elena Duarte | Entregar el punto 24 | 2026-10-20 | 0 · **vencido hace 3 días, sin acta** · minuta 2026-10-16 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 | 0 · minuta 2026-10-16 |
| Gustavo Neira | Validar el ambiente 20 | 2026-11-04 | 0 · primera fecha puesta el 10-16 (antes «por definir») |
| Gustavo Neira | Aprobar el diseño 21 | 2026-11-12 | 0 · minuta 2026-10-16 |
| Ricardo Salas | Actualizar la matriz 22 | 2026-11-09 | 0 · minuta 2026-10-16 |
| Óscar Ramírez | Revisión con el proveedor | 2026-11-02 | 0 · notas 2026-10-23 |

Hallazgo de fondo: cuatro compromisos acumulan 3 a 6 movimientos (documento 1, prueba 2, anexo 3, ambiente 4). Más que cuatro atrasos, apuntan a un bloqueo que nadie ha nombrado. El de Laura Vélez, el ambiente 4, está entre ellos. Ninguno ha tenido nunca acta.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y por eso desaparecen de los informes:
- Carlos Peña — Confirmar la fecha 7 (desde 2026-09-18). El 09-25 dijo que ya lo entregó; no se presentó acta.
- Javier Hoyos — Revisar el anexo 11 (desde 2026-09-25). El 10-09 dijo que ya lo entregó; no se presentó acta.
- Liliana Torres — Aprobar el diseño 13 (desde 2026-10-02). El 10-16 dijo que ya lo entregó; no se presentó acta.
- Carlos Peña — Entregar el punto 16 (desde 2026-10-02). El 10-09 dijo que ya lo entregó; no se presentó acta.
- Laura Vélez — Mandar el ajuste del presupuesto: «la otra semana» (notas 2026-10-23). Eso no es una fecha, y no la calculé.

Los cuatro «ya lo entregué» siguen abiertos: sin acta de recibo no se cierran.

### Cumplidos con acta (6)
Entregar el punto 8 (G. Neira, acta 2026-09-25) · Aprobar el diseño 5 (M. Restrepo), Enviar el documento 9 (S. Gil) y Confirmar la fecha 15 (L. Torres) (actas 2026-10-09) · Actualizar la matriz 6 (E. Duarte) y Cerrar la prueba 18 (A. Lozano) (actas 2026-10-16).

### Otras señales que levantó el cálculo
- **Avance declarado 79% contra un cronograma que da los 3 hitos por cumplidos (100%).** Brecha de 21,0 puntos. El informe del 2026-10-19 dice 79% y estado amarillo.
- **Los 3 hitos del cronograma figuran cumplidos y ninguno tiene acta de recibo:** Diseño funcional aprobado (2025-08-21), Ambiente de pruebas certificado (2025-10-26), Integración con el core cooperativo (2025-12-31). Hace falta el acta de cada uno.
- Presupuesto, tomado del informe del 2026-10-19: aprobado 18.000.000.000 COP; comprometido 8.536.248.082 (47,4%); ejecutado 10.213.765.153 (56,7%); proyección al cierre 18.497.117.057 → 2,8% sobre lo aprobado. Es declaración del gerente, sin otra fuente. El ejecutado supera al comprometido, y ese dato conviene aclararlo.
- Riesgo mencionado el 2026-10-23 y no registrado: el proveedor podría no llegar con el equipo completo a la siguiente fase. Nadie lo anotó como riesgo.
- El acta de constitución no declara dependencias ni la autoridad del gerente; no hay fase declarada.

### Qué le falta a tu carpeta
- Un cronograma vigente: el único (v1, 2025-06-06) tiene como último hito el 2025-12-31, hace casi 10 meses, y el proyecto sigue en marcha. Toma esa fecha como cierre vigente solo por falta de otra.
- Actas de recibo de los 3 hitos del cronograma y de los cuatro compromisos que se dicen entregados.
- Minutas anteriores al 2026-09-11, si existen: los movimientos de las fechas se cuentan desde esa fecha.
- El acta de constitución lista «Componente 1/2/3» sin describirlos.
- El cronograma `.xml` no es un formato que Samuel lea sin instalar algo; lo leí como texto.

La ficha quedó en `estado/PRY-206-pagos-con-qr/records/PRY-206.json` sin sellar: leí las reuniones, no el proyecto entero.

**Cuándo vuelvo:** el viernes 2026-10-30, día de tu reunión semanal. Las notas del 10-23 mencionan la próxima «en dos semanas» (2026-11-06); si es así, dímelo y lo cambio.
