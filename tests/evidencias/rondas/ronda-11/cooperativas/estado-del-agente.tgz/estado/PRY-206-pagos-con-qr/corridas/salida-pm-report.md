# Pagos con QR (PRY-206) — semana del 2026-10-17 al 2026-10-23

*Sesión sin interfaz: nadie respondió la pregunta de la declaración. Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).*

**Declara el gerente (Laura Vélez) esta semana:** *sin declarar* · — % · —
**Última declaración en archivo (informe de avance del 2026-10-19, 4 días):** amarillo · 79 %. Se cita como antecedente, no como declaración de esta semana.
**Sustento documental:** sin sustento. De las fuentes de la ficha, 0 son evidencia, 8 son declaración y 106 no están marcadas.
**Lo que el semáforo no explica** (contra la declaración en archivo): compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, y avance declarado frente al plan.

## Qué cambió esta semana
Es la primera corrida con instantánea: `diff` no tiene con qué comparar y devuelve 0 cambios. No puedo decir qué estaba y qué está. Desde la próxima semana esta tabla se llena.

Lo que sí entró desde el comité anterior (2026-10-16) son las notas del 2026-10-23:
| Qué | Estaba | Está |
|---|---|---|
| Paula Céspedes, «Enviar el documento 1» | 6.º intento: 2026-11-30 | 2026-12-14 (7.ª fecha, contando la original del 2026-09-21) |
| Óscar Ramírez, revisión con el proveedor | sin registro | 2026-11-02 |
| Laura Vélez, «Mandar el ajuste del presupuesto» | sin registro | «la otra semana», sin fecha exacta |
| Riesgo: el proveedor podría no llegar con el equipo completo a la siguiente fase | sin registro | dicho en la reunión, **nadie lo anotó como riesgo** |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Los 3 hitos figuran «cumplidos» y ninguno tiene evidencia | cronograma v1, 2025-06-06 | 428 / 362 / 296 desde su fecha |
| Fin del proyecto 2025-12-31, ya pasado, sin replanificación | 2025-12-31 | 296 |
| «Enviar el documento 1» (Paula Céspedes) | 2026-09-21 | 32, 6 reprogramaciones |
| «Cerrar la prueba 2» (María Restrepo) | 2026-09-14 | 39, 5 reprogramaciones |
| Silencio: sin dato de autoridad ni de fase | acta 2025-06-06 | — |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2025-12-31 | 2025-12-31 | 0 días contra ambas |
| Presupuesto | COP 18.000 M | COP 18.000 M | proyección COP 18.497 M, +2,8 % |

Replanificaciones: **0**. Hay una sola línea base (v1, 2025-06-06).

**Lectura que no hay que dejar pasar:** la desviación sale en 0 porque la línea base nunca se movió, no porque se cumpla. La fecha de cierre pasó hace 296 días y el proyecto sigue en ejecución con 79 % declarado. El plan sostiene 100 % (3 de 3 hitos «cumplidos»), así que el avance declarado queda **21 puntos por debajo del plan**, contra un umbral de 10. O el plan está desactualizado o los hitos no se cumplieron; los documentos no permiten decidir cuál.

### Hitos de las próximas cuatro semanas
Ninguno. Los tres hitos del cronograma están vencidos.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 8.536.248.082 (47,4 %) | 10.213.765.153 (56,7 %) | 18.497.117.057 | **9.463.751.918** |

Disponible real = aprobado − comprometido. Ojo: **lo ejecutado es mayor que lo comprometido** (por 1.677 M), y eso no debería pasar. Las dos cifras salen del informe del 2026-10-19, que es una declaración. Hay que revisar de dónde sale cada una antes de confiar en el disponible. La proyección supera lo aprobado en COP 497 M.

## Abierto
**Reprogramados (primero):**
- Paula Céspedes, «Enviar el documento 1»: 6 veces, de 2026-09-21 a 2026-12-14.
- María Restrepo, «Cerrar la prueba 2»: 5 veces, de 2026-09-14 a 2026-11-24.
- María Restrepo, «Revisar el anexo 3»: 4 veces, de 2026-09-16 a 2026-11-14.
- Laura Vélez, «Validar el ambiente 4»: 3 veces, de 2026-10-05 a 2026-11-11. Llega al umbral de 3.

**Vencidos sin evidencia:**
- Gustavo Neira, «Cerrar la prueba 10»: vencía el 2026-10-21 (2 días).
- Liliana Torres, «Enviar el documento 17»: vencía el 2026-10-19 (4 días).
- Diana Molina, «Confirmar la fecha 23»: vencía el 2026-10-19 (4 días).
- Elena Duarte, «Entregar el punto 24»: vencía el 2026-10-20 (3 días).

**Sin fecha (5):** Carlos Peña («Confirmar la fecha 7», «Entregar el punto 16»), Javier Hoyos («Revisar el anexo 11»), Liliana Torres («Aprobar el diseño 13»), Laura Vélez («Mandar el ajuste del presupuesto»).

**RAID sin movimiento:** no hay registro RAID en la carpeta. El riesgo del proveedor, dicho el 2026-10-23, no está anotado.
**Proveedor:** la ficha no tiene proveedores registrados. Hay actas de recibo en `20-seguimiento` (5, 6, 8, 9, 15 y 18) que no se cruzaron con ningún contrato.

## Lo que necesito de alguien
- **Laura Vélez:** declarar el estado y el avance de esta semana. La línea está en blanco.
- **Laura Vélez:** fecha exacta para el ajuste del presupuesto, y aclarar cómo lo ejecutado supera lo comprometido.
- **Laura Vélez / Liliana Torres (sponsor):** decidir si se replantea la línea base. El cierre de 2025-12-31 ya pasó. *Excede la autoridad del gerente: material de comité (próximo 2026-10-30).*
- **Laura Vélez:** registrar el riesgo del proveedor en el RAID.
- **Paula Céspedes y María Restrepo:** fecha firme o decir que no se puede.
- **Gustavo Neira, Liliana Torres, Diana Molina, Elena Duarte:** cumplir lo vencido o reprogramarlo.
- **Carlos Peña, Javier Hoyos, Liliana Torres:** poner fecha a sus compromisos.

## Lo que no se sabe
**Sin dato:** autoridad de aprobación, fase del proyecto, y evidencia de los 3 hitos «cumplidos». Además, 24 campos de la ficha tienen 16 meses (acta y cronograma del 2025-06-06).
**Silencio:** último documento hace 0 días (notas del 2026-10-23) · última reunión hace 0 días (2026-10-23); último comité formal hace 7 días (2026-10-16).

---
*Ficha: `estado/PRY-206-pagos-con-qr/records/PRY-206.json`, corte 2026-10-23. 5 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal*
