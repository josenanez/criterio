# Plan — Pagos con QR (PRY-206) · borrador del 2026-10-23
**Desde:** acta de constitución del 2025-06-06 (`00-gobierno/2025-06-06-acta-constitucion.md`) · **Criterio de éxito:** «Pagos con QR en producción y medido.»

> Los términos vigentes (v1.2) ya estaban registrados a nombre de José Francisco Ñáñez, 2026-10-23; no hubo que volver a pedirlos.

**Una advertencia antes de empezar.** Esto se pide como «primer borrador del plan», pero el acta es de hace 16 meses y el cierre comprometido en ella (2025-12-31) quedó 10 meses atrás. Existe un cronograma v1 (`10-plan/2025-06-06-cronograma-v1.xml`) con tres hitos. Este borrador parte del acta y no reconstruye lo que ya pasó; si lo que se quiere es un replan, eso es control de cambios y una línea base nueva, no este comando.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** Dice «Componente 1, 2 y 3» y nada más. | No hay de dónde sacar entregables. Los nodos de la WBS que siguen son o supuestos o «sin definir»; no se pueden citar al acta. |
| **Fuera de alcance vacío en la práctica.** Dice «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué. | No se sabe dónde termina este proyecto; el riesgo es construir (o dejar sin construir) algo que otro proyecto tiene. |
| **Criterio de éxito sin medida.** «En producción y medido»: no dice qué se mide, cuánto, ni quién lo acepta. | Es el vacío más caro: no se puede decidir qué entra al alcance ni cuándo el proyecto terminó. |
| **Autoridad del gerente no declarada** (`identity.authority`: no encontrada). | No se sabe qué puede decidir quien planifica y qué debe subir al patrocinador o al Comité de Riesgos. |
| **Dependencias: «Ninguna declarada».** Aun así el cronograma tiene un hito de «Integración con el core cooperativo» y el informe 2026-10-19 registra como riesgo la dependencia del proveedor del core. | El acta y el resto de los documentos se contradicen. Para el plan, el core cooperativo es una dependencia que el acta no reconoce. |
| **Sin proveedor ni contrato citable** (`vendors` vacío), pero las notas del 2026-10-23 hablan de un proveedor y de su equipo. | No hay de dónde sacar duraciones contractuales ni quién entrega qué. |

Patrocinador (Liliana Torres), gerente (Laura Vélez), comité (Comité de Riesgos), presupuesto (18.000.000.000 COP) y fechas de inicio y cierre sí están en el acta.

## WBS
Los componentes del acta no tienen descripción, así que no hay entregables «del acta» más allá de los dos extremos. Lo demás es supuesto o sin definir y está marcado como tal.

| # | Entregable (algo que alguien recibe y acepta) | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 (el acta no lo describe) | Sin definir | **Sin definir** · acta, «Alcance» | — |
| 2 | Componente 2 (el acta no lo describe) | Sin definir | **Sin definir** · acta, «Alcance» | — |
| 3 | Componente 3 (el acta no lo describe) | Sin definir | **Sin definir** · acta, «Alcance» | — |
| 4 | Diseño funcional aprobado | Sin definir | **Del cronograma v1**, hito 1 (no es del acta). El acta no dice si es parte de algún componente | — |
| 5 | Ambiente de pruebas certificado | Sin definir (certifica quién) | **Del cronograma v1**, hito 2 | — |
| 6 | Integración con el core cooperativo | Sin definir | **Del cronograma v1**, hito 3 | — |
| 7 | Pagos con QR en producción | Sin definir | **Del acta**, criterio de éxito (mitad «en producción») | — |
| 8 | Medición de los pagos con QR (qué, cuánto, desde cuándo) | Sin definir | **Del acta**, criterio de éxito (mitad «medido»); el contenido es **sin definir** | — |
| 9 | Reglamento aprobado por el Consejo de Administración | Consejo de Administración (supuesto) | **Supuesto**: sale del informe 2026-10-19 como riesgo, no del acta. Si es entregable de este proyecto o de un tercero, nadie lo ha dicho | — |

No creé nodos para pruebas de seguridad, cumplimiento, capacitación, puesta en marcha o soporte: nadie los ha dicho y agregarlos «porque es lo normal» sería rellenar.

## Orden
Sin fechas; solo qué necesita qué.
- Lo que el cronograma v1 ya declara: 4 → 5 → 6 (diseño aprobado, luego ambiente de pruebas, luego integración con el core).
- **Supuesto:** 7 (producción) necesita 4, 5 y 6. Es lo que cualquier lector asumiría, pero el acta no lo dice.
- **Supuesto:** 8 (medición) necesita 7; no se puede medir lo que no está en producción.
- **Sin definir:** de qué dependen los componentes 1, 2 y 3 y dónde caen frente a 4, 5 y 6.
- **Sin definir:** si 9 (reglamento) bloquea el paso a producción o solo el lanzamiento comercial.
- **Sin definir:** qué necesita el proyecto del core cooperativo y de su proveedor (el acta no declara ninguna dependencia).

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Diseño, ambiente de pruebas e integración con el core (hitos del cronograma v1) son parte del alcance y no entregables de otro proyecto | Si pertenecen al proyecto del core (PRY-202 existe en la carpeta de proyectos; no lo verifiqué ni el acta lo cita), la WBS está inflada y la dependencia es más grande de lo que parece |
| «En producción» significa que entra en producción para toda la cooperativa y no un piloto | Cambia lo que cuenta como entregable 7 y quién lo acepta |
| «Medido» exige al menos una métrica en operación real | Sin esto, 8 no tiene criterio de aceptación |
| El reglamento (9) es una condición del proyecto y no de un tercero | Si es de un tercero, deja de ser nodo y pasa a ser dependencia con doliente |
| Producción (7) viene después de integración con el core (6) | Si se pueden hacer en paralelo, el orden cambia |
| El presupuesto de 18.000.000.000 COP cubre los 9 nodos | El acta no lo reparte por componente; no hay cómo verificarlo |

Cuando el plan se apruebe, estos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los componentes 1, 2 y 3 | Patrocinador (Liliana Torres), por ser dueña del acta |
| Qué se mide, con qué umbral y desde cuándo | Patrocinador / Bienestar social |
| Qué cubre «lo que otro proyecto cubre» | Patrocinador, con la PMO |
| Quién acepta cada entregable | Patrocinador; el acta no lo dice |
| Autoridad del gerente al planificar | Patrocinador / Comité de Riesgos |
| Relación con el core cooperativo y su proveedor | Patrocinador y dueño del core |
| Quién certifica el ambiente de pruebas | Sin definir |
| Si el reglamento es de este proyecto | Sin definir |

## Proyectos análogos
**No hay ninguno a la vista.** La configuración de PRY-206 no apunta a una carpeta de fichas de la PMO, y en `estado/` solo existe la de este proyecto. Hay otras carpetas de proyectos en `documentos/proyectos/`, pero sin fichas no puedo decir qué les pasó, y no voy a estimar por parecido de nombre. Se deja sin referencia, que evita una falsa precisión.

Lo único comparable es el propio proyecto: su cronograma v1 declaraba cierre 2025-12-31, y 16 meses después sigue abierto (informe 2026-10-19: avance declarado 79 %, estado amarillo). Eso es un dato sobre este proyecto, no una estimación para los nodos nuevos.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto toma el componente 1? Y antes, ¿qué es?
2. ¿Cuánto toma el componente 2? Y antes, ¿qué es?
3. ¿Cuánto toma el componente 3? Y antes, ¿qué es?
4. ¿Cuánto falta, hoy, para el diseño funcional aprobado? El cronograma v1 lo daba por cumplido, pero no encontré el documento de aprobación.
5. ¿Cuánto toma certificar el ambiente de pruebas, y quién lo certifica?
6. ¿Cuánto toma la integración con el core, y qué entrega el proveedor del core y cuándo?
7. ¿Cuánto toma pasar a producción una vez integrado?
8. ¿Cuánto tiempo de operación hace falta para poder decir «medido»?
9. ¿Cuánto toma la aprobación del reglamento en el Consejo de Administración, y cuándo sesiona?

## Para comprometer una fecha falta
- La **disponibilidad real del equipo**: el informe del 2026-10-19 registra una rotación que costó dos semanas, y las notas del 2026-10-23 dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase.
- La **fecha del proveedor** del core y del proveedor de QR (si son distintos; no se sabe), y qué dice su contrato. No hay contrato en la carpeta.
- La **ventana de producción** y las fechas de sesión del Consejo de Administración.
- El **ajuste de presupuesto** que Laura Vélez quedó de enviar «la otra semana» (sin fecha): el informe proyecta 18.497.117.057 COP contra 18.000.000.000 aprobados, declarado por el gerente y no verificado aquí.

La fecha la compromete el gerente. Este borrador no pone ninguna.
