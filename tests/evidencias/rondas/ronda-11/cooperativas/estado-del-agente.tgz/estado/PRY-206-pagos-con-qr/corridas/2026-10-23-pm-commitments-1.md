# Corrida del 2026-10-23 · pm-commitments

1 proyectos · 42 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 5 |
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 4 |
| `milestone_met_without_evidence` | 3 |
| `progress_vs_plan` | 1 |

4 reprogramados (Paula Céspedes 6 veces, María Restrepo 5 y 4, Laura Vélez 3), 4 vencidos sin evidencia y 5 sin fecha

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Compromisos — Pagos con QR (PRY-206) · al 2026-10-23

20 compromisos abiertos de 26 registrados: 4 vencidos sin evidencia, 5 sin fecha, 4 reprogramados (3 o más veces). Cifras de `portafolio.py compute`.

### Se viene reprogramando

> **Paula Céspedes** · Enviar el documento 1
> Prometido para el 2026-12-14, y antes para el 11-30, 11-18, 11-06, 10-23 y 10-06; la promesa original era el 2026-09-21. **Seis reprogramaciones desde que se dijo el 2026-09-11.**
> **Tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **María Restrepo** · Cerrar la prueba 2
> Vigente: 2026-11-24. Antes: 11-07, 10-31, 10-14 y 10-06; original 2026-09-14. **Cinco reprogramaciones.**

> **María Restrepo** · Revisar el anexo 3
> Vigente: 2026-11-14. Antes: 10-26, 10-19 y 09-28; original 2026-09-16. **Cuatro reprogramaciones.** Es la misma persona del punto anterior: dos bloqueos con un mismo doliente.

> **Laura Vélez** (gerente del proyecto) · Validar el ambiente 4
> Vigente: 2026-11-11. Antes: 10-29 y 10-14; original 2026-10-05. **Tres reprogramaciones.**

Fuera del umbral, a vigilar: Jorge Medina, «Validar el ambiente 12», lleva dos (original 09-30, vigente 11-06).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-21 | 2 días |
| Liliana Torres | Enviar el documento 17 | 2026-10-19 | 4 días |
| Diana Molina | Confirmar la fecha 23 | 2026-10-19 | 4 días |
| Elena Duarte | Entregar el punto 24 | 2026-10-20 | 3 días |

Gustavo Neira dijo en el comité del 2026-10-09 que «Cerrar la prueba 10» estaba entregado; no hay acta ni documento en el expediente que lo respalde, así que sigue abierto.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Carlos Peña | Confirmar la fecha 7 | 2026-09-18 |
| Javier Hoyos | Revisar el anexo 11 | 2026-09-25 |
| Liliana Torres | Aprobar el diseño 13 | 2026-10-02 |
| Carlos Peña | Entregar el punto 16 | 2026-10-02 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-23 |

No pueden estar vencidos, por eso se cuentan aparte. Laura Vélez dijo «la otra semana», que no es una fecha, y no se le puso una.

Cuatro de estos cinco (Carlos Peña ×2, Javier Hoyos, Liliana Torres) fueron declarados entregados en reunión, sin acta ni documento. Siguen abiertos.

### Cerrados desde la última revisión
Es la primera revisión de compromisos; los cierres con documento son:
- María Restrepo · Aprobar el diseño 5 — `20-seguimiento/2026-10-09-acta-recibo-5.md`
- Elena Duarte · Actualizar la matriz 6 — `20-seguimiento/2026-10-16-acta-recibo-6.md`
- Gustavo Neira · Entregar el punto 8 — `20-seguimiento/2026-09-25-acta-recibo-8.md`
- Sandra Gil · Enviar el documento 9 — `20-seguimiento/2026-10-09-acta-recibo-9.md`
- Liliana Torres · Confirmar la fecha 15 — `20-seguimiento/2026-10-09-acta-recibo-15.md`
- Andrés Lozano · Cerrar la prueba 18 — `20-seguimiento/2026-10-16-acta-recibo-18.md`

### Contra lo que dice el informe del 2026-10-19
El informe declara estado amarillo y 79 % de avance, y no recoge los compromisos vencidos ni las cuatro reprogramaciones.

### Después
Lo de Paula Céspedes (6 reprogramaciones) y María Restrepo (9 entre sus dos compromisos) excede al gerente. Puedo formularlo como decisión para el próximo comité (30-10): qué se pide, qué pasa si no se decide y quién tiene la facultad. Y como la ficha cambió, `/pm-publish` deja que la PMO la vea.
