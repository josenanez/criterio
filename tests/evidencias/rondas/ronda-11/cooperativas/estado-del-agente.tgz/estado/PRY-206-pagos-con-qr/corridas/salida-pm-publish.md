Términos vigentes (versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23; comprobante en `.criterio/terminos/`). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Recalculé la ficha antes de publicar (corte 2026-10-23). `plan.end_date` es 2025-12-31 y sale del único cronograma que hay (v1, 2025-06-06); no hay uno más nuevo, así que la fecha vigente y la de la línea base coinciden.

**Qué voy a publicar:** 114 campos con dato · 5 sin decir en ninguna parte (autoridad, fase y la evidencia de los 3 hitos) · declara **amarillo** al 2026-10-19 (79 % de avance, según el informe de avance, declaración del gerente).

Publiqué la ficha en `documentos/proyectos/PRY-206-pagos-con-qr/00-gobierno/ficha-pm.json`, con corte al 2026-10-23.

**Lleva:** 114 campos con dato · 5 sin decir en ninguna parte · declara **amarillo** al 2026-10-19

**Lo más viejo que va ahí:** identidad, plan (fechas, hitos, alcance) y presupuesto aprobado, todos del acta de constitución y el cronograma del 2025-06-06, con 16 meses; pasa de un año.

**Para tener presente (la PMO lo va a ver):**
- Los 3 hitos figuran como cumplidos en el cronograma v1, sin ninguna evidencia de recibo; el avance declarado (79 %) queda 21 puntos por debajo de lo que ese plan sostiene (100 %).
- La fecha de cierre vigente (2025-12-31) ya pasó hace casi 10 meses y no hay un cronograma posterior.
- 4 compromisos vencidos, 5 sin fecha y 4 reprogramados 3 o más veces.
- Patrocinador, gerente y comité vienen del acta de 2025; si cambiaron en alguna reunión, conviene corregirlo antes de que Vera lo contraste.
