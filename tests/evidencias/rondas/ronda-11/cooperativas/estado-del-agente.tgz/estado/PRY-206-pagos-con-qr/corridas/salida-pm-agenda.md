## Reunión de seguimiento — Pagos con QR (PRY-206) · 2026-10-30
8 puntos de decisión + 1 verificación · 43 minutos · 8 personas requeridas

*Términos: vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hizo falta registrarlos otra vez.*

**Tres cosas que debes saber antes de usarla:**
- **Fecha:** tomé el 2026-10-30 porque es la que dice la configuración (comité semanal). Las notas del 10-23 dicen «próxima reunión en dos semanas» (≈ 11-06). Si es el 11-06, cambia el bloque «Vence antes de la próxima» (ver abajo). Lo decide quien convoca.
- **Duración:** la configuración no trae la duración de la reunión. Supuse 45 minutos y la agenda suma 43. Si es otra, dímelo y recorto por el final.
- **Qué cambió:** es la primera corrida, no hay foto anterior. «Lo que cambió» lo saqué de comparar el comité del 2026-10-16 con las notas del 2026-10-23 y con el cálculo de hoy.

### Lo que no se destraba solo

> **[1] Que alguien nombre qué bloquea «Enviar el documento 1» y quién lo destraba** · 8 min · **Paula Céspedes** (con Liliana Torres, patrocinadora, en la sala)
> Prometido para el 2026-12-14, y antes para el 11-30, el 11-18, el 11-06, el 10-23 y el 10-06; la promesa original era el 2026-09-21. **Seis reprogramaciones** en seis reuniones seguidas.
> Fuente: `30-reuniones/2026-09-11-comite-semanal.md` (origen) y `2026-10-23-notas-reunion.txt`, línea 4 (la última); cálculo `commitment_rescheduled` del 2026-10-23.
> **Si no se resuelve hoy:** la fecha vuelve a correrse en el próximo comité; ya cae después del cierre de año y el expediente no dice qué depende de este documento.
> *Lo que el expediente no dice:* qué lo bloquea. Ningún documento da la causa; hay que preguntarla.

> **[2] Lo mismo para «Cerrar la prueba 2» y «Revisar el anexo 3»** · 8 min · **María Restrepo**
> Prueba 2: vigente 2026-11-24; antes 11-07, 10-31, 10-14 y 10-06; original 2026-09-14 (**5 reprogramaciones**). Anexo 3: vigente 2026-11-14; antes 10-26, 10-19 y 09-28; original 2026-09-16 (**4 reprogramaciones**). Un mismo doliente con dos bloqueos: pregunta si es capacidad suya o algo que depende de otro.
> Fuente: `30-reuniones/2026-10-16-comite-semanal.md` y las actas anteriores del comité semanal; cálculo del 2026-10-23.
> **Si no se resuelve hoy:** la prueba 2 sigue corriéndose y el 10-26 vence la fecha previa del anexo sin que nadie lo vea.

> **[3] Validar el ambiente 4: confirmar la fecha o decir qué la mueve** · 4 min · **Laura Vélez** (gerente)
> Vigente 2026-11-11; antes 10-29 y 10-14; original 2026-10-05 (**3 reprogramaciones**).
> Fuente: `30-reuniones/2026-10-16-comite-semanal.md`; cálculo del 2026-10-23.
> **Si no se resuelve hoy:** es la cuarta; se incumple el umbral de tres y queda como bloqueo sin nombrar.

### Vencido sin evidencia

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-21 (hace 2 días al 10-23) | Dijo en el comité del 10-09 que estaba entregado; no hay acta de recibo. Traer el documento o dar nueva fecha | 3 |
| Liliana Torres | Enviar el documento 17 | 2026-10-19 (4 días) | Entregarlo o dar fecha. Además «Aprobar el diseño 13» (sin fecha): dijo el 10-16 que ya lo entregó, sin acta | 3 |
| Diana Molina | Confirmar la fecha 23 | 2026-10-19 (4 días) | Confirmar la fecha en la sala | 3 |
| Elena Duarte | Entregar el punto 24 | 2026-10-20 (3 días) | Entregarlo o dar fecha | 3 |

Fuentes: `30-reuniones/2026-09-25-comite-semanal.md`, `2026-10-09-…`, `2026-10-16-…`; cálculo `commitment_overdue` del 2026-10-23. Los días son al 10-23; al 10-30 serán 7 más.
**Si no se resuelve hoy:** el informe de avance del 10-19 (amarillo, 79 %) sigue sin recoger ninguno de estos cuatro.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha real de «Mandar el ajuste del presupuesto» (hoy «la otra semana», sin fecha) | Laura Vélez | Sigue como compromiso sin fecha, que no puede vencer. La proyección declarada (18.497.117.057 COP) supera el aprobado (18.000.000.000 COP) en 2,8 %; las notas no relacionan las dos cosas, y no lo afirmo | 3 |
| Dueño del riesgo «el proveedor podría no llegar con el equipo completo a la siguiente fase» | Laura Vélez, con Óscar Ramírez presente | Queda sin dueño y fuera del RAID; nadie lo anotó el 10-23 (notas, línea 7). La revisión con el proveedor está fijada para el 2026-11-02 | 3 |
| Cadencia del comité: ¿semanal (como dice la configuración) o cada dos semanas (como dijeron las notas)? | Quien convoca el comité | Se sigue convocando por una fecha que nadie confirmó | 2 |

### Vence antes de la próxima

| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 (antes de esta reunión: preguntar si se hizo; 1 min) |

Si la próxima reunión resulta ser el 11-06, entran también Óscar Ramírez «Revisión con el proveedor» (2026-11-02) y Gustavo Neira «Validar el ambiente 20» (2026-11-04).

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Los tres hitos declarados como cumplidos sin evidencia (diseño funcional, ambiente de pruebas, integración con el core) y el 79 % declarado frente a 100 % que sostiene el plan | Excede al gerente: es contraste del informe contra el cronograma | Material de comité (30-10); `/pm-escalate` |
| Qué hacer con Paula Céspedes y María Restrepo si el bloqueo es de otra área (6 y 9 reprogramaciones) | Depende de quién tenga la facultad. La ficha no trae autoridad del proyecto (`authority: not_found`) y no la invento | `/pm-escalate` y comité |
| Carlos Peña: «Confirmar la fecha 7» y «Entregar el punto 16»; Javier Hoyos: «Revisar el anexo 11» (los tres sin fecha) | Ninguno de los dos estuvo el 10-23; no hay forma de saber que vayan a estar. Los tres se declararon entregados en reunión, sin acta | Mensaje directo del gerente antes de la reunión |
| Jorge Medina: «Validar el ambiente 12» (2 reprogramaciones, vigente 11-06) | Bajo el umbral de tres; solo vigilar | Anexo |

### Anexo — sin cambios desde el 2026-10-16
- Gustavo Neira · Actualizar la matriz 14 · 2026-11-13
- Gustavo Neira · Validar el ambiente 20 · 2026-11-04
- Gustavo Neira · Aprobar el diseño 21 · 2026-11-12
- Ricardo Salas · Actualizar la matriz 22 · 2026-11-09
- Jorge Medina · Validar el ambiente 12 · 2026-11-06 (2 reprogramaciones; vigilar)
- Cerrados con acta de recibo, no se repasan: diseño 5, matriz 6, punto 8, documento 9, fecha 15, prueba 18.

**Fuera por tiempo:** nada. Lo que no cabía en 45 minutos se fue a «No es de esta reunión», no se recortó.

**Después:** `/pm-escalate` para la decisión sobre Paula Céspedes y María Restrepo antes del comité. Cuando termine la reunión, `/pm-minutes` sobre las notas.
