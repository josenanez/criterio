## RAID — portafolio Cooperativas (13 proyectos) al 2026-10-23

**Sale de:** las 13 fichas en `estado/records/` (RAID de cada informe de avance, citado en cada ficha), las actas de constitución (sección «Dependencias declaradas»), las 17 minutas y notas de reunión en `30-reuniones/` y `2026-10-23-notas-reunion.txt`, y las solicitudes de cambio CC-01 de PRY-203 y PRY-210. La escala de valoración no está definida en la configuración: se usaría alta/media/baja, pero ningún ítem trae valoración.

11 riesgos · 0 supuestos · 12 incidencias · 10 dependencias (33 ítems)
33 sin doliente · 33 sin fecha · 21 sin dato de movimiento (los otros 12 solo traen la fecha «desde» o la de la reunión) · 1 no registrado formalmente

**Lo que este registro no puede decir:** ningún ítem tiene doliente, fecha, probabilidad, impacto ni mitigación en ningún documento. No se rellenó nada. Sin historial de movimiento por ítem no se puede afirmar «dos períodos sin movimiento»: se reporta como «sin dato». Ningún proyecto declara supuestos ni dependencias en su acta («Ninguna declarada» en los 13), así que el registro de supuestos está vacío por falta de documentos, no porque no existan.

**Reclasificados (†, 10 ítems).** Estaban como riesgos en el informe de avance; por la prueba «depende de alguien fuera del proyecto» son dependencias:
- «Dependencia del proveedor del core cooperativo» (PRY-202, 204, 206, 209): el propio texto dice que es una dependencia.
- «El proveedor no ha confirmado la fecha de la última entrega» (PRY-200, 211): lo que el proyecto necesita lo controla un tercero y no está confirmado.
- «Aprobación del reglamento por el Consejo de Administración» (PRY-199, 201, 206, 207): la aprobación la da un órgano externo al proyecto. Es la reclasificación más discutible; el gerente decide si la deja como dependencia.

Ninguna dependencia lleva código de proyecto de destino porque nadie lo declaró. No lo asigné.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-203·2, 204·2, 208·2 (y 199·2, 201·1, 206·2, 207·1) | Incidencia / Dependencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto; en otros cuatro proyectos la aprobación del reglamento sigue como pendiente | sin doliente | 2026-10-07 (PRY-204), 2026-10-20 (PRY-208), 2026-10-22 (PRY-203) | Afecta a 7 proyectos a la vez y la decide un órgano fuera de todos ellos. PRY-203 tiene el piloto el 2026-12-04. |
| PRY-202·2, 204·1, 206·1, 209·2 | Dependencia | Proveedor del core cooperativo | sin doliente | sin dato | Afecta a 4 proyectos más al propio PRY-202. La ficha de PRY-202 no registra proveedor ni contrato. No se puede decir si la dependencia es de PRY-202; nadie lo declaró. |
| PRY-201·3 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | sin doliente | 2026-10-20 | Incidencia abierta sin doliente ni fecha, en un proyecto declarado verde. El informe no dice la severidad. |
| PRY-200·4, 211·2 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes, sin nueva fecha en ningún cronograma | sin doliente | 2026-10-18 / 2026-10-19 | Una salida sin fecha no tiene cronograma que la sostenga. PRY-200 declara amarillo y PRY-211 verde. |
| PRY-200, 201, 202, 205, 209 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | sin doliente | 2026-10-18 a 2026-10-23 | Mismo texto en cinco informes. Nadie lo ha vinculado como un solo asunto. Si es un ambiente o un proveedor común, afecta a todos. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo a la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-206-pagos-con-qr/2026-10-23-notas-reunion.txt | 2026-10-23 |

Es el único. Las otras 16 minutas solo traen tablas de compromisos y no contienen riesgos dichos al pasar. Comprobé el texto de cada una.

### Sin doliente o sin fecha
Los 33 ítems. Detalle en el registro completo. Faltan además probabilidad e impacto en los 11 riesgos y 10 dependencias, y la fecha «desde» en PRY-206·4 (el equipo perdió dos semanas por rotación de un desarrollador clave).

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-200·2, 211·1 | Proveedor (sin nombre en el informe) | No: «no ha confirmado la fecha» | Declarada, no acordada. PRY-200 tiene fin planeado 2026-08-02 y PRY-211 2026-03-07, ambos ya vencidos. |
| PRY-202·2, 204·1, 206·1, 209·2 | Proveedor del core cooperativo | Sin dato | Declarada, no acordada. El proyecto PRY-202 (Core cooperativo) no movió su línea base: fin 2027-04-09, sin cambios. Su hito «Integración con el core cooperativo» está pendiente para 2027-04-09, y PRY-203 registra su propio hito de integración con el core como cumplido el 2026-09-22 sin acta de recibo. No sé si esto es contradicción o son integraciones distintas; hay que preguntar. |
| PRY-199·2, 201·1, 206·2, 207·1 | Consejo de Administración | Sin dato | El Consejo ya pidió ajustes en 3 proyectos hermanos (ver arriba). |

Ningún proyecto que sea destino de una dependencia movió su fecha, y eso es todo lo que puedo afirmar: como ninguna dependencia lleva código de destino, el cruce está incompleto.

### Registro completo
† reclasificado de riesgo a dependencia · ‡ no registrado formalmente

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-199·2 | Dependencia † | Aprobación del reglamento por el Consejo de Administración | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-200·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-200·2 | Dependencia † | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-200·3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | sin fecha | desde 2026-10-18 |
| PRY-200·4 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes (sin nueva fecha en ningún cronograma) | — | — | sin doliente | sin fecha | desde 2026-10-18 |
| PRY-201·1 | Dependencia † | Aprobación del reglamento por el Consejo de Administración | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-201·2 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | sin fecha | desde 2026-10-20 |
| PRY-201·3 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | — | — | sin doliente | sin fecha | desde 2026-10-20 |
| PRY-202·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-202·2 | Dependencia † | Dependencia del proveedor del core cooperativo | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-202·3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | sin fecha | desde 2026-10-19 |
| PRY-203·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-203·2 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | sin doliente | sin fecha | desde 2026-10-22 |
| PRY-204·1 | Dependencia † | Dependencia del proveedor del core cooperativo | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-204·2 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | sin doliente | sin fecha | desde 2026-10-07 |
| PRY-205·1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205·2 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-205·3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | sin fecha | desde 2026-10-23 |
| PRY-206·1 | Dependencia † | Dependencia del proveedor del core cooperativo | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-206·2 | Dependencia † | Aprobación del reglamento por el Consejo de Administración | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-206·3 | Riesgo ‡ | El proveedor podría no llegar con el equipo completo a la siguiente fase | sin valorar | sin valorar | sin doliente | sin fecha | 2026-10-23 |
| PRY-206·4 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | sin doliente | sin fecha | sin dato |
| PRY-207·1 | Dependencia † | Aprobación del reglamento por el Consejo de Administración | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-208·1 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-208·2 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | sin doliente | sin fecha | desde 2026-10-20 |
| PRY-209·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-209·2 | Dependencia † | Dependencia del proveedor del core cooperativo | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-209·3 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | sin doliente | sin fecha | desde 2026-10-23 |
| PRY-210·1 | Riesgo | Concentración del conocimiento en una sola persona | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-210·2 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211·1 | Dependencia † | El proveedor no ha confirmado la fecha de la última entrega | sin valorar | sin valorar | sin doliente | sin fecha | sin dato |
| PRY-211·2 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes (sin nueva fecha en ningún cronograma) | — | — | sin doliente | sin fecha | desde 2026-10-19 |

Fuente de cada ítem: el informe de avance más reciente de su proyecto (ruta completa en la ficha `estado/records/<código>.json`); PRY-206·3 sale de `PRY-206-pagos-con-qr/2026-10-23-notas-reunion.txt`.

### Después
Puedo preparar para comité, con la decisión formulada, los cuatro primeros puntos de «Necesitan decisión ahora». Y puedo proponer dolientes para los 33 ítems; propondría, no asignaría. Los gerentes de proyecto y el comité confirman. No hice ninguna de las dos cosas.

---
**Pie de rigor.** Borrador de trabajo, no decisión ni asesoría. Todo sale de los documentos citados; no sé lo que se habló fuera de ellos. Reclasificar riesgo a dependencia es criterio mío y el gerente lo confirma. El tipo de PRY-206·3 (riesgo y no dependencia) también lo es. No se inventó ningún riesgo, doliente, fecha ni valoración.
