# Corrida del 2026-10-23 · portfolio-wake

13 proyectos · 41 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Barrido sin cambios (79 documentos); confirmación: 5 preguntas (PRY-205 y PRY-208), sin respuesta en sesión desatendida; no sé producto, autoridad ni fase de esos dos proyectos.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## 2026-10-23

**Revisé:** 79 documentos · 0 cambiaron · 0 proyectos recalculados. Sin peticiones en el servidor. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23).

### Lo que cruzó un umbral
Nada. El barrido corrió y no había noticia.

### Preguntas (confirmación mensual, primera corrida: 5 campos, sin respuesta porque la sesión es desatendida)
Elegidos por importancia: los dos proyectos en rojo (PRY-205 y PRY-208), que además declaran su estado sin producto, autoridad ni fase en la evidencia. Ningún dato tiene más de 12 meses; la antigüedad no es el criterio hoy.

1. **PRY-205 · producto**: no aparece en ningún documento. ¿A qué producto responde?
2. **PRY-205 · autoridad**: no aparece. ¿Quién tiene la autoridad que aprueba cambios? (Informe de avance del 2026-10-23.)
3. **PRY-208 · producto**: no aparece. ¿A qué producto responde?
4. **PRY-208 · autoridad**: no aparece. ¿Quién tiene la autoridad que aprueba cambios? (Informe de avance del 2026-10-20.)
5. **PRY-205 · fase**: no aparece. ¿En qué fase está?

Respuesta sugerida y aplicada: dejar los cinco campos como «no encontrado», sin inventar valor. Quedan preguntadas el 2026-10-23, sin respuesta; no se repiten, se reportan así.

**Vuelvo el 2026-10-24.**
