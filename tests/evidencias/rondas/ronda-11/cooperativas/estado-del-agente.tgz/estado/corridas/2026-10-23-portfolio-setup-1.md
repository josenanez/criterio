# Corrida del 2026-10-23 · portfolio-setup

3 proyectos · 79 documentos, 61 releídos y 18 sin cambio · 113 s · 18 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `progress_vs_plan` | 3 |
| `commitment_overdue` | 2 |
| `declared_vs_evidence` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `commitment_undated` | 1 |
| `rebaseline_unauthorized` | 1 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); tiempo hasta el primer resultado no medido; 3 proyectos leídos (PRY-205, PRY-209, PRY-204), 18 señales, 2 verdes contradichos por la evidencia

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Cooperativas

**Miré:** 79 documentos en 13 proyectos · formatos: md (37), docx (13), pdf (13), xml (8), xlsx (5), csv (1), json (1), txt (1) · más reciente: 2026-10-23
**Eres:** PMO del portafolio (propuesto por haber varios proyectos)
**Te aviso:** dos días antes del comité; comité semanal, próximo viernes 2026-10-30 (informe el miércoles 28)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2, fecha 2026-10-23) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-23.md` y `.pdf` · SHA-256 del Markdown fe830b9a4eee0bc9…
**Carpeta:** `documentos/proyectos`, marcada con `_CRITERIO_PORTAFOLIO.txt`. Estado en `estado`, informes en `reportes`.

### Probé con tres proyectos

Los de documentación más reciente: PRY-205, PRY-209 y PRY-204.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-205 Prevención de lavado de activos | 4 | Gerente Carlos Peña, patrocinador Óscar Ramírez, Comité de Riesgos. Declara **rojo, 67%** (informe 2026-10-23). Aprobado COP 4.200.000.000, ejecutado 841.054.466 (20%). Cierre 2027-09-07. 2 compromisos abiertos (30-oct y 9-nov). | Producto, facultad del gerente, etapa. |
| PRY-209 Convenios de libranza con empresas | 7 | Gerente Liliana Torres, patrocinador Carlos Peña, Comité de Tecnología. Declara **verde, 35%** (2026-10-23). Aprobado COP 3.300.000.000, ejecutado 1.632.928.205 (49,5%). Cierre original 2026-11-07, vigente 2027-03-05. Solicitud CC-01 (+118 días, +COP 236.000.000) pendiente de comité. | Producto, facultad del gerente, etapa. Fecha del compromiso del punto 31. |
| PRY-204 Tarjeta débito para asociados | 7 | Gerente Sandra Gil, patrocinadora Diana Molina, Comité de Crédito. Declara **verde, 37%** (2026-10-07). Aprobado COP 9.500.000.000, ejecutado 5.254.568.526 (55,3%), proyección +3,1%. Proveedor Soluciones Solidarias, contrato CT-222. | Facultad del gerente, etapa. |

**Lo que `compute` levantó (18 señales):**

- **PRY-209:** `declared_vs_evidence` (declara verde y hay cuatro señales detrás); `variance_time` (118 días, 23,8% contra la línea base original); `rebaseline_unauthorized` (el cronograma v2 del 2026-10-23 ya mueve la salida a producción a 2027-03-05, y la CC-01 sigue sin autorización); `progress_vs_plan` (declara 35% y el plan sostiene 80–100%); `milestone_met_without_evidence` en tres hitos (diseño funcional, ambiente de pruebas e integración con el core: el cronograma los da por cerrados y no hay acta; solo el piloto tiene acta de recibo, del 2026-10-20); `commitment_undated` (Liliana Torres, punto 31, «por definir»).
- **PRY-204:** `declared_vs_evidence` (verde contra cinco señales); `progress_vs_plan` (declara 37% y el plan sostiene 60–80%); `milestone_met_without_evidence` en diseño funcional y ambiente de pruebas; `vendor_deliverable_late` (licenciamiento del módulo, vencido hace 60 días y aún pendiente); `vendor_invoiced_without_delivery` (factura FV-1222 por COP 1.064.377.272 radicada el 2026-09-10 sin acta de recibo, cuando el contrato condiciona el pago a esa acta); dos `commitment_overdue` (el punto 20, de Jorge Medina, vencido hace 9 días; el punto 11, de Elena Duarte, vencido hace 5; sin evidencia de cumplimiento).
- **PRY-205:** `milestone_met_without_evidence` (diseño funcional, cerrado el 2026-09-04 sin acta); `progress_vs_plan` en sentido contrario: declara 67% y el plan sostiene 25–50%. El proyecto está en rojo y no hay otra señal de atraso en los documentos.

Dos de los tres proyectos declaran verde con señales en contra. Ninguno de los tres trae `authority`.

### El portafolio completo

10 proyectos más (PRY-199 a PRY-203, PRY-206 a PRY-208, PRY-210 y PRY-211) y 61 documentos, en un lote de diez proyectos y otro de uno, uno tras otro. Con los tres de esta prueba como referencia, calculo que es aproximadamente el triple de lo que tomó esta lectura. Es una estimación, no una medida.

### Lo que le falta a tu carpeta

- 8 cronogramas `.xml` no se leen con el lector estándar (PRY-201, 202, 203, 204, 206, 210 ×2 y 211). El de PRY-204 lo leí como texto; en el barrido completo hay que leer los demás igual.
- `PRY-206-pagos-con-qr/2026-10-23-notas-reunion.txt` está suelto en la raíz del proyecto, fuera de `30-reuniones`.
- PRY-207 y PRY-208 solo tienen acta de constitución e informe de avance. No tienen cronograma ni reuniones.
- Ninguna acta nombra la facultad del gerente: cuánto puede decidir sin subir a comité.
- Los hitos cerrados en los cronogramas casi nunca traen su acta de recibo.
- Hay una ficha publicada por el gerente (`PRY-206-pagos-con-qr/00-gobierno/ficha-pm.json`). Se guardará en `pm_record` cuando se lea ese proyecto.
