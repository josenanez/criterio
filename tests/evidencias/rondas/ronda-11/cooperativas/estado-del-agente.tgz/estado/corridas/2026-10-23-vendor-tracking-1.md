# Corrida del 2026-10-23 · vendor-tracking

13 proyectos · 30 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Proveedor Talento Solidario (CT-989): 2 entregables vencidos sin recibo, 0 aceptados; sin facturación, vencimiento ni preaviso en los documentos; estado declarado Verde sin sustento.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

## Proveedores — PRY-203 Aportes sociales en línea al 2026-10-23

**De qué documentos sale:** contrato `00-gobierno/2026-02-10-contrato-ct-989.md`; informe de avance `20-seguimiento/2026-10-22-informe-avance.pdf`; comité `30-reuniones/2026-10-13-comite-semanal.docx`; ficha `estado/records/PRY-203.json`; cifras de `portafolio.py compute`. En la carpeta no hay actas de recibo, correos de aceptación ni facturas.

### Talento Solidario Ltda. — contrato CT-989
**Vigencia:** firma 2026-02-10; el contrato no declara fecha de inicio ni de terminación · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2026-05-26 · 395.187.394 COP | pending (contrato: "pendiente") | ninguna | sin dato |
| Bolsa de horas de desarrollo | 2026-09-04 · 395.187.394 COP | pending (contrato: "pendiente") | ninguna | sin dato |
| Parametrización de líneas de crédito | 2026-12-14 · 395.187.394 COP | pending (contrato: "en curso") | ninguna | sin dato |

Según el script: 3 entregables, 0 aceptados, monto aceptado 0, `invoiced` = null.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Estado de "Parametrización de líneas de crédito" | "en curso" | La ficha lo registra como `pending`, sin evidencia de avance | contrato CT-989; ficha |
| Estado general del proyecto | Dos entregables del proveedor vencidos y sin recibo | El informe declara **Verde**, 65 % | informe de avance 2026-10-22; script (`declared_vs_evidence`) |
| Hitos del proyecto | — | 3 hitos declarados "met" sin evidencia: Diseño funcional aprobado (178 días), Ambiente de pruebas certificado (105 días), Integración con el core cooperativo (31 días) | cronograma v2; script |

El informe de avance no menciona al proveedor ni los entregables vencidos.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del módulo | pending; vencido, 150 días | 2026-05-26 |
| Bolsa de horas de desarrollo | pending; vencido, 49 días | 2026-09-04 |

`accepted_without_evidence`: vacío. Nadie declara aceptado nada que no esté probado. El problema es el contrario: dos entregables vencidos que nadie declara entregados ni recibidos. La señal `vendor_deliverable_late` se levanta dos veces.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso de reunión (comité 2026-10-13) es de Camilo Beltrán: "Entregar el punto 4", para 2026-11-13. Está abierto, no vencido, y la minuta no dice si Camilo Beltrán pertenece al proveedor.

### Sin dato
- **Vencimiento del contrato, renovación automática y preaviso:** CT-989 no los declara. No puedo decir si hay un preaviso por vencer. Hay que pedir el contrato completo o sus anexos.
- **Monto facturado** (`vendors[0].invoiced`): no está en ningún documento. No se puede hacer el cruce contra lo facturado ni levantar `vendor_invoiced_without_delivery`.
- **Actas de recibo:** el contrato exige acta firmada por el gerente del proyecto (Rubén Cárdenas) para facturar cada entregable. No hay ninguna en la carpeta. Eso no prueba que no existan; prueba que no están aquí.
- **Autoridad del proyecto y fase:** no declaradas (`identity.authority`, `identity.phase`).
- **Solicitud de cambio CC-01** (+85 días, +170.000.000 COP, ampliación de alcance sin detalle): el documento no dice si toca el contrato con el proveedor.

### Después
No hay preaviso que se pueda declarar por vencer, porque el contrato no trae fechas. Hay dos entregables vencidos sin recibo bajo un estado declarado "Verde". Eso vale la pena llevarlo a comité (próximo: 2026-10-30), junto con la pregunta de si se facturó algo contra ellos. No hay dato para afirmarlo.

---
**Rigor:** cifras copiadas de `portafolio.py compute` (2026-10-23). Cada línea cita su documento. Lo que no está en la carpeta se declara arriba como "sin dato". La verificación contra los originales es de quien lea. Criterio produce borradores de trabajo, no decisiones ni asesoría.
