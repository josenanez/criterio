# Corrida del 2026-10-23 · product-view

13 proyectos · 67 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Producto recaudos con un solo proyecto (PRY-211): sin vista de producto, se reportó el proyecto. Verde declarado contradicho por 3 hitos sin evidencia, 63 puntos de brecha de avance y proyección +25,7 %. No se sabe: autoridad, fase, cuál de avance o hitos es el erróneo; fuentes sin marcar. 5 proyectos sin producto declarado. Segundo registro: el primero salió sin archivo de salida por una ruta mal escrita.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Salida de `/product-view recaudos`, con las fichas del estado calculadas al 2026-10-23. Términos vigentes: v1.2, aceptados por José Francisco Ñáñez el 2026-10-23.

## Producto «recaudos» al 2026-10-23

**Recaudos tiene un solo proyecto, PRY-211 «Cobranza digital».** La vista por producto no aporta nada aquí: no hay suma de señales entre proyectos, ni dependencias internas, ni una fecha del producto distinta de la del proyecto. No armo una sección de producto. Lo que sigue es lo que `compute` dice de ese único proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| recaudos | 1 (PRY-211) | 1 de 1, con 7 alertas | 2026-03-07 | COP 4.200.000.000 | COP 3.403.064.146 |

**Dinero.** El único proyecto trae las cuatro cifras, así que la suma está completa (1 de 1).
- Ejecutado: COP 1.718.932.257 (40,9 %).
- Comprometido: 81,0 % del aprobado.
- Disponible real: COP 796.935.854.
- Proyección: COP 5.280.911.293, **25,7 % sobre lo aprobado**. Es la señal `variance_cost`.

**Fecha.** El fin del plan es 2026-03-07 y es anterior a la fecha de este informe. No hay desviación contra la línea base (0 días contra la original y contra la vigente, 0 replanificaciones). Sí hay línea base.

**Lo que hay que ver en PRY-211**
- **El verde declarado no se sostiene.** El informe de avance del 2026-10-19 declara «verde» y 37 % de avance. Tres señales quedan sin explicar: hitos cumplidos sin evidencia, avance contra plan y desviación de costo. (Fuente: `PRY-211-cobranza-digital/20-seguimiento/2026-10-19-informe-avance.pdf`.)
- **Los tres hitos están declarados «cumplidos» sin evidencia de cumplimiento:**
  - Diseño funcional aprobado, vencimiento 2025-09-24, 394 días.
  - Ambiente de pruebas certificado, vencimiento 2025-12-15, 312 días.
  - Integración con el core cooperativo, vencimiento 2026-03-07, 230 días.
- **El avance declarado no cuadra con el plan.** El plan respalda entre 100 % y 100 % (3 de 3 hitos cumplidos) y el informe dice 37 %, una brecha de 63 puntos. Una de las dos cifras está mal: o el avance subestima lo hecho, o los hitos están marcados como cumplidos sin estarlo. Los documentos no permiten decidir cuál.
- **Un compromiso sin fecha.** Óscar Ramírez, «Entregar el punto 13». (Fuente: `PRY-211-cobranza-digital/30-reuniones/2026-10-10-comite-semanal.docx`.)
- **Sin proveedores registrados** en la ficha. No hay entregables ni facturación que contrastar.
- **Días en silencio:** 4. Hay documentos recientes, no es un proyecto callado.

**Lo que no sé**
- La ficha no tiene autoridad ni fase (`identity.authority`, `identity.phase`).
- Los campos de identidad, plan y `money.approved` vienen de un documento del 2025-06-24, con 16 meses de antigüedad, por encima del umbral de 12.
- Las 15 fuentes de la ficha están sin marcar como evidencia o declaración (0 y 0), así que no puedo distinguir qué es hecho comprobado y qué es dicho.

**Dependencias internas:** no aplica, el producto tiene un solo proyecto. PRY-211 tampoco registra dependencias con otros proyectos, ni otro proyecto con ella.

## Proyectos sin producto declarado (portafolio completo)

Para recaudos no es relevante, pero el cálculo lo marca. Cinco de los 13 proyectos no declaran producto: PRY-202 Core cooperativo, PRY-205 Prevención de lavado de activos, PRY-208 Motor de crédito, PRY-209 Convenios de libranza con empresas y PRY-210 Corresponsales rurales. El área dueña no la leí en esta corrida, y no la invento. Consecuencia: nadie puede responder por el conjunto al que sirven. Tampoco puedo descartar que alguno toque recaudos, porque ninguno lo declara.

## Siguiente paso

Como no hay dependencias internas, no hay nada que llevar al comité de producto. Lo que sí merece el comité del 2026-10-30 es PRY-211 como proyecto: el verde del 2026-10-19 contra tres hitos sin evidencia y una proyección 25,7 % sobre el presupuesto aprobado.

---
*Rigor:* cifras copiadas de `portafolio.py compute` al 2026-10-23, sobre las fichas de `estado`. Nada se leyó de los documentos fuente en esta corrida. Las citas son las que la ficha trae. La verificación es de quien decide.
