# Portafolio — 2026-10-23

Fichas cargadas: 13 (PRY-199 a PRY-211), barrido del 2026-10-23. Términos vigentes: versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23.
13 proyectos · 11 con hallazgos (67 señales) · último barrido 2026-10-23

## Qué cambió desde 2026-10-23
Sin cambios desde la corrida anterior. La instantánea anterior es del mismo día y el diff devolvió 0 cambios.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes. Sí hay 7 proyectos declarados en verde que la evidencia contradice (ver "Sin sustento").

## Hitos vencidos sin evidencia
Vacía: ningún hito está vencido sin evidencia. El problema inverso sí existe: hitos declarados cumplidos sin evidencia (ver "Sin sustento").

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-207 Microcrédito rural | 16 (umbral 15) | 2026-10-07, informe de avance |

## Dependencias en riesgo
Vacía: el script no encontró dependencias declaradas entre proyectos.

## Sin sustento
Los 7 proyectos declarados en verde que la evidencia contradice:

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 Apertura de ahorro en línea | verde (2026-10-20) | Compromiso vencido y un hito cumplido sin evidencia |
| PRY-202 Core cooperativo | verde (2026-10-19) | Un hito cumplido sin evidencia; avance declarado por encima de lo que soporta el plan |
| PRY-203 Aportes sociales en línea | verde (2026-10-22) | 3 hitos sin evidencia, 85 días de atraso contra la línea base original y 2 entregables del proveedor tarde |
| PRY-204 Tarjeta débito para asociados | verde (2026-10-07) | 2 hitos sin evidencia, 2 compromisos vencidos, entregable tarde y proveedor facturado ($1.064.377.272) sin entrega |
| PRY-207 Microcrédito rural | verde (2026-10-07) | Solo silencio de 16 días |
| PRY-209 Convenios de libranza con empresas | verde (2026-10-23) | 3 hitos sin evidencia, 118 días de movimiento de línea base sin autorización, avance por encima del plan |
| PRY-211 Cobranza digital | verde (2026-10-19) | 3 hitos sin evidencia, proyección 25,7 % sobre el aprobado ($5.280.911.293 contra $4.200.000.000) |

Otros hallazgos de sustento: PRY-200 (3 hitos sin evidencia, avance sobre el plan, compromiso vencido), PRY-205 (1 hito sin evidencia, avance sobre el plan), PRY-206 (3 hitos sin evidencia; 4 compromisos vencidos, 5 sin fecha, 4 reprogramados), PRY-210 (3 hitos sin evidencia, 28 días de línea base movidos sin autorización).

## Vacíos de información
- Ningún proyecto tiene autoridad (patrocinador/aprobador) registrada: 13 de 13.
- 5 proyectos sin producto asociado: PRY-202, PRY-205, PRY-208, PRY-209, PRY-210.
- Sin problemas de esquema en las fichas.

## Estado general
| Proyecto | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|
| PRY-199 | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-200 | Con hallazgos | 0 d | 0 d | 0 |
| PRY-201 | Contradicho | 0 d | 0 d | 0 |
| PRY-202 | Contradicho | 0 d | 0 d | 0 |
| PRY-203 | Contradicho | 85 d | 0 d | 1 |
| PRY-204 | Contradicho | 0 d | 0 d | 0 |
| PRY-205 | Con hallazgos | 0 d | 0 d | 0 |
| PRY-206 | Con hallazgos | 0 d | 0 d | 0 |
| PRY-207 | Contradicho | 0 d | 0 d | 0 |
| PRY-208 | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-209 | Contradicho | 118 d | 0 d | 1 |
| PRY-210 | Con hallazgos | 28 d | 0 d | 1 |
| PRY-211 | Contradicho | 0 d | 0 d | 0 |

## Necesito que confirmes
Este mes no se generaron preguntas de confirmación: la corrida no devolvió campos viejos para confirmar. Sesión sin interfaz, nadie responde.

## Dónde quedó el informe
Carpeta `reportes/` (25 páginas):
- `reportes/index.html`: vista por campo con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html`: vista por decisión. Para el patrocinador: solo lo que excede la facultad de quien gerencia.
- Una página por proyecto (`PRY-199.html` a `PRY-211.html`) y páginas por producto.
- PDF: se obtiene imprimiendo el HTML.

Pie: criterio-portfolio 0.8.0 · fichas del 2026-10-23 · campos inciertos: ninguno marcado como ambiguo; autoridad faltante en los 13 proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
