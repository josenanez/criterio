## Diagnóstico · PRY-204 Tarjeta débito para asociados · 2026-10-23

**Leí:** 7 documentos · del 2026-05-28 al 2026-10-23 · formatos: .docx (2), .md (2), .pdf (2), .xml (1)
**No pude leer:** ninguno. Busqué también menciones del proyecto en los documentos de los otros 12: no hay minutas ajenas que lo nombren. Solo el contrato CT-199 de PRY-199 comparte proveedor (Soluciones Solidarias S.A.S.) y no dice nada de PRY-204.

Términos: vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hizo falta registrarlos otra vez. Las cifras derivadas salen de `portafolio.py compute` con fecha 2026-10-23. Esa salida se apoya en la ficha que dejó el barrido de hoy; cada dato lo contrasté contra el documento original.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 8 · **Contradicho:** 3

El conteo es mío y se enumera abajo; son 15 afirmaciones en total. De esta carpeta se puede afirmar quién es el patrocinador y el gerente, cuánto se aprobó, las fechas comprometidas y que la integración con el core se recibió el 2026-10-15. No se puede afirmar que el proyecto esté en verde. El informe de avance (2026-10-07) dice "Verde" y el contrato y la factura del proveedor lo contradicen. Ninguna de las cifras de dinero tiene un documento que la respalde, solo el propio informe. No hay documento que diga quién autoriza desviaciones.

Sostenidas (4): patrocinador Diana Molina y gerente Sandra Gil (acta); presupuesto aprobado de 9.500.000.000 COP por el Comité de Crédito el 2026-06-06 (acta); inicio 2026-06-16 y cierre 2026-12-21 (acta y cronograma coinciden en el cierre); integración con el core cooperativo recibida a satisfacción el 2026-10-15 (acta de recibo).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Diana Molina | 2026-06-06-acta-constitucion.docx |
| Gerente | Sandra Gil | 2026-06-06-acta-constitucion.docx |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o días | 2026-06-06-acta-constitucion.docx |
| Comité | Comité de Crédito (aprobó el presupuesto). Sin integrantes, cadencia ni reglas de decisión. La minuta del 2026-10-23 lista como asistentes a Sandra Gil y Diana Molina | acta; 2026-10-23-comite-semanal.md |

Sin autoridad declarada no hay desviación aprobada: lo que difiera de la línea base son fechas o cifras que alguien escribió, no cambios autorizados.

### Contra el plan
- **Línea base:** existe una sola, la v1, aprobada el 2026-06-06 con el acta. Cierre 2026-12-21. El cronograma no trae fecha de inicio de línea base; el inicio (2026-06-16) solo está en el acta.
- **Vigente:** igual a la original en los 5 hitos. Replanificaciones: 0. Atraso contra la original y contra la vigente: 0 días. No hay solicitudes de cambio en la carpeta.
- **Pero el cronograma v1 no es de 2026-06-06.** Lleva fecha de junio y trae porcentajes de avance de hitos de julio a octubre (100 %, 100 %, 100 %, 50 %, 50 %). Alguien lo editó después sin versión nueva ni fecha. Esos porcentajes son declaración, no evidencia.
- El hito "Piloto con asociados" (2026-11-13) y "Salida a producción" (2026-12-21) figuran al 50 % sin haber ocurrido el piloto. El informe dice que el Consejo de Administración pidió ajustar el reglamento antes del piloto; eso no aparece como dependencia ni como cambio de plan.
- La integración con el core estaba prevista para 2026-10-06; el acta de recibo es del 2026-10-15. El cronograma sigue mostrando 2026-10-06 y el informe del 2026-10-07 es anterior al recibo.
- **Avance:** declarado 37 %. Con 3 de 5 hitos marcados cumplidos, el plan respalda entre 60 % y 80 %: 23 puntos de diferencia, el reporte por debajo del cronograma. O el informe subestima o el cronograma marca como cumplido lo que no lo está. La carpeta no permite decidir cuál.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-07-23 | 92 | Acta de aprobación del diseño, firmada por patrocinador o comité |
| Ambiente de pruebas certificado | 2026-08-30 | 54 | Certificado o acta de recibo del ambiente de pruebas |

Ambos figuran como cumplidos (100 %) en el cronograma y no hay un solo documento que lo pruebe. El tercer hito cumplido, integración con el core, sí tiene acta de recibo (2026-10-15).

### Dinero
Fuente de todas las cifras salvo el aprobado: el informe del 2026-10-07 (declaración). No hay ningún libro, extracto ni reporte de contabilidad.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 7.487.113.499 (78,8 %) | 5.254.568.526 (55,3 %) | 9.790.767.231 (3,1 % sobre lo aprobado) | 2.012.886.501 |

- La proyección supera lo aprobado en 3,1 %, por debajo del umbral de 10 %. Supera el aprobado y no hay solicitud de cambio ni autoridad que la cubra.
- Ejecutado 55,3 % del presupuesto contra avance declarado de 37 %.
- **Proveedor (CT-222, Soluciones Solidarias S.A.S.):** 2 entregables, 0 aceptados. "Licenciamiento del módulo", comprometido para 2026-08-24, sigue en estado pendiente, 60 días de atraso. "Bolsa de horas de desarrollo" (2026-11-01) está en curso. Cada uno vale 1.064.377.272 COP.
- **Factura FV-1222 (2026-09-10) por 1.064.377.272 COP**, radicada en cuentas por pagar. El contrato exige acta de recibo firmada por el gerente para facturar cada entregable. En la carpeta no hay ningún acta de recibo de un entregable del contrato (la única acta es del hito de integración con el core). Facturado sin entrega aceptada. La factura dice "Entregables del contrato CT-222", sin precisar cuál. El monto coincide con uno solo. No sé si ya se pagó.

### Lo que se dijo y nadie registró
- **Dependencia (el acta dice "Ninguna declarada").** El informe nombra como riesgo abierto la "dependencia del proveedor del core cooperativo", y el informe y la minuta no la tratan como dependencia con dueño ni fecha. Tampoco hay registro RAID.
- **Dependencia del Consejo de Administración:** ajuste del reglamento antes del piloto. No hay documento del Consejo, ni dueño ni fecha, y el piloto es el 2026-11-13.
- **Compromisos de la minuta del 2026-10-23, vencidos sin evidencia:**
  - Jorge Medina, "Entregar el punto 20", para 2026-10-14: 9 días.
  - Elena Duarte, "Entregar el punto 11", para 2026-10-18: 5 días.
  - No se sabe a qué se refieren "punto 20" y "punto 11". Ninguno de los dos figura como asistente. La minuta es del 2026-10-23 y ya trae las dos fechas vencidas: no se sabe si son compromisos nuevos con fecha pasada o arrastrados de una reunión anterior (no hay otra minuta). Temas tratados: "Avance" y "Compromisos", sin contenido.
- **Atraso del proveedor:** el licenciamiento lleva 60 días sin recibo y no aparece como riesgo ni incidencia en ningún documento.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| El proyecto está en **Verde** | Informe de avance 2026-10-07: "Verde" | Contrato CT-222: licenciamiento pendiente con 60 días de atraso; factura FV-1222 de 1.064.377.272 sin acta de recibo; 2 hitos "cumplidos" sin evidencia |
| "Dependencias declaradas: ninguna" | Acta 2026-06-06 | Informe 2026-10-07: riesgo abierto por dependencia del proveedor del core; pide ajuste de reglamento por el Consejo antes del piloto |
| Avance de **37 %** | Informe 2026-10-07 | Cronograma v1: 3 de 5 hitos al 100 % (el plan respalda 60–80 %) |

### Sin sustento
1. Hito "Diseño funcional aprobado" cumplido: sin acta.
2. Hito "Ambiente de pruebas certificado" cumplido: sin certificado ni acta.
3. Avance de 37 %: el informe no dice cómo se calculó.
4. Comprometido 7.487.113.499 COP: sin libro ni soporte.
5. Ejecutado 5.254.568.526 COP: sin libro ni soporte.
6. Proyección al cierre 9.790.767.231 COP: sin supuestos ni soporte.
7. "Se ajustó el plan de pruebas con el área de seguridad": el plan de pruebas no está en la carpeta.
8. "El Consejo de Administración pidió ajustar el reglamento": sin documento del Consejo.

### Lo que esta carpeta no permite saber
- **Quién autoriza qué:** sin autoridad declarada, no se puede decir si la proyección sobre el aprobado, un cambio de fechas o una factura anticipada son decisiones válidas.
- **Si la factura FV-1222 es legítima:** falta el acta de recibo del entregable contractual. Sin ella no se sabe qué se facturó ni si procede pagarla.
- **Qué hito está bien reportado, el cronograma o el informe:** faltan las actas de los dos hitos sin evidencia.
- **Cuánto se gastó de verdad:** falta cualquier soporte contable.
- **Si el piloto del 2026-11-13 es viable:** falta el pronunciamiento del Consejo sobre el reglamento y el plan de pruebas.
- **Qué son "punto 20" y "punto 11":** faltan minutas anteriores o su fuente; sin eso no se sabe qué se debe.
- **Estado del proyecto después del 2026-10-07:** no hay informe más reciente (16 días). Los documentos posteriores son un acta de recibo y la minuta, sin avance.
- **Fase actual:** no está en ningún documento.

### Siguiente paso (ofrecido, no hecho)
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo:
1. Preparar el punto de comité con la lista de lo que falta (autoridad, actas de hitos, acta del contrato, soporte contable).
2. Llevar las 3 contradicciones a la gerente Sandra Gil como preguntas, una por una.

---
*Pie de rigor: 7 documentos leídos; 15 afirmaciones dictaminadas (4 sostenidas, 8 sin sustento, 3 contradichas); cifras derivadas copiadas de `portafolio.py compute`. Cada dato apunta al documento original de la carpeta PRY-204. Es un borrador de trabajo: la verificación es de quien lo recibe.*
