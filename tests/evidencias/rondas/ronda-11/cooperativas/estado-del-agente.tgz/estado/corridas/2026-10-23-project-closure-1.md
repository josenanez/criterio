# Corrida del 2026-10-23 · project-closure

13 proyectos · 68 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Cierre de PRY-200 no sustentable: nadie declaró el fin, informe 2026-10-18 en amarillo 76 %, 3 hitos cerrados sin acta de recibo. No determiné si está en producción, qué se entregó de cada componente ni a qué corresponden los puntos 3 y 20. No archivé la carpeta.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

**Fuentes de este cierre:** ficha `estado/records/PRY-200.json` y los cuatro documentos de la carpeta de PRY-200: acta de constitución (2025-06-20), cronograma v1 (2025-06-20), informe de avance (corte 2026-10-18) y acta del comité semanal (2026-10-23). Las cifras derivadas salen de `portafolio.py compute` con fecha de corte 2026-10-23. Términos vigentes (versión 0.8.0, aceptados por José Francisco Ñáñez el 2026-10-23).

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-23

> **Lo primero:** nadie ha declarado que este proyecto terminó. El último documento de estado (informe del 2026-10-18) lo reporta en **amarillo, con 76 % de avance**, con la prueba de carga repetida y la salida reprogramada. Este documento es el cierre que se puede sustentar hoy, no un acta de cierre firmable. Cerrarlo ahora sería una decisión de la persona que lo cierra, no un cumplimiento verificado.

### Contra lo comprometido
**Criterio de éxito:** "Crédito de libranza digital en producción y medido" (`00-gobierno/2025-06-20-acta-constitucion.md`). El acta no define con qué métrica ni con qué umbral se mide.
**Se cumplió:** **no se puede determinar, y la evidencia disponible apunta a que no.** El informe del 2026-10-18 dice que la prueba de carga no alcanzó el umbral pactado y que la salida se reprogramó por el cierre contable de fin de mes. Ningún documento muestra el crédito en producción ni una medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | No se puede determinar | El acta no lo detalla |
| Componente 2 | No se puede determinar | El acta no lo detalla |
| Componente 3 | No se puede determinar | El acta no lo detalla |
| Hito: Diseño funcional aprobado (línea base 2025-11-09) | Cronograma: "cerrado". **Sin evidencia** (348 días desde su fecha) | Ningún acta de recibo en la carpeta |
| Hito: Ambiente de pruebas certificado (2026-03-22) | Cronograma: "cerrado". **Sin evidencia** (215 días) | Ningún acta de recibo en la carpeta |
| Hito: Integración con el core cooperativo (2026-08-02) | Cronograma: "cerrado". **Sin evidencia** (82 días) | Ningún acta de recibo en la carpeta |

Los tres hitos están "cerrados" solo en el cronograma v1, que es de la fecha del acta (2025-06-20) y por tanto no pudo registrar un cierre real. Es una marca sin respaldo.

El informe declara 76 % de avance con los 3 hitos del plan cerrados. El plan sostiene entre 100 % y 100 %, así que la brecha es de **24,0 puntos**. Esos puntos faltantes no están nombrados en ningún documento.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato. El acta solo dice "lo que otro proyecto cubre". Ningún documento registra un recorte de alcance. | — | — |

Como el acta no detalla los componentes, tampoco se puede probar si el alcance se recortó. Se registra la imposibilidad, no se concluye que no hubo recorte.

### Números finales
Todavía no son finales: el proyecto sigue ejecutando.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-02 | 2026-08-02 | No hay: la salida a producción no tiene nueva fecha en ningún cronograma | 0 días en el cronograma; la fecha ya pasó y no hay cierre |
| Presupuesto aprobado | 1.200.000.000 COP | 1.200.000.000 COP | — | — |
| Comprometido | | 548.775.948 COP (45,7 %) | | |
| Ejecutado | | 524.552.530 COP (43,7 %) | | |
| Proyección al cierre | | 1.227.187.227 COP | | +2,3 % sobre lo aprobado |

Replanificaciones registradas: **0**. La desviación de 0 días no significa que cumplió. Significa que nadie movió la línea base, mientras la salida se reprogramó de hecho y el cronograma no cambió (informe 2026-10-18).

Caja disponible real: 651.224.052 COP. Es cifra del script, calculada contra lo comprometido.

### RAID al cierre
**Materializados:**
- La prueba de carga no alcanzó el umbral pactado y se repite (incidencia, desde 2026-10-18, sin responsable).
- Reprogramación de la salida por el cierre contable de fin de mes (incidencia, desde 2026-10-18, sin responsable y sin nueva fecha).

**No materializados:** ninguno puede afirmarse. Ambos riesgos del informe siguen abiertos.

**Abiertos, con doliente:** **ninguno tiene doliente con nombre**, así que por la regla del cierre no están cerrados.
| Qué | Doliente |
|---|---|
| Concentración del conocimiento en una sola persona (riesgo) | Sin doliente |
| El proveedor no ha confirmado la fecha de la última entrega (riesgo). La ficha no registra ningún proveedor ni contrato | Sin doliente |
| Prueba de carga por repetir (incidencia) | Sin doliente |
| Salida reprogramada sin fecha (incidencia) | Sin doliente |
| Compromiso: Sandra Gil, "Entregar el punto 3", vencido el 2026-10-10, **13 días** de atraso (comité 2026-10-23) | Sandra Gil |
| Compromiso: Andrés Lozano, "Entregar el punto 20", para el 2026-11-04 | Andrés Lozano |

Los dos compromisos son solo referencias numéricas ("punto 3", "punto 20"). El acta del comité no dice a qué corresponden.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El criterio de éxito del acta ("en producción y medido") no trae métrica ni umbral. Los alcances son "Componente 1, 2 y 3" sin detalle. | Acta, 2025-06-20 | Hoy no se puede determinar qué se entregó ni si se cumplió. | Exigir en el acta una métrica con umbral y un alcance detallado antes de aprobarla. |
| Los 3 hitos figuran "cerrados" sin acta de recibo en la carpeta. | Cronograma v1 (2025-06-20) contra el estado a 2026-10-23 | El avance declarado (76 %) no se puede contrastar con nada. La brecha con el plan es de 24,0 puntos. | No aceptar un hito como cerrado sin el acta de recibo en la carpeta del proyecto. |
| La salida a producción se reprogramó de hecho y el cronograma sigue siendo el v1 sin replanificaciones. | Informe 2026-10-18 | El plan no refleja la realidad. La fecha de cierre del 2026-08-02 pasó y nadie la movió formalmente. | Pasar por control de cambios toda reprogramación, con línea base nueva. |

Efecto cuantificado: sin dato en los tres casos. Los documentos no dan días ni montos atribuibles.

### Sin dato
- Si el crédito está en producción y si hay alguna medición del criterio de éxito.
- Qué se entregó de cada componente.
- Quién aprobó el cierre de cada hito, y cuándo.
- A qué se refieren los puntos 3 y 20 del comité.
- Si el "proveedor" del riesgo existe como contrato. La ficha no tiene proveedores.
- Autoridad de aprobación y fase del proyecto (campos no encontrados en la ficha).
- Antigüedad: todos los datos de identidad, plan y presupuesto aprobado vienen del acta de hace 16 meses. Ningún campo está respaldado como evidencia: 15 sin marcar, 0 de evidencia y 0 declaraciones, según el script.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha. El proyecto no está declarado terminado. Mover la carpeta lo sacaría del barrido diario con cuatro incidencias y riesgos abiertos y sin doliente. Cuando alguien declare el cierre, o decida cerrarlo por decisión y no por cumplimiento, se puede archivar.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados y la verificación es de quien lo usa. Criterio no sabe lo que se habló fuera de ellos.*
