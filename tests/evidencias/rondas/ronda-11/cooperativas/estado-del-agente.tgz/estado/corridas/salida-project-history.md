## Historia · PRY-203 Aportes sociales en línea · 2026-02-04 a 2026-10-22

**Leí:** 7 documentos entre 2026-02-04 y 2026-10-22 (acta de constitución, contrato CT-989, cronograma v1, cronograma v2, solicitud de cambio CC-01, informe de avance, minuta del comité del 2026-10-13).
**Trimestres sin un solo documento:** 2026 T2 (abr–jun) y 2026 T3 (jul–sep). Hay documentos en T1 (4 y 10 de febrero) y en T4 (13, 21 y 22 de octubre). Nada ocurre en los siete meses entre el contrato y la minuta de octubre.

**Términos:** vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Comprobante ya registrado; no se volvió a generar.

### En una línea
El proyecto nace el 2026-02-04 con cierre al 2027-02-16 y 3.300.000.000 COP. Los dos meses siguientes dejan solo el contrato con Talento Solidario (2026-02-10). Después no hay documentos hasta octubre. El 2026-10-21 se pide el cambio CC-01 (+85 días, +170.000.000 COP) y el 2026-10-22 hay un cronograma v2 con cierre al 2027-05-12 y un informe de avance que declara **verde, 65 %**. Esa historia sale de siete documentos, con un hueco de siete meses y sin ninguna evidencia de recibo de hitos ni de entregables.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 85 días (23,2 %) | No calculable: hay una sola declaración (2026-10-22) | 0 documentados |

Las tres primeras salen de `portafolio.py compute`. "Meses declarando sin sustento" no se puede calcular porque la carpeta no tiene una serie de estados declarados, solo uno.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-02-04 | Acta de constitución (.docx) | Se aprueba el proyecto: patrocinadora Sandra Gil, gerente Rubén Cárdenas, Comité de Tecnología. Presupuesto 3.300.000.000 COP, inicio 2026-02-14, cierre 2027-02-16. Dependencias: "ninguna declarada". |
| 2026-02-04 | Cronograma v1 (.xlsx) | Línea base original: 5 hitos, salida a producción 2027-02-16. Ver la nota sobre este archivo abajo. |
| 2026-02-10 | Contrato CT-989 (.md) | Talento Solidario Ltda.: tres entregables de 395.187.394 COP, con fechas 2026-05-26, 2026-09-04 y 2026-12-14. Se factura contra acta de recibo firmada por el gerente. |
| 2026-10-13 | Minuta del Comité de Tecnología (.docx) | Asisten Rubén Cárdenas y Sandra Gil. Temas: "Avance" y "Compromisos", sin contenido para "Avance". Un compromiso: Camilo Beltrán, "Entregar el punto 4", para 2026-11-13. |
| 2026-10-21 | Solicitud de cambio CC-01 (.md) | Ampliación de alcance sin detalle: +85 días sobre la línea base vigente y +170.000.000 COP. Dice "Autorizada por el comité" sin nombrar cuál ni quién firma. |
| 2026-10-22 | Cronograma v2 (.xml) | Línea base v2: salida a producción pasa de 2027-02-16 a 2027-05-12. Los otros cuatro hitos no se mueven. |
| 2026-10-22 | Informe de avance (.pdf) | Gerente declara verde y 65 %. Reporta 3.300.000.000 aprobado, 2.771.948.711 comprometido, 608.518.136 ejecutado, proyección 3.263.594.053. Riesgo: concentración del conocimiento en una persona. Incidencia: el Consejo de Administración pidió ajustar el reglamento antes del piloto. |

**Nota sobre el cronograma v1.** Su nombre lleva fecha 2026-02-04, pero ya marca como "cerrado" los hitos del 2026-04-28, 2026-07-10 y 2026-09-22. O el archivo se editó después de esa fecha, o la fecha del nombre no es la del contenido. Lo ubiqué en 2026-02-04 por su nombre y no sé cuándo se modificó. Es el único registro de la línea base original.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-22 | 2027-05-12 | CC-01: ampliación de alcance, sin detalle de qué se amplía | CC-01 dice "Autorizada por el comité". No hay minuta ni acta que lo respalde: la única minuta (2026-10-13) es anterior a la solicitud y no la menciona. |

Atraso acumulado contra la línea base original (2027-02-16): 85 días, 23,2 %. Contra la vigente: 0 días. El cambio aprobado mueve la línea base exactamente 85 días, sin días no autorizados.

El informe del 2026-10-22 sigue mostrando 3.300.000.000 COP como aprobado, no 3.470.000.000. Si CC-01 aumentó el presupuesto en 170.000.000 COP, esa suma no figura aún en el informe.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité documentado. Sandra Gil y Rubén Cárdenas aparecen igual en el acta (2026-02-04), la minuta (2026-10-13) y el informe (2026-10-22). | — |

Lo que no se puede saber: qué comité autorizó CC-01 y quién lo firmó. El acta nombra al Comité de Tecnología, pero CC-01 solo dice "el comité". Esa omisión no es un cambio de gobierno, pero deja sin sustento la autorización de la única replanificación.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió. Hay un solo compromiso (Camilo Beltrán, "Entregar el punto 4", dicho el 2026-10-13, para 2026-11-13), todavía no vencido. | 1 | 2026-11-13 |

Con una sola minuta no se puede ver una repetición. Tampoco se puede decir qué es el "punto 4": el documento no lo define.

### Desde cuándo lo declarado no se sostiene
No se puede fechar como deslizamiento: la carpeta tiene **una sola declaración de estado** (2026-10-22, verde, 65 %), así que no hay serie que recorrer.

Lo que sí se ve en esa declaración:
- **Primer hito sin evidencia:** "Diseño funcional aprobado", fecha 2026-04-28, marcado como cumplido. Lleva 178 días sin ningún documento de respaldo.
- Siguen "Ambiente de pruebas certificado" (2026-07-10, 105 días sin evidencia) e "Integración con el core cooperativo" (2026-09-22, 31 días sin evidencia).
- **Qué se reporta encima:** verde y 65 %. El avance entra en el rango que el cronograma soporta (60–80 %), pero ese rango cuenta como cumplidos tres hitos que no tienen documento de respaldo.
- Dos entregables de Talento Solidario están pendientes, sin acta de recibo: licenciamiento (vencido el 2026-05-26, 150 días) y bolsa de horas (vencida el 2026-09-04, 49 días). El informe no los menciona. El contrato no dice cuánto se facturó y la carpeta tampoco.
- El informe declara verde con 85 días de atraso contra la línea base original.

Entre el 2026-02-10 y el 2026-10-13 no hay un solo documento. No sé qué se declaró en esos meses ni a quién.

### Lecciones ancladas a un hecho
1. **Una replanificación sin acta que la respalde.** Hecho: CC-01 (2026-10-21) dice "Autorizada por el comité" y la línea base v2 aparece al día siguiente (2026-10-22); la única minuta es del 2026-10-13. Efecto: la fecha de cierre se movió 85 días y la autorización no se puede comprobar con documentos.
2. **Hitos cerrados sin evidencia.** Hecho: tres hitos (2026-04-28, 2026-07-10, 2026-09-22) figuran como cumplidos en el cronograma v2 sin acta ni entregable que los sustente. Efecto: el 65 % y el verde del 2026-10-22 descansan sobre ellos.
3. **Un cronograma base sin fecha confiable.** Hecho: el v1 lleva fecha 2026-02-04 y ya trae hitos posteriores como cerrados. Efecto: no se puede reconstruir cuándo se cerró cada hito, y la línea base original no tiene una fecha de modificación fiable.

### Qué no sé
- Cuándo se supo del atraso: no hay documentos entre el 2026-02-10 y el 2026-10-13.
- Qué comité autorizó CC-01, qué amplía y si el presupuesto cambió.
- Si hubo actas de recibo de los hitos o de los entregables de Talento Solidario fuera de esta carpeta.
- Qué es el "punto 4" del compromiso de Camilo Beltrán.

Esta historia no atribuye intención: que no haya documentos en siete meses no dice que alguien los haya evitado. Sirve para tener esa conversación con datos. Si de aquí sale una decisión, puedo llevarla al comité; y si el proyecto se cierra, a su cierre.

**Pie de rigor:** 7 documentos leídos, todos de la carpeta del proyecto. Las cifras derivadas (replanificaciones, 85 días, 23,2 %, días sin evidencia) vienen de `portafolio.py compute` con fecha de corte 2026-10-23. Borrador de trabajo, no decisión: verifica cada dato contra el documento citado.
