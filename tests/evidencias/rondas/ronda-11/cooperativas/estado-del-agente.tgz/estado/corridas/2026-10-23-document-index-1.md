# Corrida del 2026-10-23 · document-index

13 proyectos · 16 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

79 documentos, todos sin cambio; 0 por releer, 0 citas rotas. No se leyó ningún documento.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-23: 79 documentos, los 79 sin cambio. Nada que releer y ninguna cita rota.
