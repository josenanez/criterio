# Corrida del 2026-10-23 · project-charter

13 proyectos · 45 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Revisión del acta 2025-08-12: sin autoridad del gerente, objetivo = solución, alcance y exclusiones con marcador de posición, criterio de éxito sin métrica ni quién mide, sin supuestos/hitos/cadencia, dependencias 'ninguna' contradichas por el informe del 2026-10-20. No sé si hay versiones posteriores o delegaciones fuera de la carpeta.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Términos: vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-23); no hubo que volver a pedirlos.

**Acta previa:** existe, del 2025-08-12 (aprobada por el Comité de Educación). Es el único documento de gobierno de PRY-208; no hay revisión anterior de esta acta hecha por el agente.

## Acta — PRY-208 Motor de crédito
**Estado:** existe, del 2025-08-12

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Jorge Medina sin comité. | Nada de lo que pase en el proyecto tiene un umbral que lo resuelva abajo: el ajuste de reglamento que pidió el Consejo (informe del 2026-10-20) y el posible cambio normativo del supervisor llegan al comité por defecto, o se deciden sin que nadie pueda decir si el gerente tenía facultad. |
| Objetivo de negocio | Presente pero es la solución: «Entregar motor de crédito para Servicio al asociado». | No dice qué resultado de negocio se busca (tiempo de respuesta, cartera, riesgo). Sin eso no se puede juzgar si un cambio de alcance sigue sirviendo al fin, y «entregado» y «útil» se vuelven lo mismo. |
| Alcance | Marcador de posición: «Componente 1, 2, 3». | No hay qué contar como dentro ni fuera. El 79% reportado no se puede contrastar contra nada porque los componentes no tienen nombre ni contenido. |
| Exclusiones | Marcador de posición: «Lo que otro proyecto cubre». | No nombra el proyecto ni lo excluido. Cualquier solicitud de cambio puede alegar estar dentro o fuera con igual derecho; es la puerta del crecimiento de alcance. |
| Criterio de éxito | Parcial: «Motor de crédito en producción y medido». | Sin métrica, sin umbral y sin quién mide. «Medido» no puede incumplirse, así que el cierre no tiene contra qué evaluarse. |
| Supuestos y restricciones | **No están.** | El cambio normativo y el ajuste de reglamento que hoy aparecen como riesgo e incidencia no tienen un supuesto de origen contra el cual compararse. |
| Dependencias | Declaradas: «Ninguna». | Contradice el informe del 2026-10-20: el Consejo de Administración condiciona el piloto a un ajuste del reglamento, y hay un riesgo regulatorio. Sí hay dependencias externas y el acta dice que no. |
| Hitos | **No están** (la ficha lo registra: no hay cronograma). | Solo hay fecha de inicio y de cierre; no existe punto intermedio donde el atraso se hubiera visto antes del cierre. |
| Cadencia de reporte al comité | **No está.** | Nadie está obligado a ver el proyecto en una fecha; el silencio no incumple nada. |
| Patrocinador / Gerente | Con nombre de persona: Camilo Beltrán / Jorge Medina. | Cubierto. |
| Comité | Comité de Educación. | Dato a confirmar, no conclusión: un comité de ese nombre aprobó 18.000 millones COP para un motor de crédito. El acta no explica por qué ese comité tiene competencia; si no la tiene, la aprobación del presupuesto es discutible. |
| Presupuesto y fechas | Presentes (18.000.000.000 COP; 2025-08-22 a 2026-03-17). | Cubierto. Pero la fecha de cierre pactada venció hace más de siete meses y el informe del 2026-10-20 sigue en rojo, al 79%, sin ninguna línea base nueva en los documentos: el acta quedó describiendo un proyecto que ya no es el que corre. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice «Entregar motor de crédito para Servicio al asociado» (acta, sección Objetivo del negocio).
**Alcance:** pendiente de definir. El acta solo lista «Componente 1, 2, 3» (acta, sección Alcance).
**Exclusiones:** pendiente de definir. El acta dice «Lo que otro proyecto cubre» sin nombrar el proyecto (acta, sección Fuera de alcance).
**Patrocinador:** Camilo Beltrán · **Gerente:** Jorge Medina (acta, encabezado).
**Autoridad del gerente:** pendiente de definir: hasta [monto] y [qué cambios] sin comité. No figura en ningún documento.
**Comité al que reporta:** Comité de Educación (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «Motor de crédito en producción y medido» (acta); falta métrica y umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir; solo inicio 2025-08-22 y cierre 2026-03-17 (acta). Presupuesto aprobado: 18.000.000.000 COP el 2025-08-12 (acta).

Lo que no sé: si existe una versión posterior del acta, una delegación de autoridad o una aprobación de cambio de fechas fuera de esta carpeta; solo hay dos documentos de PRY-208 (el acta y el informe del 2026-10-20). Qué hay detrás de «Componente 1, 2, 3» y quién es «otro proyecto».

### Después
- El acta quedó **sin autoridad declarada**: ofrezco llevar esa definición al próximo comité (2026-10-30). Es una decisión de gobierno, no un trámite.
- De la revisión salen dos supuestos implícitos para el registro RAID: que no habría cambio normativo del supervisor, y que el reglamento no exigiría ajuste antes del piloto. Ofrezco pasarlos a `/raid-log PRY-208`.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Sale solo del acta del 2025-08-12 y del informe de avance del 2026-10-20; no sé lo que se haya hablado fuera de esos documentos. La verificación de cada dato es de quien lo use, con la cita que lo acompaña.
