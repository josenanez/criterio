Informe construido desde la ficha `estado/records/PRY-207.json` (actualizada el 2026-10-23) y el cálculo de `compute` con corte 2026-10-23.

## PRY-207 · Microcrédito rural — estado al 2026-10-23

**Declara el gerente:** verde · 32% · al 2026-10-07 (Sandra Gil; `PRY-207-microcrédito-rural/20-seguimiento/2026-10-07-informe-avance.md`). La declaración tiene 16 días, dentro del límite de 30, así que no está vencida.
**Sustento documental:** sin sustento. De la ficha, 15 datos no tienen marca de origen (`unmarked`) y ninguno cuenta como evidencia. Los dos documentos del proyecto son el acta de constitución y el propio informe de avance. No hay cronograma, actas de reunión ni entregables que respalden el 32%.
**Lo que el semáforo no explica:** `silent`. El proyecto lleva 16 días sin documentos nuevos, y el umbral es 15. El script levanta la alerta `declared_vs_evidence`: se reporta verde y hay una señal que ese verde no cubre.
**Último documento:** 2026-10-07 · **Última reunión:** sin dato. No hay actas ni transcripciones de reunión en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-07-17 | 2026-07-17 | 0 días (el script no registra replanificaciones) |
| Presupuesto aprobado | COP 2.400.000.000 | COP 2.400.000.000 | sin cambio |
| Proyección al cierre | — | COP 2.315.758.298 | −3,5% sobre lo aprobado |

Replanificaciones: 0. No hay solicitudes de cambio registradas.

**Lo que esta tabla no dice.** La fecha de cierre vigente, 2026-07-17, es anterior al corte de este informe, y el proyecto declara 32% de avance. El script no marca atraso porque ninguna replanificación movió la fecha. Tampoco calcula los días transcurridos desde esa fecha, por eso no escribo la cifra. El gerente no ha declarado una fecha nueva ni se ha aprobado ningún cambio de línea base. Un "0 días de desviación" aquí significa que nadie ha reconocido el atraso, no que no exista.

**Dinero.** Ejecutado: COP 534.713.444 (22,3% del aprobado). Comprometido: COP 1.491.363.645 (62,1%). Disponible real: COP 908.636.355. Todas las cifras de dinero vienen del informe de avance, o sea que son declaradas, no verificadas con facturas ni contratos.

### Hitos
Sin dato. La ficha no tiene hitos (`plan.milestones`: no hay cronograma). Sin hitos no se puede comparar el 32% con lo que el plan exigía a esta fecha.

### Dónde no coincide
- El informe dice **verde / 32%** (2026-10-07). El acta de constitución (2026-01-01) fija el cierre para el **2026-07-17**, que ya pasó. Ningún documento explica cómo un proyecto vencido en fechas está en verde.
- Hay 16 días de silencio documental desde ese informe.
- El único avance del periodo que cuenta el informe es «se ajustó el plan de pruebas con el área de seguridad». Eso no respalda un 32% de avance.

### Abierto
**Riesgos e incidencias sin movimiento:** el riesgo «Aprobación del reglamento por el Consejo de Administración» aparece en el informe sin probabilidad, impacto, responsable, fecha ni último movimiento. No se puede decir cuántos días lleva sin moverse porque no tiene fecha de alta.
**Compromisos vencidos:** ninguno registrado (no hay actas de reunión de las que extraerlos).
**Dependencias sin confirmar:** ninguna registrada. Las exclusiones del acta («lo que otro proyecto cubre») no nombran ese proyecto.

### Sin dato
- Autoridad que aprueba (`identity.authority`).
- Fase del proyecto (`identity.phase`).
- Hitos y cronograma.
- Última reunión.
- Responsable, probabilidad, impacto y fecha del único riesgo.
- Detalle de los componentes 1, 2 y 3 del alcance: el acta no los describe.

### Siguiente paso
Una fecha de cierre ya pasada, un verde sin sustento y 16 días sin documentos justifican llevar PRY-207 al comité del 2026-10-30. Puedo preparar el punto de comité con `/steering-pack`. También puedo armar una solicitud de cambio si el gerente va a reconocer un nuevo plazo.

---
Criterio · criterio-portfolio 0.8.0 · ficha PRY-207 aplicada, actualizada el 2026-10-23, con corte 2026-10-23 · campos inciertos: autoridad, fase, hitos, última reunión, datos del riesgo · Términos v1.2 aceptados por José Francisco Ñáñez el 2026-10-23: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
