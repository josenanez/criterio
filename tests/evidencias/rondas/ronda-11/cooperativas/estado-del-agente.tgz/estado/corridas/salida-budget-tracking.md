Fuente: ficha `estado/records/PRY-211.json` y `portafolio.py compute`, calculado al 2026-10-23. Documentos de origen: acta de constitución (2025-06-24) e informe de avance (2026-10-19).

## Presupuesto — PRY-211 Cobranza digital al 2026-10-23
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 4.200.000.000 | 100 | 00-gobierno/2025-06-24-acta-constitucion.docx | 2025-06-24 |
| Comprometido | 3.403.064.146 | 81.0 | 20-seguimiento/2026-10-19-informe-avance.pdf | 2026-10-19 |
| Ejecutado | 1.718.932.257 | 40.9 | 20-seguimiento/2026-10-19-informe-avance.pdf | 2026-10-19 |
| Proyección al cierre | 5.280.911.293 | 125.7 | 20-seguimiento/2026-10-19-informe-avance.pdf | 2026-10-19 |

**Disponible real** (aprobado menos comprometido): 796.935.854 COP

La proyección es una declaración del informe de avance, no un dato medido. Es posterior al aprobado y no hay ningún movimiento de presupuesto registrado después, así que no está desactualizada frente a él.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 4.200.000.000 | 4.200.000.000 | 0 |
| Proyección frente al aprobado | 4.200.000.000 | 4.200.000.000 | +25.7 % |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas (0 cambios en la ficha).
La línea base registrada (v1, 2025-06-24) solo trae fechas; el presupuesto vigente es el del acta.

### Ejecución frente a avance
Ejecutado 40.9 % · Hitos cumplidos 3 de 3 · Avance declarado 37 %, mientras el plan sostiene 100 % (brecha de 63.0 puntos, hacia atrás).
Lectura: el gasto es coherente con el avance declarado, pero no con el plan. El plan terminaba el 2026-03-07, hace 230 días, y marca los 3 hitos como cumplidos sin ninguna evidencia de cumplimiento. O los hitos no se cumplieron, o el avance declarado está mal. Los documentos no permiten decidir cuál.

### Alertas
- **Proyección por encima del aprobado: 25.7 %**, con umbral de 10 % (variance_cost). El informe de avance del 2026-10-19 declara estado **verde** sin explicar esta señal, ni las otras dos de este informe.
- **Comprometido 81.0 %**: por debajo del umbral de 90 %, no hay alerta de comprometido. Pero la holgura real es 796.935.854 COP (19.0 % del aprobado), no el 59.1 % que sugeriría mirar solo lo ejecutado, y la proyección dice que no alcanza.
- **Ejecución frente a avance**: señal `progress_vs_plan` abierta (brecha de 63.0 puntos) y 3 hitos cumplidos sin evidencia (`milestone_met_without_evidence`: 394, 312 y 230 días).
- **Aprobado con 16 meses de antigüedad** (acta del 2025-06-24), por encima del umbral de 12 meses. Nadie lo ha reconfirmado.

### Sin dato
- Presupuesto vigente distinto del original: ningún documento lo declara; se asume igual solo porque no hay cambios registrados.
- Detalle por proveedor: la ficha no tiene proveedores ni contratos para este proyecto.
- Autoridad que aprobó el presupuesto (`identity.authority`) y fase (`identity.phase`): no están en ningún documento.
- Los montos comprometido, ejecutado y proyección provienen del mismo informe y ninguna fuente de evidencia los respalda de forma independiente (0 fuentes de evidencia, 15 sin marcar).

### Después
La proyección excede el aprobado: queda ofrecida la preparación de la solicitud de cambio (`/criterio-portfolio:change-control`). No se prepara sin que la pidan. No se ofrece detalle por proveedor porque no hay datos.

*Pie de rigor: borrador de trabajo hecho solo con los documentos indicados; no sabe lo que se habló fuera de ellos. Cada cifra sale de `compute` y de la ficha; verifíquela contra la cita antes de usarla.*
