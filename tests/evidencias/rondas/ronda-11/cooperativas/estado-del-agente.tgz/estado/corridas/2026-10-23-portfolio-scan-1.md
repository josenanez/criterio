# Corrida del 2026-10-23 · portfolio-scan

13 proyectos · 79 documentos, 0 releídos y 79 sin cambio · 358 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

10 fichas nuevas de 61 documentos leídos; 18 sin cambio (PRY-204, 205, 209 intactas). Nada que mover desde entrada/ (no existe). Mirar: PRY-210 línea base v2 sin CC-01 aprobada; PRY-203 CT-989 con 2 entregables vencidos; PRY-206 compromisos vencidos y reprogramados; hitos cerrados sin acta; PRY-207 en silencio. Los 8 .xml figuran como no legibles en el inventario pero se leyeron.

Contra la corrida del 2026-10-23: +49 hallazgos.

## Lo que produjo

## Barrido — 2026-10-23

Encontré 79 documentos en `documentos/proyectos` (13 carpetas de proyecto). Términos vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-23). Ejecuté el plan de lectura tal cual: 1 lote de 10 proyectos, uno tras otro, sin subagentes.

**Documentos:** 79 en la carpeta · 61 leídos · 18 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Formatos: 37 .md, 13 .docx, 13 .pdf, 8 .xml, 5 .xlsx, 1 .csv, 1 .json, 1 .txt. Se leyeron por su texto convertido; las citas van a los originales.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan (5 hitos), presupuesto, contrato CT-199, 2 riesgos, 1 compromiso | autoridad, fase, facturado de CT-199 |
| PRY-200 Crédito de libranza digital | 4 | identidad, plan (3 hitos), presupuesto, 2 riesgos, 2 incidencias, 2 compromisos | autoridad, fase |
| PRY-201 Apertura de ahorro en línea | 8 | identidad, plan (5 hitos), presupuesto, contrato CT-967 con factura, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase |
| PRY-202 Core cooperativo | 4 | identidad, plan (3 hitos), presupuesto, 2 riesgos, 1 incidencia, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-203 Aportes sociales en línea | 7 | identidad, 2 líneas base, plan (5 hitos), presupuesto, contrato CT-989, CC-01, 1 compromiso | autoridad, fase, facturado de CT-989 |
| PRY-206 Pagos con QR | 17 | identidad, plan (3 hitos), presupuesto, 3 riesgos (1 no registrado), 1 incidencia, 26 compromisos; `ficha-pm.json` guardada entera en `pm_record` | autoridad, fase, fecha de inicio de la incidencia |
| PRY-207 Microcrédito rural | 2 | identidad, presupuesto, 1 riesgo | autoridad, fase, hitos (no hay cronograma) |
| PRY-208 Motor de crédito | 2 | identidad, presupuesto, 1 riesgo, 1 incidencia | producto («No aplica»), autoridad, fase, hitos (no hay cronograma) |
| PRY-210 Corresponsales rurales | 7 | identidad, 2 líneas base, plan (4 hitos), presupuesto, CC-01, 2 riesgos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 4 | identidad, plan (3 hitos), presupuesto, 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-204, PRY-205, PRY-209 | Nada: los 18 documentos tienen el mismo hash de la corrida anterior. No se abrieron. | `estado/records/` |

### Lo que hay que mirar
- **PRY-210:** el cronograma v2 (2026-10-12) ya mueve el piloto 28 días, y la solicitud CC-01 (2026-10-13) dice «pendiente de presentación al comité». La línea base v2 quedó registrada con la fecha del cronograma, no con una aprobación; el código la marca como `rebaseline_unauthorized`.
- **PRY-203:** CC-01 figura «autorizada por el comité» (sin decir cuál ni quién firma) y mueve la salida de 2027-02-16 a 2027-05-12. El contrato CT-989 tiene dos entregables con fecha vencida (2026-05-26 y 2026-09-04) y sin acta de recibo.
- **PRY-206:** 4 compromisos vencidos, 5 sin fecha y 4 reprogramados; el de «Enviar el documento 1» se movió 6 veces (de 2026-09-21 a 2026-12-14). Cinco compromisos se dieron por entregados de palabra en reunión y ninguno tiene acta, así que no se cerraron. Un riesgo dicho en la reunión del 2026-10-23 (el proveedor podría no llegar con el equipo completo) no estaba registrado; quedó levantado como no registrado. El cronograma lo da todo por cerrado en 2025, pero el informe declara 79 % y amarillo. La ficha del gerente y mi lectura no discrepan en los campos que se contrastan.
- **Hitos declarados cerrados sin acta de recibo:** PRY-200, PRY-202, PRY-203, PRY-206, PRY-210 y PRY-211, entre otros. Se registraron como `met` con la evidencia vacía; es la señal `milestone_met_without_evidence`, no un atraso.
- **PRY-207:** sin documentos desde el 2026-10-07 (señal `silent`), y su cierre comprometido, 2026-07-17, ya pasó con 32 % de avance declarado.
- **PRY-211:** la proyección al cierre supera el aprobado (`variance_cost`). **PRY-200 y PRY-211** informan que se reprogramó la salida sin que ningún cronograma tenga la fecha nueva.
- **PRY-201:** hay una factura de CT-967 por 1.574.919.460 COP (2026-09-27) y un acta de recibo del licenciamiento (2026-09-13) por el mismo monto; la factura dice «Entregables del contrato» sin nombrar cuál.

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | El inventario marcó como «no legibles sin instalar algo» 8 cronogramas .xml de Microsoft Project, pero `texto.py` los convirtió todos y los leí. Lo dejo dicho porque la marca del inventario no coincide con lo ocurrido. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | — | No existe carpeta `entrada/` ni archivos sueltos fuera de las carpetas de proyecto. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

## Después

Hay más de un proyecto, así que puedo producir el informe consolidado con `/criterio-portfolio:portfolio-report`. Las contradicciones y los compromisos vencidos ya están dichos arriba.

---
Criterio Portfolio 0.8.0 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 206, 207, 208, 210, 211) · campos en `not_found`: 28 (autoridad ×10, fase ×10, producto ×3, facturado ×2, hitos ×2, inicio de incidencia ×1) · Criterio produce borradores de trabajo; la verificación es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
