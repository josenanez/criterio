*Fichas cargadas: las 13 de `estado/records/` (PRY-199 a PRY-211), con cifras recalculadas hoy, 2026-10-23, con `portafolio.py compute`. Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-23; no hubo que registrarlos de nuevo.*

# Comité de proyectos — 2026-10-30 (próximo según la configuración; datos al 2026-10-23)
7 decisiones · 7 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (67 señales)

**Lo primero.** Ninguna de las 13 fichas tiene autoridad de aprobación declarada (`identity.authority` no encontrado en 13 de 13). Las actas nombran cuerpos distintos: Comité de Tecnología (PRY-201, 202, 203, 207, 209, 210), Consejo de Administración (PRY-199, 200, 211), Comité de Riesgos (PRY-205, 206), Comité de Crédito (PRY-204) y Comité de Educación (PRY-208). Ninguna fija umbrales de cambio. Por eso la decisión 1 es sobre quién decide, y las decisiones 2 a 7 se dirigen al cuerpo que nombra el acta de cada proyecto, a confirmar.

## Decisiones del comité anterior
No hay acta de un comité de dirección anterior en los documentos, así que no puedo cerrar ese ciclo. Lo único que lo roza:

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| CC-01 de PRY-203 «Autorizada por el comité» | sin fecha | El documento no dice qué comité, qué día ni quién firma. El cronograma v2 se publicó el 2026-10-22 con +85 días. | Sin sustento verificable (ver decisión 4) |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base y presupuesto en este portafolio, y con qué umbrales?
**Proyecto:** los 13 · **Quién decide:** no se puede determinar; es el hallazgo de fondo · **Si no se decide hoy:** las decisiones 2 a 7 se toman sin que conste que quien las toma puede hacerlo. PRY-203, 209 y 210 ya movieron su línea base y ninguno puede probar quién lo autorizó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada acta se completa con el cuerpo que ya nombra y un umbral por tamaño de cambio | Sin cambio | Una revisión de actas por proyecto; el tiempo que toma no consta en ningún documento | Sin cambio |
| B. Un solo cuerpo de portafolio aprueba todos los cambios | Sin cambio | Más rápido de operar; exige modificar las 13 actas | Sin cambio |
| C. Seguir sin autoridad declarada | Sin cambio | Sin cambio | Cada cambio queda sin respaldo |

**Recomendación:** A. Las actas ya nombran un cuerpo; falta que fijen qué le toca decidir. Es lo más barato y no desplaza a nadie. El umbral lo propone el comité; yo no lo invento.

### [2] ¿Se aprueba el CC-01 de PRY-209 (+118 días, +236.000.000 COP) o se devuelve la línea base a la original?
**Proyecto:** PRY-209 Convenios de libranza con empresas (gerente Liliana Torres) · **Quién decide:** Comité de Tecnología según el acta, a confirmar con la decisión 1 · **Si no se decide hoy:** la línea base ya se movió 118 días sin autorización (fin vigente 2027-03-05, desviación 23,8 % contra la original) y la solicitud sigue «Pendiente de presentación al comité».

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar tal cual | «Ampliación de alcance», sin detalle | +118 días | +236.000.000 COP |
| B. Rechazar y volver a la línea base original | Sin ampliación | 0 días sobre la original | Sin adicional |
| C. Devolver hasta que el alcance se detalle y haya evidencia de hitos | Pendiente | Pendiente | Pendiente |

**Recomendación:** C. Se pide ampliar un alcance que nadie describe, sobre un proyecto declarado verde con 35 % de avance cuando el plan sustenta entre 80 y 100 %, y con 3 hitos dados por cumplidos sin acta de recibo.

### [3] ¿Se aprueba el CC-01 de PRY-210 (+28 días, +56.000.000 COP)?
**Proyecto:** PRY-210 Corresponsales rurales (gerente Camilo Beltrán) · **Quién decide:** Comité de Tecnología según el acta, a confirmar · **Si no se decide hoy:** la línea base ya se movió 28 días sin autorización (desviación 6,8 %). El fin vigente es 2026-10-13, ya vencido. El hito «Piloto con asociados» figura cumplido sin evidencia.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar tal cual | «Ampliación de alcance», sin detalle | +28 días | +56.000.000 COP |
| B. Rechazar y volver a la original | Sin ampliación | Fin original vencido sin justificarlo | Sin adicional |
| C. Devolver hasta tener acta de recibo del piloto y alcance descrito | Pendiente | Pendiente | Pendiente |

**Recomendación:** C. Sin evidencia del piloto no se sabe si el cambio extiende un proyecto que avanza o legaliza uno que ya se pasó de fecha. La proyección es 7.125.458.903 COP contra 6.800.000.000 aprobados, +4,8 %.

### [4] ¿Se ratifica el CC-01 de PRY-203 (+85 días, +170.000.000 COP), que dice estar autorizado por «el comité»?
**Proyecto:** PRY-203 Aportes sociales en línea (gerente Rubén Cárdenas) · **Quién decide:** el cuerpo que lo autorizó, que el documento no nombra; Comité de Tecnología según el acta · **Si no se decide hoy:** el cronograma v2 (fin 2027-05-12, +23,2 % sobre la original) rige sin un acta que lo respalde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar y registrar en acta con cuerpo, fecha y firma | «Ampliación de alcance», sin detalle | +85 días | +170.000.000 COP |
| B. No reconocerlo hasta que exista acta | Sin ampliación | Vuelve a la línea base original | Sin adicional |

**Recomendación:** A si el Comité de Tecnología confirma que lo autorizó; si no lo hizo, B. Antes hay que pedir al proveedor Talento Solidario (CT-989) las dos entregas que lleva atrasadas: licenciamiento, 150 días, y bolsa de horas, 49 días, con 0 entregables aceptados. Los +85 días no deben absorber ese atraso sin que conste.

### [5] ¿Se retiene la aprobación del pago de la factura de Soluciones Solidarias (CT-222, PRY-204) hasta que haya acta de recibo?
**Proyecto:** PRY-204 Tarjeta débito para asociados (gerente Sandra Gil) · **Quién decide:** Comité de Crédito según el acta, a confirmar · **Si no se decide hoy:** hay 1.064.377.272 COP facturados con 0 de 2 entregables aceptados, y el licenciamiento del módulo lleva 60 días de atraso (vencía el 2026-08-24). No sé si la factura ya se pagó; la ficha no lo dice.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener hasta acta de recibo | Sin cambio | Puede tensionar al proveedor; el fin vigente es 2026-12-21 | Se difiere 1.064.377.272 COP |
| B. Pagar contra un compromiso de entrega con fecha | Sin cambio | El proveedor fija fecha | Se paga sin entrega aceptada |
| C. Si ya se pagó, reclamar lo no entregado | Sin cambio | Sin dato | 1.064.377.272 COP en disputa |

**Recomendación:** A. Se facturó sin entrega aceptada. El informe del 2026-10-07, de hace 16 días, dice verde con 37 % de avance cuando el plan sustenta entre 60 y 80 %, y esa lectura del avance no coincide con la evidencia.

### [6] ¿Se autoriza el sobrecosto proyectado de PRY-211, o se congela hasta que haya replanificación con fecha y presupuesto?
**Proyecto:** PRY-211 Cobranza digital (gerente Mauricio Pérez) · **Quién decide:** Consejo de Administración según el acta, a confirmar · **Si no se decide hoy:** la proyección de 5.280.911.293 COP supera en 25,7 % los 4.200.000.000 aprobados (umbral 10 %). Hay 3.403.064.146 COP comprometidos, 81,0 %. El fin vigente es 2026-03-07, ya vencido, y la salida se reprogramó «sin nueva fecha en ningún cronograma».

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aceptar la proyección como nuevo presupuesto | Sin cambio declarado | Sin fecha | 5.280.911.293 COP |
| B. Congelar compromisos nuevos hasta tener replan con fecha | Sin cambio | Se detiene lo no comprometido | 4.200.000.000 COP vigentes |
| C. Detener el proyecto y evaluar | Se suspende | Indefinido | Sin dato |

**Recomendación:** B. Hoy no hay fecha ni cambio de línea base registrado que sustente ninguna cifra. Declarado verde, 37 % de avance contra un plan que sustenta 100 %, y 3 hitos cumplidos sin acta de recibo.

### [7] ¿Quién es el interlocutor único ante el Consejo de Administración por el reglamento, y para cuándo se pide su pronunciamiento?
**Proyecto:** PRY-199, 201, 203, 204, 206, 207 y 208 · **Quién decide:** el comité, para designar al interlocutor; el Consejo decide el reglamento · **Si no se decide hoy:** el Consejo ya pidió ajustes en tres proyectos (PRY-204 desde 2026-10-07, PRY-208 desde 2026-10-20, PRY-203 desde 2026-10-22) y en otros cuatro la aprobación sigue pendiente. El piloto de PRY-203 es el 2026-12-04. Los 7 ítems no tienen doliente.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un dueño único y pronunciamiento solicitado antes del 2026-12-04 | Reglamento ajustado una vez | Fecha límite explícita | Sin dato |
| B. Cada proyecto negocia por separado | Siete ajustes posiblemente distintos | Sin fecha común | Sin dato |
| C. Aplazar los pilotos hasta tener el reglamento | Sin cambio | Se mueven los pilotos | Sin dato |

**Recomendación:** A. Es un solo asunto con siete frentes, y el Consejo pide ajustes proyecto a proyecto.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-201 | Hallazgo de seguridad de la revisión de arquitectura, sin doliente ni severidad, en un proyecto declarado verde | 2026-10-20 | Un doliente y la severidad. Además hay una evaluación de cambio de +30 días (2027-03-24 a 2027-04-23) hecha hoy en una corrida previa, pero **no hay solicitud en los documentos** y la ficha no registra cambios: hay que saber quién la pide y por qué |
| PRY-200, 201, 202, 205, 209 | «La prueba de carga no alcanzó el umbral pactado y se repite», el mismo texto en cinco informes | 2026-10-18 a 2026-10-23 | Que alguien confirme si es un ambiente o un proveedor común |
| PRY-202, 204, 206, 209 | Dependencia del proveedor del core cooperativo, sin doliente ni fecha; la ficha de PRY-202 no registra proveedor ni contrato | sin dato | Un doliente. Además, PRY-203 da por cumplido el hito «Integración con el core cooperativo» (2026-09-22) sin acta de recibo, mientras ese hito en PRY-202 está pendiente para 2027-04-09. No sé si es contradicción o son integraciones distintas |
| PRY-200, 206, 207, 208, 210, 211 | El fin de la línea base vigente ya pasó: 2026-08-02, 2025-12-31, 2026-07-17, 2026-03-17, 2026-10-13 y 2026-03-07; ninguna ficha registra una fecha nueva. Declarados: 200 amarillo, 206 amarillo, 207 verde, 208 rojo, 210 amarillo y 211 verde | desde esas fechas | Que cada gerente declare fecha o cierre. No sé si algún proyecto terminó sin que el documento lo diga |
| PRY-206 | 4 compromisos vencidos, 5 sin fecha y 4 reprogramados; uno ya va por la sexta fecha (Paula Céspedes, «Enviar el documento 1», original 2026-09-21, ahora 2026-12-14). El ejecutado, 10.213.765.153 COP, supera el comprometido, 8.536.248.082 COP. Riesgo dicho en reunión el 2026-10-23 y no registrado: el proveedor podría no llegar con el equipo completo | 2026-09-14 en adelante | Que el gerente explique por qué el ejecutado supera al comprometido y registre el riesgo |
| PRY-207 | Silencio de 16 días (último documento 2026-10-07; umbral 15) con estado declarado verde | 2026-10-07 | Que el gerente confirme el estado |
| PRY-205 | Declarado rojo con 67 % de avance, cuando el plan sustenta entre 25 y 50 %. Lo declarado va más adelantado que el plan, y «Diseño funcional aprobado» figura cumplido sin evidencia | 2026-10-23 | Que explique qué hace rojo a un proyecto que dice ir adelantado |

## Para conocimiento
- PRY-199 Cambio de mobiliario de agencias: verde, sin señales.
- PRY-200 Crédito de libranza digital: amarillo, 5 señales; 3 hitos cumplidos sin evidencia.
- PRY-201 Apertura de ahorro en línea: verde contradicho por 2 señales; ver escalamientos.
- PRY-202 Core cooperativo: verde contradicho; declara 80 % y el plan sustenta entre 33 y 67 %.
- PRY-203 Aportes sociales en línea: verde contradicho por 3 señales; ver decisión 4.
- PRY-204 Tarjeta débito para asociados: verde contradicho por 5 señales; ver decisión 5.
- PRY-205 Prevención de lavado de activos: rojo declarado; ver escalamientos.
- PRY-206 Pagos con QR: amarillo, 17 señales, la mayor concentración; ver escalamientos.
- PRY-207 Microcrédito rural: verde, en silencio; ver escalamientos.
- PRY-208 Motor de crédito: rojo declarado, 0 señales calculadas. No sé por qué está en rojo; no leí su informe en esta corrida.
- PRY-209 Convenios de libranza con empresas: verde contradicho por 4 señales; ver decisión 2.
- PRY-210 Corresponsales rurales: amarillo, 5 señales; ver decisión 3.
- PRY-211 Cobranza digital: verde contradicho por 3 señales; ver decisión 6.

## Anexo

**Estado de cada proyecto** (cifras de `compute`)

| Proyecto | Declarado (fecha) | Avance declarado | Señales | Desviación de tiempo vs original | Proyección vs aprobado |
|---|---|---|---|---|---|
| PRY-199 | verde (2026-10-21) | 20,0 % | 0 | 0 | 0,0 % |
| PRY-200 | amarillo (2026-10-18) | 76,0 % | 5 | 0 | +2,3 % |
| PRY-201 | verde (2026-10-20) | 33,0 % | 3 | 0 | +4,6 % |
| PRY-202 | verde (2026-10-19) | 80,0 % | 3 | 0 | −2,2 % |
| PRY-203 | verde (2026-10-22) | 65,0 % | 7 | +85 días (23,2 %) | −1,1 % |
| PRY-204 | verde (2026-10-07) | 37,0 % | 8 | 0 | +3,1 % |
| PRY-205 | rojo (2026-10-23) | 67,0 % | 2 | 0 | −0,1 % |
| PRY-206 | amarillo (2026-10-19) | 79,0 % | 17 | 0 | +2,8 % |
| PRY-207 | verde (2026-10-07) | 32,0 % | 2 | 0 | −3,5 % |
| PRY-208 | rojo (2026-10-20) | 79,0 % | 0 | 0 | −3,4 % |
| PRY-209 | verde (2026-10-23) | 35,0 % | 8 | +118 días (23,8 %) | −4,9 % |
| PRY-210 | amarillo (2026-10-12) | 63,0 % | 5 | +28 días (6,8 %) | +4,8 % |
| PRY-211 | verde (2026-10-19) | 37,0 % | 7 | 0 | +25,7 % |

Portafolio: 13 proyectos, 11 con señales, 67 señales, 7 con estado verde contradicho por la evidencia (PRY-201, 202, 203, 204, 207, 209, 211).

**Contradicciones abiertas**
- PRY-203 declara cumplido el hito de integración con el core (2026-09-22) sin acta; PRY-202 lo tiene pendiente para 2027-04-09.
- PRY-203, 209 y 210 tienen la línea base movida (85, 118 y 28 días). El script solo da por autorizados los 85 de PRY-203, y eso por una frase sin firma.
- PRY-206: ejecutado mayor que comprometido.

**Vacíos de información**
- Autoridad de aprobación: no encontrada en 13 de 13 fichas.
- Los 33 ítems RAID del portafolio no tienen doliente ni fecha, y ninguno trae valoración.
- No hay acta de un comité anterior.
- PRY-209 y PRY-210 no declaran producto.
- Los 13 proyectos dicen «Ninguna declarada» como dependencia en el acta, y aun así los informes de avance traen 10.
- Trabajé sobre las fichas, los resultados de `compute` y las corridas de hoy (RAID, control de cambios). No releí los documentos fuente en este pase; la verificación es suya.

---
**Pie.** Criterio Portfolio 0.8.0 · fichas aplicadas: 13 (`estado/records/`, snapshot 2026-10-23) · campos inciertos: autoridad ×13, y los ítems que arriba figuran «sin dato» · Borrador de trabajo, no decisión ni asesoría; las recomendaciones son criterio del agente y el comité las confirma o las descarta. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
