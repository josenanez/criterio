# Corrida del 2026-10-23 · change-control

13 proyectos · 38 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Solicitud +30 días a la salida a producción de PRY-201. Sin impacto en portafolio (sin dependencias declaradas). Sin autoridad declarada en el acta: va a comité. Alcance y costo sin impacto declarado; solicitante y motivo no constan.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-201 (actualizada 2026-10-23), línea base v1 y `portafolio.py impact`.

## Solicitud de cambio — PRY-201 Apertura de ahorro en línea — 2026-10-23

**Qué se pide:** mover la salida a producción 30 días (2027-03-24 → 2027-04-23). · **Quién lo pide:** no consta en ningún documento ni en la solicitud. · **Por qué:** no se dio motivo. Lo que hay en el informe de avance del 2026-10-20 (prueba de carga bajo el umbral y se repite; hallazgo de seguridad abierto) es contexto posible, no un motivo declarado por nadie.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 (el acta no los detalla) | No declarado | Sin impacto declarado |
| Tiempo | Cierre 2027-03-24 (línea base v1) | 2027-04-23 | +30 días |
| Costo | Aprobado 18.000.000.000 COP; proyección 18.824.193.276 | No declarado | Sin impacto declarado |

Alcance y costo quedan sin impacto declarado. Mover 30 días sin tocar alcance ni presupuesto significa que alguien lo absorbe en calidad, en horas no pagadas o en costo que ya excede lo aprobado. Eso no lo dice ningún documento, así que no lo calculo. Dato de contexto: la proyección ya supera lo aprobado en 824.193.276 COP (4,6 %), bajo el umbral de 10 %. Un mes más de equipo no se puede valorar con la ficha.

Lo que el cambio toca más allá del hito final: las fechas del contrato CT-967 con Red Rural de Pagos (bolsa de horas 2026-11-20; parametrización 2027-02-04) no cambian con esta solicitud. Si la salida se mueve y esas fechas no, la solicitud no dice qué pasa con ellas. La vigencia del contrato no figura en la ficha.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El cálculo no encuentra proyectos alcanzados, directa ni indirectamente (0 alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar) | n/a |

Esto se sostiene en las dependencias declaradas, y el acta de PRY-201 dice «Ninguna declarada». No prueba que no haya dependencias, solo que nadie las declaró. Verifique con PRY-202 (core cooperativo), porque PRY-201 tiene un hito «Integración con el core cooperativo» y no hay dependencia declarada hacia él.

Hitos propios por los que pasa el cambio, no los que se movieron: Integración con el core cooperativo (2026-12-04), Piloto con asociados (2027-01-28) y Salida a producción (2027-03-24). El cálculo no dice cuántos días se mueve cada uno. Eso necesita holgura por actividad, que la ficha no tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara autoridad para aprobar cambios (`identity.authority` no encontrado). · **Según:** el acta de constitución (2026-06-12) nombra al Comité de Tecnología como quien aprobó la línea base v1 y el presupuesto, pero no fija umbrales de cambio. · **Va a comité:** sí, por defecto, ante la falta de autoridad declarada: el gerente (Camilo Beltrán) no puede aprobarlo por su cuenta sin una cláusula que lo faculte. Comité de Tecnología; el próximo comité es el 2026-10-30. Que no haya autoridad declarada es el hallazgo de fondo.

### Si no se aprueba
El proyecto sigue con cierre 2027-03-24. Con el informe del 2026-10-20 (prueba de carga repetida, hallazgo de seguridad sin responsable, riesgo del reglamento sin dueño ni fecha) y 33 % de avance reportado, esa fecha no tiene un sustento documentado. El estado declarado es verde y la evidencia que lo acompaña no lo respalda. Un compromiso vencido (punto 29, Rubén Cárdenas, 2026-10-08) sigue abierto.

### Si se aprueba
Línea base 2 — cierre 2027-04-23 · presupuesto: no definido en la solicitud (hoy 18.000.000.000 COP aprobados) · motivo: no declarado; hay que escribirlo antes de registrar.
Desviación acumulada contra la línea base original (v1, 2027-03-24): +30 días · costo +0 hasta que se declare otro presupuesto (la proyección ya está +824.193.276 COP sobre lo aprobado).
La línea base v1 no se toca; el conteo de replanificaciones pasa de 0 a 1. Hoy no hay cambios registrados (`changes` vacío), así que no hay días autorizados que reconciliar: los 30 días saldrían como no autorizados hasta que el documento de aprobación exista.

### Lo que no sé
- Quién lo pide y por qué.
- Cuántos días se mueven el piloto y la integración con el core.
- Cuánto cuesta un mes más y qué pasa con CT-967.
- Si hay dependencias reales con otros proyectos que nadie declaró.

**Pie de rigor:** borrador de trabajo, no decisión. Cada dato sale de la ficha PRY-201 y de sus documentos (acta de constitución 2026-06-12, cronograma v1, informe de avance 2026-10-20, contrato CT-967, comité 2026-10-18). La verificación es suya.
