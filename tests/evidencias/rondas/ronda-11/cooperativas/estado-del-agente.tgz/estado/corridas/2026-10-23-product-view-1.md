# Corrida del 2026-10-23 · product-view

13 proyectos · 38 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 7 |
| `commitment_rescheduled` | 4 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `silent` | 1 |
| `variance_cost` | 1 |

Producto recaudos con un solo proyecto (PRY-211): sin vista de producto, se reportó el proyecto. Verde declarado contradicho por 3 hitos sin evidencia, 63 puntos de brecha de avance y proyección +25,7 %. No se sabe: autoridad, fase, cuál de avance o hitos es el erróneo; fuentes sin marcar. 5 proyectos sin producto declarado.

Contra la corrida del 2026-10-23: +0 hallazgos.

## Lo que produjo

> El comando no entregó su resultado (`--salida`): la corrida registra las cifras, pero lo que dijo se quedó en la conversación.
