# Comité de producto · Remesas familiares

**Fecha:** 2026-10-21
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | sin asignar | se verifica en producción | — | aceptado | 2026-04-03 | — |
| REQ-4801 | Requerimiento REQ-4801 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-23 | — |
| REQ-4802 | Requerimiento REQ-4802 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-30 | — |
| REQ-4803 | Requerimiento REQ-4803 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-15 | — |
| REQ-4804 | Requerimiento REQ-4804 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-01 | — |
| REQ-4805 | Requerimiento REQ-4805 | Felipe Arango | se verifica en producción | — | aceptado | 2026-06-10 | — |
| REQ-4806 | Requerimiento REQ-4806 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4807 | Requerimiento REQ-4807 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4808 | Requerimiento REQ-4808 | Beatriz Cuéllar | — | — | propuesto | 2026-06-24 | — |
| REQ-4809 | Requerimiento REQ-4809 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4810 | Requerimiento REQ-4810 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-14 | — |
| REQ-4811 | Requerimiento REQ-4811 | María Restrepo | se verifica en producción | — | propuesto | 2026-04-11 | — |
| REQ-4812 | Requerimiento REQ-4812 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4813 | Requerimiento REQ-4813 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-25 | — |
| REQ-4814 | Requerimiento REQ-4814 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-08-03 | — |
| REQ-4815 | Requerimiento REQ-4815 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-05-25 | — |
| REQ-2037 | Requerimiento REQ-2037 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-14 | — |

## Decisiones

- Se mantiene el plan
