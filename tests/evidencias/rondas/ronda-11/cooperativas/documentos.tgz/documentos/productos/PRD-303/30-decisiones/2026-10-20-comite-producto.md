# Comité de producto · Tarjeta débito

**Fecha:** 2026-10-20
**Asistentes:** Ricardo Salas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Mauricio Pérez | — | Cliente entrevistado | propuesto | 2026-05-27 | — |
| REQ-4301 | Requerimiento REQ-4301 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-31 | — |
| REQ-4302 | Requerimiento REQ-4302 | Carlos Peña | — | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4303 | Requerimiento REQ-4303 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-05-23 | — |
| REQ-4304 | Requerimiento REQ-4304 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-4305 | Requerimiento REQ-4305 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-4306 | Requerimiento REQ-4306 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4307 | Requerimiento REQ-4307 | Natalia Ospina | — | — | aceptado | 2026-07-05 | — |
| REQ-4308 | Requerimiento REQ-4308 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4309 | Requerimiento REQ-4309 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-03-27 | — |
| REQ-4310 | Requerimiento REQ-4310 | Natalia Ospina | — | — | propuesto | 2026-03-26 | — |
| REQ-4311 | Requerimiento REQ-4311 | Sandra Gil | se verifica en producción | — | aceptado | 2026-06-27 | — |

## Decisiones

- Se mantiene el plan
