# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-04-09
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 296.438 | Caso de negocio, 2026-04-09 |

## Retorno esperado

Retorno esperado en 24 meses.
