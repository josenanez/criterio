# Verificación del supuesto · Tarjeta débito

**Fecha:** 2026-09-11

**Supuesto:** Los asociados usan el canal digital

**Con qué se verificó:** la medición del piloto del 2026-09-11. Este anexo es esa evidencia: recoge la verificación completa y no remite a otro documento.

**Resultado:** se confirmó.
