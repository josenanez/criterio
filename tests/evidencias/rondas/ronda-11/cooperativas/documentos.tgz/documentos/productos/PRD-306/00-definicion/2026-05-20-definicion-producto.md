# Definición de producto · Recaudos

**Código:** PRD-306
**Gerente de producto:** Camilo Beltrán
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-05-20

## El problema

El segmento Microempresarios no tiene recaudos.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-29 · verificado con el documento técnico del proveedor del 2026-10-01 (anexo «Verificación del supuesto» del 2026-10-01)

## Proyectos que lo construyen

- Ninguno declarado
