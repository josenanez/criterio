# Comité de producto · Microcrédito

**Fecha:** 2026-10-20
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4501 | Requerimiento REQ-4501 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4502 | Requerimiento REQ-4502 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-01 | — |
| REQ-4503 | Requerimiento REQ-4503 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4504 | Requerimiento REQ-4504 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-07-08 | — |
| REQ-4505 | Requerimiento REQ-4505 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-14 | — |
| REQ-4506 | Requerimiento REQ-4506 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-11 | — |
| REQ-4507 | Requerimiento REQ-4507 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-27 | — |
| REQ-4508 | Requerimiento REQ-4508 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4509 | Requerimiento REQ-4509 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4510 | Requerimiento REQ-4510 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-16 | — |
| REQ-4511 | Requerimiento REQ-4511 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-13 | — |
| REQ-4512 | Requerimiento REQ-4512 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4513 | Requerimiento REQ-4513 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-16 | — |
| REQ-4514 | Requerimiento REQ-4514 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-08-03 | — |
| REQ-4515 | Requerimiento REQ-4515 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-16 | — |
| REQ-2037 | Requerimiento REQ-2037 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-10-12 | — |

## Decisiones

- Se mantiene el plan
