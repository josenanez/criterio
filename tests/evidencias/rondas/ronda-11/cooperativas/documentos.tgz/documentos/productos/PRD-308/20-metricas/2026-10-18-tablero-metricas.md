# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-18

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 140.445 | 2026-10-18 |
