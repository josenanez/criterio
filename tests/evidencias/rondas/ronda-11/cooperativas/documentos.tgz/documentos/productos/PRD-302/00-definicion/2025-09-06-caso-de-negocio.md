# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-09-06
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 299.211 | Caso de negocio, 2025-09-06 |

## Retorno esperado

Retorno esperado en 24 meses.
