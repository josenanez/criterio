# Comité de producto · Pagos QR

**Fecha:** 2026-10-07
**Asistentes:** Paula Céspedes

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4401 | Requerimiento REQ-4401 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-18 | — |
| REQ-4402 | Requerimiento REQ-4402 | Laura Vélez | se verifica en producción | — | aceptado | 2026-08-23 | — |
| REQ-4403 | Requerimiento REQ-4403 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-24 | — |
| REQ-4404 | Requerimiento REQ-4404 | Natalia Ospina | — | Cliente entrevistado | propuesto | 2026-06-29 | — |
| REQ-4405 | Requerimiento REQ-4405 | Laura Vélez | — | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4406 | Requerimiento REQ-4406 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-13 | — |
| REQ-4407 | Requerimiento REQ-4407 | Rubén Cárdenas | — | — | aceptado | 2026-08-02 | — |
| REQ-4408 | Requerimiento REQ-4408 | Sandra Gil | se verifica en producción | — | aceptado | 2026-08-31 | — |
| REQ-4409 | Requerimiento REQ-4409 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-26 | — |
| REQ-4410 | Requerimiento REQ-4410 | sin asignar | se verifica en producción | — | aceptado | 2026-05-26 | — |
| REQ-4411 | Requerimiento REQ-4411 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-03 | — |
| REQ-4412 | Requerimiento REQ-4412 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-08-01 | — |
| REQ-4413 | Requerimiento REQ-4413 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-01 | — |

## Decisiones

- Se mantiene el plan
