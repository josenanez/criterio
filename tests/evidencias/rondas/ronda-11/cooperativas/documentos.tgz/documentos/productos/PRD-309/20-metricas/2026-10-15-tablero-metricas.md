# Tablero de métricas · Microseguros

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 199.332 | 2026-10-15 |
