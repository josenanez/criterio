# Comité de producto · Crédito de libranza

**Fecha:** 2026-10-12
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4001 | Requerimiento REQ-4001 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-04-13 | — |
| REQ-4002 | Requerimiento REQ-4002 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-04-27 | — |
| REQ-4003 | Requerimiento REQ-4003 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-06 | — |
| REQ-4004 | Requerimiento REQ-4004 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-05 | — |
| REQ-4005 | Requerimiento REQ-4005 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-07 | — |
| REQ-4006 | Requerimiento REQ-4006 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-05-08 | — |
| REQ-4007 | Requerimiento REQ-4007 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4008 | Requerimiento REQ-4008 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4009 | Requerimiento REQ-4009 | sin asignar | — | Cliente entrevistado | propuesto | 2026-05-25 | — |
| REQ-4010 | Requerimiento REQ-4010 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-30 | — |
| REQ-4011 | Requerimiento REQ-4011 | María Restrepo | se verifica en producción | — | aceptado | 2026-04-14 | — |
| REQ-4012 | Requerimiento REQ-4012 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-29 | — |
| REQ-4013 | Requerimiento REQ-4013 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4014 | Requerimiento REQ-4014 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4015 | Requerimiento REQ-4015 | sin asignar | — | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-2030 | Requerimiento REQ-2030 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-10-05 | — |

## Decisiones

- Se mantiene el plan
