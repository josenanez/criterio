# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2026-02-25
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 59.224 | Caso de negocio, 2026-02-25 |

## Retorno esperado

Retorno esperado en 24 meses.
