# Tablero de métricas · Tarjeta débito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 291.702 | 2026-10-16 |
