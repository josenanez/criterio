# Entrevistas · Recaudos

**Ronda:** Ronda · 2025-09-23
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2025-09-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
