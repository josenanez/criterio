# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2026-05-20
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 214.523 | Caso de negocio, 2026-05-20 |

## Retorno esperado

Retorno esperado en 24 meses.
