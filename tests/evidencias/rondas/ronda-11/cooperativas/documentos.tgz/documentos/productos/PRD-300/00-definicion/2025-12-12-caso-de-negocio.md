# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2025-12-12
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 272.910 | Caso de negocio, 2025-12-12 |

## Retorno esperado

Retorno esperado en 24 meses.
