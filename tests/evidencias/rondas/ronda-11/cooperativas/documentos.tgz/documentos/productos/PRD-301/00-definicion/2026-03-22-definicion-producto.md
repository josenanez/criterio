# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Andrés Lozano
**Segmento:** Pensionados
**Fecha de la definición:** 2026-03-22

## El problema

El segmento Pensionados no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-17 · verificado con el concepto jurídico de cumplimiento del 2026-08-08 (anexo «Verificación del supuesto» del 2026-08-08)

## Proyectos que lo construyen

- Ninguno declarado
