# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-03-22
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.475 | Caso de negocio, 2026-03-22 |

## Retorno esperado

Retorno esperado en 24 meses.
