# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Felipe Arango
**Segmento:** Pensionados
**Fecha de la definición:** 2026-02-25

## El problema

El segmento Pensionados no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-16 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
