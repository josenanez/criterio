# Entrevistas · Pagos QR

**Ronda:** Ronda · 2026-03-20
**Realizadas por:** Paula Céspedes

### Cliente entrevistado · 2026-03-20

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
