# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Paula Céspedes
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-07-05

## El problema

El segmento Microempresarios no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-17 · verificado con el documento técnico del proveedor del 2026-08-01 (anexo «Verificación del supuesto» del 2026-08-01)

## Proyectos que lo construyen

- Ninguno declarado
