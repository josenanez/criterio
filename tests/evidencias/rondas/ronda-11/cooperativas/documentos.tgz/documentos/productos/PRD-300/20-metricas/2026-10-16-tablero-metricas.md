# Tablero de métricas · Crédito de libranza

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 210.408 | 2026-10-16 |
