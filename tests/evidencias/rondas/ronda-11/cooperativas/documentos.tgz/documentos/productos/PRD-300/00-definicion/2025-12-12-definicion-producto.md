# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Óscar Ramírez
**Segmento:** Pensionados
**Fecha de la definición:** 2025-12-12

## El problema

El segmento Pensionados no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-09-12 · verificado con el concepto jurídico de cumplimiento del 2026-09-17 (anexo «Verificación del supuesto» del 2026-09-17)

## Proyectos que lo construyen

- Ninguno declarado
