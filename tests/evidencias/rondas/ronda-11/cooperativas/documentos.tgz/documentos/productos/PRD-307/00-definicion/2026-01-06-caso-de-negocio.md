# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-01-06
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 207.538 | Caso de negocio, 2026-01-06 |

## Retorno esperado

Retorno esperado en 24 meses.
