# Informe de avance · Microcrédito rural

**Código:** PRY-207
**Fecha de corte:** 2026-10-07
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **32%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.491.363.645 |
| Ejecutado | 534.713.444 |
| Proyección al cierre | 2.315.758.298 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
