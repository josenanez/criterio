# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-10-23
**Asistentes:** Liliana Torres, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 31 | por definir |
