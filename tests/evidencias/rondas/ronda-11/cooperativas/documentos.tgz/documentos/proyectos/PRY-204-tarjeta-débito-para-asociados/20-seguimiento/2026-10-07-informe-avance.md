# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-07
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **37%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 7.487.113.499 |
| Ejecutado | 5.254.568.526 |
| Proyección al cierre | 9.790.767.231 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
