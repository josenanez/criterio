# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-09-18
**Asistentes:** Carlos Peña, Elena Duarte, Gustavo Neira, Laura Vélez, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-06 |
| María Restrepo | Cerrar la prueba 2 | 2026-10-06 |
| María Restrepo | Revisar el anexo 3 | 2026-09-28 |
| Laura Vélez | Validar el ambiente 4 | 2026-10-14 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-14 |
| Elena Duarte | Actualizar la matriz 6 | 2026-09-21 |
| Carlos Peña | Confirmar la fecha 7 | por definir |
| Gustavo Neira | Entregar el punto 8 | 2026-10-07 |
