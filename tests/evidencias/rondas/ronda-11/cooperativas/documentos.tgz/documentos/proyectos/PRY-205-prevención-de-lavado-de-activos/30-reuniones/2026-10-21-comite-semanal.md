# Comité de Riesgos · Prevención de lavado de activos

**Fecha:** 2026-10-21
**Asistentes:** Carlos Peña, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 14 | 2026-10-30 |
| Javier Hoyos | Entregar el punto 35 | 2026-11-09 |
