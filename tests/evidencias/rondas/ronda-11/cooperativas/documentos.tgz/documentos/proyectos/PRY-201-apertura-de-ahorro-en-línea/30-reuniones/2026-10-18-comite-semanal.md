# Comité de Tecnología · Apertura de ahorro en línea

**Fecha:** 2026-10-18
**Asistentes:** Camilo Beltrán, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 29 | 2026-10-08 |
