# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Bienestar social
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Riesgos
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2025-06-06

## Objetivo del negocio

Entregar pagos con qr para Bienestar social.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Riesgos el 2025-06-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-16 |
| Cierre | 2025-12-31 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
