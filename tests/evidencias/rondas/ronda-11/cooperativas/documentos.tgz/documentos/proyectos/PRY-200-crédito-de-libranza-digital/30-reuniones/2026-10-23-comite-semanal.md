# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-23
**Asistentes:** Ricardo Salas, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 20 | 2026-11-04 |
| Sandra Gil | Entregar el punto 3 | 2026-10-10 |
