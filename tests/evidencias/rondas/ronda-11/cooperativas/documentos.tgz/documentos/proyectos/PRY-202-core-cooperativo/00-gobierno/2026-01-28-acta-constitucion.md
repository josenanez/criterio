# Acta de constitución · Core cooperativo

**Código:** PRY-202
**Área dueña:** Tecnología
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-01-28

## Objetivo del negocio

Entregar core cooperativo para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Tecnología el 2026-01-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-07 |
| Cierre | 2027-04-09 |

## Criterio de éxito

Core cooperativo en producción y medido.

## Dependencias declaradas

- Ninguna declarada
