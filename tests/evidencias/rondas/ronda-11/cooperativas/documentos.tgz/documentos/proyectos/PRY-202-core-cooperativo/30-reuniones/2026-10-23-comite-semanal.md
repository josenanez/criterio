# Comité de Tecnología · Core cooperativo

**Fecha:** 2026-10-23
**Asistentes:** Javier Hoyos, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 26 | 2026-11-19 |
