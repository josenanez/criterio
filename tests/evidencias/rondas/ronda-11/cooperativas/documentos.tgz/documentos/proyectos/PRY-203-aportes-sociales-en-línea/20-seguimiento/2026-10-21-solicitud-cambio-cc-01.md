# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Aportes sociales en línea
**Fecha:** 2026-10-21
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +85 días sobre la línea base vigente |
| Costo | 170.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
