# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-09-11
**Asistentes:** Laura Vélez, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-21 |
| María Restrepo | Cerrar la prueba 2 | 2026-09-14 |
| María Restrepo | Revisar el anexo 3 | 2026-09-16 |
| Laura Vélez | Validar el ambiente 4 | 2026-10-05 |
