# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Convenios de libranza con empresas
**Fecha:** 2026-10-16
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +118 días sobre la línea base vigente |
| Costo | 236.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
