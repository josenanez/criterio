# Corrida · 2026-10-22-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:46:10 · **Fin:** 2026-10-22T20:47:59 · **Duración:** 109 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 23 | 54 | Barrido sin cambios (74 documentos). Confirmación: 5 preguntas hechas, sin respuesta (sesión sin interfaz). Sin peticiones. No sé si los hitos de PRY-200 tienen evidencia fuera de la carpeta. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 17, `commitment_overdue` 14, `declared_vs_evidence` 5, `progress_vs_plan` 4, `variance_time` 3, `commitment_undated` 3, `change_without_baseline` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `variance_cost` 2

## Lo que el agente mostró

Hoy tocaban el barrido diario y la confirmación periódica. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-22), así que no los registré de nuevo.

- **Barrido:** revisé 74 documentos y ninguno cambió. No recalculé ningún proyecto y no hubo noticia nueva.
- **Peticiones:** no había ninguna pendiente en el servidor.
- **Confirmación:** preparé las cinco preguntas, pero en esta sesión nadie puede responderlas. Quedan "preguntadas el 22, sin respuesta". No las repetiré hasta que alguien conteste.
  1. PRY-200: el motivo del cambio de la línea base v2 (el fin pasó de 2026-12-10 a 2027-03-31).
  2. PRY-200: los hitos de Diseños, Licencias y Cimentación figuran cumplidos y no tienen evidencia.
  3. PRY-200: el compromiso "Entregar el punto 35", de Beatriz Cuéllar, venció el 2026-10-19 sin evidencia.
  4. PRY-199: el monto facturado del contrato CT-199 no aparece en ningún documento.
  5. PRY-199: los dos riesgos registrados no tienen responsable.

Dejé constancia del barrido y de la confirmación, y registré la corrida. Tardó 23 segundos. Quedó abierta con 54 hallazgos en los proyectos. La salida está en `estado/corridas/salida-portfolio-wake.md`.

Vuelvo el 2026-10-23.

## Respuesta 2

El mapa de Rostrum quedó con 3 agentes de la familia pmo: Vera (portafolio), Samuel (PRY-201) y Alba (PRD-305). No dejé ninguno fuera del portal. Quedó guardado en `.criterio/rostrum/config.json`.

- **Organización:** la configuración de la PMO no trae su nombre y en esta sesión nadie podía darlo, así que el mapa quedó sin él. Se agrega volviendo a correr `guardar` con `--organizacion "<nombre>"`.
- **Marcas pendientes:** las tres carpetas de documentos no tienen su archivo `_CRITERIO_<QUÉ>.txt`. Se marcan desde el setup de cada agente: `/criterio-portfolio:portfolio-setup`, `/criterio-project:pm-setup` y `/criterio-product:product-setup`.
- **Términos:** quedaron aceptados a nombre de José Francisco Ñáñez, versión 1.2, el 2026-10-22. El comprobante está en `.criterio/terminos/aceptacion-criterio-server-0.8.0-2026-10-22.md` y en el `.pdf` del mismo nombre.

Para levantar el portal: `/criterio-server:server-start`.

## Respuesta 3

Rostrum arrancó bien, pero lo paró el límite de 15 s de esta sesión. Mientras estuvo arriba imprimió sus direcciones, y ahora no está corriendo. No pude dejarlo en segundo plano, porque la herramienta de comandos de esta sesión no lo permite.

**Lo que sirve el mapa** (3 entradas: Vera/portafolio, Samuel/PRY-201, Alba/PRD-305; el mapa está al día, sin entradas nuevas, desaparecidas ni sin estado):

| Ruta | Qué hay |
|---|---|
| `/` | Portada con las tres puertas y el formulario de peticiones |
| `/pmo` | Informes de la PMO |
| `/decisiones` | Material para el comité |
| `/proyectos` | 13 proyectos (PRY-199 a PRY-211) |
| `/productos` | 5 productos |
| `/corridas` | 33 corridas |
| `/estado.json` | De cuándo es lo de cada agente (para un mecanismo, no una persona) |

**Para levantarlo a mano**, en una terminal propia:

```
python3 "/home/claude/banco/plugins/criterio-server/scripts/servidor.py" --mapa .criterio/rostrum/config.json
```

Escucha solo en `127.0.0.1:8787` y se para con Ctrl-C. Si el puerto está ocupado, agrega `--puerto 8788`.

**Qué enlace pasar a quién**, cuando lo dejen corriendo:
- **Patrocinador:** `/`.
- **Comité:** `/decisiones`.
- **Gerencia:** `/pmo` y `/proyectos`. `/vence` y `/familia/…` no aparecieron en las direcciones que imprimió, porque el mapa solo tiene la familia PMO.

Cada página dice de cuándo es lo que muestra. Los informes de `reportes/` son del 2026-10-22. Conviene decírselo a quien reciba el enlace.

**Qué no hace.** No calcula, no autentica, no manda correos y no escribe fichas. Lo único que crea son las peticiones, en la carpeta `peticiones/` de cada agente.

**Para dejarlo corriendo** (`--abierto`), la organización tendría que dar un host y un puerto internos y publicarlo detrás de su control de acceso, porque el servidor no autentica. No necesita nada más. Por ahora, como pidió `rato`, no hace falta.
