# Corrida · 2026-10-22-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:21:30 · **Fin:** 2026-10-22T20:22:38 · **Duración:** 67 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 52 | 19 | Paquete con 3 puntos: autoridad no declarada en el acta, compromiso 'documento 1' con 6 reprogramaciones, 'prueba 2' con 5. No corrí impact porque ningún punto mueve una fecha del plan. Sin saber: qué es el documento 1, el costo de las opciones, quién decide por el proveedor, y por qué el ejecutado supera al comprometido. |

Por señal (`pm-escalate`): `commitment_overdue` 9, `commitment_undated` 3, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-201 con tres puntos para decisión y registré la corrida como `2026-10-22-pm-escalate-1`. No venía un tema en el argumento, así que usé lo que ya estaba marcado como escalable en la ficha y en el informe del 22 de octubre. Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22), así que no hubo que aceptarlos de nuevo.

1. **Autoridad de la gerente.** El acta de constitución no declara qué puede decidir Diana Molina, así que ese es el primer punto. Recomiendo una adenda al acta. Hasta que esté, no puedo decir de ningún otro punto si excede o no a la gerente.
2. **«Enviar el documento 1» (Beatriz Cuéllar).** Lleva 6 reprogramaciones, y la fecha vigente (2026-12-25) cae diez días después del cierre del proyecto (2026-12-15). Recomiendo mantenerlo solo con una fecha tope anterior al cierre.
3. **«Cerrar la prueba 2» (Mauricio Pérez).** Lleva 5 reprogramaciones y está para el 2026-11-13. Recomiendo mantener esa fecha y revisarla en la próxima sesión.

Lo que el paquete dice que no sabe:
- **«Documento 1»:** no sé qué es ni qué bloquea, y por eso no puse costo a ninguna opción de los puntos 2 y 3.
- **Efecto de fechas:** no corrí `impact` porque ningún punto mueve una fecha del plan, así que no hay lista de proyectos alcanzados. El acta tampoco declara dependencias.
- **Proveedor Interventorías Técnicas (CT-521):** no puedo decir si sus dos entregables vencidos escalan; depende del punto 1.
- **Presupuesto:** el ejecutado (501,9 M COP) supera al comprometido (269,0 M COP). Lo dejé como aclaración pendiente, no como decisión.

Archivos en `estado/PRY-201-edificio-de-oficinas-torre-norte/corridas/`:
- `salida-pm-escalate.md`
