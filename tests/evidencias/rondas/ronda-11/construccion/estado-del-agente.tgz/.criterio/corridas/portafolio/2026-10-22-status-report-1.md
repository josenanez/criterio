# Corrida · 2026-10-22-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-22T20:30:41 · **Fin:** 2026-10-22T20:31:21 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 27 | 54 | Informe de estado de PRY-200: declara verde 73% (2026-09-30) contradicho por +111 días, 3 hitos sin evidencia y 1 compromiso vencido. Dijo no saber: producto, autoridad, fase, evidencia de hitos, motivo de la replanificación, dueños de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 17, `commitment_overdue` 14, `declared_vs_evidence` 5, `progress_vs_plan` 4, `variance_time` 3, `commitment_undated` 3, `change_without_baseline` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `variance_cost` 2

## Lo que el agente mostró

**PRY-200, Variante vial del sur, estado al 2026-10-22**

El gerente (Javier Hoyos) declara verde con 73 % de avance al 2026-09-30, y los documentos lo contradicen.

- **Cierre:** la línea base original era el 2026-12-10 y la vigente es el 2027-03-31, 111 días más (43,4 %, sobre el umbral de 10 %). Hubo 1 replanificación, aprobada el 2026-09-30, y ningún documento da su motivo.
- **Hitos:** tres de los cuatro figuran como cumplidos solo porque lo dice el cronograma v2. Ninguno tiene evidencia: Diseños de detalle (143 días), Licencias y permisos (79 días) y Cimentación (15 días).
- **Compromiso vencido:** Beatriz Cuéllar debía «Entregar el punto 35» el 2026-10-19 y lleva 3 días sin evidencia de entrega.
- **Cambio sin línea base:** CC-01 (+111 días y +222.000.000 COP) se aprobó el 2026-10-14, pero la línea base no se movió por él.
- **Presupuesto:** la proyección es 757.747694 COP frente a 800.000.000 aprobados (−5,3 %). Esa cifra no incluye el costo adicional de CC-01.
- **Silencio:** el último documento es del 2026-10-14 (8 días) y la última reunión del 2026-10-12.
- **Sin dato:** producto, autoridad, fase, evidencia de los hitos, motivo de la replanificación y dueño de cada riesgo e incidencia.

Los términos (versión 1.2) ya estaban aceptados a nombre de José Francisco Ñáñez con fecha 2026-10-22, así que no los registré de nuevo. Hay desviación sobre el umbral, así que puedo preparar el punto de comité y la regularización de la línea base de CC-01.

La salida completa está en `estado/corridas/salida-status-report.md`. La corrida quedó registrada como `2026-10-22-status-report-1` y tardó 27 segundos.

El registro de la corrida cuenta los 13 proyectos del portafolio (54 hallazgos en total), aunque el informe cubre solo PRY-200.
