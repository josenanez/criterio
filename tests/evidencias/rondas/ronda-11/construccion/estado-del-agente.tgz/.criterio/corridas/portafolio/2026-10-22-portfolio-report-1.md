# Corrida · 2026-10-22-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:44:58 · **Fin:** 2026-10-22T20:46:08 · **Duración:** 70 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 74 | 48 | 54 | 5 proyectos en verde contradichos por la evidencia (PRY-200, 201, 204, 205, 209); sin delta: primera instantánea. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 17, `commitment_overdue` 14, `declared_vs_evidence` 5, `progress_vs_plan` 4, `variance_time` 3, `commitment_undated` 3, `change_without_baseline` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `variance_cost` 2

## Lo que el agente mostró

El informe HTML está generado: 22 páginas en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/construccion/espacio/reportes`, y la corrida quedó registrada (`2026-10-22-portfolio-report-1`).

**Términos:** estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22), así que no hubo que volver a registrarlos.

**Qué leyó:** las 13 fichas, todas del 2026-10-22. No hay delta, porque la única instantánea es de hoy mismo; esto es el punto de partida.

**Qué salió:** 54 señales en 9 de los 13 proyectos.
- **Verdes contradichos (5):** PRY-200, 201, 204, 205 y 209 se declaran en verde y los documentos no lo sostienen.
- **Hitos sin evidencia (17):** declarados como cumplidos sin documento que los respalde; el más viejo es PRY-205, con 372 días.
- **Compromisos vencidos (14):** 9 son de PRY-201.
- **Atraso:** PRY-200 lleva +111 días, PRY-203 +147 y PRY-204 +58 contra la línea base original.
- **Costo:** PRY-203 proyecta +27,7 % sobre lo aprobado y PRY-206 +16,1 %.
- **Vacíos:** ninguna ficha tiene patrocinador o decisor identificado (13 de 13).

**Qué va a quién:**
- `index.html` es la vista por campo, con la cadena de evidencia completa. Es para quien va a actuar.
- `decisiones.html` es la vista por decisión, solo lo que excede la facultad del gerente. Es para el patrocinador y el comité.
- El PDF sale de imprimir el HTML desde el navegador.

**Pendiente:** no armé las cinco preguntas de confirmación mensual porque es la primera corrida y no hay historial de confirmaciones. Dejé dicho en la salida que `decisiones.html` es donde está lo que sí requiere decisión.

Dos cosas que no quedaron resueltas. PRY-207 tiene fecha fin 2026-10-12 ya pasada y se declara verde con 32 %, pero el cálculo no generó señal; vale la pena revisarlo. Y la carpeta `reportes/` no existía: el script la creó al generar el informe.

La salida completa quedó en `estado/corridas/salida-portfolio-report.md`.

Criterio Portfolio v0.8.0 · 13 fichas del 2026-10-22 · campos inciertos: autoridad, fase y producto en varios proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

¿Preparo el material de comité o entro al detalle de los proyectos con hallazgos?
