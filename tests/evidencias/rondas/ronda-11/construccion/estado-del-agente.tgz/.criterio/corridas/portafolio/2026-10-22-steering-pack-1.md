# Corrida · 2026-10-22-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:42:27 · **Fin:** 2026-10-22T20:44:17 · **Duración:** 111 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 93 | 54 | Paquete de 5 decisiones y 5 escalamientos sobre 13 fichas. Dijo que no sabe: ciclo anterior (sin registro de comité previo), autoridad de aprobación (13 de 13 sin dato), facturación de proveedores, fechas de fin proyectadas de PRY-203 y PRY-207. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 17, `commitment_overdue` 14, `declared_vs_evidence` 5, `progress_vs_plan` 4, `variance_time` 3, `commitment_undated` 3, `change_without_baseline` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `variance_cost` 2

## Lo que el agente mostró

Preparé el paquete de comité del 2026-10-22: 5 decisiones, 5 escalamientos sin decisión asociada y 9 de los 13 proyectos con hallazgos. Los términos v1.2 ya estaban aceptados a nombre de José Francisco Ñáñez para esta fecha, así que no los registré de nuevo.

Las cifras salen de `compute`. Las de las solicitudes de cambio (días y COP adicionales) son las que declara cada solicitud.

**Decisiones de hoy**
1. **Autoridad de aprobación:** quién puede aprobar cambios de línea base y cierres de hito. Ninguna de las 13 fichas la registra, y este punto va primero porque los demás dependen de él.
2. **PRY-203 Planta de tratamiento de agua:** nueva línea base. La fecha de fin vigente (2026-08-16) ya venció. La desviación de tiempo es de 147 días (63.6 %) y la proyección de costo está 27.7 % por encima de lo aprobado. Recomiendo pedir la nueva línea base al gerente, condicionada a auditar los dos hitos sin evidencia.
3. **PRY-208 Bodega logística modular:** la solicitud CC-01 (+30 días, 60 000 000 COP) está pendiente. Recomiendo aprobarla condicionada a registrar hitos y una línea base nueva.
4. **PRY-205 Ampliación del aeropuerto regional:** la ficha da los 4 hitos como cumplidos, pero el avance declarado es 34 %, una diferencia de 66.0 puntos. Recomiendo una verificación independiente de los hitos.
5. **PRY-201 Edificio de oficinas Torre Norte:** requerimiento formal a Interventorías Técnicas S.A.S. (CT-521). Tiene dos entregables vencidos, de 116 y 51 días, sin ninguno aceptado.

**Escalamientos sin decisión asociada:** PRY-200 y PRY-204 (cambios aprobados sin línea base nueva), PRY-206 (sobrecosto de 16.1 %), PRY-211 (rojo con 90 % de avance) y PRY-207 (fecha de fin pasada, sin hitos).

**Lo que el paquete no sabe**
- **Comité anterior:** no hay registro de uno, así que esa sección dice "no verificable".
- **Facturación:** no aparece lo facturado a los proveedores.
- **Fechas de fin:** no hay fecha proyectada para PRY-203 ni PRY-207.

La corrida quedó registrada como `2026-10-22-steering-pack-1`. Antes de cerrarla corregí dos cosas en el texto: un conteo de proyectos sin producto asociado (son 8) y una frase mía sin respaldo.

Archivos (en `estado/corridas/`):
- `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/construccion/espacio/estado/corridas/salida-steering-pack.md`
