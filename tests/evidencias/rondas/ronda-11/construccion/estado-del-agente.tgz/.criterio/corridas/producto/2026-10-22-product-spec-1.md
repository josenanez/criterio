# Corrida · 2026-10-22-product-spec-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-spec (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:09:57 · **Fin:** 2026-10-22T20:10:57 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-spec` | 15 | — | 45 | 26 | Borrador sobre 13 requerimientos aceptados; sin secciones de comportamiento porque el registro no describe qué pide ninguno; 10 criterios 'se verifica en producción' no verificables, 3 sin criterio; supuesto de licencia sin verificar y con fecha inconsistente; sin proyecto que construya; obligación normativa de la licencia sin identificar. |

Por señal (`product-spec`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 6, `requirement_without_acceptance` 3, `requirement_undecided` 2, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Escribí el borrador de especificación de PRD-305 (Locales comerciales), pero no tiene secciones de comportamiento. Ningún requerimiento del registro dice qué pide: los 15 se llaman solo «Requerimiento REQ-xxxx», y escribir ese comportamiento habría sido inventarlo.

Los términos ya estaban vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22), así que no los registré de nuevo.

- **Cobertura:** el borrador toma los 13 requerimientos aceptados. REQ-4502 y REQ-4511 siguen en `propuesto` y quedan fuera. La tabla final lista los 13 como no cubiertos por ninguna sección de comportamiento, cada uno con su motivo.
- **Criterios de aceptación:** diez dicen «se verifica en producción», que no es verificable porque no fija medida ni umbral. Tres no tienen criterio: REQ-4501, REQ-4506 y REQ-4507.
- **Supuesto:** «La licencia se expide sin sustento» sigue sin verificar y no tiene dueño. Además, está declarado el 2026-09-06 dentro de una definición fechada 2025-09-25. Lo señalo sin resolverlo.
- **Vacíos con dueño:** no hay criterio de éxito del producto, ni contenido en «La propuesta», ni prioridad. Ningún proyecto construye los requerimientos. Hay una obligación normativa sin identificar: la licencia es una autorización de un tercero y ningún documento dice cuál. No hice un barrido normativo completo, porque la definición no toca datos personales ni pagos.
- **Sustento de demanda:** seis requerimientos aceptados no tienen evidencia de que alguien los pidió. El acta del comité de 2026-10-16 tiene un solo asistente, Beatriz Cuéllar, y decide «Se mantiene el plan» aunque no hay plan en los documentos.

No ofrezco `/criterio-product:product-charter`, porque los vacíos siguen abiertos y falta el criterio de éxito.

La corrida quedó registrada como `2026-10-22-product-spec-1` (45 s, 26 señales).

Archivos están en `/tmp/claude-0/-home-claude/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/r11/construccion/espacio/estado-producto/PRD-305/corridas/`:
- `salida-product-spec.md`
