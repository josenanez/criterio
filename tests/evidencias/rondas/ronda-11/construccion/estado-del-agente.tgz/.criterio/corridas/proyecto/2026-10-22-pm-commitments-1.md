# Corrida · 2026-10-22-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-22; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-22T20:16:25 · **Fin:** 2026-10-22T20:17:33 · **Duración:** 68 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 46 | 19 | Reprogramados: Beatriz Cuéllar (6) y Mauricio Pérez (5); 9 vencidos sin evidencia, 4 con 'dice que entregó' sin acta; 3 sin fecha |

Por señal (`pm-commitments`): `commitment_overdue` 9, `commitment_undated` 3, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `vendor_deliverable_late` 2, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — Edificio de oficinas Torre Norte (PRY-201) · al 2026-10-22

Los términos ya estaban vigentes, aceptados el 2026-10-22 por José Francisco Ñáñez. No hubo que registrar nada. Las cifras salen de `compute`, que no trajo `record_issues`.

### Se viene reprogramando
> **Beatriz Cuéllar** · Enviar el documento 1
> Prometido para el 2026-12-25. Antes para el 12-11, el 11-30, el 11-10, el 11-02 y el 10-20. La promesa original, del 09-10, era para el 10-02.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.**
> Según la ficha, Beatriz Cuéllar es la sponsor del proyecto. Su fecha vigente cae diez días después del fin del plan (2026-12-15).

> **Mauricio Pérez** · Cerrar la prueba 2
> Prometido para el 2026-11-13. Antes para el 11-05, el 10-25, el 10-05 y el 09-25. La promesa original era para el 09-16. Son cinco reprogramaciones.

### Vencidos sin evidencia
| Quién | Qué | Hace |
|---|---|---|
| Laura Vélez | Validar el ambiente 4 | 35 días |
| Andrés Lozano | Enviar el documento 9 | 21 días |
| Liliana Torres | Confirmar la fecha 7 | 19 días |
| Carlos Peña | Aprobar el diseño 13 | 10 días |
| María Restrepo | Entregar el punto 8 | 7 días |
| Gustavo Neira | Confirmar la fecha 15 | 7 días |
| Rubén Cárdenas | Enviar el documento 17 | 5 días |
| Gustavo Neira | Actualizar la matriz 22 | 4 días |
| Andrés Lozano | Confirmar la fecha 23 | 3 días |

Laura Vélez, Andrés Lozano (documento 9), Carlos Peña y María Restrepo dicen que ya entregaron. No hay acta ni nada en el expediente que lo respalde, así que siguen abiertos.

### Vencen esta semana
- **Ricardo Salas** · Revisar el anexo 11 · 2026-10-24. Es la segunda fecha (la primera era el 10-10). Dice que ya entregó, pero no hay acta.

### Sin fecha
- **Felipe Arango** · Revisar el anexo 3, dicho el 09-10. Dice que ya entregó, pero no hay acta.
- **Beatriz Cuéllar** · Validar el ambiente 12, dicho el 09-24. Dice que ya entregó, pero no hay acta.
- **Laura Vélez** · Mandar el ajuste del presupuesto, dicho el 10-22.

### Cerrados con documento
- **Javier Hoyos** · Actualizar la matriz 6, cerrado con `20-seguimiento/2026-09-24-acta-recibo-6.md`.
- **Natalia Ospina** · Cerrar la prueba 10, cerrado con `20-seguimiento/2026-10-08-acta-recibo-10.md`.

### Contexto y siguiente paso
- El informe de avance del 10-21 declara estado verde, y no explica ninguna de estas señales.
- **Para el comité del 2026-11-05:** puedo formular como decisión lo de Beatriz Cuéllar y Mauricio Pérez con `/pm-escalate`. La ficha no registra quién tiene la facultad de decidir (`identity.authority` sin encontrar), y eso hay que resolverlo primero.
- `/pm-publish` deja la ficha al día para la PMO.

La salida completa quedó en `estado/PRY-201-edificio-de-oficinas-torre-norte/corridas/salida-pm-commitments.md`. La corrida se registró como `2026-10-22-pm-commitments-1`.
