## Registro — Locales comerciales (PRD-305) · al 2026-10-22
15 requerimientos · 13 decididos · 53.8% con evidencia (7 de 13) · 0% con proyecto que lo ejecuta

> Nota de alcance: no hay fichas de proyectos en el espacio (`estado/` está vacío), así que ningún requerimiento tiene traza confirmada. El 0% dice «sin traza confirmada», no «nadie lo construye».

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió. Van primero.
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4501 | Requerimiento REQ-4501 | aceptado | Andrés Lozano |
| REQ-4504 | Requerimiento REQ-4504 | aceptado | Rubén Cárdenas |
| REQ-4507 | Requerimiento REQ-4507 | aceptado | Paula Céspedes |
| REQ-4508 | Requerimiento REQ-4508 | aceptado | Camilo Beltrán |
| REQ-4509 | Requerimiento REQ-4509 | aceptado | Diana Molina |
| REQ-4513 | Requerimiento REQ-4513 | aceptado | Mauricio Pérez |

### Decidido y nadie lo está construyendo
Los 13 aceptados (REQ-2035, 4500, 4501, 4503, 4504, 4505, 4506, 4507, 4508, 4509, 4510, 4512, 4513) figuran sin proyecto. Todos tienen decisión registrada el 2026-10-16. Sin fichas de proyectos no se puede distinguir «nadie lo construye» de «no se ha cargado la ficha».

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4502 | Requerimiento REQ-4502 | sin doliente (no aparece) |

### Sin criterio de aceptación
Solo los decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-4501 | Requerimiento REQ-4501 | aceptado |
| REQ-4506 | Requerimiento REQ-4506 | aceptado |
| REQ-4507 | Requerimiento REQ-4507 | aceptado |

### Decidido sin documento que lo respalde
No se pudo calcular: el cálculo de esta corrida no trae esa señal y no la invento. Hay que revisar a mano las 13 decisiones del 2026-10-16.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días. Quien tiene la facultad: el Comité de producto (según la configuración), con Beatriz Cuéllar como gerente de producto.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4511 | Requerimiento REQ-4511 | 204 días (desde 2026-04-01) | Comité de producto |
| REQ-4502 | Requerimiento REQ-4502 | 148 días (desde 2026-05-27) | Comité de producto; además sin doliente |

### Evidencia vieja
Ninguna cruza el umbral de 12 meses. Lo más nuevo que sostiene a los requerimientos con evidencia es del 2026-02-03 (hace unos 8 meses).

### Supuesto sin verificar (de la definición)
«La licencia se expide sin objeciones»: 46 días sin verificar (umbral 30).

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 2 | 13 | 0 | 0 | 0 |

Sin descartados registrados: si hubo discusiones cerradas, no están en el registro.
