## Trazabilidad — Locales comerciales (PRD-305) · al 2026-10-22
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Ninguno de los 13 requerimientos aceptados tiene proyecto: la columna «Proyecto que lo ejecuta» del acta del comité está en «—» en las 15 filas (`documentos/productos/PRD-305/30-decisiones/2026-10-16-comite-producto.md`). Los 2 propuestos (REQ-4502, REQ-4511) no están decididos y no entran aquí.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-2035 | Requerimiento REQ-2035 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Óscar Ramírez |
| REQ-4500 | Requerimiento REQ-4500 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Sandra Gil |
| REQ-4501 | Requerimiento REQ-4501 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Andrés Lozano |
| REQ-4503 | Requerimiento REQ-4503 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Carlos Peña |
| REQ-4504 | Requerimiento REQ-4504 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Rubén Cárdenas |
| REQ-4505 | Requerimiento REQ-4505 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Ricardo Salas |
| REQ-4506 | Requerimiento REQ-4506 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Óscar Ramírez |
| REQ-4507 | Requerimiento REQ-4507 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Paula Céspedes |
| REQ-4508 | Requerimiento REQ-4508 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Camilo Beltrán |
| REQ-4509 | Requerimiento REQ-4509 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Diana Molina |
| REQ-4510 | Requerimiento REQ-4510 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Paula Céspedes |
| REQ-4512 | Requerimiento REQ-4512 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Elena Duarte |
| REQ-4513 | Requerimiento REQ-4513 | 2026-10-16 | Comité de producto (asistente registrado: Beatriz Cuéllar); doliente: Mauricio Pérez |

El acta registra «Se mantiene el plan» como única decisión y la tabla con estado «aceptado»; no dice quién aceptó cada requerimiento ni nombra un proyecto. Cada eslabón decisión → proyecto está roto en el primero, así que no hay entregables que trazar.

### La traza no se confirma
Ninguna: no hay requerimiento con proyecto declarado, así que no hay traza que confirmar ni desmentir.

### Lo que un proyecto construye y el registro no tiene
Ninguno detectable con lo que hay a la vista. La única ficha disponible, PRY-201 (`ficha-pm.json`), dice que ejecuta «arriendo de oficinas» (acta de constitución del 2026-04-15), no este producto. Eso es lo esperable, no una brecha.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2035 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4500 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4501 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4503 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4504 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4505 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4506 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4507 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4508 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4509 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4510 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4512 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4513 | aceptado | comité 2026-10-16 | — | no | — |
| REQ-4502 | propuesto | sin decidir (148 días) | — | no | — |
| REQ-4511 | propuesto | sin decidir (204 días) | — | no | — |

### Sin fichas a la vista
Solo hay una ficha de proyecto (PRY-201) para los 12 proyectos de la carpeta (PRY-199 a PRY-211). Para los otros 11 no se puede confirmar nada. Como ningún requerimiento nombra proyecto, el hueco que importa es otro: si alguno de esos 11 ejecuta este producto, su ficha no está publicada y no se puede ver desde aquí.

Aparte: 6 de los 13 decididos están aceptados sin evidencia de demanda y 3 sin criterio de aceptación; es material de `/product-requirements`, no de la traza.

Siguiente paso: `/criterio-product:product-charter` para el primer requerimiento que Beatriz Cuéllar considere listo para volverse proyecto.
