# Corrida del 2026-10-22 · product-setup

PRD-305 · 15 requerimientos · 22 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

0 preguntas respondidas por la persona (sesión sin interfaz, respuestas sugeridas); sin cronómetro de minutos; 4 documentos, 15 requerimientos levantados; falta criterio de éxito, serie de la métrica y proyecto para los 13 aceptados

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Locales comerciales (PRD-305)

**Lo que miré:** 4 documentos · 1 de descubrimiento (entrevistas del 2026-02-03) · la definición del 2025-09-25 (.docx) y el caso de negocio de la misma fecha · el acta del comité de producto del 2026-10-16. No hay serie de métricas. Todos los formatos se pudieron leer.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2), 2026-10-22 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 2e5e5e39f9a3bd66… (md) y 01ee10fce067d8f7… (pdf)
**Configuración:** `.criterio/producto/PRD-305/config.json` · estado en `estado-producto/PRD-305` · gerente: Beatriz Cuéllar · decide: Comité de producto (propuesto; ningún documento lo dice con esas palabras, solo que el comité revisa y acepta los requerimientos).
**Marca de la carpeta (`_CRITERIO_PRODUCTO.txt`):** no la dejé; no hubo un sí de la persona y es lo único que se escribiría dentro de los documentos.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Entidades públicas no tiene locales comerciales | Nada: la definición lo dice y no cita entrevista ni dato. La única entrevista dice «Lo necesito y hoy no lo tengo», sin decir qué ni quién | 2025-09-25 (definición) · 2026-02-03 (entrevista) |
| Propuesta principal | Solo el título; no dice qué se propone | 2025-09-25 |
| volumen_mensual = 214.841 | El propio caso de negocio, como fuente de sí mismo. Sin serie medida | 2025-09-25 |
| Retorno esperado en 24 meses | Sin cifra ni base | 2025-09-25 |
| La licencia se expide sin objeciones | Supuesto declarado, sin verificar | declarado 2026-09-06 |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito:** ninguno. No se podrá cerrar el producto contra nada.
- **Quién decide qué se construye:** ningún documento lo nombra; el acta de comité solo lista como asistente a Beatriz Cuéllar.
- **Medición de volumen_mensual (214.841):** no hay ninguna serie, así que nadie está midiendo lo que el negocio afirmó.
- **Qué es la «propuesta principal»** y **de dónde sale el retorno a 24 meses.**
- **Proyecto que ejecute cualquiera de los 15 requerimientos:** 13 aceptados, 0 con proyecto (0.0 % con traza). La definición dice «Ninguno declarado».
- **Quién pidió qué:** la entrevista no nombra requerimiento alguno. Los 7 requerimientos aceptados con «Cliente entrevistado» (53.8 % de los 13 decididos tienen evidencia) se apoyan en una sola cita genérica.
- **Requerimientos aceptados sin evidencia (6):** REQ-4501, REQ-4504, REQ-4507, REQ-4508, REQ-4509, REQ-4513.
- **Aceptados sin criterio de aceptación (3):** REQ-4501, REQ-4506, REQ-4507. REQ-4501 y REQ-4507 no tienen ni criterio ni evidencia.
- **Sin doliente:** REQ-4502 («sin asignar»), propuesto hace 148 días.
- **Propuestos sin decidir:** REQ-4502 (148 días) y REQ-4511 (204 días), con un acta que solo dice «Se mantiene el plan».
- **Los 15 requerimientos se llaman «Requerimiento REQ-xxxx»:** ningún documento dice qué problema es cada uno.

### Supuestos sobre los que está escrita
Uno: «La licencia se expide sin objeciones», sin verificar, 46 días desde que se declaró. Dato raro: su fecha (2026-09-06) es posterior a la de la definición (2025-09-25), así que alguien editó el documento sin cambiar la fecha, o la fecha está mal.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: las transcripciones completas de las entrevistas (hay una sola ronda, de una sola persona entrevistada); la serie de volumen_mensual con su fuente; el criterio de éxito; un documento que nombre quién decide; y la verificación del supuesto de la licencia (otros productos tienen su `verificacion-supuesto`; este no). La carpeta sigue la estructura recomendada (`00-definicion`, `10-descubrimiento`, `30-decisiones`) salvo que falta `20-metricas`.

**Después:** `/product-discovery` sobre las entrevistas, para ver qué dijo realmente el cliente y a qué requerimiento corresponde.
