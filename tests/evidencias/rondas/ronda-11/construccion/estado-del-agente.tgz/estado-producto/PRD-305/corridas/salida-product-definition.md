## Definición — Locales comerciales (PRD-305) · contrastada al 2026-10-22
**Documento:** 00-definicion/2025-09-25-definicion-producto.docx (con el caso de negocio del mismo día) · **del** 2025-09-25 · 5 afirmaciones

Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-22; no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de la definición. Eso no significa que la sostengan: ver más abajo.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa del umbral (20 %): no hay serie medida con la que comparar. |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 214.841 | 00-definicion/2025-09-25-caso-de-negocio.md (2025-09-25) | No hay ninguna serie de `volumen_mensual`. Es la única cifra del caso de negocio y lleva 13 meses sin medirse. |

### No está dicho en ninguna parte
- **El criterio de éxito.** No existe en ningún documento (`success` = not_found).
- **El tamaño del problema.** La definición dice que Entidades públicas "no tiene locales comerciales", pero no dice cuántas entidades ni cuántos locales.
- **La propuesta.** La sección dice solo "Propuesta principal", sin contenido: no hay propuesta enunciada.
- **El retorno.** El caso de negocio dice "Retorno esperado en 24 meses" sin cifra, base ni supuestos.
- **Cuánto pagaría el cliente, o si alguien ya pagó.** No hay ninguna evidencia de pago ni de precio.
- **Los proyectos que lo construyen.** La definición declara "Ninguno", pero el comité del 2026-10-16 tiene 13 requerimientos aceptados sin proyecto que los ejecute.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La licencia se expide sin objeciones | 46 (declarado el 2026-09-06, umbral 30) | Nombrar qué licencia y qué autoridad la expide; pedir a esa autoridad el requisito y el plazo por escrito, o un precedente de expedición a una entidad pública, y fijar quién lo verifica y para cuándo. Redactado así, "sin objeciones" es difícil de desmentir: conviene un criterio concreto, por ejemplo "expedida en N días". |

Nota: el docx tiene fecha 2025-09-25 pero registra un supuesto "declarado el 2026-09-06". El documento se editó después de su fecha, o la fecha del supuesto es un error. Debe aclararlo su autora.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene locales comerciales | 10-descubrimiento/2026-02-03-entrevistas.md: un cliente entrevistado dijo "Lo necesito y hoy no lo tengo" | 2026-02-03 | Débil. Es una voz anónima, "dijo que lo necesita" (lo más bajo de la jerarquía). No dice que sea una entidad pública. No hay pago, compromiso ni segunda fuente. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento no tiene locales comerciales | Entrevista del 2026-02-03 | ~8,6 meses. Aún no pasa el umbral de 12 meses; lo cruza el 2027-02-03. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Licencia que condiciona el producto (supuesto) | no declarado | No sé cuál es | — | No tengo la norma a la vista: la definición no dice país ni qué licencia. No hay datos personales, pagos ni retención de información declarados. Esto no dice que cumpla ni que no cumpla. |

Va a revisión jurídica una vez se sepa qué licencia y en qué país.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. **Sin él el producto no se puede cerrar**, porque el cierre se juzga contra él meses después.
- **Problema:** está (2025-09-25), pero sin tamaño.
- **Para quién:** Entidades públicas (2025-09-25), sin segmentar ni cuantificar.
- **Quién decide:** Comité de producto (acta del 2026-10-16). Gerente: Beatriz Cuéllar.

### Después
- El supuesto de la licencia lleva 46 días sin verificar. Se ofrece convertirlo en riesgo con doliente (raid-taxonomy).
- La definición no está cerrada (sin criterio de éxito), por lo que **no se ofrece `/product-charter`** todavía.
