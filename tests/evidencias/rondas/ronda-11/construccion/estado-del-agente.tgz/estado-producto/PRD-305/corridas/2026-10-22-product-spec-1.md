# Corrida del 2026-10-22 · product-spec

PRD-305 · 15 requerimientos · 45 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador sobre 13 requerimientos aceptados; sin secciones de comportamiento porque el registro no describe qué pide ninguno; 10 criterios 'se verifica en producción' no verificables, 3 sin criterio; supuesto de licencia sin verificar y con fecha inconsistente; sin proyecto que construya; obligación normativa de la licencia sin identificar.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

> **Borrador de trabajo, no una especificación aprobada.** Lo cierra Beatriz Cuéllar (gerente de producto, PRD-305) ante el Comité de producto; este agente no aprueba.

# Especificación — Locales comerciales (PRD-305) · borrador del 2026-10-22

## Qué problema resuelve

«El segmento Entidades públicas no tiene locales comerciales.» (definición de producto, 2025-09-25, `00-definicion/2025-09-25-definicion-producto.docx`). Segmento: Entidades públicas.

La definición **no dice** qué es el producto: su sección «La propuesta» contiene solo el rótulo «Propuesta principal». Tampoco hay criterio de éxito del producto (`success`: no encontrado).

## Alcance

El registro tiene 15 requerimientos: 13 `aceptado` y 2 `propuesto`. Esta especificación toma los 13 aceptados.

### Entra
Nada se puede describir todavía como comportamiento. Los 13 requerimientos aceptados llevan como título el texto «Requerimiento REQ-xxxx» y ninguna descripción de lo que piden. Escribir qué hace cada uno sería inventarlo.

Los 13 que entran por estado: REQ-4500, 4501, 4503, 4504, 4505, 4506, 4507, 4508, 4509, 4510, 4512, 4513 y 2035.

### No entra
- **REQ-4502** (`propuesto`, sin doliente, desde 2026-05-27): nadie lo decidió.
- **REQ-4511** (`propuesto`, doliente Mauricio Pérez, desde 2026-04-01): nadie lo decidió.
- Todo lo que la definición no menciona. No hay proyecto, plan ni entregable declarado.
- Diseño técnico, estimación de esfuerzo, costo y fechas: no se tocan aquí.

## Comportamiento

**Sin secciones de comportamiento.** El registro no trae, para ningún requerimiento aceptado, qué debe hacer el producto. Lo único que hay por requerimiento es doliente, estado, fecha y la frase de aceptación. Las secciones se escriben cuando el doliente de cada uno describa el requerimiento; hoy serían texto del agente sin respaldo en ningún documento.

## Criterios de aceptación

Los 10 que tienen criterio dicen todos lo mismo: «se verifica en producción» (acta del Comité, 2026-10-16). **Ese texto no pasa la prueba:** dos personas mirando lo construido no pueden llegar a la misma respuesta, porque no dice qué se mide ni contra qué valor. Es un lugar, no un criterio.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4500 (Sandra Gil) | No definido | No verificable: sin medida ni umbral |
| «se verifica en producción» | REQ-4503 (Carlos Peña) | No definido | No verificable |
| «se verifica en producción» | REQ-4504 (Rubén Cárdenas) | No definido | No verificable |
| «se verifica en producción» | REQ-4505 (Ricardo Salas) | No definido | No verificable |
| «se verifica en producción» | REQ-4508 (Camilo Beltrán) | No definido | No verificable |
| «se verifica en producción» | REQ-4509 (Diana Molina) | No definido | No verificable |
| «se verifica en producción» | REQ-4510 (Paula Céspedes) | No definido | No verificable |
| «se verifica en producción» | REQ-4512 (Elena Duarte) | No definido | No verificable |
| «se verifica en producción» | REQ-4513 (Mauricio Pérez) | No definido | No verificable |
| «se verifica en producción» | REQ-2035 (Óscar Ramírez) | No definido | No verificable |
| **Sin criterio** | REQ-4501 (Andrés Lozano) | — | — |
| **Sin criterio** | REQ-4506 (Óscar Ramírez) | — | — |
| **Sin criterio** | REQ-4507 (Paula Céspedes) | — | — |

Además, no hay indicio en los documentos de que la organización mida algo en producción para este producto. No hay serie medida, solo la cifra declarada de `volumen_mensual` (214.841, caso de negocio de 2025-09-25) sin unidad ni medición que la respalde.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La licencia se expide sin objeciones» (definición de producto; declarado el 2026-09-06) | **No** | Sin dueño en los documentos. Propuesto: Beatriz Cuéllar lo asigna |

Dos observaciones sobre este supuesto:
- La definición está fechada 2025-09-25 y el supuesto dice «declarado el 2026-09-06»: casi un año después de la fecha del documento. O el documento se editó después sin cambiar su fecha, o la fecha está mal. No lo resuelvo; lo señalo.
- Si la licencia no se expide, no es evidente qué requerimiento aceptado sigue en pie. El registro no lo relaciona con ninguno (todos tienen `assumptions` vacío).

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué pide cada requerimiento (títulos y descripciones son solo el código) | No se puede escribir comportamiento ni diseñar prueba alguna | Cada doliente; ver tabla de criterios |
| Criterio de aceptación de REQ-4501, REQ-4506, REQ-4507 | Se aceptaron sin forma de saber cuándo están hechos | Andrés Lozano, Óscar Ramírez, Paula Céspedes |
| Criterio medible en lugar de «se verifica en producción» (10 requerimientos) | La discusión de si quedó bien ocurre después de construirlo | Los dolientes de cada uno, con Beatriz Cuéllar |
| Criterio de éxito del producto | No hay contra qué juzgar el conjunto | Beatriz Cuéllar |
| Contenido de «La propuesta» de la definición | La definición no dice qué se ofrece al segmento | Beatriz Cuéllar |
| Comportamiento en casos borde (falla de la licencia, solicitud duplicada, entidad que abandona el trámite, etc.) | Lo decide quien construya, no quien lo pidió. No hay texto de requerimiento del cual derivarlo | Dolientes, con el Comité de producto |
| Prioridad (no encontrada en ninguno de los 15 requerimientos) | No hay orden de construcción | Comité de producto |
| Quién construye: `traces.project` es nulo en los 15 y la definición dice «Ninguno declarado» | Requerimientos aceptados que ningún proyecto ejecuta; tampoco hay equipo externo acordado | Beatriz Cuéllar / Comité de producto |
| Obligaciones normativas | Ver nota abajo | Beatriz Cuéllar (asigna revisión jurídica) |

**Nota normativa.** No hice un barrido normativo completo: la definición no menciona datos personales, pagos ni consumidor financiero, que son los temas que dispara ese barrido. Pero el supuesto de la licencia indica que hay una autorización de un tercero de la que depende el producto, y ningún documento dice cuál, quién la otorga ni qué exige. Queda como obligación sin identificar, no como «no hay obligaciones».

**Respaldo de la demanda (contexto, no hueco de especificación):** seis requerimientos aceptados no tienen evidencia de solicitud en el registro (REQ-4501, 4504, 4507, 4508, 4509, 4513). Los otros siete aceptados citan la entrevista del 2026-02-03, cuya cita («Lo necesito y hoy no lo tengo») no nombra ningún requerimiento; la atribución viene del acta. El acta de 2026-10-16 registra como único asistente a Beatriz Cuéllar, y su única decisión es «Se mantiene el plan», aunque no hay plan en los documentos.

## Requerimientos aceptados que esta especificación no cubre

Ninguna sección de comportamiento cubre ninguno: la razón es la misma para todos (el registro no describe qué piden), más lo propio de cada uno.

| ID | Título | Por qué no |
|---|---|---|
| REQ-2035 | Requerimiento REQ-2035 | Sin descripción; criterio no verificable |
| REQ-4500 | Requerimiento REQ-4500 | Sin descripción; criterio no verificable |
| REQ-4501 | Requerimiento REQ-4501 | Sin descripción; sin criterio; sin evidencia de solicitud |
| REQ-4503 | Requerimiento REQ-4503 | Sin descripción; criterio no verificable |
| REQ-4504 | Requerimiento REQ-4504 | Sin descripción; criterio no verificable; sin evidencia |
| REQ-4505 | Requerimiento REQ-4505 | Sin descripción; criterio no verificable |
| REQ-4506 | Requerimiento REQ-4506 | Sin descripción; sin criterio |
| REQ-4507 | Requerimiento REQ-4507 | Sin descripción; sin criterio; sin evidencia |
| REQ-4508 | Requerimiento REQ-4508 | Sin descripción; criterio no verificable; sin evidencia |
| REQ-4509 | Requerimiento REQ-4509 | Sin descripción; criterio no verificable; sin evidencia |
| REQ-4510 | Requerimiento REQ-4510 | Sin descripción; criterio no verificable |
| REQ-4512 | Requerimiento REQ-4512 | Sin descripción; criterio no verificable |
| REQ-4513 | Requerimiento REQ-4513 | Sin descripción; criterio no verificable; sin evidencia |

## Después

`/criterio-product:product-charter` no está listo: la especificación quedó con los vacíos abiertos, y el producto no tiene criterio de éxito.

---
*Registro: `estado-producto/PRD-305/requirements/` (15 requerimientos, registro actualizado el 2026-10-22; acta del comité del 2026-10-16). Cubre 13 requerimientos aceptados por estado, y ninguno con comportamiento escrito. Términos de uso: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0 (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22).*
