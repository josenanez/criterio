# Caso de negocio — Locales comerciales (PRD-305) · borrador del 2026-10-22
**Desde:** la definición del 2025-09-25 (`00-definicion/2025-09-25-definicion-producto.docx`, tal como quedó en la ficha `producto.json`) y el caso de negocio del mismo día · **Cifras con fuente:** 1 de 1 (la única cifra tiene fuente, pero es declarada y sin serie que la mida)

Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-22; no hizo falta registrarlos de nuevo.

**Lectura corta:** esto es una propuesta, no un caso de negocio evaluable. No hay costo de construir en ningún documento, no hay criterio de éxito, y la única cifra es un volumen declarado que nadie mide. Este borrador arma la estructura y nombra los vacíos; no produce ni completa ninguna cifra.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Entidades públicas no tiene locales comerciales.» (definición, 2025-09-25). Sin tamaño: no dice cuántas entidades ni cuántos locales.
- **Para quién:** Entidades públicas (definición, 2025-09-25), sin segmentar ni cuantificar.
- **Propuesta:** la sección «Propuesta principal» de la definición está vacía. No hay propuesta enunciada.

## Qué se construye
Alcance: los 13 requerimientos aceptados el 2026-10-16 (`30-decisiones/2026-10-16-comite-producto.md`). Los 2 propuestos (REQ-4502, REQ-4511) quedan fuera del caso hasta que se decidan.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4500 | aceptado | «Lo necesito y hoy no lo tengo.» Cliente entrevistado, 2026-02-03 (`10-descubrimiento/2026-02-03-entrevistas.md`). El acta lo atribuye a este requerimiento; la entrevista no nombra cuál. |
| REQ-4503, 4505, 4506, 4510, 4512, REQ-2035 | aceptado | La misma cita única, atribuida por el acta a cada uno; la entrevista no nombra requerimiento. |
| REQ-4501, 4504, 4507, 4508, 4509, 4513 | aceptado | **Ninguna.** Aceptados sin cita de quién los pidió. |

Resumen: 7 de 13 con evidencia, y toda sale de una sola frase de una voz anónima. 3 de los 13 (REQ-4501, 4506, 4507) no tienen criterio de aceptación. Ninguno tiene proyecto que lo ejecute según las fichas; pero no hay fichas de proyectos cargadas (`estado/` está vacío), así que eso es «sin traza confirmada», no «nadie lo construye».

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 214.841 | **Declarada** | `00-definicion/2025-09-25-caso-de-negocio.md`, tabla «Cifras que sostienen el caso», preparada por Beatriz Cuéllar | 2025-09-25 |

Clase **medida**: ninguna. No hay serie de `volumen_mensual` ni de ninguna otra métrica del producto.
Clase **supuesta**: ninguna se declaró como cifra, pero el caso menciona «Retorno esperado en 24 meses» sin valor, base ni supuestos. Eso no es una cifra: es una frase que parece una. No entra a la tabla.

Además, el caso no dice qué es lo que se cuenta (¿transacciones, locales, solicitudes?) ni en qué unidad. Quien la produce debe aclararlo antes de que alguien la cite.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 214.841 | — | No hay medida con la que comparar. La declarada lleva 13 meses (2025-09-25 a 2026-10-22) sin contrastarse. Umbral de diferencia configurado: 20 %. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — |
| Costo del equipo | No está | — |
| Contratos, cotizaciones | No hay | — |

**Este es el primer vacío.** Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La licencia se expide sin objeciones» (declarado el 2026-09-06, sin verificar: 46 días, umbral 30) | No se puede operar el producto; el volumen declarado y el retorno quedan sin base. | Sin nombrar. Hay que decir qué licencia, qué autoridad y en qué país. |
| Que Entidades públicas sea el segmento que necesita el producto | La única evidencia (entrevista del 2026-02-03) no dice que el cliente entrevistado sea una entidad pública. | Beatriz Cuéllar, que hizo las entrevistas. |

Nota: el docx tiene fecha 2025-09-25 pero registra un supuesto «declarado el 2026-09-06». O se editó después, o la fecha es un error; lo aclara su autora.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso que evaluar. | El negocio (Beatriz Cuéllar / Comité de producto) |
| Retorno: cifra, base y supuestos | «Retorno esperado en 24 meses» no es verificable. | El negocio |
| Qué mide `volumen_mensual`, y de dónde sale el 214.841 | Única cifra del caso; 13 meses sin serie. | El negocio; el sistema donde el producto vive, para la serie |
| Criterio de éxito | Sin él el producto no se puede cerrar. | Comité de producto |
| Tamaño del problema (cuántas entidades, cuántos locales) | No se puede dimensionar nada. | El negocio |
| Propuesta principal | La sección está vacía. | Beatriz Cuéllar |
| Cuánto pagaría el cliente, o si alguien ya pagó | No hay evidencia de precio ni de pago. | El negocio |
| Qué pasa si no se hace | No está dicho. | El negocio |
| Alternativas consideradas | No están dichas. | El negocio |
| Licencia, autoridad y país | Sin ellos no hay revisión jurídica posible. | El negocio, luego jurídica |
| Fichas de proyectos | Sin ellas no se sabe si los 13 aceptados se construyen. | Quien lleve los proyectos |

## Cómo se sabrá si funcionó
**No está declarado.** No existe criterio de éxito en ningún documento. Sin métrica y fecha de corte, el criterio no se puede verificar meses después. El volumen mensual declarado podría servir de métrica, pero requiere que alguien diga qué cuenta y desde qué sistema se mide.

## Si hay otros productos publicados
No hay ninguno a la vista (`estado/` está vacío). No se pudo hacer el cruce de `/product-overlap`: queda pendiente cuando se publique otro producto, para detectar si cuenta las mismas transacciones.

## Después
- Se ofrece pasar los dos supuestos al seguimiento con **assumption-tracking**: el de la licencia lleva 46 días sin verificar.
- No se ofrece `/product-charter`: la definición no está cerrada (sin criterio de éxito) y el caso carece de costos.
- Este documento no recomienda aprobar ni rechazar; esa decisión es del Comité de producto.
