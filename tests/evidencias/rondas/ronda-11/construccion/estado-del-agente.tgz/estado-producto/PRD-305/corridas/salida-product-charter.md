Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22): no se vuelven a pedir.

**Verificación previa (REQ-4500).** Aceptado: sí (comité 2026-10-16). Criterio de aceptación: existe, pero débil. Evidencia de demanda: existe, una sola cita. Autoridad en la definición: **no está declarada**. Pregunta sugerida «¿seguir sin lo que falta, marcándolo como vacío del acta?»: sí, se sigue y cada falta queda en «Vacíos de este acta».

# Acta de constitución — Locales comerciales (REQ-4500) · borrador del 2026-10-22
**Producto:** PRD-305 · Locales comerciales · **Requerimientos:** REQ-4500

## Qué problema resuelve
«El segmento Entidades públicas no tiene locales comerciales.» (`documentos/productos/PRD-305/00-definicion/2025-09-25-definicion-producto.docx`, 2025-09-25). La definición no dice qué pide REQ-4500 en concreto: su título es el genérico «Requerimiento REQ-4500» y no tiene `need` registrado (`documentos/productos/PRD-305/30-decisiones/2026-10-16-comite-producto.md`).

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `30-decisiones/2026-10-16-comite-producto.md` | **No está dicho.** Indica dónde se verifica, no qué se mide, con qué umbral ni quién lo mide. No se redacta por el proyecto. |

El éxito de la definición del producto (`definition.success`) está en `not_found`: ningún documento lo afirma.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4500 | «Requerimiento REQ-4500» (sin título propio en la fuente) | «Lo necesito y hoy no lo tengo.» — Cliente entrevistado, tema «Necesidad principal», 2026-02-03 (`10-descubrimiento/2026-02-03-entrevistas.md`). **El acta del comité lo atribuye a REQ-4500; la entrevista no nombra cuál requerimiento.** Es una entrevista, evidencia media, anónima, de hace ~8,5 meses (umbral de envejecimiento: 12). |

### No entra
Esta acta cubre solo REQ-4500. El resto del registro queda fuera por no haberse pedido; ninguna exclusión de alcance está declarada en un documento del producto, y no se inventa una razón de fondo.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4501, 4503, 4504, 4505, 4506, 4507, 4508, 4509, 4510, 4512, 4513, 2035 | «Requerimiento REQ-xxxx» | Aceptados en el comité de 2026-10-16, pero no incluidos en esta acta por no haberse pedido en la invocación. Pueden constituirse aparte o sumarse con otra acta; eso lo decide quien tiene la autoridad. |
| REQ-4502, REQ-4511 | «Requerimiento REQ-xxxx» | Siguen en estado `propuesto`; sin decisión no hay acta (REQ-4502 además sin doliente). |

## Gobierno
- **Patrocinador:** no está dicho en ninguna parte.
- **Gerente propuesto:** no se nombra. Quien asigna a una persona es quien tiene la autoridad. Como dato: la gerente del *producto* es Beatriz Cuéllar (definición, 2025-09-25); no se sabe si dirigirá también el proyecto.
- **Comité:** Comité de producto (`30-decisiones/2026-10-16-comite-producto.md`). El acta lista como único asistente a Beatriz Cuéllar y no registra quién decidió.
- **Autoridad del gerente del proyecto:** no está dicha (monto, cambio de alcance, escalamiento). La definición no la declara; la única mención de autoridad es el nombre del comité.
- **Doliente de REQ-4500:** Sandra Gil (persona), según el acta del comité.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La licencia se expide sin objeciones» (definición; declarado el 2026-09-06, y el documento es del 2025-09-25: las dos fechas no cuadran) | No. Sin cita que lo verifique. Lleva más de 30 días sin verificar (umbral `assumption_unverified_days`). | **Sin doliente asignado.** Se registra con raid-taxonomy como riesgo del proyecto; la valoración y el doliente los pone el gerente. Queda además en el registro de producto con la marca de que se escaló. |
| REQ-4500 no tiene supuestos propios registrados | — | — (no se asumen supuestos que nadie declaró) |

Para verificarlo haría falta una respuesta escrita de la entidad que expide la licencia; este agente no la gestiona.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Licencia de los locales (mencionada en el supuesto) | No identificada | Ninguna citada en los documentos | Sin barrido. No se opina sobre cumplimiento ni se infiere la norma. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad del gerente del proyecto | Todo cambio de alcance o gasto sube al comité, o nadie sabe si puede decidirlo | Comité de producto |
| Patrocinador con nombre | Nadie respalda el proyecto ni desbloquea | Comité de producto |
| Criterio de éxito medible (solo «se verifica en producción») | El cierre no podrá juzgarse contra nada concreto | Sandra Gil con Beatriz Cuéllar |
| Éxito del producto (`definition.success`) | El proyecto no se puede atar a un resultado del producto | Beatriz Cuéllar |
| Título y necesidad propios de REQ-4500 | No se sabe qué se construye | Sandra Gil |
| Evidencia que nombre a REQ-4500 | La demanda descansa en una cita anónima que el acta atribuye sin que la entrevista lo diga | Beatriz Cuéllar |
| Decisor del acta de comité y plan citado | «Se mantiene el plan» no remite a ningún plan en los documentos; solo consta un asistente | Comité de producto |
| Cifra del caso de negocio (214.841 mensuales) | Sin serie medida en `metrics/`; el retorno «en 24 meses» no trae monto. Se llevan como declaradas por el negocio, no como medidas | Beatriz Cuéllar |
| Prioridad | `not_found` | Beatriz Cuéllar |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (hoy sin nombrar: ver Patrocinador). La ficha del proyecto se crea después de la firma; no se creó y no se escribió `declared`.

## A quién le queda
El proyecto necesita un gerente, y desde la firma la ficha es suya. Instala `criterio-project` y corre primero `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza REQ-4500 → proyecto y Alba sabrá si el producto se construye.
