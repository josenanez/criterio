# Corrida del 2026-10-22 · pm-escalate

1 proyectos · 52 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 9 |
| `commitment_undated` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `declared_vs_evidence` | 1 |

Paquete con 3 puntos: autoridad no declarada en el acta, compromiso 'documento 1' con 6 reprogramaciones, 'prueba 2' con 5. No corrí impact porque ningún punto mueve una fecha del plan. Sin saber: qué es el documento 1, el costo de las opciones, quién decide por el proveedor, y por qué el ejecutado supera al comprometido.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

*Sesión sin interfaz: nadie respondió preguntas. No venía tema en el argumento, así que armé el paquete con lo que ya está marcado como escalable en la ficha y en el informe del 2026-10-22. Términos v1.2 (criterio-project 0.8.0) vigentes, aceptados el 2026-10-22 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal*

# Para decisión — Edificio de oficinas Torre Norte (PRY-201) · 2026-10-22

Gerente: Diana Molina · Patrocinador: Beatriz Cuéllar · Comité: Comité de Inversiones (próximo: 2026-11-05).

**El acta no declara la autoridad del gerente.** Por eso el primer punto es ese y no el que venías a subir. Mientras no esté resuelto, no puedo decir de ningún otro punto si excede o no al gerente: los marco como «escala por umbral de la PMO» y no como «excede tu autoridad».

---

## Punto 1 — ¿Se declara por escrito qué puede decidir la gerente de PRY-201?

**Quién decide:** el órgano que aprobó el acta, el Comité de Inversiones (2026-04-15), o la patrocinadora Beatriz Cuéllar si el comité se lo delega. Esto último lo infiero del acta; el acta no lo dice. · **Si no se decide hoy:** no hay fecha de vencimiento propia, pero cada decisión pendiente del proyecto queda sin destinatario claro. El hito «Estructura terminada» vence el 2026-10-29, seis días antes del comité del 2026-11-05, y con el ensayo de concreto fallido abierto es el primer punto que podría necesitar una decisión antes de esa sesión.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta con la autoridad de la gerente (montos, fechas, proveedor) | Ninguno | Lo que tarde la firma; antes del 2026-11-05 si la patrocinadora lo hace por su cuenta | Sin sobrecosto. No tengo cifra de horas |
| B. Dejarlo como está | Ninguno | Cada punto con duda va al comité, cada dos semanas | Sin costo directo declarado. Los puntos del proveedor quedan en espera |

**Recomiendo:** A. Sin esa línea, la gerente escala todo o no escala nada, y no hay base para devolver un punto mal dirigido.

---

## Punto 2 — ¿Se mantiene «Enviar el documento 1» con una fecha tope anterior al cierre, o se retira?

**Quién decide:** el comité. El compromiso es de la patrocinadora, y a ella no le puede fijar fecha la gerente. · **Si no se decide hoy:** vuelve a reprogramarse en la reunión del 2026-11-05. La fecha vigente, 2026-12-25, cae diez días después del cierre del proyecto (2026-12-15).

Historial (todas las fechas salen de las actas de comité y de las notas del 22-oct): original 2026-10-02 → 10-20 → 11-02 → 11-10 → 11-30 → 12-11 → 12-25. Seis reprogramaciones; el umbral es 3.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mantener con fecha tope anterior al 2026-12-15 | Se conserva | La fecha la fija el comité | No lo sé. |
| B. Retirar el compromiso | Se pierde lo que dé el documento | Cierra el ítem | No lo sé. |
| C. Cambiar de responsable | Se conserva | Arranque desde cero con otra persona | No lo sé. |

**No sé qué es el «documento 1» ni qué bloquea.** Los documentos solo lo nombran. Sin eso no puedo poner costo a ninguna opción, y ninguna opción tiene costo declarado por mí. Alguien tiene que decir qué bloquea antes de la sesión.

**Recomiendo:** A con tope anterior al cierre, y que el comité diga qué cuenta como entregado. Con un compromiso que se ha corrido seis veces, otra fecha sin consecuencia declarada se corre también.

---

## Punto 3 — ¿Se mantiene «Cerrar la prueba 2» (Mauricio Pérez) para el 2026-11-13, o se reasigna?

**Quién decide:** por determinar (punto 1). · **Si no se decide hoy:** vuelve a correrse el 2026-11-13. Cinco reprogramaciones: 2026-09-16 → 09-25 → 10-05 → 10-25 → 11-05 → 11-13.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mantener 2026-11-13 | Igual | 58 días sobre el original | No lo sé |
| B. Reasignar | Igual | No lo sé | No lo sé |

**Recomiendo:** A, con revisión en la próxima sesión. No tengo evidencia de por qué se corrió cada vez, así que reasignar sería adivinar.

---

## A quién alcanza

No calculé el efecto con `portafolio.py impact`: nada de lo anterior mueve una fecha del plan. Las tres decisiones son de gobierno y de compromisos; el cierre sigue en 2026-12-15. Si la decisión del punto 2 o 3 mueve una fecha del cronograma, hay que correr el cálculo con los días en cuestión. **Sin ese cálculo no sé qué proyectos quedan alcanzados.** El acta declara «Dependencias: ninguna declarada», así que tampoco hay una dependencia que confirmar.

## Mis hitos por los que pasa

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Estructura terminada | 2026-10-29 | Sin cambio propuesto |
| Entrega de obra al cliente | 2026-12-15 | Sin cambio propuesto |

## Qué no escala todavía, y por qué

- **Proveedor Interventorías Técnicas S.A.S. (CT-521):** acero de refuerzo vencido hace 116 días y bolsa de horas hace 51; ninguno con acta de recibo. No sé si excede al gerente: depende del punto 1. Si la adenda dice que puede exigir al proveedor, es suya la llamada.
- **Ejecutado (501.908.947 COP) mayor que comprometido (269.031.166 COP):** una de las dos cifras está mal o salen de criterios distintos. Es una aclaración del que lleva el presupuesto, no una decisión. Laura Vélez tiene pendiente «Mandar el ajuste del presupuesto» sin fecha.
- **Riesgos e incidencia sin dueño (3 y 1):** nombrar dueño es del gerente.
- **Desviación de costo (+1,7 %):** bajo el umbral de 10 %. No escala.

## De dónde sale esto

- Autoridad no declarada: `00-gobierno/2026-04-15-acta-constitucion.md` (sin sección de autoridad; ficha `identity.authority`: no encontrada).
- Documento 1: `30-reuniones/2026-09-10-comite-semanal.md` (origen) y reprogramaciones en las actas del 09-17, 09-24, 10-01, 10-08 y 10-15, más `2026-10-22-notas-reunion.txt` (fecha 25/12/2026).
- Prueba 2: `30-reuniones/2026-09-10-comite-semanal.md` y reprogramaciones en las cinco actas siguientes.
- Hitos y cierre: `10-plan/2026-04-15-cronograma-v1.xlsx`. Cifras: `20-seguimiento/2026-10-21-informe-avance.md`. Fecha del próximo comité: `config.json`.

**Qué no hace este paquete:** no lo lleva al comité, no decide, y no le escribe a Beatriz Cuéllar ni a Mauricio Pérez. La llamada a Beatriz antes del 2026-11-05 es de Diana Molina. Es probable que resuelva el punto 2 antes de la sesión.

Borrador de trabajo: la verificación contra los documentos es suya.
