## Listo — PRY-201 · Edificio de oficinas Torre Norte

**Lo que miré:** 14 documentos (1 .docx, 10 .md, 1 .pdf, 1 .txt, 1 .xlsx; los 14 se pudieron leer) · 7 reuniones (6 minutas de comité semanal del 2026-09-10 al 2026-10-15, más las notas del 2026-10-22) · la última, del 2026-10-22. Leí las siete en orden, de la más vieja a la más nueva.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2, 2026-10-22) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 828fdb02ffd2726d… (.md)

**Respuestas por defecto de la prueba:** proyecto PRY-201 con gerente Diana Molina (del acta de constitución); reunión de seguimiento los jueves (todas las minutas caen en jueves); estado en `estado/PRY-201-edificio-de-oficinas-torre-norte`. No dejé el archivo `_CRITERIO_PROYECTO.txt` en la carpeta: es lo único que se escribiría en los documentos y nadie lo autorizó.

### Lo que está abierto, y cuántas veces se ha movido

26 compromisos en total: 2 cumplidos con acta, 24 abiertos (9 vencidos, 3 sin fecha, 12 con fecha por venir).

**Reprogramados 3 veces o más**

| Quién | Qué | Para cuándo | Veces movido |
|---|---|---|---|
| Beatriz Cuéllar (patrocinadora) | Enviar el documento 1 | 2026-12-25, dicha en las notas del 2026-10-22. Primera promesa: 2026-10-02 (minuta 2026-09-10). Fechas: 10-20 → 11-02 → 11-10 → 11-30 → 12-11 → 12-25 | **6** |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-13 (minuta 2026-10-15). Primera promesa: 2026-09-16. Fechas: 09-25 → 10-05 → 10-25 → 11-05 → 11-13 | **5** |

La fecha del documento 1 (2026-12-25) queda después de la fecha de cierre vigente del proyecto, 2026-12-15. Las otras 9 reprogramaciones menores (Diana Molina 2, Gustavo Neira 2 en dos compromisos, y 1 cada uno: María Restrepo, Ricardo Salas, Elena Duarte, Camilo Beltrán, Paula Céspedes) están por debajo del umbral y no se levantan como señal.

**Vencidos sin evidencia** (ninguna acta de recibo los prueba)

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 | 35 | `30-reuniones/2026-09-10-comite-semanal.md`; el 2026-10-01 dijo que ya entregó, «no se presentó acta» |
| Andrés Lozano | Enviar el documento 9 | 2026-10-01 | 21 | `30-reuniones/2026-09-24-comite-semanal.md`; el 2026-10-01 dijo que ya entregó, «no se presentó acta» |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 | 19 | `30-reuniones/2026-09-17-comite-semanal.md`; la misma fecha en cinco minutas seguidas |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-12 | 10 | `30-reuniones/2026-10-01-comite-semanal.md`; el 2026-10-08 dijo que ya entregó, «no se presentó acta» |
| María Restrepo | Entregar el punto 8 | 2026-10-15 | 7 | `30-reuniones/2026-09-17-comite-semanal.md`; el 2026-10-08 dijo que ya entregó, «no se presentó acta» |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-15 | 7 | `30-reuniones/2026-10-01-comite-semanal.md` |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 | 5 | `30-reuniones/2026-10-08-comite-semanal.md` |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-18 | 4 | `30-reuniones/2026-10-15-comite-semanal.md` |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 | 3 | `30-reuniones/2026-10-15-comite-semanal.md` |

**Abiertos con fecha por venir (12):** Beatriz Cuéllar (documento 1) y Mauricio Pérez (prueba 2), arriba; Diana Molina, Aprobar el diseño 5 (2026-11-06; el 2026-10-08 dijo que ya entregó, sin acta); Ricardo Salas, Revisar el anexo 11 (2026-10-24; el 2026-10-15 dijo que ya entregó, sin acta); Gustavo Neira, Actualizar la matriz 14 (2026-11-14); Elena Duarte, Entregar el punto 16 (2026-11-04); Andrés Lozano, Cerrar la prueba 18 (2026-11-02); Camilo Beltrán, Revisar el anexo 19 (2026-11-14); Paula Céspedes, Validar el ambiente 20 (2026-11-04); Sandra Gil, Aprobar el diseño 21 (2026-11-07); Natalia Ospina, Entregar el punto 24 (2026-11-04); Óscar Ramírez, Revisión con el proveedor (2026-11-01, notas del 2026-10-22).

**Cumplidos con acta (2):** Actualizar la matriz 6 (Javier Hoyos), acta de recibo del 2026-09-24; Cerrar la prueba 10 (Natalia Ospina), acta de recibo del 2026-10-08.

### Sin fecha

Nadie los fechó; no pueden estar vencidos y por eso se pierden en los informes:
- Felipe Arango · Revisar el anexo 3 — sin fecha desde el 2026-09-10; el 2026-10-08 dijo que ya entregó, sin acta (`30-reuniones/2026-09-10-comite-semanal.md`).
- Beatriz Cuéllar · Validar el ambiente 12 — sin fecha desde el 2026-09-24; el 2026-10-01 dijo que ya entregó, sin acta (`30-reuniones/2026-09-24-comite-semanal.md`).
- Laura Vélez · Mandar el ajuste del presupuesto — «la otra semana», sin fecha (`2026-10-22-notas-reunion.txt`).

### Lo que Samuel levantó además

- **El estado declarado no cuadra con la evidencia.** El informe del 2026-10-21 declara **verde** y 51% (`20-seguimiento/2026-10-21-informe-avance.md`); en la misma carpeta hay 9 compromisos vencidos, 2 muy reprogramados, 2 hitos cerrados sin acta y 2 entregables del proveedor atrasados. El estado lo declaras tú; esto es contra lo que se contrasta.
- **2 hitos declarados cerrados sin acta que los pruebe:** Licencias y permisos obtenidos (2026-07-27, 87 días) y Cimentación terminada (2026-09-12, 40 días), según `10-plan/2026-04-15-cronograma-v1.xlsx`. «Diseños de detalle aprobados» sí tiene acta (`20-seguimiento/2026-10-10-acta-recibo-diseños-de-detalle-aprobados.pdf`).
- **2 entregables del proveedor Interventorías Técnicas S.A.S. (CT-521) vencidos sin recibo:** Suministro de acero de refuerzo (2026-06-28, 116 días) y Bolsa de horas de ingeniería (2026-09-01, 51 días), según `00-gobierno/2026-04-14-contrato-ct-521.docx`. Alquiler de equipos de izaje vence el 2026-11-04.
- **Un riesgo dicho en reunión y no anotado:** «el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (`2026-10-22-notas-reunion.txt`). Los riesgos del informe son otros dos: compra de predios pendiente y concentración del conocimiento.
- **Presupuesto** (informe del 2026-10-21): aprobado 800.000.000 COP, comprometido 269.031.166, ejecutado 501.908.947, proyección al cierre 813.951.902 (1,7 % sobre lo aprobado, por debajo del umbral de 10 %; no se levanta como señal).
- **Fecha de cierre:** 2026-12-15, sin cambios desde el acta de constitución; no hay cronograma posterior a la v1 de abril.

### Qué le falta a tu carpeta

- Actas de recibo de lo que se dice entregado: 8 compromisos «ya entregados» no tienen ninguna, y sin ellas un compromiso cumplido se ve igual que uno incumplido.
- Actas de recibo de «Licencias y permisos obtenidos», «Cimentación terminada» y de los entregables del contrato CT-521.
- Un cronograma vigente: el único es la v1 del 2026-04-15 y todas sus fechas coinciden con la línea base.
- El acta de constitución trae texto de plantilla («Componente 1/2/3», «Lo que otro proyecto cubre»), un criterio de éxito sin medida y sin facultad del gerente (cuánto y qué cambios puede decidir sin comité).
- Las notas del 2026-10-22 están sueltas en la raíz del proyecto, en .txt y sin la estructura de una minuta; la convención es `30-reuniones/AAAA-MM-DD-comite-semanal.md`.
- Dos riesgos del informe («predios», «concentración del conocimiento») no tienen responsable ni fecha.

**Cuándo vuelvo:** jueves, según tu reunión de seguimiento. Las notas del 2026-10-22 dicen «próxima reunión en dos semanas», así que dejé la siguiente el 2026-11-05.
