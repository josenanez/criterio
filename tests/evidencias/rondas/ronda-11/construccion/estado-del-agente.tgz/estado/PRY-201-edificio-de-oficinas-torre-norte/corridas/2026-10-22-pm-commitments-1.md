# Corrida del 2026-10-22 · pm-commitments

1 proyectos · 46 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 9 |
| `commitment_undated` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `declared_vs_evidence` | 1 |

Reprogramados: Beatriz Cuéllar (6) y Mauricio Pérez (5); 9 vencidos sin evidencia, 4 con 'dice que entregó' sin acta; 3 sin fecha

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

## Compromisos — Edificio de oficinas Torre Norte (PRY-201) · al 2026-10-22

Términos vigentes (aceptados el 2026-10-22 por José Francisco Ñáñez, versión 0.8.0). Fuente de las cifras: `portafolio.py compute`. Sin `record_issues`.

### Se viene reprogramando

> **Beatriz Cuéllar** · Enviar el documento 1
> Prometido para el 2026-12-25, y antes para el 2026-12-11, el 2026-11-30, el 2026-11-10, el 2026-11-02 y el 2026-10-20. La primera promesa, dicha el 2026-09-10, era para el 2026-10-02.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.**
> Dos datos de la ficha: Beatriz Cuéllar figura como sponsor del proyecto (acta de constitución, 2026-04-15), y la fecha vigente cae diez días después del fin del plan (2026-12-15).

> **Mauricio Pérez** · Cerrar la prueba 2
> Prometido para el 2026-11-13, y antes para el 2026-11-05, el 2026-10-25, el 2026-10-05 y el 2026-09-25. La primera promesa, dicha el 2026-09-10, era para el 2026-09-16.
> **Cinco reprogramaciones: mismo patrón, otro doliente.**

Umbral de aviso: 3 reprogramaciones (`reschedules_to_flag`). Diana Molina, con "Aprobar el diseño 5" (2 reprogramaciones, vigente 2026-11-06), queda por debajo.

### Vencidos sin evidencia

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 | 35 días |
| Andrés Lozano | Enviar el documento 9 | 2026-10-01 | 21 días |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 | 19 días |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-12 | 10 días |
| María Restrepo | Entregar el punto 8 | 2026-10-15 | 7 días |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-15 | 7 días |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 | 5 días |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-18 | 4 días |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 | 3 días |

Cuatro de estos tienen una nota de "dice que ya entregó; no se presentó acta": Laura Vélez, Andrés Lozano (documento 9), Carlos Peña y María Restrepo. **Dicen que lo entregaron; no hay nada en el expediente que lo respalde.** Siguen abiertos hasta que haya un documento.

Dos personas aparecen dos veces: Gustavo Neira (además tiene "Actualizar la matriz 14", reprogramada una vez a 2026-11-14) y Andrés Lozano.

### Vencen esta semana

| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Revisar el anexo 11 | 2026-10-24 (reprogramado una vez; antes 2026-10-10) |

Ricardo Salas dice que ya entregó; no hay acta.

### Sin fecha

| Quién | Qué | Dicho el |
|---|---|---|
| Felipe Arango | Revisar el anexo 3 | 2026-09-10 |
| Beatriz Cuéllar | Validar el ambiente 12 | 2026-09-24 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-22 |

No pueden estar vencidos y por eso se cuentan aparte. Felipe Arango y Beatriz Cuéllar dicen que ya entregaron; no hay acta.

### Cerrados desde la última revisión

- **Javier Hoyos** · Actualizar la matriz 6 — `20-seguimiento/2026-09-24-acta-recibo-6.md` (recibido por Diana Molina).
- **Natalia Ospina** · Cerrar la prueba 10 — `20-seguimiento/2026-10-08-acta-recibo-10.md` (recibido por Diana Molina).

### Contexto

El informe de avance del 2026-10-21 declara estado **verde**. Los compromisos vencidos y reprogramados están entre las señales que ese informe no explica (`declared_vs_evidence`).

### Después

- **Decisión para el comité (próximo: 2026-11-05).** Beatriz Cuéllar (6) y Mauricio Pérez (5) superan el umbral. Esto excede la autoridad del gerente. Para formularlo falta saber quién tiene la facultad: la ficha no registra autoridad (`identity.authority` sin encontrar). ¿La formulo con `/pm-escalate`?
- La ficha cambió respecto a lo que ve la PMO; `/pm-publish` la actualiza.
