# Acta — Edificio de oficinas Torre Norte (PRY-201) · 2026-10-22
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** 2026-10-22-notas-reunion.txt · **Ausentes con tema en agenda:** no hay agenda en el insumo; no se puede decir. (Dueños de compromisos abiertos que no estuvieron: Felipe Arango, María Restrepo, Carlos Peña, Ricardo Salas.)

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 (línea 4: «lo de "enviar el documento 1" no alcanzó, se compromete para el 25/12/2026») | 2026-12-25 | **Reprogramado por 6.ª vez.** Promesa original 2026-10-02; fechas: 10-20, 11-02, 11-10, 11-30, 12-11, 12-25. La nueva fecha cae 10 días después del fin del proyecto (2026-12-15). Beatriz Cuéllar es además la patrocinadora. |
| Óscar Ramírez | Revisión con el proveedor (línea 6) | 2026-11-01 | Nuevo. 2026-11-01 es domingo. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto (línea 5: «la otra semana»; no es una fecha, queda `no_declarada`) |

(Ya había sin fecha de reuniones anteriores: Felipe Arango, «Revisar el anexo 3»; Beatriz Cuéllar, «Validar el ambiente 12». Total sin fecha en el proyecto: 3.)

## Decisiones
Ninguna. Las notas no registran ninguna decisión.

## Quedó sin decidir
Nada se nombra como pendiente de decisión en las notas.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No se identifica quién; las notas dicen «se comentó» | Riesgo | **No.** Los dos riesgos del RAID son la compra de predios y la concentración del conocimiento. Se añadió a la ficha sin doliente. |

Las notas no dicen qué proveedor ni qué fase. El contrato CT-521 (Interventorías Técnicas) ya tiene dos entregables vencidos sin recibo (acero, 116 días; bolsa de horas, 51 días) y uno por vencer el 2026-11-04 (equipos de izaje), pero no se asume que sea ese proveedor.

## Cerrado en esta reunión
Nada. No se presentó ningún documento de cierre.

## Lo que esta reunión contradice
Ningún campo de la ficha. Para tener en cuenta: el estado declarado es verde (informe del 2026-10-21) y el cálculo da 19 alertas, entre ellas 9 compromisos vencidos y 2 hitos «cumplidos» sin evidencia.

## Sin resolver de la transcripción
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01»: no dice si Óscar se compromete a hacerla o solo se informa la fecha. Se registró a su nombre porque la línea empieza con su nombre.
- «próxima reunión en dos semanas»: el comité va semanal; sin fecha exacta (serían ~2026-11-05, que coincide con `committee_next`). No queda claro si cambia la cadencia.
- Mauricio Pérez («Cerrar la prueba 2», 5 reprogramaciones) estuvo y las notas no dicen nada de ese compromiso: queda en 2026-11-13.
