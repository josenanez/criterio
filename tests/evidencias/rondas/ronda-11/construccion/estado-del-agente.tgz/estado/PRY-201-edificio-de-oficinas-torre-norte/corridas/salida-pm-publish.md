Antes de escribir, esto iba a publicar: 220 campos con dato, 9 sin decir en ninguna parte (identity.authority, la evidencia de 4 hitos, la evidencia de 3 entregables del proveedor y vendors[0].invoiced). El dato más viejo es del 2026-04-14 (contrato CT-521). El estado declarado es **verde**, al 2026-10-21, y es una declaración del gerente, no de la PMO. Ese verde lo contradicen 4 señales: compromisos vencidos, compromisos reprogramados, hitos "cumplidos" sin evidencia y entregables del proveedor atrasados.

Fecha de cierre: `plan.end_date` es 2026-12-15 y sale del único cronograma que hay (v1, 2026-04-15). No hay uno más nuevo, así que coincide con la línea base y no hay nada que corregir.

Publiqué la ficha en `documentos/proyectos/PRY-201-edificio-de-oficinas-torre-norte/00-gobierno/ficha-pm.json`, con corte al 2026-10-22.

**Lleva:** 220 campos con dato · 9 sin decir en ninguna parte · declara **verde** al 2026-10-21

**Lo más viejo que va ahí:** `vendors[0].contract_ref`, del 2026-04-14 (contrato CT-521). Tiene unos 6 meses, así que no pasa de un año.

Aviso: este comando no avisa a nadie. Vera la encontrará en su próximo barrido.
