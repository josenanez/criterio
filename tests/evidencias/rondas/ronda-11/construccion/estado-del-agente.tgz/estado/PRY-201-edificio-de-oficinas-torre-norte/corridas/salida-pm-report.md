# Edificio de oficinas Torre Norte (PRY-201) — semana del 2026-10-16 al 2026-10-22

*Sesión sin interfaz: no hubo quien respondiera la pregunta de declaración. Usé la declaración que el gerente ya dejó escrita en su informe del 2026-10-21 y no propuse ninguna. Si Diana Molina quiere declarar otra cosa hoy, la línea se corrige.*

**Declara el gerente:** verde · 51 % · al 2026-10-21 (hace 1 día; vigente) — `20-seguimiento/2026-10-21-informe-avance.md`
**Sustento documental:** contradicho. Ninguno de los hechos que sustentan el verde tiene documento (0 fuentes de evidencia; 2 declaraciones; 218 sin marcar).
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia y entregables de proveedor vencidos.

## Qué cambió esta semana
No hay corrida anterior con la que comparar: esta es la primera instantánea (2026-10-22) y la comparación sale con 0 cambios. No puedo decir qué cambió; solo qué hay hoy. La semana que viene este apartado ya tendrá contra qué medirse.

Lo que apareció en los documentos de hoy (2026-10-22, notas de reunión):
- Riesgo nuevo, dicho en reunión y no registrado antes: el proveedor podría no llegar con el equipo completo para la siguiente fase. Sin dueño.
- Compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto».
- Incidencia abierta desde el 2026-10-21: el ensayo de resistencia del concreto no alcanzó el valor pactado y se repite. Sin dueño.

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Licencias y permisos obtenidos» marcado cumplido, sin documento | vencía 2026-07-27 | 87 |
| Hito «Cimentación terminada» marcado cumplido, sin documento | vencía 2026-09-12 | 40 |
| Suministro de acero de refuerzo (proveedor), pendiente | 2026-06-28 | 116 |
| Bolsa de horas de ingeniería (proveedor), pendiente | 2026-09-01 | 51 |
| Compromiso «Validar el ambiente 4» (Laura Vélez), vencido | 2026-09-17 | 35 |
| Compromiso «Enviar el documento 9» (Andrés Lozano), vencido | 2026-10-01 | 21 |
| Compromiso «Confirmar la fecha 7» (Liliana Torres), vencido | 2026-10-03 | 19 |

Los días son «días desde el vencimiento», no semanas de estar igual: sin corrida previa no puedo afirmar cuánto llevan sin moverse.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-15 | 2026-12-15 | 0 días contra ambas |
| Presupuesto | 800.000.000 COP | 800.000.000 COP | proyección 813.951.902 (+1,7 %), bajo el umbral del 10 % |

Replanificaciones: 0. Cambios aprobados: 0.
La desviación en fechas es cero porque ninguna fecha se ha movido, no porque el avance la sostenga. **El avance declarado es 51 %; el plan, con 3 de 5 hitos marcados cumplidos, sostiene entre 60 % y 80 %: brecha de 9 puntos, justo por debajo del umbral de 10.** Dos de esos tres hitos no tienen documento.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Estructura terminada | 2026-10-29 | 2026-10-29 | pendiente; faltan 7 días. Sin dato de avance; el ensayo de concreto fallido está abierto. |

«Entrega de obra al cliente» (2026-12-15) queda fuera de la ventana de cuatro semanas.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 269.031.166 (33,6 %) | 501.908.947 (62,7 %) | 813.951.902 | **530.968.834** (aprobado − comprometido) |

Atención: el ejecutado (501,9 M) es mayor que el comprometido (269,0 M). Normalmente lo ejecutado está contenido en lo comprometido. Una de las dos cifras no está bien medida o viene de criterios distintos en el informe del 21 de octubre. El disponible real depende de cuál sea la correcta y hoy no puedo decirlo.

## Abierto
**Reprogramados:**
- Beatriz Cuéllar, «Enviar el documento 1»: 6 veces; original 2026-10-02, hoy 2026-12-25. Sobre el umbral de 3.
- Mauricio Pérez, «Cerrar la prueba 2»: 5 veces; original 2026-09-16, hoy 2026-11-13. Sobre el umbral de 3.

**Vencidos sin evidencia (9):**
| Quién | Qué | Venció | Días |
|---|---|---|---|
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 | 35 |
| Andrés Lozano | Enviar el documento 9 | 2026-10-01 | 21 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 | 19 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-12 | 10 |
| María Restrepo | Entregar el punto 8 | 2026-10-15 | 7 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-15 | 7 |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 | 5 |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-18 | 4 |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 | 3 |

**Sin fecha (3):** Felipe Arango, «Revisar el anexo 3» (reunión del 2026-09-10); Beatriz Cuéllar, «Validar el ambiente 12» (2026-09-24); Laura Vélez, «Mandar el ajuste del presupuesto» (2026-10-22).

**RAID sin movimiento:** 3 riesgos y 1 incidencia, ninguno con dueño. Los dos primeros riesgos (compra de predios pendiente en el trazado; concentración del conocimiento en una sola persona) aparecen en el informe del 21 de octubre; sin corrida previa no puedo dar días sin movimiento.

**Proveedor (Interventorías Técnicas S.A.S., CT-521):** 3 entregables, 0 aceptados; 2 vencidos (acero de refuerzo, 116 días; bolsa de horas, 51 días). Sin dato de lo facturado, así que no puedo decir si hay facturado sin entrega.

## Lo que necesito de alguien
- Diana Molina: confirmar o corregir la declaración verde/51 % a la vista de lo anterior.
- Quien tenga las licencias y la cimentación: el documento que sustenta que están cumplidas, o corregir el estado del hito.
- Beatriz Cuéllar y Mauricio Pérez: fecha realista o decisión de dejar el compromiso. Cada uno lleva 5 o más reprogramaciones; pasa del umbral de 3, material de comité.
- Quien lleve el presupuesto: aclarar por qué el ejecutado supera al comprometido.
- Nombrar dueño para los 3 riesgos y la incidencia del concreto.
- Interventorías Técnicas S.A.S.: fecha para los dos entregables vencidos. Si excede la autoridad del gerente, va a comité (próximo: 2026-11-05).
- Sin autoridad de aprobación registrada en la ficha (`identity.authority`): no puedo marcar qué excede al gerente.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto; evidencia de 4 hitos (licencias, cimentación, estructura, entrega); evidencia de recibo de los 3 entregables del proveedor; lo facturado al proveedor.
**Silencio:** último documento hace 0 días (2026-10-22) · última reunión hace 0 días (2026-10-22). No hay silencio documental; el problema es que lo que se documenta no sustenta lo declarado.

---
Fuente: ficha `PRY-201.json`, corte 2026-10-22. Campos sin dato: 9. Términos v1.2 (criterio-project 0.8.0), aceptados el 2026-10-22 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal
Borrador de trabajo: la verificación contra los documentos es suya.

**Siguiente paso:** hay dos compromisos reprogramados más de 3 veces y una declaración verde contradicha por la evidencia. Puedo armar el punto de comité con la decisión formulada (`/pm-escalate`) y publicar la ficha para la PMO (`/pm-publish`).
