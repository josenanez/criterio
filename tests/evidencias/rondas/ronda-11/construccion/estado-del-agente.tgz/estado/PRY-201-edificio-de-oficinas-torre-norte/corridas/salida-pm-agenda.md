## Reunión de seguimiento — Edificio de oficinas Torre Norte (PRY-201) · 2026-11-05
6 puntos · 45 minutos · 10 personas requeridas (más Diana Molina)

**Supuestos de esta agenda, dichos de una vez:**
- **Fecha:** 2026-11-05. Sale de `committee_next` y de las notas del 2026-10-22 («próxima reunión en dos semanas»); el comité está configurado semanal. Si la reunión es el 2026-10-29, cambia la fecha, no el orden.
- **Duración:** 45 minutos. La configuración no trae el tiempo de la reunión; es mi suposición y la suma cabe en ella. Si pasas un número (`/pm-agenda 30`), recorto por el final.
- **Base:** datos al 2026-10-22. No hay una agenda ni un cálculo anterior contra el cual diferenciar (`diff` devolvió «primer punto de partida»), así que «lo que cambió» se tomó contra las notas del 2026-10-22 y las seis minutas de septiembre y octubre. **Esta agenda hay que volver a correrla el 2026-11-04** (día del informe): para entonces lo que vence antes de la reunión ya estará cumplido o vencido.
- Nadie dijo en las notas qué quedó pendiente de decidir, así que no hay puntos por ese camino.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y fijar una fecha que quepa en el proyecto** · 8 min · **Beatriz Cuéllar** (patrocinadora; con Diana Molina)
> Prometido para el 2026-12-25, y antes para el 2026-12-11, el 2026-11-30, el 2026-11-10, el 2026-11-02 y el 2026-10-20. La primera promesa, del 2026-09-10, era para el 2026-10-02. Seis veces.
> **Tiene que quedar resuelto:** quién o qué impide enviarlo, y una fecha anterior al cierre del proyecto (2026-12-15), o la decisión explícita de que el cierre se mueve. Si lo segundo, no se decide aquí: es un cambio de línea base y va por control de cambios; se formula con `/pm-escalate`.
> Fuente: `2026-10-22-notas-reunion.txt` (línea 4) y minutas del 2026-09-10 al 2026-10-15; acta de constitución del 2026-04-15 (fecha de cierre y patrocinio).
> **Si no se resuelve hoy:** la fecha vigente ya cae diez días después del fin del plan; el siguiente aplazamiento no tiene dónde caber.

> **[2] Nombrar qué bloquea «Cerrar la prueba 2» y confirmar o cambiar el 2026-11-13** · 6 min · **Mauricio Pérez**
> Prometido para el 2026-11-13, y antes para el 2026-11-05, el 2026-10-25, el 2026-10-05 y el 2026-09-25. Primera promesa, 2026-09-16. Cinco veces.
> **Tiene que quedar resuelto:** qué necesita para cerrarla y de quién. El 2026-10-22 estuvo en la reunión y las notas no dicen nada de este compromiso.
> Fuente: minuta del 2026-10-15; primera promesa en la del 2026-09-10.
> **Si no se resuelve hoy:** sube a la sexta reprogramación, el mismo patrón que el punto 1.

### Vencido sin evidencia
Días al 2026-10-22; para el 2026-11-05 suman 14 más. Más viejo primero.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 (35 d) | El acta de recibo, o la fecha real. Dijo el 2026-10-01 que ya entregó; no hay acta (minutas 2026-09-10 y 2026-10-01) | 3 |
| Andrés Lozano | Enviar el documento 9 · Confirmar la fecha 23 | 2026-10-01 (21 d) · 2026-10-19 (3 d) | El acta del documento 9 (dijo que ya entregó, sin acta) y una fecha para la 23 (minutas 2026-09-24 y 2026-10-15) | 3 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 (19 d) | La fecha; lleva cinco minutas seguidas con la misma sin cumplirse (minuta 2026-09-17) | 2 |
| Carlos Peña · María Restrepo | Aprobar el diseño 13 · Entregar el punto 8 | 2026-10-12 (10 d) · 2026-10-15 (7 d) | El acta de recibo de cada uno; ambos dijeron el 2026-10-08 que ya entregaron, sin acta. **No vinieron el 2026-10-22: confirmar asistencia; si no vienen, se pide el acta por mensaje y el punto sale** (minutas 2026-10-01 y 2026-09-17) | 3 |
| Gustavo Neira | Confirmar la fecha 15 · Actualizar la matriz 22 | 2026-10-15 (7 d) · 2026-10-18 (4 d) | Fecha o entrega de ambas (minutas 2026-10-01 y 2026-10-15) | 3 |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 (5 d) | Entrega o fecha (minuta 2026-10-08) | 2 |

Subtotal: 16 min.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **Riesgo del proveedor sin registrar y entregables atrasados.** En las notas del 2026-10-22: «el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». Las notas no dicen qué proveedor ni quién lo dijo; hay que cerrar eso en la sala. El contrato CT-521 (Interventorías Técnicas S.A.S.) tiene dos entregables vencidos sin recibo (acero, 2026-06-28; bolsa de horas de ingeniería, 2026-09-01) y el de equipos de izaje vence el 2026-11-04. **Sale de la sala:** qué proveedor es, quién es doliente del riesgo (entra al RAID con responsable y fecha), y el resultado de la revisión con el proveedor que Óscar Ramírez dejó para el 2026-11-01. (Fuente: notas 2026-10-22, líneas 6 y 7; `00-gobierno/2026-04-14-contrato-ct-521.docx`.) | **Óscar Ramírez** trae el resultado; Diana Molina asigna el doliente del riesgo. Qué hacer con el contrato si no entrega, no está en la ficha: la facultad del gerente no está registrada | El riesgo sigue sin doliente, y la fase siguiente depende del proveedor | 8 |
| **Ponerle fecha a dos compromisos sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana», notas 2026-10-22); Beatriz Cuéllar, «Validar el ambiente 12» (sin fecha desde el 2026-09-24; dijo el 2026-10-01 que ya entregó, sin acta). | Cada doliente, con Diana Molina | Siguen sin poder vencer, y por eso sin que nadie los vea | 4 |

### Vence antes de la próxima
Para la reunión del 2026-11-05 el único valor es preventivo: se pregunta solo a quien el 2026-11-04 no tenga acta. 3 min.

| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Revisar el anexo 11 (movido una vez; dijo que ya entregó, sin acta) | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor (2026-11-01 es domingo) | 2026-11-01 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-11-02 |
| Elena Duarte | Entregar el punto 16 | 2026-11-04 |
| Paula Céspedes | Validar el ambiente 20 | 2026-11-04 |
| Natalia Ospina | Entregar el punto 24 | 2026-11-04 |
| Proveedor CT-521 | Alquiler de equipos de izaje | 2026-11-04 |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Mover la fecha de cierre (2026-12-15) o la línea base, si el punto 1 lo pide | Excede lo que se decide en una reunión de seguimiento; la ficha no registra qué puede decidir el gerente | Control de cambios y `/pm-escalate`; material de comité |
| «Licencias y permisos obtenidos» (2026-07-27) y «Cimentación terminada» (2026-09-12), declarados cumplidos sin acta | No son compromisos de una persona, y no encontré doliente en los documentos | Diana Molina pide las actas por escrito; mientras no estén, se informan como cumplidos sin evidencia |
| Estado declarado **verde** (informe del 2026-10-21) frente a 9 vencidos, 2 muy reprogramados, 2 hitos sin acta y 2 entregables del proveedor atrasados | El estado lo declara la gerente, no se discute en la sala | `/pm-report` |
| Felipe Arango, «Revisar el anexo 3» (sin fecha desde el 2026-09-10; dijo que ya entregó, sin acta) · Ricardo Salas, anexo 11 | No estuvieron el 2026-10-22; su doliente no está en la sala | Mensaje a cada uno pidiendo el acta o la fecha; si el 2026-11-04 siguen sin ella, vuelven a la agenda |
| Si la cadencia pasa de semanal a quincenal | Las notas lo insinúan y nadie lo decidió | Diana Molina lo confirma antes de convocar |

### Anexo — sin cambios desde el 2026-10-22
No se repasa en la reunión. Con fecha posterior al 2026-11-05:
- Diana Molina · Aprobar el diseño 5 — 2026-11-06 (movido dos veces; dijo el 2026-10-08 que ya entregó, sin acta)
- Sandra Gil · Aprobar el diseño 21 — 2026-11-07
- Gustavo Neira · Actualizar la matriz 14 — 2026-11-14 (movido una vez)
- Camilo Beltrán · Revisar el anexo 19 — 2026-11-14
- Cerrados con acta desde la última revisión: Javier Hoyos, matriz 6 (acta del 2026-09-24); Natalia Ospina, prueba 10 (acta del 2026-10-08)

*Tiempo: 8 + 6 + 16 + 8 + 4 + 3 = 45 minutos. Nada quedó fuera por tiempo. Producí la agenda; convocar y dirigir la reunión es tuyo.*

**Después:** cuando termine la reunión, `/pm-minutes` sobre las notas o la transcripción; los compromisos nuevos entran a `/pm-commitments` con su cita.
