# Plan — Edificio de oficinas Torre Norte (PRY-201) · borrador del 2026-10-22
**Desde:** acta de constitución del 2026-04-15 (`00-gobierno/2026-04-15-acta-constitucion.md`) · **Criterio de éxito:** «Edificio de oficinas Torre Norte en producción y medido» (acta, sección Criterio de éxito). Está escrito, pero no dice qué se mide ni con qué umbral.

**Antes de leer el plan:** el proyecto no está arrancando. El acta es de abril, el inicio comprometido fue el 2026-04-25 y hoy hay cimentación cerrada y estructura en curso. Este borrador es la WBS que el acta permite reconstruir, no un plan prospectivo. Ya existe un `cronograma-v1.xlsx` (2026-04-15) con cinco hitos; lo cito, no lo reemplazo. Y no compromete ninguna fecha.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido**: «Componente 1 / 2 / 3» (acta, Alcance) | No se puede descomponer por entregable. Los componentes de la WBS salen de otros documentos (cronograma y contrato), no del acta. Si el alcance real es otro, la WBS lo hereda mal. |
| **Fuera de alcance sin contenido**: «Lo que otro proyecto cubre» | No se sabe qué rechazar como cambio. Cualquier petición puede entrar al alcance por defecto. |
| **Objetivo del negocio genérico**: «Entregar edificio de oficinas torre norte para Ingeniería» | No dice para qué se necesita el edificio ni cuándo deja de servir. No hay con qué priorizar si hay que recortar. |
| **Criterio de éxito no medible**: «en producción y medido» | «Medido» no tiene métrica, fuente ni umbral. No se puede saber cuándo el proyecto cerró bien. |
| **Autoridad del gerente no declarada** | No se sabe qué puede decidir Diana Molina al planificar y qué hay que subir al Comité de Inversiones. |
| **Dependencias: «Ninguna declarada»**, pero el informe del 2026-10-21 lista «Compra de predios pendiente en el trazado» y las notas del 2026-10-22 mencionan que el proveedor podría no llegar con el equipo completo | El acta dice que no hay dependencias y los documentos posteriores dicen que sí. Un plan sin esas dependencias parece más corto de lo que es. |

Sí está: patrocinador (Beatriz Cuéllar), gerente (Diana Molina), comité (Comité de Inversiones), presupuesto (800.000.000 COP) y fechas de inicio y cierre. Ofrezco seguir con los huecos marcados; no los relleno.

## WBS
Los nodos son los entregables que los documentos permiten nombrar. Ninguno viene del alcance del acta.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseños de detalle aprobados | **Sin definir** (quién aprueba) | Cronograma v1, hito «cerrado» (línea base y vigente 2026-06-10); acta de recibo del 2026-10-10 (PDF) | — |
| 2 | Licencias y permisos obtenidos | **Sin definir** | Cronograma v1, hito «cerrado» (2026-07-27) | — |
| 3 | Cimentación terminada | **Sin definir** (la interventoría mide cantidades según el informe; no dice quién acepta) | Cronograma v1, hito «cerrado» (2026-09-12) | — |
| 4 | Estructura terminada | **Sin definir** | Cronograma v1, hito «en curso» (2026-10-29). Informe 2026-10-21: ensayo de resistencia del concreto no alcanzó el valor pactado y se repite | — |
| 5 | Entrega de obra al cliente | **Sin definir** («cliente» no está identificado; el acta dice «para Ingeniería») | Cronograma v1, hito «en curso» (2026-12-15); acta, fecha de cierre | — |
| 6 | Suministro de acero de refuerzo (CT-521) | Gerente del proyecto firma el acta de recibo | Contrato CT-521, entregable «pendiente», 2026-06-28, 77.546.392 COP | — |
| 7 | Bolsa de horas de ingeniería (CT-521) | Gerente del proyecto | Contrato CT-521, «en curso», 2026-09-01, 77.546.392 COP | — |
| 8 | Alquiler de equipos de izaje (CT-521) | Gerente del proyecto | Contrato CT-521, «pendiente», 2026-11-04, 77.546.392 COP | — |
| 9 | Puesta en producción y medición del edificio | **Sin definir** | Solo del criterio de éxito del acta; sin entregable, sin métrica | — |
| 10 | Compra de predios del trazado | **Sin definir** | Solo del informe 2026-10-21 (riesgo abierto); el acta no lo menciona | — |

Los nodos 9 y 10 quedan como **sin definir**: no sé si son parte del alcance, de otro proyecto o del mismo trabajo con otro nombre. La columna Duración queda vacía en todos: ningún documento dice cuánto toma cada entregable; solo hay fechas de hito, y una fecha no es una duración.

## Orden
Sin fechas. Lo que los documentos permiten afirmar:
- Diseños → licencias → cimentación → estructura → entrega: es el orden del cronograma v1; es una propiedad del trabajo y ese archivo lo usa.
- Estructura terminada necesita el concreto aprobado (ensayo repetido) y, probablemente, el acero (nodo 6) y los equipos de izaje (nodo 8). **Supuesto**, no dato.
- Entrega de obra al cliente necesita la estructura. Qué más (acabados, instalaciones) **no aparece en ningún documento**: la WBS no tiene nodos entre «Estructura terminada» y «Entrega».
- Compra de predios (nodo 10): no sé de qué depende ni qué depende de ella. Sin definir.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 son todos los entregables de obra | Falta trabajo entre estructura y entrega (acabados, instalaciones, pruebas) y la WBS es incompleta |
| Los tres entregables de CT-521 corresponden al alcance de la obra (acero, horas, izaje) | Si el contrato cubre otra cosa, los nodos 6-8 no pertenecen aquí |
| El gerente firma las actas de recibo de CT-521 (así lo dice la condición de pago) | Si aceptar es una decisión compartida con la interventoría, hay un aceptante que no está nombrado |
| La compra de predios es parte del proyecto | Si es de otro proyecto, el riesgo no es de Diana Molina y el nodo 10 sobra |
| «En producción» significa edificio entregado y ocupado | Si implica operación posterior a 2026-12-15, el cierre no está cubierto por la fecha |

Al aprobarse el plan, estos supuestos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido real de los componentes 1-3 del alcance | Patrocinador (Beatriz Cuéllar) |
| Qué queda fuera de alcance | Patrocinador / Comité de Inversiones |
| Qué se mide en «medido», con qué umbral y desde qué fuente | Patrocinador |
| Quién acepta cada hito de obra (nodos 1-5) | Patrocinador, o a quien delegue por escrito |
| Autoridad del gerente al planificar | Comité de Inversiones |
| Si la compra de predios es de este proyecto | Patrocinador |
| Quién es el «cliente» de la entrega de obra | Patrocinador |

## Proyectos análogos
No hay ninguno a la vista. La configuración de PRY-201 no apunta a una carpeta de fichas de la PMO, y en `estado/` solo existe la de este proyecto. Hay carpetas de otros proyectos en `documentos/proyectos/` (PRY-199, 200, 202, 203, 204, 205), pero sin ficha; no las leí y no infiero nada de los nombres. Sin análogos no hay referencia de corrimiento, y no la invento.

## Observaciones que el plan no debe esconder
Son lecturas de los documentos, no parte de la WBS:
- **Presupuesto:** informe del 2026-10-21, aprobado 800.000.000, ejecutado 501.908.947, comprometido 269.031.166 y proyección al cierre 813.951.902 (por encima del aprobado). Ejecutado más comprometido suman 770.940.113, es decir 96,4 % del aprobado, con 51 % de avance declarado. Es aritmética del informe, no una estimación mía.
- **Estado «Verde»** en un informe que a la vez declara una proyección sobre el presupuesto y un ensayo de concreto fallido. Eso es del gerente, no lo califico aquí; lo recojo para `/pm-report`.
- **Contrato CT-521:** los tres entregables suman 232.639.176 COP, pero el comprometido del informe es 269.031.166. No sé qué explica la diferencia.
- **Proveedor de CT-521:** el nombre es «Interventorías Técnicas S.A.S.», pero los entregables son acero, horas de ingeniería y equipos de izaje. Puede ser normal o un error de captura; no está explicado.
- El entregable «Suministro de acero» figura «pendiente» con fecha 2026-06-28, ya vencida, mientras la cimentación figura cerrada. Sin acta de recibo en la carpeta.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto toma repetir el ensayo de resistencia y qué pasa con la estructura si falla de nuevo? (nodo 4)
2. ¿Cuánto falta para terminar estructura y qué parte del 51 % reportado corresponde a ella? (nodo 4)
3. ¿Qué trabajo hay entre estructura terminada y entrega de obra, y cuánto toma cada parte? (nodo 5)
4. ¿Cuánto toma la entrega formal y quién la recibe? (nodo 5)
5. ¿Se recibió el acero? Si sí, ¿dónde está el acta; si no, cuánto se espera? (nodo 6)
6. ¿Cuántas horas de ingeniería quedan en la bolsa y a qué ritmo se consumen? (nodo 7)
7. ¿Cuánto tiempo hay que reservar el equipo de izaje y por qué es posterior a la estructura? (nodo 8)
8. ¿Qué es «producción y medido» para un edificio, cuánto toma y quién mide? (nodo 9)
9. ¿Cuánto toma la compra de predios, quién la lleva y de qué depende? (nodo 10)
10. ¿Cuánto toma cada hito ya cerrado (nodos 1-3) respecto de lo planeado? Sin esa referencia no hay base para estimar los pendientes.

## Para comprometer una fecha falta
- La disponibilidad real del equipo: nada en la carpeta la documenta. En las notas del 2026-10-22 se comenta que el proveedor podría no llegar con el equipo completo, y nadie lo registró como riesgo.
- La fecha del proveedor: CT-521 tiene fechas por entregable, pero no hay fecha confirmada ni acta de recibo vigente de los tres.
- El resultado del ensayo de concreto repetido, del que depende la estructura.
- La resolución de la compra de predios.
- Una decisión del patrocinador sobre alcance y aceptación (ver Sin definir).
- Un análogo con el cual contrastar, si existe.

Nada de esto está en un documento. La fecha de cierre (2026-12-15) es la del acta; no la confirmo ni la cuestiono.

## Después
Cuando el plan se apruebe, puedo registrarlo como línea base. Hoy ya hay una línea base original en el cronograma v1 (2026-04-15); este plan no la reemplaza. Los supuestos pasarían al RAID con doliente.
