<!-- origen: PRY-200-variante-vial-del-sur/10-plan/2026-03-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2026-06-01 | 2026-06-01 | cerrado
Licencias y permisos obtenidos | 2026-08-04 | 2026-08-04 | cerrado
Cimentación terminada | 2026-10-07 | 2026-10-07 | cerrado
Estructura terminada | 2026-12-10 | 2026-12-10 | en curso
