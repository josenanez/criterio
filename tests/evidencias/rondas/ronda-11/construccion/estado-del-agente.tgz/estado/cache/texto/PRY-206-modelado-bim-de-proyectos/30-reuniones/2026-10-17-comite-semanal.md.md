<!-- origen: PRY-206-modelado-bim-de-proyectos/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Modelado BIM de proyectos

**Fecha:** 2026-10-17
**Asistentes:** Óscar Ramírez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 14 | 2026-10-10 |
| Liliana Torres | Entregar el punto 19 | 2026-11-11 |
