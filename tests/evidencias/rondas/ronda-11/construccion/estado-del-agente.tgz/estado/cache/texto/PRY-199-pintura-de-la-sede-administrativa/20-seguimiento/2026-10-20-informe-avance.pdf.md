<!-- origen: PRY-199-pintura-de-la-sede-administrativa/20-seguimiento/2026-10-20-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pintura de la sede administrativa
Código: PRY-199
Fecha de corte: 2026-10-20
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Se acordó con la interventoría cómo se miden las cantidades de obra

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- Cambio en la norma de sismorresistencia que puede mover el alcance
- Compra de predios pendiente en el trazado
