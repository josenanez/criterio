<!-- origen: PRY-208-bodega-logística-modular/20-seguimiento/2026-10-21-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Bodega logística modular
**Fecha:** 2026-10-21
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +30 días sobre la línea base vigente |
| Costo | 60.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
