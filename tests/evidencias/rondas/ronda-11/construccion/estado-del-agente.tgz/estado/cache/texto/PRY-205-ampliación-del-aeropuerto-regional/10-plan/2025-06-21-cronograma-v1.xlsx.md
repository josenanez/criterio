<!-- origen: PRY-205-ampliación-del-aeropuerto-regional/10-plan/2025-06-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2025-10-15 | 2025-10-15 | cerrado
Licencias y permisos obtenidos | 2026-01-30 | 2026-01-30 | cerrado
Cimentación terminada | 2026-05-17 | 2026-05-17 | cerrado
Estructura terminada | 2026-09-01 | 2026-09-01 | cerrado
