<!-- origen: PRY-209-doble-calzada-del-corredor-central/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Doble calzada del corredor central
Código: PRY-209
Fecha de corte: 2026-10-22
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 44%

Lo que pasó en el periodo
- Las lluvias detuvieron el movimiento de tierras durante nueve días
- El equipo perdió dos semanas por rotación del residente de obra
- Se levantó un hallazgo de seguridad en el trabajo en alturas

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.127.508.842
Ejecutado 1.532.246.827
Proyección al cierre 6.662.068.986

Riesgos abiertos
- Concentración del conocimiento en una sola persona
