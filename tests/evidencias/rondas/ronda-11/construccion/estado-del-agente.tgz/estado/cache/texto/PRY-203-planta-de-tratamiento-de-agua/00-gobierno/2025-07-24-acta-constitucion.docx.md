<!-- origen: PRY-203-planta-de-tratamiento-de-agua/00-gobierno/2025-07-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Planta de tratamiento de agua

Código: PRY-203

Área dueña: Medio Ambiente

Patrocinador: Laura Vélez

Gerente de proyecto: Carlos Peña

Comité: Comité de Contratación

Producto asociado: No aplica

Fecha de aprobación: 2025-07-24

Objetivo del negocio

Entregar planta de tratamiento de agua para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Contratación el 2025-07-24.

Fechas comprometidas

Fecha

Inicio

2025-08-03

Cierre

2026-03-22

Criterio de éxito

Planta de tratamiento de agua en producción y medido.

Dependencias declaradas

• Ninguna declarada
