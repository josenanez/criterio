<!-- origen: PRY-210-colegio-público-por-concesión/00-gobierno/2026-02-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Colegio público por concesión

Código: PRY-210

Área dueña: Calidad

Patrocinador: Laura Vélez

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Obra

Producto asociado: No aplica

Fecha de aprobación: 2026-02-11

Objetivo del negocio

Entregar colegio público por concesión para Calidad.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Obra el 2026-02-11.

Fechas comprometidas

Fecha

Inicio

2026-02-21

Cierre

2027-07-01

Criterio de éxito

Colegio público por concesión en producción y medido.

Dependencias declaradas

• Ninguna declarada
