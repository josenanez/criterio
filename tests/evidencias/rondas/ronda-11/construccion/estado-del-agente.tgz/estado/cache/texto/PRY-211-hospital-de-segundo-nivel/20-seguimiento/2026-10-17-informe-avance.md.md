<!-- origen: PRY-211-hospital-de-segundo-nivel/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Hospital de segundo nivel

**Código:** PRY-211
**Fecha de corte:** 2026-10-17
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **90%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en el trabajo en alturas
- El equipo perdió dos semanas por rotación del residente de obra

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.398.539.653 |
| Ejecutado | 1.507.625.105 |
| Proyección al cierre | 2.439.748.860 |

## Riesgos abiertos

- Compra de predios pendiente en el trazado
