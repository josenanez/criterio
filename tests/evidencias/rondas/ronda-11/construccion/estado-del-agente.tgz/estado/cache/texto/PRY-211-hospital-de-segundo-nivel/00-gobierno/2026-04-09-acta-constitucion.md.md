<!-- origen: PRY-211-hospital-de-segundo-nivel/00-gobierno/2026-04-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Hospital de segundo nivel

**Código:** PRY-211
**Área dueña:** Ingeniería
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Contratación
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-09

## Objetivo del negocio

Entregar hospital de segundo nivel para Ingeniería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Contratación el 2026-04-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-19 |
| Cierre | 2027-02-19 |

## Criterio de éxito

Hospital de segundo nivel en producción y medido.

## Dependencias declaradas

- Ninguna declarada
