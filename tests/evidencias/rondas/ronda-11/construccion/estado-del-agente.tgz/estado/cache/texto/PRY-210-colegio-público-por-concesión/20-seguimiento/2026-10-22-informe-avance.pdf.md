<!-- origen: PRY-210-colegio-público-por-concesión/20-seguimiento/2026-10-22-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Colegio público por concesión
Código: PRY-210
Fecha de corte: 2026-10-22
Gerente: Rubén Cárdenas

Estado declarado
Amarillo
Avance reportado: 82%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en el trabajo en alturas

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.520.770.622
Ejecutado 1.385.914.207
Proyección al cierre 3.403.196.254

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Lluvias por encima del promedio en la temporada
