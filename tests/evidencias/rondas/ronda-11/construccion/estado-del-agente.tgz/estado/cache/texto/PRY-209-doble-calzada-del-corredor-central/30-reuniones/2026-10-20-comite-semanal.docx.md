<!-- origen: PRY-209-doble-calzada-del-corredor-central/30-reuniones/2026-10-20-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Técnico · Doble calzada del corredor central

Fecha: 2026-10-20

Asistentes: Mauricio Pérez, María Restrepo

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Laura Vélez

Entregar el punto 11

2026-09-28

Sandra Gil

Entregar el punto 38

2026-11-21
