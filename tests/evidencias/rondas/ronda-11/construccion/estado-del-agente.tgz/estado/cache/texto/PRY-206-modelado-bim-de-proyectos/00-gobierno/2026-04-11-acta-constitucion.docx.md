<!-- origen: PRY-206-modelado-bim-de-proyectos/00-gobierno/2026-04-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Modelado BIM de proyectos

Código: PRY-206

Área dueña: Ingeniería

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Seguridad

Producto asociado: modelos BIM

Fecha de aprobación: 2026-04-11

Objetivo del negocio

Entregar modelado bim de proyectos para Ingeniería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Seguridad el 2026-04-11.

Fechas comprometidas

Fecha

Inicio

2026-04-21

Cierre

2027-07-31

Criterio de éxito

Modelado BIM de proyectos en producción y medido.

Dependencias declaradas

• Ninguna declarada
