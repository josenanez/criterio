<!-- origen: PRY-199-pintura-de-la-sede-administrativa/00-gobierno/2026-06-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pintura de la sede administrativa

**Código:** PRY-199
**Área dueña:** Proyectos
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Obra
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-14

## Objetivo del negocio

Entregar pintura de la sede administrativa para Proyectos.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Obra el 2026-06-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-24 |
| Cierre | 2027-12-21 |

## Criterio de éxito

Pintura de la sede administrativa en producción y medido.

## Dependencias declaradas

- Ninguna declarada
