<!-- origen: PRY-204-vivienda-de-interés-social-etapa-2/00-gobierno/2025-12-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Vivienda de interés social etapa 2

Código: PRY-204

Área dueña: Calidad

Patrocinador: Javier Hoyos

Gerente de proyecto: Gustavo Neira

Comité: Comité de Inversiones

Producto asociado: vivienda VIS

Fecha de aprobación: 2025-12-08

Objetivo del negocio

Entregar vivienda de interés social etapa 2 para Calidad.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Inversiones el 2025-12-08.

Fechas comprometidas

Fecha

Inicio

2025-12-18

Cierre

2026-11-11

Criterio de éxito

Vivienda de interés social etapa 2 en producción y medido.

Dependencias declaradas

• Ninguna declarada
