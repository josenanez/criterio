<!-- origen: PRY-208-bodega-logística-modular/20-seguimiento/2026-10-21-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Bodega logística modular

**Código:** PRY-208
**Fecha de corte:** 2026-10-21
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **35%**

## Lo que pasó en el periodo

- Se ajustó el programa de obra con el contratista de estructura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 591.232.616 |
| Ejecutado | 367.578.519 |
| Proyección al cierre | 1.188.909.320 |

## Riesgos abiertos

- Lluvias por encima del promedio en la temporada
- Compra de predios pendiente en el trazado
