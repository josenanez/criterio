<!-- origen: PRY-200-variante-vial-del-sur/20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Variante vial del sur
**Fecha:** 2026-10-14
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +111 días sobre la línea base vigente |
| Costo | 222.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
