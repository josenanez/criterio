<!-- origen: PRY-203-planta-de-tratamiento-de-agua/10-plan/2025-07-24-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseños de detalle aprobados | 2025-09-29 | 2025-09-29 | 2025-09-29 | 100% | hito | — | — |
| 2 | 2 | Licencias y permisos obtenidos | 2025-11-26 | 2025-11-26 | 2025-11-26 | 100% | hito | 1FS | — |
| 3 | 3 | Cimentación terminada | 2026-01-23 | 2026-01-23 | 2026-01-23 | 100% | hito | 2FS | — |
| 4 | 4 | Estructura terminada | 2026-03-22 | 2026-03-22 | 2026-03-22 | 100% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseños de detalle aprobados | 2025-09-29 | 2025-09-29 | cerrado |
| Licencias y permisos obtenidos | 2025-11-26 | 2025-11-26 | cerrado |
| Cimentación terminada | 2026-01-23 | 2026-01-23 | cerrado |
| Estructura terminada | 2026-03-22 | 2026-03-22 | cerrado |
