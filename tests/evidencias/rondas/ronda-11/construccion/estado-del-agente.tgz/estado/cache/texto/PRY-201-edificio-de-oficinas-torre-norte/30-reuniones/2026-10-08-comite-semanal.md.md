<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Gustavo Neira, Liliana Torres, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-30 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-05 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 |
| Ricardo Salas | Revisar el anexo 11 | 2026-10-24 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-14 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-15 |
| Elena Duarte | Entregar el punto 16 | 2026-10-20 |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-11-02 |
| Camilo Beltrán | Revisar el anexo 19 | 2026-11-02 |
| Paula Céspedes | Validar el ambiente 20 | 2026-10-18 |

## Cerrados en esta reunión

- Cerrar la prueba 10 (Natalia Ospina): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- Felipe Arango dice que ya entregó «revisar el anexo 3». No se presentó acta.
- Diana Molina dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- María Restrepo dice que ya entregó «entregar el punto 8». No se presentó acta.
- Carlos Peña dice que ya entregó «aprobar el diseño 13». No se presentó acta.
