<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-201",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "name": {
 "value": "Edificio de oficinas Torre Norte",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "business_area": {
 "value": "Ingeniería",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "product": {
 "value": "arriendo de oficinas",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Beatriz Cuéllar",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "manager": {
 "value": "Diana Molina",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Inversiones",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 51,
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-21",
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found"
 }
 },
 "plan": {
 "start_date": {
 "value": "2026-04-25",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "end_date": {
 "value": "2026-12-15",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-04-15",
 "start_date": "2026-04-25",
 "end_date": "2026-12-15",
 "reason": "inicial",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseños de detalle aprobados",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-06-10",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "current_date": {
 "value": "2026-06-10",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-diseños-de-detalle-aprobados.pdf",
 "source": "20-seguimiento/2026-10-10-acta-recibo-diseños-de-detalle-aprobados.pdf",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 {
 "name": {
 "value": "Licencias y permisos obtenidos",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-07-27",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "current_date": {
 "value": "2026-07-27",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Cimentación terminada",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-09-12",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "current_date": {
 "value": "2026-09-12",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Estructura terminada",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-29",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-29",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Entrega de obra al cliente",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-12-15",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "current_date": {
 "value": "2026-12-15",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-04-15-cronograma-v1.xlsx",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ]
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-04-15-acta-constitucion.md",
 "source_date": "2026-04-15",
 "state": "found"
 },
 "approved": {
 "value": 800000000,
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found"
 },
 "committed": {
 "value": 269031166,
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found"
 },
 "executed": {
 "value": 501908947,
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found"
 },
 "projection": {
 "value": 813951902,
 "source": "20-seguimiento/2026-10-21-informe-avance.md",
 "source_date": "2026-10-21",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Interventorías Técnicas S.A.S.",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-521",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Suministro de acero de refuerzo",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "due_date": {
 "value": "2026-06-28",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "amount": {
 "value": 77546392,
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-01",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "amount": {
 "value": 77546392,
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Alquiler de equipos de izaje",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "amount": {
 "value": 77546392,
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-04-14-contrato-ct-521.docx",
 "source_date": "2026-04-14",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ],
 "invoiced": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Compra de predios pendiente en el trazado",
 "owner": null,
 "source": "20-seguimiento/2026-10-21-informe-avance.md"
 },
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": null,
 "source": "20-seguimiento/2026-10-21-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión, no registrado antes)",
 "owner": null,
 "source": "2026-10-22-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite",
 "since": "2026-10-21",
 "owner": null,
 "source": "20-seguimiento/2026-10-21-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-25",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-11",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 },
 {
 "due_date": "2026-12-25",
 "stated_on": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-13",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-16",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-09-25",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [],
 "note": {
 "value": "Felipe Arango dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [],
 "note": {
 "value": "Laura Vélez dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "note": {
 "value": "Diana Molina dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-09-24-acta-recibo-6.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-24-acta-recibo-6.md",
 "source": "20-seguimiento/2026-09-24-acta-recibo-6.md",
 "source_date": "2026-09-24",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "note": {
 "value": "María Restrepo dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [],
 "note": {
 "value": "Andrés Lozano dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Natalia Ospina",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-08-acta-recibo-10.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-10.md",
 "source": "20-seguimiento/2026-10-08-acta-recibo-10.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-10",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": {
 "value": "Ricardo Salas dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [],
 "note": {
 "value": "Beatriz Cuéllar dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [],
 "note": {
 "value": "Carlos Peña dice que ya entregó; no se presentó acta",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-14",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-17",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-17",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-14",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-07",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-07",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Natalia Ospina",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-15-comite-semanal.md",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-01",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-01",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "reschedules": []
 }
 ],
 "activity": {
 "last_document_date": {
 "value": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 },
 "last_meeting_date": {
 "value": "2026-10-22",
 "source": "2026-10-22-notas-reunion.txt",
 "source_date": "2026-10-22",
 "state": "found"
 }
 },
 "meta": {
 "record_updated": "2026-10-22",
 "fields_not_found": [
 "identity.authority",
 "vendors[0].invoiced"
 ],
 "open_conflicts": []
 }
}
