<!-- origen: PRY-202-puente-vehicular-sobre-el-río/00-gobierno/2026-05-13-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Puente vehicular sobre el río

**Código:** PRY-202
**Área dueña:** Ingeniería
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Contratación
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-13

## Objetivo del negocio

Entregar puente vehicular sobre el río para Ingeniería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Contratación el 2026-05-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-23 |
| Cierre | 2027-05-11 |

## Criterio de éxito

Puente vehicular sobre el río en producción y medido.

## Dependencias declaradas

- Ninguna declarada
