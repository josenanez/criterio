<!-- origen: PRY-205-ampliación-del-aeropuerto-regional/00-gobierno/2025-06-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación del aeropuerto regional

Código: PRY-205

Área dueña: Proyectos

Patrocinador: Natalia Ospina

Gerente de proyecto: Andrés Lozano

Comité: Comité Técnico

Producto asociado: No aplica

Fecha de aprobación: 2025-06-21

Objetivo del negocio

Entregar ampliación del aeropuerto regional para Proyectos.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité Técnico el 2025-06-21.

Fechas comprometidas

Fecha

Inicio

2025-07-01

Cierre

2026-09-01

Criterio de éxito

Ampliación del aeropuerto regional en producción y medido.

Dependencias declaradas

• Ninguna declarada
