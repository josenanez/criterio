<!-- origen: PRY-200-variante-vial-del-sur/10-plan/2026-09-30-cronograma-v2.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseños de detalle aprobados | 2026-06-01 | 2026-06-01 | 2026-06-01 | 100% | hito | — | — |
| 2 | 2 | Licencias y permisos obtenidos | 2026-08-04 | 2026-08-04 | 2026-08-04 | 100% | hito | 1FS | — |
| 3 | 3 | Cimentación terminada | 2026-10-07 | 2026-10-07 | 2026-10-07 | 100% | hito | 2FS | — |
| 4 | 4 | Estructura terminada | 2027-03-31 | 2027-03-31 | 2026-12-10 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseños de detalle aprobados | 2026-06-01 | 2026-06-01 | cerrado |
| Licencias y permisos obtenidos | 2026-08-04 | 2026-08-04 | cerrado |
| Cimentación terminada | 2026-10-07 | 2026-10-07 | cerrado |
| Estructura terminada | 2026-12-10 | 2027-03-31 | en curso |
