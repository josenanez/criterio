<!-- origen: PRY-199-pintura-de-la-sede-administrativa/10-plan/2026-06-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2026-10-11 | 2026-10-11 | cerrado
Licencias y permisos obtenidos | 2027-01-28 | 2027-01-28 | en curso
Cimentación terminada | 2027-05-17 | 2027-05-17 | en curso
Estructura terminada | 2027-09-03 | 2027-09-03 | en curso
Entrega de obra al cliente | 2027-12-21 | 2027-12-21 | en curso
