<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/10-plan/2026-04-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2026-06-10 | 2026-06-10 | cerrado
Licencias y permisos obtenidos | 2026-07-27 | 2026-07-27 | cerrado
Cimentación terminada | 2026-09-12 | 2026-09-12 | cerrado
Estructura terminada | 2026-10-29 | 2026-10-29 | en curso
Entrega de obra al cliente | 2026-12-15 | 2026-12-15 | en curso
