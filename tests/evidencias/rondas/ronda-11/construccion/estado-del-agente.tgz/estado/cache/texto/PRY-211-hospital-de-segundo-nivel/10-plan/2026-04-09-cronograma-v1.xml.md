<!-- origen: PRY-211-hospital-de-segundo-nivel/10-plan/2026-04-09-cronograma-v1.xml · convertidor: project -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Cronograma · Microsoft Project · Cronograma

**Inicio:** — · **Fin:** — · **Fecha de estado:** —

## Tareas

| ID | EDT | Tarea | Inicio | Fin | Línea base: fin | Avance | Tipo | Predecesoras | Recursos |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Diseños de detalle aprobados | 2026-07-04 | 2026-07-04 | 2026-07-04 | 100% | hito | — | — |
| 2 | 2 | Licencias y permisos obtenidos | 2026-09-19 | 2026-09-19 | 2026-09-19 | 100% | hito | 1FS | — |
| 3 | 3 | Cimentación terminada | 2026-12-05 | 2026-12-05 | 2026-12-05 | 50% | hito | 2FS | — |
| 4 | 4 | Estructura terminada | 2027-02-19 | 2027-02-19 | 2027-02-19 | 50% | hito | 3FS | — |

## Hitos

| Hito | Línea base | Vigente | Estado |
|---|---|---|---|
| Diseños de detalle aprobados | 2026-07-04 | 2026-07-04 | cerrado |
| Licencias y permisos obtenidos | 2026-09-19 | 2026-09-19 | cerrado |
| Cimentación terminada | 2026-12-05 | 2026-12-05 | en curso |
| Estructura terminada | 2027-02-19 | 2027-02-19 | en curso |
