<!-- origen: PRY-206-modelado-bim-de-proyectos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Modelado BIM de proyectos
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Óscar Ramírez

Estado declarado
Amarillo
Avance reportado: 69%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en el trabajo en alturas
- Se reprogramó el vaciado por la llegada tardía del acero
- Se recibió el concepto de la autoridad ambiental sobre el plan de manejo

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.410.717.775
Ejecutado 3.198.959.008
Proyección al cierre 7.897.229.155

Riesgos abiertos
- Lluvias por encima del promedio en la temporada
- Cambio en la norma de sismorresistencia que puede mover el alcance
