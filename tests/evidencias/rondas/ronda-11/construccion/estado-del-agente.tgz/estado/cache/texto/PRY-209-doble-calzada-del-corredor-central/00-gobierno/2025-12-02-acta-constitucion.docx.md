<!-- origen: PRY-209-doble-calzada-del-corredor-central/00-gobierno/2025-12-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Doble calzada del corredor central

Código: PRY-209

Área dueña: Medio Ambiente

Patrocinador: María Restrepo

Gerente de proyecto: Mauricio Pérez

Comité: Comité Técnico

Producto asociado: No aplica

Fecha de aprobación: 2025-12-02

Objetivo del negocio

Entregar doble calzada del corredor central para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Técnico el 2025-12-02.

Fechas comprometidas

Fecha

Inicio

2025-12-12

Cierre

2027-02-08

Criterio de éxito

Doble calzada del corredor central en producción y medido.

Dependencias declaradas

• Ninguna declarada
