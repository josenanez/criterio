<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-10-15
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Gustavo Neira, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-11 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-13 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-14 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-15 |
| Elena Duarte | Entregar el punto 16 | 2026-11-04 |
| Rubén Cárdenas | Enviar el documento 17 | 2026-10-17 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-11-02 |
| Camilo Beltrán | Revisar el anexo 19 | 2026-11-14 |
| Paula Céspedes | Validar el ambiente 20 | 2026-11-04 |
| Sandra Gil | Aprobar el diseño 21 | 2026-11-07 |
| Gustavo Neira | Actualizar la matriz 22 | 2026-10-18 |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 |
| Natalia Ospina | Entregar el punto 24 | 2026-11-04 |

## Lo que se dijo

- Ricardo Salas dice que ya entregó «revisar el anexo 11». No se presentó acta.
