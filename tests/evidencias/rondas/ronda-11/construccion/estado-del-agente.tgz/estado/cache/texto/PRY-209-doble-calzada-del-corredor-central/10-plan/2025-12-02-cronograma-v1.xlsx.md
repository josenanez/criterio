<!-- origen: PRY-209-doble-calzada-del-corredor-central/10-plan/2025-12-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2026-03-27 | 2026-03-27 | cerrado
Licencias y permisos obtenidos | 2026-07-11 | 2026-07-11 | cerrado
Cimentación terminada | 2026-10-25 | 2026-10-25 | en curso
Estructura terminada | 2027-02-08 | 2027-02-08 | en curso
