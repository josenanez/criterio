<!-- origen: PRY-203-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-17-solicitud-cambio-cc-02.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-02

**Proyecto:** PRY-203 · Planta de tratamiento de agua
**Fecha:** 2026-10-17
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +46 días sobre la línea base vigente |
| Costo | 92.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
