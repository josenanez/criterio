<!-- origen: PRY-204-vivienda-de-interés-social-etapa-2/20-seguimiento/2026-10-02-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Vivienda de interés social etapa 2
Código: PRY-204
Fecha de corte: 2026-10-02
Gerente: Gustavo Neira

Estado declarado
Verde
Avance reportado: 76%

Lo que pasó en el periodo
- Se ajustó el programa de obra con el contratista de estructura

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.443.923.145
Ejecutado 7.756.540.080
Proyección al cierre 17.615.046.374

Riesgos abiertos
- Concentración del conocimiento en una sola persona
