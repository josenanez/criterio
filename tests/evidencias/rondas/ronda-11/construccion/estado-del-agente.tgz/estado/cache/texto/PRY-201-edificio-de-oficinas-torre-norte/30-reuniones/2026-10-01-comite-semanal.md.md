<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-10-01
**Asistentes:** Beatriz Cuéllar, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-10 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-25 |
| Felipe Arango | Revisar el anexo 3 | por definir |
| Diana Molina | Aprobar el diseño 5 | 2026-11-06 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 |
| María Restrepo | Entregar el punto 8 | 2026-10-15 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-22 |
| Ricardo Salas | Revisar el anexo 11 | 2026-10-10 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-12 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-29 |
| Gustavo Neira | Confirmar la fecha 15 | 2026-10-06 |
| Elena Duarte | Entregar el punto 16 | 2026-10-20 |

## Lo que se dijo

- Laura Vélez dice que ya entregó «validar el ambiente 4». No se presentó acta.
- Andrés Lozano dice que ya entregó «enviar el documento 9». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «validar el ambiente 12». No se presentó acta.
