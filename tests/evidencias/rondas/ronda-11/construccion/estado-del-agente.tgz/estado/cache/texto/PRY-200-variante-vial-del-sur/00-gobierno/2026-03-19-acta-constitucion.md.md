<!-- origen: PRY-200-variante-vial-del-sur/00-gobierno/2026-03-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Variante vial del sur

**Código:** PRY-200
**Área dueña:** Interventoría
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Seguridad
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-03-19

## Objetivo del negocio

Entregar variante vial del sur para Interventoría.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Seguridad el 2026-03-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-29 |
| Cierre | 2026-12-10 |

## Criterio de éxito

Variante vial del sur en producción y medido.

## Dependencias declaradas

- Ninguna declarada
