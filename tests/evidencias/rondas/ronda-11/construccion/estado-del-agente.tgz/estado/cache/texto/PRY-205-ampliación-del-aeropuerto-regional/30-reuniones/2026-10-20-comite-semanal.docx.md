<!-- origen: PRY-205-ampliación-del-aeropuerto-regional/30-reuniones/2026-10-20-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Técnico · Ampliación del aeropuerto regional

Fecha: 2026-10-20

Asistentes: Andrés Lozano, Natalia Ospina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 32

2026-11-12
