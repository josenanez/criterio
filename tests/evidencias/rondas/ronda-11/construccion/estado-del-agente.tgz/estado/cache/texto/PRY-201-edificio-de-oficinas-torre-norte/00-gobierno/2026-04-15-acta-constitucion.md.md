<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/00-gobierno/2026-04-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Edificio de oficinas Torre Norte

**Código:** PRY-201
**Área dueña:** Ingeniería
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Inversiones
**Producto asociado:** arriendo de oficinas
**Fecha de aprobación:** 2026-04-15

## Objetivo del negocio

Entregar edificio de oficinas torre norte para Ingeniería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Inversiones el 2026-04-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-25 |
| Cierre | 2026-12-15 |

## Criterio de éxito

Edificio de oficinas Torre Norte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
