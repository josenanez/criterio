<!-- origen: PRY-204-vivienda-de-interés-social-etapa-2/10-plan/2026-10-02-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseños de detalle aprobados,2026-03-10,2026-03-10,cerrado
Licencias y permisos obtenidos,2026-05-31,2026-05-31,cerrado
Cimentación terminada,2026-08-21,2026-08-21,cerrado
Estructura terminada,2026-11-11,2027-01-08,en curso
