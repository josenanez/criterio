<!-- origen: PRY-202-puente-vehicular-sobre-el-río/10-plan/2026-05-13-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseños de detalle aprobados,2026-08-19,2026-08-19,cerrado
Licencias y permisos obtenidos,2026-11-15,2026-11-15,en curso
Cimentación terminada,2027-02-12,2027-02-12,en curso
Estructura terminada,2027-05-11,2027-05-11,en curso
