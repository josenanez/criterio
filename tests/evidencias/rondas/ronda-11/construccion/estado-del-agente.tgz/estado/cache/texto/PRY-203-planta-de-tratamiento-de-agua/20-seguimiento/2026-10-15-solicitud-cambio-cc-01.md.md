<!-- origen: PRY-203-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Planta de tratamiento de agua
**Fecha:** 2026-10-15
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +101 días sobre la línea base vigente |
| Costo | 202.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
