<!-- origen: PRY-207-control-de-avance-con-drones/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Control de avance con drones

**Código:** PRY-207
**Fecha de corte:** 2026-10-13
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **32%**

## Lo que pasó en el periodo

- Se reprogramó el vaciado por la llegada tardía del acero
- Se ajustó el programa de obra con el contratista de estructura
- Se acordó con la interventoría cómo se miden las cantidades de obra

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 689.685.164 |
| Ejecutado | 494.907.240 |
| Proyección al cierre | 1.257.230.172 |

## Riesgos abiertos

- Compra de predios pendiente en el trazado
- Concentración del conocimiento en una sola persona
