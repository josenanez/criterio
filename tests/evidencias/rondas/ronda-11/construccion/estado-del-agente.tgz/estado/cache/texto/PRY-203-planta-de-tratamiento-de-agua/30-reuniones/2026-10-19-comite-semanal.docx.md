<!-- origen: PRY-203-planta-de-tratamiento-de-agua/30-reuniones/2026-10-19-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Contratación · Planta de tratamiento de agua

Fecha: 2026-10-19

Asistentes: Carlos Peña, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Elena Duarte

Entregar el punto 28

2026-10-17

Javier Hoyos

Entregar el punto 19

2026-10-15
