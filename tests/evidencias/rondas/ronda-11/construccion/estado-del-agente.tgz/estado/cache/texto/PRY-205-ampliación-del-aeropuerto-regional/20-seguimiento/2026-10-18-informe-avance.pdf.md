<!-- origen: PRY-205-ampliación-del-aeropuerto-regional/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ampliación del aeropuerto regional
Código: PRY-205
Fecha de corte: 2026-10-18
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 34%

Lo que pasó en el periodo
- El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite
- Se reprogramó el vaciado por la llegada tardía del acero

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 5.584.385.585
Ejecutado 4.482.743.262
Proyección al cierre 16.597.564.697

Riesgos abiertos
- Concentración del conocimiento en una sola persona
