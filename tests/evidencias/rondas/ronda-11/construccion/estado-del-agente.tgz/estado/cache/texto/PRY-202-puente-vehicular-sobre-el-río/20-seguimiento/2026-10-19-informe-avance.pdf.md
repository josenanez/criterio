<!-- origen: PRY-202-puente-vehicular-sobre-el-río/20-seguimiento/2026-10-19-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Puente vehicular sobre el río
Código: PRY-202
Fecha de corte: 2026-10-19
Gerente: Jorge Medina

Estado declarado
Amarillo
Avance reportado: 41%

Lo que pasó en el periodo
- Las lluvias detuvieron el movimiento de tierras durante nueve días

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 6.856.672.643
Ejecutado 1.801.285.079
Proyección al cierre 9.693.566.917

Riesgos abiertos
- Compra de predios pendiente en el trazado
- Cambio en la norma de sismorresistencia que puede mover el alcance
