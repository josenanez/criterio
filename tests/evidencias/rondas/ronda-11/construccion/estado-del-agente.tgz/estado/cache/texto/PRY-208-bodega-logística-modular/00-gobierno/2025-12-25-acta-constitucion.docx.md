<!-- origen: PRY-208-bodega-logística-modular/00-gobierno/2025-12-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Bodega logística modular

Código: PRY-208

Área dueña: Medio Ambiente

Patrocinador: María Restrepo

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Contratación

Producto asociado: bodegas en arriendo

Fecha de aprobación: 2025-12-25

Objetivo del negocio

Entregar bodega logística modular para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Contratación el 2025-12-25.

Fechas comprometidas

Fecha

Inicio

2026-01-04

Cierre

2026-12-31

Criterio de éxito

Bodega logística modular en producción y medido.

Dependencias declaradas

• Ninguna declarada
