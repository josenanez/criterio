<!-- origen: PRY-206-modelado-bim-de-proyectos/10-plan/2026-04-11-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseños de detalle aprobados,2026-07-23,2026-07-23,cerrado
Licencias y permisos obtenidos,2026-10-24,2026-10-24,en curso
Cimentación terminada,2027-01-25,2027-01-25,en curso
Estructura terminada,2027-04-29,2027-04-29,en curso
Entrega de obra al cliente,2027-07-31,2027-07-31,en curso
