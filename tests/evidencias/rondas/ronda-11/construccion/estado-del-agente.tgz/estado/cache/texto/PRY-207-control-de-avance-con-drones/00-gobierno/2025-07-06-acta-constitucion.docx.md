<!-- origen: PRY-207-control-de-avance-con-drones/00-gobierno/2025-07-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Control de avance con drones

Código: PRY-207

Área dueña: Seguridad y Salud en el Trabajo

Patrocinador: Carlos Peña

Gerente de proyecto: Paula Céspedes

Comité: Comité de Contratación

Producto asociado: No aplica

Fecha de aprobación: 2025-07-06

Objetivo del negocio

Entregar control de avance con drones para Seguridad y Salud en el Trabajo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Contratación el 2025-07-06.

Fechas comprometidas

Fecha

Inicio

2025-07-16

Cierre

2026-10-12

Criterio de éxito

Control de avance con drones en producción y medido.

Dependencias declaradas

• Ninguna declarada
