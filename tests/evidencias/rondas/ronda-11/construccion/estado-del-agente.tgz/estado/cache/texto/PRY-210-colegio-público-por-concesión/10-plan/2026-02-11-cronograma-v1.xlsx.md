<!-- origen: PRY-210-colegio-público-por-concesión/10-plan/2026-02-11-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseños de detalle aprobados | 2026-08-05 | 2026-08-05 | cerrado
Licencias y permisos obtenidos | 2027-01-17 | 2027-01-17 | en curso
Cimentación terminada | 2027-07-01 | 2027-07-01 | en curso
