<!-- origen: PRY-201-edificio-de-oficinas-torre-norte/2026-10-22-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión edificio de oficinas torre norte — 2026-10-22
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Beatriz Cuéllar dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 25/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-11-01
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
