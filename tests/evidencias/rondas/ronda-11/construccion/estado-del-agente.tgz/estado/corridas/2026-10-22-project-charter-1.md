# Corrida del 2026-10-22 · project-charter

13 proyectos · 34 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Revisión del acta 2026-05-13: falta autoridad del gerente, supuestos, restricciones, quién mide el éxito y cadencia; objetivo y criterio de éxito no medibles; exclusiones sin contenido. No se releyó el PDF del informe de avance.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

**Acta previa:** sí, una sola, del 2026-05-13 (`PRY-202-puente-vehicular-sobre-el-río/00-gobierno/2026-05-13-acta-constitucion.md`). Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22); no se registraron de nuevo.

## Acta — PRY-202 Puente vehicular sobre el río
**Estado:** existe, del 2026-05-13 (sin versiones posteriores)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No existe** (ni monto ni tipo de cambio) | Jorge Medina no puede saber qué decide solo. La proyección es 9.693.566.917 COP contra 9.500.000.000 aprobados (+193.566.917, ≈2,0 %): sin umbral declarado, ese sobrecosto y cualquier cambio de alcance (p. ej. por la norma de sismorresistencia) suben al comité por defecto. |
| Objetivo de negocio | Describe la solución: "Entregar puente vehicular sobre el río para Ingeniería" | No dice qué problema resuelve ni qué cambia al terminar; no hay contra qué decidir si un cambio de alcance vale la pena. |
| Alcance | Genérico: "Componente 1, 2, 3" | No se puede distinguir qué es cambio de alcance y qué es el alcance original; el control de cambios no tiene línea de partida. |
| Exclusiones | Declaradas pero vacías de contenido: "Lo que otro proyecto cubre" | No nombra qué proyecto ni qué cubre; no excluye nada verificable. Con la compra de predios pendiente (riesgo del informe), nadie sabe si está dentro o fuera. |
| Patrocinador | Andrés Lozano (persona) | Cumple. |
| Gerente | Jorge Medina (persona) | Cumple. |
| Supuestos | **No existe sección** | Los supuestos que sostienen el plan (predios, licencias para 2026-11-15, norma sismorresistente vigente) no están escritos; cuando fallan no hay nada que comparar. |
| Restricciones | **No existe sección** | Sin tope de fecha o de recurso declarado como restricción, el cierre 2027-05-11 y el presupuesto se leen como metas, no como límites. |
| Criterio de éxito | "Puente … en producción y medido": no medible | No hay métrica, umbral ni fecha. |
| Quién mide el éxito | **No existe** | "Medido" sin responsable: nadie puede declarar el éxito ni su fracaso. |
| Comité y cadencia | Comité de Contratación; cadencia no declarada | Un comité de contratación decide compras, no el alcance de una obra; la cadencia solo se infiere de un acta (2026-10-17). |
| Dependencias | "Ninguna declarada" | Contradice el informe de avance del 2026-10-19, que registra compra de predios pendiente y el cambio normativo como riesgos. |
| Hitos principales | Solo en el cronograma v1, no en el acta | Cuatro hitos (diseños 2026-08-19, licencias 2026-11-15, cimentación 2027-02-12, estructura 2027-05-11) sin vínculo con el acta. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar puente vehicular sobre el río para Ingeniería" (acta, 2026-05-13), que es la solución, no el objetivo.
**Alcance:** "Componente 1; Componente 2; Componente 3" (acta, 2026-05-13). Sin detalle.
**Exclusiones:** "Lo que otro proyecto cubre" (acta, 2026-05-13); sin contenido verificable.
**Patrocinador:** Andrés Lozano · **Gerente:** Jorge Medina (acta, 2026-05-13)
**Autoridad del gerente:** pendiente de definir. No está en ningún documento.
**Comité al que reporta:** Comité de Contratación (acta, 2026-05-13) · **Cadencia:** pendiente de definir (una reunión en el expediente: 2026-10-17).
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Puente vehicular sobre el río en producción y medido" (acta, 2026-05-13); no medible · **Lo mide:** pendiente de definir.
**Presupuesto aprobado:** 9.500.000.000 COP, Comité de Contratación, 2026-05-13 (acta). **Fechas:** inicio 2026-05-23, cierre 2027-05-11 (acta).
**Hitos principales** (cronograma v1, 2026-05-13): Diseños de detalle aprobados 2026-08-19 (cumplido, acta de recibo 2026-10-18); Licencias y permisos 2026-11-15 (pendiente); Cimentación terminada 2027-02-12 (pendiente); Estructura terminada 2027-05-11 (pendiente).

### Observaciones adicionales
- El hito "Diseños de detalle aprobados" (plan 2026-08-19) tiene acta de recibo del 2026-10-18, casi dos meses después de la fecha de línea base; la ficha lo marca "cumplido" con fecha vigente 2026-08-19. Eso es asunto de baseline-variance/status-report, no del acta, pero conviene verlo.
- El compromiso de Óscar Ramírez ("Entregar el punto 18", 2026-10-30) no identifica de qué punto se trata ni aparece en el acta como interesado; Óscar Ramírez no figura en el acta.
- No se leyó el contenido del informe de avance del 2026-10-19 (PDF): lo que se cita de él viene de la ficha ya extraída, no de una lectura nueva.

### Después
- **Autoridad sin declarar:** llevar esa definición al comité es una decisión, no un trámite (monto máximo y tipos de cambio que decide Jorge Medina sin comité). Propuesta: citarla en el próximo comité; no se completa un valor aquí.
- **Supuestos que salieron de la revisión** (predios, licencias a 2026-11-15, norma sismorresistente estable): se pueden pasar al registro RAID con `/raid-log PRY-202`.

*Pie de rigor: borrador de trabajo basado solo en el acta, el cronograma v1, el acta de comité del 2026-10-17 y la ficha existente; no incluye lo hablado fuera de documentos. Verifique cada cita contra su fuente antes de usarla.*
