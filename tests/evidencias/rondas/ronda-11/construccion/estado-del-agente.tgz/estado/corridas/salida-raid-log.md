# RAID — portafolio al 2026-10-22

**De qué documentos sale:** las 13 fichas (`estado/records/PRY-199` a `PRY-211`), los informes de avance y las actas de constitución (sección «Dependencias declaradas») que ellas citan, y 16 documentos de reunión: 15 actas de comité y las notas del 2026-10-22 de PRY-201. Leí el texto convertido en caché; las citas apuntan a los originales. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22).

15 riesgos · 0 supuestos · 17 incidencias · 7 dependencias (reclasificadas, ninguna confirmada)
39 sin doliente · sin movimiento: no medible · 1 no registrado formalmente

Ninguno de los 39 ítems tiene doliente, probabilidad, impacto ni mitigación registrados. Ningún riesgo ni dependencia tiene fecha. Las incidencias solo traen la fecha del informe que las menciona, no una fecha de resolución. Las acciones sobre el registro que propongo van marcadas «propuesta»; no asigné ni rellené nada.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-203-2, PRY-203-3 | Incidencia | Ensayo de concreto no alcanzó el valor pactado y se repite; dos semanas perdidas por rotación del residente | sin doliente | 2026-10-17 | Estado rojo, 93 % reportado; proyección al cierre 4.214.486.517 contra 3.300.000.000 aprobado; fecha fin en la ficha 2026-08-16, ya vencida; dos solicitudes de cambio autorizadas (CC-01 +101 días, CC-02 +46 días). Sin doliente. |
| PRY-211-2, PRY-211-3 | Incidencia | Hallazgo de seguridad en alturas; dos semanas perdidas por rotación del residente | sin doliente | 2026-10-17 | Estado rojo, 90 % reportado; ejecutado 1.507.625.105 mayor que comprometido 1.398.539.653. Sin doliente. |
| PRY-206 / 209 / 210 / 211 (incidencia «hallazgo de seguridad en alturas») | Incidencia | El mismo hallazgo aparece en cuatro proyectos | sin doliente | 2026-10-15 a 2026-10-22 | Seguridad abierta sin doliente ni fecha en cuatro proyectos; afecta a más de uno del portafolio. |
| PRY-201-4 | Incidencia | Ensayo de concreto no alcanzó el valor pactado y se repite | sin doliente | 2026-10-21 | Se declara verde con ejecutado 501.908.947 mayor que comprometido 269.031.166 (informe del 2026-10-21). Sin doliente. |
| PRY-205-2, PRY-205-3 y PRY-207-3 | Incidencia | Vaciado reprogramado por llegada tardía del acero (también concreto en PRY-205) | sin doliente | 2026-10-13 / 2026-10-18 | Fechas fin en la ficha ya vencidas (PRY-205: 2026-09-01; PRY-207: 2026-10-12) con 34 % y 32 % reportados, ambos en verde. Sin doliente. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo (con componente de dependencia de un tercero) | PRY-201, notas de reunión | 2026-10-22 |

La ficha de PRY-201 ya lo recogió como riesgo sin doliente (marcado ‡ abajo); el informe de avance del 2026-10-21 no lo trae. Es el único riesgo dicho en una reunión que encontré. Las otras 15 actas no mencionan ningún riesgo, supuesto ni dependencia: traen solo compromisos. No inventé ninguno. Los compromisos que vencieron o se dicen entregados sin acta en PRY-201 son materia de `pm-commitments`, no de este registro.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 15 riesgos | Riesgo | ver registro completo | doliente, probabilidad, impacto, fecha, mitigación |
| Las 7 dependencias | Dependencia | «Compra de predios pendiente» | doliente, fecha, contraparte y código del proyecto del que dependen |
| Las 17 incidencias | Incidencia | ver registro completo | doliente y fecha de resolución |

Propuesta de doliente (proponer, no asignar): el gerente de proyecto según la ficha para los ítems de cada proyecto. Para el hallazgo de seguridad en alturas, que se repite en cuatro proyectos, un solo responsable de seguridad definido por la PMO.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199-2 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-200-1 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-201-1 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-202-1 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-207-1 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-208-2 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |
| PRY-211-1 | contraparte sin identificar (sin código de proyecto) | No | Declarada en el informe de avance como riesgo; ninguna acta de constitución declara dependencias |

No hay ninguna dependencia entre proyectos declarada: las 13 actas de constitución dicen «Ninguna declarada». **El cruce de portafolio no se pudo hacer**: sin código de proyecto no se sabe de quién se depende ni si esa contraparte movió su fecha. Reclasifiqué «Compra de predios pendiente en el trazado» de riesgo a dependencia porque describe algo que ya está pendiente y que decide un tercero. Aparece en 7 proyectos, incluidos una pintura (PRY-199) y un proyecto de drones (PRY-207), donde un trazado no parece aplicar.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-1 | Riesgo | Cambio en la norma de sismorresistencia que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | 2026-10-20 |
| PRY-199-2 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-20 |
| PRY-200-1 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-09-30 |
| PRY-200-2 | Riesgo | Lluvias por encima del promedio en la temporada | no registrada | no registrado | sin doliente | sin fecha | 2026-09-30 |
| PRY-200-3 | Incidencia | El equipo perdió dos semanas por rotación del residente de obra | no registrada | no registrado | sin doliente | desde 2026-09-30 | 2026-09-30 |
| PRY-200-4 | Incidencia | Las lluvias detuvieron el movimiento de tierras durante nueve días | no registrada | no registrado | sin doliente | desde 2026-09-30 | 2026-09-30 |
| PRY-201-1 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-21 |
| PRY-201-2 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-21 |
| PRY-201-3 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión; las notas dicen que nadie lo anotó como riesgo) ‡ | no registrada | no registrado | sin doliente | sin fecha | 2026-10-22 |
| PRY-201-4 | Incidencia | El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite | no registrada | no registrado | sin doliente | desde 2026-10-21 | 2026-10-21 |
| PRY-202-1 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-19 |
| PRY-202-2 | Riesgo | Cambio en la norma de sismorresistencia que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | 2026-10-19 |
| PRY-202-3 | Incidencia | Las lluvias detuvieron el movimiento de tierras durante nueve días | no registrada | no registrado | sin doliente | desde 2026-10-19 | 2026-10-19 |
| PRY-203-1 | Riesgo | Cambio en la norma de sismorresistencia que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | 2026-10-17 |
| PRY-203-2 | Incidencia | El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite | no registrada | no registrado | sin doliente | desde 2026-10-17 | 2026-10-17 |
| PRY-203-3 | Incidencia | El equipo perdió dos semanas por rotación del residente de obra | no registrada | no registrado | sin doliente | desde 2026-10-17 | 2026-10-17 |
| PRY-204-1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-02 |
| PRY-205-1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-18 |
| PRY-205-2 | Incidencia | El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite | no registrada | no registrado | sin doliente | desde 2026-10-18 | 2026-10-18 |
| PRY-205-3 | Incidencia | Se reprogramó el vaciado por la llegada tardía del acero | no registrada | no registrado | sin doliente | desde 2026-10-18 | 2026-10-18 |
| PRY-206-1 | Riesgo | Lluvias por encima del promedio en la temporada | no registrada | no registrado | sin doliente | sin fecha | 2026-10-15 |
| PRY-206-2 | Riesgo | Cambio en la norma de sismorresistencia que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | 2026-10-15 |
| PRY-206-3 | Incidencia | Se levantó un hallazgo de seguridad en el trabajo en alturas | no registrada | no registrado | sin doliente | desde 2026-10-15 | 2026-10-15 |
| PRY-206-4 | Incidencia | Se reprogramó el vaciado por la llegada tardía del acero | no registrada | no registrado | sin doliente | desde 2026-10-15 | 2026-10-15 |
| PRY-207-1 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-13 |
| PRY-207-2 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-13 |
| PRY-207-3 | Incidencia | Se reprogramó el vaciado por la llegada tardía del acero | no registrada | no registrado | sin doliente | desde 2026-10-13 | 2026-10-13 |
| PRY-208-1 | Riesgo | Lluvias por encima del promedio en la temporada | no registrada | no registrado | sin doliente | sin fecha | 2026-10-21 |
| PRY-208-2 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-21 |
| PRY-209-1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-22 |
| PRY-209-2 | Incidencia | Las lluvias detuvieron el movimiento de tierras durante nueve días | no registrada | no registrado | sin doliente | desde 2026-10-22 | 2026-10-22 |
| PRY-209-3 | Incidencia | El equipo perdió dos semanas por rotación del residente de obra | no registrada | no registrado | sin doliente | desde 2026-10-22 | 2026-10-22 |
| PRY-209-4 | Incidencia | Se levantó un hallazgo de seguridad en el trabajo en alturas | no registrada | no registrado | sin doliente | desde 2026-10-22 | 2026-10-22 |
| PRY-210-1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | 2026-10-22 |
| PRY-210-2 | Riesgo | Lluvias por encima del promedio en la temporada | no registrada | no registrado | sin doliente | sin fecha | 2026-10-22 |
| PRY-210-3 | Incidencia | Se levantó un hallazgo de seguridad en el trabajo en alturas | no registrada | no registrado | sin doliente | desde 2026-10-22 | 2026-10-22 |
| PRY-211-1 | Dependencia (reclasificada) | Compra de predios pendiente en el trazado † | no registrada | no registrado | sin doliente | sin fecha | 2026-10-17 |
| PRY-211-2 | Incidencia | Se levantó un hallazgo de seguridad en el trabajo en alturas | no registrada | no registrado | sin doliente | desde 2026-10-17 | 2026-10-17 |
| PRY-211-3 | Incidencia | El equipo perdió dos semanas por rotación del residente de obra | no registrada | no registrado | sin doliente | desde 2026-10-17 | 2026-10-17 |

† Reclasificado de riesgo a dependencia: ya está pendiente y depende de un tercero.
‡ Detectado en reunión; no registrado formalmente por el gerente.

### Para verificar
- Los mismos textos se repiten palabra por palabra entre proyectos de naturaleza distinta (por ejemplo «vaciado por llegada tardía del acero» en un proyecto de drones y uno de BIM; «sismorresistencia» en una pintura). Pueden ser plantilla copiada y no riesgo real. Esto lo debe confirmar cada gerente.
- No hay histórico: solo existe el corte del 2026-10-22, así que «sin movimiento en dos períodos» y «mitigación vencida» no se pueden evaluar. Tampoco hay campo de mitigación en ninguna ficha.
- Los ids (`PRY-xxx-n`) los asigné en esta corrida por orden de aparición; el registro de origen no tiene ids.

### Después
¿Subo a comité los cinco grupos de «Necesitan decisión ahora»? Cumplen el criterio de escalamiento por afectar a más de un proyecto, por excederse en fecha o monto, o por no tener doliente. Cada uno iría con la decisión formulada: quién asume el ítem y para cuándo. También puedo preparar la propuesta de doliente por proyecto.

**Pie de rigor.** Fuentes citadas arriba; leí el caché de texto, no los originales. No sé nada de lo que se habló fuera de estos documentos. Probabilidad e impacto no están registrados y no usé escala. Borrador para su verificación, no decisión ni asesoría.
