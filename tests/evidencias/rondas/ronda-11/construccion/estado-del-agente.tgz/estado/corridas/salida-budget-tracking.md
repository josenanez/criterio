Sale de la ficha PRY-203 (`estado/records/PRY-203.json`) y del recálculo `portafolio.py compute` del 2026-10-22. Documentos fuente: acta de constitución (2025-07-24), informe de avance (2026-10-17), solicitudes de cambio CC-01 (2026-10-15) y CC-02 (2026-10-17), cronograma v3 (2026-10-17).

## Presupuesto — PRY-203 Planta de tratamiento de agua, al 2026-10-22
**Moneda:** COP (única en la ficha; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | 00-gobierno/2025-07-24-acta-constitucion.docx | 2025-07-24 |
| Comprometido | 2.066.126.764 | 62.6% | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Ejecutado | 1.510.877.959 | 45.8% | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Proyección al cierre | 4.214.486.517 | 27.7% por encima del aprobado | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |

**Disponible real** (aprobado menos comprometido): 1.233.873.236 COP

La proyección es una declaración del informe de avance (2026-10-17), no un dato duro. Es posterior a los dos cambios aprobados (CC-01 y CC-02), así que no está más vieja que el último movimiento de presupuesto.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 3.300.000.000 | no declarado | proyección 27.7% sobre el original |
| Plazo (referencia) | — | — | 147 días (63.6%) contra la original; 0 contra la vigente |

Cambios aprobados por el comité con efecto en costo: CC-01 (2026-10-15) +202.000.000 COP y CC-02 (2026-10-17) +92.000.000 COP, ambos ampliaciones de alcance.
Replanificaciones: 1 (de cronograma). De presupuesto: la ficha no registra una línea base de costo nueva; solo existe el aprobado de 2025-07-24. `compute` no entrega un presupuesto vigente, así que no lo calculo ni lo sumo a mano.

### Ejecución frente a avance
Ejecutado 45.8% · Hitos cumplidos 4 de 4 (declarados) · Avance declarado 93%.
Lectura: el avance declarado (93%) está muy por encima de lo ejecutado (45.8%), y la proyección al cierre está muy por encima de lo ejecutado a hoy. Sirve una de dos lecturas, y los documentos no permiten decidir cuál: hay trabajo hecho y no causado que aparecerá de golpe, o el avance está sobredeclarado. Dos de los 4 hitos (Cimentación terminada, Estructura terminada) figuran como cumplidos sin acta de recibo ni otra evidencia, lo que hace pesar la segunda lectura.

### Alertas
- **Proyección excede el aprobado:** 4.214.486.517 contra 3.300.000.000, 27.7% por encima (umbral 10%).
- **Desviación en plazo:** 147 días (63.6%) contra la línea base original.
- **Ejecución desalineada del avance:** 45.8% ejecutado contra 93% declarado.
- **Hitos cumplidos sin evidencia:** Cimentación terminada (vence 2026-01-23, 272 días) y Estructura terminada (vence 2026-08-16, 67 días).
- **Compromisos vencidos que tocan el cierre del informe:** Elena Duarte, "Entregar el punto 28" (vence 2026-10-17, 5 días); Javier Hoyos, "Entregar el punto 19" (vence 2026-10-15, 7 días). Acta: 30-reuniones/2026-10-19-comite-semanal.docx.
- El informe de avance declara estado rojo y no da cuenta de ninguna de estas señales (`unaccounted_signals`: compromisos vencidos, hitos sin evidencia, desviación de costo, desviación de plazo).
- Comprometido 62.6%: por debajo del umbral de 90%, sin alerta por ese concepto.

### Sin dato
- Presupuesto vigente (el original más CC-01 y CC-02): no declarado en ningún documento.
- Estado de las cifras de comprometido, ejecutado y proyección frente a esos cambios: el informe no dice si ya los incluye.
- No hay contratos de proveedor en la ficha, así que no hay detalle de comprometido por proveedor.
- Campos de identidad y de plan con fuente de 2025-07-24, antigüedad de 15 meses (umbral 12), incluido el aprobado.

### Siguiente paso posible
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto. El detalle por proveedor no está disponible, porque la ficha no tiene proveedores.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato lleva la cita del documento de donde salió y la verificación es de quien lo usa. Las cifras derivadas se copian de `portafolio.py compute`; lo que el script no da va como "sin dato".*
