# Corrida del 2026-10-22 · project-history

13 proyectos · 67 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Historia de PRY-203 sobre 9 documentos (2025-07-24 a 2026-10-19); 1 replanificación, 147 días de atraso vs. original. Dijo que no sabe: qué pasó entre 2025-07-24 y 2026-10-11, el motivo de la replanificación, el contenido de los puntos 19 y 28, y los meses declarando sin sustento (un solo estado declarado).

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

## Historia · PRY-203 Planta de tratamiento de agua · 2025-07-24 a 2026-10-19

**Leí:** 9 documentos entre 2025-07-24 y 2026-10-19
**Trimestres sin un solo documento:** 2025-T4, 2026-T1, 2026-T2 y 2026-T3. Entre el acta de constitución (2025-07-24) y la primera acta de recibo (2026-10-11) la carpeta no tiene nada.

*Términos: vigentes (versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-22). No hizo falta volver a registrarlos.*

### En una línea
El proyecto se constituyó el 2025-07-24 con cierre al 2026-03-22 y 3.300.000.000 COP. Casi todo lo que hay después quedó escrito entre el 2026-10-11 y el 2026-10-19: dos actas de recibo, dos solicitudes de cambio aprobadas (+101 y +46 días), un cronograma v3 que mueve el cierre al 2026-08-16, un informe en rojo con 93 % y un comité. Los datos son de un solo mes y no dicen qué pasó durante los 14 meses anteriores.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 147 días (63.6 %) | No se puede calcular: hay un solo estado declarado (2026-10-17) | 0 detectados |

La cifra de «meses declarando sin sustento» no sale del script y no hay serie de estados declarados con la que calcularla. Se necesitarían informes de avance de períodos anteriores.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-07-24 | `00-gobierno/2025-07-24-acta-constitucion.docx` | Nace el proyecto. Patrocinadora Laura Vélez, gerente Carlos Peña, Comité de Contratación. Presupuesto de 3.300.000.000 COP. Inicio 2025-08-03, cierre 2026-03-22. |
| 2025-07-24 | `10-plan/2025-07-24-cronograma-v1.xml` | Línea base v1 con 4 hitos: 2025-09-29, 2025-11-26, 2026-01-23 y 2026-03-22. |
| 2026-10-11 | `20-seguimiento/2026-10-11-acta-recibo-licencias-y-permisos-obtenidos.md` | Se recibe «Licencias y permisos obtenidos». Su hito era del 2025-11-26. |
| 2026-10-15 | `20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +101 días, +202.000.000 COP. «Autorizada por el comité». |
| 2026-10-17 | `20-seguimiento/2026-10-17-solicitud-cambio-cc-02.md` | CC-02: ampliación de alcance, +46 días, +92.000.000 COP. «Autorizada por el comité». |
| 2026-10-17 | `10-plan/2026-10-17-cronograma-v3.xml` | Línea base v3: «Estructura terminada» pasa del 2026-03-22 al 2026-08-16. Los 4 hitos figuran al 100 %. |
| 2026-10-17 | `20-seguimiento/2026-10-17-informe-avance.md` | Estado declarado **rojo**, 93 %. Proyección al cierre 4.214.486.517 COP. |
| 2026-10-19 | `20-seguimiento/2026-10-19-acta-recibo-diseños-de-detalle-aprobados.pdf` | Se recibe «Diseños de detalle aprobados». Su hito era del 2025-09-29. |
| 2026-10-19 | `30-reuniones/2026-10-19-comite-semanal.docx` | Comité con Carlos Peña y Laura Vélez. Dos compromisos, ambos ya vencidos. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-17 | 2026-08-16 | No documentado. El informe de avance menciona un «ajuste del programa de obra con el contratista de estructura», pero no lo vincula a un cambio de fecha. | `cronograma-v3.xml` es el plan. CC-01 (+101) y CC-02 (+46) son los cambios aprobados. Ninguno de los dos documenta una sesión de comité. |

- La línea base original (2026-03-22) y la vigente (2026-08-16) están separadas por 147 días, que es la suma de CC-01 y CC-02 según el script. Es el atraso acumulado contra el original; contra la vigente es de 0 días.
- La carpeta no tiene un cronograma v2. La numeración salta de v1 a v3.
- La fecha de cierre nueva (2026-08-16) es anterior a la fecha del documento que la fija (2026-10-17). La replanificación quedó escrita después de la fecha que establece.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité detectado. | El acta de constitución y el comité del 2026-10-19 coinciden en Laura Vélez, Carlos Peña y el Comité de Contratación. |

El informe de avance cuenta que «el equipo perdió dos semanas por rotación del residente de obra». Ese cargo no está en el gobierno registrado, así que no se cuenta como cambio. Tampoco hay un documento que diga quién es ese residente ni cuándo cambió.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Elena Duarte | Entregar el punto 28 | 1 | 2026-10-17 (vencido hace 5 días) |
| Javier Hoyos | Entregar el punto 19 | 1 | 2026-10-15 (vencido hace 7 días) |

No hay compromisos repetidos: la carpeta solo tiene una minuta. Los dos que existen ya están vencidos. Ninguno de los dos dolientes figura entre los asistentes. Los documentos no dicen qué son el «punto 28» ni el «punto 19».

### Desde cuándo lo declarado no se sostiene
No se puede fijar una fecha de inicio del deslizamiento: la carpeta no tiene nada entre 2025-07-24 y 2026-10-11.

Lo que sí se puede decir con fecha:
- **«Cimentación terminada»** (hito del 2026-01-23, 272 días atrás) figura como cumplido en el cronograma v3 del 2026-10-17 y no tiene acta de recibo ni otra evidencia en la carpeta. Es el primer hito sin sustento.
- **«Estructura terminada»** (hito vigente del 2026-08-16, 67 días atrás) figura como cumplido sin evidencia. Esto choca con el informe del mismo día, que dice que el ensayo de resistencia del concreto no alcanzó el valor pactado y se repite.
- Las dos actas que sí existen se firmaron mucho después del hito: la de licencias el 2026-10-11 (hito del 2025-11-26) y la de diseños el 2026-10-19 (hito del 2025-09-29). Esta última es posterior al cronograma v3 y al informe, que ya daban el hito por cumplido.
- Avance declarado: 93 %. El plan sostiene entre 100 % y 100 % (brecha de 7 puntos), porque los 4 hitos figuran cumplidos. Lo ejecutado es 45.8 % del presupuesto y lo comprometido 62.6 %.
- El cronograma v1, fechado el 2025-07-24, ya trae los 4 hitos al 100 %. Un plan recién aprobado no debería traerlos así; el archivo se editó después de su fecha o la fecha del nombre no es la del contenido.

Después de esto se siguió reportando: estado rojo, 93 %, una proyección de 4.214.486.517 COP contra 3.300.000.000 aprobados (27.7 % por encima) y dos solicitudes de cambio «autorizadas por el comité».

### Lecciones ancladas a un hecho
- **Las aprobaciones de cambio no dejan constancia de la sesión.** CC-01 (2026-10-15) y CC-02 (2026-10-17) dicen «Autorizada por el comité». La única minuta (2026-10-19) no las menciona. Efecto: el atraso de 147 días queda aprobado sin acta que lo respalde.
- **El cronograma v3 se publicó sin v2 y con una fecha de cierre ya vencida.** Hecho: 2026-10-17, cierre al 2026-08-16. Efecto: la línea base vigente muestra 0 días de atraso a pesar de estar vencida.
- **Dos hitos cumplidos sin evidencia.** Hecho: «Cimentación terminada» y «Estructura terminada» a 2026-10-17. Efecto: el 93 % declarado no se puede verificar contra documentos.

## Qué no sé
- Qué pasó entre 2025-07-24 y 2026-10-11: no hay documentos.
- Por qué el cierre se movió. Ningún documento da el motivo.
- Qué contienen los puntos 19 y 28.
- Desde cuándo se declara avance sin sustento, porque solo hay un estado declarado.

Este documento no atribuye intención. Que el atraso quede registrado casi todo de una vez no dice por qué ni quién. Esa conversación es entre personas y esta historia sirve para tenerla con datos. Puedo llevarla al cierre del proyecto o al comité, si hay una decisión que salga de ella.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cifras copiadas de la salida de `compute` del 2026-10-22; cada dato viene del documento citado. Verifíquelo contra los originales.*
