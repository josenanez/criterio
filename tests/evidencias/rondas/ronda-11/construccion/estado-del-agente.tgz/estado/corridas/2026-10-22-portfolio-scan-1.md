# Corrida del 2026-10-22 · portfolio-scan

13 proyectos · 74 documentos, 0 releídos y 74 sin cambio · 154 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

10 fichas nuevas (PRY-199,200,202-208,211), 51 documentos leídos y 23 sin cambio (PRY-201,209,210 sin tocar). Nada movido: no existe entrada/. Los 4 .xml se convirtieron con texto.py. Mirar: hitos cerrados sin acta (200,203,204,205,211), PRY-205 y PRY-207 con cierre vencido y avance bajo en verde, CC de 200/203/204 fechadas después del cronograma, 4 compromisos vencidos, contrato CT-199 que no corresponde a una pintura.

Contra la corrida del 2026-10-22: +29 hallazgos.

## Lo que produjo

## Barrido — 2026-10-22

**Documentos:** 74 en la carpeta · 51 leídos · 23 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta (PRY-199 a PRY-211) · 10 fichas nuevas escritas y selladas · 3 sin tocar (PRY-201, PRY-209, PRY-210: sus documentos no cambiaron) · 0 sin carpeta propia

Términos vigentes: versión 1.2, aceptada por José Francisco Ñáñez el 2026-10-22 (no hizo falta registrarlos otra vez). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Formatos: 33 .md · 14 .docx · 11 .pdf · 7 .xlsx · 4 .xml · 3 .csv · 1 .json · 1 .txt. El plan marcó 4 cronogramas .xml (Project) como «no se lee sin instalar algo»; `texto.py` los convirtió sin instalar nada y los leí (PRY-200 v2, PRY-203 v1 y v3, PRY-211 v1). Nada se omitió.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Pintura de la sede administrativa | 6 | identidad, fechas, presupuesto, 5 hitos, contrato CT-199 (3 entregables), 2 riesgos, 1 compromiso | autoridad, fase, evidencia de recibo de los 3 entregables del contrato, facturado |
| PRY-200 Variante vial del sur | 6 | identidad, fechas, 4 hitos (2 cronogramas), CC-01, 2 riesgos, 2 incidencias, 1 compromiso | producto («No aplica»), autoridad, fase, evidencia de 3 hitos cerrados |
| PRY-202 Puente vehicular sobre el río | 5 | identidad, fechas, 4 hitos, presupuesto, 2 riesgos, 1 incidencia, 1 compromiso | producto, autoridad, fase |
| PRY-203 Planta de tratamiento de agua | 9 | identidad, 4 hitos (v1 y v3), CC-01 y CC-02, 2 actas de recibo, 1 riesgo, 2 incidencias, 2 compromisos | producto, autoridad, fase, evidencia de 2 hitos cerrados |
| PRY-204 Vivienda de interés social etapa 2 | 6 | identidad, producto «vivienda VIS», 4 hitos (v1 y v2), CC-01, 1 riesgo | autoridad, fase, evidencia de 2 hitos cerrados; sin minutas |
| PRY-205 Ampliación del aeropuerto regional | 4 | identidad, 4 hitos, presupuesto, 1 riesgo, 2 incidencias, 1 compromiso | producto, autoridad, fase, evidencia de los 4 hitos cerrados |
| PRY-206 Modelado BIM de proyectos | 5 | identidad, producto «modelos BIM», 5 hitos, 2 riesgos, 2 incidencias, 2 compromisos | autoridad, fase |
| PRY-207 Control de avance con drones | 2 | identidad, presupuesto, estado declarado, 2 riesgos, 1 incidencia | producto, autoridad, fase, cronograma e hitos (no hay cronograma) |
| PRY-208 Bodega logística modular | 3 | identidad, producto «bodegas en arriendo», presupuesto, CC-01 pendiente, 2 riesgos | autoridad, fase, cronograma e hitos, quién decide CC-01 |
| PRY-211 Hospital de segundo nivel | 5 | identidad, 4 hitos, presupuesto, 1 riesgo, 2 incidencias, 1 compromiso | producto, autoridad, fase, evidencia de 1 hito cerrado |

(Detalle campo por campo en `meta.fields_not_found` de cada ficha. En PRY-199 el único hito cerrado, «Diseños de detalle aprobados», sí tiene acta; su vacío son los entregables del contrato. El estado declarado y el avance de los 10 proyectos se guardaron como declaración del gerente, no como evidencia.)

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-201, PRY-209, PRY-210 | Nada: los documentos son los mismos de la corrida anterior (23). No se releyeron. | — |

### Para mirar (lo que salta a la vista al levantar las fichas)
Esto es lo que los documentos muestran; el cálculo de desviaciones y señales lo hace `informe`, no este barrido.

- **Hitos cerrados sin acta de recibo:** PRY-200 (3: diseños, licencias, cimentación), PRY-203 (2: cimentación, estructura), PRY-204 (2: licencias, cimentación), PRY-205 (los 4), PRY-211 (1: licencias). Lo declara el cronograma; ningún documento lo prueba. PRY-199, PRY-202, PRY-206 sí tienen acta del hito de diseños.
- **PRY-205:** el cronograma declara cerrado «Estructura terminada» (2026-09-01) y los cuatro hitos, pero el informe del 2026-10-18 reporta 34 % de avance en verde; la fecha de cierre del acta (2026-09-01) ya pasó.
- **PRY-207:** el cierre comprometido era 2026-10-12; el informe del 2026-10-13 reporta 32 % en verde. No hay cronograma ni minutas.
- **Cambios con impacto en fechas:** PRY-200 (CC-01, +111 días, +222.000.000 COP sobre 800.000.000) y PRY-203 (CC-01 y CC-02, +147 días y +294.000.000 COP en total) tienen cronograma nuevo que mueve «Estructura terminada» (PRY-200 de 2026-12-10 a 2027-03-31; PRY-203 de 2026-03-22 a 2026-08-16). PRY-204 (CC-01 +58 días) mueve la misma estructura de 2026-11-11 a 2027-01-08. En los tres, la solicitud de cambio está fechada después del cronograma que parece reflejarla (200: 09-30 vs 10-14; 203: v3 del 10-17 es el mismo día que CC-02; 204: 10-02 vs 10-17), y en PRY-200 y PRY-204 el informe declara verde. PRY-203 v2 no está en la carpeta (hay v1 y v3).
- **Ejecutado por encima de lo comprometido:** PRY-206 (3.198.959.008 ejecutado vs 2.410.717.775 comprometido) y PRY-211 (1.507.625.105 vs 1.398.539.653).
- **PRY-211:** estado rojo con 90 % de avance; proyección al cierre 2.439.748.860 contra 2.400.000.000 aprobados.
- **PRY-203:** rojo, 93 %, proyección 4.214.486.517 contra 3.300.000.000 aprobados; el cierre del acta (2026-03-22) está vencido.
- **Compromisos vencidos sin evidencia de cumplimiento (4):** PRY-200 Beatriz Cuéllar (punto 35, 2026-10-19); PRY-203 Elena Duarte (punto 28, 2026-10-17) y Javier Hoyos (punto 19, 2026-10-15); PRY-206 Sandra Gil (punto 14, 2026-10-10). Abiertos: 5 más (PRY-199, 202, 205, 206, 211).
- **PRY-208:** CC-01 (+30 días, +60.000.000 COP) está «pendiente de presentación al comité»; sin cronograma contra el cual medir.
- **PRY-199:** el contrato CT-199 con Constructora del Valle (3 entregables de 144.000.000 COP, todos pendientes) cubre acero de refuerzo, horas de ingeniería e izaje, que no corresponden a una pintura; el acta y el informe de este proyecto también hablan de sismorresistencia y compra de predios. Lo registré tal cual; conviene confirmar que el contrato está bien archivado.
- **Riesgos sin dueño ni fecha:** todos los extraídos de los informes (owner `null`).

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 4 .xml que el plan marcaba como no legibles se convirtieron con `texto.py`. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` en `documentos/proyectos`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

---
criterio-portfolio 0.8.0 · 10 fichas tocadas (PRY-199, 200, 202, 203, 204, 205, 206, 207, 208, 211) · campos en `not_found`: 45 en total (autoridad y fase en las 10; producto en 6; el resto, evidencia de hitos cerrados, evidencia y facturación del contrato CT-199, cronograma ausente en PRY-207 y PRY-208, y quién decide CC-01 de PRY-208; ver `meta.fields_not_found`) · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Siguiente paso:** hay más de un proyecto con ficha, así que puedo generar el informe consolidado (`/criterio-portfolio:portfolio-report`).
