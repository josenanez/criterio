# Corrida del 2026-10-22 · vendor-tracking

13 proyectos · 28 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Informe de proveedores de PRY-201 (CT-521): 2 entregables tardíos sin evidencia, 0 aceptados; no se pudo evaluar vigencia/preaviso ni facturación porque no están en los documentos.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

## Proveedores — PRY-201 Edificio de oficinas Torre Norte al 2026-10-22

**Sale de:** `00-gobierno/2026-04-14-contrato-ct-521.docx`, `00-gobierno/ficha-pm.json`, `20-seguimiento/` (actas de recibo, informe de avance 2026-10-21), `30-reuniones/` (6 comités), `2026-10-22-notas-reunion.txt`, y las cifras de `portafolio.py compute`. Términos vigentes (v1.2, aceptados por José Francisco Ñáñez el 2026-10-22).

### Interventorías Técnicas S.A.S. — contrato CT-521
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2026-04-14) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Suministro de acero de refuerzo (COP 77.546.392) | 2026-06-28 | pendiente, 116 días de atraso | ninguna | sin dato |
| Bolsa de horas de ingeniería (COP 77.546.392) | 2026-09-01 | el contrato dice «en curso»; la ficha lo recoge como pendiente; 51 días pasada la fecha | ninguna | sin dato |
| Alquiler de equipos de izaje (COP 77.546.392) | 2026-11-04 | pendiente, aún no vence (13 días) | ninguna | sin dato |

Cifras del script: 3 entregables, 0 aceptados, 2 tardíos, 0 aceptados sin evidencia, facturado sin dato.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Estado de la bolsa de horas | «en curso» | La ficha lo registra «pendiente» y no hay acta ni mención de avance; la fecha pasó hace 51 días | contrato CT-521; ficha-pm.json |
| Informe de avance en verde | — | El informe 2026-10-21 declara «verde» con dos entregables del proveedor vencidos sin evidencia | 20-seguimiento/2026-10-21-informe-avance.md; contrato CT-521 |

No se levantó `vendor_invoiced_without_delivery`: no hay ninguna factura declarada en los documentos.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Suministro de acero de refuerzo | pendiente | vencido desde 2026-06-28 |
| Bolsa de horas de ingeniería | pendiente (contrato: en curso) | vencido desde 2026-09-01 |
| Alquiler de equipos de izaje | pendiente | vence 2026-11-04 |

Ningún entregable figura como entregado o aceptado. Las actas de recibo de la carpeta (2026-09-24 «matriz 6», 2026-10-08 «prueba 10», 2026-10-10 «Diseños de detalle aprobados») no corresponden a entregables de CT-521; no las usé como evidencia del proveedor.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Ninguno vencido atribuible al proveedor | — | — | — |

Hay un compromiso de Óscar Ramírez «revisión con el proveedor» para 2026-11-01 (notas del 2026-10-22), todavía no vence. Los 9 compromisos vencidos del proyecto son de personas internas, no del proveedor; van en `/commitment-tracking`.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-521: el contrato no los trae. No puedo decir si el preaviso vence antes del cierre del proyecto (2026-12-15).
- Monto facturado a la fecha: ninguna factura en la carpeta.
- Evidencia de aceptación de los tres entregables.
- Las notas del 2026-10-22 recogen que «el proveedor podría no llegar con el equipo completo para la siguiente fase» y que nadie lo anotó como riesgo. No dice de qué proveedor; es un candidato a RAID, no un hallazgo de este informe.

### Después
Condición de pago de CT-521: cada entregable se factura contra acta de recibo firmada por el gerente del proyecto. Hoy no hay ni acta ni factura; antes de aprobar cualquier factura, exigir el acta. Si el acero y la bolsa de horas llevan 116 y 51 días de atraso y el informe sigue en verde, vale llevarlo a comité.

---
**Rigor:** cifras tomadas de `portafolio.py compute` (as_of 2026-10-22); ninguna recalculada a mano salvo los 13 días hasta 2026-11-04. Lo que no está en los documentos se declara como sin dato; lo hablado fuera de ellos no lo sé.
