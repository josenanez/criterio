# Corrida del 2026-10-22 · change-control

13 proyectos · 40 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Solicitud de mover 30 días la salida a producción de PRY-206 (leída como cierre, 2027-07-31 a 2027-08-30). Sin autoridad de cambios declarada, sin solicitante ni motivo, sin costo del cambio; impact no alcanza a ningún proyecto porque no hay dependencias declaradas. No sabe qué hito es la salida a producción ni cuántos días se mueve cada hito.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-206 (estado/records/PRY-206.json, actualizada 2026-10-22). Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-22.

Supuesto tomado (sesión sin interfaz, respuesta sugerida): «salida a producción» se lee como el cierre del proyecto, porque el criterio de éxito del acta es «en producción y medido» y el cierre comprometido es 2027-07-31. Si se refiere a otro hito, el cálculo cambia.

## Solicitud de cambio — PRY-206 Modelado BIM de proyectos — 2026-10-22

**Qué se pide:** mover la salida a producción (cierre) 30 días. · **Quién lo pide:** no consta en ningún documento. · **Por qué:** no consta; la solicitud no trae motivo y la carpeta tampoco.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta 2026-04-11) | Sin cambio declarado | 0 declarado |
| Tiempo | Cierre 2027-07-31 (línea base 1) | 2027-08-30 | +30 días |
| Costo | Aprobado COP 6.800.000.000; proyección COP 7.897.229.155 (informe 2026-10-15) | No declarado | No declarado |

**Quién absorbe lo que no se declaró.** Alcance sin cambio y costo sin cambio con 30 días más de plazo significa que alguien lo absorbe: horas no pagadas del equipo o recorte de calidad. Y el costo ya viene mal sin este cambio: la proyección está COP 1.097.229.155 (+16,1 %) por encima de lo aprobado, sobre un umbral de 10 %. Treinta días más de equipo no pueden costar cero; el valor no está en ningún documento y no lo invento.

**Otras señales de la ficha que pesan sobre la solicitud**
- Ejecutado COP 3.198.959.008 = 47,0 % de lo aprobado, frente a 69 % de avance declarado (informe 2026-10-15).
- Comprometido (COP 2.410.717.775) es menor que ejecutado (COP 3.198.959.008). Un comprometido por debajo de lo ejecutado no cuadra; falta saber cuál de las dos cifras está mal.
- «Licencias y permisos obtenidos» vence el 2026-10-24 (en 2 días), pendiente y sin evidencia. Si ese hito se corre, el cierre ya no se mueve solo 30 días.
- Los hitos del cronograma (cimentación, estructura, entrega de obra) son de construcción, no de modelado BIM. Conviene confirmar que el cronograma es el de este proyecto.
- Dos incidencias abiertas sin dueño (hallazgo de seguridad en alturas; vaciado reprogramado por acero tardío) y un compromiso vencido (Sandra Gil, punto 14, para 2026-10-10).

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno calculado | `impact` devuelve 0 proyectos alcanzados, directos o indirectos, 0 que no puedan sostener su fecha y 0 dependencias sin confirmar | — |

Esto es **ausencia de dependencias declaradas, no ausencia de efecto**: el acta dice «Ninguna declarada» y ninguna otra ficha apunta a PRY-206. Si otro proyecto usa estos modelos, nadie lo escribió. Tampoco se sabe cuántos días se mueve cada hito intermedio: eso necesita holgura por actividad y la ficha no la tiene. El cierre pasa a 2027-08-30; por el cambio pasan 4 hitos (licencias 2026-10-24, cimentación 2027-01-25, estructura 2027-04-29, entrega 2027-07-31), pero cuáles se mueven de verdad no se calcula aquí.

### Quién decide
**Autoridad requerida:** no determinable. · **Según:** el acta no declara autoridad de cambios (`identity.authority`: no encontrado) ni umbrales de tiempo o costo; solo dice que el Comité de Seguridad aprobó el presupuesto el 2026-04-11. · **Va a comité:** sí, por defecto. El único órgano que consta aprobando la línea base es el Comité de Seguridad (patrocinador Rubén Cárdenas, gerente Óscar Ramírez), y un cambio de fecha no debería decidirse por debajo de quien aprobó el plan. Que el Comité de Seguridad sea el órgano de un proyecto de modelado BIM también hay que confirmarlo.

**Hallazgo de fondo:** el proyecto no tiene autoridad de cambios declarada. Eso se resuelve antes de aprobar esta solicitud.

### Si no se aprueba
El proyecto sigue con cierre 2027-07-31, con la proyección ya 16,1 % sobre el presupuesto, avance declarado 69 % contra 47 % de presupuesto ejecutado, y un hito de licencias que vence en 2 días sin evidencia. No hay desviación de tiempo registrada todavía contra la línea base 1.

### Si se aprueba
Línea base 2 — cierre 2027-08-30 · presupuesto: sin cambio declarado (COP 6.800.000.000; la proyección de COP 7.897.229.155 no queda cubierta) · motivo: no consta, hay que traerlo.
Desviación acumulada contra la línea base original (1, cierre 2027-07-31): +30 días · costo: +COP 1.097.229.155 (+16,1 %) de proyección sobre lo aprobado, sin sumar el costo de los 30 días, que no está declarado.
Replanificaciones: 0 hasta hoy; pasaría a 1. La línea base 1 no se toca. Cambios registrados en la ficha: ninguno, así que no hay tiempo autorizado previo que reconciliar.

### Lo que esta salida no sabe
Quién pide el cambio y por qué; el costo de 30 días más; qué hito es «la salida a producción»; quién tiene autoridad de aprobarlo; y qué otros proyectos dependen de este.

### Después
Ofrezco llevarlo a comité con el paquete de decisión (`/steering-pack`) y, si se aprueba, registrar la línea base 2.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de la ficha PRY-206 y de los documentos citados en ella (acta de constitución 2026-04-11, cronograma v1, informe de avance 2026-10-15, comité semanal 2026-10-17). La verificación es de quien lo lea.
