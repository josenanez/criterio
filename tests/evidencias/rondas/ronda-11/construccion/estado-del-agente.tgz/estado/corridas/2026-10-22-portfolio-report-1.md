# Corrida del 2026-10-22 · portfolio-report

13 proyectos · 74 documentos, 0 releídos y 74 sin cambio · 48 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

El informe quedó en `reportes`.

5 proyectos en verde contradichos por la evidencia (PRY-200, 201, 204, 205, 209); sin delta: primera instantánea.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-22
13 proyectos · 9 con hallazgos (54 señales) · fichas del 2026-10-22 (las 13, frescas; ninguna con más de una semana sin barrido).
Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-22.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la del 2026-10-22, de este mismo día: esto es el punto de partida, no hay delta real.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes.

## Hitos vencidos sin evidencia
17 hitos declarados "cumplidos" sin documento que lo sustente:
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-205 | Diseños de detalle aprobados | 2025-10-15 | 372 |
| PRY-203 | Cimentación terminada | 2026-01-23 | 272 |
| PRY-205 | Licencias y permisos obtenidos | 2026-01-30 | 265 |
| PRY-209 | Diseños de detalle aprobados | 2026-03-27 | 209 |
| PRY-205 | Cimentación terminada | 2026-05-17 | 158 |
| PRY-204 | Licencias y permisos obtenidos | 2026-05-31 | 144 |
| PRY-200 | Diseños de detalle aprobados | 2026-06-01 | 143 |
| PRY-209 | Licencias y permisos obtenidos | 2026-07-11 | 103 |
| PRY-201 | Licencias y permisos obtenidos | 2026-07-27 | 87 |
| PRY-200 | Licencias y permisos obtenidos | 2026-08-04 | 79 |
| PRY-210 | Diseños de detalle aprobados | 2026-08-05 | 78 |
| PRY-203 | Estructura terminada | 2026-08-16 | 67 |
| PRY-204 | Cimentación terminada | 2026-08-21 | 62 |
| PRY-205 | Estructura terminada | 2026-09-01 | 51 |
| PRY-201 | Cimentación terminada | 2026-09-12 | 40 |
| PRY-211 | Licencias y permisos obtenidos | 2026-09-19 | 33 |
| PRY-200 | Cimentación terminada | 2026-10-07 | 15 |

Compromisos de reunión vencidos sin evidencia: 14 (9 en PRY-201, 2 en PRY-203, 1 en cada uno de PRY-200, PRY-206 y PRY-209). Reprogramados varias veces: Beatriz Cuéllar (PRY-201, 6 veces, original 2026-10-02) y Mauricio Pérez (PRY-201, 5 veces, original 2026-09-16). 3 compromisos sin fecha en PRY-201.

## Proyectos en silencio
Vacía: el más callado es PRY-207 con 9 días, bajo el umbral de 15.

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias entre proyectos.
Proveedor: PRY-201, Interventorías Técnicas S.A.S., con 2 entregables pendientes y vencidos (acero de refuerzo, 116 días; bolsa de horas de ingeniería, 51 días).

## Sin sustento
5 proyectos declaran verde y los documentos no lo sostienen:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | verde (73 %, 2026-09-30) | contradicho: atraso de 111 días (43,4 %), hitos sin evidencia, compromiso vencido |
| PRY-201 | verde (51 %, 2026-10-21) | contradicho: compromisos vencidos y reprogramados, hitos y entregables de proveedor sin evidencia |
| PRY-204 | verde (76 %, 2026-10-02) | contradicho: atraso de 58 días (17,7 %), hitos sin evidencia |
| PRY-205 | verde (34 %, 2026-10-18) | contradicho: el plan con 4 de 4 hitos cumplidos soporta 100 %; el avance declarado es 66 puntos menor |
| PRY-209 | verde (44 %, 2026-10-22) | contradicho: compromiso vencido 24 días, hitos sin evidencia |

Avance declarado por encima del plan (no es contradicción de color, pero hay que explicarlo): PRY-206 (69 % vs 20–40 %), PRY-210 (82 % vs 33–67 %), PRY-211 (90 % vs 50–75 %).

## Vacíos de información
Ninguna ficha tiene autoridad (patrocinador/decisor) identificada: 13 de 13. Fase sin identificar en la mayoría; sin producto asociado en 8 (PRY-200, 202, 203, 205, 207, 209, 210, 211). Casi todos los proyectos tienen hitos sin evidencia citada. Campos con más de 12 meses sin actualizar en PRY-203, PRY-205 y PRY-207.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Pintura sede administrativa | verde | sin señales | 0 d | 0 d | 0 |
| PRY-200 Variante vial del sur | verde | contradicho | +111 d (43,4 %) | 0 d | 1 |
| PRY-201 Edificio Torre Norte | verde | contradicho | 0 d | 0 d | 0 |
| PRY-202 Puente vehicular | amarillo | sin señales | 0 d | 0 d | 0 |
| PRY-203 Planta de agua | rojo | consistente; costo +27,7 % (4.214 M vs 3.300 M COP) | +147 d (63,6 %) | 0 d | 1 |
| PRY-204 Vivienda VIS etapa 2 | verde | contradicho | +58 d (17,7 %) | 0 d | 1 |
| PRY-205 Aeropuerto regional | verde | contradicho | 0 d | 0 d | 0 |
| PRY-206 Modelado BIM | amarillo | costo +16,1 % (7.897 M vs 6.800 M COP) | 0 d | 0 d | 0 |
| PRY-207 Drones | verde | sin señales | 0 d | 0 d | 0 |
| PRY-208 Bodega modular | verde | sin señales | 0 d | 0 d | 0 |
| PRY-209 Doble calzada | verde | contradicho | 0 d | 0 d | 0 |
| PRY-210 Colegio por concesión | amarillo | avance sobre el plan | 0 d | 0 d | 0 |
| PRY-211 Hospital segundo nivel | rojo | avance sobre el plan | 0 d | 0 d | 0 |

Además: PRY-200 y PRY-204 tienen un cambio (CC-01) que movió la fecha sin línea base nueva registrada. PRY-207 tiene fecha fin 2026-10-12 ya pasada y se declara verde con 32 % (sin señal calculada; vale mirarlo).

## Necesito que confirmes
En esta corrida no armé las cinco preguntas de confirmación mensual (primera corrida, sin historial de confirmaciones). Lo que sí requiere decisión está en `decisiones.html`.

---
**Informe HTML** en `reportes/` (22 páginas: `index.html`, `decisiones.html` y una por proyecto).
- `index.html`: por campo, con la cadena de evidencia; para quien va a actuar (gerente de PMO, equipos).
- `decisiones.html`: por decisión, solo lo que excede la facultad del gerente; para el patrocinador y el comité.
PDF: imprimir el HTML desde el navegador.

Pie: Criterio Portfolio v0.8.0 · fichas aplicadas: 13, todas del 2026-10-22 · campos inciertos: ver "Vacíos de información" · términos v1.2: https://www.josenanez.com/es/agents/criterio-pmo/legal
