# Corrida del 2026-10-22 · health-check

13 proyectos · 69 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Diagnóstico de PRY-205 sobre 4 documentos: 3 sostenidas, 7 sin sustento, 2 contradichas. Dijo que no puede afirmar el estado (Verde, 34 %), los 4 hitos sin recibo, la desviación ni la autoridad del gerente; no hay documentos entre 2025-06-21 y 2026-10-18.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-205 Ampliación del aeropuerto regional · 2026-10-22

**Leí:** 4 documentos del proyecto · de 2025-06-21 a 2026-10-20 · formatos: docx (2), xlsx (1), pdf (1)
**No pude leer:** ninguno quedó ilegible. Lo leí a través del texto convertido en `estado/cache/texto/`, no abriendo los originales; la ficha no guarda huella del texto del PDF del informe (`text_hash` nulo). En las carpetas de los otros 12 proyectos y en el caché no hay ningún documento que mencione PRY-205 o el aeropuerto, así que no hay minutas ajenas que cruzar.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 2

De esta carpeta se puede afirmar quién gobierna el proyecto (patrocinador, gerente y comité nombrados en el acta) y cuál es el presupuesto aprobado. No se puede afirmar el estado: el informe declara Verde y 34 % de avance, el cronograma da por cerrados los 4 hitos (el plan sostiene 100 %), el mismo informe cuenta un ensayo de concreto fallido y un vaciado reprogramado, y ninguno de los 4 hitos cerrados tiene un solo documento de recibo. Hay 0 fuentes de evidencia en la ficha, 2 declaraciones y 38 datos sin marcar.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Natalia Ospina | Acta de constitución, 2025-06-21 |
| Gerente | Andrés Lozano | Acta de constitución, 2025-06-21 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente (cambios de fecha, de presupuesto). Sin autoridad declarada no hay desviación aprobada: solo fechas que alguien escribió. | Acta de constitución, 2025-06-21 |
| Comité | Comité Técnico, que aprobó los 18.000.000.000 COP el 2025-06-21. Sesionó el 2026-10-20 con Andrés Lozano y Natalia Ospina. | Acta; comité semanal 2026-10-20 |

Otras observaciones sobre el acta:
- Alcance: «Componente 1; Componente 2; Componente 3».
- Fuera de alcance: «Lo que otro proyecto cubre».
- Dependencias: «Ninguna declarada».
- Criterio de éxito: «en producción y medido».
- Producto asociado: «No aplica».

El texto es genérico para una obra de aeropuerto y lo que dice no permite verificar el alcance. Todos los datos de gobierno tienen 16 meses de antigüedad (umbral: 12).

### Contra el plan
- **Línea base original:** versión 1, aprobada el 2025-06-21, cierre 2026-09-01 (`10-plan/2025-06-21-cronograma-v1.xlsx`).
- **Vigente:** la misma. 0 replanificaciones y 0 solicitudes de cambio en la carpeta. En los 4 hitos, la fecha de línea base y la vigente son idénticas.
- **Desviación:** el cálculo da 0 días contra la original y 0 contra la vigente. Eso solo significa que nadie registró una replanificación; no mide que no haya atraso. La fecha de cierre (2026-09-01) pasó hace 51 días, el informe del 2026-10-18 reporta obra en curso y ningún documento mueve esa fecha.
- **Fechas del cronograma:** el archivo está fechado 2025-06-21 y aun así marca como «cerrado» hitos de 2026 (hasta el 2026-09-01). O se editó después sin versionarlo, o los estados no son de esa fecha. En ambos casos no se sabe cuándo se marcó cada cierre.

### Hitos vencidos sin evidencia
Los 4 hitos están marcados como cumplidos en el cronograma y ninguno tiene documento de recibo.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseños de detalle aprobados | 2025-10-15 | 372 | Acta de recibo de diseños aprobados |
| Licencias y permisos obtenidos | 2026-01-30 | 265 | Acta de recibo o resolución de licencias y permisos |
| Cimentación terminada | 2026-05-17 | 158 | Acta de recibo de cimentación (incluye ensayos de concreto) |
| Estructura terminada | 2026-09-01 | 51 | Acta de recibo de estructura |

«Días» son los días desde la fecha del hito hasta hoy, copiados del cálculo. En otros proyectos de este portafolio la carpeta `20-seguimiento` trae actas de recibo; aquí no hay ninguna.

### Dinero
Moneda: COP. Fuente de aprobado: acta 2025-06-21. Fuente del resto: informe 2026-10-18 (declaración del gerente).

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 5.584.385.585 (31.0 %) | 4.482.743.262 (24.9 %) | 16.597.564.697 (−7.8 % vs aprobado) | 12.415.614.415 |

«Disponible real» es aprobado menos comprometido. Ninguna cifra de comprometido, ejecutado ni proyección tiene factura, acta financiera o contrato en la carpeta. No hay proveedores registrados ni contrato.

### Lo que se dijo y nadie registró
No hay registro RAID en la carpeta. Lo que aparece solo en el informe y la minuta:
- **Incidencia, sin responsable:** el ensayo de resistencia del concreto no alcanzó el valor pactado y se repite. Fecha de origen desconocida; el primer documento que la menciona es del 2026-10-18.
- **Incidencia, sin responsable:** se reprogramó el vaciado por la llegada tardía del acero. No dice a qué fecha ni qué hito mueve. Es una dependencia de un proveedor de acero que el acta no declaró («Ninguna declarada») y del que no hay contrato.
- **Riesgo, sin dueño:** concentración del conocimiento en una sola persona. No dice quién.
- **Compromiso abierto:** Camilo Beltrán, «Entregar el punto 32», para el 2026-11-12 (dicho el 2026-10-20). No está vencido. Camilo no figura entre los asistentes, y «punto 32» no está definido en ningún documento de la carpeta. La minuta lista «1. Avance» y «2. Compromisos», pero no registra qué se dijo de avance ni qué se decidió sobre el ensayo fallido.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance real | Informe 2026-10-18: avance 34 % | Cronograma v1: 4 de 4 hitos «cerrado» (el plan sostiene 100 %) |
| «Estructura terminada», cerrado, 2026-09-01 | Cronograma v1 | Informe 2026-10-18: ensayo de concreto se repite y el vaciado se reprogramó. Lo que se vacía y ensaya sigue en obra. |

### Sin sustento
Lo que nada contradice y nada respalda:
- Estado **Verde** (informe 2026-10-18). El mismo informe lista dos incidencias y un riesgo. Los dos cálculos de señales (hitos cumplidos sin evidencia, avance contra plan) no están explicados en el informe.
- Hito «Diseños de detalle aprobados» cerrado.
- Hito «Licencias y permisos obtenidos» cerrado.
- Hito «Cimentación terminada» cerrado.
- Comprometido 5.584.385.585 COP.
- Ejecutado 4.482.743.262 COP.
- Proyección al cierre 16.597.564.697 COP. Está por debajo del aprobado y no dice con qué fecha de cierre se calculó.

Sostenido: presupuesto aprobado de 18.000.000.000 COP (acta y informe coinciden); gerente Andrés Lozano (acta, informe y asistencia al comité); patrocinador y comité (acta y asistencia de Natalia Ospina al Comité Técnico del 2026-10-20).

### Lo que esta carpeta no permite saber
- **Si el proyecto está en verde.** El estado depende de 4 hitos sin recibo y de un avance que el plan no respalda. Un comité que decida sobre este estado decide sobre una declaración.
- **Cuánto atraso real hay.** No hay replanificación ni fecha nueva de cierre; el cierre comprometido ya pasó. Sin eso no hay desviación calculable.
- **Quién puede aprobar un cambio de fecha o de dinero.** El acta no declara autoridad del gerente. Cualquier cambio futuro quedaría sin dueño que lo apruebe.
- **Qué pasó entre 2025-06-21 y 2026-10-18.** La carpeta no tiene ningún documento en ese tramo: ni informes, ni minutas, ni actas de recibo. El silencio es de la carpeta entera, no solo de quien reporta. Ese tramo contiene los 4 hitos.
- **Cuándo se marcó cada hito como cerrado**, por lo explicado arriba sobre la fecha del cronograma.
- **Qué impacto tiene el ensayo de concreto fallido** sobre costo y fecha, y quién responde por repetirlo.
- **Qué es el «punto 32»** y qué debe entregar Camilo Beltrán.
- **Si el gasto declarado es real.** Sin factura, contrato ni conciliación, las cifras son del informe.

**Pie de rigor.** Este diagnóstico se hizo solo con 4 documentos de la carpeta de PRY-205, leídos desde su texto convertido. Las cifras derivadas (días, porcentajes, disponible real, conteo de señales) vienen del cálculo del script `portafolio.py compute` del 2026-10-22. Los conteos del dictamen (3, 7 y 2) son criterio de esta lectura y se detallan arriba afirmación por afirmación. Lo que se dijo fuera de los documentos no se sabe. Términos de uso v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-22. No se recomienda detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

**Siguiente paso, si lo quieres:** puedo llevar cada contradicción y cada hito sin recibo al gerente como pregunta, una por una, o preparar el punto de comité con la lista de lo que falta.
