# Corrida del 2026-10-22 · document-index

13 proyectos · 8 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Índice sobre 74 documentos: todos sin cambio, nada que releer, sin citas rotas. No se leyó ningún documento.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-22: 74 documentos, los 74 sin cambio. Nada que releer y ninguna cita rota; no hay nada más que hacer.
