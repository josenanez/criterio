**Material cargado:** 13 fichas de `estado/records/` (actualizadas el 2026-10-22) y la salida de `compute` con fecha de corte 2026-10-22. Términos v1.2 vigentes, aceptados por José Francisco Ñáñez el 2026-10-22 (familia 0.8.0). Todas las cifras derivadas salen de `compute`; las cifras de solicitudes de cambio (días, COP) son las que declara cada solicitud.

# Comité de proyectos — 2026-10-22
5 decisiones · 5 escalamientos sin decisión asociada · 9 proyectos con hallazgos (de 13) · 54 señales abiertas en el portafolio

## Decisiones del comité anterior
No hay registro de un comité anterior en `estado/` (no existe ninguna corrida previa de `steering-pack` ni decisiones anotadas en las fichas). No puedo decir qué se decidió, qué se hizo ni qué sigue abierto. Si hubo un comité, sus decisiones no están escritas donde el agente pueda leerlas.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | — | No verificable |

Hay seis solicitudes de cambio aprobadas por «comité» sin que el documento diga cuál comité ni en qué fecha de sesión (ver punto 1).

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base y cierres de hito en el portafolio, y se registra en cada ficha?
**Proyecto:** todos (13 de 13 sin autoridad de aprobación registrada: `identity.authority` no encontrado) · **Quién decide:** el patrocinador de mayor nivel del portafolio. Esto no se puede resolver con los documentos leídos. · **Si no se decide hoy:** los demás puntos de este paquete quedan dirigidos a un comité cuya facultad no está escrita en ninguna ficha, y siguen aprobándose cambios sin que conste quién tenía autoridad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Declarar por escrito la autoridad por proyecto (monto y días hasta los cuales decide el gerente, el patrocinador o el comité) y cargarla a las fichas | Sin cambio | Una sesión | Sin costo directo |
| B. Mantener «comité» genérico | Sin cambio | Ninguno | Cada cambio aprobado queda sin sustento verificable |

**Recomendación:** A. Las fichas de PRY-203 y PRY-208 nombran al «Comité de Contratación» como comité. No leí las actas de los otros 11 proyectos para ver cuál comité figura. Los cuatro cambios aprobados en PRY-200, PRY-203 (dos) y PRY-204 dicen «comité» y nada más.

### [2] ¿Se aprueba una nueva línea base para PRY-203 Planta de tratamiento de agua, con fecha de fin que no esté ya vencida y presupuesto que cubra la proyección?
**Proyecto:** PRY-203 · **Quién decide:** sin determinar (punto 1). Según su acta de constitución, el comité es el Comité de Contratación. · **Si no se decide hoy:** el proyecto sigue en rojo sobre una línea base cuya fecha de fin (2026-08-16) ya pasó (el cronograma v3 se aprobó el 2026-10-17, con esa fecha ya vencida) y con una proyección de costo por encima del aprobado.

Datos (de `compute`):
- Desviación de tiempo contra la línea base original: 147 días (63.6 %). Las dos solicitudes CC-01 (+101 días) y CC-02 (+46 días) se aprobaron, y suman los 147 días de `approved_time_days`.
- Proyección de costo 4 214 486 517 COP contra 3 300 000 000 COP aprobados: 27.7 % por encima. Umbral de la configuración: 10 %. CC-01 declara 202 000 000 COP adicionales y CC-02 declara 92 000 000 COP adicionales; el script no da cuánto de la proyección cubren.
- Avance declarado 93 %, estado declarado rojo (informe del 2026-10-17). Los 4 hitos figuran como cumplidos, pero «Cimentación terminada» y «Estructura terminada» no tienen evidencia de recibo.
- Fecha de fin vigente 2026-08-16, vencida; el hito «Estructura terminada» tiene fecha 2026-08-16, 67 días atrás.
- Riesgo y dos incidencias sin responsable: ensayo de concreto repetido, dos semanas perdidas por rotación del residente, cambio de norma sismorresistente.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir al gerente una nueva línea base con fecha de fin proyectada y su sustento, y decidirla en el próximo comité | Sin cambio | Una semana más sin línea base realista | Sin impacto hasta aprobar |
| B. Aprobar hoy ampliar presupuesto hasta la proyección declarada | Sin cambio | No resuelve la fecha vencida | 4 214 486 517 COP (proyección declarada, no verificada) |
| C. Exigir antes auditoría de los dos hitos sin evidencia y de la cifra de proyección | Sin cambio | Más largo | La auditoría no está costeada en los documentos |

**Recomendación:** A, con C como condición de la aprobación. La fecha de fin vigente ya venció, así que ninguna opción de presupuesto resuelve el atraso. No hay en los documentos una fecha de fin proyectada: esa es la cifra que falta.

### [3] ¿Se aprueba la solicitud CC-01 de PRY-208 Bodega logística modular (ampliación de alcance, +30 días, 60 000 000 COP)?
**Proyecto:** PRY-208 · **Quién decide:** sin determinar (punto 1); la solicitud no registra quién decide (`changes[0].decided_by` no encontrado). · **Si no se decide hoy:** la solicitud, radicada el 2026-10-21, queda pendiente; la fecha de fin vigente sigue siendo 2026-12-31.

Datos: presupuesto aprobado 1 200 000 000 COP, proyección 1 188 909 320 COP (−0.9 %); declarado verde, 35 % de avance. La ficha no tiene hitos (`plan.milestones` vacío), por lo que no se puede medir contra qué se movería la fecha.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación declarada | +30 días sobre 2026-12-31 | +60 000 000 COP declarados |
| B. Rechazar | Se mantiene | Sin cambio | Sin cambio |
| C. Aprobar condicionado a hitos y a la línea base nueva | Ampliación declarada | +30 días | +60 000 000 COP |

**Recomendación:** C. Sin hitos registrados no se puede verificar el impacto de tiempo, y de aprobar sin línea base nueva se repite el patrón de PRY-200 y PRY-204 (aprobado sin línea base nueva).

### [4] ¿Cuál es la fuente válida del avance de PRY-205 Ampliación del aeropuerto regional: los 4 hitos cumplidos o el 34 % declarado?
**Proyecto:** PRY-205 · **Quién decide:** sin determinar (punto 1); lo resuelve quien puede ordenar una verificación de hitos. · **Si no se decide hoy:** el informe sigue en verde (2026-10-18) con una contradicción de 66.0 puntos entre lo declarado y lo que sustenta el plan.

Datos: avance declarado 34 %; el plan marca los 4 hitos cumplidos (sustenta 100 %); diferencia de 66.0 puntos. Ningún hito tiene evidencia de recibo. El último hito, «Estructura terminada», vencía el 2026-09-01 (51 días atrás) y la fecha de fin del proyecto es esa misma. Los datos de identidad y plan vienen de documentos de 2025-06-21 (16 meses, sobre el umbral de 12). Presupuesto: 18 000 000 000 COP aprobados, 4 482 743 262 COP ejecutados (24.9 %).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ordenar verificación independiente de los 4 hitos y suspender el verde hasta tenerla | Sin cambio | Tiempo de la verificación (no estimado en los documentos) | No estimado |
| B. Aceptar el 34 % y reabrir el plan: los hitos pasan a «no cumplido» | Plan rehecho | La fecha de fin ya vencida deja de valer | Sin cifra en los documentos |
| C. Aceptar los hitos y corregir el 34 % | Sin cambio | Proyecto casi terminado | Contradice el 24.9 % ejecutado |

**Recomendación:** A. Las opciones B y C descartan una de las dos fuentes sin verla. Con 24.9 % de presupuesto ejecutado, que el proyecto esté terminado en todos sus hitos es difícil de sostener, pero eso es una inferencia mía, no un dato.

### [5] ¿Se emite requerimiento formal a Interventorías Técnicas S.A.S. (CT-521) por dos entregables vencidos de PRY-201 Edificio de oficinas Torre Norte?
**Proyecto:** PRY-201 · **Quién decide:** sin determinar (punto 1); el contrato es del proyecto y la ficha no registra quién lo puede reclamar. · **Si no se decide hoy:** los entregables siguen pendientes sin consecuencia contractual y el informe del 2026-10-21 sigue en verde.

Datos: «Suministro de acero de refuerzo», vencido el 2026-06-28 (116 días, pendiente); «Bolsa de horas de ingeniería», vencido el 2026-09-01 (51 días, pendiente). Ningún entregable aceptado. Lo facturado no está en los documentos (`vendors[0].invoiced` no encontrado), y no se puede cruzar contra lo pagado. Además: 9 compromisos vencidos sin evidencia, 3 sin fecha, 2 reprogramados 6 y 5 veces (Beatriz Cuéllar, «Enviar el documento 1»: original 2026-10-02; Mauricio Pérez, «Cerrar la prueba 2»: original 2026-09-16), 2 hitos cumplidos sin evidencia («Licencias y permisos obtenidos» y «Cimentación terminada»). Avance declarado 51 %, el plan sustenta entre 60 y 80 %.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Requerimiento formal con fecha de entrega y consecuencia | Sin cambio | Fecha por fijar; el proyecto termina el 2026-12-15 | Sin cifra en los documentos |
| B. Renegociar los entregables | Puede cambiar | Mueve el 2026-12-15 | Sin cifra |
| C. Esperar al siguiente informe | Sin cambio | Se pierde otra semana | Sin cifra |

**Recomendación:** A. Con un atraso de 116 y 51 días sin ninguna aceptación, esperar no aporta información. Antes de decidir, debe saberse cuánto se ha facturado; hoy no se sabe.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200 Variante vial del sur | CC-01 aprobada (+111 días, 222 000 000 COP declarados) sin línea base nueva registrada; desviación de tiempo 111 días (43.4 %) contra la original; 3 hitos cumplidos sin evidencia; informe del 2026-09-30 en verde; compromiso de Beatriz Cuéllar vencido (3 días) | Solicitud del 2026-10-14 | Que el gerente registre la línea base o diga por qué no. Persona que decide: punto 1 |
| PRY-204 Vivienda de interés social etapa 2 | CC-01 aprobada (+58 días, 116 000 000 COP declarados) sin línea base nueva; desviación de tiempo 58 días (17.7 %); hitos «Licencias y permisos obtenidos» y «Cimentación terminada» cumplidos sin evidencia; informe del 2026-10-02 en verde | Solicitud del 2026-10-17 | Igual que PRY-200 |
| PRY-206 Modelado BIM de proyectos | Proyección de costo 7 897 229 155 COP sobre 6 800 000 000 COP aprobados: 16.1 % por encima (umbral 10 %); avance declarado 69 % con plan que sustenta entre 20 y 40 % (−29.0 puntos); compromiso de Sandra Gil vencido (12 días) | Informe del 2026-10-15 | Decidir si el sobrecosto es una solicitud de cambio o una corrección |
| PRY-211 Hospital de segundo nivel | Declarado rojo con 90 % de avance; el plan sustenta entre 50 y 75 % (−15.0 puntos); hito «Licencias y permisos obtenidos» cumplido sin evidencia (33 días) | Informe del 2026-10-17 | Verificar avance y causa del rojo; el informe no la explica en las señales calculadas |
| PRY-207 Control de avance con drones | Fecha de fin vigente 2026-10-12, ya pasada, sin hitos registrados; declarado verde con 32 % de avance; 9 días sin actividad | Fecha de fin 2026-10-12 | Nueva fecha o cierre; sin hitos no se puede medir |

## Para conocimiento
- PRY-199 Pintura de la sede administrativa: sin señales abiertas; declarado verde, 20 % de avance.
- PRY-202 Puente vehicular sobre el río: sin señales abiertas; declarado amarillo, 41 % de avance; el plan sustenta entre 25 y 50 %.
- PRY-209 Doble calzada del corredor central: 2 hitos cumplidos sin evidencia; compromiso de Laura Vélez vencido (24 días); informe del 2026-10-22 en verde.
- PRY-210 Colegio público por concesión: avance declarado 82 % frente a un plan que sustenta entre 33 y 67 % (−15.0 puntos); 1 hito cumplido sin evidencia; amarillo.

## Anexo

**Contradicciones entre lo declarado y lo sustentado (5 informes verdes contradichos):** PRY-200, PRY-201, PRY-204, PRY-205 y PRY-209.

**Proyectos sin ninguna señal:** PRY-199, PRY-202, PRY-207 (aunque su fecha de fin ya pasó, ver escalamientos), PRY-208 (salvo la solicitud pendiente del punto 3).

**Vacíos de información (13 de 13 proyectos):**
- `identity.authority` no encontrado en los 13.
- `identity.phase` no encontrado en 11; en PRY-209 y PRY-210 sí está.
- En ningún proyecto hay fuentes marcadas como evidencia (todas son «declaración» o sin marcar) y casi todos los hitos cumplidos carecen de evidencia de recibo.
- PRY-199 (Constructora del Valle, CT-199) y PRY-201 (CT-521): facturación no encontrada.
- Datos con más de 12 meses de antigüedad: PRY-203 (15 meses), PRY-205 (16 meses), PRY-207 (15 meses).
- PRY-203: la razón de la línea base v3 no está en los documentos.
- Producto sin asociar en 8 proyectos: PRY-200, PRY-202, PRY-203, PRY-205, PRY-207, PRY-209, PRY-210 y PRY-211.

**Compromisos sin fecha en PRY-201:** Felipe Arango, Beatriz Cuéllar (en la reunión del 2026-09-24) y Laura Vélez (en `2026-10-22-notas-reunion.txt`).

**Lo que este paquete no sabe:** qué se habló en comités fuera de los documentos; si los «comité» de las solicitudes de cambio sesionaron; cuánto se ha facturado a los proveedores; las fechas de fin proyectadas de PRY-203 y PRY-207.

---
*criterio-portfolio 0.8.0 · términos v1.2 vigentes (aceptados el 2026-10-22 por José Francisco Ñáñez) · 13 fichas aplicadas, todas con `record_updated` 2026-10-22 · campos inciertos: `identity.authority` (13), `identity.phase` (11), evidencia de hitos, `decided_by` de PRY-208 CC-01, facturación de proveedores · Los datos se leen de documentos que el agente no verifica: la verificación es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0*
