## Vista por producto: vivienda VIS — al 2026-10-22

Fuente: fichas de `estado/records`, recalculadas con `portafolio.py compute` al 2026-10-22. Términos vigentes (v1.2), aceptados por José Francisco Ñáñez el 2026-10-22.

**«vivienda VIS» tiene un solo proyecto: PRY-204 Vivienda de interés social etapa 2.** La vista por producto no aporta nada aquí (no hay suma entre proyectos, ni dependencias internas, ni «fecha más tardía» distinta de la del proyecto), así que no armo sección de producto. Lo que dice el cálculo de ese proyecto:

- **Señales abiertas (5):** desviación en tiempo de 58 días / 17.7 % contra la línea base original (umbral 10 %); dos hitos declarados cumplidos sin evidencia («Licencias y permisos obtenidos», vencido 2026-05-31, y «Cimentación terminada», vencido 2026-08-21); el cambio CC-01 (58 días) aprobado sin línea base nueva; y el estado declarado «verde» (informe de avance del 2026-10-02) contradicho por las dos señales anteriores de hitos y tiempo.
- **Fecha comprometida:** 2027-01-08 (vigente; 58 días después de la original).
- **Dinero (COP):** aprobado 18.000.000.000; comprometido 10.443.923.145 (58.0 %); ejecutado 7.756.540.080 (43.1 %); proyección 17.615.046.374 (−2.1 % sobre lo aprobado). Un solo proyecto, así que no hay suma parcial que declarar.
- **Dependencias:** no declara ninguna. **Proveedores:** ninguno registrado, de modo que no se contrastó nada contra facturación.
- **No sé / falta en la ficha:** autoridad que aprueba, fase, y la evidencia de tres hitos.

### Proyectos sin producto declarado
Son 8 de 13: PRY-200, PRY-202, PRY-203, PRY-205, PRY-207, PRY-209, PRY-210 y PRY-211. Es un hallazgo de gobierno: nadie puede responder por el conjunto al que sirven. El cálculo no trae el área dueña de estos proyectos y no la invento; falta ese dato en las fichas.

### Qué sigue
Sin dependencias internas no hay nada que llevar al comité de producto. Lo que sí necesita decisión es PRY-204: la línea base de CC-01 y la evidencia de los dos hitos «cumplidos», antes de sostener el verde.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría; cada cifra sale de `compute` y cada dato de las fichas con su cita. La verificación es de quien lo lee.*
