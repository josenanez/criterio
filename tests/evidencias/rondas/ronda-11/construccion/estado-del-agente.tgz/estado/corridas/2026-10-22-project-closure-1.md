# Corrida del 2026-10-22 · project-closure

13 proyectos · 73 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Acta de cierre borrador de PRY-203: no se puede cerrar por cumplimiento (rojo, 93 %, criterio de éxito sin evidencia); cierre solo por decisión. Dijo que no sabía: alcance de CC-01/CC-02, evidencia de cimentación y estructura, motivo de la replanificación, quién autorizó los cambios, presupuesto vigente, qué son los puntos 19 y 28. No archivó la carpeta.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

**Sale de:** la ficha `estado/records/PRY-203.json` (actualizada 2026-10-22), el recálculo de `portafolio.py compute` del 2026-10-22 y estos documentos de `PRY-203-planta-de-tratamiento-de-agua/`: `00-gobierno/2025-07-24-acta-constitucion.docx`, `10-plan/2025-07-24-cronograma-v1.xml`, `10-plan/2026-10-17-cronograma-v3.xml`, `20-seguimiento/2026-10-17-informe-avance.md`, `…/2026-10-15-solicitud-cambio-cc-01.md`, `…/2026-10-17-solicitud-cambio-cc-02.md`, `…/2026-10-11-acta-recibo-licencias-y-permisos-obtenidos.md`, `…/2026-10-19-acta-recibo-diseños-de-detalle-aprobados.pdf`, `30-reuniones/2026-10-19-comite-semanal.docx`.

(Términos vigentes: versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-22; no hizo falta volver a registrarlos.)

## Cierre — PRY-203 Planta de tratamiento de agua — 2026-10-22

**Primero lo esencial:** este proyecto **no se puede cerrar por cumplimiento**. El último informe (2026-10-17, Carlos Peña) lo declara en **rojo** con **93 %** de avance, la fecha vigente de cierre (2026-08-16) ya pasó hace 67 días sin que haya cierre, el ensayo de concreto se repite y no hay ninguna evidencia de que la planta esté "en producción y medida". Si alguien lo cierra hoy, es **cierre por decisión**, y debe quedar escrito así, con nombre de quien lo decide. Esta acta es el borrador de ese cierre y de lo que deja pendiente; no declara que el proyecto terminó.

### Contra lo comprometido
**Criterio de éxito:** "Planta de tratamiento de agua en producción y medido." (`00-gobierno/2025-07-24-acta-constitucion.docx`, aprobada 2025-07-24).
**Se cumplió:** **no se puede determinar; la documentación no lo sostiene.** No hay documento de puesta en producción ni de medición. Además, el plan (4 hitos) termina en "Estructura terminada": ningún hito cubre la puesta en producción ni la medición que exige el criterio. El 100 % que el plan soporta es el de esos cuatro hitos, no el del criterio de éxito.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1, 2 y 3 (alcance del acta; el acta no los describe más) | No se puede determinar | Ninguna: el acta no detalla qué es cada componente |
| Hito: Diseños de detalle aprobados (línea base 2025-09-29) | Declarado cumplido en cronograma v3 (2026-10-17) | Acta de recibo del 2026-10-19, firmada por Carlos Peña: **posterior** a la declaración de cumplido (cronograma 2026-10-17); fecha pactada 2025-09-29, acta 2026-10-19 |
| Hito: Licencias y permisos obtenidos (2025-11-26) | Declarado cumplido | Acta de recibo del 2026-10-11, Carlos Peña (recibe el mismo gerente que lo reporta) |
| Hito: Cimentación terminada (2026-01-23) | Declarado cumplido | **Sin evidencia** (señal abierta, 272 días desde la fecha pactada) |
| Hito: Estructura terminada (línea base 2026-03-22, vigente 2026-08-16) | Declarado cumplido | **Sin evidencia** (señal abierta, 67 días desde la fecha vigente); el informe del 2026-10-17 dice que el ensayo de resistencia del concreto no alcanzó el valor pactado y se repite, lo que contradice el "cumplido" |

Fuentes de la columna Estado: `10-plan/2026-10-17-cronograma-v3.xml`. En la ficha, de las fuentes de las cifras: 0 son evidencia, 2 son declaraciones y 60 no están marcadas.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Del acta: "Lo que otro proyecto cubre" (no dice qué) | Acta de constitución | 2025-07-24 |
| Alcance añadido (no recortado): CC-01 "Ampliación de alcance" | "El comité" (sin nombre ni acta de la decisión) | 2026-10-15 |
| Alcance añadido: CC-02 "Ampliación de alcance" | "El comité" (sin nombre ni acta de la decisión) | 2026-10-17 |

No hay alcance recortado registrado. Hallazgo del cierre: las dos solicitudes dicen "ampliación de alcance" pero **no describen qué se amplía**; no se puede contrastar qué se entregó contra qué se amplió. Tampoco consta qué comité decidió: el acta nombra al Comité de Contratación y el acta del 2026-10-19 del comité no menciona CC-01 ni CC-02.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-03-22 | 2026-08-16 (cronograma v3, 2026-10-17) | **No hay**: el proyecto no ha terminado | **147 días (63,6 %)**; contra la vigente, 0 días |
| Presupuesto aprobado | 3.300.000.000 COP | No hay presupuesto vigente registrado: los costos de CC-01 (202.000.000 COP) y CC-02 (92.000.000 COP) no consta que se hayan incorporado | No hay | Proyección 4.214.486.517 COP: **27,7 %** sobre lo aprobado |
| Comprometido | | | 2.066.126.764 COP (62,6 % de lo aprobado) | |
| Ejecutado | | | 1.510.877.959 COP (45,8 % de lo aprobado) | |

Replanificaciones: **1** (la línea base pasó de la versión 1 a la 3; la versión 2 no está en la carpeta). Los 147 días de atraso coinciden con los 147 días de cambios "aprobados" (+101 de CC-01 y +46 de CC-02), con la línea base movida 147 días y 0 días sin autorización formal (según el recálculo). Pero el cronograma v3 está fechado 2026-10-17, **dos meses después** de la fecha de cierre que fija (2026-08-16): la fecha vigente se fijó cuando ya había pasado. El motivo de la replanificación no está en ningún documento.

### RAID al cierre
**Materializados:**
- El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite (incidencia, informe 2026-10-17). Sin responsable.
- Pérdida de dos semanas por rotación del residente de obra (incidencia, informe 2026-10-17). Sin responsable.
- Atraso de 147 días contra la línea base original.

**No materializados:** el riesgo "Cambio en la norma de sismorresistencia que puede mover el alcance" sigue abierto en el informe del 2026-10-17; no hay documento que diga que ocurrió ni que dejó de aplicar.

**Abiertos, con doliente:** **ninguno tiene doliente con nombre.** Los tres elementos (riesgo, dos incidencias) no tienen responsable en el informe. Los dos compromisos del comité del 2026-10-19 siguen vencidos:
- Elena Duarte, "Entregar el punto 28", para 2026-10-17 (5 días de vencido).
- Javier Hoyos, "Entregar el punto 19", para 2026-10-15 (7 días de vencido).
El acta del comité no dice qué son el punto 28 ni el punto 19, y ninguna de las dos personas figura entre los asistentes (Carlos Peña, Laura Vélez). Sin doliente con nombre, esto **no está cerrado**. Dependencias: ninguna declarada en el acta ni en el resto.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v3 y las solicitudes CC-01 y CC-02 fijaron como fecha de cierre 2026-08-16, cuando ya había pasado; sin motivo escrito ni acta de quién decidió | CC-01 2026-10-15; CC-02 y cronograma v3 2026-10-17 | Los 147 días de atraso quedaron como "aprobados" (0 días sin autorización) y la desviación contra la vigente es 0 | Exigir la fecha, el nombre y el acta de la decisión antes de mover la línea base, no después de vencida la fecha |
| "Estructura terminada" figura cumplido en el cronograma v3 sin acta de recibo, mientras el informe del mismo día dice que el ensayo de concreto se repite | 2026-10-17 | Un hito cuenta como cumplido (cuenta para el 100 % del plan) sin que lo respalde ningún documento; el 93 % declarado y el plan no coinciden en 7 puntos | Un hito se marca cumplido solo con su acta de recibo anexa |
| El acta de recibo de "Diseños de detalle aprobados" es del 2026-10-19; el hito se declaró cumplido el 2026-10-17 y su fecha pactada era 2025-09-29 | 2026-10-17 a 2026-10-19 | Recibo después del reporte y más de un año después de lo pactado; el recibo lo firma el mismo gerente que reporta | Que el recibo lo firme quien no es el gerente que reporta, y antes de marcar el hito |
| El plan tiene 4 hitos y termina en "Estructura terminada"; el criterio de éxito exige planta en producción y medida | Desde la constitución, 2025-07-24 | El 100 % del plan no acerca al criterio de éxito; nadie puede decir que se cumplió | Incluir en el plan hitos de puesta en producción y medición, derivados del criterio de éxito |
| Rotación del residente de obra | Informe 2026-10-17 (no dice cuándo ocurrió) | Dos semanas perdidas; el documento no las liga a ningún hito | Sin dato suficiente para decir más: queda como hecho, no como lección |

### Sin dato
- Qué es cada componente del alcance, qué se amplió en CC-01 y CC-02, y qué cubre "lo que otro proyecto cubre".
- Cualquier evidencia de producción y medición de la planta.
- Evidencia de "Cimentación terminada" y "Estructura terminada".
- Motivo de la replanificación y por qué falta la versión 2 del cronograma.
- Quién del comité autorizó CC-01 y CC-02, y en qué reunión.
- Presupuesto vigente (¿se sumaron los 202.000.000 y 92.000.000 COP?).
- Qué son los puntos 19 y 28 de los compromisos.
- Fecha real de término: no existe.
- Fuente del informe: 0 evidencias; los campos de identidad (producto, autoridad, fase) no están en ningún documento.

### Después
**No muevo la carpeta a `archivo/` ni congelo la ficha:** el proyecto sigue abierto, con señales abiertas (atraso 63,6 %, proyección +27,7 %, dos hitos sin evidencia, dos compromisos vencidos). Si Laura Vélez o el comité deciden cerrarlo por decisión, se archiva entonces con su última instantánea y esta lista de pendientes con doliente.

*Rigor: cada cifra derivada sale del recálculo de `portafolio.py compute` (2026-10-22); lo que ese cálculo no da, no se escribió. Las citas apuntan a los documentos originales; la verificación es de quien lee. Lo que se habló fuera de los documentos no lo sé.*
