# Corrida del 2026-10-22 · portfolio-setup

3 proyectos · 74 documentos, 51 releídos y 23 sin cambio · 152 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 10 |
| `milestone_met_without_evidence` | 5 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `declared_vs_evidence` | 2 |
| `progress_vs_plan` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); primer resultado en una sola conversación; 3 proyectos (PRY-201, 209, 210) leídos, sellados y calculados: 25 señales, 2 verdes contradichos (201, 209), 4 cronogramas .xml sin leer

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 74 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: md 33, docx 14, pdf 11, xlsx 7, csv 3, xml 4, txt 1, json 1 · más reciente: 2026-10-22
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** informe semanal, dos días antes de cada reunión (propuesto: no declaraste comité)
**En:** presentación (propuesto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.8.0 (términos 1.2), 2026-10-22 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.8.0-2026-10-22.md` y `.pdf` · SHA-256 83fcc3e6c0571faa… (md) y 6b4c1841b9a486ff… (pdf)

Sin archivo `_CRITERIO_PORTAFOLIO.txt` en la carpeta (respuesta sugerida; la ruta vino dada).
Estado en `estado/`, informes en `reportes/`.

### Probé con tres proyectos

Elegí los tres con documentación más reciente. Fichas escritas y selladas en `estado/records/`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Edificio de oficinas Torre Norte | 15 (con la ficha del gerente, guardada aparte en `pm_record`) | Patrocina Beatriz Cuéllar, gerente Diana Molina, Comité de Inversiones; aprobado COP 800.000.000; cierre 2026-12-15; declara verde y 51 % (informe 2026-10-21); 26 compromisos sacados de seis comités y de las notas del 2026-10-22; contrato CT-521 con tres entregables de COP 77.546.392 | Autoridad del gerente; actas de recibo de «Licencias» y «Cimentación»; actas de los tres entregables del proveedor; lo facturado |
| PRY-209 Doble calzada del corredor central | 4 | Patrocina María Restrepo, gerente Mauricio Pérez, Comité Técnico; aprobado COP 6.800.000.000; cierre 2027-02-08; declara verde y 44 % (2026-10-22); ejecutado 22,5 % | Autoridad; producto (el acta dice «No aplica»); actas de recibo de los dos hitos cerrados |
| PRY-210 Colegio público por concesión | 4 | Patrocina Laura Vélez, gerente Rubén Cárdenas, Comité de Obra; aprobado COP 3.300.000.000; cierre 2027-07-01; declara amarillo y 82 % (2026-10-22); ejecutado 42 % | Autoridad; producto; acta de recibo del hito cerrado |

### Lo que levantó el cálculo (25 señales)

**PRY-201** (19)
- **declared_vs_evidence:** declara verde, y el cálculo le encuentra encima compromisos vencidos, compromisos reprogramados, hitos cerrados sin acta y entregables de proveedor tardíos.
- **milestone_met_without_evidence (2):** «Licencias y permisos obtenidos» (vencía 2026-07-27, 87 días) y «Cimentación terminada» (vencía 2026-09-12, 40 días) figuran cerrados en el cronograma, sin acta que lo pruebe. Solo «Diseños de detalle aprobados» tiene acta (2026-10-10).
- **commitment_overdue (9):** Laura Vélez «Validar el ambiente 4» (35 días, vencía 2026-09-17); Andrés Lozano «Enviar el documento 9» (21); Liliana Torres «Confirmar la fecha 7» (19); Carlos Peña «Aprobar el diseño 13» (10); María Restrepo «Entregar el punto 8» (7); Gustavo Neira «Confirmar la fecha 15» (7); Rubén Cárdenas «Enviar el documento 17» (5); Gustavo Neira «Actualizar la matriz 22» (4); Andrés Lozano «Confirmar la fecha 23» (3). Varios dicen en el comité que ya entregaron y no hay acta.
- **commitment_rescheduled (2):** «Enviar el documento 1» (Beatriz Cuéllar) se prometió para 2026-10-02 y se ha movido 6 veces, hasta 2026-12-25. «Cerrar la prueba 2» (Mauricio Pérez) se prometió para 2026-09-16 y se ha movido 5 veces, hasta 2026-11-13. Es un bloqueo que nadie ha nombrado, no un descuido de seguimiento.
- **commitment_undated (3):** Revisar el anexo 3 (Felipe Arango), Validar el ambiente 12 (Beatriz Cuéllar), Mandar el ajuste del presupuesto (Laura Vélez, dicho como «la otra semana»).
- **vendor_deliverable_late (2):** «Suministro de acero de refuerzo» (116 días) y «Bolsa de horas de ingeniería» (51 días), CT-521, sin acta de recibo.
- Contraste con la ficha del gerente: no salió ninguna discrepancia (`pm_vs_pmo`).
- Dicho en la reunión del 2026-10-22 y sin registrar antes: el proveedor podría no llegar con el equipo completo. Quedó en la ficha como riesgo con su cita, sin dueño.

**PRY-209** (4)
- **declared_vs_evidence:** declara verde, con un compromiso vencido y dos hitos cerrados sin acta.
- **milestone_met_without_evidence (2):** «Diseños de detalle aprobados» (209 días) y «Licencias y permisos obtenidos» (103 días).
- **commitment_overdue:** Laura Vélez «Entregar el punto 11», para 2026-09-28, registrado en el comité del 2026-10-20: la fecha ya estaba vencida al anotarse (24 días).

**PRY-210** (2)
- **progress_vs_plan:** declara 82 %, y el cronograma, con 1 de 3 hitos cerrados, sustenta entre 33 % y 67 %: la declaración va 15 puntos por delante del plan.
- **milestone_met_without_evidence:** «Diseños de detalle aprobados» (78 días) sin acta.

Los tres proyectos no tienen autoridad del gerente declarada en ningún documento.

### El portafolio completo

10 proyectos más (PRY-199, 200, 202 a 208), en dos lotes uno tras otro, 74 documentos en total (ya vi 23). Pocos minutos por proyecto en esta misma conversación; los proyectos con minutas son los que más cuestan.

### Lo que le falta a tu carpeta

- **Cuatro cronogramas .xml no se pueden leer** sin instalar algo (PRY-200 v2, PRY-203 v1 y v3, PRY-211 v1). Si me dices que los exporte a .xlsx o .csv, entran; hoy no cuentan.
- **Los documentos .docx y .xlsx no los abre el lector estándar**: usé un extractor mínimo de solo lectura. Funciona, pero lo ideal es tenerlos también en .md o .pdf.
- **Actas de recibo casi inexistentes:** de 6 hitos declarados cerrados en los tres proyectos, solo 1 tiene acta. PRY-207 y PRY-208 no tienen cronograma.
- **Proyectos sin minutas:** PRY-207 y PRY-208 solo traen acta de constitución e informe (PRY-208 además una solicitud de cambio). Hay solicitudes de cambio por revisar en PRY-200, PRY-203, PRY-204 y PRY-208.
- **Productos:** el acta de PRY-209 y PRY-210 dice «No aplica», y así quedó el campo (vacío).
- **Estructura:** cada proyecto tiene su carpeta (00-gobierno, 10-plan, 20-seguimiento, 30-reuniones); en PRY-201 las notas del 2026-10-22 están sueltas en la raíz del proyecto. No moví nada.

Nada de esto bloquea el análisis.

### Cómo fue la sesión

0 preguntas hechas a la persona (sesión sin interfaz: todo con la respuesta sugerida). Resultado sobre sus documentos al cierre de esta conversación.
