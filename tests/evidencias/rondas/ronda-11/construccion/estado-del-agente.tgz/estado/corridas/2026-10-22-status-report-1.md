# Corrida del 2026-10-22 · status-report

13 proyectos · 27 s · 54 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 17 |
| `commitment_overdue` | 14 |
| `declared_vs_evidence` | 5 |
| `progress_vs_plan` | 4 |
| `variance_time` | 3 |
| `commitment_undated` | 3 |
| `change_without_baseline` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_cost` | 2 |

Informe de estado de PRY-200: declara verde 73% (2026-09-30) contradicho por +111 días, 3 hitos sin evidencia y 1 compromiso vencido. Dijo no saber: producto, autoridad, fase, evidencia de hitos, motivo de la replanificación, dueños de RAID.

Contra la corrida del 2026-10-22: +0 hallazgos.

## Lo que produjo

Informe de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-22), recalculado con `portafolio.py compute` al 2026-10-22. Términos vigentes: versión 1.2, aceptados por José Francisco Ñáñez el 2026-10-22.

## PRY-200 · Variante vial del sur — estado al 2026-10-22

**Declara el gerente (Javier Hoyos):** verde · 73,0 % · al 2026-09-30 (22 días; no está vencida para el umbral de 30 días, pero ya es de hace más de tres semanas)
**Sustento documental:** contradicho. La alerta `declared_vs_evidence` está activa.
**Lo que el semáforo no explica:** `commitment_overdue`, `milestone_met_without_evidence`, `variance_time`
**Último documento:** 2026-10-14 (8 días de silencio; umbral 15) · **Última reunión:** 2026-10-12

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-10 | 2027-03-31 | +111 días contra la original (43,4 %, sobre el umbral de 10 %) · 0 días contra la vigente |
| Presupuesto | 800.000.000 COP aprobados | 800.000.000 COP aprobados; proyección 757.747.694 COP | proyección −5,3 % frente a lo aprobado. Ejecutado 373.222.579 COP (46,7 %); comprometido 400.065.156 COP (50,0 %) |

Replanificaciones: 1. La línea base v2 se aprobó el 2026-09-30 (cronograma-v2.xml) y su motivo no figura en los documentos (`not_found`).

El presupuesto no incorpora CC-01 (+222.000.000 COP adicionales, aprobado por el comité el 2026-10-14). Con la línea base de dinero tal como está, la cifra de −5,3 % no refleja ese cambio. El script no calculó una cifra con el cambio, así que no la escribo.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseños de detalle aprobados | 2026-06-01 | 2026-06-01 | declarado cumplido | ninguna (143 días) |
| Licencias y permisos obtenidos | 2026-08-04 | 2026-08-04 | declarado cumplido | ninguna (79 días) |
| Cimentación terminada | 2026-10-07 | 2026-10-07 | declarado cumplido | ninguna (15 días) |
| Estructura terminada | 2026-12-10 | 2027-03-31 | pendiente | no aplica |

Tres de cuatro hitos figuran como cumplidos solo porque lo dice el cronograma v2; ningún documento los sustenta. El avance declarado (73,0 %) cae 2,0 puntos por debajo del rango que el plan soporta (75–100 %).

### Dónde no coincide
- **Declarado:** verde, 73 % (informe de avance, 2026-09-30). **Documentos:** +111 días de desviación contra la línea base original, tres hitos "cumplidos" sin evidencia y un compromiso vencido (ver abajo). La ficha no tiene ningún dato marcado como evidencia (0 fuentes de evidencia, 2 de declaración, 45 sin marcar).
- **CC-01** (solicitud de cambio, 2026-10-14): aprobada por el comité con +111 días y +222.000.000 COP, y la alerta `change_without_baseline` dice que la línea base no se movió por ese cambio (111 días).
- El mismo informe del 2026-09-30 que declara verde también registra dos semanas perdidas por rotación del residente de obra y nueve días de lluvias que detuvieron el movimiento de tierras.

### Abierto
**Riesgos e incidencias sin movimiento:** el script no calcula días para los RAID; todos vienen del informe del 2026-09-30 (22 días) y ninguno tiene dueño.
- Riesgo: compra de predios pendiente en el trazado
- Riesgo: lluvias por encima del promedio en la temporada
- Incidencia: dos semanas perdidas por rotación del residente de obra
- Incidencia: nueve días de movimiento de tierras detenido por lluvias

**Compromisos vencidos:** Beatriz Cuéllar — «Entregar el punto 35», comprometido en el comité del 2026-10-12 para el 2026-10-19; lleva 3 días vencido y no hay evidencia de entrega.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Producto, autoridad y fase del proyecto (`identity.product`, `identity.authority`, `identity.phase`).
- Evidencia de cumplimiento de los cuatro hitos.
- Motivo de la replanificación v2.
- Dueño de cada riesgo e incidencia.

Hay desviación por encima del umbral (43,4 % frente a 10 %). Puedo preparar el punto de comité y la regularización de la línea base de CC-01.

---
*Pie:* criterio-portfolio 0.8.0 · ficha aplicada: `PRY-200.json` del 2026-10-22 · campos inciertos: los listados en «Sin dato» · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.8.0
