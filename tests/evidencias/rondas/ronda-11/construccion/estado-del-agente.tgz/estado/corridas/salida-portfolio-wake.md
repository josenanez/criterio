## 2026-10-22

**Revisé:** 74 documentos · 0 cambiaron · 0 proyectos recalculados. El barrido corrió y no hubo noticia: ningún umbral cruzó por documentos nuevos. No había peticiones en el servidor.

### Preguntas (confirmación periódica, primera corrida: 5 campos, por importancia)
Sesión sin interfaz: nadie las contesta ahora. Quedan **preguntadas el 22 de octubre de 2026, sin respuesta**; no se repiten hasta que se respondan.

1. **PRY-200 · línea base v2, motivo del cambio** (`PRY-200-variante-vial-del-sur/10-plan/2026-09-30-cronograma-v2.xml`, 2026-09-30): el fin pasó de 2026-12-10 a 2027-03-31 y el motivo no aparece en ningún documento. ¿Quién lo aprobó y por qué?
2. **PRY-200 · hitos «Diseños», «Licencias» y «Cimentación» en estado cumplido** (cronograma v2, 2026-09-30): sin acta de recibo ni otra evidencia. ¿Existe el documento que lo sustenta?
3. **PRY-200 · compromiso de Beatriz Cuéllar, «Entregar el punto 35»** (`30-reuniones/2026-10-12-comite-semanal.md`): venció el 2026-10-19 sin evidencia de entrega. ¿Se entregó, o se reprograma?
4. **PRY-199 · monto facturado del contrato CT-199** (`00-gobierno/2026-06-14-contrato-ct-199.docx`, 2026-06-14): no consta en ningún documento. ¿Cuánto se ha facturado a la fecha?
5. **PRY-199 · responsable de los riesgos** (`20-seguimiento/2026-10-20-informe-avance.pdf`, 2026-10-20): los dos riesgos registrados no tienen dueño. ¿Quién responde por cada uno?

**Vuelvo el 2026-10-23.**
