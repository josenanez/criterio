# Comité de producto · Locales comerciales

**Fecha:** 2026-10-16
**Asistentes:** Beatriz Cuéllar

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4501 | Requerimiento REQ-4501 | Andrés Lozano | — | — | aceptado | 2026-05-17 | — |
| REQ-4502 | Requerimiento REQ-4502 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-27 | — |
| REQ-4503 | Requerimiento REQ-4503 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-03 | — |
| REQ-4504 | Requerimiento REQ-4504 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-05-25 | — |
| REQ-4505 | Requerimiento REQ-4505 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4506 | Requerimiento REQ-4506 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-09-06 | — |
| REQ-4507 | Requerimiento REQ-4507 | Paula Céspedes | — | — | aceptado | 2026-04-26 | — |
| REQ-4508 | Requerimiento REQ-4508 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-09-06 | — |
| REQ-4509 | Requerimiento REQ-4509 | Diana Molina | se verifica en producción | — | aceptado | 2026-09-06 | — |
| REQ-4510 | Requerimiento REQ-4510 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4511 | Requerimiento REQ-4511 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-01 | — |
| REQ-4512 | Requerimiento REQ-4512 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-21 | — |
| REQ-4513 | Requerimiento REQ-4513 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-08-05 | — |
| REQ-2035 | Requerimiento REQ-2035 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-11 | — |

## Decisiones

- Se mantiene el plan
