# Caso de negocio · Vivienda VIS

**Código:** PRD-301
**Fecha:** 2026-02-01
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 166.067 | Caso de negocio, 2026-02-01 |

## Retorno esperado

Retorno esperado en 24 meses.
