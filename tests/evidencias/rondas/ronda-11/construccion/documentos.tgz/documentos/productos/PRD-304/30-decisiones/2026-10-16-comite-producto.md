# Comité de producto · Prefabricados

**Fecha:** 2026-10-16
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4401 | Requerimiento REQ-4401 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4402 | Requerimiento REQ-4402 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4403 | Requerimiento REQ-4403 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-01 | — |
| REQ-4404 | Requerimiento REQ-4404 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4405 | Requerimiento REQ-4405 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4406 | Requerimiento REQ-4406 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-04-09 | — |
| REQ-4407 | Requerimiento REQ-4407 | Elena Duarte | — | — | propuesto | 2026-07-01 | — |
| REQ-4408 | Requerimiento REQ-4408 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-06-05 | — |
| REQ-4409 | Requerimiento REQ-4409 | Beatriz Cuéllar | se verifica en producción | — | propuesto | 2026-08-01 | — |
| REQ-4410 | Requerimiento REQ-4410 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-02 | — |
| REQ-4411 | Requerimiento REQ-4411 | Paula Céspedes | se verifica en producción | — | propuesto | 2026-04-22 | — |
| REQ-4412 | Requerimiento REQ-4412 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-11 | — |
| REQ-4413 | Requerimiento REQ-4413 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-02 | — |
| REQ-2028 | Requerimiento REQ-2028 | Carlos Peña | se verifica en producción | — | aceptado | 2026-10-07 | — |
| REQ-2036 | Requerimiento REQ-2036 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-16 | — |

## Decisiones

- Se mantiene el plan
