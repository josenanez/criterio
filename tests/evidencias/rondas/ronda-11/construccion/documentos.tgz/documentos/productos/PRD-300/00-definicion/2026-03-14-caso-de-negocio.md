# Caso de negocio · Arriendo de oficinas

**Código:** PRD-300
**Fecha:** 2026-03-14
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 166.090 | Caso de negocio, 2026-03-14 |

## Retorno esperado

Retorno esperado en 24 meses.
