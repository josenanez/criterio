# Definición de producto · Vivienda VIS

**Código:** PRD-301
**Gerente de producto:** Camilo Beltrán
**Segmento:** Hogares
**Fecha de la definición:** 2026-02-01

## El problema

El segmento Hogares no tiene vivienda vis.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-10 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
