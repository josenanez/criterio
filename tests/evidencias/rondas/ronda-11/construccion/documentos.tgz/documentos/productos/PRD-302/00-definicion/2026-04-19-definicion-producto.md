# Definición de producto · Modelos BIM

**Código:** PRD-302
**Gerente de producto:** Óscar Ramírez
**Segmento:** Comunidad
**Fecha de la definición:** 2026-04-19

## El problema

El segmento Comunidad no tiene modelos bim.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del acero se sostiene** · declarado el 2026-09-02 · verificado con el concepto jurídico de cumplimiento del 2026-09-04 (anexo «Verificación del supuesto» del 2026-09-04)

## Proyectos que lo construyen

- Ninguno declarado
