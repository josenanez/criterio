# Caso de negocio · Interventoría externa

**Código:** PRD-309
**Fecha:** 2025-09-30
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 261.111 | Caso de negocio, 2025-09-30 |

## Retorno esperado

Retorno esperado en 24 meses.
