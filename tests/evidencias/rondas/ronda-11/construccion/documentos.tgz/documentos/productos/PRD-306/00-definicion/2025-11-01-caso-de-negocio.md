# Caso de negocio · Lotes campestres

**Código:** PRD-306
**Fecha:** 2025-11-01
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 154.267 | Caso de negocio, 2025-11-01 |

## Retorno esperado

Retorno esperado en 24 meses.
