# Caso de negocio · Locales comerciales

**Código:** PRD-305
**Fecha:** 2025-09-25
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 214.841 | Caso de negocio, 2025-09-25 |

## Retorno esperado

Retorno esperado en 24 meses.
