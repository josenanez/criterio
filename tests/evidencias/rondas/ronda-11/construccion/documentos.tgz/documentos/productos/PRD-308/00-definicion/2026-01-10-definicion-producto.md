# Definición de producto · Alquiler de maquinaria

**Código:** PRD-308
**Gerente de producto:** Gustavo Neira
**Segmento:** Inversionistas
**Fecha de la definición:** 2026-01-10

## El problema

El segmento Inversionistas no tiene alquiler de maquinaria.

## La propuesta

- Propuesta principal

## Supuestos

- **El precio del acero se sostiene** · declarado el 2026-04-20 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
