# Tablero de métricas · Alquiler de maquinaria

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-18

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 231.848 | 2026-10-18 |
