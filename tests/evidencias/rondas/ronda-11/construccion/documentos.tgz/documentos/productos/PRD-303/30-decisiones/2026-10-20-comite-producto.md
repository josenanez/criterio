# Comité de producto · Bodegas en arriendo

**Fecha:** 2026-10-20
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4301 | Requerimiento REQ-4301 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4302 | Requerimiento REQ-4302 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-21 | — |
| REQ-4303 | Requerimiento REQ-4303 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4304 | Requerimiento REQ-4304 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-04 | — |
| REQ-4305 | Requerimiento REQ-4305 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-03 | — |
| REQ-4306 | Requerimiento REQ-4306 | Sandra Gil | se verifica en producción | — | aceptado | 2026-08-18 | — |
| REQ-4307 | Requerimiento REQ-4307 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-11 | — |
| REQ-4308 | Requerimiento REQ-4308 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-18 | — |
| REQ-4309 | Requerimiento REQ-4309 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-02 | — |
| REQ-4310 | Requerimiento REQ-4310 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4311 | Requerimiento REQ-4311 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-26 | — |
| REQ-4312 | Requerimiento REQ-4312 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4313 | Requerimiento REQ-4313 | Mauricio Pérez | — | Cliente entrevistado | propuesto | 2026-08-10 | — |
| REQ-4314 | Requerimiento REQ-4314 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-01 | — |
| REQ-4315 | Requerimiento REQ-4315 | Javier Hoyos | se verifica en producción | — | propuesto | 2026-06-08 | — |
| REQ-2037 | Requerimiento REQ-2037 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-17 | — |

## Decisiones

- Se mantiene el plan
