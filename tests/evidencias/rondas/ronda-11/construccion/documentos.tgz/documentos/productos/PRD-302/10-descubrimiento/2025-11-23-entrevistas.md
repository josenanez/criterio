# Entrevistas · Modelos BIM

**Ronda:** Ronda · 2025-11-23
**Realizadas por:** Óscar Ramírez

### Cliente entrevistado · 2025-11-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
