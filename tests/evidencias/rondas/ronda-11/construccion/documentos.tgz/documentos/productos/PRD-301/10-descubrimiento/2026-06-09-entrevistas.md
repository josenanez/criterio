# Entrevistas · Vivienda VIS

**Ronda:** Ronda · 2026-06-09
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-06-09

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
