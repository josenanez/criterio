# Comité de producto · Vivienda VIS

**Fecha:** 2026-10-20
**Asistentes:** Camilo Beltrán

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-21 | — |
| REQ-4101 | Requerimiento REQ-4101 | Laura Vélez | se verifica en producción | — | aceptado | 2026-08-15 | — |
| REQ-4102 | Requerimiento REQ-4102 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-12 | — |
| REQ-4103 | Requerimiento REQ-4103 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4104 | Requerimiento REQ-4104 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-22 | — |
| REQ-4105 | Requerimiento REQ-4105 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-05-03 | — |
| REQ-4106 | Requerimiento REQ-4106 | Laura Vélez | — | — | aceptado | 2026-06-02 | — |
| REQ-4107 | Requerimiento REQ-4107 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-06-06 | — |
| REQ-4108 | Requerimiento REQ-4108 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-05-13 | — |
| REQ-4109 | Requerimiento REQ-4109 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-22 | — |
| REQ-4110 | Requerimiento REQ-4110 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-20 | — |
| REQ-4111 | Requerimiento REQ-4111 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-15 | — |

## Decisiones

- Se mantiene el plan
