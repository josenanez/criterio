# Definición de producto · Prefabricados

**Código:** PRD-304
**Gerente de producto:** Andrés Lozano
**Segmento:** Entidades públicas
**Fecha de la definición:** 2025-12-23

## El problema

El segmento Entidades públicas no tiene prefabricados.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia se expide sin objeciones** · declarado el 2026-09-22 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
