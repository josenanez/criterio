# Tablero de métricas · Interventoría externa

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-21

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 223.463 | 2026-10-21 |
