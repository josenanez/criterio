# Tablero de métricas · Modelos BIM

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 117.189 | 2026-10-16 |
