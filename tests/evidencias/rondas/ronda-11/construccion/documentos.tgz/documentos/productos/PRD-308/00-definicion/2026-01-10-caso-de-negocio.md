# Caso de negocio · Alquiler de maquinaria

**Código:** PRD-308
**Fecha:** 2026-01-10
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 237.276 | Caso de negocio, 2026-01-10 |

## Retorno esperado

Retorno esperado en 24 meses.
