# Tablero de métricas · Mantenimiento vial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-19

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 71.036 | 2026-10-19 |
