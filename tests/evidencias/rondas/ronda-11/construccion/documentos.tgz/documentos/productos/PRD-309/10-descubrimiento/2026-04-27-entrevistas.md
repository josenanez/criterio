# Entrevistas · Interventoría externa

**Ronda:** Ronda · 2026-04-27
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-04-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
