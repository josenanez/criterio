# Definición de producto · Bodegas en arriendo

**Código:** PRD-303
**Gerente de producto:** Elena Duarte
**Segmento:** Comunidad
**Fecha de la definición:** 2026-05-20

## El problema

El segmento Comunidad no tiene bodegas en arriendo.

## La propuesta

- Propuesta principal

## Supuestos

- **Los predios se compran a tiempo** · declarado el 2026-05-02 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
