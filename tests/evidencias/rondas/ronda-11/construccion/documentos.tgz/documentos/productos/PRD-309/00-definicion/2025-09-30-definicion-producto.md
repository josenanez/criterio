# Definición de producto · Interventoría externa

**Código:** PRD-309
**Gerente de producto:** Javier Hoyos
**Segmento:** Hogares
**Fecha de la definición:** 2025-09-30

## El problema

El segmento Hogares no tiene interventoría externa.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia se expide sin objeciones** · declarado el 2026-05-15 · verificado con el documento técnico del proveedor del 2026-08-16 (anexo «Verificación del supuesto» del 2026-08-16)

## Proyectos que lo construyen

- Ninguno declarado
