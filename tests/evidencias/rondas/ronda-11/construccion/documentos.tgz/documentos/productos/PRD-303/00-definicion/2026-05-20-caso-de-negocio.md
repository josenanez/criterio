# Caso de negocio · Bodegas en arriendo

**Código:** PRD-303
**Fecha:** 2026-05-20
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 155.642 | Caso de negocio, 2026-05-20 |

## Retorno esperado

Retorno esperado en 24 meses.
