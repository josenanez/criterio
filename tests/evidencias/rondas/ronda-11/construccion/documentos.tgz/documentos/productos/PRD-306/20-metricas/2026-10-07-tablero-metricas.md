# Tablero de métricas · Lotes campestres

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 113.327 | 2026-10-07 |
