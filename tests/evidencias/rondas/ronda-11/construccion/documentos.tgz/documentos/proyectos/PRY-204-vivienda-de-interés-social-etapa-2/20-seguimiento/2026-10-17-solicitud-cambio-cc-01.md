# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Vivienda de interés social etapa 2
**Fecha:** 2026-10-17
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +58 días sobre la línea base vigente |
| Costo | 116.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
