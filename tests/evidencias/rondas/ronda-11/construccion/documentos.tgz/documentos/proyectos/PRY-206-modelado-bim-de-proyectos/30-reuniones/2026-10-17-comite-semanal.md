# Comité de Seguridad · Modelado BIM de proyectos

**Fecha:** 2026-10-17
**Asistentes:** Óscar Ramírez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 14 | 2026-10-10 |
| Liliana Torres | Entregar el punto 19 | 2026-11-11 |
