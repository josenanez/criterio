# Comité de Seguridad · Variante vial del sur

**Fecha:** 2026-10-12
**Asistentes:** Javier Hoyos, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 35 | 2026-10-19 |
