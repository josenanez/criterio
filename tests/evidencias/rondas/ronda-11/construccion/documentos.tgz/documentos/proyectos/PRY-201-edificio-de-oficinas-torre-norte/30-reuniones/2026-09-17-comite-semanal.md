# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-09-17
**Asistentes:** Beatriz Cuéllar, Diana Molina, Felipe Arango, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-20 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-25 |
| Felipe Arango | Revisar el anexo 3 | por definir |
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 |
| Diana Molina | Aprobar el diseño 5 | 2026-10-15 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-10-11 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 |
| María Restrepo | Entregar el punto 8 | 2026-09-30 |
