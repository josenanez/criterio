# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-203
**Fecha de corte:** 2026-10-17
**Gerente:** Carlos Peña

## Estado declarado

**Rojo**

Avance reportado: **93%**

## Lo que pasó en el periodo

- El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite
- El equipo perdió dos semanas por rotación del residente de obra
- Se ajustó el programa de obra con el contratista de estructura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.066.126.764 |
| Ejecutado | 1.510.877.959 |
| Proyección al cierre | 4.214.486.517 |

## Riesgos abiertos

- Cambio en la norma de sismorresistencia que puede mover el alcance
