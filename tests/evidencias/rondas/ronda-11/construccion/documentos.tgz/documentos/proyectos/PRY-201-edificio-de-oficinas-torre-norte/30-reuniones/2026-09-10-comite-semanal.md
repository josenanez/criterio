# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-09-10
**Asistentes:** Beatriz Cuéllar, Diana Molina, Felipe Arango, Laura Vélez, Mauricio Pérez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-02 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-16 |
| Felipe Arango | Revisar el anexo 3 | por definir |
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 |
