# Informe de avance · Variante vial del sur

**Código:** PRY-200
**Fecha de corte:** 2026-09-30
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **73%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación del residente de obra
- Se recibió el concepto de la autoridad ambiental sobre el plan de manejo
- Las lluvias detuvieron el movimiento de tierras durante nueve días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 400.065.156 |
| Ejecutado | 373.222.579 |
| Proyección al cierre | 757.747.694 |

## Riesgos abiertos

- Compra de predios pendiente en el trazado
- Lluvias por encima del promedio en la temporada
