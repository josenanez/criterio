# Comité de Contratación · Hospital de segundo nivel

**Fecha:** 2026-10-11
**Asistentes:** Rubén Cárdenas, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 20 | 2026-11-12 |
