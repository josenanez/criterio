# Comité de Contratación · Puente vehicular sobre el río

**Fecha:** 2026-10-17
**Asistentes:** Jorge Medina, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 18 | 2026-10-30 |
