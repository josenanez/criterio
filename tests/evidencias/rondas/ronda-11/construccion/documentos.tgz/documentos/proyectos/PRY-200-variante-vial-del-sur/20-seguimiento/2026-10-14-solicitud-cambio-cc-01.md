# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Variante vial del sur
**Fecha:** 2026-10-14
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +111 días sobre la línea base vigente |
| Costo | 222.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
