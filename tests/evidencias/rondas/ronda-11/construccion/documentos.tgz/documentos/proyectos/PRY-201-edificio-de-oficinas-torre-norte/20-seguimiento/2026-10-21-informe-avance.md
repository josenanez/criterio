# Informe de avance · Edificio de oficinas Torre Norte

**Código:** PRY-201
**Fecha de corte:** 2026-10-21
**Gerente:** Diana Molina

## Estado declarado

**Verde**

Avance reportado: **51%**

## Lo que pasó en el periodo

- El ensayo de resistencia del concreto no alcanzó el valor pactado y se repite
- Se acordó con la interventoría cómo se miden las cantidades de obra

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 269.031.166 |
| Ejecutado | 501.908.947 |
| Proyección al cierre | 813.951.902 |

## Riesgos abiertos

- Compra de predios pendiente en el trazado
- Concentración del conocimiento en una sola persona
