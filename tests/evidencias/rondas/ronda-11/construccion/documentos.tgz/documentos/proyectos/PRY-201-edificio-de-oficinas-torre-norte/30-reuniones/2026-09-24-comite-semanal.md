# Comité de Inversiones · Edificio de oficinas Torre Norte

**Fecha:** 2026-09-24
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Felipe Arango, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-02 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-05 |
| Felipe Arango | Revisar el anexo 3 | por definir |
| Laura Vélez | Validar el ambiente 4 | 2026-09-17 |
| Diana Molina | Aprobar el diseño 5 | 2026-10-22 |
| Liliana Torres | Confirmar la fecha 7 | 2026-10-03 |
| María Restrepo | Entregar el punto 8 | 2026-09-30 |
| Andrés Lozano | Enviar el documento 9 | 2026-10-01 |
| Natalia Ospina | Cerrar la prueba 10 | 2026-10-22 |
| Ricardo Salas | Revisar el anexo 11 | 2026-10-10 |
| Beatriz Cuéllar | Validar el ambiente 12 | por definir |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Javier Hoyos): recibido, acta de recibo del 2026-09-24.
