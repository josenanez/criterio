# Solicitud de cambio CC-02

**Proyecto:** PRY-203 · Planta de tratamiento de agua
**Fecha:** 2026-10-17
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +46 días sobre la línea base vigente |
| Costo | 92.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
