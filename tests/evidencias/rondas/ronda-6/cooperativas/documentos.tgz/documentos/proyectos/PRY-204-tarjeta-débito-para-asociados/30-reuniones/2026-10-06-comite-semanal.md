# Comité de Educación · Tarjeta débito para asociados

**Fecha:** 2026-10-06
**Asistentes:** Javier Hoyos, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 35 | 2026-10-21 |
