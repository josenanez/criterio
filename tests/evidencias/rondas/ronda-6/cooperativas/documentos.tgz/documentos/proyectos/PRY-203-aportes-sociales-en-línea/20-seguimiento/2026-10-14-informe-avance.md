# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **36%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 336.456.745 |
| Ejecutado | 441.454.741 |
| Proyección al cierre | 767.281.484 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Aprobación del reglamento por el Consejo de Administración
