# Comité de Crédito · Prevención de lavado de activos

**Fecha:** 2026-10-08
**Asistentes:** Ricardo Salas, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 39 | 2026-09-30 |
