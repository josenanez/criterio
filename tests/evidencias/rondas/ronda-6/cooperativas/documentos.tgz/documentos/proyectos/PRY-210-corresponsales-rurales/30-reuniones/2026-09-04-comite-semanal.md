# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-09-04
**Asistentes:** Andrés Lozano, Javier Hoyos, Liliana Torres, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | por definir |
| Javier Hoyos | Cerrar la prueba 2 | por definir |
| Javier Hoyos | Revisar el anexo 3 | por definir |
| Sandra Gil | Validar el ambiente 4 | 2026-09-29 |
