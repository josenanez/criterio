# Informe de avance · Core cooperativo

**Código:** PRY-202
**Fecha de corte:** 2026-10-09
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **73%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 14.468.329.305 |
| Ejecutado | 8.652.317.770 |
| Proyección al cierre | 18.103.235.355 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
