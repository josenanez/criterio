# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Bienestar social
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Crédito
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-06-14

## Objetivo del negocio

Entregar corresponsales rurales para Bienestar social.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Crédito el 2026-06-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-24 |
| Cierre | 2027-08-30 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
