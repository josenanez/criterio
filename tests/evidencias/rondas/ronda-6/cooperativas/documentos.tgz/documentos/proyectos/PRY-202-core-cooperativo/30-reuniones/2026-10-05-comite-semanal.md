# Comité de Crédito · Core cooperativo

**Fecha:** 2026-10-05
**Asistentes:** Natalia Ospina, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 13 | 2026-10-19 |
