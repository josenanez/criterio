# Comité de Crédito · Convenios de libranza con empresas

**Fecha:** 2026-10-06
**Asistentes:** Javier Hoyos, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 11 | 2026-11-10 |
