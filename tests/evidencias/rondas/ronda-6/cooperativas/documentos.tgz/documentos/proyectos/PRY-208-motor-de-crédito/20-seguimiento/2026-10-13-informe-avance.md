# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **67%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 8.150.332.447 |
| Ejecutado | 9.306.995.922 |
| Proyección al cierre | 17.185.557.889 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
