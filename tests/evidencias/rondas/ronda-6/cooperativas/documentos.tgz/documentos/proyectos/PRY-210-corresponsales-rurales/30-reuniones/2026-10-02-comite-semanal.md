# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Carlos Peña, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-11-08 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-08 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-23 |
| Paula Céspedes | Entregar el punto 8 | 2026-10-21 |
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-20 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-18 |
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-24 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-11-08 |
| Carlos Peña | Enviar el documento 17 | por definir |
| Óscar Ramírez | Cerrar la prueba 18 | 2026-10-12 |
| Rubén Cárdenas | Revisar el anexo 19 | 2026-10-21 |
| Laura Vélez | Validar el ambiente 20 | 2026-10-13 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Javier Hoyos): recibido, acta de recibo del 2026-10-02.
- Actualizar la matriz 14 (Ricardo Salas): recibido, acta de recibo del 2026-10-02.
- Entregar el punto 16 (Felipe Arango): recibido, acta de recibo del 2026-10-02.
