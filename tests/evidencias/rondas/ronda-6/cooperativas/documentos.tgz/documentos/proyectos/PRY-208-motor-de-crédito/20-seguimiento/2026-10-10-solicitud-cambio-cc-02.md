# Solicitud de cambio CC-02

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-10
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +115 días sobre la línea base vigente |
| Costo | 230.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
