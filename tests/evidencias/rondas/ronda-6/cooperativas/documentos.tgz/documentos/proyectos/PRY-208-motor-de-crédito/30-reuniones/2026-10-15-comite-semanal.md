# Comité de Educación · Motor de crédito

**Fecha:** 2026-10-15
**Asistentes:** Rubén Cárdenas, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 16 | 2026-10-12 |
