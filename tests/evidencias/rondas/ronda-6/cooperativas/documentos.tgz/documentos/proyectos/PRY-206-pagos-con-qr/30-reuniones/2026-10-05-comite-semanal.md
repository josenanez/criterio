# Comité de Crédito · Pagos con QR

**Fecha:** 2026-10-05
**Asistentes:** Mauricio Pérez, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 14 | por definir |
