# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-09-25
**Asistentes:** Andrés Lozano, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-10-19 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-21 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-23 |
| Paula Céspedes | Entregar el punto 8 | 2026-10-07 |
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-04 |
| Jorge Medina | Revisar el anexo 11 | 2026-09-21 |
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-08 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-10-18 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-23 |
| Felipe Arango | Entregar el punto 16 | 2026-10-14 |
