# Acta de constitución · Microcrédito rural

**Código:** PRY-207
**Área dueña:** Ahorro y aportes
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Tecnología
**Producto asociado:** microcrédito
**Fecha de aprobación:** 2025-10-24

## Objetivo del negocio

Entregar microcrédito rural para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Tecnología el 2025-10-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-03 |
| Cierre | 2026-05-10 |

## Criterio de éxito

Microcrédito rural en producción y medido.

## Dependencias declaradas

- Ninguna declarada
