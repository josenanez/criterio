# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-13
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **47%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.546.990.306 |
| Ejecutado | 2.527.235.531 |
| Proyección al cierre | 8.851.807.729 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
