# Comité de producto · Microcrédito

**Fecha:** 2026-10-05
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-4501 | Requerimiento REQ-4501 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-07-09 | — |
| REQ-4502 | Requerimiento REQ-4502 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-08-21 | — |
| REQ-4503 | Requerimiento REQ-4503 | Carlos Peña | se verifica en producción | — | aceptado | 2026-05-16 | — |
| REQ-4504 | Requerimiento REQ-4504 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-07 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | — | Cliente entrevistado | aceptado | 2026-04-24 | — |
| REQ-4506 | Requerimiento REQ-4506 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-04 | — |
| REQ-4507 | Requerimiento REQ-4507 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4508 | Requerimiento REQ-4508 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-24 | — |
| REQ-4509 | Requerimiento REQ-4509 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4510 | Requerimiento REQ-4510 | sin asignar | se verifica en producción | — | aceptado | 2026-04-01 | — |
| REQ-4511 | Requerimiento REQ-4511 | sin asignar | se verifica en producción | — | aceptado | 2026-06-06 | — |
| REQ-4512 | Requerimiento REQ-4512 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-20 | — |
| REQ-4513 | Requerimiento REQ-4513 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-05-01 | — |
| REQ-4514 | Requerimiento REQ-4514 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4515 | Requerimiento REQ-4515 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-08-10 | — |

## Decisiones

- Se mantiene el plan
