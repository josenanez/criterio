# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-02-01
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 173.353 | Caso de negocio, 2026-02-01 |

## Retorno esperado

Retorno esperado en 24 meses.
