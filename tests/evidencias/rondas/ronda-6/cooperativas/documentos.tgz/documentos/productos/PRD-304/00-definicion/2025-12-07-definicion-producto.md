# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Natalia Ospina
**Segmento:** Pensionados
**Fecha de la definición:** 2025-12-07

## El problema

El segmento Pensionados no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-29 · verificado

## Proyectos que lo construyen

- Ninguno declarado
