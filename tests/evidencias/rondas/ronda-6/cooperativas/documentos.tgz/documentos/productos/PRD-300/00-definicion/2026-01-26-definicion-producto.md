# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Andrés Lozano
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-01-26

## El problema

El segmento Asociados urbanos no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-04-15 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
