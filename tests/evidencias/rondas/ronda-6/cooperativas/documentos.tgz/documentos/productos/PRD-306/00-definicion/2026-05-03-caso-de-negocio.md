# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2026-05-03
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 134.482 | Caso de negocio, 2026-05-03 |

## Retorno esperado

Retorno esperado en 24 meses.
