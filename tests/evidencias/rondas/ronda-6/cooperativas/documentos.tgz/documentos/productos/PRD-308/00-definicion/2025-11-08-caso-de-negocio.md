# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2025-11-08
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 180.870 | Caso de negocio, 2025-11-08 |

## Retorno esperado

Retorno esperado en 24 meses.
