# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** Diana Molina
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-06-17

## El problema

El segmento Asociados urbanos no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-03-21 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
