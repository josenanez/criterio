# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2026-06-17
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 282.341 | Caso de negocio, 2026-06-17 |

## Retorno esperado

Retorno esperado en 24 meses.
