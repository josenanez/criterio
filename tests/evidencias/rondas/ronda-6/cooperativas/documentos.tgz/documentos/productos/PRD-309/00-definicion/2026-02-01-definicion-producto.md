# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Javier Hoyos
**Segmento:** Pensionados
**Fecha de la definición:** 2026-02-01

## El problema

El segmento Pensionados no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-07-31 · verificado

## Proyectos que lo construyen

- Ninguno declarado
