# Entrevistas · Recaudos

**Ronda:** Ronda · 2025-08-15
**Realizadas por:** Liliana Torres

### Cliente entrevistado · 2025-08-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
