# Comité de producto · Crédito de libranza

**Fecha:** 2026-10-16
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-24 | — |
| REQ-4001 | Requerimiento REQ-4001 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4002 | Requerimiento REQ-4002 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-30 | — |
| REQ-4003 | Requerimiento REQ-4003 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-20 | — |
| REQ-4004 | Requerimiento REQ-4004 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4005 | Requerimiento REQ-4005 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-16 | — |
| REQ-4006 | Requerimiento REQ-4006 | sin asignar | se verifica en producción | — | propuesto | 2026-05-02 | — |
| REQ-4007 | Requerimiento REQ-4007 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-20 | — |
| REQ-4008 | Requerimiento REQ-4008 | Andrés Lozano | — | Cliente entrevistado | propuesto | 2026-06-29 | — |
| REQ-4009 | Requerimiento REQ-4009 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-25 | — |
| REQ-4010 | Requerimiento REQ-4010 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4011 | Requerimiento REQ-4011 | María Restrepo | se verifica en producción | — | aceptado | 2026-08-24 | — |

## Decisiones

- Se mantiene el plan
