# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Liliana Torres
**Segmento:** Pensionados
**Fecha de la definición:** 2025-11-10

## El problema

El segmento Pensionados no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-06-27 · verificado

## Proyectos que lo construyen

- Ninguno declarado
