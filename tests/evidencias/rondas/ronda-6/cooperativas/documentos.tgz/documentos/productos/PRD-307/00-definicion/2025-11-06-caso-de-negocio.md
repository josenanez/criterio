# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2025-11-06
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 250.177 | Caso de negocio, 2025-11-06 |

## Retorno esperado

Retorno esperado en 24 meses.
