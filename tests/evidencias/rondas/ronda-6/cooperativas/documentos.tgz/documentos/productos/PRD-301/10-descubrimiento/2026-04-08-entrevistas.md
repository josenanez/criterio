# Entrevistas · Ahorro a la vista

**Ronda:** Ronda · 2026-04-08
**Realizadas por:** Liliana Torres

### Cliente entrevistado · 2026-04-08

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
