# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Óscar Ramírez
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-09-05

## El problema

El segmento Jóvenes no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-04 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
