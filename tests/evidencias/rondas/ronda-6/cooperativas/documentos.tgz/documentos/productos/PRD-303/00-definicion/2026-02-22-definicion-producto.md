# Definición de producto · Tarjeta débito

**Código:** PRD-303
**Gerente de producto:** Paula Céspedes
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-02-22

## El problema

El segmento Asociados urbanos no tiene tarjeta débito.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-07-09 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
