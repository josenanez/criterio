# Comité de producto · Auxilios de solidaridad

**Fecha:** 2026-10-05
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4701 | Requerimiento REQ-4701 | María Restrepo | se verifica en producción | — | propuesto | 2026-07-19 | — |
| REQ-4702 | Requerimiento REQ-4702 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-13 | — |
| REQ-4703 | Requerimiento REQ-4703 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-18 | — |
| REQ-4704 | Requerimiento REQ-4704 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-07-20 | — |
| REQ-4705 | Requerimiento REQ-4705 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-19 | — |
| REQ-4706 | Requerimiento REQ-4706 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4707 | Requerimiento REQ-4707 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-20 | — |
| REQ-4708 | Requerimiento REQ-4708 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4709 | Requerimiento REQ-4709 | Gustavo Neira | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-12 | — |
| REQ-4710 | Requerimiento REQ-4710 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4711 | Requerimiento REQ-4711 | Mauricio Pérez | se verifica en producción | — | aceptado | 2026-06-29 | — |
| REQ-2026 | Requerimiento REQ-2026 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-26 | — |

## Decisiones

- Se mantiene el plan
