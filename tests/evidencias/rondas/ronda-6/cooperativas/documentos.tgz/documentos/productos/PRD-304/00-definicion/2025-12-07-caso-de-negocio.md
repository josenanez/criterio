# Caso de negocio · Pagos QR

**Código:** PRD-304
**Fecha:** 2025-12-07
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 120.789 | Caso de negocio, 2025-12-07 |

## Retorno esperado

Retorno esperado en 24 meses.
