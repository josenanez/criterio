# Tablero de métricas · Ahorro a la vista

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 125.078 | 2026-10-16 |
