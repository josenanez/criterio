# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2025-09-05
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 282.429 | Caso de negocio, 2025-09-05 |

## Retorno esperado

Retorno esperado en 24 meses.
