# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2025-11-10
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 122.511 | Caso de negocio, 2025-11-10 |

## Retorno esperado

Retorno esperado en 24 meses.
