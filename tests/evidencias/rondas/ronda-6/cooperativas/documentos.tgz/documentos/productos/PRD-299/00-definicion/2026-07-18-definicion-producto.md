# Definición de producto · Kit de bienvenida del asociado

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-18

## El problema

El segmento Personas no tiene kit de bienvenida del asociado.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-08-27 · verificado

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
