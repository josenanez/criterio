# Tablero de métricas · Kit de bienvenida del asociado

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 120.000 | 2026-10-10 |
