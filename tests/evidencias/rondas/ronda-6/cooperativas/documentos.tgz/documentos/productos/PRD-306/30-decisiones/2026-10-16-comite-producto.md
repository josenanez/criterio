# Comité de producto · Recaudos

**Fecha:** 2026-10-16
**Asistentes:** Liliana Torres

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-24 | — |
| REQ-4601 | Requerimiento REQ-4601 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4602 | Requerimiento REQ-4602 | sin asignar | se verifica en producción | — | aceptado | 2026-04-06 | — |
| REQ-4603 | Requerimiento REQ-4603 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-03-17 | — |
| REQ-4604 | Requerimiento REQ-4604 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-23 | — |
| REQ-4605 | Requerimiento REQ-4605 | Jorge Medina | — | — | propuesto | 2026-07-24 | — |
| REQ-4606 | Requerimiento REQ-4606 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-10 | — |
| REQ-4607 | Requerimiento REQ-4607 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4608 | Requerimiento REQ-4608 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4609 | Requerimiento REQ-4609 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-17 | — |
| REQ-4610 | Requerimiento REQ-4610 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4611 | Requerimiento REQ-4611 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-21 | — |
| REQ-4612 | Requerimiento REQ-4612 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-25 | — |
| REQ-4613 | Requerimiento REQ-4613 | Andrés Lozano | — | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4614 | Requerimiento REQ-4614 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-07 | — |
| REQ-4615 | Requerimiento REQ-4615 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-24 | — |
| REQ-2030 | Requerimiento REQ-2030 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-04 | — |
| REQ-2038 | Requerimiento REQ-2038 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-06 | — |

## Decisiones

- Se mantiene el plan
