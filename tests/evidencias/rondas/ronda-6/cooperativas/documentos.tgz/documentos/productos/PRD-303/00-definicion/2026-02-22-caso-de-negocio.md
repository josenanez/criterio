# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-02-22
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 282.124 | Caso de negocio, 2026-02-22 |

## Retorno esperado

Retorno esperado en 24 meses.
