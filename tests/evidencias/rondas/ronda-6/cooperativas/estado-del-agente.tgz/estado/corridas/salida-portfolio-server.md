# Rostrum — para mirarlo un rato

**Términos:** ya estaban vigentes para esta versión (0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16, comprobante en `.criterio/terminos/`). No hizo falta volver a registrarlos.

**Forma elegida:** «para mirarlo un rato» (respuesta sugerida: empezar por la primera). Se levanta, se mira y se apaga con Ctrl-C. El patrocinador no tiene un enlace que funcione mañana; para eso existe «que quede corriendo», que requiere hablar con seguridad.

**Informe:** existe en `reportes/` (portada, proyectos PRY-199 a PRY-211, decisiones, productos).

**Dirección:** escucha solo en este equipo, `http://127.0.0.1:8787`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto; enlaza a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Informe de producto; enlaza a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda correos. El formulario deja la petición en cola; el agente la ve con `due` cuando despierte.

**Cierre:** este enlace (`127.0.0.1:8787`) solo sirve en este equipo, así que no se lo pases a nadie: sirve para que lo veas tú. El informe es del 2026-10-16 (15:13) y queda desactualizado en cuanto cambie un documento o corra otro barrido; la portada lo dice. Para que el patrocinador tenga un enlace propio hay que pasar a «que quede corriendo» y pedirle a la organización un host con puerto, publicarlo detrás de su control de acceso y mantener el equipo encendido.
