# Corrida del 2026-10-16 · document-index

13 proyectos · 18 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

76 documentos sin cambio, 0 por releer. 104 citas de PRY-210 marcadas como no resueltas por el índice, pero los 15 documentos citados existen: probable discrepancia de rutas relativas, no confirmada.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-16

**Documentos:** 76 · **Sin cambio:** 76 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 104 citas de PRY-210 (corresponsales rurales) como "fuente no encontrada". Todas salen de `documentos/proyectos/PRY-210-corresponsales-rurales/00-gobierno/ficha-pm.json`: identidad, estado declarado, plan, dinero y 26 compromisos.

Los 15 documentos que citan (acta de constitución, cronograma v1, informe de avance del 13-oct, actas de recibo 3/4/7/13/14/16/18/19, comités semanales y notas del 16-oct) **sí existen en la carpeta del proyecto**. Con esa evidencia, lo más probable es que las rutas de la ficha sean relativas a la carpeta del proyecto y el índice las busque desde la raíz de documentos. Esto no está confirmado: no se corrigió nada ni se comparó cita por cita.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-210 | 104 campos de `pm_record` (identity, declared, plan, money, commitments[0..25]) | los 15 documentos arriba listados |

### Formatos que no se pudieron leer
Ninguno: este comando no lee documentos, solo los cuenta y los compara.

### Siguiente paso
No hay nada que releer, así que no hace falta `/portfolio-scan`. Queda por revisar si las citas de PRY-210 son un falso positivo de rutas.
