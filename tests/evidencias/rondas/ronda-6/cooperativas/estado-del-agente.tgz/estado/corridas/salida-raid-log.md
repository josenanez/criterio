## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-16

**De qué documentos sale:** las 13 fichas de `estado/records/` (sección RAID y compromisos), las 7 minutas de comité de PRY-199, 202, 204, 205, 206, 208 y 209, las 6 minutas y las notas del 2026-10-16 de PRY-210, la minuta .docx de PRY-207 (leída del caché de texto), los informes de avance citados por cada ficha, las actas de constitución (sección «Dependencias declaradas») y las solicitudes de cambio de PRY-208. No hay minutas de PRY-200, 201, 203 ni 211: en esos cuatro, lo dicho en reuniones no se pudo revisar.

7 riesgos · 0 supuestos · 15 incidencias · 14 dependencias (36 ítems; 14 reclasificados desde «riesgo»)
36 sin doliente · 36 sin fecha de resolución · 1 no registrado formalmente · sin movimiento: no medible (ver límites)

Escala de valoración: los documentos no traen probabilidad ni impacto para ningún ítem. No inventé una; la columna dice «no valorado». Si quieren usar alta/media/baja, la valoración la hace el gerente.

### Necesitan decisión ahora
Criterio de escalamiento: afecta a otro proyecto, o el doliente está fuera del proyecto. Ninguno tiene doliente.

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| D-CORE | Dependencia (estaba como riesgo) | «Dependencia del proveedor del core cooperativo», PRY-199, 201, 204, 205, 206, 207, 210 | sin doliente | informes 2026-09-28 a 2026-10-16 | Afecta a 7 proyectos a la vez y el doliente es externo. Esos proyectos tienen hito «Integración con el core cooperativo», y PRY-202 (Core cooperativo) tiene su piloto del 2026-10-09 vencido y «en curso». Ningún documento dice que la dependencia sea de PRY-202 ni de otro proyecto: es una lectura mía para que alguien la confirme. |
| D-REGL | Dependencia (estaba como riesgo) + incidencia | Aprobación del reglamento por el Consejo de Administración (PRY-203, 205, 210, 211). El Consejo ya pidió ajustarlo antes del piloto (PRY-200, 204, 211) | sin doliente | 2026-09-29 a 2026-10-14 | Misma decisión de un órgano externo que toca a 6 proyectos. En PRY-211 convive con un cronograma que da el piloto por cerrado. |
| I-SEG | Incidencia | «Hallazgo de seguridad levantado en la revisión de arquitectura», PRY-199, 201, 202, 206, 209, 210 | sin doliente | 2026-09-28 a 2026-10-14 (PRY-210 sin fecha) | Seis proyectos con el mismo texto. No sé si es un solo hallazgo o seis; ningún documento lo dice. Si es uno, necesita un solo doliente. |
| I-ROT | Incidencia | «El equipo perdió dos semanas por rotación de un desarrollador clave», PRY-203, 206, 208, 210 | sin doliente | 2026-10-09 a 2026-10-14 (208 y 210 sin fecha) | En PRY-208 se junta con el riesgo «Concentración del conocimiento en una sola persona», mientras hay dos solicitudes de cambio (CC-01 y CC-02) sin presentar al comité. |
| I-CARGA | Incidencia | «La prueba de carga no alcanzó el umbral pactado y se repite», PRY-200 y PRY-203 | sin doliente | 2026-10-12 y 2026-10-14 | PRY-200 y PRY-203 tienen el cierre del acta vencido (2026-08-13 y 2026-07-25) y no hay cronograma que lo mueva. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas dicen que nadie lo anotó como riesgo | Riesgo, **no registrado formalmente**. Ya está en la ficha de PRY-210, extraído de las notas | PRY-210, `2026-10-16-notas-reunion.txt` | 2026-10-16 |

Es el único. Leí las minutas de PRY-199, 202, 204, 205, 206, 207, 208, 209 y 210: solo traen asistentes y compromisos, sin riesgos dichos al pasar. No inventé ninguno.

### Sin doliente o sin fecha
Falta de doliente y de fecha se reporta, no se rellena. **Los 36 ítems no tienen doliente.** Fecha: ninguno trae fecha de resolución. Las fechas «desde» son las del informe donde aparecen, no necesariamente cuándo ocurrió el hecho. En PRY-208 (rotación) y PRY-210 (rotación y seguridad) ni eso: «desde» está vacío.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| todos | los cuatro tipos | los 36 ítems de las secciones anteriores y del registro completo | doliente; fecha de resolución o de revisión |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| D-CORE (7 proyectos) | «proveedor del core cooperativo»; sin código de proyecto | No. Declarada, no acordada | PRY-202 tiene hito «Piloto con asociados» del 2026-10-09 vencido y su informe dice «se reprogramó la salida» sin cronograma ni acta que lo respalde. Si PRY-202 es la contraparte, esto la afecta; no puedo afirmarlo. |
| D-REGL (4 proyectos) | Consejo de Administración (órgano, no proyecto) | No | PRY-211 declara «Piloto con asociados» cerrado el 2026-03-11 y a la vez dice que el reglamento se ajusta «antes del piloto». Los documentos se contradicen. |
| D-PROV (PRY-202, 203, 204) | «proveedor… la última entrega»; sin código | No: el proveedor «no ha confirmado la fecha» | En PRY-204, «Bolsa de horas de desarrollo» venció el 2026-08-04 en CT-467 y CT-968 sin que nadie diga que se entregó. |

Las actas de constitución de PRY-203, 204, 207 y 210 dicen «Ninguna declarada» en dependencias. Ninguna ficha tiene una dependencia con código de proyecto, así que **el cruce entre proyectos no se puede hacer con lo registrado**. Propongo que los gerentes declaren de qué proyecto dependen.

### Registro completo
Agrupado por texto idéntico. Prob. e Impacto: no valorado en todos. Doliente: sin doliente en todos. Fecha: sin fecha en todos. Último movimiento: fecha del informe donde aparece, porque no hay otra.

| Id | Tipo | Qué | Proyectos | Último movimiento |
|---|---|---|---|---|
| R-NORM | Riesgo | Cambio normativo del supervisor que puede mover el alcance | 199, 200, 201, 207, 209 | 2026-09-28 a 2026-10-16 |
| R-CONC | Riesgo | Concentración del conocimiento en una sola persona | 208 | 2026-10-13 |
| R-EQ | Riesgo, no registrado formalmente | Proveedor podría no llegar con el equipo completo para la siguiente fase | 210 | 2026-10-16 |
| D-CORE | Dependencia (reclasificada desde riesgo) | Dependencia del proveedor del core cooperativo | 199, 201, 204, 205, 206, 207, 210 | 2026-09-28 a 2026-10-16 |
| D-REGL | Dependencia (reclasificada desde riesgo) | Aprobación del reglamento por el Consejo de Administración | 203, 205, 210, 211 | 2026-09-29 a 2026-10-14 |
| D-PROV | Dependencia (reclasificada desde riesgo) | El proveedor no ha confirmado la fecha de la última entrega | 202, 203, 204 | 2026-10-06 a 2026-10-14 |
| I-SEG | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | 199, 201, 202, 206, 209, 210 | 2026-09-28 a 2026-10-14 |
| I-ROT | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | 203, 206, 208, 210 | 2026-10-09 a 2026-10-14 |
| I-CARGA | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | 200, 203 | 2026-10-12 y 2026-10-14 |
| I-REGL | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | 200, 204, 211 | 2026-10-06 a 2026-10-12 |

Cuentas: riesgos 5+1+1 = 7; dependencias 7+4+3 = 14; incidencias 6+4+2+3 = 15. Suman 36 ítems.

**Reclasificaciones y por qué** (prueba rápida de raid-taxonomy): estaban registrados como riesgo. «Dependencia del proveedor del core», «Aprobación del reglamento por el Consejo» y «El proveedor no ha confirmado la fecha» dependen de alguien fuera del proyecto, así que son dependencias. Los tres se coordinan y se confirman con la contraparte; no se mitigan.

### Límites
- **Sin movimiento en dos períodos:** no lo puedo medir. Hay una sola foto del registro (2026-10-16) y los informes de avance son uno por proyecto. No hay historial de movimiento del RAID.
- **Supuestos:** no hay ninguno registrado ni dicho en reuniones. No levanté ninguno; con estos documentos no hay base.
- **PRY-200, 201, 203 y 211:** sin minutas, no pude buscar riesgos dichos al pasar.
- **Mitigaciones:** ningún ítem trae mitigación, así que «mitigación vencida sin evidencia» no aplica; sería inventar.
- **Otras señales fuera del RAID:** hay compromisos vencidos (PRY-205, 208 y varios de PRY-210), cierres vencidos (PRY-200, 203, 207, 211) y solicitudes de cambio pendientes (PRY-208). No son ítems RAID; salen en `/status-report` y `/commitment`.

### Siguiente paso
Propongo subir al comité del 2026-10-30 D-CORE, D-REGL e I-SEG, con la decisión formulada: quién es el doliente de cada uno y, para D-CORE, de qué proyecto depende cada uno de los siete. También propongo, sin asignar, que el gerente de cada proyecto sea doliente provisional de lo suyo y que el patrocinador o el comité confirme a los dolientes de los ítems que cruzan proyectos. Los gerentes deciden si formalizan el riesgo de PRY-210.

*Pie de rigor: lo que dicen los documentos va con su fuente en las fichas. Lo que son lecturas mías (que el core de los siete proyectos sea PRY-202, que los hallazgos de seguridad sean uno solo, la reclasificación) está marcado como tal. La verificación es suya.*
