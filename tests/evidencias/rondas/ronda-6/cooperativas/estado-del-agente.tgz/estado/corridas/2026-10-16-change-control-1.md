# Corrida del 2026-10-16 · change-control

13 proyectos · 26 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Solicitud PRY-201 +30 días a salida a producción. Impacto de portafolio: 0 alcanzados (sin dependencias declaradas). No se pudo determinar solicitante, motivo, impacto en alcance/costo ni autoridad aprobadora; no se registró línea base nueva.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Sale de la ficha:** `estado/records/PRY-201.json` (actualizada 2026-10-16; último informe de avance 2026-09-28).

## Solicitud de cambio — PRY-201 Apertura de ahorro en línea — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días (2027-01-04 → 2027-02-03).
**Quién lo pide:** no consta en ningún documento de la carpeta ni en la solicitud. No lo inventé.
**Por qué:** no consta. La solicitud no da motivo. Sin motivo no hay solicitud completa.

### Línea base vigente
Una sola: v1, aprobada el 2026-01-07 por el Comité de Tecnología (`10-plan/2026-01-07-cronograma-v1.csv`). Cierre 2027-01-04. No hay replanificaciones previas ni cambios aprobados registrados, así que la desviación contra la original y contra la vigente es hoy la misma.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Tres componentes sin nombre (acta de constitución) | No declarado | Sin impacto declarado |
| Tiempo | Salida a producción 2027-01-04 | 2027-02-03 | +30 días |
| Costo | Aprobado COP 1.200.000.000; comprometido 443.714.282; ejecutado 191.071.658; proyección 1.173.792.669 (informe 2026-09-28) | No declarado | Sin impacto declarado |

**Quién absorbe lo que no se declaró:** 30 días más de equipo de proyecto sin costo declarado significa que alguien lo absorbe. La proyección actual deja solo COP 26.207.331 de holgura sobre lo aprobado (2,2 %). Un mes más de equipo probablemente la supera, pero no puedo cuantificarlo: la ficha no trae costo mensual. Si no se pide presupuesto adicional, el costo lo absorben horas no pagadas o calidad.

**Hito intermedio:** el Piloto con asociados (2026-10-26, a 10 días) queda en el camino del cambio. La solicitud no dice si también se mueve. Tampoco puedo decir cuántos días se mueve, porque eso necesita holgura por actividad y la ficha no la tiene.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`) no encontró proyectos alcanzados, directa ni indirectamente. | — |

Cuidado con leer esto como «sin efecto». La ficha tiene `dependencies: []`: no hay ninguna dependencia declarada. Pero el acta dice que las exclusiones son «lo que otro proyecto cubre», y el riesgo «dependencia del proveedor del core cooperativo» no está enlazado a ningún proyecto. Pueden existir dependencias reales que nadie declaró. Cuántos días se mueve cada afectado, si los hay, no se puede calcular con estos datos.

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo `authority` no se encontró en la ficha: el acta no declara quién aprueba cambios ni con qué umbral.
**Según:** nada. Existe un Comité de Tecnología (aprobó la línea base v1) y un patrocinador, Carlos Peña, pero ninguno tiene límites de autoridad escritos para cambios.
**Va a comité:** sí, por defecto. Sin autoridad declarada no hay base para decir que alguien por debajo del Comité de Tecnología pueda aprobarlo. Que falte la autoridad es el hallazgo de fondo.

### Si no se aprueba
El proyecto sigue con salida el 2027-01-04. Su estado declarado es verde y 74 % de avance (informe 2026-09-28), pero la evidencia no lo sostiene del todo:
- Solo «Diseño funcional aprobado» tiene acta de recibo, y es del 2026-10-07, seis meses después de su fecha de línea base (2026-03-28).
- «Ambiente de pruebas certificado» e «Integración con el core cooperativo» figuran como cerrados sin acta que lo pruebe.
- Hay un hallazgo de seguridad abierto desde 2026-09-28 sin responsable, y dos riesgos sin responsable.
- No hay minutas ni actas de comité en la carpeta.

Esto sugiere que la fecha actual puede estar en riesgo con o sin la solicitud. Es una señal y no una conclusión.

### Si se aprueba (nada se registra: no hay aprobación)
Línea base 2 — cierre 2027-02-03 · presupuesto: no declarado (sigue en COP 1.200.000.000 hasta que alguien diga otra cosa) · motivo: no consta, hay que obtenerlo antes de registrar.
Desviación acumulada contra la línea base original: +30 días · costo sin cambio declarado. Contra la vigente: 0 días hoy. A partir de ahí, todo se reporta contra dos referencias. La v1 no se toca.

### Qué falta para cerrar este paquete
1. Quién pide el cambio y por qué.
2. Si el Piloto del 2026-10-26 se mueve.
3. Impacto en alcance y en costo, aunque sea «ninguno» dicho por alguien responsable.
4. Dónde está escrita la autoridad para aprobar cambios.
5. Si existen dependencias con otros proyectos que no se declararon.

**Siguiente paso:** llevarlo al Comité de Tecnología (próximo comité de la PMO: 2026-10-30) una vez completados los puntos 1 a 4. No registro línea base nueva: nadie la ha aprobado.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de la ficha PRY-201 y de los documentos citados en ella; la verificación es de quien decide. No supe y no inventé: quién pide, el motivo, el impacto en alcance y costo, la autoridad aprobadora, ni cuántos días se mueve el piloto.*
