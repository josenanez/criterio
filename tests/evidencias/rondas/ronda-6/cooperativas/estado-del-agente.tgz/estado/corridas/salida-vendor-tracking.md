## Proveedores — PRY-204 Tarjeta débito para asociados al 2026-10-16

**Sale de:** `00-gobierno/2026-01-03-contrato-ct-467.docx`, `00-gobierno/2026-01-11-contrato-ct-968.md`, `20-seguimiento/2026-10-01-factura-ct-467.pdf`, `20-seguimiento/2026-09-28-factura-ct-968.md`, `30-reuniones/2026-10-06-comite-semanal.md`, `20-seguimiento/2026-10-06-informe-avance.pdf` (declaración del gerente) y la salida de `compute` del 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

### Soluciones Solidarias S.A.S. — contrato CT-467
**Vigencia:** firma 2026-01-03; fin, renovación y preaviso: sin dato (el contrato no los trae) · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2026-04-29 · 584.839.421 | declarado entregado ("recibido" en el propio contrato) | ninguna: sin acta de recibo | 584.839.421 (FV-1467, 2026-10-01; por el total, no desglosada) |
| Bolsa de horas de desarrollo | 2026-08-04 · 584.839.421 | `late` (73 días) | ninguna | — |
| Parametrización de líneas de crédito | 2026-11-08 · 584.839.421 | pendiente | ninguna | — |

### Integración Financiera del Sur — contrato CT-968
**Vigencia:** firma 2026-01-11; fin, renovación y preaviso: sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2026-04-29 · 777.441.999 | declarado entregado ("recibido" en el contrato) | ninguna: sin acta de recibo | 929.615.834 (FV-2968, 2026-09-28; un solo valor para "entregables del contrato") |
| Bolsa de horas de desarrollo | 2026-08-04 · 777.441.999 | `late` (73 días) | ninguna | — |
| Parametrización de líneas de crédito | 2026-11-08 · 777.441.999 | pendiente | ninguna | — |

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-968: facturado vs. aceptado | Se factura cada entregable contra acta de recibo firmada; el único marcado "recibido" vale 777.441.999 | FV-2968 cobra 929.615.834: **152.173.835 por encima** de lo aceptado (señal `vendor_invoiced_over_accepted`) | contrato CT-968; factura 2026-09-28 |
| CT-467: factura sin acta | Misma condición de pago | FV-1467 cobra 584.839.421, igual al monto del único entregable "recibido", pero no hay acta que lo sustente | contrato CT-467; factura 2026-10-01 |
| Estado declarado vs. evidencia | El informe de avance del 2026-10-06 declara **verde** | Quedan abiertas 4 señales: hitos cumplidos sin evidencia, desviación de costo, entregables vencidos del proveedor y facturación sobre lo aceptado | informe de avance 2026-10-06; `compute` |

Costo: proyección 7.559.606.133 COP contra 6.800.000.000 aprobados, **11,2 %** por encima del umbral de 10 % (comprometido 3.543.460.884; ejecutado 2.023.984.664).

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del módulo (CT-467) | delivered | fecha comprometida 2026-04-29; la fecha de marcado no consta |
| Licenciamiento del módulo (CT-968) | delivered | fecha comprometida 2026-04-29; la fecha de marcado no consta |

Además, "Bolsa de horas de desarrollo" venció el 2026-08-04 en ambos contratos (73 días), sin evidencia y sin declarar entrega.

### Compromisos del proveedor vencidos
Ninguno vencido. Hay uno abierto: Andrés Lozano, "Entregar el punto 35", prometido en el comité del 2026-10-06 para el 2026-10-21 (faltan 5 días). El acta no dice a qué proveedor pertenece Lozano ni qué es el "punto 35".

### Sin dato
- Fecha de terminación, renovación automática y preaviso de ambos contratos: no aparecen en los documentos, así que no puedo decir si hay un preaviso por vencer.
- Actas de recibo o correos de aceptación de cualquier entregable: no hay ninguno en la carpeta.
- Desglose de las facturas: ambas se refieren a "entregables del contrato" sin decir cuáles.
- Los dos contratos listan los mismos tres entregables con las mismas fechas; no puedo decir si es un solo alcance dividido o un solapamiento (queda para quien conozca el contrato).

### Después
Hay entregables facturados sin evidencia de aceptación, y una factura por encima de lo aceptado: lo llevaría a comité (próximo, 2026-10-30) antes de aprobar el pago de FV-2968.

*Pie de rigor: cifras tomadas de la salida de `compute` y de los documentos citados; no se leyó nada fuera de la carpeta PRY-204; la verificación final es de quien lo lea. Criterio produce borradores, no decisiones.*
