# Corrida del 2026-10-16 · project-history

13 proyectos · 51 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Historia de PRY-208 sobre 8 documentos (2026-01-17 a 2026-10-15). 1 replanificación, 161 días (48,3 %) sin autorización. No pudo fijar desde cuándo lo declarado no se sostiene (una sola declaración), ni el motivo del corrimiento, ni qué ocurrió entre enero y octubre (sin documentos en T2 y T3).

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Historia · PRY-208 Motor de crédito · 2026-01-17 a 2026-10-15

**Leí:** 8 documentos entre 2026-01-17 y 2026-10-15 (el acta de recibo en PDF la leí por su texto extraído; la ficha no guarda hash de texto para ella)
**Trimestres sin un solo documento:** 2026-T2 (abr–jun) y 2026-T3 (jul–sep). Los 8 documentos están en T1 (2) y T4 (6): nada escrito en los seis meses intermedios.

### En una línea
El proyecto se aprobó el 2026-01-17 con cierre el 2026-12-26 y no deja documentos hasta el 2026-10-09. En esa semana aparecen dos solicitudes de cambio de alcance sin decidir (CC-01 y CC-02, 2026-10-09 y 2026-10-10), un cronograma v3 (2026-10-13) que mueve el piloto al 2027-06-05, y un informe de avance (2026-10-13) que declara Verde con 67 % sin mencionar ninguna de las dos cosas. Un día después del informe, el comité del 2026-10-15 solo tiene un compromiso, ya vencido desde el 2026-10-12.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 161 días (48,3 %) | No calculable: hay una sola declaración (2026-10-13) | 0 detectados |

La última columna significa "no detectados", no "no hubo": en la carpeta hay un solo documento de gobierno (el acta de constitución) y nada entre enero y octubre con que compararlo.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-01-17 | `00-gobierno/2026-01-17-acta-constitucion.docx` | Aprobación por el Comité de Educación: 18.000.000.000 COP, inicio 2026-01-27, cierre 2026-12-26. Patrocinadora Sandra Gil, gerente Rubén Cárdenas. Alcance: "Componente 1, 2 y 3" sin nombre. Dependencias: "Ninguna declarada". |
| 2026-01-17 | `10-plan/2026-01-17-cronograma-v1.xlsx` | Línea base original: cuatro hitos, piloto el 2026-12-26. (Ver nota 1 sobre su estado.) |
| 2026-04-20 | — (sin documento) | Fecha del hito "Diseño funcional aprobado". Ningún documento lo sustenta. |
| 2026-07-12 | — (sin documento) | Fecha del hito "Ambiente de pruebas certificado". Ningún documento lo sustenta. |
| 2026-10-04 | — (sin documento en esa fecha) | Fecha del hito "Integración con el core cooperativo". El acta de recibo es del 2026-10-15. |
| 2026-10-09 | `20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md` | CC-01, ampliación de alcance: +46 días sobre la línea base vigente, +92.000.000 COP. Pendiente de presentación al comité. |
| 2026-10-10 | `20-seguimiento/2026-10-10-solicitud-cambio-cc-02.md` | CC-02, ampliación de alcance: +115 días sobre la línea base vigente, +230.000.000 COP. Pendiente de presentación al comité. |
| 2026-10-13 | `10-plan/2026-10-13-cronograma-v3.xlsx` | Cronograma v3: el piloto pasa del 2026-12-26 al 2027-06-05. No hay v2 en la carpeta. |
| 2026-10-13 | `20-seguimiento/2026-10-13-informe-avance.md` | Declara Verde, 67 %. Cuenta que se perdieron dos semanas por rotación de un desarrollador clave; riesgo abierto: concentración del conocimiento en una persona. Ejecutado 9.306.995.922 COP contra comprometido 8.150.332.447 COP. No menciona CC-01, CC-02 ni el cronograma v3. |
| 2026-10-15 | `20-seguimiento/2026-10-15-acta-recibo-integración-con-el-core-cooperativo.pdf` | Recibo a satisfacción de la integración con el core, firmado por Rubén Cárdenas. Es la única acta de recibo de la carpeta. |
| 2026-10-15 | `30-reuniones/2026-10-15-comite-semanal.md` | Comité de Educación (Rubén Cárdenas, Sandra Gil). Temas: avance y compromisos. Un compromiso: Laura Vélez, "Entregar el punto 16", para el 2026-10-12. No registra decisión sobre CC-01, CC-02 ni el cronograma v3. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 (cronograma v3) | 2026-10-13 | 2027-06-05 (original: 2026-12-26) | Sin motivo documentado | Ninguno. CC-01 y CC-02 siguen pendientes, y el acta del comité del 2026-10-15 no registra decisión |

Atraso acumulado contra la línea base original: 161 días (48,3 %). Contra la vigente (v3): 0 días, porque la v3 ya incorpora el corrimiento. Autorizado por cambio aprobado: 0 días; sin autorización: 161 días.

Dato que se puede verificar: CC-01 (+46) más CC-02 (+115) suman 161 días, exactamente lo que se movió el piloto. Que los números coincidan indica que la v3 incorpora ambas solicitudes; ningún documento lo dice, y ninguna de las dos está aprobada.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios detectados. Patrocinadora y gerente aparecen solo en el acta de 2026-01-17 y siguen siendo los mismos en el comité del 2026-10-15. | — |

Un hallazgo menor, sin interpretar: el comité que aprueba y revisa este proyecto es el "Comité de Educación", y el área dueña es Canales digitales. Está así en el acta y en el comité de octubre.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repite: solo hay un comité en la carpeta | — | — |

Compromiso abierto, no repetido: Laura Vélez, "Entregar el punto 16", para el 2026-10-12. Se registró el 2026-10-15, tres días después de su fecha, y ningún documento lo da por cumplido (4 días vencido al 2026-10-16). El acta no dice qué es el "punto 16".

### Desde cuándo lo declarado no se sostiene
- **Fecha:** no se puede fijar con la evidencia que hay. Solo existe una declaración (Verde, 67 %, corte 2026-10-13), así que no hay serie donde buscar un deslizamiento ni un "meses declarando".
- **Primer hito sin evidencia:** "Diseño funcional aprobado", fecha 2026-04-20 (179 días al 2026-10-16), marcado como cerrado sin acta ni documento. Le sigue "Ambiente de pruebas certificado", 2026-07-12 (96 días), en la misma situación.
- **Qué se reportó:** Verde y 67 % el 2026-10-13, cuando ya había una replanificación de 161 días sin autorizar, dos solicitudes de cambio pendientes y un compromiso vencido. De los cuatro hitos, tres figuran cerrados; solo uno tiene acta de recibo, y esa acta es posterior al informe. El plan, con tres de cuatro hitos cerrados, sustenta entre 75 % y 100 %; se declara 67 %, 8 puntos por debajo del rango, lo que va en contra de inflar el avance.
- **Qué no se puede decir:** si el diseño y el ambiente de pruebas se cerraron de verdad. Falta el documento, no se prueba que no ocurrieran.

### Lecciones ancladas a un hecho
1. **Hecho:** el cronograma v3 (2026-10-13) mueve el piloto 161 días y no hay v2 ni cambio aprobado. **Efecto:** la línea base vigente se movió sin autorización y el atraso contra la original (161 días, 48,3 %) solo se ve comparando v1 con v3.
2. **Hecho:** dos hitos cerrados (2026-04-20 y 2026-07-12) sin acta, y un tercero con acta del 2026-10-15 contra fecha del 2026-10-04. **Efecto:** de cuatro hitos, solo uno se puede sustentar, y con un acta posterior a su fecha.
3. **Hecho:** ningún documento entre 2026-01-17 y 2026-10-09. **Efecto:** el período en que se acumuló el atraso no se puede reconstruir, y esta historia no puede decir cuándo empezó.
4. **Hecho:** el informe del 2026-10-13 omite CC-01, CC-02 y el cronograma v3, emitidos el 2026-10-09, 2026-10-10 y el mismo 2026-10-13. **Efecto:** el estado Verde se declaró sin reflejar la replanificación en curso.

### Notas sobre los datos
1. La v1 está fechada 2026-01-17 pero muestra los tres primeros hitos como "cerrado", con fechas de abril, julio y octubre. Un cronograma aprobado en enero no puede traer hitos de octubre cerrados: o el archivo se editó después de su fecha, o el estado se refiere a otro momento. La fecha que cuenta es la del nombre del archivo; el contenido apunta a una edición posterior.
2. El ejecutado (9.306.995.922 COP) supera lo comprometido (8.150.332.447 COP) en el mismo informe. Ejecutado: 51,7 % del aprobado; comprometido: 45,3 %; la proyección al cierre (17.185.557.889 COP) queda 4,5 % por debajo del aprobado. El informe no dice si la proyección incluye el costo de CC-01 y CC-02, pendientes.
3. Falta en la ficha: producto, autoridad y fase del proyecto.

### Qué no sé
- Por qué se movió el piloto y quién decidió hacerlo.
- Qué se hizo y qué pasó de enero a octubre.
- Si los hitos sin acta se cumplieron.
- Qué es el "punto 16".

Esto reconstruye lo que dicen los documentos; no dice por qué ocurrió ni atribuye intención. Que el atraso no se viera antes no indica que alguien lo ocultara: sirve para tener esa conversación con datos.

**Siguiente paso posible:** llevar esta historia al comité del 2026-10-30, donde CC-01, CC-02 y la v3 necesitan decisión, o al cierre del proyecto cuando corresponda. Dime cuál prefieres.

*Pie de rigor: borrador de trabajo de Criterio, no una decisión ni una asesoría. Cada dato viene del documento citado; la verificación es de quien lo usa. Cifras copiadas de `portafolio.py compute` (as_of 2026-10-16).*
