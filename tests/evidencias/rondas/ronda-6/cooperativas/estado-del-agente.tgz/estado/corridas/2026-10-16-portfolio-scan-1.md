# Corrida del 2026-10-16 · portfolio-scan

13 proyectos · 76 documentos, 0 releídos y 76 sin cambio · 271 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Leídos 45 de 76 documentos (10 proyectos nuevos, un lote, sin subagentes); 31 sin cambio. No existe entrada/: nada movido. Sin archivos ilegibles. Mirar: contradicción cronograma vs informe en PRY-211; 14 hitos cerrados sin acta en 7 proyectos; cierres vencidos en PRY-200, 202, 203 y 211; factura FV-2968 de PRY-204 por encima de lo recibido; compromiso vencido en PRY-205 y sin fecha en PRY-206; citas de PRY-210 escritas sin la carpeta del proyecto (no se tocó esa ficha).

Contra la corrida del 2026-10-16: +29 hallazgos.

## Lo que produjo

## Barrido — 2026-10-16

Antes de empezar: la configuración existe y los términos de la v0.3.12 están vigentes (aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que registrarlos de nuevo.

**Documentos:** 76 en la carpeta · 45 leídos · 31 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 actualizados · 3 sin tocar (PRY-207, PRY-208 y PRY-210, sin cambios) · 0 sin carpeta propia

Formatos: 39 .md, 12 .docx, 11 .pdf, 7 .xlsx, 5 .csv, 1 .txt, 1 .json. Los Word, Excel y PDF se leyeron por su texto convertido; cada cita apunta al documento original. El plan era de un solo lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes. No quedó nada diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, declarado, plan, 5 hitos, presupuesto, 1 contrato (3 entregables), 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase, lo facturado a CT-199 |
| PRY-200 Crédito de libranza digital | 2 | identidad, declarado, plan (sin hitos), presupuesto, 1 riesgo, 2 incidencias | autoridad, fase |
| PRY-201 Apertura de ahorro en línea | 4 | identidad, declarado, plan, 5 hitos, presupuesto, 2 riesgos, 1 incidencia | autoridad, fase |
| PRY-202 Core cooperativo | 5 | identidad, declarado, plan, 4 hitos, presupuesto, 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-203 Aportes sociales en línea | 2 | identidad, declarado, plan (sin hitos), presupuesto, 2 riesgos, 2 incidencias | autoridad, fase |
| PRY-204 Tarjeta débito para asociados | 8 | identidad, declarado, plan, 5 hitos, presupuesto, 2 contratos (6 entregables), 2 facturas, 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 4 | identidad, declarado, plan, 4 hitos, presupuesto, 2 riesgos, 1 compromiso | autoridad, fase, producto («No aplica») |
| PRY-206 Pagos con QR | 4 | identidad, declarado (rojo), plan, 4 hitos, presupuesto, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase |
| PRY-209 Convenios de libranza con empresas | 5 | identidad, declarado, plan, 4 hitos, presupuesto, 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase, producto («No aplica») |
| PRY-211 Cobranza digital | 5 | identidad, declarado (amarillo), plan, 5 hitos, presupuesto, 1 riesgo, 1 incidencia | autoridad, fase |

En los diez, `autoridad` y `fase` no aparecen en ningún documento. Es un vacío de información, no un error de lectura.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: los diez proyectos leídos no tenían ficha previa. | — |

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Todos los archivos se pudieron leer. | 

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No existe la carpeta `entrada/` bajo `documentos/proyectos`; no hay nada que mover. | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

## Lo que hay que mirar

Hechos tal como los dicen los documentos; ninguno es un juicio sobre las personas, y casi todos tienen una explicación que la carpeta no ve.

**Contradicción entre documentos (se reporta sin umbral)**
- **PRY-211:** el cronograma declara cerrados los cinco hitos, incluidos el piloto (2026-03-11) y la salida a producción (2026-05-12). El informe del 2026-10-12 reporta 48 % de avance, estado amarillo, y habla de ajustar el reglamento «antes del piloto». Se guardaron las dos lecturas sin elegir.

**Hitos declarados cerrados sin acta de recibo que los pruebe:** 14 en 7 proyectos (PRY-201: 2, PRY-202: 2, PRY-204: 3, PRY-205: 1, PRY-206: 2, PRY-209: 1, PRY-211: 3). Las actas que sí existen llegan meses después de la fecha de línea base (por ejemplo, PRY-211: diseño funcional con acta del 2026-10-14 frente a una fecha de 2025-09-08).

**Fechas de cierre ya vencidas** (a 2026-10-16), con el proyecto aún en curso y sin cronograma posterior a v1:
- PRY-200: cierre 2026-08-13, declarado verde al 42 %.
- PRY-202: cierre y piloto 2026-10-09, el piloto sigue «en curso».
- PRY-203: cierre 2026-07-25, declarado amarillo al 36 %.
- PRY-211: cierre 2026-05-12 (ver la contradicción de arriba).

**Reprogramaciones sin documento:** los informes de PRY-199, PRY-202 y PRY-209 dicen «se reprogramó la salida», pero no hay cronograma posterior ni acta de comité que mueva las fechas.

**Proveedores y facturas (PRY-204)**
- Hay dos contratos (CT-467 y CT-968) con la condición «cada entregable se factura contra acta de recibo firmada por el gerente»; no hay ninguna acta de recibo en la carpeta.
- La factura FV-2968 (929.615.834 COP) supera el valor de lo único que el contrato CT-968 declara recibido (777.441.999 COP).
- La «Bolsa de horas» venció el 2026-08-04 en ambos contratos y nadie dice que se entregó.
- PRY-199 tiene contrato CT-199 con tres entregables pendientes y ninguna factura en la carpeta.

**Compromisos**
- PRY-205: el compromiso de Diana Molina (punto 39) tiene fecha 2026-09-30, anterior a la reunión que lo registra (2026-10-08); sin evidencia de cumplimiento, queda vencido.
- PRY-206: el compromiso de Camilo Beltrán (punto 14) dice «por definir»: nadie lo fechó.
- Las personas con compromiso en PRY-199, PRY-202, PRY-204, PRY-205 y PRY-206 no figuran entre los asistentes de la reunión que las nombra.

**Gobierno:** en PRY-202 y PRY-204 patrocinador y gerente son la misma persona, y la minuta lista dos veces a esa persona como único asistente.

**Cifras que no cuadran dentro de un mismo informe:** ejecutado mayor que comprometido en PRY-203 (441.454.741 frente a 336.456.745) y en PRY-205 (435.202.817 frente a 245.154.532). En PRY-199 el comprometido del informe (1.080.000.000) no coincide con los 432.000.000 de entregables del contrato CT-199.

**PRY-210 (no se leyó; sus documentos no cambiaron):** el índice marca como «cita que no resuelve» las fuentes de su ficha porque están escritas sin la carpeta del proyecto (por ejemplo `00-gobierno/2026-06-14-acta-constitucion.md`, que debería llevar `PRY-210-corresponsales-rurales/` delante). Los archivos están en disco. No toqué esa ficha; conviene corregir las rutas en la próxima pasada.

## Después

Con más de un proyecto con ficha, el siguiente paso es el informe consolidado: `/criterio-portfolio:portfolio-report`. Ahí se calculan las desviaciones, los semáforos y las señales, que este barrido no calcula.

---
*Criterio PMO · criterio-portfolio v0.3.12 · Fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 205, 206, 209, 211) · Campos en `not_found`: autoridad y fase en los 10; producto en PRY-202, 205 y 209; lo facturado a CT-199 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12*
