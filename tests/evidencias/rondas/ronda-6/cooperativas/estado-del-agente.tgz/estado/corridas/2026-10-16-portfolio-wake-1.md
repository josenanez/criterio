# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 24 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Barrido: 76 documentos sin cambios, nada que releer. Citas de PRY-210 sin resolver por posible desajuste de nombre de carpeta, sin verificar. Confirmación mensual no preguntada: nadie para responder.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## 2026-10-16

**Revisé:** 76 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada. El barrido corrió sin documentos nuevos, cambiados, renombrados ni borrados, así que no se releyó nada ni se recalculó ningún proyecto.

**Hallazgo del índice (sin resolver):** PRY-210 (corresponsales rurales) tiene unas 130 citas que el índice marca como `source_missing` (identidad, estado declarado, plan, dinero y compromisos 0–25). Los documentos citados sí existen en `documentos/proyectos/PRY-210-corresponsales-rurales/`. El índice los busca en una carpeta llamada solo `PRY-210`, que no existe. Parece un desajuste entre el nombre de la carpeta y la ruta que usa la ficha, y no documentos borrados. No lo verifiqué ni lo corregí, y no escribí en la ficha. Lo dejo para que alguien lo revise antes del informe de comité.

### Peticiones atendidas
Ninguna. No había peticiones pendientes en el servidor.

### Preguntas
La confirmación mensual toca (primera vez, cinco campos), pero esta sesión no tiene a nadie que responda. No hice preguntas y no la di por corrida; vuelve a tocar mañana.

**Vuelvo el 2026-10-17.** El informe de comité es el 2026-10-30 y se prepara el 2026-10-28.
