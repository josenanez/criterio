# Corrida del 2026-10-16 · status-report

13 proyectos · 21 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Informe de PRY-202: verde declarado contradicho por piloto vencido y 2 hitos sin acta; sin replanificación formal; no sabe producto, autoridad ni fase.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-202.json` (actualizada el 2026-10-16), con cifras de `portafolio.py compute` al 2026-10-16. Configuración: `.criterio/portafolio/config.json` (v0.1). Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-16.

## PRY-202 Core cooperativo — estado al 2026-10-16

**Declara el gerente:** verde · 73% · al 2026-10-09 (Natalia Ospina; informe de hace 7 días, vigente)
**Sustento documental:** contradicho en parte (alerta `declared_vs_evidence`)
**Lo que el semáforo no explica:** `milestone_overdue` (Piloto con asociados, 7 días vencido) y `milestone_met_without_evidence` (2 hitos dados por cumplidos sin acta)
**Último documento:** 2026-10-09 (hace 7 días) · **Última reunión:** 2026-10-05 (comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-09 | 2026-10-09 | 0 días (pero la fecha ya pasó y el cierre sigue en curso) |
| Presupuesto (COP) | 18.000.000.000 aprobado | proyección 18.103.235.355 | +0,6 % (bajo el umbral del 10 %) |

Presupuesto: comprometido 14.468.329.305 (80,4 %), ejecutado 8.652.317.770 (48,1 %), disponible real 3.531.670.695.
Avance declarado 73 % frente a 75–100 % que sostiene el plan (3 de 4 hitos; diferencia 2,0 puntos).

Replanificaciones: 0 registradas. El informe del 2026-10-09 dice «se reprogramó la salida», pero no hay cronograma posterior ni acta que lo respalde; el cronograma sigue en v1.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-03-08 | 2026-03-08 | cumplido (declarado) | ninguna — 222 días sin acta |
| Ambiente de pruebas certificado | 2026-05-19 | 2026-05-19 | cumplido (declarado) | ninguna — 150 días sin acta |
| Integración con el core cooperativo | 2026-07-29 | 2026-07-29 | cumplido | acta de recibo del 2026-10-05 (más de dos meses después de su fecha) |
| Piloto con asociados | 2026-10-09 | 2026-10-09 | pendiente, vencido 7 días | ninguna |

### Dónde no coincide
- **Verde (informe 2026-10-09) frente a hito vencido:** el mismo día del informe vencía el Piloto con asociados y el cierre del proyecto; a 2026-10-16 siguen en curso. Fuente: informe de avance 2026-10-09 y cronograma v1 (2025-12-17).
- **Hitos cumplidos sin acta:** Diseño funcional y Ambiente de pruebas figuran como cumplidos en el cronograma, sin documento de recibo.
- **Reprogramación sin soporte:** el informe habla de reprogramar la salida; ningún documento la formaliza.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (sin responsable; informe 2026-10-09).
- Incidencia: hallazgo de seguridad de la revisión de arquitectura, abierta desde 2026-10-09 (sin responsable).
**Compromisos vencidos:** ninguno. Hay uno abierto: Jorge Medina, «Entregar el punto 13», vence 2026-10-19; no figura entre los asistentes de la minuta.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
Producto asociado (el acta dice «No aplica»), autoridad de aprobación y fase del proyecto. Además: patrocinador y gerente son la misma persona (Natalia Ospina), y el comité no incluye a nadie distinto de quien gerencia. Ninguna fuente del proyecto está marcada como evidencia (0 de 22); 2 son declaración y 20 sin marcar.

### Siguiente paso
La fecha de cierre se cumplió sin cierre y sin replanificación formal. Puedo preparar el punto de comité (próximo: 2026-10-30) y, si la salida se reprogramó de verdad, la solicitud de cambio.

---
Pie: criterio-portfolio 0.3.12 · ficha PRY-202 aplicada, actualizada el 2026-10-16 · campos inciertos: producto, autoridad, fase · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
