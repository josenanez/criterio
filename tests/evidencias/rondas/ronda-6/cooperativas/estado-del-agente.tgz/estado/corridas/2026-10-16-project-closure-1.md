# Corrida del 2026-10-16 · project-closure

13 proyectos · 34 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Cierre de PRY-200 sin sustento: criterio de éxito declarado (producción y medido) sin evidencia, 42% declarado, cierre del acta vencido, sin cronograma ni actas. Dijo que no sabe: autoridad, hitos, componentes, dolientes del RAID. No archivó.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Cierre de PRY-200 — sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-16) y de dos documentos: `00-gobierno/2025-12-23-acta-constitucion.docx` y `20-seguimiento/2026-10-12-informe-avance.pdf`. Cifras derivadas copiadas de `portafolio.py compute` (corte 2026-10-16).**

## Cierre — Crédito de libranza digital (PRY-200) — 2026-10-16

> **Advertencia de entrada:** la documentación no sustenta que el proyecto haya terminado. El informe del 2026-10-12 declara 42 % de avance, con una prueba de carga fallida que se repite y un ajuste de reglamento pendiente antes del piloto. Lo que sigue es el contraste contra lo comprometido, no un acta de cierre por cumplimiento. Si la PMO cierra, cierra por decisión, y esa decisión no está en la carpeta.

### Contra lo comprometido
**Criterio de éxito:** "Crédito de libranza digital en producción y medido." (acta de constitución, 2025-12-23, sección *Criterio de éxito*).
**Se cumplió:** **No se puede determinar que se cumpla; la evidencia disponible apunta a que no.** No hay documento que muestre producción ni medición. El informe de avance habla de prueba de carga no superada y piloto aún por hacer.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin nombre en el acta; no se puede contrastar | Acta: alcance lista "Componente 1, 2 y 3" sin describirlos |
| Componente 2 | Ídem | Ídem |
| Componente 3 | Ídem | Ídem |
| Producción y medición (criterio de éxito) | Sin evidencia | Ningún documento lo registra |

No hay cronograma ni hitos en la carpeta (`milestones` vacío), así que no hay forma de decir qué se entregó por entregable.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta; no nombra cuál proyecto) | Acta de constitución | 2025-12-23 |

No hay recorte de alcance posterior documentado. Tampoco hay minutas ni actas de comité en la carpeta que lo permitan registrar.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-13 | 2026-08-13 | Sin cierre real (proyecto no terminado) | 0 días según `compute`, **no porque se cumpliera sino porque no hay fecha final contra la cual medir** |
| Presupuesto aprobado (COP) | 6.800.000.000 | 6.800.000.000 | Proyección al cierre: 6.511.899.586 | −4,2 % (proyección sobre aprobado) |

- Comprometido: 6.037.085.557 COP (88,8 % del aprobado).
- Ejecutado: 2.337.646.171 COP (34,4 % del aprobado).
- Disponible real: 762.914.443 COP.
- Replanificaciones: **0**. La línea base tiene una sola versión (2025-12-23). No hay cambios registrados.
- La fecha de cierre del acta (2026-08-13) ya pasó a la fecha de corte, y el informe del 2026-10-12 sigue declarando **verde**. Esa contradicción no está explicada en ningún documento. No se registra ninguna replanificación que la justifique.

### RAID al cierre
**Materializados:**
- Prueba de carga que no alcanzó el umbral pactado y se repite (informe 2026-10-12). Sin doliente.
- El Consejo de Administración pidió ajustar el reglamento antes del piloto (informe 2026-10-12). Sin doliente.

**No materializados:** ninguno que se pueda afirmar. El riesgo "cambio normativo del supervisor que puede mover el alcance" sigue abierto y sin doliente.

**Abiertos, con doliente:** **ninguno tiene doliente con nombre**. Los tres puntos anteriores quedan abiertos y, según el principio del cierre, sin doliente no están cerrados. Jorge Medina (patrocinador) y Sandra Gil (gerente) son los nombres del acta, pero ningún documento les asigna estos puntos, y no se los asigno yo.

### Lecciones
No hay lecciones que se puedan sustentar todavía: el proyecto no ha terminado y no hay historial de comité ni cronograma de donde anclar un hecho con fecha y efecto. Dos observaciones sí están ancladas, y quedan como hallazgos, no como lecciones:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta aprobó alcance como "Componente 1, 2 y 3" sin nombrarlos y excluyó "lo que otro proyecto cubre" sin decir cuál | 2025-12-23 | Hoy no se puede contrastar entregado contra comprometido | Pendiente de decidir por la PMO; no se infiere de los documentos |
| El informe del 2026-10-12 sigue en verde con el cierre del acta ya vencido | 2026-10-12 | El estado declarado no tiene sustento en documentos | Pendiente de decidir por la PMO |

### Sin dato
- Autoridad que aprueba el cierre y fase del proyecto (campos `identity.authority` e `identity.phase` no encontrados).
- Cronograma, hitos y su cumplimiento.
- Qué son los componentes 1, 2 y 3.
- Qué proyecto cubre lo excluido.
- Evidencia de producción y medición.
- Minutas o actas de comité; cualquier decisión de mover fecha o presupuesto.
- Por qué el informe cita al Consejo de Administración si el acta asigna el proyecto al Comité de Tecnología.
- Dolientes de los dos asuntos abiertos y del riesgo.
- Cuenta de días de atraso: `compute` no la da sin fecha final real, y no la calculo a mano.

### Archivo
No muevo la carpeta a `archivo/` ni congelo la ficha: no hay un cierre declarado ni sustentado. Si la PMO decide cerrar por decisión, ese es el momento de archivarlo.

*Pie de rigor: borrador de trabajo basado solo en los dos documentos citados; no sabe lo que se habló fuera de ellos. Verifique cada cita antes de usarlo.*
