# Corrida del 2026-10-16 · product-view

13 proyectos · 21 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Producto de un solo proyecto (PRY-203), sin alertas; se reportó fecha de fin vencida sin señal, datos sin evidencia y 5 proyectos sin producto. No se supo el área dueña de esos 5.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Producto: aportes sociales — al 2026-10-16

Sale de las fichas del estado y del cálculo `portafolio.py compute` del 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

**«Aportes sociales» tiene un solo proyecto: PRY-203 Aportes sociales en línea.** La vista por producto no aporta aquí más que la ficha del proyecto, así que no armo sección de producto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| aportes sociales | 1 (PRY-203) | 0 | 2026-07-25 | COP 800.000.000 | COP 336.456.745 |

- **Señales del cálculo:** ninguna alerta. Sin atraso contra la línea base (0 días contra la original y contra la vigente), 0 replanificaciones, 2 días de silencio, sin compromisos vencidos, sin proveedores, sin cambios de control.
- **Dinero (las cuatro cifras vienen):** aprobado 800.000.000; comprometido 336.456.745 (42,1 %); ejecutado 441.454.741 (55,2 %); proyección 767.281.484 (−4,1 % sobre lo aprobado); disponible real 463.543.255.
- **Declarado por el gerente:** amarillo, 36,0 % de avance, al 2026-10-14 (`PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-14-informe-avance.md`).
- **Dependencias internas:** ninguna declarada, y no hay otro proyecto del producto con el cual cruzarlas.

## Lo que no cuadra y el cálculo no marca
- La fecha de fin vigente del proyecto es 2026-07-25, ya pasada hace casi tres meses, y el avance declarado es 36 %. El cálculo no emitió señal de hito vencido ni de atraso; no puedo decir por qué sin leer el plan, y no invento una cifra de atraso. Conviene que el gerente confirme si esa fecha sigue vigente.
- Ninguno de los datos de la ficha tiene fuente de evidencia: 0 de evidencia, 2 de declaración, 17 sin marcar. Los campos de identidad y plan vienen de un documento de 2025-05-15 (17 meses, sobre el umbral de 12).
- Faltan `identity.authority` (quién aprueba) y `identity.phase`.

## Proyectos sin producto declarado
No entraron a ninguna vista de producto: nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | no consta en el cálculo |
| PRY-205 Prevención de lavado de activos | no consta en el cálculo |
| PRY-208 Motor de crédito | no consta en el cálculo |
| PRY-209 Convenios de libranza con empresas | no consta en el cálculo |
| PRY-210 Corresponsales rurales | no consta en el cálculo |

Además, PRY-199 declara el producto «PRD-299», un código y no un nombre de producto como los demás; vale confirmarlo.

## Pie de rigor
Cifras copiadas de `compute` (as_of 2026-10-16). No sé: el área dueña de los cinco proyectos sin producto (el cálculo no la entrega), por qué PRY-203 no marca atraso con fecha de fin vencida, ni nada de lo hablado fuera de los documentos. La verificación de cada dato es de quien lo use; cada uno remite a su documento fuente.
