## Diagnóstico · PRY-207 Microcrédito rural · 2026-10-16

**Leí:** 5 documentos completos · del 2025-10-24 al 2026-10-16 · formatos: md, xlsx, pdf, docx
- PRY-207: acta de constitución (2025-10-24), cronograma v1 (2025-10-24), comité semanal (2026-10-13), informe de avance (2026-10-16).
- Otras carpetas: comité de producto de PRD-305 Microcrédito (2026-10-05). No nombra a PRY-207; lo leí entero porque el acta asocia el proyecto al producto «microcrédito».

**No pude leer / no leí:** en PRD-305, la definición de producto y el caso de negocio solo coinciden por la palabra «microcrédito», y no los leí enteros. Tampoco abrí las entrevistas (.docx) de esa carpeta, porque no pude comprobar por búsqueda de texto si nombran el proyecto. No hay ninguna otra minuta que mencione PRY-207. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 8 · **Contradicho:** 3

La carpeta sostiene quién es quién (patrocinador, gerente, comité) y el presupuesto aprobado. Todo lo demás viene de quien reporta. El «Verde» y el «61%» del informe los contradice el propio cronograma del proyecto, que da los tres hitos por cerrados, y la fecha de cierre del acta (2026-05-10) lleva 159 días vencida sin replanificación registrada. Los tres hitos «cerrados» y las cifras de dinero (comprometido, ejecutado, proyección) no tienen un solo documento de evidencia en la carpeta. De esta carpeta se puede afirmar quién gobierna el proyecto y cuánto se aprobó. No se puede afirmar en qué estado está ni cuánto se ha gastado.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Mauricio Pérez | acta 2025-10-24; asiste al comité 2026-10-13 |
| Gerente | Carlos Peña | acta 2025-10-24; informe 2026-10-16; comité 2026-10-13 |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente (fechas, presupuesto, cambios). | acta 2025-10-24 |
| Comité | Comité de Tecnología; aprobó el presupuesto el 2025-10-24 | acta 2025-10-24 |

Sin autoridad declarada no hay desviación aprobada: lo que existe son fechas que alguien escribió. El acta tampoco trae alcance verificable («Componente 1, 2, 3»), exclusiones concretas («lo que otro proyecto cubre») ni criterio de éxito medible («en producción y medido»). Tampoco hay un documento de control de cambios.

### Contra el plan
- **Línea base:** existe, en el cronograma v1 del 2025-10-24. Tiene tres hitos; en los tres, fecha de línea base y fecha vigente son iguales.
- **Replanificaciones:** 0. Desviación contra la original: 0 días. Contra la vigente: 0 días.
- **Cierre comprometido en el acta:** 2026-05-10. El proyecto sigue reportando avance al 2026-10-16 (61%), sin replanificación ni cambio aprobado que lo explique. El cierre de la línea base y la fecha de hoy no cuadran y nadie lo registró.
- **Avance:** el informe declara 61%. El cronograma tiene 3 de 3 hitos cerrados, de modo que el plan sostiene 100%. Brecha: 39,0 puntos, el informe por debajo del plan.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado (estado: cerrado) | 2026-01-04 | 285 | Documento de diseño funcional con aprobación firmada o acta de aprobación |
| Ambiente de pruebas certificado (estado: cerrado) | 2026-03-08 | 222 | Certificado o acta de certificación del ambiente de pruebas |
| Integración con el core cooperativo (estado: cerrado) | 2026-05-10 | 159 | Acta de pruebas de integración o aceptación del proveedor del core |

Los tres están «cerrados» solo por lo que dice el cronograma. Evidencia en la carpeta: 0 documentos.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 COP | 2.615.128.347 COP (79,2%) | 1.059.251.553 COP (32,1%) | 3.339.268.621 COP (1,2% sobre lo aprobado) | 684.871.653 COP |

Solo el aprobado está respaldado por un documento (el acta). Comprometido, ejecutado y proyección salen únicamente del informe de avance; no hay ni un contrato, orden de compra ni extracto de ejecución. Dato para el comité: el informe reporta 61% de avance y la ejecución es 32,1% del aprobado. El informe no explica esa distancia.

### Lo que se dijo y nadie registró
- **Compromiso, comité 2026-10-13:** Carlos Peña, «Entregar el punto 11», para 2026-11-01. Ningún documento define qué es el «punto 11». Como no se sabe qué debe entregarse, no se podrá comprobar su cumplimiento. No está vencido hoy.
- **Minuta sin contenido:** el comité del 2026-10-13 lista «Avance» y «Compromisos» como temas, sin decisiones, sin estado, sin mención de la fecha de cierre vencida. Asisten dos personas.
- **Riesgos (solo en el informe, no en un registro):** (1) cambio normativo del supervisor que puede mover el alcance; (2) dependencia del proveedor del core cooperativo. No hay registro de riesgos, dueño, probabilidad ni plan de respuesta. El riesgo 2 es en realidad una dependencia, y el acta declara «Ninguna declarada».
- **Hecho del periodo sin rastro:** «Se recibió el concepto pendiente del ente supervisor». Ningún documento anterior lo declara pendiente y el concepto no está en la carpeta.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado «Verde» | Informe 2026-10-16: Verde | Acta: cierre 2026-05-10, ya vencido 159 días y sin replanificación; cronograma: 3/3 hitos cerrados frente a 61% de avance |
| Avance 61% | Informe 2026-10-16: 61% | Cronograma v1: 3 de 3 hitos cerrados (plan sostiene 100%) |
| Dependencias: ninguna | Acta 2025-10-24: «Ninguna declarada» | Informe 2026-10-16: riesgo «Dependencia del proveedor del core cooperativo»; cronograma: hito «Integración con el core cooperativo» |

### Sin sustento
- Los tres hitos como «cerrados» (cronograma, sin evidencia).
- «Se recibió el concepto pendiente del ente supervisor» (solo el informe).
- Comprometido, ejecutado y proyección al cierre (solo el informe; tres afirmaciones).
- Riesgo «cambio normativo del supervisor» (solo el informe; no está en acta, ni en minuta, ni en registro).

Además: el producto asociado, microcrédito (PRD-305), no tiene en su comité de producto del 2026-10-05 ningún requerimiento ejecutado por PRY-207 (la columna «Proyecto que lo ejecuta» está vacía en los 16), y esa minuta no cita el proyecto. La decisión «Se mantiene el plan» de esa minuta no puede atribuirse a PRY-207. Qué requerimientos construye este proyecto no se sabe desde la carpeta.

### Lo que esta carpeta no permite saber
- **Si los hitos se cumplieron de verdad:** falta toda evidencia de recibo. Consecuencia: el 100% del plan y el 61% reportado no se pueden contrastar con nada.
- **Por qué sigue abierto 159 días después del cierre comprometido:** falta replanificación o control de cambios. Consecuencia: no hay fecha de cierre vigente; la desviación real es desconocida, aunque el cálculo dé 0 días.
- **Qué puede decidir el gerente:** falta autoridad declarada. Consecuencia: ninguna desviación de fecha o presupuesto puede considerarse aprobada.
- **Cuánto se ha gastado y comprometido:** faltan contratos, órdenes y ejecución. Consecuencia: el «disponible real» de 684.871.653 COP es la cifra del informe, no una comprobada.
- **Qué contiene el alcance y qué es «el punto 11»:** faltan alcance detallado y minuta con contenido.
- **Qué dijo el supervisor:** no está el concepto. Consecuencia: el riesgo normativo no se puede valorar.

### Qué sigue
Esto es un diagnóstico, no una recomendación: detener, continuar o reestructurar lo decide quien tiene la facultad. Con este dictamen la carpeta no permite sostener el estado «Verde», y puedo preparar el punto de comité con la lista de lo que falta. También puedo llevar las tres contradicciones al gerente como preguntas, una por una.

*Pie de rigor: borrador de trabajo; cada dato va con su documento de origen y la verificación es de quien lo lee. Las cifras derivadas se copiaron de la salida de `compute` (corrida del 2026-10-16). Lo que no está en esta carpeta no se supone.*
