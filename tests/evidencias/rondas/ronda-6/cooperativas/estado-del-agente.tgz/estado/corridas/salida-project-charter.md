Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Respuestas sugeridas tomadas sin preguntar, por ser sesión sin interfaz.

**Acta previa:** sí, `2025-12-23-acta-constitucion.docx` (aprobada el 2025-12-23 por el Comité de Tecnología).

## Acta — PRY-200 Crédito de libranza digital
**Estado:** existe, del 2025-12-23

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** (ni monto ni tipo de cambio) | Sandra Gil no tiene un límite escrito; todo cambio de alcance, fecha o presupuesto termina en comité. Hoy hay dos incidencias abiertas (prueba de carga fallida, ajuste de reglamento) y un riesgo normativo que puede mover el alcance, y no hay regla que diga quién decide. |
| Objetivo de negocio | Descripción de la solución: "Entregar crédito de libranza digital para Canales digitales" | No dice qué resultado de negocio se busca (volumen, costo, tiempo de desembolso). No se puede juzgar si el proyecto valió la pena, solo si se entregó. |
| Alcance | "Componente 1, 2, 3" sin nombre | No se puede saber qué entra ni verificar entregas. Cualquier solicitud nueva (p. ej. el ajuste de reglamento pedido por el Consejo) no se puede clasificar como dentro o fuera del alcance. |
| Exclusiones | Plantilla: "Lo que otro proyecto cubre" | No nombra ningún proyecto ni ninguna exclusión. Equivale a no tener exclusiones: el riesgo de solapamiento queda sin control. |
| Criterio de éxito | "En producción y medido" | No hay métrica, umbral ni plazo, y no dice quién mide. "Medido" no define qué resultado cuenta como éxito, así que el cierre sería discrecional. |
| Supuestos y restricciones | No hay sección | El cambio normativo que hoy figura como riesgo se pudo haber declarado como supuesto en el acta; sin supuestos escritos no hay contra qué contrastarlo. |
| Dependencias | "Ninguna declarada" | Un crédito de libranza suele depender de convenios con pagadurías y del reglamento. El informe ya menciona un ajuste de reglamento que no estaba previsto. |
| Hitos principales | No hay | Con solo inicio y cierre, el avance no se puede medir contra nada intermedio. |
| Cadencia de reporte al comité | No está | Sin cadencia, nada obliga a que el comité vea el proyecto. |
| Patrocinador, gerente, comité, presupuesto, fechas | Presentes (Jorge Medina, Sandra Gil, Comité de Tecnología, 6.800.000.000 COP, 2026-01-02 a 2026-08-13) | Sin observación. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar crédito de libranza digital para Canales digitales" (acta, Objetivo del negocio).
**Alcance:** tres componentes sin nombre (acta, Alcance). Pendiente de definir.
**Exclusiones:** pendiente de definir. El acta trae el texto de plantilla "Lo que otro proyecto cubre".
**Patrocinador:** Jorge Medina · **Gerente:** Sandra Gil (acta, cabecera)
**Autoridad del gerente:** pendiente de definir (no aparece en ningún documento de la carpeta).
**Comité al que reporta:** Comité de Tecnología (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Crédito de libranza digital en producción y medido" (acta) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. No hay cronograma en la carpeta. Solo se conocen inicio 2026-01-02 y cierre 2026-08-13 (acta).

### Lo que el acta y el informe no concilian
- La fecha de cierre del acta (2026-08-13) ya venció a 2026-10-16. El informe del 2026-10-12 declara **verde** y **42 %**. No hay en la carpeta ninguna replanificación aprobada (acta, Fechas comprometidas; informe de avance, Estado declarado).
- El informe dice que pidió ajustes el **Consejo de Administración**, pero el acta asigna el proyecto al **Comité de Tecnología**. Esto confirma el vacío de gobierno: no está escrito quién decide ni dónde.
- Presupuesto, según el informe: aprobado 6.800.000.000, comprometido 6.037.085.557 (88,8 %), ejecutado 2.337.646.171, proyección 6.511.899.586 COP. El comprometido queda debajo del umbral de 90 % de la configuración.

## Después
- El acta quedó sin autoridad declarada. Te ofrezco llevar esa definición al Comité de Tecnología (próximo comité del portafolio: 2026-10-30) como una decisión, no como un trámite.
- De la revisión salen tres candidatos al registro RAID: el riesgo normativo, la dependencia del reglamento y la ausencia de supuestos. Puedo pasarlos con `/raid-log` si lo confirmas.

*Pie de rigor: borrador de trabajo hecho solo con las dos carpetas leídas (acta e informe de avance). No sé lo que se habló fuera de esos documentos; si existe una autoridad delegada, un cronograma o una replanificación fuera de la carpeta, no los he visto. Verifica cada dato contra la cita.*
