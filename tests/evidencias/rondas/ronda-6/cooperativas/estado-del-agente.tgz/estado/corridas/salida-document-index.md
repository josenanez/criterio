## Carpeta al 2026-10-16

**Documentos:** 76 · **Sin cambio:** 76 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 122 citas de PRY-210 (corresponsales rurales) como "fuente no encontrada". Todas salen de `documentos/proyectos/PRY-210-corresponsales-rurales/00-gobierno/ficha-pm.json`: identidad (6), estado declarado (3), plan (4), dinero (5) y 26 compromisos (104).

Los 18 documentos que citan (acta de constitución, cronograma v1, informe de avance del 13-oct, actas de recibo 3/4/7/13/14/16/18/19, comités semanales y notas del 16-oct) **sí existen en la carpeta del proyecto**. Con esa evidencia, lo más probable es que las rutas de la ficha sean relativas a la carpeta del proyecto y el índice las busque desde la raíz de documentos. Esto no está confirmado: no se corrigió nada ni se comparó cita por cita.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-210 | 122 campos de `pm_record` (identity, declared, plan, money, commitments[0..25]) | los 18 documentos arriba listados |

### Formatos que no se pudieron leer
Ninguno: este comando no lee documentos, solo los cuenta y los compara.

### Siguiente paso
No hay nada que releer, así que no hace falta `/portfolio-scan`. Queda por revisar si las citas de PRY-210 son un falso positivo de rutas.
