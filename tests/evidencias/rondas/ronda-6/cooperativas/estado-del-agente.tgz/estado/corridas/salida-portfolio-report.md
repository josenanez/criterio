Cargué 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas escritas el 2026-10-16 (frescas, ninguna con más de una semana). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-16.

# Portafolio — 2026-10-16
13 proyectos · 10 con hallazgos (52 señales) · último barrido 2026-10-16 · 8 de 13 declaran verde con señales que lo contradicen

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (`snapshots/2026-10-16.json`), así que este informe es el punto de partida: no hay delta real contra el que medir.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-202 Core cooperativo | Piloto con asociados (vencido, sin cumplir) | 2026-10-09 | 7 | informe de avance 2026-10-09 |
| PRY-210 Corresponsales rurales | Diseño funcional aprobado (vencido, sin cumplir) | 2026-10-10 | 6 | informe de avance 2026-10-13 |

Hitos declarados "cumplidos" sin evidencia que lo respalde: 19 hitos en 9 proyectos (PRY-201, 202, 204, 205, 206, 207, 208, 209, 211). Los más antiguos: PRY-207 Diseño funcional (285 días), PRY-211 Integración con el core (280), PRY-206 Diseño funcional (250), PRY-202 Diseño funcional (222), PRY-207 Ambiente de pruebas (222).

## Proyectos en silencio
Vacía: el que más días lleva sin documento nuevo es PRY-204 con 10 (umbral: 15).

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencia por código de otro proyecto. Un cruce que sí aparece: PRY-202 Core cooperativo (hito vencido) es el core que PRY-201, 204, 207 y 211 citan en sus hitos de integración, pero ninguno lo declara como dependencia; es una lectura mía, no un campo de las fichas.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | verde, 74 % | 2 hitos "cumplidos" sin evidencia |
| PRY-202 | verde, 73 % | hito vencido hace 7 días + 2 hitos sin evidencia |
| PRY-204 | verde, 64 % | sobrecosto proyectado 11,2 %; 2 proveedores con entregable tardío (73 días); Integración Financiera del Sur facturó $929.615.834 contra $777.441.999 aceptado (+$152.173.835); 3 hitos sin evidencia |
| PRY-205 | verde, 23 % | compromiso vencido hace 16 días (Diana Molina, punto 39); 1 hito sin evidencia |
| PRY-207 | verde, 61 % | 3 de 3 hitos "cumplidos" sin evidencia; el plan sostendría 100 % (rezago de 39 puntos) |
| PRY-208 | verde, 67 % | re-línea base no autorizada de 161 días (+48,3 %); compromiso vencido (Laura Vélez, punto 16); 2 hitos sin evidencia |
| PRY-209 | verde, 52 % | 1 hito sin evidencia |
| PRY-210 | verde, 47 % | 3 compromisos vencidos (hasta 24 días), 2 reprogramados 5 y 4 veces, 4 sin fecha, hito vencido; declara 47 % con 0 de 4 hitos cumplidos |

PRY-211 (amarillo) también: declara 48 % con 5 de 5 hitos cumplidos, 3 sin evidencia (rezago de 52 puntos).

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad (`identity.authority`) y fase (`identity.phase`) |
| PRY-202, 205, 208, 209, 210 | Producto asociado (`identity.product`) |
| PRY-199 | Facturado del proveedor CT-199 |
| PRY-203, 206, 207, 211 | Campos de identidad y plan con fuente de 12 a 17 meses (umbral: 12) |
| Los 13 | Ningún dato está marcado como evidencia (0); todo es declaración o sin marcar |

Fechas de fin ya pasadas con proyecto en curso (lectura mía, no señal del script): PRY-200 (2026-08-13, 42 %), PRY-203 (2026-07-25, 36 %), PRY-207 (2026-05-10, 61 %), PRY-211 (2026-05-12, 48 %).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Mobiliario agencias | verde 20 % | sin señales | 0 d | 0 d | 0 |
| PRY-200 Libranza digital | verde 42 % | sin señales | 0 d | 0 d | 0 |
| PRY-201 Ahorro en línea | verde 74 % | 3 señales | 0 d | 0 d | 0 |
| PRY-202 Core cooperativo | verde 73 % | 4 señales | 0 d | 0 d | 0 |
| PRY-203 Aportes sociales | amarillo 36 % | sin señales | 0 d | 0 d | 0 |
| PRY-204 Tarjeta débito | verde 64 % | 10 señales | 0 d | 0 d | 0 |
| PRY-205 Prevención LA | verde 23 % | 3 señales | 0 d | 0 d | 0 |
| PRY-206 Pagos QR | rojo 71 % | 3 señales | 0 d | 0 d | 0 |
| PRY-207 Microcrédito rural | verde 61 % | 5 señales | 0 d | 0 d | 0 |
| PRY-208 Motor de crédito | verde 67 % | 6 señales | +161 d (48,3 %) | 0 d | 1 |
| PRY-209 Convenios libranza | verde 52 % | 2 señales | 0 d | 0 d | 0 |
| PRY-210 Corresponsales rurales | verde 47 % | 12 señales | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | amarillo 48 % | 4 señales | 0 d | 0 d | 0 |

Dinero: solo PRY-204 cruza el umbral de costo (proyección +11,2 % sobre $6.800 M). Ninguno cruza el umbral de comprometido (90 %); el más alto es PRY-200 con 88,8 %.

## Necesito que confirmes
(Sesión sin interfaz: nadie respondió; quedan como preguntas abiertas para el mes.)
1. PRY-203: ¿la fecha de fin sigue siendo 2026-07-25? (fuente de 2025-05-15, 17 meses)
2. PRY-211: ¿la fecha de fin sigue siendo 2026-05-12? (fuente de 2025-06-29, 16 meses)
3. PRY-206: ¿el patrocinador sigue siendo el mismo del acta? (fuente de 2025-09-18, 13 meses)
4. PRY-207: ¿la fecha de fin sigue siendo 2026-05-10? (fuente de 2025-10-24, 12 meses)
5. ¿Quién es la autoridad de PRY-208 Motor de crédito, el proyecto con la re-línea base de 161 días sin autorizar?

## Dónde quedó el informe
`reportes/` (25 páginas): `index.html` (por campo, con la cadena de evidencia, para quien actúa) y `decisiones.html` (por decisión, para el patrocinador). Para PDF, imprimir el HTML. Hay además una página por proyecto y por producto.

Nota de configuración: el formato configurado es `pptx`; esta corrida usó `html` por el argumento.

---
criterio-portfolio 0.3.12 · fichas aplicadas: 13, todas del 2026-10-16 · campos inciertos: autoridad y fase en los 13, producto en 5, y los de fuente antigua en 4 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
