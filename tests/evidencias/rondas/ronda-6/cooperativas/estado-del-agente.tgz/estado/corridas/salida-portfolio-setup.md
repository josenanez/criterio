Soy Vera, el agente PMO de Criterio. Proceso la documentación que ya tienes y digo qué no se sostiene.

(Sesión sin interfaz: en cada pregunta tomé la respuesta sugerida y la dije en una línea.)

## Listo — Cooperativa

**Miré:** 76 documentos en 13 proyectos · formatos: .md (39), .docx (12), .pdf (11), .xlsx (7), .csv (5), .json (1), .txt (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (se ven 13 proyectos; propuesta por defecto)
**Te aviso:** dos días antes del comité del 2026-10-30, que propuse quincenal por no haber comité indicado
**En:** presentación (propuesta por defecto)
**Términos:** aceptados por José Francisco Ñáñez, versión 0.3.12 (términos 1.1), 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 del .md: 08da686bb7c9acf4…
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

Los de documentación más reciente: PRY-207, PRY-208 y PRY-210. Los tres reportan **verde** y en los tres las señales calculadas contradicen ese verde.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-207 Microcrédito rural | 4 | Gerente Carlos Peña, patrocinador Mauricio Pérez, presupuesto 3.300 M COP (ejecutado 1.059 M, proyección 3.339 M). Declara verde y 61% (informe 2026-10-16). Tres hitos declarados cerrados. | Acta de recibo de los tres hitos; facultad del gerente (authority); fase. |
| PRY-208 Motor de crédito | 8 | Gerente Rubén Cárdenas, patrocinador Sandra Gil, presupuesto 18.000 M COP. Declara verde y 67% (informe 2026-10-13). Cronograma v3 mueve el piloto al 2027-06-05. Dos solicitudes de cambio (CC-01, CC-02) pendientes de comité. | Acta de recibo de diseño funcional y de ambiente de pruebas; cronograma v2; facultad del gerente; fase; producto («No aplica»). |
| PRY-210 Corresponsales rurales | 19 | Gerente Liliana Torres, patrocinador Rubén Cárdenas, presupuesto 9.500 M COP. Declara verde y 47% (informe 2026-10-13). 26 compromisos de reunión leídos. El gerente publicó `ficha-pm.json`; va aparte, sin fusionar. | Acta de recibo de los cuatro hitos; facultad del gerente; fase; producto («No aplica»). |

### Hallazgos (los que levantó el cálculo)

**PRY-207 · `declared_vs_evidence`** — declara verde; lo contradicen dos señales:
- `milestone_met_without_evidence` ×3: Diseño funcional (due 2026-01-04, 285 días), Ambiente de pruebas (2026-03-08, 222 días), Integración con el core (2026-05-10, 159 días). Declarados cerrados en `10-plan/2025-10-24-cronograma-v1.xlsx`; ninguna acta de recibo en la carpeta.
- `progress_vs_plan`: declara 61% y el cronograma con los tres hitos cerrados sostiene 100%: 39 puntos de diferencia.

**PRY-208 · `declared_vs_evidence`** — declara verde; lo contradicen cuatro señales:
- `rebaseline_unauthorized`: 161 días movidos, 0 autorizados (2 solicitudes vistas, ambas pendientes). El piloto pasó del 2026-12-26 al 2027-06-05 en el cronograma v3 del 2026-10-13.
- `variance_time`: 161 días, 48,3 % contra la línea base original.
- `milestone_met_without_evidence` ×2: Diseño funcional (2026-04-20, 179 días) y Ambiente de pruebas (2026-07-12, 96 días). La integración con el core sí tiene acta (2026-10-15).
- `commitment_overdue`: Laura Vélez, «Entregar el punto 16», vencido el 2026-10-12 (4 días).

**PRY-210 · `declared_vs_evidence`** — declara verde; lo contradicen cuatro señales:
- `milestone_overdue`: Diseño funcional aprobado, vencido el 2026-10-10 (6 días), sigue «en curso».
- `commitment_overdue` ×3: Óscar Ramírez «Enviar el documento 9» (24 días, misma fecha repetida cuatro semanas); Laura Vélez «Validar el ambiente 20» (3 días); Ricardo Salas «Confirmar la fecha 23» (1 día).
- `commitment_rescheduled` ×2: Andrés Lozano «Enviar el documento 1», 5 reprogramaciones (de 2026-09-19 a 2026-11-30); Javier Hoyos «Cerrar la prueba 2», 4 reprogramaciones (de 2026-09-19 a 2026-11-16).
- `commitment_undated` ×4: Ricardo Salas (diseño 5), Carlos Peña (documento 17), Óscar Ramírez (punto 24), Laura Vélez (ajuste del presupuesto).
- `progress_vs_plan`: declara 47% y el cronograma sostiene entre 0 y 25% (ningún hito cerrado): 22 puntos por encima.

**Portafolio (de estos tres):** 23 señales; 3 de 3 con verde contradicho; 3 de 3 sin facultad del gerente (authority) en ningún documento.

### El portafolio completo

10 proyectos más (PRY-199 a PRY-206, PRY-209 y PRY-211) y 60 documentos, en 2 lotes uno tras otro: aproximadamente de 30 a 45 minutos con lo que vi.

### Lo que le falta a tu carpeta

- **Actas de recibo de hitos:** en PRY-207 y PRY-208 hay hitos declarados cerrados sin acta; solo PRY-208 tiene una (integración con el core).
- **Cronogramas intermedios:** PRY-208 tiene v1 y v3 pero no v2; PRY-207 tiene solo v1 y su cierre comprometido (2026-05-10) ya pasó sin documento posterior que lo mueva.
- **Facultad del gerente:** ninguna de las tres actas dice hasta qué monto o cambio puede decidir sin subir a comité.
- **Fase y producto:** la fase no aparece en ningún documento; en PRY-208 y PRY-210 el producto dice «No aplica».
- **Compromisos sin fecha:** en PRY-210, varios quedaron en «por definir» o «la otra semana».

Ninguno es bloqueante: el análisis corre con lo que hay.

### Sigue

Puedo correr el portafolio completo. Como eres PMO con equipo, también puedo publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios.
