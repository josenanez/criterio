# Corrida del 2026-10-16 · steering-pack

13 proyectos · 85 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de comité 2026-10-30: 5 decisiones, 4 escalamientos. No hay acta del comité anterior; autoridad de aprobación vacía en los 13 proyectos; motivo y alcance de CC-01/CC-02 no constan.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** 13 fichas (`estado/records/PRY-199` a `PRY-211`), todas con fecha 2026-10-16. Cifras derivadas copiadas de `portafolio.py compute` (corte 2026-10-16). Términos vigentes: versión 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16.

# Comité de proyectos — 2026-10-30 (material preparado el 2026-10-16)
5 decisiones · 4 escalamientos sin decisión asociada · 10 de 13 proyectos con hallazgos (52 señales abiertas; 8 proyectos declarados en verde con señales que lo contradicen)

> **Lo primero que dice el material:** en los 13 proyectos el campo `authority` está vacío. Ninguna ficha dice quién aprueba cambios ni con qué umbral. Por eso la decisión [1] va antes que las demás: sin ella, las otras cuatro no tienen a quién dirigirse con certeza.

## Decisiones del comité anterior
No hay acta, minuta ni registro de un comité anterior en las fichas ni en la carpeta de estado. No puedo decir qué se decidió antes ni qué quedó abierto. Esta sección queda vacía por falta de dato, no porque no haya habido decisiones. Si existe un acta del comité previo, hay que traerla para cerrar el ciclo.

## Decisiones de hoy

### [1] ¿Quién aprueba los cambios de alcance, tiempo y costo de los proyectos del portafolio, y con qué umbral?
**Proyecto:** todos (13 sin autoridad declarada) · **Quién decide:** el propio comité; es la pregunta que fija quién decide las demás · **Si no se decide hoy:** las solicitudes de cambio siguen sin destinatario cierto (hoy: PRY-201 y las dos de PRY-208) y cada cronograma nuevo puede entrar como línea base sin autorización.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Este comité aprueba todo cambio de línea base, sin umbral | Todo cambio llega al comité | Más espera por cambio; el comité es quincenal | Sin costo directo declarado |
| B. El gerente aprueba por debajo de un umbral y el comité por encima | Los menores no suben | Rápido en lo menor | El umbral lo fija el comité; los documentos no traen ninguno |
| C. Se deja sin definir | — | — | — |

**Recomendación:** A de forma provisional, hasta que cada proyecto tenga escrita su autoridad en el acta. Ya hay un precedente parcial: en PRY-201 un Comité de Tecnología aprobó la línea base v1, pero ningún documento fija sus límites. La opción C es la única que no sirve: es el estado actual y es el que produjo el punto [2]. El umbral de B no sale de ningún documento; sería una decisión nueva del comité.

### [2] PRY-208 Motor de crédito: ¿se aprueban CC-01 y CC-02, y se reconoce o se rechaza el cronograma v3 que ya movió la fecha?
**Proyecto:** PRY-208 · **Quién decide:** no se puede determinar (autoridad no declarada); va al comité según [1] · **Si no se decide hoy:** el cronograma v3 (2026-10-13) sigue en uso con la salida 2027-06-05, que está 161 días después de la original, y hay 161 días movidos con 0 autorizados. El informe de avance del 2026-10-13 declara verde.

Qué dicen los documentos: CC-01 (2026-10-09, +46 días, COP 92.000.000 adicionales) y CC-02 (2026-10-10, +115 días, COP 230.000.000 adicionales), ambas «ampliación de alcance», solicitante Rubén Cárdenas, ambas «pendiente de presentación al comité». Ninguna dice qué alcance se amplía ni por qué. Los +46 y +115 declarados coinciden con los 161 días movidos de la línea base; es una lectura mía, ningún documento la afirma.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar ambas y registrar la línea base 2 (la original queda intacta) | Ampliado; qué se amplía no consta | +161 días, salida 2027-06-05, ya reflejados en v3 | COP 92.000.000 + 230.000.000 adicionales, según las solicitudes |
| B. Aprobar CC-01 y rechazar CC-02 | Ampliación parcial | +46 días (lo demás deshecho); v3 se reemplaza | COP 92.000.000 |
| C. No aprobar ninguna hasta que el solicitante diga qué alcance y por qué | Sin cambio | Se mantiene la fecha original; v3 queda como propuesta no aprobada | Sin adicional |

**Recomendación:** C para esta sesión y que Rubén Cárdenas traiga el contenido del alcance y el motivo, porque hoy el comité aprobaría un alcance que nadie describió. Mientras tanto v3 no se toma como línea base y el proyecto se reporta contra la original. La verde declarada no se sostiene mientras tanto: el script reporta 161 días de variación en tiempo contra la original (48,3 %, umbral 10 %) y rebaseline no autorizado. Lo que no sé: la ficha no trae el motivo de nada de esto.

### [3] PRY-204 Tarjeta débito: ¿se retiene el pago de la diferencia facturada sobre lo aceptado a Integración Financiera del Sur?
**Proyecto:** PRY-204 · **Quién decide:** no se puede determinar (autoridad no declarada) · **Si no se decide hoy:** la factura sigue circulando sin que lo aceptado la cubra y la proyección sigue 11,2 % sobre lo aprobado.

Hechos de `compute`: contrato CT-968, facturado COP 929.615.834 contra aceptado COP 777.441.999, diferencia COP 152.173.835. Proyección COP 7.559.606.133 contra aprobado COP 6.800.000.000 (+11,2 %, umbral 10 %). «Bolsa de horas de desarrollo» venció el 2026-08-04, 73 días, en CT-467 (Soluciones Solidarias) y en CT-968, sin evidencia de entrega; «Licenciamiento del módulo» figura entregado sin acta de recibo en ambos. El informe del 2026-10-06 declara verde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener COP 152.173.835 hasta que haya aceptación documentada | Sin cambio | Puede frenar al proveedor y alargar la bolsa de horas, que ya está tarde | Se evita pagar lo no aceptado |
| B. Pagar y exigir las actas después | Sin cambio | Sin freno | Se paga antes de que haya evidencia |
| C. Pedir al gerente que presente las actas de recibo antes de cualquier otro pago, sin retener todavía | Sin cambio | Una semana de espera para el proveedor | Pago diferido, no retenido |

**Recomendación:** A. La diferencia está calculada y no hay acta que la cubra. Si aparece el acta, se libera. No sé si el contrato permite retener; eso lo verifica Jurídica o quien administre el contrato. La proyección sobre el presupuesto (+11,2 %) queda como segundo punto a decidir cuando el gerente explique de dónde sale.

### [4] D-CORE, D-REGL e I-SEG: ¿quién es el doliente de cada uno?
**Proyecto:** varios · **Quién decide:** el comité, porque cruzan proyectos y el doliente de D-CORE y D-REGL es externo · **Si no se decide hoy:** siguen los tres sin doliente en 7, 4 y 6 proyectos respectivamente, sin fecha de resolución.

| Ítem | Qué | Proyectos |
|---|---|---|
| D-CORE | Dependencia del proveedor del core cooperativo | PRY-199, 201, 204, 205, 206, 207, 210 |
| D-REGL | Aprobación del reglamento por el Consejo de Administración (ya pidió ajustarlo antes del piloto) | PRY-203, 205, 210, 211 (e incidencia en 200, 204, 211) |
| I-SEG | Hallazgo de seguridad de la revisión de arquitectura | PRY-199, 201, 202, 206, 209, 210 |

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Una persona nombrada por el comité por cada ítem | Un solo seguimiento por ítem | Respuesta única, más rápida | Sin costo declarado |
| B. Cada gerente dueño provisional de lo suyo | Sigue repartido | Seis y siete respuestas distintas al mismo problema | Sin costo declarado |
| C. Dejarlos como están | — | — | — |

**Recomendación:** A. Los ítems son compartidos; con B nadie pregunta una sola vez al Consejo ni al proveedor del core. Además, para D-CORE cada gerente debe declarar de qué proyecto concreto depende; ninguna ficha lo hace y el cruce entre proyectos no se puede calcular. Que el core sea PRY-202 es lectura mía. Tampoco sé si I-SEG es un hallazgo o seis.

### [5] Proyectos con fecha de cierre vencida: ¿se replanifica por cambio formal o se cierra?
**Proyecto:** PRY-200, 202, 203, 207, 211 · **Quién decide:** el comité, según [1] · **Si no se decide hoy:** siguen en curso con el cierre vencido y sin cronograma posterior que lo explique.

| Proyecto | Cierre en línea base | Estado declarado | Avance declarado |
|---|---|---|---|
| PRY-207 | 2026-05-10 | verde | 61 % |
| PRY-211 | 2026-05-12 | amarillo | 48 % |
| PRY-203 | 2026-07-25 | amarillo | 36 % |
| PRY-200 | 2026-08-13 | verde | 42 % |
| PRY-202 | 2026-10-09 | verde | 73 % |

En PRY-207 y PRY-211 los cinco y tres hitos del plan figuran cumplidos, pero el avance declarado es 61 % y 48 %: el script marca brecha de 39 y 52 puntos. Documentos que se contradicen.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada gerente presenta solicitud de cambio con fecha nueva y motivo; el comité decide | Sin cambio | Fechas nuevas, quedan trazables | No declarado |
| B. Cerrar los que cumplan el criterio de éxito y replanificar el resto | Cierre parcial | Se corta el arrastre | No declarado |
| C. Esperar | — | Sigue el atraso sin fecha | — |

**Recomendación:** A. No hay evidencia de que alguno de los cinco cumpla su criterio de éxito (PRY-200 lo contrasté: la documentación apunta a que no), así que cerrar no es defendible hoy. Lo que no sé: cuánto cuesta cada mes de atraso; las fichas no traen costo mensual.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-201 | Solicitud de mover la salida 30 días (2027-01-04 → 2027-02-03). **Devuelta**: no dice quién la pide, ni el motivo, ni el impacto en alcance y costo; el piloto del 2026-10-26 (a 10 días) queda en medio y no se sabe si se mueve | 2026-10-16 | Gerente completa los cinco puntos del paquete antes del comité; entra a [1] |
| PRY-210 | Compromisos reprogramados: 5 veces (Andrés Lozano, «Enviar el documento 1», original 2026-09-19, última 2026-11-30) y 4 veces (Javier Hoyos, «Cerrar la prueba 2», original 2026-09-19, última 2026-11-16). 3 vencidos y 4 sin fecha. Hito «Diseño funcional aprobado» vencido el 2026-10-10. Avance declarado 47 % con plan que soporta 0 a 25 % | desde 2026-09-18 (acta más antigua) | Decidir si se acepta la nueva fecha o se reasigna |
| PRY-205 / PRY-208 | Compromisos vencidos: Diana Molina (punto 39, vencía 2026-09-30, 16 días) y Laura Vélez (punto 16, vencía 2026-10-12, 4 días) | 2026-09-30 / 2026-10-12 | Que cada una responda con fecha |
| PRY-206 | Declarado en rojo (71 %) y compromiso de Camilo Beltrán sin fecha. El resto del informe no está en este material | 2026-10-09 | Gerente explica el rojo; no hay causa en las fichas |

## Para conocimiento
- PRY-199 Mobiliario de agencias: sin señales. Verde, 20 %.
- PRY-200 Libranza digital: en [5]; prueba de carga repetida.
- PRY-201 Ahorro en línea: cambio devuelto; dos hitos «cumplidos» sin acta.
- PRY-202 Core cooperativo: en [5]; piloto vencido 7 días.
- PRY-203 Aportes sociales: en [5].
- PRY-204 Tarjeta débito: en [3].
- PRY-205 Prevención de lavado: un hito sin acta y un compromiso vencido.
- PRY-206 Pagos QR: rojo; en escalamientos.
- PRY-207 Microcrédito rural: en [5].
- PRY-208 Motor de crédito: en [2].
- PRY-209 Convenios de libranza: un hito «cumplido» sin acta; declarado verde.
- PRY-210 Corresponsales rurales: en escalamientos.
- PRY-211 Cobranza digital: en [5]; tres hitos cumplidos sin acta.

## Anexo
**Contradicciones abiertas** (declarado contra evidencia): 8 de 13 proyectos en verde con señales que lo contradicen: PRY-201, 202, 204, 205, 207, 208, 209, 210. «Cumplido sin acta de recibo»: PRY-201, 202, 204, 205, 206, 207, 208, 209, 211. Ninguna ficha tiene fuente de evidencia propia contra la declaración; para PRY-204 el script cuenta 0 evidencias y 2 declaraciones.
**Vacíos de información:**
- `authority` vacío en los 13; `phase` vacío al menos en PRY-204 y PRY-208; `product` vacío en PRY-208.
- Los 36 ítems RAID sin doliente ni fecha de resolución; sin valoración de probabilidad e impacto.
- Sin minutas de PRY-200, 201, 203 y 211.
- Sin historial de movimiento del RAID: «dos períodos sin movimiento» no se puede medir.
- No hay acta del comité anterior.
**Fuentes:** `estado/records/*.json`, `estado/corridas/salida-raid-log.md`, `salida-change-control.md`, `salida-portfolio-scan.md`, y las solicitudes CC-01 y CC-02 de PRY-208.
**Después del comité:** se pueden registrar las decisiones en las fichas, y ahí es donde el próximo material se construye solo.

---
*Pie: criterio-portfolio 0.3.12 · términos 1.1 · fichas aplicadas: 13 (corte 2026-10-16) · campos inciertos: autoridad de aprobación, motivo y alcance de CC-01/CC-02, si I-SEG es un solo hallazgo, qué proyecto es la contraparte de D-CORE, base contractual para retener en [3] · borrador de trabajo, no decisión ni asesoría; la verificación es de quien decide · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12*
