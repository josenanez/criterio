# Corrida del 2026-10-16 · budget-tracking

13 proyectos · 26 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `declared_vs_evidence` | 8 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 5 |
| `progress_vs_plan` | 3 |
| `milestone_overdue` | 2 |
| `vendor_deliverable_late` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Presupuesto de PRY-204: proyección 11,2 % sobre el aprobado (umbral 10 %), CT-968 facturado 152.173.835 COP sobre lo aceptado. Dijo que no sabe: composición del comprometido, línea base posterior al acta, evidencia de recibo.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-204 (8 documentos leídos, último con fecha 2026-10-06) y del cálculo `compute` al 2026-10-16.

## Presupuesto — PRY-204 Tarjeta débito para asociados al 2026-10-16
**Moneda:** COP (única; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100 | 00-gobierno/2026-01-13-acta-constitucion.md | 2026-01-13 |
| Comprometido | 3.543.460.884 | 52,1 | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |
| Ejecutado | 2.023.984.664 | 29,8 | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |
| Proyección al cierre | 7.559.606.133 | 11,2 por encima del aprobado | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |

**Disponible real** (aprobado menos comprometido): 3.256.539.116 COP

La proyección es una declaración del informe de avance, no un dato duro. Tiene la misma fecha que el comprometido y el ejecutado (2026-10-06), y no hay un movimiento de presupuesto posterior que la deje vieja.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | 0 |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas en la carpeta. Contra el aprobado, el costo proyectado se desvía 11,2 %.

### Ejecución frente a avance
Ejecutado 29,8 % · Hitos cumplidos 3 de 5 · El informe declara 64 % de avance y estado verde, con 29,8 % ejecutado y 52,1 % comprometido. Los 3 hitos «cumplidos» no tienen acta de recibo que los pruebe, así que el 3 de 5 es una declaración y no una medición.

### Alertas
- **Proyección por encima del aprobado: 11,2 %**, sobre el umbral de 10 % configurado. El informe lo marca verde y no lo menciona.
- **Facturado por encima de lo recibido en CT-968 (Integración Financiera del Sur):** facturado 929.615.834, aceptado 777.441.999, diferencia 152.173.835 COP. El contrato factura contra acta de recibo firmada, y no hay ninguna en la carpeta.
- **CT-467 (Soluciones Solidarias S.A.S.):** facturado 584.839.421, igual al valor de un entregable. Ese entregable figura recibido en el contrato, pero sin acta que lo pruebe.
- **«Bolsa de horas de desarrollo» vencida hace 73 días** (2026-08-04) en los dos contratos, y nadie dice que se entregó.
- El comprometido (52,1 %) está por debajo del umbral de 90 %, así que no hay alerta de agotamiento.

### Sin dato
- **Comprometido sin conciliar:** el comprometido del informe (3.543.460.884) no concilia con el valor de los dos contratos, y los documentos no lo explican. No se sabe qué lo compone.
- **Línea base de presupuesto:** solo existe la aprobación del acta. No hay versión posterior ni cambio aprobado, así que «vigente» es igual a «original» por ausencia de documentos, no porque alguien lo haya confirmado.
- **Autoridad y fase del proyecto:** `not_found`.
- **Evidencia de recibo:** ninguna acta en la carpeta. La cifra de ejecutado y la de hitos descansan solo en el informe de avance, que es una declaración.

Pie de rigor: borrador de trabajo. Cada cifra sale del script `compute` o de la ficha, con su cita. La verificación contra los documentos es de quien lo use.

**Siguiente paso posible:** como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto. Si se necesita el detalle por proveedor (facturado frente a aceptado), puedo hacerlo con `/vendor-tracking PRY-204`.
