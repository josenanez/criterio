<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-02-02-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-05,2026-05-05,cerrado
Ambiente de pruebas certificado,2026-07-26,2026-07-26,cerrado
Integración con el core cooperativo,2026-10-17,2026-10-17,en curso
Piloto con asociados,2027-01-07,2027-01-07,en curso
