<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Core cooperativo

**Fecha:** 2026-10-05
**Asistentes:** Natalia Ospina, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 13 | 2026-10-19 |
