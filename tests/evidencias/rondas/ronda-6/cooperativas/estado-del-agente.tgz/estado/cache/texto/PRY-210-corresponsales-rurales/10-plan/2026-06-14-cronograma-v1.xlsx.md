<!-- origen: PRY-210-corresponsales-rurales/10-plan/2026-06-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-10-10 | 2026-10-10 | en curso
Ambiente de pruebas certificado | 2027-01-26 | 2027-01-26 | en curso
Integración con el core cooperativo | 2027-05-14 | 2027-05-14 | en curso
Piloto con asociados | 2027-08-30 | 2027-08-30 | en curso
