<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-02-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-06-17,2026-06-17,cerrado
Ambiente de pruebas certificado,2026-10-21,2026-10-21,en curso
Integración con el core cooperativo,2027-02-25,2027-02-25,en curso
Piloto con asociados,2027-07-01,2027-07-01,en curso
