<!-- origen: PRY-200-crédito-de-libranza-digital/00-gobierno/2025-12-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Crédito de libranza digital

Código: PRY-200

Área dueña: Canales digitales

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Tecnología

Producto asociado: crédito de libranza

Fecha de aprobación: 2025-12-23

Objetivo del negocio

Entregar crédito de libranza digital para Canales digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Tecnología el 2025-12-23.

Fechas comprometidas

Fecha

Inicio

2026-01-02

Cierre

2026-08-13

Criterio de éxito

Crédito de libranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
