<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2026-01-13-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Tarjeta débito para asociados

**Código:** PRY-204
**Área dueña:** Tesorería
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Educación
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2026-01-13

## Objetivo del negocio

Entregar tarjeta débito para asociados para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Educación el 2026-01-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-23 |
| Cierre | 2027-01-08 |

## Criterio de éxito

Tarjeta débito para asociados en producción y medido.

## Dependencias declaradas

- Ninguna declarada
