<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-210",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "name": {
 "value": "Corresponsales rurales",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Bienestar social",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "manager": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Crédito",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 47,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-06-24",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "end_date": {
 "value": "2027-08-30",
 "source": "10-plan/2026-06-14-cronograma-v1.xlsx",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-06-14",
 "start_date": "2026-06-24",
 "end_date": "2027-08-30",
 "reason": "Aprobación del Comité de Crédito",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2026-10-10",
 "current_date": "2026-10-10",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-14-cronograma-v1.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2027-01-26",
 "current_date": "2027-01-26",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-14-cronograma-v1.xlsx"
 },
 {
 "name": "Integración con el core cooperativo",
 "baseline_date": "2027-05-14",
 "current_date": "2027-05-14",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-14-cronograma-v1.xlsx"
 },
 {
 "name": "Piloto con asociados",
 "baseline_date": "2027-08-30",
 "current_date": "2027-08-30",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-14-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Tres componentes sin nombre (Componente 1, 2 y 3)",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2026-06-14-acta-constitucion.md",
 "source_date": "2026-06-14",
 "state": "found"
 },
 "committed": {
 "value": 3546990306,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 2527235531,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 8851807729,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Dependencia del proveedor del core cooperativo",
 "owner": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13"
 },
 {
 "what": "Aprobación del reglamento por el Consejo de Administración",
 "owner": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó; nadie lo registró)",
 "owner": null,
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "Hallazgo de seguridad levantado en la revisión de arquitectura",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-30",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-16",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "note": "Dicho sin fecha el 2026-09-04; la nota del 2026-10-16 dice que 'no alcanzó'."
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-16",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-16",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-02-acta-recibo-3.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-3.md"
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-09-11-acta-recibo-4.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-11-acta-recibo-4.md"
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "reschedules": [],
 "note": "El 2026-09-18 dijo que ya lo entregó; no se presentó acta y desapareció de la lista."
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-09 dijo que ya lo entregó; no se presentó acta y desapareció de la lista."
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-20",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-09-18-acta-recibo-7.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-18-acta-recibo-7.md"
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-22",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "overdue",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [],
 "note": "La misma fecha repetida cuatro semanas, sin reprogramar y sin acta."
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-09 dijo que ya lo entregó; no se presentó acta y desapareció de la lista."
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-30",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-09-acta-recibo-13.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-13.md"
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-02-acta-recibo-14.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-14.md"
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-08",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-23",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-02-acta-recibo-16.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-02-acta-recibo-16.md"
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-12",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-09-acta-recibo-18.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-18.md"
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "met",
 "source": "20-seguimiento/2026-10-09-acta-recibo-19.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-19.md"
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-13",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "overdue",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "reschedules": [],
 "note": "El 2026-10-09 dijo que ya lo entregó; no se presentó acta."
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-11-03",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "overdue",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": [],
 "note": "Vencido el 2026-10-15; las notas del 2026-10-16 no lo mencionan."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": {
 "value": "open",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "reschedules": [],
 "note": "Dicho como 'la otra semana'; no es una fecha."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": {
 "value": "open",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-16",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": [],
 "notas": [
 "El producto es 'No aplica' en el acta; va vacío.",
 "Las minutas del 2026-09-04 al 2026-10-09 y la nota del 2026-10-16 se leyeron en orden.",
 "Ficha sin sellar: se leyó el historial de reuniones, no se declara el proyecto leído entero."
 ]
 }
}
