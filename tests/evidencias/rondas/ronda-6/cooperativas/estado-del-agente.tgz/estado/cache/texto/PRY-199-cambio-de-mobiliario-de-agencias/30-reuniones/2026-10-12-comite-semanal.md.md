<!-- origen: PRY-199-cambio-de-mobiliario-de-agencias/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Cambio de mobiliario de agencias

**Fecha:** 2026-10-12
**Asistentes:** Andrés Lozano, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Presentar el cierre de la fase | 2026-11-05 |
