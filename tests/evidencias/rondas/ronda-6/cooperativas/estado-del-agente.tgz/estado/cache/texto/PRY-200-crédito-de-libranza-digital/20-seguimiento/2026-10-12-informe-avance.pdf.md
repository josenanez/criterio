<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Crédito de libranza digital
Código: PRY-200
Fecha de corte: 2026-10-12
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 42%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 6.037.085.557
Ejecutado 2.337.646.171
Proyección al cierre 6.511.899.586

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
