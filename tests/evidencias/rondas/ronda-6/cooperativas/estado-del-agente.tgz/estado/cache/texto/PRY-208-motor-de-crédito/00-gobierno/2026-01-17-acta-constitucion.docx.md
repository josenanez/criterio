<!-- origen: PRY-208-motor-de-crédito/00-gobierno/2026-01-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de crédito

Código: PRY-208

Área dueña: Canales digitales

Patrocinador: Sandra Gil

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Educación

Producto asociado: No aplica

Fecha de aprobación: 2026-01-17

Objetivo del negocio

Entregar motor de crédito para Canales digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Educación el 2026-01-17.

Fechas comprometidas

Fecha

Inicio

2026-01-27

Cierre

2026-12-26

Criterio de éxito

Motor de crédito en producción y medido.

Dependencias declaradas

• Ninguna declarada
