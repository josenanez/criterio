<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Prevención de lavado de activos

**Fecha:** 2026-10-08
**Asistentes:** Ricardo Salas, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 39 | 2026-09-30 |
