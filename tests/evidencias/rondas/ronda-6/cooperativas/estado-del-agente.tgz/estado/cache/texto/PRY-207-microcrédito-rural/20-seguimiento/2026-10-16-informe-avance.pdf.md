<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-10-16
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 61%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.615.128.347
Ejecutado 1.059.251.553
Proyección al cierre 3.339.268.621

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
- Dependencia del proveedor del core cooperativo
