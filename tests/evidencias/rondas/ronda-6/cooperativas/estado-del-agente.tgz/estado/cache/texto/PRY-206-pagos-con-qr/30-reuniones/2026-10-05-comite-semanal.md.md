<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Pagos con QR

**Fecha:** 2026-10-05
**Asistentes:** Mauricio Pérez, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 14 | por definir |
