<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-09-29-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-09-29
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 23%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 800.000.000
Comprometido 245.154.532
Ejecutado 435.202.817
Proyección al cierre 808.331.169

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
