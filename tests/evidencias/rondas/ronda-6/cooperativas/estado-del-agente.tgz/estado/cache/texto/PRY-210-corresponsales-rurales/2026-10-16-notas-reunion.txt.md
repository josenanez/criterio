<!-- origen: PRY-210-corresponsales-rurales/2026-10-16-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión corresponsales rurales — 2026-10-16
estuvieron: Andrés Lozano, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Óscar Ramírez

- Andrés Lozano dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 30/11/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
