<!-- origen: PRY-211-cobranza-digital/10-plan/2025-06-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-08 | 2025-09-08 | cerrado
Ambiente de pruebas certificado | 2025-11-08 | 2025-11-08 | cerrado
Integración con el core cooperativo | 2026-01-09 | 2026-01-09 | cerrado
Piloto con asociados | 2026-03-11 | 2026-03-11 | cerrado
Salida a producción | 2026-05-12 | 2026-05-12 | cerrado
