<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-11-16 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-16 |
| Paula Céspedes | Entregar el punto 8 | 2026-10-21 |
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 |
| Jorge Medina | Revisar el anexo 11 | 2026-10-30 |
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-11-08 |
| Carlos Peña | Enviar el documento 17 | por definir |
| Carlos Peña | Aprobar el diseño 21 | 2026-11-03 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-02 |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-15 |
| Óscar Ramírez | Entregar el punto 24 | por definir |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Felipe Arango): recibido, acta de recibo del 2026-10-09.
- Cerrar la prueba 18 (Óscar Ramírez): recibido, acta de recibo del 2026-10-09.
- Revisar el anexo 19 (Rubén Cárdenas): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Ricardo Salas dice que ya entregó «actualizar la matriz 6». No se presentó acta.
- Javier Hoyos dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Laura Vélez dice que ya entregó «validar el ambiente 20». No se presentó acta.
