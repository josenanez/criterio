<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-09-28
Gerente: Camilo Beltrán

Estado declarado
Verde
Avance reportado: 74%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 443.714.282
Ejecutado 191.071.658
Proyección al cierre 1.173.792.669

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
- Dependencia del proveedor del core cooperativo
