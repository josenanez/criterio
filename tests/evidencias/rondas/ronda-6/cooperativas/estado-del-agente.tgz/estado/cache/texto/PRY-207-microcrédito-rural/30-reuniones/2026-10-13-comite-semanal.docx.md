<!-- origen: PRY-207-microcrédito-rural/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Microcrédito rural

Fecha: 2026-10-13

Asistentes: Carlos Peña, Mauricio Pérez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Carlos Peña

Entregar el punto 11

2026-11-01
