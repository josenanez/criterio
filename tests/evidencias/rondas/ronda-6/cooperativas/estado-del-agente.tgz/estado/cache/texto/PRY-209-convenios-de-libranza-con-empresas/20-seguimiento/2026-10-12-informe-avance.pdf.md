<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Convenios de libranza con empresas
Código: PRY-209
Fecha de corte: 2026-10-12
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 52%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- Se reprogramó la salida por el cierre contable de fin de mes
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.360.726.247
Ejecutado 1.278.037.004
Proyección al cierre 4.015.260.919

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
