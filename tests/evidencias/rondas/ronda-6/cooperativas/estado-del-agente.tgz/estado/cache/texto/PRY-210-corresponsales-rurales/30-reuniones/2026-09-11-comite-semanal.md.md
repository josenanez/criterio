<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-09-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-09-11
**Asistentes:** Andrés Lozano, Felipe Arango, Javier Hoyos, Liliana Torres, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-09-19 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-09-19 |
| Javier Hoyos | Revisar el anexo 3 | 2026-09-20 |
| Ricardo Salas | Aprobar el diseño 5 | por definir |
| Ricardo Salas | Actualizar la matriz 6 | por definir |
| Felipe Arango | Confirmar la fecha 7 | 2026-09-20 |
| Paula Céspedes | Entregar el punto 8 | 2026-09-24 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Sandra Gil): recibido, acta de recibo del 2026-09-11.
