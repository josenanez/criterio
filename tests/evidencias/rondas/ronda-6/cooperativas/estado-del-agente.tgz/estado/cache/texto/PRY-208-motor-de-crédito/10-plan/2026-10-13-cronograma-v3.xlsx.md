<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-10-13-cronograma-v3.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-20 | 2026-04-20 | cerrado
Ambiente de pruebas certificado | 2026-07-12 | 2026-07-12 | cerrado
Integración con el core cooperativo | 2026-10-04 | 2026-10-04 | cerrado
Piloto con asociados | 2026-12-26 | 2027-06-05 | en curso
