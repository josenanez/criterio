<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2026-02-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Convenios de libranza con empresas

Código: PRY-209

Área dueña: Tesorería

Patrocinador: María Restrepo

Gerente de proyecto: Javier Hoyos

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2026-02-02

Objetivo del negocio

Entregar convenios de libranza con empresas para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Crédito el 2026-02-02.

Fechas comprometidas

Fecha

Inicio

2026-02-12

Cierre

2027-01-07

Criterio de éxito

Convenios de libranza con empresas en producción y medido.

Dependencias declaradas

• Ninguna declarada
