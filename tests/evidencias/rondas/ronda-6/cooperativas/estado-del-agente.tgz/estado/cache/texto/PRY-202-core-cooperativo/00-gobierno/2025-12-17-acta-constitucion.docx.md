<!-- origen: PRY-202-core-cooperativo/00-gobierno/2025-12-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core cooperativo

Código: PRY-202

Área dueña: Cartera y cobranza

Patrocinador: Natalia Ospina

Gerente de proyecto: Natalia Ospina

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2025-12-17

Objetivo del negocio

Entregar core cooperativo para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Crédito el 2025-12-17.

Fechas comprometidas

Fecha

Inicio

2025-12-27

Cierre

2026-10-09

Criterio de éxito

Core cooperativo en producción y medido.

Dependencias declaradas

• Ninguna declarada
