<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-02-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Ahorro y aportes

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: Ricardo Salas

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2026-02-01

Objetivo del negocio

Entregar prevención de lavado de activos para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Crédito el 2026-02-01.

Fechas comprometidas

Fecha

Inicio

2026-02-11

Cierre

2027-07-01

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
