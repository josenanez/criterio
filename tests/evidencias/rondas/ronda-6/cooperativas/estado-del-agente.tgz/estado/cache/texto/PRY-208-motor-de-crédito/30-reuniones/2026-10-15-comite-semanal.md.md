<!-- origen: PRY-208-motor-de-crédito/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Motor de crédito

**Fecha:** 2026-10-15
**Asistentes:** Rubén Cárdenas, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 16 | 2026-10-12 |
