<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-09
**Gerente:** Mauricio Pérez

## Estado declarado

**Rojo**

Avance reportado: **71%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 737.982.710 |
| Ejecutado | 582.270.477 |
| Proyección al cierre | 1.139.061.556 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
