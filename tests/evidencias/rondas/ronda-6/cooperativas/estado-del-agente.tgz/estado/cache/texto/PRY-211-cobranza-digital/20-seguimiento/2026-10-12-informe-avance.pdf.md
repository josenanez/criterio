<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-12
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 48%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 6.957.696.466
Ejecutado 3.600.532.352
Proyección al cierre 18.390.132.026

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
