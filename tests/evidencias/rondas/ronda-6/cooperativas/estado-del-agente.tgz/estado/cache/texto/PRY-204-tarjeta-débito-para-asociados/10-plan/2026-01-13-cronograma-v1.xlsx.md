<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2026-01-13-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-03 | 2026-04-03 | cerrado
Ambiente de pruebas certificado | 2026-06-12 | 2026-06-12 | cerrado
Integración con el core cooperativo | 2026-08-21 | 2026-08-21 | cerrado
Piloto con asociados | 2026-10-30 | 2026-10-30 | en curso
Salida a producción | 2027-01-08 | 2027-01-08 | en curso
