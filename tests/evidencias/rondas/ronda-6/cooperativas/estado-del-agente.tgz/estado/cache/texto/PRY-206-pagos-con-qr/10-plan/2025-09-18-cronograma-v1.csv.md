<!-- origen: PRY-206-pagos-con-qr/10-plan/2025-09-18-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-08,2026-02-08,cerrado
Ambiente de pruebas certificado,2026-06-21,2026-06-21,cerrado
Integración con el core cooperativo,2026-11-01,2026-11-01,en curso
Piloto con asociados,2027-03-14,2027-03-14,en curso
