<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2026-01-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Apertura de ahorro en línea

Código: PRY-201

Área dueña: Riesgo y Cumplimiento

Patrocinador: Carlos Peña

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Tecnología

Producto asociado: ahorro a la vista

Fecha de aprobación: 2026-01-07

Objetivo del negocio

Entregar apertura de ahorro en línea para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Tecnología el 2026-01-07.

Fechas comprometidas

Fecha

Inicio

2026-01-17

Cierre

2027-01-04

Criterio de éxito

Apertura de ahorro en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
