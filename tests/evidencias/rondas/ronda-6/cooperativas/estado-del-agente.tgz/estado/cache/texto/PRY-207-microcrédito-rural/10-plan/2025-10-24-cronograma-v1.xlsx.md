<!-- origen: PRY-207-microcrédito-rural/10-plan/2025-10-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-04 | 2026-01-04 | cerrado
Ambiente de pruebas certificado | 2026-03-08 | 2026-03-08 | cerrado
Integración con el core cooperativo | 2026-05-10 | 2026-05-10 | cerrado
