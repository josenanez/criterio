<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-10-solicitud-cambio-cc-02.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-02

**Proyecto:** PRY-208 · Motor de crédito
**Fecha:** 2026-10-10
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +115 días sobre la línea base vigente |
| Costo | 230.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
