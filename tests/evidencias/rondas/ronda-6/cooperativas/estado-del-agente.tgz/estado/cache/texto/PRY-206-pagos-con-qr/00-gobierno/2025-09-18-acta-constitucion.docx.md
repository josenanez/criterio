<!-- origen: PRY-206-pagos-con-qr/00-gobierno/2025-09-18-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pagos con QR

Código: PRY-206

Área dueña: Tecnología

Patrocinador: Óscar Ramírez

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Crédito

Producto asociado: pagos QR

Fecha de aprobación: 2025-09-18

Objetivo del negocio

Entregar pagos con qr para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Crédito el 2025-09-18.

Fechas comprometidas

Fecha

Inicio

2025-09-28

Cierre

2027-03-14

Criterio de éxito

Pagos con QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
