<!-- origen: PRY-204-tarjeta-débito-para-asociados/30-reuniones/2026-10-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Tarjeta débito para asociados

**Fecha:** 2026-10-06
**Asistentes:** Javier Hoyos, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 35 | 2026-10-21 |
