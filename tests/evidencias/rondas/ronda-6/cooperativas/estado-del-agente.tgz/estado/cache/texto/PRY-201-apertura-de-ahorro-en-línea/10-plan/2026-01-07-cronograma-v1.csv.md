<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2026-01-07-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-03-28,2026-03-28,cerrado
Ambiente de pruebas certificado,2026-06-07,2026-06-07,cerrado
Integración con el core cooperativo,2026-08-16,2026-08-16,cerrado
Piloto con asociados,2026-10-26,2026-10-26,en curso
Salida a producción,2027-01-04,2027-01-04,en curso
