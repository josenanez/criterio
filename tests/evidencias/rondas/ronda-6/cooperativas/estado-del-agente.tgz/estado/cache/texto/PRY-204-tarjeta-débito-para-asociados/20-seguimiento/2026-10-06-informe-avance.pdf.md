<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tarjeta débito para asociados
Código: PRY-204
Fecha de corte: 2026-10-06
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 64%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto pendiente del ente supervisor
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.543.460.884
Ejecutado 2.023.984.664
Proyección al cierre 7.559.606.133

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Dependencia del proveedor del core cooperativo
