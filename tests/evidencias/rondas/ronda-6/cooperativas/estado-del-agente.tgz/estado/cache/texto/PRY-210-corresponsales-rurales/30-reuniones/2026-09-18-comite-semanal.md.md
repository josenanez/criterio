<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-09-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-09-18
**Asistentes:** Andrés Lozano, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-10-02 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-10 |
| Javier Hoyos | Revisar el anexo 3 | 2026-10-03 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-05 |
| Paula Céspedes | Entregar el punto 8 | 2026-09-24 |
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-21 |
| Jorge Medina | Revisar el anexo 11 | 2026-09-21 |
| Gustavo Neira | Validar el ambiente 12 | 2026-09-25 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Felipe Arango): recibido, acta de recibo del 2026-09-18.

## Lo que se dijo

- Ricardo Salas dice que ya entregó «aprobar el diseño 5». No se presentó acta.
