<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-05-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Aportes sociales en línea

**Código:** PRY-203
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Riesgos
**Producto asociado:** aportes sociales
**Fecha de aprobación:** 2025-05-15

## Objetivo del negocio

Entregar aportes sociales en línea para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Riesgos el 2025-05-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-25 |
| Cierre | 2026-07-25 |

## Criterio de éxito

Aportes sociales en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
