<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-06-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Crédito

Patrocinador: Óscar Ramírez

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Tecnología

Producto asociado: recaudos

Fecha de aprobación: 2025-06-29

Objetivo del negocio

Entregar cobranza digital para Crédito.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Tecnología el 2025-06-29.

Fechas comprometidas

Fecha

Inicio

2025-07-09

Cierre

2026-05-12

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
