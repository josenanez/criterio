<!-- origen: PRY-202-core-cooperativo/10-plan/2025-12-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-08 | 2026-03-08 | cerrado
Ambiente de pruebas certificado | 2026-05-19 | 2026-05-19 | cerrado
Integración con el core cooperativo | 2026-07-29 | 2026-07-29 | cerrado
Piloto con asociados | 2026-10-09 | 2026-10-09 | en curso
