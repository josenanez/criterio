## Para decisión — PRY-210 Corresponsales rurales · 2026-10-16

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16; comprobante ya registrado). Sin argumento, se revisó lo escalable en la ficha.

### Punto 1 (el primero, porque condiciona todos los demás): ¿Qué puede decidir la gerente de proyecto sin ir al comité?

El acta del 2026-06-14 no declara la autoridad del gerente (`identity.authority`: no encontrado). Sin eso no puedo decir cuáles de los puntos siguientes escalan de verdad.

**Quién decide:** el patrocinador Rubén Cárdenas, con el Comité de Crédito (acta de constitución) · **Si no se decide hoy:** el comité siguiente es el 2026-10-30; hasta entonces cada punto de abajo queda sin dueño de decisión comprobable.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se declara la autoridad por escrito (adenda al acta) | Sin cambio | Una sesión | Sin costo declarado |
| B. Se mantiene el vacío y todo lo que exceda lo operativo va al comité | Sin cambio | Cada punto espera al comité (cadencia semanal, próximo 2026-10-30) | Sin costo declarado; riesgo de decisiones sin validez |

**Recomiendo:** A. Sin límites declarados, la gerente escala todo o no escala nada.

### Punto 2: ¿Se acepta una sexta fecha para «Enviar el documento 1» (Andrés Lozano), o se reasigna?

Prometido el 2026-09-04 para 2026-09-19. Reprogramado 5 veces: 10-02, 10-19, 11-08, 11-16 y 11-30 (nota del 2026-10-16: «no alcanzó»). Cumple el criterio de escalamiento (más de tres reprogramaciones). Lleva 27 días de atraso sobre la fecha original, sin acta de recibo.

**Quién decide:** no se puede decir con el acta actual (ver punto 1); lo natural es el patrocinador · **Si no se decide hoy:** no hay fecha dura declarada que venza; lo único fechado es el compromiso en 2026-11-30, y el comité del 2026-10-30 es la última sesión antes de que vuelva a correrse.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se acepta 2026-11-30 con acta de recibo como condición | Sin cambio | 2026-11-30 | No declarado |
| B. Se reasigna el entregable | Sin cambio | No declarado | No declarado |

**Recomiendo:** A, con la condición de acta de recibo y reasignación automática si vuelve a correrse. El documento 1 no aparece vinculado a ningún hito en la ficha, así que no puedo medir su efecto en el cronograma.

### Fuera de este paquete (no escala, o no hay base)

- **Hito «Diseño funcional aprobado», fecha 2026-10-10, pendiente y sin evidencia, 6 días vencido.** Es una pregunta para el gerente, no una decisión de comité todavía: ¿se aprobó? Hasta que se confirme no se formula opción.
- **Riesgo «el proveedor podría no llegar con el equipo completo»:** se comentó el 2026-10-16 y nadie lo registró. Esto es registrarlo en el RAID, no escalarlo. Tampoco hay dependencia declarada en el acta («Ninguna declarada») aunque el informe del 2026-10-13 lista la dependencia del proveedor del core cooperativo como riesgo abierto.
- **Compromisos vencidos sin acta (Óscar Ramírez, doc. 9, con la misma fecha desde 2026-09-22; Ricardo Salas, fecha 23):** se destraban con una llamada, no escalan.

### A quién alcanza

No se corrió `impact`: ninguno de los dos puntos trae un cambio de fecha con días. No tengo cifra de arrastre a otros proyectos y no la invento. Dependencias con otros proyectos: ninguna declarada en el acta; la del proveedor del core nunca se confirmó con el otro lado.

### Mis hitos por los que pasa

Sin días de cambio no se calcula. Hitos vigentes: Diseño funcional aprobado 2026-10-10 (pendiente, vencido), Ambiente de pruebas certificado 2027-01-26, Integración con el core cooperativo 2027-05-14, Piloto con asociados 2027-08-30.

### De dónde sale esto

- Autoridad no declarada, presupuesto, fechas, sponsor y comité: `00-gobierno/2026-06-14-acta-constitucion.md`.
- Hitos: `10-plan/2026-06-14-cronograma-v1.xlsx`.
- Reprogramaciones del documento 1: `30-reuniones/2026-09-04`, `09-18`, `09-25`, `10-02`, `10-09-comite-semanal.md` y `2026-10-16-notas-reunion.txt`.
- Riesgos abiertos: `20-seguimiento/2026-10-13-informe-avance.md`.
- Riesgo del proveedor: `2026-10-16-notas-reunion.txt`.

**Lo que no sé:** la autoridad del gerente, el costo de las opciones y qué hito depende del documento 1. Los costos de las opciones están marcados «no declarado» porque ningún documento los da.
