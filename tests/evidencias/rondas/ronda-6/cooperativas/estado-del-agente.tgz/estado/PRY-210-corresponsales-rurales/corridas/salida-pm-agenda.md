## Reunión de seguimiento — PRY-210 Corresponsales rurales · 2026-10-30
7 puntos con tiempo y 1 revisión de lo que vence · 42 minutos · 10 personas requeridas

Supuestos que tomé sin que nadie respondiera: la fecha es la del comité configurado (2026-10-30; las notas del 10-16 dicen «en dos semanas», coherente); el tiempo es 45 min porque ni la configuración ni el argumento lo traen; los términos ya estaban vigentes (v1.1, José Francisco Ñáñez, 2026-10-16) y no se pidió nueva aceptación. **Los cálculos de «vencido» son al 2026-10-16**: la agenda se vuelve a correr antes del 10-30. El diff no tiene corrida anterior (es el punto de partida), así que el anexo no puede decir «sin cambios desde»: lista lo abierto que no entró.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea el «documento 1» y salir con una fecha que tenga con qué sostenerse (o con una decisión formulada)** · 10 min · **Andrés Lozano**
> Prometido para el 2026-11-30, y antes para el 11-16, el 11-08, el 10-19 y el 10-02; la primera promesa fue el 2026-09-19. **Cinco reprogramaciones en seis semanas.**
> Fuente: minutas de comité 2026-09-11, 09-18, 09-25, 10-02, 10-09 y notas del 2026-10-16 («no alcanzó», línea 4).
> **Si no se resuelve hoy:** los documentos no dicen de qué depende el entregable; el 11-30 tiene el mismo respaldo que las cinco fechas anteriores. Si el bloqueo excede a la gerente, sale de aquí como `/pm-escalate` (el patrocinador, Rubén Cárdenas, no figura en las asistencias del 10-09 ni del 10-16).

> **[2] Nombrar qué bloquea la «prueba 2» y revisar la carga de quien la tiene** · 10 min · **Javier Hoyos**
> Prometido para el 2026-11-16, y antes para el 11-08, el 10-21 y el 10-10; la primera promesa fue el 2026-09-19. **Cuatro reprogramaciones.**
> Javier tiene hoy **cuatro compromisos abiertos**: prueba 2 (4 reprogramaciones), prueba 10 (2, vence 10-20), fecha 15 (1, vence 11-08) y matriz 22 (sin cambios, 11-02). El patrón es de la persona o del flujo, no de un entregable; la minuta no dice cuál.
> Fuente: minutas 2026-09-11, 09-18, 09-25, 10-02 y 10-09.
> **Si no se resuelve hoy:** se repite la fecha por quinta vez sin causa nombrada.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 (24 días al 10-16; misma fecha repetida cuatro semanas, sin reprogramar) | Entregarlo con acta, o decir por qué no y para cuándo. Fuente: minuta 09-18, abierto en la del 10-09 | 4 |
| Laura Vélez | Validar el ambiente 20 | 2026-10-13 (3 días) | Dijo el 10-09 que ya lo entregó: traer el acta de recibo o reabrirlo. Fuente: minuta 10-02 y 10-09 | 2 |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-15 (1 día) | Las notas del 10-16 no lo mencionan: confirmar la fecha o declarar que no. Fuente: minuta 10-09 | 2 |

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» y darle dueño. Entrada: la revisión con el proveedor de Óscar Ramírez (2026-10-26). En el mismo acto, dueño para los otros dos riesgos del informe del 10-13 (dependencia del proveedor del core; aprobación del reglamento por el Consejo) y las dos incidencias (rotación del desarrollador clave; hallazgo de seguridad): hoy ninguno tiene dueño. Fuente: notas 10-16 l.7; informe de avance 2026-10-13 | Liliana Torres | Se comentó el 10-16 y no se anotó; el acta de constitución declara «Ninguna» dependencia y el riesgo sigue solo en la ficha de estado, sin dueño | 5 |
| Poner fecha a los cuatro compromisos sin ella: Ricardo Salas (aprobar el diseño 5, desde 2026-09-11; el 09-18 dijo que ya lo entregó, sin acta), Carlos Peña (documento 17, desde 10-02), Óscar Ramírez (punto 24, desde 10-09), Laura Vélez (ajuste del presupuesto: «la otra semana» del 10-16, no es fecha). Cada uno, en la sala. Fuente: minutas 09-11, 10-02, 10-09 y notas 10-16 | Cada responsable; Liliana Torres lo registra | No pueden vencer, así que nadie los reclama | 4 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 (hoy; una reprogramación; las notas de hoy no lo mencionan) |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-20 (reprogramado 2 veces; el 10-09 dijo que ya lo entregó, sin acta: pedir el acta) |
| Paula Céspedes | Entregar el punto 8 | 2026-10-21 (reprogramado 2 veces) |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-23 (reprogramado 1 vez; el 10-09 dijo que ya lo entregó, sin acta: pedir el acta) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 (nuevo, notas 10-16) |
| Jorge Medina | Revisar el anexo 11 | 2026-10-30 (el día de la reunión; reprogramado 2 veces) |

Se revisan en bloque, 5 min: cada responsable dice si llega con acta o pide fecha nueva.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| El estado «verde» y el 47 % del informe del 2026-10-13 frente a lo calculado: 3 vencidos sin evidencia, 2 reprogramados 4 y 5 veces, 0 de 4 hitos cumplidos | El estado lo declara la gerente, no se discute en la sala | `/pm-report` (declaración contra evidencia) |
| El hito «Diseño funcional aprobado», vencido el 2026-10-10 sin evidencia (línea base v1, aprobada por el Comité de Crédito) | Cambiar su fecha es un cambio de línea base; la minuta no dice qué diseño falta | `/pm-escalate` o control de cambios, si se decide moverlo |

### Anexo — abiertos que no entran (no hay corrida anterior contra la cual decir «sin cambios»)
- Carlos Peña · Aprobar el diseño 21 — 2026-11-03, sin reprogramaciones.
- Javier Hoyos · Actualizar la matriz 22 — 2026-11-02, sin reprogramaciones.
- Javier Hoyos · Confirmar la fecha 15 — 2026-11-08, una reprogramación (visto en el punto 2).
- Cerrados con acta, no se repasan: anexo 3, ambiente 4, fecha 7, diseño 13, matriz 14, punto 16, prueba 18, anexo 19.

Nada quedó fuera por tiempo: la suma de los puntos (10 + 10 + 8 + 9 + 5 de revisión de lo que vence) es 42 de 45 minutos.

**Después de la reunión:** `/pm-minutes` sobre la transcripción o las notas; los compromisos nuevos entran a `/pm-commitments` con su cita.
