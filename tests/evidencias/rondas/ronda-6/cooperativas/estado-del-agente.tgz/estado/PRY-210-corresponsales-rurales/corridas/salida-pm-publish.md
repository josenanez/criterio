Publiqué la ficha en `/home/claude/banco/ronda-6/cooperativas/espacio/documentos/proyectos/PRY-210-corresponsales-rurales/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 18 campos con dato · 3 sin decir en ninguna parte (producto, autoridad, fase) · declara **verde** al 2026-10-13

**Lo más viejo que va ahí:** identidad, alcance, presupuesto aprobado y fechas, del 2026-06-14 (acta de constitución y cronograma v1), cuatro meses; nada pasa de un año.

**Antes de escribir, revisé:**
- Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.
- Fecha de cierre: `plan.end_date` es 2027-08-30. No hay cronograma más nuevo que el v1, y su último hito (Piloto con asociados) cae en esa misma fecha; coincide con la línea base, sin diferencia.
- La carpeta de gobierno ya existía; no se creó nada.

**Lo que la PMO va a ver primero:** el estado declarado es verde (47 %), y el recálculo lo contradice con cuatro señales: avance declarado 22 puntos por encima de lo que el plan sustenta (0 de 4 hitos cumplidos), hito «Diseño funcional aprobado» vencido hace 6 días (2026-10-10), compromisos vencidos (3) y compromisos reprogramados 4 y 5 veces. La ficha lo marca como declaración tuya, no como evidencia.

**Para que lo sepas:** la ficha no está sellada; se leyó el historial de reuniones, no se declara el proyecto leído entero. La copia es idéntica a la de tu estado; no se agregó ningún campo fuera del esquema.
