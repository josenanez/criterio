Revisé PRY-210 (Corresponsales rurales): no toca barrido (desactivado) ni informe; el comité es el 2026-10-30, a 14 días. Nada venció. Vuelvo el 2026-10-29.
