# Corrida del 2026-10-16 · pm-commitments

1 proyectos · 23 s · 12 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 4 |
| `commitment_overdue` | 3 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `milestone_overdue` | 1 |
| `declared_vs_evidence` | 1 |

Reprogramados: Andrés Lozano (5 veces) y Javier Hoyos (4 veces); vencidos sin evidencia: Óscar Ramírez, Laura Vélez, Ricardo Salas

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-210 Corresponsales rurales · al 2026-10-16

Fuente de las cifras: `portafolio.py compute`. 2 reprogramados (umbral: 3 promesas nuevas), 3 vencidos sin evidencia, 4 sin fecha. La ficha cubre el historial de reuniones (2026-09-04 a 2026-10-16); no se declara el proyecto leído entero.

### Se viene reprogramando

> **Andrés Lozano** · Enviar el documento 1
> Prometido para el 2026-11-30, y antes para el 11-16, el 11-08, el 10-19 y el 10-02; la primera promesa fue el 2026-09-19. **Cinco reprogramaciones** (la última, en las notas del 2026-10-16: «no alcanzó»).
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Javier Hoyos** · Cerrar la prueba 2
> Prometido para el 2026-11-16, y antes para el 11-08, el 10-21 y el 10-10; la primera promesa fue el 2026-09-19. **Cuatro reprogramaciones.**
> **Es un bloqueo que nadie ha nombrado.**

Se pueden formular ambos como decisión para el comité (próximo: 2026-10-30): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 (misma fecha repetida cuatro semanas, sin reprogramar) | 24 días |
| Laura Vélez | Validar el ambiente 20 | 2026-10-13 | 3 días |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-15 | 1 día |

Laura Vélez dijo el 10-09 que ya lo entregó: no hay acta en el expediente. Las notas del 10-16 no mencionan lo de Ricardo Salas.

### Vencen esta semana (próximos 7 días, abiertos)
| Quién | Qué | Para cuándo |
|---|---|---|
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 (hoy) |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-20 (reprogramado 2 veces; el 10-09 dijo que ya lo entregó, sin acta) |
| Paula Céspedes | Entregar el punto 8 | 2026-10-21 (reprogramado 2 veces) |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Ricardo Salas | Aprobar el diseño 5 | 2026-09-11 (el 09-18 dijo que ya lo entregó; sin acta) |
| Carlos Peña | Enviar el documento 17 | 2026-10-02 |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-16 («la otra semana» no es una fecha) |

No pueden estar vencidos; se cuentan aparte para que no desaparezcan.

### Cerrados (con el documento que los cierra)
- Javier Hoyos · Revisar el anexo 3 — 20-seguimiento/2026-10-02-acta-recibo-3.md
- Sandra Gil · Validar el ambiente 4 — 20-seguimiento/2026-09-11-acta-recibo-4.md
- Felipe Arango · Confirmar la fecha 7 — 20-seguimiento/2026-09-18-acta-recibo-7.md
- Felipe Arango · Aprobar el diseño 13 — 20-seguimiento/2026-10-09-acta-recibo-13.md
- Ricardo Salas · Actualizar la matriz 14 — 20-seguimiento/2026-10-02-acta-recibo-14.md
- Felipe Arango · Entregar el punto 16 — 20-seguimiento/2026-10-02-acta-recibo-16.md
- Óscar Ramírez · Cerrar la prueba 18 — 20-seguimiento/2026-10-09-acta-recibo-18.md
- Rubén Cárdenas · Revisar el anexo 19 — 20-seguimiento/2026-10-09-acta-recibo-19.md

### Contexto
El informe de avance del 2026-10-13 declara **verde**; los compromisos vencidos y reprogramados, el hito «Diseño funcional aprobado» vencido el 2026-10-10 (6 días) y el avance declarado de 47 % frente a 0–25 % que sostiene el plan no son coherentes con ese verde. Si algo de esto cambia lo que dice la ficha, `/pm-publish` la deja visible para la PMO.
