# Plan — Corresponsales rurales (PRY-210) · borrador del 2026-10-16
**Desde:** acta de constitución del 2026-06-14 (`00-gobierno/2026-06-14-acta-constitucion.md`) · **Criterio de éxito:** «Corresponsales rurales en producción y medido» (acta). Es una frase, no un criterio verificable: no dice qué se mide, con qué umbral ni quién lo mide.

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo.

**Antes de leer el plan:** este proyecto ya tiene un cronograma v1 (`10-plan/2026-06-14-cronograma-v1.xlsx`) con cuatro hitos y una línea base v1 aprobada el 2026-06-14, y un avance declarado de 47 % (informe del 2026-10-13). Este borrador no la reemplaza ni crea una línea base nueva. Sirve para ver qué sostiene el acta y qué falta.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin nombre:** «Componente 1, Componente 2, Componente 3» | No se puede descomponer por entregable; no hay nada que alguien reciba y acepte. Los tres nodos quedan «sin definir». |
| **Fuera de alcance:** «Lo que otro proyecto cubre» | No dice qué proyecto ni qué cubre. Cualquier discusión de alcance se queda sin referencia. |
| **Objetivo del negocio:** «Entregar corresponsales rurales para Bienestar social» | No dice cuántos, dónde ni para quién. No sirve para decidir qué entra y qué no. |
| **Criterio de éxito sin medida** (ver arriba) | Sin umbral, «medido» no se puede cerrar ni aceptar. Es el vacío más caro. |
| **Autoridad del gerente no declarada** (la ficha lo tiene como no encontrado) | No se sabe qué puede decidir quien planifica y qué debe subir. Patrocinador sí hay: Rubén Cárdenas. |
| **Dependencias: «Ninguna declarada»**, pero el informe del 2026-10-13 abre como riesgos la dependencia del proveedor del core cooperativo y la aprobación del reglamento por el Consejo de Administración | El acta y el informe se contradicen. Un plan sobre «ninguna dependencia» es optimista por construcción. |
| **Producto asociado: «No aplica»** | Nada con qué cruzar el alcance contra requerimientos. |
| **Cierre 2027-08-30 coincide con el hito «Piloto con asociados»** (cronograma v1), pero el criterio de éxito dice «en producción» | Un piloto no es producción. O falta un hito de puesta en producción y de medición, o el criterio y el cierre no hablan de lo mismo. Alguien con autoridad debe decidir cuál. |

Se señala y se sigue. Nada de esto se rellenó.

## WBS
Cada nodo terminal debería ser algo que alguien recibe y acepta. Donde el acta no da con qué hacerlo, el nodo queda sin definir.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | del acta (solo el nombre «Componente 1»); contenido **sin definir** | vacía |
| 2 | Componente 2 | sin definir | del acta (solo el nombre); contenido **sin definir** | vacía |
| 3 | Componente 3 | sin definir | del acta (solo el nombre); contenido **sin definir** | vacía |
| 4 | Diseño funcional aprobado | sin definir (quién aprueba no consta) | cronograma v1, hito con fecha línea base 2026-10-10, estado «en curso», sin evidencia de aprobación | vacía |
| 5 | Ambiente de pruebas certificado | sin definir (quién certifica no consta) | cronograma v1, hito 2027-01-26 | vacía |
| 6 | Integración con el core cooperativo | sin definir | cronograma v1, hito 2027-05-14 | vacía |
| 7 | Piloto con asociados | sin definir | cronograma v1, hito 2027-08-30 | vacía |
| 8 | Puesta en producción y medición | sin definir | **supuesto:** el criterio de éxito del acta lo exige y ningún hito del cronograma v1 lo cubre | vacía |
| 9 | Reglamento aprobado por el Consejo de Administración | sin definir (el Consejo, si es entregable del proyecto) | informe de avance 2026-10-13, como riesgo. **Supuesto:** es una condición del proyecto, no un entregable | vacía |

No se sabe cómo se relacionan los nodos 4 a 7 con los componentes 1 a 3: si son los mismos, si los cruzan o si son aparte. Es la pregunta de estructura más importante del plan.

Los hitos 4 a 7 son hitos, no entregables. Sirven como puntos de control, pero para aceptar algo falta decir qué documento o artefacto prueba cada uno.

## Orden
Sin fechas. Es una propiedad del trabajo.

- 4 (diseño funcional) antes que 5, 6 y 7. **Supuesto:** el cronograma v1 los ordena así, pero no dice si es dependencia técnica o solo secuencia.
- 5 (ambiente de pruebas) antes que 6 y 7. Mismo supuesto.
- 6 (integración con el core) antes que 7 (piloto). Mismo supuesto.
- 7 antes que 8.
- **Sin definir:** de qué nodos depende el nodo 9 (reglamento) y qué nodos bloquea. Tampoco cómo se mapean los componentes 1 a 3 en esta cadena.
- **Sin definir:** qué entrega el proveedor del core y cuándo. Es una dependencia externa que el acta no declara.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son la estructura real del trabajo y los componentes 1 a 3 los cruzan | Si los componentes son entregables aparte, el plan está incompleto y el avance de 47 % no se puede leer contra él. |
| El orden 4 → 5 → 6 → 7 es una dependencia, no solo una secuencia | Si hay paralelismo posible, el cierre del 2027-08-30 se puede sostener con otra estructura. Si hay más dependencias de las vistas, se cae. |
| Falta un nodo de puesta en producción y medición | Si «piloto» ya cuenta como producción, el criterio de éxito está mal redactado; si no, el proyecto cierra sin entregar lo que prometió. |
| El reglamento del Consejo es condición externa al proyecto | Si es entregable propio, hay trabajo sin dueño ni plan. |
| El proveedor del core entrega a tiempo y con el equipo completo | Las notas del 2026-10-16 recogen que podría no llegar con el equipo completo para la siguiente fase y que nadie lo registró. Si se materializa, golpea los nodos 6 y 7. |

Estos pasan al RAID con doliente cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido y nombre de los componentes 1, 2 y 3 | Patrocinador (Rubén Cárdenas), con la gerencia. El acta no lo dice. |
| Qué excluye «lo que otro proyecto cubre» y cuál es ese proyecto | Patrocinador / PMO |
| Medida y umbral de «en producción y medido» | Patrocinador y Bienestar social (área dueña) |
| Quién acepta cada entregable | Patrocinador. No consta ninguna persona aceptante en el acta. |
| Autoridad del gerente al planificar | Patrocinador / Comité de Crédito |
| Dependencias reales (proveedor del core, Consejo de Administración) | Gerencia con el patrocinador |
| Si falta un hito de producción y medición | Patrocinador |

## Proyectos análogos
Ninguno a la vista: la configuración de este proyecto no apunta a una carpeta de fichas de la PMO. Se dice así para no inventar una referencia. Sin análogos no hay comparación de cuánto se corrió un cierre, y no se estima nada por analogía.

## Preguntas para el equipo
Una por cada duración vacía.

1. Componente 1: ¿qué es y cuánto toma?
2. Componente 2: ¿qué es y cuánto toma?
3. Componente 3: ¿qué es y cuánto toma?
4. Diseño funcional aprobado: el hito de línea base era el 2026-10-10 y sigue «en curso» sin evidencia de aprobación. ¿Qué falta para aprobarlo, quién lo aprueba y cuánto toma?
5. Ambiente de pruebas certificado: ¿cuánto toma y quién certifica? (Hay compromisos abiertos de validar ambientes con vencimiento próximo; no se sabe si son de este hito.)
6. Integración con el core cooperativo: ¿cuánto toma y cuánto depende del proveedor del core?
7. Piloto con asociados: ¿cuántos asociados, en qué zonas y cuánto dura?
8. Puesta en producción y medición: ¿existe, o «piloto» ya es el criterio de éxito?
9. Reglamento del Consejo de Administración: ¿cuándo sesiona, qué necesita antes y qué bloquea?

## Para comprometer una fecha falta
Nada de esto está en un documento:

- La **disponibilidad real del equipo**. El informe del 2026-10-13 dice que se perdieron dos semanas por la rotación de un desarrollador clave, y no dice si el reemplazo está.
- La **fecha del proveedor del core** y si llega con el equipo completo (las notas del 2026-10-16 lo ponen en duda).
- El **calendario del Consejo de Administración** para el reglamento.
- La **ventana de certificación** del ambiente de pruebas y el resultado del hallazgo de seguridad abierto (informe 2026-10-13).
- **Una decisión sobre el alcance.** Mientras los componentes no tengan nombre, cualquier fecha es sobre algo indefinido.

La fecha la compromete la gerente, que es un acto de autoridad. Este borrador no la propone.

## Después
Si la gerente aprueba un plan a partir de esto, el siguiente paso es registrarlo como línea base. Ojo: ya existe una v1 del 2026-06-14, así que lo que se apruebe sería una versión nueva que se suma a ella, sin borrarla. Los supuestos pasarían al RAID con doliente.
