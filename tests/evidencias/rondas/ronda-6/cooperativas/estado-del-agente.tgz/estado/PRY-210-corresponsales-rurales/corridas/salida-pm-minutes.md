# Acta — Corresponsales rurales (PRY-210) · 2026-10-16

**Asistieron:** Andrés Lozano, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Óscar Ramírez · **Fuente:** `2026-10-16-notas-reunion.txt` (notas de una persona, no transcripción) · **Ausentes con tema en agenda:** ninguno identificable; las notas no traen agenda. Quienes tienen compromisos abiertos y no estuvieron: ninguno.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se pidió nueva aceptación.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Andrés Lozano | Enviar el documento 1 (notas, l.4: «no alcanzó, se compromete para el 30/11/2026») | 2026-11-30 | **Reprogramado por 5.ª vez.** Promesa original 2026-09-19; fechas: 10-02, 10-19, 11-08, 11-16, 11-30 |
| Óscar Ramírez | Revisión con el proveedor (l.6: «queda para el 2026-10-26») | 2026-10-26 | Nuevo; no hay promesa previa de lo mismo en el historial |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto (l.5: «la otra semana»; eso no es una fecha, queda `no_declarada`) |

Sin fecha en total, contando los de reuniones anteriores: **4** — Laura Vélez (ajuste del presupuesto), Ricardo Salas (aprobar el diseño 5, desde 2026-09-11), Carlos Peña (enviar el documento 17), Óscar Ramírez (entregar el punto 24).

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué hacer con el posible faltante de equipo del proveedor para la siguiente fase | Se «comentó» y no se resolvió nada (l.7) | No consta en las notas |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo» (l.7) | No se atribuye: las notas dicen «se comentó» | Riesgo | **No** en los documentos. Solo aparece en la ficha de estado, a partir de estas mismas notas, sin dueño. Se parece a «Dependencia del proveedor del core cooperativo» (informe del 2026-10-13), pero no es lo mismo: aquel habla de la dependencia, este de la capacidad del equipo. El acta de constitución declara «Ninguna» dependencia. |

## Cerrado en esta reunión
Nada. No se presentó ningún documento.

## Lo que esta reunión contradice
Ningún campo de la ficha (patrocinador, fechas de cierre, comité). Sí queda en tensión, por el recálculo: el informe del 2026-10-13 declara **verde** y 47 %, y el cálculo encuentra 3 compromisos vencidos, 2 reprogramados 4 y 5 veces, el hito «Diseño funcional aprobado» vencido hace 6 días (2026-10-10) y 0 de 4 hitos cumplidos contra 47 % declarado. Es una contradicción de la declaración con la evidencia, no de la reunión.

## Sin resolver de la transcripción
- «30/11/2026»: se normalizó a 2026-11-30 asumiendo día/mes/año; las demás fechas vienen en formato ISO.
- «La otra semana» (Laura Vélez): sin fecha.
- «Próxima reunión en dos semanas»: sin fecha; la configuración tiene el comité en 2026-10-30, coherente pero no dicho en las notas.
- Las notas no mencionan los compromisos vencidos de Óscar Ramírez (documento 9, venció 2026-09-22, 24 días), Laura Vélez (validar el ambiente 20, 2026-10-13) y Ricardo Salas (confirmar la fecha 23, 2026-10-15), ni el de Gustavo Neira (validar el ambiente 12, para hoy). No se sabe si se trataron.

## Recálculo
Vencidos: 3 · Sin fecha: 4 · Reprogramados 3 veces o más: 2 (documento 1, prueba 2).

**Siguiente:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no es necesario por esta acta, porque ningún campo de la ficha cambió.
