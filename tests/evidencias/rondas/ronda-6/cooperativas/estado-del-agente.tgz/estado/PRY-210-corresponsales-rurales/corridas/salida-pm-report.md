# Corresponsales rurales (PRY-210) — semana del 2026-10-10 al 2026-10-16

**Declara el gerente:** — · — · — (en esta corrida nadie declaró estado ni avance; la línea queda en blanco a propósito)
*Última declaración en documentos, no hecha en esta corrida:* verde · 47 % · al 2026-10-13 (hace 3 días), `20-seguimiento/2026-10-13-informe-avance.md`
**Sustento documental:** contradicho — ese verde lo contradice la evidencia; 0 fuentes de evidencia frente a 2 de declaración
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hito vencido, avance declarado frente al plan

## Qué cambió esta semana
Esta es la primera foto del proyecto (`snapshots/2026-10-16.json`): no hay corrida anterior contra la que comparar, y el diff sale vacío por eso, no porque nada se haya movido. No se puede decir qué cambió; lo que sigue es la situación al corte, y la comparación empieza la próxima semana.

## Lo que sigue igual y sigue mal
Sin corrida previa no se puede medir desde cuándo está así cada cosa. Los días son contra la fecha comprometida:

| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño funcional aprobado», sin evidencia | 2026-10-10 | 6 |
| Óscar Ramírez — Enviar el documento 9 (misma fecha repetida cuatro semanas, sin reprogramar y sin acta) | 2026-09-22 | 24 |
| Laura Vélez — Validar el ambiente 20 (el 10-09 dijo que ya lo entregó; sin acta) | 2026-10-13 | 3 |
| Ricardo Salas — Confirmar la fecha 23 (las notas del 10-16 no lo mencionan) | 2026-10-15 | 1 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-08-30 | 2027-08-30 | 0 días |
| Presupuesto aprobado | COP 9.500.000.000 | COP 9.500.000.000 | 0 |

Replanificaciones: 0 — hay una sola línea base (v1, 2026-06-14, Comité de Crédito). Ojo: el cronograma no se ha movido, pero el hito de diseño ya venció sin evidencia y el informe del 10-13 reporta dos semanas perdidas por rotación de un desarrollador clave. La fecha de cierre sigue intacta con atraso ya visible.

Avance: el gerente declaró 47 %; el plan sustenta entre 0 y 25 % (0 de 4 hitos cumplidos). Brecha de 22 puntos por encima de lo que el plan respalda.

### Hitos de las próximas cuatro semanas (hasta 2026-11-13)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno. El siguiente es «Ambiente de pruebas certificado» | 2027-01-26 | 2027-01-26 | — |

Vencido y sin evidencia: «Diseño funcional aprobado», base y vigente 2026-10-10.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 3.546.990.306 (37,3 %) | 2.527.235.531 (26,6 %) | 8.851.807.729 | 5.953.009.694 |

Cifras en COP, al 2026-10-13. Disponible real = aprobado − comprometido. La proyección queda 6,8 % por debajo de lo aprobado.

## Abierto
**Reprogramados:**
- Andrés Lozano — Enviar el documento 1: 5 veces (original 2026-09-19 → 10-02 → 10-19 → 11-08 → 11-16 → 11-30). Supera el umbral de 3.
- Javier Hoyos — Cerrar la prueba 2: 4 veces (original 2026-09-19 → 10-10 → 10-21 → 11-08 → 11-16). Supera el umbral de 3.

**Vencidos sin evidencia:** los tres de la tabla de arriba (Óscar Ramírez 24 días, Laura Vélez 3, Ricardo Salas 1).
**Dichos como entregados, sin acta:** Ricardo Salas (matriz 6, diseño 5), Javier Hoyos (prueba 10), Laura Vélez (ambiente 20). Sin acta no cuentan como cumplidos.
**Sin fecha:** Ricardo Salas — Aprobar el diseño 5; Carlos Peña — Enviar el documento 17; Óscar Ramírez — Entregar el punto 24; Laura Vélez — Mandar el ajuste del presupuesto («la otra semana», que no es fecha).
**RAID sin movimiento:** 3 riesgos y 2 incidencias, ninguno con responsable ni fecha de inicio, así que no se pueden contar días:
- Riesgo: dependencia del proveedor del core cooperativo.
- Riesgo: aprobación del reglamento por el Consejo de Administración.
- Riesgo: el proveedor podría no llegar con el equipo completo (se comentó el 10-16; nadie lo registró).
- Incidencia: dos semanas perdidas por rotación de un desarrollador clave.
- Incidencia: hallazgo de seguridad de la revisión de arquitectura.

**Proveedor:** sin proveedores registrados en la ficha, aunque los riesgos y las notas del 10-16 hablan de uno.

## Lo que necesito de alguien
- Liliana Torres: declarar estado y avance con esta evidencia a la vista (esta corrida no tuvo declaración).
- Óscar Ramírez: el documento 9 lleva 24 días vencido; fecha real o acta.
- Andrés Lozano y Javier Hoyos: un compromiso con 5 reprogramaciones y otro con 4 necesitan decisión, no otra fecha. **Excede al gerente: material de comité** (próximo, 2026-10-30).
- Laura Vélez y Ricardo Salas: acta de lo que dicen haber entregado.
- Quien corresponda: dueño y fecha para los 5 elementos de RAID.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto (`identity.product`, `identity.authority`, `identity.phase`). Sin autoridad, no se sabe quién decide lo que excede al gerente.
**Silencio:** último documento hace 3 días (informe del 2026-10-13) · última reunión hace 0 días (notas del 2026-10-16).
Ninguna de las dos mediciones muestra silencio; el problema es que lo que se dice no tiene acta que lo respalde (0 fuentes de evidencia de 122).

---
*Ficha `records/PRY-210.json`, actualizada el 2026-10-16 (sin sellar: se leyó el historial de reuniones, no el proyecto entero). 3 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12*
