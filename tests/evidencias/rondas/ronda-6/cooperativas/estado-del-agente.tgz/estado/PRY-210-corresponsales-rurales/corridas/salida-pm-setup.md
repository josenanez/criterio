Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.
1. Quién y qué proyecto: Liliana Torres, gerente de PRY-210 · Corresponsales rurales (del acta de constitución).
2. Reunión de seguimiento: semanal, los viernes (así están fechadas las minutas); la próxima, según las notas del 2026-10-16, en dos semanas: 2026-10-30.
3. Dónde guardo lo que encuentro: `estado/PRY-210-corresponsales-rurales`.
4. Términos (versión 1.1), tal cual:

> Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Aceptados por José Francisco Ñáñez, con el sí dado en la instrucción de esta prueba, el 2026-10-16.

## Listo — PRY-210 · Corresponsales rurales

**Lo que miré:** 18 documentos · 6 minutas del comité (2026-09-04 a 2026-10-09, leídas de la más vieja a la más nueva) más las notas de la reunión del 2026-10-16 · 8 actas de recibo · la última reunión es del 2026-10-16. Formatos que no pude leer: ninguno.
**Términos:** aceptados para la versión 0.3.12 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 c5ca81ee804ae819…

La ficha tiene 26 compromisos. Quedó en `estado/PRY-210-corresponsales-rurales/records/PRY-210.json`, sin sellar: leí el historial de reuniones, no el proyecto entero.

### Lo que está abierto, y cuántas veces se ha movido

**Reprogramados 3 veces o más**

| Quién | Qué | Para cuándo | Historial |
|---|---|---|---|
| Andrés Lozano | Enviar el documento 1 | 2026-11-30 | **5 reprogramaciones**. Dicho sin fecha el 2026-09-04; primera fecha 2026-09-19, luego 2026-10-02, 2026-10-19, 2026-11-08, 2026-11-16 y 2026-11-30 (notas del 2026-10-16: «no alcanzó»). |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-16 | **4 reprogramaciones**. Dicho sin fecha el 2026-09-04; primera fecha 2026-09-19, luego 2026-10-10, 2026-10-21, 2026-11-08 y 2026-11-16. |

**Vencidos sin evidencia**

| Quién | Qué | Venció | Días |
|---|---|---|---|
| Óscar Ramírez | Enviar el documento 9 | 2026-09-22 | 24 (la misma fecha repetida en cuatro reuniones, sin acta) |
| Laura Vélez | Validar el ambiente 20 | 2026-10-13 | 3 (el 2026-10-09 dijo que ya lo entregó; no hay acta) |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-15 | 1 |

Citas: `30-reuniones/2026-09-18-comite-semanal.md`, `30-reuniones/2026-10-02-comite-semanal.md` y `30-reuniones/2026-10-09-comite-semanal.md`.

**Otros abiertos con fecha**

| Quién | Qué | Para cuándo | Movimientos |
|---|---|---|---|
| Paula Céspedes | Entregar el punto 8 | 2026-10-21 | 2 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-20 | 2 (el 2026-10-09 dijo que ya lo entregó; no hay acta) |
| Jorge Medina | Revisar el anexo 11 | 2026-10-30 | 2 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-23 | 1 (el 2026-10-09 dijo que ya lo entregó; no hay acta) |
| Gustavo Neira | Validar el ambiente 12 | 2026-10-16 (hoy) | 1 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-11-08 | 1 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-02 | 0 |
| Carlos Peña | Aprobar el diseño 21 | 2026-11-03 | 0 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | 0 (notas del 2026-10-16) |

Un «ya lo entregué» dicho en la reunión no cierra el compromiso: los dejé abiertos hasta que haya acta.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos:
- Ricardo Salas · Aprobar el diseño 5 (desde el 2026-09-11; el 2026-09-18 dijo que ya lo entregó, sin acta).
- Carlos Peña · Enviar el documento 17 (desde el 2026-10-02).
- Óscar Ramírez · Entregar el punto 24 (desde el 2026-10-09).
- Laura Vélez · Mandar el ajuste del presupuesto (2026-10-16, «la otra semana», que no es una fecha).

### Contra lo que declara el informe
El informe del 2026-10-13 declara **verde** y 47% de avance. Contra eso, `compute` levantó: el hito «Diseño funcional aprobado» (2026-10-10) lleva 6 días vencido y sin acta; ningún hito de los 4 está cumplido, y el plan sustenta entre 0% y 25%, a 22 puntos del 47% declarado; además los compromisos vencidos y reprogramados. Presupuesto: comprometido 37,3% y ejecutado 26,6% del aprobado de 9.500.000.000 COP; la proyección al cierre (8.851.807.729 COP) queda 6,8% por debajo del aprobado. El estado lo declaras tú; esto es contra qué.

Las notas del 2026-10-16 mencionan que el proveedor podría no llegar con el equipo completo para la siguiente fase y que nadie lo anotó como riesgo: lo dejé en la ficha, con esa cita, para que decidas si lo registras.

### Qué le falta a tu carpeta
- Actas de recibo de lo que dicen haber entregado Ricardo Salas (diseño 5 y matriz 6), Javier Hoyos (prueba 10) y Laura Vélez (ambiente 20): sin ellas un compromiso cumplido se ve igual que uno incumplido.
- Un cronograma vigente: el único es la v1 del 2026-06-14, con la línea base igual a la vigente en los cuatro hitos, y el hito del 2026-10-10 sigue «en curso».
- Un acta de constitución con alcance real: los componentes se llaman «Componente 1, 2 y 3», sin el límite de decisión del gerente.
- Minutas en lugar de notas sueltas para la reunión del 2026-10-16.

**Cuándo vuelvo:** semanal por la cadencia de tu reunión; la próxima, según las notas, el 2026-10-30, así que preparo la agenda un día antes. Si la reunión sigue siendo cada viernes, dímelo y lo cambio.
