# Corrida · 2026-10-16-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-16T15:09:13 · **Fin:** 2026-10-16T15:09:52 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 23 | 52 | Revisión del acta PRY-200 (2025-12-23): faltan autoridad del gerente, objetivo medible, alcance nombrado, exclusiones, criterio de éxito medible y quién lo mide, supuestos, hitos y cadencia. Dijo que no sabe si hay autoridad delegada, cronograma o replanificación fuera de la carpeta. |

Por señal (`project-charter`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

El acta de PRY-200 existe (del 2025-12-23), pero le faltan varios campos clave, sobre todo la autoridad del gerente.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que volver a registrarlos. La revisión se basa solo en dos documentos: el acta y el informe de avance del 2026-10-12.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no está escrita. No hay límite de monto ni de cambio de alcance para Sandra Gil, así que todo cambio sube al comité. Hay dos incidencias abiertas (la prueba de carga fallida y el ajuste de reglamento) y un riesgo normativo, y ninguna regla dice quién decide.
- **Objetivo de negocio:** el acta solo describe la solución ("Entregar crédito de libranza digital"). No dice qué resultado se busca, así que no se puede juzgar si valió la pena.
- **Alcance y exclusiones:** el alcance son "Componente 1, 2 y 3" sin nombre, y la exclusión es el texto de plantilla "Lo que otro proyecto cubre". Sin nombres no se puede clasificar una solicitud nueva como dentro o fuera del alcance.
- **Criterio de éxito:** "En producción y medido" no tiene métrica ni umbral, y no dice quién mide. El cierre quedaría a discreción.
- **Supuestos, restricciones, hitos y cadencia:** no aparecen, y las dependencias dicen "Ninguna declarada". Con solo fecha de inicio y de cierre no hay contra qué medir el avance.
- **Sin observación:** patrocinador (Jorge Medina), gerente (Sandra Gil), Comité de Tecnología, presupuesto de 6.800.000.000 COP y fechas del 2026-01-02 al 2026-08-13.

**Lo que el acta y el informe no concilian**
- **Fecha vencida:** el cierre del acta (2026-08-13) ya pasó, y el informe declara verde y 42 % sin ninguna replanificación en la carpeta.
- **Comité distinto:** el informe dice que el ajuste lo pidió el Consejo de Administración, pero el acta asigna el proyecto al Comité de Tecnología.

Como el acta quedó sin autoridad declarada, ofrezco llevar esa definición al comité como decisión (el próximo es el 2026-10-30). También puedo pasar al registro RAID el riesgo normativo, la dependencia del reglamento y la falta de supuestos.

La corrida quedó registrada como `2026-10-16-project-charter-1`, con la salida completa guardada en `estado/corridas/salida-project-charter.md`. No sé si existe fuera de la carpeta una autoridad delegada, un cronograma o una replanificación. Verifica cada dato contra la cita del documento.
