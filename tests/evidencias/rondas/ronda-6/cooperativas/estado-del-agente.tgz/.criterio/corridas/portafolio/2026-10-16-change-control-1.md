# Corrida · 2026-10-16-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-16T15:05:34 · **Fin:** 2026-10-16T15:06:11 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 26 | 52 | Solicitud PRY-201 +30 días a salida a producción. Impacto de portafolio: 0 alcanzados (sin dependencias declaradas). No se pudo determinar solicitante, motivo, impacto en alcance/costo ni autoridad aprobadora; no se registró línea base nueva. |

Por señal (`change-control`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Partí de la ficha `estado/records/PRY-201.json`. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

**Qué dice el análisis**
- **Tiempo:** la salida a producción pasa del 2027-01-04 al 2027-02-03 (+30 días). Hoy hay una sola línea base (v1), así que no hay desviación previa. El Piloto con asociados (2026-10-26) queda en el camino y la solicitud no dice si se mueve.
- **Alcance y costo:** la solicitud no declara impacto en ninguno. La proyección deja solo COP 26,2 millones de holgura sobre los COP 1.200 millones aprobados, así que un mes más de equipo probablemente la supera. No puedo cuantificarlo, porque la ficha no trae costo mensual.
- **Portafolio:** el cálculo no alcanza a ningún proyecto, pero la ficha no declara ninguna dependencia. Hay un riesgo, «dependencia del proveedor del core cooperativo», que no está enlazado a ningún proyecto. Un resultado vacío no prueba que no haya efecto.
- **Quién decide:** no se puede determinar. El acta no declara autoridad para aprobar cambios, y ese es el hallazgo de fondo. Por defecto va al Comité de Tecnología.
- **Si no se aprueba:** el proyecto se declara en verde con 74 % de avance, pero la evidencia no lo sostiene.
  - Dos hitos figuran como cerrados sin acta de recibo.
  - Hay un hallazgo de seguridad abierto sin responsable.
  - No hay minutas ni actas de comité.

**Lo que no supe y no inventé:**
- Quién pide el cambio.
- Por qué lo pide.
- Si el piloto se mueve.
- Cuántos días se mueve cada proyecto afectado, si los hay.

**Registro:** no creé una línea base nueva, porque nadie la ha aprobado. La corrida quedó registrada como `2026-10-16-change-control-1`.

El siguiente paso es completar solicitante, motivo, impacto en alcance y costo, y dónde está escrita la autoridad. Después se lleva al Comité de Tecnología. El próximo comité de la PMO es el 2026-10-30.

Archivos en `/home/claude/banco/ronda-6/cooperativas/espacio/estado/corridas/`:
- `salida-change-control.md`
- `2026-10-16-change-control.md`
