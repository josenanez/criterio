# Corrida · 2026-10-16-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-16T15:01:49 · **Fin:** 2026-10-16T15:02:30 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 21 | 52 | Informe de PRY-202: verde declarado contradicho por piloto vencido y 2 hitos sin acta; sin replanificación formal; no sabe producto, autoridad ni fase. |

Por señal (`status-report`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## PRY-202 Core cooperativo — estado al 2026-10-16

El informe sale de la ficha `PRY-202.json`, actualizada el 2026-10-16. Las cifras vienen de `portafolio.py compute`. Los términos v1.1 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16, así que no hubo que registrarlos de nuevo.

**Declara el gerente:** verde, 73 %, al 2026-10-09 (Natalia Ospina). El informe tiene 7 días.
**Sustento documental:** contradicho en parte. Salta la alerta `declared_vs_evidence`.
**Lo que el semáforo no explica:** el hito «Piloto con asociados» lleva 7 días vencido, y dos hitos figuran como cumplidos sin acta.
**Último documento:** 2026-10-09. **Última reunión:** 2026-10-05.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-09 | 2026-10-09 | 0 días, pero la fecha ya pasó y el proyecto sigue en curso |
| Presupuesto (COP) | 18.000.000.000 | proyección 18.103.235.355 | +0,6 %, bajo el umbral del 10 % |

- **Presupuesto:** comprometido 14.468.329.305 (80,4 %), ejecutado 8.652.317.770 (48,1 %), disponible real 3.531.670.695.
- **Avance:** el 73 % declarado queda 2,0 puntos por debajo del rango de 75–100 % que sostiene el plan (3 de 4 hitos).
- **Replanificaciones:** 0 registradas. El informe dice «se reprogramó la salida», pero ningún cronograma ni acta lo respalda.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-03-08 | 2026-03-08 | cumplido (declarado) | ninguna; 222 días sin acta |
| Ambiente de pruebas certificado | 2026-05-19 | 2026-05-19 | cumplido (declarado) | ninguna; 150 días sin acta |
| Integración con el core cooperativo | 2026-07-29 | 2026-07-29 | cumplido | acta de recibo del 2026-10-05, más de dos meses después de su fecha |
| Piloto con asociados | 2026-10-09 | 2026-10-09 | pendiente, vencido 7 días | ninguna |

### Dónde no coincide
- **Verde frente a hito vencido:** el informe del 2026-10-09 dice verde el mismo día en que vencían el piloto y el cierre. A 2026-10-16 siguen en curso.
- **Hitos sin acta:** Diseño funcional y Ambiente de pruebas figuran como cumplidos en el cronograma, sin documento de recibo.
- **Reprogramación sin soporte:** no hay cronograma posterior a la v1 que la formalice.

### Abierto
- **Riesgo:** el proveedor no ha confirmado la fecha de la última entrega (sin responsable).
- **Incidencia:** hallazgo de seguridad abierto desde 2026-10-09 (sin responsable).
- **Compromisos vencidos:** ninguno. Hay uno abierto: Jorge Medina, «Entregar el punto 13», vence el 2026-10-19. No figura entre los asistentes de la minuta.
- **Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- **Campos que no están en los documentos:** producto (el acta dice «No aplica»), autoridad y fase.
- **Gobierno:** patrocinador y gerente son la misma persona, y el comité no incluye a nadie distinto de quien gerencia.
- **Fuentes:** ninguna de las 22 está marcada como evidencia; 2 son declaración y 20 no están marcadas.

### Siguiente paso
La fecha de cierre pasó sin cierre ni replanificación formal. Puedo preparar el punto del comité del 2026-10-30. Si la salida se reprogramó de verdad, puedo preparar también la solicitud de cambio.

---
*criterio-portfolio 0.3.12 · ficha PRY-202 aplicada, del 2026-10-16 · campos inciertos: producto, autoridad, fase · [Términos y nota legal](https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12)*

La corrida quedó registrada como `2026-10-16-status-report-1`. Tardó 21 segundos. El texto de este informe está guardado en `estado/corridas/salida-status-report.md`. El registro de la corrida cuenta 13 proyectos, porque `compute` recalcula todo el portafolio. Tampoco midió los documentos leídos.
