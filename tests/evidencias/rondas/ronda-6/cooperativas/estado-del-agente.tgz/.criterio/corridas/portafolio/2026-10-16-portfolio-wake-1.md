# Corrida · 2026-10-16-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:14:31 · **Fin:** 2026-10-16T15:15:08 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 24 | 52 | Barrido: 76 documentos sin cambios, nada que releer. Citas de PRY-210 sin resolver por posible desajuste de nombre de carpeta, sin verificar. Confirmación mensual no preguntada: nadie para responder. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Hice el barrido de hoy. Revisé 76 documentos y ninguno cambió, así que no recalculé ningún proyecto.

- **Términos:** ya estaban vigentes (versión 0.3.12, aceptados el 2026-10-16 por José Francisco Ñáñez). No hizo falta registrarlos otra vez.
- **Citas de PRY-210 sin resolver:** el índice marca unas 130 citas de PRY-210 como `source_missing`. Los documentos sí existen en `documentos/proyectos/PRY-210-corresponsales-rurales/`; el índice los busca en una carpeta llamada solo `PRY-210`. Parece un desajuste de nombre y no documentos borrados, pero no lo verifiqué ni lo corregí. No escribí en la ficha. Alguien debería revisarlo antes del informe de comité.
- **Peticiones:** no había ninguna pendiente.
- **Confirmación mensual:** también tocaba, pero no la hice porque no hay nadie que responda en esta sesión. No la marqué como hecha, así que vuelve a tocar mañana.
- **Registro:** marqué solo el barrido como hecho. La corrida quedó registrada con su salida en `estado/corridas/salida-portfolio-wake.md`. Tardó 24 segundos sobre 13 proyectos.

La corrida registra 52 hallazgos abiertos, por ejemplo PRY-204 con 10 y PRY-210 con 12; son señales ya existentes, no de hoy. Ninguna cruzó un umbral nuevo en este barrido.

Vuelvo el 2026-10-17. El informe de comité es el 2026-10-30 y se prepara el 2026-10-28.
