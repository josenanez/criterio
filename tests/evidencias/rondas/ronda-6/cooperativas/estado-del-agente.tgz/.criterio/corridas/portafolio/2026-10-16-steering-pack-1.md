# Corrida · 2026-10-16-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:10:52 · **Fin:** 2026-10-16T15:12:33 · **Duración:** 101 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 85 | 52 | Paquete de comité 2026-10-30: 5 decisiones, 4 escalamientos. No hay acta del comité anterior; autoridad de aprobación vacía en los 13 proyectos; motivo y alcance de CC-01/CC-02 no constan. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Preparé el material del comité del 2026-10-30 y dejé la corrida registrada (`2026-10-16-steering-pack-1`). Quedó en `estado/corridas/salida-steering-pack.md`.

Los términos ya estaban vigentes (versión 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo. El paquete usa las 13 fichas del 2026-10-16: 5 decisiones, 4 escalamientos sin decisión asociada y 10 de 13 proyectos con hallazgos. Hay 8 proyectos declarados en verde que la evidencia contradice.

Las cinco decisiones:
1. **Quién aprueba los cambios:** el campo de autoridad está vacío en los 13 proyectos. Recomiendo que el comité apruebe todo cambio de línea base mientras tanto.
2. **PRY-208, CC-01 y CC-02:** las dos solicitudes siguen pendientes y el cronograma v3 ya movió la fecha 161 días sin autorización. Las solicitudes no dicen qué alcance amplían ni por qué. Recomiendo no aprobar hasta que el solicitante lo aclare.
3. **PRY-204, pago a Integración Financiera del Sur:** facturó COP 152.173.835 por encima de lo aceptado, y la proyección de costo supera lo aprobado en 11,2 %. Recomiendo retener esa diferencia hasta que haya acta de recibo.
4. **Dolientes de D-CORE, D-REGL e I-SEG:** son tres ítems compartidos entre proyectos y ninguno tiene responsable.
5. **PRY-200, 202, 203, 207 y 211:** tienen la fecha de cierre vencida. Recomiendo que cada gerente presente una solicitud de cambio con fecha nueva, porque ninguno tiene evidencia de haber cumplido su criterio de éxito.

Lo que no pude llenar:
- **Comité anterior:** no hay ningún acta ni registro, así que la sección de decisiones previas queda vacía por falta de dato.
- **PRY-201:** la solicitud de mover la salida 30 días queda devuelta. No dice quién la pide ni por qué, y el piloto del 2026-10-26 queda en medio.
- **Base contractual:** para retener el pago en la decisión 3 hay que verificar que el contrato lo permita.

En la última corrida el script midió 85 segundos y no midió los documentos leídos.
