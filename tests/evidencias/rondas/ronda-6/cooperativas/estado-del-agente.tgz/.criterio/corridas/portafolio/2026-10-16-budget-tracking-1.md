# Corrida · 2026-10-16-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-16T15:03:59 · **Fin:** 2026-10-16T15:04:41 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 26 | 52 | Presupuesto de PRY-204: proyección 11,2 % sobre el aprobado (umbral 10 %), CT-968 facturado 152.173.835 COP sobre lo aceptado. Dijo que no sabe: composición del comprometido, línea base posterior al acta, evidencia de recibo. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Terminé el informe de presupuesto de PRY-204 y dejé la corrida registrada. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

**Presupuesto de PRY-204, Tarjeta débito para asociados, en COP al 2026-10-16**

| | Monto | % del aprobado |
|---|---|---|
| Aprobado | 6.800.000.000 | 100 |
| Comprometido | 3.543.460.884 | 52,1 |
| Ejecutado | 2.023.984.664 | 29,8 |
| Proyección al cierre | 7.559.606.133 | 11,2 por encima del aprobado |

- **Disponible real:** 3.256.539.116 COP.
- **Alerta de costo:** la proyección supera el umbral de 10 %. El informe de avance del 2026-10-06 lo marca verde y no lo menciona.
- **Facturado sobre lo recibido en CT-968:** la factura excede lo aceptado por 152.173.835 COP. El contrato factura contra acta de recibo firmada y no hay ninguna en la carpeta.
- **Avance:** el informe declara 64 % de avance y 3 de 5 hitos cumplidos. Esos 3 hitos no tienen acta de recibo que los pruebe.
- **Línea base:** no hay solicitudes de cambio registradas, así que el aprobado vigente es igual al original (0 replanificaciones). Eso es por falta de documentos, no porque alguien lo haya confirmado.
- **Sin dato:** de qué se compone el comprometido, porque no concilia con el valor de los dos contratos; además, la autoridad del proyecto y su fase.

Como la proyección excede el aprobado, puedo preparar la solicitud de cambio. Si prefieres el detalle por proveedor, hay que correr `/vendor-tracking PRY-204`.

La salida quedó en `estado/corridas/salida-budget-tracking.md` y la corrida en `estado/corridas/2026-10-16-budget-tracking-1`. La corrida registra 13 proyectos y 52 hallazgos en todo el portafolio, no solo en PRY-204.
