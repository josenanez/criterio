# Corrida · 2026-10-16-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view aportes sociales

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:12:38 · **Fin:** 2026-10-16T15:13:15 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 21 | 52 | Producto de un solo proyecto (PRY-203), sin alertas; se reportó fecha de fin vencida sin señal, datos sin evidencia y 5 proyectos sin producto. No se supo el área dueña de esos 5. |

Por señal (`product-view`): `milestone_met_without_evidence` 19, `declared_vs_evidence` 8, `commitment_overdue` 5, `commitment_undated` 5, `progress_vs_plan` 3, `milestone_overdue` 2, `vendor_deliverable_late` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

# Producto: aportes sociales, al 2026-10-16

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo. Los datos salen de las fichas del estado y del cálculo `compute` de hoy.

**«Aportes sociales» tiene un solo proyecto, PRY-203 Aportes sociales en línea.** En ese caso la vista por producto no aporta más que la ficha del proyecto, así que no armé una sección aparte.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| aportes sociales | 1 (PRY-203) | 0 | 2026-07-25 | COP 800.000.000 | COP 336.456.745 |

- **Señales:** el cálculo no marca ninguna alerta. El proyecto no tiene atraso contra la línea base, ni replanificaciones, ni compromisos vencidos. Lleva 2 días en silencio.
- **Dinero:** las cuatro cifras vienen completas.
  - Ejecutado: 441.454.741 (55,2 %).
  - Comprometido: 42,1 %.
  - Proyección: 767.281.484 (−4,1 % sobre lo aprobado).
  - Disponible real: 463.543.255.
- **Declarado por el gerente:** amarillo, con 36 % de avance al 2026-10-14.
- **Dependencias internas:** ninguna declarada.

**Lo que no cuadra y el cálculo no marca**
- **Fecha de fin vencida:** la fecha de fin vigente es 2026-07-25 y ya pasó, con el avance declarado en 36 %. El cálculo no emitió señal de atraso ni de hito vencido, y no sé por qué sin leer el plan. No inventé una cifra de atraso. Conviene que el gerente confirme si esa fecha sigue vigente.
- **Datos sin evidencia:** ningún dato de la ficha tiene evidencia (2 son declaraciones y 17 no tienen marca). Los campos de identidad y plan vienen de un documento de 2025-05-15, de hace 17 meses, sobre el umbral de 12.
- **Campos que faltan:** la autoridad que aprueba (`identity.authority`) y la fase (`identity.phase`).

**Proyectos sin producto declarado:** PRY-202, PRY-205, PRY-208, PRY-209 y PRY-210. Nadie puede responder por el conjunto al que sirven. El cálculo no entrega su área dueña, así que no la pude llenar. Aparte, PRY-199 declara el producto «PRD-299», que es un código y no un nombre como los demás; vale confirmarlo.

La salida quedó guardada en `estado/corridas/salida-product-view.md`. La corrida quedó registrada como `2026-10-16-product-view-1`: tardó 21 segundos, sobre 13 proyectos, con caso «aportes sociales».
