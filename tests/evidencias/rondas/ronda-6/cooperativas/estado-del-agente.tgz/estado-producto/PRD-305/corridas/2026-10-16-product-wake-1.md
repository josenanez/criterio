# Corrida del 2026-10-16 · product-wake

PRD-305 · 16 requerimientos · 26 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |

Primera corrida, sin corte previo: 16 requerimientos y 1 supuesto con señales abiertas. Sin carpeta de fichas, ninguna traza confirmada. No se releyeron los documentos de descubrimiento ni se contrastó el volumen declarado por falta de medición.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Microcrédito (PRD-305) · 2026-10-16

**Primera corrida: no hay corte anterior**, así que todo lo abierto se cuenta como nuevo. Desde hoy queda el corte y la próxima vez solo se reporta lo que cruce después.

Términos: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 días) | REQ-4513 (Diana Molina) | 168 días, desde 2026-05-01; además sin criterio de aceptación | Que el Comité de producto lo decida o lo descarte | Comité de producto (autoridad, según la configuración) |
| Propuesto sin decidir | REQ-4508 (Liliana Torres) | 114 días, desde 2026-06-24 | Ídem | Comité de producto |
| Supuesto sin verificar (umbral 30 días) | "El proveedor cumple el tiempo pactado" | 73 días | Una evidencia de cumplimiento del proveedor (plazo pactado frente a plazo real); si no existe, tratarlo como riesgo registrado | Óscar Ramírez (gerente) |

### Lo aceptado que no sostiene nada
- **Sin ningún proyecto que lo construya:** los 13 requerimientos aceptados (0 % de trazabilidad). Esto puede deberse a que no tuve la carpeta de fichas (ver abajo).
- **Aceptados sin evidencia de demanda:** REQ-4501, 4502, 4503, 4510, 4511.
- **Aceptados sin doliente:** REQ-4505, 4509, 4510, 4511. Para decidirlos falta primero nombrar quién los pide.
- **Aceptados sin criterio de aceptación:** REQ-4500, 4505, 4515.
- **Evidencia vencida (12 meses):** 11 requerimientos se apoyan en la misma entrevista del 2025-10-03. La afirmación "el cliente lo necesita y hoy no lo tiene" se queda sin sustento fechado.

### Definición y caso de negocio
- La definición no declara criterio de éxito.
- El caso de negocio declara un volumen mensual de 282.429 (2025-09-05). No hay medición contra la cual contrastarlo, así que no puedo decir si coincide.

### Las trazas
No tuve la carpeta de fichas de proyecto, así que **ninguna traza se da por confirmada**. Tampoco puedo decir si algún proyecto (por ejemplo PRY-207 Microcrédito rural) ejecuta este producto.

### Del descubrimiento
No revisé los documentos contra el registro en esta corrida: la revisión se limitó al recálculo de señales.

**Vuelvo el 2026-11-15.**
