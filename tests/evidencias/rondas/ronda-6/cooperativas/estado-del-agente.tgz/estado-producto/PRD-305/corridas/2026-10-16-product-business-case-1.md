# Corrida del 2026-10-16 · product-business-case

PRD-305 · 16 requerimientos · 27 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada (volumen_mensual 282.429, sin serie medida), 0 costos, retorno sin cifra, criterio de exito ausente; 3 supuestos, 10 vacios. No es evaluable: falta costo de construir.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Microcrédito (PRD-305) · borrador del 2026-10-16
**Desde:** la definición del 2025-09-05 y el caso de negocio del 2025-09-05 · **Cifras con fuente:** 1 de 1 (declarada). Costos: 0 de 0, no hay ninguno escrito.

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-16 (versión 1.1, familia 0.3.12); no hizo falta registrarlos de nuevo. Sesión sin interfaz: donde había una pregunta tomé la respuesta sugerida.

**Lo primero: esto todavía es una propuesta, no un caso de negocio que se pueda evaluar.** No hay costo de construir en ningún documento, no hay cifra de retorno y no hay criterio de éxito. Abajo está qué sí hay y qué falta.

## Qué problema resuelve, y para quién
«El segmento Jóvenes no tiene microcrédito.» Segmento: Jóvenes. (`00-definicion/2025-09-05-definicion-producto.md`, 2025-09-05.)
Sustento: una sola entrevista, del 2025-10-03: «Lo necesito y hoy no lo tengo.» Es débil: no consta que el entrevistado sea del segmento, y ya cumplió 12 meses (umbral 12). Ningún documento dice cuántas personas son ni cómo se definió «Jóvenes».
La propuesta de la definición dice solo «Propuesta principal», sin contenido. No hay qué construir descrito.

## Qué se construye
Lo que entra al caso son los requerimientos decididos (13 aceptados). Fuente: `30-decisiones/2026-10-05-comite-producto.md`. Los títulos del registro son genéricos («Requerimiento REQ-45xx»): ningún documento dice qué es cada uno.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4500 | aceptado | Cliente entrevistado (entrevista 2025-10-03); sin criterio de aceptación |
| REQ-4501 | aceptado | **Nadie lo pidió**; doliente Camilo Beltrán |
| REQ-4502 | aceptado | **Nadie lo pidió**; doliente Rubén Cárdenas |
| REQ-4503 | aceptado | **Nadie lo pidió**; doliente Carlos Peña |
| REQ-4504 | aceptado | Cliente entrevistado |
| REQ-4505 | aceptado | Cliente entrevistado; sin doliente; sin criterio de aceptación |
| REQ-4506 | aceptado | Cliente entrevistado |
| REQ-4507 | aceptado | Cliente entrevistado |
| REQ-4509 | aceptado | Cliente entrevistado; sin doliente |
| REQ-4510 | aceptado | **Nadie lo pidió**; sin doliente |
| REQ-4511 | aceptado | **Nadie lo pidió**; sin doliente |
| REQ-4514 | aceptado | Cliente entrevistado |
| REQ-4515 | aceptado | Cliente entrevistado; sin criterio de aceptación |

Fuera del caso: REQ-4508, 4512 y 4513 (propuestos, sin decidir; 4513 lleva 168 días y 4508 114). Toda la evidencia de demanda descansa en la misma entrevista del 2025-10-03. Ninguno de los 13 tiene proyecto que lo ejecute.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 282.429 | **Declarada** | Caso de negocio (Óscar Ramírez) | 2025-09-05 |

Sin base de cálculo ni unidades: no se sabe si son desembolsos, solicitudes o saldo. Además, la cifra tiene 13 meses.
«Retorno esperado en 24 meses» **no es una cifra**: no tiene valor, base ni fecha de partida. No entra a la tabla; va a vacíos.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 282.429 (2025-09-05) | **No hay serie medida** | Nadie mide lo que el caso afirmó. No es contradicción: es una afirmación sin contraste posible. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — |
| Contratos, cotizaciones, costo del equipo | No hay | — |

Este es el primer vacío. Sin costo no hay caso que evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-08-04, sin verificar hace 73 días; umbral 30) | No se puede decir: ningún documento nombra al proveedor ni el tiempo pactado | Sin dueño. Óscar Ramírez como gerente, a confirmar |
| El volumen mensual de 282.429 es alcanzable | Todo ingreso derivado de él cae; no hay ingreso escrito, pero el volumen es la única cifra del caso | Sin dueño; nadie lo mide |
| Jóvenes es un segmento que pagaría por el microcrédito | El problema que justifica el producto no existe | Sin dueño; solo hay una entrevista sin compromiso de pago |

Los dos últimos son **supuestos implícitos** en el razonamiento del caso, no afirmados por nadie. Nota: el supuesto del proveedor está declarado el 2026-08-04 dentro de una definición fechada 2025-09-05; conviene que el autor confirme la fecha.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso de negocio | Óscar Ramírez / finanzas, por confirmar |
| Retorno esperado como cifra (valor, base, fecha de partida) | «Retorno en 24 meses» no se puede verificar | Negocio (Óscar Ramírez) |
| De dónde sale 282.429 y en qué unidad | Sin base la cifra no se puede defender ni medir | Autor del caso de negocio |
| Qué es «microcrédito» aquí (monto, plazo, tasa, canal) | La propuesta no tiene contenido | Gerente de producto |
| Qué pasa si no se hace | El comité no tiene contra qué comparar | Gerente de producto |
| Alternativas consideradas | Ninguna aparece | Gerente de producto |
| Cuántos son «Jóvenes» y cómo se definió el segmento | Dimensiona el mercado | Negocio |
| Qué plan «se mantiene» (comité 2026-10-05) | Ningún documento contiene un plan | Comité de producto |
| Quién decide | «Comité de producto» es una inferencia de la instalación | A confirmar |
| País y norma aplicable (crédito al consumidor, datos personales, información crediticia) | No se puede citar norma sin país ni edades del segmento; va a revisión jurídica | Jurídico |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio escriben criterio de éxito. «Retorno esperado en 24 meses» no tiene métrica, valor ni fecha de corte. Sin esto el producto no se puede cerrar meses después. La única métrica candidata es `volumen_mensual`, que hoy nadie mide.

## Si hay otros productos publicados
No hay ningún otro producto publicado a la vista; no se hizo el cruce de `/product-overlap`. Si se publica otro que afirme `volumen_mensual`, hay que cruzarlo antes de sumar.

## Lo que este documento no hace
No proyecta ingresos, retorno ni ahorro, no calcula rentabilidad ni recuperación, y no recomienda aprobar ni rechazar. Ninguna cifra de referencia del sector entró.

## Después
Los tres supuestos conviene pasarlos al seguimiento con **assumption-tracking** (el del proveedor ya lleva 73 días sin verificar). `/product-charter` no corresponde todavía: falta costo, criterio de éxito y autoridad documentada.
