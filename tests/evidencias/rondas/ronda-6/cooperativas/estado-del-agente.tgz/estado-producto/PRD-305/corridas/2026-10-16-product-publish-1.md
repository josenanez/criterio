# Corrida del 2026-10-16 · product-publish

PRD-305 · 16 requerimientos · 13 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |

No se publicó: no hay carpeta de productos publicados configurada

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-305 (Microcrédito), con corte al 2026-10-16.

**Motivo:** la configuración (`.criterio/producto/PRD-305/config.json`) no define la carpeta de productos publicados, y no existe ninguna `productos/publicados/` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la inventé ni la creé.

**Lo que la ficha llevaría (salida de `publish`, sin escribir):**
- 16 requerimientos (13 aceptados, 3 propuestos) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Jóvenes
- Métrica: volumen_mensual = 282429.0, de `documentos/productos/PRD-305/00-definicion/2025-09-05-caso-de-negocio.md` (2025-09-05)
- Ningún requerimiento tiene proyecto asignado: para `/product-overlap` la ficha solo cruzaría por métrica y segmento.

Cuando la organización acuerde la carpeta, se vuelve a correr este comando.
