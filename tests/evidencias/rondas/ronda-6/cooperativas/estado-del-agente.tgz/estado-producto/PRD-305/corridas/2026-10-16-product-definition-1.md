# Corrida del 2026-10-16 · product-definition

PRD-305 · 16 requerimientos · 29 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |

La evidencia sostiene solo el problema, con una entrevista de 12 meses; propuesta, éxito y quién decide no están dichos; volumen_mensual no tiene serie

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Definición — Microcrédito (PRD-305) · contrastada al 2026-10-16
**Documento:** `00-definicion/2025-09-05-definicion-producto.md` y `00-definicion/2025-09-05-caso-de-negocio.md` · **del** 2025-09-05 · 7 afirmaciones

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-16 (versión 1.1, familia 0.3.12); no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Pero que no haya contradicción aquí se debe a que casi no hay evidencia con la que contradecir (ver más abajo).

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %): la única cifra declarada no tiene medida contra la que compararse.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 282.429 | Caso de negocio, 2025-09-05 | No hay ninguna serie medida de `volumen_mensual`. No es contradicción: nadie está midiendo lo que el caso de negocio afirmó. |

### No está dicho en ninguna parte
- **La propuesta.** La definición dice solo «Propuesta principal», sin contenido. No hay qué contrastar.
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben. El caso dice «Retorno esperado en 24 meses», sin cifra, sin base y sin fecha de partida.
- **Por qué Jóvenes.** El segmento está nombrado, pero ningún documento dice cómo se definió ni cuántas personas son. La entrevista no dice la edad del entrevistado.
- **Qué es «microcrédito» aquí:** monto, plazo, tasa, canal. Ningún documento lo dice.
- **De dónde sale 282.429.** El caso de negocio da la cifra, pero no la base de cálculo ni las unidades (¿desembolsos, solicitudes, saldo?).
- **Qué plan «se mantiene».** El comité del 2026-10-05 decide «Se mantiene el plan», pero ningún documento de la carpeta contiene un plan.
- **Quién decide.** Ningún documento lo dice. «Comité de producto» es una inferencia de la instalación, no una afirmación documentada.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»; ninguno de los 13 requerimientos aceptados tiene proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-08-04) | 73 (umbral 30) | Nombrar al proveedor y el tiempo pactado, y poner el contrato o su cronograma en la carpeta; sin eso no hay contra qué verificarlo. El texto tal como está se puede desmentir solo una vez que esos dos datos existan. |

Una observación: la definición está fechada 2025-09-05 y declara el supuesto el 2026-08-04, es decir que se editó después sin cambiar la fecha del documento. Conviene que el autor lo confirme; el agente no lo resuelve.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene microcrédito | Una entrevista: cliente entrevistado, «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal), ronda 2025-10-03 | 2025-10-03 | Débil. Es una persona que dijo que lo necesita, sin compromiso de pago; no consta que sea del segmento Jóvenes, y no hay nada de quién lo pidió con dinero de por medio. |

No hay ninguna evidencia de más peso (alguien que ya haya pagado, lista de espera, solicitudes rechazadas).

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento no tiene microcrédito | Entrevista del 2025-10-03 | 12 meses (umbral 12): ya cruzó el umbral |

Esa misma entrevista es la única evidencia de 11 de los 16 requerimientos del registro.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Crédito a personas naturales (consumidor financiero) | No declarado en la configuración | No identificada | — | No tengo la norma a la vista |
| Datos personales de solicitantes jóvenes, incluidos menores de edad si el segmento los incluye | No declarado | No identificada | — | No tengo la norma a la vista |
| Información crediticia y retención de documentos | No declarado | No identificada | — | No tengo la norma a la vista |

Esto nombra lo que la definición roza; no dice si el producto cumple. Ni el país ni los años del segmento están escritos, y sin eso no se puede citar la norma. Va a revisión jurídica; no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito: falta.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Problema y para quién:** están escritos (el segmento Jóvenes no tiene microcrédito), pero con una sola entrevista como sustento.
- **Quién decide:** no está escrito en ningún documento.
- **Propuesta:** sin contenido.

### Después
El supuesto del proveedor lleva 73 días sin verificar. Se puede convertir en riesgo con doliente (raid-taxonomy). La definición no está cerrada: no tiene criterio de éxito ni autoridad documentada, así que no corresponde ofrecer `/product-charter` todavía.
