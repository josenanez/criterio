## Trazabilidad — Microcrédito (PRD-305) · al 2026-10-16
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas a la vista: 13 (PRY-199 a PRY-211, en `estado/records`). Ninguna traza se da por confirmada: ningún requerimiento nombra proyecto.

### Decidido y nadie lo está construyendo
Los 13 aceptados del acta del comité de producto del 2026-10-05 (`documentos/productos/PRD-305/30-decisiones/2026-10-05-comite-producto.md`), con «Proyecto que lo ejecuta» = «—». Decidido por: Comité de producto (asistente registrado: Óscar Ramírez). El registro no guarda fecha de decisión por requerimiento (`decided_on` vacío); la columna «Desde» es la fecha en que se planteó, no la de la decisión.

| REQ | Doliente | Desde |
|---|---|---|
| REQ-4500 | Elena Duarte | 2026-06-28 |
| REQ-4501 | Camilo Beltrán | 2026-07-09 |
| REQ-4502 | Rubén Cárdenas | 2026-08-21 |
| REQ-4503 | Carlos Peña | 2026-05-16 |
| REQ-4504 | Elena Duarte | 2026-07-07 |
| REQ-4505 | sin asignar | 2026-04-24 |
| REQ-4506 | Gustavo Neira | 2026-06-04 |
| REQ-4507 | Diana Molina | 2026-05-24 |
| REQ-4509 | sin asignar | 2026-03-20 |
| REQ-4510 | sin asignar | 2026-04-01 |
| REQ-4511 | sin asignar | 2026-06-06 |
| REQ-4514 | Natalia Ospina | 2026-08-26 |
| REQ-4515 | Diana Molina | 2026-08-10 |

Los títulos del registro son genéricos («Requerimiento REQ-45xx»); el acta no dice qué se pidió.
Propuestos, sin decidir (no cuentan aquí): REQ-4508, REQ-4512, REQ-4513 (REQ-4508 y REQ-4513 pasan del umbral de 60 días sin decisión: 114 y 168 días).

### La traza no se confirma
Ninguna: no hay traza declarada que confirmar. Ningún requerimiento dice ser ejecutado por un proyecto.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-207 Microcrédito rural (estado declarado: verde, informe del 2026-10-16) | Campo producto = «microcrédito» (acta de constitución 2025-10-24) | Sí: los 16 REQ tienen proyecto «—» |

Cautela: la ficha nombra el producto por texto, no por código PRD-305, y el cálculo no lo cruzó solo; el cruce lo hice por el nombre. Conviene confirmar con el gerente de PRY-207 que es este producto y no otro de microcrédito. Mientras tanto, PRY-207 está construyendo algo que el registro no tiene en inventario, y los 13 decididos no dicen si es eso.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4500…4507, 4509, 4510, 4511, 4514, 4515 (13) | aceptado | comité 2026-10-05 | — | no | — |
| REQ-4508, 4512, 4513 (3) | propuesto | sin decisión | — | no | — |

La cadena se rompe en el segundo eslabón: la decisión existe y tiene cita; no hay proyecto.

### Sin fichas a la vista
Se omite: las fichas de los 13 proyectos están. Ninguna dice PRD-305 por código; solo PRY-207 lo nombra por texto.
