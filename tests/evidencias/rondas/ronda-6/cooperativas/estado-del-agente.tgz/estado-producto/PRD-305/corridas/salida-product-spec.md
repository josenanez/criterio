> **Borrador del agente, no una especificación aprobada.** Lo cierra el gerente de producto, Óscar Ramírez (la autoridad que figura es el Comité de producto, inferida: ningún documento dice quién decide). Este agente no aprueba.

# Especificación — Microcrédito (PRD-305) · borrador del 2026-10-16

**Resultado en una línea:** con el registro de hoy no hay comportamiento que especificar. Los 13 requerimientos aceptados se llaman «Requerimiento REQ-45xx» y ninguno dice qué pide. Escribir comportamiento sería inventarlo, así que esta especificación solo deja a la vista los vacíos y no rellena ninguno.

*Aviso de sesión:* los términos ya estaban vigentes (v1.1, familia 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16. No hubo nadie a quien preguntar; donde había que elegir se tomó la respuesta sugerida.

## Qué problema resuelve

«El segmento Jóvenes no tiene microcrédito.» (`00-definicion/2025-09-05-definicion-producto.md`).

La definición no dice más:
- **Propuesta:** solo el encabezado «Propuesta principal», sin contenido.
- **Criterio de éxito:** no está. El caso de negocio dice «Retorno esperado en 24 meses» sin cifra (`2025-09-05-caso-de-negocio.md`).
- **«Jóvenes»:** no tiene rango de edad definido.

## Alcance

### Entra (propuesto desde el registro; el alcance lo decide el gerente)

Los 13 requerimientos en estado `aceptado` según el acta del comité del 2026-10-05: REQ-4500 a REQ-4507, REQ-4509, REQ-4510, REQ-4511, REQ-4514 y REQ-4515. Ninguno está `en_construccion`.

**Entran solo como identificadores.** El registro no trae qué hace ninguno. Su título es «Requerimiento REQ-45xx» en el acta, y ni la definición ni el caso de negocio los describen.

### No entra

- **REQ-4508, REQ-4512 y REQ-4513**, en estado `propuesto`, sin decidir. REQ-4513 lleva 168 días y REQ-4508 lleva 114, sobre el umbral de 60 días. REQ-4512 lleva 57. Especificarlos sería escribir el documento antes de la decisión.
- **Todo lo que la propuesta principal pudiera contener.** Está vacía.
- **Diseño, arquitectura, estimación, costo y fecha.** No son de este documento.
- **Cualquier otro producto o segmento distinto de Jóvenes.** La definición solo nombra a Jóvenes.

## Comportamiento

**Sin secciones.** Ningún requerimiento aceptado tiene texto de comportamiento que citar: el acta lista solo ID, doliente, criterio, quién lo pidió, estado, fecha y proyecto. Una sección de comportamiento hoy sería del agente y no del registro. Cuando el gerente aporte qué pide cada REQ, cada sección citará los que cubre.

## Criterios de aceptación

Prueba aplicada: dos personas distintas, mirando lo construido, llegan a la misma respuesta.

| Criterio (texto del acta) | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4501, 4502, 4503, 4504, 4506, 4507, 4509, 4510, 4511, 4514 (10) | **No pasa la prueba.** Dice dónde se verifica, no qué se verifica ni con qué umbral | No determinable: sin métrica, sin umbral, sin fuente |
| — (sin criterio) | REQ-4500, 4505, 4515 (3) | No hay | No hay criterio que medir |

Los 13 quedan sin criterio verificable: 3 sin criterio y 10 con una frase que no discrimina. **No propongo criterios de reemplazo**: sin saber qué pide cada REQ, cualquier cifra sería inventada.

Cuando se escriban, hay que revisar si la organización tiene con qué medirlos. En ningún documento hay una métrica medida para este producto. La única cifra, `volumen_mensual 282.429` del caso de negocio, es declarada, no medida, y no trae unidad.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-08-04). No nombra proveedor ni tiempo pactado | No. Lleva 73 días sin verificar, con umbral de 30 | Óscar Ramírez como gerente; el documento no nombra a otra persona. Primero hay que decir quién es el proveedor |
| `volumen_mensual` = 282.429 (caso de negocio, 2025-09-05): cifra declarada, sin medición ni unidad | No. Sin contraste | Óscar Ramírez, autor del caso de negocio |
| Que «Lo necesito y hoy no lo tengo» (entrevista del 2025-10-03) sostiene estos requerimientos. La nota del registro dice que la entrevista es genérica y no nombra ningún REQ | No. Evidencia de hace 12 meses, una sola fuente | Elena Duarte y los demás dolientes, para sus propios REQ |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Qué pide cada uno de los 13 REQ aceptados** (título y descripción) | No hay nada que especificar ni construir | El doliente de cada uno (ver abajo); coordina Óscar Ramírez |
| **Criterio de aceptación verificable**, para los 13 | Se discute si quedó bien después de construir | Cada doliente propone; el Comité de producto aprueba |
| **Doliente de REQ-4505, 4509, 4510, 4511** («sin asignar»); en 4510 y 4511 tampoco hay quien lo pidiera | Nadie responde por qué existen ni qué significa «bien» | Comité de producto, que los aceptó |
| **Propuesta principal y criterio de éxito** de la definición | No se puede decir si el producto funcionó | Óscar Ramírez |
| **Casos borde.** No se puede definir comportamiento sin comportamiento base. Hay que nombrar al menos: solicitud duplicada, abandono a medio trámite, falla de conexión, solicitud rechazada | Lo decide quien construye, por defecto | Dolientes de los REQ correspondientes (sin asignar para 4505, 4509–4511) |
| **Quién es el «Jóvenes» al que se atiende** (edad mínima, y si incluye a quien no pueda contratar crédito por sí mismo) | El alcance del segmento queda a interpretación y toca el barrido normativo | Óscar Ramírez, con revisión jurídica |
| **Qué debe hacer otro equipo.** Ningún documento lo dice. Hay un proveedor en un supuesto, sin contrato ni acuerdo visible, y «Proyectos que lo construyen: Ninguno declarado» | No hay acuerdo con quien tendría que entregar | Óscar Ramírez, con quien tenga el contrato del proveedor |
| **Proyecto que ejecuta** cada REQ: 0 de 13. La carpeta de fichas de proyecto está vacía, así que es «sin proyecto registrado», no necesariamente «nadie construye» | Decidido, sin quien lo construya | Comité de producto; `/product-charter` cuando haya requerimiento y criterio |
| **Quién y cuándo decidió.** El registro no guarda la fecha de decisión de ningún aceptado. El acta del 2026-10-05 solo dice «Se mantiene el plan» | No se puede reconstruir cuándo se aceptó cada REQ | Óscar Ramírez / secretaría del comité |

### Obligaciones normativas (primer barrido, sin opinar sobre cumplimiento)

**El país no está declarado en ningún documento.** Por eso no cito norma ni artículo: sería inventarlo. Todos los estados son «no tengo la norma a la vista» o «sin resolver».

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Otorgar crédito a personas naturales (microcrédito) | no declarado | Obligaciones de quien atiende consumidor financiero: información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Evaluar y registrar a solicitantes (datos personales y financieros, previsiblemente) | no declarado | Autorización previa y finalidad; encargo a terceros | — | no tengo la norma a la vista |
| Tasas, intereses y comisiones del crédito | no declarado | Posibles topes y reglas de divulgación | — | no tengo la norma a la vista |
| Consulta o reporte a centrales de riesgo | no declarado | Autorización y reporte | — | no tengo la norma a la vista |
| Proveedor tercero (supuesto) | no declarado | Obligaciones de quien encarga tratamiento, y transferencia a otro país si el proveedor está fuera | — | no tengo la norma a la vista |
| Aceptación del contrato de crédito por el joven | no declarado | Firma y prueba del consentimiento; capacidad para contratar según la edad | — | no tengo la norma a la vista |
| Conservación de la información del crédito | no declarado | Retención y trazabilidad | — | no tengo la norma a la vista |

Estos hallazgos son del primer barrido. Tienen que revisarse con jurídica antes de decidir nada. Los que sigan sin resolver deben entrar al registro como restricción del requerimiento o como riesgo con doliente. Cierra: Óscar Ramírez y el área jurídica de la organización; hoy no hay nadie nombrado.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Sin contenido en el registro y sin criterio de aceptación. Doliente: Elena Duarte |
| REQ-4501 | Requerimiento REQ-4501 | Sin contenido; criterio no verificable; nadie lo pidió. Doliente: Camilo Beltrán |
| REQ-4502 | Requerimiento REQ-4502 | Sin contenido; criterio no verificable; nadie lo pidió. Doliente: Rubén Cárdenas |
| REQ-4503 | Requerimiento REQ-4503 | Sin contenido; criterio no verificable; nadie lo pidió. Doliente: Carlos Peña |
| REQ-4504 | Requerimiento REQ-4504 | Sin contenido; criterio no verificable. Doliente: Elena Duarte |
| REQ-4505 | Requerimiento REQ-4505 | Sin contenido, sin criterio y sin doliente |
| REQ-4506 | Requerimiento REQ-4506 | Sin contenido; criterio no verificable. Doliente: Gustavo Neira |
| REQ-4507 | Requerimiento REQ-4507 | Sin contenido; criterio no verificable. Doliente: Diana Molina |
| REQ-4509 | Requerimiento REQ-4509 | Sin contenido; criterio no verificable; sin doliente |
| REQ-4510 | Requerimiento REQ-4510 | Sin contenido; criterio no verificable; sin doliente; nadie lo pidió |
| REQ-4511 | Requerimiento REQ-4511 | Sin contenido; criterio no verificable; sin doliente; nadie lo pidió |
| REQ-4514 | Requerimiento REQ-4514 | Sin contenido; criterio no verificable. Doliente: Natalia Ospina |
| REQ-4515 | Requerimiento REQ-4515 | Sin contenido y sin criterio. Doliente: Diana Molina |

**Cubiertos: 0 de 13.** No es una falla de lectura. El registro no trae qué pide ninguno.

## Después

No ofrezco `/product-charter` todavía. Antes hay que tener cerrados los vacíos de arriba y un criterio de éxito. El primer paso es que cada doliente escriba qué pide su requerimiento. Cuando exista, vuelve a correr `/product-spec`.

---
*Sale del registro de 16 requerimientos (13 aceptados, 3 propuestos) de PRD-305, al 2026-10-16, a partir del acta del comité del 2026-10-05, la definición y el caso de negocio del 2025-09-05. Cubre 0 de 13 aceptados con comportamiento. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12*
