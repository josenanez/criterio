## Listo — Microcrédito (PRD-305)

**Lo que miré:** 4 documentos · 1 de descubrimiento (una entrevista, de 3 líneas) · la definición del 2025-09-05 · el caso de negocio del 2025-09-05 · el acta del comité de producto del 2026-10-05. Lo más reciente es el acta (2026-10-05). No hay carpeta de métricas ni ningún documento sobre un proyecto. Todo se pudo leer; el `.docx` de la entrevista se leyó extrayendo su texto.
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.1 (familia 0.3.12), fecha 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 bbc944aafa669a50…

**Configuración:** `.criterio/producto/PRD-305/config.json` (verificada: completa). Estado en `estado-producto/PRD-305`. Gerente: Óscar Ramírez. Decide: Comité de producto (supuesto mío: ningún documento lo dice).

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Jóvenes no tiene microcrédito» | Un supuesto: una entrevista con un «cliente entrevistado» que dice «Lo necesito y hoy no lo tengo». No dice que sea joven ni que hable de microcrédito | 2025-10-03 (12 meses, en el umbral de envejecer) |
| 16 requerimientos en el comité; 13 aceptados | Acta del comité de producto. La demanda de 11 de ellos remite a esa misma cita | 2026-10-05 |
| Volumen mensual 282.429 | Solo el propio caso de negocio, que se cita a sí mismo como fuente. No hay serie medida | 2025-09-05 |
| «Retorno esperado en 24 meses» | Nada: sin cifra, sin fuente | — |
| «El proveedor cumple el tiempo pactado» | Es un supuesto declarado, sin verificar | declarado el 2026-08-04; 73 días sin verificar |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito.** Ni la definición ni el caso de negocio lo escriben; sin él no hay contra qué cerrar.
- **La propuesta.** La definición dice «Propuesta principal» y nada más.
- **De dónde sale 282.429 al mes**, y quién lo midió. Nadie está midiendo `volumen_mensual`: no hay serie. Es un hallazgo en sí mismo.
- **Cuánto es el retorno** esperado en 24 meses, y sobre qué inversión.
- **Que el segmento sea Jóvenes.** Ninguna entrevista lo dice.
- **Quién es el proveedor y cuál es el tiempo pactado**, que el supuesto da por conocidos.
- **Quién decide.** El acta la firma como asistente solo Óscar Ramírez, el mismo que preparó la definición y el caso de negocio.
- **Ningún proyecto ejecuta nada.** 0 de 13 requerimientos aceptados tienen proyecto (0,0 %); la definición dice «Ninguno declarado». El acta decide «Se mantiene el plan», pero no hay plan escrito.

Del registro de 16 requerimientos (cifras del cálculo, no mías):
- 5 aceptados sin evidencia de que alguien los pidiera: REQ-4501, 4502, 4503, 4510, 4511 (8 de 13 aceptados tienen evidencia, 61,5 %).
- 11 con evidencia vencida o en el límite (la entrevista de 2025-10-03).
- 4 sin doliente: REQ-4505, 4509, 4510, 4511.
- 3 aceptados sin criterio de aceptación: REQ-4500, 4505, 4515. Los que sí lo tienen dicen todos «se verifica en producción», que no permite saber si algo quedó hecho antes de construirlo.
- 2 propuestos sin decidir: REQ-4508 (114 días) y REQ-4513 (168 días).
- Los títulos son «Requerimiento REQ-45xx»: ningún documento dice qué es cada uno.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», 73 días sin verificar. Además, el documento lo fecha el 2026-08-04 dentro de una definición fechada el 2025-09-05: o se editó después sin cambiar la fecha, o hay un error de fecha. Conviene aclararlo.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas. Hoy hay una cita; sin más, una sola frase sostiene 11 requerimientos.
- La serie de `volumen_mensual` con su fuente (no existe la carpeta de métricas).
- Las decisiones del comité con su motivo: con el acta actual un requerimiento descartado se vería igual que uno que nadie miró.
- Si el proyecto PRY-207 (microcrédito rural) tiene algo que ver con este producto: ningún documento lo dice y no lo leí.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién los pidió.
