# Corrida del 2026-10-16 · product-requirements

PRD-305 · 16 requerimientos · 22 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 11 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_owner` | 4 |
| `requirement_without_acceptance` | 3 |
| `requirement_undecided` | 2 |
| `assumption_unverified` | 1 |

5 aceptados sin evidencia, 4 sin doliente, 2 propuestos sin decidir, 13 sin proyecto (fichas vacías)

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Registro — Microcrédito (PRD-305) · al 2026-10-16
16 requerimientos · 13 decididos (13 aceptados, 3 propuestos) · 61.5% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4501 | Requerimiento REQ-4501 | aceptado | Camilo Beltrán |
| REQ-4502 | Requerimiento REQ-4502 | aceptado | Rubén Cárdenas |
| REQ-4503 | Requerimiento REQ-4503 | aceptado | Carlos Peña |
| REQ-4510 | Requerimiento REQ-4510 | aceptado | — (sin doliente) |
| REQ-4511 | Requerimiento REQ-4511 | aceptado | — (sin doliente) |

Ninguno tiene una sola cita de quien lo pidió. Quien los aceptó, según la configuración, es el Comité de producto (gerente: Óscar Ramírez).

### Decidido y nadie lo está construyendo
Los 13 aceptados (REQ-4500 a REQ-4507, 4509, 4510, 4511, 4514, 4515) no tienen proyecto asociado. Ojo: la carpeta de fichas de proyectos (`estado/`) está vacía, así que no se pudo confirmar ninguna traza; es «sin proyecto registrado», no necesariamente «nadie lo construye». «Decidido el» está vacío en los 13: el registro no guarda la fecha de decisión.

### Sin doliente, o con un área en vez de una persona
| REQ | Estado | Dice |
|---|---|---|
| REQ-4505 | aceptado | sin dueño |
| REQ-4509 | aceptado | sin dueño |
| REQ-4510 | aceptado | sin dueño |
| REQ-4511 | aceptado | sin dueño |

### Sin criterio de aceptación
Solo decididos: REQ-4500, REQ-4505, REQ-4515 (aceptados).
(REQ-4513 también carece de criterio, pero está propuesto y no se le exige.)

### Decidido sin documento que lo respalde
El cálculo no emite esta señal y ningún requerimiento trae la fecha de decisión, así que no puedo decir quién decidió ni cuándo. Existe `30-decisiones/2026-10-05-comite-producto.md`; esta corrida no lo leyó para cruzarlo con el registro.

### Lleva meses y nadie lo decide
Umbral: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4513 | Requerimiento REQ-4513 | 168 días (desde 2026-05-01) | Comité de producto |
| REQ-4508 | Requerimiento REQ-4508 | 114 días (desde 2026-06-24) | Comité de producto |

Lo propongo para decidir en el próximo comité (mensual); no se cierran por viejos. REQ-4512 (57 días) aún no cruza el umbral.

### Evidencia vieja
11 requerimientos (REQ-4500, 4504 a 4509, 4512 a 4515 con evidencia): lo más nuevo que los sostiene es la misma entrevista del 2025-10-03 («Lo necesito y hoy no lo tengo.», tema Necesidad principal), de hace 12 meses. Toda la evidencia del registro descansa en esa sola fuente.

### Otros vacíos de la definición
- Supuesto sin verificar hace 73 días: «El proveedor cumple el tiempo pactado» (umbral 30).
- Cifra declarada sin contraste: volumen_mensual 282,429 (caso de negocio, 2025-09-05), sin medición.
- Criterio de éxito de la definición: no dicho en ninguna parte.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

Nada descartado ni entregado: es un registro que solo crece.
