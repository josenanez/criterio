# Acta de constitución — Microcrédito · REQ-4500 · borrador del 2026-10-16
**Producto:** PRD-305 Microcrédito · **Requerimientos:** REQ-4500

> **Verificación previa (paso 1): REQ-4500 no cumple todo lo que el acta exige.** Sesión sin interfaz: no hubo a quién preguntar, así que tomé la respuesta sugerida —seguir marcando cada faltante como vacío del acta, sin rellenarlo—.
> - **Aceptado:** sí. «aceptado» desde 2026-06-28 (`documentos/productos/PRD-305/30-decisiones/2026-10-05-comite-producto.md`, fila REQ-4500).
> - **Criterios de aceptación: FALTAN.** El acta del comité pone «—». Sin ellos no hay criterio de éxito contra el cual juzgar el cierre.
> - **Evidencia de demanda: débil.** Una cita genérica de «Cliente entrevistado» (`10-descubrimiento/2025-10-03-entrevistas.docx`): «Lo necesito y hoy no lo tengo.» Tema «Necesidad principal». No nombra este requerimiento ni qué se necesita.
> - **Autoridad: NO DECLARADA.** Ningún documento dice quién decide; «Comité de producto» es una inferencia de la instalación (`estado-producto/PRD-305/producto.json`, `identity.authority`, estado «inferred»).

## Qué problema resuelve
«El segmento Jóvenes no tiene microcrédito.» (`00-definicion/2025-09-05-definicion-producto.md`, «El problema»). Es el problema del producto; **el registro no dice qué parte resuelve REQ-4500**: su título es el genérico «Requerimiento REQ-4500» y no hay descripción en ningún documento.

## Criterio de éxito
**Vacío.** REQ-4500 no tiene criterios de aceptación. La definición tampoco escribe criterio de éxito, y el caso de negocio dice solo «Retorno esperado en 24 meses» sin cifra (`00-definicion/2025-09-05-caso-de-negocio.md`). No hay nada que verificar.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4500 | «Requerimiento REQ-4500» (sin título real ni descripción) | Cita genérica de «Cliente entrevistado», 2025-10-03, que no menciona este requerimiento. Doliente: Elena Duarte. |

### No entra
Esta acta se pidió solo para REQ-4500. Los demás no entran **porque no se pidieron aquí**; no hay documento que los excluya por una razón de fondo.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4501 a REQ-4507, REQ-4509 a REQ-4511, REQ-4514, REQ-4515 (aceptados) | «Requerimiento REQ-45xx» | No incluidos en esta invocación. Si pertenecen al mismo proyecto, hay que decirlo antes de firmar. |
| REQ-4508, REQ-4512, REQ-4513 (propuestos) | «Requerimiento REQ-45xx» | Siguen en estado «propuesto»: sin decisión del gerente de producto no entran a ningún acta. |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no dicho. Este comando propone, no nombra; quien tenga la autoridad lo asigna. (Óscar Ramírez es el gerente del *producto*, no del proyecto.)
- **Comité:** «Comité de producto» — inferido, no declarado (ver arriba). Único asistente en el acta del 2026-10-05: Óscar Ramírez.
- **Autoridad del gerente del proyecto:** no dicha. Es el campo que más cuesta después.
- **Proyecto que ejecuta REQ-4500:** ninguno («—» en el acta del comité; «Ninguno declarado» en la definición).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (`definicion-producto.md`, declarado el 2026-08-04) | No. Lleva 73 días sin verificar, sobre un umbral de 30. No nombra proveedor ni tiempo pactado. | **Sin doliente.** Hay que nombrar uno en la firma. Ojo: el documento lo pone a nivel de producto, no de REQ-4500; si el proyecto depende del proveedor, es riesgo del proyecto. |

REQ-4500 no declara supuestos propios.

## Restricciones normativas sin resolver
**El país no está declarado en ningún documento**, así que no cito norma ni artículo: sería inventarlo. Primer barrido del 2026-10-16 (de la corrida de `product-spec`), sin opinar sobre cumplimiento:

| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Otorgar crédito a personas naturales | Obligaciones hacia el consumidor financiero: información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Evaluar y registrar solicitantes (datos personales y financieros) | Autorización previa, finalidad, encargo a terceros | — | no tengo la norma a la vista |
| Tasas, intereses y comisiones | Posibles topes y reglas de divulgación | — | no tengo la norma a la vista |
| Consulta o reporte a centrales de riesgo | Autorización y reporte | — | no tengo la norma a la vista |
| Proveedor tercero (supuesto) | Encargo de tratamiento; transferencia a otro país si está fuera | — | no tengo la norma a la vista |
| Contrato de crédito aceptado por un joven | Prueba del consentimiento; capacidad para contratar según la edad | — | no tengo la norma a la vista |
| Conservación de la información | Retención y trazabilidad | — | no tengo la norma a la vista |

Hay que revisarlos con jurídica; hoy no hay nadie nombrado. No se sabe cuáles tocan REQ-4500, porque no se sabe qué pide.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4500 | El cierre no se puede juzgar meses después: «bien» lo define quien construye | Elena Duarte (doliente) propone; Comité de producto aprueba |
| Qué pide REQ-4500 (título y descripción) | Se firma un proyecto sin objeto | Elena Duarte |
| Evidencia de demanda específica | La demanda es una frase genérica; no sustenta este requerimiento | Óscar Ramírez / Elena Duarte |
| Criterio de éxito del producto y «Propuesta principal» | No se puede decir si el proyecto sirvió | Óscar Ramírez |
| Autoridad del gerente del proyecto (y quién decide) | El gerente escala todo o no escala nada | Quien firma el acta |
| Patrocinador y gerente del proyecto | Nadie responde por el proyecto | Quien tenga la autoridad para asignarlos |
| Doliente del riesgo «proveedor cumple el tiempo» | El supuesto pasa a riesgo sin dueño | Quien firme el acta |
| Presupuesto aprobado e hitos | No hay contra qué medir | Quien firme el acta |
| País y revisión jurídica | Las obligaciones normativas siguen sin norma citada | Óscar Ramírez con jurídica |

**Mi lectura:** firmar hoy es firmar un acta con cinco campos esenciales vacíos. Recomiendo cerrar primero los criterios de aceptación y la autoridad. La decisión es de quien firma.

---
**Esto es un borrador.** Lo firma quien tenga la autoridad —no está dicho quién—. **No creé la ficha del proyecto** (paso 6): la ficha se crea después de la firma, y `declared` quedará vacío por diseño.

**Qué sigue:** quien firme y asigne al gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando el gerente publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si su producto se está construyendo sin tener que preguntar.
