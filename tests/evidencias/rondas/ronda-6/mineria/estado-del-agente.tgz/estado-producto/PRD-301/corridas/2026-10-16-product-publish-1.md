# Corrida del 2026-10-16 · product-publish

PRD-301 · 14 requerimientos · 12 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 7 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_owner` | 5 |
| `requirement_without_acceptance` | 1 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

No se publicó: la configuración no define carpeta de productos publicados

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-301 (Alerta de taludes), con corte al 2026-10-16.

**Motivo:** la configuración (`.criterio/producto/PRD-301/config.json`) no define una carpeta de productos publicados. `paths` solo trae `documents` y `state`. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No escribí ni creé ninguna carpeta.

**Lo que habría llevado (calculado, no escrito en ningún sitio):**
- 14 requerimientos (13 aceptados, 1 propuesto) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Segmento Mantenimiento
- Métrica: `volumen_mensual`, declarada en 169380.0, según `documentos/productos/PRD-301/00-definicion/2026-06-01-caso-de-negocio.md` (2026-06-01)

**Para que otro gerente lo sepa antes de cruzar:** ningún requerimiento está enlazado a un proyecto (0 de 14 trazados). La ficha no daría ninguna coincidencia por proyecto compartido.

**Aviso sobre la cifra:** el tablero de métricas del 2026-10-08 mide 106047.0 contra los 169380.0 declarados, un 37.4 % por debajo (umbral configurado: 20 %). La ficha publicaría la cifra declarada, no la medida.

**Términos:** vigentes, aceptados por José Francisco Ñáñez el 2026-10-16. No hubo que registrarlos de nuevo.

**Pendiente:** definir la carpeta de productos publicados con la organización y añadirla a la configuración.
