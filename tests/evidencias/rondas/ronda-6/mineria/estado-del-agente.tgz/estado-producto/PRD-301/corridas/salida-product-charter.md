Términos: ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-16 (versión 0.3.12, términos 1.1); no hubo que registrarlos de nuevo.

Verificación previa (requirement-record): REQ-4100 está **aceptado** (comité 2026-10-12), pero **le faltan dos de los cuatro requisitos**: no tiene evidencia de demanda con cita, y la definición no declara la autoridad. Respuesta sugerida tomada (sesión sin interfaz): seguir sin ellos, marcados como vacíos del acta, sin rellenarlos.

# Acta de constitución — Alerta de taludes (REQ-4100) · borrador del 2026-10-16
**Producto:** PRD-301 · Alerta de taludes · **Requerimientos:** REQ-4100

## Qué problema resuelve
De la definición del producto: "El segmento Mantenimiento no tiene alerta de taludes." (`00-definicion/2026-06-01-definicion-producto.docx`, 2026-06-01).
**De REQ-4100 en particular no se sabe nada:** ningún documento dice su problema. El acta del comité lo titula "Requerimiento REQ-4100", que es solo el identificador (`30-decisiones/2026-10-12-comite-producto.md`).

## Criterio de éxito
- Del requerimiento: "se verifica en producción" (comité 2026-10-12). **No es verificable tal cual:** no dice qué se mide, con qué umbral ni quién lo certifica. Se registra, pero no sirve para juzgar el cierre meses después.
- A nivel de producto: **no está dicho en ningún documento** (`success` sin encontrar).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 (sin descripción) | **Ninguna con cita.** Quién lo pidió: "—" en el acta del comité. Ver vacíos. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4101 a REQ-4113 | Sin descripción en las fuentes | No se pidieron en este acta (solo REQ-4100). Esto no es un juicio sobre ellos: nadie los ha excluido, simplemente no vienen en este argumento. REQ-4111 está además solo "propuesto" (no puede entrar a un acta). |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no dicho. Mauricio Pérez es el gerente del **producto** (definición, 2026-06-01); no hay documento que lo nombre gerente de un proyecto. Asignarlo es decisión de quien tiene la autoridad.
- **Comité:** Comité de producto (acta 2026-10-12; asistente registrado: Mauricio Pérez).
- **Autoridad del gerente:** **no declarada en la definición.** La ficha del producto toma "Comité de producto" del acta que lo emite, con la nota: "El acta no dice quién decide… Confirmar con el gerente". Quién aceptó REQ-4100 tampoco consta (`decision.who` vacío; aceptado desde 2026-05-16).
- **Doliente de REQ-4100:** Sandra Gil (acta del comité).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-08-23, definición) | No. Lleva sin verificar más de 30 días (umbral configurado) | Por asignar: el gerente del proyecto. Se registra como riesgo con doliente. Ojo: la definición no dice qué proveedor ni qué tiempo se pactó. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Sin barrido hecho | — | — | Ningún documento permite decir si la alerta de taludes toca una obligación normativa; no se ha hecho el barrido y no se opina sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Evidencia de demanda de REQ-4100 con cita. La única cita de demanda del producto ("Lo necesito y hoy no lo tengo", entrevista del 2025-10-06) es de hace 12 meses, es general del producto y no está atada a REQ-4100 | El proyecto arranca sobre una necesidad que nadie ha demostrado para este requerimiento | Mauricio Pérez / Sandra Gil |
| El problema de REQ-4100 (qué resuelve) | No hay forma de decidir qué entra o qué es "terminado" | Sandra Gil (doliente) |
| Autoridad del gerente del proyecto no declarada | El gerente no sabrá qué puede decidir: escalará todo o no escalará nada | Comité de producto |
| Criterio de éxito verificable (el actual es circular) | El cierre no se podrá juzgar | Sandra Gil y el comité |
| Quién decidió aceptar REQ-4100 (aceptado desde 2026-05-16; el acta del 2026-10-12 solo dice "Se mantiene el plan") | La decisión de qué se construye no está atribuida a una persona | Mauricio Pérez |
| Propuesta de la definición vacía ("Propuesta principal", marcador sin contenido) | No consta qué se va a construir | Mauricio Pérez |
| Patrocinador y gerente del proyecto | Sin doliente del proyecto | Quien tenga la autoridad |
| Cifra del caso de negocio: declarado 169.380 de volumen mensual (2026-06-01) vs. medido 106.047 (tablero, 2026-10-08): **37,4 % por debajo, sobre el umbral del 20 %** | El caso que justifica el proyecto sobreestima la base | Mauricio Pérez (dueño del caso) |
| Retorno esperado: "Retorno esperado en 24 meses", sin cifra | No hay presupuesto ni retorno contra los cuales medir. El acta no declara presupuesto | Mauricio Pérez |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre el producto (por confirmar: el Comité de producto). **La ficha del proyecto NO se ha creado**: se crea solo después de la firma, y el campo `declared` (el estado) queda siempre sin llenar: lo declara el gerente del proyecto, no este agente.

## Qué sigue
El gerente del proyecto —quien se designe— instala `criterio-project` y corre primero `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza.
