# Corrida del 2026-10-16 · product-trace

PRD-301 · 14 requerimientos · 28 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 7 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_owner` | 5 |
| `requirement_without_acceptance` | 1 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

13 requerimientos aceptados sin proyecto; no hay fichas a la vista, ninguna traza confirmada

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Alerta de taludes (PRD-301) · al 2026-10-16
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

**Términos:** vigentes y ya aceptados (v1.1, José Francisco Ñáñez, 2026-10-16); no hubo que registrarlos de nuevo.

### Decidido y nadie lo está construyendo
Los 13 requerimientos aceptados tienen la columna «Proyecto que lo ejecuta» en «—» en el acta del comité del 2026-10-12 (`documentos/productos/PRD-301/30-decisiones/2026-10-12-comite-producto.md`). El acta no dice quién decidió cada uno: el campo «Por quién» está vacío en los 13. La única decisión escrita en el acta es «Se mantiene el plan».

| REQ | Título | Aceptado desde | Por quién | Doliente |
|---|---|---|---|---|
| REQ-4109 | Requerimiento REQ-4109 | 2026-04-08 | no consta | sin asignar |
| REQ-4103 | Requerimiento REQ-4103 | 2026-04-12 | no consta | Laura Vélez |
| REQ-4106 | Requerimiento REQ-4106 | 2026-04-20 | no consta | sin asignar |
| REQ-4105 | Requerimiento REQ-4105 | 2026-04-29 | no consta | Felipe Arango |
| REQ-4100 | Requerimiento REQ-4100 | 2026-05-16 | no consta | Sandra Gil |
| REQ-4102 | Requerimiento REQ-4102 | 2026-05-31 | no consta | Natalia Ospina |
| REQ-4112 | Requerimiento REQ-4112 | 2026-06-07 | no consta | Beatriz Cuéllar |
| REQ-4113 | Requerimiento REQ-4113 | 2026-06-12 | no consta | sin asignar |
| REQ-4101 | Requerimiento REQ-4101 | 2026-07-03 | no consta | María Restrepo |
| REQ-4104 | Requerimiento REQ-4104 | 2026-07-27 | no consta | Óscar Ramírez |
| REQ-4107 | Requerimiento REQ-4107 | 2026-08-06 | no consta | sin asignar |
| REQ-4110 | Requerimiento REQ-4110 | 2026-08-25 | no consta | Mauricio Pérez |
| REQ-4108 | Requerimiento REQ-4108 | 2026-08-26 | no consta | sin asignar |

Lleva más de seis meses sin proyecto el REQ-4109 (aceptado hace 191 días). REQ-4111 sigue «propuesto» desde 2026-05-02 (167 días) y no cuenta como decidido.

### La traza no se confirma
Ningún requerimiento declara un proyecto, así que no hay traza que confirmar ni que desmentir. Esta tabla queda vacía.

### Lo que un proyecto construye y el registro no tiene
No se puede evaluar: no hay fichas de proyectos a la vista.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4100 a REQ-4110, REQ-4112, REQ-4113 | aceptado | acta del 2026-10-12, fecha «desde» propia de cada uno; autor no consta | ninguno | no | ninguno |
| REQ-4111 | propuesto | sin decisión | ninguno | no | ninguno |

Cadena rota en el primer eslabón siguiente a la decisión: la decisión tiene cita (el acta), pero no hay proyecto que la siga.

### Sin fichas a la vista
No se encontró ninguna ficha de proyecto en la carpeta de trabajo, y tampoco se recibió una carpeta de fichas. Por eso ninguna traza se da por confirmada y la vuelta (proyectos que construyen algo que el registro no nombra) no se pudo hacer. La cadena hasta la decisión sí está armada.

### Aparte, lo que el cálculo marcó sobre estos mismos requerimientos
Son señales del registro, no de la traza; se anotan para no perderlas.
- Aceptados sin evidencia de demanda: REQ-4100, 4102, 4103, 4104, 4108, 4113.
- Con evidencia vencida (entrevistas del 2025-10-06, 12 meses): REQ-4101, 4105, 4106, 4107, 4109, 4110, 4112.
- Sin doliente: REQ-4106, 4107, 4108, 4109, 4113.
- Sin criterio de aceptación: REQ-4105.
- Definición: el caso de negocio declara un volumen mensual de 169.380 y el tablero del 2026-10-08 mide 106.047 (37,4 % por debajo, umbral 20 %). El supuesto «El proveedor cumple el tiempo pactado» lleva 54 días sin verificar.

**Siguiente paso:** el filtro se corre otra vez cuando haya fichas. Para los 13 aceptados, `/product-charter` solo aplica al que ya esté listo para ser proyecto. REQ-4106, 4107, 4108, 4109 y 4113 no lo están: no tienen doliente.
