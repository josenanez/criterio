# Caso de negocio — Alerta de taludes (PRD-301) · borrador del 2026-10-16
**Desde:** la definición del 2026-06-01 y el caso de negocio del 2026-06-01 · **Cifras con fuente:** 1 de 2 (la cifra de volumen tiene fuente; «retorno esperado» no trae cifra, así que no entra como cifra)

> Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Este documento arma estructura y trazabilidad; no produce cifras ni recomienda aprobar o rechazar.

## Qué problema resuelve, y para quién
«El segmento Mantenimiento no tiene alerta de taludes.» Para el segmento Mantenimiento. (00-definicion/2026-06-01-definicion-producto.docx, 2026-06-01).
La única evidencia es una entrevista a un cliente sin nombre: «Lo necesito y hoy no lo tengo» (10-descubrimiento/2025-10-06-entrevistas.md, 2025-10-06). No menciona el segmento Mantenimiento.

## Qué se construye
La definición no dice qué se propone: «Propuesta principal» es un marcador sin contenido.
Requerimientos decididos: 13 aceptados, ninguno con proyecto que lo ejecute. Se listan los que tienen cita de quien lo pidió; los otros 6 no entran al caso hasta tenerla. (30-decisiones/2026-10-12-comite-producto.md, 2026-10-12)

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4101 | aceptado (desde 2026-07-03) | «Cliente entrevistado» (entrevista 2025-10-06, que no nombra el requerimiento) |
| REQ-4105 | aceptado (desde 2026-04-29); sin criterio de aceptación | «Cliente entrevistado», ídem |
| REQ-4106 | aceptado (desde 2026-04-20); sin doliente | «Cliente entrevistado», ídem |
| REQ-4107 | aceptado (desde 2026-08-06); sin doliente | «Cliente entrevistado», ídem |
| REQ-4109 | aceptado (desde 2026-04-08); sin doliente | «Cliente entrevistado», ídem |
| REQ-4110 | aceptado (desde 2026-08-25) | «Cliente entrevistado», ídem |
| REQ-4112 | aceptado (desde 2026-06-07) | «Cliente entrevistado», ídem |

Aceptados sin cita de quien los pidió (fuera de la tabla): REQ-4100, 4102, 4103, 4104, 4108, 4113. REQ-4111 sigue propuesto (167 días, umbral 60).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| Volumen mensual | 169.380 | Declarada | Caso de negocio, Mauricio Pérez | 2026-06-01 |
| Volumen mensual | 106.047 | Medida | Tablero de métricas, bodega de datos | corte 2026-10-08 |
| Retorno esperado | «en 24 meses», sin monto | — (no es una cifra) | Caso de negocio | 2026-06-01 |
| Cálculo o base de 169.380 | — | Supuesta (nadie la ha escrito) | — | — |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 169.380 | 106.047 | Declarada por encima de la medida en 37,4 % (umbral 20 %). Caso de negocio 2026-06-01 vs. tablero con corte 2026-10-08 |

La serie medida tiene un solo punto: no se puede decir si el volumen bajó o nunca llegó a lo declarado. El comité del 2026-10-12 decidió «Se mantiene el plan» sin tratar la diferencia.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir el producto | **No está en ningún documento de PRD-301** | — |
| Candidato, sin confirmar: presupuesto aprobado de PRY-204 «Monitoreo de taludes» | 3.300.000.000 COP aprobado; 1.741.956.167 ejecutado; proyección al cierre 3.081.945.482 | PRY-204, acta de constitución 2026-01-27 e informe de avance 2026-10-13 |

Sobre el candidato: el acta de PRY-204 dice «Producto asociado: alerta de taludes», pero con área dueña Seguridad y Salud, mientras PRD-301 es del segmento Mantenimiento, y la definición de PRD-301 dice «Proyectos que lo construyen: Ninguno declarado». El vínculo es solo por nombre. No lo cuento como costo del producto hasta que el gerente lo confirme (`/product-trace`).

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-08-23, sin verificar hace 54 días; umbral 30) | Sin dato en ningún documento: ni el plazo ni el proveedor están escritos | Mauricio Pérez, contra contrato o cronograma de entregas |
| Que 169.380 es el volumen que el producto atenderá (implícito, sin base escrita) | El caso se apoya en una cifra 37,4 % sobre lo medido | Mauricio Pérez / dueño de la bodega de datos |
| Que Mantenimiento es el segmento con el problema (implícito; la entrevista no lo dice) | El caso apunta al segmento equivocado | Mauricio Pérez |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (primer vacío) | Sin él no hay caso de negocio que evaluar: hay una propuesta | Mauricio Pérez con el proyecto/proveedor que lo construya |
| Qué se propone | La definición dice solo «Propuesta principal» | Mauricio Pérez |
| Monto y base del retorno | «Retorno esperado en 24 meses» no se puede medir ni contrastar | El negocio (Mauricio Pérez) |
| Base de los 169.380 | No se puede defender ni corregir la brecha | Mauricio Pérez |
| Qué pasa si no se hace; alternativas consideradas | No están en ningún documento | El negocio |
| Quién decide | El acta no lo dice; se tomó al Comité de producto (a confirmar) | Mauricio Pérez |
| Vínculo con PRY-204 | Define si 3.300 millones COP son costo de este producto | Mauricio Pérez |

## Cómo se sabrá si funcionó
No está declarado: ningún documento escribe un criterio de éxito para PRD-301. Sin él el producto no se puede cerrar meses después. (PRY-204 tiene el suyo: «Monitoreo de taludes en producción y medido», pero es del proyecto, no del producto.) Falta además fecha de corte y métrica; la única métrica con serie es volumen_mensual.

## Si hay otros productos publicados
Revisados los 10 productos con documentos (PRD-299 a PRD-309, salvo el propio): ninguno afirma volumen_mensual = 169.380 ni menciona taludes; sus cifras declaradas son distintas (p. ej. 120.000, 268.427, 195.120). No se detecta doble conteo con las cifras a la vista. Único cruce: PRY-204, ya citado arriba.

## Después
Ofrezco pasar los tres supuestos a `assumption-tracking` (el del proveedor ya lleva 54 días). `/product-charter` aún no aplica: faltan costo, propuesta y criterio de éxito.
