# Corrida del 2026-10-16 · product-definition

PRD-301 · 14 requerimientos · 29 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 7 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_owner` | 5 |
| `requirement_without_acceptance` | 1 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

La evidencia sostiene solo la necesidad general (1 entrevista de hace 12 meses); volumen declarado 37,4 % sobre lo medido; sin criterio de éxito ni propuesta; 1 supuesto 54 días sin verificar

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Definición — Alerta de taludes (PRD-301) · contrastada al 2026-10-16
**Documento:** 00-definicion/2026-06-01-definicion-producto.docx (más el caso de negocio 00-definicion/2026-06-01-caso-de-negocio.md) · **del** 2026-06-01 · 6 afirmaciones sobre el mundo (problema, para quién, propuesta, un supuesto, una cifra de volumen, un retorno)

### Lo que la evidencia contradice
| Afirma | Dice la evidencia | Las dos fuentes y sus fechas |
|---|---|---|
| volumen_mensual = 169.380 | Medido 106.047; el declarado está por encima en 37,4 % (umbral 20 %) | Caso de negocio, 2026-06-01 · Tablero de métricas (bodega de datos), corte 2026-10-08 |

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 169.380 | 106.047 | 37,4 % (declarado por encima) | 20-metricas/2026-10-08-tablero-metricas.md (2026-10-08) vs 00-definicion/2026-06-01-caso-de-negocio.md (2026-06-01) |

Solo hay un punto en la serie, así que no se puede decir si el volumen viene bajando o nunca llegó a la cifra declarada.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | Caso de negocio, 2026-06-01 | No trae cifra de retorno ni métrica asociada; no hay nada que medir |

### No está dicho en ninguna parte
- **Qué se propone:** la definición dice solo «Propuesta principal», un marcador sin contenido.
- **Criterio de éxito:** ningún documento lo escribe.
- **Qué se invierte ni cuánto retorna:** el caso de negocio dice «retorno esperado en 24 meses» sin monto, sin base y sin costo.
- **Qué volumen cuenta y por qué 169.380:** la cifra aparece sin cálculo ni fuente más allá del propio caso.
- **Cuál es «el tiempo pactado» y con qué proveedor:** el supuesto lo menciona; ningún documento lo define.
- **Quién decide:** el acta del comité no lo dice; se tomó el comité que la emite (a confirmar con el gerente).
- **Qué proyecto lo construye:** «Ninguno declarado», y 13 de 14 requerimientos no tienen proyecto (el 14.º está solo propuesto).
- **Que Mantenimiento sea el segmento que tiene el problema:** la entrevista no menciona el segmento.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-08-23) | 54 (umbral 30) | Escribir cuál es el tiempo pactado y quién es el proveedor, y contrastarlo con el contrato o con el cronograma de entregas; hoy ni el plazo ni el proveedor están en ningún documento. Nota: la fecha del supuesto (2026-08-23) es posterior a la fecha del documento que lo contiene (2026-06-01), así que el documento se editó sin cambiar su fecha |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe una necesidad de alerta de taludes («Lo necesito y hoy no lo tengo») | Entrevista a un cliente sin nombre, tema «Necesidad principal» (10-descubrimiento/2025-10-06-entrevistas.md) | 2025-10-06 | Débil: una sola persona, solo dicho (nadie pagó ni se comprometió), sin nombre ni segmento. Solo sostiene la necesidad en general, no el problema para Mantenimiento ni el volumen |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del cliente; sostiene a 7 requerimientos (REQ-4101, 4105, 4106, 4107, 4109, 4110, 4112) | Entrevista del 2025-10-06 | 12 meses (umbral 12), y es anterior en ocho meses a la definición del 2026-06-01 |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada identificable: la definición no menciona datos personales, pagos, consumidor financiero ni retención de información | — | — | — | No tengo la norma a la vista. El barrido no es un «no aplica»: con una propuesta sin contenido no se puede saber qué tocaría. Un sistema de alerta sobre infraestructura puede tener obligaciones de seguridad o ambientales que el agente no está cubriendo; va a revisión jurídica |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no existe. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Propuesta:** solo un marcador sin contenido.
- **Quién decide:** inferido del comité, sin confirmar.
- Problema y para quién sí están escritos (Mantenimiento no tiene alerta de taludes), pero sin evidencia que los sostenga más allá de la entrevista citada.

### Contexto del registro (no es de la definición, pero la rodea)
Del cálculo sobre los 14 requerimientos: 13 aceptados sin proyecto que los ejecute, 6 aceptados sin evidencia, 5 sin doliente, 1 sin criterio de aceptación y 1 propuesto desde hace 167 días sin decidir. El comité del 2026-10-12 decidió «Se mantiene el plan», con un solo asistente, y sin tratar la diferencia de la cifra.

### Después
Ofrezco convertir el supuesto del proveedor (54 días) en un riesgo con doliente (raid-taxonomy). La definición no se puede cerrar ni pasar a `/criterio-product:product-charter` mientras falte el criterio de éxito.
