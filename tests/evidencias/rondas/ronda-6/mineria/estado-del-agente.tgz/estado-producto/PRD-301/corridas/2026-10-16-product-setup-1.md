# Corrida del 2026-10-16 · product-setup

PRD-301 · 14 requerimientos · 23 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 7 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_owner` | 5 |
| `requirement_without_acceptance` | 1 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

0 preguntas hechas (sesión sin interfaz, se tomaron las sugeridas); minutos hasta el primer resultado no medidos; 14 requerimientos levantados, 6 aceptados sin evidencia, 7 con evidencia de 12 meses, 13 sin proyecto, volumen declarado 37,4% sobre lo medido, criterio de éxito no dicho

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Alerta de taludes (PRD-301)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-10-06) · la definición del 2026-06-01 (.docx, se leyó completo; sin formatos ilegibles). Lo más reciente: el acta del comité del 2026-10-12.
**Términos:** aceptados para la versión 0.3.12 (términos 1.1) por José Francisco Ñáñez, 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 bbc944aafa669a50… (md) y 089f4fb48989f62f… (pdf)

**Preguntas:** ninguna se pudo hacer (sesión sin interfaz). Tomé lo sugerido:
- Producto y gerente: Alerta de taludes, Mauricio Pérez (salen de la definición).
- Quién decide: «Comité de producto» (el acta no lo dice; es el comité que la emite). Confírmalo.
- Estado: `estado-producto/PRD-301`, hermana de `documentos/`, no la carpeta `estado/` de otro agente.
- Términos: el sí viene dado en la instrucción de la prueba.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Mantenimiento no tiene alerta de taludes» | Una sola entrevista: «Lo necesito y hoy no lo tengo» (cliente sin nombre; no dice segmento ni qué necesita) | 2025-10-06 (12 meses) |
| Volumen mensual de 169.380 | Declarada en el caso de negocio. **Medida: 106.047** en el tablero (bodega de datos). **37,4 % por debajo de lo declarado** | caso 2026-06-01 · medición 2026-10-08 |
| «El proveedor cumple el tiempo pactado» | Supuesto declarado, sin verificar desde hace 54 días. No dice qué proveedor ni qué tiempo | 2026-08-23 |
| Retorno esperado en 24 meses | Nada: sin cifra, sin cálculo, sin fuente | — |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito.** Ningún documento lo escribe.
- **Qué se propone.** La definición dice «Propuesta principal» y nada más.
- **Cuánto retorna.** «Retorno esperado en 24 meses» no trae monto.
- **Qué problema resuelve cada requerimiento.** El acta los nombra REQ-4100 a REQ-4113 sin describirlos.
- **Quién decide.** El acta no firma ni dice quién aceptó los 13 requerimientos; solo figura Mauricio Pérez como asistente. La decisión escrita es «Se mantiene el plan».
- **Qué proyecto construye algo.** La definición dice «Ninguno declarado» y los 14 requerimientos tienen «—».

### Registro de requerimientos (14: 13 aceptados, 1 propuesto)
- 13 de 13 aceptados sin proyecto que los ejecute.
- 6 aceptados sin ninguna evidencia de demanda (REQ-4100, 4102, 4103, 4104, 4108, 4113).
- 7 con evidencia, y es la **misma** entrevista de hace 12 meses para los siete (53,8 % del registro). La entrevista no nombra ningún requerimiento: el acta solo dice «Cliente entrevistado».
- 5 sin doliente: «sin asignar» (REQ-4106, 4107, 4108, 4109, 4113).
- 1 aceptado sin criterio de aceptación (REQ-4105).
- 1 propuesto sin decidir hace 167 días (REQ-4111, desde 2026-05-02).
- Dato a vigilar: Mauricio Pérez es gerente, autor del caso de negocio, entrevistador, único asistente al comité y doliente de REQ-4110.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado» (2026-08-23, sin verificar, 54 días). Nada más se declara como supuesto, aunque el volumen y el retorno lo son.

### Qué le falta a tu carpeta
- La transcripción completa de las entrevistas: hay una sola, de tres líneas, y no nombra requerimientos.
- Una serie de la métrica: hay un solo punto medido (2026-10-08), sin historia para ver si 106.047 sube o baja.
- Las decisiones del comité con quién decidió y por qué; sin ellas un descartado se ve igual que uno que nadie miró.
- Una métrica para el retorno: nadie está midiéndolo.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para que los temas se conviertan en requerimientos con la cita de quién los pidió.
