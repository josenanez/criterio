# Corrida del 2026-10-16 · product-spec

PRD-301 · 14 requerimientos · 58 s · 35 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `evidence_stale` | 7 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_owner` | 5 |
| `requirement_without_acceptance` | 1 |
| `requirement_undecided` | 1 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador de especificación sin secciones de comportamiento: los 13 aceptados no tienen problema escrito y 12 de 13 solo dicen 'se verifica en producción' (REQ-4105 sin criterio). Dejó a la vista 12 vacíos con dueño, incluidos casos borde, dependencias con el proveedor sin acordar y obligaciones normativas sin confirmar. No sabe qué hace cada requerimiento, qué proveedor es, ni si hay normativa sectorial aplicable.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribe el agente; lo cierra Mauricio Pérez (gerente de producto), con el Comité de producto como autoridad. Este agente no lo aprueba.

# Especificación — Alerta de taludes (PRD-301) · borrador del 2026-10-16

**Lo primero que hay que saber:** el registro no permite escribir una especificación de comportamiento. Ninguno de los 13 requerimientos aceptados tiene el problema que resuelve («Ningún documento dice el problema de este requerimiento»); su título es el propio identificador. Prefiero dejarlo a la vista antes que inventar qué hace cada uno. Lo que sigue es el esqueleto trazable y la lista de lo que falta decidir.

## Alcance

### Entra
Los 13 requerimientos en estado `aceptado` del acta del Comité del 2026-10-12, **solo como identificador**: REQ-4100, 4101, 4102, 4103, 4104, 4105, 4106, 4107, 4108, 4109, 4110, 4112, 4113. Ninguno tiene una sección de comportamiento porque ninguno tiene necesidad escrita.

| REQ | Doliente (acta) | Aceptado desde | Quién lo pidió (acta) |
|---|---|---|---|
| REQ-4100 | Sandra Gil | 2026-05-16 | — |
| REQ-4101 | María Restrepo | 2026-07-03 | Cliente entrevistado |
| REQ-4102 | Natalia Ospina | 2026-05-31 | — |
| REQ-4103 | Laura Vélez | 2026-04-12 | — |
| REQ-4104 | Óscar Ramírez | 2026-07-27 | — |
| REQ-4105 | Felipe Arango | 2026-04-29 | Cliente entrevistado |
| REQ-4106 | sin asignar | 2026-04-20 | Cliente entrevistado |
| REQ-4107 | sin asignar | 2026-08-06 | Cliente entrevistado |
| REQ-4108 | sin asignar | 2026-08-26 | — |
| REQ-4109 | sin asignar | 2026-04-08 | Cliente entrevistado |
| REQ-4110 | Mauricio Pérez | 2026-08-25 | Cliente entrevistado |
| REQ-4112 | Beatriz Cuéllar | 2026-06-07 | Cliente entrevistado |
| REQ-4113 | sin asignar | 2026-06-12 | — |

Contexto de la definición (2026-06-01): «El segmento Mantenimiento no tiene alerta de taludes.» La propuesta es el marcador «Propuesta principal», sin contenido.

### No entra
- **REQ-4111** (propuesto desde 2026-05-02, doliente Rubén Cárdenas): nadie lo ha decidido y no se especifica lo no decidido.
- Todo lo que no esté en el acta del 2026-10-12. No hay otros requerimientos en el registro.
- Arquitectura, estimación de esfuerzo, costo y fechas: no son de este documento.
- Cualquier comportamiento del producto no descrito en un documento: no lo deduzco del nombre «Alerta de taludes».

## Criterios de aceptación

Doce de los trece dicen lo mismo: «se verifica en producción». Es un lugar, no un criterio: dos personas mirando lo construido no pueden llegar a la misma respuesta. REQ-4105 no tiene ninguno.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4100, 4101, 4102, 4103, 4104, 4106, 4107, 4108, 4109, 4110, 4112, 4113 | No dice qué se observa, con qué umbral ni quién lo observa | **No verificable todavía** |
| *(ninguno)* | REQ-4105 | — | **No verificable todavía** |

No propongo umbrales (por ejemplo, tiempos de alerta o tasas de falsos positivos): ningún documento da un valor y elegirlo sería decidir por el negocio. La única métrica medida hoy para el producto es `volumen_mensual` (106.047, tablero del 2026-10-08), y ningún requerimiento la usa como criterio.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-08-23 en la definición; sin verificar hace 54 días, umbral 30). No dice qué proveedor ni qué tiempo. | No | Mauricio Pérez |
| Que el pedido del «Cliente entrevistado» (entrevista del 2025-10-06: «Lo necesito y hoy no lo tengo.») corresponde a REQ-4101, 4105, 4106, 4107, 4109, 4110 y 4112. La entrevista no nombra ninguno; es la atribución del acta. | No | Mauricio Pérez (realizó la entrevista) |
| Que esa evidencia sigue vigente: tiene 12 meses (umbral 12). | No | Mauricio Pérez |
| Que `volumen_mensual` de 169.380 (caso de negocio, 2026-06-01) es la cifra correcta: el tablero mide 106.047 (2026-10-08), brecha de 37,4 % (umbral 20 %). | No: contradicha por la medición | Mauricio Pérez, que preparó el caso |

Nota: la definición está fechada 2026-06-01 pero recoge un supuesto «declarado el 2026-08-23». Hay que confirmar si el documento se editó después sin cambiar su fecha.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| El problema que resuelve cada uno de los 13 requerimientos | No se puede escribir ni verificar comportamiento alguno; el equipo construiría lo que adivine | Cada doliente; los 5 sin doliente, tras asignarlo |
| Doliente de REQ-4106, 4107, 4108, 4109, 4113 («sin asignar») | Nadie responde por el criterio ni por aceptar lo construido | Mauricio Pérez, en el próximo comité |
| Criterio de aceptación medible de los 13 (REQ-4105 ni siquiera tiene el texto) | La aceptación se discute después de construir | Cada doliente, con Mauricio Pérez |
| Casos borde: qué pasa ante falla del sensor o de la fuente de datos, alerta duplicada, sin conexión, destinatario no disponible, falsa alarma | Cada desarrollador lo resuelve a su modo. Ningún documento los menciona | Mauricio Pérez, con los dolientes |
| Criterio de éxito del producto («Ningún documento escribe un criterio de éxito») | No hay forma de saber si la suma de requerimientos resuelve el problema | Mauricio Pérez / Comité de producto |
| Qué se propone («Propuesta principal» es un marcador vacío) | La especificación no tiene a qué responder | Mauricio Pérez |
| Quién decidió cada aceptación: el acta lista como único asistente a Mauricio Pérez y la única decisión es «Se mantiene el plan» | Las 13 aceptaciones no tienen decisor documentado | Comité de producto |
| Prioridad de los 13 (todas `no encontrada`) | No hay orden para construir ni recortar | Comité de producto |
| **Dependencias de otros equipos:** el supuesto del proveedor implica un tercero, pero ningún documento nombra al proveedor, un acuerdo ni qué debe hacer. Tampoco hay proyecto en ningún requerimiento (carpeta `estado/` vacía; acta con «—» en todos) | Si el proveedor o un equipo interno tiene trabajo que hacer, nadie lo ha acordado con él | Mauricio Pérez |
| **Obligaciones normativas:** el barrido no encuentra en los documentos mención de datos personales, pagos, consumidor financiero ni retención de información. No opino sobre cumplimiento. Sí queda sin confirmar si el producto, por tratarse de seguridad de taludes, tiene obligaciones sectoriales: ningún documento lo dice ni lo descarta | Descubrirlas después de construir | Mauricio Pérez, con quien tenga la función jurídica o de cumplimiento (no figura en los documentos) |
| Cifra del caso de negocio contra la medición (169.380 frente a 106.047) | Si el caso sustenta la inversión, está apoyado en una cifra que los datos no sostienen | Mauricio Pérez |
| Estado de REQ-4111 (propuesto, 167 días; umbral 60) | Queda fuera de la especificación indefinidamente | Comité de producto; doliente Rubén Cárdenas |

## Requerimientos aceptados que esta especificación no cubre

Hay 13 aceptados y ninguno tiene sección de comportamiento. Entran solo nominalmente, por el mismo motivo base: **sin problema descrito**.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Sin problema descrito; sin quién lo pidió; sin evidencia; criterio no verificable |
| REQ-4101 | Requerimiento REQ-4101 | Sin problema descrito; criterio no verificable; evidencia de 12 meses que no lo nombra |
| REQ-4102 | Requerimiento REQ-4102 | Sin problema descrito; sin quién lo pidió; sin evidencia; criterio no verificable |
| REQ-4103 | Requerimiento REQ-4103 | Sin problema descrito; sin quién lo pidió; sin evidencia; criterio no verificable |
| REQ-4104 | Requerimiento REQ-4104 | Sin problema descrito; sin quién lo pidió; sin evidencia; criterio no verificable |
| REQ-4105 | Requerimiento REQ-4105 | Sin problema descrito; **sin criterio de aceptación**; evidencia de 12 meses que no lo nombra |
| REQ-4106 | Requerimiento REQ-4106 | Sin problema descrito; **sin doliente**; criterio no verificable; evidencia que no lo nombra |
| REQ-4107 | Requerimiento REQ-4107 | Sin problema descrito; **sin doliente**; criterio no verificable; evidencia que no lo nombra |
| REQ-4108 | Requerimiento REQ-4108 | Sin problema descrito; **sin doliente**; sin quién lo pidió; sin evidencia; criterio no verificable |
| REQ-4109 | Requerimiento REQ-4109 | Sin problema descrito; **sin doliente**; criterio no verificable; evidencia que no lo nombra |
| REQ-4110 | Requerimiento REQ-4110 | Sin problema descrito; criterio no verificable; evidencia que no lo nombra |
| REQ-4112 | Requerimiento REQ-4112 | Sin problema descrito; criterio no verificable; evidencia que no lo nombra |
| REQ-4113 | Requerimiento REQ-4113 | Sin problema descrito; **sin doliente**; sin quién lo pidió; sin evidencia; criterio no verificable |

Seis de ellos (REQ-4100, 4102, 4103, 4104, 4108, 4113) no tienen ninguna cita de quien los pidió.

## Después

`/product-charter` todavía no aplica: no hay un requerimiento con problema, criterio medible, doliente y evidencia vigente a la vez. Lo que toca primero es que Mauricio Pérez y los dolientes escriban el problema y el criterio de los más antiguos (REQ-4109, 4103, 4106) y asignen dolientes. Después se actualiza esta especificación; y `/product-trace`, porque ninguno de los 13 tiene proyecto.

---
**Pie.** Sale del registro de requerimientos de PRD-301 (`estado-producto/PRD-301/requirements/`), actualizado el 2026-10-16, sobre el acta del Comité del 2026-10-12. Cubre 13 requerimientos solo por identificador (de 14 en el registro; REQ-4111 queda fuera por no estar decidido). Borrador de trabajo, no decisión ni asesoría; la verificación contra los documentos citados es suya. Términos de la versión 0.3.12 (aceptados por José Francisco Ñáñez el 2026-10-16): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
