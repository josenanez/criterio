## Alerta de taludes (PRD-301) · 2026-10-16

**Primera revisión: no hay corte anterior** (`last: null`), así que todo lo que sigue es lo que hay hoy, no lo que cruzó desde una corrida previa. Desde el corte que dejo hoy, solo se reportará lo nuevo.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Revisión: nada que releer (5 documentos, ninguno nuevo ni cambiado).

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Requerimiento sin decidir | REQ-4111 | 167 días (planteado 2026-05-02; umbral 60) | Que se decida o se descarte; doliente: Rubén Cárdenas | Comité de producto |
| Supuesto sin verificar: «El proveedor cumple el tiempo pactado» | definición | 54 días (umbral 30) | Una verificación con el proveedor, o tratarlo como riesgo registrado (assumption-tracking) | Mauricio Pérez |
| Lo declarado contra lo medido: volumen mensual | caso de negocio | Declarado 169.380 (2026-06-01) vs medido 106.047 (2026-10-08): 37,4 % por encima (umbral 20 %) | Que el negocio corrija la cifra o explique la diferencia | Mauricio Pérez / Comité |

### Aceptado sin sustento
- **Sin evidencia de demanda (6):** REQ-4100, 4102, 4103, 4104, 4108, 4113.
- **Evidencia vencida (7):** REQ-4101, 4105, 4106, 4107, 4109, 4110, 4112 descansan en una sola entrevista del 2025-10-06 que cumple 12 meses. La definición pierde sustento en «Necesidad principal».
- **Sin doliente (5):** REQ-4106, 4107, 4108, 4109, 4113.
- **Sin criterio de aceptación (1):** REQ-4105.

### Las trazas
**Ninguna se da por confirmada.** Los 13 requerimientos aceptados figuran sin proyecto que los construya (`requirement_untraced`, 13 de 13). La configuración no nombra una carpeta de fichas; usé `estado/records` por ser la que hay en este espacio. Confírmala si no es la correcta.

### Del descubrimiento
Sin documentos nuevos desde el registro.

### Lo que no sé
- Éxito del producto (`success`): no está definido en ningún documento.
- Aviso técnico: `plan-lectura` marca como «fuente no encontrada» las citas de la definición (`…2026-06-01-definicion-producto.docx`) y del comité (`…2026-10-12-comite-producto.md`), aunque los archivos existen. Parece un problema del índice de documentos (nunca sellado), no de la carpeta. No lo corregí.

**Vuelvo el 2026-11-15.**
