## Registro — Alerta de taludes (PRD-301) · al 2026-10-16
14 requerimientos · 13 decididos · 53,8 % con evidencia · 0 % con proyecto que lo ejecuta

> La carpeta de fichas de proyecto (`estado/`) está vacía: ningún requerimiento tiene un proyecto confirmado. Ninguna fila dice «proyecto»; el acta tampoco nombra uno.

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió (6). Van primero.
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | aceptado | Sandra Gil |
| REQ-4102 | Requerimiento REQ-4102 | aceptado | Natalia Ospina |
| REQ-4103 | Requerimiento REQ-4103 | aceptado | Laura Vélez |
| REQ-4104 | Requerimiento REQ-4104 | aceptado | Óscar Ramírez |
| REQ-4108 | Requerimiento REQ-4108 | aceptado | sin asignar |
| REQ-4113 | Requerimiento REQ-4113 | aceptado | sin asignar |

### Decidido y nadie lo está construyendo
13 de 13 decididos, ninguno con proyecto (acta del 2026-10-12, columna «Proyecto que lo ejecuta»: «—» en todos).
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | 2026-05-16 |
| REQ-4101 | Requerimiento REQ-4101 | 2026-07-03 |
| REQ-4102 | Requerimiento REQ-4102 | 2026-05-31 |
| REQ-4103 | Requerimiento REQ-4103 | 2026-04-12 |
| REQ-4104 | Requerimiento REQ-4104 | 2026-07-27 |
| REQ-4105 | Requerimiento REQ-4105 | 2026-04-29 |
| REQ-4106 | Requerimiento REQ-4106 | 2026-04-20 |
| REQ-4107 | Requerimiento REQ-4107 | 2026-08-06 |
| REQ-4108 | Requerimiento REQ-4108 | 2026-08-26 |
| REQ-4109 | Requerimiento REQ-4109 | 2026-04-08 |
| REQ-4110 | Requerimiento REQ-4110 | 2026-08-25 |
| REQ-4112 | Requerimiento REQ-4112 | 2026-06-07 |
| REQ-4113 | Requerimiento REQ-4113 | 2026-06-12 |

Quien los cerraría: Mauricio Pérez (gerente de producto), llevando los más antiguos (REQ-4109, REQ-4103, REQ-4106) a `/product-charter`. El más viejo lleva 191 días aceptado.

### Sin doliente, o con un área en vez de una persona
El acta dice «sin asignar» (5).
| REQ | Título | Dice |
|---|---|---|
| REQ-4106 | Requerimiento REQ-4106 | sin asignar |
| REQ-4107 | Requerimiento REQ-4107 | sin asignar |
| REQ-4108 | Requerimiento REQ-4108 | sin asignar |
| REQ-4109 | Requerimiento REQ-4109 | sin asignar |
| REQ-4113 | Requerimiento REQ-4113 | sin asignar |

Quien lo cierra: Mauricio Pérez, asignando una persona en el próximo comité.

### Sin criterio de aceptación
Solo los decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-4105 | Requerimiento REQ-4105 | aceptado |

Nota: los otros 12 dicen «se verifica en producción». Eso es un lugar, no un criterio medible; no lo cuento como vacío del registro, pero no sirve para especificar.

### Decidido sin documento que lo respalde
El acta del 2026-10-12 respalda el estado de los 13, pero no dice **quién** decidió cada uno: lista como único asistente a Mauricio Pérez y la única decisión es «Se mantiene el plan». Quién decidió: sin dato en ningún documento. Cuándo: las fechas «Desde» de la tabla de decididos.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4111 | Requerimiento REQ-4111 | 167 días (desde 2026-05-02; umbral 60) | Comité de producto (según la configuración). Doliente: Rubén Cárdenas |

Propongo que el Comité lo decida —aceptar o descartar con documento— en la próxima sesión. No se cierra por viejo.

### Evidencia vieja
Lo más nuevo que los sostiene es la misma entrevista del 2025-10-06, hace 12 meses (umbral 12) (7).
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4101, 4105, 4106, 4107, 4109, 4110, 4112 | «Lo necesito y hoy no lo tengo.» — cliente entrevistado (2025-10-06) | 12 meses |

Además, esa entrevista no nombra ninguno de estos requerimientos; el acta atribuye el pedido a «Cliente entrevistado» sin más.

### Fuera del registro, pero cruzan umbral
- Cifra declarada vs. medida: volumen mensual declarado 169.380 (caso de negocio, 2026-06-01) contra 106.047 medido (tablero, 2026-10-08): brecha de 37,4 % (umbral 20 %).
- Supuesto sin verificar hace 54 días: «El proveedor cumple el tiempo pactado» (umbral 30).
- La definición no dice criterio de éxito.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 13 | 0 | 0 | 0 |

Después: hay 13 requerimientos decididos sin proyecto, así que corresponde `/product-trace`. Hoy no hay ninguno aceptado con evidencia vigente, criterio medible y doliente a la vez, por lo que `/product-charter` aún no aplica.
