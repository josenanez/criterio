## Reunión de seguimiento — PRY-205 Sistema de gestión de seguridad · 2026-10-30
12 puntos (2 + 7 + 2 + confirmación de lo que vence) · 44 minutos · 9 personas requeridas (Elena Duarte, Laura Vélez, Paula Céspedes, Gustavo Neira, Mauricio Pérez, Sandra Gil, Diana Molina, Óscar Ramírez, Carlos Peña)

> **Fecha y duración:** 2026-10-30 sale de las notas del 2026-10-16 («próxima reunión en dos semanas») y coincide con `committee_next` de la configuración. Nadie fijó duración; los 44 minutos son la suma de los puntos.
> **Cómo se calculó:** no hay corrida anterior ni registro de compromisos en el estado (`diff` dijo «no previous snapshot»), así que las reprogramaciones y los días de atraso salen de leer a mano las seis minutas (09-04 a 10-09) y las notas del 10-16, con corte al 2026-10-16. Para el 10-30 los atrasos serán 14 días mayores.

### Lo que no se destraba solo

> **[1] Que Elena Duarte dé una fecha que no se mueva para «Enviar el documento 1», o que se diga quién más lo puede cerrar** · 10 min · **Elena Duarte**
> Prometido para el 2026-12-20, y antes para el 12-06, y antes para el 11-27, el 11-06, el 10-28, el 10-07 y el 09-30: **seis reprogramaciones**, 81 días de corrimiento desde el 09-30. Las notas del 10-16 dicen que «no alcanzó», pero la última fecha registrada (12-06) no había llegado; falta saber contra qué fecha no alcanzó.
> Fuente: minutas 2026-09-04, 09-11, 09-18, 09-25, 10-02, 10-09 y notas 2026-10-16
> **Si no se resuelve hoy:** el documento 1 queda sin entregar al menos hasta el 12-20 sin que nadie haya dicho qué lo traba. Elena sí cerró otro compromiso con acta («Entregar el punto 8», 2026-09-25).

> **[2] Qué traba «Cerrar la prueba 2» y una fecha que se sostenga** · 8 min · **Laura Vélez**
> Prometido para el 2026-12-13, y antes para el 11-26, el 11-18, el 10-30, el 10-13 y el 10-02: **cinco reprogramaciones**, 72 días desde el 10-02. Además Laura quedó en las notas del 10-16 con el ajuste del presupuesto «la otra semana» (sin fecha; ver punto 8).
> Fuente: minutas 2026-09-04 a 10-09 y notas 2026-10-16
> **Si no se resuelve hoy:** la prueba 2 sigue corriéndose entre 1 y 3 semanas por reunión, que es lo que ha hecho cinco veces.

### Vencido sin evidencia
Más viejo primero, por la fecha vigente. Días al 2026-10-16. Ninguno tiene acta de recibo.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 (18 d; antes 09-14) | Fecha o evidencia. Es compromiso de la gerente: va primero para que el resto lo vea. | 2 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 (14 d) | Confirmar la fecha o decir por qué no se puede | 4 |
| Gustavo Neira | Revisar el anexo 3 | 2026-10-03 (13 d; antes 09-13 y 09-25) | Entregar la revisión o fecha firme; ya se corrió dos veces | (incl.) |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 (9 d) | Confirmar o decir qué falta | 3 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 (4 d) | Evidencia o fecha | 4 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-10-14 (2 d; antes 10-06). El 09-25 dijo que ya lo entregó; no hay acta y desapareció de la lista desde ese día | Mostrar la entrega para que Paula emita el acta, o reabrirlo con fecha | (incl.) |
| Diana Molina | Revisar el anexo 19 | 2026-10-14 (2 d) | Evidencia o fecha | 2 |

Fuente: minutas 2026-09-11 a 10-09; ver también 09-25 (Mauricio, punto 5).

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar como riesgo que el proveedor podría no llegar con el equipo completo para la siguiente fase (dicho el 10-16, «nadie lo anotó como riesgo»): dueño, y qué se revisa en la «revisión con el proveedor» del 10-26 | Paula Céspedes, con Óscar Ramírez | El riesgo sigue sin dueño ni registro; el informe del 10-11 lista dos riesgos y este no está. | 5 |
| Fecha para dos compromisos sin fecha: «Cerrar la prueba 18» (Carlos Peña, «por definir» desde el 10-02) y el ajuste del presupuesto (Laura Vélez, «la otra semana») | Carlos Peña y Laura Vélez | Se quedan «por definir» y no pueden vencer. Carlos tiene además otros dos compromisos (20 y 24). | 3 |

Fuente: notas 2026-10-16; minutas 2026-10-02 y 10-09.

### Vence antes de la próxima
Solo confirmar en la reunión; 3 minutos en total.

| Quién | Qué | Para cuándo |
|---|---|---|
| Carlos Peña | Validar el ambiente 20 | 2026-10-24 |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-26 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 |
| Andrés Lozano | Enviar el documento 9 (ya corrido: antes 09-25) | 2026-10-26 |
| Liliana Torres | Enviar el documento 17 (ya corrido: antes 10-21) | 2026-10-29 |

Estos vencen antes del 10-30; si no hay noticias el 10-30 pasan a la tabla de vencidos. Andrés y Liliana no son requeridos; con avisarles basta.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Ricardo Salas · «Actualizar la matriz 14» (para 2026-10-16) | Dijo el 10-02 que ya lo entregó; no hay acta. No asiste desde el 09-25. | Paula le pide por fuera la evidencia y emite el acta, o lo reabre con fecha. |
| Rubén Cárdenas · «Actualizar la matriz 22» (sin fecha desde el 10-09) | No estuvo el 10-16 y su punto es solo conseguir una fecha. | Mensaje de Paula antes del 10-30. |
| Estado declarado «Verde» (informe del 10-11, 58%) frente a siete compromisos vencidos y dos con cinco o más reprogramaciones | Es de estado, no de agenda. | `/pm-report`, antes de que la PMO lo lea. |

No encontré nada que exceda la autoridad del gerente; no hay punto para comité.

### Anexo — no se puede decir «sin cambios desde»
No hay corrida anterior contra la cual comparar. Lo que sigue no se repasa en la reunión:
- Cerrados con acta de recibo: Entregar el punto 8 (Elena), Cerrar la prueba 10 (Javier Hoyos) y Revisar el anexo 11 (Rubén Cárdenas), 2026-09-25; Aprobar el diseño 13 (Gustavo), 2026-10-02; Validar el ambiente 4 (Felipe Arango) y Entregar el punto 16 (Camilo Beltrán), 2026-10-09.
- Abiertos con fecha posterior al 10-30: Aprobar el diseño 21 (Andrés Lozano, 2026-11-06); Entregar el punto 24 (Carlos Peña, 2026-11-02).

**Qué no sé:** si los compromisos que las notas del 10-16 no mencionan (3, 6, 7, 12, 15, 19, entre otros) avanzaron esta semana; las notas del 10-16 no son una lista completa. Tampoco sé la duración real de la reunión ni quiénes asistirán el 10-30.
