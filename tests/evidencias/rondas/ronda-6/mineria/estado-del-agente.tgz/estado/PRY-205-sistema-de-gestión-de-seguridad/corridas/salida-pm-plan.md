# Plan — PRY-205 Sistema de gestión de seguridad · borrador del 2026-10-16
**Desde:** acta de constitución del 2025-12-23 (`00-gobierno/2025-12-23-acta-constitucion.docx`) · **Criterio de éxito:** «Sistema de gestión de seguridad en producción y medido.» (acta) — declarado, pero sin ninguna métrica ni umbral.

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que volver a pedirlos. Sesión sin interfaz: no se hizo ninguna pregunta.

**Antes de leer el borrador:** este proyecto no está en arranque. El acta es de hace 10 meses, ya existe un cronograma v1 (`10-plan/2025-12-23-cronograma-v1.xlsx`) y el último informe declara 58 % de avance (`20-seguimiento/2026-10-11-informe-avance.md`). Lo que sigue es lo que sale de reconstruir el plan desde el acta; sirve sobre todo para ver qué nunca se definió. Si lo que se quiere es auditar el plan vigente, el modo es `/pm-plan revisar`.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance real.** El acta dice «Componente 1 / Componente 2 / Componente 3» y, en fuera de alcance, «Lo que otro proyecto cubre». Son marcadores de plantilla, no alcance. | No se puede descomponer por entregable: no se sabe qué son los tres componentes. La WBS de abajo no puede pasar de los hitos del cronograma. |
| **Criterio de éxito medible.** «En producción y medido» no dice qué se mide, con qué umbral, ni quién lo mide. | No se puede saber cuándo el proyecto terminó, ni qué entra o no en el alcance. Es el vacío más caro. |
| **Autoridad declarada.** El acta no dice qué puede decidir la gerente y qué debe subir (el registro de la ficha lo confirma: `identity.authority` no encontrado). | No se sabe qué puede decidir quien planifica y qué hay que llevar al patrocinador o al comité. |
| **Dependencias.** Dice «Ninguna declarada». | El orden de abajo es un supuesto, y el proveedor y la ventana de parada de planta (que aparecen en otros documentos) no están en el acta. |
| Patrocinador | Sí está: Andrés Lozano. Hay a quién llevarle las excepciones. |

Se señala y se sigue; nada de lo anterior se rellenó.

## WBS
Los estados son tres: **del acta**, **supuesto**, **sin definir**. Los hitos que vienen del cronograma v1 y no del acta se marcan como supuesto, con la cita, porque el acta no los menciona.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | Sin definir | Supuesto — hito del cronograma v1 (2025-12-23), no está en el acta | vacía (ver nota) |
| 2 | Ingeniería de detalle aprobada | Sin definir | Supuesto — hito del cronograma v1, no está en el acta | vacía |
| 3 | Licencia y permisos obtenidos | Sin definir | Supuesto — hito del cronograma v1, no está en el acta | vacía |
| 4 | Componente 1 | Sin definir | Del acta, pero como marcador sin contenido: no se sabe qué es | vacía |
| 5 | Componente 2 | Sin definir | Ídem | vacía |
| 6 | Componente 3 | Sin definir | Ídem | vacía |
| 7 | Sistema en producción | Sin definir | Del acta, implícito en el criterio de éxito («en producción»). Ningún hito del cronograma lo cubre | vacía |
| 8 | Medición del sistema en producción | Sin definir | Del acta, implícito en el criterio de éxito («y medido»). Ningún hito lo cubre; qué se mide, sin definir | vacía |

Nota sobre duraciones: lo único citable es la ventana total del acta, inicio 2026-01-02 a cierre 2027-04-23. No hay de dónde sacar duraciones por nodo, así que van vacías. Las fechas de los hitos 1 a 3 en el cronograma v1 son las que alguien comprometió entonces; este borrador no las repite como propias.

Ojo con los nodos 4 a 8: el cronograma v1 tiene tres hitos y ninguno es «en producción» ni «medido». El criterio de éxito del acta no tiene un solo hito que lo respalde, y el último hito (licencia y permisos, 2027-04-23) cae justo en la fecha de cierre.

## Orden
Sin fechas. Qué necesita qué:

- Ingeniería básica (1) → ingeniería de detalle (2) → licencia y permisos (3): es la secuencia en que el cronograma v1 los lista; la dependencia entre ellos **es un supuesto**, el acta no declara ninguna.
- Componentes (4 a 6) → sistema en producción (7) → medición (8): el orden se sigue del propio criterio de éxito («en producción y medido»); qué componente va antes de cuál **sin definir**.
- Dónde entra cada componente respecto a las ingenierías y a la licencia: sin definir. Hay un riesgo registrado de que un cambio de licencia «puede mover el alcance» (informe del 2026-10-11), lo que sugiere un vínculo, pero nadie lo ha dicho como dependencia.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres hitos del cronograma v1 son entregables aceptables y completos del proyecto | Faltaría trabajo que ningún hito representa (ya falta el de producción y medición) |
| Ingeniería básica → detalle → licencia es una cadena de dependencia, no trabajo en paralelo | Cambia la ruta crítica y la fecha de cierre |
| Los «Componentes 1 a 3» son tres entregables y no un marcador sin sustituir | Si el alcance real es otro, la WBS entera cambia |
| «Producción» y «medido» son entregables propios con su propio tiempo, no se dan por sí solos al final | Si nadie los planeó, el cierre del 2027-04-23 no los incluye |
| El proveedor llega con el equipo completo para la siguiente fase | Retraso en la fase; no hay contrato del proveedor en la carpeta que diga qué debe entregar y cuándo |
| Operaciones define la ventana de parada de planta a tiempo | Cualquier trabajo que necesite parada se corre (riesgo ya listado en el informe, sin doliente) |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | Patrocinador (Andrés Lozano) con la gerente |
| Exclusiones reales del alcance | Patrocinador |
| Métrica y umbral de «medido»; quién lo mide | Patrocinador / área dueña (Geología) |
| Quién acepta cada entregable | Patrocinador |
| Autoridad de la gerente al planificar | Patrocinador / Comité Ambiental |
| Dependencias del proyecto | Gerente, con el patrocinador |
| Qué es «la siguiente fase» (se mencionó en la reunión del 2026-10-16; ninguna fase está definida en la ficha) | Gerente |
| Proveedor y su contrato (la carpeta no tiene ninguno) | Gerente / quien contrató |
| Ajuste del presupuesto que Laura Vélez debía enviar «la otra semana» (sin fecha) | Laura Vélez, a confirmar con la gerente |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no se buscó análogos. Es la respuesta correcta y evita una falsa precisión: este borrador no estima nada por analogía.

## Preguntas para el equipo
Una por cada duración vacía:

1. ¿Cuánto tomó o cuánto falta de la ingeniería básica? (El cronograma v1 la marca cerrada el 2026-06-09, pero no hay acta de recibo de ese hito en la carpeta; ¿quién la aceptó y dónde consta?)
2. ¿Cuánto toma la ingeniería de detalle, y qué la hace «aprobada»: quién firma?
3. ¿Cuánto toma obtener la licencia y los permisos? El informe del 2026-10-11 dice que se recibió «el permiso ambiental pendiente»; ¿es eso el hito 3 o es otro permiso?
4. ¿Qué son los Componentes 1, 2 y 3, y cuánto toma cada uno?
5. ¿Cuánto toma pasar a producción, y qué necesita la parada de planta?
6. ¿Qué se mide, con qué umbral y durante cuánto tiempo antes de dar el sistema por «medido»?
7. ¿Qué entrega el proveedor, cuándo, y qué pasa si no llega con el equipo completo?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (el informe del 2026-10-11 ya reporta dos semanas perdidas por rotación de un ingeniero clave).
- La fecha del proveedor; no hay contrato en la carpeta, y la revisión con el proveedor está para el 2026-10-26 (Óscar Ramírez).
- La ventana de parada de planta, que define operaciones.
- Un alcance y un criterio de éxito que alguien pueda aceptar.

Ninguna de las cuatro está en un documento. Este borrador no compromete ninguna fecha.

## Después
Si el plan se aprueba, queda ofrecer registrarlo como línea base y pasar los supuestos al RAID con doliente. Hoy el RAID de la ficha tiene tres riesgos sin doliente, una incidencia sin doliente, y cero supuestos registrados.
