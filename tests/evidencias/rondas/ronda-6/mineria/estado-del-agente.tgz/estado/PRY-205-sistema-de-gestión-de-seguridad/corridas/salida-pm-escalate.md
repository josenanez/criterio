## Para decisión — PRY-205 Sistema de gestión de seguridad · 2026-10-16

> Sin tema indicado, revisé lo que ya estaba marcado. La configuración no marca nada como escalable y el agenda del 10-30 dice «no encontré nada que exceda la autoridad del gerente». Esa frase no se sostiene: **el acta no declara cuál es esa autoridad**, así que no hay contra qué medir. Ese es el primer punto que escala, antes que cualquier otro.

### ¿Se declara por escrito, antes del 30 de octubre, qué puede decidir Paula Céspedes sin subir —mover fechas de compromisos, mover hitos, mover presupuesto, aceptar o cambiar al proveedor— y por encima de qué umbral decide el patrocinador o el Comité Ambiental?

**Quién decide:** Andrés Lozano (patrocinador) y el Comité Ambiental, que aprobaron el acta y el presupuesto el 2025-12-23. *Es inferencia mía: el acta no dice quién puede enmendarla.* · **Si no se decide hoy:** no hay fecha en ningún documento que fuerce esto, y no la invento. Lo verificable: el hito «Ingeniería de detalle aprobada» vence el 2026-11-15 (30 días), y cada fecha que se mueva antes de eso se mueve sin que se sepa quién podía aprobarlo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Enmienda al acta con la autoridad declarada y umbrales | Solo la sección de autoridad; no toca el alcance de Componentes 1–3 | Una sesión del comité; no tengo estimación de días | Sin costo en la ficha; lo que cuesta es el tiempo del comité |
| B. Aplicar una política general de la organización | Igual | Depende de si existe; **no la encontré en la carpeta** | Sin dato |
| C. No declarar nada | Sin cambio | Sin cambio | Cada caso límite (proveedor, presupuesto, fechas) llega al comité sin saber si tocaba subirlo, o se decide sin facultad |

**Recomiendo:** A — es la única que deja escrito qué se sabía y quién podía decidir; con ella la lista de abajo se vuelve respondible.

### También cumplen el criterio de escalar (en espera de la respuesta anterior)
Compromisos reprogramados tres o más veces, según la ficha:

| Compromiso | Doliente | Reprogramaciones | Fecha vigente |
|---|---|---|---|
| Enviar el documento 1 | Elena Duarte | 6 (original 2026-09-30) | 2026-12-20 |
| Cerrar la prueba 2 | Laura Vélez | 5 (original 2026-10-02) | 2026-12-13 |

Sin autoridad declarada no puedo decir si cabe resolverlos con una llamada de Paula o si hay que subirlos. No armo su paquete: la pregunta cerrada depende de eso.

### A quién alcanza
No calculé el efecto: nadie propuso mover una fecha del proyecto, y `impact` pide los días. La ficha tampoco tiene dependencias declaradas (el acta dice «Ninguna declarada»). Si el comité decide mover el hito del 11-15 o el cierre del 2027-04-23, corro `impact` con esos días.

### Mis hitos por los que pasa
Ninguno calculado (sin cambio propuesto). Vigentes: Ingeniería de detalle aprobada 2026-11-15 · Licencia y permisos obtenidos 2027-04-23.

### De dónde sale esto
- Acta sin autoridad: `00-gobierno/2025-12-23-acta-constitucion.docx` (campos Patrocinador, Gerente, Comité, Presupuesto; no hay sección de autoridad). La ficha lo registra como `identity.authority: not_found`.
- Reprogramaciones: minutas 2026-09-04 a 2026-10-09 y notas 2026-10-16.
- Propuesta de comité y fecha 10-30: `committee_next` de la configuración y notas del 10-16.

**Qué no sé:** si existe una política de autoridades fuera de la carpeta del proyecto; quién puede enmendar el acta; si el Comité Ambiental sesiona antes del 10-30. Cuántos días se mueve cada proyecto alcanzado, tampoco: la ficha no tiene holgura.
