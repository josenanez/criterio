## Listo — PRY-205 · Sistema de gestión de seguridad

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta. Gerente: Paula Céspedes (acta de constitución del 2025-12-23). Reunión de seguimiento: los viernes, comité semanal (los nombres de las minutas lo muestran); las notas del 2026-10-16 dicen «próxima reunión en dos semanas», así que dejé la próxima en 2026-10-30. Estado guardado en `estado/PRY-205-sistema-de-gestión-de-seguridad`, junto a la carpeta de documentos y fuera de `.criterio/`.

**Lo que miré:** 16 documentos · 7 de reunión (6 minutas de comité y las notas del 2026-10-16) · la más reciente, del 2026-10-16. Leí las siete en orden, de la más vieja a la más nueva. No hay formatos ilegibles.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-16 para la versión 1.1 (familia 0.3.12) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 del comprobante c5ca81ee804ae819…

### Lo que está abierto, y cuántas veces se ha movido

Son 26 compromisos en total. 6 están cerrados con acta de recibo y 20 siguen abiertos.

**Se movió tres veces o más**

| Quién | Qué | Para cuándo | Veces |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-20 (la primera promesa era 2026-09-30) | 6 |
| Laura Vélez | Cerrar la prueba 2 | 2026-12-13 (la primera promesa era 2026-10-02) | 5 |

Fechas sucesivas de Elena: 10-07, 10-28, 11-06, 11-27, 12-06 y 12-20. Fechas sucesivas de Laura: 10-13, 10-30, 11-18, 11-26 y 12-13. Cada fecha sale de una minuta distinta (`30-reuniones/…-comite-semanal.md`); la última de Elena, de `2026-10-16-notas-reunion.txt`. Ninguna minuta sola lo muestra; sale de leerlas en orden.

**Vencidos sin evidencia (7)**

| Quién | Qué | Para cuándo | Días vencido |
|---|---|---|---|
| Gustavo Neira | Revisar el anexo 3 | 2026-10-03 | 13 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-10-14 | 2 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 | 18 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 | 14 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 | 4 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 | 9 |
| Diana Molina | Revisar el anexo 19 | 2026-10-14 | 2 |

Citas: anexo 3 en `30-reuniones/2026-09-04-comite-semanal.md`; diseño 5, matriz 6 y fecha 7 en `30-reuniones/2026-09-11-comite-semanal.md`; ambiente 12 en `30-reuniones/2026-09-18-comite-semanal.md`; fecha 15 en `30-reuniones/2026-09-25-comite-semanal.md`; anexo 19 en `30-reuniones/2026-10-02-comite-semanal.md`.

- Mauricio Pérez dijo el 2026-09-25 que ya entregó «aprobar el diseño 5». No se presentó acta, y el compromiso dejó de aparecer en la tabla de ese día sin cerrarse. Sigue abierto.
- Ricardo Salas dijo el 2026-10-02 que ya entregó «actualizar la matriz 14». No se presentó acta. Vence hoy (2026-10-16), así que todavía no cuenta como vencido.
- Gustavo Neira tiene dos compromisos vencidos (anexo 3 y fecha 7). Mauricio Pérez, otros dos (diseño 5 y ambiente 12).

**Abiertos y con fecha, todavía no vencidos (10):** Elena Duarte, documento 1 (arriba); Laura Vélez, prueba 2 (arriba); Andrés Lozano, documento 9 (2026-10-26, movido una vez); Ricardo Salas, matriz 14 (2026-10-16); Liliana Torres, documento 17 (2026-10-29, movido una vez); Carlos Peña, ambiente 20 (2026-10-24); Andrés Lozano, diseño 21 (2026-11-06); Elena Duarte, fecha 23 (2026-10-26); Carlos Peña, punto 24 (2026-11-02); Óscar Ramírez, revisión con el proveedor (2026-10-26, notas del 2026-10-16).

**Cerrados con acta de recibo (6):** ambiente 4 (Felipe Arango, acta del 2026-10-09), punto 8 (Elena Duarte, 2026-09-25), prueba 10 (Javier Hoyos, 2026-09-25), anexo 11 (Rubén Cárdenas, 2026-09-25), diseño 13 (Gustavo Neira, 2026-10-02) y punto 16 (Camilo Beltrán, 2026-10-09).

### Sin fecha

Nadie les puso fecha. No pueden estar vencidos, y por eso suelen desaparecer de los informes.

- Carlos Peña: Cerrar la prueba 18. Está sin fecha desde la minuta del 2026-10-02.
- Rubén Cárdenas: Actualizar la matriz 22 (minuta del 2026-10-09).
- Laura Vélez: Mandar el ajuste del presupuesto. Dijo «la otra semana»; no es una fecha (notas del 2026-10-16).

### Lo que el informe de avance declara frente a lo que muestran los documentos

Paula Céspedes declara **verde** y **58 %** (informe del 2026-10-11, tiene 5 días). Contra eso, `compute` levantó:

- 7 compromisos vencidos, 2 reprogramados cinco veces o más y 3 sin fecha.
- Un hito declarado cerrado sin acta que lo pruebe: «Ingeniería básica aprobada», con fecha 2026-06-09, 129 días atrás.
- El cronograma sostiene entre 33 % y 67 % de avance (1 de 3 hitos cerrados). El 58 % cabe en ese tramo y no levanta señal.
- Dinero: ejecutado 32.3 % del aprobado (COP 258.170.381 de 800.000.000), comprometido 40.5 %, proyección 765.512.063 (−4.3 % frente al aprobado). No hay desviación de costo.
- Cierre: 2027-04-23 en el acta y en el cronograma v1. No hay desviación de fechas, pero tampoco hay un segundo cronograma que la mida.

`compute` marca el verde como contradicho: el estado lo declara usted; yo solo le muestro contra qué.

Riesgos que el informe ya lista: la ventana de parada de planta y el cambio en la licencia ambiental. **Uno que no está en ninguna parte:** en la reunión del 2026-10-16 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y nadie lo anotó como riesgo. Lo dejé en la ficha marcado como no registrado.

### Qué le falta a tu carpeta

- **Un cronograma posterior al v1.** Solo hay el del 2025-12-23, así que no se puede medir ninguna replanificación.
- **El acta de recibo de «Ingeniería básica aprobada».** Sin ella, ese hito cerrado se ve igual que uno que no se cerró.
- **Actas de recibo de lo que dicen haber entregado** Mauricio Pérez (diseño 5) y Ricardo Salas (matriz 14).
- **Fecha para los tres compromisos sin ella** (prueba 18, matriz 22 y ajuste del presupuesto).
- **El contrato del proveedor.** Hay un proveedor en las notas, pero ningún contrato en la carpeta, y sin él no puedo contrastar entregables con facturas.
- **El acta de constitución no trae autoridad del gerente, ni etapa, ni producto** (dice «No aplica»). Quedan registrados como no encontrados.

**Cuándo vuelvo:** el viernes 2026-10-30, que es la próxima reunión según las notas del 2026-10-16.

*Ficha escrita en `estado/PRY-205-sistema-de-gestión-de-seguridad/records/PRY-205.json`. No la sellé: leí las reuniones del proyecto, no el proyecto entero.*
