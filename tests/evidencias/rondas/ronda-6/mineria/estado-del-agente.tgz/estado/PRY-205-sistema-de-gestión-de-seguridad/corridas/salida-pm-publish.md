Antes de escribir, esto es lo que iba a publicar:

- **Campos con dato:** 17 · **sin decir en ninguna parte:** 3 (`identity.product` —el acta dice «No aplica»—, `identity.authority`, `identity.phase`).
- **Estado que declara el proyecto:** **verde**, al 2026-10-11, con 58 % de avance (`20-seguimiento/2026-10-11-informe-avance.md`). Es una declaración tuya; la ficha la marca como tal.
- **Fecha de cierre:** `plan.end_date` = 2027-04-23. No hay un cronograma más nuevo que `10-plan/2025-12-23-cronograma-v1.xlsx`, así que la fecha vigente y la de la línea base coinciden.
- **Ojo, la PMO va a ver esto:** el verde queda contradicho por 3 señales — 7 compromisos vencidos sin evidencia, 2 compromisos reprogramados 5 y 6 veces, y el hito «Ingeniería básica aprobada» (vencido el 2026-06-09) marcado como cumplido sin evidencia.

Publiqué la ficha en `documentos/proyectos/PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/ficha-pm.json`, con corte al 2026-10-16. Es copia idéntica de `estado/PRY-205-sistema-de-gestión-de-seguridad/records/PRY-205.json`, que recalculé antes de publicar.

**Lleva:** 17 campos con dato · 3 sin decir en ninguna parte · declara **verde** al 2026-10-11

**Lo más viejo que va ahí:** los datos del acta de constitución (patrocinador, gerente, comité, producto, presupuesto aprobado) y el cronograma v1, del 2025-12-23 — 297 días, menos de un año.
