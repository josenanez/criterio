## Compromisos — PRY-205 Sistema de gestión de seguridad · al 2026-10-16

20 compromisos abiertos sin cierre documentado (de 26 registrados): 7 vencidos, 3 sin fecha, 2 reprogramados 3 veces o más. (Cifras de `portafolio.py compute`.)

### Se viene reprogramando

> **Elena Duarte** · Enviar el documento 1
> Prometido para el 2026-09-30, y antes para el 10-07, 10-28, 11-06, 11-27, 12-06; hoy para el **2026-12-20**. Seis reprogramaciones desde el 09-04.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuentes: comités 09-11, 09-18, 09-25, 10-02, 10-09 y notas del 10-16.

> **Laura Vélez** · Cerrar la prueba 2
> Prometido para el 2026-10-02, y antes para el 10-13, 10-30, 11-18, 11-26; hoy para el **2026-12-13**. Cinco reprogramaciones desde el 09-04.
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuentes: comités 09-11, 09-18, 09-25, 10-02 y 10-09.

Nota: Laura Vélez tiene además un compromiso sin fecha (ver abajo).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Paula Céspedes | Actualizar la matriz 6 (reprogramado 1 vez; antes 09-14) | 2026-09-28 | 18 días |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 | 14 días |
| Gustavo Neira | Revisar el anexo 3 (reprogramado 2 veces; original 09-13) | 2026-10-03 | 13 días |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 | 9 días |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 | 4 días |
| Mauricio Pérez | Aprobar el diseño 5 (reprogramado 1 vez; original 10-06) | 2026-10-14 | 2 días |
| Diana Molina | Revisar el anexo 19 | 2026-10-14 | 2 días |

- **Mauricio Pérez dice que ya entregó el diseño 5** (comité del 09-25); no hay acta de recibo ni nada en el expediente que lo respalde. Sigue abierto.
- Gustavo Neira y Mauricio Pérez tienen dos vencidos cada uno.
- Uno de los vencidos es de la gerente del proyecto (Paula Céspedes).

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Actualizar la matriz 14 | 2026-10-16 (hoy) |

- Ricardo Salas dijo en el comité del 10-02 que ya entregó; no se presentó acta. Sigue abierto hasta que haya documento.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Carlos Peña | Cerrar la prueba 18 | 2026-10-02 |
| Rubén Cárdenas | Actualizar la matriz 22 | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; nadie dijo fecha) | 2026-10-16 |

No pueden estar vencidos; se cuentan aparte para que no desaparezcan. El de Carlos Peña lleva 14 días sin fecha.

### Cerrados desde la última revisión
Cada uno contra su acta de recibo:
- Felipe Arango · Validar el ambiente 4 → `20-seguimiento/2026-10-09-acta-recibo-4.md`
- Camilo Beltrán · Entregar el punto 16 → `20-seguimiento/2026-10-09-acta-recibo-16.md`
- Gustavo Neira · Aprobar el diseño 13 → `20-seguimiento/2026-10-02-acta-recibo-13.md`
- Elena Duarte · Entregar el punto 8 → `20-seguimiento/2026-09-25-acta-recibo-8.md`
- Javier Hoyos · Cerrar la prueba 10 → `20-seguimiento/2026-09-25-acta-recibo-10.md`
- Rubén Cárdenas · Revisar el anexo 11 → `20-seguimiento/2026-09-25-acta-recibo-11.md`

### Contradicción con el estado declarado
El informe de avance del 2026-10-11 declara **verde**. Con 7 compromisos vencidos, 2 reprogramados repetidamente y un hito («Ingeniería básica aprobada», 2026-06-09) marcado cumplido sin evidencia, ese verde no está sustentado por los documentos. Decidir qué hacer con él es del gerente.

### Después
- **Elena Duarte (6 reprogramaciones) y Laura Vélez (5)**: se puede formular como decisión para el comité (próximo: 2026-10-30): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente. Se hace con `/pm-escalate`.
- Si cambian lo que dice la ficha, `/pm-publish` para que la PMO lo vea.
