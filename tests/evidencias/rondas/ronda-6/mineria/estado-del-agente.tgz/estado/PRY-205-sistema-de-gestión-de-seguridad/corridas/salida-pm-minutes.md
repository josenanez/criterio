# Acta — Sistema de gestión de seguridad (PRY-205) · 2026-10-16
**Asistieron:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-16-notas-reunion.txt` (notas de una persona, no transcripción; sin autor ni agenda) · **Ausentes con tema en agenda:** no se puede decir: las notas no traen agenda.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 («no alcanzó») | 2026-12-20 (dicho como 20/12/2026) | **Reprogramado 6 veces.** Promesa original 2026-09-30; luego 10-07, 10-28, 11-06, 11-27, 12-06 y 12-20. Hoy se corre 14 días más y queda 81 días después de la promesa original (la distancia entre 09-30 y 12-20). No es un compromiso nuevo. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. La nota dice «queda para el 2026-10-26»; no dice «me comprometo», se registra a su nombre por la atribución de la línea. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana»; nadie dio fecha. Se registra `due_date: no_declarada`, sin elegir un día de esa semana. |

Con ella, ya son 3 compromisos sin fecha en el proyecto (los otros: Carlos Peña, «Cerrar la prueba 18»; Rubén Cárdenas, «Actualizar la matriz 22»). No pueden vencerse, y por eso no salen en ningún informe de vencidos.

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Nada se dejó explícitamente como pendiente de decisión. Las notas no dicen qué se hará con el riesgo del proveedor (ver más abajo).

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas dicen que «nadie lo anotó como riesgo» | No se sabe: las notas dicen «se comentó» y no atribuyen | Riesgo (recurso del proveedor, fase siguiente) | **No.** Está en la ficha con `registered: false` y sin responsable. La carpeta no tiene un registro RAID del proyecto donde estuviera. Ojo: la fase no está identificada en el expediente (`identity.phase` no se encontró) ni hay contrato de proveedor en la carpeta (`vendors` vacío), así que no hay con qué medir el riesgo. |

## Cerrado en esta reunión
Nada. Elena dice que lo suyo no alcanzó; nadie presentó documento de cierre.

## Lo que esta reunión contradice
Ningún campo de la ficha (patrocinador, comité, fechas de cierre). Una cosa para mirar:

| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-30) | La configuración dice comité semanal; la próxima fecha configurada, 2026-10-30, coincide con las dos semanas | Notas 2026-10-16 / configuración de PRY-205 |

No es una contradicción de la ficha, es un dato para confirmar: si el comité pasó a quincenal, la cadencia configurada está desactualizada.

## Sin resolver de la transcripción
- «la otra semana» (Laura Vélez): sin día. Ver Sin fecha.
- «se comentó que el proveedor podría no llegar…»: no se sabe quién lo dijo ni de qué fase habla.
- «revisión con el proveedor, queda para el 2026-10-26» (Óscar Ramírez): no queda claro si es un compromiso suyo o una cita agendada de la que solo participa; tampoco si es un cambio de fecha de algo previo (no hay una promesa anterior suya sobre esto en el historial).
- Las notas no dicen nada de los vencidos de los asistentes Gustavo Neira, Mauricio Pérez, Diana Molina y Sandra Gil: ni que los entregaron, ni que los movieron.

## Cómo queda el seguimiento tras esta acta
Calculado por el script, no a mano:
- **Vencidos sin evidencia: 7.** Gustavo Neira (anexo 3, 13 días; fecha 7, 14 días), Mauricio Pérez (diseño 5, 2 días; ambiente 12, 4 días), Paula Céspedes (matriz 6, 18 días), Sandra Gil (fecha 15, 9 días), Diana Molina (anexo 19, 2 días).
- **Sin fecha: 3.** Laura Vélez, Carlos Peña, Rubén Cárdenas.
- **Reprogramados 3 veces o más: 2.** Elena Duarte (6 veces) y Laura Vélez, «Cerrar la prueba 2» (5 veces, ahora al 2026-12-13).
- El informe del 2026-10-11 declara el proyecto en **verde**. Con lo anterior, más el hito «Ingeniería básica aprobada» marcado cumplido sin evidencia (129 días), ese verde no lo sostienen los documentos.

## Después
`/pm-commitments` para ver el seguimiento completo. `/pm-publish` si quieres que la PMO vea la ficha; el acta no se publica sola. La guardas tú: el agente no la escribió en tu carpeta de reuniones.
