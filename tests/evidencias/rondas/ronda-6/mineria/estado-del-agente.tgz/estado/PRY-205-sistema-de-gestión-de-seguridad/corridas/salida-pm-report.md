# PRY-205 Sistema de gestión de seguridad — semana del 2026-10-10 al 2026-10-16

**Declara el gerente esta semana:** *(en blanco: la sesión no tuvo a quién preguntarle y el agente no declara por el gerente ni propone un estado)*
**Última declaración en documentos:** verde · 58 % · al 2026-10-11 (hace 5 días, vigente), `20-seguimiento/2026-10-11-informe-avance.md`
**Sustento documental:** **contradicho.** Hay cero documentos de evidencia marcados; la carpeta solo trae 2 declaraciones y 153 fuentes sin clasificar.
**Lo que el semáforo no explica:** compromisos vencidos (7), compromisos reprogramados (2) e hito «cumplido» sin evidencia (1).

## Qué cambió esta semana
Esta es la primera corrida registrada de este proyecto: no hay corrida anterior contra la cual comparar y `diff` devuelve 0 cambios. No se puede decir qué cambió; solo qué hay hoy. La semana que viene este apartado ya tendrá contenido.

## Lo que sigue igual y sigue mal
Sin corrida anterior, «desde cuándo» es la fecha de vencimiento o el hito, no la última vez que se miró.

| Qué | Desde | Días así |
|---|---|---|
| Hito «Ingeniería básica aprobada» declarado cumplido, sin evidencia | vencía 2026-06-09 | 129 |
| Paula Céspedes — Actualizar la matriz 6 | 2026-09-28 | 18 |
| Gustavo Neira — Confirmar la fecha 7 | 2026-10-02 | 14 |
| Gustavo Neira — Revisar el anexo 3 | 2026-10-03 | 13 |
| Sandra Gil — Confirmar la fecha 15 | 2026-10-07 | 9 |
| Mauricio Pérez — Validar el ambiente 12 | 2026-10-12 | 4 |
| Mauricio Pérez — Aprobar el diseño 5 | 2026-10-14 | 2 |
| Diana Molina — Revisar el anexo 19 | 2026-10-14 | 2 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-04-23 | 2027-04-23 | 0 días / 0 días |
| Presupuesto aprobado | COP 800.000.000 | COP 800.000.000 | proyección −4,3 % bajo lo aprobado |

Replanificaciones: **0**. La desviación en fechas es cero porque la línea base nunca se movió, no porque el plan se haya verificado. El único hito que da avance al plan (1 de 3) no tiene evidencia.
Avance declarado 58 %; el plan sostiene entre 33 % y 67 % (1 de 3 hitos). Sin brecha formal, pero el 58 % descansa sobre ese hito sin evidencia.

### Hitos de las próximas cuatro semanas (hasta 2026-11-13)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno cae en la ventana | | | |

El siguiente, «Ingeniería de detalle aprobada», vence el 2026-11-15 (30 días), dos días después de la ventana, sin evidencia y sin replanificar. «Licencia y permisos obtenidos»: 2027-04-23.

## Las cifras (COP, al 2026-10-11)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 324.133.771 (40,5 %) | 258.170.381 (32,3 %) | 765.512.063 | **475.866.229** (aprobado − comprometido) |

Se ha ejecutado el 32,3 % del dinero frente a un avance declarado de 58 %.

## Abierto
**Reprogramados:**
- Elena Duarte — Enviar el documento 1: **6 veces**; original 2026-09-30, hoy 2026-12-20.
- Laura Vélez — Cerrar la prueba 2: **5 veces**; original 2026-10-02, hoy 2026-12-13.

Ambos pasaron el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:** los 7 de la tabla de arriba.
**Sin fecha:** Carlos Peña — Cerrar la prueba 18 (comité 2026-10-02); Rubén Cárdenas — Actualizar la matriz 22 (comité 2026-10-09); Laura Vélez — Mandar el ajuste del presupuesto (notas 2026-10-16).
**RAID sin movimiento:** 3 riesgos y 1 incidencia, ninguno con dueño. Sin fecha de apertura, así que no se pueden contar los días.
- Riesgo: ventana de parada de planta definida por operaciones.
- Riesgo: cambio en la licencia ambiental que puede mover el alcance.
- Riesgo **no registrado**: el proveedor podría no llegar con el equipo completo para la siguiente fase (se dijo en la reunión del 2026-10-16 y nadie lo anotó).
- Incidencia: el equipo perdió dos semanas por rotación de un ingeniero clave. Esas dos semanas de atraso no aparecen en el cronograma ni en ninguna replanificación.

**Proveedor:** no hay contratos en la carpeta; no se puede contrastar entregables ni facturación.

## Lo que necesito de alguien
- **Paula Céspedes:** declarar el estado de la semana. La declaración vigente es verde y la evidencia no la cubre.
- **Paula Céspedes:** aportar la evidencia de la aprobación de «Ingeniería básica aprobada», o corregir el estado del hito.
- **Elena Duarte y Laura Vélez:** fecha firme o decisión de descartar los compromisos reprogramados 6 y 5 veces.
- **Carlos Peña, Rubén Cárdenas, Laura Vélez:** fecha para sus compromisos sin fecha.
- **Paula Céspedes:** registrar el riesgo del proveedor con dueño, y poner dueño a los riesgos y a la incidencia abiertos.
- **Para el comité (excede al gerente):** decidir qué se hace con dos compromisos reprogramados 6 y 5 veces (paso a comité del 2026-10-30), y si las dos semanas perdidas por la rotación justifican replanificar.

## Lo que no se sabe
**Sin dato:** producto asociado (el acta dice «No aplica»), autoridad, fase, contratos de proveedor.
**Silencio:** último documento hace 0 días (notas del 2026-10-16); último informe de avance hace 5 días; último comité semanal (2026-10-09) hace 7 días. No hay silencio. Lo que falta es evidencia: 0 documentos marcados como evidencia.

---
Ficha `PRY-205` (actualizada 2026-10-16), datos al 2026-10-11 y notas del 2026-10-16. 4 campos sin dato. Términos v1.1 (criterio-project 0.3.12): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
Este informe es un borrador de trabajo: cada dato lleva su fuente, y la verificación es de quien lo lea.
