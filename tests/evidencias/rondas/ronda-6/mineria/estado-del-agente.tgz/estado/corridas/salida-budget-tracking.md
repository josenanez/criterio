Documentos de los que sale: acta de constitución (2026-02-06), informe de avance (corte 2026-10-13) y solicitud de cambio CC-01 (2026-10-12) de PRY-209. Cifras recalculadas con `portafolio.py compute` al 2026-10-16. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16.

## Presupuesto — PRY-209 Electrificación de equipos al 2026-10-16
**Moneda:** COP (única; no hay otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 4.200.000.000 | 100 | Acta de constitución | 2026-02-06 |
| Comprometido | 2.559.247.474 | 60.9 | Informe de avance | 2026-10-13 |
| Ejecutado | 788.256.015 | 18.8 | Informe de avance | 2026-10-13 |
| Proyección al cierre | 5.247.860.031 | 124.9 (24.9 sobre el aprobado) | Informe de avance | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 1.640.752.526 COP

La proyección es una declaración de la gerente (Diana Molina), no un dato medido. Tiene la misma fecha que el comprometido y el ejecutado, así que no es más vieja que el último movimiento de presupuesto que consta.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 4.200.000.000 | 4.200.000.000 | 0 |
| Cierre | 2027-01-19 | 2027-01-19 | 0 días |

Replanificaciones de presupuesto: 0. Hay una solicitud de cambio, CC-01 (2026-10-12): ampliación de alcance, +186.000.000 COP y +93 días sobre la línea base vigente. Su autorización dice "Pendiente de presentación al comité", así que la línea base no se ha movido y no se suma a nada de lo anterior.

### Ejecución frente a avance
Ejecutado 18.8% · Hitos cumplidos: sin dato (ningún documento declara hitos) · Avance declarado 45%.
Lectura: el ejecutado es menos de la mitad del avance declarado. Sin hitos no se puede decir cuál de las dos cifras falla. Puede ser trabajo hecho y aún no causado, que aparecería de golpe, o puede ser un avance sobreestimado. El comprometido (60.9%) está por encima del avance declarado, lo que apunta a contratación adelantada a la ejecución.

### Alertas
- **Proyección excede el aprobado en 24.9%** (5.247.860.031 contra 4.200.000.000). Supera el umbral de desviación de costo (10%). El informe de avance declara estado amarillo y no explica esta desviación.
- El comprometido (60.9%) está por debajo del umbral de 90%. No hay alerta por comprometido.
- No hay alerta de ejecución desalineada formal, porque faltan hitos con los que medirla.

### Sin dato
- Hitos del proyecto: no hay cronograma en la documentación. Sin ellos no hay cruce entre ejecución y avance de hitos.
- Detalle del comprometido por proveedor o contrato: ningún documento lo da, y la ficha no tiene proveedores.
- Base de la proyección: el informe no dice cómo se calculó.
- Fase, producto y autoridad del proyecto: no declarados.

### Después
La proyección excede el aprobado. Puedo preparar la solicitud de cambio de presupuesto. Ojo: CC-01 sólo pide 186.000.000 COP, y la proyección declarada excede el aprobado en una cifra mucho mayor. Hoy ese cambio no cubre la brecha que la propia gerente proyecta.

*Pie de rigor: borrador de trabajo sobre los documentos citados, no una decisión. Cada cifra sale de los documentos o del cálculo del script. La verificación es de quien decide.*
