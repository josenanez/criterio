# Corrida del 2026-10-16 · status-report

13 proyectos · 28 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Informe de PRY-204: amarillo/81% declarado, sin evidencia de 3 de 4 hitos cumplidos, hito de pruebas vencido 4 días. Dijo no saber: autoridad, fase, proveedores, última reunión, fechas de riesgos.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-204.json` (actualizada 2026-10-16), cifras recalculadas con `compute` al 2026-10-16. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-16.

## PRY-204 · Monitoreo de taludes — estado al 2026-10-16

**Declara el gerente:** amarillo · 81% · al 2026-10-13 (Laura Vélez, informe de avance; 3 días de antigüedad, vigente)
**Sustento documental:** sin sustento. El cálculo registra 0 fuentes de evidencia y 2 de declaración; de 4 hitos declarados cumplidos solo 1 tiene documento que lo respalde.
**Lo que el semáforo no explica:** `milestone_overdue` (Pruebas en operación, 4 días de atraso) y `milestone_met_without_evidence` (3 hitos).
**Último documento:** 2026-10-13 (3 días de silencio) · **Última reunión:** sin dato, no hay actas de reunión en la carpeta.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-12 | 2026-10-12 | 0 días (la fecha ya pasó y el hito de cierre sigue pendiente) |
| Presupuesto | COP 3.300.000.000 (aprobado) | COP 3.300.000.000 | Proyección COP 3.081.945.482: −6,6 % frente a lo aprobado |

Replanificaciones: 0. Cambios de control de cambios registrados: 0.

Dinero (al 2026-10-13): comprometido COP 1.956.619.363 (59,3 %), ejecutado COP 1.741.956.167 (52,8 %), disponible real COP 1.343.380.637.

Avance: el 81 % declarado cae dentro de lo que el plan soporta (80–100 %, 4 de 5 hitos cumplidos); brecha 0 puntos. Pero ese plan cuenta como cumplidos hitos que no tienen evidencia.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-03-27 | 2026-03-27 | cumplido (declarado) | ninguna (203 días) |
| Ingeniería de detalle aprobada | 2026-05-16 | 2026-05-16 | cumplido (declarado) | ninguna (153 días) |
| Licencia y permisos obtenidos | 2026-07-04 | 2026-07-04 | cumplido | acta de recibo 2026-10-07 |
| Montaje e instalación | 2026-08-23 | 2026-08-23 | cumplido (declarado) | ninguna (54 días) |
| Pruebas en operación | 2026-10-12 | 2026-10-12 | pendiente, vencido 4 días | — |

### Dónde no coincide
- Declarado: amarillo, 81 %, avance «normal» con equipos entregados (informe 2026-10-13). Documentos: el único hito con acta (licencia y permisos) se documentó el 2026-10-07, más de tres meses después de su fecha base (2026-07-04); los otros tres hitos «cumplidos» no tienen documento de aceptación; y la fecha de cierre ya venció con las pruebas sin hacer. El amarillo no explica esas dos señales.
- Los equipos se entregaron «pendientes de aceptación»: el montaje figura como cumplido (base 2026-08-23) mientras la entrega aún no se acepta. Son dos fuentes del mismo informe y del cronograma que no cuadran entre sí.

### Abierto
**Riesgos e incidencias sin movimiento:** la ficha no guarda fecha de apertura de los dos riesgos (proveedor sin confirmar fecha de última entrega; bloqueo de la vía de acceso a la mina), así que no se pueden contar días. Incidencia: equipos entregados pendientes de aceptación, desde 2026-10-13, sin responsable asignado.
**Compromisos vencidos:** ninguno registrado (no hay compromisos en la ficha; tampoco hay actas de reunión).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad del proyecto (`identity.authority`) y fase (`identity.phase`).
- Proveedores/contratos: ninguno en la carpeta, aunque el informe habla de un proveedor que entrega equipos; no se puede contrastar entregable contra factura.
- Última reunión y razón del retraso de «Licencia y permisos» respecto de su fecha base.
- Fecha de apertura y responsable de los riesgos e incidencias.

### Después
No hay desviación en cifras sobre el umbral (10 %), pero hay un hito de cierre vencido y tres hitos sin evidencia. Puedo preparar el punto de comité del 2026-10-19 y pedir al gerente las actas de aceptación de los hitos sin sustento, si lo quieren.

---
Pie: criterio-portfolio 0.3.12 · ficha PRY-204 aplicada, actualizada 2026-10-16 · campos inciertos: autoridad, fase, proveedores, última reunión · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
