# Corrida del 2026-10-16 · health-check

13 proyectos · 79 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Diagnóstico de PRY-201 sobre 8 documentos: 3 sostenidas, 6 sin sustento, 3 contradichas. Dijo que no sabe el estado real, el gasto real, la autoridad del gerente ni por qué hay dos contratos idénticos; la factura FV-2600 no tiene acta de recibo.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-201 · Ampliación de la relavera · 2026-10-16

**Leí:** 8 documentos · 2026-01-31 a 2026-10-15 · formatos: md (3), docx (2), xlsx (1), pdf (2). Busqué el código y el nombre del proyecto en el resto de la carpeta de proyectos: ninguna otra minuta ni documento lo menciona.
**No pude leer:** nada quedó sin leer. Los dos PDF (acta de recibo e informe de avance) se leyeron por su texto extraído; no vi el aspecto original, firmas ni sellos.

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se volvieron a pedir.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 6 · **Contradicho:** 3

- Sostenidas: (1) presupuesto aprobado de 4.200.000.000 COP; (2) Ingeniería básica aprobada, con acta de recibo del 2026-10-07; (3) el compromiso de Carlos Peña dicho en el comité del 2026-10-08.
- Contradichas: (1) estado «verde»; (2) avance de 76 %; (3) la factura FV-2600 como cobro de entregables recibidos.
- Sin sustento: (1) comprometido; (2) ejecutado; (3) proyección al cierre; (4) Ingeniería de detalle aprobada; (5) el riesgo de licencia ambiental; (6) el fallo del ensayo de disponibilidad.

Desde esta carpeta se puede afirmar que el proyecto está constituido y con presupuesto aprobado. Se puede afirmar también que el informe del 2026-10-15 lo declara en verde con 76 % de avance, y que ese estado y ese avance no los sostiene ningún otro documento. Lo que sí hay apunta en contra: 2 de 5 hitos cumplidos, una factura radicada sin acta de recibo y entregables de proveedores vencidos. No se puede afirmar nada sobre el dinero comprometido o ejecutado, porque todas esas cifras salen solo del informe del gerente.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Javier Hoyos | acta de constitución, 2026-02-05 |
| Gerente | Óscar Ramírez | acta de constitución, 2026-02-05 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente | acta de constitución, 2026-02-05 |
| Comité | Comité de Inversiones (aprobó el presupuesto el 2026-02-05) | acta de constitución, 2026-02-05 |

Otras observaciones de gobierno:
- El alcance del acta es «Componente 1, 2, 3» y la exclusión es «Lo que otro proyecto cubre». Ambos son marcadores sin contenido.
- El criterio de éxito («en producción y medido») no trae umbral.
- Las dependencias dicen «Ninguna declarada», pero el informe habla de una licencia ambiental que puede mover el alcance y el cronograma tiene un hito de licencia y permisos.
- Los dos contratos son anteriores a la aprobación del acta. CT-600 se firmó el 2026-01-31 y CT-563 el 2026-02-03; el acta es del 2026-02-05. La carpeta no dice con qué autorización se contrató.
- Sin autoridad declarada no hay desviación aprobada, solo fechas que alguien escribió.

### Contra el plan
Hay una sola línea base, la versión 1, aprobada el 2026-02-05 por el Comité de Inversiones, con cierre el 2027-04-18. No hay replanificaciones (0) ni solicitudes de cambio (0). `compute` da desviación de 0 días contra la original y contra la vigente.

Ese cero no significa que el plan se esté cumpliendo. Dice que nadie movió las fechas. Los cinco hitos tienen fecha vigente igual a la de la línea base, aunque hay entregables de proveedores vencidos (ver abajo). El cronograma tiene 2 de 5 hitos cumplidos y `compute` dice que el plan sostiene un avance de entre 40 % y 60 %.

La Ingeniería básica aprobada figura como cumplida con fecha de línea base 2026-05-11. Su acta de recibo es del 2026-10-07, posterior a esa fecha. La diferencia en días no la da el script, así que no la calculo. Lo que sí consta es que el acta se firmó después de la fecha plan y el cronograma nunca se actualizó.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería de detalle aprobada (figura «cerrado») | 2026-08-04 | 73 | Acta de recibo o de aprobación de la ingeniería de detalle |
| CT-600 · Licenciamiento del software | 2026-06-12 | 126 | Acta de recibo firmada por el gerente |
| CT-563 · Licenciamiento del software | 2026-06-12 | 126 | Acta de recibo firmada por el gerente |
| CT-600 · Bolsa de horas de ingeniería | 2026-10-08 | 8 | Acta de recibo firmada por el gerente |
| CT-563 · Bolsa de horas de ingeniería | 2026-10-08 | 8 | Acta de recibo firmada por el gerente |

Ningún hito del cronograma está vencido sin cerrar según `compute`. El próximo vence el 2026-10-29: «Licencia y permisos obtenidos», todavía en curso.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 1.599.687.700 | 868.334.873 | 4.040.633.078 | 2.600.312.300 |

- COP. Ejecutado: 20,7 % del aprobado. Comprometido: 38,1 %. La proyección queda 3,8 % por debajo del aprobado.
- Frente a un avance declarado de 76 %, lo ejecutado es 20,7 %.
- Comprometido, ejecutado y proyección salen solo del informe del gerente del 2026-10-15. Ningún otro documento los respalda.
- Facturado: CT-600 tiene una factura FV-2600 del 2026-09-23 por 371.934.503 COP, radicada en cuentas por pagar. Esa suma coincide con el monto de un entregable del contrato. CT-563 no tiene facturas en la carpeta.
- `compute` no da el total de los montos contractuales, así que no lo escribo ni lo contrasto con el comprometido. Cada contrato fija un monto por entregable: 371.934.503 en CT-600 y 436.824.099 en CT-563.

### Lo que se dijo y nadie registró
- **Compromiso:** Carlos Peña, «Entregar el punto 36», para 2026-10-28 (comité del 2026-10-08). Está abierto y no vencido.
  - La minuta lista como asistentes solo a Óscar Ramírez y Javier Hoyos, así que Carlos Peña no estuvo.
  - Ningún documento dice qué es el «punto 36».
  - La minuta nombra los temas «Avance» y «Compromisos», pero no registra decisiones, riesgos ni lo que se habló.
- **Riesgo:** el cambio en la licencia ambiental aparece solo en el informe de avance. No hay registro de riesgos, ni dueño, ni fecha, ni mención en la minuta del 2026-10-08.
- **Incidencia:** el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite. Está solo en el informe, sin dueño (`owner` vacío) y sin fecha de repetición.
  - El proyecto es una ampliación de relavera y el cronograma no tiene un hito de ensayo de disponibilidad. Tampoco dice qué equipos ni qué se pactó.
  - Pese a ello el informe declara «Verde».
- **Dependencias:** ninguna registrada.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado «Verde» | Informe de avance 2026-10-15: «Verde» | El mismo informe reporta un ensayo fallido y un riesgo abierto. `compute` marca 4 señales sin explicar: hito cumplido sin evidencia, avance contra plan, entregables de proveedor vencidos y factura sin entrega |
| Avance 76 % | Informe de avance 2026-10-15: 76 % | Cronograma v1: 2 de 5 hitos cumplidos; el plan sostiene 40–60 % (16 puntos de diferencia, el informe va por delante). Ejecutado: 20,7 % del aprobado |
| Factura FV-2600 (371.934.503 COP, «Entregables del contrato CT-600») | Factura del 2026-09-23, radicada en cuentas por pagar | CT-600: se factura contra acta de recibo firmada por el gerente. En la carpeta no hay ninguna acta de CT-600 y sus tres entregables figuran en estado «pendiente» o «en curso». |

### Sin sustento
- **Comprometido (1.599.687.700), ejecutado (868.334.873) y proyección (4.040.633.078):** solo salen del informe del gerente. No hay estado de ejecución ni documento contable.
- **Ingeniería de detalle aprobada, «cerrado»:** el cronograma la da por cumplida el 2026-08-04, sin acta ni otro documento que lo respalde.
- **Riesgo de licencia ambiental:** aparece solo en el informe. El hito «Licencia y permisos obtenidos» sigue en curso para 2026-10-29, pero eso no confirma el riesgo.
- **Ensayo de disponibilidad fallido:** solo aparece en el informe.
- **El resto del informe:** los 18 datos extraídos de la ficha no traen marca de evidencia. Según `compute`: 0 de evidencia, 2 de declaración y 16 sin marcar.

### Lo que esta carpeta no permite saber
- **Si el estado real es verde, amarillo o rojo.** No hay una sola evidencia independiente del gerente sobre el avance físico. Sin acta de ingeniería de detalle ni actas de proveedores, el 76 % no se puede contrastar.
- **Si se pagó o se va a pagar sin recibo.** Hay una factura radicada de 371.934.503 COP sin acta de recibo, y la condición de pago del contrato la exige. No hay orden de pago ni aprobación en la carpeta.
- **Cuánto se ha gastado de verdad.** Faltan el estado de ejecución presupuestal y las facturas de CT-563. Sin ellos no se pueden contrastar el comprometido, el ejecutado ni la proyección.
- **Qué puede decidir el gerente.** El acta no declara su autoridad. Cualquier cambio de fecha o de alcance quedaría sin quién lo haya aprobado.
- **Por qué hay dos contratos con los mismos tres entregables y fechas.** CT-600 y CT-563 tienen los mismos nombres de entregable y las mismas fechas (2026-06-12, 2026-10-08 y 2027-02-02) con proveedores distintos, y los estados se cruzan. Los entregables («licenciamiento del software», «bolsa de horas», «calibración de sensores») tampoco se explican con el alcance de una relavera. La carpeta no aclara si es duplicidad, traslape o plantilla.
- **Qué pasó con Ingeniería básica entre mayo y octubre.** Se cerró en el cronograma con fecha de mayo y el acta es de octubre. No hay minuta ni informe que lo explique.
- **Qué decidió el comité.** La única minuta no registra decisiones, y no hay minutas anteriores.
- **Qué es el «punto 36».** Sin eso el compromiso del 2026-10-28 no se puede verificar.

---
**Pie de rigor:** 8 documentos de PRY-201 leídos completos, ninguno omitido. Toda cifra derivada (porcentajes, días, disponible, señales) está copiada de `compute` del 2026-10-16; las que el script no da no se calcularon. Lo declarado por el gerente y lo probado por documentos se mantienen separados; de los datos extraídos ninguno viene de evidencia independiente. Este diagnóstico no recomienda detener, continuar ni reestructurar el proyecto: esa decisión es de quien tiene la facultad. No encontré la definición del «pie de rigor» en el plugin, así que este pie es el mínimo que puedo sostener.

**Qué puedo hacer ahora:** llevar las 3 contradicciones al gerente como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.
