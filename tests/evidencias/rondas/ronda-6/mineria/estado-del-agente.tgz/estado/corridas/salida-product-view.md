Fuente: fichas del portafolio en `estado/`, recalculadas con `portafolio.py compute` al 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Producto: gemelo digital

El producto «gemelo digital» tiene un solo proyecto, PRY-207 (Gemelo digital de la planta). La vista por producto no aporta nada distinto a la del proyecto, así que no armo sección de producto: no hay señales que sumar entre proyectos ni dependencias internas que cruzar (`dependencies` está vacío).

Lo que sí dice el cálculo sobre ese único proyecto (9 alertas):
- Declara verde y 87 % de avance (informe del 2026-10-14), pero 3 de las señales abiertas no están reconocidas en esa declaración.
- 4 hitos declarados cumplidos sin evidencia: Ingeniería básica (vence 2026-02-07), Ingeniería de detalle (2026-04-11), Licencia y permisos (2026-06-14), Montaje e instalación (2026-08-16).
- Proveedor Automatización de Procesos Ltda. (CT-101): 2 de 4 entregables aceptados; Licenciamiento del software (vencido hace 245 días) y Calibración de sensores (105 días) siguen pendientes. Facturado COP 3.363.389.644 contra aceptado COP 2.876.935.730: diferencia de COP 486.453.914 (4 de 4 montos declarados).
- Compromiso sin fecha: Gustavo Neira, «Entregar el punto 21» (comité semanal 2026-10-14).
- Fecha comprometida del producto: 2026-10-19, de PRY-207 (único proyecto). Desviación contra línea base original y vigente: 0 días.
- Dinero (1 de 1 proyecto con las cuatro cifras, COP): aprobado 18.000.000.000; comprometido 11.117.330.735 (61,8 %); ejecutado 5.640.512.961 (31,3 %); proyección 18.154.854.182 (0,9 % sobre lo aprobado).
- Faltan en la ficha: autoridad (`identity.authority`) y fase (`identity.phase`).

## Proyectos sin producto declarado

Siete de los 13 proyectos no declaran producto. Nadie puede responder por el conjunto al que sirven.

| Proyecto | Nombre | Área dueña |
|---|---|---|
| PRY-201 | Ampliación de la relavera | no consta en el cálculo |
| PRY-202 | Planta de tratamiento de agua | no consta en el cálculo |
| PRY-205 | Sistema de gestión de seguridad | no consta en el cálculo |
| PRY-206 | Red privada LTE en mina | no consta en el cálculo |
| PRY-209 | Electrificación de equipos | no consta en el cálculo |
| PRY-210 | Programa de relacionamiento comunitario | no consta en el cálculo |
| PRY-211 | Control de polvo en vías | no consta en el cálculo |

El área dueña no sale de `compute`; no la escribo sin leer las fichas.

## Pie de rigor
Cifras copiadas de la salida de `compute`. Creencia no verificada: que el producto tenga un único proyecto asume que las fichas de los otros 12 proyectos no lo mencionan; el cálculo agrupa solo por `identity.product`. Criterio produce borradores; la verificación contra los documentos citados es de quien decide.
