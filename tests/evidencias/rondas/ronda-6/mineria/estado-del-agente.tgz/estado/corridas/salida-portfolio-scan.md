## Barrido — 2026-10-16

Antes de leer nada: términos vigentes (v1.1, familia 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16; no se registraron de nuevo. En las demás preguntas se tomó la respuesta sugerida (sesión sin interfaz).

**Documentos:** 78 en la carpeta · 52 leídos · 26 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 carpetas · 13 con ficha (10 escritas en esta corrida, 3 que ya estaban: PRY-202, PRY-205, PRY-208) · 10 nuevos · 0 sin carpeta propia

Formatos: 41 .md, 13 .pdf, 12 .docx, 5 .csv, 5 .xlsx, 1 .json, 1 .txt. Plan: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Nada diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, producto (PRD-299), presupuesto, 5 hitos, contrato CT-199, avance, 1 compromiso | autoridad, fase |
| PRY-200 Mantenimiento predictivo de camiones | 4 | identidad, producto, presupuesto, 5 hitos, avance | autoridad, fase, contratos, reuniones |
| PRY-201 Ampliación de la relavera | 8 | identidad, presupuesto, 5 hitos, CT-600 (con factura) y CT-563, avance, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-203 Despacho automático de flota | 6 | identidad, producto, presupuesto, 2 versiones de cronograma, CC-01, avance, 1 compromiso | autoridad, fase, contratos |
| PRY-204 Monitoreo de taludes | 4 | identidad, producto, presupuesto, 5 hitos, avance | autoridad, fase, contratos, reuniones |
| PRY-206 Red privada LTE en mina | 2 | identidad, presupuesto, avance | producto, autoridad, fase, cronograma, contratos |
| PRY-207 Gemelo digital de la planta | 8 | identidad, producto, presupuesto, 5 hitos, CT-101 (con factura y 2 actas), avance, 2 compromisos | autoridad, fase |
| PRY-209 Electrificación de equipos | 3 | identidad, presupuesto, CC-01, avance | producto, autoridad, fase, cronograma, contratos |
| PRY-210 Programa de relacionamiento comunitario | 8 | identidad, presupuesto, 5 hitos, CT-855 (con factura y 2 actas), avance | producto, autoridad, fase |
| PRY-211 Control de polvo en vías | 3 | identidad, presupuesto, CC-01, avance | producto, autoridad, fase, cronograma, contratos |

### Actualizados
Ninguno. Los 26 documentos sin cambio pertenecen a PRY-202, PRY-205 y PRY-208, cuyas fichas no se tocaron.

### Lo que hay que mirar (declaración contra evidencia, tal como quedó en las fichas; no es dictamen)
- **PRY-203**: el cronograma v2 (2026-10-04) movió «Licencia y permisos obtenidos» de 2026-01-21 a 2026-05-21; no trae motivo ni aprobación y se registró como línea base v2 con «no declarado». El cierre del acta (2026-01-21) ya pasó, el avance declarado es 58% en verde, y CC-01 (+120 días, +240.000.000 COP) está pendiente de presentarse al comité. El compromiso de Gustavo Neira (punto 37) vence 2026-10-01, antes de la fecha del comité que lo registra (2026-10-12), sin evidencia de cumplimiento.
- **PRY-207**: la factura FV-1101 (3.363.389.644 COP, 2026-09-13) está radicada; el contrato CT-101 tiene 2 entregables recibidos con acta (1.438.467.865 COP c/u). El cálculo de la brecha lo hace el script de informe. El compromiso de Gustavo Neira (punto 21) quedó «por definir», sin fecha.
- **PRY-210**: factura FV-1855 (5.600.547.495 COP, 2026-09-28) frente a 2 actas de recibo (licenciamiento y bolsa de horas); «Soporte del primer trimestre» figura recibido en el contrato sin acta. Los 5 hitos están declarados cerrados (cierre del acta 2026-05-22) y el informe reporta 56% en amarillo.
- **PRY-201**: factura FV-2600 (371.934.503 COP) de CT-600 radicada con los 3 entregables de CT-600 en pendiente/en curso y sin acta. Avance declarado 76% en verde.
- **Hitos declarados cerrados sin acta que lo pruebe**: PRY-201 (detalle), PRY-203 (3 hitos), PRY-204 (básica, detalle, montaje), PRY-207 (4 hitos), PRY-210 (4 de 5). Solo constan actas de «Ingeniería básica aprobada» en PRY-199, 200, 201 y 210, y de «Licencia y permisos obtenidos» en PRY-204; las de PRY-199, 200 y 201 son posteriores a la fecha vigente del hito.
- **PRY-204**: el acta de «Licencia y permisos» es de 2026-10-07; el hito vigente era 2026-07-04. Cierre comprometido 2026-10-12, con «Pruebas en operación» aún en curso.
- **Solicitudes de cambio pendientes de comité**: PRY-203 (CC-01), PRY-209 (CC-01, +93 días, +186.000.000 COP), PRY-211 (CC-01, +102 días, +204.000.000 COP). PRY-211 y PRY-209 no tienen cronograma en la carpeta.
- **Sin cronograma ni contratos**: PRY-206, PRY-209 y PRY-211 (el cierre de PRY-206 es 2026-11-01 y el de PRY-211 fue 2026-05-19, con 63% declarado).
- **PRY-205 (no leído en esta corrida)**: el índice marca como `source_missing` las citas de su ficha (por ejemplo `00-gobierno/2025-12-23-acta-constitucion.docx`), porque no llevan la carpeta del proyecto: no resuelven contra la raíz de documentación. No lo corregí porque no se leyó en esta corrida; queda para el siguiente barrido de ese proyecto.

### No pude leer
Ninguno.

### Movidos desde entrada/
Ninguno. No existe carpeta `entrada/` en la documentación.

### Pendientes de clasificar
Ninguno. El archivo suelto `PRY-205-…/2026-10-16-notas-reunion.txt` ya está en su proyecto y sin cambio.

### Notas de proceso
- Hay una carpeta `estado/PRY-205-sistema-de-gestión-de-seguridad/` con su propio estado (cadencia, corridas, records) que el barrido no usa; no la toqué.
- Los textos de Word, Excel, PowerPoint y PDF se convirtieron al caché `estado/cache/texto/`; las citas de las fichas apuntan a los originales.
- Los compromisos se registraron con la fecha de la reunión como `stated_on`; todos con `reschedules` vacío (una sola mención).
