## Historia · PRY-203 Despacho automático de flota · 2025-05-19 a 2026-10-12

**Leí:** 6 documentos entre 2025-05-19 y 2026-10-12 (acta de constitución, cronograma v1 en xlsx, cronograma v2 en csv, informe de avance en pdf, solicitud de cambio CC-01, acta del comité del 12 de octubre).
**Trimestres sin un solo documento:** 2025-T3, 2025-T4, 2026-T1, 2026-T2 y 2026-T3. De los siete trimestres del período, solo 2025-T2 y 2026-T4 tienen documentos.

*Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16 (comprobante ya registrado en la configuración).*

### En una línea
El proyecto se aprobó el 2025-05-19 con cierre al 2026-01-21 y no deja ningún documento durante los cinco trimestres siguientes. Todo el rastro posterior está entre el 2026-10-04 y el 2026-10-12. Ese día se escribió un cronograma v2 que mueve el hito de licencias al 2026-05-21, sin motivo ni aprobación, y un informe que declara "verde" con 58% de avance. En esa misma semana se presentó una solicitud de cambio de +120 días que sigue sin autorizar. **La distancia entre lo que pasó y lo que quedó escrito es el hallazgo:** la v1 es de 2025-05-19, la v2 es de 2026-10-04, y entre las dos no hay documentos.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 (v2, sin motivo ni aprobación) | 120 días (50.6 %) | No calculable: hay una sola declaración (2026-10-04) y no una serie | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-05-19 | `00-gobierno/2025-05-19-acta-constitucion.md` | Aprobación. Presupuesto 2.400.000.000 COP, inicio 2025-05-29, cierre 2026-01-21. Patrocinadora Liliana Torres, gerente Ricardo Salas, Comité de Operaciones. |
| 2025-05-19 | `10-plan/2025-05-19-cronograma-v1.xlsx` | Línea base v1: tres hitos, 2025-08-16, 2025-11-03 y 2026-01-21. Los tres figuran como "cerrado" en el archivo. |
| 2025-05-19 → 2026-10-04 | (sin documentos) | Más de dieciséis meses sin una sola fuente. |
| 2026-10-04 | `10-plan/2026-10-04-cronograma-v2.csv` | El hito "Licencia y permisos obtenidos" pasa de 2026-01-21 a 2026-05-21, estado "cerrado". No trae motivo ni aprobación. |
| 2026-10-04 | `20-seguimiento/2026-10-04-informe-avance.pdf` | Declara estado Verde y 58 % de avance. Presupuesto: comprometido 761.236.966, ejecutado 977.479.972, proyección 2.427.429.368. |
| 2026-10-07 | `20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md` | Ricardo Salas pide ampliación de alcance: +120 días sobre la línea base vigente y +240.000.000 COP. Autorización: "pendiente de presentación al comité". |
| 2026-10-12 | `30-reuniones/2026-10-12-comite-semanal.md` | Asisten Ricardo Salas y Liliana Torres. Temas: avance y compromisos. Un compromiso: Gustavo Neira, "Entregar el punto 37", para el 2026-10-01. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-04 | 2026-05-21 | **No declarado** | **Ninguno** |

- Atraso contra la línea base original: 120 días (50.6 %). Contra la vigente: 0 días, porque la vigente es la que se movió.
- La fecha nueva (2026-05-21) ya estaba vencida cuando se escribió el cronograma v2.
- Los 120 días movidos no tienen autorización registrada. La única solicitud de cambio (CC-01) tampoco está autorizada.
- La CC-01 pide también +120 días, y el cronograma v2 ya movió 120. Ningún documento dice si son el mismo movimiento o dos. Es una pregunta para quien firmó ambos.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos | — |

Solo el acta de 2025-05-19 y el comité de 2026-10-12 nombran a las personas, y coinciden. Una salvedad: no hay correos ni minutas intermedias, así que un cambio en el medio no habría dejado rastro en esta carpeta. "No hubo cambios" no se puede afirmar, solo que no se ven. El nombre de Gustavo Neira aparece una sola vez, en la tabla de compromisos de 2026-10-12, y no figura en el acta de constitución.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Gustavo Neira | Entregar el punto 37 | 1 | 2026-10-01 |

Ninguno se repitió, porque hay una sola reunión. El compromiso está vencido hace 15 días y no hay evidencia de entrega. Se registró en un comité del 2026-10-12 con una fecha que ya había pasado 11 días antes. Con un único acta no se puede decir si es un compromiso viejo que se anotó tarde o uno que venció antes de anotarse.

### Desde cuándo lo declarado no se sostiene
- **La declaración:** Verde, 58 %, con fecha de corte 2026-10-04. Es la única que existe.
- **Primer hito sin evidencia:** "Ingeniería básica aprobada", vencimiento 2025-08-16. Figura "cerrado" en v1 y en v2 y no hay ningún documento que lo respalde (426 días sin evidencia a hoy). Siguen "Ingeniería de detalle aprobada" (2025-11-03, 347 días) y "Licencia y permisos obtenidos" (2026-05-21, 148 días).
- **Qué se siguió reportando:** el plan da 3 de 3 hitos cerrados, que equivale a 100 %. El informe declara 58 %, una diferencia de 42 puntos. El pdf, además, cuenta como novedad del periodo que "se recibió el permiso ambiental pendiente desde el trimestre anterior". Eso no cuadra con una licencia ya cerrada el 2026-05-21, y ningún documento lo aclara.
- **Lo que no se puede fechar:** no hay serie de estados declarados antes del 2026-10-04, así que no se puede decir si fue un deslizamiento o un salto, ni desde qué mes. Lo único que se sostiene es esto: los tres hitos se declaran cumplidos y ninguno tiene evidencia, y el estado Verde convive con cinco señales abiertas (variación de tiempo, avance contra plan, hitos sin evidencia, compromiso vencido y replanificación sin autorización).
- **Dato presupuestal para revisar:** el informe reporta ejecutado (977.479.972) por encima de comprometido (761.236.966). Es 40.7 % ejecutado y 31.7 % comprometido de lo aprobado. Quien conozca la contabilidad del proyecto debería explicarlo.

### Lecciones ancladas a un hecho
1. **Una línea base movida sin acta deja de ser línea base.** Hecho: el cronograma v2 (2026-10-04) trasladó el cierre del hito de licencias 120 días y no trae motivo ni aprobación. Efecto: contra el cronograma vigente el atraso es 0 y contra el original es 120 días (50.6 %).
2. **Un hito "cerrado" sin documento no es avance medible.** Hecho: los tres hitos de v1 y v2 figuran cerrados y ninguno tiene evidencia en la carpeta. Efecto: el plan sostiene 100 % y el informe declara 58 %, y la carpeta no resuelve cuál es el correcto.
3. **Más de dieciséis meses sin documentos no dejan reconstruir cuándo se torció el proyecto.** Hecho: ningún documento entre 2025-05-19 y 2026-10-04. Efecto: la fecha desde la cual lo declarado no se sostiene no se puede fijar. Solo se sabe que a 2026-10-04 no se sostiene.

### Lo que no se sabe
- Por qué se movió la licencia y quién lo aprobó. Ningún documento lo dice.
- Si la CC-01 y el movimiento de la v2 son el mismo cambio de 120 días.
- Qué pasó entre 2025-05-19 y 2026-10-04 (hay hitos con fecha en ese lapso y ningún documento).

Este documento no atribuye intención. Que la distancia entre la fecha de cada hecho y la de su documento sea tan grande no indica que alguien la haya ocultado. Sirve para tener esa conversación con datos. Quién la tiene es una persona.

---
*Pie de rigor:* cada cifra sale de `portafolio.py compute` del 2026-10-16 y cada dato lleva su documento fuente. Los documentos citados son los 6 de `documentos/proyectos/PRY-203-despacho-automático-de-flota/`. Criterio produce borradores de trabajo, no decisiones ni asesoría, y puede equivocarse: la verificación contra los originales es de quien lo lee. Para llevar esta historia al cierre del proyecto o al comité (la próxima sesión del comité es el 2026-10-19, donde la CC-01 sigue pendiente), dímelo.
