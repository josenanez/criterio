Parto de la ficha `estado/records/PRY-202.json` y de estos documentos de `documentos/proyectos/PRY-202-planta-de-tratamiento-de-agua/`: acta de constitución (2025-09-03), contrato CT-250 (2025-08-25), cronograma v1 (2025-09-03), acta de recibo de montaje e instalación (2026-10-03), factura FV-1250 (2026-08-31) e informe de avance (2026-10-16). Las cifras salen de `portafolio.py compute` (as_of 2026-10-16). Los términos están vigentes (versión 1.1, aceptados el 2026-10-16 por José Francisco Ñáñez), así que no se registraron de nuevo.

## Cierre — PRY-202 Planta de tratamiento de agua — 2026-10-16

**Conclusión: el proyecto no está en condición de cerrarse contra lo pactado.** Lo que declara el propio gerente no es un cierre: el informe del 2026-10-16 dice estado Amarillo, avance 70 %, un ensayo de disponibilidad que no alcanzó lo pactado y "se repite", un hallazgo de auditoría de seguridad y dos riesgos abiertos. Si la PMO lo cierra hoy, se cierra por decisión, no por cumplimiento. Eso tendría que quedar escrito como decisión, con nombre.

### Contra lo comprometido
**Criterio de éxito:** "Planta de tratamiento de agua en producción y medido" (acta de constitución, 2025-09-03, sección Criterio de éxito).
**Se cumplió:** no se puede determinar, y la evidencia disponible apunta a que no. Ningún documento muestra la planta en producción ni una medición que cumpla. El único documento que habla de medición es el informe de avance, y dice que el primer ensayo de disponibilidad no alcanzó lo pactado. El acta tampoco dice qué umbral hay que medir.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Ingeniería básica aprobada (2025-11-10) | El cronograma lo marca "cerrado" | Ninguna: no hay acta ni aprobación en la carpeta (la señal sale con 340 días de vencido) |
| Ingeniería de detalle aprobada (2026-01-08) | "cerrado" | Ninguna (281 días) |
| Licencia y permisos obtenidos (2026-03-07) | "cerrado" | Ninguna (223 días) |
| Montaje e instalación (2026-05-05) | "cerrado" | Acta de recibo de Óscar Ramírez, fechada 2026-10-03 |
| Pruebas en operación (2026-07-02) | "cerrado" | Ninguna (106 días). Contradice el informe, que dice que el ensayo de disponibilidad no pasó y se repite |

El acta de recibo del montaje lleva fecha 2026-10-03. El cronograma pone ese hito el 2026-05-05 y su fecha vigente nunca cambió. El script no calcula esa diferencia, así que no escribo los días. Las dos fechas están en los documentos citados.

### Fuera de alcance final
El acta declara tres componentes sin nombre ("Componente 1, 2 y 3") y como exclusión "Lo que otro proyecto cubre". No hay ningún registro de recorte de alcance ni de control de cambios (cambios registrados: 0). Con estos documentos no se puede decir qué quedó fuera: no se puede saber qué era cada componente, ni si el entregado los cubre. No hay recorte sin decisión que señalar, pero tampoco hay forma de comprobar que no lo hubo.

| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato | Sin dato | Sin dato |

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-07-02 | 2026-07-02 | Sin cierre real: el proyecto sigue abierto al 2026-10-16 | 0 días según el script (ver nota) |
| Presupuesto aprobado (COP) | 2.400.000.000 | 2.400.000.000 | Proyección al cierre 2.469.560.038 | +2,9 % sobre lo aprobado |

Replanificaciones: 0. Hay una sola línea base (v1, 2025-09-03).

**Nota sobre la fecha.** La desviación contra la línea base sale en 0 porque nadie movió las fechas, no porque el proyecto vaya a tiempo. La fecha comprometida de cierre pasó hace 106 días y el proyecto sigue abierto. El informe dice que "se reprogramó la parada de planta" y no hay cambio ni línea base nueva que lo respalde. Es una reprogramación sin registrar.

**Presupuesto (COP, del script):** aprobado 2.400.000.000; comprometido 1.657.958.497 (69,1 %); ejecutado 537.469.391 (22,4 %); disponible real 742.041.503. Son cifras declaradas en el informe del 2026-10-16, sin respaldo contable en la carpeta. El script no entrega la diferencia en pesos entre proyección y aprobado, así que solo escribo el 2,9 %.

### RAID al cierre
**Materializados:** el ensayo de disponibilidad que no alcanzó lo pactado, y la reprogramación de la parada de planta por la ventana de mantenimiento. Ambos están en el informe del 2026-10-16. No hay un riesgo registrado que se les pueda asociar, así que no entraron como riesgos.

**No materializados (siguen abiertos como riesgo):**
- Cambio en la licencia ambiental que puede mover el alcance.
- Bloqueo de la vía de acceso a la mina.

**Abiertos y sin doliente:** los dos primeros no tienen responsable en ningún documento, así que no están cerrados. Siguen abiertos.
- Hallazgo en la auditoría de seguridad (desde 2026-10-16, sin responsable).
- Ensayo de disponibilidad que se repite (desde 2026-10-16, sin responsable).

Mientras no tengan nombre, el proyecto no se puede cerrar con estos asuntos pendientes.

**Proveedor (CT-250, Servicios Ambientales del Norte), contra lo facturado:**

| Entregable | Fecha | Monto (COP) | Estado contractual | Evidencia de recibo |
|---|---|---|---|---|
| Licenciamiento del software | 2025-12-02 | 110.830.774 | pendiente (318 días de atraso) | ninguna |
| Bolsa de horas de ingeniería | 2026-02-21 | 110.830.774 | en curso en el contrato (237 días de atraso) | ninguna |
| Calibración de sensores | 2026-05-12 | 110.830.774 | recibido | **ninguna**: no hay acta de recibo |

El contrato exige que cada entregable se facture contra un acta de recibo firmada por el gerente. La única acta en la carpeta es la de Montaje e instalación, que no es un entregable de este contrato. La factura FV-1250 (2026-08-31, 110.830.774 COP, radicada en cuentas por pagar) dice "Entregables del contrato CT-250" sin decir cuál. Su valor coincide con el de un solo entregable. El único que figura como recibido es la calibración de sensores, pero no tiene acta. Hay que confirmar con cuentas por pagar contra qué entregable se facturó y por qué no hay acta.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Se registraron como "cerrados" cuatro hitos del cronograma sin ninguna acta ni aprobación en la carpeta | Hitos con fecha entre 2025-11-10 y 2026-07-02 | El avance que respalda el plan es 100 % (5 de 5 hitos) y el gerente declara 70 %: 30 puntos de diferencia. Ninguna de las dos cifras se puede comprobar | Un hito no se marca cerrado sin su acta de aceptación en la carpeta |
| El acta de recibo del montaje se firmó el 2026-10-03, frente a una fecha de hito del 2026-05-05 que nunca se movió | 2026-05-05 / 2026-10-03 | El cronograma muestra cero desviación sobre un hito que se recibió después de la fecha | Cuando la fecha real se aparta de la comprometida, se registra el cambio y la línea base nueva el mismo día |
| El acta de constitución no define componentes ni umbral de éxito medible | 2025-09-03 | El criterio "en producción y medido" no se puede contrastar. No hay umbral contra el cual decidir si el ensayo de disponibilidad aprobó | El acta nombra cada componente y fija el umbral a medir antes de aprobar |

No registro más lecciones: el resto serían suposiciones sobre causas que ningún documento sostiene.

### Sin dato
- Evidencia de que la planta está en producción y medida; resultado numérico de cualquier ensayo; umbral pactado de disponibilidad.
- Acta o aprobación de los hitos de ingeniería básica, ingeniería de detalle, licencias y permisos, y pruebas en operación.
- Contenido de los tres componentes del alcance.
- Acta de recibo de la calibración de sensores, y a qué entregable corresponde la factura FV-1250.
- Quién decidió reprogramar la parada de planta, y con qué fecha nueva.
- Responsable de los dos asuntos abiertos (hallazgo de seguridad y repetición del ensayo).
- Fase del proyecto, producto asociado y autoridad que decide (campos vacíos en la ficha; el acta dice "No aplica" en producto).
- Respaldo contable de lo ejecutado y comprometido.
- Ningún campo de la ficha tiene fuente que sea evidencia: 0 con evidencia, 2 declaraciones y 16 sin marcar.

### Después
Sugiero **no** mover la carpeta a `archivo/` ni congelar la ficha: el proyecto no está cerrado. Cuando haya una decisión de cierre con nombre, o cuando se cumpla el criterio de éxito con evidencia, se repite este comando y se archiva entonces. Mientras tanto, PRY-202 sigue en el barrido diario.

**Pie de rigor:** el borrador sale de seis documentos y de las cifras del script; nada de lo que se habló fuera de ellos está incluido. Corresponde a la PMO y a Óscar Ramírez verificar cada dato contra su documento antes de usarlo en una decisión.
