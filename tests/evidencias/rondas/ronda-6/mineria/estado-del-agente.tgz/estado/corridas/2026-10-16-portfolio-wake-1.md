# Corrida del 2026-10-16 · portfolio-wake

13 proyectos · 22 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Barrido: 78 documentos sin cambios; 0 peticiones. Citas de PRY-205 no resuelven en el índice aunque los archivos existen (causa sin verificar). Confirmación no preguntada: sin interlocutor.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## 2026-10-16

**Revisé:** 78 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.

### Lo que cruzó un umbral
Ningún umbral cruzado por cambio de documentos: no hubo documentos nuevos, cambiados, renombrados ni borrados.

**Hallazgo de citas (PRY-205, sistema de gestión de seguridad):** el índice reporta que las rutas de fuente de todos los campos de la ficha (identidad, estado declarado, plan, dinero y 26 compromisos) no resuelven. Los archivos citados sí existen en la carpeta del proyecto (por ejemplo `00-gobierno/2025-12-23-acta-constitucion.docx` y `20-seguimiento/2026-10-11-informe-avance.md`). Lo que no sé es la causa: parece que las rutas de la ficha son relativas a la carpeta del proyecto y el índice las busca desde la raíz de documentos, pero no lo verifiqué. No toqué la ficha ni la releí: nada cambió en los documentos, y las fichas no las escribe el agente.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
La confirmación periódica toca (nunca se ha hecho), pero esta corrida no tiene a nadie que responda, así que no pregunté y no la registré como hecha. Vuelve a tocar mañana.

**Vuelvo el 2026-10-17** (el informe de comité del 2026-10-19 toca ese día, con dos días de anticipación).
