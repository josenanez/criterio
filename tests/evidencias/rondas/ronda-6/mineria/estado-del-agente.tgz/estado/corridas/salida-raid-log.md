Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16 para esta prueba.

**De qué documentos sale:** las 13 fichas (`estado/records/PRY-199` a `PRY-211`) con su RAID; las 13 actas de constitución (sección «Dependencias declaradas»); los informes de avance de los 13 proyectos (los de formato PDF los tomé tal como quedaron en la ficha, no los reabrí); y las 11 actas y notas de reunión que hay en la carpeta (PRY-199, 201, 203 y 207 una cada una; PRY-205 seis comités más las notas del 2026-10-16). No hay transcripciones.

## RAID — portafolio (13 proyectos) al 2026-10-16

**14 riesgos · 0 supuestos · 16 incidencias · 6 dependencias** (ya reclasificado; las fichas traían 20 riesgos, 0 dependencias, 0 supuestos)
**36 de 36 ítems registrados sin doliente · 14 riesgos y 6 dependencias sin fecha · 1 no registrado formalmente**
Sin movimiento: no se puede medir. Ningún ítem tiene historial; la fecha «desde» de las incidencias es la del informe donde se vio por primera vez, no la de cuando ocurrió.

Escala de valoración: la organización no definió una, así que usaría alta / media / baja. Ningún ítem trae probabilidad ni impacto, y no los inventé: figuran «sin dato».

### Reclasificados
- **«El proveedor no ha confirmado la fecha de la última entrega»** (PRY-203, 204, 206): estaba como riesgo. Depende de un tercero fuera del proyecto, así que es **dependencia**, y declarada, no acordada: el proveedor no la ha confirmado.
- **«Ventana de parada de planta definida por operaciones»** (PRY-205, 208, 209): estaba como riesgo. La fecha la fija otra área, así que es **dependencia** de Operaciones.
- Las incidencias se quedan como están (ya ocurrieron). Los riesgos de bloqueo de la vía, cambio de licencia ambiental y concentración del conocimiento se quedan como riesgo: no ocurrieron y no dependen de una entrega concreta.

### Necesitan decisión ahora
| Ref. | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-202·R2, 203·R1, 204·R1, 207·R1, 210·R2 | Riesgo | Bloqueo de la vía de acceso a la mina | sin doliente | sin fecha | Aparece en 5 proyectos con el mismo texto. Afecta a más de un proyecto y nadie lo tiene. |
| PRY-201·R1, 202·R1, 205·R1, 210·R1, 211·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin doliente | sin fecha | Mismo caso: 5 proyectos, ningún doliente. |
| PRY-205·D1, 208·D1, 209·D1 | Dependencia | Ventana de parada de planta definida por Operaciones | sin doliente | sin fecha | Está fuera de los tres proyectos y ninguno la tiene confirmada. |
| PRY-203·D1, 204·D1, 206·D1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin doliente | sin fecha | Doliente fuera del proyecto, sin respuesta registrada. No se sabe si es el mismo proveedor. |
| PRY-200·I1 | Incidencia | Hallazgo en la auditoría de seguridad | sin doliente | 2026-09-24 (22 días, la más antigua) | Abierta más de dos períodos semanales, sin responsable. |

Para el comité, cada decisión formulada: (1) ¿quién es el doliente único de la vía de acceso y de la licencia ambiental? (2) ¿Quién coordina con Operaciones una sola ventana de parada para PRY-205, 208 y 209? (3) ¿Quién exige fecha por escrito al proveedor en 203, 204 y 206? (4) ¿Quién cierra el hallazgo de auditoría de PRY-200? Si nadie decide, los 14 riesgos y 6 dependencias siguen sin dueño.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Dependencia (o riesgo; depende de que se confirme el compromiso del proveedor) | PRY-205, `2026-10-16-notas-reunion.txt` | 2026-10-16 |

Es la única. Las otras 10 actas y notas contienen solo compromisos, ningún riesgo dicho al pasar. No se inventó ninguno. La ficha de PRY-205 ya lo guarda marcado como dicho en reunión; sigue sin estar en el registro del proyecto, y decide el gerente (Paula Céspedes) si lo formaliza.

### Sin doliente o sin fecha
No se rellenó nada.
| Ref. | Tipo | Qué | Qué falta |
|---|---|---|---|
| 14 riesgos (ver registro completo) | Riesgo | Todos | Doliente, fecha de apertura, probabilidad, impacto, mitigación |
| 6 dependencias | Dependencia | Todas | Doliente, fecha, contraparte con código de proyecto, confirmación |
| 16 incidencias | Incidencia | Todas | Doliente y fecha de resolución (tienen fecha «desde») |
| Supuestos | — | Ninguno registrado | Nadie declaró supuestos en ningún proyecto. No inventé ninguno, pero 0 de 13 es ausencia de registro, no de supuestos. |

### Dependencias en riesgo
| Ref. | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-203·D1, 204·D1, 206·D1 | Proveedor (sin código de proyecto) | No | El proveedor no confirmó la fecha de la última entrega. |
| PRY-205·D1, 208·D1, 209·D1 | Operaciones (área, no proyecto) | No | La ventana la define Operaciones; no hay fecha en los documentos. |
| PRY-205·D2 (no formal) | Proveedor | No | Puede no llegar con el equipo completo. |

**Cruce entre proyectos: no se pudo hacer.** Ninguna dependencia lleva el código de un proyecto del que dependa, y las 13 actas de constitución dicen «Ninguna declarada». Los informes de avance contradicen esas actas: los proyectos dependen de proveedores y de Operaciones. Sin código no se puede saber si un proyecto movió su fecha y arrastró a otro.

### Registro completo
Las referencias (R riesgo, D dependencia, I incidencia) son provisionales de este informe; la ficha no trae ids. En todas las filas: probabilidad, impacto y doliente = sin dato. «Último movimiento» = sin historial; entre paréntesis, fecha del informe donde se vio por primera vez.

| Ref. | Tipo | Qué | Fecha | Fuente |
|---|---|---|---|---|
| PRY-199·R1 | Riesgo | Concentración del conocimiento en una sola persona | sin fecha (visto 2026-10-14) | informe de avance |
| PRY-200·R1 | Riesgo | Concentración del conocimiento en una sola persona | sin fecha (2026-09-24) | informe de avance |
| PRY-200·I1 | Incidencia | Hallazgo en la auditoría de seguridad | desde 2026-09-24 | informe de avance |
| PRY-201·R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin fecha (2026-10-15) | informe de avance |
| PRY-201·I1 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | desde 2026-10-15 | informe de avance |
| PRY-202·R1 | Riesgo | Cambio en la licencia ambiental | sin fecha (2026-10-16) | informe de avance |
| PRY-202·R2 | Riesgo | Bloqueo de la vía de acceso a la mina | sin fecha (2026-10-16) | informe de avance |
| PRY-202·I1 | Incidencia | Hallazgo en la auditoría de seguridad | desde 2026-10-16 | informe de avance |
| PRY-202·I2 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | desde 2026-10-16 | informe de avance |
| PRY-203·D1 | Dependencia | Proveedor sin confirmar fecha de la última entrega (reclasificado) | sin fecha (2026-10-04) | informe de avance |
| PRY-203·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | sin fecha (2026-10-04) | informe de avance |
| PRY-203·I1 | Incidencia | Hallazgo en la auditoría de seguridad | desde 2026-10-04 | informe de avance |
| PRY-203·I2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | desde 2026-10-04 | informe de avance |
| PRY-204·D1 | Dependencia | Proveedor sin confirmar fecha de la última entrega (reclasificado) | sin fecha (2026-10-13) | informe de avance |
| PRY-204·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | sin fecha (2026-10-13) | informe de avance |
| PRY-204·I1 | Incidencia | Equipos entregados en el campamento, pendientes de aceptación | desde 2026-10-13 | informe de avance |
| PRY-205·D1 | Dependencia | Ventana de parada de planta definida por Operaciones (reclasificado) | sin fecha (2026-10-11) | informe de avance |
| PRY-205·R1 | Riesgo | Cambio en la licencia ambiental | sin fecha (2026-10-11) | informe de avance |
| PRY-205·D2 | Dependencia, **no registrada formalmente** | El proveedor podría no llegar con el equipo completo | dicho 2026-10-16 | notas de reunión |
| PRY-205·I1 | Incidencia | El equipo perdió dos semanas por la rotación de un ingeniero clave | desde 2026-10-11 | informe de avance |
| PRY-206·D1 | Dependencia | Proveedor sin confirmar fecha de la última entrega (reclasificado) | sin fecha (2026-10-15) | informe de avance |
| PRY-206·R1 | Riesgo | Concentración del conocimiento en una sola persona | sin fecha (2026-10-15) | informe de avance |
| PRY-206·I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | desde 2026-10-15 | informe de avance |
| PRY-207·R1 | Riesgo | Bloqueo de la vía de acceso a la mina | sin fecha (2026-10-14) | informe de avance |
| PRY-207·I1 | Incidencia | El equipo perdió dos semanas por la rotación de un ingeniero clave | desde 2026-10-14 | informe de avance |
| PRY-207·I2 | Incidencia | Hallazgo en la auditoría de seguridad | desde 2026-10-14 | informe de avance |
| PRY-208·D1 | Dependencia | Ventana de parada de planta definida por Operaciones (reclasificado) | sin fecha (2026-10-16) | informe de avance |
| PRY-208·I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | desde 2026-10-16 | informe de avance |
| PRY-208·I2 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | desde 2026-10-16 | informe de avance |
| PRY-209·R1 | Riesgo | Concentración del conocimiento en una sola persona | sin fecha (2026-10-13) | informe de avance |
| PRY-209·D1 | Dependencia | Ventana de parada de planta definida por Operaciones (reclasificado) | sin fecha (2026-10-13) | informe de avance |
| PRY-210·R1 | Riesgo | Cambio en la licencia ambiental | sin fecha (2026-10-12) | informe de avance |
| PRY-210·R2 | Riesgo | Bloqueo de la vía de acceso a la mina | sin fecha (2026-10-12) | informe de avance |
| PRY-210·I1 | Incidencia | Equipos entregados en el campamento, pendientes de aceptación | desde 2026-10-12 | informe de avance |
| PRY-211·R1 | Riesgo | Cambio en la licencia ambiental | sin fecha (2026-10-08) | informe de avance |
| PRY-211·I1 | Incidencia | Equipos entregados en el campamento, pendientes de aceptación | desde 2026-10-08 | informe de avance |
| PRY-211·I2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | desde 2026-10-08 | informe de avance |

### Lo que no sé
- Si los ítems con el mismo texto en varios proyectos (vía bloqueada, licencia, auditoría, lluvias, rotación, ensayo) son el mismo hecho o textos repetidos del informe. Los traté como ítems por proyecto y los agrupé solo para la decisión.
- Cuánto tiempo llevan abiertos los riesgos: las fichas no guardan fecha de apertura. Y las incidencias: «desde» marca la primera vez que las vi, así que su antigüedad real es mayor o igual.
- Si hay mitigaciones: ningún documento trae alguna, ni vencida ni vigente.
- Quién es el proveedor y de qué entrega se habla en PRY-203, 204, 206 y 205; los documentos no lo dicen.
- Lo que se habló fuera de los documentos.

## Después
**Subir a comité** los cinco bloques de «Necesitan decisión ahora». **Doliente propuesto, no asignado:**
- Dependencias de proveedor y riesgo de vía/licencia dentro de un solo proyecto: su gerente (Ricardo Salas en 203, Laura Vélez en 204, Camilo Beltrán en 206, Paula Céspedes en 205).
- Ventana de parada (205, 208, 209): la persona de Operaciones que fije la ventana; no sale en los documentos, la designa el comité.
- Vía de acceso y licencia ambiental (5 proyectos cada una): un doliente de portafolio, que decide el comité.
- Hallazgo de auditoría de PRY-200: Jorge Medina, gerente.
- Incidencias de equipos pendientes de aceptación (204, 210, 211): Laura Vélez y Natalia Ospina, gerentes, junto con quien reciba en el campamento.

¿Formalizo en PRY-205 la dependencia no registrada del proveedor? Queda a decisión del gerente.

**Pie de rigor:** documentos citados arriba; 0 preguntas hechas (sesión sin interfaz); términos v1.1 vigentes. Lo que no está en esos documentos no está en este registro.
