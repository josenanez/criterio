# Corrida del 2026-10-16 · document-index

13 proyectos · 16 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

78 documentos sin cambio, 0 por releer. 134 citas de PRY-205 marcadas source_missing aunque los archivos existen: la ficha-pm.json cita con ruta relativa al proyecto y el índice resuelve desde la raíz. No corregí la ficha.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-16

**Documentos:** 78 · **Sin cambio:** 78 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 134 citas de PRY-205 (identidad, plan, dinero, compromisos 0–25) como `source_missing`. Todas salen de `PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/ficha-pm.json`.
Los 18 documentos citados SÍ existen en la carpeta de PRY-205 (acta de constitución, cronograma v1, informe de avance, actas de recibo, comités y notas del 2026-10-16). Las citas están escritas con ruta relativa a la carpeta del proyecto, y el índice las busca desde la raíz `documentos/proyectos`. Es un desajuste de ruta, no documentos perdidos.
Nadie corrigió la ficha: reescribirla en silencio no corresponde. Queda por decidir si la ficha del PM debe citar con la ruta completa o si el índice debe resolver esa ficha desde su carpeta de proyecto.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

**Hay que releer: 0. No hay nada que barrer.** `projects_to_recompute` está vacío; no se ofrece `/portfolio-scan`.
