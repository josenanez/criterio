# Corrida del 2026-10-16 · portfolio-report

13 proyectos · 78 documentos, 0 releídos y 78 sin cambio · 50 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

El informe quedó en `/home/claude/banco/ronda-6/mineria/espacio/reportes`.

Primera corrida del informe: sin instantánea previa, no hay delta. 4 verdes contradichos (PRY-201, 203, 205, 207). Formato html por argumento; el configurado es pptx.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-16
13 proyectos · 9 con hallazgos · último barrido 2026-10-16

Cargué las 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas con fecha 2026-10-16, es decir sin fichas viejas. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Formato pedido: `html`.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. Solo existe la instantánea de hoy (2026-10-16), así que este es el punto de partida: no hay delta que comparar.

## Contradicciones abiertas
Vacía en esta corrida: el cómputo no reportó campos `ambiguous` en el portafolio. Las contradicciones que sí aparecen son entre lo declarado y la evidencia (ver "Sin sustento").

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-204 | Pruebas en operación (vencido, sin cumplir) | 2026-10-12 | 4 |
| PRY-201 | Ingeniería de detalle aprobada (declarado cumplido, sin evidencia) | 2026-08-04 | 73 |
| PRY-202 | 4 hitos declarados cumplidos sin evidencia (el más viejo: Ingeniería básica) | 2025-11-10 | 340 |
| PRY-203 | 3 hitos declarados cumplidos sin evidencia (el más viejo: Ingeniería básica) | 2025-08-16 | 426 |
| PRY-204 | 3 hitos declarados cumplidos sin evidencia (el más viejo: Ingeniería básica) | 2026-03-27 | 203 |
| PRY-205 | Ingeniería básica aprobada | 2026-06-09 | 129 |
| PRY-207 | 4 hitos declarados cumplidos sin evidencia (el más viejo: Ingeniería básica) | 2026-02-07 | 251 |
| PRY-210 | 4 hitos declarados cumplidos sin evidencia (el más viejo: Ingeniería de detalle) | 2025-11-17 | 333 |

## Proyectos en silencio
Vacía: ningún proyecto supera el umbral de 15 días (el máximo es PRY-211 con 8).

## Dependencias en riesgo
Vacía: el cómputo no reportó dependencias declaradas entre proyectos que se hayan movido.

## Sin sustento
Cuatro proyectos declaran verde y la evidencia no lo sostiene: **PRY-201, PRY-203, PRY-205 y PRY-207**.
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | Verde, 76 % (2026-10-15) | El plan sostiene 40–60 %; 1 hito sin evidencia; 4 entregables de proveedor tardíos; factura sin entrega |
| PRY-203 | Verde, 58 % (2026-10-04) | Atraso de 120 días (50,6 %) contra la original; replanificación no autorizada; compromiso vencido (G. Neira, 15 días) |
| PRY-205 | Verde, 58 % (2026-10-11) | 7 compromisos vencidos, 3 sin fecha, 2 reprogramados (uno 6 veces); 1 hito sin evidencia |
| PRY-207 | Verde, 87 % (2026-10-14) | 4 hitos sin evidencia; 2 entregables tardíos; facturado por encima de lo aceptado; fin previsto 2026-10-19 |

Además, en proveedores: PRY-202 y PRY-210 tienen entregables aceptados sin evidencia.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad (quién aprueba) y fase |
| PRY-201, 202, 205, 206, 209, 210, 211 | Producto asociado (7 de 13 sin producto) |
| PRY-202, 203, 210, 211 | Campos de identidad con fuente de 13 a 17 meses (umbral: 12) |
| Todos | Ninguna fuente marcada como evidencia: todo lo marcado es declaración o sin marcar |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | Verde | Sin alertas | 0 d | 0 d | 0 |
| PRY-200 | Verde | Sin alertas | 0 d | 0 d | 0 |
| PRY-201 | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-202 | Amarillo | 70 % declarado; el plan exigiría 100 % (fin 2026-07-02, vencido) | 0 d | 0 d | 0 |
| PRY-203 | Verde | Contradicho | +120 d (50,6 %) | 0 d | 1 |
| PRY-204 | Amarillo | Hito vencido; 3 sin evidencia | 0 d | 0 d | 0 |
| PRY-205 | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-206 | Amarillo | Sin alertas | 0 d | 0 d | 0 |
| PRY-207 | Verde | Contradicho | 0 d | 0 d | 0 |
| PRY-208 | Verde | Sin alertas | 0 d | 0 d | 0 |
| PRY-209 | Amarillo | Sobrecosto proyectado 24,9 % (5.247,9 M frente a 4.200 M aprobados) | 0 d | 0 d | 0 |
| PRY-210 | Amarillo | 56 % declarado; el plan exigiría 100 % (fin 2026-05-22, vencido); 4 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-211 | Amarillo | Sobrecosto proyectado 17,9 % (943,6 M frente a 800 M) | 0 d | 0 d | 0 |

Totales del script: 60 alertas, 9 proyectos con alertas, 4 verdes contradichos, 13 sin autoridad registrada.

## Necesito que confirmes
Sesión sin interfaz: no hay quien responda. Dejo pendientes, como preguntas cerradas, los cinco campos más viejos entre los que importan (identidad de PRY-203, fuente de 2025-05-19):
1. ¿Siguen vigentes el código y el nombre de PRY-203? (sí/no)
2. ¿Sigue siendo el mismo el patrocinador de PRY-203? (sí/no)
3. ¿Sigue siendo la misma el área de negocio de PRY-203? (sí/no)
4. ¿PRY-203 sigue asociado al producto «despacho de flota»? (sí/no)
5. ¿Sigue siendo el mismo el patrocinador de PRY-210 (fuente 2025-07-07)? (sí/no)

## Dónde quedó el informe
Carpeta `reportes/` (23 páginas, 13 proyectos, 6 productos):
- `reportes/index.html` — por campo, con la cadena de evidencia. Para quien va a actuar (gerente de PMO).
- `reportes/decisiones.html` — por decisión, solo lo que excede la facultad del gerente. Para el patrocinador y el comité.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`). El PDF sale de imprimir el HTML.

Nota: el formato configurado es `pptx`; esta corrida usó `html` por el argumento.

---
Pie: criterio-portfolio 0.3.12 · fichas aplicadas: 13, todas del 2026-10-16 · campos inciertos: autoridad y fase en los 13 proyectos, producto en 7 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
