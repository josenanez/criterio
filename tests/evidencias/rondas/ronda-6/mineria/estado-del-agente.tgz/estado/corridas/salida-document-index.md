## Carpeta al 2026-10-16

**Documentos:** 78 · **Sin cambio:** 78 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 134 citas de PRY-205 (identidad, plan, dinero, compromisos 0–25) como `source_missing`. Todas salen de `PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/ficha-pm.json`.
Los 18 documentos citados SÍ existen en la carpeta de PRY-205 (acta de constitución, cronograma v1, informe de avance, actas de recibo, comités y notas del 2026-10-16). Las citas están escritas con ruta relativa a la carpeta del proyecto, y el índice las busca desde la raíz `documentos/proyectos`. Es un desajuste de ruta, no documentos perdidos.
Nadie corrigió la ficha: reescribirla en silencio no corresponde. Queda por decidir si la ficha del PM debe citar con la ruta completa o si el índice debe resolver esa ficha desde su carpeta de proyecto.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

**Hay que releer: 0. No hay nada que barrer.** `projects_to_recompute` está vacío; no se ofrece `/portfolio-scan`.
