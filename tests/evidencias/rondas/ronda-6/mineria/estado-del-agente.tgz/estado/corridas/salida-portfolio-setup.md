## Listo — Portafolio de proyectos

**Miré:** 78 documentos en 13 proyectos · formatos: md (41), pdf (13), docx (12), csv (5), xlsx (5), txt (1), json (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (propuesto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo supuesto es el 2026-10-19 (propuesto: las actas se llaman «comité semanal»)
**En:** presentación (propuesto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.1 de los términos (familia 0.3.12), 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 del .md 08da686bb7c9acf4…
**Estado y reportes:** `estado/` y `reportes/`, junto a la carpeta de documentos.

### Probé con tres proyectos

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | 6 | Gerente Óscar Ramírez, patrocinadora Paula Céspedes; presupuesto 2.400 M COP (ejecutado 22 %); declara amarillo, 70 % | Producto, facultad del gerente, etapa |
| PRY-205 Sistema de gestión de seguridad | 17 | Gerente Paula Céspedes, patrocinador Andrés Lozano; presupuesto 800 M COP (ejecutado 32 %); declara verde, 58 %; 26 compromisos tomados de 6 comités y de las notas del 16-oct; trae `ficha-pm.json` del gerente, guardada aparte | Producto, facultad del gerente, etapa, contratos de proveedores |
| PRY-208 Trazabilidad del mineral | 3 | Gerente Javier Hoyos; presupuesto 9.500 M COP (ejecutado 40 %); declara verde, 77 %; solicitud de cambio CC-01 pendiente (+25 días, +50 M COP) | Cronograma, facultad del gerente, etapa, contratos |

**Hallazgos (los que levantó `compute`):**

- **PRY-202 — hitos declarados cerrados sin acta.** Cuatro de cinco hitos (ingeniería básica, ingeniería de detalle, licencia y permisos, pruebas en operación) figuran cerrados en el cronograma y no hay acta que lo pruebe. Solo «Montaje e instalación» tiene acta de recibo (2026-10-03, cinco meses después de su fecha de 2026-05-05).
- **PRY-202 — avance declarado contra plan.** El cronograma da los cinco hitos como cumplidos (100 %) y el informe declara 70 %: 30 puntos de diferencia. La fecha de cierre comprometida, 2026-07-02, ya pasó.
- **PRY-202 — proveedor CT-250 (Servicios Ambientales del Norte).** Dos entregables vencidos y pendientes: licenciamiento del software (318 días) y bolsa de horas de ingeniería (237 días). «Calibración de sensores» figura recibido en el contrato, sin acta de recibo. Hay una factura de 110.830.774 COP radicada el 2026-08-31 contra un contrato cuya condición de pago es el acta de recibo.
- **PRY-205 — verde contradicho.** El informe del 2026-10-11 declara verde, y la evidencia levanta tres señales que no explica:
  - siete compromisos vencidos (de 2 a 18 días);
  - dos compromisos reprogramados cinco y seis veces: «Enviar el documento 1» (Elena Duarte) pasó del 2026-09-30 al 2026-12-20, y «Cerrar la prueba 2» (Laura Vélez) del 2026-10-02 al 2026-12-13;
  - el hito «Ingeniería básica aprobada» está cerrado sin acta.
- **PRY-205 — compromisos sin fecha.** Tres: Carlos Peña (prueba 18), Rubén Cárdenas (matriz 22) y Laura Vélez (ajuste del presupuesto, «la otra semana»).
- **PRY-205 — riesgo dicho y no registrado.** En las notas del 16-oct se comentó que el proveedor podría no llegar con el equipo completo a la siguiente fase; nadie lo anotó. Lo dejé en la ficha, con su fuente.
- **PRY-208 — sin señales.** `compute` no levantó ninguna. Hay una solicitud de cambio pendiente y no hay cronograma.
- **Faltan en los tres:** la facultad del gerente (`authority`). Es lo que impide saber si un cambio excede lo que puede decidir sin subir a comité.

### El portafolio completo
10 proyectos más y 52 documentos, en un lote, uno tras otro. Estimo unos 20–30 minutos de conversación; es una estimación mía, no una medición.

### Lo que le falta a tu carpeta
- Ningún proyecto trae la facultad del gerente en el acta.
- PRY-208 y otros (PRY-206, PRY-211) no tienen cronograma, así que no se puede contrastar el avance declarado con un plan.
- PRY-205: los compromisos de las notas del 16-oct no están en ningún acta de comité, y dos personas dijeron haber entregado («diseño 5», «matriz 14») sin acta que lo respalde.
- Los informes de avance son lo único que hay de varios proyectos; sin actas de recibo, lo «cumplido» queda como declaración.

Ninguno de estos puntos bloquea el análisis.

**Preguntas hechas:** 0 (sesión de prueba sin interfaz; todo con valores sugeridos).
