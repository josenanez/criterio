# Corrida del 2026-10-16 · steering-pack

13 proyectos · 90 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Paquete de comité 2026-10-19: 7 decisiones, 5 escalamientos, 9 de 13 proyectos con hallazgos. Dijo que no sabe quién decide (autoridad vacía en 13 de 13), que no hay comité anterior registrado y que no calculó porcentajes de las solicitudes de cambio porque el script no los da.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Cargué las fichas de los 13 proyectos (PRY-199 a PRY-211), actualizadas el 2026-10-16, y el cálculo `compute` con corte 2026-10-16. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Sin argumento de fecha, usé la del próximo comité de la configuración: 2026-10-19.

# Comité de proyectos — 2026-10-19
7 decisiones · 5 escalamientos · 9 proyectos con hallazgos (de 13)

## Decisiones del comité anterior
No hay registro de un comité anterior en las fichas ni en las corridas previas, así que no puedo decir qué se decidió ni qué quedó abierto. Las cuatro solicitudes de cambio pendientes dicen "Pendiente de presentación al comité"; ninguna ha pasado por uno.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | — | — |

## Decisiones de hoy

### [1] ¿Quién aprueba las solicitudes de cambio y los pagos a proveedores de este portafolio, y con qué umbral?
**Proyecto:** los 13 · **Quién decide:** patrocinador del portafolio (no está nombrado en ningún documento) · **Si no se decide hoy:** los puntos 2 a 7 no tienen a quién dirigirse y se quedan como están.

La autoridad no aparece en ninguna de las 13 fichas. Las actas nombran cinco comités distintos (Inversiones, Operaciones, Tecnología, Ambiental, Seguridad) y ningún documento fija un umbral de monto o de días a partir del cual algo sale del gerente de proyecto. Por eso este es el primer punto: sin él, los otros no se pueden dirigir con certeza.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Este comité decide todo lo que exceda al gerente, con umbral escrito | Sin cambio | Decisiones en una sola sesión | Sin costo directo |
| B. Cada solicitud va al comité que aprobó el acta del proyecto | Sin cambio | Hay que convocar a cinco comités; cada uno con su calendario | Sin costo directo |

**Recomendación:** A, con el umbral escrito en el acta de este comité. B deja cuatro solicitudes esperando a comités cuyo calendario no consta en ninguna ficha. Si el comité prefiere B, los puntos 2 a 5 pasan a cada comité de origen y de este paquete solo quedan los puntos 6 y 7.

### [2] ¿Se aprueba CC-01 de PRY-203 (+120 días, 240.000.000 COP) o se devuelve la línea base a la original?
**Proyecto:** PRY-203 Despacho automático de flota · **Quién decide:** por definir en el punto 1 (el acta lo aprobó el Comité de Operaciones) · **Si no se decide hoy:** la línea base sigue 120 días más allá de la original sin autorización, y el proyecto sigue reportando verde.

Hechos: la solicitud es del 2026-10-07 (solicitante: Ricardo Salas), con ampliación de alcance. El script marca `rebaseline_unauthorized`: la línea base se movió 120 días, con 0 días autorizados. La desviación contra la original es de 50,6 %, sobre un umbral de 10 %. La fecha fin vigente es 2026-05-21, ya vencida. El informe del 2026-10-04 declara verde y 58 % de avance, y el plan sustenta 100 %. Además, Gustavo Neira tiene vencido "Entregar el punto 37" desde el 2026-10-01 (15 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar la línea base nueva sin borrar la anterior | Ampliado | +120 días sobre la vigente | +240.000.000 COP |
| B. Rechazar CC-01 y volver a la línea base original | Sin ampliación | La fecha original ya venció; hay que replanificar el cierre | Sin costo adicional por el cambio |
| C. Aplazar hasta que el gerente presente evidencia de los hitos declarados cumplidos | Sin decidir | Sigue corriendo | Sin decidir |

**Recomendación:** C, con fecha tope en el siguiente comité. Los tres hitos que el informe da por cumplidos no tienen evidencia (426, 347 y 148 días desde su fecha), y el verde está contradicho por cinco señales. Aprobar sobre ese dato firmaría una línea base que nadie sustenta.

### [3] ¿Se aprueba CC-01 de PRY-209 (+93 días, 186.000.000 COP) con el sobrecosto proyectado ya fuera de umbral?
**Proyecto:** PRY-209 Electrificación de equipos · **Quién decide:** por definir en el punto 1 (el acta la aprobó el Comité de Tecnología) · **Si no se decide hoy:** la solicitud, del 2026-10-12, sigue pendiente mientras el proyecto avanza con 60,9 % del presupuesto comprometido.

Hechos: la proyección es de 5.247.860.031 COP contra 4.200.000.000 aprobados (24,9 % por encima, umbral 10 %). El informe del 2026-10-13 declara amarillo y no explica la desviación. La ficha no trae cronograma, así que no puedo contrastar el avance de 45 % contra el plan.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliado | +93 días | +186.000.000 COP sobre un presupuesto ya proyectado 24,9 % por encima |
| B. Rechazar CC-01 y pedir plan de contención del sobrecosto | Sin ampliación | Sin cambio | Se mantiene la proyección actual |
| C. Aplazar hasta que el gerente explique de dónde sale la desviación del 24,9 % | Sin decidir | Sin decidir | Sin decidir |

**Recomendación:** C. El comité no debería ampliar el alcance de un proyecto cuya proyección ya excede el presupuesto sin que nadie haya explicado por qué.

### [4] ¿Se aprueba CC-01 de PRY-211 (+102 días, 204.000.000 COP) en un proyecto con fecha fin vencida y proyección sobre el presupuesto?
**Proyecto:** PRY-211 Control de polvo en vías · **Quién decide:** por definir en el punto 1 (el acta la aprobó el Comité de Operaciones) · **Si no se decide hoy:** la solicitud, del 2026-10-03, sigue sin respuesta y el proyecto sigue con la fecha fin vencida.

Hechos: la fecha fin vigente es 2026-05-19, ya vencida, y el informe del 2026-10-08 declara 63 % de avance. La proyección es de 943.567.807 COP contra 800.000.000 aprobados (17,9 % por encima, umbral 10 %). La ficha no trae cronograma.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliado | +102 días sobre la vigente | +204.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | El proyecto sigue con la fecha vencida; hay que replanificar sin el cambio | Se mantiene la proyección (17,9 % por encima) |
| C. Aplazar hasta recibir un cronograma y la explicación de la desviación | Sin decidir | Sin decidir | Sin decidir |

**Recomendación:** C. Sin cronograma en la carpeta no se puede medir cuánto de los 102 días ya estaba perdido antes del cambio.

### [5] ¿Se aprueba CC-01 de PRY-208 (+25 días, 50.000.000 COP)?
**Proyecto:** PRY-208 Trazabilidad del mineral · **Quién decide:** por definir en el punto 1 (el acta la aprobó el Comité de Inversiones) · **Si no se decide hoy:** la solicitud, del 2026-10-05, sigue pendiente. Es la de menor impacto de las cuatro.

Hechos: el proyecto no tiene señales abiertas y declara verde con 77 % de avance (informe del 2026-10-16). La proyección está 4,0 % por encima del presupuesto, dentro del umbral de 10 %. La ficha no trae cronograma, así que el avance declarado no se puede contrastar.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar la línea base nueva | Ampliado | +25 días | +50.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | Sin cambio | Se mantiene la proyección |

**Recomendación:** A, si el punto 1 deja esta solicitud en este comité. Es la única de las cuatro sin otra señal en contra. Condición: que el gerente confirme que la proyección ya incluye los 50.000.000 COP o no, porque la ficha no lo dice.

### [6] ¿Se retienen las facturas de Automatización de Procesos Ltda. (CT-101, PRY-207) hasta que se acepten sus entregables vencidos?
**Proyecto:** PRY-207 Gemelo digital de la planta · **Quién decide:** por definir en el punto 1 (el acta la aprobó el Comité de Operaciones) · **Si no se decide hoy:** se siguen pagando entregables que no constan como recibidos. El proyecto cierra el 2026-10-19.

Hechos: se facturaron 3.363.389.644 COP y lo aceptado es 2.876.935.730 COP, es decir 486.453.914 COP facturados por encima de lo aceptado. Hay dos entregables vencidos y pendientes: "Licenciamiento del software" (245 días) y "Calibración de sensores" (105 días). El informe del 2026-10-14 declara verde con 87 % de avance, y las tres señales abiertas que el script deja sin reconocer en el informe (hitos sin evidencia, entregables vencidos, facturado sobre lo aceptado).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos hasta aceptar los dos entregables pendientes | Sin cambio | Puede presionar la entrega del 2026-10-19 | Los 486.453.914 COP quedan retenidos |
| B. Seguir pagando y exigir fecha de entrega con cláusula | Sin cambio | Depende del proveedor | Se mantiene lo facturado por encima de lo aceptado |

**Recomendación:** A. Hoy la diferencia facturada sobre lo aceptado es lo único con lo que el proyecto puede exigir los dos entregables vencidos.

### [7] ¿Se suspende el pago a Montajes Industriales Ltda. (CT-600, PRY-201) hasta que haya algún entregable aceptado?
**Proyecto:** PRY-201 Ampliación de la relavera · **Quién decide:** por definir en el punto 1 (el acta la aprobó el Comité de Inversiones) · **Si no se decide hoy:** el proveedor sigue facturando sin entregas aceptadas y el informe sigue en verde.

Hechos: se han facturado 371.934.503 COP y no hay ningún entregable aceptado (0 de 3). "Licenciamiento del software" lleva 126 días vencido y "Bolsa de horas de ingeniería" 8. El informe del 2026-10-15 declara verde con 76 % de avance y el plan sustenta entre 40 % y 60 %: el avance declarado está 16 puntos por encima. El hito "Ingeniería de detalle aprobada" figura cumplido sin evidencia (73 días). Servicios Ambientales del Norte (CT-563) también figura con los mismos dos entregables vencidos y sin facturación.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender pagos hasta la primera aceptación | Sin cambio | Puede frenar al proveedor | Se detiene el desembolso adicional |
| B. Pagar y exigir plan de entrega | Sin cambio | Depende del proveedor | Se mantiene lo ya facturado |

**Recomendación:** A, y pedir al gerente que corrija el avance declarado antes del próximo informe.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-205 | 7 compromisos vencidos (entre 2 y 18 días), 3 sin fecha y 2 reprogramados 6 y 5 veces ("Enviar el documento 1", Elena Duarte; "Cerrar la prueba 2", Laura Vélez). Declarado verde el 2026-10-11 | El más antiguo venció el 2026-09-28 (18 días) | Que el comité exija fechas firmes y un responsable que responda por el atraso |
| PRY-203, 205 y 207 | Gustavo Neira figura con 3 compromisos vencidos (uno en PRY-203, dos en PRY-205) y 1 sin fecha (PRY-207). El mismo responsable atrasa tres proyectos | 2026-10-01 (PRY-203) | Que alguien con autoridad revise su carga en los tres proyectos |
| PRY-202 | Declara amarillo con 70 % de avance, pero el plan sustenta 100 % (5 de 5 hitos cumplidos). Cuatro hitos sin evidencia (entre 106 y 340 días). Fecha fin 2026-07-02, vencida. Entregables vencidos del proveedor: 318 y 237 días. "Calibración de sensores" figura aceptado sin evidencia | Fecha fin vencida desde 2026-07-02 | Evidencia de los hitos o corrección del avance; decisión de cierre o prórroga |
| PRY-210 | Declara amarillo con 56 % de avance, pero el plan sustenta 100 %. Cuatro hitos sin evidencia (entre 147 y 333 días). Fecha fin 2026-05-22, vencida. "Calibración de sensores" lleva 252 días vencida; "Soporte del primer trimestre" figura aceptado sin evidencia | Fecha fin vencida desde 2026-05-22 | Igual que PRY-202 |
| PRY-204 | Hito "Pruebas en operación" vencido hace 4 días (fecha 2026-10-12). Tres hitos cumplidos sin evidencia (203, 153 y 54 días) | 2026-10-12 | Nueva fecha o evidencia del hito |

## Para conocimiento
- PRY-199 Cambio de luminarias: verde, sin señales.
- PRY-200 Mantenimiento predictivo: verde, sin señales; el último informe tiene 22 días.
- PRY-206 Red privada LTE: amarillo, sin señales; fecha fin 2026-11-01.
- PRY-208 Trazabilidad: verde, solo la solicitud CC-01 (punto 5).

## Anexo
**Señales contra lo declarado.** Cuatro proyectos declaran verde con señales abiertas: PRY-201 (4 señales), PRY-203 (5), PRY-205 (3) y PRY-207 (3). Los cuatro están reunidos en los puntos 2, 6 y 7 y en los escalamientos.

**Totales del cálculo.** 13 proyectos, 9 con alertas, 60 alertas en total, 6 productos, 0 sin línea base, 13 sin autoridad registrada.

**Contradicciones abiertas.** Ninguna registrada entre documentos (`conflicts` vacío en las 13 fichas). Sí hay contradicción entre lo declarado y lo que sustentan los hitos en PRY-202, PRY-203, PRY-201 y PRY-210.

**Vacíos de información.**
- Autoridad: falta en las 13 fichas. Fase: falta en las 13. Producto: falta en PRY-201, 202, 205, 206, 209, 210 y 211.
- Sin cronograma en la carpeta: PRY-208, 209 y 211, por lo que su avance no se puede contrastar contra el plan.
- Sin contratos en la carpeta: PRY-203, 208, 209 y 211 (las fichas lo dicen expresamente).
- Datos de identidad y plan con más de 12 meses de antigüedad: PRY-202 (13 meses), PRY-203 (17), PRY-210 (15) y PRY-211 (14).
- Ninguna fuente está marcada como evidencia: en todas las fichas el conteo de evidencia es 0 y los datos son declaraciones o fuentes sin marcar. Por eso "cumplido sin evidencia" aparece tan seguido.
- PRY-205 tiene un compromiso sin fecha en las notas del 2026-10-16 (Laura Vélez, "Mandar el ajuste del presupuesto"). Es el único indicio de un cambio de presupuesto y no tiene solicitud formal.

**Solicitudes de cambio pendientes (4).** PRY-203 CC-01 (2026-10-07), PRY-211 CC-01 (2026-10-03), PRY-208 CC-01 (2026-10-05), PRY-209 CC-01 (2026-10-12). Las cuatro son ampliaciones de alcance con "decisión: pendiente" y sin quién decidió.

**Qué no calculé.** Porcentajes de las solicitudes de cambio sobre su presupuesto y el tiempo que llevan pendientes: el script no los da y no los escribo.

---
Criterio Portfolio versión 0.3.12 · fichas aplicadas: PRY-199 a PRY-211 (13), corte 2026-10-16 · campos inciertos: autoridad (13 de 13), fase (13 de 13), producto (7), cronograma (3), contratos (4), antigüedad de identidad (4) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
