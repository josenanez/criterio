**Salen de:** `00-gobierno/2026-01-31-contrato-ct-600.md`, `00-gobierno/2026-02-03-contrato-ct-563.docx`, `20-seguimiento/2026-09-23-factura-ct-600.md`, `20-seguimiento/2026-10-07-acta-recibo-ingeniería-básica-aprobada.pdf`, `20-seguimiento/2026-10-15-informe-avance.pdf`, `30-reuniones/2026-10-08-comite-semanal.md`, y el cálculo de `portafolio.py compute` al 2026-10-16. Términos vigentes (v1.1, aceptados el 2026-10-16 por José Francisco Ñáñez).

## Proveedores — PRY-201 Ampliación de la relavera al 2026-10-16

**Hallazgo principal:** Montajes Industriales Ltda. tiene una factura radicada (FV-2600, 371.934.503 COP, 2026-09-23) y ninguno de sus 3 entregables está aceptado ni tiene acta de recibo. El contrato dice que cada entregable se factura contra acta de recibo firmada por el gerente del proyecto. Esa acta no existe en la carpeta.

### Montajes Industriales Ltda. — contrato CT-600
**Vigencia:** sin dato (el contrato solo trae firma, 2026-01-31) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-06-12 (371.934.503) | pendiente, 126 días de atraso | ninguna | FV-2600 dice "Entregables del contrato CT-600" sin detallar |
| Bolsa de horas de ingeniería | 2026-10-08 (371.934.503) | pendiente, 8 días de atraso | ninguna | ídem |
| Calibración de sensores | 2027-02-02 (371.934.503) | en curso según el contrato; sin evidencia | ninguna | ídem |

Facturado: 371.934.503 COP. Entregables aceptados: 0 de 3.

### Servicios Ambientales del Norte — contrato CT-563
**Vigencia, preaviso y vencimiento:** sin dato (el contrato solo trae firma, 2026-02-03).

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-06-12 (436.824.099) | "en curso" según el contrato; 126 días de atraso | ninguna | no hay factura |
| Bolsa de horas de ingeniería | 2026-10-08 (436.824.099) | "en curso" según el contrato; 8 días de atraso | ninguna | no hay factura |
| Calibración de sensores | 2027-02-02 (436.824.099) | pendiente | ninguna | no hay factura |

Facturado: sin dato (no hay factura en la carpeta). Entregables aceptados: 0 de 3.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura de CT-600 | Se factura cada entregable contra acta de recibo firmada | Factura FV-2600 por 371.934.503 COP, igual al valor de un entregable, sin acta de recibo de ningún entregable de CT-600 | contrato CT-600; factura FV-2600 |
| Estado del proyecto | — | El informe del 2026-10-15 declara verde y 76% de avance. El plan sustenta entre 40% y 60% (2 de 5 hitos cumplidos); la diferencia es de 16,0 puntos, con el avance declarado por delante | informe de avance; cronograma v1 |
| Hito "Ingeniería de detalle aprobada" (2026-08-04) | — | Figura como cumplido, sin acta ni evidencia, 73 días después de su fecha | ficha PRY-201; cronograma v1 |
| Acta de recibo del 2026-10-07 | — | Recibe "Ingeniería básica aprobada", un hito del proyecto. No corresponde a ningún entregable de CT-600 ni de CT-563, y no sustenta la factura | acta de recibo |
| Los dos contratos | — | Listan los mismos tres entregables con las mismas fechas, a cada proveedor. Puede ser una plantilla repetida o un solapamiento de alcance; los documentos no lo aclaran | CT-600; CT-563 |
| Comprometido | Montos de entregables de ambos contratos en las tablas de arriba | El informe reporta Comprometido 1.599.687.700 COP; no pude reconciliarlo con los montos de los contratos | contratos; informe de avance |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Los 3 de CT-600 | pendiente (2) y en curso (1) en el contrato; ninguno declarado entregado | sin dato |
| Los 3 de CT-563 | en curso (2) y pendiente (1) en el contrato; ninguno declarado entregado | sin dato |

Entregables "aceptados sin evidencia": 0 en ambos proveedores. El problema no es una aceptación sin acta. Es una factura sin ninguna aceptación.

### Compromisos del proveedor vencidos
Ninguno vencido. El único compromiso abierto es de Carlos Peña, "Entregar el punto 36", para el 2026-10-28, dicho en el comité del 2026-10-08. Los documentos no dicen si Carlos Peña es de alguno de los proveedores.

### Sin dato
- Vigencia, renovación automática y preaviso de CT-600 y CT-563: los contratos no los traen. No puedo decir si algún preaviso vence antes del cierre del proyecto (plan al 2027-04-18).
- Factura de CT-563: no hay ninguna.
- Qué entregables cubre FV-2600: dice "Entregables del contrato CT-600" sin detallar.
- Estado real de los entregables: no hay actas de recibo, correos de aceptación ni minutas que los mencionen. Por regla, el estado es `unknown`, no `delivered`.

## Después
- Antes de pagar FV-2600 o aprobarla en cuentas por pagar, conviene llevarla a comité: está radicada sin acta de recibo, y el licenciamiento va 126 días tarde.
- Pedir a los dos proveedores el acta de recibo, o confirmar por escrito que no hay entrega, y pedir el texto completo de ambos contratos (vigencia y preaviso).
- Declarado y evidencia no coinciden: el informe dice verde y las señales abiertas lo contradicen. El informe tampoco menciona el atraso de los proveedores.

*Pie de rigor: Criterio produce borradores de trabajo, no decisiones ni asesoría. Esto sale solo de los documentos citados; lo hablado fuera de ellos no lo sé. Las cifras derivadas (días, puntos, porcentajes, señales) vienen de `portafolio.py compute`. La verificación es suya.*
