# Rostrum — modo «para mirarlo un rato»

**Términos:** ya estaban vigentes (versión 1.1, familia 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16), así que no se pidió un nuevo sí ni se escribió un nuevo comprobante. Comprobante existente: `.criterio/terminos/aceptacion-criterio-portfolio-0.3.12-2026-10-16.md` (y `.pdf`). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12

**Modo elegido:** «para mirarlo un rato» (respuesta sugerida; el argumento fue `rato`). Se levanta, se mira y se apaga con Ctrl-C. Sin infraestructura que pedir y sin conversación con seguridad. Lo que se pierde: mañana no hay un enlace que funcione.

**Informe encontrado:** carpeta `reportes/` (13 proyectos PRY-199 a PRY-211, `index.html`, `decisiones.html`, `proyectos.html`, `productos.html` y 6 productos). Estado: `estado/`. Configuración: `.criterio/portafolio/config.json`. Organización en el portal: «Portafolio de proyectos».

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto; enlaza a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos.

**Cola de peticiones:** el formulario de la portada deja la petición en `estado/peticiones/`; el servidor no puede correr el agente. `due` las cuenta y una petición abierta rompe el silencio de `/portfolio-wake`.

**Cierre:** el enlace `http://127.0.0.1:8787/` es solo para quien esté en este equipo; no se le puede pasar al patrocinador. El informe es del 2026-10-16 (generado a las 15:55) y se queda desactualizado en cuanto cambie algún documento o ficha: hay que volver a correr `/portfolio-report html`. Para que el patrocinador tenga un enlace estable, el siguiente paso es el modo «que quede corriendo» (`--abierto`), que requiere pedir host, puerto y control de acceso a la organización.
