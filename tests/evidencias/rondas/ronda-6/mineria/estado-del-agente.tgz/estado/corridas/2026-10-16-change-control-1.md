# Corrida del 2026-10-16 · change-control

13 proyectos · 30 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Solicitud PRY-200 +30 dias a salida a produccion. Sin solicitante, motivo, autoridad declarada ni impacto en alcance/costo; interprete salida a produccion como Pruebas en operacion; sin dependencias declaradas; no se calculan dias por hito (sin holgura).

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Sale de la ficha** `estado/records/PRY-200.json` (actualizada 2026-10-16). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-16.

## Solicitud de cambio — PRY-200 Mantenimiento predictivo de camiones — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta (la solicitud llegó sin solicitante). · **Por qué:** no consta; ningún documento de la carpeta da el motivo.

**Supuesto que hay que confirmar:** el cronograma no tiene un hito llamado «salida a producción». El más cercano es *Pruebas en operación* (2027-11-08), que además es el cierre; el criterio de éxito del acta es «en producción y medido». Evalúo el cambio como mover ese hito y el cierre de 2027-11-08 a 2027-12-08. Si se refiere a otro, hay que decir cuál.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta 2026-06-22) | No declarado | Sin impacto declarado |
| Tiempo | Cierre 2027-11-08 | 2027-12-08 | +30 días (≈6 % de los 494 días del plan; bajo el umbral de 10 %) |
| Costo | Aprobado 18.000.000.000 COP; proyección 16.873.506.496 COP | No declarado | No calculable: no hay costo de la extensión |

- **Alcance sin impacto declarado:** si el alcance no cambia, alguien absorbe la extensión en calidad o en horas no pagadas. Nadie lo dice.
- **Costo sin impacto declarado:** 30 días más de equipo sin presupuesto adicional también lo absorbe alguien. Hay 1.126.493.504 COP de margen entre aprobado y proyección, pero ese margen no se ha asignado a este cambio.
- **No sé:** cuántos días se mueven los hitos intermedios. Eso necesita holgura por actividad y la ficha no la tiene. Los hitos por los que pasa el cambio son *Ingeniería de detalle* (2027-01-15), *Licencia y permisos* (2027-04-24), *Montaje* (2027-08-01) y *Pruebas en operación* (2027-11-08); no es que se muevan todos 30 días.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`) no encontró proyectos alcanzados, ni directa ni indirectamente: 0 dependientes, 0 que no puedan sostener su fecha, 0 sin confirmar | — |

Ojo: esto es cierto solo para las dependencias **declaradas**. El acta dice «Ninguna declarada». Que no haya dependencias declaradas no prueba que no existan; el producto asociado es «monitoreo de flota», y otros proyectos sobre ese producto no aparecen cruzados.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara autoridad de cambio (`identity.authority`: no encontrado). · **Según:** ninguna cláusula. El único dato de gobierno es que el Comité de Seguridad aprobó la línea base y el presupuesto el 2026-06-22. · **Va a comité:** sí, por defecto. Sin autoridad declarada no hay base para decir que alguien más pueda aprobarlo, y quien aprobó la línea base fue el Comité de Seguridad. Eso es el hallazgo de fondo: el acta no dice quién puede mover fechas.

### Si no se aprueba
El proyecto sigue con la línea base v1 (cierre 2027-11-08). Hoy no hay desviación registrada: ningún cambio aprobado, una sola línea base, hitos vigentes iguales a los de la base. Pero el estado «verde / 30 %» del informe del 2026-09-24 es declaración del gerente, y ese informe menciona un hallazgo de auditoría de seguridad abierto sin dueño y una parada de planta reprogramada. No sé si esos hechos ya empujan la fecha. Esa puede ser la razón del pedido, pero ningún documento lo dice.

### Si se aprueba
Línea base 2 — cierre 2027-12-08 · presupuesto: sin cambio declarado (18.000.000.000 COP) · motivo: **por escribir**, no se puede inventar.
Desviación acumulada contra la línea base original: +30 días · costo: sin cambio declarado. Replanificaciones: de 0 a 1. La línea base 1 no se toca.
Reconciliación: hoy hay 0 días de movimiento de línea base y 0 días autorizados por cambios aprobados; con esta aprobación, el cambio debe quedar en un documento firmado por quien decide, o los 30 días saldrán como no autorizados.

### Otros hechos que el comité debería ver
- Ejecutado (7.288.618.068) supera lo comprometido (6.199.323.109) en el informe del 2026-09-24. Ejecutar más de lo comprometido no es normal y nadie lo explica.
- El hito *Ingeniería básica aprobada* se cerró con acta de recibo del 2026-10-10, dos días después de la fecha de línea base (2026-10-08); el cronograma conserva 2026-10-08 como vigente.
- El riesgo abierto «concentración del conocimiento en una sola persona» sigue sin dueño ni plan.

### Pie de rigor
Leído: acta de constitución, cronograma v1, informe de avance 2026-09-24 y la ficha. No leído: documentos fuera de la carpeta del proyecto. No sé por qué se pide, quién lo pide, cuánto cuesta ni si algún otro proyecto depende de este sin haberlo declarado. Criterio produce borradores; la verificación y la decisión son suyas.

**Después:** esta solicitud va a comité (Comité de Seguridad), porque no hay autoridad declarada que permita otra ruta. Cuando lo apruebe quien pueda, se registra la línea base 2.
