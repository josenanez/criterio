# Corrida del 2026-10-16 · project-charter

13 proyectos · 25 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 9 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 4 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Revisión del acta de PRY-200: faltan autoridad del gerente, cadencia, supuestos/restricciones, criterio de éxito medible y quién lo mide; objetivo y alcance débiles. No sé nada fuera de los documentos: no hay minutas.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Acta previa: sí, del 2026-06-22 (acta-constitucion.docx, aprobada por el Comité de Seguridad). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se registraron de nuevo.

## Acta — PRY-200 Mantenimiento predictivo de camiones
**Estado:** existe, del 2026-06-22

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Jorge Medina sin comité. | Cualquier cambio o sobrecosto, por pequeño que sea, solo puede resolverse subiéndolo al Comité de Seguridad. Con 18.000 M COP y 16 meses de plazo, eso lo vuelve el cuello de botella; o, peor, el gerente decide sin un límite escrito y nadie puede decir después si se excedió. |
| Objetivo de negocio | **Débil.** "Entregar mantenimiento predictivo de camiones para Geología" describe la solución, no un resultado de negocio. | No hay a qué compararse cuando el proyecto termine: se puede entregar el sistema y no haber reducido paradas ni costos, y el acta lo daría por cumplido. |
| Alcance | **Débil.** Solo dice "Componente 1, 2 y 3", sin nombre ni contenido. | Nadie puede decir si una solicitud está dentro o fuera. Todo cambio de alcance se discute desde cero. |
| Exclusiones | **Vacía en la práctica.** "Lo que otro proyecto cubre" no nombra ningún proyecto. | Si dos proyectos cubren o dejan sin cubrir lo mismo, nada lo hace visible; la frontera con el otro proyecto es un hueco. |
| Criterio de éxito | **No medible.** "En producción y medido" no tiene indicador, meta ni plazo, y no dice quién lo mide. | El cierre se vuelve opinión: sin meta, "medido" se cumple con cualquier número. |
| Quién mide el éxito | **No está.** | Nadie responde por declarar el éxito. |
| Supuestos y restricciones | **No hay.** Solo "Dependencias: ninguna declarada". | Un proyecto de 16 meses con licencias y permisos en su cronograma (hito 2027-04-24) no tiene ninguna dependencia ni supuesto escrito; lo que se rompa no estaba registrado y nace como incidencia. |
| Patrocinador | Sí: Felipe Arango (persona). | — |
| Gerente | Sí: Jorge Medina. | — |
| Comité y cadencia | Comité: Comité de Seguridad. **Cadencia: no está.** | Se sabe a quién reporta, pero no cada cuánto; no hay forma de decir que un reporte llegó tarde. |
| Presupuesto | Sí: 18.000.000.000 COP, aprobado el 2026-06-22. | — |
| Fechas | Sí: inicio 2026-07-02, cierre 2027-11-08. Hitos en el cronograma v1. | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar mantenimiento predictivo de camiones para Geología", que es la solución, no un resultado medible. *(Fuente: acta-constitucion.docx)*
**Alcance:** Componente 1, Componente 2, Componente 3, sin detalle. *(acta-constitucion.docx)*
**Exclusiones:** "Lo que otro proyecto cubre", sin nombrar cuál. *(acta-constitucion.docx)*
**Patrocinador:** Felipe Arango · **Gerente:** Jorge Medina *(acta-constitucion.docx)*
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento.
**Comité al que reporta:** Comité de Seguridad *(acta-constitucion.docx)* · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. Dependencias: "Ninguna declarada" *(acta-constitucion.docx)*.
**Criterio de éxito:** "Mantenimiento predictivo de camiones en producción y medido" *(acta-constitucion.docx)*, sin indicador ni meta · **Lo mide:** pendiente de definir.
**Hitos principales** *(cronograma-v1.xlsx, 2026-06-22)*: Ingeniería básica aprobada 2026-10-08 (cumplido; acta de recibo del 2026-10-10) · Ingeniería de detalle 2027-01-15 · Licencia y permisos 2027-04-24 · Montaje e instalación 2027-08-01 · Pruebas en operación 2027-11-08.

### Observaciones fuera del acta, para el gerente
- El informe del 2026-09-24 declara verde y 30 % de avance, pero reporta ejecutado (7.288.618.068 COP) por encima de lo comprometido (6.199.323.109 COP). Esto no es del acta y no lo dictamino aquí; lo señalo porque sin autoridad del gerente declarada no hay umbral escrito contra el cual juzgarlo.
- El informe menciona un hallazgo de la auditoría de seguridad sin responsable, y el Comité de Seguridad es justamente el comité del proyecto.
- El informe dice que se "reprogramó la parada de planta", pero la línea base vigente sigue siendo la v1 y no hay solicitud de cambio en la carpeta.

### Después
El acta quedó sin autoridad declarada: **ofrezco llevar esa definición al comité (próximo: 2026-10-19)**. Es una decisión sobre cuánto puede decidir el gerente, no un trámite. También ofrezco pasar al registro RAID el vacío de supuestos (licencias y permisos, dependencia con el otro proyecto sin nombrar).

### Pie de rigor
Leí 4 documentos de la carpeta de PRY-200 (acta, cronograma, informe de avance y acta de recibo, estos dos últimos solo como contexto) y la ficha del 2026-10-16. No sé lo que se haya hablado fuera de esos documentos: no hay minutas de reunión en la carpeta. Los campos marcados como pendientes no se completaron a propósito. La verificación de cada dato es de ustedes; cada uno lleva su fuente.
