<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/2025-12-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de seguridad

Código: PRY-205

Área dueña: Geología

Patrocinador: Andrés Lozano

Gerente de proyecto: Paula Céspedes

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2025-12-23

Objetivo del negocio

Entregar sistema de gestión de seguridad para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité Ambiental el 2025-12-23.

Fechas comprometidas

Fecha

Inicio

2026-01-02

Cierre

2027-04-23

Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

Dependencias declaradas

• Ninguna declarada
