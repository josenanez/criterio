<!-- origen: PRY-209-electrificación-de-equipos/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-13
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **45%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.559.247.474 |
| Ejecutado | 788.256.015 |
| Proyección al cierre | 5.247.860.031 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Ventana de parada de planta definida por operaciones
