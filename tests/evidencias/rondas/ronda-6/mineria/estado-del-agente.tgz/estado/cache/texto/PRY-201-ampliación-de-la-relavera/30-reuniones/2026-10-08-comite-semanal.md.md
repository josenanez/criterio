<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Ampliación de la relavera

**Fecha:** 2026-10-08
**Asistentes:** Óscar Ramírez, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 36 | 2026-10-28 |
