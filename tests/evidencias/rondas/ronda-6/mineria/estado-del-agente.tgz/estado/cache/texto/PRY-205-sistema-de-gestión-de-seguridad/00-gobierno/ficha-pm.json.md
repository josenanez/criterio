<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-205",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "name": {
 "value": "Sistema de gestión de seguridad",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "business_area": {
 "value": "Geología",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Andrés Lozano",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "manager": {
 "value": "Paula Céspedes",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "committee": {
 "value": "Comité Ambiental",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 58,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-11",
 "source": "20-seguimiento/2026-10-11-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-01-02",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "end_date": {
 "value": "2027-04-23",
 "source": "10-plan/2025-12-23-cronograma-v1.xlsx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-12-23",
 "start_date": "2026-01-02",
 "end_date": "2027-04-23",
 "reason": "Aprobación inicial del Comité Ambiental",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2026-06-09",
 "current_date": "2026-06-09",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-12-23-cronograma-v1.xlsx"
 },
 {
 "name": "Ingeniería de detalle aprobada",
 "baseline_date": "2026-11-15",
 "current_date": "2026-11-15",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-12-23-cronograma-v1.xlsx"
 },
 {
 "name": "Licencia y permisos obtenidos",
 "baseline_date": "2027-04-23",
 "current_date": "2027-04-23",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-12-23-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "approved": {
 "value": 800000000,
 "source": "00-gobierno/2025-12-23-acta-constitucion.docx",
 "source_date": "2025-12-23",
 "state": "found"
 },
 "committed": {
 "value": 324133771,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "executed": {
 "value": 258170381,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "projection": {
 "value": 765512063,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Ventana de parada de planta definida por operaciones",
 "owner": null,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11"
 },
 {
 "what": "Cambio en la licencia ambiental que puede mover el alcance",
 "owner": null,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "owner": null,
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "registered": false
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un ingeniero clave",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-11-informe-avance.md",
 "source_date": "2026-10-11"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-20",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-12-06",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-20",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-13",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-26",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-12-13",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-13",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-09-25",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-25",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "source_date": "2026-09-04",
 "state": "found"
 },
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-09-acta-recibo-4.md",
 "source": "20-seguimiento/2026-10-09-acta-recibo-4.md",
 "source_date": "2026-10-09",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "claimed_delivered": {
 "value": "dice que ya entregó, no se presentó acta",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25"
 }
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-28",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-14",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-09-28",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "source_date": "2026-09-11",
 "state": "found"
 },
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-09-25-acta-recibo-8.md",
 "source": "20-seguimiento/2026-09-25-acta-recibo-8.md",
 "source_date": "2026-09-25",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-25",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-25-acta-recibo-10.md",
 "source": "20-seguimiento/2026-09-25-acta-recibo-10.md",
 "source_date": "2026-09-25",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-25-acta-recibo-11.md",
 "source": "20-seguimiento/2026-09-25-acta-recibo-11.md",
 "source_date": "2026-09-25",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "source_date": "2026-09-18",
 "state": "found"
 },
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-02-acta-recibo-13.md",
 "source": "20-seguimiento/2026-10-02-acta-recibo-13.md",
 "source_date": "2026-10-02",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "claimed_delivered": {
 "value": "dice que ya entregó, no se presentó acta",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02"
 }
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-07",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-07",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "source_date": "2026-09-25",
 "state": "found"
 },
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-09-acta-recibo-16.md",
 "source": "20-seguimiento/2026-10-09-acta-recibo-16.md",
 "source_date": "2026-10-09",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-26",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "source_date": "2026-10-09",
 "state": "found"
 },
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found",
 "note": "«la otra semana»; nadie dijo fecha"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-26",
 "source": "2026-10-16-notas-reunion.txt",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-16",
 "fields_not_found": [
 "identity.product (el acta dice «No aplica»)",
 "identity.authority",
 "identity.phase",
 "vendors (ningún contrato en la carpeta)"
 ],
 "open_conflicts": []
 }
}
