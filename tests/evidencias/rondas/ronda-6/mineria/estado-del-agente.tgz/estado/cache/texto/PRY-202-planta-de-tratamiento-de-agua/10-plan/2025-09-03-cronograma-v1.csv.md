<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2025-09-03-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-11-10,2025-11-10,cerrado
Ingeniería de detalle aprobada,2026-01-08,2026-01-08,cerrado
Licencia y permisos obtenidos,2026-03-07,2026-03-07,cerrado
Montaje e instalación,2026-05-05,2026-05-05,cerrado
Pruebas en operación,2026-07-02,2026-07-02,cerrado
