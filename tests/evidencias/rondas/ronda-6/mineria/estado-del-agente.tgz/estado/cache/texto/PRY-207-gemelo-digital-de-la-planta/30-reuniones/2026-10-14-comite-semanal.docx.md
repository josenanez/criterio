<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Operaciones · Gemelo digital de la planta

Fecha: 2026-10-14

Asistentes: Liliana Torres, Camilo Beltrán

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Rubén Cárdenas

Entregar el punto 30

2026-10-18

Gustavo Neira

Entregar el punto 21

por definir
