<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Despacho automático de flota

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 37 | 2026-10-01 |
