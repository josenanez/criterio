<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Despacho automático de flota
Código: PRY-203
Fecha de corte: 2026-10-04
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 58%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad
- Las lluvias detuvieron el montaje durante diez días
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 761.236.966
Ejecutado 977.479.972
Proyección al cierre 2.427.429.368

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Bloqueo de la vía de acceso a la mina
