<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-01-27-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-03-27,2026-03-27,cerrado
Ingeniería de detalle aprobada,2026-05-16,2026-05-16,cerrado
Licencia y permisos obtenidos,2026-07-04,2026-07-04,cerrado
Montaje e instalación,2026-08-23,2026-08-23,cerrado
Pruebas en operación,2026-10-12,2026-10-12,en curso
