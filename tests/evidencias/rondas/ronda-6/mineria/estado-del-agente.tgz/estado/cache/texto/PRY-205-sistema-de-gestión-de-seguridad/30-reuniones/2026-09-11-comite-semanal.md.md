<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/30-reuniones/2026-09-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-09-11
**Asistentes:** Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Mauricio Pérez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-10-07 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-13 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-13 |
| Felipe Arango | Validar el ambiente 4 | 2026-09-25 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-10-06 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-14 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 |
| Elena Duarte | Entregar el punto 8 | 2026-10-02 |
