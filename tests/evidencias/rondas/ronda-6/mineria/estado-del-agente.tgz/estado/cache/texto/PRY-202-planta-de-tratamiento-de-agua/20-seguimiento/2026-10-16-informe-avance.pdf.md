<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-16
Gerente: Óscar Ramírez

Estado declarado
Amarillo
Avance reportado: 70%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.657.958.497
Ejecutado 537.469.391
Proyección al cierre 2.469.560.038

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
