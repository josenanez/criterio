<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Control de polvo en vías
Código: PRY-211
Fecha de corte: 2026-10-08
Gerente: Natalia Ospina

Estado declarado
Amarillo
Avance reportado: 63%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 800.000.000
Comprometido 314.613.145
Ejecutado 296.031.516
Proyección al cierre 943.567.807

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
