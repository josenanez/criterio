<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/10-plan/2026-06-08-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-10-05,2026-10-05,cerrado
Ingeniería de detalle aprobada,2027-01-22,2027-01-22,en curso
Licencia y permisos obtenidos,2027-05-11,2027-05-11,en curso
Montaje e instalación,2027-08-28,2027-08-28,en curso
Pruebas en operación,2027-12-15,2027-12-15,en curso
