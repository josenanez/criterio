<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2026-02-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Mantenimiento

Patrocinador: Javier Hoyos

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2026-02-05

Objetivo del negocio

Entregar ampliación de la relavera para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Inversiones el 2026-02-05.

Fechas comprometidas

Fecha

Inicio

2026-02-15

Cierre

2027-04-18

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
