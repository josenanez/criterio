<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-12-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-06-09 | 2026-06-09 | cerrado
Ingeniería de detalle aprobada | 2026-11-15 | 2026-11-15 | en curso
Licencia y permisos obtenidos | 2027-04-23 | 2027-04-23 | en curso
