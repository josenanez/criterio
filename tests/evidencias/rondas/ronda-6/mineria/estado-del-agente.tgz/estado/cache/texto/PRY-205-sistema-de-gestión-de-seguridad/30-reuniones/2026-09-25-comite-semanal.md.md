<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-09-25
**Asistentes:** Andrés Lozano, Camilo Beltrán, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-06 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-18 |
| Gustavo Neira | Revisar el anexo 3 | 2026-10-03 |
| Felipe Arango | Validar el ambiente 4 | 2026-09-25 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 |
| Andrés Lozano | Enviar el documento 9 | 2026-09-25 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-18 |
| Ricardo Salas | Actualizar la matriz 14 | 2026-10-16 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 |
| Camilo Beltrán | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Entregar el punto 8 (Elena Duarte): recibido, acta de recibo del 2026-09-25.
- Cerrar la prueba 10 (Javier Hoyos): recibido, acta de recibo del 2026-09-25.
- Revisar el anexo 11 (Rubén Cárdenas): recibido, acta de recibo del 2026-09-25.

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «aprobar el diseño 5». No se presentó acta.
