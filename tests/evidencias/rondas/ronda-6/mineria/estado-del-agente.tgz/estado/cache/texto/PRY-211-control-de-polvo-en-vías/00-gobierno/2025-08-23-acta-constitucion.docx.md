<!-- origen: PRY-211-control-de-polvo-en-vías/00-gobierno/2025-08-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Control de polvo en vías

Código: PRY-211

Área dueña: Tecnología

Patrocinador: Paula Céspedes

Gerente de proyecto: Natalia Ospina

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2025-08-23

Objetivo del negocio

Entregar control de polvo en vías para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Operaciones el 2025-08-23.

Fechas comprometidas

Fecha

Inicio

2025-09-02

Cierre

2026-05-19

Criterio de éxito

Control de polvo en vías en producción y medido.

Dependencias declaradas

• Ninguna declarada
