<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2026-10-04-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-08-16,2025-08-16,cerrado
Ingeniería de detalle aprobada,2025-11-03,2025-11-03,cerrado
Licencia y permisos obtenidos,2026-01-21,2026-05-21,cerrado
