<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2025-07-07-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-09-16,2025-09-16,cerrado
Ingeniería de detalle aprobada,2025-11-17,2025-11-17,cerrado
Licencia y permisos obtenidos,2026-01-18,2026-01-18,cerrado
Montaje e instalación,2026-03-21,2026-03-21,cerrado
Pruebas en operación,2026-05-22,2026-05-22,cerrado
