<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ampliación de la relavera
Código: PRY-201
Fecha de corte: 2026-10-15
Gerente: Óscar Ramírez

Estado declarado
Verde
Avance reportado: 76%

Lo que pasó en el periodo
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.599.687.700
Ejecutado 868.334.873
Proyección al cierre 4.040.633.078

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
