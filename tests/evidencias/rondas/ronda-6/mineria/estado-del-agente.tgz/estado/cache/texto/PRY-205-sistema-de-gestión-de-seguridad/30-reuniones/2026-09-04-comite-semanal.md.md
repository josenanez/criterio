<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/30-reuniones/2026-09-04-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-09-04
**Asistentes:** Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-09-30 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-02 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-13 |
| Felipe Arango | Validar el ambiente 4 | 2026-09-25 |
