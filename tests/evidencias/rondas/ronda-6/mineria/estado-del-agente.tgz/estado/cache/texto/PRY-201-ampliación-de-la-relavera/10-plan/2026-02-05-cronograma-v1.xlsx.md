<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-02-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-11 | 2026-05-11 | cerrado
Ingeniería de detalle aprobada | 2026-08-04 | 2026-08-04 | cerrado
Licencia y permisos obtenidos | 2026-10-29 | 2026-10-29 | en curso
Montaje e instalación | 2027-01-22 | 2027-01-22 | en curso
Pruebas en operación | 2027-04-18 | 2027-04-18 | en curso
