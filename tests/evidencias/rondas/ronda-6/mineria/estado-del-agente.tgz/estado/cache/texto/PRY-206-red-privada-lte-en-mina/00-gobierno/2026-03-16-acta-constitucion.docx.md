<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2026-03-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Mantenimiento

Patrocinador: Óscar Ramírez

Gerente de proyecto: Camilo Beltrán

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2026-03-16

Objetivo del negocio

Entregar red privada lte en mina para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité Ambiental el 2026-03-16.

Fechas comprometidas

Fecha

Inicio

2026-03-26

Cierre

2026-11-01

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
