<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 56%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.057.331.261
Ejecutado 1.455.603.409
Proyección al cierre 3.106.425.264

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
