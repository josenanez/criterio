<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Natalia Ospina

Estado declarado
Amarillo
Avance reportado: 56%

Lo que pasó en el periodo
- El proveedor entregó los equipos en el campamento, pendientes de aceptación

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 11.373.057.398
Ejecutado 4.377.951.088
Proyección al cierre 17.015.122.466

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
