<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2025-10-10-acta-recibo-ct-855-licenciamiento-del-software.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Licenciamiento del software

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha de recibo:** 2025-10-10
**Recibido por:** Natalia Ospina

Se recibe a satisfacción el entregable **Licenciamiento del software**.

Contrato CT-855 · Ingeniería Minera del Sur S.A.S..
