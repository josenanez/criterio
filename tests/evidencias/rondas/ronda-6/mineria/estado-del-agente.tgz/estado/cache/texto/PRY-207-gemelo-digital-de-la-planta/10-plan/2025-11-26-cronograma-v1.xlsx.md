<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2025-11-26-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-02-07 | 2026-02-07 | cerrado
Ingeniería de detalle aprobada | 2026-04-11 | 2026-04-11 | cerrado
Licencia y permisos obtenidos | 2026-06-14 | 2026-06-14 | cerrado
Montaje e instalación | 2026-08-16 | 2026-08-16 | cerrado
Pruebas en operación | 2026-10-19 | 2026-10-19 | en curso
