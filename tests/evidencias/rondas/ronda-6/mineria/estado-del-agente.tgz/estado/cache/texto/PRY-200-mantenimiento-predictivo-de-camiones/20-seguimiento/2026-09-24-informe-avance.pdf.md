<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Mantenimiento predictivo de camiones
Código: PRY-200
Fecha de corte: 2026-09-24
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 30%

Lo que pasó en el periodo
- Se actualizó el presupuesto de la obra con el área de compras
- Se levantó un hallazgo en la auditoría de seguridad
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 6.199.323.109
Ejecutado 7.288.618.068
Proyección al cierre 16.873.506.496

Riesgos abiertos
- Concentración del conocimiento en una sola persona
