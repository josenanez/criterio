<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Trazabilidad del mineral
Código: PRY-208
Fecha de corte: 2026-10-16
Gerente: Javier Hoyos

Estado declarado
Verde
Avance reportado: 77%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 2.620.701.714
Ejecutado 3.821.892.255
Proyección al cierre 9.877.132.559

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
