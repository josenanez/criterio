<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2025-11-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la planta

Código: PRY-207

Área dueña: Medio Ambiente

Patrocinador: Camilo Beltrán

Gerente de proyecto: Liliana Torres

Comité: Comité de Operaciones

Producto asociado: gemelo digital

Fecha de aprobación: 2025-11-26

Objetivo del negocio

Entregar gemelo digital de la planta para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Operaciones el 2025-11-26.

Fechas comprometidas

Fecha

Inicio

2025-12-06

Cierre

2026-10-19

Criterio de éxito

Gemelo digital de la planta en producción y medido.

Dependencias declaradas

• Ninguna declarada
