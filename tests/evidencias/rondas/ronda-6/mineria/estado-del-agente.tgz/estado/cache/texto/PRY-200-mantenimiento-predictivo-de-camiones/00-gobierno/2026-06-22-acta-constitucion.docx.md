<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2026-06-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de camiones

Código: PRY-200

Área dueña: Geología

Patrocinador: Felipe Arango

Gerente de proyecto: Jorge Medina

Comité: Comité de Seguridad

Producto asociado: monitoreo de flota

Fecha de aprobación: 2026-06-22

Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Seguridad el 2026-06-22.

Fechas comprometidas

Fecha

Inicio

2026-07-02

Cierre

2027-11-08

Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

Dependencias declaradas

• Ninguna declarada
