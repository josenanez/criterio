<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/2026-10-16-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión sistema de gestión de seguridad — 2026-10-16
estuvieron: Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Sandra Gil, Óscar Ramírez

- Elena Duarte dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 20/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
