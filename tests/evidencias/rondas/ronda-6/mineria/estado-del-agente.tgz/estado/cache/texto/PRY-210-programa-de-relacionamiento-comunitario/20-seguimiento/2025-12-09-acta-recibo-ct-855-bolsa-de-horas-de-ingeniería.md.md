<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2025-12-09-acta-recibo-ct-855-bolsa-de-horas-de-ingeniería.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha de recibo:** 2025-12-09
**Recibido por:** Natalia Ospina

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-855 · Ingeniería Minera del Sur S.A.S..
