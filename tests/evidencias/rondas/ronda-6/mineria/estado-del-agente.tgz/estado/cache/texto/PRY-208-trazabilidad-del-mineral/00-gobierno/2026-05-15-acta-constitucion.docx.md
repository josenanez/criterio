<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2026-05-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Mina

Patrocinador: Paula Céspedes

Gerente de proyecto: Javier Hoyos

Comité: Comité de Inversiones

Producto asociado: trazabilidad

Fecha de aprobación: 2026-05-15

Objetivo del negocio

Entregar trazabilidad del mineral para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Inversiones el 2026-05-15.

Fechas comprometidas

Fecha

Inicio

2026-05-25

Cierre

2027-03-17

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
