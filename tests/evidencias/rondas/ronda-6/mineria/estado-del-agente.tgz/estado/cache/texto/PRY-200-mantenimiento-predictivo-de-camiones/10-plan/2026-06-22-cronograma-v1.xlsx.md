<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2026-06-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-10-08 | 2026-10-08 | cerrado
Ingeniería de detalle aprobada | 2027-01-15 | 2027-01-15 | en curso
Licencia y permisos obtenidos | 2027-04-24 | 2027-04-24 | en curso
Montaje e instalación | 2027-08-01 | 2027-08-01 | en curso
Pruebas en operación | 2027-11-08 | 2027-11-08 | en curso
