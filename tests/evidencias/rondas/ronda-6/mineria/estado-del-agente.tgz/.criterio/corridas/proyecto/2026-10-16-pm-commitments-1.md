# Corrida · 2026-10-16-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:28:54 · **Fin:** 2026-10-16T15:29:46 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 34 | 14 | Reprogramados: Elena Duarte (6 veces, documento 1) y Laura Vélez (5 veces, prueba 2); 7 vencidos sin evidencia, 3 sin fecha; el verde declarado el 10-11 no se sostiene |

Por señal (`pm-commitments`): `commitment_overdue` 7, `commitment_undated` 3, `commitment_rescheduled` 2, `milestone_met_without_evidence` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — PRY-205 Sistema de gestión de seguridad · al 2026-10-16

De 26 compromisos registrados, 20 siguen abiertos sin cierre documentado. Siete están vencidos, tres no tienen fecha y dos se vienen reprogramando.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16, así que no los registré de nuevo. No había minuta en el argumento, así que revisé todo lo abierto. Las cifras salen de `compute`.

### Se viene reprogramando
> **Elena Duarte** · Enviar el documento 1
> Prometido para el 09-30 y reprogramado seis veces (10-07, 10-28, 11-06, 11-27, 12-06). Hoy está para el **12-20**.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Laura Vélez** · Cerrar la prueba 2
> Prometido para el 10-02 y reprogramado cinco veces (10-13, 10-30, 11-18, 11-26). Hoy está para el **12-13**.
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Paula Céspedes | Actualizar la matriz 6 | 09-28 | 18 días |
| Gustavo Neira | Confirmar la fecha 7 | 10-02 | 14 días |
| Gustavo Neira | Revisar el anexo 3 (reprogramado 2 veces) | 10-03 | 13 días |
| Sandra Gil | Confirmar la fecha 15 | 10-07 | 9 días |
| Mauricio Pérez | Validar el ambiente 12 | 10-12 | 4 días |
| Mauricio Pérez | Aprobar el diseño 5 | 10-14 | 2 días |
| Diana Molina | Revisar el anexo 19 | 10-14 | 2 días |

Mauricio Pérez dice que ya entregó el diseño 5, pero no hay acta de recibo ni nada en el expediente que lo respalde. Sigue abierto.

### Vencen esta semana
- **Ricardo Salas** · Actualizar la matriz 14 · hoy, 10-16. Dijo el 10-02 que ya entregó, pero no se presentó acta. Sigue abierto.

### Sin fecha
Estos no pueden estar vencidos, por eso se cuentan aparte:
- **Carlos Peña** · Cerrar la prueba 18 · dicho el 10-02
- **Rubén Cárdenas** · Actualizar la matriz 22 · dicho el 10-09
- **Laura Vélez** · Mandar el ajuste del presupuesto · dicho el 10-16 («la otra semana»; nadie dijo fecha)

### Cerrados con acta de recibo
Seis compromisos tienen su acta: Felipe Arango (ambiente 4), Camilo Beltrán (punto 16), Gustavo Neira (diseño 13), Elena Duarte (punto 8), Javier Hoyos (prueba 10) y Rubén Cárdenas (anexo 11).

### Contradicción con el estado declarado
El informe del 10-11 declara **verde**, y los documentos no lo sostienen. Hay siete vencidos y dos compromisos reprogramados repetidamente. Además, el hito «Ingeniería básica aprobada» (2026-06-09) figura cumplido sin evidencia. Qué hacer con ese verde le toca a la gerente del proyecto.

### Después
Lo de Elena Duarte y Laura Vélez excede la autoridad del gerente, y se puede formular como decisión para el comité del 2026-10-30. Eso se hace con `/pm-escalate`. Si esto cambia lo que dice la ficha, `/pm-publish` la deja visible para la PMO.

La salida completa quedó en `estado/PRY-205-sistema-de-gestión-de-seguridad/corridas/salida-pm-commitments.md`. La corrida quedó registrada como `2026-10-16-pm-commitments-1`: 14 hallazgos, 34 segundos.
