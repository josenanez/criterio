# Corrida · 2026-10-16-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view gemelo digital

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:53:37 · **Fin:** 2026-10-16T15:54:16 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 24 | 60 | Producto con un solo proyecto (PRY-207): sin sección de producto, señales del proyecto resumidas. 7 proyectos sin producto declarado reportados; el área dueña no sale de compute y no se escribió. |

Por señal (`product-view`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Terminé la vista de «gemelo digital» y dejé la corrida registrada.

**Producto con un solo proyecto.** «Gemelo digital» tiene solo PRY-207, así que no armé sección de producto. No hay señales que sumar entre proyectos ni dependencias internas.

Lo que sí dice el cálculo sobre ese proyecto (9 alertas):
- **Declaración:** informa verde y 87 % de avance (2026-10-14), pero tres señales abiertas no figuran en esa declaración.
- **Hitos:** 4 aparecen cumplidos sin evidencia.
- **Proveedor (Automatización de Procesos Ltda.):**
  - Dos entregables siguen pendientes: licenciamiento, vencido hace 245 días, y calibración de sensores, hace 105.
  - Lo facturado supera lo aceptado en COP 486.453.914.
- **Compromiso sin fecha:** Gustavo Neira, «Entregar el punto 21».
- **Fecha del producto:** 2026-10-19, con 0 días de desviación.
- **Dinero:** aprobado COP 18.000.000.000, comprometido 61,8 %, ejecutado 31,3 %, proyección 0,9 % sobre lo aprobado.
- **Campos que faltan en la ficha:** autoridad y fase.

**Siete proyectos sin producto declarado**: PRY-201, 202, 205, 206, 209, 210 y 211. Nadie puede responder por el conjunto al que sirven. El área dueña no sale del cálculo y no la escribí.

**Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los volví a registrar.

**Pendiente:** para producto de un solo proyecto no había nada que llevar al comité de producto, así que no ofrecí esa decisión.

La salida completa está en `estado/corridas/salida-product-view.md` y la corrida en `estado/corridas/2026-10-16-product-view-1.md` (24 segundos, 13 proyectos, 60 hallazgos).
