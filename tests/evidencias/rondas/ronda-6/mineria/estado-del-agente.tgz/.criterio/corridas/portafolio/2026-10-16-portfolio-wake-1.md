# Corrida · 2026-10-16-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:56:02 · **Fin:** 2026-10-16T15:56:37 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 22 | 60 | Barrido: 78 documentos sin cambios; 0 peticiones. Citas de PRY-205 no resuelven en el índice aunque los archivos existen (causa sin verificar). Confirmación no preguntada: sin interlocutor. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## 2026-10-16

**Revisé:** 78 documentos, ninguno cambió, 0 proyectos recalculados. Vuelvo el 2026-10-17.

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.
- **Citas de PRY-205:** el índice dice que ninguna ruta de fuente de esa ficha resuelve. Son los campos de identidad, estado declarado, plan, dinero y los 26 compromisos. Los archivos citados sí existen en la carpeta del proyecto. Sospecho que la ficha usa rutas relativas a la carpeta del proyecto y el índice las busca desde la raíz de documentos. No lo verifiqué, y no toqué la ficha.
- **Peticiones:** no había ninguna en el servidor.
- **Confirmación periódica:** toca y nunca se ha hecho, pero nadie podía responder en esta corrida. No pregunté y no la registré como hecha, así que vuelve a tocar mañana.
- **Informe de comité:** el del 2026-10-19 toca mañana, con dos días de anticipación.

El barrido sí quedó registrado como hecho. La salida está en `estado/corridas/salida-portfolio-wake.md` y la corrida en `2026-10-16-portfolio-wake-1`. El registro de la corrida cuenta 60 hallazgos abiertos en 9 de los 13 proyectos. Los más repetidos son hitos cumplidos sin evidencia (20), entregables de proveedor atrasados (9) y compromisos vencidos (8), 7 de ellos en PRY-205. Esas cifras no vienen de una relectura de hoy, porque no cambió ningún documento.
