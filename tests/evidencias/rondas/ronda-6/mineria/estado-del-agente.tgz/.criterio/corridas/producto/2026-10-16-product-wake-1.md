# Corrida · 2026-10-16-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:58:53 · **Fin:** 2026-10-16T15:59:41 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 14 | — | 33 | 35 | Primera revisión, sin corte previo: 3 hallazgos de decisión (REQ-4111 167 d, supuesto 54 d, volumen declarado 37,4 % sobre lo medido), aceptados sin sustento, trazas sin confirmar. No sé: éxito del producto, ni si estado/records es la carpeta de fichas; índice marca fuentes inexistentes que sí existen. |

Por señal (`product-wake`): `requirement_untraced` 13, `evidence_stale` 7, `requirement_accepted_without_evidence` 6, `requirement_without_owner` 5, `requirement_without_acceptance` 1, `requirement_undecided` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

## Alerta de taludes (PRD-301) · 2026-10-16

Esta fue la primera revisión del registro y no había corte anterior. Por eso lo que sigue es lo que hay hoy, no lo que cruzó un umbral desde una corrida previa. Dejé el corte de hoy. Desde la próxima corrida solo se reportará lo nuevo.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16, y no tuve que registrarlos de nuevo. No había documentos nuevos ni cambiados que releer (5 revisados).

**Lo que necesita decisión**
- **REQ-4111 sin decidir:** lleva 167 días, con un umbral de 60. Se planteó el 2026-05-02 y su doliente es Rubén Cárdenas. Lo decide el Comité de producto.
- **Supuesto sin verificar:** «El proveedor cumple el tiempo pactado» lleva 54 días, con un umbral de 30. Falta verificarlo con el proveedor o tratarlo como riesgo registrado.
- **Volumen mensual:** el caso de negocio declara 169.380 y la bodega de datos mide 106.047. La cifra declarada está 37,4 % por encima, con un umbral de 20 %.

**Aceptado sin sustento**
- 6 requerimientos no tienen evidencia de demanda: REQ-4100, 4102, 4103, 4104, 4108 y 4113.
- 7 se apoyan solo en una entrevista del 2025-10-06 que cumple 12 meses: REQ-4101, 4105, 4106, 4107, 4109, 4110 y 4112.
- 5 no tienen doliente: REQ-4106, 4107, 4108, 4109 y 4113.
- REQ-4105 no tiene criterio de aceptación.

**Trazas:** ninguna se da por confirmada. Los 13 requerimientos aceptados figuran sin proyecto que los construya. La configuración no nombra una carpeta de fichas, así que usé `estado/records` porque es la que hay en este espacio. Confírmala si no es la correcta.

**Lo que no sé**
- El éxito del producto no está definido en ningún documento.
- El índice marca como inexistentes dos fuentes que sí existen: la definición `.docx` y el acta del comité del 2026-10-12. Parece un problema del índice y no lo corregí.

**Vuelvo el 2026-11-15.**

El informe completo está en `estado-producto/PRD-301/corridas/salida-product-wake.md`, y la corrida quedó registrada como `2026-10-16-product-wake-1`.
