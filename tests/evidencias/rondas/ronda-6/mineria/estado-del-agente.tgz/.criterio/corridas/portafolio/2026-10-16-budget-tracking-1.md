# Corrida · 2026-10-16-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-209

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-209

**Inicio:** 2026-10-16T15:43:40 · **Fin:** 2026-10-16T15:44:24 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 29 | 60 | Presupuesto de PRY-209: proyección excede el aprobado en 24.9%; comprometido 60.9% (bajo umbral). Dijo que no hay hitos ni detalle por proveedor para cruzar ejecución con avance, y que CC-01 (+186M, pendiente) no cubre la brecha proyectada. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

**Presupuesto de PRY-209 (Electrificación de equipos) al 2026-10-16:** la proyección declarada al cierre excede el aprobado en 24,9 %, por encima del umbral de 10 %. La corrida quedó registrada como `2026-10-16-budget-tracking-1`. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no volví a registrarlos.

| Concepto | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 4.200.000.000 | 100 |
| Comprometido | 2.559.247.474 | 60,9 |
| Ejecutado | 788.256.015 | 18,8 |
| Proyección al cierre | 5.247.860.031 | 124,9 |

- **Fuentes:** el aprobado sale del acta de constitución (2026-02-06). Las otras tres cifras salen del informe de avance con corte 2026-10-13. La proyección es una declaración de la gerente, no un dato medido.
- **Disponible real:** 1.640.752.526 COP (aprobado menos comprometido). El comprometido está por debajo del umbral de 90 %, así que no hay alerta por ese lado.
- **Contra la línea base:** no hay replanificaciones de presupuesto.
- **Solicitud de cambio CC-01:** está pendiente de presentación al comité y pide +186.000.000 COP y +93 días. No cubre la brecha que la propia proyección señala. El informe declara estado amarillo y no explica la desviación.
- **Ejecución frente a avance:** el ejecutado (18,8 %) es menos de la mitad del avance declarado (45 %). No puedo decir cuál de las dos cifras falla, porque ningún documento declara hitos.
- **Sin dato:** hitos, comprometido por proveedor, base de cálculo de la proyección, y fase, producto y autoridad del proyecto.

Si quieres, puedo preparar la solicitud de cambio de presupuesto.

La salida completa quedó en `/home/claude/banco/ronda-6/mineria/espacio/estado/corridas/salida-budget-tracking.md`.
