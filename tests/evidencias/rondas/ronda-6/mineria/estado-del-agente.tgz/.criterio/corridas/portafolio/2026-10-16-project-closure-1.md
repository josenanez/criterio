# Corrida · 2026-10-16-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-16T15:50:24 · **Fin:** 2026-10-16T15:51:26 · **Duración:** 62 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 47 | 60 | Cierre de PRY-202 no recomendado: el proyecto sigue abierto (70 % declarado, amarillo). Criterio de éxito no determinable; 4 hitos cerrados sin evidencia; calibración de sensores recibida sin acta y facturación sin acta; 2 incidencias sin doliente. No supe: umbral de disponibilidad, contenido de los componentes, quién reprogramó la parada, y a qué entregable corresponde la factura FV-1250. |

Por señal (`project-closure`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

**No recomiendo cerrar PRY-202.** El informe de hoy lo declara en amarillo y al 70 %, y nada en la carpeta sostiene un cierre.

**Cómo se hizo.** Los términos ya estaban vigentes (versión 1.1, registrados el 2026-10-16 a nombre de José Francisco Ñáñez), así que no se volvieron a registrar. No hubo preguntas que responder. El cierre sale de la ficha, de seis documentos del proyecto y de las cifras de `compute`. El texto completo está en `estado/corridas/salida-project-closure.md` y la corrida quedó registrada como `2026-10-16-project-closure-1`.

- **Criterio de éxito:** el acta pide "planta en producción y medido". Ningún documento lo muestra, y el informe dice que el primer ensayo de disponibilidad no alcanzó lo pactado y se repite. El acta tampoco fija el umbral a medir.
- **Hitos:** el cronograma marca los cinco hitos como cerrados, pero solo el montaje tiene acta de recibo, y es del 2026-10-03 frente a una fecha de hito del 2026-05-05. Los otros cuatro no tienen evidencia. El plan respalda 100 % de avance y el gerente declara 70 %.
- **Fechas:** la desviación sale en 0 días porque nadie movió la línea base, pero la fecha de cierre (2026-07-02) pasó hace 106 días. El informe menciona una parada de planta reprogramada que no tiene cambio registrado. Hay 0 replanificaciones.
- **Presupuesto (COP):** aprobado 2.400.000.000, comprometido 1.657.958.497 (69,1 %), ejecutado 537.469.391 (22,4 %). La proyección es +2,9 % sobre lo aprobado.
- **Proveedor CT-250:** hay dos entregables vencidos y sin recibo, con 318 y 237 días de atraso. La calibración de sensores figura como recibida sin acta, aunque el contrato exige acta firmada. La factura FV-1250 por 110.830.774 COP no dice contra qué entregable se emitió.
- **RAID:** el hallazgo de seguridad y la repetición del ensayo no tienen responsable, así que no están cerrados. Los riesgos de licencia ambiental y de bloqueo de la vía siguen abiertos.
- **Lecciones:** solo quedaron tres, las que se anclan a un hecho documentado. El acta tampoco nombra los tres componentes del alcance, por lo que no se puede comprobar qué quedó fuera.

Dejé sin mover la carpeta a `archivo/` y sin congelar la ficha, porque el proyecto no está cerrado. Sigue en el barrido diario.
