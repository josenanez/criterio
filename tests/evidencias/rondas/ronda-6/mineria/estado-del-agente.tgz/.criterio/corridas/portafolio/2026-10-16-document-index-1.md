# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:40:33 · **Fin:** 2026-10-16T15:41:02 · **Duración:** 28 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 16 | 60 | 78 documentos sin cambio, 0 por releer. 134 citas de PRY-205 marcadas source_missing aunque los archivos existen: la ficha-pm.json cita con ruta relativa al proyecto y el índice resuelve desde la raíz. No corregí la ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## Carpeta al 2026-10-16

**Documentos:** 78 · **Sin cambio:** 78 · **Hay que releer:** 0

No cambió ningún documento. No hay nuevos, cambiados, reguardados, renombrados ni borrados, y el índice no reporta formatos ilegibles. No ofrezco `/portfolio-scan`, porque `projects_to_recompute` está vacío.

**Citas que dejaron de resolver:** el índice marca 134 citas de PRY-205 como `source_missing`, pero los archivos sí existen. Salen todas de `00-gobierno/ficha-pm.json`, que cita con ruta relativa a la carpeta del proyecto, mientras que el índice las busca desde `documentos/proyectos`. Lo comprobé listando la carpeta: el acta de constitución, el cronograma v1, el informe de avance, las actas de recibo, los comités y las notas del 2026-10-16 están ahí.

No corregí la ficha, porque no se reescribe en silencio. La decisión es de ustedes: o la ficha cita con la ruta completa, o el índice resuelve esa ficha desde su carpeta de proyecto.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no pedí aceptación de nuevo.

La corrida quedó registrada como `2026-10-16-document-index-1` y la salida está en `estado/corridas/salida-document-index.md`. La corrida contó 60 hallazgos en 13 proyectos, pero salen de los datos de las fichas, no de este índice. No los revisé.
