# Corrida · 2026-10-16-product-spec-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-spec (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:22:44 · **Fin:** 2026-10-16T15:23:58 · **Duración:** 74 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-spec` | 14 | — | 58 | 35 | Borrador de especificación sin secciones de comportamiento: los 13 aceptados no tienen problema escrito y 12 de 13 solo dicen 'se verifica en producción' (REQ-4105 sin criterio). Dejó a la vista 12 vacíos con dueño, incluidos casos borde, dependencias con el proveedor sin acordar y obligaciones normativas sin confirmar. No sabe qué hace cada requerimiento, qué proveedor es, ni si hay normativa sectorial aplicable. |

Por señal (`product-spec`): `requirement_untraced` 13, `evidence_stale` 7, `requirement_accepted_without_evidence` 6, `requirement_without_owner` 5, `requirement_without_acceptance` 1, `requirement_undecided` 1, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Escribí el borrador de especificación de PRD-301 (Alerta de taludes), pero no tiene secciones de comportamiento. Los 13 requerimientos aceptados no tienen escrito el problema que resuelven, y el registro no permite inventarlo. Quien debe cerrarlo es Mauricio Pérez, gerente de producto.

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-16). No hubo preguntas que responder.

- **Alcance:** entran los 13 aceptados, solo por su identificador. REQ-4111 queda fuera porque está propuesto desde hace 167 días y nadie lo ha decidido.
- **Criterios de aceptación:**
  - 12 de los 13 dicen «se verifica en producción», que es un lugar y no un criterio medible.
  - REQ-4105 no tiene ninguno.
  - No propuse umbrales, porque ningún documento los da.
- **Supuestos:**
  - «El proveedor cumple el tiempo pactado» lleva 54 días sin verificar.
  - La evidencia de demanda es una entrevista de hace 12 meses que no nombra ningún requerimiento.
  - La cifra del caso de negocio (169.380) está 37,4 % por encima de la medida (106.047).
- **Vacíos:** son 12, cada uno con quien lo cierra. Incluyen:
  - los casos borde, que ningún documento menciona;
  - el criterio de éxito, que no existe;
  - los 5 requerimientos sin doliente;
  - que el acta no dice quién decidió cada aceptación;
  - el proveedor, que nadie ha acordado;
  - las obligaciones normativas, que quedan por confirmar.
- **Lo que no cubre:** los 13 aceptados entran solo nominalmente, y la tabla da el motivo de cada uno. Seis no tienen ninguna cita de quien los pidió.
- **Siguiente paso:** `/product-charter` todavía no aplica. Primero hay que escribir el problema y el criterio de los más antiguos (REQ-4109, 4103, 4106) y asignar dolientes. `/product-trace` sí aplica, porque ninguno de los 13 tiene proyecto.

La corrida quedó registrada como `2026-10-16-product-spec-1`: 58 s, 14 requerimientos, 35 hallazgos.

Archivos en `estado-producto/PRD-301/corridas/`:
- `salida-product-spec.md`
