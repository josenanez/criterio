# Corrida · 2026-10-16-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-200 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-16T15:45:30 · **Fin:** 2026-10-16T15:46:15 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 30 | 60 | Solicitud PRY-200 +30 dias a salida a produccion. Sin solicitante, motivo, autoridad declarada ni impacto en alcance/costo; interprete salida a produccion como Pruebas en operacion; sin dependencias declaradas; no se calculan dias por hito (sin holgura). |

Por señal (`change-control`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

**Solicitud de cambio PRY-200: mover la salida a producción 30 días.** No se puede decidir con lo que hay, y por defecto va a comité. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no registré ninguno nuevo.

- **Qué se mueve:** el cronograma no tiene un hito «salida a producción». Tomé *Pruebas en operación*, que es también el cierre, y pasa de 2027-11-08 a 2027-12-08. Si se refería a otro hito, hay que decirlo.
- **Tiempo:** son +30 días, cerca del 6 % del plan, bajo el umbral de 10 %. No sé cuántos días se mueven los hitos intermedios, porque la ficha no tiene holgura por actividad.
- **Alcance y costo:** la solicitud no declara impacto en ninguno de los dos. Entonces alguien absorbe la extensión sin que se diga quién. Hay 1.126.493.504 COP de margen entre lo aprobado y la proyección, pero nadie lo ha asignado a este cambio.
- **Portafolio:** el cálculo no encontró proyectos alcanzados. Eso vale solo para dependencias declaradas, y el acta dice «Ninguna declarada».
- **Quién decide:** el acta no declara autoridad de cambio. El Comité de Seguridad aprobó la línea base, así que el paquete va ahí. Este vacío es el hallazgo de fondo.
- **Si se aprueba:** queda una línea base 2 con cierre 2027-12-08, y la línea base 1 no se toca. La desviación acumulada contra la original sería de +30 días, sin cambio de costo declarado. El motivo hay que escribirlo: ningún documento lo da.
- **Falta en la solicitud:** quién la pide y por qué. El informe del 2026-09-24 menciona un hallazgo de auditoría de seguridad sin dueño y una parada de planta reprogramada. Pueden ser la razón, pero no lo confirman.
- **Aparte, en el informe de avance:** lo ejecutado supera lo comprometido, y nadie lo explica.

La corrida quedó registrada como `2026-10-16-change-control-1`, con la salida completa en `estado/corridas/salida-change-control.md`.
