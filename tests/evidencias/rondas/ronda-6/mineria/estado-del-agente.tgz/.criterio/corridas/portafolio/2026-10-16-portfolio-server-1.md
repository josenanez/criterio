# Corrida · 2026-10-16-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:56:42 · **Fin:** 2026-10-16T15:57:28 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 60 | puerto 8787, informe en reportes/, modo rato (127.0.0.1) |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 9, `commitment_overdue` 8, `progress_vs_plan` 4, `declared_vs_evidence` 4, `commitment_undated` 4, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_invoiced_without_delivery` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Rostrum está corriendo en **http://127.0.0.1:8791/**, solo en este equipo. Lo levanté en modo «para mirarlo un rato», que es lo que pedía el argumento `rato`.

- **Términos:** ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-16). No pedí un nuevo sí ni escribí otro comprobante.
- **Puerto:** el 8787 y el 8788 estaban ocupados por otros servidores. Sus listas de productos no coinciden con esta carpeta, así que no eran el nuestro. Usé el 8791 y comprobé que `/estado.json` muestra los 13 proyectos y los 6 productos de `reportes/`.
- **Qué muestra:** la portada con sus secciones, `/pmo`, `/decisiones`, `/proyectos`, `/productos` y `/corridas`. El nombre de la organización sale como «Portafolio de proyectos». No hay peticiones abiertas.
- **Qué no hace:** no calcula, no escribe fichas, no autentica y no manda correos. El formulario solo deja peticiones en `estado/peticiones/`.
- **Registro:** guardé lo mostrado en `estado/corridas/salida-portfolio-server.md` y registré la corrida como `2026-10-16-portfolio-server-1`. La nota de la corrida dice «puerto 8787»; el puerto real fue el 8791. Corrí el registro antes de saber qué puerto quedaría libre, y la nota quedó así.
- **Enlace:** `127.0.0.1` solo sirve en este equipo, así que no se lo puedes pasar al patrocinador. El informe es de hoy y queda desactualizado si cambia algún documento. Entonces hay que volver a correr `/portfolio-report html`.
- **Para un enlace estable:** el paso siguiente es «que quede corriendo» con `--abierto`. Eso exige pedirle a la organización un host, un puerto y su control de acceso, porque el servidor no autentica.

El servidor sigue en segundo plano. Se apaga terminando el proceso `servidor.py` del puerto 8791; el registro está en `/tmp/claude-0/rostrum.log`.
