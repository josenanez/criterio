# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2025-09-03
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 268.427 | Caso de negocio, 2025-09-03 |

## Retorno esperado

Retorno esperado en 24 meses.
