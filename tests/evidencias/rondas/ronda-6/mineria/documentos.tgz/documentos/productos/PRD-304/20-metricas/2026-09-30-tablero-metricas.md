# Tablero de métricas · Trazabilidad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 140.240 | 2026-09-30 |
