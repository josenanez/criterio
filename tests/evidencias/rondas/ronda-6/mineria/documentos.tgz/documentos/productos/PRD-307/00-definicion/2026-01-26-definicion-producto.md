# Definición de producto · Reporte ambiental

**Código:** PRD-307
**Gerente de producto:** Andrés Lozano
**Segmento:** Supervisores
**Fecha de la definición:** 2026-01-26

## El problema

El segmento Supervisores no tiene reporte ambiental.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-04-01 · verificado

## Proyectos que lo construyen

- Ninguno declarado
