# Tablero de métricas · Inspección con drones

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-03

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 129.370 | 2026-10-03 |
