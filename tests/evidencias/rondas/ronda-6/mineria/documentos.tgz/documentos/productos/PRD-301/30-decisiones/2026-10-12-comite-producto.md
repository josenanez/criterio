# Comité de producto · Alerta de taludes

**Fecha:** 2026-10-12
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Sandra Gil | se verifica en producción | — | aceptado | 2026-05-16 | — |
| REQ-4101 | Requerimiento REQ-4101 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-03 | — |
| REQ-4102 | Requerimiento REQ-4102 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-05-31 | — |
| REQ-4103 | Requerimiento REQ-4103 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-12 | — |
| REQ-4104 | Requerimiento REQ-4104 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-07-27 | — |
| REQ-4105 | Requerimiento REQ-4105 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-04-29 | — |
| REQ-4106 | Requerimiento REQ-4106 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4107 | Requerimiento REQ-4107 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4108 | Requerimiento REQ-4108 | sin asignar | se verifica en producción | — | aceptado | 2026-08-26 | — |
| REQ-4109 | Requerimiento REQ-4109 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-08 | — |
| REQ-4110 | Requerimiento REQ-4110 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4111 | Requerimiento REQ-4111 | Rubén Cárdenas | se verifica en producción | — | propuesto | 2026-05-02 | — |
| REQ-4112 | Requerimiento REQ-4112 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4113 | Requerimiento REQ-4113 | sin asignar | se verifica en producción | — | aceptado | 2026-06-12 | — |

## Decisiones

- Se mantiene el plan
