# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4801 | Requerimiento REQ-4801 | Ricardo Salas | se verifica en producción | — | propuesto | 2026-08-14 | — |
| REQ-4802 | Requerimiento REQ-4802 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4803 | Requerimiento REQ-4803 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-08-07 | — |
| REQ-4804 | Requerimiento REQ-4804 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-07-01 | — |
| REQ-4805 | Requerimiento REQ-4805 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-04-09 | — |
| REQ-4806 | Requerimiento REQ-4806 | Andrés Lozano | — | — | aceptado | 2026-08-24 | — |
| REQ-4807 | Requerimiento REQ-4807 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-23 | — |
| REQ-4808 | Requerimiento REQ-4808 | Jorge Medina | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-22 | — |
| REQ-4809 | Requerimiento REQ-4809 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-18 | — |
| REQ-4810 | Requerimiento REQ-4810 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-04-09 | — |
| REQ-4811 | Requerimiento REQ-4811 | sin asignar | se verifica en producción | — | aceptado | 2026-08-11 | — |
| REQ-2026 | Requerimiento REQ-2026 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-09-19 | — |

## Decisiones

- Se mantiene el plan
