# Comité de producto · Inspección con drones

**Fecha:** 2026-10-08
**Asistentes:** Ricardo Salas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-06-18 | — |
| REQ-4901 | Requerimiento REQ-4901 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-07-01 | — |
| REQ-4902 | Requerimiento REQ-4902 | sin asignar | — | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4903 | Requerimiento REQ-4903 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4904 | Requerimiento REQ-4904 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4905 | Requerimiento REQ-4905 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-10 | — |
| REQ-4906 | Requerimiento REQ-4906 | María Restrepo | se verifica en producción | — | aceptado | 2026-05-13 | — |
| REQ-4907 | Requerimiento REQ-4907 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-20 | — |
| REQ-4908 | Requerimiento REQ-4908 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4909 | Requerimiento REQ-4909 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-14 | — |
| REQ-4910 | Requerimiento REQ-4910 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4911 | Requerimiento REQ-4911 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4912 | Requerimiento REQ-4912 | Camilo Beltrán | — | Cliente entrevistado | propuesto | 2026-06-24 | — |
| REQ-4913 | Requerimiento REQ-4913 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-07-09 | — |
| REQ-4914 | Requerimiento REQ-4914 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-25 | — |
| REQ-4915 | Requerimiento REQ-4915 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-12 | — |
| REQ-2030 | Requerimiento REQ-2030 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-09-19 | — |

## Decisiones

- Se mantiene el plan
