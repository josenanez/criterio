# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2025-09-23
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 50.292 | Caso de negocio, 2025-09-23 |

## Retorno esperado

Retorno esperado en 24 meses.
