# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Natalia Ospina
**Segmento:** Mantenimiento
**Fecha de la definición:** 2026-01-31

## El problema

El segmento Mantenimiento no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La red de la mina soporta el volumen** · declarado el 2026-03-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
