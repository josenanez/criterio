# Tablero de métricas · Permisos de trabajo digitales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 62.934 | 2026-10-10 |
