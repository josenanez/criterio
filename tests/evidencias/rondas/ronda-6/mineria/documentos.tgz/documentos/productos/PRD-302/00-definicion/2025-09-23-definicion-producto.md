# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Felipe Arango
**Segmento:** Mantenimiento
**Fecha de la definición:** 2025-09-23

## El problema

El segmento Mantenimiento no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-09-26 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
