# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Ricardo Salas
**Segmento:** Gerencia
**Fecha de la definición:** 2026-05-31

## El problema

El segmento Gerencia no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-07-12 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
