# Tablero de métricas · Alerta de fatiga

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 68.852 | 2026-10-12 |
