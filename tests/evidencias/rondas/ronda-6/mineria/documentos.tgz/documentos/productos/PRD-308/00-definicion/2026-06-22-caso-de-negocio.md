# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-06-22
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 60.307 | Caso de negocio, 2026-06-22 |

## Retorno esperado

Retorno esperado en 24 meses.
