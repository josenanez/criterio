# Comité de producto · Despacho de flota

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4201 | Requerimiento REQ-4201 | Sandra Gil | se verifica en producción | — | aceptado | 2026-03-20 | — |
| REQ-4202 | Requerimiento REQ-4202 | sin asignar | — | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-4203 | Requerimiento REQ-4203 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4204 | Requerimiento REQ-4204 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-03-26 | — |
| REQ-4205 | Requerimiento REQ-4205 | Paula Céspedes | — | — | aceptado | 2026-08-10 | — |
| REQ-4206 | Requerimiento REQ-4206 | Sandra Gil | — | — | propuesto | 2026-04-20 | — |
| REQ-4207 | Requerimiento REQ-4207 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-10 | — |
| REQ-4208 | Requerimiento REQ-4208 | Laura Vélez | se verifica en producción | — | propuesto | 2026-05-31 | — |
| REQ-4209 | Requerimiento REQ-4209 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4210 | Requerimiento REQ-4210 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-13 | — |
| REQ-4211 | Requerimiento REQ-4211 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-01 | — |
| REQ-4212 | Requerimiento REQ-4212 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-23 | — |
| REQ-4213 | Requerimiento REQ-4213 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-17 | — |

## Decisiones

- Se mantiene el plan
