# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-06-01
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 169.380 | Caso de negocio, 2026-06-01 |

## Retorno esperado

Retorno esperado en 24 meses.
