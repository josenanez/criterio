# Tablero de métricas · Gemelo digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-16

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 126.138 | 2026-10-16 |
