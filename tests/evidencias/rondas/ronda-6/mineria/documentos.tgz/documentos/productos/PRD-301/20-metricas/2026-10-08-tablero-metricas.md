# Tablero de métricas · Alerta de taludes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 106.047 | 2026-10-08 |
