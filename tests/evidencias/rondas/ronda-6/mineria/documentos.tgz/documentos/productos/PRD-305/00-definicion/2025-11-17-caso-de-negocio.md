# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-11-17
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 74.748 | Caso de negocio, 2025-11-17 |

## Retorno esperado

Retorno esperado en 24 meses.
