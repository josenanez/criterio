# Caso de negocio · Almacén de repuestos

**Código:** PRD-306
**Fecha:** 2025-12-06
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 196.196 | Caso de negocio, 2025-12-06 |

## Retorno esperado

Retorno esperado en 24 meses.
