# Tablero de métricas · Despacho de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 41.118 | 2026-10-01 |
