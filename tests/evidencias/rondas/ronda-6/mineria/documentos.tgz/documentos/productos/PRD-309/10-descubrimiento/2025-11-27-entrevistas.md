# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2025-11-27
**Realizadas por:** Ricardo Salas

### Cliente entrevistado · 2025-11-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
