# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-05-31
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 195.120 | Caso de negocio, 2026-05-31 |

## Retorno esperado

Retorno esperado en 24 meses.
