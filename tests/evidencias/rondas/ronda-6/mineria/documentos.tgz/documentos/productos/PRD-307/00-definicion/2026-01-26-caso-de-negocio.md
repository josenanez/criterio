# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-01-26
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 85.668 | Caso de negocio, 2026-01-26 |

## Retorno esperado

Retorno esperado en 24 meses.
