# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-09-18
**Asistentes:** Andrés Lozano, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Laura Vélez, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-10-28 |
| Laura Vélez | Cerrar la prueba 2 | 2026-10-30 |
| Gustavo Neira | Revisar el anexo 3 | 2026-09-25 |
| Felipe Arango | Validar el ambiente 4 | 2026-09-25 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-10-14 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 |
| Elena Duarte | Entregar el punto 8 | 2026-10-16 |
| Andrés Lozano | Enviar el documento 9 | 2026-09-25 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-23 |
| Rubén Cárdenas | Revisar el anexo 11 | 2026-09-30 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 |
