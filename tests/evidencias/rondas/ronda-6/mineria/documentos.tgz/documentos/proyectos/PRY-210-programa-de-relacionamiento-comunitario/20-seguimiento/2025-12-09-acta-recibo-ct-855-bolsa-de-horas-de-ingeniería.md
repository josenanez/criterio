# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha de recibo:** 2025-12-09
**Recibido por:** Natalia Ospina

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-855 · Ingeniería Minera del Sur S.A.S..
