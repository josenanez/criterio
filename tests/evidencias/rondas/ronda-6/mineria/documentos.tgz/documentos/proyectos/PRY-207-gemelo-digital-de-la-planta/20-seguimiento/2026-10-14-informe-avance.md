# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **87%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 11.117.330.735 |
| Ejecutado | 5.640.512.961 |
| Proyección al cierre | 18.154.854.182 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
