# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Electrificación de equipos
**Fecha:** 2026-10-12
**Solicitante:** Diana Molina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +93 días sobre la línea base vigente |
| Costo | 186.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
