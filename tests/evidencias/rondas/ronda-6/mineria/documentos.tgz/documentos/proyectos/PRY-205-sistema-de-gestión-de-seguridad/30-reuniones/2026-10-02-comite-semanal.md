# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-27 |
| Laura Vélez | Cerrar la prueba 2 | 2026-11-26 |
| Gustavo Neira | Revisar el anexo 3 | 2026-10-03 |
| Felipe Arango | Validar el ambiente 4 | 2026-10-18 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 |
| Andrés Lozano | Enviar el documento 9 | 2026-09-25 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 |
| Camilo Beltrán | Entregar el punto 16 | 2026-10-18 |
| Liliana Torres | Enviar el documento 17 | 2026-10-21 |
| Carlos Peña | Cerrar la prueba 18 | por definir |
| Diana Molina | Revisar el anexo 19 | 2026-10-14 |
| Carlos Peña | Validar el ambiente 20 | 2026-10-24 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Gustavo Neira): recibido, acta de recibo del 2026-10-02.

## Lo que se dijo

- Ricardo Salas dice que ya entregó «actualizar la matriz 14». No se presentó acta.
