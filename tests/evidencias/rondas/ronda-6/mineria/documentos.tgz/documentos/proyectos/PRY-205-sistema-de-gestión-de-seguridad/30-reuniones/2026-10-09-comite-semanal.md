# Comité Ambiental · Sistema de gestión de seguridad

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-06 |
| Laura Vélez | Cerrar la prueba 2 | 2026-12-13 |
| Gustavo Neira | Revisar el anexo 3 | 2026-10-03 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-28 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-02 |
| Andrés Lozano | Enviar el documento 9 | 2026-10-26 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-12 |
| Sandra Gil | Confirmar la fecha 15 | 2026-10-07 |
| Liliana Torres | Enviar el documento 17 | 2026-10-29 |
| Carlos Peña | Cerrar la prueba 18 | por definir |
| Diana Molina | Revisar el anexo 19 | 2026-10-14 |
| Carlos Peña | Validar el ambiente 20 | 2026-10-24 |
| Andrés Lozano | Aprobar el diseño 21 | 2026-11-06 |
| Rubén Cárdenas | Actualizar la matriz 22 | por definir |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-26 |
| Carlos Peña | Entregar el punto 24 | 2026-11-02 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Felipe Arango): recibido, acta de recibo del 2026-10-09.
- Entregar el punto 16 (Camilo Beltrán): recibido, acta de recibo del 2026-10-09.
