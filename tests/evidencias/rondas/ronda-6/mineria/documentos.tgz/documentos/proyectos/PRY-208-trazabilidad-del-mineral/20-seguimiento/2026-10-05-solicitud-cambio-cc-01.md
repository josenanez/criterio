# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-05
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +25 días sobre la línea base vigente |
| Costo | 50.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
