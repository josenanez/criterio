# Comité de Inversiones · Ampliación de la relavera

**Fecha:** 2026-10-08
**Asistentes:** Óscar Ramírez, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 36 | 2026-10-28 |
