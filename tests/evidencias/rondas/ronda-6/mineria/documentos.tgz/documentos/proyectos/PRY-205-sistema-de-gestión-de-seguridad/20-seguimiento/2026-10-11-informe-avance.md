# Informe de avance · Sistema de gestión de seguridad

**Código:** PRY-205
**Fecha de corte:** 2026-10-11
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **58%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 324.133.771 |
| Ejecutado | 258.170.381 |
| Proyección al cierre | 765.512.063 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
