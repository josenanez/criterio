# Acta de constitución · Programa de relacionamiento comunitario

**Código:** PRY-210
**Área dueña:** Tecnología
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-07

## Objetivo del negocio

Entregar programa de relacionamiento comunitario para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Tecnología el 2025-07-07.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-17 |
| Cierre | 2026-05-22 |

## Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

## Dependencias declaradas

- Ninguna declarada
