# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Tecnología
**Patrocinador:** Paula Céspedes
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-03

## Objetivo del negocio

Entregar planta de tratamiento de agua para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Inversiones el 2025-09-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-13 |
| Cierre | 2026-07-02 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
