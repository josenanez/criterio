# Comité de Operaciones · Despacho automático de flota

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 37 | 2026-10-01 |
