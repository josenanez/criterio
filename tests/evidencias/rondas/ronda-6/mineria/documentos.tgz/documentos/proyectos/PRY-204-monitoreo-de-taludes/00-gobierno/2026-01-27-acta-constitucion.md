# Acta de constitución · Monitoreo de taludes

**Código:** PRY-204
**Área dueña:** Seguridad y Salud
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Tecnología
**Producto asociado:** alerta de taludes
**Fecha de aprobación:** 2026-01-27

## Objetivo del negocio

Entregar monitoreo de taludes para Seguridad y Salud.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Tecnología el 2026-01-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-06 |
| Cierre | 2026-10-12 |

## Criterio de éxito

Monitoreo de taludes en producción y medido.

## Dependencias declaradas

- Ninguna declarada
