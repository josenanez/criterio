# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Despacho automático de flota
**Fecha:** 2026-10-07
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +120 días sobre la línea base vigente |
| Costo | 240.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
