# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-13
**Gerente:** Laura Vélez

## Estado declarado

**Amarillo**

Avance reportado: **81%**

## Lo que pasó en el periodo

- El proveedor entregó los equipos en el campamento, pendientes de aceptación

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.956.619.363 |
| Ejecutado | 1.741.956.167 |
| Proyección al cierre | 3.081.945.482 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Bloqueo de la vía de acceso a la mina
