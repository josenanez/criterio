# Acta de recibo · Licenciamiento del software

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha de recibo:** 2025-10-10
**Recibido por:** Natalia Ospina

Se recibe a satisfacción el entregable **Licenciamiento del software**.

Contrato CT-855 · Ingeniería Minera del Sur S.A.S..
