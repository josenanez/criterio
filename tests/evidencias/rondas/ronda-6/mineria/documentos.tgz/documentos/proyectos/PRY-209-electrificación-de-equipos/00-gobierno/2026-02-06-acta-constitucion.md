# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Tecnología
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-06

## Objetivo del negocio

Entregar electrificación de equipos para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-16 |
| Cierre | 2027-01-19 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
