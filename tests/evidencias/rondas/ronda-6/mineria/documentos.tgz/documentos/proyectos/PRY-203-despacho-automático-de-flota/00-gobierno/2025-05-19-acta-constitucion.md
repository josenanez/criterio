# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Geología
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Operaciones
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-05-19

## Objetivo del negocio

Entregar despacho automático de flota para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Operaciones el 2025-05-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-29 |
| Cierre | 2026-01-21 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
