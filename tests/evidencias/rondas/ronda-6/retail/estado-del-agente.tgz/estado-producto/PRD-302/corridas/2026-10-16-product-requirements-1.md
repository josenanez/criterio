# Corrida del 2026-10-16 · product-requirements

PRD-302 · 15 requerimientos · 12 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

4 aceptados sin evidencia (2028, 4203, 4207, 4209); 12 aceptados sin proyecto; 3 propuestos sin decidir

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Registro — Autopago en tienda (PRD-302) · al 2026-10-16
15 requerimientos · 12 decididos · 66,7% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado | Natalia Ospina |
| REQ-4203 | Requerimiento REQ-4203 | aceptado | Andrés Lozano |
| REQ-4207 | Requerimiento REQ-4207 | aceptado | sin doliente |
| REQ-4209 | Requerimiento REQ-4209 | aceptado | sin doliente |

### Decidido y nadie lo está construyendo
Los 12 aceptados, ninguno con proyecto: REQ-2028, 4200, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4210, 4211, 4212. Todos figuran decididos el 2026-10-10. Ofrezco /product-trace.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4207 | Requerimiento REQ-4207 | (vacío) |
| REQ-4209 | Requerimiento REQ-4209 | (vacío) |

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4204 | Requerimiento REQ-4204 | aceptado |
| REQ-4208 | Requerimiento REQ-4208 | aceptado |
| REQ-4210 | Requerimiento REQ-4210 | aceptado |
(REQ-4213 también carece de criterio, pero está propuesto: no es hallazgo.)

### Decidido sin documento que lo respalde
El cálculo no mide esta señal; no la afirmo.

### Lleva meses y nadie lo decide
Umbral: 60 días. Tiene la facultad: Comité de producto (según la configuración).
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4201 | Requerimiento REQ-4201 | 135 días (2026-06-03) | Comité de producto |
| REQ-4206 | Requerimiento REQ-4206 | 130 días (2026-06-08) | Comité de producto |
| REQ-4213 | Requerimiento REQ-4213 | 125 días (2026-06-13) | Comité de producto |

### Evidencia vieja
Sin hallazgo: lo más nuevo es del 2026-05-28 (141 días), por debajo del umbral de 12 meses.

### Fuera del registro (definición)
- Supuesto sin verificar hace 57 días: «La regulación de datos lo permite» (umbral 30). Quién lo verificaría: no consta en el cálculo.
- La definición no declara criterio de éxito.
- Cifra declarada vs medida (volumen mensual): 107.018 vs 107.348, brecha 0,3%; sin hallazgo.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 12 | 0 | 0 | 0 |

Cierre: cada vacío lo cierra su doliente; sin doliente (4207, 4209), lo asigna Elena Duarte, gerente del producto. Nada se cierra por viejo: se propone decidir.
