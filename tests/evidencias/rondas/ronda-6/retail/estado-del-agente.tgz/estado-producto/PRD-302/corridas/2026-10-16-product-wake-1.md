# Corrida del 2026-10-16 · product-wake

PRD-302 · 15 requerimientos · 32 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

Primera revisión sin corte anterior: reportó estado de partida (3 propuestos sin decidir, 1 supuesto sin verificar, aceptados sin respaldo, 0 trazas). No hizo document-intake, así que no dice si hay documentos nuevos.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Autopago en tienda (PRD-302) · 2026-10-16

**Primera revisión registrada: no hay corte anterior, así que `crossed` no existe todavía.** Lo que sigue es el estado de partida. Desde la próxima corrida solo se reporta lo que cambie.

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). No se pidió una aceptación nueva.

**Registro:** 15 requerimientos (12 aceptados, 3 propuestos). 8 tienen evidencia (66,7 %). 0 están trazados a un proyecto (0 %).

### Lo que necesita decisión en el comité (umbral: 60 días sin decidir)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4201 | 135 días (desde 2026-06-03) | Decidir si se acepta o se descarta | Comité de producto. Doliente: Beatriz Cuéllar |
| Propuesto sin decidir | REQ-4206 | 130 días (desde 2026-06-08) | Ídem | Comité de producto. Doliente: Camilo Beltrán |
| Propuesto sin decidir | REQ-4213 | 125 días (desde 2026-06-13) | Ídem. Además no tiene criterio de aceptación | Comité de producto. Doliente: Javier Hoyos |

Quien tiene la facultad de decidirlos es el Comité de producto. Ofrezco llevarlos al próximo comité.

### Supuesto sin verificar
- **"La regulación de datos lo permite":** 57 días sin verificar, y el umbral es 30. Para verificarlo hace falta un concepto jurídico o de cumplimiento sobre el tratamiento de datos que implica el autopago. Ya pasó el punto en que conviene tratarlo como riesgo registrado. Aplica assumption-tracking.

### Aceptados sin respaldo (se detectan por las alertas del registro)
- **Sin evidencia de demanda:** REQ-2028, REQ-4203, REQ-4207, REQ-4209.
- **Sin criterio de aceptación:** REQ-4204, REQ-4208, REQ-4210.
- **Sin doliente:** REQ-4207, REQ-4209. Estos dos también están sin evidencia, y es el caso más débil del registro.
- **Aceptados que nadie construye:** los 12 aceptados están sin proyecto. Todos se decidieron el 2026-10-10.

### Las trazas
Tengo la carpeta de fichas (13 fichas en `estado/records`). Ninguna nombra PRD-302 ni "Autopago". Por eso ninguna traza queda confirmada, y no hay ninguna que se haya roto, porque no había ninguna declarada.

### Definición y descubrimiento
- Cifra del caso de negocio contra datos: volumen mensual declarado 107.018, medido 107.348 el 2026-10-11. Diferencia de 0,3 %, dentro del umbral de 20 %.
- La definición no trae criterio de éxito, y eso queda declarado como desconocido.
- No hice la comparación de documentos contra lo ya leído (document-intake), así que no puedo decir si alguno es nuevo. Solo listé la carpeta. Los documentos que hay son la definición y el caso de negocio (2025-10-25), las entrevistas (2026-05-28), la decisión del comité (2026-10-10) y el tablero de métricas (2026-10-11).

**Vuelvo el 2026-11-15.**
