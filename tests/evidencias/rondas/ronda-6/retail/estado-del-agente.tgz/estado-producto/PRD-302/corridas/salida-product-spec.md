> **Borrador** de especificación, escrito por el agente. Lo cierra Elena Duarte, gerente de producto; la aprobación es del Comité de producto. Este agente no firma.

# Especificación — Autopago en tienda (PRD-302) · borrador del 2026-10-16

## Qué problema resuelve
«El segmento Pequeños negocios no tiene autopago en tienda.» (definición de producto, 2025-10-25). La definición no dice qué debe hacer el autopago: su «propuesta» es el texto «Propuesta principal». No declara criterio de éxito.

## Alcance
Del registro salen 12 requerimientos aceptados (REQ-2028, 4200, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4210, 4211, 4212) y 3 propuestos (REQ-4201, 4206, 4213). Ninguno dice qué necesita: en los 15 el campo «necesidad» no consta, y el título es solo el código («Requerimiento REQ-xxxx»).

### Entra
Nada se puede enunciar como comportamiento. Los 12 aceptados son lo que el registro propone que entre, pero no hay texto de requerimiento del que redactar una sección. Escribir el comportamiento sería inventarlo.

### No entra
- REQ-4201, REQ-4206 y REQ-4213: propuestos hace 135, 130 y 125 días, sin decisión del Comité de producto. No se especifican hasta que se decidan.
- Todo lo que ningún documento pidió. No se agrega nada por ser «lo razonable» en un autopago (cobro, medios de pago, conexión, devoluciones): ningún documento lo menciona.

## Comportamiento
Sin secciones. Ningún requerimiento aceptado tiene necesidad enunciada, así que ninguna sección tendría de qué citar. Ver la tabla del final.

## Criterios de aceptación
El único criterio que existe en el registro es el mismo para todos: «se verifica en producción» (acta del comité, 2026-10-10). Dos personas mirando lo construido no llegarían a la misma respuesta, porque no dice qué se verifica ni con qué umbral. No sirve como criterio.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-2028, 4200, 4202, 4203, 4205, 4207, 4209, 4211, 4212 | No consta: no dice qué se observa ni qué valor cuenta como cumplido | No: no es verificable todavía |
| Sin criterio | REQ-4204, 4208, 4210 | — | No: no existe |

Lo único medido hoy es `volumen_mensual` (107.348 al 2026-10-11, tablero de producto). Ningún criterio lo usa. No propongo umbrales: no hay documento del que salgan.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La regulación de datos lo permite» (declarado 2026-08-20) | No. La definición dice «verificado» pero no cita con qué; sin cita no cuenta. Lleva 57 días sin verificar (umbral 30) | No consta |
| Que el volumen mensual de 107.018 declarado en el caso de negocio sostiene el producto | Sí contra el tablero: 107.348 medido, brecha 0,3% | No aplica |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada uno de los 12 aceptados (el campo «necesidad» no consta en ninguno) | No se puede escribir comportamiento ni criterio; el equipo construiría lo que interprete | Cada doliente; Elena Duarte para REQ-4207 y 4209 |
| Criterio de aceptación de REQ-4204, 4208, 4210 | Se aceptó algo sin forma de saber si quedó bien | Beatriz Cuéllar, Paula Céspedes, María Restrepo |
| Reemplazar «se verifica en producción» por un criterio medible en los otros 9 | La discusión de si quedó bien se tiene después de construirlo | Cada doliente, con Elena Duarte |
| Doliente de REQ-4207 y REQ-4209 | Nadie responde por ellos | Elena Duarte |
| Quién pidió REQ-2028 y REQ-4203, REQ-4207, REQ-4209 (el acta pone «—») | Se construye algo que ningún documento sustenta | Doliente; Elena Duarte en 4207 y 4209 |
| Casos borde (sin conexión, pago duplicado, cliente que se va antes de la confirmación): ningún documento los toca | Quedan decididos por quien construya | Gerente de producto, con los dolientes. No los defino yo |
| Criterio de éxito del producto (la definición no lo declara) | Sin vara para decir que el autopago funcionó | Elena Duarte; decide el Comité de producto |
| Obligaciones normativas: el supuesto de regulación de datos no está verificado y no hay barrido citado de qué obligaciones toca un autopago | Se podría construir algo que la norma no permite | Elena Duarte (sin responsable de cumplimiento nombrado en los documentos) |
| Lo que otros equipos deben hacer: ningún documento nombra equipos, proyectos ni dependencias | No hay acuerdo con nadie; ningún proyecto ejecuta los requerimientos (ficha: 0%) | Elena Duarte; ofrezco `/product-trace` |
| Evidencia: las entrevistas (2026-05-28) tienen una sola cita, «Lo necesito y hoy no lo tengo», que no nombra ningún requerimiento; el acta le atribuye a ese cliente la petición de 8 de los 12 aceptados | Una cita genérica respalda requerimientos distintos | Elena Duarte (hizo las entrevistas) |

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | Necesidad no consta; nadie lo pidió según el acta |
| REQ-4200 | Requerimiento REQ-4200 | Necesidad no consta |
| REQ-4202 | Requerimiento REQ-4202 | Necesidad no consta |
| REQ-4203 | Requerimiento REQ-4203 | Necesidad no consta; nadie lo pidió |
| REQ-4204 | Requerimiento REQ-4204 | Necesidad no consta; sin criterio de aceptación |
| REQ-4205 | Requerimiento REQ-4205 | Necesidad no consta |
| REQ-4207 | Requerimiento REQ-4207 | Necesidad no consta; sin doliente; nadie lo pidió |
| REQ-4208 | Requerimiento REQ-4208 | Necesidad no consta; sin criterio de aceptación |
| REQ-4209 | Requerimiento REQ-4209 | Necesidad no consta; sin doliente; nadie lo pidió |
| REQ-4210 | Requerimiento REQ-4210 | Necesidad no consta; sin criterio de aceptación |
| REQ-4211 | Requerimiento REQ-4211 | Necesidad no consta |
| REQ-4212 | Requerimiento REQ-4212 | Necesidad no consta |

Cubiertos: 0 de 12.

## Después
No ofrezco `/product-charter`: los vacíos no están cerrados y la definición no tiene criterio de éxito. Cerrados los de necesidad y criterio de aceptación, se vuelve a correr este comando.

---
Sale del registro de requerimientos de PRD-302 (`estado-producto/PRD-302/requirements`, 15 fichas), actualizado el 2026-10-16; acta del comité del 2026-10-10. Cubre 0 de 12 requerimientos aceptados. Términos aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
