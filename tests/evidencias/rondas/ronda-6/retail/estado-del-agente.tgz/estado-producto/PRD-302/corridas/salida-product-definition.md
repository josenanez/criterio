## Definición — Autopago en tienda (PRD-302) · contrastada al 2026-10-16
**Documento:** 00-definicion/2025-10-25-definicion-producto.md y 2025-10-25-caso-de-negocio.md · **del** 2025-10-25 · 5 afirmaciones

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 107.018 | 107.348 | 0,3 % (umbral 20 %: no pasa, es imprecisión, no contradicción) | Caso de negocio, 2025-10-25 · tablero de métricas (bodega de datos), corte 2026-10-11 |

Solo hay un punto en la serie medida: el contraste es contra una sola medición.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | caso-de-negocio, 2025-10-25 | No trae cifra ni serie que la mida; no se puede contrastar. |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo declara.
- **Quién decide:** la autoridad es «Comité de producto» (acta 2026-10-10, asiste solo Elena Duarte); ningún documento nombra a una persona.
- **La propuesta:** la sección dice solo «Propuesta principal»; no hay propuesta escrita que contrastar.
- **Por qué «Pequeños negocios» no tiene autopago:** el problema se afirma, no se sustenta con dato de mercado ni de uso.
- **Cuánto pagaría o qué haría el cliente:** no hay evidencia de pago ni de compromiso.
- **Proyectos que lo construyen:** «Ninguno declarado»; ninguno de los 12 requerimientos aceptados tiene proyecto.
- **El retorno:** ni monto, ni base, ni supuestos.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La regulación de datos lo permite» | 57 (declarado 2026-08-20; umbral 30) | El documento dice «verificado» pero no cita con qué, así que no cuenta como verificado. Haría falta el concepto o la revisión jurídica con su fecha, y la norma citada. Además, «lo permite» no dice qué norma ni qué tratamiento de datos; hay que acotarlo para que se pueda verificar. Nota: el supuesto se declara el 2026-08-20 dentro de un documento fechado 2025-10-25. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe una necesidad de autopago | Entrevista a un cliente: «Lo necesito y hoy no lo tengo» | 2026-05-28 | Débil: una sola voz declarada, sin pago ni compromiso, sin decir si es de «Pequeños negocios». |
| volumen_mensual ≈ 107.018 | Tablero de métricas | 2026-10-11 | Medida, concuerda (0,3 %). Es una sola medición. |

### Evidencia que ya envejeció
Nada pasa el umbral de 12 meses. Lo más antiguo que sostiene algo es la entrevista del 2026-05-28 (141 días).

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales del cliente en el autopago (la definición misma asume «regulación de datos»); posible tratamiento de datos de pago | No declarado en la configuración | Base legal del tratamiento, autorización y seguridad de datos personales; si hay pagos, la regulación de pagos y de consumidor financiero | No tengo la norma a la vista | No tengo la norma a la vista. Esto va a revisión jurídica; no dice si cumple. |

### Lo que falta para cerrar la definición
- **Criterio de éxito** (sin él el producto no se puede cerrar).
- **Quién decide** (una persona, no un comité).
- El problema y para quién sí están escritos (Pequeños negocios), pero sin sustento más allá de una entrevista.

### Adicional que la corrida vio en el registro
15 requerimientos: 12 aceptados, 3 propuestos. Sin evidencia: 4 aceptados (REQ-2028, 4203, 4207, 4209). Sin doliente: 2 (REQ-4207, 4209). Sin criterio de aceptación: 3 (REQ-4204, 4208, 4210). Sin proyecto: los 12 aceptados. Sin decidir hace más de 60 días: 3 (REQ-4201, 4206, 4213).

**Después:** el supuesto regulatorio lleva 57 días sin verificarse; conviene convertirlo en riesgo con doliente (raid-taxonomy). La definición no está cerrada, así que no se ofrece `/product-charter`.
