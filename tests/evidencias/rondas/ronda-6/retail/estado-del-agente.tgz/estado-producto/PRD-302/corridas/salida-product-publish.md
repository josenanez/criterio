No publiqué la ficha de PRD-302 (Autopago en tienda): no hay carpeta de productos publicados. La configuración (`.criterio/producto/PRD-302/config.json`) no define ninguna y no existe una `productos/publicados` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ni inventé la carpeta.

**Lo que habría llevado la ficha (corte 2026-10-16):**
- 15 requerimientos (12 aceptados, 3 propuestos) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Pequeños negocios
- Métrica: volumen_mensual, declarado 107018.0 (documentos/productos/PRD-302/00-definicion/2025-10-25-caso-de-negocio.md, 2025-10-25)

**Para que la ficha publicada no engañe:** ningún requerimiento tiene proyecto asignado (0 de 15 con traza), así que el cruce por proyecto compartido no encontraría nada.

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hizo falta registrarlos de nuevo.
