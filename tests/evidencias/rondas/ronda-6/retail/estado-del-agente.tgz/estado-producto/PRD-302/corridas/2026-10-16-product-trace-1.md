# Corrida del 2026-10-16 · product-trace

PRD-302 · 15 requerimientos · 34 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `assumption_unverified` | 1 |

12 requerimientos decididos el 2026-10-10 sin proyecto; PRY-204 dice ejecutar autopago en tienda y ningún REQ lo nombra

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Autopago en tienda (PRD-302) · al 2026-10-16
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Hay 13 fichas a la vista (`estado/records`, PRY-199 a PRY-211). Ningún requerimiento del registro nombra un proyecto, así que no hay traza que confirmar contra ninguna ficha.

### Decidido y nadie lo está construyendo
Los 12 aceptados en el comité de producto del 2026-10-10 (`documentos/productos/PRD-302/30-decisiones/2026-10-10-comite-producto.docx`). El acta no deja registrado quién decidió cada uno (`decision.who` vacío en los 12).

| REQ | Título | Decidido el | Por quién | Dueño | Nota |
|---|---|---|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | 2026-10-10 | no registrado | Natalia Ospina | sin evidencia de demanda |
| REQ-4200 | Requerimiento REQ-4200 | 2026-10-10 | no registrado | Mauricio Pérez | |
| REQ-4202 | Requerimiento REQ-4202 | 2026-10-10 | no registrado | Laura Vélez | |
| REQ-4203 | Requerimiento REQ-4203 | 2026-10-10 | no registrado | Andrés Lozano | sin evidencia de demanda |
| REQ-4204 | Requerimiento REQ-4204 | 2026-10-10 | no registrado | Beatriz Cuéllar | sin criterio de aceptación |
| REQ-4205 | Requerimiento REQ-4205 | 2026-10-10 | no registrado | Elena Duarte | |
| REQ-4207 | Requerimiento REQ-4207 | 2026-10-10 | no registrado | sin dueño | sin dueño y sin evidencia de demanda |
| REQ-4208 | Requerimiento REQ-4208 | 2026-10-10 | no registrado | Paula Céspedes | sin criterio de aceptación |
| REQ-4209 | Requerimiento REQ-4209 | 2026-10-10 | no registrado | sin dueño | sin dueño y sin evidencia de demanda |
| REQ-4210 | Requerimiento REQ-4210 | 2026-10-10 | no registrado | María Restrepo | sin criterio de aceptación |
| REQ-4211 | Requerimiento REQ-4211 | 2026-10-10 | no registrado | Jorge Medina | |
| REQ-4212 | Requerimiento REQ-4212 | 2026-10-10 | no registrado | Andrés Lozano | |

Los 3 propuestos (REQ-4201, REQ-4206, REQ-4213) no están decididos y no cuentan aquí; llevan 125 a 135 días sin decidirse.

### La traza no se confirma
Ninguna: no hay requerimiento que diga ejecutarlo un proyecto. La cadena se rompe antes, en el eslabón decisión → proyecto.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice | Ningún REQ lo nombra |
|---|---|---|
| PRY-204 Cajas de autopago | producto «autopago en tienda» (acta de constitución del 2025-09-24, `PRY-204-cajas-de-autopago/00-gobierno/2025-09-24-acta-constitucion.md`) | Ningún REQ de PRD-302 lo nombra. La ficha lo liga por nombre, no por el código PRD-302, así que conviene confirmar que es el mismo producto. |

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2028, 4200, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4210, 4211, 4212 | aceptado | comité 2026-10-10 | — | no | — |
| REQ-4201, 4206, 4213 | propuesto | sin decisión | — | no | — |

### Sin fichas a la vista
Hay ficha de todos los proyectos que se conocen, pero 6 no dicen qué producto ejecutan (campo vacío en la ficha: PRY-202, 203, 206, 209, 210, 211). Es un hallazgo del lado de esos proyectos, y no se puede descartar que alguno construya algo de este producto. Ninguna ficha cita el código PRD-302.
