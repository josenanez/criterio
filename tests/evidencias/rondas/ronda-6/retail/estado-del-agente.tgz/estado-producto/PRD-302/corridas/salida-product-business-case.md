# Caso de negocio — Autopago en tienda (PRD-302) · borrador del 2026-10-16
**Desde:** definición y caso de negocio del 2025-10-25 · **Cifras con fuente:** 2 de 3 afirmaciones numéricas (volumen declarado, volumen medido; el «retorno esperado» no trae cifra)

No hay argumento de archivo de caso (`/product-business-case` sin parámetro): se armó desde cero con lo que existe. Este borrador no produce cifras, no calcula retorno y no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
«El segmento Pequeños negocios no tiene autopago en tienda.» (`00-definicion/2025-10-25-definicion-producto.md`, 2025-10-25). Es una afirmación; ningún documento la sustenta con dato de mercado o de uso. La propuesta dice solo «Propuesta principal»: no hay propuesta escrita.

## Qué se construye
12 requerimientos aceptados el 2026-10-10 (acta del comité, `30-decisiones/2026-10-10-comite-producto.docx`); 3 siguen propuestos y no entran al caso (REQ-4201, 4206, 4213). Los títulos del registro son genéricos («Requerimiento REQ-xxxx»): el documento no dice qué es cada uno.

| Requerimiento | Estado | Doliente | Evidencia de demanda |
|---|---|---|---|
| REQ-4200 | aceptado | Mauricio Pérez | Entrevista 2026-05-28 (ver nota) |
| REQ-4202 | aceptado | Laura Vélez | Entrevista 2026-05-28 (ver nota) |
| REQ-4204 | aceptado | Beatriz Cuéllar | Entrevista 2026-05-28 (ver nota); sin criterio de aceptación |
| REQ-4205 | aceptado | Elena Duarte | Entrevista 2026-05-28 (ver nota) |
| REQ-4208 | aceptado | Paula Céspedes | Entrevista 2026-05-28 (ver nota); sin criterio de aceptación |
| REQ-4210 | aceptado | María Restrepo | Entrevista 2026-05-28 (ver nota); sin criterio de aceptación |
| REQ-4211 | aceptado | Jorge Medina | Entrevista 2026-05-28 (ver nota) |
| REQ-4212 | aceptado | Andrés Lozano | Entrevista 2026-05-28 (ver nota) |
| REQ-2028 | aceptado | Natalia Ospina | **Ninguna** |
| REQ-4203 | aceptado | Andrés Lozano | **Ninguna** |
| REQ-4207 | aceptado | **Sin doliente** | **Ninguna** |
| REQ-4209 | aceptado | **Sin doliente** | **Ninguna** |

*Nota:* la única evidencia es «Lo necesito y hoy no lo tengo» de un cliente entrevistado. El acta le atribuye la petición, pero la entrevista no nombra ninguno de estos requerimientos ni dice si el cliente es de Pequeños negocios. Ninguno de los 12 tiene proyecto que lo construya (la definición dice «Ninguno declarado»).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 107.018 | Declarada | `00-definicion/2025-10-25-caso-de-negocio.md` (Elena Duarte) | 2025-10-25 |
| volumen_mensual | 107.348 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-11-tablero-metricas.md`) | corte 2026-10-11 |
| «Retorno esperado en 24 meses» | sin valor | Supuesta (sin cifra, sin base) | Mismo caso de negocio; no trae monto ni supuestos | 2025-10-25 |

La serie medida tiene un solo punto; no hay tendencia que contrastar.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 107.018 | 107.348 | Caso de negocio 2025-10-25 · tablero de métricas, corte 2026-10-11. Brecha 0,3 % (umbral 20 %): imprecisión, no contradicción. |

Dos cosas que conviene saber aunque las cifras coincidan: la definición del indicador no está escrita (`definition: null` en la serie), y que un producto «sin autopago» ya tenga un volumen mensual medido de 107.348 no lo explica ningún documento (qué se está contando).

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No consta** | Ningún documento |
| Costo de operar | **No consta** | Ningún documento |
| Contratos, cotizaciones, costo del equipo | **No constan** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta. Es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La regulación de datos lo permite» (declarado 2026-08-20; 57 días sin verificar, umbral 30). El documento dice «verificado» pero no cita con qué: no cuenta como verificado. | El producto o parte de sus 12 requerimientos podría no poder construirse. | No consta. Haría falta concepto o revisión jurídica con fecha y norma citada; el país no está declarado en la configuración. |
| «Retorno esperado en 24 meses» | El caso carece de justificación económica. | No consta; lo produce el negocio. |
| Que la voz de un cliente entrevistado represente la demanda de Pequeños negocios | La demanda sería menor o de otro segmento. | No consta. |

Se ofrece pasarlos a **assumption-tracking** para que tengan doliente y fecha.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | El negocio (Elena Duarte; no consta fuente) |
| Cifra y base del retorno esperado | Hoy es una frase sin número | El negocio |
| Qué es exactamente lo que cuenta `volumen_mensual` | Sin definición la brecha del 0,3 % no es interpretable | Dueño de la bodega de datos |
| Alternativas consideradas y qué pasa si no se hace | El comité no puede comparar | El negocio |
| Evidencia de demanda para REQ-2028, 4203, 4207, 4209 | Aceptados sin que nadie los pidiera | Sus dolientes; 4207 y 4209 no tienen |
| Doliente de REQ-4207 y REQ-4209 | Nadie responde por ellos | Elena Duarte asigna |
| Criterio de aceptación de REQ-4204, 4208, 4210 | No se puede verificar que se entregaron | Sus dolientes |
| Verificación citada del supuesto regulatorio | Ver arriba | Jurídica |
| Persona que decide (el acta es de un comité; asistió solo Elena Duarte) | Nadie firma el caso | Por definir |
| Proyecto que construya los 12 aceptados | Decidido y sin quién lo construya | Por definir; ver `/product-trace` |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no tiene criterio de éxito, ni métrica, ni fecha de corte. Sin esto el producto no se puede cerrar meses después, y «retorno en 24 meses» no es verificable. La única métrica medida (volumen_mensual) podría servir, pero nadie ha dicho qué valor significaría éxito.

## Si hay otros productos publicados
No hay ninguno a la vista (la carpeta de fichas `estado/records` está vacía): no se pudo cruzar si otro producto afirma las mismas transacciones. Se dice, no se asume que no hay solape.

## Después
- Pasar los supuestos a **assumption-tracking**.
- `/product-charter` no se ofrece: la definición no está cerrada (sin criterio de éxito ni persona que decida) y el costo no consta.
