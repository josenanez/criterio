## Listo — Autopago en tienda (PRD-302)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 5 documentos · 2 de descubrimiento y demanda (1 entrevista del 2026-05-28 y el tablero de métricas del 2026-10-11) · la definición y el caso de negocio, ambos del 2025-10-25 · el acta del comité de producto del 2026-10-10 · lo más reciente es del 2026-10-11. Los 5 se pudieron leer (.md y .docx). Sin material de descubrimiento abundante: hay una sola entrevista, con una sola cita.
**Términos:** aceptados para la versión 0.3.12 (términos 1.1) por José Francisco Ñáñez, 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 bbc944aafa669a50…

**Respuestas tomadas por defecto (sesión sin interfaz):** gerente de producto Elena Duarte (la que firma la definición y el caso de negocio); quien decide: Comité de producto (el acta es suya; ningún documento nombra una persona); estado en `estado-producto/PRD-302`, hermana de la documentación y distinta de `estado/`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Pequeños negocios no tiene autopago en tienda | Nada directo. La única entrevista dice «Lo necesito y hoy no lo tengo», pero no nombra el segmento ni el autopago | 2026-05-28 |
| volumen_mensual = 107.018 | Sostenida por la medición: el tablero mide 107.348 al 2026-10-11 (diferencia 0.3 %, bajo el umbral de 20 %) | caso de negocio 2025-10-25 · tablero 2026-10-11 |
| La regulación de datos lo permite | Un supuesto: el documento lo marca «verificado» sin citar con qué | declarado 2026-08-20 |
| 12 requerimientos aceptados | 8 con una cita (la misma entrevista), 4 sin ninguna | acta 2026-10-10 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo trae; el cierre del producto no tendrá contra qué juzgarse.
- **Qué mide `volumen_mensual`.** Ni el caso de negocio ni el tablero lo definen. Y el problema dice que el segmento no tiene autopago: no está dicho qué se está contando.
- **El retorno.** El caso de negocio dice «Retorno esperado en 24 meses» sin cifra ni fuente.
- **La propuesta.** Dice solo «Propuesta principal».
- **Quién decide, con nombre.** Solo figura el comité de producto.
- **Ningún proyecto.** La definición dice «Ninguno declarado» y los 12 requerimientos aceptados tienen «—» como proyecto que los ejecuta (0 de 12 con traza).
- **Con qué se verificó la regulación de datos.**
- **Cuatro aceptados sin demanda citada:** REQ-2028, REQ-4203, REQ-4207, REQ-4209.
- **Tres aceptados sin criterio de aceptación:** REQ-4204, REQ-4208, REQ-4210.
- **Dos sin doliente** («sin asignar»): REQ-4207, REQ-4209.
- **Tres propuestos sin decidir hace más de 60 días:** REQ-4201 (135 días), REQ-4206 (130), REQ-4213 (125).

### Supuestos sobre los que está escrita
Uno declarado: «La regulación de datos lo permite» (2026-08-20). Pasaron 57 días y no tiene cita que lo verifique, así que se cuenta como no verificado. Si es verdad, falta la cita; si no, sostiene todo el producto.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas: hay una sola cita, y el acta atribuye 11 requerimientos a «Cliente entrevistado» sin que la entrevista nombre ninguno.
- La definición de la métrica y su serie con fuente: hay un solo punto medido, no una serie.
- Los títulos y el problema de cada requerimiento: el acta los llama «Requerimiento REQ-42xx».
- El criterio de éxito y el retorno con cifra.
- Un requerimiento con otro prefijo, REQ-2028, aceptado el 2026-09-27: conviene confirmar que es de este producto.
- El acta no dice quién decidió cada estado ni cuándo; se registró la fecha del acta (2026-10-10).

**Lo que quedó registrado:** ficha del producto, 15 requerimientos (12 aceptados, 3 propuestos) y la serie de la métrica en `estado-producto/PRD-302`, con la lectura sellada. Configuración en `.criterio/producto/PRD-302/config.json`.

### Después
Te ofrezco `/product-discovery` sobre el material de entrevistas: ahí los temas se vuelven requerimientos con la cita de quién lo pidió.
