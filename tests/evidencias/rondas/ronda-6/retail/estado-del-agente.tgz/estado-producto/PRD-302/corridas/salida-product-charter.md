**Términos:** ya vigentes para esta versión (0.3.12, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-16; comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.12-2026-10-16.md` y `.pdf`. No hizo falta registrarlos de nuevo.

**Verificación previa (paso 1):** el argumento `REQ-4200` es un requerimiento, no un código de producto; hay un solo producto configurado, PRD-302 «Autopago en tienda». Resultado de las cuatro comprobaciones:

| Comprobación | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado» el 2026-10-10 (acta del comité de producto). Pero `decision.who` está vacío: el acta no dice quién decidió. |
| Criterios de aceptación verificables | **Falta de hecho:** el único criterio es «se verifica en producción», que no dice qué se mide ni contra qué umbral. No sirve para juzgar el cierre. |
| Evidencia de demanda con cita | **Débil:** «Lo necesito y hoy no lo tengo» (cliente entrevistado, 2026-05-28). La entrevista no nombra este requerimiento; el acta se lo atribuye. No dice si es de «Pequeños negocios». |
| Autoridad declarada en la definición | **Falta:** la autoridad es «Comité de producto»; ningún documento nombra a una persona que decida. |

Falta lo que el paso 1 manda señalar. Como nadie puede responder en esta sesión, tomo la respuesta sugerida: **sigo sin ello, marcado como vacío del acta, sin rellenarlo.** Además, la corrida de definición del 2026-10-16 ya había dicho que la definición no está cerrada y no ofreció `/product-charter`; este borrador existe porque se pidió, y lo dice en sus vacíos.

---

# Acta de constitución — Autopago en tienda (REQ-4200) · borrador del 2026-10-16
**Producto:** PRD-302 Autopago en tienda · **Requerimientos:** REQ-4200

## Qué problema resuelve
«El segmento Pequeños negocios no tiene autopago en tienda.» (`00-definicion/2025-10-25-definicion-producto.md`, 2025-10-25.)
El problema se afirma; no hay dato de mercado ni de uso que lo sustente. El requerimiento REQ-4200 no tiene la necesidad escrita (`need`: no encontrada), y su título es solo «Requerimiento REQ-4200» (`30-decisiones/2026-10-10-comite-producto.docx`).

## Criterio de éxito
| Criterio | Fuente | Cómo se verifica |
|---|---|---|
| «se verifica en producción» | `30-decisiones/2026-10-10-comite-producto.docx`, 2026-10-10 | **No está dicho.** Sin métrica, umbral ni fecha. |

El criterio de éxito del producto tampoco está declarado en ningún documento (`success`: no encontrado). **Este acta no lo inventa.**

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 (el título es genérico) | Entrevista a un cliente, 2026-05-28 (`10-descubrimiento/2026-05-28-entrevistas.docx`): «Lo necesito y hoy no lo tengo.» Débil, y la entrevista no nombra el requerimiento. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4201, 4206, 4213 | Requerimiento REQ-… | Siguen «propuestos» (desde 2026-06-03, 2026-06-08 y 2026-06-13); sin decisión no hay alcance. |
| REQ-2028, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4210, 4211, 4212 | Requerimiento REQ-… | Están aceptados, pero esta acta se pidió solo para REQ-4200. Cada uno necesita su acta o entrar en esta con decisión de quien firme. Varios traen sus propios vacíos (sin doliente: 4207, 4209; sin criterio: 4204, 4208, 4210; sin evidencia: 2028, 4203, 4207, 4209), según el acta del comité del 2026-10-10. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no se nombra. Elena Duarte es la gerente de **producto** (definición, 2025-10-25) y la única asistente del comité del 2026-10-10; eso no la hace gerente del proyecto. Asignarlo es de quien tiene la autoridad.
- **Comité:** Comité de producto (acta 2026-10-10; asistió solo Elena Duarte).
- **Doliente del requerimiento:** Mauricio Pérez (acta 2026-10-10).
- **Autoridad del gerente del proyecto:** no está dicha. **Quién decide:** ningún documento nombra a una persona, solo al comité.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La regulación de datos lo permite» (declarado 2026-08-20, en un documento fechado 2025-10-25) | **No.** El documento dice «verificado» sin citar con qué; sin cita no cuenta. Lleva 57 días sin verificar (umbral 30). | Riesgo del proyecto, **doliente por asignar** (no hay nombre en los documentos). Se registra con raid-taxonomy cuando el gerente del proyecto abra su registro. «Lo permite» está sin acotar: falta qué norma y qué tratamiento de datos. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Datos personales del cliente en el autopago; posible tratamiento de datos de pago | Base legal, autorización y seguridad de datos personales; si hay pagos, pagos y consumidor financiero | No tengo la norma a la vista (el país no está en la configuración) | Sin resolver. Va a revisión jurídica; esto no dice si se cumple. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de éxito verificable (métrica, umbral, fecha) | El cierre no se podrá juzgar meses después: «se verifica en producción» sirve para cualquier resultado. | Mauricio Pérez (doliente) con Elena Duarte |
| Persona que decide (autoridad) | El gerente no sabrá qué puede decidir: escalará todo o nada. | Comité de producto (quien lo convoque) |
| Quién decidió aceptar REQ-4200 | La aceptación del 2026-10-10 no tiene firmante rastreable. | Comité de producto |
| Necesidad de REQ-4200 sin escribir; la evidencia no lo nombra ni dice si el cliente es de Pequeños negocios | El proyecto arranca sobre una voz sola, atribuida por el acta. | Elena Duarte (hizo las entrevistas) |
| Supuesto regulatorio sin verificar | Se construye sobre algo que quizá no se puede hacer. | Por asignar; revisión jurídica |
| Patrocinador y gerente del proyecto | Sin ellos no hay a quién entregarle la ficha. | Quien tenga la autoridad |
| Presupuesto e hitos | Ningún documento los declara; el caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra. | Por asignar |
| Propuesta de producto | La sección dice solo «Propuesta principal». | Elena Duarte |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre PRD-302; hoy ningún documento nombra a una persona, así que **no sé quién firma**. No está firmado y no lo doy por firmado. **La ficha del proyecto no se creó** (`portafolio.py init` no se corrió): se crea después de la firma.

**Después:** una vez firmada, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
