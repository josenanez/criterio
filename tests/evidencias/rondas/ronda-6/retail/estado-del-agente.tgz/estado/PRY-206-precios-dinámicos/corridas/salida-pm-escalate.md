## Para decisión — Precios dinámicos (PRY-206) · 2026-10-16

Sin tema indicado, tomé lo que la ficha y las corridas de hoy ya dejan como escalable. Salen **dos puntos, en este orden**: el primero es previo al segundo, porque sin él no se sabe quién puede decidir el otro.

**Respuestas que tomé yo (sesión sin interfaz):** qué escalar = lo ya marcado como escalable (agenda y informe de hoy lo mandan a `/pm-escalate`); días del impacto = 40 (ver abajo); términos ya vigentes a nombre de José Francisco Ñáñez, 2026-10-16.

---

### Punto 1 — ¿Quién tiene la facultad de mover la línea base de PRY-206: la gerente, la patrocinadora o el Comité de Arquitectura?

**Quién decide:** no se puede decir. La ficha no trae la autoridad declarada del gerente (`identity.authority`: no encontrada; el acta de constitución de 2025-11-15 no la declara). Por eso este es el primer punto, y no el de abajo. · **Si no se decide hoy:** el punto 2 no tiene a quién ir y se decidiría sin que valga. Fecha dura en los documentos: ninguna. Lo que sí hay es el comité del **2026-10-30**; si llega sin esto, el punto 2 se aplaza a la sesión siguiente.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. La patrocinadora (Beatriz Cuéllar, según el acta) fija por escrito la autoridad de la gerente y qué cambios van al comité | Una página; no toca el alcance del proyecto | Se puede cerrar antes del 10-30 | Sin costo documentado |
| B. Se declara en el comité del 10-30 (Comité de Arquitectura, según el acta) | Ídem, con acta de comité | Hasta el 10-30 | Sin costo documentado |
| C. Se queda sin declarar | — | — | Cada escalamiento futuro puede volver con «eso lo decide usted» |

**Recomiendo:** A, con ratificación en el comité del 10-30 — es la más corta y deja escrito quién firmó. Es una recomendación sobre un vacío, no sobre un dato.

---

### Punto 2 — ¿Se replanifica PRY-206 con una línea base v2, o se mantiene la v1 y se declara el atraso?

**Quién decide:** pendiente del punto 1. Por lo que consta, un cambio de línea base no es decisión de reunión de seguimiento (agenda de hoy). · **Si no se decide hoy:** no hay una fecha de vencimiento escrita en los documentos y no la invento. Lo que sí está escrito: el cierre de la v1 (2026-08-31) pasó hace 46 días; el informe dice **verde, 21 %** mientras el cronograma da 5 de 5 hitos cerrados (79 puntos de brecha); la proyección ya excede lo aprobado en COP 172.559.716 (+1,8 %) y el disponible real (aprobado menos comprometido) es COP 1.628.515.944. Cada comité sin decisión es un período más con una línea base que no describe el proyecto.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Replanificar: línea base v2 con fecha de cierre y hitos nuevos; la v1 queda intacta | Sin cambio documentado; hoy es «Componente 1, 2, 3, sin más detalle» (acta) | **No consta una fecha propuesta.** Hecho observado: el único hito con acta (Despliegue en la cadena) se recibió el 2026-10-10, 40 días después de su base | Proyección declarada COP 9.672.559.716 vs aprobado 9.500.000.000; ese exceso necesita aprobación en cualquiera de las opciones |
| B. Mantener la v1 y declarar el atraso como desviación | Ídem | Cierre 2026-08-31, desviación creciente cada día | Ídem; el informe tendría que dejar de decir verde |
| C. Reabrir los hitos sin acta antes de decidir (4 de 5: diseño, ambiente de pruebas, ERP, piloto) | Verifica qué está realmente cerrado | Lo que tarden las actas; no consta cuánto | Sin costo documentado |

**Recomiendo:** C primero y A después, en el mismo comité. Razón: hoy no se sabe qué está hecho (cuatro hitos «cerrados» sin acta, avance de 21 %), y una v2 firmada sobre esa base repetiría el problema de la v1. B no es defendible mientras el informe diga verde.

---

### A quién alcanza
Nadie, según lo que hay. `impact` con 40 días devolvió **0 proyectos alcanzados**: la ficha no declara dependencias (el acta tampoco) y el estado de portafolio no contiene otros proyectos. **Eso no prueba que no haya efecto**: prueba que nadie lo escribió. Si hay un proyecto que consume lo que PRY-206 entrega, hay que preguntarlo, porque el cálculo no puede verlo.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| — | — | — | Sin dependencias declaradas |

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| (ninguno) | — | El cálculo con +40 días corre el cierre de 2026-08-31 a 2026-10-10, fecha que ya pasó; por eso no hay hitos futuros por los que pase. Los 5 hitos figuran como cerrados |

**Lo que el cálculo no dice:** los 40 días son el atraso ya observado del despliegue, no una fecha nueva propuesta (nadie la ha propuesto). Si la v2 pone otra fecha, hay que volver a correr `impact` con esos días. Tampoco dice cuántos días se mueve cada proyecto alcanzado: necesita holgura por actividad.

### Lo que dejé fuera, y por qué
- **Documento 1 de Diana Molina (5 reprogramaciones):** el doliente es la propia gerente y no consta que el bloqueo esté fuera del proyecto. Es de la reunión de seguimiento (punto 1 de la agenda). Escala si ahí se nombra un bloqueo externo.
- **Documento 9 de Beatriz Cuéllar (vencido desde 2026-10-08, sin acta):** la patrocinadora es quien por el acta tendría la facultad del punto 1; conviene tratarlo en la misma conversación, pero no es una decisión que se pueda formular: es un acta que falta.
- **Incidencia de seguridad en medios de pago sin doliente:** puede ser de la gerente asignarlo; si el punto 1 dice que no, sube.

### De dónde sale esto
- Autoridad no declarada: `estado/PRY-206-precios-dinámicos/records/PRY-206.json` (`identity.authority`, `meta.fields_not_found`); patrocinadora y comité: `00-gobierno/2025-11-15-acta-constitucion.docx`.
- Línea base única v1, cierre 2026-08-31, 5 hitos cerrados: `10-plan/2025-11-15-cronograma-v1.csv`.
- Acta de recibo del despliegue (2026-10-10): `20-seguimiento/2026-10-10-acta-recibo-despliegue-en-la-cadena.pdf`.
- Verde, 21 %, comprometido, ejecutado y proyección (declaración de la gerencia, no evidencia): `20-seguimiento/2026-10-16-informe-avance.pdf`.
- Aprobado COP 9.500.000.000: acta de constitución. Cifras derivadas: `estado/.../corridas/salida-pm-report.md`.
- Agenda del 10-30 que manda ambos puntos a `/pm-escalate`: `estado/.../corridas/salida-pm-agenda.md`.
- Impacto: `portafolio.py impact --code PRY-206 --days 40`.

*Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación de cada cita es suya. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-16: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12*
*Este comando no escala solo: llevar el paquete al comité es de Diana Molina.*
