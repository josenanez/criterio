## Reunión de seguimiento — Precios dinámicos (PRY-206) · 2026-10-30
7 puntos · 49 minutos · 11 personas requeridas (Diana Molina, Óscar Ramírez, Paula Céspedes, Javier Hoyos, Liliana Torres, Laura Vélez, Andrés Lozano, Mauricio Pérez, Elena Duarte, María Restrepo, Ricardo Salas)

**Cómo leer esta agenda:** la fecha sale de la cadencia (quincenal; las notas del 2026-10-16 dicen «próxima reunión en dos semanas»). La configuración no trae duración, así que no recorté por tiempo: 49 minutos es la suma de los puntos, no un límite que me hayan dado. **No hay corrida anterior contra la que comparar** (`diff` devolvió «sin snapshot previo»), así que el anexo no puede decir «sin cambios desde»: dice «al 2026-10-16». Los días de atraso están contados al 2026-10-16; el 10-30 serán 14 más. Lo que cambie entre hoy y el 10-30 no lo sé.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y quién lo puede quitar** · 10 min · **Diana Molina**
> Prometido para el 2026-11-18, y antes para el 11-04, y antes para el 10-27, el 10-06, el 09-27 y el 09-18. Cinco reprogramaciones, 61 días de corrimiento. Las notas del 10-16 solo dicen «no alcanzó»; el motivo no está escrito en ninguna parte.
> Fuente: `30-reuniones/2026-09-11`, `09-18`, `09-25`, `10-02`, `10-09-comite-semanal.md`; `2026-10-16-notas-reunion.txt` (línea 4).
> **Si no se resuelve hoy:** la fecha del 11-18 es la sexta y nadie sabe qué la sostiene. Si el bloqueo excede a quien está en la sala, sale de aquí como punto de comité (ver «No es de esta reunión»).

> **[2] Cerrar la prueba 2, o decir qué la frena** · 8 min · **Óscar Ramírez**
> Prometido para el 2026-11-01, y antes para el 10-21, el 10-13, el 10-03 y el 09-23. Cuatro reprogramaciones.
> Fuente: `30-reuniones/2026-09-11` a `10-09-comite-semanal.md`.
> **Si no se resuelve hoy:** vence el 11-01, dos días después de la reunión; la quinta fecha queda a la vista.

> **[3] Cerrar la prueba 10: cerrada, o motivo del cuarto corrimiento** · 7 min · **Paula Céspedes**
> Prometido para el 2026-10-30 —el día de la reunión—, y antes para el 10-20, el 10-05 y el 09-23. Tres reprogramaciones.
> Fuente: `30-reuniones/2026-09-18` a `10-09-comite-semanal.md`.
> **Si no se resuelve hoy:** pasa a cuatro y entra al grupo de Óscar y Diana.

*Dos de estos tres son «cerrar la prueba» (2 y 10). Los documentos no permiten afirmar un patrón; sí permiten preguntarlo en la sala.*

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 (17 días al 10-16) | Entregarla con documento, o fecha nueva dicha en voz alta (nunca reprogramada hasta ahora) | 3 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-13 (3 días) | Ídem; se pidió el 10-02 | 2 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-14 (2 días; reprogramado una vez, del 09-24 al 10-14) | Dijo «ya lo entregué» el 09-25 y no hay acta de recibo: que traiga el acta o se reabre | 3 |

Fuentes: `30-reuniones/2026-09-25-comite-semanal.md` (matriz 14), `10-02` (ambiente 20), `09-11` y `09-25` (diseño 5).

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[4]** Dar doliente al hallazgo de seguridad en los medios de pago. Abierto desde 2026-10-16 como incidencia con `owner: no_identificado`; el informe de avance lo lista y ninguna reunión lo trató. | Diana Molina (la ficha no dice la autoridad del gerente; si no puede asignarlo, es de comité) | Una incidencia de seguridad sigue sin dueño, con el informe en verde. Fuente: `20-seguimiento/2026-10-16-informe-avance.pdf` | 4 |
| **[5]** Registrar el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase», con doliente. Se comentó el 10-16 y nadie lo anotó; Óscar tiene la «revisión con el proveedor» para el 10-26, que ya habrá pasado. | Diana Molina, con lo que traiga Óscar de esa revisión | Un riesgo dicho en voz alta que no está en el RAID: nadie lo mira hasta que sea incidencia. Fuente: `2026-10-16-notas-reunion.txt` (línea 7) | 4 |
| **[6]** Poner fecha o descartar los cinco compromisos sin fecha: Laura Vélez (ajuste del presupuesto, «la otra semana»), Andrés Lozano (documento 17), Óscar Ramírez (matriz 22), Paula Céspedes (fecha 23), Diana Molina (ambiente 4, 42 días sin fecha, dijo «ya lo entregué»). | Cada doliente, en la sala | Siguen sin poder vencer, y por eso fuera de todo atraso. Fuentes: notas 10-16; `30-reuniones/2026-09-04`, `10-02`, `10-09` | 5 |

### Vence antes de la próxima
Solo lo que cae antes del 10-30 y no está ya en un punto de arriba. Se pregunta si cada uno llegó; no se repasa.

| Quién | Qué | Para cuándo |
|---|---|---|
| Paula Céspedes | Revisar el anexo 11 (reprogramado una vez) | 2026-10-18 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-19 |
| María Restrepo | Entregar el punto 8 (reprogramado una vez) | 2026-10-20 |
| María Restrepo | Entregar el punto 24 | 2026-10-21 |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-25 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 |
| Elena Duarte | Confirmar la fecha 15 (reprogramado una vez) | 2026-10-28 |
| Paula Céspedes | Revisar el anexo 19 | 2026-10-29 |

**[7]** Son ocho compromisos de seis personas: 1 minuto cada quien que los confirme con documento, y lo que no tenga acta pasa a «vencido sin evidencia» en la agenda siguiente. · 3 min. Mauricio Pérez (ambiente 12, 10-30, reprogramado 2 veces) vence el día de la reunión; se pregunta igual que el [3].

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Beatriz Cuéllar — Enviar el documento 9 (vencido desde 2026-10-08, dijo «ya lo entregué» el 10-02, sin acta) | Es la patrocinadora y no estuvo en las reuniones del 10-09 ni del 10-16; la gerente no puede cobrarle desde la sala | Material del comité; `/pm-commitments` o `/pm-escalate` para formularlo |
| Natalia Ospina — Revisar el anexo 3 (vencido desde 2026-09-11, dijo «ya lo entregué», sin acta) | No aparece en ninguna reunión desde el 09-11; su doliente no va a estar | Pedir el acta por fuera de la reunión; si no llega, comité |
| Informe de avance en verde y 21 % contra cinco hitos cerrados en el cronograma; cuatro hitos cerrados sin acta; cierre del 2026-08-31 pasado sin replanificación escrita | Es una contradicción entre documentos y una decisión de línea base: excede lo que se arregla en una reunión de seguimiento | `/pm-report` para el informe; `/pm-escalate` para la replanificación |

### Anexo — al 2026-10-16
Sin comparación contra una reunión anterior (primera corrida). Lo abierto que no está en ningún punto: Mauricio Pérez, ambiente 12 (10-30); Liliana Torres, punto 16 (11-03). Cerrados con acta: matriz 6, fecha 7, diseño 13. Presupuesto (aprobado COP 9.500.000.000, ejecutado 26,4 %) y proveedor CT-914 (entregables con acta y factura FV-1914 coherente): sin señal.

### Lo que no sé
- **Decisiones pendientes de la reunión anterior:** las notas del 10-16 no registran ninguna, así que no hay punto de ese origen. Si alguien recuerda una, no está en los documentos.
- **Quién va a asistir el 10-30:** tomé como requeridos a los dolientes que estuvieron el 10-09 o el 10-16. Andrés Lozano faltó el 10-16.
- **Duración de la reunión:** no está configurada; si es menor a 49 minutos, el corte es por el final: [7], [6] y [5], en ese orden.

Después de la reunión, `/pm-minutes` sobre las notas; lo que salga entra a `/pm-commitments`.
