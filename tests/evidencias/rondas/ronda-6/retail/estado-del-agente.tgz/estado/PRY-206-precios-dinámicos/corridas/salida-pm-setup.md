## Listo — PRY-206 · Precios dinámicos

**Lo que miré:** 19 documentos · 7 minutas (seis comités semanales del 2026-09-04 al 2026-10-09 y las notas del 2026-10-16) · la última es de hoy, 2026-10-16. Las leí todas, de la más vieja a la más nueva. Formatos: .md, .csv, .docx, .pdf y .txt; todos legibles.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.12 (términos 1.1), fecha 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 c5ca81ee804ae819… (md) y 9d38f05487f3497e… (pdf)

**Respuestas que tomé yo, porque nadie podía contestar (prueba sin interfaz):**
- Proyecto y gerente: PRY-206 · Precios dinámicos, Diana Molina (del acta de constitución del 2025-11-15).
- Reunión de seguimiento: viernes, semanal hasta el 2026-10-09; las notas de hoy dicen «próxima reunión en dos semanas», así que quedó cada dos semanas, con la próxima el 2026-10-30.
- Dónde guardo lo que encuentro: `estado/PRY-206-precios-dinámicos`.
- Términos: el sí y el nombre vinieron en el encargo.

### Lo que está abierto, y cuántas veces se ha movido
Son 26 compromisos en total: 3 cumplidos con acta, 5 vencidos sin evidencia, 5 sin fecha y 13 abiertos con fecha vigente.

**Reprogramados (el hallazgo):**
| Quién | Qué | Primera fecha | Veces movido | Fecha vigente | Cita |
|---|---|---|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-09-18 | **5** | 2026-11-18 | comités 09-11, 09-18, 09-25, 10-02, 10-09 y notas del 10-16 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-09-23 | **4** | 2026-11-01 | comités 09-11 a 10-09 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-09-23 | **3** | 2026-10-30 | comités 09-18 a 10-09 |

Fechas sucesivas: documento 1: 09-27, 10-06, 10-27, 11-04, 11-18. Prueba 2: 10-03, 10-13, 10-21, 11-01. Prueba 10: 10-05, 10-20, 10-30. Son tres compromisos con historial, no doce vencidos; sugieren un bloqueo que nadie ha nombrado.

**Vencidos sin evidencia al 2026-10-16:**
| Quién | Qué | Para | Días | Cita |
|---|---|---|---|---|
| Natalia Ospina | Revisar el anexo 3 | 2026-09-11 | 35 | `30-reuniones/2026-09-04-comite-semanal.md` |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 | 17 | `30-reuniones/2026-09-25-comite-semanal.md` |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-08 | 8 | `30-reuniones/2026-09-25-comite-semanal.md` |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-13 | 3 | `30-reuniones/2026-10-02-comite-semanal.md` |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-14 | 2 | `30-reuniones/2026-09-11-comite-semanal.md` |

Tres de esos cinco (anexo 3, diseño 5 y documento 9) salieron de la lista tras decir su responsable «ya lo entregué»; el comité no recibió acta de ninguno, así que no los di por cumplidos. Los tres que sí se cerraron tienen acta: matriz 6 (Jorge Medina, acta del 2026-09-25), fecha 7 (Felipe Arango) y diseño 13 (Jorge Medina), ambas del 2026-10-09.

**Abiertos con fecha vigente:** María Restrepo (punto 8, 10-20; punto 24, 10-21), Paula Céspedes (anexo 11, 10-18; anexo 19, 10-29), Mauricio Pérez (ambiente 12, 10-30), Elena Duarte (fecha 15, 10-28), Liliana Torres (punto 16, 11-03; diseño 21, 10-25), Ricardo Salas (prueba 18, 10-19), Óscar Ramírez (revisión con el proveedor, 10-26, de las notas de hoy).

### Sin fecha
Nadie los fechó, así que no pueden vencer y por eso desaparecen de los informes:
- Diana Molina — Validar el ambiente 4 (desde 2026-09-04; el 09-11 dijo que ya lo entregó, sin acta).
- Andrés Lozano — Enviar el documento 17 (desde 2026-10-02).
- Óscar Ramírez — Actualizar la matriz 22 (2026-10-09).
- Paula Céspedes — Confirmar la fecha 23 (2026-10-09).
- Laura Vélez — Mandar el ajuste del presupuesto: dijo «la otra semana», que no es una fecha; no la calculé (notas del 2026-10-16).

### Lo que el cálculo levantó contra el estado declarado
El informe de avance de hoy declara **verde** y 21% (`20-seguimiento/2026-10-16-informe-avance.pdf`). Contra eso, `compute` levantó:
- **Avance contra cronograma:** los cinco hitos del cronograma están cerrados (plan sostiene 100%) y el informe dice 21%: 79 puntos de diferencia. Las dos cosas no pueden ser ciertas a la vez.
- **Cuatro hitos cerrados sin acta** (diseño de la experiencia, ambiente de pruebas, integración con el ERP, piloto en tiendas), de 102 a 270 días atrás. Solo «Despliegue en la cadena» tiene acta, del 2026-10-10.
- Los vencidos, los reprogramados y los sin fecha de arriba; el script marca que ninguno aparece explicado en el informe verde.
- Presupuesto: aprobado COP 9.500.000.000, comprometido 82,9 %, ejecutado 26,4 %, proyección 1,8 % sobre lo aprobado. No levantó señal.
- Proveedor Integra Comercio (CT-914): los tres entregables tienen acta de recibo y la factura FV-1914 por COP 1.649.080.221 coincide con lo aceptado. No levantó señal.

**Lo que dijo la reunión de hoy y nadie anotó:** el proveedor podría no llegar con el equipo completo para la siguiente fase. Lo dejé en la ficha como riesgo no registrado; el informe de avance solo lista el de regulación de datos personales y no menciona el hallazgo de seguridad en medios de pago como incidencia abierta.

### Qué le falta a tu carpeta
- Actas de recibo de cuatro hitos que el cronograma da por cerrados.
- Un cronograma posterior al v1 del 2025-11-15: la fecha de cierre sigue siendo 2026-08-31, ya pasó y el proyecto sigue en comité. No hay replanificación escrita.
- Actas de recibo de lo que se dice entregado en reunión (anexo 3, diseño 5, documento 9, ambiente 4).
- Autoridad del gerente y fase: el acta no los dice. El acta tampoco declara dependencias.
- Aviso: la ficha **no está sellada**; no la sellé, como pide este comando.

**Cuándo vuelvo:** el 2026-10-30, en la próxima reunión de seguimiento (cada dos semanas).
