# Plan — PRY-206 Precios dinámicos · borrador del 2026-10-16
**Desde:** `00-gobierno/2025-11-15-acta-constitucion.docx` (aprobada 2025-11-15) · **Criterio de éxito:** «Precios dinámicos en producción y medido.» (acta, sección Criterio de éxito). Está declarado, pero sin métrica, sin umbral y sin fecha de medición.

> Dos cosas antes de leer el borrador:
> 1. **Ya existe un plan.** `10-plan/2025-11-15-cronograma-v1.csv` tiene cinco hitos con fecha. Este borrador parte del acta y no lo toma como base. Si lo que se busca es revisar ese cronograma, el camino es `/pm-plan revisar 10-plan/2025-11-15-cronograma-v1.csv`.
> 2. **El cierre del acta (2026-08-31) ya pasó** frente a hoy (2026-10-16). Este borrador no compromete ni propone ninguna fecha nueva.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1 / Componente 2 / Componente 3» | No hay entregables que descomponer. La WBS no puede pasar de ahí sin inventar qué es cada componente, y eso no se rellena. |
| **Fuera de alcance vacío:** «Lo que otro proyecto cubre» (no dice cuál proyecto ni qué) | No se puede saber dónde termina el proyecto ni qué le toca a otro. Cualquier solicitud adicional entra sin poder rechazarla con el acta. |
| **Criterio de éxito sin métrica:** «en producción y medido» | No se sabe qué se mide, contra qué línea de comparación ni cuándo se considera cumplido. El entregable «medido» no se puede aceptar. |
| **Objetivo del negocio genérico:** «Entregar precios dinámicos para Tecnología» | No dice qué resultado de negocio se busca, ni para qué categorías, tiendas o canales. |
| **Autoridad del gerente no declarada** (el acta no tiene esa sección; la ficha lo registra como no encontrado) | No se sabe qué puede decidir quien planifica y qué hay que subir al patrocinador o al comité. |
| **Dependencias:** «Ninguna declarada» | El proyecto tiene un contrato con proveedor (CT-914) y, según el cronograma, integración con el ERP. Que el acta no declare ninguna no significa que no existan. |
| **Producto asociado: «No aplica»** | Un proyecto de precios dinámicos queda sin producto que lo reciba o lo opere después. No hay a quién entregarle el resultado. |

Sí está: patrocinador (Beatriz Cuéllar), gerente (Diana Molina), comité (Comité de Arquitectura), presupuesto (9.500.000.000 COP), inicio (2025-11-25) y cierre (2026-08-31). El hueco más caro es el del alcance. Lo dejo señalado y no lo relleno.

## WBS
Estado: **Del acta** (escrito en el acta, con su cita), **Supuesto** (lo asumo yo) o **Sin definir** (nadie lo ha dicho).

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | Sin definir | **Del acta** el nombre (Alcance); su contenido es **sin definir** | vacía |
| 2 | Componente 2 | Sin definir | **Del acta** el nombre; contenido **sin definir** | vacía |
| 3 | Componente 3 | Sin definir | **Del acta** el nombre; contenido **sin definir** | vacía |
| 4 | Precios dinámicos en producción | Sin definir (el acta nombra al patrocinador, no dice quién acepta) | **Del acta** (Criterio de éxito) | vacía |
| 5 | Medición de precios dinámicos | Sin definir | **Del acta** («y medido»); qué se mide, **sin definir** | vacía |
| 6 | Licenciamiento de la plataforma (CT-914; fecha contractual 2026-02-09; 549.693.407 COP) | Gerente del proyecto, firma el acta de recibo (contrato CT-914, Condición de pago) | **Supuesto:** el acta no lo nombra. Lo incluyo porque el contrato lo liga al proyecto | vacía |
| 7 | Bolsa de horas de desarrollo (CT-914; fecha contractual 2026-04-27; 549.693.407 COP) | Gerente del proyecto (ídem) | **Supuesto** (ídem) | vacía |
| 8 | Configuración del catálogo (CT-914; fecha contractual 2026-07-13; 549.693.407 COP) | Gerente del proyecto (ídem) | **Supuesto** (ídem) | vacía |
| 9 | Diseño de la experiencia aprobado | Sin definir | **Supuesto:** es un hito del cronograma v1, no del acta | vacía |
| 10 | Ambiente de pruebas certificado | Sin definir | **Supuesto** (ídem) | vacía |
| 11 | Integración con el ERP | Sin definir | **Supuesto** (ídem) | vacía |
| 12 | Piloto en tiendas | Sin definir | **Supuesto** (ídem) | vacía |
| 13 | Despliegue en la cadena | Sin definir | **Supuesto** (ídem) | vacía |

Notas:
- Las fechas contractuales de 6–8 son del contrato, no duraciones. No las convierto en duración.
- Los nodos 1–3 no son terminales aceptables todavía: un «Componente N» no es algo que alguien reciba y acepte. Hasta que el negocio diga qué son, la WBS tiene un hueco ahí.
- No hay duración propuesta en ningún nodo, porque ningún documento citable la da.

## Orden
Sin fechas. El acta no declara dependencias, así que **todo este orden es supuesto**:
- 4 (producción) requiere 12 (piloto) y 13 (despliegue), y 5 (medición) requiere 4.
- 10 (ambiente de pruebas) antes de 11 (integración con ERP) y de 12 (piloto).
- 6 (licenciamiento) antes de 8 (configuración del catálogo) y de 7 (bolsa de horas), porque sin plataforma no hay en qué configurar ni desarrollar.
- 9 (diseño aprobado) antes de 10.
- 1–3 no se pueden ordenar: no se sabe qué son.

El único apoyo para este orden es que el cronograma v1 y el contrato listan los hitos en esa secuencia. Una secuencia de fechas no demuestra una dependencia.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres entregables de CT-914 (6–8) forman parte del alcance del proyecto | Si algo de eso es de otro proyecto, la WBS carga trabajo y costo ajenos. |
| Los cinco hitos del cronograma v1 (9–13) son entregables del proyecto y siguen vigentes | Si se replanificaron o cambiaron, la WBS queda desactualizada respecto de lo que se ejecuta. |
| El orden de dependencias de la sección anterior | Si hay una dependencia distinta, el camino crítico cambia sin que nadie lo vea. |
| «Producción» significa la cadena completa y no solo el piloto | Si es solo el piloto, el nodo 13 sobra. Si es más, falta trabajo. |
| «Componente 1–3» corresponden a entregables distintos de los de CT-914 y del cronograma | Si coinciden, los nodos 1–3 duplican a otros. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | El patrocinador (Beatriz Cuéllar) con el negocio. El acta no dice quién. |
| Qué proyecto cubre lo «fuera de alcance» | El patrocinador / el Comité de Arquitectura |
| Qué se mide, con qué métrica y umbral, y cuándo se da por cumplido «medido» | El patrocinador |
| Quién acepta cada entregable de negocio (4, 5, 9–13) | El patrocinador / el Comité de Arquitectura |
| Autoridad del gerente al planificar | El patrocinador |
| Dependencias externas (ERP, proveedor, tiendas) | La gerente del proyecto con los dueños de cada una |
| Quién recibe y opera el resultado (producto asociado «No aplica») | El patrocinador |
| La «siguiente fase», mencionada en las notas del 2026-10-16, no existe en el acta | El patrocinador / el comité. Es una pregunta abierta. |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no tengo con qué comparar y no lo invento. Es la respuesta correcta, y evita una falsa precisión.

## Preguntas para el equipo
Una por cada duración vacía:
1. Nodo 1, 2 y 3: ¿qué es cada componente y cuánto toma?
2. Nodo 4: ¿cuánto toma pasar a producción una vez terminado el despliegue, y quién lo acepta?
3. Nodo 5: ¿qué se mide, durante cuánto tiempo y quién da por buena la medición?
4. Nodo 6, 7 y 8: ¿cuánto toma cada entregable de Integra Comercio, aparte de la fecha del contrato?
5. Nodo 9 y 10: ¿cuánto tomó o toma el diseño y la certificación del ambiente, y quién los aprueba?
6. Nodo 11: ¿cuánto toma la integración con el ERP y quién del ERP la acepta?
7. Nodo 12 y 13: ¿cuánto toman el piloto y el despliegue, y cuántas tiendas incluye cada uno?
8. En general: ¿qué entregable necesita a cuál? Confirmar o corregir el orden supuesto.

## Para comprometer una fecha falta
Nada de esto está en un documento:
- **La disponibilidad real del equipo.** Las notas del 2026-10-16 dicen que el proveedor podría no llegar con el equipo completo a la siguiente fase, y nadie lo registró como riesgo.
- **La fecha del proveedor** para lo que sigue. El contrato solo tiene tres fechas, todas ya cumplidas según su estado.
- **La ventana de despliegue en producción y en tiendas.**
- **Una decisión sobre el cierre vencido.** El acta cierra el 2026-08-31 y hoy es 2026-10-16. Cambiarlo es control de cambios y no lo decide este plan.

## Después
Si el plan se aprueba, puede registrarse como **línea base original** y pasar los supuestos al RAID con doliente (**raid-taxonomy**). Eso lo decide quien apruebe el plan y no ocurre solo.
