# Precios dinámicos (PRY-206) — informe de la semana, corte al 2026-10-16

**Declara el gerente (Diana Molina):** verde · 21 % · al 2026-10-16 (`20-seguimiento/2026-10-16-informe-avance.pdf`)
**Sustento documental:** contradicho
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia y avance contra el plan.

> Sobre la declaración: en esta sesión nadie podía responder, y el comando prohíbe proponer un estado. Por eso no se preguntó ni se sugirió nada. Se tomó la declaración que ya consta en el informe de avance de hoy, firmado por la gerencia del proyecto. Samuel no declaró ni modificó nada.

## Qué cambió esta semana
No hay base de comparación. Esta es la primera corrida registrada: el `diff` comparó el snapshot de hoy contra sí mismo y dio 0 cambios. **No se puede decir qué cambió desde la semana pasada, y no se inventa.** La próxima corrida tendrá el snapshot de hoy como punto de partida.

Lo que sí aparece con fecha de hoy en la ficha (nuevo en la documentación, sin estado anterior contra el cual compararlo):

| Qué | Estaba | Está |
|---|---|---|
| Incidencia: hallazgo de seguridad en los medios de pago | sin registro | abierta desde 2026-10-16, sin responsable |
| Riesgo: cambio en la regulación de datos personales | sin registro | registrado, sin responsable |
| Riesgo: el proveedor podría no llegar con el equipo completo | sin registro | **dicho en la reunión de hoy, no registrado** |
| Compromiso «Enviar el documento 1» (Diana Molina) | 2026-11-04 | 2026-11-18 (5.ª reprogramación) |
| Acta de recibo de «Despliegue en la cadena» | sin evidencia | `20-seguimiento/2026-10-10-acta-recibo-despliegue-en-la-cadena.pdf` |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño de la experiencia aprobado» marcado cumplido, sin evidencia | 2026-01-19 | 270 |
| Hito «Ambiente de pruebas certificado», sin evidencia | 2026-03-16 | 214 |
| Hito «Integración con el ERP», sin evidencia | 2026-05-11 | 158 |
| Hito «Piloto en tiendas», sin evidencia | 2026-07-06 | 102 |
| Natalia Ospina — Revisar el anexo 3 (dice que lo entregó; no hay acta) | 2026-09-11 | 35 |
| Javier Hoyos — Actualizar la matriz 14 | 2026-09-29 | 17 |
| Beatriz Cuéllar — Enviar el documento 9 (dice que lo entregó; no hay acta) | 2026-10-08 | 8 |
| Javier Hoyos — Validar el ambiente 20 | 2026-10-13 | 3 |
| Liliana Torres — Aprobar el diseño 5 (dice que lo entregó; no hay acta) | 2026-10-14 | 2 |
| Avance declarado 21 % frente a un plan que da 5 de 5 hitos cumplidos | — | brecha de 79 puntos |

Los días de los hitos y compromisos se cuentan desde su fecha de vencimiento hasta el corte. Es el mismo criterio que usa el cálculo.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-08-31 | 2026-08-31 | 0 días contra ambas |
| Presupuesto (aprobado vs proyección) | COP 9.500.000.000 | COP 9.500.000.000 | +COP 172.559.716 (+1,8 %) |

Replanificaciones: **0**. La línea base es única (v1, 2025-11-15, acta de constitución).

**Lectura que hay que hacer con cuidado:** la desviación de 0 días contra la base no es buena noticia. La fecha de cierre (2026-08-31) ya pasó hace 46 días, el plan nunca se movió y el avance declarado es 21 %. El plan sigue diciendo que todo está cumplido en fecha, y esa cuenta no cuadra con el 21 % que declara la misma gerencia. El hito «Despliegue en la cadena» tiene acta de recibo del 2026-10-10, es decir 40 días después de su fecha base (2026-08-31).

### Hitos de las próximas cuatro semanas
No hay. Los 5 hitos del plan figuran como cumplidos, y 4 de ellos no tienen evidencia. Próxima fecha de gobierno: comité del 2026-10-30.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 7.871.484.056 (82,9 %) | 2.511.507.913 (26,4 %) | 9.672.559.716 | **1.628.515.944** |

El disponible real es aprobado menos comprometido. Aprobado menos ejecutado daría 6.988.492.087, que no es plata libre. La proyección excede lo aprobado en COP 172.559.716, y el disponible real ya es menor que ese cálculo.
El comprometido, el ejecutado y la proyección salen del informe de avance de la gerencia (declaración). Solo el aprobado sale de un documento de gobierno.

## Abierto
**Reprogramados** (umbral de escalamiento: 3):
- Diana Molina — Enviar el documento 1: 5 veces. Original 2026-09-18, hoy 2026-11-18.
- Óscar Ramírez — Cerrar la prueba 2: 4 veces. Original 2026-09-23, hoy 2026-11-01.
- Paula Céspedes — Cerrar la prueba 10: 3 veces. Original 2026-09-23, hoy 2026-10-30.

**Vencidos sin evidencia:** los cinco de la tabla de arriba (Natalia Ospina, Javier Hoyos ×2, Beatriz Cuéllar, Liliana Torres).

**Sin fecha:** Diana Molina (Validar el ambiente 4, sin fecha desde 2026-09-04), Andrés Lozano (documento 17), Óscar Ramírez (matriz 22), Paula Céspedes (fecha 23), Laura Vélez (ajuste del presupuesto, dijo «la otra semana», que no es fecha).

**RAID sin movimiento:** nada de más de 15 días. Pero los tres elementos (el hallazgo de seguridad, el riesgo regulatorio y el riesgo del proveedor) **no tienen responsable**. El riesgo del proveedor además no está registrado.

**Proveedor (Integra Comercio S.A.S., CT-914):** 3 de 3 entregables aceptados, todos con acta de recibo. Facturado COP 1.649.080.221, igual a lo aceptado. Sin vencidos, sin aceptados sin documento, sin facturado sin entrega. Vigencia del contrato: no consta en la ficha.

## Lo que necesito de alguien
- **Diana Molina:** el documento 1 lleva cinco reprogramaciones y es tuyo. Decir qué lo bloquea.
- **Óscar Ramírez y Paula Céspedes:** qué impide cerrar las pruebas 2 y 10, que ya van en 4 y 3 reprogramaciones.
- **Natalia Ospina, Beatriz Cuéllar y Liliana Torres:** el acta de recibo de lo que dijeron haber entregado.
- **Javier Hoyos:** matriz 14 y ambiente 20, vencidos sin reprogramar ni evidencia.
- **Quien sea dueño de los riesgos y la incidencia de seguridad:** asignar responsable, y registrar el riesgo del proveedor.
- **Diana Molina:** aclarar o corregir la declaración. Hoy dice verde, 21 %, mientras el plan dice 5 de 5 y el cierre ya venció.
- **Material de comité (excede al gerente, va al comité del 2026-10-30):** ver «Después».

## Lo que no se sabe
**Sin dato:** producto asociado (el acta dice «No aplica»), autoridad del proyecto, fase. Sin evidencia independiente de las cifras de dinero (comprometido, ejecutado y proyección son todos declaración). Sin fecha de fin del contrato CT-914.
**Silencio:** último documento hace 0 días · última reunión hace 0 días. No hay silencio. El problema es lo contrario: hay actividad, pero los hitos y los compromisos no tienen evidencia.

---
**Origen:** ficha `estado/PRY-206-precios-dinámicos/records/PRY-206.json`, actualizada el 2026-10-16. 3 campos sin dato de 3 buscados en la identidad (producto, autoridad y fase). De las fuentes de la ficha, 0 son evidencia, 5 son declaración y 17 no están marcadas.
Términos (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación de cada cita es suya.
