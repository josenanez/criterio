Antes de escribir, esto es lo que se publica: la ficha de PRY-206 recalculada hoy (2026-10-16). Va con 16 campos con dato y 3 sin decir en ninguna parte (producto, autoridad y fase). El estado que declara el proyecto es **verde**, al 2026-10-16, con 21 % de avance, según `20-seguimiento/2026-10-16-informe-avance.pdf`.

Revisé la fecha de cierre contra el cronograma vigente. El único cronograma es `10-plan/2025-11-15-cronograma-v1.csv`, y su último hito (Despliegue en la cadena) cae el 2026-08-31. Ese es el `plan.end_date` de la ficha, y la línea base original coincide, así que no hay diferencia por explicar.

Para la PMO conviene saber que el estado verde viene con 19 alertas del cálculo. Cuatro señales no están explicadas en la declaración: compromisos vencidos, compromisos reprogramados, hitos dados por cumplidos sin evidencia (4 de 5) y el avance declarado (21 %) frente a un plan que ya vencía al 100 %. Eso no lo corrijo yo: la declaración sigue siendo tuya y la ficha la marca como declarada.

La carpeta de gobierno ya existía, así que no hubo que crearla.

Publiqué la ficha en `/home/claude/banco/ronda-6/retail/espacio/documentos/proyectos/PRY-206-precios-dinámicos/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 16 campos con dato · 3 sin decir en ninguna parte · declara **verde** al 2026-10-16

**Lo más viejo que va ahí:** identidad, patrocinador, comité, alcance y presupuesto aprobado, del 2025-11-15 (acta de constitución), unos 11 meses; no pasa de un año.
