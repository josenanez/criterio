# Acta — Precios dinámicos (PRY-206) · 2026-10-16
**Asistieron:** Diana Molina, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Óscar Ramírez · **Fuente:** documentos/proyectos/PRY-206-precios-dinámicos/2026-10-16-notas-reunion.txt (notas de 8 líneas)
**Ausentes con tema en agenda:** las notas no traen agenda, así que no se puede decir. Dato aparte: Andrés Lozano estuvo el 2026-10-09 y hoy no está; tiene un compromiso sin fecha («Enviar el documento 17») que hoy no se tocó. Laura Vélez aparece por primera vez en las actas de este proyecto.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-18 | **Reprogramado por 5.ª vez.** Original 2026-09-18 → 09-27 → 10-06 → 10-27 → 11-04 → 11-18. Cita (línea 4): «lo de "enviar el documento 1" no alcanzó, se compromete para el 18/11/2026». Pasa de 2026-09-18 a 2026-11-18: dos meses. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. Cita (línea 6): «revisión con el proveedor, queda para el 2026-10-26». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana» (línea 5): no es una fecha y no se calculó una. `due_date: no_declarada` |

Ya había otros 4 sin fecha de reuniones anteriores, que esta reunión no tocó: Diana Molina («Validar el ambiente 4», desde 2026-09-04), Andrés Lozano («Enviar el documento 17»), Óscar Ramírez («Actualizar la matriz 22») y Paula Céspedes («Confirmar la fecha 23»). Total sin fecha tras esta reunión: **5**.

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quien la tomó ni con lo que se descartó.

## Quedó sin decidir
Las notas no dicen que algo haya quedado pendiente de decisión. Tampoco dicen por qué «no alcanzó» el documento 1; ese motivo no está escrito en ninguna parte.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (línea 7: «nadie lo anotó como riesgo») | No se atribuye: las notas dicen «se comentó» | Riesgo (probabilidad incierta, afecta la siguiente fase) | **No.** No está en el RAID ni en el informe de avance del 2026-10-16. Sin responsable identificado. |

El proveedor no se nombra en las notas. El único registrado en el expediente es Integra Comercio S.A.S. (CT-914), pero esa identificación es una inferencia mía y no consta en la fuente. «La siguiente fase» tampoco está definida: la ficha no trae fase vigente.

## Cerrado en esta reunión
Nada. (Se omite el detalle: ninguna nota cita un acta de recibo.)

## Lo que esta reunión contradice
Ningún campo de la ficha. Dos observaciones:
- «Próxima reunión en dos semanas» (línea 8) coincide con la cadencia quincenal de la configuración (comité siguiente 2026-10-30). Los comités anteriores del expediente se llaman «semanal» y se hicieron cada 7 días; aquí cambia la cadencia, sin que las notas lo digan expresamente.
- La reunión no corrige al informe de avance (verde, 21 %). Ese informe sí choca con el expediente (ver `/pm-report`), pero por lo que dicen los documentos, no por esta reunión.

## Sin resolver de la transcripción
- «la otra semana» (línea 5): sin fecha; no se sabe cuál semana ni qué día.
- «próxima reunión en dos semanas» (línea 8): no trae día; por calendario sería 2026-10-30, pero eso lo calculé yo.
- Línea 7: no se sabe quién lo dijo ni a qué proveedor ni a qué fase se refiere.
- Las notas no mencionan ninguno de los otros 20 compromisos abiertos del expediente (por ejemplo «Cerrar la prueba 2» de Óscar Ramírez, ya reprogramado 4 veces, hoy al 2026-11-01). Quedan como estaban, no como cumplidos.

## Seguimiento tras recalcular (portafolio.py compute)
- Vencidos sin evidencia: **5** (Natalia Ospina, anexo 3, 35 días; Javier Hoyos, matriz 14, 17 días; Beatriz Cuéllar, documento 9, 8 días; Javier Hoyos, ambiente 20, 3 días; Liliana Torres, diseño 5, 2 días). Tres de ellos aparecen como «ya entregado» en reuniones anteriores, sin acta de recibo, y por eso no cuentan como cumplidos.
- Sin fecha: **5**. Reprogramados 3 o más veces: **3** (documento 1, 5 veces; prueba 2, 4 veces; prueba 10, 3 veces).
- El informe de avance declara verde, y los cálculos tienen 4 señales que no explica.

**Siguiente paso:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por esta acta: no cambia ningún campo de la ficha. El acta es tuya: aquí queda en la conversación y no se escribió en tu carpeta de reuniones.
