## Compromisos — Precios dinámicos (PRY-206) · al 2026-10-16

Cifras de `portafolio.py compute`: 5 vencidos sin evidencia, 5 sin fecha, 3 reprogramados.

### Se viene reprogramando

> **Diana Molina** · Enviar el documento 1 (5 reprogramaciones)
> Prometido para el 2026-09-18, y antes para el 09-27, el 10-06, el 10-27, el 11-04, y hoy para el 2026-11-18.
> Desde la primera promesa son 61 días de corrimiento y cinco fechas distintas. Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.
> Fuentes: 30-reuniones/2026-09-11, 09-18, 09-25, 10-02 y 10-09-comite-semanal.md; 2026-10-16-notas-reunion.txt («no alcanzó, se compromete para el 18/11/2026»).

> **Óscar Ramírez** · Cerrar la prueba 2 (4 reprogramaciones)
> Prometido para el 2026-09-23, y antes para el 10-03, el 10-13, el 10-21, y hoy para el 2026-11-01.
> Fuentes: 30-reuniones/2026-09-11, 09-18, 09-25, 10-02 y 10-09-comite-semanal.md.

> **Paula Céspedes** · Cerrar la prueba 10 (3 reprogramaciones)
> Prometido para el 2026-09-23, y antes para el 10-05, el 10-20, y hoy para el 2026-10-30.
> Fuentes: 30-reuniones/2026-09-18, 09-25, 10-02 y 10-09-comite-semanal.md.

Dos de los tres son «cerrar la prueba» (2 y 10) y el tercero es un documento de la gerente. El patrón no se puede afirmar con los documentos, pero merece la pregunta.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Natalia Ospina | Revisar el anexo 3 | 2026-09-11 | 35 días |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 | 17 días |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-08 | 8 días |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-13 | 3 días |
| Liliana Torres | Aprobar el diseño 5 (reprogramado una vez, del 09-24 al 10-14) | 2026-10-14 | 2 días |

Tres de estos dicen «ya lo entregué» y no hay documento que lo respalde. Siguen abiertos:
- Natalia Ospina dijo que ya entregó el anexo 3 (comité del 2026-09-11); no hay acta de recibo.
- Liliana Torres dijo que ya entregó el diseño 5 (comité del 2026-09-25) y dejó de aparecer en la lista; no hay acta.
- Beatriz Cuéllar dijo que ya entregó el documento 9 (comité del 2026-10-02) y dejó de aparecer en la lista; no hay acta.

Beatriz Cuéllar es la patrocinadora del proyecto, según el acta de constitución.

### Vencen esta semana (hasta el 2026-10-23)
| Quién | Qué | Para cuándo |
|---|---|---|
| Paula Céspedes | Revisar el anexo 11 (reprogramado una vez) | 2026-10-18 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-19 |
| María Restrepo | Entregar el punto 8 (reprogramado una vez) | 2026-10-20 |
| María Restrepo | Entregar el punto 24 | 2026-10-21 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Diana Molina | Validar el ambiente 4 (dijo que ya lo entregó; sin acta) | 2026-09-04 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-02 |
| Óscar Ramírez | Actualizar la matriz 22 | 2026-10-09 |
| Paula Céspedes | Confirmar la fecha 23 | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; no es una fecha, no se calculó) | 2026-10-16 |

«Validar el ambiente 4» lleva 42 días sin fecha. Estos cinco no pueden estar vencidos y por eso no aparecen en ningún atraso.

### Cerrados con documento
| Quién | Qué | Documento |
|---|---|---|
| Jorge Medina | Actualizar la matriz 6 | 20-seguimiento/2026-09-25-acta-recibo-6.md |
| Felipe Arango | Confirmar la fecha 7 | 20-seguimiento/2026-10-09-acta-recibo-7.md |
| Jorge Medina | Aprobar el diseño 13 | 20-seguimiento/2026-10-09-acta-recibo-13.md |

### Contexto
Otros 6 compromisos están abiertos con fecha posterior a esta semana: Mauricio Pérez (ambiente 12, 10-30; reprogramado 2 veces), Elena Duarte (fecha 15, 10-28; reprogramado una vez), Liliana Torres (punto 16, 11-03, reprogramado una vez; diseño 21, 10-25), Paula Céspedes (anexo 19, 10-29) y Óscar Ramírez (revisión con el proveedor, 10-26).

El informe de avance del 2026-10-16 declara el proyecto en verde. Tiene 5 vencidos, 3 compromisos reprogramados tres veces o más y 5 sin fecha. El script marca ese verde como contradicho por la evidencia.

### Después
Hay tres compromisos reprogramados tres veces o más. Ofrezco formular **«Enviar el documento 1»** (Diana Molina, 5 veces) como decisión para el comité del 2026-10-30: qué se pide, qué pasa si no se decide y quién tiene la facultad. Tampoco puedo decir quién sería esa persona sin que alguien lo confirme. El acta no nombra autoridad.

También ofrezco `/pm-publish` para que la PMO vea el estado actualizado.
