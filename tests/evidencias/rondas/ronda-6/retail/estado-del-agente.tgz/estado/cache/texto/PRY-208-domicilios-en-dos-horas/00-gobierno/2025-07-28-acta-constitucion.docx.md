<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2025-07-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Domicilios en dos horas

Código: PRY-208

Área dueña: Abastecimiento

Patrocinador: Gustavo Neira

Gerente de proyecto: Javier Hoyos

Comité: Comité de Transformación Digital

Producto asociado: entrega rápida

Fecha de aprobación: 2025-07-28

Objetivo del negocio

Entregar domicilios en dos horas para Abastecimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Transformación Digital el 2025-07-28.

Fechas comprometidas

Fecha

Inicio

2025-08-07

Cierre

2026-11-12

Criterio de éxito

Domicilios en dos horas en producción y medido.

Dependencias declaradas

• Ninguna declarada
