<!-- origen: PRY-206-precios-dinámicos/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-206",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "name": {
 "value": "Precios dinámicos",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Tecnología",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Beatriz Cuéllar",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "manager": {
 "value": "Diana Molina",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Arquitectura",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 21,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-16",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-11-25",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "end_date": {
 "value": "2026-08-31",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-11-15",
 "start_date": "2025-11-25",
 "end_date": "2026-08-31",
 "reason": "Acta de constitución",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño de la experiencia aprobado",
 "baseline_date": "2026-01-19",
 "current_date": "2026-01-19",
 "state": {
 "value": "met",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "evidence": null
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-03-16",
 "current_date": "2026-03-16",
 "state": {
 "value": "met",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "evidence": null
 },
 {
 "name": "Integración con el ERP",
 "baseline_date": "2026-05-11",
 "current_date": "2026-05-11",
 "state": {
 "value": "met",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "evidence": null
 },
 {
 "name": "Piloto en tiendas",
 "baseline_date": "2026-07-06",
 "current_date": "2026-07-06",
 "state": {
 "value": "met",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "evidence": null
 },
 {
 "name": "Despliegue en la cadena",
 "baseline_date": "2026-08-31",
 "current_date": "2026-08-31",
 "state": {
 "value": "met",
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "source": "10-plan/2025-11-15-cronograma-v1.csv",
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-despliegue-en-la-cadena.pdf"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3 (sin más detalle)",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2025-11-15-acta-constitucion.docx",
 "source_date": "2025-11-15",
 "state": "found"
 },
 "committed": {
 "value": 7871484056,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 2511507913,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 9672559716,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": "Integra Comercio S.A.S.",
 "contract_ref": "CT-914",
 "deliverables": [
 {
 "name": "Licenciamiento de la plataforma",
 "due_date": "2026-02-09",
 "amount": 549693407,
 "state": "accepted",
 "evidence": "20-seguimiento/2026-02-10-acta-recibo-ct-914-licenciamiento-de-la-plataforma.md"
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-04-27",
 "amount": 549693407,
 "state": "accepted",
 "evidence": "20-seguimiento/2026-05-05-acta-recibo-ct-914-bolsa-de-horas-de-desarrollo.md"
 },
 {
 "name": "Configuración del catálogo",
 "due_date": "2026-07-13",
 "amount": 549693407,
 "state": "accepted",
 "evidence": "20-seguimiento/2026-07-24-acta-recibo-ct-914-configuración-del-catálogo.pdf"
 }
 ],
 "invoiced": {
 "value": 1649080221,
 "source": "20-seguimiento/2026-09-21-factura-ct-914.pdf",
 "source_date": "2026-09-21",
 "state": "found"
 },
 "source": "00-gobierno/2025-11-08-contrato-ct-914.docx"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Cambio en la regulación de datos personales que puede mover el alcance",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "registered": true
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "owner": "no_identificado",
 "source": "2026-10-16-notas-reunion.txt",
 "registered": false,
 "note": "Se comentó en la reunión; nadie lo anotó como riesgo y el informe de avance no lo trae."
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Hallazgo de seguridad en los medios de pago",
 "since": "2026-10-16",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Diana Molina",
 "what": "Enviar el documento 1",
 "due_date": "2026-11-18",
 "original_due_date": "2026-09-18",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-11-18",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt"
 }
 ],
 "first_seen_undated_on": "2026-09-04",
 "note": "Las notas del 2026-10-16: «lo de enviar el documento 1 no alcanzó, se compromete para el 18/11/2026»."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-01",
 "original_due_date": "2026-09-23",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "first_seen_undated_on": "2026-09-04"
 },
 {
 "who": "Natalia Ospina",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-11",
 "original_due_date": "2026-09-11",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Dijo en la reunión que ya lo entregó; no se presentó acta, así que no cuenta como cumplido. Dicho el 2026-09-11 (30-reuniones/2026-09-11-comite-semanal.md)."
 },
 {
 "who": "Diana Molina",
 "what": "Validar el ambiente 4",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-04",
 "source": "30-reuniones/2026-09-04-comite-semanal.md",
 "state": "unknown",
 "reschedules": [],
 "note": "Dijo en la reunión que ya lo entregó; no se presentó acta, así que no cuenta como cumplido. Dicho el 2026-09-11 (30-reuniones/2026-09-11-comite-semanal.md). Nunca tuvo fecha."
 },
 {
 "who": "Liliana Torres",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-14",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "note": "El 2026-09-25 dijo que ya lo entregó (30-reuniones/2026-09-25-comite-semanal.md); no se presentó acta y dejó de aparecer en la lista."
 },
 {
 "who": "Jorge Medina",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-24",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-25-acta-recibo-6.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-07",
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-11",
 "source": "30-reuniones/2026-09-11-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-7.md"
 },
 {
 "who": "María Restrepo",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-20",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ],
 "first_seen_undated_on": "2026-09-11"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "first_seen_undated_on": "2026-09-18",
 "note": "El 2026-10-02 dijo que ya lo entregó (30-reuniones/2026-10-02-comite-semanal.md); no se presentó acta y dejó de aparecer en la lista."
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-30",
 "original_due_date": "2026-09-23",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-18",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Mauricio Pérez",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-30",
 "original_due_date": "2026-09-24",
 "stated_on": "2026-09-18",
 "source": "30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-09-acta-recibo-13.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Liliana Torres",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-03",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-09-25",
 "source": "30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Enviar el documento 17",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-29",
 "original_due_date": "2026-10-29",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "first_seen_undated_on": "2026-10-02"
 },
 {
 "who": "Javier Hoyos",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-10-02",
 "source": "30-reuniones/2026-10-02-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Actualizar la matriz 22",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Confirmar la fecha 23",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-09",
 "source": "30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Fecha dicha: «la otra semana». No es una fecha; no se calculó."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "activity": {
 "last_document_date": "2026-10-16",
 "last_meeting_date": "2026-10-16"
 },
 "meta": {
 "record_updated": "2026-10-16",
 "fields_not_found": [
 "identity.product (el acta dice «No aplica»)",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
