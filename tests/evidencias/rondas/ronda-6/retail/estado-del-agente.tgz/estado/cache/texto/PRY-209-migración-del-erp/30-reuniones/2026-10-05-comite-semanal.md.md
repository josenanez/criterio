<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Migración del ERP

**Fecha:** 2026-10-05
**Asistentes:** Felipe Arango, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 33 | por definir |
