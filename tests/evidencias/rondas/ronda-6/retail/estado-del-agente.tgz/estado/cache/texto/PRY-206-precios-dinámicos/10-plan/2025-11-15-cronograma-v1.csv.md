<!-- origen: PRY-206-precios-dinámicos/10-plan/2025-11-15-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-01-19,2026-01-19,cerrado
Ambiente de pruebas certificado,2026-03-16,2026-03-16,cerrado
Integración con el ERP,2026-05-11,2026-05-11,cerrado
Piloto en tiendas,2026-07-06,2026-07-06,cerrado
Despliegue en la cadena,2026-08-31,2026-08-31,cerrado
