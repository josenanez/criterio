<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2025-09-26-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-12-18 | 2025-12-18 | cerrado
Ambiente de pruebas certificado | 2026-03-01 | 2026-03-01 | cerrado
Integración con el ERP | 2026-05-13 | 2026-05-13 | cerrado
Piloto en tiendas | 2026-07-25 | 2026-07-25 | cerrado
Despliegue en la cadena | 2026-10-06 | 2026-10-06 | en curso
