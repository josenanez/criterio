<!-- origen: PRY-203-reposición-automática/10-plan/2025-07-08-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-11-01 | 2025-11-01 | cerrado
Ambiente de pruebas certificado | 2026-02-15 | 2026-02-15 | cerrado
Integración con el ERP | 2026-06-01 | 2026-06-01 | cerrado
Piloto en tiendas | 2026-09-15 | 2026-09-15 | cerrado
Despliegue en la cadena | 2026-12-30 | 2026-12-30 | en curso
