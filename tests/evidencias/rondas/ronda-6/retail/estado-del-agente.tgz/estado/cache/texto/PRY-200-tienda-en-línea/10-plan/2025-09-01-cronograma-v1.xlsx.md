<!-- origen: PRY-200-tienda-en-línea/10-plan/2025-09-01-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-03 | 2026-01-03 | cerrado
Ambiente de pruebas certificado | 2026-04-27 | 2026-04-27 | cerrado
Integración con el ERP | 2026-08-19 | 2026-08-19 | cerrado
Piloto en tiendas | 2026-12-11 | 2026-12-11 | en curso
