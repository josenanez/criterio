<!-- origen: PRY-203-reposición-automática/00-gobierno/2025-07-08-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Mercadeo
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar reposición automática para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2026-12-30 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
