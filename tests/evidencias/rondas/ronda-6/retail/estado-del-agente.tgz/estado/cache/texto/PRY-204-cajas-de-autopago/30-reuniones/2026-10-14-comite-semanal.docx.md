<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Comercial · Cajas de autopago

Fecha: 2026-10-14

Asistentes: María Restrepo, Gustavo Neira

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 30

2026-11-08

Paula Céspedes

Entregar el punto 3

2026-10-12
