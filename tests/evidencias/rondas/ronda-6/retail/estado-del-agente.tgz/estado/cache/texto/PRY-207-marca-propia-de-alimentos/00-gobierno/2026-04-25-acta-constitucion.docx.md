<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-04-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Marca propia de alimentos

Código: PRY-207

Área dueña: Tiendas

Patrocinador: Gustavo Neira

Gerente de proyecto: Mauricio Pérez

Comité: Comité Comercial

Producto asociado: marca propia

Fecha de aprobación: 2026-04-25

Objetivo del negocio

Entregar marca propia de alimentos para Tiendas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité Comercial el 2026-04-25.

Fechas comprometidas

Fecha

Inicio

2026-05-05

Cierre

2027-07-29

Criterio de éxito

Marca propia de alimentos en producción y medido.

Dependencias declaradas

• Ninguna declarada
