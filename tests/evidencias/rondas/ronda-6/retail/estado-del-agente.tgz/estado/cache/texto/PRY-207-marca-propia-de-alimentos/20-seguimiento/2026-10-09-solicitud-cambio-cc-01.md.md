<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Marca propia de alimentos
**Fecha:** 2026-10-09
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +64 días sobre la línea base vigente |
| Costo | 128.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
