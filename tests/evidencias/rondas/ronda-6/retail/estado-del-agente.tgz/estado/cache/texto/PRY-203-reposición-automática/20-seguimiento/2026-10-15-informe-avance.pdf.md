<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Reposición automática
Código: PRY-203
Fecha de corte: 2026-10-15
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 49%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.203.231.939
Ejecutado 2.148.130.209
Proyección al cierre 4.057.825.880

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Concentración del conocimiento en una sola persona
