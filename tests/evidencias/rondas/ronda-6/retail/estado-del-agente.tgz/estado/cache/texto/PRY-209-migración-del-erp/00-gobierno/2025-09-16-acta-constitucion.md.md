<!-- origen: PRY-209-migración-del-erp/00-gobierno/2025-09-16-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración del ERP

**Código:** PRY-209
**Área dueña:** Talento humano
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-16

## Objetivo del negocio

Entregar migración del erp para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-09-16.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-26 |
| Cierre | 2026-04-28 |

## Criterio de éxito

Migración del ERP en producción y medido.

## Dependencias declaradas

- Ninguna declarada
