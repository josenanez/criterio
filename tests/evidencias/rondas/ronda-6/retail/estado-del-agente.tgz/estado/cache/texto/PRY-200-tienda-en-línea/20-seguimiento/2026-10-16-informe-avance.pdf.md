<!-- origen: PRY-200-tienda-en-línea/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tienda en línea
Código: PRY-200
Fecha de corte: 2026-10-16
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 46%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se recibió el concepto de Jurídica sobre los términos de uso
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.799.233.410
Ejecutado 2.855.071.580
Proyección al cierre 6.930.747.093

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
- Concentración del conocimiento en una sola persona
