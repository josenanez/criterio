<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pago con QR en caja
Código: PRY-205
Fecha de corte: 2026-10-06
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 73%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 800.000.000
Comprometido 688.496.147
Ejecutado 428.207.016
Proyección al cierre 783.938.369

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
