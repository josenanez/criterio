<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2026-10-16-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-10-02 | 2026-10-02 | en curso
Ambiente de pruebas certificado | 2027-03-01 | 2027-03-01 | en curso
Integración con el ERP | 2027-07-29 | 2027-10-01 | en curso
