<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Etiquetas electrónicas de precio
**Fecha:** 2026-10-09
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +27 días sobre la línea base vigente |
| Costo | 54.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
