<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2025-09-26-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Comercial
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Transformación Digital
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2025-09-26

## Objetivo del negocio

Entregar pago con qr en caja para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-09-26.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-06 |
| Cierre | 2026-10-06 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
