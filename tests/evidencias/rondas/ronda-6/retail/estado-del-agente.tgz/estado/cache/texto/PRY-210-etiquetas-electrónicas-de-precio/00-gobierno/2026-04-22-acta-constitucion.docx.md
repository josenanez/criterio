<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/00-gobierno/2026-04-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Etiquetas electrónicas de precio

Código: PRY-210

Área dueña: Mercadeo

Patrocinador: Óscar Ramírez

Gerente de proyecto: Javier Hoyos

Comité: Comité de Cadena de Abastecimiento

Producto asociado: No aplica

Fecha de aprobación: 2026-04-22

Objetivo del negocio

Entregar etiquetas electrónicas de precio para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2026-04-22.

Fechas comprometidas

Fecha

Inicio

2026-05-02

Cierre

2026-12-04

Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

Dependencias declaradas

• Ninguna declarada
