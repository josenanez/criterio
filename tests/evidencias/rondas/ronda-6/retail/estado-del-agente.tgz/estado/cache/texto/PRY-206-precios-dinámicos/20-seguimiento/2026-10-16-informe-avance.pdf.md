<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Precios dinámicos
Código: PRY-206
Fecha de corte: 2026-10-16
Gerente: Diana Molina

Estado declarado
Verde
Avance reportado: 21%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 7.871.484.056
Ejecutado 2.511.507.913
Proyección al cierre 9.672.559.716

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
