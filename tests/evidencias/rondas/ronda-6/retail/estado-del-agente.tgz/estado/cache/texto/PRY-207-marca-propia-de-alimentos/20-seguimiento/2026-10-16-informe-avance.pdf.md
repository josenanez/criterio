<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Marca propia de alimentos
Código: PRY-207
Fecha de corte: 2026-10-16
Gerente: Mauricio Pérez

Estado declarado
Amarillo
Avance reportado: 52%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 800.000.000
Comprometido 352.515.770
Ejecutado 304.266.576
Proyección al cierre 761.862.528

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
