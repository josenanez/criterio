<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2025-11-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Tecnología

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: Diana Molina

Comité: Comité de Arquitectura

Producto asociado: No aplica

Fecha de aprobación: 2025-11-15

Objetivo del negocio

Entregar precios dinámicos para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Arquitectura el 2025-11-15.

Fechas comprometidas

Fecha

Inicio

2025-11-25

Cierre

2026-08-31

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
