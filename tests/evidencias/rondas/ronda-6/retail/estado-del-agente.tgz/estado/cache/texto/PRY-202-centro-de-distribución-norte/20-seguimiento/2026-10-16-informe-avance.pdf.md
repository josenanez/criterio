<!-- origen: PRY-202-centro-de-distribución-norte/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Centro de distribución norte
Código: PRY-202
Fecha de corte: 2026-10-16
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 55%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.207.780.876
Ejecutado 1.090.124.030
Proyección al cierre 3.893.016.848

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
- Disponibilidad de los jefes de tienda para el piloto
