<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-08-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Centro de distribución norte

Código: PRY-202

Área dueña: Logística

Patrocinador: Elena Duarte

Gerente de proyecto: Andrés Lozano

Comité: Comité de Arquitectura

Producto asociado: No aplica

Fecha de aprobación: 2025-08-03

Objetivo del negocio

Entregar centro de distribución norte para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Arquitectura el 2025-08-03.

Fechas comprometidas

Fecha

Inicio

2025-08-13

Cierre

2026-04-24

Criterio de éxito

Centro de distribución norte en producción y medido.

Dependencias declaradas

• Ninguna declarada
