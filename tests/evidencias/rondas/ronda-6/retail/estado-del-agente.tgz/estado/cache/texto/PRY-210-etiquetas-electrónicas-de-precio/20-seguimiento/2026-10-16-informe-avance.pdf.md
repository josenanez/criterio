<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-16
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 57%

Lo que pasó en el periodo
- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se levantó un hallazgo de seguridad en los medios de pago
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.058.257.526
Ejecutado 1.968.184.724
Proyección al cierre 3.955.871.985

Riesgos abiertos
- Congelamiento de cambios en temporada alta
