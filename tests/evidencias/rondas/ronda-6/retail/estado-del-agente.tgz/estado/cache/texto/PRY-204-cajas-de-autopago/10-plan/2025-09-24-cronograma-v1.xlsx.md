<!-- origen: PRY-204-cajas-de-autopago/10-plan/2025-09-24-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-01-18 | 2026-01-18 | cerrado
Ambiente de pruebas certificado | 2026-05-05 | 2026-05-05 | cerrado
Integración con el ERP | 2026-08-19 | 2026-08-19 | cerrado
Piloto en tiendas | 2026-12-04 | 2026-12-04 | en curso
Despliegue en la cadena | 2027-03-20 | 2027-03-20 | en curso
