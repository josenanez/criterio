<!-- origen: PRY-204-cajas-de-autopago/00-gobierno/2025-09-24-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Mercadeo
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** María Restrepo
**Comité:** Comité Comercial
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2025-09-24

## Objetivo del negocio

Entregar cajas de autopago para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité Comercial el 2025-09-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-04 |
| Cierre | 2027-03-20 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
