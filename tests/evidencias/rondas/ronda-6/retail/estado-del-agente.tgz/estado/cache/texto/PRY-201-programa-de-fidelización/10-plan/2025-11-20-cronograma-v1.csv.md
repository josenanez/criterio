<!-- origen: PRY-201-programa-de-fidelización/10-plan/2025-11-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-03-03,2026-03-03,cerrado
Ambiente de pruebas certificado,2026-06-05,2026-06-05,cerrado
Integración con el ERP,2026-09-07,2026-09-07,cerrado
Piloto en tiendas,2026-12-10,2026-12-10,en curso
