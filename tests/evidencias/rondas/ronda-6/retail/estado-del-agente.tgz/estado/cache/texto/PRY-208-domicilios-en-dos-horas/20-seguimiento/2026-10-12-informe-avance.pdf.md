<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Domicilios en dos horas
Código: PRY-208
Fecha de corte: 2026-10-12
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 94%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.401.914.037
Ejecutado 459.248.225
Proyección al cierre 2.455.475.855

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Cambio en la regulación de datos personales que puede mover el alcance
