<!-- origen: PRY-209-migración-del-erp/10-plan/2026-10-08-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-11-07 | 2025-11-07 | cerrado
Ambiente de pruebas certificado | 2025-12-20 | 2025-12-20 | cerrado
Integración con el ERP | 2026-02-01 | 2026-02-01 | cerrado
Piloto en tiendas | 2026-03-16 | 2026-03-16 | cerrado
Despliegue en la cadena | 2026-04-28 | 2026-07-07 | cerrado
