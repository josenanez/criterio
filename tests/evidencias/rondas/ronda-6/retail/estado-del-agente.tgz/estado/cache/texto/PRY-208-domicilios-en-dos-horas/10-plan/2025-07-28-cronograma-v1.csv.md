<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2025-07-28-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-11-30,2025-11-30,cerrado
Ambiente de pruebas certificado,2026-03-26,2026-03-26,cerrado
Integración con el ERP,2026-07-19,2026-07-19,cerrado
Piloto en tiendas,2026-11-12,2026-11-12,en curso
