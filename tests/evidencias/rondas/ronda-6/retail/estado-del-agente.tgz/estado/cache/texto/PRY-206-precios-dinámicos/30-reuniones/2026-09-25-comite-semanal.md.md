<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-09-25
**Asistentes:** Beatriz Cuéllar, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-06 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-13 |
| Felipe Arango | Confirmar la fecha 7 | 2026-10-07 |
| María Restrepo | Entregar el punto 8 | 2026-09-29 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-10-08 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-05 |
| Paula Céspedes | Revisar el anexo 11 | 2026-09-24 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-05 |
| Jorge Medina | Aprobar el diseño 13 | 2026-10-04 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 |
| Elena Duarte | Confirmar la fecha 15 | 2026-10-10 |
| Liliana Torres | Entregar el punto 16 | 2026-10-13 |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Jorge Medina): recibido, acta de recibo del 2026-09-25.

## Lo que se dijo

- Liliana Torres dice que ya entregó «aprobar el diseño 5». No se presentó acta.
