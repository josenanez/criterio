<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Tienda en línea

**Fecha:** 2026-10-11
**Asistentes:** Carlos Peña, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 29 | 2026-10-02 |
