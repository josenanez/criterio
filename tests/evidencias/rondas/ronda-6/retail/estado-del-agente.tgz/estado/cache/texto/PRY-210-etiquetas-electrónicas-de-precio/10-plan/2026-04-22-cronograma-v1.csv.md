<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2026-04-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-06-25,2026-06-25,cerrado
Ambiente de pruebas certificado,2026-08-18,2026-08-18,cerrado
Integración con el ERP,2026-10-11,2026-10-11,en curso
Piloto en tiendas,2026-12-04,2026-12-04,en curso
