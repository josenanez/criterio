<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2025-08-13-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pronóstico de demanda

Código: PRY-211

Área dueña: Logística

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Mauricio Pérez

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2025-08-13

Objetivo del negocio

Entregar pronóstico de demanda para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité Comercial el 2025-08-13.

Fechas comprometidas

Fecha

Inicio

2025-08-23

Cierre

2026-03-12

Criterio de éxito

Pronóstico de demanda en producción y medido.

Dependencias declaradas

• Ninguna declarada
