<!-- origen: PRY-207-marca-propia-de-alimentos/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Marca propia de alimentos

**Fecha:** 2026-10-11
**Asistentes:** Mauricio Pérez, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 5 | 2026-09-30 |
