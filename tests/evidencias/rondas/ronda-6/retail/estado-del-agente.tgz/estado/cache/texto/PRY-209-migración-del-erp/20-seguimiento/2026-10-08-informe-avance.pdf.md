<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-10-08
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 82%

Lo que pasó en el periodo
- La validación con dos tiendas se extendió una semana por el conteo de inventario

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.112.039.951
Ejecutado 1.478.959.765
Proyección al cierre 3.336.392.773

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
