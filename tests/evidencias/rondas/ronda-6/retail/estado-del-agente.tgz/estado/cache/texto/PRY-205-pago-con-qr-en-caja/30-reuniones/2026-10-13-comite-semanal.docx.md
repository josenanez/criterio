<!-- origen: PRY-205-pago-con-qr-en-caja/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Pago con QR en caja

Fecha: 2026-10-13

Asistentes: Felipe Arango, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 9

2026-10-26

Laura Vélez

Entregar el punto 6

2026-11-08
