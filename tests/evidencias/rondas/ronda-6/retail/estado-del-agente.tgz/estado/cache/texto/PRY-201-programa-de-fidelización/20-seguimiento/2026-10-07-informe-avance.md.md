<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-07-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-07
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **39%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.429.539.814 |
| Ejecutado | 1.031.174.953 |
| Proyección al cierre | 3.226.390.577 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
