<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-10-09
**Asistentes:** Andrés Lozano, Diana Molina, Elena Duarte, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-04 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-11-01 |
| María Restrepo | Entregar el punto 8 | 2026-10-20 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-30 |
| Paula Céspedes | Revisar el anexo 11 | 2026-10-18 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-30 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 |
| Elena Duarte | Confirmar la fecha 15 | 2026-10-28 |
| Liliana Torres | Entregar el punto 16 | 2026-11-03 |
| Andrés Lozano | Enviar el documento 17 | por definir |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-19 |
| Paula Céspedes | Revisar el anexo 19 | 2026-10-29 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-13 |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-25 |
| Óscar Ramírez | Actualizar la matriz 22 | por definir |
| Paula Céspedes | Confirmar la fecha 23 | por definir |
| María Restrepo | Entregar el punto 24 | 2026-10-21 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Felipe Arango): recibido, acta de recibo del 2026-10-09.
- Aprobar el diseño 13 (Jorge Medina): recibido, acta de recibo del 2026-10-09.
