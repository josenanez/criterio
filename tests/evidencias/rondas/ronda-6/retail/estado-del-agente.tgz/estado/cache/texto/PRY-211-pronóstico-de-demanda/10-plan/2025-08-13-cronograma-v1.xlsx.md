<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2025-08-13-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-10-02 | 2025-10-02 | cerrado
Ambiente de pruebas certificado | 2025-11-11 | 2025-11-11 | cerrado
Integración con el ERP | 2025-12-22 | 2025-12-22 | cerrado
Piloto en tiendas | 2026-01-31 | 2026-01-31 | cerrado
Despliegue en la cadena | 2026-03-12 | 2026-03-12 | cerrado
