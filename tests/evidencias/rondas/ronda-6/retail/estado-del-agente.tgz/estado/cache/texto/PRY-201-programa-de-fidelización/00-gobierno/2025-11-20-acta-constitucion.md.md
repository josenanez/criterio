<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-11-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Logística
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Expansión
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2025-11-20

## Objetivo del negocio

Entregar programa de fidelización para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Expansión el 2025-11-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-30 |
| Cierre | 2026-12-10 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
