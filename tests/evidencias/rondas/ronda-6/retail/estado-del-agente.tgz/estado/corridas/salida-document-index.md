## Carpeta al 2026-10-16

**Documentos:** 82 · **Sin cambio:** 82 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
22 citas, todas de PRY-206, en la ficha `estado/PRY-206-precios-dinámicos/records/PRY-206.json`.

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-206 | identity.code, name, business_area, sponsor, manager, committee; plan.start_date, scope_summary, exclusions; money.approved | 00-gobierno/2025-11-15-acta-constitucion.docx |
| PRY-206 | declared.status, declared.progress_pct; money.committed, executed, projection | 20-seguimiento/2026-10-16-informe-avance.pdf |
| PRY-206 | plan.end_date; plan.milestones[0..4].state | 10-plan/2025-11-15-cronograma-v1.csv |
| PRY-206 | vendors[0].invoiced | 20-seguimiento/2026-09-21-factura-ct-914.pdf |

Los documentos citados **sí existen** en `documentos/proyectos/PRY-206-precios-dinámicos/`. Lo que no resuelve es la ruta: esta ficha cita sin el prefijo `PRY-206-precios-dinámicos/`, y las demás fichas (`estado/records/PRY-2xx.json`, incluida `estado/records/PRY-206.json`) sí lo llevan. Es una ficha duplicada con ruta relativa, no un documento borrado. No corregí nada: queda para decidir si se corrige la ruta o se retira el duplicado.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
No hay nada que releer, así que no hace falta `/portfolio-scan`. Queda pendiente resolver la ficha duplicada de PRY-206.
