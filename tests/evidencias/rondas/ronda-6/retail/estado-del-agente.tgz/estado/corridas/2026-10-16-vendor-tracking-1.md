# Corrida del 2026-10-16 · vendor-tracking

13 proyectos · 32 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Proveedor CT-599 de PRY-205: FV-1599 (155.660.032 COP) con la mitad sin acta de recibo (Soporte del primer trimestre); 2 entregables tardíos. No pude decir: vigencia, preaviso y vencimiento del contrato, ni si FV-1599 se pagó.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Proveedores — PRY-205 Pago con QR en caja, al 2026-10-16

**Sale de:** contrato CT-599 (`00-gobierno/2025-09-22-contrato-ct-599.md`), acta de constitución (`00-gobierno/2025-09-26-acta-constitucion.md`), acta de recibo de la bolsa de horas (`20-seguimiento/2026-03-23-acta-recibo-ct-599-bolsa-de-horas-de-desarrollo.md`), acta de recibo del 2026-10-04 (`20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf`), factura FV-1599 (`20-seguimiento/2026-08-28-factura-ct-599.pdf`), comité del 2026-10-13 (`30-reuniones/2026-10-13-comite-semanal.docx`) y la salida de `portafolio.py compute` al 2026-10-16. Las cifras derivadas se copian de esa salida.

### Retail Andino Consultores S.A.S. — contrato CT-599
**Firma:** 2025-09-22 · **Vigencia, preaviso de no renovación y vencimiento:** el contrato no los declara (ver «Sin dato»).
**Condición de pago (contrato):** cada entregable se factura contra acta de recibo firmada por el gerente del proyecto (Felipe Arango, según el acta de constitución).

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2025-12-25 · 77.830.016 COP | `pending` (el contrato dice «en curso») — **295 días de atraso** | Ninguna | No consta |
| Bolsa de horas de desarrollo | 2026-03-15 · 77.830.016 COP | `accepted` | Acta de recibo 2026-03-23, Felipe Arango | Dentro de FV-1599 (ver abajo) |
| Configuración del catálogo | 2026-06-04 · 77.830.016 COP | `pending` — **134 días de atraso** | Ninguna | No consta |
| Soporte del primer trimestre | 2026-08-23 · 77.830.016 COP | `accepted` según el contrato | **Ninguna** | Dentro de FV-1599 (ver abajo) |

Totales (script): 4 entregables, 2 aceptados, 2 tardíos, 1 aceptado sin evidencia. Facturado: **155.660.032 COP**, que es 2 × 77.830.016.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Soporte del primer trimestre | «recibido»; se factura contra acta firmada | No hay acta de recibo de este entregable en la carpeta. Su fecha era 2026-08-23 y la factura es del 2026-08-28 | Contrato CT-599; FV-1599 |
| Factura FV-1599 por 155.660.032 COP | Dos entregables aceptados = 155.660.032 COP | El valor cuadra con dos entregables, pero la factura dice solo «Entregables del contrato CT-599» y no los nombra. Solo la bolsa de horas tiene acta; el importe sustentado por acta es 77.830.016 COP y los otros 77.830.016 COP no tienen sustento | FV-1599; acta 2026-03-23 |
| Licenciamiento de la plataforma | Estado «en curso» | La ficha lo registra `pending` y no hay evidencia de entrega | Contrato CT-599 |
| Acta del 2026-10-04 «Diseño de la experiencia aprobado» | No es un entregable de CT-599 | Es un acta de recibo firmada por Felipe Arango, pero no corresponde a ninguna de las cuatro líneas del contrato. **No sustenta** ningún entregable del proveedor ni la factura | Contrato CT-599; acta 2026-10-04 |

Lectura: no hay prueba de pago sin entrega. Hay una factura radicada en cuentas por pagar con la mitad de su valor sin acta que la respalde, mientras dos entregables llevan meses vencidos y sin facturar.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Soporte del primer trimestre | `accepted` (contrato) | Fecha comprometida 2026-08-23 |

### Compromisos del proveedor vencidos
Ninguno. El comité del 2026-10-13 registra dos compromisos (Óscar Ramírez, «punto 9», para 2026-10-26; Laura Vélez, «punto 6», para 2026-11-08), ambos con fecha futura. El documento no dice que Óscar Ramírez pertenezca al proveedor, así que no los cuento como compromisos del proveedor. Vencidos según el script: 0.

### Sin dato
- **Vigencia, fecha de terminación, renovación automática y preaviso de CT-599:** el contrato en la carpeta no los trae. No puedo decir si hay un preaviso por vencer. El proyecto cierra el 2026-10-06 según el acta de constitución, hace 10 días, y el hito «Despliegue en la cadena» está vencido; con licenciamiento y catálogo sin entregar, conviene revisar el texto completo del contrato.
- **Entregables del contrato sin evidencia de pago:** la carpeta no tiene comprobante de pago de FV-1599, solo que está radicada. No sé si ya se pagó.
- **Contexto, no hallazgo de proveedor:** el informe de avance del 2026-10-06 declara verde y 73 %. El script marca ese estado como no respaldado por tres señales: hitos declarados cumplidos sin evidencia (3), hito vencido (1) y entregable de proveedor tardío.

### Qué sigue
FV-1599 tiene 77.830.016 COP sin acta que lo sustente. Sugiero llevarlo al comité del 2026-10-23, antes de aprobar el pago, y pedir a Felipe Arango el acta de recibo de «Soporte del primer trimestre», o su ausencia por escrito. ¿Lo preparo como punto de comité con `/steering-pack`?

---
**Rigor:** cifras copiadas de `portafolio.py compute` (2026-10-16). Cada línea cita su documento. Lo que no está en la carpeta se declara arriba como sin dato. Borrador de trabajo: la verificación contra los documentos originales es suya.
