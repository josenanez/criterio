# Corrida del 2026-10-16 · project-closure

13 proyectos · 32 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

No se generó acta de cierre: el proyecto sigue en marcha (55% declarado, verde) con fecha de cierre 2026-04-24 vencida y sin nueva fecha. Se dijo que no se sabe si terminó, ni evidencia de criterio de éxito, hitos, dolientes de RAID ni fecha reprogramada.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Cierre — PRY-202 Centro de distribución norte — 2026-10-16

**Sale de:** ficha `estado/records/PRY-202.json` y de dos documentos: `00-gobierno/2025-08-03-acta-constitucion.docx` y `20-seguimiento/2026-10-16-informe-avance.pdf`. Cifras derivadas copiadas de `portafolio.py compute`.

**Veredicto: el proyecto no está en condiciones de cerrarse, y la documentación no dice que haya terminado.** No hay declaración de término de nadie. El único informe (corte 2026-10-16) lo presenta en marcha, en verde, con 55 % de avance. No genero acta de cierre; dejo lo que se puede decir hoy.

### Contra lo comprometido
**Criterio de éxito:** "Centro de distribución norte en producción y medido." (acta, 2025-08-03, aprobada por el Comité de Arquitectura).
**Se cumplió:** no se puede determinar. Ningún documento muestra producción ni medición. El avance declarado es 55 % (declaración del gerente, no evidencia).

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | No se puede determinar | Ninguna. El acta lo nombra sin describirlo |
| Componente 2 | No se puede determinar | Ninguna |
| Componente 3 | No se puede determinar | Ninguna |

No hay hitos en la ficha ni cronograma en la carpeta (solo `00-gobierno` y `20-seguimiento`).

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta, sin precisar cuál) | Acta de constitución | 2025-08-03 |

No hay recortes de alcance registrados ni control de cambios (0 cambios en la ficha).

### Números finales (parciales, no son finales)
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-04-24 | 2026-04-24 (sin replanificaciones) | Sin dato: no ha cerrado | 0 días según compute, porque no hay otra fecha contra la que medir |
| Presupuesto aprobado (COP) | 4.200.000.000 | 4.200.000.000 | — | — |

Replanificaciones registradas: 0.

Presupuesto al corte 2026-10-16 (COP): comprometido 2.207.780.876 (52,6 %), ejecutado 1.090.124.030 (26,0 %), disponible real 1.992.219.124, proyección al cierre 3.893.016.848 (−7,3 % sobre lo aprobado).

**Lo que esto no cuenta:** el 0 de desviación en fecha es un artefacto. La fecha comprometida (2026-04-24) ya pasó, el informe es del 2026-10-16 y el proyecto sigue abierto con 55 %. El informe dice que "se reprogramó el despliegue" pero **no da la nueva fecha**, y no hay una línea base nueva ni un cambio aprobado que lo respalde. Hay un atraso real contra la fecha original que el sistema no mide. `compute` no levantó alerta (`alerts: []`) y el estado declarado sigue "verde". No calculo los días de atraso porque `compute` no los entrega; hace falta la fecha vigente de cierre.

### RAID al cierre
**Materializados:** el informe no lo dice. Sí hay una incidencia abierta: el despliegue se reprogramó por el congelamiento de fin de año (desde 2026-10-16, sin nueva fecha ni responsable).
**No materializados:** ninguno confirmado.
**Abiertos, con doliente:** ninguno tiene doliente. Hay dos riesgos abiertos sin responsable, probabilidad ni fecha (cambio en la regulación de datos personales que puede mover el alcance; disponibilidad de jefes de tienda para el piloto) y la incidencia anterior. Sin doliente con nombre no está cerrado.

### Lecciones
Ninguna entra. La única lección que sugieren los documentos es que el despliegue se reprogramó por el congelamiento de temporada, pero sin fecha de pedido ni de efecto no se puede anclar. El informe tampoco da fecha ni efecto medido.

### Sin dato
- Si el proyecto terminó, y quién lo declaró.
- Fecha vigente de cierre y quién aprobó la reprogramación del despliegue.
- Evidencia de producción y medición (criterio de éxito).
- Descripción y estado de los Componentes 1, 2 y 3; hitos y cronograma.
- Qué cubre "otro proyecto" en el fuera de alcance.
- Dolientes de los dos riesgos y de la incidencia.
- Producto asociado ("No aplica" en el acta), autoridad y fase.
- Los datos de identidad son de 2025-08-03 (14 meses), y no hay evidencia independiente en la carpeta: la ficha cuenta 0 fuentes de evidencia y 3 declaraciones.

### Después
No ofrezco mover a `archivo/` ni congelar la ficha: el proyecto sigue activo según su último informe. Si se quiere cerrar por decisión y no por cumplimiento, hay que registrar quién decide, con el 55 % como entregado y el resto como alcance abandonado o trasladado.

---
**Rigor:** sin cierre declarado, sin evidencia de entregables y sin cronograma. Las cifras de dinero vienen de la declaración del gerente (informe de avance), no de un registro contable. Esto es un borrador de trabajo; la verificación es de la persona que lo lea.
