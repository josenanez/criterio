# Producto «venta en línea» al 2026-10-16

Sale de las fichas en `estado/records`, recalculadas con `portafolio.py compute` al 2026-10-16. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

**«venta en línea» tiene un solo proyecto: PRY-200 Tienda en línea.** La vista por producto no agrega nada aquí: no hay suma entre proyectos, ni dependencias internas, ni fecha que escoger entre varias. Lo que sigue es el estado de ese proyecto, sin armar sección de producto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| venta en línea | 1 (PRY-200) | 1 (5 alertas) | 2026-12-11 | COP 6.800.000.000 | COP 4.799.233.410 |

**Lo que hay que ver (PRY-200):**
- El informe de avance del 2026-10-16 declara **verde**. Las señales lo contradicen: avance contra plan, hitos «cumplidos» sin evidencia y un compromiso vencido.
- Avance declarado 46,0 %; el plan sustenta entre 75 y 100 % (3 de 4 hitos cumplidos): 29,0 puntos por detrás.
- Hito «Ambiente de pruebas certificado» (vence 2026-04-27, 172 días) declarado cumplido sin evidencia.
- Hito «Integración con el ERP» (vence 2026-08-19, 58 días) declarado cumplido sin evidencia.
- Compromiso vencido: Javier Hoyos, «Entregar el punto 29», vencía 2026-10-02 (14 días). Fuente: PRY-200-tienda-en-línea/30-reuniones/2026-10-11-comite-semanal.md.
- Dinero: ejecutado COP 2.855.071.580 (42,0 %); comprometido 70,6 %; proyección COP 6.930.747.093 (1,9 % sobre lo aprobado); disponible real COP 2.000.766.590. Tiene las cuatro cifras.
- Cronograma: sin desviación contra la línea base (0 días, 0 replanificaciones). Sin proveedores ni cambios registrados.

**Dependencias internas:** ninguna (no hay otro proyecto del producto, y la ficha no declara dependencias).

**Fecha comprometida del producto:** 2026-12-11, de PRY-200.

**Lo que no sé:**
- Las 3 fuentes del proyecto son declaraciones y 17 no están marcadas; 0 son evidencia. Por eso los hitos no se pueden confirmar ni descartar.
- Faltan autoridad (`identity.authority`) y fase (`identity.phase`). Ocho campos de identidad y plan tienen 13 meses (fuente 2025-09-01).

### Proyectos sin producto declarado
Seis proyectos no declaran producto, así que nadie puede responder por el conjunto al que sirven: PRY-202 Centro de distribución norte, PRY-203 Reposición automática, PRY-206 Precios dinámicos, PRY-209 Migración del ERP, PRY-210 Etiquetas electrónicas de precio, PRY-211 Pronóstico de demanda. La ficha no trae el área dueña en la salida del cálculo; no la invento.

Es un hallazgo de gobierno. PRY-199 sí tiene producto (PRD-299), pero el código no coincide con ningún nombre de producto de los demás: dilo si PRD-299 es un identificador y no un nombre.

**Después:** como no hay dependencias internas, no hay nada que llevar al comité de producto como decisión conjunta. Lo que sí merece el comité del 2026-10-23 es el verde contradicho de PRY-200.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cifras copiadas de `portafolio.py compute` (as_of 2026-10-16); la verificación contra los documentos citados es suya. Sin evidencia independiente de los hitos declarados.
