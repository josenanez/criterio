Sale de la ficha `estado/records/PRY-203.json` (actualizada 2026-10-16), del acta de constitución (2025-07-08), del cronograma v1 y del informe de avance de corte 2026-10-15. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-16.

## Solicitud de cambio — PRY-203 Reposición automática — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días. Lo leo como el hito «Despliegue en la cadena» (2026-12-30), que es el cierre del proyecto; si «salida a producción» significa otra cosa, el cálculo cambia.
**Quién lo pide:** no consta en los documentos; el pedido llegó sin solicitante.
**Por qué:** los documentos dan dos causas, ambas en el informe del 2026-10-15: el congelamiento de temporada de fin de año y dos semanas perdidas por la rotación de un desarrollador clave. Ningún documento enlaza esas causas con los 30 días pedidos.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta) | Sin cambio declarado | 0 declarado |
| Tiempo | Cierre 2026-12-30 (línea base 1) | 2027-01-29 | +30 días |
| Costo | Aprobado 4.200.000.000 COP; proyección 4.057.825.880 COP | No estimado | Sin cifra; margen contra lo aprobado: 142.174.120 COP |

Alcance y costo no tienen impacto declarado. Un retraso de 30 días con el mismo alcance y el mismo presupuesto lo absorbe alguien: el equipo en horas no pagadas, o la calidad del despliegue. Nadie lo ha dicho. El costo de un mes más de equipo no está en ningún documento, así que no lo calculo.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`, 30 días) no alcanza a ningún proyecto, ni directa ni indirectamente. | — |

Esto se sostiene en que PRY-203 no declara dependencias: el acta dice «Ninguna declarada». No prueba que no existan. Un sistema de reposición automática tiene que tocar el ERP (el hito «Integración con el ERP» está marcado como cumplido, con la evidencia vacía) y otros proyectos del portafolio. Hay que confirmarlo con Andrés Lozano antes de decir que el cambio no afecta a nadie.

Sí se mueve un hito: «Despliegue en la cadena» (2026-12-30, a 75 días). No sé cuántos días se mueve cada actividad intermedia: la ficha no tiene holgura por actividad.

### Quién decide
**Autoridad requerida:** no determinable. La autoridad no está declarada en ningún documento (`identity.authority` sin encontrar).
**Según:** el acta nombra al Comité de Cadena de Abastecimiento como el que aprobó presupuesto y acta, pero no fija un umbral de cambio ni dice quién aprueba cambios de fecha.
**Va a comité:** sí, por defecto. Sin autoridad delegada, lo único con respaldo documental es el comité que aprobó la línea base. El próximo comité es el 2026-10-23.

Ese vacío es el hallazgo de fondo: no hay regla escrita que diga si este cambio lo decide el gerente, el patrocinador (Javier Hoyos) o el comité.

### Hallazgos sobre el estado actual
1. **El cambio ya ocurrió sin registro.** El informe del 2026-10-15 dice que el despliegue se reprogramó por el congelamiento de temporada. La ficha mantiene el cronograma en v1 con la misma fecha, y `changes` está vacío. Se está reportando contra una fecha que quien reporta ya dejó de usar.
2. **Estado «Verde» sin sustento.** Se declara verde con 49% de avance, cuatro de cinco hitos marcados «cumplido» sin evidencia, una reprogramación y dos semanas perdidas. Con la fecha en discusión, verde es difícil de sostener.
3. **El 2026-12-30 cae dentro del congelamiento de fin de año.** Si el congelamiento es real, la fecha de la línea base ya no era viable, y el mover 30 días no resolvería nada si el congelamiento se extiende a enero. La fecha de fin del congelamiento no está en los documentos.
4. **Los riesgos del informe no tienen dueño, probabilidad ni fecha**, y «concentración del conocimiento en una sola persona» coincide con la causa del atraso ya ocurrido.

### Si no se aprueba
El proyecto sigue con cierre el 2026-12-30 y estado verde, pese a que su propio informe dice que el despliegue ya se reprogramó. O se despliega dentro del congelamiento, o el atraso se produce sin quedar registrado, que es peor.

### Si se aprueba
Línea base 2 — cierre 2027-01-29 · presupuesto 4.200.000.000 COP (sin cambio declarado) · motivo: congelamiento de temporada de fin de año y pérdida de dos semanas por rotación (texto del informe del 2026-10-15; falta el documento que apruebe).
Desviación acumulada contra la línea base original: +30 días · costo sin estimar. Contra la línea base 1 la desviación es la misma, porque es la primera replanificación (conteo de replanificaciones: 0 → 1).

Condiciones para registrarla: documento de aprobación de quien tenga autoridad, estimación del costo del mes adicional, y confirmación de dependencias.

### Lo que no sé
- Quién pide el cambio y quién tiene autoridad para aprobarlo.
- Si «salida a producción» es el hito «Despliegue en la cadena».
- El costo del mes adicional.
- Si PRY-203 tiene dependencias no declaradas.
- Cuándo termina el congelamiento de temporada.
- Si los hitos «cumplidos» tienen evidencia: ninguno la tiene en la ficha.

### Siguiente paso
Llevarlo al comité del 2026-10-23 con el costo estimado y las dependencias confirmadas. No registro la línea base 2: no hay aprobación.
