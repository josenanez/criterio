# Corrida del 2026-10-16 · status-report

13 proyectos · 29 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Informe de PRY-205: verde declarado (2026-10-06) contradicho por hito de despliegue vencido, 3 hitos cumplidos sin evidencia y 2 entregables del proveedor atrasados. Dije que no sé: autoridad, fase, evidencia de los hitos, y qué son los puntos 6 y 9 del comité.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

_Sale de la ficha `estado/records/PRY-205.json`, actualizada el 2026-10-16; cifras recalculadas con `compute` al 2026-10-16. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-16._

## PRY-205 · Pago con QR en caja — estado al 2026-10-16

**Declara el gerente (Felipe Arango):** verde · 73% · al 2026-10-06 (hace 10 días; informe de avance, 2026-10-06)
**Sustento documental:** contradicho. Ninguna cifra de la ficha viene marcada como evidencia (0 de 21 campos; 3 son declaración del gerente y 18 sin marcar).
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `vendor_deliverable_late` (alerta `declared_vs_evidence`).
**Último documento:** 2026-10-13 (3 días de silencio) · **Última reunión:** 2026-10-13 (Comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-06 | 2026-10-06 | 0 días contra la original y contra la vigente. La fecha ya pasó y el hito de cierre sigue pendiente. |
| Presupuesto | COP 800.000.000 (aprobado) | COP 800.000.000 | Proyección al cierre COP 783.938.369: -2,0% sobre lo aprobado. Comprometido COP 688.496.147 (86,1%), ejecutado COP 428.207.016 (53,5%), disponible real COP 111.503.853. |

Replanificaciones: 0. No hay solicitudes de cambio registradas. La fecha de cierre no se movió, pero el despliegue no ocurrió.

Avance: el declarado es 73%. Con 4 de 5 hitos marcados como cumplidos, el plan sustenta entre 80% y 100%. La diferencia es de 7,0 puntos y no es la contradicción: de esos 4 hitos, 3 no tienen evidencia.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-12-18 | 2025-12-18 | cumplido | Acta de recibo del 2026-10-04 |
| Ambiente de pruebas certificado | 2026-03-01 | 2026-03-01 | cumplido (declarado) | **Ninguna** (229 días desde la fecha) |
| Integración con el ERP | 2026-05-13 | 2026-05-13 | cumplido (declarado) | **Ninguna** (156 días) |
| Piloto en tiendas | 2026-07-25 | 2026-07-25 | cumplido (declarado) | **Ninguna** (83 días) |
| Despliegue en la cadena | 2026-10-06 | 2026-10-06 | pendiente, **vencido hace 10 días** | n/a |

### Dónde no coincide
- **Verde frente a hito vencido.** El informe del 2026-10-06 declara verde. Ese mismo día vencía el despliegue en la cadena, que sigue pendiente (cronograma v1, 2025-09-26). El informe no menciona el despliegue.
- **Verde frente a prueba de carga fallida.** El mismo informe dice que la prueba de carga de temporada no alcanzó el umbral pactado y se repite. Está en la ficha como incidencia desde el 2026-10-06, sin responsable.
- **Tres hitos «cumplidos» sin un solo documento** que lo pruebe: ambiente de pruebas, integración con el ERP y piloto en tiendas. Es lo que sostiene el 73%.
- **Proveedor (Retail Andino Consultores, CT-599).** Hay 2 de 4 entregables aceptados y 2 atrasados y pendientes: Licenciamiento de la plataforma (vencía 2025-12-25, 295 días) y Configuración del catálogo (vencía 2026-06-04, 134 días). «Soporte del primer trimestre» (vencía 2026-08-23) figura aceptado **sin acta de recibo**. La factura del 2026-08-28 por COP 155.660.032 coincide con los dos entregables aceptados. Uno de ellos no tiene evidencia de aceptación.
- **Fechas del hito de diseño.** Su fecha base era 2025-12-18 y el acta de recibo es del 2026-10-04. La ficha no dice si hubo atraso. No lo juzgo.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: cambio en la regulación de datos personales que puede mover el alcance. Sin probabilidad, responsable ni fecha de último movimiento. Solo consta en el informe del 2026-10-06.
- Incidencia: la prueba de carga no alcanzó el umbral y se repite. Abierta desde el 2026-10-06 (10 días), sin responsable.

**Compromisos vencidos:** ninguno. Hay dos abiertos del comité del 2026-10-13: Óscar Ramírez «Entregar el punto 9» para el 2026-10-26, y Laura Vélez «Entregar el punto 6» para el 2026-11-08. El acta no dice a qué se refieren los puntos 6 y 9. Óscar Ramírez no figura entre los asistentes.

**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad del gerente (`identity.authority`) y fase (`identity.phase`): no están en ningún documento.
- Evidencia de cumplimiento de 3 hitos y del entregable «Soporte del primer trimestre».
- Probabilidad, responsable y fecha de movimiento del riesgo; responsable de la incidencia.
- Contenido de los puntos 6 y 9 del comité del 2026-10-13. El acta lista «Avance» y «Compromisos» sin detalle.
- Línea base de presupuesto distinta de la aprobada: no hay.
- 11 campos de identidad y plan vienen del acta de constitución del 2025-09-26 (13 meses) y superan el umbral de 12 meses.

### Después
No hay desviación de fechas ni de costo por encima del umbral, pero sí un verde contradicho y un hito de cierre vencido. Puedo preparar el punto de comité con `/steering-pack`. Para saber si los tres hitos sin evidencia se cumplieron, hace falta pedirle a Felipe Arango los documentos de cierre.

---
Criterio · criterio-portfolio 0.3.12 · términos v1.1 · ficha PRY-205 actualizada el 2026-10-16, informe del gerente del 2026-10-06 · campos inciertos: autoridad, fase y los 11 campos de más de 12 meses · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
