# Rostrum — para mirarlo un rato

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16; comprobante en `.criterio/terminos/`). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato trae la cita de su documento y la verificación es suya. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Forma elegida:** «para mirarlo un rato» (respuesta sugerida: empezar por la primera forma). Se levanta, se mira, se apaga con Ctrl-C. No hay enlace estable para el patrocinador.

**Informe:** carpeta `reportes/` (13 proyectos, 7 productos, decisiones). Estado: `estado/`. Configuración: `.criterio/portafolio/config.json`. Organización: «Portafolio de proyectos retail».

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea la petición en `estado/peticiones/`), no autentica, no manda correos. El servidor no puede correr el agente: las peticiones esperan a que `due` las cuente.

**Cierre:** el enlace `http://127.0.0.1:8787/` solo sirve en este equipo, para quien esté sentado aquí; no se le pasa a nadie. El informe es del 2026-10-16 y se desactualiza con el siguiente barrido o cuando cambien los documentos; la portada muestra su fecha. Para un enlace que el patrocinador pueda abrir mañana hay que pasar a «que quede corriendo» (host, puerto y control de acceso de la organización).
