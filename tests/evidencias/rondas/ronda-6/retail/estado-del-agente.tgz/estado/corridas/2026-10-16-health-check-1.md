# Corrida del 2026-10-16 · health-check

13 proyectos · 89 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Diagnóstico de PRY-209 desde 9 documentos: 7 sostenidas, 9 sin sustento, 5 contradichas. Estado verde y 82 % no se sostienen; autoridad y autorización de CC-01 no están; factura sin actas de recibo. Dijo que no sabe si el proyecto está en verde, quién autorizó CC-01 ni qué hubo entre 2025-09 y 2026-08.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-209 Migración del ERP · 2026-10-16

**Leí:** 9 documentos · 2025-09-09 a 2026-10-08 · formatos: .md (3), .pdf (3), .xlsx (2), .docx (1). Además busqué menciones del proyecto en las minutas de los otros 12 proyectos del portafolio: no hay ninguna.
**No pude leer:** nada quedó sin leer. Los dos .xlsx se leyeron desde su XML (sin fórmulas ni hojas adicionales: una sola hoja de 5 hitos cada uno).

### Dictamen
**Sostenido:** 7 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 5

Desde esta carpeta se puede afirmar quién es el patrocinador y el gerente, cuánto se aprobó en 2025-09-16, cuál era la fecha de cierre original (2026-04-28), que el ambiente de pruebas se recibió el 2026-10-04 y que se radicó una factura del proveedor por 275.224.201 COP. No se puede afirmar que el proyecto esté en verde, ni que esté al 82 %, ni que los cinco hitos estén cerrados, ni que el proveedor haya entregado lo que se le facturó. Los únicos tres documentos que sostienen el estado son declaraciones del gerente (informe de avance, cronograma v2, solicitud CC-01); ninguno es evidencia independiente. El "verde" declarado el 2026-10-08 no sobrevive a cinco señales que el propio informe no menciona (ver Contradicho).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Mauricio Pérez | acta de constitución, 2025-09-16 |
| Gerente | Felipe Arango | acta de constitución, 2025-09-16 |
| Autoridad declarada | **No está declarada.** El acta no dice qué puede aprobar el gerente en tiempo, costo o alcance, ni quién aprueba cambios. | acta de constitución (ausencia) |
| Comité | Comité de Transformación Digital; ni integrantes ni quórum. La única minuta (2026-10-05) lista como asistentes a Felipe Arango y Mauricio Pérez. | acta; minuta 2026-10-05 |

Sin autoridad declarada no hay desviación aprobada: la ampliación CC-01 dice "Autorizada por el comité", sin nombre de quien decidió ni fecha, y ninguna minuta de la carpeta la trata (la única es del 2026-10-05, tres días antes de que se solicitara). Producto asociado: "No aplica". Fase: no declarada.

### Contra el plan
- **Línea base original (v1):** aprobada 2025-09-16 con el acta, cierre 2026-04-28 (acta y cronograma v1 coinciden).
- **Línea base vigente (v2):** cronograma fechado 2026-10-08, cierre 2026-07-07, por CC-01 (+70 días). Motivo: ampliación de alcance "sin detalle" (la solicitud solo dice "Ampliación de alcance"). La aprobación de v2 no tiene aprobador ni fecha en ningún documento; la fecha 2026-10-08 es la del archivo.
- **Desviación (script):** 70 días contra la original, 32,7 %, sobre el umbral de 10 %; 0 días contra la vigente. La v1 se conserva, no se borró.
- **Hallazgo de fechas:** al solicitarse CC-01 (2026-10-08), tanto el cierre original (2026-04-28) como el nuevo (2026-07-07) ya habían pasado. La línea base se movió después de vencida, no antes.
- **Hallazgo de cronograma v1:** el archivo lleva fecha 2025-09-16 y marca los cinco hitos como "cerrado", incluidos hitos de 2026. O el archivo se editó después del nombre que lleva, o su columna de estado no es de esa fecha. No se puede saber cuál.
- Costo de CC-01: 140.000.000 COP adicionales. El presupuesto aprobado no se actualizó en ningún documento, así que no hay presupuesto vigente distinto de 3.300.000.000.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-11-07 | 343 | Acta o aprobación del diseño |
| Integración con el ERP | 2026-02-01 | 257 | Acta de pruebas de integración / recibo |
| Piloto en tiendas | 2026-03-16 | 214 | Informe o acta de cierre del piloto |
| Despliegue en la cadena | 2026-07-07 (vigente; original 2026-04-28) | 101 | Acta de puesta en producción; criterio de éxito "en producción y medido" |

Los cuatro figuran "cerrado" en el cronograma v2 y ninguno tiene documento de respaldo. El quinto, *Ambiente de pruebas certificado* (fecha 2025-12-20), sí tiene acta de recibo, pero firmada el 2026-10-04.

Entregables del proveedor Integra Comercio (CT-404), vencidos y sin acta de recibo:
| Entregable | Fecha contrato | Días | Estado en contrato |
|---|---|---|---|
| Licenciamiento de la plataforma | 2025-12-13 | 307 | pendiente |
| Bolsa de horas de desarrollo | 2026-03-02 | 228 | en curso |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 2.112.039.951 (64,0 %) | 1.478.959.765 (44,8 %) | 3.336.392.773 (1,1 % sobre lo aprobado) | 1.187.960.049 |

Moneda: COP. Comprometido, ejecutado y proyección salen solo del informe de avance (declaración), sin desglose ni soporte en la carpeta. Facturado al proveedor: 275.224.201 COP (FV-1404, 2026-08-31); aceptado contra acta: 0. No calculo la proyección contra el aprobado más CC-01 porque ningún documento fija ese presupuesto.

### Lo que se dijo y nadie registró
No hay registro RAID en la carpeta. Lo que aparece suelto en documentos:
- **Riesgo** (informe 2026-10-08): "El proveedor no ha confirmado la fecha de la última entrega". Sin dueño, probabilidad, impacto ni fecha. Además contradice que todos los hitos estén cerrados.
- **Incidencia** (informe): "La validación con dos tiendas se extendió una semana por el conteo de inventario". No es un riesgo, ya ocurrió; no está registrada y es incompatible con un piloto y un despliegue ya cerrados.
- **Compromiso** (minuta 2026-10-05): Javier Hoyos, "Entregar el punto 33", fecha "por definir". Sin fecha no puede vencer ni verificarse. Javier Hoyos no figura entre los asistentes y "punto 33" no resuelve a ningún documento.
- **Dependencia:** el acta dice "Ninguna declarada", pero el proyecto depende del proveedor Integra Comercio (CT-404) y de "lo que otro proyecto cubre" (exclusión sin detalle).
- Tema "Avance" de la minuta: sin contenido registrado.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado "verde" | Informe 2026-10-08: verde | Contrato CT-404 (dos entregables vencidos 307 y 228 días sin recibo), factura sin entrega, desviación de 70 días y el riesgo y la incidencia del propio informe |
| Avance 82 % | Informe 2026-10-08: 82 % | Cronograma v2, misma fecha: 5 de 5 hitos cerrados (el plan sostiene 100 %; diferencia de 18 puntos) |
| Despliegue en la cadena cerrado (2026-07-07) | Cronograma v2: cerrado | Informe 2026-10-08: validación con tiendas aún en curso y última entrega del proveedor sin fecha |
| Ambiente de pruebas certificado cerrado el 2025-12-20 | Cronogramas v1 y v2: cerrado, fecha 2025-12-20 | Acta de recibo: recibido por Felipe Arango el 2026-10-04 |
| Se entregó lo facturado | Factura FV-1404: "Entregables del contrato CT-404", 275.224.201 (valor de un entregable) | Contrato: pago contra acta de recibo firmada por el gerente; no existe acta de ninguno de los dos entregables y su estado es pendiente / en curso. El único recibo (ambiente de pruebas) no es entregable del contrato |

### Sin sustento
- Hitos *Diseño de la experiencia aprobado*, *Integración con el ERP* y *Piloto en tiendas* cerrados (3).
- Cifras de comprometido, ejecutado y proyección (3): solo existen en el informe.
- Autorización de CC-01 "por el comité" (1): sin nombre, fecha ni minuta.
- Línea base v2 como vigente (1): sin aprobador ni fecha propia.
- La causa y duración de la demora de validación en tiendas (1).

### Lo que esta carpeta no permite saber
- **Si el proyecto está en verde:** no hay evidencia independiente de ningún hito salvo el ambiente de pruebas. Consecuencia: el estado no puede usarse en comité sin que el gerente aporte actas.
- **Si el gerente podía aprobar el cambio:** sin autoridad declarada, el +70 días y los 140.000.000 COP son una solicitud, no una desviación aprobada.
- **Si lo facturado está entregado:** faltan las actas de los dos entregables. Consecuencia: la factura FV-1404, radicada en cuentas por pagar, no tiene el soporte que el contrato exige.
- **Qué ocurrió entre 2025-09-16 y 2026-08-31:** la carpeta no tiene ningún documento en ese lapso; después, siete documentos entre el 2026-08-31 y el 2026-10-08. El silencio es de la carpeta, y no puedo decir si es del proyecto o solo de quien archiva. Por el cálculo de silencio (8 días desde el último documento) no está en silencio hoy.
- **Qué incluye la ampliación de alcance** y **cuánto de los 3.300.000.000 se ha pagado realmente:** no hay detalle ni soporte contable.

### Preguntas para el gerente (si se quieren llevar, una por una)
1. ¿Dónde están las actas de recibo de *Licenciamiento* y *Bolsa de horas*, y a qué corresponde la factura FV-1404?
2. ¿Quién del comité autorizó CC-01, y en qué fecha?
3. ¿Qué documento acredita el cierre de Diseño, Integración, Piloto y Despliegue?
4. ¿Por qué 82 % si los cinco hitos figuran cerrados?
5. ¿Para cuándo es el "punto 33" de Javier Hoyos?

No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las contradicciones al gerente como preguntas.

---
*Rigor:* 9 documentos leídos, 2025-09-09 a 2026-10-08. Todas las cifras derivadas (días, porcentajes, disponible real, conteo de señales) vienen de `portafolio.py compute` del 2026-10-16; los conteos del dictamen (7/9/5) son míos y están listados arriba. Cada dato lleva su documento; la verificación contra las fuentes es suya. Criterio produce borradores de trabajo, no decisiones ni asesoría.
