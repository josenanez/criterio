## 2026-10-16

**Revisé:** 82 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Tocaban el barrido diario y la confirmación periódica; no había peticiones en el servidor.

### Lo que cruzó un umbral
Nada nuevo: el diff contra la foto de hoy no muestra cambios. Hay un hallazgo del barrido:

- **PRY-206, citas que no resuelven (21 campos).** La `ficha-pm.json` de PRY-206 (`00-gobierno/ficha-pm.json`) cita sus fuentes con ruta relativa a la carpeta del proyecto (p. ej. `00-gobierno/2025-11-15-acta-constitucion.docx`). Los archivos existen en disco, así que no es un borrado: es una ruta que el índice no resuelve. No se corrigió la ficha, porque la escribe el gerente del proyecto. Queda abierta la pregunta de si esa ficha debe citar con la ruta completa desde la carpeta de documentos.

### Peticiones atendidas
Ninguna.

### Preguntas
Nadie responde en esta corrida. Cinco campos, elegidos por importancia, quedan **preguntados el 2026-10-16, sin respuesta**:

1. **PRY-206, avance declarado.** El informe del 2026-10-16 declara 21 %, pero el cronograma tiene 5 de 5 hitos en «cumplido» (el plan sostiene 100 %), y los 4 primeros no tienen documento de respaldo. ¿Cuál de las dos cifras es la vigente?
2. **PRY-209, facturado al proveedor.** Integra Comercio S.A.S. figura con 275.224.201 COP facturados y 2 entregables pendientes (el más viejo, 307 días de atraso). ¿Qué documento de aceptación respalda la factura?
3. **PRY-210, línea base.** Se movió 140 días y solo hay 113 autorizados: 27 días sin autorización. ¿Dónde está la aprobación del resto?
4. **PRY-211, hitos cumplidos.** Declara 47 % de avance con 5 de 5 hitos «cumplido» desde octubre de 2025, y ninguno con respaldo. ¿Cuál es el estado real de los hitos?
5. **PRY-205, despliegue en la cadena.** Vencido hace 10 días, mientras el proveedor Retail Andino tiene el licenciamiento pendiente hace 295 días. ¿Hay nueva fecha acordada?

**Vuelvo el 2026-10-17.** Informe de comité: se genera el 2026-10-21 para el comité del 2026-10-23.
