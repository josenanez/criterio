# Corrida del 2026-10-16 · portfolio-scan

13 proyectos · 82 documentos, 0 releídos y 82 sin cambio · 200 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Nada movido (no existe entrada/). Nada omitido: 82 documentos convertidos, 69 leidos, 13 sin cambio (PRY-200, 202, 210). PRY-206 trae ficha-pm.json en pm_record. Mirar: hitos cerrados sin acta, facturas PRY-205 y PRY-209 sin acta, CC-01 de PRY-207 y PRY-209 sin fecha de autorizacion, compromisos de PRY-206 reprogramados, carpeta estado/PRY-206-precios-dinamicos ajena a la estructura.

Contra la corrida del 2026-10-16: +66 hallazgos.

## Lo que produjo

## Barrido — 2026-10-16

Términos vigentes (versión 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta volver a registrarlos. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12

**Documentos:** 82 en la carpeta · 69 leídos · 13 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin subagentes. Los 13 documentos sin cambio son los de PRY-200, PRY-202 y PRY-210, que conservan su ficha. Formatos: 32 .md, 20 .pdf, 13 .docx, 8 .xlsx, 7 .csv, 1 .json, 1 .txt; todos se convirtieron a texto. Cada ficha cita el documento original, no el caché.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, declarado, plan, dinero, proveedor CT-199, riesgos, 1 compromiso | authority, phase |
| PRY-201 Programa de fidelización | 4 | identidad, declarado, plan, dinero, riesgos, 1 compromiso | authority, phase |
| PRY-203 Reposición automática | 3 | identidad, declarado, plan, dinero, riesgos | authority, phase, product («No aplica») |
| PRY-204 Cajas de autopago | 4 | identidad, declarado, plan, dinero, riesgos, 2 compromisos | authority, phase |
| PRY-205 Pago con QR en caja | 8 | identidad, declarado, plan, dinero, proveedor CT-599 con factura, riesgos, 2 compromisos | authority, phase |
| PRY-206 Precios dinámicos | 20 | identidad, declarado, plan, dinero, proveedor CT-914 con factura, riesgos, 27 compromisos, `pm_record` (ficha-pm.json) | authority, phase, product («No aplica») |
| PRY-207 Marca propia de alimentos | 6 | identidad, declarado, plan v1 y v2, dinero, CC-01, riesgos, 1 compromiso | authority, phase |
| PRY-208 Domicilios en dos horas | 5 | identidad, declarado, plan, dinero, riesgos | authority, phase |
| PRY-209 Migración del ERP | 9 | identidad, declarado, plan v1 y v2, dinero, proveedor CT-404 con factura, CC-01, riesgos, 1 compromiso | authority, phase, product («No aplica») |
| PRY-211 Pronóstico de demanda | 4 | identidad, declarado, plan, dinero, riesgos | authority, phase, product («No aplica») |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| Ninguno | Los tres proyectos con ficha previa (PRY-200, PRY-202, PRY-210) no tuvieron documentos nuevos ni cambiados. | plan de lectura |

### Lo que conviene mirar (lo que dicen los documentos, sin juzgarlo)
- **Hitos declarados cerrados sin acta de recibo:** PRY-201 (3), PRY-203 (4), PRY-204 (3), PRY-205 (3), PRY-206 (4), PRY-208 (1), PRY-209 (4), PRY-211 (4). Se registraron como `met` con `evidence` vacío; no se dejaron abiertos por falta del acta.
- **PRY-205:** el contrato CT-599 declara «recibido» el entregable *Soporte del primer trimestre*, pero solo hay acta de recibo de *Bolsa de horas de desarrollo*. La factura FV-1599 (155.660.032 COP) equivale a dos entregables. El hito *Despliegue en la cadena* vencía el 2026-10-06 y sigue «en curso».
- **PRY-209:** la factura FV-1404 (275.224.201 COP, 2026-08-31) está radicada, pero el contrato CT-404 declara los dos entregables «pendiente» y «en curso», sin acta de recibo. CC-01 (2026-10-08, +70 días, 140.000.000 COP) mueve a 2026-07-07 una fecha ya pasada; la autorización dice «por el comité», sin nombre ni fecha.
- **PRY-207:** CC-01 (+64 días, 128.000.000 COP, «autorizada por el comité», sin nombre ni fecha) está reflejado en el cronograma v2, pero el informe del 2026-10-16 sigue con presupuesto aprobado de 800.000.000 COP. El hito *Diseño de la experiencia aprobado* (2026-10-02) sigue «en curso».
- **PRY-206:** declara verde con 21% de avance, y su cronograma tiene los cinco hitos cerrados con fecha final 2026-08-31. Hay 27 compromisos: «Enviar el documento 1» (Diana Molina) se reprogramó 5 veces y «Cerrar la prueba 2» (Óscar Ramírez) 4. Cinco compromisos se dieron por entregados en reunión sin acta. Las notas del 2026-10-16 recogen un riesgo dicho y no registrado (el proveedor podría no llegar con el equipo completo). La ficha del gerente (`ficha-pm.json`) va entera en `pm_record`, sin fusionarla con mi lectura.
- **PRY-203, PRY-204, PRY-211:** los informes dicen que el despliegue se reprogramó, pero el único cronograma es el v1 y la fecha no cambia. En PRY-211 el acta de recibo del despliegue es del 2026-10-09.
- **PRY-208:** declara 94% de avance con 459.248.225 de 2.400.000.000 COP ejecutados.
- **Compromisos con fecha ya pasada y sin evidencia de cumplimiento:** PRY-201 (Mauricio Pérez, 2026-10-11), PRY-204 (Paula Céspedes, 2026-10-12), PRY-207 (Mauricio Pérez, 2026-09-30), además de los vencidos de PRY-206. Quedaron `open`; el cálculo de vencimiento lo hace el script.
- **Compromisos sin fecha:** PRY-209 (Javier Hoyos, punto 33) y varios de PRY-206.
- **Carpeta ajena a la estructura:** `estado/PRY-206-precios-dinámicos/` contiene una copia de directorios de estado (corridas, records, snapshots). No la toqué.

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | Los 82 documentos se convirtieron a texto. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | — | No existe carpeta `entrada/` en la documentación. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

Una nota de método: `2026-10-16-notas-reunion.txt` estaba en la raíz de PRY-206, no en `30-reuniones/`; la leí como reunión de ese proyecto por su título y la dejé donde estaba.

**Ofrezco a continuación:** el informe consolidado del portafolio (`/criterio-portfolio:portfolio-report`), porque hay más de un proyecto y aparecieron contradicciones y compromisos vencidos.

---
Criterio Portfolio 0.3.12 · fichas tocadas: PRY-199, 201, 203, 204, 205, 206, 207, 208, 209, 211 (10) · campos en `not_found`: `identity.authority` y `identity.phase` en las 10; `identity.product` en PRY-203, 206, 209 y 211 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
