# Corrida del 2026-10-16 · steering-pack

13 proyectos · 108 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de comité 2026-10-23: 6 decisiones, 7 escalamientos, 13 fichas. No hay actas de un comité anterior; tres cambios aprobados por un comité sin nombre ni fecha. Autoridad sin declarar en los 13. No calculé la fecha de PRY-210 sin la CC-01 ni sumas entre proyectos porque el script no las da; los vencimientos del punto 4 son lectura mía.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Sale de las 13 fichas de `estado/records/` (PRY-199 a PRY-211, todas con corte 2026-10-16) y del cálculo `compute` del 2026-10-16, más las salidas de RAID y control de cambios de hoy. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-16 (versión 0.3.12). Ninguno de los 13 proyectos tiene un documento de evidencia en la ficha: todo lo que sigue contrasta lo que cada gerente declara contra lo que sus propios documentos sostienen.

# Comité de proyectos — 2026-10-23
6 decisiones · 7 escalamientos · 11 de 13 proyectos con hallazgos (76 señales abiertas)

Sesión sin interfaz: el comité sesiona el 2026-10-23 según la configuración (semanal); el paquete se preparó el 2026-10-16.

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| PRY-207 CC-01: +64 días, 128.000.000 COP | sin fecha | Figura aprobada por «el comité», sin nombrar cuál ni cuándo. La línea base se movió 64 días. | No verificable: falta el acta |
| PRY-209 CC-01: +70 días, 140.000.000 COP | sin fecha | Igual: aprobada por «el comité», sin nombre ni fecha. La línea base se movió 70 días. | No verificable: falta el acta |
| PRY-210 CC-02: +113 días, 226.000.000 COP | sin fecha | Igual. La línea base se movió 113 días autorizados. | No verificable: falta el acta |

No hay actas ni registro de decisiones de un comité anterior en las fichas ni en las carpetas leídas. No puedo decir qué se decidió la semana pasada ni qué se hizo con eso; lo único que existe son tres aprobaciones atribuidas a un comité sin acta. Pedir al secretario del comité las actas es el primer cierre del ciclo.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de fecha y de presupuesto en cada proyecto: el gerente, el patrocinador o este comité?
**Proyecto:** los 13 · **Quién decide:** este comité, por defecto (es lo único con respaldo documental: las actas dicen que aprobó presupuesto y línea base) · **Si no se decide hoy:** los puntos 2 a 6 se vuelven a decidir sin saber si este comité era el indicado, y los cambios siguen aprobándose por «el comité» sin nombre.

La autoridad no está declarada en ninguno de los 13 proyectos (`identity.authority` sin encontrar en los 13).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité aprueba todo cambio de fecha o presupuesto hasta que exista un umbral escrito | Sin impacto | Un ciclo semanal de espera por cambio | Sin impacto directo |
| B. Fijar hoy un umbral por proyecto (gerente / patrocinador / comité) | Sin impacto | Una sesión para definirlo | Sin impacto directo; el umbral lo pone el comité, yo no lo propongo |
| C. No definir | Sin impacto | Los cambios siguen pasando sin autoridad clara | Riesgo de pagos y fechas sin respaldo (ver puntos 2 y 5) |

**Recomendación:** A hoy y B en la próxima sesión. Mientras no haya regla escrita, lo único defendible es que el comité que aprobó la línea base apruebe sus cambios.

### [2] ¿Se aprueba la CC-01 de PRY-210 (ampliación de alcance, +27 días, 54.000.000 COP)?
**Proyecto:** PRY-210 Etiquetas electrónicas de precio · **Quién decide:** no determinable (ver punto 1); se lleva al comité · **Si no se decide hoy:** la línea base sigue 27 días más adelante de lo autorizado.

La solicitud se hizo el 2026-10-09 y sigue pendiente, pero la línea base ya se movió 140 días y solo hay 113 autorizados: 27 días sin autorización. El estado declarado es amarillo; la desviación contra la original es de 140 días (64,8 %). Presupuesto aprobado 4.200.000.000 COP; proyección 3.955.871.985 COP (-5,8 %).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación de alcance | +27 días sobre la línea base vigente | +54.000.000 COP |
| B. Rechazar y devolver la línea base a lo autorizado | Sin la ampliación | -27 días respecto a hoy (la fecha resultante no la calculo) | Sin costo adicional; costo del trabajo ya hecho: no consta |
| C. Aplazar | Sin decidir | La línea base sigue con 27 días sin respaldo | Sin decidir |

**Recomendación:** no recomiendo A ni B con los documentos que hay: la solicitud no dice qué se gana con la ampliación ni si ya hay trabajo hecho sobre ella. Recomiendo no aplazar: pedir al gerente esos dos datos y decidir hoy entre A y B. Confirmar además en acta la CC-02, aprobada «por el comité» sin nombre.

### [3] El despliegue por el congelamiento de fin de año: ¿se abre una solicitud de cambio por proyecto o se declara que las fechas no se mueven?
**Proyectos:** PRY-203 (con solicitud de +30 días, sin solicitante), PRY-202, PRY-204, PRY-211 · **Quién decide:** el comité del 2026-10-23, por defecto · **Si no se decide hoy:** cuatro proyectos reportan contra una fecha que sus propios informes dicen que ya no usan.

Los informes de PRY-203, PRY-204 y PRY-211 dicen que el despliegue se reprogramó y que el cronograma sigue en v1 con la misma fecha; el de PRY-202 no da la nueva fecha. PRY-203 cierra el 2026-12-30, dentro del congelamiento; el fin del congelamiento no consta en ningún documento.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Una solicitud de cambio por proyecto, con fecha y costo del mes adicional | Sin cambio declarado | PRY-203: +30 días (cierre 2027-01-29, según el control de cambios de hoy); los demás, sin fecha | Sin estimar en ningún proyecto; PRY-203 tiene 142.174.120 COP de margen contra lo aprobado |
| B. Mantener las fechas y exigir plan para desplegar dentro del congelamiento | Sin cambio | Sin cambio | Sin estimar |
| C. No decidir | Sin cambio | La reprogramación ocurre sin registro | Sin estimar |

**Recomendación:** A. B exige saber cuándo termina el congelamiento y ese dato no existe. En PRY-203 falta además quién pide el cambio y si tiene dependencias no declaradas.

### [4] Proyectos con fecha de fin vencida sin cerrar: ¿se exige replanificar con solicitud de cambio?
**Proyectos:** PRY-211, PRY-202, PRY-209, PRY-206, PRY-205 · **Quién decide:** el comité, por defecto · **Si no se decide hoy:** siguen ejecutando y comprometiendo dinero sobre una línea base cuya fecha ya pasó.

Lectura mía de las fechas de fin de la ficha contra el 2026-10-16; el script no emitió esta señal en PRY-202, PRY-206, PRY-211.

| Proyecto | Fin en la línea base | Avance declarado | Estado declarado | Disponible real (COP) |
|---|---|---|---|---|
| PRY-211 | 2026-03-12 | 47 % | amarillo | 1.650.653.709 |
| PRY-202 | 2026-04-24 | 55 % | verde | 1.992.219.124 |
| PRY-209 | 2026-07-07 | 82 % | verde | 1.187.960.049 |
| PRY-206 | 2026-08-31 | 21 % | verde | 1.628.515.944 |
| PRY-205 | 2026-10-06 | 73 % | verde | 111.503.853 |

PRY-205 tiene comprometido el 86,1 % del presupuesto aprobado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada gerente presenta replanificación con solicitud de cambio antes del comité del 2026-10-30 | A revisar | Fechas nuevas por definir | Sin estimar |
| B. Congelar nuevos compromisos de gasto en esos cinco hasta tener plan | Sin cambio | Posible pausa en el trabajo | Evita comprometer sobre una fecha vencida; costo de la pausa no consta |
| C. No decidir | Sin cambio | Sin cambio | Sin cambio |

**Recomendación:** A y B juntas para PRY-206 y PRY-205 (el menos avanzado y el que ya comprometió casi todo); A sola para el resto.

### [5] Pagos a proveedores con entregables vencidos: ¿se retiene la facturación hasta que haya aceptación con evidencia?
**Proyectos:** PRY-209 (Integra Comercio S.A.S., contrato CT-404) y PRY-205 (Retail Andino Consultores S.A.S., contrato CT-599) · **Quién decide:** no determinable; el comité por defecto · **Si no se decide hoy:** se siguen aprobando facturas sin que consten los entregables.

- **PRY-209:** facturado 275.224.201 COP con 0 de 2 entregables aceptados. Los dos están pendientes y vencidos: «Licenciamiento de la plataforma» (2025-12-13) y «Bolsa de horas de desarrollo» (2026-03-02).
- **PRY-205:** facturado 155.660.032 COP, igual al monto aceptado. Pero dos entregables siguen pendientes y vencidos («Licenciamiento de la plataforma», 2025-12-25, y «Configuración del catálogo», 2026-06-04) y uno aceptado, «Soporte del primer trimestre», no tiene evidencia de aceptación.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener nuevas facturas de ambos proveedores hasta tener aceptación con evidencia | Sin cambio | Puede frenar al proveedor | Evita pagar lo no entregado; efecto contractual no consta (no leí cláusulas de pago) |
| B. Retener solo PRY-209 (facturado sin ningún entregable aceptado) | Sin cambio | Puede frenar a un proveedor | Igual |
| C. No actuar | Sin cambio | Sin cambio | 275.224.201 COP ya facturados en PRY-209 sin entrega aceptada |

**Recomendación:** B hoy y pedir en PRY-205 la evidencia del «Soporte del primer trimestre». Retener algo que sí tiene aceptación sobre la que no puedo opinar sería ir más allá de lo que muestran los documentos.

### [6] El estado «verde» sin sustento: ¿se acepta un hito como cumplido sin evidencia en la ficha?
**Proyectos:** siete declaran verde contra señales abiertas: PRY-200, PRY-201, PRY-203, PRY-204, PRY-205, PRY-206, PRY-209 · **Quién decide:** el comité, por defecto · **Si no se decide hoy:** el comité del 2026-10-23 recibe verdes que sus propios documentos contradicen.

Hitos marcados «cumplido» sin evidencia: PRY-200 (2), PRY-201 (3), PRY-203 (4), PRY-204 (3), PRY-205 (3), PRY-206 (4), PRY-209 (4). También sin evidencia, aunque con estado amarillo: PRY-208 (1), PRY-210 (2), PRY-211 (4). Las brechas de avance contra lo que sostiene el plan son de 29 puntos (PRY-200), 36 (PRY-201), 31 (PRY-203), 14 (PRY-204), 79 (PRY-206), 18 (PRY-209) y 53 (PRY-211).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir evidencia de cada hito «cumplido»; sin ella se informa como no verificado | Sin cambio | Trabajo de recopilación por gerente | Horas del equipo, sin estimar |
| B. Aceptar la declaración del gerente | Sin cambio | Sin cambio | Sin cambio |

**Recomendación:** A, empezando por PRY-206 (21 % declarado contra cinco de cinco hitos «cumplidos») y PRY-203. Con B el semáforo del portafolio no mide nada.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-199, 206, 207, 210 | Hallazgo de seguridad en medios de pago, casi con la misma frase en cuatro proyectos, tres sin relación evidente con pagos | 2026-10-14 a 2026-10-16 | Un doliente y confirmar si es un hallazgo o cuatro |
| PRY-200, 203, 208 | Dos semanas perdidas por rotación de un desarrollador clave, misma frase en tres | 2026-10-12 a 2026-10-16 | Confirmar si es la misma persona; nombrar doliente |
| PRY-201, 205 | Prueba de carga de temporada bajo el umbral pactado, se repite; sin fecha de nueva prueba | 2026-10-06 y 2026-10-07 | Quién responde y para cuándo |
| PRY-201, 209, 211 | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-07 a 2026-10-14 | Nombrar al proveedor y exigir fecha. En PRY-209 la CC-01 (+70 días) no nombra el comité que la aprobó |
| PRY-206 | Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo | 2026-10-16 | Registrarlo, con doliente |
| PRY-206 | Compromisos reprogramados: Diana Molina (5 veces, original 2026-09-18), Óscar Ramírez (4, original 2026-09-23), Paula Céspedes (3, original 2026-09-23); además cinco vencidos y cinco sin fecha | desde 2026-09-18 | Decidir si se mantienen o se cambia al responsable |
| PRY-199, 207 vs PRY-209 | Los dos tienen un hito «Integración con el ERP» y PRY-209 migra el ERP y movió +70 días; ningún acta declara la dependencia | sin fecha | Confirmar si existe la dependencia |

## Para conocimiento
- **PRY-199 Iluminación LED en bodegas:** verde, 20 % declarado, sin señales de avance. Sin evidencia de ningún tipo en la ficha.
- **PRY-200 Tienda en línea:** verde, 46 % declarado; compromiso de Javier Hoyos vencido 14 días.
- **PRY-201 Programa de fidelización:** verde, 39 %; compromiso de Mauricio Pérez vencido 5 días.
- **PRY-202 Centro de distribución norte:** verde, 55 %; sin señales emitidas, pero con fecha de fin vencida (punto 4).
- **PRY-203 Reposición automática:** verde, 49 %; cuatro hitos «cumplidos» sin evidencia (puntos 3 y 6).
- **PRY-204 Cajas de autopago:** verde, 46 %; compromiso de Paula Céspedes vencido 4 días.
- **PRY-205 Pago con QR en caja:** verde, 73 %; hito «Despliegue en la cadena» vencido 10 días (puntos 4 y 5).
- **PRY-206 Precios dinámicos:** verde, 21 %; 19 señales, la más cargada del portafolio (puntos 4 y 6).
- **PRY-207 Marca propia de alimentos:** amarillo, 52 %; desviación de 64 días (14,2 %) contra la original, hito «Diseño de la experiencia aprobado» vencido 14 días y compromiso de Mauricio Pérez vencido 16.
- **PRY-208 Domicilios en dos horas:** amarillo, 94 %; una sola señal.
- **PRY-209 Migración del ERP:** verde, 82 %; desviación de 70 días (32,7 %) contra la original (puntos 4 a 6).
- **PRY-210 Etiquetas electrónicas de precio:** amarillo, 57 %; hito «Integración con el ERP» vencido 5 días (punto 2).
- **PRY-211 Pronóstico de demanda:** amarillo, 47 %; cinco de cinco hitos «cumplidos», cuatro sin evidencia (puntos 4 y 6).

## Anexo

### Estado de cada proyecto (cifras del `compute` del 2026-10-16)
| Proyecto | Declarado | Avance | Señales | Ejecutado | Comprometido | Proyección sobre aprobado |
|---|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 0 | 30,0 % | 45,0 % | 0,0 % |
| PRY-200 | verde | 46 % | 5 | 42,0 % | 70,6 % | 1,9 % |
| PRY-201 | verde | 39 % | 6 | 31,2 % | 43,3 % | -2,2 % |
| PRY-202 | verde | 55 % | 0 | 26,0 % | 52,6 % | -7,3 % |
| PRY-203 | verde | 49 % | 6 | 51,1 % | 52,5 % | -3,4 % |
| PRY-204 | verde | 46 % | 6 | 57,8 % | 66,0 % | 1,7 % |
| PRY-205 | verde | 73 % | 8 | 53,5 % | 86,1 % | -2,0 % |
| PRY-206 | verde | 21 % | 19 | 26,4 % | 82,9 % | 1,8 % |
| PRY-207 | amarillo | 52 % | 4 | 38,0 % | 44,1 % | -4,8 % |
| PRY-208 | amarillo | 94 % | 1 | 19,1 % | 58,4 % | 2,3 % |
| PRY-209 | verde | 82 % | 11 | 44,8 % | 64,0 % | 1,1 % |
| PRY-210 | amarillo | 57 % | 5 | 46,9 % | 49,0 % | -5,8 % |
| PRY-211 | amarillo | 47 % | 5 | 37,0 % | 50,0 % | 0,1 % |

Totales del script: 13 proyectos, 11 con señales, 76 señales, 7 con verde contradicho, 0 sin línea base, 13 sin autoridad declarada.

Tres observaciones sobre esa tabla:
- PRY-208 declara 94 % de avance con 19,1 % del presupuesto ejecutado.
- PRY-205 y PRY-206 son los dos con más dinero comprometido (86,1 % y 82,9 %); ninguno supera el umbral de 90 %.
- PRY-204 y PRY-203 son los que más han ejecutado (57,8 % y 51,1 %), con 46 % y 49 % de avance declarado.

### Contradicciones abiertas
- Siete verdes contra señales propias (punto 6).
- PRY-203: el informe del 2026-10-15 dice que el despliegue se reprogramó, la ficha mantiene v1 con la misma fecha y `changes` está vacío.
- PRY-209: la CC-01 figura aprobada, pero nombra al comité sin decir cuál; el proyecto sigue declarando verde con tres señales de proveedor y fecha vencida.
- PRY-210: la línea base está movida 27 días más allá de lo autorizado.

### Vacíos de información
- Autoridad: sin declarar en los 13 proyectos. Fase: sin declarar en todos.
- Dolientes de RAID: 0 de 36 ítems tienen doliente; ninguno tiene fecha de revisión o resolución. Los riesgos no traen probabilidad ni impacto, salvo seis de «regulación de datos personales» con impacto «alcance».
- Dependencias entre proyectos: las 13 actas dicen «Ninguna declarada».
- Datos de identidad y plan con más de 12 meses de antigüedad: PRY-200, 202, 203, 204, 205, 208, 209 y 211 (13 a 15 meses).
- Carpeta de reuniones: PRY-202, 203, 208, 210 y 211 no tienen; de ellos no hay compromisos que revisar.
- Facturación: PRY-199 no declara lo facturado a su proveedor (CT-199, 0 de 3 entregables aceptados).
- Informes de avance más viejos al 2026-10-16: PRY-205 (10 días), PRY-201 (9), PRY-204 (9) y PRY-209 (8). Ninguno pasa el umbral de 30 días.

## Pie de rigor
- **Versión:** Criterio portfolio 0.3.12 · términos v1.1.
- **Fichas aplicadas:** las 13, con corte 2026-10-16.
- **Campos inciertos:** el quién decide en todo el portafolio; qué es «salida a producción» en PRY-203; el costo de cualquier mes adicional; el fin del congelamiento de fin de año; si los hallazgos con frase repetida son uno o varios; qué comité aprobó las tres solicitudes de cambio; las cláusulas de pago de CT-404 y CT-599 (no las leí).
- **Mi lectura, no del script:** los vencimientos del punto 4 (comparé fechas de fin con el 2026-10-16); la lista de proyectos por hito sin evidencia que reúno en el punto 6; la reclasificación de riesgos a supuestos y dependencias del RAID.
- **Qué no hice:** no calculé la fecha de PRY-210 sin la CC-01 ni ninguna suma entre proyectos, porque el script no las da.
- Borrador de trabajo, no decisión ni asesoría: la verificación es de quien lo usa; cada dato lleva su ficha y documento de origen. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
