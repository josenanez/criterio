Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). Fichas cargadas: 13 (`estado/records`), barrido del 2026-10-16; ninguna con más de una semana. Formato pedido: html (anula el `pptx` de la configuración).

# Portafolio — 2026-10-16
13 proyectos · 11 con hallazgos · 76 señales · último barrido 2026-10-16

## Qué cambió desde 2026-10-16
Sin cambios desde la corrida anterior. La instantánea previa es del mismo día (2026-10-16): el diff dio 0 cambios. Es un punto de partida, no un delta de semanas.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes (`conflicts` en blanco en los 13).

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-205 Pago con QR | Despliegue en la cadena | 2026-10-06 | 10 |
| PRY-207 Marca propia | Diseño de la experiencia aprobado | 2026-10-02 | 14 |
| PRY-210 Etiquetas electrónicas | Integración con el ERP | 2026-10-11 | 5 |

Además hay hitos declarados «cumplidos» sin documento que lo respalde en 10 proyectos (ver «Sin sustento»).

## Proyectos en silencio
Vacía: ninguno supera 15 días sin documentos (el máximo es PRY-205, 3 días; PRY-209, 8 días).

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias entre proyectos.

## Sin sustento
Siete proyectos se declaran en verde y las señales lo contradicen:

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 Tienda en línea | Verde, 46 % | Nada. El plan sustenta 75–100 %. Hitos «cumplidos» sin evidencia: Ambiente de pruebas (172 d), Integración ERP (58 d). Compromiso vencido: Javier Hoyos, punto 29 (14 d). |
| PRY-201 Fidelización | Verde, 39 % | Nada. Plan sustenta 75–100 %. 3 hitos sin evidencia (hasta 227 d). Compromiso vencido: Mauricio Pérez, punto 8 (5 d). |
| PRY-203 Reposición automática | Verde, 49 % | Nada. Plan sustenta 80–100 %. 4 hitos sin evidencia (hasta 349 d). |
| PRY-204 Cajas de autopago | Verde, 46 % | Nada. Plan sustenta 60–80 %. 3 hitos sin evidencia. Compromiso vencido: Paula Céspedes, punto 3 (4 d). |
| PRY-205 Pago con QR | Verde, 73 % | Nada. Hito de despliegue vencido 10 d; 3 hitos sin evidencia; proveedor Retail Andino con 2 entregables pendientes (295 y 134 d) y uno aceptado sin evidencia. |
| PRY-206 Precios dinámicos | Verde, 21 % | Nada. Los 5 hitos figuran cumplidos, pero el avance es 21 %; 4 hitos sin evidencia (hasta 270 d); 5 compromisos vencidos (hasta 35 d), 5 sin fecha, 3 reprogramados (hasta 5 veces); fin planeado 2026-08-31, ya pasado. |
| PRY-209 Migración del ERP | Verde, 82 % | Nada. Desviación de 70 días (32,7 %) contra la original; 4 hitos sin evidencia; proveedor Integra Comercio facturó COP 275.224.201 sin ningún entregable aceptado (2 pendientes, 307 y 228 d). |

Otros hallazgos sin sustento:
- PRY-208 (amarillo, 94 %): hito «Integración con el ERP» cumplido sin evidencia (89 d).
- PRY-210 (amarillo): 2 hitos sin evidencia y **replanificación no autorizada de 27 días** (movió 140, autorizó 113).
- PRY-211 (amarillo, 47 %): los 5 hitos figuran cumplidos pero el avance es 47 %; 4 sin evidencia (hasta 379 d); fin planeado 2026-03-12, ya pasado.
- Ninguna ficha tiene fuentes marcadas como evidencia: en todas, las citas son declaraciones o no están marcadas.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad (`identity.authority`) |
| Los 13 | Fase (`identity.phase`) |
| PRY-202, 203, 206, 209, 210, 211 | Producto asociado |
| PRY-199 | Facturado del proveedor CT-199 |
| PRY-206 | Producto, autoridad y fase también en el registro del PM |
| PRY-200, 202, 203, 204, 205, 208, 209, 211 | Campos de identidad y plan con fuente de hace 13–15 meses (umbral 12) |

## Estado general
| Proyecto | Declarado | Sustento | Desv. vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Iluminación LED | Verde 20 % | Sin señales | 0 d | 0 d | 0 |
| PRY-200 Tienda en línea | Verde 46 % | Contradicho (4 señales) | 0 d | 0 d | 0 |
| PRY-201 Fidelización | Verde 39 % | Contradicho | 0 d | 0 d | 0 |
| PRY-202 Centro de distribución norte | Verde 55 % | Sin señales; fin planeado 2026-04-24 ya pasado | 0 d | 0 d | 0 |
| PRY-203 Reposición automática | Verde 49 % | Contradicho | 0 d | 0 d | 0 |
| PRY-204 Cajas de autopago | Verde 46 % | Contradicho | 0 d | 0 d | 0 |
| PRY-205 Pago con QR | Verde 73 % | Contradicho (8 señales) | 0 d | 0 d | 0 |
| PRY-206 Precios dinámicos | Verde 21 % | Contradicho (19 señales) | 0 d | 0 d | 0 |
| PRY-207 Marca propia | Amarillo 52 % | Atraso confirmado: 64 d (14,2 %) | +64 d | 0 d | 1 |
| PRY-208 Domicilios en dos horas | Amarillo 94 % | 1 hito sin evidencia | 0 d | 0 d | 0 |
| PRY-209 Migración del ERP | Verde 82 % | Contradicho | +70 d (32,7 %) | 0 d | 1 |
| PRY-210 Etiquetas electrónicas | Amarillo 57 % | Atraso confirmado: 140 d (64,8 %); 27 d sin autorización | +140 d | 0 d | 1 |
| PRY-211 Pronóstico de demanda | Amarillo 47 % | Cuestionado | 0 d | 0 d | 0 |

Presupuesto: ningún proyecto supera el umbral de 10 % de sobrecosto proyectado (máximo PRY-200, +1,9 %). Ninguno llega al 90 % comprometido (máximo PRY-205, 86,1 %).

## Necesito que confirmes
No toca confirmación mensual de campos hoy con respuesta posible (sesión sin interfaz); quedan planteadas, con la respuesta sugerida entre paréntesis:
1. ¿Quién es la autoridad de PRY-206 Precios dinámicos? (dejar como «sin dato» hasta que alguien la nombre)
2. ¿PRY-206 y PRY-211 siguen vigentes pese a que su fecha de fin ya pasó? (sí, y pedir nueva fecha al gerente)
3. ¿Hay evidencia documental de los hitos de PRY-209 declarados cumplidos? (no; pedirla)
4. ¿Qué producto sostiene PRY-202? (sin dato)
5. ¿Se autorizaron los 27 días adicionales de PRY-210? (no consta; escalar)

---
Pie: criterio-portfolio 0.3.12 · términos v1.1 · fichas aplicadas: 13, con fecha 2026-10-16 · campos inciertos: 13 sin autoridad, 13 sin fase, 6 sin producto, 8 proyectos con campos de más de 12 meses · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
