# Corrida del 2026-10-16 · budget-tracking

13 proyectos · 59 s · 76 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 30 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 7 |
| `commitment_undated` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_overdue` | 3 |
| `commitment_rescheduled` | 3 |
| `variance_time` | 3 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |

Presupuesto de 13 proyectos en COP, 52 cifras declaradas. Ninguno supera el umbral de comprometido (90%); 6 con proyección sobre el aprobado (PRY-200, 204, 206, 208, 209, 211). Dije que no sé: presupuesto original vs vigente, replanificaciones de presupuesto, facturado de PRY-199, avance de PRY-202, y si alguna proyección es anterior al último movimiento de presupuesto.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Presupuesto — portafolio (13 proyectos) al 2026-10-16
**Moneda:** COP (los 13 proyectos; no hay otra moneda, no se convirtió nada)

**De qué sale:** las fichas en `estado/records/PRY-199…PRY-211` (cifras de presupuesto tomadas del último informe de avance de cada proyecto) y el recálculo de `portafolio.py compute` con fecha 2026-10-16. Toda cifra derivada se copia de esa salida. No sumé el portafolio: el script no entrega totales en pesos y no los calculo a mano.

### Las cuatro cifras por proyecto (COP)
| Proyecto | Aprobado | Comprometido (% aprob.) | Ejecutado (% aprob.) | Proyección (sobre aprobado) | Disponible real | Fuente (informe de avance) |
|---|---|---|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 2.400.000.000 | 1.080.000.000 (45,0%) | 720.000.000 (30,0%) | 2.400.000.000 (0,0%) | 1.320.000.000 | 2026-10-14 (.md) |
| PRY-200 Tienda en línea | 6.800.000.000 | 4.799.233.410 (70,6%) | 2.855.071.580 (42,0%) | 6.930.747.093 (+1,9%) | 2.000.766.590 | 2026-10-16 (.pdf) |
| PRY-201 Programa de fidelización | 3.300.000.000 | 1.429.539.814 (43,3%) | 1.031.174.953 (31,2%) | 3.226.390.577 (−2,2%) | 1.870.460.186 | 2026-10-07 (.md) |
| PRY-202 Centro de distribución norte | 4.200.000.000 | 2.207.780.876 (52,6%) | 1.090.124.030 (26,0%) | 3.893.016.848 (−7,3%) | 1.992.219.124 | 2026-10-16 (.pdf) |
| PRY-203 Reposición automática | 4.200.000.000 | 2.203.231.939 (52,5%) | 2.148.130.209 (51,1%) | 4.057.825.880 (−3,4%) | 1.996.768.061 | 2026-10-15 (.pdf) |
| PRY-204 Cajas de autopago | 1.200.000.000 | 792.548.398 (66,0%) | 693.057.063 (57,8%) | 1.220.716.745 (+1,7%) | 407.451.602 | 2026-10-07 (.md) |
| PRY-205 Pago con QR en caja | 800.000.000 | 688.496.147 (86,1%) | 428.207.016 (53,5%) | 783.938.369 (−2,0%) | 111.503.853 | 2026-10-06 (.pdf) |
| PRY-206 Precios dinámicos | 9.500.000.000 | 7.871.484.056 (82,9%) | 2.511.507.913 (26,4%) | 9.672.559.716 (+1,8%) | 1.628.515.944 | 2026-10-16 (.pdf) |
| PRY-207 Marca propia de alimentos | 800.000.000 | 352.515.770 (44,1%) | 304.266.576 (38,0%) | 761.862.528 (−4,8%) | 447.484.230 | 2026-10-16 (.pdf) |
| PRY-208 Domicilios en dos horas | 2.400.000.000 | 1.401.914.037 (58,4%) | 459.248.225 (19,1%) | 2.455.475.855 (+2,3%) | 998.085.963 | 2026-10-12 (.pdf) |
| PRY-209 Migración del ERP | 3.300.000.000 | 2.112.039.951 (64,0%) | 1.478.959.765 (44,8%) | 3.336.392.773 (+1,1%) | 1.187.960.049 | 2026-10-08 (.pdf) |
| PRY-210 Etiquetas electrónicas de precio | 4.200.000.000 | 2.058.257.526 (49,0%) | 1.968.184.724 (46,9%) | 3.955.871.985 (−5,8%) | 2.141.742.474 | 2026-10-16 (.pdf) |
| PRY-211 Pronóstico de demanda | 3.300.000.000 | 1.649.346.291 (50,0%) | 1.221.930.488 (37,0%) | 3.304.906.826 (+0,1%) | 1.650.653.709 | 2026-10-14 (.md) |

Las cuatro cifras de cada proyecto vienen del mismo informe de avance y llevan su fecha; las 52 están declaradas (ninguna `not_found`). **Disponible real** = aprobado menos comprometido.

### Contra la línea base
No hay en ninguna ficha un presupuesto original distinto del vigente ni una replanificación de presupuesto registrada: la columna "Original / Vigente / Desviación" de presupuesto **no se puede llenar**. Lo que sí hay son replanificaciones de **plazo** (PRY-207, PRY-209 y PRY-210, una cada una), que no son de presupuesto. El umbral de desviación de costo (10%) no se cruzó en ningún proyecto.

### Ejecución frente a avance
| Proyecto | Ejecutado | Avance declarado | Hitos cumplidos | Lectura |
|---|---|---|---|---|
| PRY-208 | 19,1% | 94,0% | 3 de 4 | Ejecución muy por debajo del avance declarado: puede haber trabajo hecho y no facturado que aparecerá de golpe; o el avance está sobredeclarado. Comprometido 58,4%. |
| PRY-206 | 26,4% | 21,0% | 5 de 5 | Comprometido 82,9% con solo 26,4% ejecutado: el presupuesto casi está agotado y no se ha causado. Avance declarado 79 puntos por debajo de lo que sostienen los hitos. |
| PRY-211 | 37,0% | 47,0% | 5 de 5 | Avance declarado 53 puntos por debajo de lo que sostienen los hitos; ejecución en línea con el declarado, no con los hitos. |
| PRY-200 | 42,0% | 46,0% | 3 de 4 | Ejecución alineada con el avance declarado; los hitos sostienen 75–100%. |
| PRY-207 | 38,0% | 52,0% | 0 de 3 | Avance declarado por delante de los hitos (0 cumplidos). |
| PRY-205 | 53,5% | 73,0% | 4 de 5 | Comprometido 86,1%, cerca del umbral de 90%. |
| PRY-209 | 44,8% | 82,0% | 5 de 5 | Ejecución muy por debajo del avance declarado; además, factura al proveedor sin entrega (ver alertas). |
| PRY-201 | 31,2% | 39,0% | 3 de 4 | Sin desalineación fuerte con el declarado; avance declarado 36 puntos por debajo de los hitos. |
| PRY-203 | 51,1% | 49,0% | 4 de 5 | Alineado con el declarado; hitos sostienen 80–100%. |
| PRY-204 | 57,8% | 46,0% | 3 de 5 | Ejecución por encima del avance declarado. |
| PRY-210 | 46,9% | 57,0% | 2 de 4 | Alineado con el avance. |
| PRY-199 | 30,0% | 20,0% | 1 de 5 | Ejecución por encima del avance declarado. |
| PRY-202 | 26,0% | sin avance declarado | — | No se puede cruzar: la ficha no trae avance ni hitos. |

Los puntos de diferencia con los hitos son los de `progress_vs_plan` del script; la comparación ejecutado/declarado la leí de las columnas, sin cifra derivada propia. Ojo: en 10 proyectos hay hitos "cumplidos" sin evidencia, así que "hitos cumplidos" es lo declarado, no lo comprobado.

### Alertas
- **Comprometido por encima del umbral (90%):** ninguno. Los más cercanos: PRY-205 (86,1%) y PRY-206 (82,9%).
- **Proyección que excede el aprobado:** PRY-200 (+1,9%), PRY-204 (+1,7%), PRY-206 (+1,8%), PRY-208 (+2,3%), PRY-209 (+1,1%) y PRY-211 (+0,1%). Todas por debajo del umbral de 10%, pero son excesos declarados, sin solicitud de cambio asociada en las fichas.
- **Ejecución desalineada del avance:** PRY-208, PRY-209 (ejecución muy por debajo de lo declarado), PRY-206 y PRY-211 (avance declarado muy por debajo de los hitos), PRY-207 (declarado por delante de los hitos).
- **PRY-209:** el proveedor Integra Comercio S.A.S. aparece facturado por 275.224.201 COP con entregables pendientes (señal `vendor_invoiced_without_delivery`).
- **PRY-210:** el plazo se movió 140 días y solo 113 están autorizados (27 días sin autorización). No es de presupuesto, pero afecta su proyección.
- **Informes en verde contradichos:** 7 de los 13 proyectos declaran verde mientras sus propios documentos muestran señales abiertas (PRY-200, 201, 203, 204, 205, 206, 209).

### Sobre la proyección
Es una declaración, no un dato duro. Las 13 salen del mismo informe de avance que las otras cifras, con fecha entre 2026-10-06 (PRY-205) y 2026-10-16. No hay ningún movimiento de presupuesto registrado con el cual compararlas, así que **no puedo decir si alguna proyección es más vieja que el último movimiento**. La más antigua es la de PRY-205 (10 días).

### Sin dato
- Presupuesto original frente al vigente y replanificaciones de presupuesto: no declarados en ningún documento.
- Facturado por proveedor en PRY-199 (`vendors[0].invoiced`).
- Avance y hitos de PRY-202 (no se puede cruzar con la ejecución).
- Tasa de cambio: no aplica, todo está en COP.
- Fases y autoridad de decisión: faltan en las 13 fichas (no afecta el presupuesto, pero impide decir quién aprobaría un cambio).

### Siguiente paso que ofrezco
La proyección excede el aprobado en PRY-200, 204, 206, 208, 209 y 211: puedo preparar la solicitud de cambio de cualquiera de ellas. Para PRY-205 y PRY-206, que están cerca del tope de comprometido, puedo armar el detalle por proveedor.

---
*Pie de rigor:* borrador de trabajo, no decisión ni asesoría. Las cifras salen de los informes de avance citados, que son declaraciones de los gerentes; la verificación es de quien lee. Sin presupuesto original ni movimientos de presupuesto en los documentos, no se contrastó la línea base. Cálculos de `portafolio.py compute`, 2026-10-16.
