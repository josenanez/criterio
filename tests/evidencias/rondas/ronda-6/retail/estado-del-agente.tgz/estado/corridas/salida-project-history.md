## Historia · PRY-210 Etiquetas electrónicas de precio · 2026-04-22 a 2026-10-16

**Leí:** 6 documentos entre 2026-04-22 y 2026-10-16 (acta de constitución, cronograma v1, cronograma v3, CC-01, CC-02 e informe de avance).
**Trimestres sin un solo documento:** tercer trimestre de 2026 (julio a septiembre). Entre el 2026-04-22 y el 2026-10-09 no hay ningún documento.

Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16 (comprobante ya existente).

### En una línea
El proyecto se aprobó el 2026-04-22 con cierre el 2026-12-04. Después de cinco meses sin documentos, entre el 2026-10-09 y el 2026-10-16 aparecen dos solicitudes de cambio, un cronograma v3 que mueve el piloto al 2027-04-23 y un informe de avance en amarillo con 57 %. Ninguno de los tres documentos de la última semana habla de los otros, y los dos hitos reportados como cerrados no tienen documento de recibo.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 (cronograma v3) | 140 días, 64.8 %; contra la línea vigente, 0 | No se calcula en meses: el script da 113 días desde el primer hito sin evidencia (2026-06-25) | 0 en los documentos (el script no detecta ninguno) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-22 | Acta de constitución (.docx) | Aprueba el proyecto: presupuesto 4.200.000.000 COP, inicio 2026-05-02, cierre 2026-12-04. Patrocinador Óscar Ramírez, gerente Javier Hoyos, Comité de Cadena de Abastecimiento. |
| 2026-04-22 | Cronograma v1 (.csv) | Línea base de 4 hitos. En el archivo, los dos primeros ya figuran como «cerrado» (ver más abajo). |
| 2026-10-09 | CC-01 | Ampliación de alcance: +27 días y +54.000.000 COP. «Pendiente de presentación al comité». |
| 2026-10-11 | (fecha del hito, sin documento) | Vence «Integración con el ERP»; sigue «en curso». 5 días de atraso a la fecha de corte. |
| 2026-10-16 | Cronograma v3 | «Piloto en tiendas» pasa de 2026-12-04 a 2027-04-23 (+140 días). Los otros tres hitos no cambian. |
| 2026-10-16 | CC-02 | Ampliación de alcance: +113 días y +226.000.000 COP. «Autorizada por el comité», sin fecha de la decisión. |
| 2026-10-16 | Informe de avance (.pdf) | Amarillo, 57 %. Presupuesto aprobado 4.200.000.000, ejecutado 1.968.184.724, proyección 3.955.871.985 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-16 (cronograma v3) | 2027-04-23 (piloto) | «Ampliación de alcance», sin detalle de qué se amplía | CC-02 autoriza 113 días. El movimiento es de 140, así que 27 días no tienen autorización. |

- El cronograma v2 no está en la carpeta. Pasamos de v1 a v3 sin ver qué había en medio.
- Los 27 días sin autorización coinciden con el impacto de CC-01, que sigue «pendiente de presentación al comité». Los documentos no dicen si v3 incorporó CC-01; lo que se ve es que 140 = 27 + 113.
- CC-02 mide sus 113 días «sobre la línea base vigente». Si v3 ya incluía CC-01, esa base ya estaba corrida 27 días. No puedo resolverlo con lo que hay.
- El presupuesto aprobado sigue en 4.200.000.000 en el informe, mientras las dos solicitudes suman 280.000.000 COP adicionales (54.000.000 + 226.000.000). Solo CC-02 figura autorizada.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos. | — |

Javier Hoyos solicita CC-01 y CC-02 y firma el informe. No hay correos ni minutas en la carpeta que muestren otros cambios.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | No hay minutas ni transcripciones en la carpeta, así que no hay compromisos que seguir. | — | — |

La única fecha que se repite es el cierre del piloto, y se movió una sola vez.

### Desde cuándo lo declarado no se sostiene
- **Primer hito sin evidencia:** «Diseño de la experiencia aprobado», fecha 2026-06-25, figura «cerrado» sin documento de aprobación. Son 113 días hasta la fecha de corte.
- **Segundo:** «Ambiente de pruebas certificado», 2026-08-18, también «cerrado» sin certificación (59 días).
- **Qué se siguió reportando:** el 2026-10-16 el informe declara amarillo y 57 %. El plan sostiene entre 50 % y 75 %, así que el porcentaje cabe en el rango. Pero con 2 de 4 hitos cerrados, los dos cerrados sin evidencia y un tercero vencido, el amarillo no menciona el hito vencido, la replanificación ni los cambios. El script marca como no explicadas en el informe: hitos cumplidos sin evidencia, hito vencido, replanificación no autorizada y atraso de tiempo.
- **Una rareza en el archivo:** el cronograma v1 lleva fecha de 2026-04-22 pero marca como «cerrados» hitos que vencían en junio y agosto. O el archivo se editó después sin cambiar el nombre, o la fecha del nombre no es la del contenido. No puedo saber cuándo se escribió ese estado.
- Es un deslizamiento sin documentos intermedios: los cinco meses de silencio impiden fechar el punto exacto. Lo único firme es que, a la fecha de corte, el sustento es de 0 documentos de evidencia frente a 3 declaraciones.

### Lecciones ancladas a un hecho
1. **Hecho:** el 2026-10-16 el piloto se mueve 140 días, se autoriza un cambio de 113 y el informe del mismo día no los menciona. **Efecto:** 27 días sin autorización y un amarillo que no deja ver el atraso del 64.8 %.
2. **Hecho:** CC-01 (2026-10-09) sigue pendiente, y su impacto de 27 días coincide con el exceso del cronograma. **Efecto:** un cambio sin decidir parece estar ya aplicado.
3. **Hecho:** dos hitos «cerrados» (2026-06-25 y 2026-08-18) no tienen documento de recibo. **Efecto:** el 57 % se apoya en 2 hitos que nadie puede comprobar.

### Lo que no sé
- Qué ocurrió entre mayo y septiembre: no hay documentos de ese período.
- Cuándo decidió el comité sobre CC-02 y quién estaba presente: la solicitud no trae fecha ni acta.
- Si el cronograma v3 incorporó CC-01.
- Qué contiene el cronograma v2, si existió.
- Qué se amplió en el alcance: el acta lista «Componente 1, 2 y 3» sin descripción.
- Por qué el informe menciona un hallazgo de seguridad en medios de pago en un proyecto de etiquetas de precio.

No atribuyo intención: que el atraso no apareciera antes no dice que alguien lo ocultara. La historia sirve para tener esa conversación con datos.

### Siguiente paso
Llevar esta historia al comité del 2026-10-23 para decidir CC-01 y exigir el acta de la decisión de CC-02, el cronograma v2 y los documentos de recibo de los dos hitos cerrados. Puedo preparar el paquete de comité si lo pides.

*Cifras copiadas de `portafolio.py compute` (corte 2026-10-16). Fuentes: seis documentos de la carpeta PRY-210. Borrador de trabajo: la verificación es tuya.*
