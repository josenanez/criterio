Acta previa: sí, existe — "Acta de constitución · Centro de distribución norte", aprobada el 2025-08-03 (hace 14 meses). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16).

## Acta — PRY-202 · Centro de distribución norte
**Estado:** existe, del 2025-08-03

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** (monto y cambios sin comité) | Ausente | Ninguna decisión de Andrés Lozano tiene techo conocido. La reprogramación del despliegue por el congelamiento de fin de año (informe 2026-10-16) no se puede clasificar como decisión del gerente o como cambio que debía ir al Comité de Arquitectura. Por eso todo termina en el comité o, peor, no llega a él. |
| **Objetivo de negocio medible** | Presente, pero es la solución: "Entregar centro de distribución norte para Logística" | No hay resultado de negocio contra el cual decidir si el proyecto sigue valiendo la pena cuando se mueve el alcance o la fecha. |
| **Alcance** | "Componente 1, 2 y 3" | Los componentes no se describen. Cualquier trabajo puede entrar o quedar fuera, y el riesgo de regulación de datos personales (que "puede mover el alcance") no tiene referencia contra la cual medirse. |
| **Exclusiones** | "Lo que otro proyecto cubre" | Es una frase vacía: no nombra proyecto ni límite. Si dos proyectos se pisan, el acta no permite decir cuál es dueño de qué. |
| **Patrocinador** | Presente: Elena Duarte | Sin hallazgo. |
| **Supuestos y restricciones** | Ausentes (la sección de dependencias dice "Ninguna declarada") | Los dos riesgos del informe, la regulación de datos personales y la disponibilidad de jefes de tienda para el piloto, son supuestos que nunca se declararon. Hoy aparecen como riesgos sin dueño, probabilidad ni fecha. |
| **Criterio de éxito medible y quién lo mide** | "En producción y medido": no dice qué se mide, con qué umbral ni quién lo mide | No se puede probar el cierre ni refutar un "55 %". Nadie queda obligado a medir. |
| **Hitos principales** | Ausentes; solo inicio y cierre | Sin hitos, el 55 % reportado no se puede contrastar con nada intermedio. |
| **Cadencia del comité** | Ausente | No se sabe cuándo el Comité de Arquitectura debía ver el proyecto, así que su silencio no se puede juzgar. |
| **Producto asociado** | "No aplica" | Aceptable si es cierto. Un centro de distribución sin producto asociado conviene confirmarlo, pero no es falla del acta. |
| **Línea base vigente** | Solo la v1 (cierre 2026-04-24); no hay cambios registrados | La fecha de cierre pactada venció hace casi seis meses. El informe habla de una reprogramación sin nueva fecha y sin cambio aprobado. El acta, que es la única línea base, ya no describe lo que se está ejecutando. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice "Entregar centro de distribución norte para Logística" (acta, Objetivo del negocio).
**Alcance:** Componente 1, Componente 2, Componente 3, sin describirlos (acta, Alcance).
**Exclusiones:** "Lo que otro proyecto cubre", sin nombrar proyecto (acta, Fuera de alcance).
**Patrocinador:** Elena Duarte · **Gerente:** Andrés Lozano (acta; el informe 2026-10-16 coincide).
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento. Está sin declarar.
**Comité al que reporta:** Comité de Arquitectura (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. El acta declara "Ninguna" dependencia.
**Restricciones:** pendiente de definir.
**Criterio de éxito:** "Centro de distribución norte en producción y medido" (acta). Falta la métrica y el umbral · **Lo mide:** pendiente de definir.
**Presupuesto aprobado:** COP 4.200.000.000, aprobado por el Comité de Arquitectura el 2025-08-03 (acta).
**Fechas comprometidas:** inicio 2025-08-13, cierre 2026-04-24 (acta).
**Hitos principales:** pendiente de definir.

### Lo que el informe 2026-10-16 deja a la vista (no es parte del acta)
- Declara verde y 55 % de avance con la fecha de cierre ya vencida. El informe no da fecha nueva, y el acta no tiene cambio de línea base que la sustituya.
- Presupuesto del informe: comprometido 2.207.780.876 (52,6 %), ejecutado 1.090.124.030 (26,0 %), proyección al cierre 3.893.016.848 (92,7 % del aprobado).

### Después
- El acta quedó sin autoridad declarada. Recomiendo llevar esa definición al Comité de Arquitectura como decisión, no como trámite: hasta qué monto y qué cambios de alcance o fecha decide el gerente sin subir. Puedo prepararla con `/steering-pack`.
- De esta revisión salen supuestos que hoy no figuran en el acta: la regulación de datos personales y la disponibilidad de los jefes de tienda para el piloto. Puedo pasarlos al registro RAID con `/raid-log`.
- La fecha de cierre vencida sin cambio aprobado es materia de `/change-control`.

---
**Pie de rigor:** leí dos documentos: el acta de constitución del 2025-08-03 y el informe de avance del 2026-10-16, más la ficha PRY-202 y el texto en caché de ambos. No leí actas de comité, minutas ni contratos, porque la carpeta no tiene más. Lo que se acordó fuera de esos documentos no lo sé. Cada campo "pendiente de definir" significa que no está en esos documentos, no que no exista. No completé nada con lo razonable. La verificación de las citas es de quien lea este informe.
