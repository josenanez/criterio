# Corrida del 2026-10-16 · portfolio-setup

3 proyectos · 82 documentos, 69 releídos y 13 sin cambio · 87 s · 10 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 4 |
| `progress_vs_plan` | 1 |
| `commitment_overdue` | 1 |
| `declared_vs_evidence` | 1 |
| `variance_time` | 1 |
| `milestone_overdue` | 1 |
| `rebaseline_unauthorized` | 1 |

0 preguntas a la persona (sesión sin interfaz, se tomaron los valores sugeridos); primer resultado en la misma sesión, tiempo no medido; 3 proyectos (PRY-200, 202, 210): 10 señales, 1 verde contradicho, 202 sin señales por falta de cronograma

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos retail

**Miré:** 82 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md (32), .pdf (20), .docx (13), .xlsx (8), .csv (7), .json (1), .txt (1) · más reciente: 2026-10-16
**Eres:** PMO del portafolio (propuesto: hay 13 proyectos)
**Te aviso:** dos días antes del comité del 2026-10-23, y cada semana después (los comités semanales de las carpetas caen en viernes; la fecha del próximo la supuse a partir de ahí)
**En:** presentación (valor sugerido; nadie respondió)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.12 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 del Markdown 08da686bb7c9acf4…

Dónde queda todo: configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; los informes irán a `reportes/`.

### Probé con tres proyectos

Tomé tres de los que tienen documentación del 2026-10-16: PRY-200, PRY-202 y PRY-210.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Tienda en línea | 5 | Gerente Carlos Peña, patrocinadora Paula Céspedes, cierre comprometido 2026-12-11. Declara verde, 46 %. Presupuesto 6.800 M COP, ejecutado 2.855 M, proyección 6.931 M (+1,9 %). | Facultad del gerente, fase. Actas de recibo de 2 de los 3 hitos que el cronograma da por cerrados. |
| PRY-202 Centro de distribución norte | 2 | Gerente Andrés Lozano, patrocinador Elena Duarte. Declara verde, 55 %. Presupuesto 4.200 M COP, ejecutado 1.090 M, proyección 3.893 M (−7,3 %). Dos riesgos abiertos y un despliegue reprogramado por el congelamiento de fin de año. | Cronograma e hitos (no hay ninguno), producto, facultad del gerente, fase, la nueva fecha del despliegue. |
| PRY-210 Etiquetas electrónicas de precio | 6 | Gerente Javier Hoyos, patrocinador Óscar Ramírez. Declara amarillo, 57 %. Cierre original 2026-12-04, vigente 2027-04-23. Presupuesto 4.200 M COP, ejecutado 1.968 M, proyección 3.956 M. Dos solicitudes de cambio: CC-01 pendiente, CC-02 autorizada. | Producto, facultad del gerente, fase. Actas de recibo de los 2 hitos cerrados. |

### Hallazgos (los que levantó el cálculo)

**PRY-200 Tienda en línea**: declara verde, y el cálculo lo contradice (`declared_vs_evidence`) por tres señales:
- `progress_vs_plan`: declara 46 %, pero 3 de sus 4 hitos están cerrados en el cronograma, lo que sostiene entre 75 y 100 %. Son 29 puntos de diferencia.
- `milestone_met_without_evidence`: «Ambiente de pruebas certificado» (2026-04-27) e «Integración con el ERP» (2026-08-19) están cerrados en el cronograma, sin acta que lo pruebe. El hito «Diseño de la experiencia aprobado» sí tiene acta de recibo (2026-10-13).
- `commitment_overdue`: Javier Hoyos debía «entregar el punto 29» el 2026-10-02, y el comité del 2026-10-11 lo registra sin cumplir (14 días).

**PRY-210 Etiquetas electrónicas de precio** (declara amarillo):
- `variance_time`: el cierre se movió 140 días contra la línea base original (64,8 %).
- `rebaseline_unauthorized`: el cronograma v3 mueve 140 días, pero solo 113 están autorizados (CC-02). Los 27 restantes corresponden a CC-01, que sigue pendiente de comité.
- `milestone_overdue`: «Integración con el ERP» venció el 2026-10-11 y sigue abierto (5 días).
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado» y «Ambiente de pruebas certificado» están cerrados sin acta.

**PRY-202 Centro de distribución norte**: el cálculo no levantó ninguna señal. Eso no es lo mismo que «sano»: sin cronograma ni hitos el cálculo no tiene contra qué medir.

Totales: 3 proyectos, 2 con señales, 10 señales, 1 verde contradicho, 3 proyectos sin facultad del gerente declarada.

### El portafolio completo
10 proyectos más (PRY-199, 201, 203 a 209, 211) y 69 documentos por leer, en 2 lotes uno tras otro. Con lo que tomaron estos tres, calculo del orden de una hora a hora y media de trabajo continuo; es una estimación, no una medida. PRY-206 sola trae 27 documentos, incluido un `ficha-pm.json` de su gerente, que se leerá aparte de mi lectura.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- **Facultad del gerente:** ningún acta de los tres la declara. Sin ella no se puede saber si un cambio excede lo que el gerente decide solo.
- **Actas de recibo:** en PRY-200 y PRY-210 hay hitos cerrados sin acta.
- **PRY-202 sin cronograma:** el acta fija el cierre en 2026-04-24, y el informe del 2026-10-16 sigue en 55 % sin dar nueva fecha. Con un cronograma el cálculo podría medirlo.
- **Productos:** PRY-202 y PRY-210 dicen «No aplica» como producto asociado.
- **Fecha de la decisión de CC-02:** dice «autorizada por el comité» sin nombrar cuál comité ni cuándo.
- **Datos viejos:** en PRY-200 y PRY-202 varios campos solo salen del acta de 2025, con más de 12 meses sin confirmación posterior.
- **Cosas sueltas:** `2026-10-16-notas-reunion.txt` de PRY-206 está fuera de las carpetas de reuniones.
