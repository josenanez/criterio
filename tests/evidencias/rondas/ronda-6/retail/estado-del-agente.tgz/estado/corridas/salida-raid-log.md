## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-16

**De qué documentos sale:** las fichas en `estado/records/` (sección RAID de cada proyecto, extraída de los informes de avance del 2026-10-06 al 2026-10-16), las actas de constitución (sección «Dependencias declaradas») y las minutas y notas de reunión de la carpeta. Los códigos de ítem (p. ej. PRY-206-R2) los puse yo para poder citar: las fichas no traen ids.

12 riesgos · 6 supuestos · 15 incidencias · 3 dependencias (36 ítems)
36 sin doliente · 36 sin fecha de revisión o resolución · 1 no registrado formalmente · sin movimiento: no se puede medir (ver el pie)

Los conteos son **después de reclasificar** (9 ítems cambian de tipo; el porqué está abajo). Tal como venían en los informes: 20 riesgos registrados, 15 incidencias, 0 supuestos, 0 dependencias.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199-I1, PRY-206-I1, PRY-207-I1, PRY-210-I1 | Incidencia | Hallazgo de seguridad en los medios de pago. Aparece con casi la misma frase en cuatro proyectos, tres de ellos sin relación evidente con pagos. | Ninguno | 2026-10-14 a 2026-10-16 | Afecta a más de un proyecto y nadie responde por él. Decisión: nombrar un solo doliente y confirmar si es un mismo hallazgo o cuatro. No puedo saberlo con los documentos. |
| PRY-202-I1, PRY-203-I1, PRY-204-I1, PRY-211-I1 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año. En 203, 204 y 211 el informe dice que el cronograma sigue en v1 con la misma fecha; en 202 no da la nueva fecha. | Ninguno | 2026-10-07 a 2026-10-16 | La reprogramación ocurrió y la línea base no la recoge. Decisión: abrir solicitud de cambio por proyecto o decir que no se mueve. |
| PRY-200-I1, PRY-203-I2, PRY-208-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave. Misma frase en tres proyectos. | Ninguno | 2026-10-12 a 2026-10-16 | Si es la misma persona o el mismo equipo, afecta a tres proyectos. Hay que confirmarlo, no lo sé. |
| PRY-201-I1, PRY-205-I1 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite. | Ninguno | 2026-10-06 y 2026-10-07 | Ninguno de los dos informes da fecha de la nueva prueba. Decisión: quién responde y para cuándo. |
| PRY-206-R2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase. | Ninguno | 2026-10-16 | Dicho en reunión, no está en el informe. Ver la sección siguiente. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase. Las notas dicen «nadie lo anotó como riesgo». | Riesgo (PRY-206-R2) | `PRY-206-precios-dinámicos/2026-10-16-notas-reunion.txt`, línea 7 | 2026-10-16 |

Es el único. Busqué frases de riesgo en todas las minutas legibles y en el texto extraído de las demás; las de los comités son casi solo tablas de compromisos. No inventé ninguno más. Los proyectos 202, 203, 208, 210 y 211 no tienen carpeta de reuniones, así que de ellos no hay nada que revisar.

### Sin doliente o sin fecha
Ninguno de los 36 ítems tiene doliente. Los 21 que no son incidencias (12 riesgos, 6 supuestos, 3 dependencias) tampoco tienen probabilidad, fecha de revisión ni fecha de último movimiento. Las 15 incidencias traen «desde», pero ninguna trae fecha esperada de resolución. Se reporta como hallazgo y no relleno nada. Lo mostrado aquí es el patrón, no ítem por ítem; el detalle por ítem está en el registro completo. Los dos hechos que más pesan:

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 36 | Todos | Cualquier ítem del registro | Doliente |
| Los 12 riesgos | Riesgo | Cualquier riesgo | Probabilidad e impacto (solo los 6 de «regulación de datos personales» traen impacto: «alcance») y fecha de revisión |
| Las 15 incidencias | Incidencia | Cualquier incidencia | Fecha esperada de resolución |

### Dependencias en riesgo
Ningún proyecto declara una dependencia de otro: las 13 actas de constitución dicen «Ninguna declarada». Por eso el cruce entre proyectos no tiene nada que cruzar, y eso es en sí un hallazgo. Lo que sí hay son tres dependencias de un proveedor, que estaban escritas como riesgo:

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-201-D1 | Proveedor (el informe no lo nombra; sin código de proyecto) | No | «No ha confirmado la fecha de la última entrega», informe del 2026-10-07 |
| PRY-209-D1 | Proveedor (hay un contrato CT-404 en la carpeta; el informe no dice que sea ese) | No | Lo mismo, informe del 2026-10-08. Además la CC-01 de este proyecto (+70 días) figura aprobada «por el comité» sin nombrar cuál ni fecha. |
| PRY-211-D1 | Proveedor (el informe no lo nombra) | No | Lo mismo, informe del 2026-10-14 |

Una pregunta, no un ítem: PRY-199 y PRY-207 tienen un hito «Integración con el ERP» (2027-05-11 y 2027-10-01) y PRY-209 es la migración del ERP, que movió su fecha +70 días. Ninguna acta dice que dependan de PRY-209. Lo señalo para que alguien confirme si hay dependencia; no la registro.

### Reclasificados y duplicados
- **Riesgo → dependencia (3):** PRY-201, 209 y 211, «El proveedor no ha confirmado la fecha de la última entrega». Depende de un tercero y ya es un hecho (no ha confirmado), no una posibilidad.
- **Riesgo → supuesto (6):** PRY-199, 201, 202, 203, 208 y 211, «Disponibilidad de los jefes de tienda para el piloto». Se está dando por cierta una disponibilidad que nadie verificó. Si el gerente prefiere mantenerlo como riesgo, es su decisión; la frase del informe no dice cuál es.
- **Riesgo ya ocurrido (no cambié el tipo, lo marco):** PRY-204-R1 (congelamiento de cambios) tiene su incidencia en PRY-204-I1. PRY-200-R2 y PRY-203-R1 (concentración del conocimiento) conviven con la incidencia de rotación del desarrollador clave (PRY-200-I1, PRY-203-I2). El riesgo ya se materializó y sigue registrado como si no.

### Registro completo
Probabilidad, impacto, doliente y fecha: «—» donde la ficha no los trae (casi siempre). «Último movimiento»: la ficha no lo registra; se muestra la fecha del informe donde aparece.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-14 |
| PRY-199-I1 | Incidencia | Hallazgo de seguridad levantado en los medios de pago | — | — | — | — | desde 2026-10-14 |
| PRY-199-I2 | Incidencia | Validación con dos tiendas extendida una semana por el conteo de inventario | — | — | — | — | desde 2026-10-14 |
| PRY-200-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-16 |
| PRY-200-R2 | Riesgo | Concentración del conocimiento en una sola persona (ver I1) | — | — | — | — | informe 2026-10-16 |
| PRY-200-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | — | — | desde 2026-10-16 |
| PRY-201-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | informe 2026-10-07 |
| PRY-201-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-07 |
| PRY-201-I1 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | — | — | desde 2026-10-07 |
| PRY-202-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-16 |
| PRY-202-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-16 |
| PRY-202-I1 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; el informe no da la nueva fecha | — | — | — | — | desde 2026-10-16 |
| PRY-203-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-15 |
| PRY-203-R1 | Riesgo | Concentración del conocimiento en una sola persona (ver I2) | — | — | — | — | informe 2026-10-15 |
| PRY-203-I1 | Incidencia | Despliegue reprogramado por el congelamiento; el cronograma sigue en v1 con la misma fecha | — | — | — | — | desde 2026-10-15 |
| PRY-203-I2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | — | — | desde 2026-10-15 |
| PRY-204-R1 | Riesgo | Congelamiento de cambios en temporada alta (ya ocurrió: ver I1) | — | — | — | — | informe 2026-10-07 |
| PRY-204-I1 | Incidencia | Despliegue reprogramado por el congelamiento; el cronograma sigue en v1 con la misma fecha | — | — | — | — | desde 2026-10-07 |
| PRY-205-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-06 |
| PRY-205-I1 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | — | — | desde 2026-10-06 |
| PRY-206-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-16 |
| PRY-206-R2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | — | — | notas 2026-10-16 |
| PRY-206-I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | — | — | desde 2026-10-16 |
| PRY-207-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | informe 2026-10-16 |
| PRY-207-R2 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-16 |
| PRY-207-I1 | Incidencia | Hallazgo de seguridad levantado en los medios de pago | — | — | — | — | desde 2026-10-16 |
| PRY-208-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-12 |
| PRY-208-R1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | alcance | — | — | informe 2026-10-12 |
| PRY-208-I1 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | — | — | desde 2026-10-12 |
| PRY-209-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | informe 2026-10-08 |
| PRY-210-R1 | Riesgo | Congelamiento de cambios en temporada alta | — | — | — | — | informe 2026-10-16 |
| PRY-210-I1 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | — | — | desde 2026-10-16 |
| PRY-210-I2 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | — | — | — | — | desde 2026-10-16 |
| PRY-211-D1 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | informe 2026-10-14 |
| PRY-211-S1 | Supuesto | Disponibilidad de los jefes de tienda para el piloto | — | — | — | — | informe 2026-10-14 |
| PRY-211-I1 | Incidencia | Despliegue reprogramado por el congelamiento; el cronograma sigue en v1 con la misma fecha | — | — | — | — | desde 2026-10-14 |

### Después
Puedo subir a comité los cinco puntos de «Necesitan decisión ahora» (cuatro afectan a más de un proyecto y el quinto es un riesgo sin registrar). También puedo proponer doliente para los ítems que no lo tienen — proponer, no asignar. Dime cuál y lo preparo; no lo hago sin que lo pidas.

### Pie de rigor
- **Qué no sé:** si los hallazgos y las pérdidas de equipo con la misma frase en varios proyectos son un mismo hecho o hechos distintos; quién es doliente de cualquier ítem; cuánto lleva cada uno sin movimiento (ninguna ficha guarda fecha de último movimiento, así que el criterio «más de dos períodos sin movimiento» no se puede aplicar); la escala de probabilidad e impacto de la organización (no está definida y no inventé una).
- **Qué no revisé a fondo:** la búsqueda de riesgos dichos al pasar fue por palabras clave sobre minutas y texto extraído; no leí línea por línea los comités de PRY-204, 205 y 206 en .docx y .md. Un riesgo dicho con otras palabras podría no haber salido.
- **Mi lectura:** lo clasificado como supuesto o dependencia es mi lectura del texto del informe, no algo que el gerente haya declarado así. Los informes de avance son declaración del gerente; no los contrasté aquí contra otra evidencia.
- Es un borrador de trabajo; la verificación es tuya, cada dato lleva su ficha y documento de origen.
