# Corrida · 2026-10-16-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T16:02:00 · **Fin:** 2026-10-16T16:02:56 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 40 | 76 | Barrido: 82 documentos sin cambios, 0 recalculados; 21 citas de PRY-206 no resuelven (ficha del gerente, no corregida). Confirmación: 5 preguntas formuladas, sin respuesta (sesión sin interfaz). Sin peticiones. No sé si la ruta relativa de las citas de PRY-206 es un defecto de la ficha o del índice. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 30, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 7, `commitment_undated` 6, `vendor_deliverable_late` 4, `milestone_overdue` 3, `commitment_rescheduled` 3, `variance_time` 3, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## 2026-10-16

**Revisé:** 82 documentos. Ninguno cambió y no recalculé ningún proyecto. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no hubo que registrarlos de nuevo. No había peticiones en el servidor.

### Lo que cruzó un umbral
Nada nuevo: la comparación contra la foto de hoy no muestra cambios. Sí hay un hallazgo del barrido.

- **PRY-206: 21 campos de la ficha citan archivos que el índice no encuentra.** La ficha del gerente (`00-gobierno/ficha-pm.json`) cita con rutas relativas a la carpeta del proyecto, como `00-gobierno/2025-11-15-acta-constitucion.docx`. Esos archivos sí están en disco, así que no hubo borrado. No sé si el defecto está en la ficha o en el índice. No toqué la ficha porque la escribe el gerente del proyecto.

### Preguntas
Nadie responde en esta sesión. Elegí cinco campos por importancia y los dejo **preguntados el 2026-10-16, sin respuesta**:

1. **PRY-206, avance declarado.** El informe declara 21 %, pero el cronograma tiene los 5 hitos cumplidos y 4 de ellos no tienen documento de respaldo. ¿Cuál cifra es la vigente?
2. **PRY-209, factura al proveedor.** Integra Comercio S.A.S. tiene 275.224.201 COP facturados y 2 entregables pendientes, el más viejo con 307 días de atraso. ¿Qué documento de aceptación respalda la factura?
3. **PRY-210, línea base.** Se movió 140 días y solo hay 113 autorizados. ¿Dónde está la aprobación de los 27 días restantes?
4. **PRY-211, hitos cumplidos.** Declara 47 % de avance con los 5 hitos cumplidos, y 4 de ellos no tienen respaldo. ¿Cuál es el estado real de los hitos?
5. **PRY-205, despliegue en la cadena.** Está vencido hace 10 días, y el proveedor Retail Andino tiene el licenciamiento pendiente hace 295 días. ¿Hay nueva fecha acordada?

Dejé constancia del barrido y de la confirmación, y la corrida quedó registrada con su salida en `estado/corridas/salida-portfolio-wake.md`.

**Vuelvo el 2026-10-17.** El informe de comité se genera el 2026-10-21 para el comité del 2026-10-23.
