# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:46:12 · **Fin:** 2026-10-16T15:46:47 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 20 | 76 | 82 documentos sin cambio, 0 por releer. 22 citas de PRY-206 no resuelven porque una ficha duplicada (estado/PRY-206-precios-dinámicos/records) cita sin el prefijo de carpeta; los archivos existen. No se corrigió nada. No se evaluó si la ficha duplicada difiere en contenido de estado/records/PRY-206.json. |

Por señal (`document-index`): `milestone_met_without_evidence` 30, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 7, `commitment_undated` 6, `vendor_deliverable_late` 4, `milestone_overdue` 3, `commitment_rescheduled` 3, `variance_time` 3, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

No hay nada que releer en la carpeta, pero 22 citas de PRY-206 no resuelven. Es un problema de ruta, no de documentos borrados. Corrí `/document-index` el 2026-10-16; los términos ya estaban vigentes (v1.1, a nombre de José Francisco Ñáñez), así que no hubo que registrarlos de nuevo.

**Estado de la carpeta:** hay 82 documentos y los 82 están sin cambios. No hay nuevos, cambiados, reguardados, renombrados ni borrados, y el índice no reportó formatos ilegibles. No hace falta `/portfolio-scan`.

**Citas rotas (22, todas de PRY-206):**
- **Dónde:** están en una ficha duplicada, `estado/PRY-206-precios-dinámicos/records/PRY-206.json`.
- **Cuáles cita:** `00-gobierno/2025-11-15-acta-constitucion.docx`, `10-plan/2025-11-15-cronograma-v1.csv`, `20-seguimiento/2026-10-16-informe-avance.pdf` y `20-seguimiento/2026-09-21-factura-ct-914.pdf`.
- **Por qué no resuelven:** los archivos sí existen en `documentos/proyectos/PRY-206-precios-dinámicos/`. Esa ficha los cita sin el prefijo `PRY-206-precios-dinámicos/`, y las demás fichas (incluida `estado/records/PRY-206.json`) sí lo llevan.
- **No corregí nada.** Hay que decidir si se corrige la ruta o se retira la ficha duplicada. Tampoco comparé si su contenido difiere del de `estado/records/PRY-206.json`.

**Registro de la corrida:**
- **Salida:** `/home/claude/banco/ronda-6/retail/espacio/estado/corridas/salida-document-index.md`.
- **Corrida:** quedó registrada como `2026-10-16-document-index-1` y tardó 20 segundos.
- **Señales abiertas:** la corrida contó 76, de otras fuentes del estado y no de este índice. Ejemplos: 30 de hitos cumplidos sin evidencia y 9 de compromisos vencidos.
