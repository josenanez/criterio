# Corrida · 2026-10-16-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:58:05 · **Fin:** 2026-10-16T16:00:08 · **Duración:** 124 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 108 | 76 | Paquete de comité 2026-10-23: 6 decisiones, 7 escalamientos, 13 fichas. No hay actas de un comité anterior; tres cambios aprobados por un comité sin nombre ni fecha. Autoridad sin declarar en los 13. No calculé la fecha de PRY-210 sin la CC-01 ni sumas entre proyectos porque el script no las da; los vencimientos del punto 4 son lectura mía. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 30, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 7, `commitment_undated` 6, `vendor_deliverable_late` 4, `milestone_overdue` 3, `commitment_rescheduled` 3, `variance_time` 3, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Dejé el paquete de comité para el 2026-10-23 y la corrida quedó registrada como `2026-10-16-steering-pack-1`. Los términos v1.1 ya estaban vigentes a nombre de José Francisco Ñáñez desde hoy, así que no los registré otra vez. El paquete está en `estado/corridas/salida-steering-pack.md`.

**Las 6 decisiones**
1. **Quién decide:** la autoridad no está declarada en ninguno de los 13 proyectos. Recomiendo que el comité apruebe los cambios mientras no haya un umbral escrito.
2. **PRY-210, CC-01:** +27 días y 54.000.000 COP, pendiente, pero la línea base ya se movió esos 27 días sin autorización.
3. **Congelamiento de fin de año:** PRY-203, 202, 204 y 211 reportan contra una fecha que sus informes dicen que ya no usan. PRY-203 tiene una solicitud de +30 días sin solicitante.
4. **Fechas de fin vencidas sin cerrar:** PRY-211, 202, 209, 206 y 205 siguen sin replanificar. Esta es una lectura mía de las fechas, porque el script no emitió la señal.
5. **Pagos a proveedores:** en PRY-209 hay 275.224.201 COP facturados con 0 de 2 entregables aceptados. En PRY-205, un entregable aceptado no tiene evidencia y otros dos están vencidos.
6. **Verde sin sustento:** 7 proyectos declaran verde contra señales propias.

El paquete trae además 7 escalamientos sin decisión asociada, una línea por cada uno de los 13 proyectos y el anexo.

**Lo que no pude hacer**
- **Ciclo anterior:** no hay actas ni decisiones de un comité previo en las fichas. Solo hay tres cambios aprobados por «el comité» sin nombre ni fecha: PRY-207 CC-01, PRY-209 CC-01 y PRY-210 CC-02. Los dejé como «no verificable».
- **Cifras:** no escribí la fecha de PRY-210 sin la CC-01 ni sumas entre proyectos, porque el script no las da.

Es un borrador de trabajo: la verificación es de quien lo use, y cada dato lleva su ficha de origen.

Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
