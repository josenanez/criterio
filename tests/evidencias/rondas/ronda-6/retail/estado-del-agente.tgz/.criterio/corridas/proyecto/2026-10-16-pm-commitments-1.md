# Corrida · 2026-10-16-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:33:02 · **Fin:** 2026-10-16T15:34:05 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 30 | 19 | Reprogramado 5, 4 y 3 veces: Diana Molina (documento 1), Óscar Ramírez (prueba 2), Paula Céspedes (prueba 10); 5 vencidos sin evidencia, 5 sin fecha; verde declarado contradicho |

Por señal (`pm-commitments`): `commitment_overdue` 5, `commitment_undated` 5, `milestone_met_without_evidence` 4, `commitment_rescheduled` 3, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Terminé la revisión de compromisos de PRY-206, Precios dinámicos, al 2026-10-16. Quedó registrada como `2026-10-16-pm-commitments-1`. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16, así que no los registré otra vez.

**Se viene reprogramando:**
- **Diana Molina**, «Enviar el documento 1»: 5 veces. Pasó del 09-18 al 11-18, 61 días de corrimiento. Es lo primero que hay que mirar.
- **Óscar Ramírez**, «Cerrar la prueba 2»: 4 veces, del 09-23 al 11-01.
- **Paula Céspedes**, «Cerrar la prueba 10»: 3 veces, del 09-23 al 10-30.

**Vencidos sin evidencia (5):**
- **Natalia Ospina**, anexo 3: 35 días.
- **Javier Hoyos**, matriz 14: 17 días.
- **Beatriz Cuéllar**, documento 9: 8 días.
- **Javier Hoyos**, ambiente 20: 3 días.
- **Liliana Torres**, diseño 5: 2 días.

Natalia Ospina, Liliana Torres y Beatriz Cuéllar dicen que ya entregaron, pero no hay acta que lo respalde. Siguen abiertos.

**Vencen esta semana (4):**
- **Paula Céspedes**, anexo 11, el 10-18.
- **Ricardo Salas**, prueba 18, el 10-19.
- **María Restrepo**, punto 8, el 10-20.
- **María Restrepo**, punto 24, el 10-21.

**Sin fecha (5):** Diana Molina, Andrés Lozano, Óscar Ramírez, Paula Céspedes y Laura Vélez. El de Laura Vélez dice «la otra semana», que no es una fecha, y no la calculé.

**Cerrados con documento (3):** Jorge Medina (matriz 6 y diseño 13) y Felipe Arango (fecha 7).

El informe de avance declara el proyecto en verde. Con estos números, el script lo marca como contradicho por la evidencia.

Ofrezco formular «Enviar el documento 1» como decisión para el comité del 2026-10-30. El acta no nombra una autoridad con facultad para decidirlo, así que alguien tendría que confirmarla. También puedo correr `/pm-publish` para que la PMO vea el estado actualizado.

El informe completo está en `estado/PRY-206-precios-dinámicos/corridas/salida-pm-commitments.md`.
