# Corrida · 2026-10-16-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-16T15:57:12 · **Fin:** 2026-10-16T15:58:01 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 32 | 76 | No se generó acta de cierre: el proyecto sigue en marcha (55% declarado, verde) con fecha de cierre 2026-04-24 vencida y sin nueva fecha. Se dijo que no se sabe si terminó, ni evidencia de criterio de éxito, hitos, dolientes de RAID ni fecha reprogramada. |

Por señal (`project-closure`): `milestone_met_without_evidence` 30, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 7, `commitment_undated` 6, `vendor_deliverable_late` 4, `milestone_overdue` 3, `commitment_rescheduled` 3, `variance_time` 3, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Cierre PRY-202, Centro de distribución norte (2026-10-16)

No generé el acta de cierre, porque ningún documento dice que el proyecto haya terminado.

**De dónde sale:** la ficha `estado/records/PRY-202.json`, el acta de constitución (2025-08-03) y el informe de avance (corte 2026-10-16). Las cifras derivadas las copié de `compute`.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16). No los registré de nuevo.
- **Estado del proyecto:** el informe lo declara en verde, con 55 % de avance.
- **Criterio de éxito:** el acta pide "Centro de distribución norte en producción y medido". No hay evidencia de que se haya cumplido, así que no se puede determinar.
- **Entregables:** los Componentes 1, 2 y 3 no tienen descripción ni evidencia. No hay hitos ni cronograma en la carpeta.
- **Fecha:** la fecha de cierre pactada era 2026-04-24 y ya pasó. El informe dice que "se reprogramó el despliegue" pero no da fecha nueva, y no hay línea base nueva ni cambio aprobado.
- **Desviación en fecha:** `compute` da 0 días de desviación y ninguna alerta, pero eso es porque no hay otra fecha contra la que medir. El atraso real existe y no se calcula.
- **Dinero (COP):**
  - Aprobado: 4.200.000.000.
  - Comprometido: 2.207.780.876 (52,6 %).
  - Ejecutado: 1.090.124.030 (26,0 %).
  - Proyección al cierre: 3.893.016.848 (−7,3 % sobre lo aprobado).
  - Estas cifras vienen de la declaración del gerente, no de un registro contable.
- **RAID:** hay dos riesgos abiertos y una incidencia abierta (la reprogramación del despliegue), todos sin responsable.
- **Lecciones:** ninguna entra, porque ninguna se puede anclar a un hecho con fecha y efecto.
- **Archivo:** no ofrezco mover la carpeta a `archivo/` ni congelar la ficha, porque el proyecto sigue activo según su último informe.

La salida completa está en `estado/corridas/salida-project-closure.md`. La corrida quedó registrada con id `2026-10-16-project-closure-1`.

Esto es un borrador de trabajo y la verificación es de quien lo lea.
