# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Etiquetas electrónicas de precio
**Fecha:** 2026-10-09
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +27 días sobre la línea base vigente |
| Costo | 54.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
