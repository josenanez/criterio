# Comité Comercial · Tienda en línea

**Fecha:** 2026-10-11
**Asistentes:** Carlos Peña, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 29 | 2026-10-02 |
