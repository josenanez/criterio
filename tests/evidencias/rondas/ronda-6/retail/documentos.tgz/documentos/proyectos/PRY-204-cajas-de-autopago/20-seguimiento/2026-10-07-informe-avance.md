# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-10-07
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **46%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 792.548.398 |
| Ejecutado | 693.057.063 |
| Proyección al cierre | 1.220.716.745 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
