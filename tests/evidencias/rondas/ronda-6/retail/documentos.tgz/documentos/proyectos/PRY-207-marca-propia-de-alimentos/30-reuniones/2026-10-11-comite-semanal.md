# Comité Comercial · Marca propia de alimentos

**Fecha:** 2026-10-11
**Asistentes:** Mauricio Pérez, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 5 | 2026-09-30 |
