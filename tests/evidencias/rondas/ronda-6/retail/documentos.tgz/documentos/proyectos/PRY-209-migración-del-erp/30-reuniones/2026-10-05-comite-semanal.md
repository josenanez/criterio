# Comité de Transformación Digital · Migración del ERP

**Fecha:** 2026-10-05
**Asistentes:** Felipe Arango, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 33 | por definir |
