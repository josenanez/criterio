# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-09-11
**Asistentes:** Diana Molina, Felipe Arango, Jorge Medina, Liliana Torres, María Restrepo, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-09-18 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-09-23 |
| Liliana Torres | Aprobar el diseño 5 | 2026-09-24 |
| Jorge Medina | Actualizar la matriz 6 | 2026-09-24 |
| Felipe Arango | Confirmar la fecha 7 | 2026-09-19 |
| María Restrepo | Entregar el punto 8 | por definir |

## Lo que se dijo

- Natalia Ospina dice que ya entregó «revisar el anexo 3». No se presentó acta.
- Diana Molina dice que ya entregó «validar el ambiente 4». No se presentó acta.
