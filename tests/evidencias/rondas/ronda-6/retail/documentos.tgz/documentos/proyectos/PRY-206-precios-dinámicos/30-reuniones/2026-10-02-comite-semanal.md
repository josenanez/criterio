# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-10-02
**Asistentes:** Andrés Lozano, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-27 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-21 |
| Felipe Arango | Confirmar la fecha 7 | 2026-10-07 |
| María Restrepo | Entregar el punto 8 | 2026-09-29 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-20 |
| Paula Céspedes | Revisar el anexo 11 | 2026-09-24 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-05 |
| Jorge Medina | Aprobar el diseño 13 | 2026-10-25 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-09-29 |
| Elena Duarte | Confirmar la fecha 15 | 2026-10-28 |
| Liliana Torres | Entregar el punto 16 | 2026-10-13 |
| Andrés Lozano | Enviar el documento 17 | por definir |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-19 |
| Paula Céspedes | Revisar el anexo 19 | por definir |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-13 |

## Lo que se dijo

- Beatriz Cuéllar dice que ya entregó «enviar el documento 9». No se presentó acta.
