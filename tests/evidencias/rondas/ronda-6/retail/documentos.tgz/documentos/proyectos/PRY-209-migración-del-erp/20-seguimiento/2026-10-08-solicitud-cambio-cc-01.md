# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Migración del ERP
**Fecha:** 2026-10-08
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +70 días sobre la línea base vigente |
| Costo | 140.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
