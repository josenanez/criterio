# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Mauricio Pérez

## Estado declarado

**Amarillo**

Avance reportado: **47%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.649.346.291 |
| Ejecutado | 1.221.930.488 |
| Proyección al cierre | 3.304.906.826 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad de los jefes de tienda para el piloto
