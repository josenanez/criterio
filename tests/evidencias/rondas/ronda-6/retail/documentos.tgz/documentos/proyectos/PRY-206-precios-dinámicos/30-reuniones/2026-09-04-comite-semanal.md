# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-09-04
**Asistentes:** Diana Molina, Natalia Ospina, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | por definir |
| Óscar Ramírez | Cerrar la prueba 2 | por definir |
| Natalia Ospina | Revisar el anexo 3 | 2026-09-11 |
| Diana Molina | Validar el ambiente 4 | por definir |
