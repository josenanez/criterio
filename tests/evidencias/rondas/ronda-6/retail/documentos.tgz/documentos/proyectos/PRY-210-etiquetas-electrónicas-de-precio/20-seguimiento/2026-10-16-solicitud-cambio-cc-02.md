# Solicitud de cambio CC-02

**Proyecto:** PRY-210 · Etiquetas electrónicas de precio
**Fecha:** 2026-10-16
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +113 días sobre la línea base vigente |
| Costo | 226.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
