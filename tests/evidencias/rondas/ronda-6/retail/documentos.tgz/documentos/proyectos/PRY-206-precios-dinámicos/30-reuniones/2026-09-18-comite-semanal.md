# Comité de Arquitectura · Precios dinámicos

**Fecha:** 2026-09-18
**Asistentes:** Beatriz Cuéllar, Diana Molina, Felipe Arango, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-09-27 |
| Óscar Ramírez | Cerrar la prueba 2 | 2026-10-03 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-14 |
| Jorge Medina | Actualizar la matriz 6 | 2026-09-24 |
| Felipe Arango | Confirmar la fecha 7 | 2026-10-07 |
| María Restrepo | Entregar el punto 8 | 2026-09-29 |
| Beatriz Cuéllar | Enviar el documento 9 | por definir |
| Paula Céspedes | Cerrar la prueba 10 | 2026-09-23 |
| Paula Céspedes | Revisar el anexo 11 | 2026-09-24 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-09-24 |
