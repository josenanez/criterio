# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Marca propia de alimentos
**Fecha:** 2026-10-09
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +64 días sobre la línea base vigente |
| Costo | 128.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
