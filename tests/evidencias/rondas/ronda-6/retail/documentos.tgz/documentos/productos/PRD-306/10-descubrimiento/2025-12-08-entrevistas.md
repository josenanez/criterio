# Entrevistas · App de clientes

**Ronda:** Ronda · 2025-12-08
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-12-08

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
