# Definición de producto · Tarjeta de la tienda

**Código:** PRD-309
**Gerente de producto:** Gustavo Neira
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-06-29

## El problema

El segmento Clientes frecuentes no tiene tarjeta de la tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-05-26 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
