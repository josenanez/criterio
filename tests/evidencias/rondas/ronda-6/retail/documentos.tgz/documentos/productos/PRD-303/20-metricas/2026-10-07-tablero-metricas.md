# Tablero de métricas · Pago con QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 300.554 | 2026-10-07 |
