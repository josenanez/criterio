# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-02-25
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 192.464 | Caso de negocio, 2026-02-25 |

## Retorno esperado

Retorno esperado en 24 meses.
