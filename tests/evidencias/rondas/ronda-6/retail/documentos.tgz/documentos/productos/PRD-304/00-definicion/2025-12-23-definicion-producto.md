# Definición de producto · Marca propia

**Código:** PRD-304
**Gerente de producto:** Diana Molina
**Segmento:** Hogares
**Fecha de la definición:** 2025-12-23

## El problema

El segmento Hogares no tiene marca propia.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-05-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
