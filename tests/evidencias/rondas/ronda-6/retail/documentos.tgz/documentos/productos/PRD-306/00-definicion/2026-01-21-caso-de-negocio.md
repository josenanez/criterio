# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-01-21
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 139.543 | Caso de negocio, 2026-01-21 |

## Retorno esperado

Retorno esperado en 24 meses.
