# Definición de producto · Bolsas reutilizables

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-18

## El problema

El segmento Personas no tiene bolsas reutilizables.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-08-27 · verificado

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
