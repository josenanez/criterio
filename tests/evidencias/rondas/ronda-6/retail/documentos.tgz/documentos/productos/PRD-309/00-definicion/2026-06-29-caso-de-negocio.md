# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-06-29
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 250.890 | Caso de negocio, 2026-06-29 |

## Retorno esperado

Retorno esperado en 24 meses.
