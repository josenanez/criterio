# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2025-10-25
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 107.018 | Caso de negocio, 2025-10-25 |

## Retorno esperado

Retorno esperado en 24 meses.
