# Definición de producto · Compra y recoge

**Código:** PRD-307
**Gerente de producto:** Gustavo Neira
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-02-25

## El problema

El segmento Pequeños negocios no tiene compra y recoge.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-23 · verificado

## Proyectos que lo construyen

- Ninguno declarado
