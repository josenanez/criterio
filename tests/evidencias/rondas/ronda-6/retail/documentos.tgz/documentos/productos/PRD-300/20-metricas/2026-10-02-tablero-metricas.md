# Tablero de métricas · Venta en línea

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 121.337 | 2026-10-02 |
