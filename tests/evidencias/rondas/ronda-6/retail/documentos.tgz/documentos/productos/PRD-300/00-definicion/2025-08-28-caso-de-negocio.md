# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2025-08-28
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 145.158 | Caso de negocio, 2025-08-28 |

## Retorno esperado

Retorno esperado en 24 meses.
