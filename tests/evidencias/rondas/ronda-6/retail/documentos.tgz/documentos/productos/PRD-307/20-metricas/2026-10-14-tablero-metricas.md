# Tablero de métricas · Compra y recoge

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 193.857 | 2026-10-14 |
