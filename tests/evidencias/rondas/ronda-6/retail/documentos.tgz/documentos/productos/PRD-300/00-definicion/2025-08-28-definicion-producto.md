# Definición de producto · Venta en línea

**Código:** PRD-300
**Gerente de producto:** Liliana Torres
**Segmento:** Empresas
**Fecha de la definición:** 2025-08-28

## El problema

El segmento Empresas no tiene venta en línea.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-09-16 · verificado

## Proyectos que lo construyen

- Ninguno declarado
