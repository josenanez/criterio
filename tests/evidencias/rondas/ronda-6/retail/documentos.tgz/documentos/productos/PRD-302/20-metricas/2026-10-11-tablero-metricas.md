# Tablero de métricas · Autopago en tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 107.348 | 2026-10-11 |
