# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2025-12-23
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 111.504 | Caso de negocio, 2025-12-23 |

## Retorno esperado

Retorno esperado en 24 meses.
