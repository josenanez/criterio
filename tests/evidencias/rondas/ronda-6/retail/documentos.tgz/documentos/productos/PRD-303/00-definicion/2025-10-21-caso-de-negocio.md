# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2025-10-21
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 298.458 | Caso de negocio, 2025-10-21 |

## Retorno esperado

Retorno esperado en 24 meses.
