# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Camilo Beltrán
**Segmento:** Empresas
**Fecha de la definición:** 2025-12-11

## El problema

El segmento Empresas no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **Las tiendas soportan el volumen** · declarado el 2026-07-06 · verificado

## Proyectos que lo construyen

- Ninguno declarado
