# Definición de producto · Autopago en tienda

**Código:** PRD-302
**Gerente de producto:** Elena Duarte
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2025-10-25

## El problema

El segmento Pequeños negocios no tiene autopago en tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-08-20 · verificado

## Proyectos que lo construyen

- Ninguno declarado
