# Tablero de métricas · Tarjeta de la tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 181.312 | 2026-10-07 |
