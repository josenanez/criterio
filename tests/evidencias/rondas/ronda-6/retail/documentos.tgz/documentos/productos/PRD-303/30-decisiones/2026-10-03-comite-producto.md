# Comité de producto · Pago con QR

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-05-19 | — |
| REQ-4301 | Requerimiento REQ-4301 | Jorge Medina | — | Cliente entrevistado | propuesto | 2026-08-28 | — |
| REQ-4302 | Requerimiento REQ-4302 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4303 | Requerimiento REQ-4303 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-04 | — |
| REQ-4304 | Requerimiento REQ-4304 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-08-29 | — |
| REQ-4305 | Requerimiento REQ-4305 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-31 | — |
| REQ-4306 | Requerimiento REQ-4306 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-24 | — |
| REQ-4307 | Requerimiento REQ-4307 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-18 | — |
| REQ-4308 | Requerimiento REQ-4308 | Sandra Gil | se verifica en producción | — | aceptado | 2026-07-10 | — |
| REQ-4309 | Requerimiento REQ-4309 | Rubén Cárdenas | — | — | aceptado | 2026-06-06 | — |
| REQ-4310 | Requerimiento REQ-4310 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-31 | — |
| REQ-4311 | Requerimiento REQ-4311 | Rubén Cárdenas | — | — | aceptado | 2026-08-22 | — |
| REQ-4312 | Requerimiento REQ-4312 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-19 | — |
| REQ-4313 | Requerimiento REQ-4313 | sin asignar | — | Cliente entrevistado | aceptado | 2026-08-15 | — |

## Decisiones

- Se mantiene el plan
