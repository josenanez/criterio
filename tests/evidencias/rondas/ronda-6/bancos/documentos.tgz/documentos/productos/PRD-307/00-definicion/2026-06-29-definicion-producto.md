# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Jorge Medina
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-06-29

## El problema

El segmento Microcomercio no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-07-26 · verificado

## Proyectos que lo construyen

- Ninguno declarado
