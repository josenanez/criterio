# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Javier Hoyos
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-04-17

## El problema

El segmento Base de la pirámide no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-06-21 · verificado

## Proyectos que lo construyen

- Ninguno declarado
