# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2025-12-25
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 204.945 | Caso de negocio, 2025-12-25 |

## Retorno esperado

Retorno esperado en 24 meses.
