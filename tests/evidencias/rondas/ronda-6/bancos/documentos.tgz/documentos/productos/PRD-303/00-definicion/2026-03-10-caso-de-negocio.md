# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-03-10
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 137.238 | Caso de negocio, 2026-03-10 |

## Retorno esperado

Retorno esperado en 24 meses.
