# Tablero de métricas · Nómina empresarial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 74.390 | 2026-10-02 |
