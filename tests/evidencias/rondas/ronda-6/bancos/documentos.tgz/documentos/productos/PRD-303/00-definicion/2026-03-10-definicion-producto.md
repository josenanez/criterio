# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Ricardo Salas
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2026-03-10

## El problema

El segmento Base de la pirámide no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-03-29 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
