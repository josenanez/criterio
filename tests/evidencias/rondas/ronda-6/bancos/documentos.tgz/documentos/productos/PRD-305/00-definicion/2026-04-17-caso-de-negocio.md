# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-04-17
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 241.003 | Caso de negocio, 2026-04-17 |

## Retorno esperado

Retorno esperado en 24 meses.
