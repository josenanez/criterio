# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2026-04-21
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-04-21

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
