# Tablero de métricas · Crédito hipotecario digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 74.306 | 2026-09-30 |
