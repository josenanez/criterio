# Tablero de métricas · Cuenta de ahorros joven

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 70.769 | 2026-09-29 |
