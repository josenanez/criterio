# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-05-30
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 153.364 | Caso de negocio, 2026-05-30 |

## Retorno esperado

Retorno esperado en 24 meses.
