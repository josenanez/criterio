# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2025-11-26
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 216.012 | Caso de negocio, 2025-11-26 |

## Retorno esperado

Retorno esperado en 24 meses.
