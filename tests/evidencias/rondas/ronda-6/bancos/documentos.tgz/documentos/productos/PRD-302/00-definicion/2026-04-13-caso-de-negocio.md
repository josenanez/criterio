# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2026-04-13
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 78.771 | Caso de negocio, 2026-04-13 |

## Retorno esperado

Retorno esperado en 24 meses.
