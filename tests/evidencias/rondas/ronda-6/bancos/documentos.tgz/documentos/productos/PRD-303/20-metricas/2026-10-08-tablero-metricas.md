# Tablero de métricas · Cuenta PyME

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 129.818 | 2026-10-08 |
