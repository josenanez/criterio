# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2026-01-13
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 189.229 | Caso de negocio, 2026-01-13 |

## Retorno esperado

Retorno esperado en 24 meses.
