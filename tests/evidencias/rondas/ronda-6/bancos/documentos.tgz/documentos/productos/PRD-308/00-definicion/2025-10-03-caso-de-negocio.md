# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2025-10-03
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 82.393 | Caso de negocio, 2025-10-03 |

## Retorno esperado

Retorno esperado en 24 meses.
