# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-04-05
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 72.578 | Caso de negocio, 2026-04-05 |

## Retorno esperado

Retorno esperado en 24 meses.
