# Definición de producto · Tarjeta de crédito digital

**Código:** PRD-304
**Gerente de producto:** Ricardo Salas
**Segmento:** Base de la pirámide
**Fecha de la definición:** 2025-11-26

## El problema

El segmento Base de la pirámide no tiene tarjeta de crédito digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
