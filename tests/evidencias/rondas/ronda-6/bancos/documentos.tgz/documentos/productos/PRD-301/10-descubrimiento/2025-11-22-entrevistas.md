# Entrevistas · Nómina empresarial

**Ronda:** Ronda · 2025-11-22
**Realizadas por:** Andrés Lozano

### Cliente entrevistado · 2025-11-22

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
