# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Débito contactless
**Fecha:** 2026-10-05
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +119 días sobre la línea base vigente |
| Costo | 238.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
