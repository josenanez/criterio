# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-09-04
**Asistentes:** Beatriz Cuéllar, Elena Duarte, Jorge Medina, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-09-25 |
| Elena Duarte | Cerrar la prueba 2 | 2026-09-19 |
| Sandra Gil | Revisar el anexo 3 | por definir |
| Jorge Medina | Validar el ambiente 4 | 2026-09-15 |
