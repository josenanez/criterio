# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-13
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **30%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.145.951.271 |
| Ejecutado | 922.631.378 |
| Proyección al cierre | 2.365.074.370 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
