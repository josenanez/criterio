# Comité de Arquitectura · Billetera y QR

**Fecha:** 2026-10-03
**Asistentes:** Felipe Arango, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 19 | 2026-11-05 |
