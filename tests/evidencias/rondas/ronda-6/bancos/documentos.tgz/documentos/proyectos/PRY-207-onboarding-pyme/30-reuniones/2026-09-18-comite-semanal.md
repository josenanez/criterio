# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-09-18
**Asistentes:** Beatriz Cuéllar, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-10-20 |
| Elena Duarte | Cerrar la prueba 2 | 2026-10-18 |
| Sandra Gil | Revisar el anexo 3 | 2026-10-09 |
| Jorge Medina | Validar el ambiente 4 | 2026-09-15 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-09-14 |
| Gustavo Neira | Enviar el documento 9 | por definir |
| María Restrepo | Cerrar la prueba 10 | por definir |
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 |
| Liliana Torres | Validar el ambiente 12 | 2026-09-26 |

## Cerrados en esta reunión

- Entregar el punto 8 (Jorge Medina): recibido, acta de recibo del 2026-09-18.
