# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Banca de Personas
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Beatriz Cuéllar
**Comité:** Comité de Riesgos
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2026-01-20

## Objetivo del negocio

Entregar onboarding pyme para Banca de Personas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2026-01-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-30 |
| Cierre | 2027-03-22 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
