# Informe de avance · Core de depósitos

**Código:** PRY-201
**Fecha de corte:** 2026-10-14
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **50%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.401.402.751 |
| Ejecutado | 2.293.355.243 |
| Proyección al cierre | 4.299.777.057 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del calendario de liberaciones del core
