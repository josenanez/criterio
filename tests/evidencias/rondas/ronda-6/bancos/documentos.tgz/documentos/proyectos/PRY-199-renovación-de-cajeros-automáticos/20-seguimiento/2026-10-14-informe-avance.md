# Informe de avance · Renovación de cajeros automáticos

**Código:** PRY-199
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- Concentración del conocimiento en una sola persona
