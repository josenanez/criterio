# Comité de Arquitectura · Originación digital

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 4 | 2026-10-25 |
