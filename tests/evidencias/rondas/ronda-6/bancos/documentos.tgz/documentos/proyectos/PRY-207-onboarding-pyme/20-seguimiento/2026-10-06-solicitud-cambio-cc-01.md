# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-06
**Solicitante:** Beatriz Cuéllar

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +77 días sobre la línea base vigente |
| Costo | 154.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
