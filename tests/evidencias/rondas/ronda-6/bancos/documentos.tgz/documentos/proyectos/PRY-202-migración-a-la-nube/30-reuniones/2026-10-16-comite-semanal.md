# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-16
**Asistentes:** Rubén Cárdenas, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 21 | 2026-10-05 |
