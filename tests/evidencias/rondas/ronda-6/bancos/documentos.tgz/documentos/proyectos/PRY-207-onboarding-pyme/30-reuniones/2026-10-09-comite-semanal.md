# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-10-09
**Asistentes:** Beatriz Cuéllar, Carlos Peña, Diana Molina, Elena Duarte, Gustavo Neira, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-11-28 |
| Elena Duarte | Cerrar la prueba 2 | 2026-11-17 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-16 |
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-23 |
| Elena Duarte | Actualizar la matriz 14 | por definir |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-11-10 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |
| Diana Molina | Enviar el documento 17 | 2026-10-21 |
| Sandra Gil | Cerrar la prueba 18 | 2026-11-02 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-10 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-22 |
| Gustavo Neira | Aprobar el diseño 21 | por definir |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-01 |
| Carlos Peña | Confirmar la fecha 23 | por definir |
| Paula Céspedes | Entregar el punto 24 | 2026-10-15 |

## Cerrados en esta reunión

- Validar el ambiente 12 (Liliana Torres): recibido, acta de recibo del 2026-10-09.

## Lo que se dijo

- Jorge Medina dice que ya entregó «validar el ambiente 4». No se presentó acta.
