# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Arquitectura
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2025-11-02

## Objetivo del negocio

Entregar billetera y qr para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Arquitectura el 2025-11-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-12 |
| Cierre | 2027-05-10 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
