# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Billetera y QR
**Fecha:** 2026-10-12
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +70 días sobre la línea base vigente |
| Costo | 140.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
