# Corrida del 2026-10-16 · portfolio-report

13 proyectos · 95 documentos, 0 releídos y 95 sin cambio · 40 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

El informe quedó en `/home/claude/banco/ronda-6/bancos/espacio/reportes`.

Primer informe html; 4 verdes contradichos (PRY-203, 204, 207, 208); autoridad y fase sin identificar en los 13.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-16
13 proyectos · 11 con hallazgos (78 señales) · fichas cargadas de `estado/records/` (13, generadas el 2026-10-16; informes de avance de los proyectos del 2026-09-24 al 2026-10-15) · último barrido 2026-10-16

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-16 (versión 1.1, familia 0.3.12). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva su cita y la verificación es de usted.

Informe en formato **html** generado por script en `reportes/` (26 páginas): `index.html` (por campo, con cadena de evidencia; para quien actúa) y `decisiones.html` (por decisión; para el patrocinador). Para PDF, imprimir el HTML.

## Qué cambió desde la corrida anterior
Sin cambios: la única instantánea previa es la de hoy (`snapshots/2026-10-16.json`), el diff contra ella da 0 cambios. Este es el punto de partida, no hay delta.

## Contradicciones abiertas
Vacía: ningún proyecto tiene campos en conflicto entre dos fuentes. (Sí hay contradicción entre lo declarado y la evidencia; ver "Sin sustento".)

## Hitos vencidos sin evidencia
Hito vencido y sin cumplir (1):

| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-202 Migración a la nube | Integración con el core | 2026-10-12 | 4 |

Hitos declarados "cumplido" sin evidencia en documentos (los más viejos; el detalle completo está en `index.html`):

| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-210 Portal de proveedores | Diseño funcional aprobado | 2025-09-27 | 384 |
| PRY-211 Cobranza digital | Diseño funcional aprobado | 2025-09-30 | 381 |
| PRY-205 Prevención de lavado | Ambiente de pruebas certificado | 2025-11-25 | 325 |
| PRY-210 | Integración con el core | 2026-01-18 | 271 |
| PRY-205 | Integración con el core | 2026-02-17 | 241 |
| PRY-206 Billetera y QR | Diseño funcional aprobado | 2026-02-28 | 230 |
| PRY-202 | Diseño funcional aprobado | 2026-04-04 | 195 |
| PRY-207 Onboarding PyME | Diseño funcional aprobado | 2026-05-14 | 155 |
| PRY-211 | Piloto con usuarios internos | 2026-05-28 | 141 |
| PRY-209 Nómina electrónica | Diseño funcional aprobado | 2026-05-30 | 139 |
| PRY-204 Débito contactless | Ambiente de pruebas certificado | 2026-06-16 | 122 |
| PRY-206 | Ambiente de pruebas certificado | 2026-06-17 | 121 |
| PRY-202 | Ambiente de pruebas certificado | 2026-07-09 | 99 |
| PRY-204 | Integración con el core | 2026-08-20 | 57 |
| PRY-203 Open Banking | Ambiente de pruebas certificado | 2026-08-26 | 51 |
| PRY-207 | Ambiente de pruebas certificado | 2026-08-26 | 51 |
| PRY-200 Originación digital | Integración con el core | 2026-09-08 | 38 |

Otros hitos de este tipo en PRY-205, PRY-210 (pilotos) y otros: ver `index.html`.

## Proyectos en silencio
Vacía: ningún proyecto supera el umbral de 15 días sin documento nuevo (el mayor es PRY-208, 6 días).

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias por código entre proyectos.

## Cambios de gobierno
Vacía: sin cambios de persona en roles respecto de la corrida anterior ni del acta.

## Sin sustento
Proyectos en verde contradichos por la evidencia (4):

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-203 Open Banking (informe 2026-09-25) | Verde | Proyección de costo +23,6 % sobre lo aprobado ($22.250 M vs $18.000 M COP); línea base movida 33 días sin autorización; hito de pruebas sin evidencia |
| PRY-204 Débito contactless (2026-10-15) | Verde | 48 % declarado frente a 75–100 % que soporta el plan; 119 días (45,4 %) de desviación vs original, todos sin autorización; 2 hitos sin evidencia |
| PRY-207 Onboarding PyME (2026-10-13) | Verde | 30 % frente a 50–75 % del plan; 77 días de atraso (18,5 %, este sí aprobado); 21 señales, entre ellas compromisos vencidos y reprogramados |
| PRY-208 Motor de decisión (2026-09-24) | Verde | Compromiso de Mauricio Pérez vencido hace 15 días (acta 2026-10-10) |

Avance declarado por encima de lo que soporta el plan: PRY-202 declara 80 % (plan soporta 40–60 %).

## Vacíos de información
- Los 13 proyectos no tienen autoridad (`identity.authority`) ni fase (`identity.phase`) identificadas.
- Sin producto asociado: PRY-202, PRY-205, PRY-208, PRY-210.
- Campos de más de 12 meses sin refrescar: PRY-205 (17 meses, fuente 2025-05-31), PRY-210 (15), PRY-211 (15).
- Entregables de proveedor sin evidencia de recibo en PRY-199, PRY-200, PRY-202, PRY-205, PRY-206, PRY-210.
- Informes de avance con más de 15 días: PRY-202 (19), PRY-203 (21), PRY-208 (22).

Otras señales que el script cruzó:
- **Proveedores facturados sin entrega:** PRY-200 (Datacore $489,8 M y Núcleo Financiero $707,4 M COP), PRY-206 (Integra Sistemas $82,7 M). PRY-202, PRY-205 y PRY-210 también tienen entregables vencidos (hasta 401 días en PRY-205).
- **Reprogramaciones:** PRY-207 tiene compromisos movidos 6 y 5 veces, 5+ vencidos y varios sin fecha.
- **Línea base movida sin autorización:** PRY-203 (33 días), PRY-204 (119), PRY-206 (70).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Cajeros | Verde | Sin señales | 0 | 0 | 0 |
| PRY-200 Originación digital | Rojo | 49 % vs 60–80 % del plan | 0 | 0 | 0 |
| PRY-201 Core de depósitos | Verde | Sin señales | 0 | 0 | 0 |
| PRY-202 Migración a la nube | Amarillo | Avance declarado superior al plan | 0 | 0 | 0 |
| PRY-203 Open Banking | Verde | Contradicho | +33 d | 0 | 1 |
| PRY-204 Débito contactless | Verde | Contradicho | +119 d (45,4 %) | 0 | 1 |
| PRY-205 Prevención de lavado | Amarillo | 77 % vs 100 % del plan | 0 | 0 | 0 |
| PRY-206 Billetera y QR | Rojo | Coherente con la evidencia | +70 d (12,9 %) | 0 | 1 |
| PRY-207 Onboarding PyME | Verde | Contradicho | +77 d (18,5 %) | 0 | 1 |
| PRY-208 Motor de decisión | Verde | Contradicho | 0 | 0 | 0 |
| PRY-209 Nómina electrónica | Rojo | 1 hito sin evidencia | 0 | 0 | 0 |
| PRY-210 Portal de proveedores | Rojo | 85 % vs 100 % del plan | 0 | 0 | 0 |
| PRY-211 Cobranza digital | Amarillo | 47 % vs 100 % del plan | 0 | 0 | 0 |

## Necesito que confirmes
Sesión sin interfaz: sin respuestas. Quedan planteadas, como cinco preguntas cerradas (campos más viejos entre los que importan):
1. ¿Quién es la autoridad de aprobación de PRY-203, PRY-204 y PRY-206, que movieron su línea base sin autorización registrada?
2. ¿En qué fase está cada uno de los 13 proyectos?
3. ¿PRY-202, PRY-205, PRY-208 y PRY-210 pertenecen a algún producto? ¿Cuál?
4. ¿Siguen vigentes los datos de PRY-205 (fuente 2025-05-31), PRY-210 (2025-07-23) y PRY-211 (2025-07-02)?
5. ¿Existe evidencia de recibo para los entregables de proveedor facturados de PRY-200 y PRY-206?

---
Pie: criterio-portfolio 0.3.12 · fichas aplicadas: 13 (`estado/records/`, fecha 2026-10-16) · campos inciertos: autoridad y fase en los 13 proyectos, producto en 4, evidencia de entregables en 6, campos viejos en 3 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
