**Fichas cargadas:** 13 (PRY-199 a PRY-211), con cálculo al 2026-10-16. Términos de uso vigentes (versión 1.1, aceptados el 2026-10-16 por José Francisco Ñáñez); no hizo falta registrarlos de nuevo.

# Comité de proyectos — 2026-10-23
8 decisiones · 6 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos

> Borrador de trabajo. Cada dato lleva su fuente en la ficha; la verificación es de quien decide. La fecha del comité sale de la configuración (`committee_next`). Cuando una cifra no sale del cálculo, no se escribe.

## Decisiones del comité anterior

No hay acta ni material de un comité anterior en las carpetas ni en el estado. Lo único rastreable es una decisión citada de pasada en un documento de proyecto:

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| PRY-207 CC-01: ampliación de alcance, +77 días, 154.000.000 COP. El documento dice «Autorizada por el comité» (`PRY-207-onboarding-pyme/20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md`) | Solicitud del 2026-10-06; fecha de la decisión: **no consta** | La línea base se movió 77 días. Ningún documento dice qué comité decidió, ni quién, ni con qué facultad | Sin sustento. Es el punto 5 |

Sin acta anterior, este comité decide sin saber qué se resolvió antes. Conviene levantar el acta de hoy en el formato de la sección «Después».

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo, y hasta qué monto puede decidir un gerente sin subir al comité?
**Proyecto:** los 13 · **Quién decide:** este comité (el campo de autoridad está vacío en las 13 fichas) · **Si no se decide hoy:** los puntos 2 a 8 se deciden sin saber si quien los decide tiene la facultad. Seguirá pasando lo que ya pasó en tres proyectos: la línea base se movió antes de que alguien la autorizara.

Las fichas nombran cuatro comités distintos (Transformación Digital, Arquitectura, Medios de Pago, Riesgos) y ningún documento dice cuáles son sus límites de monto o de alcance.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un umbral único de monto y de alcance para todo gerente del portafolio, y un solo comité que ratifique los cambios | Todo cambio que lo exceda sube a un solo lugar | Una sesión de espera por cambio | Sin efecto directo. Los montos del umbral los fija quien tenga la facultad; no se proponen aquí |
| B. Un umbral por cada uno de los cuatro comités | Cada comité decide sobre lo suyo | Más rápido por cambio | Criterios distintos entre proyectos parecidos |
| C. No definir hoy | Sin cambio | Sin cambio | Sin dato |

**Recomendación:** A. Con una sola regla, la desviación entre proyectos se puede comparar, y hoy cuatro comités no coinciden en nada medible. Si el comité elige B, los puntos 2 a 5 se devuelven a los comités que figuran en las fichas.

### [2] ¿Se aprueba el CC-01 de PRY-204 (Débito contactless): ampliación de alcance, +119 días, 238.000.000 COP?
**Proyecto:** PRY-204 · **Quién decide:** Comité de Transformación Digital según la ficha; su facultad no está documentada (ver punto 1) · **Si no se decide hoy:** el proyecto sigue sobre una fecha de fin (2027-02-21) que nadie autorizó. La solicitud está «Pendiente de presentación al comité» desde el 2026-10-05.

Hechos: la línea base ya se movió 119 días (45,4 % sobre la original, umbral 10 %) con 0 días autorizados. El estado declarado es verde, pero el avance es 48 % frente a 75–100 % que sustentan los hitos. De los 3 de 4 hitos declarados cumplidos, 2 no tienen evidencia («Ambiente de pruebas certificado» y «Integración con el core»). La solicitud dice solo «Ampliación de alcance» y no describe qué entra.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar con línea base nueva y su motivo | Entra una ampliación que el documento no describe | +119 días sobre la línea base vigente | +238.000.000 COP |
| B. Rechazar | Se queda el alcance original | Vuelve a la línea base original; el avance de 48 % ya queda por debajo de lo que esa fecha exigiría | Sin costo adicional |
| C. Aplazar al siguiente comité con dos condiciones: evidencia de los 2 hitos y descripción del alcance que entra | Se define antes de aprobar | Un comité más sobre una fecha sin autorizar | Sin dato |

**Recomendación:** C. Una ampliación sin descripción de alcance no se puede evaluar en la primera de las tres dimensiones, y el proyecto que la pide declara verde con 2 hitos sin soporte.

### [3] ¿Se aprueba el CC-01 de PRY-203 (Open Banking): ampliación de alcance, +33 días, 66.000.000 COP?
**Proyecto:** PRY-203 · **Quién decide:** Comité de Medios de Pago según la ficha; facultad no documentada (punto 1) · **Si no se decide hoy:** los 33 días siguen movidos sin autorización (fecha de fin 2027-04-23); pendiente desde el 2026-10-03.

Hechos: el atraso es 8,0 % sobre la original, bajo el umbral de 10 %. El estado declarado es verde (informe del 2026-09-25, con 21 días). El hito «Ambiente de pruebas certificado» está declarado cumplido sin evidencia. La solicitud tampoco describe qué alcance entra.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar con línea base nueva y su motivo | Ampliación sin descripción en el documento | +33 días | +66.000.000 COP |
| B. Rechazar | Alcance original | Vuelve a la línea base original | Sin costo adicional |
| C. Aplazar hasta tener la descripción del alcance | Se define antes de aprobar | Los 33 días siguen sin autorizar | Sin dato |

**Recomendación:** A, con la descripción del alcance como condición del acta. El atraso es chico, y aprobar regulariza una línea base que ya se movió. No resuelve el problema de presupuesto de este proyecto; ese está en «Escalamientos sin decisión asociada».

### [4] ¿Se aprueba el CC-01 de PRY-206 (Billetera y QR): ampliación de alcance, +70 días, 140.000.000 COP?
**Proyecto:** PRY-206 · **Quién decide:** Comité de Arquitectura según la ficha; facultad no documentada (punto 1) · **Si no se decide hoy:** los 70 días siguen movidos sin autorización (fecha de fin 2027-07-19); pendiente desde el 2026-10-12.

Hechos: el atraso es 12,9 % sobre la original (umbral 10 %). Estado declarado: rojo. El presupuesto aprobado es 800.000.000 COP y la proyección es 829.681.423 COP (3,7 % sobre lo aprobado). Los dos entregables clave del proveedor Integra Sistemas están vencidos y sin aceptar: «Licenciamiento del motor» (219 días) y «Bolsa de horas de desarrollo» (99 días). Ver punto 6.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar con línea base nueva | Entra una ampliación sin descripción en el documento | +70 días | +140.000.000 COP sobre 800.000.000 aprobados |
| B. Rechazar | Alcance original | Vuelve a la línea base original | Sin costo adicional |
| C. Aplazar hasta que el proveedor entregue o firme un plan para los dos entregables vencidos | Se define antes de aprobar | Los 70 días siguen sin autorizar | Sin dato |

**Recomendación:** C. Ampliar el alcance sobre un motor cuyo licenciamiento lleva 219 días de retraso apila riesgo sobre un entregable que no existe.

### [5] ¿Ratifica el comité el CC-01 de PRY-207 (Onboarding PyME): ampliación de alcance, +77 días, 154.000.000 COP, hoy «autorizado por el comité» sin constancia de quién?
**Proyecto:** PRY-207 · **Quién decide:** el Comité de Riesgos según la ficha, si es el que autorizó · **Si no se decide hoy:** un cambio de 77 días y 154.000.000 COP queda aprobado por una autoridad que nadie puede nombrar. Un cambio aprobado por quien no tenía la facultad es un hallazgo.

Hechos: la línea base ya se movió los 77 días; el cálculo los cuenta como autorizados porque el documento lo dice, pero no dice qué comité ni quién. El estado declarado es verde, mientras que el avance es 30 % frente a 50–75 % que sustentan los hitos, hay 8 compromisos vencidos y 2 reprogramados 6 y 5 veces.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta que nombre el comité, los asistentes y la facultad | Se queda la ampliación | +77 días | +154.000.000 COP |
| B. Pedir el acta de la decisión original en 7 días; si no aparece, tratar el cambio como no autorizado y volver a decidirlo | Queda en suspenso | Hasta 7 días de incertidumbre | Sin dato |
| C. Dejarlo como está | Se queda la ampliación | +77 días | +154.000.000 COP, sin autoridad documentada |

**Recomendación:** B. Antes de ratificar hay que ver si el acta existe; hoy el único soporte es una frase.

### [6] ¿Se instruye retener todo pago adicional a proveedores con facturación sin entregable aceptado en PRY-200 y PRY-206?
**Proyecto:** PRY-200 y PRY-206 · **Quién decide:** quien tenga la facultad sobre pagos de contrato; no está documentada (punto 1) · **Si no se decide hoy:** las facturas siguen sin entregable aceptado que las respalde.

| Contrato | Facturado | Entregables aceptados | Entregables vencidos sin aceptar |
|---|---|---|---|
| Datacore Colombia, CT-936 (PRY-200) | 489.791.403 COP | 0 de 2 | «Licenciamiento del motor», 139 días |
| Núcleo Financiero S.A., CT-107 (PRY-200) | 707.420.229 COP | 0 de 4 | «Licenciamiento del motor» 202 días, «Bolsa de horas» 107 días, «Parametrización del tarifario» 12 días |
| Integra Sistemas Ltda., CT-541 (PRY-206) | 82.731.823 COP | 0 de 4 | «Licenciamiento del motor» 219 días, «Bolsa de horas» 99 días |

Los documentos no dicen si lo facturado ya se pagó. Eso hay que averiguarlo antes del comité.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener todo pago adicional a estos tres contratos hasta tener acta de aceptación por entregable | Sin cambio | Puede enfriar la relación con el proveedor y alargar los entregables vencidos | Se evita desembolsar sin respaldo |
| B. Pagar solo contra acta de aceptación entregable por entregable, sin retener el contrato completo | Sin cambio | Menos fricción | Se desembolsa lo aceptado y nada más |
| C. No intervenir | Sin cambio | Sin cambio | Se sigue facturando sin entrega |

**Recomendación:** B. Es la regla estándar de control de proveedores y no castiga entregables que sí lleguen. Pasa a A si los proveedores no responden en el comité siguiente.

### [7] ¿Se exige a PRY-205, PRY-210 y PRY-211 una solicitud de cambio con fecha nueva, o se evalúa su suspensión o cierre?
**Proyecto:** PRY-205, PRY-210, PRY-211 · **Quién decide:** este comité · **Si no se decide hoy:** tres proyectos con fecha de fin vencida siguen reportando sin línea base nueva.

| Proyecto | Fecha de fin | Avance declarado | Hitos | Estado declarado |
|---|---|---|---|---|
| PRY-205 | 2026-08-04 | 77 % | 5 de 5 declarados cumplidos; 4 sin evidencia | amarillo |
| PRY-210 | 2026-05-10 | 85 % | 5 de 5 declarados cumplidos; 3 sin evidencia | rojo |
| PRY-211 | 2026-05-28 | 47 % | 4 de 4 declarados cumplidos; 2 sin evidencia | amarillo |

Ninguno tiene cambio aprobado ni solicitud abierta. En PRY-205 los 8 entregables de proveedor están sin aceptar; PRY-211 tiene 82,4 % del aprobado (18.000.000.000 COP) comprometido.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir en el próximo comité una solicitud de cambio por proyecto, con descripción de lo que falta y evidencia de los hitos | Se define | Fecha nueva con motivo, sin borrar la anterior | Sin dato; sale de cada solicitud |
| B. Suspender los tres y evaluar cierre o cancelación | Se detiene | Se detiene | Lo comprometido y no ejecutado queda por resolver; los documentos no dicen cuánto es recuperable |
| C. Seguir como están | Sin cambio | Sin fecha vigente | Sin dato |

**Recomendación:** A. Los tres declaran hitos cumplidos y avances menores al 100 %; antes de suspender hay que saber cuál de los dos números es el cierto.

### [8] ¿Quién es el dueño único de la liberación del core y de la capacidad del equipo de seguridad, que hoy aparecen como riesgo o incidencia en 11 proyectos sin dueño ni fecha?
**Proyecto:** PRY-199, 200, 201, 202, 203, 204, 205, 206, 208, 210, 211 · **Quién decide:** este comité · **Si no se decide hoy:** ninguna dependencia está registrada con el código del proyecto del que depende (las 13 fichas la tienen vacía), así que nadie ve el cruce.

Lo que las fichas citan, siempre con dueño y fecha vacíos:
- Calendario de liberaciones del core: riesgo en PRY-199, 201, 203 y 206. En PRY-202, 210 y 211 hay historias fuera del sprint por dependencia con el core.
- Disponibilidad del equipo de seguridad para la revisión final: riesgo en PRY-200, 202, 206 y 210. Además, «hallazgo de seguridad en la revisión de arquitectura» es incidencia en PRY-201, 204, 205 y 208.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar un dueño del calendario del core y otro de la capacidad de seguridad, y registrar la dependencia con el código de cada proyecto afectado | Sin cambio | Se puede secuenciar | Sin dato |
| B. Que cada gerente gestione lo suyo con el equipo | Sin cambio | Cada proyecto compite por la misma capacidad | Sin dato |
| C. No definir | Sin cambio | Sin cambio | Sin dato |

**Recomendación:** A. Es el mismo recurso en muchos proyectos, y ningún gerente lo resuelve solo.

## Escalamientos sin decisión asociada

| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-203 | Proyección 22.250.676.721 COP contra 18.000.000.000 aprobados (23,6 % sobre lo aprobado, umbral 10 %). El estado declarado es verde. El CC-01 suma 66.000.000, una fracción de esa brecha | Informe del 2026-09-25 | Que el gerente explique la causa antes de pedir al comité ampliar presupuesto o recortar alcance |
| PRY-207 | 8 compromisos vencidos (el más antiguo, el anexo 11 de Javier Hoyos, venció el 2026-09-21), 2 reprogramados 6 y 5 veces, 6 sin fecha. Estado declarado: verde | 2026-09-21 | Fechas nuevas con evidencia, o el estado declarado corregido |
| PRY-202 | El hito «Integración con el core» venció el 2026-10-12. Avance declarado 80 % contra 40–60 % sustentado. Estado amarillo, informe del 2026-09-27 (19 días) | 2026-10-12 | Informe actualizado y evidencia de 2 hitos declarados cumplidos |
| PRY-208 | Compromiso de Mauricio Pérez («Entregar el punto 28») vencido hace 15 días. Estado verde, declarado hace 22 días | 2026-10-01 | Informe nuevo y fecha firme |
| PRY-202 y PRY-207 | Jorge Medina tiene compromisos vencidos en los dos (11 y 2 días) | 2026-10-05 | Que el comité vea la carga de una misma persona en dos proyectos |
| PRY-202, PRY-210 | Entregables de proveedor vencidos sin aceptar: Datacore Colombia en PRY-202 (27 y 115 días); Talento Digital S.A.S. en PRY-210 (363 y 208 días) | 2025-10-18 (el más antiguo) | Plan de entrega o salida con el proveedor, por contrato |

## Para conocimiento

- PRY-199 (Renovación de cajeros): verde, sin hallazgos.
- PRY-200 (Originación digital): rojo declarado; avance 49 % contra 60–80 %; hito «Integración con el core» sin evidencia.
- PRY-201 (Core de depósitos): verde, sin hallazgos. Tres incidencias sin dueño.
- PRY-202 (Migración a la nube): amarillo; ver escalamientos.
- PRY-203 (Open Banking): verde declarado contradicho por la evidencia; punto 3 y escalamiento de presupuesto.
- PRY-204 (Débito contactless): verde declarado contradicho por la evidencia; punto 2.
- PRY-205 (Prevención de lavado): amarillo; fin vencido; punto 7.
- PRY-206 (Billetera y QR): rojo; puntos 4 y 6.
- PRY-207 (Onboarding PyME): verde declarado contradicho; puntos 5 y escalamiento.
- PRY-208 (Motor de decisión): verde declarado, con un compromiso vencido.
- PRY-209 (Nómina electrónica): rojo declarado; un hito sin evidencia.
- PRY-210 (Portal de proveedores): rojo; fin vencido; punto 7.
- PRY-211 (Cobranza digital): amarillo; fin vencido; punto 7.

## Anexo

**Verdes contradichos por la evidencia (4):** PRY-203, PRY-204, PRY-207, PRY-208.

**Vacíos de información:**
- Autoridad del gerente: vacía en las 13 fichas. Fase del proyecto: vacía en las 13.
- Producto: vacío en PRY-202, 205, 208 y 210.
- Dependencias: vacías en las 13 fichas. Ningún riesgo tiene probabilidad, impacto, dueño o fecha, salvo el de PRY-207 (dueño «no_identificado», dicho en las notas del 2026-10-16 y sin registrar).
- Sin evidencia de aceptación de entregables: PRY-199, 200, 202, 205, 206 y 210.
- Campos con más de 12 meses sin actualizar: PRY-205 (17 meses), PRY-210 (15) y PRY-211 (15).
- Los 4 cambios de este paquete (PRY-203, 204, 206, 207) dicen «Ampliación de alcance» sin describir qué entra.

**Datos a verificar:** el ejecutado supera lo comprometido en PRY-202 (59,1 % contra 28,2 %), PRY-206 (50,9 % contra 37,1 %) y PRY-209 (61,5 % contra 32,7 %). Puede ser un error de captura o gasto sin compromiso registrado; los documentos no dicen cuál. No se interpretó.

**Estado numérico por proyecto (al 2026-10-16):**

| Proyecto | Declarado | Avance declarado | Sustentado por hitos | Aprobado (COP) | Proyección (COP) |
|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 20–40 % | 2.400.000.000 | 2.400.000.000 |
| PRY-200 | rojo | 49 % | 60–80 % | 6.800.000.000 | 6.265.902.381 |
| PRY-201 | verde | 50 % | 25–50 % | 4.200.000.000 | 4.299.777.057 |
| PRY-202 | amarillo | 80 % | 40–60 % | 9.500.000.000 | 9.691.323.593 |
| PRY-203 | verde | 46 % | 50–75 % | 18.000.000.000 | 22.250.676.721 |
| PRY-204 | verde | 48 % | 75–100 % | 6.800.000.000 | 6.869.556.501 |
| PRY-205 | amarillo | 77 % | 100 % | 9.500.000.000 | 9.165.818.019 |
| PRY-206 | rojo | 77 % | 60–80 % | 800.000.000 | 829.681.423 |
| PRY-207 | verde | 30 % | 50–75 % | 2.400.000.000 | 2.365.074.370 |
| PRY-208 | verde | 31 % | 0–25 % | 3.300.000.000 | 3.303.203.037 |
| PRY-209 | rojo | 48 % | 50–75 % | 9.500.000.000 | 8.764.416.043 |
| PRY-210 | rojo | 85 % | 100 % | 1.200.000.000 | 1.168.878.153 |
| PRY-211 | amarillo | 47 % | 100 % | 18.000.000.000 | 16.897.664.168 |

## Después

Cuando el comité sesione, puedo registrar las decisiones en las fichas (cambios aprobados con quién decidió, línea base nueva con su motivo, dueños de las dependencias). Así el material del próximo comité parte de lo decidido. Dime qué se decidió y lo registro.

---
**Pie:** criterio-portfolio 0.3.12 · términos 1.1 (aceptación del 2026-10-16) · fichas aplicadas: raid-taxonomy, governance-artifacts, portfolio-health (13 proyectos, `compute` del 2026-10-16) · campos inciertos: fecha y autor de la decisión del CC-01 de PRY-207, si lo facturado ya se pagó (punto 6), la facultad de cada comité, el ejecutado mayor que el comprometido en tres proyectos · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
