## Productos al 2026-10-16 — crédito de consumo

Sale de las fichas en `estado/`, calculadas el 2026-10-16 con `portafolio.py compute`. El último informe de avance del proyecto es del 2026-10-15 (`PRY-200-originación-digital/20-seguimiento/2026-10-15-informe-avance.pdf`).

**Crédito de consumo tiene un solo proyecto: PRY-200 Originación digital.** La vista por producto no suma nada aquí. No armo sección de producto y dejo el estado de ese proyecto, que es lo que hay.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| crédito de consumo | 1 (PRY-200) | 8 alertas | 2027-02-27 (PRY-200) | COP 6.800.000.000 | COP 5.617.037.802 |

### Crédito de consumo
**Proyectos:** PRY-200 Originación digital.

**Lo que hay que ver (PRY-200):**
- **El gerente declara rojo, y el rojo no explica todo.** Ninguna de las cuatro señales siguientes aparece reconocida en su declaración.
- **Avance por debajo de lo que el plan soporta.** Declara 49,0 %; los hitos cumplidos (3 de 5) sostienen entre 60 y 80 %. Dice estar atrás por 11,0 puntos. El avance declarado es menor que el que sostiene el plan, y el plan no lo explica.
- **Hito cumplido sin evidencia:** «Integración con el core», vencía el 2026-09-08 (38 días). Está declarado como cumplido y no hay documento que lo sustente.
- **Proveedor Datacore Colombia (CT-936):**
  - «Licenciamiento del motor» venció el 2026-05-30 (139 días) y sigue pendiente.
  - Tiene COP 489.791.403 facturados con 0 entregables aceptados (de 2).
- **Proveedor Núcleo Financiero S.A. (CT-107):**
  - Tres entregables vencidos y pendientes: «Licenciamiento del motor» (2026-03-28, 202 días), «Bolsa de horas de desarrollo» (2026-07-01, 107 días) y «Parametrización del tarifario» (2026-10-04, 12 días).
  - Tiene COP 707.420.229 facturados con 0 entregables aceptados (de 4).
- **Los dos proveedores tienen pendiente el licenciamiento del motor.** Los dos aparecen con «Licenciamiento del motor» pendiente, en contratos distintos (CT-936 y CT-107). La ficha no dice si es el mismo entregable cobrado dos veces o dos licencias distintas. Hay que preguntarlo.
- **Sin entregables aceptados en ninguno de los dos contratos.** Lo facturado a los dos proveedores no tiene ninguna entrega aceptada detrás. Ningún entregable de proveedor tiene evidencia de recibo en las fichas (6 de 6 sin evidencia). No sumo lo facturado: el cálculo no da ese total.

**Dinero (PRY-200, COP; las cuatro cifras están):**
- Aprobado: 6.800.000.000.
- Comprometido: 5.617.037.802 (82,6 %).
- Ejecutado: 1.908.189.235 (28,1 %).
- Proyección: 6.265.902.381 (7,9 % por debajo de lo aprobado).
- Disponible real: 1.182.962.198.

La suma es completa porque el producto tiene un solo proyecto y trae las cuatro cifras. El comprometido de 82,6 % está por debajo del umbral de 90 % y no genera alerta. Con una ejecución de 28,1 %, queda poco margen para absorber más compromisos.

**Fechas:** fin 2027-02-27. Sin desviación contra la línea base original ni contra la vigente (0 días, 0 replanificaciones, línea base presente).

**Dependencias internas:** ninguna, porque hay un solo proyecto. La ficha de PRY-200 tampoco declara dependencias con otros proyectos. Eso no confirma que no existan.

**Fecha comprometida del producto:** 2027-02-27, que sale de PRY-200.

**Lo que no sé:**
- Quién autoriza el proyecto (`identity.authority`) y en qué fase está (`identity.phase`) no están en la ficha.
- Si el hito «Integración con el core» se cumplió de verdad. Está declarado como cumplido y no hay documento que lo sustente. Si no se cumplió, el avance real es menor.
- Si los dos «Licenciamiento del motor» son el mismo entregable.

### Proyectos sin producto declarado
Cuatro de los 13 proyectos del portafolio no declaran producto: nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | No consta en el cálculo |
| PRY-205 Prevención de lavado de activos | No consta en el cálculo |
| PRY-208 Motor de decisión | No consta en el cálculo |
| PRY-210 Portal de proveedores | No consta en el cálculo |

**PRY-208 Motor de decisión** puede tocar crédito de consumo, porque PRY-200 tiene pendiente el licenciamiento de un «motor». Ninguna ficha lo dice y no lo asumo. Si es así, el producto tendría dos proyectos y las dependencias entre ellos sin coordinar. Falta que alguien declare a qué producto sirve ese proyecto.

### Para el comité de producto
No aparecieron dependencias internas sin confirmar, así que no hay un punto de comité sobre ellas. Lo que sí se puede llevar es una sola decisión sobre el proveedor: los dos contratos de PRY-200 tienen facturado sin entregables aceptados, y ambos tienen vencido el licenciamiento del motor.

---
**Pie de rigor:** salen de las fichas de `estado/` al 2026-10-16 y del cálculo de `portafolio.py compute`. Hay 45 campos sin marca de origen (ni evidencia ni declaración) en la ficha de PRY-200, y 0 con evidencia. La verificación de cada dato contra su documento es de quien lo use. Criterio produce borradores de trabajo, no decisiones ni asesoría.
