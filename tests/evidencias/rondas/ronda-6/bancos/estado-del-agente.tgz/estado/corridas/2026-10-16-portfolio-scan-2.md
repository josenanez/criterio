# Corrida del 2026-10-16 · portfolio-scan

13 proyectos · 95 documentos, 0 releídos y 95 sin cambio · 78 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

10 fichas nuevas (PRY-199,201,203-206,208-211); 62 de 95 documentos leidos, 33 sin cambio; nada movido (no existe entrada/); 0 omitidos; reemplaza el registro 2026-10-16-portfolio-scan-1 (corregido: PRY-205 tiene 4 hitos sin acta, no 5; se agregaron las senales declared_vs_evidence). Mirar: hitos cerrados sin acta, plan v2 movido con CC-01 pendiente en 203/204/206, factura sin acta en 206, contratos duplicados en 205, compromiso vencido en 208

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Barrido — 2026-10-16

Encontré la carpeta `documentos/proyectos` con 13 carpetas de proyecto y 95 documentos. Términos vigentes, aceptados por José Francisco Ñáñez (v1.1, 2026-10-16). Sin preguntas pendientes: en la sesión sin interfaz tomé las respuestas sugeridas.

**Documentos:** 95 en la carpeta · 62 leídos · 33 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 10 con ficha nueva (PRY-199, 201, 203, 204, 205, 206, 208, 209, 210, 211) · 3 sin tocar (PRY-200, 202, 207, sin cambios) · 0 sin carpeta propia

Formatos: 37 .md, 20 .pdf, 19 .docx, 10 .xlsx, 7 .csv, 1 .json, 1 .txt. Todo se convirtió a texto. Ejecuté el plan tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes, y sellé cada ficha al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros | 6 | identidad, plan y 5 hitos, presupuesto, 1 contrato (CT-199), 2 riesgos, 1 compromiso | autoridad, fase |
| PRY-201 Core de depósitos | 4 | identidad, plan y 4 hitos, presupuesto, 2 riesgos, 3 incidencias | autoridad, fase |
| PRY-203 Open Banking | 7 | identidad, 2 líneas base, 4 hitos, presupuesto, CC-01, 2 compromisos | autoridad, fase |
| PRY-204 Débito contactless | 7 | identidad, 2 líneas base, 4 hitos, presupuesto, CC-01, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado | 7 | identidad, plan y 5 hitos, presupuesto, 2 contratos (CT-853, CT-108), 1 compromiso | autoridad, fase, producto (el acta dice «No aplica») |
| PRY-206 Billetera y QR | 9 | identidad, 2 líneas base, 5 hitos, presupuesto, contrato CT-541 y su factura, CC-01, 1 compromiso | autoridad, fase |
| PRY-208 Motor de decisión | 4 | identidad, plan y 4 hitos, presupuesto, 1 compromiso | autoridad, fase, producto («No aplica»); sin contrato en la carpeta |
| PRY-209 Nómina electrónica | 5 | identidad, plan y 4 hitos, presupuesto, 1 compromiso | autoridad, fase |
| PRY-210 Portal de proveedores | 8 | identidad, plan y 5 hitos, presupuesto, contrato CT-400, su acta de recibo y su factura | autoridad, fase, producto («No aplica») |
| PRY-211 Cobranza digital | 5 | identidad, plan y 4 hitos, presupuesto, 2 actas de recibo | autoridad, fase; sin contrato en la carpeta |

La autoridad del gerente y la fase no aparecen en ninguna de las 10 actas: quedan `not_found`.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: las 10 fichas no existían antes | — |

### Lo que hay que mirar (la declaración contra lo que sustentan los documentos)

**Hitos declarados cerrados sin acta que lo pruebe.** Registré `state: met` tal como lo declara el cronograma y dejé `evidence` vacío donde no hay acta del hito:
- PRY-204: «Ambiente de pruebas» e «Integración con el core» (solo hay acta de «Diseño funcional»).
- PRY-203: «Ambiente de pruebas certificado» (solo hay acta de «Diseño funcional»).
- PRY-205: 4 de 5 hitos, incluida la salida a producción (2026-08-04); la única acta es de «Diseño funcional» y es de 2026-10-09.
- PRY-206: «Diseño funcional» y «Ambiente de pruebas» (el acta de «Integración con el core» sí existe).
- PRY-209: «Diseño funcional aprobado» (el acta de «Ambiente de pruebas» sí existe).
- PRY-210: «Diseño funcional», «Integración con el core» y «Piloto» (sí hay actas de «Ambiente de pruebas» y de «Salida a producción»).
- PRY-211: «Diseño funcional» y «Piloto con usuarios internos» (sí hay actas de «Integración» y «Ambiente»).
- PRY-199 y PRY-201: «Diseño funcional» tiene acta; sin hallazgo.

**Plan movido con la solicitud de cambio todavía pendiente.** En los tres casos el cronograma v2 ya mueve el último hito en la magnitud de la CC-01, y la CC-01 dice «pendiente de presentación al comité». El cálculo de días no autorizados lo hace el script, no yo.
- PRY-203: v2 (2026-09-25) mueve el piloto de 2027-03-21 a 2027-04-23; CC-01 pide +33 días y es del 2026-10-03, posterior al v2.
- PRY-204: v2 (2026-10-15) mueve el piloto de 2026-10-25 a 2027-02-21; CC-01 pide +119 días.
- PRY-206: v2 (2026-10-15) mueve la salida de 2027-05-10 a 2027-07-19; CC-01 pide +70 días.
Solo el informe de PRY-203 declara un motivo (ventana de cambio de operaciones). En PRY-204 y PRY-206 el motivo del v2 no está en ningún documento.

**Proveedores.**
- PRY-206: factura FV-1541 por 82.731.823 COP (2026-09-05) contra CT-541, y ninguno de los 4 entregables tiene acta de recibo. El contrato exige acta firmada por el gerente para facturar.
- PRY-205: dos contratos (CT-853 con Consultora Andina y CT-108 con Núcleo Financiero) con los mismos 4 entregables y las mismas fechas, todos vencidos entre 2025-09 y 2026-06 sin acta de recibo, y sin facturas en la carpeta. No sé si es duplicidad o un reparto; hay que preguntarlo.
- PRY-210: factura FV-1400 por 95.526.751 COP (2026-09-05) contra CT-400; un entregable tiene acta (bolsa de horas, 2026-01-24), el licenciamiento (vence 2025-10-18) y la parametrización (2026-03-22) siguen sin acta.
- PRY-199: sin facturas ni actas; los 3 entregables vencen desde 2026-11-15.

**Presupuesto.** Ejecutado mayor que comprometido, según los propios informes: PRY-206 (406.994.391 vs 296.937.416) y PRY-209 (5.839.363.347 vs 3.105.013.998). PRY-209 además declara rojo. Los cálculos de desviación los da el informe consolidado.

**Declarado contra el plan.**
- PRY-205 declara amarillo y 77% con los 5 hitos cerrados y cierre comprometido el 2026-08-04.
- PRY-210 declara rojo y 85%; cierre comprometido 2026-05-10, con acta de salida a producción del 2026-10-08.
- PRY-211 declara amarillo y 47%; cierre comprometido 2026-05-28, con los 4 hitos cerrados y sin hito de salida a producción en el cronograma.
- PRY-199: el informe dice «se reprogramó la salida» y no hay cronograma posterior al v1 que lo recoja.

**Señales del cálculo sobre las 10 fichas nuevas** (las calcula el script; las cifras por proyecto están en el registro de la corrida): `milestone_met_without_evidence` en 203, 204, 205, 206, 209, 210 y 211; `rebaseline_unauthorized` en 203, 204 y 206; `vendor_invoiced_without_delivery` en 206; `vendor_deliverable_late` en 205, 206 y 210; `progress_vs_plan` en 204, 205, 210 y 211; `declared_vs_evidence` en 203, 204 y 208; `variance_time` en 204 y 206; `variance_cost` en 203; `commitment_overdue` en 208. PRY-199, 201 y 209 no dispararon más señal que la de 209 por un hito sin acta. En todo el portafolio (13 proyectos, incluidos 200, 202 y 207 sin cambios) son 78 hallazgos.

**Compromisos de minutas.** 1 vencido: PRY-208, Mauricio Pérez, «Entregar el punto 28», para 2026-10-01, y la minuta que lo registra es del 2026-10-10 (la fecha ya había pasado cuando se dijo); no hay evidencia de entrega. PRY-205, Óscar Ramírez, «punto 26», vence hoy (2026-10-16). Los otros 7 compromisos están abiertos y vencen entre 2026-10-25 y 2026-11-12. PRY-201 y PRY-210 y PRY-211 no tienen minutas en la carpeta.

**Contradicciones entre documentos:** ninguna. Los campos de las actas, los cronogramas y los informes coinciden donde se solapan.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Todos los documentos se convirtieron a texto |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | La carpeta `entrada/` no existe en esta documentación; no moví nada |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno |

## Después

Hay más de un proyecto con ficha: puedo generar el informe consolidado (`/criterio-portfolio:portfolio-report`) con el cálculo de desviaciones, días no autorizados y señales de portafolio. Lo dejo sin correr porque no lo pidieron.

---
Criterio Portfolio v0.3.12 · fichas tocadas: 10 (PRY-199, 201, 203, 204, 205, 206, 208, 209, 210, 211) · campos en `not_found`: `identity.authority` y `identity.phase` en las 10, y `identity.product` en PRY-205, 208 y 210 (el acta dice «No aplica») · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
