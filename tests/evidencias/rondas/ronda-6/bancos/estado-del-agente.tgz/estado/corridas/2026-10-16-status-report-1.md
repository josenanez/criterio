# Corrida del 2026-10-16 · status-report

13 proyectos · 38 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Informe de PRY-202: avance declarado 80% frente a 40-60% que respalda el plan, hito Integración con el core vencido, 2 hitos cumplidos sin evidencia, compromiso vencido y 2 entregables de proveedor atrasados. Sin dato: autoridad, fase, evidencia de entregables y dueños de RAID.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Informe de estado de PRY-202, calculado a partir de la ficha `estado/records/PRY-202.json` (actualizada el 2026-10-16) y de `portafolio.py compute` con fecha de corte 2026-10-16. Los términos de la versión 1.1 ya estaban vigentes: los aceptó José Francisco Ñáñez el 2026-10-16 y no se registraron de nuevo.

## Migración a la nube (PRY-202) — estado al 2026-10-16

**Declara el gerente (Rubén Cárdenas):** amarillo · 80 % de avance · al 2026-09-27 (19 días de antigüedad). Fuente: `20-seguimiento/2026-09-27-informe-avance.pdf`.
**Sustento documental:** contradicho en el avance; sin sustento en dos hitos que se declaran cumplidos.
**Lo que el semáforo no explica:** cinco señales, que son las de `declared.unaccounted_signals`:
- avance declarado por encima de lo que respalda el plan (`progress_vs_plan`);
- hito vencido (`milestone_overdue`);
- hitos cumplidos sin evidencia (`milestone_met_without_evidence`);
- compromiso vencido (`commitment_overdue`);
- entregables de proveedor atrasados (`vendor_deliverable_late`).

**Último documento:** 2026-10-16 (acta del comité semanal) · **Última reunión:** 2026-10-16 · días en silencio: 0.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-04-22 | 2027-04-22 | 0 días |
| Presupuesto (aprobado / proyección) | 9.500.000.000 COP | proyección 9.691.323.593 COP | +2,0 % sobre lo aprobado |

Replanificaciones: 0. No hay solicitudes de cambio registradas ni línea base posterior a la v1 (acta de constitución del 2025-12-20).

Dinero (COP, informe del 2026-09-27):
- aprobado: 9.500.000.000
- comprometido: 2.675.338.214 (28,2 %)
- ejecutado: 5.614.863.191 (59,1 %)
- disponible real: 6.824.661.786

**Avance declarado frente a plan:** el gerente declara 80 %. Con 2 de 5 hitos cumplidos, el plan respalda entre 40 % y 60 %. La brecha es de 20 puntos hacia arriba, es decir, lo declarado va por delante del plan. Además, el ejecutado es 59,1 % del presupuesto.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-04-04 | 2026-04-04 | declarado cumplido | **ninguna** (195 días desde la fecha) |
| Ambiente de pruebas certificado | 2026-07-09 | 2026-07-09 | declarado cumplido | **ninguna** (99 días desde la fecha) |
| Integración con el core | 2026-10-12 | 2026-10-12 | pendiente, **vencido hace 4 días** | — |
| Piloto con usuarios internos | 2027-01-16 | 2027-01-16 | pendiente | — |
| Salida a producción | 2027-04-22 | 2027-04-22 | pendiente | — |

### Dónde no coincide
- **Avance:** el informe del 2026-09-27 declara 80 %. El cronograma v1 (2025-12-20) con 2 de 5 hitos cumplidos respalda entre 40 % y 60 %. Y esos dos hitos no tienen evidencia de cumplimiento en la carpeta.
- **Hito vencido bajo un semáforo amarillo:** «Integración con el core» venció el 2026-10-12. El informe del 2026-09-27 ya registraba como incidencia que dos historias quedaron fuera del sprint «por dependencia con el core».
- **Dependencia no declarada:** el acta dice «Ninguna declarada», pero la incidencia anterior describe una dependencia con el core. Se cita la contradicción; no se juzga cuál de los dos documentos tiene razón.
- **Proveedor:** el informe es del 2026-09-27 y no hay informe posterior. No lo sustituye el acta del comité del 2026-10-16, que solo trata «Avance» y «Compromisos» sin cifras.

### Abierto
**Riesgos e incidencias sin movimiento** (los tres vienen del informe del 2026-09-27; los plazos y los dueños faltan, por lo que no se pueden medir días sin movimiento):
- Riesgo: disponibilidad del equipo de seguridad para la revisión final. Sin probabilidad, impacto, dueño ni fecha.
- Incidencia: la prueba de carga no alcanzó el umbral pactado y se repite (desde 2026-09-27, 19 días). Sin dueño.
- Incidencia: dos historias fuera del alcance del sprint por dependencia con el core (desde 2026-09-27, 19 días). Sin dueño.

**Compromisos vencidos:** Jorge Medina, «Entregar el punto 21», para el 2026-10-05, 11 días vencido. Se registró en el comité del 2026-10-16 con una fecha que ya había pasado, y Jorge Medina no figura entre los asistentes. No hay evidencia de entrega. «El punto 21» no se explica en ningún documento.

**Proveedor Datacore Colombia:**
- CT-726, «Bolsa de horas de desarrollo»: vencía el 2026-09-19, está pendiente, 27 días de atraso, sin evidencia.
- CT-894, «Licenciamiento del motor»: vencía el 2026-06-23, está pendiente, 115 días de atraso, sin evidencia.
- CT-726 tiene facturado 594.710.263 COP, igual al monto del entregable aceptado «Licenciamiento del motor», cuya acta de recibo es del 2026-05-14 (vencía el 2026-05-10). En el CT-894 el mismo nombre de entregable figura pendiente. Es un punto que conviene revisar por si el mismo alcance se contrató dos veces; los documentos no lo afirman.

**Dependencias sin confirmar:** ninguna declarada en la ficha.

### Sin dato
- Autoridad del proyecto (`identity.authority`) y fase (`identity.phase`).
- Producto asociado: el acta dice «No aplica».
- Facturación del CT-894: no hay dato.
- Evidencia de entrega de 4 entregables de proveedor (CT-726: 2 entregables; CT-894: 2).
- Probabilidad, impacto, dueño y fecha del riesgo, y dueños de las dos incidencias.
- Sin separación entre declaración y evidencia en 40 campos de la ficha (`sources.unmarked`).

### Siguiente paso
La desviación de plazo y de costo está por debajo del umbral del 10 %. Pero hay un hito vencido, hitos cumplidos sin evidencia y un avance declarado que el plan no respalda. Se ofrece preparar el punto de comité con esas tres decisiones.

---
Pie: criterio-portfolio 0.3.12 · ficha de PRY-202 aplicada, actualizada el 2026-10-16 · campos inciertos: los de «Sin dato» · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
