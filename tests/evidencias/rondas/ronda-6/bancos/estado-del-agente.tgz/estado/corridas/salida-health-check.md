## Diagnóstico · PRY-205 Prevención de lavado de activos · 2026-10-16

**Términos:** vigentes (v1.1, familia 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16. Comprobante en `.criterio/terminos/`.

**Leí:** 7 documentos del proyecto · de 2025-05-24 a 2026-10-15 · formatos: .docx (3), .md (2), .pdf (1), .xlsx (1)
**Además:** busqué «PRY-205», «lavado», «CT-853», «CT-108» y «punto 26» en los otros 139 documentos del portafolio (proyectos y productos). Ninguno menciona a este proyecto. «Óscar Ramírez» aparece en otros proyectos (PRY-203, PRY-204, PRY-207) y en comités de producto. Ninguno lo vincula con PRY-205 ni con el «punto 26».
**No pude leer:** nada. Los 7 se convirtieron a texto. Parto de los documentos y no de la ficha previa, que usé solo para ubicar las rutas.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 10 · **Contradicho:** 2

Desde esta carpeta se puede afirmar quién gobierna el proyecto en el papel, que el presupuesto aprobado es de 9.500.000.000 COP y que el diseño funcional se recibió el 2026-10-09. No se puede afirmar que el proyecto esté en amarillo ni que lleve 77 % de avance. El cronograma dice que los 5 hitos están cerrados, incluida la salida a producción del 2026-08-04, y el informe del 2026-10-15 dice 77 %. Cuatro de esos cinco hitos no tienen ningún documento de recibo. Ninguno de los 8 entregables de proveedor tiene acta de recibo, y no hay una sola factura en la carpeta. Entre 2025-06-04 y 2026-10-09 no hay ningún documento. Casi toda la evidencia de este proyecto está fechada en la última semana.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Camilo Beltrán | Acta de constitución 2025-05-31 |
| Gerente | Carlos Peña | Acta de constitución 2025-05-31 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente, ni en tiempo ni en dinero. | Acta de constitución 2025-05-31 |
| Comité | Comité de Riesgos. Aprobó el presupuesto el 2025-05-31. La minuta del 2026-10-10 lo muestra reunido con Carlos Peña y Camilo Beltrán. | Acta; minuta 2026-10-10 |
| Producto asociado | «No aplica» | Acta |
| Alcance | «Componente 1, 2, 3», sin descripción. Fuera de alcance: «lo que otro proyecto cubre», sin nombrar cuál. | Acta |
| Dependencias | «Ninguna declarada», aunque hay dos proveedores contratados. | Acta; CT-853; CT-108 |

Sin autoridad declarada no hay desviación aprobada: las fechas del cronograma son fechas que alguien escribió.

### Contra el plan
- **Línea base original:** v1, aprobada el 2025-05-31, con cierre el 2026-08-04 (acta y cronograma v1).
- **Línea base vigente:** es la misma. No hay replanificaciones, solicitudes de cambio ni cronograma v2 (replanificaciones = 0, cambios = 0 en la salida de `compute`).
- **Fecha de cierre:** el 2026-08-04 ya pasó. El proyecto sigue reportando avance del 77 % al 2026-10-15, sin replanificación ni cambio aprobado.
- **Desviación contra la línea base:** `compute` da 0 días contra la original y 0 contra la vigente. Esa cifra no mide el atraso real. Sale de que el cronograma marca los 5 hitos como «cerrado» con fecha vigente igual a la de línea base. El acta de recibo del diseño funcional está fechada 2026-10-09, y el hito era del 2025-09-02. El cronograma no registra ese atraso.
- **Avance contra plan:** el plan sostiene 100 % (5 de 5 hitos cerrados). Lo declarado es 77 %, una diferencia de 23 puntos.

### Hitos vencidos sin evidencia
Estos hitos figuran como cerrados en el cronograma y no tienen un solo documento de recibo. Los días son contados desde la fecha del hito hasta hoy.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ambiente de pruebas certificado | 2025-11-25 | 325 | Acta de recibo o certificación del ambiente |
| Integración con el core | 2026-02-17 | 241 | Acta de recibo de la integración |
| Piloto con usuarios internos | 2026-05-12 | 157 | Acta de cierre del piloto con resultados |
| Salida a producción | 2026-08-04 | 73 | Acta de puesta en producción. El criterio de éxito del acta exige «en producción y medido», lo que además pide mediciones. |

Diseño funcional aprobado (2025-09-02) sí tiene acta de recibo, firmada por Carlos Peña el 2026-10-09. Es el único hito con evidencia. El acta no dice quién entregó, no cita criterios de aceptación y no explica la fecha.

**Entregables de proveedores** (ninguno tiene acta de recibo, y el contrato exige acta firmada por el gerente para facturar):

| Entregable | Fecha | Días | CT-853 Consultora Andina | CT-108 Núcleo Financiero |
|---|---|---|---|---|
| Licenciamiento del motor | 2025-09-10 | 401 | 425.030.772 | 491.846.814 |
| Bolsa de horas de desarrollo | 2025-12-12 | 308 | 425.030.772 | 491.846.814 |
| Parametrización del tarifario | 2026-03-14 | 216 | 425.030.772 | 491.846.814 |
| Mesa de ayuda del primer trimestre | 2026-06-15 | 123 | 425.030.772 | 491.846.814 |

Los estados que escribe cada contrato son «en curso» o «pendiente», fechados en la firma (2025). Ninguno ha sido actualizado. `compute` no da la suma de los contratos, así que no la calculo aquí. El valor facturado no aparece en ningún documento.

### Dinero
Cifras de la salida de `compute` (COP). Las cuatro cifras vienen del informe del 2026-10-15, salvo el aprobado, que viene del acta.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 5.292.231.115 (55,7 %) | 1.534.440.797 (16,2 %) | 9.165.818.019 (−3,5 % frente al aprobado) | 4.207.768.885 |

Se declara 77 % de avance con 16,2 % del presupuesto ejecutado. El informe no explica la diferencia. El informe no desglosa el comprometido, y la carpeta no tiene facturas que respalden el ejecutado.

### Lo que se dijo y nadie registró
- **Compromiso con vencimiento hoy:** Óscar Ramírez, «Entregar el punto 26», para el 2026-10-16 (minuta del Comité de Riesgos del 2026-10-10). Vence hoy y no está vencido. No hay evidencia de entrega. Nada dice qué es el «punto 26». Óscar Ramírez no figura como asistente del comité ni con rol en el acta.
- **Minuta sin contenido:** los temas «Avance» y «Compromisos» están enunciados, pero la minuta no registra decisiones ni discusión.
- **Riesgo sin registrar:** «Concentración del conocimiento en una sola persona» solo aparece en el informe, sin probabilidad, impacto, responsable ni fecha. Cuando una sola persona concentra el conocimiento, el diagnóstico depende de ella.
- **Incidencia sin registrar:** «Hallazgo de seguridad en la revisión de arquitectura» solo aparece en el informe, sin responsable, fecha ni detalle. No sé si afecta la salida a producción.
- **Dependencias:** el acta dice «ninguna declarada», pero hay dos contratos con proveedores.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance del proyecto | Informe 2026-10-15: amarillo, 77 % | Cronograma v1: 5 de 5 hitos «cerrado», incluida la salida a producción del 2026-08-04 |
| Diseño funcional cumplido en la fecha del plan (vigente = línea base, 2025-09-02) | Cronograma v1 | Acta de recibo: recibido el 2026-10-09 |

### Sin sustento
Lo que nada contradice y nada respalda:
1. Estado amarillo: no hay criterio escrito de cómo se asigna.
2. Hito «Ambiente de pruebas certificado» cerrado.
3. Hito «Integración con el core» cerrado.
4. Hito «Piloto con usuarios internos» cerrado.
5. Hito «Salida a producción» cerrado.
6. Comprometido: 5.292.231.115.
7. Ejecutado: 1.534.440.797.
8. Proyección al cierre: 9.165.818.019.
9. Riesgo de concentración del conocimiento (solo existe en el informe).
10. Hallazgo de seguridad (solo existe en el informe).

**Sostenido** (3): (1) diseño funcional recibido el 2026-10-09; (2) presupuesto aprobado de 9.500.000.000 COP por el Comité de Riesgos el 2025-05-31; (3) patrocinador, gerente y comité nombrados en el acta.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en producción.** Sin acta de salida ni mediciones, no se puede saber si se cumplió el criterio de éxito. El plan dice que sí y el informe sugiere que no.
- **Cuánto se atrasó realmente.** Sin cronograma v2 ni solicitudes de cambio, el atraso queda en 0 días solo porque el plan nunca se actualizó.
- **Qué se recibió de los proveedores y qué se pagó.** Sin actas de recibo ni facturas, no se sabe qué se entregó, qué se facturó ni cuánto de los 5.292.231.115 comprometidos corresponde a CT-853 y CT-108.
- **Por qué hay dos contratos con los mismos 4 entregables, nombres y fechas** (CT-853 con Consultora Andina y CT-108 con Núcleo Financiero), con montos distintos. Puede ser un alcance duplicado o una plantilla copiada. Los documentos no lo aclaran.
- **Qué puede decidir el gerente.** Sin autoridad declarada, nadie puede aprobar un cambio de fechas o de presupuesto dentro de este proyecto.
- **Qué pasó entre 2025-06-04 y 2026-10-09.** No hay documentos de ese periodo.
- **Qué es el «punto 26»** y qué se debe entregar hoy.

### Cierre de rigor
Leí 7 documentos y busqué referencias en 139 más. Las cifras derivadas (porcentajes, días, disponible, proyección frente al aprobado) vienen de `portafolio.py compute`. Los textos que cito salen de los documentos originales, y la verificación final es suya. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

**Siguientes pasos que puedo preparar:**
- El punto de comité con la lista de lo que falta, porque la carpeta no permite diagnosticar si el proyecto está en producción.
- Las contradicciones y los vacíos como preguntas para Carlos Peña, una por una.
