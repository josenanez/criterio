**Sale de:** la ficha PRY-200 y el cálculo `portafolio.py compute` al 2026-10-16, y de 10 documentos de `PRY-200-originación-digital`: dos contratos (CT-936, CT-107), dos facturas (FV-1936, FV-2107), dos actas de recibo, el informe de avance del 2026-10-15, el acta del comité del 2026-10-16, el acta de constitución y el cronograma v1.

## Proveedores — PRY-200 Originación digital al 2026-10-16

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no se registraron de nuevo.

**Resumen:** los dos proveedores facturaron el 100 % de un monto contractual (Datacore 489.791.403 COP, Núcleo 707.420.229 COP) y **ningún entregable de ninguno tiene acta de recibo**. El script levanta `vendor_invoiced_without_delivery` para los dos. Ambos contratos condicionan el pago a un acta de recibo firmada por el gerente del proyecto, y esa acta no está en la carpeta.

### Datacore Colombia — contrato CT-936
**Vigencia:** firma 2025-12-03; fin, renovación y preaviso no figuran en el documento · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-05-30 (139 días de atraso) | pending (el contrato dice "pendiente") | ninguna | FV-1936, 2026-09-27: 489.791.403 COP, concepto "Entregables del contrato CT-936", sin indicar cuál |
| Bolsa de horas de desarrollo | 2026-11-04 | pending (el contrato dice "en curso") | ninguna | no se puede asignar a esta línea |

Fuentes: `00-gobierno/2025-12-03-contrato-ct-936.md`, `20-seguimiento/2026-09-27-factura-ct-936.pdf`.

### Núcleo Financiero S.A. — contrato CT-107
**Vigencia:** firma 2025-12-14; fin, renovación y preaviso no figuran en el documento · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-03-28 (202 días de atraso) | pending (el contrato dice "en curso") | ninguna | FV-2107, 2026-09-10: 707.420.229 COP, concepto "Entregables del contrato CT-107", sin indicar cuál |
| Bolsa de horas de desarrollo | 2026-07-01 (107 días de atraso) | pending (el contrato dice "en curso") | ninguna | no se puede asignar |
| Parametrización del tarifario | 2026-10-04 (12 días de atraso) | pending (el contrato dice "en curso") | ninguna | no se puede asignar |
| Mesa de ayuda del primer trimestre | 2027-01-07 | pending (el contrato dice "en curso") | ninguna | no se puede asignar |

Fuentes: `00-gobierno/2025-12-14-contrato-ct-107.docx`, `20-seguimiento/2026-09-10-factura-ct-107.md`.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Pago de CT-936 | Se factura cada entregable contra acta de recibo firmada por el gerente | Hay factura por 489.791.403 COP y ninguna acta de recibo de Datacore; entregables aceptados: 0 | contrato CT-936; FV-1936 |
| Pago de CT-107 | Ídem | Hay factura por 707.420.229 COP y ninguna acta de recibo de Núcleo; entregables aceptados: 0 | contrato CT-107; FV-2107 |
| Estado "en curso" frente a entregables vencidos | CT-107 marca sus cuatro entregables "en curso" | Tres tienen fecha vencida (202, 107 y 12 días) y nada documenta avance | contrato CT-107 |
| Actas de recibo que existen | — | Las dos actas (2026-10-04 "Diseño funcional aprobado", 2026-10-14 "Ambiente de pruebas certificado") no corresponden a ningún entregable de CT-936 ni de CT-107; no sustentan ninguna de las facturas | actas de recibo del 2026-10-04 y 2026-10-14 |
| "Licenciamiento del motor" | Aparece en los dos contratos, con fechas y montos distintos (2026-05-30 y 2026-03-28) | Posible duplicidad de alcance; los documentos no lo aclaran | CT-936; CT-107 |
| Monto por entregable | Cada entregable de un contrato lleva el mismo monto que la factura entera | No se puede saber si cada factura paga un entregable o todo el contrato | contratos; facturas |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento del motor (Datacore) | pending | vencido desde 2026-05-30 |
| Bolsa de horas de desarrollo (Datacore) | pending | vence 2026-11-04 |
| Licenciamiento del motor (Núcleo) | pending | vencido desde 2026-03-28 |
| Bolsa de horas de desarrollo (Núcleo) | pending | vencido desde 2026-07-01 |
| Parametrización del tarifario (Núcleo) | pending | vencido desde 2026-10-04 |
| Mesa de ayuda del primer trimestre (Núcleo) | pending | vence 2027-01-07 |

Con el criterio de vendor-control ninguno puede subir a `delivered`: sin evidencia, `unknown` o `pending`. El script no registra entregables "declarados entregados sin evidencia" (`accepted_without_evidence` vacío en ambos); el problema es la factura, no una declaración de entrega.

### Compromisos del proveedor vencidos
Ninguno. El comité del 2026-10-16 tiene un solo compromiso, de Felipe Arango (patrocinador, no proveedor): "Entregar el punto 4", para el 2026-10-25. No hay compromisos de proveedores en las reuniones.

### Contexto del proyecto
El informe de avance del 2026-10-15 declara estado rojo y 49 % de avance, y no menciona proveedores, entregables vencidos ni las facturas. El script marca avance 11,0 puntos por debajo de lo que sustenta el plan (60–80 %) y el hito "Integración con el core" (vence 2026-09-08, 38 días) como cumplido sin evidencia. Presupuesto en el informe: comprometido 5.617.037.802 COP (82,6 %), ejecutado 1.908.189.235 COP (28,1 %).

### Sin dato
- **Vigencia, terminación, renovación automática y preaviso de CT-936 y CT-107:** los contratos solo traen firma, entregables y condición de pago. No se puede decir si hay un preaviso por vencer; **este punto queda sin evaluar**.
- **Qué entregable(s) cubre cada factura:** las facturas no lo dicen.
- **Si las facturas ya se pagaron:** solo dicen "radicada en cuentas por pagar".
- **Estado de pago de las facturas:** no hay documento de pago.
- **Montos totales de contrato:** no figuran; los documentos listan un monto por entregable, igual en todas las líneas de cada contrato.
- **Actas de aceptación de cualquier entregable de proveedor:** no existen en la carpeta. Pueden existir fuera de ella, y de eso no hay forma de saber.

## Después
Ambas facturas están radicadas en cuentas por pagar sin acta de recibo que las respalde. Si aún no se han pagado, conviene frenarlas hasta que exista el acta o el gerente explique la excepción. **Se ofrece llevarlo a comité** (próximo, 2026-10-23) como decisión: retener el pago, pedir las actas a Ricardo Salas, y pedir a ambos proveedores la vigencia y el preaviso de los contratos.

---
**Pie de rigor:** cifras tomadas de `portafolio.py compute` (2026-10-16) y de los documentos citados; no hay cifra propia salvo la lectura de los textos. Leídos en texto convertido (caché), con la cita apuntando al original. Verificar contra los documentos antes de decidir. Criterio produce borradores de trabajo, no decisiones ni asesoría.
