Carpeta al 2026-10-16: 95 documentos, todos sin cambio. No hay nada que releer ni citas rotas.
