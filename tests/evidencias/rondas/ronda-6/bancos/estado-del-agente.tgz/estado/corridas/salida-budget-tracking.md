## Presupuesto — PRY-203 Open Banking al 2026-10-16
**Moneda:** COP (todos los montos del proyecto están en COP; no hubo conversiones)

Sale de: ficha PRY-203 y `compute` del 2026-10-16, sobre el acta de constitución (2026-01-22), el informe de avance (2026-09-25), el cronograma v2 (2026-09-25) y la solicitud de cambio CC-01 (2026-10-03).

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 18.000.000.000 | 100 % | Acta de constitución | 2026-01-22 |
| Comprometido | 9.797.767.251 | 54,4 % | Informe de avance | 2026-09-25 |
| Ejecutado | 7.810.329.197 | 43,4 % | Informe de avance | 2026-09-25 |
| Proyección al cierre | 22.250.676.721 | 123,6 % (excede 23,6 %) | Informe de avance | 2026-09-25 |

**Disponible real** (aprobado menos comprometido): 8.202.232.749 COP

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 18.000.000.000 | 18.000.000.000 | 0 (no hay cambio de presupuesto aprobado) |
| Proyección vs. aprobado | | 22.250.676.721 | +23,6 % (umbral 10 %) |

Replanificaciones de presupuesto: 0. La única solicitud de cambio, CC-01 (+66.000.000 COP, +33 días, ampliación de alcance), está **pendiente**, sin decisor: no modifica el aprobado.

### Ejecución frente a avance
Ejecutado 43,4 % · Hitos cumplidos 2 de 4 · Avance declarado 46 %; el plan sustenta entre 50 y 75 %. El gasto va alineado con el avance declarado, pero el avance declarado incluye un hito sin evidencia (ver alertas). La desalineación no está en la ejecución, sino en la proyección.

### Alertas
- **Proyección excede el aprobado en 23,6 %** (22.250.676.721 vs 18.000.000.000), por encima del umbral de 10 %. Y el informe del mismo 2026-09-25 declara estado **verde**: la proyección contradice la declaración. Es un dato declarado, no medido, y tiene 21 días.
- **Comprometido 54,4 %**: bajo el umbral de 90 %. Hoy no es la señal.
- **La brecha de 4.250.676.721 COP entre proyección y aprobado no tiene una solicitud de cambio que la cubra.** CC-01 pide solo 66.000.000 COP, y está pendiente.
- Contexto de cronograma: la línea base se movió 33 días (fin 2027-03-21 a 2027-04-23) sin cambio autorizado.
- Hito "Ambiente de pruebas certificado" (vencido 2026-08-26) figura cumplido sin evidencia de recibo; puede estar sosteniendo parte del avance declarado.

### Sin dato
- Desglose del comprometido por proveedor/contrato: la ficha no tiene proveedores registrados para PRY-203.
- Si el informe de avance declara un presupuesto vigente distinto del aprobado: no encontrado más allá del aprobado de la constitución.
- Fecha del último movimiento de presupuesto: no declarada; no puedo decir si la proyección es más vieja que ese movimiento.
- Autoridad y fase del proyecto: faltan en la ficha.

### Siguiente paso posible
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/change-control`), con la brecha de 4.250.676.721 COP a sustentar.

**Pie de rigor:** borrador de trabajo, no decisión. Las cifras derivadas salen de `compute`; las cifras base, de los documentos citados. La verificación es suya.
