# Corrida del 2026-10-16 · project-closure

13 proyectos · 44 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Lectura de cierre de PRY-205: no hay declaración de terminación (informe 2026-10-15: amarillo, 77%); criterio de éxito declarado pero sin indicador; cumplimiento no determinable; 4 hitos 'cumplidos' sin evidencia; 8 entregables de proveedor vencidos sin recibo; no se recomienda archivar.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

**Fuente:** ficha `estado/records/PRY-205.json` (corte 2026-10-16) y los documentos de `PRY-205-prevención-de-lavado-de-activos/`: acta de constitución (2025-05-31), contratos CT-853 y CT-108, cronograma v1, acta de recibo (2026-10-09), informe de avance (2026-10-15) y comité semanal (2026-10-10). Cifras derivadas de `portafolio.py compute`. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-16 (v0.3.12).

## Cierre — PRY-205 Prevención de lavado de activos — 2026-10-16

### Lo primero: no hay declaración de que el proyecto terminó
Ningún documento declara el cierre. El informe de avance del 2026-10-15 (Carlos Peña) dice **estado Amarillo, avance 77 %**, con un hallazgo de seguridad abierto. Por eso esto **no es un acta de cierre**: es la lectura de dónde está el proyecto contra lo comprometido, para que alguien con autoridad decida si lo cierra, y cómo. Si se cerrara hoy, sería por decisión y no por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Prevención de lavado de activos en producción y medido." (acta de constitución, 2025-05-31). Está declarado, pero sin cifra, umbral ni indicador: "medido" no dice contra qué.
**Se cumplió:** **no se puede determinar.** Ningún documento muestra el sistema en producción ni una medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (hito, base 2025-09-02) | Cumplido | Acta de recibo del 2026-10-09 firmada por Carlos Peña |
| Ambiente de pruebas certificado (base 2025-11-25) | Declarado "cumplido" | Ninguna |
| Integración con el core (base 2026-02-17) | Declarado "cumplido" | Ninguna |
| Piloto con usuarios internos (base 2026-05-12) | Declarado "cumplido" | Ninguna |
| Salida a producción (base 2026-08-04) | Declarado "cumplido" | Ninguna |
| Alcance: "Componentes 1 a 3" | No se puede determinar | El acta no los describe |

Contradicción: el cronograma marca 5 de 5 hitos como cumplidos, que sostendría 100 %, y el informe reporta 77 % (diferencia de 23 puntos). Uno de los dos es incorrecto. Cuatro hitos "cumplidos" no tienen documento que los respalde. El de "Salida a producción" vencía hace 73 días.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (único fuera de alcance del acta; no dice cuál proyecto) | Acta de constitución | 2025-05-31 |
| Ningún recorte posterior registrado | — | — |

No hay control de cambios registrado (0 cambios). Si el alcance real difiere del acta, no consta quién lo decidió.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-04 | 2026-08-04 | Sin cierre | 0 días registrados (ver nota) |
| Presupuesto (COP) | 9.500.000.000 aprobado | 9.500.000.000 | Proyección 9.165.818.019 | −3,5 % (proyección, no final) |

- Replanificaciones: **0** registradas.
- Comprometido 5.292.231.115 (55,7 % del aprobado). Ejecutado 1.534.440.797 (16,2 %). Disponible real 4.207.768.885.
- Nota sobre la fecha: la desviación "0 días" es el resultado de que nadie replanificó, no de que se haya cumplido. La fecha base pasó hace 73 días, con avance declarado de 77 % y sin producción demostrada. No hay una fecha vigente real: la línea base no se actualizó.
- El ejecutado (16,2 %) es bajo frente al avance declarado (77 %). El informe no explica la brecha.

### RAID al cierre
**Materializados:** el hallazgo de seguridad en la revisión de arquitectura figura como incidencia abierta en el informe del 2026-10-15, sin fecha de origen ni responsable.
**No materializados:** no se puede determinar. El acta declara "Ninguna" dependencia y no hay registro RAID.
**Abiertos, con doliente:**
- Riesgo "Concentración del conocimiento en una sola persona" (informe 2026-10-15): sin responsable, probabilidad, impacto ni fecha. **No está cerrado.**
- Incidencia de seguridad: sin responsable. **No está cerrada.**
- Compromiso de Óscar Ramírez, "Entregar el punto 26", para 2026-10-16 (comité del 2026-10-10): vence hoy, sin evidencia todavía. El documento no dice qué es el "punto 26".

**Proveedores (ocho entregables contractuales, ninguno aceptado):**
- Los cuatro entregables de cada contrato están vencidos, entre 123 y 401 días, sin acta de recibo y sin facturación registrada.
  - Consultora Andina S.A.S. (CT-853): 425.030.772 por entregable.
  - Núcleo Financiero S.A. (CT-108): 491.846.814 por entregable.
- Los dos contratos listan los mismos cuatro entregables, con las mismas fechas, pero montos distintos. El documento no explica si son contratos paralelos, duplicados o un reparto. Es una pregunta para el patrocinador, no una conclusión.
- Los estados de los contratos ("en curso" / "pendiente") se contradicen entre sí para el mismo entregable.
- Ambos contratos facturan contra acta de recibo firmada por el gerente. Si hubo pagos, no consta contra qué.

### Lecciones
Se registran solo dos, que sí se anclan a hechos. Son provisionales: el proyecto no está cerrado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El criterio de éxito se pactó como "en producción y medido", sin indicador ni umbral, y el alcance como "Componentes 1 a 3" sin descripción | Acta del 2025-05-31 | Hoy no se puede determinar si se cumplió: el cierre depende de interpretar dos frases | Fijar en el acta el indicador, el umbral y la definición de cada componente antes de aprobarla |
| Los hitos se marcaron "cumplidos" sin documento de respaldo; el único respaldado es el recibo del diseño funcional, firmado el 2026-10-09 (base 2025-09-02) | Hitos de 2025-11-25 a 2026-08-04; recibo 2026-10-09 | Cronograma (5/5, 100 %) e informe (77 %) se contradicen, y hay ocho entregables de proveedor vencidos sin recibo | Exigir el acta de recibo o la evidencia antes de cambiar un hito a "cumplido" |

No se incluyen lecciones sobre comunicación, equipo o proveedores más allá de estos hechos: no hay documento que las sustente.

### Sin dato
- Declaración de terminación o decisión de cierre, y quién la tomaría.
- Evidencia de producción y medición (criterio de éxito).
- Detalle de los Componentes 1 a 3 y qué proyecto cubre lo excluido.
- Evidencia de los hitos 2 a 5 y recibos de los ocho entregables de proveedor.
- Facturación y pagos a proveedores. Gasto final.
- Fecha de origen y responsable del hallazgo de seguridad y del riesgo de concentración de conocimiento.
- Producto asociado (el acta dice "No aplica"), autoridad y fase.
- Todos los datos de la ficha tienen 16 a 17 meses de antigüedad y no hay fuente marcada como evidencia o declaración (0 y 0, 50 sin marcar).

### Después
No recomiendo mover la carpeta a `archivo/` ni congelar la ficha: el proyecto sigue abierto por su propio informe. Si el Comité de Riesgos decide cerrarlo por decisión, eso debe quedar escrito con nombre y fecha, junto con quién asume los abiertos. Si cierra, ofrezco mover la carpeta y congelar la ficha con su última instantánea.

*Pie de rigor: borrador de trabajo, no decisión. Cada dato viene del documento citado y la verificación es de quien lo usa. Criterio solo ve lo que está en la carpeta; no sabe lo que se habló fuera de ella.*
