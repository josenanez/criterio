# Corrida del 2026-10-16 · document-index

13 proyectos · 7 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Índice sobre 95 documentos: ninguno cambió, ninguno por releer, sin renombrados, borrados ni citas rotas. No se produjo informe.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Carpeta al 2026-10-16: 95 documentos, todos sin cambio. No hay nada que releer ni citas rotas.
