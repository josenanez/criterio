**Términos:** vigentes y ya aceptados (v1.1, José Francisco Ñáñez, 2026-10-16); no hubo que registrarlos de nuevo.

# RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-16

**Sale de:** las 13 fichas (`estado/records`), los 13 informes de avance, la sección «Dependencias declaradas» de las 13 actas de constitución, 15 minutas de comité, las notas de reunión de PRY-207 del 2026-10-16 y las 4 solicitudes de cambio. No hay RAID previo ni historial de movimiento: solo existe una captura (2026-10-16).

**9 riesgos · 0 supuestos · 12 incidencias · 9 dependencias** (tras reclasificar; en las fichas llegaban 18 riesgos, 12 incidencias y 0 dependencias)
**30 de 30 sin doliente** (29 sin doliente; 1 con «no identificado») · **30 de 30 sin fecha** · **sin movimiento: no se puede medir** · **1 no registrado formalmente**

Escala de valoración: no hay una definida por la organización; se usaría alta/media/baja, pero ningún documento valora probabilidad ni impacto, y no los inventé.
Los ids son provisionales (`D` dependencia, `R` riesgo, `I` incidencia + proyecto + n.º); las fichas no traen ids.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| D-199/201/203/206 | Dependencia | «Dependencia del calendario de liberaciones del core», registrada como riesgo en 4 proyectos | Ninguno | 2026-09-25 (informe de PRY-203; el más antiguo) | Afecta a varios proyectos a la vez. Además, las incidencias de PRY-202, PRY-210 y PRY-211 («dos historias quedaron fuera del alcance del sprint por dependencia con el core») muestran que ya se materializó en 3 más: 7 proyectos tocados. Ningún documento dice de qué proyecto o equipo es «el core». |
| D-200/202/206/210 | Dependencia | «Disponibilidad del equipo de seguridad para la revisión final» | Ninguno | 2026-09-27 (informe de PRY-202) | Recurso ajeno compartido por 4 proyectos; PRY-206 y PRY-210 declaran Rojo. |
| D-208 | Dependencia | «El proveedor no ha confirmado la fecha de la última entrega» | Ninguno | 2026-09-24 (informe de PRY-208) | 22 días sin movimiento visible, el doliente es externo, y el proyecto declara Verde. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-207) | Riesgo | `PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt` | 2026-10-16 |

Es el único. Las otras 14 minutas de comité solo traen tablas de compromisos y los «Lo que se dijo» de PRY-207 hablan de entregas sin acta, no de riesgos (eso es de `/pm-commitments`). PRY-201, PRY-210 y PRY-211 no tienen carpeta de reuniones: ahí no hay dónde buscar. En PRY-207 no hay contrato de proveedor en la carpeta, así que no puedo decir de qué proveedor se habla.

### Sin doliente o sin fecha
Faltan **ambos** en todos los ítems. Se reporta, no se rellena.

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| I-201-1..3 | Incidencia | Prueba de carga no alcanzó el umbral; pérdida de dos semanas por rotación; hallazgo de seguridad | Doliente y fecha de inicio. El proyecto declara Verde con 3 incidencias abiertas. |
| I-208-1..3 | Incidencia | Hallazgo de seguridad; prueba de carga; rotación de un desarrollador | Doliente y fecha. Declara Verde con 3 incidencias abiertas. |
| I-202-1, I-202-2 | Incidencia | Prueba de carga; dos historias fuera del sprint | Doliente (fecha de inicio: 2026-09-27, que es la del informe, no la del hecho). |
| I-204-1, I-205-1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | Doliente y fecha. |
| I-210-1, I-211-1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | Doliente y fecha. |
| R-199/200/201/204/205/207/209 | Riesgo | «Concentración del conocimiento en una sola persona» (7 proyectos) | Doliente, fecha, probabilidad, impacto, mitigación. Ningún documento dice quién es la persona. |
| R-211-1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | Doliente, fecha, valoración. |
| R-207-2 | Riesgo | Proveedor sin equipo completo | Doliente (figura «no identificado») y fecha. |
| D-… (los 9) | Dependencia | Ver arriba | Doliente, fecha, proyecto o equipo del que depende, confirmación. |

Sin movimiento en dos períodos y mitigaciones vencidas: **no los puedo evaluar.** No hay una captura anterior del RAID y ninguna ficha registra una mitigación con fecha.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| D-199, D-201, D-203, D-206 | «El core», sin código de proyecto | No (declarada, no acordada) | Si «el core» fuera PRY-201 Core de depósitos, su cierre no se movió (2027-07-31, línea base única), pero reporta prueba de carga fallida y dos semanas perdidas, y su hito «Ambiente de pruebas certificado» (2026-12-23) sigue pendiente. **Es una hipótesis mía: ningún documento lo dice.** Nota: PRY-201 registra esta misma dependencia de sí mismo. |
| D-200, D-202, D-206, D-210 | Equipo de seguridad (sin proyecto) | No | Sin información de la contraparte. |
| D-208 | Proveedor de la última entrega | No: el propio informe dice que no ha confirmado | Sin respuesta desde el informe del 2026-09-24. |

Cruce por código de proyecto: **imposible.** Las 13 actas declaran «Ninguna declarada» y ningún informe nombra otro proyecto, así que no hay dependencia que cruzar contra una fecha movida.

### Reclasificadas (y por qué)
- **«Dependencia del calendario de liberaciones del core»** (PRY-199, 201, 203, 206): estaba como riesgo. Depende de alguien fuera del proyecto → dependencia.
- **«Disponibilidad del equipo de seguridad para la revisión final»** (PRY-200, 202, 206, 210): estaba como riesgo. Depende de un equipo ajeno → dependencia.
- **«El proveedor no ha confirmado la fecha de la última entrega»** (PRY-208): estaba como riesgo. Ya es un hecho presente y depende de un tercero → dependencia.
- Las 12 incidencias se quedan como están: ya pasaron.

### Registro completo
Prob./Impacto: no consta en ningún documento. Doliente y Fecha: no consta, salvo indicación. «Último movimiento»: no consta; se da el corte del informe donde se vio.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| R-199-1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | visto 2026-10-14 |
| R-200-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-15 |
| R-201-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-14 |
| R-204-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-15 |
| R-205-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-15 |
| R-207-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-13 |
| R-209-1 | Riesgo | Ídem | — | — | — | — | visto 2026-10-12 |
| R-207-2 | Riesgo (no registrado formalmente) | Proveedor podría no llegar con el equipo completo en la siguiente fase | — | — | «no identificado» | — | dicho 2026-10-16 |
| R-211-1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | visto 2026-10-12 |
| D-199-1 | Dependencia | Calendario de liberaciones del core | — | — | — | — | visto 2026-10-14 |
| D-201-1 | Dependencia | Ídem | — | — | — | — | visto 2026-10-14 |
| D-203-1 | Dependencia | Ídem | — | — | — | — | visto 2026-09-25 |
| D-206-1 | Dependencia | Ídem | — | — | — | — | visto 2026-10-15 |
| D-200-1 | Dependencia | Disponibilidad del equipo de seguridad (revisión final) | — | — | — | — | visto 2026-10-15 |
| D-202-1 | Dependencia | Ídem | — | — | — | — | visto 2026-09-27 |
| D-206-2 | Dependencia | Ídem | — | — | — | — | visto 2026-10-15 |
| D-210-1 | Dependencia | Ídem | — | — | — | — | visto 2026-10-13 |
| D-208-1 | Dependencia | Proveedor sin confirmar fecha de la última entrega | — | — | — | — | visto 2026-09-24 |
| I-201-1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | — | — | — | — | visto 2026-10-14 |
| I-201-2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | — | — | visto 2026-10-14 |
| I-201-3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | — | — | visto 2026-10-14 |
| I-202-1 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | — | — | — | desde 2026-09-27 | visto 2026-09-27 |
| I-202-2 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | — | desde 2026-09-27 | visto 2026-09-27 |
| I-204-1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | — | — | visto 2026-10-15 |
| I-205-1 | Incidencia | Ídem | — | — | — | — | visto 2026-10-15 |
| I-208-1 | Incidencia | Ídem | — | — | — | — | visto 2026-09-24 |
| I-208-2 | Incidencia | Prueba de carga no alcanzó el umbral y se repite | — | — | — | — | visto 2026-09-24 |
| I-208-3 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | — | — | visto 2026-09-24 |
| I-210-1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | — | — | visto 2026-10-13 |
| I-211-1 | Incidencia | Ídem | — | — | — | — | visto 2026-10-12 |

## Después
- **Subir a comité** (cumplen el criterio «afecta a otro proyecto»): la dependencia del core, la del equipo de seguridad y la del proveedor de PRY-208. Cada una iría con la decisión formulada: quién es el doliente y cuál es la fecha de confirmación. ¿Las preparo con `/steering-pack`?
- **Proponer doliente** (propuesta, no asignación): para lo interno de cada proyecto, su gerente según el informe (PRY-199 Andrés Lozano, PRY-200 Ricardo Salas, PRY-201 Camilo Beltrán, PRY-202 Rubén Cárdenas, PRY-203 María Restrepo, PRY-204 y PRY-206 Felipe Arango, PRY-205 y PRY-208 Carlos Peña, PRY-207 Beatriz Cuéllar, PRY-209 Jorge Medina, PRY-210 Mauricio Pérez, PRY-211 Sandra Gil). Para el core y el equipo de seguridad no hay un nombre que se desprenda de los documentos; eso lo nombra la PMO.
- **Formalizar o no** el riesgo del proveedor de PRY-207 queda para Beatriz Cuéllar.

## Lo que esta corrida no sabe
- Quién es «el core» y quién es la persona clave de cada proyecto: los documentos no lo dicen.
- Cuánto tiempo llevan abiertos la mayoría de los ítems: solo conozco la fecha del informe donde aparecen, no cuándo nacieron.
- Si hay riesgos hablados fuera de los documentos: no los veo. PRY-201, PRY-210 y PRY-211 no tienen minutas.
- Valoración de probabilidad e impacto: nadie la hizo y no la inventé.
