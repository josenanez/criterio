# Corrida del 2026-10-16 · project-charter

13 proyectos · 27 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Revisión del acta PRY-201 (2026-05-07): falta autoridad del gerente, objetivo/alcance/exclusiones/criterio de éxito vagos o con marcador, sin supuestos ni cadencia; contradicción dependencias (acta 'ninguna' vs informe). No evaluó el estado verde ni sabe lo hablado fuera de los documentos.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Acta previa: sí, existe — `documentos/proyectos/PRY-201-core-de-depósitos/00-gobierno/2026-05-07-acta-constitucion.md`, aprobada el 2026-05-07 (hace ~5 meses). Modo: revisar.

Términos: vigentes (versión 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que volver a registrarlos.

## Acta — PRY-201 Core de depósitos
**Estado:** existe, del 2026-05-07

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | **No existe.** El acta no dice hasta qué monto ni qué cambio de alcance decide Camilo Beltrán sin subir al comité. | La proyección al cierre es 4.299.777.057 COP contra 4.200.000.000 aprobados (+99.777.057, ≈2,4 %; informe 2026-10-14). Sin autoridad declarada nadie puede decir si ese exceso lo resuelve el gerente o exige al Comité de Transformación Digital; la decisión sube por defecto, o se toma sin mandato. |
| Objetivo de negocio | Presente pero es una descripción del entregable: «Entregar core de depósitos para Banca de Personas». No hay resultado de negocio ni cifra. | Sin objetivo medible no hay cómo juzgar si, con la prueba de carga fallida y el atraso, el proyecto sigue valiendo lo aprobado. |
| Alcance | Marcador: «Componente 1, 2, 3», sin descripción. | No se puede distinguir un cambio de alcance de una aclaración; cualquier solicitud de cambio se discute sin referencia. |
| Exclusiones | Marcador: «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué. | Una exclusión sin nombre no excluye nada; abre la puerta a trabajo duplicado o sin dueño entre proyectos. |
| Patrocinador / Gerente | Con nombre: Elena Duarte / Camilo Beltrán. | Sin hallazgo. |
| Supuestos y restricciones | No existen. | Los riesgos del informe (conocimiento concentrado en una persona; calendario de liberaciones del core) no tienen supuesto de origen contra el cual contrastarlos. |
| Dependencias | El acta declara «Ninguna declarada». | **Contradicción:** el informe del 2026-10-14 reporta como riesgo abierto la «dependencia del calendario de liberaciones del core», y el cronograma tiene el hito «Integración con el core» (2027-04-12). La dependencia existe y el acta la niega. |
| Criterio de éxito | Presente pero no medible: «Core de depósitos en producción y medido». No dice qué se mide, qué umbral, ni quién lo mide. | El cierre no puede declararse cumplido ni incumplido con evidencia. |
| Cadencia de reporte al comité | No existe. | No hay regla de cuándo el proyecto debe presentarse ni con qué umbrales. |
| Hitos principales | No están en el acta; sí en el cronograma v1 (4 hitos, 2026-09-04 a 2027-07-31). | Aceptable como fuente, pero el acta no los referencia. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo describe el entregable). — Fuente del texto actual: acta, «Objetivo del negocio».
**Alcance:** Componentes 1 a 3, sin detalle — pendiente de definir. (acta, «Alcance»)
**Exclusiones:** «Lo que otro proyecto cubre» — pendiente de nombrar el proyecto y el contenido. (acta, «Fuera de alcance»)
**Patrocinador:** Elena Duarte · **Gerente:** Camilo Beltrán (acta)
**Autoridad del gerente:** **pendiente de definir** — no consta en ningún documento.
**Comité al que reporta:** Comité de Transformación Digital (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. Presupuesto aprobado 4.200.000.000 COP el 2026-05-07 y fechas 2026-05-17 a 2027-07-31 (acta) son los únicos topes declarados.
**Criterio de éxito:** «Core de depósitos en producción y medido» (acta), sin métrica · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2026-05-07): Diseño funcional aprobado 2026-09-04 (con acta de recibo del 2026-10-06); Ambiente de pruebas certificado 2026-12-23; Integración con el core 2027-04-12; Piloto con usuarios internos 2027-07-31.

### Lo que esta revisión no resuelve
- No evalúo si el estado «Verde» declarado se sostiene (informe 2026-10-14: prueba de carga fallida, dos semanas perdidas, hallazgo de seguridad); eso es de status-report / health-check.
- No sé qué se acordó fuera de los documentos.

### Después
- El acta quedó sin autoridad declarada: **ofrezco llevar esa definición al Comité de Transformación Digital** (próximo comité según configuración: 2026-10-23). Es una decisión, no un trámite, y conviene tomarla junto con el exceso proyectado de 99.777.057 COP.
- De la revisión salen dos supuestos/dependencias para el registro RAID: la dependencia del calendario de liberaciones del core (declarada «ninguna» en el acta) y la ausencia de supuestos. Ofrezco pasarlos con `/raid-log`.

**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada dato cita el documento del que sale; la verificación es de quien lo usa. Fuentes leídas: acta de constitución (2026-05-07), informe de avance (2026-10-14) y la ficha PRY-201 para hitos del cronograma.
