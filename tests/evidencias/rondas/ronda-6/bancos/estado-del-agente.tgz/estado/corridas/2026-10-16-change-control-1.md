# Corrida del 2026-10-16 · change-control

13 proyectos · 42 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Evaluó mover la salida a producción de PRY-200 en 30 días (2027-02-27 a 2027-03-29). Sin solicitante, motivo, autoridad declarada ni dependencias declaradas; no calculó días del piloto ni costo mensual; no generó paquete de comité.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

Ficha de la que sale: `estado/records/PRY-200.json` (actualizada 2026-10-16). Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-16.

## Solicitud de cambio — PRY-200 Originación digital — 2026-10-16

**Qué se pide:** mover la salida a producción 30 días (2027-02-27 → 2027-03-29).
**Quién lo pide:** no consta. La solicitud no dice quién la hace. **Por qué:** no consta. Ningún documento de la carpeta da el motivo.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1 a 3 (el acta no los detalla) | Sin cambio declarado | No declarada |
| Tiempo | Salida y cierre 2027-02-27 (línea base v1) | 2027-03-29 | +30 días |
| Costo | Aprobado 6.800.000.000 COP; proyección 6.265.902.381 | No declarado | No declarada |

- **Alcance y costo quedan sin impacto declarado. Alguien los está absorbiendo.** Si la salida se mueve 30 días y el presupuesto no, el equipo o los proveedores cargan un mes adicional sin presupuesto adicional, o se recorta calidad. La solicitud tiene que decir cuál de los dos.
- El hito "Salida a producción" coincide con el cierre del acta, así que el cierre se mueve también. El hito "Piloto con usuarios internos" (2026-12-03) está en el camino del cambio, pero no se sabe si se mueve.
- **Costo, lo que sí se puede decir:** la proyección deja 534.097.619 COP de holgura sobre lo aprobado (6.800.000.000 − 6.265.902.381), pero esa proyección es del 2026-10-15 y no incluye un mes más de ejecución. No se calcula cuánto cuesta un mes: ningún documento da el costo mensual.
- **Contratos:** los entregables de CT-936 y CT-107 vencen entre 2026-03-28 y 2027-01-07, todos antes de la nueva fecha. Los textos convertidos de los contratos no traen cláusula de vigencia, así que no se puede decir si un mes más los afecta.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`) no encuentra proyectos que dependan de PRY-200: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar. | — |

**Esto no significa que no haya efecto.** El acta de PRY-200 declara «Ninguna declarada» en dependencias y la ficha no registra ninguna en RAID. Es la ausencia de declaración, no la ausencia de dependencia. El acta dice que lo que otro proyecto cubre queda fuera de alcance, y no dice qué proyecto. Hay que preguntar a Ricardo Salas si algún proyecto, o el producto «crédito de consumo», espera la salida.
Hitos por los que pasa el cambio: Piloto con usuarios internos (2026-12-03, a 48 días) y Salida a producción (2027-02-27, a 134 días). **No se calcula cuántos días se mueve el piloto:** eso necesita holgura por actividad y la ficha no la tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. **Según:** el acta de constitución de PRY-200 no declara autoridad para aprobar cambios (`identity.authority`: no encontrada). Solo dice que el Comité de Arquitectura aprobó el presupuesto el 2025-12-13.
**Va a comité:** sí, por defecto. Sin umbral escrito, un cambio de fecha de cierre del proyecto no puede decidirlo solo el gerente. El comité que consta es el Comité de Arquitectura, con Felipe Arango como patrocinador. **Esta es la conclusión de fondo:** el proyecto no tiene escrito quién aprueba un cambio.
El comité semanal del 2026-10-16 (Ricardo Salas, Felipe Arango) trató «Avance» y «Compromisos» y no registra esta solicitud ni ninguna decisión sobre ella.

### Si no se aprueba
El proyecto sigue con salida y cierre el 2027-02-27. Está en rojo declarado, con 49 % de avance reportado al 2026-10-15. El informe no dice por qué está en rojo ni qué hito está en riesgo. Los dos riesgos abiertos no tienen dueño, fecha ni valoración: concentración del conocimiento en una persona, y disponibilidad del equipo de seguridad para la revisión final. Que el proyecto esté en rojo y no tenga otra causa documentada sugiere que la fecha actual es la que está bajo presión, pero eso es una inferencia, no un dato del documento.

### Si se aprueba
**Línea base 2** — cierre 2027-03-29 · presupuesto 6.800.000.000 COP (sin cambio declarado; a confirmar) · motivo: **sin motivo documentado, hay que completarlo antes de registrar**.
Se agregaría como registro nuevo y la v1 (2025-12-13, cierre 2027-02-27) no se toca. El conteo de replanificaciones pasaría de 0 a 1.
**Desviación acumulada contra la línea base original:** tiempo +30 días (hoy 0) · costo sin variación declarada (la proyección está 534.097.619 COP por debajo del aprobado).
Reconciliación: la ficha no tiene cambios registrados (`changes` vacío) y la línea base nunca se movió, así que hoy no hay días sin autorizar. Si se mueve la línea base sin un documento que lo apruebe, quedarían 30 días sin autorización.

### Lo que este análisis no sabe
- Quién pidió el cambio ni por qué.
- Si el alcance o el costo cambian.
- Quién tiene autoridad para aprobarlo.
- Si algún proyecto o producto depende de la salida de PRY-200.
- Cuánto se mueve el piloto, y cuánto cuesta un mes más.
- Si los contratos CT-936 y CT-107 tienen vigencia que cubra hasta 2027-03-29.
- Hallazgo aparte, no revisado a fondo: el hito «Integración con el core» (2026-09-08) figura cumplido sin evidencia de recibo, y los entregables de CT-936 y CT-107 figuran pendientes sin evidencia de recibo mientras ambos contratos aparecen facturados por el monto de un entregable. Corresponde a vendor-tracking.

### Después
Esta solicitud no se puede registrar como línea base nueva: no hay aprobación. Se propone llevarla al Comité de Arquitectura con el motivo, el efecto en costo y la autoridad como puntos abiertos, y dejar que el comité declare quién aprueba cambios en este proyecto. No he generado el paquete de comité.

---
**Pie de rigor.** Borrador de trabajo, no una decisión. Cada dato sale de la ficha PRY-200 y de los documentos citados: acta de constitución (2025-12-13), cronograma v1, informe de avance (2026-10-15) y comité (2026-10-16). Los días que se mueve el piloto, el costo mensual y el efecto en otros proyectos no se calcularon porque la evidencia no los sostiene. La verificación es de quien lo lea.
