# Corrida del 2026-10-16 · project-history

13 proyectos · 56 s · 78 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `vendor_deliverable_late` | 18 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 6 |
| `declared_vs_evidence` | 4 |
| `vendor_invoiced_without_delivery` | 3 |
| `rebaseline_unauthorized` | 3 |
| `variance_time` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |

Historia de PRY-206 sobre 9 documentos (2025-11-02 a 2026-10-15): 1 replanificación sin aprobación (+70 días, 12,9 %), silencio documental en 2026-T1 y T2, factura sin acta de recibo. Dijo que no sabe: meses declarando sin sustento (solo hay un estado declarado), cuándo se editó el estado del cronograma v1, y si los +70 días de CC-01 son los mismos de la v2.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Historia · PRY-206 Billetera y QR · 2025-11 a 2026-10

**Leí:** 9 documentos entre 2025-11-02 y 2026-10-15
**Trimestres sin un solo documento:** 2026-T1 (ene–mar) y 2026-T2 (abr–jun)

*Términos: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.*

### En una línea
El proyecto arrancó con acta (2025-11-02) y contrato con Integra Sistemas (2025-11-04) y después no deja un solo documento durante seis meses (enero–junio de 2026), justo cuando vencían dos hitos que hoy figuran como cerrados y el primer entregable del proveedor. Los documentos reaparecen el 2026-09-05 con una factura, y entre el 2026-10-12 y el 2026-10-15 se concentra todo lo demás: una solicitud de cambio de alcance (+70 días, +140.000.000 COP) todavía sin autorizar, un cronograma v2 que ya mueve el cierre de 2027-05-10 a 2027-07-19, y un informe que declara Rojo con 77 % de avance.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 70 días (12,9 %) | No calculable: solo hay un estado declarado (2026-10-15) | 0 vistos |

El atraso de 12,9 % supera el umbral de 10 % configurado. "Meses declarando sin sustento" necesita una serie de estados declarados en el tiempo; en la carpeta hay uno solo, así que no se escribe una cifra.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-11-02 | `00-gobierno/2025-11-02-acta-constitucion.md` | Nace el proyecto: 800.000.000 COP, inicio 2025-11-12, cierre 2027-05-10. Patrocinador Elena Duarte, gerente Felipe Arango, Comité de Arquitectura. |
| 2025-11-02 | `10-plan/2025-11-02-cronograma-v1.csv` | Línea base de 5 hitos. Ojo: el archivo lleva fecha de 2025-11 pero marca como "cerrado" tres hitos que vencen en 2026; su columna de estado se editó después de la fecha del nombre, y no hay forma de saber cuándo. |
| 2025-11-04 | `00-gobierno/2025-11-04-contrato-ct-541.docx` | Contrato con Integra Sistemas: 4 entregables de 82.731.823 COP cada uno, todos "pendiente". Se factura contra acta de recibo firmada por el gerente. |
| 2026-01 a 2026-06 | *(ningún documento)* | Vencen "Diseño funcional aprobado" (2026-02-28), "Licenciamiento del motor" (2026-03-11), "Ambiente de pruebas certificado" (2026-06-17). |
| 2026-09-05 | `20-seguimiento/2026-09-05-factura-ct-541.md` | Factura FV-1541 por 82.731.823 COP, "Entregables del contrato CT-541", radicada en cuentas por pagar. |
| 2026-10-03 | `30-reuniones/2026-10-03-comite-semanal.md` | Comité con Felipe Arango y Elena Duarte. Un compromiso: Ricardo Salas, "Entregar el punto 19", para 2026-11-05. |
| 2026-10-12 | `20-seguimiento/2026-10-12-acta-recibo-integración-con-el-core.pdf` | Felipe Arango recibe a satisfacción "Integración con el core" (hito previsto el 2026-10-04). |
| 2026-10-12 | `20-seguimiento/2026-10-12-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +70 días y +140.000.000 COP. Autorización: "Pendiente de presentación al comité". |
| 2026-10-15 | `10-plan/2026-10-15-cronograma-v2.csv` | "Salida a producción" pasa de 2027-05-10 a 2027-07-19; la línea base se conserva. |
| 2026-10-15 | `20-seguimiento/2026-10-15-informe-avance.pdf` | Estado declarado Rojo, avance 77 %, proyección 829.681.423 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-15 (fecha del archivo v2) | 2027-07-19 | El cronograma v2 no lo dice. El único texto que coincide es CC-01 (ampliación de alcance, +70 días), que no cita la v2 ni la v2 cita a CC-01. | Ninguno. CC-01 está "pendiente de presentación al comité" y el acta del comité del 2026-10-03 es anterior a la solicitud. |

Atraso acumulado contra la línea base original: 70 días (12,9 %). Contra la vigente: 0, porque la vigente ya incluye el movimiento. Queda abierto si los +70 días de CC-01 ("sobre la línea base vigente") son esos mismos 70 días o se sumarían a ellos; lo que dice el cronograma v2 es un solo movimiento de 70 días.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos. | Acta (2025-11-02) y comité (2026-10-03) nombran a las mismas personas y al mismo comité. |

Dos notas que no son cambios pero conviene saberlas: el acta no declara dependencias ("Ninguna declarada") y el informe del 2026-10-15 lista como riesgo la dependencia del calendario de liberaciones del core; y el alcance del acta es "Componente 1, 2, 3", sin contenido sobre el que medir una "ampliación de alcance".

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ricardo Salas | Entregar el punto 19 | 1 | 2026-11-05 |

Ninguno se repitió ni está vencido. Es el único compromiso en los documentos; solo existe un acta de comité, así que no hay historia de reprogramaciones que revisar. Ricardo Salas no figura entre los asistentes de esa reunión.

### Desde cuándo lo declarado no se sostiene
- **Fecha:** 2026-02-28. Es el vencimiento de "Diseño funcional aprobado", marcado "cerrado" sin ningún documento en la carpeta que lo respalde (no hay acta, aprobación ni entregable). Le sigue "Ambiente de pruebas certificado" (2026-06-17), también "cerrado" y sin respaldo. Ambos caen en los dos trimestres sin documentos.
- **Primer hito sin evidencia:** Diseño funcional aprobado.
- **Qué se siguió reportando después:** en el informe del 2026-10-15, avance de 77 %. Con 3 de 5 hitos cerrados el plan sostiene entre 60 y 80 %, así que la cifra cae dentro del rango; pero uno de esos 3 hitos tiene evidencia (Integración con el core, acta del 2026-10-12) y dos no. El informe sí declara Rojo, pero no menciona la replanificación, CC-01, la factura ni los entregables vencidos del proveedor (cinco señales que el script marca sin explicar en el informe).
- **Proveedor:** ningún entregable de CT-541 tiene acta de recibo en la carpeta. "Licenciamiento del motor" (vencido desde 2026-03-11) y "Bolsa de horas de desarrollo" (desde 2026-07-09) siguen "pendiente". La factura FV-1541 (82.731.823 COP, 2026-09-05) existe sin acta de recibo del contrato que la respalde; el único acta es de un hito del plan, de fecha posterior (2026-10-12).
- **Presupuesto:** ejecutado 406.994.391 COP frente a comprometido 296.937.416 COP, es decir, lo ejecutado supera lo comprometido, y no hay en la carpeta documento que explique la diferencia. La proyección de 829.681.423 COP (3,7 % sobre lo aprobado) no dice si incluye los 140.000.000 COP de CC-01.

No es un salto: no hay un documento donde el proyecto "se rompa". Es un silencio de seis meses que luego se llena de una sola vez en octubre.

### Lecciones ancladas a un hecho
1. **Un hito cerrado necesita su acta en la carpeta.** Hecho: "Diseño funcional aprobado" y "Ambiente de pruebas certificado" aparecen "cerrado" (cronogramas v1 y v2) sin documento de respaldo. Efecto: 2 de los 3 hitos que sustentan el 77 % no se pueden verificar.
2. **Factura sin acta de recibo.** Hecho: FV-1541 (2026-09-05) se radicó contra un contrato cuya condición de pago es acta firmada, y ningún entregable tiene acta. Efecto: 82.731.823 COP facturados sin entrega aceptada que se vea.
3. **La replanificación precedió a la autorización.** Hecho: cronograma v2 (2026-10-15) mueve el cierre 70 días tres días después de CC-01 (2026-10-12), que sigue pendiente de comité. Efecto: la fecha vigente ya cambió sin decisión documentada.

---
**Pie de rigor.** Leí 9 documentos (todos en la versión de texto extraída; las citas apuntan a los originales). No sé qué se habló fuera de ellos; no sé cuándo se editó el estado del cronograma v1, ni si hay actas, aprobaciones o correos que no estén en la carpeta. Las cifras (1 replanificación, 70 días, 12,9 %, 0 cambios de gobierno, importes y porcentajes) salen del cálculo del script del 2026-10-16; el resto es lectura de los documentos. Que no haya evidencia en la carpeta no prueba que no exista, y esto no atribuye intención a nadie: sirve para abrir la conversación con fechas. La verificación es suya.

Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-23, donde hay una decisión pendiente: CC-01.
