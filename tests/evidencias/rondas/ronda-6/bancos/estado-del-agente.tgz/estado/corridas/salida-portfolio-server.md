# Rostrum — para mirarlo un rato

**Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16, comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.12-2026-10-16.md` y `.pdf`). No hubo que registrarlos de nuevo.

**Forma elegida:** «para mirarlo un rato» (la que se pidió como argumento). Se levanta, se mira y se apaga con Ctrl-C. No hay que pedirle nada a seguridad. A cambio, el patrocinador no tiene un enlace que funcione mañana.

**Informe:** existe en `reportes/` (13 proyectos PRY-199 a PRY-211, 9 productos, decisiones, listados). El servidor no lo genera, lo sirve.

**Comando:**

    python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json

Escucha en `127.0.0.1:8787`, solo en este equipo.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado, por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Qué no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos. Las peticiones del formulario esperan hasta que el agente despierte: `due` las cuenta y rompen el silencio de `/portfolio-wake`.

**Cierre:** este enlace (`http://127.0.0.1:8787/`) solo sirve en este equipo, para quien esté sentado aquí. Para un patrocinador remoto hace falta la otra forma (`--abierto`, detrás del control de acceso de la organización). El informe es del 2026-10-16 y quedará desactualizado en cuanto cambie algún documento o se corra un nuevo barrido; la portada muestra su fecha.
