Publiqué la ficha en `/home/claude/banco/ronda-6/bancos/espacio/documentos/proyectos/PRY-207-onboarding-pyme/00-gobierno/ficha-pm.json`, con corte al 2026-10-16.

**Lleva:** 15 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`; además no hay proveedores) · declara **verde** al 2026-10-13

**Lo más viejo que va ahí:** los campos de identidad, alcance y fecha de inicio, del acta de constitución del 2026-01-20 (unos 9 meses; no pasa de un año).

**Antes de publicar:**
- Recalculé la ficha el 2026-10-16.
- `plan.end_date` es 2027-06-07, tomada del cronograma v2 (2026-10-13), que es el vigente. La del acta, 2027-03-22, va en `plan.baseline`. El cambio CC-01 (+77 días) explica la diferencia.
- Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

**Lo que la PMO va a ver primero:** el estado declarado es verde, y el cálculo lo contradice con 5 señales: compromisos vencidos, compromisos reprogramados, hitos dados por cumplidos sin evidencia, avance declarado 30 % frente a 50–75 % que sustenta el plan, y 77 días de atraso contra la línea base original.

**Qué no hice:** no toqué ningún otro archivo de la documentación y no avisé a nadie. Vera la encontrará en su próximo barrido.
