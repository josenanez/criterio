# Onboarding PyME (PRY-207) — semana del 2026-10-09 al 2026-10-16

**Declara el gerente esta semana:** *(sin declarar)* · *(sin avance)* · al 2026-10-16
La sesión corrió sin interfaz y nadie respondió la pregunta de la declaración. Samuel no la propone: la línea queda en blanco.
**Última declaración que consta en documentos:** verde · 30 % · al 2026-10-13, hace 3 días (`20-seguimiento/2026-10-13-informe-avance.md`). Es lo que dice el informe de avance; no es una declaración de esta semana.
**Sustento documental:** contradicho. Hay un verde en el informe, y la evidencia contiene cinco señales que ese verde no explica.
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, avance declarado por debajo del plan, atraso contra la línea base original.

> Pregunta de declaración (sin respuesta en esta corrida): con las señales de arriba a la vista, ¿qué estado declara Beatriz Cuéllar para esta semana y con qué avance?

## Qué cambió esta semana
No hay corrida anterior con la que comparar: este es el primer snapshot (2026-10-16) y el diff salió con 0 cambios. Samuel no puede decir qué cambió desde la semana pasada, y no lo inventa. A partir de la próxima corrida esta sección se llena.

Lo que sí consta fechado esta semana:
| Qué | Fecha | Fuente |
|---|---|---|
| Informe de avance con declaración verde 30 % | 2026-10-13 | `20-seguimiento/2026-10-13-informe-avance.md` |
| Cronograma v2 (cierre 2027-06-07) | 2026-10-13 | `10-plan/2026-10-13-cronograma-v2.xlsx` |
| Cambio CC-01 aprobado (+77 días, +154.000.000 COP) | solicitado 2026-10-06 | `20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md` |
| Rubén Cárdenas movió «Enviar el documento 1» por sexta vez, a 2026-12-12 | 2026-10-16 | `2026-10-16-notas-reunion.txt` |
| Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo | 2026-10-16 | `2026-10-16-notas-reunion.txt` |
| Compromiso nuevo sin fecha: Laura Vélez, ajuste del presupuesto («la otra semana») | 2026-10-16 | `2026-10-16-notas-reunion.txt` |
| Compromiso nuevo: Óscar Ramírez, revisión con el proveedor, 2026-10-26 | 2026-10-16 | `2026-10-16-notas-reunion.txt` |

## Lo que sigue igual y sigue mal
Sin corrida anterior, «desde» es la fecha de vencimiento y «días así» se cuenta a 2026-10-16.
| Qué | Desde | Días así |
|---|---|---|
| Javier Hoyos — Revisar el anexo 11 | 2026-09-21 | 25 |
| Sandra Gil — Actualizar la matriz 6 (dice que ya entregó; sin acta) | 2026-10-03 | 13 |
| Sandra Gil — Revisar el anexo 3 (dice que ya entregó; sin acta) | 2026-10-09 | 7 |
| Óscar Ramírez — Revisar el anexo 19 | 2026-10-10 | 6 |
| Rubén Cárdenas — Entregar el punto 16 | 2026-10-11 | 5 |
| Liliana Torres — Aprobar el diseño 5 | 2026-10-13 | 3 |
| Jorge Medina — Validar el ambiente 4 (dice que ya entregó; sin acta) | 2026-10-14 | 2 |
| Paula Céspedes — Entregar el punto 24 | 2026-10-15 | 1 |
| Hito «Diseño funcional aprobado» marcado cumplido, sin evidencia | 2026-05-14 | 155 |
| Hito «Ambiente de pruebas certificado» marcado cumplido, sin evidencia | 2026-08-26 | 51 |
| Atraso de +77 días contra la línea base original (18,5 %, umbral 10 %) | 2026-10-06 | 10 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-03-22 | 2027-06-07 | +77 días contra la original (18,5 %); 0 contra la vigente |
| Presupuesto | sin dato | 2.400.000.000 COP | sin dato: los documentos no separan el aprobado original del vigente, ni dicen si los 154.000.000 de CC-01 están dentro de los 2.400 M |

Replanificaciones: 1 — 2026-10-06, CC-01, ampliación de alcance (+77 días). El documento dice que la autorizó «el comité» sin nombrar cuál ni quién. Mirar solo la desviación contra la vigente daría 0 días; contra la original son 77.
Avance: declarado 30 %; el plan sostiene entre 50 % y 75 % (2 de 4 hitos cumplidos). Brecha: 20 puntos por debajo. Esos 2 hitos cumplidos no tienen evidencia.

### Hitos de las próximas cuatro semanas (hasta 2026-11-13)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno cae en la ventana | | | |

El siguiente es «Integración con el core»: base 2026-12-08, vigente 2026-12-08, pendiente. «Piloto con usuarios internos»: base 2027-03-22, vigente 2027-06-07.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.145.951.271 (47,7 %) | 922.631.378 (38,4 %) | 2.365.074.370 (−1,5 % vs. aprobado) | 1.254.048.729 |

El disponible real es aprobado menos comprometido. Aprobado menos ejecutado daría 1.477.368.622, que sobrestima en 223.319.893. Fuente: informe de avance del 2026-10-13.

## Abierto
**Reprogramados:**
- Rubén Cárdenas — Enviar el documento 1: 6 veces. Original 2026-09-25, hoy 2026-12-12 (78 días de corrimiento). Supera el umbral de 3.
- Elena Duarte — Cerrar la prueba 2: 5 veces. Original 2026-09-19, hoy 2026-11-17 (59 días). Supera el umbral de 3.
- Con 1 o 2 reprogramaciones: María Restrepo (diseño 13, a 2026-10-23), Sandra Gil (anexo 3; prueba 18, a 2026-11-02), Jorge Medina (ambiente 4), Liliana Torres (diseño 5; ambiente 12, cumplido), Rubén Cárdenas (fecha 7, a 2026-10-16), Mauricio Pérez (fecha 15, a 2026-11-10).

**Vencidos sin evidencia:** los 8 de la tabla anterior. En 3 casos la persona dice que ya entregó y no hay acta de recibo (Sandra Gil ×2, Jorge Medina). Gustavo Neira (documento 9) y María Restrepo (prueba 10) también dicen que entregaron, sin fecha y sin acta.

**Sin fecha (6):** Gustavo Neira (documento 9; diseño 21), María Restrepo (prueba 10), Elena Duarte (matriz 14), Carlos Peña (fecha 23), Laura Vélez (ajuste del presupuesto). Un compromiso sin fecha no puede vencer, así que no aparece como vencido.

**RAID sin movimiento:**
- «Concentración del conocimiento en una sola persona»: sin dueño, probabilidad, impacto ni fecha. Sin movimiento registrado (`last_moved` vacío).
- «El proveedor podría no llegar con el equipo completo»: nuevo, dicho en reunión y sin registrar; dueño no identificado.

**Proveedor:** no hay proveedor en la ficha. Sin embargo las notas del 2026-10-16 hablan de un proveedor y de una «revisión con el proveedor» (Óscar Ramírez, 2026-10-26). Falta el contrato.

## Lo que necesito de alguien
- **Beatriz Cuéllar:** la declaración de esta semana. Sin ella este informe sale incompleto, a propósito.
- **Beatriz Cuéllar:** evidencia de recibo de «Diseño funcional aprobado» y «Ambiente de pruebas certificado», o cambiar su estado a no cumplido.
- **Sandra Gil, Jorge Medina, Gustavo Neira, María Restrepo:** el acta o el documento que respalda «ya entregué».
- **Rubén Cárdenas y Elena Duarte:** o una fecha que se pueda sostener, o decir que el compromiso no es suyo. Esto pasa de tres reprogramaciones y es material de comité (próximo: 2026-10-30), no de este informe.
- **Laura Vélez, Gustavo Neira, María Restrepo, Elena Duarte, Carlos Peña:** una fecha para cada compromiso sin fecha.
- **Sin nombre en los documentos (excede al gerente):** quién autorizó CC-01 y en qué comité. Quién es la autoridad del proyecto.
- **Dueño** para los dos riesgos del RAID.

## Lo que no se sabe
**Sin dato:** autoridad del proyecto (`identity.authority`) · fase (`identity.phase`) · proveedores y su contrato · presupuesto original separado del vigente · fecha de aprobación del comité de CC-01 · evidencia de los dos hitos marcados cumplidos.
**Silencio:** el cálculo no entrega días de silencio (la actividad de la ficha está vacía). Por las fechas de los documentos: último documento (notas de reunión) 2026-10-16, hace 0 días; última minuta de comité 2026-10-09, hace 7 días, en el umbral de 7. De los 15 documentos leídos, ninguno está marcado como evidencia ni como declaración.

---
Ficha: `estado/PRY-207-onboarding-pyme/records/PRY-207.json`, al 2026-10-16 · lectura de 6 minutas (2026-09-04 a 2026-10-09), notas del 2026-10-16 y 2 actas de recibo; no sellada · 3 campos sin dato en la ficha (autoridad, fase, proveedores).
Términos de uso y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12
