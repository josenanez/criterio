## Compromisos — Onboarding PyME (PRY-207) · al 2026-10-16

26 compromisos registrados: 22 abiertos (8 vencidos, 6 sin fecha, 2 reprogramados por encima del umbral) y 2 cerrados con documento. Las cifras salen de `portafolio.py compute`.

### Se viene reprogramando

> **Rubén Cárdenas** · Enviar el documento 1
> Prometido para el 2026-12-12, y antes para el 11-28, el 11-15, el 11-06, el 10-20 y el 10-03. La promesa original era del 2026-09-25. **Seis reprogramaciones en siete semanas, cada una dicha en una reunión distinta.** Fuentes: minutas del 09-11, 09-18, 09-25, 10-02, 10-09 y notas del 10-16.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Las notas del 10-16 dicen «no alcanzó», sin decir qué no alcanzó. El umbral de alerta es 3.

> **Elena Duarte** · Cerrar la prueba 2
> Prometido para el 2026-11-17, y antes para el 11-04, el 10-27, el 10-18 y el 10-09. La promesa original era del 2026-09-19. **Cinco reprogramaciones.** Todavía no está vencido, pero cada reunión lo ha movido unos días. No hay motivo escrito en ninguna minuta.

Por debajo del umbral, pero a vigilar: María Restrepo, *Aprobar el diseño 13*, original 2026-09-30, reprogramado 2 veces, vigente 2026-10-23.

### Vencidos sin evidencia

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 | 25 días |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 | 13 días |
| Sandra Gil | Revisar el anexo 3 | 2026-10-09 (original 09-19) | 7 días |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-10 | 6 días |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 | 5 días |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 (original 10-05) | 3 días |
| Jorge Medina | Validar el ambiente 4 | 2026-10-14 (original 09-15) | 2 días |
| Paula Céspedes | Entregar el punto 24 | 2026-10-15 | 1 día |

Tres de estos tienen un «ya entregó» dicho en reunión y ningún documento detrás:
- Sandra Gil, anexo 3 (dicho el 09-25) y matriz 6 (dicho el 10-02).
- Jorge Medina, ambiente 4 (dicho el 10-09).

Sin acta de recibo ni entregable en el expediente siguen abiertos. Que lo hayan dicho no los cierra.

### Vencen esta semana

| Quién | Qué | Para cuándo |
|---|---|---|
| Rubén Cárdenas | Confirmar la fecha 7 (reprogramado 1 vez; original 09-14) | 2026-10-16 (hoy) |
| Diana Molina | Enviar el documento 17 | 2026-10-21 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-22 |
| María Restrepo | Aprobar el diseño 13 (reprogramado 2 veces) | 2026-10-23 |

Las notas del 10-16 no dicen si se habló de la fecha 7, que vence hoy, ni de ninguno de los 8 vencidos.

### Sin fecha

| Quién | Qué | Dicho el |
|---|---|---|
| Gustavo Neira | Enviar el documento 9 | 2026-09-18 |
| María Restrepo | Cerrar la prueba 10 | 2026-09-18 |
| Elena Duarte | Actualizar la matriz 14 | 2026-09-25 |
| Gustavo Neira | Aprobar el diseño 21 | 2026-10-09 |
| Carlos Peña | Confirmar la fecha 23 | 2026-10-09 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-16 |

Son 6 compromisos que no pueden estar vencidos y por eso no aparecen en ningún conteo de atraso.
- Gustavo Neira (documento 9, 10-02) y María Restrepo (prueba 10, 09-25) dijeron «ya entregó», sin documento que lo respalde.
- «La otra semana» de Laura Vélez puede ser la del 19 o la del 26 de octubre; no lo convertí en fecha.
- Gustavo Neira, Carlos Peña y Jorge Medina no figuran entre los asistentes del 10-16.

### Cerrados desde la última revisión

| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Jorge Medina | Entregar el punto 8 | `20-seguimiento/2026-09-18-acta-recibo-8.md` |
| Liliana Torres | Validar el ambiente 12 | `20-seguimiento/2026-10-09-acta-recibo-12.md` |

### Contexto
- Sin evidencia de recibo en el expediente: 5 compromisos con un «ya entregó» sin documento (los 3 vencidos de arriba más Gustavo Neira y María Restrepo). Solo cuentan como cerrados los dos de la tabla anterior.
- El informe de avance del 2026-10-13 declara «verde». Compromisos vencidos y reprogramados son dos de las cinco señales que ese informe no explica.
- Nuevo compromiso del 10-16 por confirmar con su doliente: Óscar Ramírez, *Revisión con el proveedor*, 2026-10-26 (abierto; la frase no dice si es una reunión o un entregable).

### Siguiente paso
Rubén Cárdenas (6 veces) y Elena Duarte (5 veces) superan el umbral de 3. **Puedo formularlos como decisión para el comité:** qué se pide, qué pasa si no se decide y quién tiene la facultad. El comité tiene su próxima reunión el 2026-10-30. Esto excede la autoridad del gerente y por eso sube.

`/pm-publish` no hace falta: esta corrida no cambió ningún campo de la ficha.
