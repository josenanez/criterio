## Reunión de seguimiento — Onboarding PyME (PRY-207) · 2026-10-30
5 puntos · 33 minutos · 14 personas requeridas

Fecha tomada de `committee_next` de la configuración (la nota del 2026-10-16 dice «en dos semanas»). No se pidió duración; los 33 minutos caben en cualquier reunión de 40 o más. Es la primera corrida: no hay foto anterior, así que no se puede decir qué cambió «desde la reunión anterior», solo qué está abierto contra las seis minutas (2026-09-04 a 2026-10-09) y las notas del 2026-10-16.

### Lo que no se destraba solo

> **[1] Que Rubén Cárdenas deje fecha firme, o que se reasigne, el «documento 1»** · 10 min · **Rubén Cárdenas** (y Beatriz Cuéllar, que puede reasignar)
> Prometido para el 12/12, y antes para el 28/11, y antes para el 15/11, y antes para el 06/11, y antes para el 20/10, y antes para el 03/10, y antes para el 25/09. Seis reprogramaciones.
> Rubén tiene además «Entregar el punto 16» vencido desde el 2026-10-11 y «Confirmar la fecha 7» con fecha el 2026-10-16 (hoy, sin mención en las notas): tres compromisos en la misma persona. Al terminar tiene que quedar dicho qué lo detiene, si se parte el documento en entregas parciales con fecha, o si lo toma otra persona. No sé si el documento 1 alimenta el hito «Integración con el core» (2026-12-08); si lo alimenta, el 12/12 ya llega tarde, y esa es la pregunta que hay que hacer en la sala.
> Fuente: minutas 2026-09-04, 09-11, 09-18, 09-25, 10-02, 10-09 y notas 2026-10-16.
> **Si no se resuelve hoy:** la séptima fecha se sumará a las seis anteriores y el compromiso seguirá sin evidencia.

> **[2] Que Elena Duarte cierre la «prueba 2» o diga qué falta** · 5 min · **Elena Duarte**
> Prometido para el 17/11, y antes para el 04/11, y antes para el 27/10, y antes para el 18/10, y antes para el 09/10, y antes para el 19/09. Cinco reprogramaciones. Además tiene «Actualizar la matriz 14» sin fecha desde el 2026-09-25.
> Fuente: minutas 2026-09-04, 09-11, 09-18, 09-25, 10-02, 10-09. Las notas del 2026-10-16 no la mencionan.
> **Si no se resuelve hoy:** igual que el punto 1.

### Vencido sin evidencia
Más viejo primero. «Ya entregó» sin acta de recibo aparece marcado: lo que se pide hoy es el acta, o decir que no se entregó.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 (sin reprogramar) | Entrega o fecha nueva | 1 |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 | Dijo el 10-02 que ya entregó, sin acta: presentar el acta | 1 |
| Sandra Gil | Revisar el anexo 3 | 2026-10-09 (antes 09-19) | Dijo el 09-25 que ya entregó, sin acta: presentar el acta | 1 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-10 | Entrega o fecha nueva | 1 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 (antes 10-05) | Aprobación o fecha nueva | 1 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-14 (antes 09-15) | Dijo el 10-09 que ya entregó, sin acta. No estuvo el 2026-10-16: confirmar que asiste | 1 |
| Paula Céspedes | Entregar el punto 24 | 2026-10-15 | Entrega o fecha nueva | 1 |

Rubén Cárdenas, «Entregar el punto 16» (2026-10-11), va en el punto 1. Ocho vencidos en total.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Ponerle fecha a los seis compromisos sin fecha: Laura Vélez, ajuste del presupuesto («la otra semana»); Gustavo Neira, documentos 9 («ya entregó», sin acta) y 21; María Restrepo, prueba 10 («ya entregó», sin acta); Elena Duarte, matriz 14; Carlos Peña, fecha 23 | Cada doliente, con Beatriz Cuéllar. Gustavo Neira y Carlos Peña no estuvieron el 2026-10-16: confirmar que asisten | No hay contra qué verificarlos y nunca van a vencer | 4 |
| Registrar el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase»: dueño, probabilidad, impacto, fecha de revisión | Beatriz Cuéllar, con Óscar Ramírez (lleva la revisión con el proveedor) y Sandra Gil como patrocinadora | Sigue dicho de pasada y sin dueño; el 10-16 «nadie lo anotó como riesgo» | 3 |

### Vence antes de la próxima

| Quién | Qué | Para cuándo |
|---|---|---|
| Laura Vélez | Ajuste del presupuesto | «La otra semana» (semana del 2026-10-19), sin fecha; se cierra en el punto de decisión |
| Diana Molina | Enviar el documento 17 | 2026-10-21 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-22 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-23 (ya reprogramado: 09-30, 10-09, 10-23) |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 (es el momento natural para el riesgo del proveedor) |

Tiempo para este bloque: 3 min.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| El estado «verde», 30 %, declarado en el informe del 2026-10-13 | Cinco señales lo contradicen (ocho vencidos, dos reprogramados 5-6 veces, desviación de tiempo, avance contra el plan, hitos sin evidencia). El estado lo declara la gerente; no se discute con la sala | `/pm-report` |
| Hitos «Diseño funcional aprobado» (2026-05-14) y «Ambiente de pruebas certificado» (2026-08-26), marcados cumplidos en el cronograma v2 sin acta de recibo en la carpeta | Es pedir un documento, no discutirlo | `/pm-commitments` para formular el pedido al dueño del hito |
| CC-01 (+77 días, 154.000.000 COP): el documento dice «autorizada por el comité» sin nombrar cuál ni quién | Un vacío del documento; el comité de la configuración es el Comité de Riesgos, pero no puedo afirmar que fue ese | Pedirle a Sandra Gil la referencia; si excede a la gerente, `/pm-escalate` |
| Riesgo «concentración del conocimiento en una sola persona» (informe 2026-10-13), sin dueño, probabilidad ni impacto | No hay doliente en la sala identificado | Registro RAID, a cargo de Beatriz Cuéllar |

### Anexo — sin cambios desde el [no hay fecha de referencia: primera corrida]
- Mauricio Pérez, Confirmar la fecha 15: 2026-11-10 (reprogramado una vez).
- Sandra Gil, Cerrar la prueba 18: 2026-11-02 (reprogramado una vez).
- Sandra Gil, Actualizar la matriz 22: 2026-11-01.
- Cumplidos con acta: Jorge Medina, Entregar el punto 8 (acta 2026-09-18); Liliana Torres, Validar el ambiente 12 (acta 2026-10-09).

Después de la reunión: `/pm-minutes` sobre la transcripción o las notas.
