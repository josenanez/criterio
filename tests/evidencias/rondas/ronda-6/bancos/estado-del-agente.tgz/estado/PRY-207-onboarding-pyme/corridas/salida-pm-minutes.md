# Acta — Onboarding PyME (PRY-207) · 2026-10-16

**Asistieron:** Beatriz Cuéllar, Diana Molina, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez (12) · **Fuente:** `documentos/proyectos/PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt` (notas de 9 líneas, no es transcripción)
**No aparecen en la lista, pero tienen compromisos abiertos:** Carlos Peña, Gustavo Neira, Jorge Medina. Las notas no traen agenda, así que no puedo decir si tenían tema hoy. Laura Vélez asiste por primera vez en las minutas leídas.

## Compromisos

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-12-12 | **Reprogramado por 6.ª vez.** Promesa original 2026-09-25 → 10-03 → 10-20 → 11-06 → 11-15 → 11-28 → 12-12. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 12/12/2026» (línea 4). Es la misma promesa, no una nueva. El umbral de alerta es 3. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo. Cita: «revisión con el proveedor, queda para el 2026-10-26» (línea 6). Ver «Sin resolver»: la frase no dice si es una reunión o un entregable. |

### Sin fecha

| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana» (línea 5). `due_date: no_declarada`. «La otra semana» no es una fecha y no la convertí en una. |

Con este compromiso el proyecto tiene **6 compromisos sin fecha**: Gustavo Neira (documento 9 y diseño 21), María Restrepo (prueba 10), Elena Duarte (matriz 14), Carlos Peña (fecha 23) y Laura Vélez (presupuesto).

## Decisiones

Las notas no registran ninguna decisión.

## Quedó sin decidir

Las notas no dicen que algo se haya discutido y quedado abierto. No lo invento.

## Intenciones sin doliente

Ninguna.

## Dicho al pasar y no registrado

| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | Sin atribuir: las notas dicen «se comentó» | Riesgo (incertidumbre futura sobre la capacidad del proveedor) | **No.** El único riesgo previo es «Concentración del conocimiento en una sola persona». Queda con `owner: no_identificado`, sin probabilidad ni impacto, porque la reunión no los dio. |

Dos huecos del expediente que este riesgo toca. La ficha no tiene proveedores cargados (`vendors: []`) y no encontré un contrato en la carpeta. La fase («siguiente fase») tampoco está definida en el expediente (`identity.phase` no encontrado). No sé a qué proveedor ni a qué fase se refiere.

## Cerrado en esta reunión

Nada. Las notas no traen ningún documento de recibo.

## Lo que esta reunión contradice

| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-30) | `cycle.committee: weekly`; `committee_next: 2026-10-30` | Notas 2026-10-16 · configuración del proyecto. La fecha coincide con `committee_next`. Lo que choca es la frecuencia: las 6 minutas anteriores son semanales. Si el comité pasó a quincenal, la configuración está vieja. Si no, la frase se refiere solo a la próxima. |

Patrocinador, gerente, comité, fechas de cierre y presupuesto: la reunión no los toca. Ningún campo de la ficha cambia por esta acta.

## Sin resolver de la transcripción

- «lo de "enviar el documento 1" no alcanzó» (línea 4): no dice qué no alcanzó (tiempo, insumos, capacidad). El motivo de la 6.ª reprogramación no quedó escrito.
- «la otra semana» (línea 5): puede ser la semana del 19 o la del 26 de octubre.
- «queda para el 2026-10-26» (línea 6): no dice si Óscar Ramírez se compromete a hacer la revisión o a que ocurra. Lo registré como compromiso suyo con esa fecha, y conviene confirmarlo con él.
- «se comentó» (línea 7): no se sabe quién advirtió el riesgo del proveedor, ni qué dijo exactamente.
- Las notas no mencionan los compromisos que vencen o vencieron: Rubén Cárdenas «Confirmar la fecha 7» (vence hoy, 2026-10-16) ni los 8 vencidos sin reprogramar. No sé si se habló de ellos.

## Cifras recalculadas (portafolio.py compute, al 2026-10-16)

- 8 compromisos vencidos: Sandra Gil (anexo 3, 7 días; matriz 6, 13 días), Jorge Medina (ambiente 4, 2 días), Liliana Torres (diseño 5, 3 días), Javier Hoyos (anexo 11, 25 días), Rubén Cárdenas (punto 16, 5 días), Óscar Ramírez (anexo 19, 6 días), Paula Céspedes (punto 24, 1 día). Los vencidos no cambian con esta reunión.
- 2 compromisos reprogramados por encima del umbral: Rubén Cárdenas (6 veces) y Elena Duarte (5 veces, prueba 2).
- Estado declarado «verde» (informe 2026-10-13) con 5 señales que no explica: compromisos vencidos, reprogramados, hitos «cumplidos» sin evidencia, avance 30 % declarado frente a 50-75 % que sostiene el plan, y +77 días sobre la línea base original.

**Nota de proceso.** El estado ya traía estas tres promesas y el riesgo, cargados en el setup desde este mismo archivo. No dupliqué nada y no modifiqué el estado.

**Siguiente paso:** `/pm-commitments` para el seguimiento completo. No hace falta `/pm-publish`, porque ningún campo de la ficha cambió.
