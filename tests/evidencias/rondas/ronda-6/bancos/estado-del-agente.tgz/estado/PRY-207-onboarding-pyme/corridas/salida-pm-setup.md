Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.
1. Quién eres y qué proyecto es: Beatriz Cuéllar, gerente de PRY-207 Onboarding PyME (acta de constitución del 2026-01-20).
2. Reunión de seguimiento: los viernes (todas las minutas caen en viernes). Las notas de hoy dicen «próxima reunión en dos semanas», así que anoto el 2026-10-30.
3. Dónde guardo lo que encuentro: `estado/PRY-207-onboarding-pyme`.
4. Términos: versión 1.1 mostrada tal cual; registrada la aceptación de José Francisco Ñáñez (fecha de la prueba, 2026-10-16).

## Listo — Onboarding PyME (PRY-207)

**Lo que miré:** 14 documentos · 7 de reunión (6 minutas del comité semanal y las notas del 2026-10-16) · la última del 2026-10-16. Leí las seis minutas de la más vieja a la más nueva, las notas de hoy y las dos actas de recibo. Formatos: 11 .md, 1 .txt, 2 .xlsx; todos legibles. Fichas sin sellar: leí reuniones, no el proyecto entero.
**Términos:** aceptados para la versión 0.3.12 (términos 1.1) por José Francisco Ñáñez · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 c5ca81ee804ae819…

Registré 26 compromisos: 2 cumplidos con acta, 24 abiertos. De los abiertos, 8 están vencidos sin evidencia, 6 no tienen fecha y 2 se han reprogramado tres o más veces.

### Lo que está abierto, y cuántas veces se ha movido

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-12-12 | **Se movió 6 veces.** Prometido 2026-09-25 → 10-03 → 10-20 → 11-06 → 11-15 → 11-28 → 12-12. Última: notas 2026-10-16, «no alcanzó». Citas: minutas del 09-04 al 10-09 |
| Elena Duarte | Cerrar la prueba 2 | 2026-11-17 | **Se movió 5 veces.** 09-19 → 10-09 → 10-18 → 10-27 → 11-04 → 11-17. Hoy no se mencionó. Citas: minutas del 09-04 al 10-09 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-23 | Se movió 2 veces (09-30 → 10-09 → 10-23). Citas: minutas 09-25, 10-02, 10-09 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-16 | Se movió 1 vez (09-14 → 10-16). Vence hoy; hoy no se mencionó. Minutas 09-11 a 10-09 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-11-10 | Se movió 1 vez (10-20 → 11-10). Minutas 09-25 a 10-09 |
| Sandra Gil | Cerrar la prueba 18 | 2026-11-02 | Se movió 1 vez (10-23 → 11-02). Minutas 10-02 y 10-09 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-22 | Sin cambios. Minutas 10-02 y 10-09 |
| Diana Molina | Enviar el documento 17 | 2026-10-21 | Primera fecha puesta el 10-09 (antes «por definir»). Minuta 10-09 |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-01 | Minuta 10-09 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-26 | Nuevo hoy. Notas 2026-10-16 |

**Vencidos sin evidencia** (días contados a 2026-10-16):

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 | 25 | Minuta 09-18; la fecha nunca se movió |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 | 13 | Minuta 09-11. El 10-02 dijo que ya la entregó; no se presentó acta |
| Sandra Gil | Revisar el anexo 3 | 2026-10-09 | 7 | Minuta 09-04. El 09-25 dijo que ya la entregó; no se presentó acta. Se movió 1 vez (09-19 → 10-09) |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-10 | 6 | Minuta 10-02 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 | 5 | Minuta 09-25 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 | 3 | Minuta 09-11. Se movió 1 vez (10-05 → 10-13) |
| Jorge Medina | Validar el ambiente 4 | 2026-10-14 | 2 | Minuta 09-04. El 10-09 dijo que ya lo entregó; no se presentó acta. Se movió 1 vez (09-15 → 10-14) |
| Paula Céspedes | Entregar el punto 24 | 2026-10-15 | 1 | Minuta 10-09 |

**Cerrados con acta de recibo:** Entregar el punto 8 (Jorge Medina, acta 2026-09-18) y Validar el ambiente 12 (Liliana Torres, acta 2026-10-09). Que alguien diga «ya lo entregué» sin acta no cierra un compromiso: tres de los vencidos están en ese caso.

**Otros hallazgos de lo que calculó el script:**
- **Estado declarado verde, con 5 señales que no lo respaldan** (informe del 2026-10-13, avance 30%): compromisos vencidos, compromisos reprogramados, hitos cerrados sin acta, avance frente al plan y desviación de tiempo.
- **Desviación de tiempo:** +77 días (18.5%) contra la línea base original. El cierre pasó de 2027-03-22 a 2027-06-07 por CC-01 (ampliación de alcance, autorizada por «el comité»; no dice cuál).
- **Avance frente al plan:** el informe declara 30%; los hitos sostienen entre 50% y 75% (2 de 4 declarados cerrados), una diferencia de 20 puntos en dirección de atraso.
- **Hitos declarados cerrados sin acta:** Diseño funcional aprobado (2026-05-14, hace 155 días) y Ambiente de pruebas certificado (2026-08-26, hace 51 días).
- **Presupuesto:** de 2.400.000.000 COP aprobados, 1.145.951.271 comprometidos (47.7%) y 922.631.378 ejecutados (38.4%); proyección al cierre 2.365.074.370, 1.5% por debajo de lo aprobado. La solicitud CC-01 habla de 154.000.000 COP adicionales; ningún documento dice si el aprobado ya los incluye.
- **Riesgo no registrado:** hoy se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; «nadie lo anotó como riesgo». Lo dejé en la ficha, con dueño `no_identificado`. El informe solo registra «concentración del conocimiento en una sola persona».
- **Sin autoridad definida del gerente:** el acta no dice hasta qué monto o cambio de alcance decide Beatriz sin subir a comité. Tampoco declara la fase.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos y por eso se pierden en los informes:
- Gustavo Neira: Enviar el documento 9 (sin fecha desde el 09-18; el 10-02 dijo que ya lo entregó, sin acta)
- María Restrepo: Cerrar la prueba 10 (sin fecha desde el 09-18; el 09-25 dijo que ya la entregó, sin acta)
- Elena Duarte: Actualizar la matriz 14 (sin fecha en tres reuniones seguidas: 09-25, 10-02 y 10-09)
- Gustavo Neira: Aprobar el diseño 21 (10-09)
- Carlos Peña: Confirmar la fecha 23 (10-09)
- Laura Vélez: mandar el ajuste del presupuesto, «la otra semana» (notas 2026-10-16). No es una fecha y no la calculé.

### Qué le falta a tu carpeta
- Actas de recibo de lo que dicen haber entregado: Sandra Gil (anexo 3 y matriz 6), Jorge Medina (ambiente 4), Gustavo Neira (documento 9) y María Restrepo (prueba 10). Sin ellas un compromiso cumplido se ve igual que uno incumplido.
- Actas de recibo de los dos hitos declarados cerrados (diseño funcional y ambiente de pruebas).
- Un acta de constitución con alcance real: dice «Componente 1, 2, 3», no hay objetivos ni exclusiones concretas, y la sección de dependencias dice «Ninguna declarada».
- Minutas de antes del 2026-09-04: la más vieja que tengo es de esa fecha, y los compromisos de Rubén y Elena pueden venir de antes.
- Las fechas de la minuta del 09-04 al 10-09 del comité: la fecha de Jorge Medina (09-15) se repitió sin cambio durante cuatro reuniones antes de moverse; conviene que el comité la confirme cada vez.

**Cuándo vuelvo:** los viernes, según la cadencia de tu reunión; la próxima, según las notas de hoy, es el 2026-10-30 (en dos semanas).
