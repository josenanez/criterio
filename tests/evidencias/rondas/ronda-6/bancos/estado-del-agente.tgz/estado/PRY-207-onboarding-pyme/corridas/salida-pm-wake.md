## Onboarding PyME (PRY-207) · 2026-10-16

**Revisé:** 15 documentos · 15 nuevos para el índice (primer barrido, no hay corrida anterior contra la cual comparar) · 1 minuta nueva: `2026-10-16-notas-reunion.txt`

La minuta de hoy ya estaba extraída en la ficha por `/pm-setup` de esta misma fecha, así que no volví a extraerla: Rubén Cárdenas (documento 1 → 2026-12-12), Laura Vélez (ajuste del presupuesto, «la otra semana», sin fecha exacta), Óscar Ramírez (revisión con el proveedor → 2026-10-26) y el riesgo del proveedor sin registrar (sin dueño).

### Lo que se venció solo
Nada nuevo desde la corrida anterior (la anterior es de hoy). Siguen vencidos los 8 compromisos ya reportados; ninguno cruzó un umbral hoy. «Confirmar la fecha 7» (Rubén Cárdenas) vence hoy y aún no cuenta como vencido. «Enviar el documento 1» lleva 6 reprogramaciones (umbral: 3), ya señalado.

### La reunión
El comité es el 2026-10-30, a 14 días: aún no toca ofrecer agenda. El informe toca el 2026-10-29.

### Tu ficha publicada
`/pm-publish` corrió hoy; no se ha quedado vieja.

Aviso del índice: 15 citas de la ficha (identidad, plan, dinero) no resolvían por la ruta con que fueron escritas (`PRY-207-onboarding-pyme/...` en vez de la ruta relativa a la carpeta de documentos). No las toqué; conviene revisarlas.

**Vuelvo el 2026-10-17.**
