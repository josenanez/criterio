Sin argumento: tomé lo que ya está marcado como escalable en la ficha (PRY-207, lectura sin sellar: 6 minutas, notas del 2026-10-16, 2 actas de recibo). Términos vigentes (versión 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16); no hubo que registrarlos de nuevo.

## Para decisión — Onboarding PyME (PRY-207) · 2026-10-16

Escalan **dos puntos**. El primero es el que manda: el acta no declara autoridad, y sin eso no se sabe a quién le corresponde decidir el segundo.

---

### Punto 1 — ¿Qué puede decidir la gerente sin ir al comité?

**Pregunta cerrada:** ¿Se acepta que la autoridad de Beatriz Cuéllar sea la que fije el patrocinador Sandra Gil en una adenda al acta de constitución, antes del comité del 2026-10-30, o se deja sin declarar y todo cambio de alcance, tiempo o costo va al comité?

**Quién decide:** Sandra Gil (patrocinadora) · el acta es del Comité de Riesgos, que aprobó el presupuesto el 2026-01-20. El acta no dice quién puede modificarla; esto es lo que hay que preguntar.
**Si no se decide hoy:** el 2026-10-30 el comité se sienta sin saber qué le toca a la gerente y qué a él. No encontré una fecha límite externa en los documentos; la consecuencia que sí consta es que CC-01 (+77 días, 154.000.000 COP) ya se «autorizó» sin que el documento diga qué comité ni quién, y el próximo cambio repite la ambigüedad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta con la autoridad declarada (umbrales de días y de COP que decide la gerente) | Ninguno | Una revisión del acta por la patrocinadora; no hay estimación en los documentos | Sin costo declarado en los documentos |
| B. No declararla; todo cambio va al comité | Ninguno | Cada cambio espera al comité (semanal según la configuración) | Sin costo declarado en los documentos |

**Recomiendo:** A, porque hoy ninguna de las dos partes puede probar quién decidió CC-01 y una autoridad escrita evita que la gerente escale todo o nada.

**Lo que no sé:** si existe un documento de autoridad fuera de esta carpeta. La ficha marca `identity.authority` como no encontrada.

---

### Punto 2 — Documento 1 de Rubén Cárdenas (seis reprogramaciones)

**Pregunta cerrada:** ¿Se reasigna el «documento 1» a otra persona, o se parte en entregas parciales con fecha, o se mantiene con Rubén Cárdenas y fecha 2026-12-12?

**Quién decide:** según el acta, no se puede decir (ver punto 1). Dentro del proyecto lo puede reasignar Beatriz Cuéllar; la minuta no dice que lo haya hecho. Lo escalo porque cumple el criterio de «reprogramado tres veces o más»: seis veces (2026-09-25 → 10-03 → 10-20 → 11-06 → 11-15 → 11-28 → 12-12), sin evidencia de entrega. Rubén tiene además vencido «Entregar el punto 16» (2026-10-11) y «Confirmar la fecha 7» con fecha de hoy.
**Si no se decide hoy:** la séptima fecha se suma a las seis y el compromiso sigue sin evidencia. Si el documento alimenta «Integración con el core» (2026-12-08), el 12/12 ya llega 4 días tarde. **No lo sé: ningún documento dice qué alimenta el documento 1.**

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mantener con Rubén, 2026-12-12 | Sin cambio | 12/12; 4 días después del hito del core, si lo alimenta | No declarado |
| B. Reasignar | Sin cambio | No declarado | No declarado |
| C. Entregas parciales con fecha | Sin cambio | No declarado | No declarado |

**Recomiendo:** C, con la primera entrega parcial antes del 2026-12-08, porque es la única opción que protege el hito sin cambiar de persona, y la que deja evidencia intermedia. Es una recomendación sobre la forma del compromiso, no sobre el contenido del documento, que desconozco.

---

### A quién alcanza
No alcanza a otro proyecto: el cálculo no devuelve proyectos alcanzados, y el acta declara «Ninguna declarada» como dependencias. Eso no prueba que no haya dependencias: solo que nadie las declaró.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno | n/a | n/a | n/a |

### Mis hitos por los que pasa
Cálculo con `impact --days 4` (hipótesis: documento 1 el 12/12 contra el hito del 08/12). Corrí también `--days 77` para dimensionar un segundo cambio de ese tamaño; **no es CC-01, que ya está en la línea base vigente** (cierre 2027-06-07).

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Integración con el core | 2026-12-08 | 53 |
| Piloto con usuarios internos | 2027-06-07 | 234 |

Con 4 días el cierre pasaría del 2027-06-07 al 2027-06-11; con 77, al 2027-08-23. Cuántos días se mueve cada hito no sale de este cálculo: necesita holgura por actividad, y la ficha no la tiene.

### De dónde sale esto
- Autoridad no declarada: acta de constitución 2026-01-20 (`00-gobierno/2026-01-20-acta-constitucion.md`); sin sección de autoridad. Ficha: `identity.authority = not_found`.
- CC-01 «Autorizada por el comité», sin nombre: `20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md`.
- Seis reprogramaciones del documento 1: minutas 2026-09-04, 09-11, 09-18, 09-25, 10-02, 10-09 y notas 2026-10-16 (`2026-10-16-notas-reunion.txt`).
- Hito «Integración con el core» y cierre 2027-06-07: `10-plan/2026-10-13-cronograma-v2.xlsx`.
- Dependencias: acta, sección «Dependencias declaradas».

### Lo que no escala
- El riesgo «el proveedor podría no llegar con el equipo completo» no escala: no tiene dueño, pero lo puede registrar Beatriz Cuéllar; está en la agenda del 2026-10-30.
- El resto de vencidos (Javier Hoyos, Óscar Ramírez, Liliana Torres, Paula Céspedes, Sandra Gil, Jorge Medina) se destraban con una llamada o con el acta de recibo; ver `/pm-commitments`.

*Escalar es tuyo: este paquete no se lo envía a nadie ni llama a nadie.*
