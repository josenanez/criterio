# Plan — PRY-207 Onboarding PyME · borrador del 2026-10-16
**Desde:** acta de constitución del 2026-01-20 (`00-gobierno/2026-01-20-acta-constitucion.md`) · **Criterio de éxito:** «Onboarding PyME en producción y medido» (acta, sección *Criterio de éxito*). No dice qué se mide, con qué meta, ni quién da por medido.

> Los términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-16) ya estaban registrados; no se pidió nuevo registro.
> El proyecto no es nuevo: ya tiene dos líneas base (v1 acta, 2026-01-20; v2 CC-01, 2026-10-06) y dos hitos cerrados. Este borrador reconstruye la estructura desde el acta; no reemplaza ninguna línea base.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** «Componente 1 / 2 / 3» y fuera de alcance «Lo que otro proyecto cubre» (acta, *Alcance* y *Fuera de alcance*) | No hay entregables que descomponer. Los nodos de la WBS quedan nombrados por el acta, no definidos. Y lo que el proyecto no hace no se puede distinguir de lo que sí |
| **Criterio de éxito sin métrica.** «en producción y medido» | No se sabe qué significa «medido»: cuántas PyMEs, en qué tiempo, con qué tasa de conversión. Sin eso no hay punto de cierre que alguien pueda aceptar |
| **Autoridad del gerente no declarada** (la ficha la registra como no encontrada) | No se sabe qué puede decidir quien planifica y qué debe subir; cada ajuste de este plan queda sin tope conocido |
| **Dependencias: «Ninguna declarada»**, pero el cronograma tiene un hito «Integración con el core» y las notas del 2026-10-16 hablan de un proveedor | O la integración no depende de nadie —improbable— o la dependencia existe y no está escrita. Un orden construido sobre «ninguna» esconde las dos |
| **Área dueña «Banca de Personas» para un producto «cuenta PyME»** | Puede ser un error de copia o una decisión; si es error, el patrocinador y el comité podrían no ser los correctos. No lo corrijo: lo señalo |
| **Comité de aprobación inconsistente.** El acta nombra «Comité de Riesgos»; CC-01 dice «autorizada por el comité» sin nombrarlo | No se sabe ante quién se lleva una excepción de este plan |

Patrocinador sí está declarado (Sandra Gil). Presupuesto sí (2.400.000.000 COP, aprobado el 2026-01-20; CC-01 suma 154.000.000 COP según su solicitud).

## WBS
Regla aplicada: cada nodo terminal debe ser algo que alguien recibe y acepta. Con este acta casi ningún nodo cumple todavía; lo digo en lugar de inventarlo.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | «Componente 1» — **qué se entrega: sin definir** | sin definir | del acta (solo el nombre) · contenido **sin definir** | — |
| 2 | «Componente 2» — **qué se entrega: sin definir** | sin definir | del acta (solo el nombre) · contenido **sin definir** | — |
| 3 | «Componente 3» — **qué se entrega: sin definir** | sin definir | del acta (solo el nombre) · contenido **sin definir** | — |
| 4 | Diseño funcional aprobado (hito cerrado, 2026-05-14) | sin definir | **supuesto**: sale del cronograma v1/v2, no del acta; que corresponda a algún componente es supuesto | — |
| 5 | Ambiente de pruebas certificado (hito cerrado, 2026-08-26) | sin definir | **supuesto**: ídem | — |
| 6 | Integración con el core (hito pendiente, 2026-12-08) | sin definir | **supuesto**: ídem | — |
| 7 | Piloto con usuarios internos (hito pendiente; 2027-03-22 en v1, 2027-06-07 en v2) | sin definir | **supuesto**: ídem. Quién es «usuario interno» y cuántos: sin definir | — |
| 8 | Ampliación de alcance de CC-01 — **qué se amplió: sin definir** | sin definir | CC-01 dice «Ampliación de alcance» y nada más; no está en el acta | — |
| 9 | Onboarding PyME en producción | sin definir | del acta (criterio de éxito) · fecha de paso a producción **sin definir** | — |
| 10 | Medición del onboarding en producción | sin definir | del acta («y medido») · indicador y meta **sin definir** | — |

Duración citable solo del proyecto completo, no de nodos: inicio 2026-01-30 y cierre 2027-03-22 en el acta; 2027-06-07 en el cronograma v2 tras CC-01 (+77 días). Ninguna duración por nodo sale de un documento, así que todas van vacías.

## Orden
Sin fechas. Lo que sigue es el orden en que el cronograma lista los hitos; **el acta no declara dependencias**, así que lo trato como supuesto, no como hecho.
- 4 → 5 → 6 → 7: diseño, ambiente de pruebas, integración con el core, piloto (orden del cronograma).
- 7 → 9 → 10: producción después del piloto, medición después de producción (consecuencia lógica del criterio de éxito; **supuesto**).
- 1, 2, 3 y 8: no se pueden ordenar. No se sabe qué son ni con cuál hito se relacionan.
- Dependencias externas posibles, no declaradas: la integración con el core (6) y el proveedor mencionado en las notas del 2026-10-16. Si el core pertenece a otro proyecto del portafolio, el acta no lo dice.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma cubren el alcance del acta (Componentes 1 a 3) | Hay entregables sin hito, y el cierre se mide contra algo incompleto |
| El orden diseño → pruebas → core → piloto es una dependencia y no solo el orden del calendario | Un hito podría adelantarse o cambiar sin arrastrar a los demás; o al revés |
| Producción y medición vienen después del piloto | Si el piloto no es previo a producción, el cierre del cronograma no es el cierre del proyecto |
| «Medido» se mide en producción, después del último hito | Si exige un periodo de observación, el cierre real es posterior a 2027-06-07 |
| «Ampliación de alcance» de CC-01 son entregables adicionales dentro de estos mismos hitos | Si crea hitos nuevos, el cronograma v2 solo corrió una fecha y no incorporó el trabajo |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 | no está escrito; correspondería al patrocinador (Sandra Gil) y al gerente (Beatriz Cuéllar) — el acta no lo asigna |
| Qué se amplió con CC-01 | quien solicitó el cambio (Beatriz Cuéllar, según CC-01) |
| Quién acepta cada entregable | el acta no lo dice |
| Indicador y meta de «medido» | el acta no lo dice |
| Lo que queda fuera de alcance | el acta no lo dice (hoy: «Lo que otro proyecto cubre») |
| Autoridad del gerente al planificar | el acta no la declara |
| Qué comité aprueba excepciones y cambios | el acta dice Comité de Riesgos; CC-01 dice «el comité» |
| Si el área dueña es Banca de Personas o Banca PyME | el patrocinador |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, y en `estado/` solo existe la ficha de PRY-207. El único estado de producto presente (PRD-306, Microseguros) no es el mismo producto. Sin análogos no hay referencia de corrimiento, y no pongo una cifra de relleno. Para el propio proyecto, lo que ya pasó: el cierre se corrió de 2027-03-22 a 2027-06-07 (+77 días) por CC-01.

## Preguntas para el equipo
Una por cada duración vacía.
1. Componente 1: ¿qué se entrega, quién lo acepta y cuánto toma?
2. Componente 2: ¿qué se entrega, quién lo acepta y cuánto toma?
3. Componente 3: ¿qué se entrega, quién lo acepta y cuánto toma?
4. Diseño funcional aprobado: ¿qué componentes cubre? (Ya está cerrado, pero el acta no lo enlaza a nada.)
5. Ambiente de pruebas certificado: ¿qué componentes cubre y quién lo certificó?
6. Integración con el core: ¿cuánto toma, y de quién depende el core?
7. Piloto con usuarios internos: ¿cuántos usuarios, cuánto dura el piloto y cuál es su criterio de salida?
8. CC-01: ¿qué entregables nuevos trae la ampliación y cuánto toma cada uno?
9. Paso a producción: ¿cuánto toma, y quién lo autoriza?
10. Medición: ¿qué se mide, con qué meta, durante cuánto tiempo y quién la da por cumplida?

## Para comprometer una fecha falta
- La disponibilidad real del equipo (nombres y dedicación): no está en ningún documento.
- La fecha del proveedor y qué equipo trae. Las notas del 2026-10-16 dicen que podría no llegar completo y nadie lo anotó como riesgo; la ficha no registra ningún contrato de proveedor.
- La ventana de paso a producción y de la sala/ambiente de pruebas: no aparece en ningún documento.
- Que alguien con autoridad declare qué es cada componente; sin eso cualquier fecha es sobre un entregable sin definir.

La fecha la compromete Beatriz Cuéllar; este borrador no compromete ninguna.

## Después
Cuando el plan se apruebe: ofrecer registrarlo como línea base (aquí ya existen v1 y v2, así que sería una versión nueva que se añade, sin borrar las anteriores) y pasar los cinco supuestos al RAID con doliente.
