<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Portal de proveedores

**Código:** PRY-210
**Fecha de corte:** 2026-10-13
**Gerente:** Mauricio Pérez

## Estado declarado

**Rojo**

Avance reportado: **85%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 664.747.393 |
| Ejecutado | 436.821.154 |
| Proyección al cierre | 1.168.878.153 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
