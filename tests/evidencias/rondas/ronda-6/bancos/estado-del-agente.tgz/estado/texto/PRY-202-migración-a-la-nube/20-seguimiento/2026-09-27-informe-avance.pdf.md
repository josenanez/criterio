<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración a la nube
Código: PRY-202
Fecha de corte: 2026-09-27
Gerente: Rubén Cárdenas

Estado declarado
Amarillo
Avance reportado: 80%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 2.675.338.214
Ejecutado 5.614.863.191
Proyección al cierre 9.691.323.593

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
