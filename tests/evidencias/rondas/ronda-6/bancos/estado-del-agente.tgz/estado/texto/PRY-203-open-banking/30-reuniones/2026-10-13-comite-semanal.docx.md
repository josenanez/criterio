<!-- origen: PRY-203-open-banking/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Open Banking

Fecha: 2026-10-13

Asistentes: María Restrepo, Óscar Ramírez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Sandra Gil

Entregar el punto 21

2026-10-28

Diana Molina

Entregar el punto 33

2026-10-28
