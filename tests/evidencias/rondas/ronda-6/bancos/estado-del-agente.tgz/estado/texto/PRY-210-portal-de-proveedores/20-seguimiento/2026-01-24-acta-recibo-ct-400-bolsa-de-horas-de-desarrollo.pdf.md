<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-01-24-acta-recibo-ct-400-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-210 · Portal de proveedores
Fecha de recibo: 2026-01-24
Recibido por: Mauricio Pérez
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-400 · Talento Digital S.A.S..
