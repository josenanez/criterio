<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2025-05-31-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-02 | 2025-09-02 | cerrado
Ambiente de pruebas certificado | 2025-11-25 | 2025-11-25 | cerrado
Integración con el core | 2026-02-17 | 2026-02-17 | cerrado
Piloto con usuarios internos | 2026-05-12 | 2026-05-12 | cerrado
Salida a producción | 2026-08-04 | 2026-08-04 | cerrado
