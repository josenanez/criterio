<!-- origen: PRY-203-open-banking/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Open Banking
Código: PRY-203
Fecha de corte: 2026-09-25
Gerente: María Restrepo

Estado declarado
Verde
Avance reportado: 46%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 9.797.767.251
Ejecutado 7.810.329.197
Proyección al cierre 22.250.676.721

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
