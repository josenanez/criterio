<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-10-15
Gerente: Ricardo Salas

Estado declarado
Rojo
Avance reportado: 49%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.617.037.802
Ejecutado 1.908.189.235
Proyección al cierre 6.265.902.381

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Disponibilidad del equipo de seguridad para la revisión final
