<!-- origen: PRY-211-cobranza-digital/10-plan/2025-07-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-30 | 2025-09-30 | cerrado
Ambiente de pruebas certificado | 2025-12-19 | 2025-12-19 | cerrado
Integración con el core | 2026-03-09 | 2026-03-09 | cerrado
Piloto con usuarios internos | 2026-05-28 | 2026-05-28 | cerrado
