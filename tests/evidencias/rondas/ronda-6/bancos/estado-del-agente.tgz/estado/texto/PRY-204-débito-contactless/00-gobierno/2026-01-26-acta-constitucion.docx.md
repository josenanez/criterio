<!-- origen: PRY-204-débito-contactless/00-gobierno/2026-01-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Operaciones

Patrocinador: Laura Vélez

Gerente de proyecto: Felipe Arango

Comité: Comité de Transformación Digital

Producto asociado: tarjeta débito

Fecha de aprobación: 2026-01-26

Objetivo del negocio

Entregar débito contactless para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Transformación Digital el 2026-01-26.

Fechas comprometidas

Fecha

Inicio

2026-02-05

Cierre

2026-10-25

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
