<!-- origen: PRY-203-open-banking/20-seguimiento/2026-10-03-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-203 · Open Banking
**Fecha:** 2026-10-03
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +33 días sobre la línea base vigente |
| Costo | 66.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
