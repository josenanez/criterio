<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-09-11
**Asistentes:** Beatriz Cuéllar, Elena Duarte, Jorge Medina, Liliana Torres, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-10-03 |
| Elena Duarte | Cerrar la prueba 2 | 2026-10-09 |
| Sandra Gil | Revisar el anexo 3 | 2026-09-19 |
| Jorge Medina | Validar el ambiente 4 | 2026-09-15 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-05 |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-09-14 |
| Jorge Medina | Entregar el punto 8 | 2026-09-30 |
