<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Riesgos · Prevención de lavado de activos

Fecha: 2026-10-10

Asistentes: Carlos Peña, Camilo Beltrán

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 26

2026-10-16
