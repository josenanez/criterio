<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-12
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 47%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 14.825.731.865
Ejecutado 4.683.062.643
Proyección al cierre 16.897.664.168

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
