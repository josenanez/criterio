<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-10-02
**Asistentes:** Beatriz Cuéllar, Diana Molina, Elena Duarte, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-11-15 |
| Elena Duarte | Cerrar la prueba 2 | 2026-11-04 |
| Jorge Medina | Validar el ambiente 4 | 2026-10-14 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-16 |
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 |
| Liliana Torres | Validar el ambiente 12 | 2026-10-14 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-09 |
| Elena Duarte | Actualizar la matriz 14 | por definir |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-20 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |
| Diana Molina | Enviar el documento 17 | por definir |
| Sandra Gil | Cerrar la prueba 18 | 2026-10-23 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-10 |
| Javier Hoyos | Validar el ambiente 20 | 2026-10-22 |

## Lo que se dijo

- Sandra Gil dice que ya entregó «actualizar la matriz 6». No se presentó acta.
- Gustavo Neira dice que ya entregó «enviar el documento 9». No se presentó acta.
