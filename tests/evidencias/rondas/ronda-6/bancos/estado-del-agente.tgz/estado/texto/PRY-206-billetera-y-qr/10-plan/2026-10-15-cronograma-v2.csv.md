<!-- origen: PRY-206-billetera-y-qr/10-plan/2026-10-15-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-28,2026-02-28,cerrado
Ambiente de pruebas certificado,2026-06-17,2026-06-17,cerrado
Integración con el core,2026-10-04,2026-10-04,cerrado
Piloto con usuarios internos,2027-01-21,2027-01-21,en curso
Salida a producción,2027-05-10,2027-07-19,en curso
