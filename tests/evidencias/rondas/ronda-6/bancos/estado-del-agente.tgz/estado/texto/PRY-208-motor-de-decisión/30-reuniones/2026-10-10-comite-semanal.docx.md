<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Motor de decisión

Fecha: 2026-10-10

Asistentes: Carlos Peña, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Mauricio Pérez

Entregar el punto 28

2026-10-01
