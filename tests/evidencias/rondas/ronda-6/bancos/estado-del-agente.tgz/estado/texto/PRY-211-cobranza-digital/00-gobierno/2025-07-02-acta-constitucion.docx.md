<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-07-02-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Banca Empresas

Patrocinador: Paula Céspedes

Gerente de proyecto: Sandra Gil

Comité: Comité de Transformación Digital

Producto asociado: recaudos

Fecha de aprobación: 2025-07-02

Objetivo del negocio

Entregar cobranza digital para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Transformación Digital el 2025-07-02.

Fechas comprometidas

Fecha

Inicio

2025-07-12

Cierre

2026-05-28

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
