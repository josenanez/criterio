<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Felipe Arango

Estado declarado
Rojo
Avance reportado: 77%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 800.000.000
Comprometido 296.937.416
Ejecutado 406.994.391
Proyección al cierre 829.681.423

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
