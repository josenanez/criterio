<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-12-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración a la nube

**Código:** PRY-202
**Área dueña:** Tesorería
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-20

## Objetivo del negocio

Entregar migración a la nube para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-12-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-30 |
| Cierre | 2027-04-22 |

## Criterio de éxito

Migración a la nube en producción y medido.

## Dependencias declaradas

- Ninguna declarada
