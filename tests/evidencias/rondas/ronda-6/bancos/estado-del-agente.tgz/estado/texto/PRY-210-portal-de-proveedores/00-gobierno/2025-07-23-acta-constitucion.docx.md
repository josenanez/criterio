<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-07-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Canales Digitales

Patrocinador: Jorge Medina

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-07-23

Objetivo del negocio

Entregar portal de proveedores para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-07-23.

Fechas comprometidas

Fecha

Inicio

2025-08-02

Cierre

2026-05-10

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
