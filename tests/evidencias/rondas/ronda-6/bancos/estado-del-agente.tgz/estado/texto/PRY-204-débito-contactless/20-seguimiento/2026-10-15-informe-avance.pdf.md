<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-15
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 48%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.158.705.831
Ejecutado 1.316.546.200
Proyección al cierre 6.869.556.501

Riesgos abiertos
- Concentración del conocimiento en una sola persona
