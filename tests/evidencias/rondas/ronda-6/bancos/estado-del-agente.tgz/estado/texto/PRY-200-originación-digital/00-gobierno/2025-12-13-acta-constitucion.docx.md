<!-- origen: PRY-200-originación-digital/00-gobierno/2025-12-13-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Canales Digitales

Patrocinador: Felipe Arango

Gerente de proyecto: Ricardo Salas

Comité: Comité de Arquitectura

Producto asociado: crédito de consumo

Fecha de aprobación: 2025-12-13

Objetivo del negocio

Entregar originación digital para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Arquitectura el 2025-12-13.

Fechas comprometidas

Fecha

Inicio

2025-12-23

Cierre

2027-02-27

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
