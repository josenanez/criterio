<!-- origen: PRY-209-nómina-electrónica/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Nómina electrónica

Fecha: 2026-10-13

Asistentes: Jorge Medina, Beatriz Cuéllar

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Gustavo Neira

Entregar el punto 16

2026-11-12
