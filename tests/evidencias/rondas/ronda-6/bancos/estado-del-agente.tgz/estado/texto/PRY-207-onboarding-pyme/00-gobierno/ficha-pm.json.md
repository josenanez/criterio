<!-- origen: PRY-207-onboarding-pyme/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "identity": {
 "code": {
 "value": "PRY-207",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "name": {
 "value": "Onboarding PyME",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Banca de Personas",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "product": {
 "value": "cuenta PyME",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Sandra Gil",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "manager": {
 "value": "Beatriz Cuéllar",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Riesgos",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "verde",
 "progress_pct": 30,
 "as_of": "2026-10-13",
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-01-30",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "end_date": {
 "value": "2027-06-07",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-01-20",
 "start_date": "2026-01-30",
 "end_date": "2027-03-22",
 "baseline_end_date": "2027-03-22",
 "reason": "Acta de constitución; cronograma v1 coincide en el cierre (último hito 2027-03-22)",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md"
 },
 {
 "version": 2,
 "approved_on": "2026-10-06",
 "start_date": "2026-01-30",
 "end_date": "2027-06-07",
 "baseline_end_date": "2027-03-22",
 "reason": "Solicitud de cambio CC-01 (ampliación de alcance, +77 días), autorizada por el comité; fecha tomada del cronograma v2",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2026-05-14",
 "current_date": "2026-05-14",
 "state": "met",
 "evidence": "",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-08-26",
 "current_date": "2026-08-26",
 "state": "met",
 "evidence": "",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": "Integración con el core",
 "baseline_date": "2026-12-08",
 "current_date": "2026-12-08",
 "state": "pending",
 "evidence": "",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": "Piloto con usuarios internos",
 "baseline_date": "2027-03-22",
 "current_date": "2027-06-07",
 "state": "pending",
 "evidence": "",
 "source": "PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componentes 1 a 3 (sin detalle)",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "PRY-207-onboarding-pyme/00-gobierno/2026-01-20-acta-constitucion.md",
 "source_date": "2026-01-20",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 2400000000,
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "committed": {
 "value": 1145951271,
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 922631378,
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 2365074370,
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "probability": null,
 "impact": null,
 "owner": "no_identificado",
 "due_date": null,
 "last_moved": "2026-10-16",
 "source": "PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-06",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+77 días sobre la línea base vigente",
 "cost_impact": "154.000.000 COP adicionales",
 "decision": "approved",
 "decided_by": "el comité (autorizada; el documento no nombra cuál ni quién)",
 "source": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": "Rubén Cárdenas",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-12",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-04",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md"
 },
 {
 "due_date": "2026-12-12",
 "stated_on": "2026-10-16",
 "source": "PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-17",
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-04",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md"
 },
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-09",
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-04",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md"
 }
 ],
 "note": "2026-09-25: Sandra Gil dice que ya entregó. No se presentó acta. (PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md) Primera fecha puesta el 2026-09-11; antes era «por definir»."
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-14",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-04",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "note": "2026-10-09: Jorge Medina dice que ya entregó. No se presentó acta. (PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md)"
 },
 {
 "who": "Liliana Torres",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-13",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-03",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "2026-10-02: Sandra Gil dice que ya entregó. No se presentó acta. (PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md)"
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-16",
 "original_due_date": "2026-09-14",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Entregar el punto 8",
 "due_date": "2026-09-30",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-11",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-11-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "PRY-207-onboarding-pyme/20-seguimiento/2026-09-18-acta-recibo-8.md"
 },
 {
 "who": "Gustavo Neira",
 "what": "Enviar el documento 9",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-02: Gustavo Neira dice que ya entregó. No se presentó acta. (PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md)"
 },
 {
 "who": "María Restrepo",
 "what": "Cerrar la prueba 10",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-09-25: María Restrepo dice que ya entregó. No se presentó acta. (PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md)"
 },
 {
 "who": "Javier Hoyos",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-21",
 "original_due_date": "2026-09-21",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-14",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-18",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-18-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 }
 ],
 "evidence": "PRY-207-onboarding-pyme/20-seguimiento/2026-10-09-acta-recibo-12.md"
 },
 {
 "who": "María Restrepo",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-23",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Actualizar la matriz 14",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-11-10",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-25",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Primera fecha puesta el 2026-10-09; antes era «por definir»."
 },
 {
 "who": "Sandra Gil",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-11-02",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-02",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-02-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Aprobar el diseño 21",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Confirmar la fecha 23",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-10-09",
 "source": "PRY-207-onboarding-pyme/30-reuniones/2026-10-09-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto (notas: «la otra semana»)",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-16",
 "source": "PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-16",
 "source": "PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "activity": {},
 "meta": {
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors"
 ],
 "open_conflicts": [],
 "reading_scope": "6 minutas (2026-09-04 a 2026-10-09) + notas del 2026-10-16 + 2 actas de recibo; no sellada"
 }
}
