<!-- origen: PRY-207-onboarding-pyme/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-14 | 2026-05-14 | cerrado
Ambiente de pruebas certificado | 2026-08-26 | 2026-08-26 | cerrado
Integración con el core | 2026-12-08 | 2026-12-08 | en curso
Piloto con usuarios internos | 2027-03-22 | 2027-06-07 | en curso
