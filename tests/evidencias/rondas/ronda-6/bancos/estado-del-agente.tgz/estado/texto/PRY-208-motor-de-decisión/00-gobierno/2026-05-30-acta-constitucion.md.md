<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2026-05-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Motor de decisión

**Código:** PRY-208
**Área dueña:** Banca Empresas
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Medios de Pago
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-30

## Objetivo del negocio

Entregar motor de decisión para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Medios de Pago el 2026-05-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-09 |
| Cierre | 2027-11-22 |

## Criterio de éxito

Motor de decisión en producción y medido.

## Dependencias declaradas

- Ninguna declarada
