<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-07-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-27 | 2025-09-27 | cerrado
Ambiente de pruebas certificado | 2025-11-22 | 2025-11-22 | cerrado
Integración con el core | 2026-01-18 | 2026-01-18 | cerrado
Piloto con usuarios internos | 2026-03-15 | 2026-03-15 | cerrado
Salida a producción | 2026-05-10 | 2026-05-10 | cerrado
