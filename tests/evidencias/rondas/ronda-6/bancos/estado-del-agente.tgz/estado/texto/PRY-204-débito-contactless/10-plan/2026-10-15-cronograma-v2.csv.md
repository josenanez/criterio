<!-- origen: PRY-204-débito-contactless/10-plan/2026-10-15-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-04-11,2026-04-11,cerrado
Ambiente de pruebas certificado,2026-06-16,2026-06-16,cerrado
Integración con el core,2026-08-20,2026-08-20,cerrado
Piloto con usuarios internos,2026-10-25,2027-02-21,en curso
