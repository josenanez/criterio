<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2026-03-01-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Nómina electrónica

**Código:** PRY-209
**Área dueña:** Canales Digitales
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Transformación Digital
**Producto asociado:** nómina empresarial
**Fecha de aprobación:** 2026-03-01

## Objetivo del negocio

Entregar nómina electrónica para Canales Digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-03-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-11 |
| Cierre | 2027-01-28 |

## Criterio de éxito

Nómina electrónica en producción y medido.

## Dependencias declaradas

- Ninguna declarada
