<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-05-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-09-04 | 2026-09-04 | cerrado
Ambiente de pruebas certificado | 2026-12-23 | 2026-12-23 | en curso
Integración con el core | 2027-04-12 | 2027-04-12 | en curso
Piloto con usuarios internos | 2027-07-31 | 2027-07-31 | en curso
