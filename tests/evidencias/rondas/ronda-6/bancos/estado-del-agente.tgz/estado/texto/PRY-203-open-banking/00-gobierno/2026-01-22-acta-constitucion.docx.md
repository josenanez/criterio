<!-- origen: PRY-203-open-banking/00-gobierno/2026-01-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Medios de Pago

Patrocinador: Óscar Ramírez

Gerente de proyecto: María Restrepo

Comité: Comité de Medios de Pago

Producto asociado: APIs de datos

Fecha de aprobación: 2026-01-22

Objetivo del negocio

Entregar open banking para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Medios de Pago el 2026-01-22.

Fechas comprometidas

Fecha

Inicio

2026-02-01

Cierre

2027-03-21

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
