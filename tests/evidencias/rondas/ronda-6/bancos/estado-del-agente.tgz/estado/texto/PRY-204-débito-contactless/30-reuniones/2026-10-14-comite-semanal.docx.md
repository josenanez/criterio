<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Débito contactless

Fecha: 2026-10-14

Asistentes: Felipe Arango, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 36

2026-10-25
