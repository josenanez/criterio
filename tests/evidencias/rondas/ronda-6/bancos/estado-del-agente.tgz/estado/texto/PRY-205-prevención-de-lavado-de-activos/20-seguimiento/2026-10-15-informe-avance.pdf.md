<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-10-15
Gerente: Carlos Peña

Estado declarado
Amarillo
Avance reportado: 77%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 5.292.231.115
Ejecutado 1.534.440.797
Proyección al cierre 9.165.818.019

Riesgos abiertos
- Concentración del conocimiento en una sola persona
