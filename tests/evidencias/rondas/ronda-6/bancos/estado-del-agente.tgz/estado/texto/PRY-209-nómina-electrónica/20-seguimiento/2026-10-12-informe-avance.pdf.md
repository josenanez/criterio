<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-12
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 48%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.105.013.998
Ejecutado 5.839.363.347
Proyección al cierre 8.764.416.043

Riesgos abiertos
- Concentración del conocimiento en una sola persona
