<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de decisión
Código: PRY-208
Fecha de corte: 2026-09-24
Gerente: Carlos Peña

Estado declarado
Verde
Avance reportado: 31%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- La prueba de carga no alcanzó el umbral pactado y se repite
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.242.450.730
Ejecutado 1.027.858.751
Proyección al cierre 3.303.203.037

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
