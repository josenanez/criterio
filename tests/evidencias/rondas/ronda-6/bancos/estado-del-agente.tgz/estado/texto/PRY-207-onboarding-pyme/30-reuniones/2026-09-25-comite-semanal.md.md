<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-09-25-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Onboarding PyME

**Fecha:** 2026-09-25
**Asistentes:** Beatriz Cuéllar, Elena Duarte, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Enviar el documento 1 | 2026-11-06 |
| Elena Duarte | Cerrar la prueba 2 | 2026-10-27 |
| Jorge Medina | Validar el ambiente 4 | 2026-09-15 |
| Liliana Torres | Aprobar el diseño 5 | 2026-10-13 |
| Sandra Gil | Actualizar la matriz 6 | 2026-10-03 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-09-14 |
| Gustavo Neira | Enviar el documento 9 | por definir |
| Javier Hoyos | Revisar el anexo 11 | 2026-09-21 |
| Liliana Torres | Validar el ambiente 12 | 2026-09-26 |
| María Restrepo | Aprobar el diseño 13 | 2026-09-30 |
| Elena Duarte | Actualizar la matriz 14 | por definir |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-20 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |

## Lo que se dijo

- Sandra Gil dice que ya entregó «revisar el anexo 3». No se presentó acta.
- María Restrepo dice que ya entregó «cerrar la prueba 10». No se presentó acta.
