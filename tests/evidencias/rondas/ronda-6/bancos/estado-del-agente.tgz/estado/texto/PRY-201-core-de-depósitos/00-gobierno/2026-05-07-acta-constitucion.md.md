<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2026-05-07-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Core de depósitos

**Código:** PRY-201
**Área dueña:** Banca de Personas
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Transformación Digital
**Producto asociado:** cuenta de ahorros
**Fecha de aprobación:** 2026-05-07

## Objetivo del negocio

Entregar core de depósitos para Banca de Personas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-05-07.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-17 |
| Cierre | 2027-07-31 |

## Criterio de éxito

Core de depósitos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
