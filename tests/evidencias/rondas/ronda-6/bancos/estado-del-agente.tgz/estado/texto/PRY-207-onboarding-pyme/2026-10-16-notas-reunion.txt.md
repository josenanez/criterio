<!-- origen: PRY-207-onboarding-pyme/2026-10-16-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión onboarding pyme — 2026-10-16
estuvieron: Beatriz Cuéllar, Diana Molina, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Rubén Cárdenas dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 12/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-26
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
