<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-12-20-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-04 | 2026-04-04 | cerrado
Ambiente de pruebas certificado | 2026-07-09 | 2026-07-09 | cerrado
Integración con el core | 2026-10-12 | 2026-10-12 | en curso
Piloto con usuarios internos | 2027-01-16 | 2027-01-16 | en curso
Salida a producción | 2027-04-22 | 2027-04-22 | en curso
