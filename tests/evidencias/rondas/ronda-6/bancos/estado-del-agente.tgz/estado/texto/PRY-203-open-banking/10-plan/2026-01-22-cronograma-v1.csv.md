<!-- origen: PRY-203-open-banking/10-plan/2026-01-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-15,2026-05-15,cerrado
Ambiente de pruebas certificado,2026-08-26,2026-08-26,cerrado
Integración con el core,2026-12-08,2026-12-08,en curso
Piloto con usuarios internos,2027-03-21,2027-03-21,en curso
