<!-- origen: PRY-209-nómina-electrónica/10-plan/2026-03-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-30,2026-05-30,cerrado
Ambiente de pruebas certificado,2026-08-19,2026-08-19,cerrado
Integración con el core,2026-11-08,2026-11-08,en curso
Piloto con usuarios internos,2027-01-28,2027-01-28,en curso
