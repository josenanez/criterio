<!-- origen: PRY-208-motor-de-decisión/10-plan/2026-05-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-10-19,2026-10-19,en curso
Ambiente de pruebas certificado,2027-03-01,2027-03-01,en curso
Integración con el core,2027-07-12,2027-07-12,en curso
Piloto con usuarios internos,2027-11-22,2027-11-22,en curso
