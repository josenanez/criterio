<!-- origen: PRY-199-renovación-de-cajeros-automáticos/10-plan/2026-06-08-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-10-05,2026-10-05,cerrado
Ambiente de pruebas certificado,2027-01-22,2027-01-22,en curso
Integración con el core,2027-05-11,2027-05-11,en curso
Piloto con usuarios internos,2027-08-28,2027-08-28,en curso
Salida a producción,2027-12-15,2027-12-15,en curso
