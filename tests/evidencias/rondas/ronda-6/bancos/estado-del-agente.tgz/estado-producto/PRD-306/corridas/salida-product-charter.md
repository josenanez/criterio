Términos: vigentes (versión 1.1, familia 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.

**Verificación previa (REQ-4600)**

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado» desde 2026-06-28 (comité 2026-10-14). Pero **no consta quién lo decidió** (`decision.who` = not_found). |
| Criterios de aceptación verificables | **Débil:** solo «se verifica en producción», que no es un criterio medible. |
| Evidencia de demanda con cita | **Débil:** una cita de cliente («Lo necesito y hoy no lo tengo.», entrevista 2025-10-05) que no nombra el requerimiento. |
| Autoridad declarada en la definición | **Falta.** El acta del comité no dice quién decide; «Comité de producto» es propuesto por defecto. |

Faltan la autoridad y quién decidió la aceptación; el criterio de aceptación y la evidencia son débiles. Respuesta sugerida tomada: seguir y marcarlos como vacíos del acta, sin rellenarlos.

---

# Acta de constitución — Microseguros (REQ-4600) · borrador del 2026-10-16
**Producto:** PRD-306 Microseguros · **Requerimientos:** REQ-4600

## Qué problema resuelve
«El segmento Personas no tiene microseguros.» (`documentos/productos/PRD-306/00-definicion/2025-12-25-definicion-producto.docx`, 2025-12-25). Segmento: Personas. La propuesta aparece como «Propuesta principal», sin descripción. El título del requerimiento es genérico («Requerimiento REQ-4600») y su necesidad (`need`) no está dicha en ninguna parte.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No dice cómo.** Sin métrica, umbral ni fecha, el cierre no se podrá juzgar. | comité 2026-10-14 |

El éxito del producto en la definición: **no dicho** (`definition.success` = not_found).

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 (doliente: Diana Molina) | Cita de cliente «Lo necesito y hoy no lo tengo.» (entrevistas 2025-10-05). No nombra el requerimiento; es la más cercana. 12 meses de antigüedad al 2026-10-16: en el límite del umbral de 12 meses. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4601 a REQ-4615 | Los otros 15 del registro | No se pidieron para esta acta. El comité del 2026-10-14 los lista sin proyecto que los ejecute. Esta acta no los cubre ni los descarta: quedan sin decisión de alcance. |

## Gobierno
**Patrocinador:** no dicho. · **Gerente propuesto:** no se nombra; la persona que designe quien tenga autoridad. Contexto: el gerente del producto es Jorge Medina (definición 2025-12-25) y el doliente de REQ-4600 es Diana Molina (comité 2026-10-14). · **Comité:** Comité de producto, propuesto por defecto; el acta no dice quién decide. · **Autoridad del gerente:** no dicha en ninguna parte.
La reunión del 2026-10-14 tuvo un solo asistente (Jorge Medina) y su única decisión fue «Se mantiene el plan».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-06-28 según el documento, aunque la definición es de 2025-12-25) | No | **Pendiente de doliente.** Se registra como riesgo del proyecto cuando exista gerente. Lleva más de 30 días sin verificar. Ningún proveedor ni contrato está identificado en los documentos del producto. |

También se lleva la cifra del caso de negocio: volumen_mensual 204.945 (2025-12-25). No hay tablero de métricas de PRD-306 que la contraste: **sin contrastar**.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Microseguros para personas (producto de seguros) | No se barrió. | — | **Sin barrido normativo.** No se afirma ni se descarta ninguna obligación; hay que hacerlo antes de firmar. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién decidió aceptar REQ-4600 | La aceptación no se puede atribuir ni defender. | Gerente de producto |
| Autoridad declarada | El gerente del proyecto no sabrá qué puede decidir: escala todo o no escala nada. | Comité de producto / gerente de producto |
| Criterio de éxito medible | El cierre no se podrá juzgar meses después. | Doliente (Diana Molina) con el gerente de producto |
| La necesidad (`need`) y la prioridad | Alcance sin razón escrita ni orden. | Gerente de producto |
| Evidencia de demanda propia de REQ-4600 | La demanda se apoya en una cita que no nombra el requerimiento. | Gerente de producto |
| Descripción de la propuesta | No hay qué construir descrito. | Gerente de producto |
| Patrocinador y presupuesto | No hay quién respalde ni con cuánto. | Quien tenga la autoridad |
| Hitos | La definición no declara ninguno. | Gerente del proyecto, en su plan |
| Fecha de la decisión | Registrada como 2026-06-28, pero el documento que la recoge es del 2026-10-14. | Gerente de producto |
| Contraste de la cifra 204.945 y barrido normativo | Una cifra sin contrastar y una obligación sin mirar. | Gerente de producto / jurídico |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (no está dicho quién es). La ficha del proyecto se crea después de la firma.

**Qué sigue:** nadie ha firmado, así que **no se creó la ficha** (paso 6). Tras la firma y la asignación de un gerente, esa persona instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
