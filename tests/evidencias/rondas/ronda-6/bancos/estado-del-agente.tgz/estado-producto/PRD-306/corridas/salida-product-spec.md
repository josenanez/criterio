> **Borrador del agente (Alba) — lo cierra Jorge Medina, gerente de producto, con el Comité de producto como autoridad.** Este agente no aprueba ni firma.

# Especificación — Microseguros (PRD-306) · borrador del 2026-10-16

**Lo primero que hay que saber:** el registro permite listar *qué* está aceptado, pero no *qué comportamiento* se pide. Los 12 requerimientos aceptados se llaman «Requerimiento REQ-46xx», ninguno tiene el problema que resuelve (`need: not_found`), y ninguno tiene prioridad. Por la regla de este comando —no rellenar con lo razonable— **no escribí la sección de comportamiento**: cualquier cosa que pusiera sería inventada por mí y quedaría como decisión de nadie.

Términos: aceptados por José Francisco Ñáñez para esta versión (0.3.12, términos 1.1), 2026-10-16. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12

## Qué problema resuelve

«El segmento Personas no tiene microseguros.» (definición de producto, 2025-12-25). La definición **no dice** qué es el éxito (`success: not_found`) y la propuesta es solo «Propuesta principal», sin descripción.

## Alcance

Sale del acta del comité de 2026-10-14. Solo se toman requerimientos en `aceptado` (no hay ninguno `en_construccion`).

### Entra (propuesto por el registro, sin decidir)
REQ-4600, 4602, 4603, 4604, 4605, 4606, 4608, 4610, 4612, 4613, 4614, 4615 — 12 aceptados.

### No entra
- **REQ-4601, 4607, 4609, 4611**: siguen en `propuesto`; nadie decidió nada. Especificarlos sería escribir el documento dos veces.
- Todo lo que no tiene requerimiento: no hay ninguno para canal, cobertura, emisión, reclamación, pagos, atención ni datos personales. El registro no los menciona; que no estén no significa que no hagan falta (ver Vacíos).
- Diseño técnico, estimación y fechas: no son de este documento.

## Comportamiento

**No redactado.** Los 12 requerimientos aceptados tienen `need: not_found` y solo el título genérico del acta. Citarlos aquí sin describir qué hacen sería una sección vacía con apariencia de completa. Para escribirla hace falta que cada doliente diga el problema en sus palabras (ver Vacíos, fila 1).

## Criterios de aceptación

El único criterio del registro es «se verifica en producción» (acta 2026-10-14). **No pasa la prueba:** no dice qué se mide ni contra qué valor, y dos personas mirando lo construido no llegan a la misma respuesta. No lo reescribí con una cifra porque la cifra la tiene que poner el doliente.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4600, 4602, 4603, 4604, 4605, 4608, 4610, 4612 | No definido: no nombra métrica, umbral ni quién verifica | No verificable todavía |
| *(sin criterio)* | REQ-4606, 4613, 4614, 4615 | — | — Falta el criterio |

Tampoco hay medición de base: el único dato cuantitativo del caso de negocio es «volumen_mensual 204.945» (declarado 2025-12-25) sin fuente medida ni metodología en los documentos.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (definición; declarado 2026-06-28, lleva ~110 días sin verificar, umbral 30). Nota: el documento es de 2025-12-25 pero el supuesto dice 2026-06-28; fecha inconsistente | No | Jorge Medina (propuesto; la definición no nombra dueño). No dice quién es el proveedor ni qué tiempo se pactó |
| El volumen mensual será 204.945 (caso de negocio, 2025-12-25) | No hay dato medido que lo contraste | Jorge Medina, con quien tenga la fuente del dato |

Ningún requerimiento aceptado trae supuestos propios registrados (`assumptions: []`); no significa que no los tengan.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| El problema (`need`) de cada uno de los 12 requerimientos aceptados | No se puede escribir comportamiento; se construiría lo que cada uno imagine | Cada doliente (ver tabla de abajo), con Jorge Medina |
| Criterio de aceptación verificable en los 12 (8 tienen uno no verificable; 4 no tienen) | El «¿quedó bien?» se discute después de construir | Cada doliente + Comité de producto |
| **REQ-4606, 4613, 4614, 4615**: sin criterio de aceptación estando `aceptado` | Aceptados sin poder saber cuándo están hechos | Natalia Ospina (4606), Camilo Beltrán (4613, 4615), Andrés Lozano (4614) |
| **REQ-4602**: sin doliente (acta: «sin asignar») | Nadie responde por su necesidad ni su criterio | Jorge Medina / Comité de producto asigna una persona |
| **REQ-4603, 4614, 4615**: sin evidencia de demanda; **los otros 9** solo tienen una cita genérica («Lo necesito y hoy no lo tengo», entrevista 2025-10-05, que no nombra el requerimiento y tiene ~12 meses) | Aceptados sin sustento de que alguien los pidió | Jorge Medina (realizó las entrevistas) |
| Proyecto que ejecuta cada requerimiento: el acta dice «—» en los 12; la definición dice «Ninguno declarado» | Lo decidido no tiene quién lo construya | Comité de producto / Jorge Medina (paso a `/product-charter` solo cuando haya criterio) |
| Quién decidió la aceptación: `decision.who` sin dato en los 12; el acta solo lista y dice «Se mantiene el plan» | La decisión no se puede atribuir ni auditar | Comité de producto |
| Casos borde (sin conexión, pago duplicado, cancelación a mitad de contratación, siniestro en curso): no definidos en ninguna parte | Cada equipo los resolverá distinto | Dolientes + quien construya |
| Éxito del producto (`success: not_found`) y retorno «en 24 meses» sin cifra | No hay contra qué comparar lo construido | Jorge Medina |
| Lo que otro equipo tiene que hacer: el proveedor aparece en un supuesto, pero no hay acuerdo escrito con él | Dependencia sin pactar | Jorge Medina |
| Obligaciones normativas: un producto de seguros para personas roza regulación de seguros, consumidor financiero y datos personales; **ningún documento las menciona ni las resuelve**. No hice el barrido citado, no opino sobre cumplimiento | Riesgo de construir algo que no se puede ofrecer | Jorge Medina con el área legal/cumplimiento (no nombrada en los documentos) |
| Prioridad de los 12 (`not_found`) | Sin orden de construcción | Jorge Medina |

## Requerimientos aceptados que esta especificación no cubre

Ninguno quedó cubierto en *comportamiento* (no hay base para escribirlo). En la tabla, qué falta por requerimiento:

| REQ | Título | Doliente | Por qué no |
|---|---|---|---|
| REQ-4600 | Requerimiento REQ-4600 | Diana Molina | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4602 | Requerimiento REQ-4602 | *(sin doliente)* | Sin doliente, sin necesidad; criterio no verificable |
| REQ-4603 | Requerimiento REQ-4603 | Natalia Ospina | Sin necesidad; sin evidencia; criterio no verificable |
| REQ-4604 | Requerimiento REQ-4604 | María Restrepo | Sin necesidad; criterio no verificable |
| REQ-4605 | Requerimiento REQ-4605 | Jorge Medina | Sin necesidad; criterio no verificable |
| REQ-4606 | Requerimiento REQ-4606 | Natalia Ospina | Sin necesidad; **sin criterio** |
| REQ-4608 | Requerimiento REQ-4608 | Beatriz Cuéllar | Sin necesidad; criterio no verificable |
| REQ-4610 | Requerimiento REQ-4610 | Felipe Arango | Sin necesidad; criterio no verificable |
| REQ-4612 | Requerimiento REQ-4612 | Beatriz Cuéllar | Sin necesidad; criterio no verificable |
| REQ-4613 | Requerimiento REQ-4613 | Camilo Beltrán | Sin necesidad; **sin criterio** |
| REQ-4614 | Requerimiento REQ-4614 | Andrés Lozano | Sin necesidad; **sin criterio; sin evidencia** |
| REQ-4615 | Requerimiento REQ-4615 | Camilo Beltrán | Sin necesidad; **sin criterio; sin evidencia** |

Nota: los títulos son genéricos porque así vienen del acta; el agente no inventó nombres descriptivos.

---
**Pie:** sale del registro `estado-producto/PRD-306/requirements/` (16 requerimientos: 12 aceptados, 4 propuestos), construido sobre el acta del comité de 2026-10-14, la definición y el caso de negocio de 2025-12-25 y las entrevistas de 2025-10-05. Cubre 12 requerimientos en alcance, 0 en comportamiento. Borrador: lo cierra Jorge Medina; este agente no firma. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.12

**Después:** `/product-charter` no se ofrece todavía: no hay vacíos cerrados ni un requerimiento con criterio de éxito verificable.
