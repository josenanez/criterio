# Corrida del 2026-10-16 · product-trace

PRD-306 · 16 requerimientos · 37 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 12 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

12 decididos sin proyecto; ninguna ficha nombra PRD-306

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Microseguros (PRD-306) · al 2026-10-16
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Una cadena que se rompe en el primer eslabón después de la decisión: ningún requerimiento aceptado nombra proyecto. El acta del comité (`documentos/productos/PRD-306/30-decisiones/2026-10-14-comite-producto.docx`) dice «—» en la columna de proyecto para cada uno.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4603 | Requerimiento REQ-4603 | 2026-04-19 | no está dicho en el acta (Comité de producto, sin nombre) |
| REQ-4602 | Requerimiento REQ-4602 (sin doliente) | 2026-05-19 | no está dicho en el acta |
| REQ-4604 | Requerimiento REQ-4604 | 2026-05-26 | no está dicho en el acta |
| REQ-4612 | Requerimiento REQ-4612 | 2026-06-25 | no está dicho en el acta |
| REQ-4615 | Requerimiento REQ-4615 | 2026-06-26 | no está dicho en el acta |
| REQ-4600 | Requerimiento REQ-4600 | 2026-06-28 | no está dicho en el acta |
| REQ-4613 | Requerimiento REQ-4613 | 2026-07-02 | no está dicho en el acta |
| REQ-4605 | Requerimiento REQ-4605 | 2026-07-17 | no está dicho en el acta |
| REQ-4608 | Requerimiento REQ-4608 | 2026-07-22 | no está dicho en el acta |
| REQ-4614 | Requerimiento REQ-4614 | 2026-08-01 | no está dicho en el acta |
| REQ-4610 | Requerimiento REQ-4610 | 2026-08-09 | no está dicho en el acta |
| REQ-4606 | Requerimiento REQ-4606 | 2026-08-23 | no está dicho en el acta |

Los 12 llevan entre 54 y 180 días decididos sin proyecto. Los más antiguos: REQ-4603 (180 días), REQ-4602 (150), REQ-4604 (143). Los títulos son genéricos porque el acta no los da; hay que ir al acta para saber qué se decidió construir.

Para tener en cuenta al priorizar cuáles llevar a acta de constitución: 3 de estos 12 no tienen evidencia de demanda (REQ-4603, REQ-4614, REQ-4615), 4 no tienen criterio de aceptación (REQ-4606, REQ-4613, REQ-4614, REQ-4615), y 9 apoyan su evidencia en una sola entrevista del 2025-10-05, que no los nombra y ya cumple 12 meses.

### La traza no se confirma
No hay trazas declaradas que confirmar: ningún REQ dice ejecutarlo un proyecto, así que no hay nada que contrastar contra una ficha. Ninguna traza se da por confirmada.

### Lo que un proyecto construye y el registro no tiene
Ninguno encontrado. Se revisaron las 13 fichas de proyecto (PRY-199 a PRY-211): ninguna nombra PRD-306 ni Microseguros. Las que declaran producto dicen otros (PRD-299, cuenta de ahorros, APIs de datos, cuenta PyME, nómina empresarial, recaudos, crédito de consumo, tarjeta débito, pagos QR) y cuatro lo dejan vacío (PRY-202, PRY-205, PRY-208, PRY-210). Esos vacíos son un hallazgo del lado del proyecto, no de este producto; pero significa que no se puede descartar que alguno de ellos esté construyendo algo de Microseguros.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 12 aceptados (REQ-4600 a REQ-4615, salvo los propuestos) | aceptado | acta 2026-10-14 | — | no | — |
| REQ-4601, 4607, 4609, 4611 | propuesto | sin decisión (111 a 197 días) | — | no aplica | — |

### Sin fichas a la vista
Las fichas están (13 de 13, en `estado/records`). Lo que falta es lo contrario: ninguna de ellas apunta a este producto, así que no hay ficha contra la cual confirmar.

### Aparte
Un supuesto sin verificar sostiene el producto: «El proveedor cumple el tiempo pactado», 110 días sin verificarse.

### Después
Hay decididos sin proyecto: `/product-charter` para el que ya esté listo para serlo (los candidatos con evidencia y criterio de aceptación son REQ-4600, 4602, 4604, 4605, 4608, 4610 y 4612; REQ-4602 además sin doliente).
