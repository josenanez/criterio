# Corrida del 2026-10-16 · product-requirements

PRD-306 · 16 requerimientos · 29 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 12 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

3 aceptados sin evidencia (REQ-4603, 4614, 4615); 12 aceptados sin proyecto; 4 propuestos sin decidir hace más de 60 días; 1 sin doliente; 4 sin criterio de aceptación

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

## Registro — Microseguros (PRD-306) · al 2026-10-16
16 requerimientos · 12 decididos · 75% con evidencia (9 de 12) · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4603 | Requerimiento REQ-4603 | aceptado el 2026-04-19 | Natalia Ospina |
| REQ-4614 | Requerimiento REQ-4614 | aceptado el 2026-08-01 | Andrés Lozano |
| REQ-4615 | Requerimiento REQ-4615 | aceptado el 2026-06-26 | Camilo Beltrán |

Ninguno tiene una sola cita de quien lo pidió. REQ-4614 y REQ-4615 además no tienen criterio de aceptación.

### Decidido y nadie lo está construyendo
Los 12 aceptados: el acta del comité del 2026-10-14 dice «—» en proyecto para todos.

| REQ | Decidido el | Doliente |
|---|---|---|
| REQ-4603 | 2026-04-19 | Natalia Ospina |
| REQ-4615 | 2026-06-26 | Camilo Beltrán |
| REQ-4602 | 2026-05-19 | sin doliente |
| REQ-4604 | 2026-05-26 | María Restrepo |
| REQ-4600 | 2026-06-28 | Diana Molina |
| REQ-4612 | 2026-06-25 | Beatriz Cuéllar |
| REQ-4613 | 2026-07-02 | Camilo Beltrán |
| REQ-4605 | 2026-07-17 | Jorge Medina |
| REQ-4608 | 2026-07-22 | Beatriz Cuéllar |
| REQ-4614 | 2026-08-01 | Andrés Lozano |
| REQ-4610 | 2026-08-09 | Felipe Arango |
| REQ-4606 | 2026-08-23 | Natalia Ospina |

Quién lo cerraría: Jorge Medina (gerente de producto) con el Comité de producto, abriendo proyecto o declarando que no se hace. Es el paso de `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4602 | Requerimiento REQ-4602 | no dice (aceptado el 2026-05-19) |

Lo cierra Jorge Medina nombrando a una persona. No hay ningún caso de área en lugar de persona.

### Sin criterio de aceptación
Solo decididos.

| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4606 | Requerimiento REQ-4606 | aceptado | Natalia Ospina |
| REQ-4613 | Requerimiento REQ-4613 | aceptado | Camilo Beltrán |
| REQ-4614 | Requerimiento REQ-4614 | aceptado | Andrés Lozano |
| REQ-4615 | Requerimiento REQ-4615 | aceptado | Camilo Beltrán |

Cada doliente lo cierra con el gerente de producto. Los propuestos no se cuentan, por regla.

### Decidido sin documento que lo respalde
Los 12 aceptados citan el acta del comité del 2026-10-14. Lo que falta es quién decidió: en ninguna ficha el acta lo nombra.

| REQ | Quién decidió | Cuándo |
|---|---|---|
| Los 12 aceptados (REQ-4600, 4602 a 4606, 4608, 4610, 4612 a 4615) | no consta en el acta | fechas arriba |

Lo que consta es una fecha de decisión anterior al acta (entre 2026-04-19 y 2026-08-23) y un acta fechada el 2026-10-14. Hay que confirmar si el acta recoge decisiones tomadas antes o las registra tarde. La confirma el secretario del Comité de producto.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4609 | Requerimiento REQ-4609 | 197 días (2026-04-02) | Comité de producto |
| REQ-4601 | Requerimiento REQ-4601 | 154 días (2026-05-15) | Comité de producto |
| REQ-4607 | Requerimiento REQ-4607 | 143 días (2026-05-26) | Comité de producto |
| REQ-4611 | Requerimiento REQ-4611 | 111 días (2026-06-27) | Comité de producto |

La facultad es del Comité de producto, que sesiona cada mes. Se propone decidirlos en la próxima sesión (aceptar o descartar); no se cierran por viejos. REQ-4609 no tiene ni evidencia ni criterio, lo cual es normal en un propuesto.

### Evidencia vieja
Umbral: 12 meses. En los 12 la única evidencia es la entrevista del 2025-10-05 («Lo necesito y hoy no lo tengo»), y el registro advierte que esa entrevista no nombra el requerimiento: es la más cercana, no una cita directa.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4600, 4601, 4602, 4604, 4605, 4606, 4607, 4608, 4610, 4611, 4612, 4613 | 2025-10-05, entrevistas | 12 meses |

### Además, de la definición
- Supuesto sin verificar: «El proveedor cumple el tiempo pactado», 110 días sin verificar (umbral 30).
- Afirmación del caso de negocio: volumen mensual declarado de 204.945 (2025-12-25), sin medición contra la cual contrastarlo.
- Criterio de éxito del producto: no está dicho en ninguna parte.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 12 | 0 | 0 | 0 |

Nada descartado: ningún requerimiento tiene registrada una decisión de no hacerlo.

### Siguiente paso
Hay 12 decididos que nadie construye: `/product-trace`. Ningún aceptado reúne a la vez evidencia directa, criterio y doliente con evidencia fresca, así que por ahora no hay candidato claro para `/product-charter`.
