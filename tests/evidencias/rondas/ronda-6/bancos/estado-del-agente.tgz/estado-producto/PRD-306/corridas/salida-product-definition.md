## Definición — Microseguros (PRD-306) · contrastada al 2026-10-16
**Documento:** 00-definicion/2025-12-25-definicion-producto.docx (más el caso de negocio 00-definicion/2025-12-25-caso-de-negocio.md) · **del** 2025-12-25 · 6 afirmaciones

Términos: vigentes (versión 1.1), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición.

### El negocio y los datos
Nada pasa del umbral (20 %): no hay ninguna métrica medida contra la cual comparar.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 204.945 | Caso de negocio, 2025-12-25 | Nadie mide el volumen mensual: no hay serie en ninguna fuente. No es una contradicción; es que la cifra que sostiene el caso no tiene nada contra qué contrastarse. |
| «Retorno esperado en 24 meses» | Caso de negocio, 2025-12-25 | Sin cifra, sin base de cálculo y sin serie. Ni siquiera se puede medir. |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo dice (`success` queda en `unknown`).
- **Qué es la propuesta:** la definición dice solo «Propuesta principal», sin descripción.
- **Qué proyecto lo construye:** la definición dice «Ninguno declarado»; los 12 requerimientos aceptados tampoco tienen proyecto.
- **Cuánto es el mercado de Personas** y cuántos clientes lo quieren: la definición nombra al segmento, pero ningún documento lo dimensiona.
- **Cuál es el tiempo pactado con el proveedor, quién es el proveedor y dónde consta el pacto:** el supuesto lo usa y nadie lo define.
- **Qué mide el «retorno esperado» y cómo se calcula.**
- **Quién decide:** el acta del comité del 2026-10-14 no lo dice; «Comité de producto» está propuesto por defecto.
- **Qué plan «se mantiene»:** la única decisión del comité (2026-10-14) es «Se mantiene el plan», y ningún documento del producto contiene ese plan.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-06-28 en un documento fechado 2025-12-25) | 110 (umbral 30) | El contrato o acuerdo de nivel de servicio con el plazo escrito, y el registro de entregas del proveedor contra ese plazo. Sin el contrato no hay con qué contrastar. Además, la fecha del supuesto es posterior a la del documento: alguien lo editó sin actualizar la fecha. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Personas no tiene microseguros» | Una entrevista: un cliente sin nombre dice «Lo necesito y hoy no lo tengo.» (10-descubrimiento/2025-10-05-entrevistas.md) | 2025-10-05 | Débil. Es alguien que dijo que lo necesita, no alguien que pagó ni que pidió. Es una sola persona, y la entrevista no dice que sea del segmento Personas. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| «El segmento Personas no tiene microseguros» (y los 12 requerimientos cuya evidencia más cercana es esa misma entrevista) | Entrevista del 2025-10-05 | 12 meses (umbral 12): ya cruzó. No hay nada posterior. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Un seguro vendido a personas toca la regulación de seguros y la de protección al consumidor financiero, y probablemente datos personales | No declarado: ningún documento dice el país | No la puedo nombrar sin país | — | **No tengo la norma a la vista.** Esto no es un cumplimiento ni un incumplimiento. Va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** el acta no lo dice.
- **Problema y para quién:** están escritos (un enunciado cada uno), pero apoyados en una sola entrevista de hace 12 meses.
- La definición no se puede cerrar hoy.

### Después
El supuesto del proveedor lleva 110 días sin verificar. Se puede pasar al registro de riesgos con un doliente (raid-taxonomy). La definición no está cerrada, así que no corresponde `/product-charter`.
