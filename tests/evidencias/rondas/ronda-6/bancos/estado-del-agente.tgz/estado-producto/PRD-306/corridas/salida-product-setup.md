## Listo — Microseguros (PRD-306)

**Lo que miré:** 4 documentos · 1 de descubrimiento (una entrevista, 2025-10-05) · la definición y el caso de negocio del 2025-12-25 · el acta del comité de producto del 2026-10-14 (lo más reciente). Formatos que no pude leer: ninguno (2 .docx, 2 .md). No hay serie medida de ninguna métrica.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.12 (términos 1.1), 2026-10-16 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.12-2026-10-16.md` y `.pdf` · SHA-256 bbc944aafa669a5067d0a907591a89f40c0b0d00c37cb1e1b054d8f9862c5919 (md) · 089f4fb48989f62fa2f9978ef3a7dce58e82d169a9c7fdce42a23875e81d4c51 (pdf)

**Lo que quedó configurado (respuestas por defecto, sin interlocutor):** gerente Jorge Medina (definición) · quien decide: Comité de producto (propuesto; el acta no dice quién decide, hay que confirmarlo) · estado en `estado-producto/PRD-306` · ficha y 16 requerimientos levantados de lo escrito.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Personas no tiene microseguros» | Nada que lo diga del segmento. Lo más cercano: un cliente sin nombre dijo «Lo necesito y hoy no lo tengo» sin decir qué es «lo» | 2025-10-05 |
| Volumen mensual de 204.945 | Solo el propio caso de negocio; no hay serie medida | 2025-12-25 |
| «Retorno esperado en 24 meses» | Nada: sin cifra, sin base | 2025-12-25 |
| «El proveedor cumple el tiempo pactado» | Un supuesto sin verificar, declarado el 2026-06-28 (110 días) | 2026-06-28 |

### Lo que no está dicho en ninguna parte
- Que el segmento Personas lo necesite: hay una entrevista, de una persona sin nombre, que no menciona microseguros ni el segmento.
- El criterio de éxito del producto: no hay ninguno escrito.
- En qué consiste la propuesta: el documento dice «Propuesta principal» y nada más.
- De dónde sale el 204.945 mensual, y cuánto se mide hoy: no hay serie, así que nadie está midiendo lo que el caso de negocio afirmó.
- Cuánto es el retorno esperado y con qué se calculó.
- Quién decide qué se construye: el acta lista asistentes (solo Jorge Medina) pero no dice quién decidió cada aceptación.
- Los 16 requerimientos del acta (REQ-4600 a REQ-4615) no tienen título ni descripción del problema: solo el número.
- Qué proyecto ejecuta cada uno: ninguno declarado (0 de 12 aceptados con traza, 0.0 %).

### Lo que el registro ya muestra (cifras de `compute`)
- 16 requerimientos: 12 aceptados, 4 propuestos. La entrevista de 2025-10-05, que ninguna parte del acta nombra, es toda la evidencia: 9 de los 12 aceptados tienen alguna evidencia (75.0 %), y las 9 tienen 12 meses, el umbral de vencimiento. Esa evidencia no nombra ningún requerimiento.
- 3 aceptados sin evidencia alguna: REQ-4603, REQ-4614, REQ-4615.
- 4 aceptados sin criterio de aceptación: REQ-4606, REQ-4613, REQ-4614, REQ-4615. En los demás el criterio es «se verifica en producción», que no dice qué se mide.
- 1 aceptado sin doliente: REQ-4602 («sin asignar»).
- 4 propuestos sin decisión desde hace 111 a 197 días: REQ-4609 (197), REQ-4601 (154), REQ-4607 (143), REQ-4611 (111).
- 12 aceptados sin proyecto que los ejecute.
- Supuesto sin verificar: 1, hace 110 días. Nota: el documento es de 2025-12-25 pero el supuesto dice «declarado el 2026-06-28»: el documento fue editado después de su fecha.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», sin verificar.

### Qué le falta a tu carpeta
- Las transcripciones de más entrevistas, con nombre de quien habla y qué pide: hoy hay una.
- La serie del volumen mensual con su fuente, para contrastar el 204.945.
- El acta de decisión de cada aceptado con quién decidió; sin ella, un descartado se vería igual que uno que nadie miró.
- Qué proyecto ejecuta cada aceptado.

### Lo que no hice
No se preguntó nada: todas las respuestas son las propuestas por defecto (autoridad y ubicación del estado incluidas). Mi lectura del acta como decisión «aceptado» usa la fecha «Desde» como fecha de decisión.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas.
