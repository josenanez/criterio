## Microseguros (PRD-306) · 2026-10-16

**Términos:** ya vigentes (versión 1.1, familia 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16. No hubo que pedirlos de nuevo.

**Qué tocaba:** `review` (nunca se había corrido). `crossed` no aplica: no existía corte anterior, así que esta corrida **fija la línea base** y no reporta "señales nuevas". Desde la próxima corrida solo se reportará lo que cruce un umbral después de hoy.

### Revisión del registro contra la carpeta
- 4 documentos en la carpeta, 4 sin cambios desde la última lectura; nada que releer, ningún renombrado ni borrado. Lo más reciente es el acta del comité del 2026-10-14.
- El índice marca 8 campos con `source_missing` (las fuentes de identidad, problema, quién, propuesta, supuesto y autoridad). Los archivos citados existen en disco; parece un desajuste de ruta entre la cita y la carpeta, no documentos perdidos. No lo he resuelto: conviene que alguien lo confirme.
- Descubrimiento y definición: sin documentos nuevos, así que no ofrezco `/product-discovery` ni `/product-definition`.

### Las trazas
**Ninguna se puede dar por confirmada.** Usé como carpeta de fichas `estado/records` (13 fichas de proyecto, PRY-199 a PRY-211); ninguna nombra PRD-306 ni "Microseguros". Resultado: 0 de 12 requerimientos aceptados tienen proyecto (0 %). No hay ninguna traza que haya dejado de decirse, porque ninguna se había dicho.

### Estado de base (16 requerimientos: 12 aceptados, 4 propuestos)
**Necesitan decisión del comité**
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4609 | 197 días (desde 2026-04-02) | Decisión; además no tiene evidencia ni criterio de aceptación | Diana Molina (doliente) |
| Sin decidir | REQ-4601 | 154 días | Decisión | Laura Vélez |
| Sin decidir | REQ-4607 | 143 días | Decisión | Laura Vélez |
| Sin decidir | REQ-4611 | 111 días | Decisión | Jorge Medina |
| Supuesto sin verificar | «El proveedor cumple el tiempo pactado» | 110 días (umbral 30) | Qué haría falta: evidencia del cumplimiento del proveedor, o tratarlo como riesgo registrado (assumption-tracking). | — |

El acta del comité no dice quién tiene la facultad de decidir; "Comité de producto" quedó como autoridad propuesta por defecto. Ese es el dato que falta para los cuatro.

**Aceptado sin sustento**
- Sin evidencia de demanda: REQ-4603, REQ-4614, REQ-4615.
- Sin criterio de aceptación: REQ-4606, REQ-4613, REQ-4614, REQ-4615.
- Sin doliente: REQ-4602.
- Aceptados que nadie construye (sin proyecto): los 12.

**Evidencia vencida (12 requerimientos):** toda la evidencia es una sola entrevista del 2025-10-05, que cumple 12 meses; además la propia cita dice que no nombra el requerimiento (es "la más cercana"). La definición se queda sin sustento de demanda actual.

**Definición:** el criterio de éxito no está en ningún documento. La cifra declarada de volumen mensual (204.945, caso de negocio de 2025-12-25) no tiene medición con la que contrastarla.

**Vuelvo el 2026-11-15.**
