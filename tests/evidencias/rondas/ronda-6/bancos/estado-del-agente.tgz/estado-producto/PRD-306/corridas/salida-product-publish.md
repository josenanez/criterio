**No publiqué la ficha de PRD-306 (Microseguros): no hay carpeta de productos publicados.**

La configuración (`.criterio/producto/PRD-306/config.json`) solo define `documents` y `state`, y en el espacio no existe ninguna carpeta `publicados`. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ni inventé una ruta.

Términos: ya vigentes (versión 0.3.12), aceptados por José Francisco Ñáñez el 2026-10-16. No hizo falta registrarlos de nuevo.

**Lo que habría publicado (corte al 2026-10-16):**
- Requerimientos: 16 (12 aceptados, 4 propuestos), todos sin proyecto asignado
- Proyectos: 0
- Métricas afirmadas: 1
- Segmento declarado: Segmento Personas
- Métrica: `volumen_mensual` = 204945, de `documentos/productos/PRD-306/00-definicion/2025-12-25-caso-de-negocio.md` (2025-12-25)

**Para publicar:** acordar y configurar la carpeta común de productos publicados. Cuando exista, vuelve a correr `/product-publish` y escribirá `PRD-306.json` ahí.
