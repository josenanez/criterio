# Corrida del 2026-10-16 · product-business-case

PRD-306 · 16 requerimientos · 35 s · 37 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 12 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador del caso de negocio de Microseguros: 1 cifra declarada sin base (volumen_mensual 204.945), ninguna medida, retorno sin cifra. No hay costos en ningún documento. Sin criterio de éxito. No sé quién produjo la cifra ni qué proveedor ni qué plazo; no hay fichas publicadas de otros productos para cruzar.

Contra la corrida del 2026-10-16: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Microseguros (PRD-306) · borrador del 2026-10-16
**Desde:** la definición del 2025-12-25 y el caso de negocio del 2025-12-25 · **Cifras con fuente:** 1 de 2 (la otra es una frase sin cifra)

Términos: vigentes (versión 1.1), aceptados por José Francisco Ñáñez el 2026-10-16; no hizo falta registrarlos de nuevo.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Personas no tiene microseguros.» (00-definicion/2025-12-25-definicion-producto.docx, 2025-12-25)
- **Para quién:** Segmento Personas (misma fuente).
- **Qué respalda el problema:** una sola entrevista de un cliente sin nombre: «Lo necesito y hoy no lo tengo.» (10-descubrimiento/2025-10-05-entrevistas.md, 2025-10-05). Es evidencia débil, de 12 meses (umbral 12), y la entrevista no dice que sea del segmento Personas.
- **Propuesta:** la definición dice solo «Propuesta principal», sin descripción.

## Qué se construye
12 requerimientos aceptados de 16; 4 siguen propuestos y no entran al caso. Fuente del estado: 30-decisiones/2026-10-14-comite-producto.docx (2026-10-14). Ninguno tiene proyecto que lo ejecute (el acta dice «—» en los 16).

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4600, 4604, 4605, 4608, 4610, 4612 | aceptado | «Cliente entrevistado» (entrevista del 2025-10-05, la más cercana; no nombra el requerimiento) |
| REQ-4602 | aceptado, sin doliente | ídem |
| REQ-4606, 4613 | aceptado, sin criterio de aceptación | ídem |
| REQ-4603 | aceptado | **Nadie lo pidió** (acta: «—») |
| REQ-4614, 4615 | aceptado, sin criterio de aceptación | **Nadie lo pidió** (acta: «—») |

Quién decidió los 12 aceptados no consta en el acta (la única decisión escrita es «Se mantiene el plan»).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 204.945 | **Declarada** (no dice quién la calculó ni con qué base) | Caso de negocio, 00-definicion/2025-12-25-caso-de-negocio.md | 2025-12-25 |
| Retorno esperado | «en 24 meses», sin cifra | **Supuesta**: ninguna cifra ni base de cálculo | Caso de negocio, mismo documento | 2025-12-25 |
| El proveedor cumple el tiempo pactado | sin plazo | **Supuesta** (declarada el 2026-06-28 en un documento fechado 2025-12-25; sin verificar) | Definición, 2025-12-25 | 2025-12-25 |

No hay ninguna cifra **medida**.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 204.945 (2025-12-25) | **No existe serie.** Nadie mide el volumen de este producto. | Sin comparación posible; no es una contradicción, es una cifra sin nada contra qué contrastarse |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — (primer vacío) |
| Costo del equipo | No declarado | — |
| Contratos o cotizaciones del proveedor | No hay | — |

Sin costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (110 días sin verificar; umbral 30) | Los plazos del caso dejan de valer; no se sabe cuáles, porque el tiempo pactado no está escrito | Jorge Medina, con el contrato o acuerdo de nivel de servicio y el registro de entregas |
| El volumen mensual de 204.945 es alcanzable (implícito, sin base) | Todo ingreso derivado cae con él | El negocio: quien produjo la cifra |
| El segmento Personas quiere el producto (una entrevista, 12 meses) | No hay demanda que sostenga los 12 requerimientos | Jorge Medina, con entrevistas nuevas |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso | Jorge Medina con finanzas |
| Base y cálculo del volumen de 204.945 | Es la única cifra y no tiene origen | Quien la declaró; Jorge Medina como firmante del documento |
| Qué mide el «retorno» y su cifra | «Retorno esperado en 24 meses» no se puede verificar | El negocio |
| Tamaño del mercado de Personas | Nadie dimensiona el segmento | Quien tenga la fuente (negocio / mercadeo) |
| Qué pasa si no se hace | No está dicho | Comité de producto |
| Alternativas consideradas | No está dicho | Comité de producto |
| Criterio de éxito y fecha de corte | Sin él el producto no se puede cerrar | Jorge Medina, aprobado por el Comité |
| Plazo pactado, proveedor y dónde consta el pacto | El supuesto lo usa y nadie lo define | Jorge Medina |
| País y marco normativo | El caso toca seguros y consumidor financiero, sin país no se puede nombrar la norma; va a revisión jurídica | Jurídico |
| Quién decide | El acta no lo dice; «Comité de producto» está propuesto por defecto | Secretario del Comité |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento define el criterio de éxito, su métrica ni su fecha de corte. Mientras no exista, el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguna ficha publicada. Revisé los documentos de los otros productos de la carpeta (PRD-299 a PRD-309): ninguno afirma el valor 204.945. Las demás coincidencias son solo el nombre de la métrica `volumen_mensual`, no su valor. Sin cifras repetidas, no hay suma doble que señalar hoy.

## Después
Los supuestos pueden pasar al seguimiento con assumption-tracking (el del proveedor lleva 110 días). No corresponde `/product-charter`: el caso no tiene costos, criterio de éxito ni cifra con base.

Este borrador no recomienda aprobar ni rechazar y no calcula retorno ni rentabilidad: decide el Comité de producto.
