# Corrida · 2026-10-16-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:51:17 · **Fin:** 2026-10-16T14:52:14 · **Duración:** 58 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 38 | 21 | Dos escalamientos: autoridad no declarada en el acta, y documento 1 con seis reprogramaciones. No sé qué alimenta el documento 1 ni los días por hito; costos de las opciones no declarados en los documentos. |

Por señal (`pm-escalate`): `commitment_overdue` 8, `commitment_undated` 6, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `variance_time` 1, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Terminé el paquete de escalamiento de PRY-207 y registré la corrida. Quedó en `estado/PRY-207-onboarding-pyme/corridas/salida-pm-escalate.md`.

Los términos ya estaban vigentes (versión 0.3.12, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo. No hubo argumento, así que escalé lo que la ficha marca como escalable. Escalan dos puntos.

1. **Autoridad de la gerente.** El acta no declara qué puede decidir Beatriz Cuéllar sin pasar por el comité. Por eso es el primer punto, y también explica por qué CC-01 dice «autorizada por el comité» sin nombrar cuál ni quién.
   - **Pregunta:** ¿se declara la autoridad en una adenda al acta, o todo cambio va al comité?
   - **Recomendación:** la adenda.

2. **Documento 1 de Rubén Cárdenas.** Lleva seis reprogramaciones, la última al 2026-12-12, sin evidencia de entrega.
   - **Pregunta:** ¿se mantiene con Rubén, se reasigna o se parte en entregas parciales con fecha?
   - **Recomendación:** entregas parciales, con la primera antes del 2026-12-08.

- **Lo que no sé:** ningún documento dice si el documento 1 alimenta «Integración con el core» (2026-12-08). Tampoco dicen cuánto cuesta cada opción ni cuántos días se mueve cada hito. Lo dejé escrito como «no declarado» y no lo inventé.
- **Impacto en otros proyectos:** el cálculo no devuelve ninguno, y el acta declara «Ninguna» como dependencias. Eso solo prueba que nadie las declaró, no que no existan.
- **Sobre el cálculo de fechas:** corrí +4 días (12/12 contra el hito del 08/12) y +77 días. Ese +77 es un segundo cambio hipotético de ese tamaño, no CC-01, que ya está en la línea base vigente.
- **Sin escalar:** el riesgo del proveedor, que Beatriz puede registrar ella misma, y los compromisos vencidos que se destraban con una llamada o con el acta de recibo.

Llevar el paquete al comité es tuyo; el comando no se lo envió a nadie.
