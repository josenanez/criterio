# Corrida · 2026-10-16-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:37:45 · **Fin:** 2026-10-16T14:38:30 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 16 | — | 29 | 37 | 3 aceptados sin evidencia (REQ-4603, 4614, 4615); 12 aceptados sin proyecto; 4 propuestos sin decidir hace más de 60 días; 1 sin doliente; 4 sin criterio de aceptación |

Por señal (`product-requirements`): `evidence_stale` 12, `requirement_untraced` 12, `requirement_undecided` 4, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

El registro de Microseguros (PRD-306) está listo y la corrida quedó guardada como `2026-10-16-product-requirements-1`. Salieron 37 hallazgos en 29 segundos. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta registrarlos otra vez.

**Estado:** hay 16 requerimientos: 12 aceptados y 4 propuestos. El 75 % de lo decidido tiene evidencia (9 de 12) y el 0 % tiene un proyecto que lo ejecute.

**Por orden de lectura:**
1. **Se va a construir y nadie lo pidió:** REQ-4603, REQ-4614 y REQ-4615 están aceptados sin ninguna evidencia.
2. **Decidido y nadie lo construye:** los 12 aceptados. El acta del comité del 2026-10-14 dice «—» en proyecto para todos.
3. **Sin doliente:** REQ-4602.
4. **Sin criterio de aceptación:** REQ-4606, REQ-4613, REQ-4614 y REQ-4615.
5. **Sin decidir hace más de 60 días:** REQ-4609 (197 días), REQ-4601 (154), REQ-4607 (143) y REQ-4611 (111). La facultad de decidir es del Comité de producto.
6. **Evidencia vieja:** en 12 requerimientos la única evidencia es la entrevista del 2025-10-05, que no nombra ninguno de ellos.

También quedaron un supuesto sin verificar hace 110 días («El proveedor cumple el tiempo pactado»), un volumen mensual declarado sin medición y un criterio de éxito que no está en ningún documento.

En los 12 aceptados, el acta cita el documento pero no dice quién decidió. Lo dejé señalado para confirmar con el comité. Nada está descartado ni en construcción.

El siguiente paso es `/product-trace` para los 12 sin proyecto. Todavía no hay un aceptado con evidencia fresca y criterio que sirva para `/product-charter`.

La salida completa está en `/home/claude/banco/ronda-6/bancos/espacio/estado-producto/PRD-306/corridas/salida-product-requirements.md`.
