# Corrida · 2026-10-16-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:39:28 · **Fin:** 2026-10-16T14:40:18 · **Duración:** 51 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 16 | — | 35 | 37 | Borrador del caso de negocio de Microseguros: 1 cifra declarada sin base (volumen_mensual 204.945), ninguna medida, retorno sin cifra. No hay costos en ningún documento. Sin criterio de éxito. No sé quién produjo la cifra ni qué proveedor ni qué plazo; no hay fichas publicadas de otros productos para cruzar. |

Por señal (`product-business-case`): `evidence_stale` 12, `requirement_untraced` 12, `requirement_undecided` 4, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

El borrador del caso de negocio de Microseguros (PRD-306) está hecho y la corrida quedó registrada. El caso no se sostiene todavía. Solo tiene una cifra con fuente, el volumen mensual de 204.945, y esa cifra no dice cómo se calculó. No hay costos, ni criterio de éxito, ni cifra de retorno.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-16), así que no hizo falta registrarlos de nuevo.

- **Cifras:**
  - El volumen mensual de 204.945 es una cifra declarada, del caso de negocio del 2025-12-25. Nadie lo mide: no hay serie contra la cual compararlo.
  - El retorno dice solo «esperado en 24 meses», sin cifra ni base de cálculo.
  - No hay ninguna cifra medida.
- **Costos:** el costo de construir no aparece en ningún documento. Es el primer vacío, y sin él lo que hay es una propuesta, no un caso.
- **Qué se construye:** hay 12 requerimientos aceptados y 4 propuestos. Ninguno tiene proyecto que lo ejecute. Tres aceptados no tienen evidencia de quién los pidió (REQ-4603, 4614 y 4615).
- **Demanda:** el problema se apoya en una sola entrevista de hace 12 meses (2025-10-05), de un cliente sin nombre.
- **Supuesto del proveedor:** «el proveedor cumple el tiempo pactado» lleva 110 días sin verificar (el umbral es 30). El plazo pactado no está escrito en ninguna parte.
- **Cómo se sabrá si funcionó:** no hay criterio de éxito ni fecha de corte en ningún documento.
- **Otros productos:** no hay fichas publicadas. Revisé los documentos de PRD-299 a PRD-309 y ninguno afirma 204.945, así que no hay cifra contada dos veces.

No recomiendo aprobar ni rechazar, y no calculé retorno ni rentabilidad. No corresponde `/product-charter` todavía. Los supuestos pueden pasar al seguimiento con assumption-tracking.

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-business-case.md`
- `2026-10-16-product-business-case-1.md`
