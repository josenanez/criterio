# Corrida · 2026-10-16-product-spec-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-spec (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:40:24 · **Fin:** 2026-10-16T14:41:22 · **Duración:** 58 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-spec` | 16 | — | 40 | 37 | Borrador de especificación PRD-306: 12 aceptados en alcance, 4 propuestos fuera; comportamiento no redactado porque need=not_found en los 12; criterio 'se verifica en producción' no verificable (8) y ausente (4); sin doliente REQ-4602; sin proyecto en ninguno; supuesto del proveedor sin verificar y con fecha inconsistente; obligaciones normativas sin documento, sin barrido citado. |

Por señal (`product-spec`): `evidence_stale` 12, `requirement_untraced` 12, `requirement_undecided` 4, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Escribí el borrador de especificación de Microseguros (PRD-306), pero sin la sección de comportamiento. Los 12 requerimientos aceptados no dicen qué problema resuelven, y no quise inventarlo. Dejé la corrida registrada como `2026-10-16-product-spec-1`.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (fecha 2026-10-16), así que no hubo que volver a registrarlos. No hubo preguntas que responder.

- **Alcance:** entran los 12 requerimientos en estado `aceptado`. Quedan fuera los 4 `propuesto` (REQ-4601, 4607, 4609, 4611), porque nadie los ha decidido.
- **Criterios de aceptación:** en 8 requerimientos el criterio es «se verifica en producción», que no dice qué se mide ni quién verifica. Otros 4 no tienen criterio: REQ-4606, 4613, 4614 y 4615.
- **Supuestos:** hay uno, «el proveedor cumple el tiempo pactado», sin verificar desde el 2026-06-28. Su fecha no cuadra con el documento, que es de 2025-12-25.
- **Vacíos, cada uno con quién lo cierra:**
  - REQ-4602 no tiene doliente.
  - REQ-4603, 4614 y 4615 no tienen evidencia de demanda. Los otros 9 solo tienen una cita genérica de la entrevista de 2025-10-05, que no nombra ningún requerimiento.
  - Ningún requerimiento tiene proyecto que lo ejecute.
  - El acta no dice quién decidió cada aceptación.
  - Los casos borde, el éxito del producto y la prioridad no están definidos.
  - No hay acuerdo escrito con el proveedor.
  - Las obligaciones normativas no aparecen en ningún documento. No hice el barrido citado, y la tabla de vacíos lo dice.
- **Requerimientos aceptados sin cubrir:** los 12 quedan sin comportamiento. La tabla final dice qué le falta a cada uno.
- **Siguiente paso:** no ofrecí `/product-charter`, porque no hay vacíos cerrados ni un criterio de éxito verificable.

La corrida midió 40 segundos y 37 hallazgos, y su nota quedó en el registro.

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-spec.md`
