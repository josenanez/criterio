# Corrida · 2026-10-16-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:46:18 · **Fin:** 2026-10-16T14:47:06 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 30 | 21 | Rubén Cárdenas (documento 1, 6 reprogramaciones) y Elena Duarte (prueba 2, 5); 8 vencidos, 6 sin fecha; 5 'ya entregó' sin documento |

Por señal (`pm-commitments`): `commitment_overdue` 8, `commitment_undated` 6, `milestone_met_without_evidence` 2, `commitment_rescheduled` 2, `variance_time` 1, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos: Onboarding PyME (PRY-207), al 2026-10-16

Hay 26 compromisos registrados. 22 siguen abiertos y 2 están cerrados con documento. Los otros 2 los dejé sin clasificar aquí porque ya estaban en el estado como vencidos o abiertos.

Los términos de la versión 0.3.12 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-16. No los volví a registrar.

**Se viene reprogramando**
- **Rubén Cárdenas, "Enviar el documento 1":** va en 6 reprogramaciones, una por reunión.
  - La promesa original era del 2026-09-25. La vigente es el 2026-12-12.
  - Las notas del 10-16 dicen que "no alcanzó", sin decir qué no alcanzó.
- **Elena Duarte, "Cerrar la prueba 2":** va en 5 reprogramaciones. La original era del 2026-09-19 y la vigente es el 2026-11-17. Todavía no está vencida y no hay motivo escrito en ninguna minuta.
- **Umbral de alerta:** es 3, y los dos lo superan.

**Vencidos sin evidencia (8)**
- Javier Hoyos (25 días), Sandra Gil (13 y 7), Óscar Ramírez (6), Rubén Cárdenas (5), Liliana Torres (3), Jorge Medina (2) y Paula Céspedes (1).
- Para 5 compromisos alguien dijo "ya entregó" y no hay documento. Son los dos de Sandra Gil, el de Jorge Medina, el de Gustavo Neira y el de María Restrepo. Siguen abiertos.

**Vencen esta semana (4)**
- Rubén Cárdenas, "Confirmar la fecha 7", vence hoy.
- Diana Molina, el 10-21.
- Javier Hoyos, el 10-22.
- María Restrepo, el 10-23.

**Sin fecha (6)**
- Gustavo Neira (2), María Restrepo, Elena Duarte, Carlos Peña y Laura Vélez. Laura dijo "la otra semana" y no lo convertí en fecha.

**Cerrados con documento (2)**
- Jorge Medina, "Entregar el punto 8", con el acta de recibo 8.
- Liliana Torres, "Validar el ambiente 12", con el acta de recibo 12.

**Para confirmar con su doliente:** el compromiso nuevo de Óscar Ramírez, "Revisión con el proveedor" para el 10-26. La frase no dice si es una reunión o un entregable.

**Siguiente paso:** puedo formular lo de Rubén Cárdenas y Elena Duarte como decisión para el comité del 2026-10-30. Excede la autoridad del gerente, así que sube al comité. No hace falta `/pm-publish`, porque esta corrida no cambió ningún campo de la ficha.

La corrida quedó registrada como `2026-10-16-pm-commitments-1` con 21 hallazgos. Texto completo: `estado/PRY-207-onboarding-pyme/corridas/salida-pm-commitments.md`.
