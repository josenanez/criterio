# Corrida · 2026-10-16-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4600

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4600

**Inicio:** 2026-10-16T14:41:28 · **Fin:** 2026-10-16T14:42:14 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 30 | 37 | Borrador de acta para REQ-4600. Sin autoridad declarada, sin quién decidió la aceptación, criterio de aceptación no verificable y evidencia de demanda débil: marcados como vacíos. Sin barrido normativo. Ficha no creada: falta la firma. |

Por señal (`product-charter`): `evidence_stale` 12, `requirement_untraced` 12, `requirement_undecided` 4, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Escribí el borrador del acta de constitución para REQ-4600 (producto PRD-306, Microseguros), pero no creé la ficha del proyecto: el acta no está firmada.

Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-16, así que no los registré de nuevo.

**Qué falta en REQ-4600.** Cuando el comando ofrece seguir marcando lo que falta como vacío, tomé la respuesta sugerida (seguir) y no rellené nada:
- **Quién lo aceptó:** consta que está aceptado desde 2026-06-28, pero no quién lo decidió.
- **Autoridad:** la definición no la declara. «Comité de producto» es solo una propuesta por defecto.
- **Criterio de éxito:** el único criterio es «se verifica en producción», que no se puede medir.
- **Evidencia de demanda:** es una sola cita de cliente de 2025-10-05 («Lo necesito y hoy no lo tengo.») que no nombra el requerimiento.
- **Otros vacíos:** el borrador marca también como vacíos la necesidad, la prioridad, el patrocinador y el presupuesto.

**Supuesto y cifra que pasan al proyecto:**
- El supuesto «El proveedor cumple el tiempo pactado» sigue sin verificar. Pasa a ser riesgo del proyecto cuando exista gerente.
- La cifra del caso de negocio, volumen mensual de 204.945, no tiene ningún tablero de métricas contra el que contrastarla.

**Sin barrido normativo:** no revisé obligaciones normativas de microseguros. El acta lo deja como pendiente, sin afirmar ni descartar nada.

**Alcance:** solo entra REQ-4600. Los otros 15 requerimientos del registro quedan sin decisión de alcance, no descartados.

**Siguiente paso:** alguien con autoridad firma el acta y se asigna un gerente. Esa persona instala `criterio-project` y corre `/pm-setup`.

La corrida quedó registrada como `2026-10-16-product-charter-1` y tardó 30 segundos. Detectó 37 hallazgos sobre los 16 requerimientos del producto (por ejemplo, 12 evidencias vencidas y 12 requerimientos sin proyecto).

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-charter.md`
