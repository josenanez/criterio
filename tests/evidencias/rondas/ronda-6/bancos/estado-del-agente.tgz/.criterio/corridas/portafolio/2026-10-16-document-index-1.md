# Corrida · 2026-10-16-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:00:40 · **Fin:** 2026-10-16T15:00:59 · **Duración:** 19 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 7 | 78 | Índice sobre 95 documentos: ninguno cambió, ninguno por releer, sin renombrados, borrados ni citas rotas. No se produjo informe. |

Por señal (`document-index`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 18, `commitment_overdue` 10, `progress_vs_plan` 7, `commitment_undated` 6, `declared_vs_evidence` 4, `vendor_invoiced_without_delivery` 3, `rebaseline_unauthorized` 3, `variance_time` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1

## Lo que el agente mostró

Carpeta al 2026-10-16: hay 95 documentos y ninguno cambió. No hay nada que releer, ni renombrados, ni borrados, ni citas rotas. No hace falta lanzar un barrido.

Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-16, versión 0.3.12), así que no los registré de nuevo.

Dejé la corrida registrada en `estado/corridas/` con su salida. Las 78 señales abiertas que aparecen en ese registro vienen de las fichas ya existentes, no de este índice. Esta corrida solo comparó la carpeta.
