# Corrida · 2026-10-16-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T14:38:35 · **Fin:** 2026-10-16T14:39:23 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 32 | 37 | La evidencia sostiene débilmente el problema (una entrevista de hace 12 meses); volumen y retorno sin serie; sin criterio de éxito; supuesto del proveedor 110 días sin verificar |

Por señal (`product-definition`): `evidence_stale` 12, `requirement_untraced` 12, `requirement_undecided` 4, `requirement_without_acceptance` 4, `requirement_accepted_without_evidence` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

Terminé la contrastación de la definición de Microseguros (PRD-306) y dejé la corrida registrada.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los volví a registrar.

**Lo que encontré** (la definición es del 2025-12-25 y tiene 6 afirmaciones):
- **Contradicciones:** ninguna. Tampoco hay métrica medida que pase el umbral de 20 %.
- **Cifras que nadie mide:** el volumen mensual de 204.945 y el «retorno esperado en 24 meses». El retorno ni siquiera trae cifra.
- **Sostenida por evidencia:** solo el problema («Personas no tiene microseguros»). La sostiene una entrevista de un cliente sin nombre, del 2025-10-05, que no dice que sea del segmento Personas. Es evidencia débil y ya cruzó el umbral de 12 meses.
- **Sostenida por un supuesto:** «El proveedor cumple el tiempo pactado» lleva 110 días sin verificar. Para verificarlo hace falta el contrato con el plazo escrito y el registro de entregas del proveedor.
- **No está dicho en ninguna parte:** el criterio de éxito, qué es la propuesta (solo dice «Propuesta principal»), quién decide, qué proyecto lo construye, y cuál es el plan que el comité del 2026-10-14 decidió mantener.
- **Lo normativo:** ningún documento dice el país, así que dejé el estado «no tengo la norma a la vista». Eso no es un cumplimiento ni un incumplimiento.
- **Cierre:** la definición no se puede cerrar hoy, porque falta el criterio de éxito y el acta no dice quién decide. Por eso no corresponde `/product-charter`. Sí se puede pasar el supuesto del proveedor al registro de riesgos con un doliente.

La corrida registró 37 hallazgos (los de los 16 requerimientos más el supuesto) en 32 segundos.

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado-producto/PRD-306/corridas/`:
- `salida-product-definition.md`
- `2026-10-16-product-definition-1.md`
