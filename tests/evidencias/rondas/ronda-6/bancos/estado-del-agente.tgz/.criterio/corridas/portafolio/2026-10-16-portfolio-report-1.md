# Corrida · 2026-10-16-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-16T15:16:33 · **Fin:** 2026-10-16T15:17:32 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 95 | 40 | 78 | Primer informe html; 4 verdes contradichos (PRY-203, 204, 207, 208); autoridad y fase sin identificar en los 13. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 18, `commitment_overdue` 10, `progress_vs_plan` 7, `commitment_undated` 6, `declared_vs_evidence` 4, `vendor_invoiced_without_delivery` 3, `rebaseline_unauthorized` 3, `variance_time` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1

## Lo que el agente mostró

El informe HTML de portafolio está generado: 26 páginas en `/home/claude/banco/ronda-6/bancos/espacio/reportes`. Cubre 13 proyectos, 11 de ellos con hallazgos, 78 señales en total.

**Términos y fichas.** Los términos ya estaban aceptados por José Francisco Ñáñez el 2026-10-16 (v1.1), así que no volví a registrarlos. Cargué las 13 fichas de `estado/records/`, generadas hoy; la carpeta `estado/fichas/` que menciona el comando no existe.

**Vistas por audiencia.**
- `index.html` es la vista por campo, con la cadena de evidencia completa, para quien va a actuar.
- `decisiones.html` es la vista por decisión, para el patrocinador.
- Para sacar el PDF, imprima el HTML.

**Qué cambió.** Nada: la única instantánea previa es la de hoy, así que este es el punto de partida y no hay delta.

**Verdes contradichos por la evidencia (4).**
- **PRY-203 Open Banking:** proyección de costo 23,6 % sobre lo aprobado y línea base movida 33 días sin autorización.
- **PRY-204 Débito contactless:** declara 48 % cuando el plan soporta 75–100 %, con 119 días de atraso sin autorización.
- **PRY-207 Onboarding PyME:** declara 30 % cuando el plan soporta 50–75 %, con compromisos vencidos y reprogramados.
- **PRY-208 Motor de decisión:** tiene un compromiso vencido hace 15 días.

**Otros hallazgos.**
- **Proveedores facturados sin entrega:** PRY-200 y PRY-206.
- **Hito vencido:** PRY-202 tiene "Integración con el core" vencido hace 4 días.
- **Hitos declarados cumplidos sin evidencia:** hay 20 en total.

**Secciones vacías.** Contradicciones entre fuentes, proyectos en silencio, dependencias entre proyectos y cambios de gobierno salieron sin nada.

**Vacíos.** Ninguno de los 13 proyectos tiene autoridad ni fase identificadas. Cuatro proyectos no tienen producto asociado: PRY-202, PRY-205, PRY-208 y PRY-210.

**Confirmación del mes.** Dejé las cinco preguntas cerradas en el informe sin responder, porque nadie las puede contestar en esta sesión.

La corrida quedó registrada como `2026-10-16-portfolio-report-1` en `estado/corridas/`; tardó 40 segundos y no releyó ningún documento. El texto completo del informe está en `estado/corridas/salida-portfolio-report.md`, con el pie de versión y el enlace a los términos.

Si hay comité próximo (el 2026-10-23), puedo preparar el material de comité o entrar al detalle de los proyectos con hallazgos.
