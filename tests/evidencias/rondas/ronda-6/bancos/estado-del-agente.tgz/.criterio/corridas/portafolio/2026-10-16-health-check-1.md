# Corrida · 2026-10-16-health-check-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:health-check PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-16T15:02:05 · **Fin:** 2026-10-16T15:04:01 · **Duración:** 116 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `health-check` | 13 | — | 101 | 78 | Diagnóstico de PRY-205 desde 7 documentos: 3 sostenidas, 10 sin sustento, 2 contradichas. Dijo que no sabe si está en producción, qué se recibió y facturó de CT-853/CT-108, ni qué es el punto 26. |

Por señal (`health-check`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 18, `commitment_overdue` 10, `progress_vs_plan` 7, `commitment_undated` 6, `declared_vs_evidence` 4, `vendor_invoiced_without_delivery` 3, `rebaseline_unauthorized` 3, `variance_time` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1

## Lo que el agente mostró

El diagnóstico de PRY-205 está hecho, pero con lo que hay en la carpeta no se puede decir si el proyecto está en producción. El cronograma marca los 5 hitos como cerrados, incluida la salida a producción del 2026-08-04, y el informe del 2026-10-15 reporta 77 % de avance en amarillo.

Leí los 7 documentos del proyecto, de 2025-05-24 a 2026-10-15, y no hubo ninguno ilegible. También busqué el proyecto en los otros 139 documentos del portafolio y ninguno lo menciona. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta mostrarlos de nuevo.

- **Dictamen:** 3 afirmaciones sostenidas, 10 sin sustento y 2 contradichas.
- **Sostenido:** el diseño funcional se recibió el 2026-10-09, el presupuesto aprobado es de 9.500.000.000 COP y el acta nombra patrocinador, gerente y comité.
- **Contradicho:** el 77 % del informe choca con el cronograma (100 % cerrado). El cronograma tampoco registra que el diseño funcional se recibió más de un año después de su fecha de línea base.
- **Hitos sin evidencia:** 4 de los 5 hitos cerrados no tienen ningún documento de recibo (entre 73 y 325 días de vencidos). Los 8 entregables de los dos contratos (CT-853 y CT-108) tampoco tienen acta de recibo, y no hay facturas en la carpeta.
- **Gobierno y plan:** el acta no declara autoridad del gerente. No hay replanificación y la fecha de cierre, 2026-08-04, ya pasó. Entre 2025-06-04 y 2026-10-09 no hay ningún documento.
- **Dinero (COP):** hay 5.292.231.115 comprometidos (55,7 %), 1.534.440.797 ejecutados (16,2 %) y 4.207.768.885 disponibles. La proyección es de 9.165.818.019, un 3,5 % por debajo de lo aprobado. El informe no explica la diferencia entre el 77 % de avance y el 16,2 % ejecutado.
- **Dicho y no registrado:** Óscar Ramírez se comprometió en el comité del 2026-10-10 a entregar el «punto 26», que vence hoy, y nada dice qué es. El riesgo de concentración del conocimiento y el hallazgo de seguridad solo aparecen en el informe, sin responsable ni fecha.
- **Los dos contratos:** tienen los mismos 4 entregables, nombres y fechas, con montos distintos. Los documentos no aclaran si es alcance duplicado o una plantilla copiada.

No recomiendo detener, continuar ni reestructurar; eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las contradicciones a Carlos Peña como preguntas, una por una.

La corrida quedó registrada como `2026-10-16-health-check-1` y tardó 101 segundos. Los conteos de `documentos` y `relectura` no se midieron.

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado/corridas/`:
- salida-health-check.md
