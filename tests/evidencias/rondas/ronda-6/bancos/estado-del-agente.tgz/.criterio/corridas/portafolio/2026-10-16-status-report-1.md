# Corrida · 2026-10-16-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-16; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-16T15:01:04 · **Fin:** 2026-10-16T15:02:00 · **Duración:** 56 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 38 | 78 | Informe de PRY-202: avance declarado 80% frente a 40-60% que respalda el plan, hito Integración con el core vencido, 2 hitos cumplidos sin evidencia, compromiso vencido y 2 entregables de proveedor atrasados. Sin dato: autoridad, fase, evidencia de entregables y dueños de RAID. |

Por señal (`status-report`): `milestone_met_without_evidence` 20, `vendor_deliverable_late` 18, `commitment_overdue` 10, `progress_vs_plan` 7, `commitment_undated` 6, `declared_vs_evidence` 4, `vendor_invoiced_without_delivery` 3, `rebaseline_unauthorized` 3, `variance_time` 3, `commitment_rescheduled` 2, `milestone_overdue` 1, `variance_cost` 1

## Lo que el agente mostró

Terminé el informe de estado de PRY-202 y dejé la corrida registrada. El hallazgo principal es que el gerente declara 80 % de avance, pero el plan solo respalda entre 40 % y 60 %.

**PRY-202 — Migración a la nube, al 2026-10-16**
- **Lo que declara el gerente (Rubén Cárdenas):** semáforo amarillo y 80 % de avance, al 2026-09-27.
- **Lo que no cuadra:** con 2 de 5 hitos cumplidos, el plan respalda entre 40 % y 60 %, así que lo declarado va 20 puntos por delante. Esos 2 hitos ("Diseño funcional aprobado" y "Ambiente de pruebas certificado") no tienen evidencia de cumplimiento en la carpeta.
- **Hito vencido:** "Integración con el core" venció el 2026-10-12, hace 4 días.
- **Compromiso vencido:** Jorge Medina debía "entregar el punto 21" el 2026-10-05, hace 11 días. Se registró con una fecha que ya había pasado y él no asistió al comité.
- **Proveedor Datacore Colombia:** la bolsa de horas del CT-726 lleva 27 días de atraso y el licenciamiento del CT-894 lleva 115. Los dos entregables siguen pendientes y sin evidencia.
- **Posible contratación doble:** el "Licenciamiento del motor" figura en dos contratos. En el CT-726 está aceptado y facturado por 594.710.263 COP, y en el CT-894 sigue pendiente. Los documentos no dicen si es el mismo alcance; conviene revisarlo.
- **Plazo y costo:** el cierre sigue en 2027-04-22, sin replanificaciones. La proyección de presupuesto está 2,0 % por encima de lo aprobado, por debajo del umbral del 10 %.
- **Sin dato:** autoridad del proyecto, fase, evidencia de entrega de 4 entregables de proveedor, y los dueños de los riesgos e incidencias abiertos.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-16), así que no los registré de nuevo.

Puedo preparar el punto de comité con el avance, el hito vencido y los hitos sin evidencia; no lo he hecho.

Archivos en `/home/claude/banco/ronda-6/bancos/espacio/estado/corridas/`:
- `salida-status-report.md`
- `2026-10-16-status-report-1.md` (el registro de la corrida)
