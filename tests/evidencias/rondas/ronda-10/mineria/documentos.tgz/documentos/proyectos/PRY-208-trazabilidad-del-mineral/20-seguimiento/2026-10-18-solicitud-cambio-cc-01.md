# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-18
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +26 días sobre la línea base vigente |
| Costo | 52.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
