# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-10-11
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-12-05 |
| Diana Molina | Cerrar la prueba 2 | 2026-11-08 |
| Paula Céspedes | Revisar el anexo 3 | 2026-10-18 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 7 | 2026-10-24 |
| Sandra Gil | Entregar el punto 8 | 2026-10-27 |
| Carlos Peña | Enviar el documento 9 | 2026-10-24 |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 |
| Óscar Ramírez | Actualizar la matriz 14 | 2026-10-21 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-28 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-26 |
| Elena Duarte | Enviar el documento 17 | 2026-10-31 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-18 |
| Carlos Peña | Revisar el anexo 19 | 2026-10-19 |
| Elena Duarte | Validar el ambiente 20 | 2026-10-12 |
| Felipe Arango | Aprobar el diseño 21 | 2026-10-30 |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-22 |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-21 |
| Felipe Arango | Entregar el punto 24 | 2026-10-30 |

## Lo que se dijo

- Laura Vélez dice que ya entregó «revisar el anexo 11». No se presentó acta.
