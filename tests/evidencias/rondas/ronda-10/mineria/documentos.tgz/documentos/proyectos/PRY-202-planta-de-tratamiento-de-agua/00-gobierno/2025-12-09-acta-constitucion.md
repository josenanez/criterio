# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Logística
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-09

## Objetivo del negocio

Entregar planta de tratamiento de agua para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Inversiones el 2025-12-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-19 |
| Cierre | 2026-08-27 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
