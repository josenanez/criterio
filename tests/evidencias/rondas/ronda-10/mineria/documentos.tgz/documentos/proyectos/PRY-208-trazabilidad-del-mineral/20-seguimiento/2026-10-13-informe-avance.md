# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se levantó un hallazgo en la auditoría de seguridad
- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 679.211.337 |
| Ejecutado | 591.160.037 |
| Proyección al cierre | 1.220.321.053 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
