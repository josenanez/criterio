# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-09-27
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-11 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-19 |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-15 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-13 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 7 | por definir |
| Sandra Gil | Entregar el punto 8 | 2026-10-03 |
| Carlos Peña | Enviar el documento 9 | 2026-10-24 |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 |
| Laura Vélez | Revisar el anexo 11 | 2026-10-16 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-18 |
| Óscar Ramírez | Actualizar la matriz 14 | 2026-10-21 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-10 |
| Paula Céspedes | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Validar el ambiente 12 (María Restrepo): recibido, acta de recibo del 2026-09-27.
