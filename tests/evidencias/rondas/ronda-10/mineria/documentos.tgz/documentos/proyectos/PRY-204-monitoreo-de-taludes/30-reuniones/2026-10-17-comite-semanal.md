# Comité de Seguridad · Monitoreo de taludes

**Fecha:** 2026-10-17
**Asistentes:** Elena Duarte, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 16 | 2026-11-02 |
