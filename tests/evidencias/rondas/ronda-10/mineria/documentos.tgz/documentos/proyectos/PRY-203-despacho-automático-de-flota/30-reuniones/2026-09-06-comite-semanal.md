# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-09-06
**Asistentes:** Diana Molina, Jorge Medina, María Restrepo, Natalia Ospina, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-02 |
| Diana Molina | Cerrar la prueba 2 | por definir |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-15 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-02 |
