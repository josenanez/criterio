# Acta de constitución · Control de polvo en vías

**Código:** PRY-211
**Área dueña:** Logística
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-20

## Objetivo del negocio

Entregar control de polvo en vías para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Operaciones el 2025-09-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-30 |
| Cierre | 2027-02-18 |

## Criterio de éxito

Control de polvo en vías en producción y medido.

## Dependencias declaradas

- Ninguna declarada
