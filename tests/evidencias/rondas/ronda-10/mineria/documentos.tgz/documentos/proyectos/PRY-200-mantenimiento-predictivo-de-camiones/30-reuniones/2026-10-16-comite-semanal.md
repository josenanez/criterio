# Comité Ambiental · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-16
**Asistentes:** Sandra Gil, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 26 | 2026-10-18 |
