# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-201 · Ampliación de la relavera
**Fecha de recibo:** 2026-09-05
**Recibido por:** Mauricio Pérez

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-546 · Automatización de Procesos Ltda..
