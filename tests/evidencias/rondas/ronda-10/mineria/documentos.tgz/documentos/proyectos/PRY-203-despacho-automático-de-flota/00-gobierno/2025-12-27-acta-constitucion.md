# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Finanzas
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Seguridad
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-12-27

## Objetivo del negocio

Entregar despacho automático de flota para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Seguridad el 2025-12-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-06 |
| Cierre | 2027-02-09 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
