# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-10
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se acordó con operaciones el plan de arranque de los equipos
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.957.170.074 |
| Ejecutado | 2.066.157.295 |
| Proyección al cierre | 4.010.077.163 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
