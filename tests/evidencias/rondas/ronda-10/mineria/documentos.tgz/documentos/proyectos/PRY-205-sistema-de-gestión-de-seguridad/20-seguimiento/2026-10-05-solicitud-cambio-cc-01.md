# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-05
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +30 días sobre la línea base vigente |
| Costo | 60.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
