# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-17
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **57%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 873.204.376 |
| Ejecutado | 405.049.006 |
| Proyección al cierre | 1.258.073.437 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- Concentración del conocimiento en una sola persona
