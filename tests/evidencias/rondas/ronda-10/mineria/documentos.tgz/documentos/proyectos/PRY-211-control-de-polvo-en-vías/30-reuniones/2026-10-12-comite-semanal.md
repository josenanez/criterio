# Comité de Operaciones · Control de polvo en vías

**Fecha:** 2026-10-12
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 10 | 2026-11-08 |
