# Acta de constitución · Monitoreo de taludes

**Código:** PRY-204
**Área dueña:** Mantenimiento
**Patrocinador:** Mauricio Pérez
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Seguridad
**Producto asociado:** alerta de taludes
**Fecha de aprobación:** 2026-05-01

## Objetivo del negocio

Entregar monitoreo de taludes para Mantenimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Seguridad el 2026-05-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-11 |
| Cierre | 2027-02-02 |

## Criterio de éxito

Monitoreo de taludes en producción y medido.

## Dependencias declaradas

- Ninguna declarada
