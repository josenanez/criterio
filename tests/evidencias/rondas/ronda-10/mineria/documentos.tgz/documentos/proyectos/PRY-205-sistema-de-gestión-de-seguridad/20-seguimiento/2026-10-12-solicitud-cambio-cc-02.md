# Solicitud de cambio CC-02

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-12
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +116 días sobre la línea base vigente |
| Costo | 232.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
