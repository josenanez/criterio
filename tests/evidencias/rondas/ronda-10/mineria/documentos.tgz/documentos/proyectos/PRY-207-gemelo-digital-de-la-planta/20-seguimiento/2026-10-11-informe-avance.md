# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-11
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **34%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- Se reprogramó la parada de planta por la ventana de mantenimiento
- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.329.332.635 |
| Ejecutado | 1.415.362.308 |
| Proyección al cierre | 4.127.012.940 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
