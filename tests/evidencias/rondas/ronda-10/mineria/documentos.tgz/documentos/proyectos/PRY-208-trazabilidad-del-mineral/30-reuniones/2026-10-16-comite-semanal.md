# Comité de Tecnología · Trazabilidad del mineral

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 10 | 2026-10-19 |
