# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-05-23
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 217.036 | Caso de negocio, 2026-05-23 |

## Retorno esperado

Retorno esperado en 24 meses.
