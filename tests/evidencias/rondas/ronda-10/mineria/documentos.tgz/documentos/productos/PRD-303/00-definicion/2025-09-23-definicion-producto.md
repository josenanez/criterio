# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Javier Hoyos
**Segmento:** Gerencia
**Fecha de la definición:** 2025-09-23

## El problema

El segmento Gerencia no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-08-26 · verificado con la medición del piloto del 2026-08-29 (anexo «Verificación del supuesto» del 2026-08-29)

## Proyectos que lo construyen

- Ninguno declarado
