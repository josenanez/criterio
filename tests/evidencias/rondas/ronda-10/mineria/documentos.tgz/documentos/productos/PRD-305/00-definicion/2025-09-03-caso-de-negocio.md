# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-09-03
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 150.339 | Caso de negocio, 2025-09-03 |

## Retorno esperado

Retorno esperado en 24 meses.
