# Definición de producto · Alerta de taludes

**Código:** PRD-301
**Gerente de producto:** Carlos Peña
**Segmento:** Supervisores
**Fecha de la definición:** 2026-02-14

## El problema

El segmento Supervisores no tiene alerta de taludes.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-05-08 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
