# Entrevistas · Permisos de trabajo digitales

**Ronda:** Ronda · 2025-09-27
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-09-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
