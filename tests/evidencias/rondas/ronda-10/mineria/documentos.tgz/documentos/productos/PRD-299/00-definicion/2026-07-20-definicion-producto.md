# Definición de producto · Solicitud de dotación

**Código:** PRD-299
**Gerente de producto:** Felipe Arango
**Segmento:** Personas
**Fecha de la definición:** 2026-07-20

## El problema

El segmento Personas no tiene solicitud de dotación.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-08-29 · verificado con el concepto jurídico de cumplimiento del 2026-09-24 (anexo «Verificación del supuesto» del 2026-09-24)

## Proyectos que lo construyen

- PRY-199
- PRY-199
- PRY-199
- PRY-199
