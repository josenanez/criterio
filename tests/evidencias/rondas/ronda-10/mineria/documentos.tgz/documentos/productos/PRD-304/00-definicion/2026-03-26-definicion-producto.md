# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Javier Hoyos
**Segmento:** Supervisores
**Fecha de la definición:** 2026-03-26

## El problema

El segmento Supervisores no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-05-10 · verificado con el documento técnico del proveedor del 2026-06-05 (anexo «Verificación del supuesto» del 2026-06-05)

## Proyectos que lo construyen

- Ninguno declarado
