# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-07-05
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 165.286 | Caso de negocio, 2026-07-05 |

## Retorno esperado

Retorno esperado en 24 meses.
