# Definición de producto · Reporte ambiental

**Código:** PRD-307
**Gerente de producto:** Elena Duarte
**Segmento:** Supervisores
**Fecha de la definición:** 2026-07-05

## El problema

El segmento Supervisores no tiene reporte ambiental.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-04-28 · verificado con la medición del piloto del 2026-08-09 (anexo «Verificación del supuesto» del 2026-08-09)

## Proyectos que lo construyen

- Ninguno declarado
