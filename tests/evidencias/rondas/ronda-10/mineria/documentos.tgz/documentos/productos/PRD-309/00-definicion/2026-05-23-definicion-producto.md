# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Camilo Beltrán
**Segmento:** Operadores
**Fecha de la definición:** 2026-05-23

## El problema

El segmento Operadores no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
