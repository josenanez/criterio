# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Mauricio Pérez
**Segmento:** Operadores
**Fecha de la definición:** 2026-06-03

## El problema

El segmento Operadores no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-06-26 · verificado con la entrevista con doce clientes del segmento del 2026-07-28 (anexo «Verificación del supuesto» del 2026-07-28)

## Proyectos que lo construyen

- Ninguno declarado
