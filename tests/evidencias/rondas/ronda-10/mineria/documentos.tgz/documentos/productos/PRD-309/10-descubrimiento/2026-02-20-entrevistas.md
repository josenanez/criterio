# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2026-02-20
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-02-20

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
