# Tablero de métricas · Alerta de taludes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-05

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 58.894 | 2026-10-05 |
