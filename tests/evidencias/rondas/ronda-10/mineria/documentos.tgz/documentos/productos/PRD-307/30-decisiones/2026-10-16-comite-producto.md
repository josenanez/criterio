# Comité de producto · Reporte ambiental

**Fecha:** 2026-10-16
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-01 | — |
| REQ-4701 | Requerimiento REQ-4701 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4702 | Requerimiento REQ-4702 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-28 | — |
| REQ-4703 | Requerimiento REQ-4703 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-23 | — |
| REQ-4704 | Requerimiento REQ-4704 | Óscar Ramírez | — | — | propuesto | 2026-08-10 | — |
| REQ-4705 | Requerimiento REQ-4705 | sin asignar | se verifica en producción | — | aceptado | 2026-07-05 | — |
| REQ-4706 | Requerimiento REQ-4706 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-18 | — |
| REQ-4707 | Requerimiento REQ-4707 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-06-24 | — |
| REQ-4708 | Requerimiento REQ-4708 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-04 | — |
| REQ-4709 | Requerimiento REQ-4709 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-03-19 | — |
| REQ-4710 | Requerimiento REQ-4710 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4711 | Requerimiento REQ-4711 | Laura Vélez | se verifica en producción | — | propuesto | 2026-03-31 | — |
| REQ-4712 | Requerimiento REQ-4712 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-27 | — |
| REQ-4713 | Requerimiento REQ-4713 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-21 | — |
| REQ-4714 | Requerimiento REQ-4714 | Carlos Peña | se verifica en producción | — | aceptado | 2026-03-31 | — |
| REQ-4715 | Requerimiento REQ-4715 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-06-08 | — |
| REQ-2037 | Requerimiento REQ-2037 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-05 | — |

## Decisiones

- Se mantiene el plan
