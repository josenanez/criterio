# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-02-14
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 61.780 | Caso de negocio, 2026-02-14 |

## Retorno esperado

Retorno esperado en 24 meses.
