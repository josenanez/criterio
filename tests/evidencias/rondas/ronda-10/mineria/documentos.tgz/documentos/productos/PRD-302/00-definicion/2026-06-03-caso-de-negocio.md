# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-06-03
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 70.089 | Caso de negocio, 2026-06-03 |

## Retorno esperado

Retorno esperado en 24 meses.
