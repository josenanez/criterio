# Caso de negocio · Gemelo digital

**Código:** PRD-303
**Fecha:** 2025-09-23
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 206.217 | Caso de negocio, 2025-09-23 |

## Retorno esperado

Retorno esperado en 24 meses.
