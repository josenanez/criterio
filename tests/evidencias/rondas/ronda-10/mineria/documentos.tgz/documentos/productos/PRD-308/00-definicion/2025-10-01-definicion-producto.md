# Definición de producto · Permisos de trabajo digitales

**Código:** PRD-308
**Gerente de producto:** Javier Hoyos
**Segmento:** Supervisores
**Fecha de la definición:** 2025-10-01

## El problema

El segmento Supervisores no tiene permisos de trabajo digitales.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-05-13 · verificado con la entrevista con doce clientes del segmento del 2026-08-08 (anexo «Verificación del supuesto» del 2026-08-08)

## Proyectos que lo construyen

- Ninguno declarado
