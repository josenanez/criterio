# Tablero de métricas · Despacho de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 44.473 | 2026-10-08 |
