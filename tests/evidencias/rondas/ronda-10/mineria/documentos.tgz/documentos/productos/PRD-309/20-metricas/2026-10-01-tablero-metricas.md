# Tablero de métricas · Inspección con drones

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 225.066 | 2026-10-01 |
