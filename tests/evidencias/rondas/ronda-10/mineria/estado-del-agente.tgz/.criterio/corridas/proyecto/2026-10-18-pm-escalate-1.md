# Corrida · 2026-10-18-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:46:19 · **Fin:** 2026-10-18T08:47:13 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 38 | 9 | Paquete de una decisión: quién declara la autoridad del gerente (identity.authority no existe en ningún documento). No formulé el bloqueo del documento 1 (6 reprogramaciones) ni la prueba 2 (4): ninguna fuente dice la causa. No corrí impact: ninguna fecha se mueve y no hay días ni dependencias declaradas. Costos de las opciones no están en los documentos. |

Por señal (`pm-escalate`): `commitment_overdue` 4, `commitment_rescheduled` 2, `progress_vs_plan` 1, `commitment_undated` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé un paquete de escalamiento con una sola decisión lista para PRY-203, y la corrida quedó registrada con su salida completa.

**Términos:** ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-18, así que no los registré de nuevo.

**Lo que escala y está listo:**
- **La pregunta:** ¿quién declara por escrito qué puede decidir Jorge Medina, el patrocinador Felipe Arango o el Comité de Seguridad?
- **Por qué sube primero:** el acta no tiene sección de autoridad, y la búsqueda en todos los documentos del proyecto no encontró nada.
- **Recomendación:** una adenda al acta firmada por el patrocinador, y que el comité la ratifique el 2026-11-01.
- **Si no se decide:** esa fecha el comité se reúne sin saber si lo que se le pide al gerente está dentro de su autoridad. Esa consecuencia la infiero de las fechas; ningún documento la declara.

**Lo que escala pero no formulé:**
- **«Enviar el documento 1» (María Restrepo):** seis reprogramaciones, con umbral de tres.
- **«Cerrar la prueba 2» (Diana Molina):** cuatro reprogramaciones.
- **Por qué no:** ningún documento dice qué las bloquea, y sin eso no hay pregunta cerrada ni opciones. Primero hay que preguntarles qué las frena; si excede la autoridad del gerente, vuelve aquí.

**Lo que no escala:**
- **Riesgo del proveedor:** primero se registra con dueño.
- **Natalia Ospina (ambiente 4):** se destraba con una llamada.
- **Estado verde y 37 %:** es tema de `/pm-report`.

**Lo que no sé:**
- **Costos y tiempos:** los costos de las opciones y el tiempo de la firma no están en ningún documento, y no los inventé.
- **Impacto:** no corrí el cálculo de impacto porque ninguna fecha se mueve. Tampoco hay días ni dependencias declaradas.

Archivos en `estado/PRY-203-despacho-automático-de-flota/corridas/`:
- `salida-pm-escalate.md`
- `2026-10-18-pm-escalate-1.md`
