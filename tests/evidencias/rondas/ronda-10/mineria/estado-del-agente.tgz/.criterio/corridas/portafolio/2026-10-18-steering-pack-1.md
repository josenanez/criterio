# Corrida · 2026-10-18-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T09:05:15 · **Fin:** 2026-10-18T09:07:30 · **Duración:** 135 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 119 | 47 | Paquete de 6 decisiones, 6 escalamientos y anexo de 13 proyectos. No había comité anterior registrado; no sé quién tiene autoridad de cambio (0 de 13 fichas), ni la vigencia de CT-546/CT-852, ni si el cálculo reconoce las actas de recibo de la carpeta. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

El material de comité está listo para el comité del 2026-10-29. Tiene 6 decisiones, 6 escalamientos sin decisión asociada y un anexo con los 13 proyectos. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

**Las 6 decisiones**
1. Quién aprueba los cambios de línea base. Ninguna de las 13 actas dice quién tiene esa facultad, y los demás puntos dependen de esto.
2. PRY-208, solicitud de cambio CC-01 (+26 días, +52.000.000 COP). La línea base ya se movió 26 días sin autorización. Recomiendo aplazar hasta tener la descripción del alcance y la fecha escrita del proveedor.
3. PRY-201, retener pagos a CT-546 y CT-852 hasta que existan las actas de recibo.
   - CT-546 facturó 709.436.086 COP por encima de lo que respalda su acta.
   - CT-852 facturó 4.289.910.924 COP sin ninguna acta.
4. PRY-201, mover el cierre 30 días. No hay solicitud escrita, así que recomiendo devolverla.
5. Ratificar las solicitudes de cambio de PRY-202 (CC-01) y PRY-205 (CC-01 y CC-02), que dicen «autorizada por el comité» sin acta. Recomiendo ratificar PRY-202 y exigir un replan a PRY-205, que está en rojo y proyecta +21,3 % sobre lo aprobado.
6. Nombrar un responsable en Operaciones que confirme por escrito la ventana de parada de planta, que 10 de 13 informes mencionan.

**Lo que no pude hacer**
- **Comité anterior:** no hay registro de uno en la carpeta, así que no pude cerrar el ciclo de decisiones previas. Lo dejé dicho en el documento.
- **Contratos:** no tengo la vigencia ni el preaviso de CT-546 y CT-852.
- **Evidencia de hitos:** las 13 fichas cuentan 0 fuentes de evidencia, aunque la carpeta tiene algunas actas de recibo. No verifiqué si el cálculo las reconoce, así que la lista de hitos «cumplidos sin evidencia» puede estar inflada.
- **Autoridad de cambio:** vacía en las 13 fichas.

La corrida quedó registrada como `2026-10-18-steering-pack-1`. Tardó 119 segundos y el sistema contó 47 señales abiertas.

Ofrezco registrar las decisiones en las fichas cuando el comité sesione.

Archivos están en `/home/claude/banco/ronda-10/mineria/espacio/estado/corridas/`:
- `salida-steering-pack.md`
