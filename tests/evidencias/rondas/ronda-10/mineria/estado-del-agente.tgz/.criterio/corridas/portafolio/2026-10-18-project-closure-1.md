# Corrida · 2026-10-18-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-18T09:04:12 · **Fin:** 2026-10-18T09:05:10 · **Duración:** 57 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 42 | 47 | Cierre provisional de PRY-202: el proyecto no ha terminado (cierre vigente 2026-11-30, ensayo de disponibilidad fallido). Criterio de éxito sin evidencia; dos hitos sin soporte; CC-01 sin aprobador identificable; no se sabe si el presupuesto incluye los 190 M de CC-01. No se archivó. |

Por señal (`project-closure`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

PRY-202 no se puede cerrar: los documentos muestran un proyecto en marcha, no uno terminado. Dejé un acta de cierre **provisional**. Cerrarlo hoy sería una decisión de alguien, no un cumplimiento.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hubo que registrar nada. Esta sesión no tiene interfaz, así que no pregunté nada y tomé las respuestas sugeridas.

- **Criterio de éxito:** el acta pide «planta en producción y medido». No hay evidencia de ninguna de las dos cosas. El primer ensayo de disponibilidad no alcanzó lo pactado y se repite.
- **Fecha:** el cierre pasó de 2026-08-27 a 2026-11-30, que aún no llega. Son 95 días, 37.8 % sobre la base original, con 1 replanificación.
- **Presupuesto:** de 2.400.000.000 COP aprobados, hay 1.308.832.360 ejecutados. La proyección es 2.358.092.650. No se sabe si esa proyección incluye los 190.000.000 COP de CC-01.
- **Hitos:** la ingeniería de detalle, la licencia y el montaje figuran cumplidos sin evidencia. El montaje figura cerrado con fecha vigente futura.
- **Avance declarado:** 84 % y estado «verde», 16 puntos por debajo de lo que sostiene el cronograma.
- **CC-01:** lo pidió la misma persona que patrocina y gerencia el proyecto. Dice «autorizada por el comité» sin decir cuál. El comité del 2026-10-12 lista solo a Sandra Gil, dos veces, y no menciona el cambio.
- **RAID:** el ensayo que se repite y el riesgo de la ventana de parada no tienen doliente. El compromiso de Carlos Peña vence hoy y sigue abierto.
- **Lecciones:** solo escribí tres, todas sobre gobierno y ancladas a hechos documentados. Los documentos no dicen por qué se movió la fecha, así que no hay lección sobre causas técnicas.

No moví la carpeta a `archivo/` ni congelé la ficha; queda ofrecido para cuando alguien declare el cierre.

El archivo cambió en disco después de que lo escribí y no lo releí, así que no sé si el texto final es el que redacté.

La corrida quedó registrada como `2026-10-18-project-closure-1` con el acta como evidencia. El tiempo salió en 42 segundos; el número de documentos no se pudo medir.

Archivos en `/home/claude/banco/ronda-10/mineria/espacio/estado/corridas/`:
- salida-project-closure.md
