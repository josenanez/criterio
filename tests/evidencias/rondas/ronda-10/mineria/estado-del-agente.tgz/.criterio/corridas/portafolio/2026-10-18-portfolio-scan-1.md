# Corrida · 2026-10-18-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:50:39 · **Fin:** 2026-10-18T08:53:22 · **Duración:** 163 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 80 | 148 | 47 | Sin movimientos desde entrada/ (no existe). Se leyeron 54 de 80 documentos de 10 proyectos nuevos; PRY-203, 208 y 211 sin cambio. PRY-203 tiene 17 campos pm_record cuya fuente no resuelve. Falta cronograma v2 en PRY-205. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Barrido terminado. Leí 54 de 80 documentos, escribí y sellé 10 fichas nuevas, y la corrida quedó registrada con 47 hallazgos. Dejé la salida completa en `estado/corridas/salida-portfolio-scan.md`.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

- **Documentos:** 80 en la carpeta, 54 leídos, 26 sin cambio y 0 ilegibles. Todo cupo en un solo lote de 10 proyectos, sin diferidos.
- **Fichas nuevas:** PRY-199, 200, 201, 202, 204, 205, 206, 207, 209 y 210. PRY-203, 208 y 211 no cambiaron y no las toqué.
- **Entrada y clasificación:** no existe la carpeta `entrada/`, así que no moví ni dejé pendiente ningún archivo.
- **Campos sin dato:** autoridad y fase faltan en las 10 fichas. Producto falta en 6 (el acta dice «No aplica»). En 7 no hay proveedores. A PRY-201 y PRY-204 les faltan facturas de algún contrato.

Lo que más pesa en los hallazgos:
- **Hitos cerrados sin acta de recibo:** 21 en total. Solo hay acta para algunos hitos de PRY-199, 200, 202, 206 y 209.
- **Entregables «recibidos» sin acta, con factura radicada:**
  - **PRY-201 (CT-852):** 2 entregables, factura de 4.289.910.924.
  - **PRY-204 (CT-387):** la bolsa de horas, factura de 1.573.545.600.
  - **PRY-201 (CT-546):** hay acta, pero la factura (2.519.443.535) supera el monto de un entregable (1.810.007.449).
- **Cambios de cronograma:** PRY-202 pasó a v2 y PRY-205 a v3, con CC-01 (y CC-02 en PRY-205) «autorizadas por el comité» sin decir cuál. A PRY-205 le falta el cronograma v2 en la carpeta.
- **PRY-207:** el acta fijó cierre el 2026-07-30 y no hay plan posterior, pero el informe declara verde y 34%.
- **PRY-209:** el informe declara ejecutado mayor que comprometido.
- **PRY-210:** declara amarillo con 69%, con los cuatro hitos cerrados y el cierre previsto el 2026-08-29.
- **Compromisos:** hay 5 abiertos. En PRY-199, 200, 202 y 204 el responsable (Carlos Peña o Liliana Torres) no figura entre los asistentes de la reunión.
- **PRY-203:** 17 campos de su ficha citan fuentes que ya no resuelven. No los toqué, porque esa ficha no entró en el plan de lectura.

Siguiente paso: puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`.
