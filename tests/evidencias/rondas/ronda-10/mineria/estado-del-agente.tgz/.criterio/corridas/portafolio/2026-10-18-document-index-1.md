# Corrida · 2026-10-18-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:53:27 · **Fin:** 2026-10-18T08:53:58 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 19 | 47 | 80 documentos sin cambio, 0 por releer. 17 citas de PRY-203 sin resolver en 3 documentos que sí existen en disco; no sé la causa. |

Por señal (`document-index`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Carpeta al 2026-10-18

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

Los términos ya estaban vigentes (versión 0.5.0, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré otra vez.

No cambió el contenido de ningún documento. Tampoco hay documentos reguardados, renombrados ni borrados. El índice no reportó formatos ilegibles.

### Citas que dejaron de resolver
Hay 17 campos de la ficha de PRY-203 que ya no resuelven, repartidos en tres documentos:

| Documento citado | Campos de PRY-203 |
|---|---|
| `00-gobierno/2025-12-27-acta-constitucion.md` | identity (código, nombre, área, producto, patrocinador, gerente, comité), fecha de inicio, alcance, exclusiones, moneda, presupuesto aprobado |
| `10-plan/2025-12-27-cronograma-v1.xlsx` | fecha de fin |
| `20-seguimiento/2026-10-10-informe-avance.md` | estado declarado, % de avance, comprometido, ejecutado, proyección |

Los tres archivos sí están en el disco, dentro de la carpeta de PRY-203. No sé por qué el índice no los resuelve; hay que confirmarlo. Mientras tanto, la ficha sigue mostrando esos datos como sustentados y ya no lo están.

### Qué sigue
No ofrezco barrido, porque `projects_to_recompute` está vacío. Lo que sí hace falta es que alguien revise esas 17 citas de PRY-203. No propongo correcciones de rutas, porque no hay renombrados detectados.

La corrida quedó registrada como `2026-10-18-document-index-1`: 19 segundos, 13 proyectos. La salida está guardada en `estado/corridas/salida-document-index.md`.
