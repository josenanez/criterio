# Corrida · 2026-10-18-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-206 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-206

**Inicio:** 2026-10-18T09:03:19 · **Fin:** 2026-10-18T09:04:07 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 33 | 47 | Revisión del acta de PRY-206 (2026-04-22): falta autoridad del gerente, supuestos/restricciones y cadencia; objetivo, alcance, exclusiones y criterio de éxito presentes pero no medibles ni concretos. Dijo que no sabe nada fuera de 4 documentos (sin minutas ni solicitudes de cambio). |

Por señal (`project-charter`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Revisé el acta de PRY-206 (Red privada LTE en mina), aprobada el 2026-04-22. Le falta la autoridad del gerente, los supuestos y restricciones y la cadencia del comité. Los otros campos están, pero sin contenido útil. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hubo que volver a aceptarlos. Nadie respondió preguntas en esta sesión de prueba.

| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | Ausente | Nadie puede decir si Jorge Medina decide por sí mismo un cambio o debe subirlo al Comité de Tecnología. La proyección al cierre supera el aprobado en COP 96.957.949 (+2,3 %) y no hay umbral con qué juzgarlo. |
| Objetivo de negocio | Es la solución: «Entregar red privada lte en mina para Mina» | No dice qué mejora para el negocio, así que solo se puede saber si se instaló, no si sirvió. |
| Alcance | «Componente 1, 2 y 3», sin nombrarlos | No hay contra qué comparar el posible cambio de alcance por la licencia ambiental. |
| Exclusiones | «Lo que otro proyecto cubre» | No nombra el proyecto ni lo que cubre, así que no evita la discusión de alcance. |
| Supuestos y restricciones | Ausentes; dependencias «Ninguna declarada» | El cronograma tiene un hito de licencias y el informe cita riesgos de licencia ambiental y de vía de acceso. El acta dice que no hay dependencias. |
| Criterio de éxito | «En producción y medido», sin métrica | No dice qué se mide, con qué umbral ni quién lo mide. El cierre no tendría contra qué declararse. |
| Cadencia del comité | Ausente (el comité sí está nombrado) | No se puede decir si el proyecto está en silencio ante su comité. |

El patrocinador (Felipe Arango) y el gerente (Jorge Medina) son personas con nombre. Lo que no estaba en ningún documento lo dejé marcado como pendiente de definir, sin completarlo.

Una observación fuera del acta: la ingeniería básica tenía fecha de línea base 2026-08-13, pero su acta de recibo es del 2026-10-17 (65 días después). El cronograma sigue mostrándola como cerrada en la fecha original. No hay minutas, así que no pude contrastar qué pasó.

Leí solo 4 documentos: el acta, el cronograma v1, el informe del 2026-10-16 y el acta de recibo. No hay minutas ni solicitudes de cambio.

Puedo preparar la definición de autoridad del gerente como punto para el comité (el próximo es el 2026-10-29). También puedo pasar los supuestos implícitos al registro RAID. No hice ninguna de las dos cosas.

La corrida quedó registrada como `2026-10-18-project-charter-1`. Lo que te mostré está en `estado/corridas/salida-project-charter.md`.
