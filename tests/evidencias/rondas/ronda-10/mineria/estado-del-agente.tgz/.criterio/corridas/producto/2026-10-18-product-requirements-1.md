# Corrida · 2026-10-18-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:33:17 · **Fin:** 2026-10-18T08:33:57 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 12 | — | 23 | 30 | 4 aceptados sin evidencia (4802, 4803, 4806, 4809); 9 aceptados sin proyecto; 3 propuestos sin decidir; 1 sin doliente |

Por señal (`product-requirements`): `requirement_untraced` 9, `evidence_stale` 8, `requirement_accepted_without_evidence` 4, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Registro — Permisos de trabajo digitales (PRD-308) · al 2026-10-18

El registro tiene 12 requerimientos y 9 están decididos. El 55,6 % de los decididos tiene evidencia. Ninguno tiene un proyecto que lo ejecute (0 %).

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18, así que no los registré de nuevo.

**Se va a construir y nadie lo pidió.** Hay 4 aceptados sin ninguna cita de quien los pidió.
- REQ-4802: Gustavo Neira.
- REQ-4803: María Restrepo.
- REQ-4806: Carlos Peña.
- REQ-4809: sin asignar.

**Decidido y nadie lo construye.** Los 9 aceptados no tienen proyecto: REQ-4800, 4802, 4803, 4805, 4806, 4807, 4808, 4809 y 4811. El más antiguo es REQ-4803, aceptado el 2026-03-24.

**Sin doliente.** REQ-4809 figura como «sin asignar» y fue aceptado el 2026-06-19. Quien lo cierra es el Comité de producto, nombrando una persona.

**Sin criterio de aceptación.** Faltan en 4 aceptados: REQ-4803, 4805, 4806 y 4808.

**Decidido sin documento que lo respalde.** El único documento de decisión es el acta del 2026-10-15, con un solo asistente (Javier Hoyos). Las 9 aceptaciones son anteriores (2026-03-24 a 2026-08-05). No hay un acta de la fecha de cada una ni consta quién decidió. Es una observación mía, no una señal calculada. Habría que confirmar si existen actas anteriores que no están en la carpeta.

**Lleva meses y nadie lo decide.** La facultad de decidir es del Comité de producto, según la configuración. El umbral es de 60 días.

| REQ | Propuesto hace |
|---|---|
| REQ-4804 | 213 días |
| REQ-4801 | 120 días |
| REQ-4810 | 86 días |

**Evidencia vieja.** Toda la evidencia del registro es una misma entrevista con un cliente, del 2025-09-27, con 12 meses de antigüedad. Afecta a 8 requerimientos: REQ-4800, 4801, 4804, 4805, 4807, 4808, 4810 y 4811.

**De la definición.**
- El supuesto «Operaciones adopta la herramienta» lleva 158 días sin verificar.
- La cifra de volumen mensual del caso de negocio (98.890) no tiene medición contra la cual contrastarla.
- La definición no declara criterio de éxito.

**Por estado.** Hay 3 propuestos, 9 aceptados y ninguno en construcción, entregado o descartado.

La corrida quedó registrada como `2026-10-18-product-requirements-1` (23 segundos, 30 hallazgos). La salida completa está en `estado-producto/PRD-308/corridas/salida-product-requirements.md`.

El siguiente paso es `/product-trace` para los 9 decididos sin proyecto.
