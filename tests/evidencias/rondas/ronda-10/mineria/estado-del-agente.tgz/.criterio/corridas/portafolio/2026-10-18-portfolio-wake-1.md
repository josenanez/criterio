# Corrida · 2026-10-18-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T09:09:22 · **Fin:** 2026-10-18T09:09:56 · **Duración:** 34 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 21 | 47 | Barrido: 80 documentos, 0 cambiaron. 18 citas de PRY-203 reportadas sin resolver aunque los archivos existen (probable ruta de la ficha), sin verificar. Confirmación mensual no corrida: sin interlocutor y sin fichas en estado/records. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## 2026-10-18

**Revisé:** 80 documentos. Ninguno cambió y no recalculé ningún proyecto.

- **Umbrales:** nada cruzó un umbral. No hay documentos nuevos, cambiados, renombrados ni borrados.
- **Citas rotas en PRY-203:** el índice reporta 18 campos de la ficha con la fuente sin resolver. Son el acta de constitución del 2025-12-27, el cronograma v1 y el informe de avance del 2026-10-10. Los tres archivos existen en la carpeta del proyecto. La ficha está en `estado/PRY-203-despacho-automático-de-flota/records/`, no en `estado/records/`, que está vacía. Lo más probable es que el índice la compare contra una ruta distinta, pero no lo verifiqué. Queda como hallazgo abierto y no toqué la ficha.
- **Confirmación mensual:** tocaba (cinco campos), pero no la hice. En esta sesión nadie responde y `estado/records/` está vacía, así que no había fichas de donde elegir los campos. No hice preguntas y no la marqué como corrida.
- **Peticiones:** `due` no marcó `requests`, así que no corrí ese paso.
- **Términos:** ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-18), así que no los registré de nuevo.

**Vuelvo el 2026-10-19.** El informe de comité sale el 2026-10-27, para el comité del 2026-10-29.

La corrida quedó registrada en `estado/corridas/` con el texto de esta salida (`salida-portfolio-wake.md`). Marqué el barrido como hecho con `ran`. La nota de la corrida dice lo que no pude verificar.
