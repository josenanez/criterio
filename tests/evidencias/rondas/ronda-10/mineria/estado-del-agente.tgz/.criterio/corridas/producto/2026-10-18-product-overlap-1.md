# Corrida · 2026-10-18-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-301

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-301

**Inicio:** 2026-10-18T09:12:03 · **Fin:** 2026-10-18T09:12:11 · **Duración:** 8 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No encontré la configuración de PRD-301, así que me detengo aquí.

Busqué en `.criterio/producto/PRD-301/config.json`, dentro de la carpeta donde corre la sesión. Esa carpeta no existe. En `.criterio/producto/` solo hay una: `PRD-308`.

No usé la de PRD-308 en lugar de la de PRD-301, y no inventé una configuración. Tampoco corrí `terminos`, `corrida-inicio` ni `overlap`, y no registré la aceptación de términos. Sin configuración no hay `--config` ni `--state` con los que correrlos.

Para seguir hay dos caminos:
- **Configurar PRD-301:** `/criterio-product:product-setup` crea esa configuración. Después se vuelve a correr `/product-overlap PRD-301`.
- **Si se quería PRD-308:** se corre `/product-overlap PRD-308`.
