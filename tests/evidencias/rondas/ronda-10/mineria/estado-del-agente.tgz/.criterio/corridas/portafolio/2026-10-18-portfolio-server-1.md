# Corrida · 2026-10-18-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T09:10:00 · **Fin:** 2026-10-18T09:10:43 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 47 | puerto 8787, carpeta del informe reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Rostrum funciona con el informe de este portafolio, pero en el puerto 8788, no en el 8787. El 8787 ya lo ocupaba otro servidor que sirve un informe distinto. Sus productos son ahorro-a-la-vista, microcredito y otros, y no coinciden con los de esta carpeta. No lo toqué.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18). No registré nada nuevo.
- **Modo:** «para mirarlo un rato», como pedía el argumento. Escucha solo en `127.0.0.1`, sin autenticación, y no hubo nada que pedirle a seguridad.
- **Informe servido:** `reportes/`, con 13 proyectos (PRY-199 a PRY-211) y 6 productos. Es del 2026-10-18 y tiene 0 peticiones abiertas.
- **Corrida:** quedó registrada como `2026-10-18-portfolio-server-1`, y lo que le mostré a la persona está en `estado/corridas/salida-portfolio-server.md`.
- **Estado ahora:** la prueba la levanté con un límite de 30 segundos, así que ya se apagó. Para dejarlo corriendo, ejecuta esto en `/home/claude/banco/ronda-10/mineria/espacio` y para con Ctrl-C:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json --puerto 8788
```

**Qué enlace pasarle a quién:**
- `http://127.0.0.1:8788/` y `/pmo` son para la PMO.
- `/decisiones` es para el comité y el patrocinador, pero solo se abre desde esta máquina. El patrocinador no puede usar estos enlaces.
- Para darle un enlace que funcione mañana hay que pasar a «que quede corriendo» (`--abierto`). Eso pide un host y puerto internos, y publicarlo detrás del control de acceso de la organización.

El informe es del 2026-10-18 y se desactualiza cuando se corra de nuevo `/portfolio-report html`. La portada muestra su fecha.
