# Corrida · 2026-10-18-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-201

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-18T08:54:02 · **Fin:** 2026-10-18T08:54:48 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 29 | 47 | Estado de PRY-201 con verde declarado (2026-10-08) contradicho: 4 hitos cumplidos sin evidencia, avance 48% vs 80-100% del plan, facturación CT-546 sobre lo aceptado, 2 licenciamientos vencidos. Sin dato: autoridad, fase, minutas/reuniones, valoración de riesgos. |

Por señal (`status-report`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Registrada la corrida `2026-10-18-status-report-1`; el informe de PRY-201 queda así:

## PRY-201 · Ampliación de la relavera — estado al 2026-10-18

Sale de la ficha `estado/records/PRY-201.json`, actualizada el 2026-10-18. Los términos v1.1 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18.

**Declara el gerente (Mauricio Pérez):** verde · 48% · al 2026-10-08, hace 10 días, así que la declaración no está vencida.
**Sustento documental:** contradicho. La ficha no tiene ninguna fuente de evidencia.
**Lo que el semáforo no explica:**
- Cuatro hitos figuran como cumplidos sin evidencia.
- El avance declarado es 48% y el plan sustenta entre 80% y 100%, una brecha de 32.0 puntos.
- Hay dos entregables de licenciamiento vencidos.
- CT-546 está facturado por encima de lo aceptado.

**Último documento:** 2026-10-08, hace 10 días y por debajo del umbral de 15. **Última reunión:** sin dato, porque la carpeta no tiene minutas.

### Contra el plan
| | Original | Vigente | Desviación |
|---|---|---|---|
| Cierre | 2026-12-15 | 2026-12-15 | 0 días |
| Presupuesto | COP 18.000.000.000 | COP 18.000.000.000 | La proyección es COP 18.496.508.384, un 2.8% sobre lo aprobado (el umbral es 10%) |

Hay 0 replanificaciones y solo existe la línea base v1.

### Hitos
Las fechas vigentes son iguales a las de línea base.

| Hito | Fecha | Estado | Evidencia |
|---|---|---|---|
| Ingeniería básica | 2025-12-20 | cumplido | ninguna |
| Ingeniería de detalle | 2026-03-20 | cumplido | ninguna |
| Licencia y permisos | 2026-06-18 | cumplido | ninguna |
| Montaje e instalación | 2026-09-16 | cumplido | ninguna |
| Pruebas en operación | 2026-12-15 | pendiente | — |

### Dónde no coincide
- **CT-546:** está facturado COP 2.519.443535 contra COP 1.810.007.449 aceptado, una diferencia de COP 709.436.086. El licenciamiento lleva 227 días de atraso.
- **CT-852:** la factura de COP 4.289.910.924 iguala la suma de dos entregables «aceptados» que no tienen acta de recibo. El licenciamiento lleva 268 días de atraso.
- **El propio informe del 2026-10-08:** reporta una parada de planta reprogramada y un proveedor sin fecha confirmada, y aun así declara verde.

### Abierto
- **Riesgos e incidencias sin movimiento:** hay 2 riesgos y 1 incidencia, ninguno con fecha de último movimiento, así que no se pueden contar días.
- **Compromisos vencidos:** ninguno, pero tampoco hay compromisos registrados.
- **Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- No hay autoridad de decisión, fase ni reuniones.
- Faltan la evidencia de los hitos y las actas de recibo de CT-852.
- Los riesgos no traen valoración ni responsable.
- Los campos de identidad, plan y presupuesto tienen 13 meses de antigüedad, por encima del umbral de 12.

### Siguiente paso
Las facturas por encima de lo aceptado pueden exceder la autoridad del gerente, y esa autoridad no está definida en ningún documento. Puedo preparar el punto para el comité del 2026-10-29 con `/steering-pack`.

**Pie:** criterio-portfolio 0.5.0 · ficha del 2026-10-18 sobre documentos hasta el 2026-10-08 · campos inciertos: autoridad, fase, evidencia de hitos y valoración de riesgos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

El texto completo está en `/home/claude/banco/ronda-10/mineria/espacio/estado/corridas/salida-status-report.md`. La corrida midió 29 segundos, pero no el número de documentos leídos.
