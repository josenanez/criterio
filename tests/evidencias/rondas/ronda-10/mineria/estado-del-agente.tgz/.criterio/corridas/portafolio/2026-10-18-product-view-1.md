# Corrida · 2026-10-18-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view monitoreo de flota

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T09:07:35 · **Fin:** 2026-10-18T09:08:17 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 26 | 47 | Producto con un solo proyecto (PRY-200): sin sección de producto. Verde declarado sin sustento (avance 57% vs plan 75-100%, hito de licencias sin evidencia). Siete proyectos sin producto declarado reportados. No supe si la licencia existe ni el área dueña de los proyectos sin producto. |

Por señal (`product-view`): `milestone_met_without_evidence` 21, `progress_vs_plan` 7, `declared_vs_evidence` 6, `vendor_deliverable_late` 5, `vendor_accepted_without_evidence` 3, `variance_time` 2, `vendor_invoiced_over_accepted` 1, `variance_cost` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**Monitoreo de flota tiene un solo proyecto, PRY-200, así que no armé sección de producto.** La vista por producto no aporta nada con un proyecto, y tampoco hay dependencias internas que llevar al comité del 2026-10-29.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo. La vista sale de las fichas con el cálculo del 2026-10-18.

**PRY-200, Mantenimiento predictivo de camiones**
- **Estado:** declara verde (informe del 2026-10-17, avance 57 %). La evidencia no lo sostiene: son tres alertas abiertas.
  - El plan (3 de 4 hitos cumplidos) sostiene entre 75 y 100 %, es decir, 18 puntos más de lo declarado.
  - El hito «Licencia y permisos obtenidos» venció el 2026-08-19 (hace 60 días) y está dado por cumplido sin evidencia.
  - El verde declarado queda contradicho por las dos anteriores.
- **Fecha:** 2026-11-05, sin replanificaciones ni desviación contra la línea base.
- **Dinero (COP):**

  | Concepto | Monto |
  |---|---|
  | Aprobado | 1.200.000.000 |
  | Comprometido | 873.204.376 |
  | Ejecutado | 405.049.006 |
  | Proyección | 1.258.073.437 |

  La proyección queda 4,8 % sobre lo aprobado, por debajo del umbral de 10 %. El proyecto trae las cuatro cifras.
- **Sin ejecutar:** autoridad y fase faltan en la ficha, y ninguna fuente está marcada como evidencia.

**Gobierno:** siete de 13 proyectos no declaran producto: PRY-201, 202, 205, 206, 209, 210 y 211. Nadie puede responder por el conjunto al que sirven, ni saber si alguno construye lo mismo que monitoreo de flota.

**Lo que no sé:** si la licencia y los permisos existen o solo falta el documento, y quién es el área dueña de esos siete proyectos, porque el cálculo no la da.

El texto completo está en `estado/corridas/salida-product-view.md`. La corrida quedó registrada como `2026-10-18-product-view-1`: 26 segundos, 13 proyectos, 47 hallazgos en el portafolio.
