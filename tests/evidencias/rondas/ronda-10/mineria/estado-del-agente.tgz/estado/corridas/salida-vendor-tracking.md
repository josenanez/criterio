*Sale de: acta de constitución, contratos CT-546 y CT-852, cronograma v1, acta de recibo CT-546, facturas FV-1546 y FV-2852 e informe de avance del 2026-10-08, todos de la carpeta de PRY-201. Cifras copiadas de `portafolio.py compute` (as_of 2026-10-18). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-18.*

## Proveedores — PRY-201 Ampliación de la relavera al 2026-10-18

Hay dos contratos. Los dos tienen entregables vencidos sin evidencia de recibo, y los dos están facturados por encima de lo que la evidencia sustenta. Lo hallado es de evidencia documental; lo que se haya hablado fuera de los documentos no lo sé.

### Automatización de Procesos Ltda. — contrato CT-546
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-09-09) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (1.810.007.449 COP) | 2026-03-05 | `pending`, vencido hace 227 días | ninguna | Dentro de FV-1546 |
| Bolsa de horas de ingeniería (1.810.007.449 COP) | 2026-08-17 | `accepted` | Acta de recibo 2026-09-05, firmada por Mauricio Pérez (`20-seguimiento/2026-09-05-acta-recibo-ct-546-…md`) | Dentro de FV-1546 |

Facturado en total (FV-1546, 2026-09-28): **2.519.443.535 COP**. Aceptado con evidencia: **1.810.007.449 COP**. Diferencia: **709.436.086 COP** facturados sin entregable aceptado que los respalde.

### Servicios Ambientales del Norte — contrato CT-852
**Vigencia:** sin dato (solo fecha de firma, 2025-09-18) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (2.144.955.462 COP) | 2026-01-23 | `pending`, vencido hace 268 días (el contrato dice «en curso») | ninguna | Dentro de FV-2852 |
| Bolsa de horas de ingeniería (2.144.955.462 COP) | 2026-05-27 | `accepted` (el contrato dice «recibido») | **ninguna: no hay acta de recibo** | Dentro de FV-2852 |
| Calibración de sensores (2.144.955.462 COP) | 2026-09-27 | `accepted` (el contrato dice «recibido») | **ninguna: no hay acta de recibo** | Dentro de FV-2852 |

Facturado en total (FV-2852, 2026-09-18): **4.289.910.924 COP**. Los dos entregables «recibidos» suman 4.289.910.924 COP, así que el cálculo los da por aceptados y la diferencia con lo facturado es 0. Pero esa aceptación descansa solo en la palabra «recibido» del contrato, sin un solo documento de recibo.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-546: pago | Cada entregable se factura contra acta de recibo firmada por el gerente | Hay un acta (bolsa de horas) y la factura cubre 2.519.443.535 COP, que son 709.436.086 COP más que el único entregable con acta | CT-546 (cláusula de pago); acta 2026-09-05; FV-1546 |
| CT-852: pago | Misma condición de pago | Se facturaron 4.289.910.924 COP sin ninguna acta de recibo en la carpeta | CT-852; FV-2852 |
| CT-852: estado de entregables | «recibido» en bolsa de horas y calibración | Ningún documento de recibo; el informe no los sustenta | CT-852; carpeta `20-seguimiento` |
| Estado del proyecto | — | El informe del 2026-10-08 declara verde y 48 % de avance; el plan con 4 de 5 hitos cumplidos sustenta entre 80 y 100 %. Los 4 hitos figuran cumplidos sin evidencia (302, 212, 122 y 32 días desde su fecha). Brecha: 32 puntos. | Informe 2026-10-08; cronograma v1 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-852 · Bolsa de horas de ingeniería | `accepted` («recibido» en el contrato) | Fecha comprometida 2026-05-27; no hay fecha de recibo en ningún documento |
| CT-852 · Calibración de sensores | `accepted` («recibido» en el contrato) | Fecha comprometida 2026-09-27; no hay fecha de recibo en ningún documento |

Por la regla del registro, el estado sin evidencia es `unknown`, no `delivered`: tómenlos como no demostrados mientras no aparezca el acta.

### Compromisos del proveedor vencidos
Sin dato. No hay minutas ni reuniones en la carpeta de PRY-201, así que no pude revisar qué prometió ningún proveedor en comité. El informe del 2026-10-08 menciona como riesgo que «el proveedor no ha confirmado la fecha de la última entrega», sin dueño ni fecha.

### Sin dato
- **Vigencia, renovación automática y preaviso:** ninguno de los dos contratos los trae. No puedo decir si hay un preaviso por vencer antes del cierre del proyecto (2026-12-15). Hay que pedir las condiciones completas o el anexo de vigencia.
- **Fecha de recibo de la bolsa de horas de CT-852 y de la calibración:** no existe documento.
- **Desglose de las facturas:** FV-1546 y FV-2852 dicen «entregables del contrato» sin detallar a cuáles corresponden; asumí el cruce por monto, y por eso la diferencia de CT-546 es un cálculo, no una declaración de la factura.
- **Fuente del informe de avance:** el PDF del 2026-10-08 no lo releí en esta corrida; uso lo que la ficha ya tiene de él.

### Qué sigue
Hay entregables facturados sin evidencia de recibo en ambos contratos (709.436.086 COP en CT-546 y 4.289.910.924 COP en CT-852 sin ningún acta), y los dos licenciamientos llevan más de 200 días vencidos. Conviene llevarlo a comité (próximo: 2026-10-29) y pedir antes las actas, o bloquear el pago pendiente. Dime si lo preparo con `/steering-pack`.

---
*Pie de rigor: borrador de trabajo para verificar contra los documentos citados; no es una decisión ni asesoría. Una persona debe confirmar las actas ausentes antes de actuar sobre los pagos.*
