# Corrida del 2026-10-18 · product-view

13 proyectos · 26 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Producto con un solo proyecto (PRY-200): sin sección de producto. Verde declarado sin sustento (avance 57% vs plan 75-100%, hito de licencias sin evidencia). Siete proyectos sin producto declarado reportados. No supe si la licencia existe ni el área dueña de los proyectos sin producto.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-18 — monitoreo de flota

**Fuente:** fichas del portafolio en `estado/`, cálculo de `portafolio.py compute` del 2026-10-18 (13 proyectos, 6 productos). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

**Monitoreo de flota tiene un solo proyecto (PRY-200).** La vista por producto no aporta nada aquí: no hay grupo que sumar ni dependencias internas que cruzar. Va la lectura del proyecto, sin sección de producto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| monitoreo de flota | 1 (PRY-200) | 1 (3 alertas) | 2026-11-05 | 1.200.000.000 COP | 873.204.376 COP |

**PRY-200 — Mantenimiento predictivo de camiones**

- **Estado declarado:** verde, a 2026-10-17 (hace 1 día), avance declarado 57 %. Fuente: `PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-17-informe-avance.md`.
- **El verde no lo sostiene la evidencia.** El informe no da cuenta de dos señales abiertas:
  - **Avance contra plan:** declara 57 % y el plan (3 de 4 hitos cumplidos) sostiene entre 75 y 100 %. Brecha de 18 puntos, por debajo de lo que el plan indica.
  - **Hito dado por cumplido sin evidencia:** «Licencia y permisos obtenidos», vencía el 2026-08-19 (hace 60 días), declarado cumplido y sin documento que lo sustente.
- **Fecha:** 2026-11-05. Sin replanificaciones y sin desviación contra la línea base (0 días contra la original y contra la vigente). Sin cambios de alcance registrados.
- **Dinero (COP):** aprobado 1.200.000.000; comprometido 873.204.376 (72,8 %); ejecutado 405.049.006 (33,8 %); proyección 1.258.073.437 (4,8 % sobre lo aprobado, por debajo del umbral de 10 %). Disponible real 326.795.624. Trae las cuatro cifras: 1 de 1 proyecto.
- **Sin proveedores, compromisos vencidos ni dependencias** en la ficha.
- **Datos que faltan:** autoridad (`identity.authority`) y fase (`identity.phase`). Ninguna fuente de la ficha está marcada como evidencia: 2 son declaraciones y 21 no están marcadas.

**Lo que no sé:** si la licencia y los permisos existen. Puede que estén y falte el documento en la carpeta, o que no estén; el cálculo no puede distinguirlo. Tampoco sé por qué el avance declarado queda 18 puntos por debajo de lo que sostienen los hitos. Con la fecha de cierre al 2026-11-05 (18 días), conviene resolverlo antes.

**Proyectos sin producto declarado (hallazgo de gobierno)**

Siete de 13 proyectos no declaran a qué producto sirven: PRY-201, PRY-202, PRY-205, PRY-206, PRY-209, PRY-210 y PRY-211. Consecuencia: nadie puede responder por el conjunto al que sirven, y no se puede saber si alguno construye lo mismo que monitoreo de flota. El área dueña no sale del cálculo y no la invento.

**Dependencias internas:** ninguna por confirmar (el producto tiene un solo proyecto), así que no hay nada que llevar al comité de producto del 2026-10-29.

---
*Pie de rigor:* cifras copiadas de `compute` con todos sus dígitos; ninguna fuente de PRY-200 está marcada como evidencia, todo sale de declaraciones o de texto sin marcar; verifique las citas antes de actuar. Criterio produce borradores de trabajo, no decisiones ni asesoría.
