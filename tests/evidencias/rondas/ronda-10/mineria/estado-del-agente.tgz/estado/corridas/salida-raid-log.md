**Sale de:** las 13 fichas de `estado/records` (PRY-199 a PRY-211) con su RAID; las 13 actas de constitución (sección «Dependencias declaradas»); 14 documentos de reunión (6 minutas semanales y las notas del 2026-10-18 de PRY-203, más 1 minuta en cada uno de PRY-199, 200, 202, 204, 208, 209 y 211); y los «Riesgos abiertos» de los informes de avance, tal como los recogen las fichas. PRY-201, 205, 206, 207 y 210 no tienen minutas en la carpeta. Los informes no se releyeron enteros: se tomó lo que dicen las fichas.

Los Id (`199-R1`, `203-D1`…) son provisionales de esta corrida: el registro existente no trae identificadores. R = riesgo, S = supuesto, I = incidencia, D = dependencia.

## RAID — portafolio al 2026-10-18
12 riesgos · 0 supuestos · 13 incidencias · 9 dependencias (+1 no registrada formalmente)
35 sin doliente (34 registrados + 1 no registrado) · sin movimiento: no se puede medir (ver abajo) · 1 no registrado formalmente

- **Reclasificados:** 9 de los 21 «riesgos» que traían las fichas son dependencias (6 «ventana de parada de planta» y 3 «proveedor sin confirmar fecha»). El detalle está en la sección de dependencias.
- **Valoración:** ningún ítem trae probabilidad ni impacto. No se usó una escala inventada; quedan sin valorar.
- **Doliente y fecha:** ningún ítem de los 35 trae doliente ni fecha. Es un hallazgo, no se rellenó.
- **Movimiento:** ningún riesgo trae fecha de último movimiento y solo hay una foto del portafolio (2026-10-18). Por eso «sin movimiento en dos períodos» no se puede afirmar ni descartar. Las incidencias traen la fecha del informe en que aparecen como «desde».
- **Supuestos y dependencias:** el registro no tiene ninguno, y las 13 actas dicen «Ninguna declarada» en dependencias. No levanté supuestos que nadie dijo. Pero hay 9 dependencias de hecho (ver abajo) que ningún proyecto declaró.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 201-D1, 202-D1, 203-D1, 204-D1, 210-D1, 211-D1 | Dependencia (antes «riesgo») | «Ventana de parada de planta definida por operaciones» | Falta. Lo define Operaciones, un área externa a los proyectos | Informes del 2026-09-30 al 2026-10-18 | Afecta a más de un proyecto. La misma frase aparece en 6 proyectos como riesgo y en 6 como incidencia «se reprogramó la parada de planta» (199, 201, 206, 207, 209, 210). Todos los informes con alguna de las dos son 10 de 13. Los documentos no dicen si es la misma parada. Hay que confirmarlo. **Decisión a formular:** que Operaciones fije y confirme por escrito una ventana, con un doliente nombrado. |
| 208-D1 | Dependencia (antes «riesgo») | El proveedor no ha confirmado la fecha de la última entrega | Falta | 2026-10-13 | PRY-208 está en rojo. Montaje previsto 2026-11-07, pendiente. Su CC-01 (+26 días, 52.000.000 COP) sigue pendiente desde el 2026-10-18. **Decisión a formular:** exigir fecha al proveedor antes de resolver el CC-01. |
| 211-D2 y 201-D2 | Dependencia (antes «riesgo») | Mismo texto: proveedor sin confirmar fecha de la última entrega | Falta | 2026-10-18 (211) y 2026-10-08 (201) | PRY-211: montaje previsto 2026-11-09, pendiente. PRY-201: el hito de montaje figura cumplido (2026-09-16) y aun así la última entrega no tiene fecha. Una de las dos cosas no cuadra. Pedir aclaración al gerente. |
| 200-I1 (con 200-R2) | Incidencia y riesgo materializado | Dos semanas perdidas por rotación de un ingeniero clave; sigue abierto «concentración del conocimiento» | Falta | 2026-10-17 | El riesgo ya ocurrió y se sigue llevando como riesgo. El hito de montaje es el 2026-11-05, a 18 días. |
| 205-I1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | Falta | 2026-10-15 | PRY-205 está en rojo. Tiene dos cambios aprobados en una semana (CC-01, CC-02: +146 días y 292.000.000 COP en total) y no hay doliente de la incidencia. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-203) | Dependencia de proveedor, declarada y sin confirmar. La ficha lo lleva como riesgo sin doliente. Por la prueba rápida es dependencia: el proveedor está fuera del proyecto | `PRY-203…/2026-10-18-notas-reunion.txt` | 2026-10-18 |

**No es un riesgo, y lo dejo en una línea:** en esas notas Óscar Ramírez queda con «revisión con el proveedor» para el 2026-10-28. Es la única acción fechada ligada a esa dependencia, y no está registrada como mitigación. El seguimiento de ese compromiso y de los otros de las notas (María Restrepo, 19/12/2026; Laura Vélez, «la otra semana») es de `pm-commitments`.

Las otras 13 minutas (PRY-199, 200, 202, 203 del 09-06 al 10-11, 204, 208, 209, 211) solo traen temas genéricos y compromisos. No hay ahí riesgos dichos al pasar, y no inventé ninguno. Quedan sin minutas PRY-201, 205, 206, 207 y 210. En esos cinco no se pudo buscar nada.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 35 ítems de la tabla completa | R / I / D | Todos | Doliente y fecha. Probabilidad e impacto en los 21 riesgos y dependencias que vienen como riesgos |

No propongo doliente aquí; está en «Después».

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| 201-D1, 202-D1, 203-D1, 204-D1, 210-D1, 211-D1 | Operaciones (área, sin código de proyecto) | No (declarada por el informe, no acordada) | 201 y 210 reportan que la parada ya se reprogramó. Los demás no reportan movimiento |
| 201-D2, 208-D1, 211-D2, 203-D2 (no registrada) | Proveedor. Los informes no lo nombran. PRY-201 tiene los contratos CT-546 y CT-852, pero no dice cuál es | No | Ninguno trae fecha de entrega. En PRY-203 solo existe el comentario en reunión |

**Cruce entre proyectos:** no se pudo hacer. Ninguna dependencia apunta a un código PRY, así que no hay un proyecto cuyo movimiento de fecha la ponga en riesgo. Por eso el cruce por código no detecta nada, y eso no significa que no haya dependencias entre proyectos. Quien las conozca debería registrarlas con el código.

### Registro completo
Prob., Impacto, Doliente y Fecha: sin dato en todos los ítems (—). «Último movimiento»: en incidencias es la fecha del informe donde aparece. En riesgos y dependencias no existe.

| Id | Tipo | Qué | Último movimiento |
|---|---|---|---|
| 199-R1 | Riesgo | Concentración del conocimiento en una sola persona | — |
| 199-I1 | Incidencia | Primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | 2026-10-16 |
| 199-I2 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-16 |
| 200-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — |
| 200-R2 | Riesgo | Concentración del conocimiento en una sola persona | — |
| 200-I1 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | 2026-10-17 |
| 201-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 201-D2 | Dependencia (reclasificada) | Proveedor no ha confirmado la fecha de la última entrega | — |
| 201-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-08 |
| 202-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 202-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-13 |
| 203-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 203-D2 | Dependencia (no registrada formalmente) | Proveedor podría no llegar con el equipo completo para la siguiente fase | 2026-10-18 |
| 204-R1 | Riesgo | Concentración del conocimiento en una sola persona | — |
| 204-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 204-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-09-30 |
| 205-R1 | Riesgo | Concentración del conocimiento en una sola persona | — |
| 205-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-15 |
| 206-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — |
| 206-R2 | Riesgo | Bloqueo de la vía de acceso a la mina | — |
| 206-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-16 |
| 207-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — |
| 207-R2 | Riesgo | Bloqueo de la vía de acceso a la mina | — |
| 207-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-11 |
| 207-I2 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-11 |
| 207-I3 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | 2026-10-11 |
| 208-D1 | Dependencia (reclasificada) | Proveedor no ha confirmado la fecha de la última entrega | — |
| 209-R1 | Riesgo | Concentración del conocimiento en una sola persona | — |
| 209-R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — |
| 209-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-13 |
| 210-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 210-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — |
| 210-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | 2026-10-15 |
| 211-D1 | Dependencia (reclasificada) | Ventana de parada de planta definida por operaciones | — |
| 211-D2 | Dependencia (reclasificada) | Proveedor no ha confirmado la fecha de la última entrega | — |

PRY-208 y PRY-211 no traen incidencias registradas. PRY-203 no trae ninguna.

### Reclasificaciones y cosas que no cuadran
- **Ventana de parada de planta (6 ítems) y proveedor sin fecha (3 ítems):** estaban como riesgos. Dependen de alguien fuera del proyecto, así que son dependencias y no se mitigan: se coordinan y se confirman.
- **Riesgo ya ocurrido:** en PRY-200, «concentración del conocimiento» sigue como riesgo y la incidencia «rotación de un ingeniero clave» ya ocurrió. En PRY-201 y PRY-210, la «ventana de parada» sigue como dependencia mientras la reprogramación de parada ya se reportó como incidencia. Hay que decidir si el ítem original se cierra o se sigue gestionando.
- **Texto repetido que no cuadra con la fase** (verificar con el gerente, no lo doy por falso): PRY-199, aún en ingeniería (detalle prevista 2027-01-24), reporta un «primer ensayo de disponibilidad de los equipos» y una parada de planta reprogramada. PRY-206, también en ingeniería, reporta la parada reprogramada. PRY-204, con permisos pendientes, reporta el ensayo. La misma frase se repite palabra por palabra en varios informes.
- **PRY-207:** reporta lluvias que detuvieron el montaje, pero no hay cronograma ni hitos, y la fecha de cierre del acta (2026-07-30) ya pasó sin documento posterior.
