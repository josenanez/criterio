## Carpeta al 2026-10-18

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-203 | pm_record.identity.code, name, business_area, product, sponsor, manager, committee | 00-gobierno/2025-12-27-acta-constitucion.md |
| PRY-203 | pm_record.plan.start_date, scope_summary, exclusions | 00-gobierno/2025-12-27-acta-constitucion.md |
| PRY-203 | pm_record.money.currency, approved | 00-gobierno/2025-12-27-acta-constitucion.md |
| PRY-203 | pm_record.plan.end_date | 10-plan/2025-12-27-cronograma-v1.xlsx |
| PRY-203 | pm_record.declared.status, progress_pct | 20-seguimiento/2026-10-10-informe-avance.md |
| PRY-203 | pm_record.money.committed, executed, projection | 20-seguimiento/2026-10-10-informe-avance.md |

17 campos de PRY-203, repartidos en 3 documentos. Los tres archivos aparecen en el disco, dentro de la carpeta PRY-203-despacho-automático-de-flota. El índice no los resuelve: la ruta citada en la ficha no coincide con la que el índice conoce. No sé por qué. Falta confirmarlo.

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Pendiente
Con `hay que releer` en cero no se ofrece barrido (`projects_to_recompute` está vacío). Las 17 citas de PRY-203 sí necesitan revisión de una persona.
