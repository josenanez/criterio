Sale de la ficha `estado/records/PRY-201.json` (Ampliación de la relavera), corte del informe 2026-10-08, y del cálculo `portafolio.py impact`.

## Solicitud de cambio — PRY-201 Ampliación de la relavera — 2026-10-18

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta en ningún documento de la carpeta (la solicitud llegó por la PMO, sin solicitud escrita). · **Por qué:** no consta. El informe del 2026-10-08 dice que «se reprogramó la parada de planta por la ventana de mantenimiento», pero no la liga a este cambio ni da fecha nueva; es una pista, no un motivo sustentado.

**Supuesto que hay que confirmar:** el plan no tiene un hito llamado «salida a producción». Lo más cercano es «Pruebas en operación» (2026-12-15), que coincide con el cierre. Evalúo el cambio como mover ese hito y el cierre de 2026-12-15 a 2027-01-14.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta 2025-09-12) | No declarado | Sin impacto declarado |
| Tiempo | Cierre 2026-12-15 (línea base 1) | 2027-01-14 | +30 días |
| Costo | Aprobado 18.000.000.000 COP; proyección 18.496.508.384 COP | No declarado | Sin impacto declarado |

**Quién absorbe lo que no se declaró:** nadie lo dice. Mover 30 días sin tocar costo ni alcance significa que alguien lo absorbe en horas no pagadas o en calidad, o que el costo existe y no se escribió. Con el dato que hay, un mes más de equipo y de contratos vigentes no es costo cero. No lo estimo: ninguna ficha trae tarifa ni holgura.

Contexto de costo, sin relación demostrada con el cambio: la proyección ya supera lo aprobado en 496.508.384 COP (2,8 %) y el estado declarado sigue en verde. Se ha ejecutado el 57,1 % del presupuesto (10.279.560.112) con 48 % de avance declarado. El umbral de la PMO es 10 %, así que no cruza, pero ese margen es lo que queda para absorber.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo no encontró proyectos que dependan de PRY-201 (0 alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar) | — |

**Esto no equivale a «no afecta a nadie».** El acta de PRY-201 declara «Ninguna declarada» como dependencia, y la ficha no tiene dependencias en RAID. El cálculo solo recorre lo declarado. Hay dos señales de que puede haber efecto que nadie escribió:
- «Ventana de parada de planta definida por operaciones» es un riesgo abierto, y la parada ya se reprogramó. Operaciones depende de esta fecha y no figura como dependencia.
- «El proveedor no ha confirmado la fecha de la última entrega» (riesgo abierto, sin dueño).

Hito por el que pasa el cambio: «Pruebas en operación», 2026-12-15, a 58 días. Cuántos días se mueve cada actividad no se puede decir: la ficha no tiene holgura por actividad.

### Quién decide
**Autoridad requerida:** no se puede determinar. La autoridad de cambio de PRY-201 no aparece en ningún documento (`identity.authority`: no encontrada). Ese es el hallazgo de fondo. · **Según:** acta 2025-09-12: solo dice que el presupuesto lo aprobó el Comité de Seguridad, sin umbrales de tiempo ni de costo ni quién aprueba cambios. Patrocinador: Natalia Ospina. Gerente: Mauricio Pérez. · **Va a comité:** sí, por defecto, mientras nadie demuestre autoridad individual. Propuesta: Comité de Seguridad, que aprobó el presupuesto. El próximo comité de la PMO es el 2026-10-29.

### Si no se aprueba
El proyecto sigue con cierre el 2026-12-15, que es lo único aprobado. El informe del 2026-10-08 ya declara una parada de planta reprogramada y un proveedor sin fecha de última entrega, y aun así reporta verde. Si la fecha real ya es otra, el plan vigente está desactualizado y la desviación se está acumulando sin registro.

### Si se aprueba
Línea base 2 — cierre 2027-01-14 · presupuesto 18.000.000.000 COP, a menos que el comité apruebe otro monto (no se pidió ninguno) · motivo: por documentar; hoy no consta (candidato a verificar: reprogramación de la parada de planta).
La línea base 1 (2025-09-12, cierre 2026-12-15) no se toca. Replanificaciones: de 0 a 1.
**Desviación acumulada contra la línea base original:** tiempo +30 días (+30 sobre 2026-12-15, hoy 0 registrada) · costo +496.508.384 COP (+2,8 %) por la proyección vigente contra lo aprobado; el cambio no declara costo propio.

### Otros hallazgos que el comité debería ver
- La carpeta no contiene solicitud de cambio, ni acta que autorice un movimiento. `changes` está vacío y no hay desviación de línea base sin autorizar que reconciliar.
- Los cuatro primeros hitos figuran «cumplidos» en la ficha sin evidencia de recibo propia; el cumplimiento sale del cronograma v1, no de un acta.
- El hito de licenciamiento del software de CT-546 (vencía 2026-03-05) y CT-852 (vencía 2026-01-23) sigue pendiente, sin evidencia. No revisé la vigencia de ambos contratos: si vencen antes de 2027-01-14, el cambio los alcanza.

### Después
Qué sigue, según la decisión:
1. Si se lleva a comité: el paquete es esta solicitud más la pregunta de quién tiene autoridad sobre PRY-201.
2. Si ya está aprobado por quien podía hacerlo: pásame el documento y registro la línea base 2.

---
**Pie de rigor.** Fuente: ficha PRY-201 (acta 2025-09-12, cronograma v1, informe 2026-10-08) y cálculo `impact`. No sé: quién pidió el cambio ni por qué, qué se habló fuera de los documentos, la holgura por actividad, ni el costo de 30 días. Las cifras son las que declara el informe del gerente. La verificación es suya.
