# Corrida del 2026-10-18 · project-history

13 proyectos · 42 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Historia de PRY-205 sobre 6 documentos (2025-07-11 a 2026-10-15). Dijo que no sabe: qué pasó entre 2025-07-11 y 2026-10-05, meses sin sustento (una sola declaración), cambios de gobierno, qué comité autorizó CC-01/CC-02.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Historia · PRY-205 Sistema de gestión de seguridad · 2025-07-11 a 2026-10-15

**Leí:** 6 documentos entre 2025-07-11 y 2026-10-15 (acta, cronogramas v1 y v3, CC-01, CC-02 e informe de avance). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).
**Trimestres sin un solo documento:** 2025-T4, 2026-T1, 2026-T2 y 2026-T3. Entre el acta del 2025-07-11 y la primera solicitud de cambio del 2026-10-05 la carpeta no tiene nada.

### En una línea
El proyecto se aprobó el 2025-07-11 con cierre el 2026-07-26 y 4.200.000.000 COP. Todo lo que cuenta cómo cambió está en los diez días entre el 2026-10-05 y el 2026-10-15: dos ampliaciones de alcance (CC-01 y CC-02) y un cronograma v3 que mueve el cierre al 2026-12-19, con un informe que declara rojo y 34 %. Lo ocurrido en los 15 meses anteriores no tiene documento.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 146 días (39.5 %) | No se puede calcular: hay una sola declaración (2026-10-15) | 0 detectados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-07-11 | `00-gobierno/2025-07-11-acta-constitucion.docx` | Aprobación: patrocinadora Laura Vélez, gerente Sandra Gil, Comité de Seguridad, 4.200.000.000 COP, inicio 2025-07-21, cierre 2026-07-26 |
| 2025-07-11 | `10-plan/2025-07-11-cronograma-v1.csv` | Línea base: hitos 2025-11-21, 2026-03-24 y 2026-07-26 (los tres figuran como «cerrado» el mismo día de la aprobación) |
| 2026-10-05 | `20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +30 días, +60.000.000 COP, «autorizada por el comité» |
| 2026-10-12 | `20-seguimiento/2026-10-12-solicitud-cambio-cc-02.md` | CC-02: ampliación de alcance, +116 días, +232.000.000 COP, «autorizada por el comité» |
| 2026-10-15 | `10-plan/2026-10-15-cronograma-v3.xlsx` | Cronograma v3: cierre pasa a 2026-12-19; los tres hitos «cerrado» |
| 2026-10-15 | `20-seguimiento/2026-10-15-informe-avance.pdf` | Declara rojo y 34 %; ensayo de disponibilidad de equipos no alcanzó lo pactado y se repite; proyección 5.095.962.103 COP |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| v3 | 2026-10-15 | 2026-12-19 | Ninguno en el cronograma v3. Los dos CC son de ampliación de alcance y suman 146 días, que es el atraso contra la original | Ninguno propio. Los CC dicen «autorizada por el comité» sin decir cuál. No hay cronograma v2 en la carpeta |

La línea base original (2026-07-26) se conserva en el v3 como fecha de línea base, y el atraso de 146 días contra ella coincide con los días aprobados en CC-01 y CC-02. Ambos CC expresan su impacto «sobre la línea base vigente», sin dar la fecha de esa línea.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité detectado. El gobierno que consta es el del acta de 2025-07-11; no hay minutas ni correos en la carpeta, que es donde estos cambios suelen aparecer | — |

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | No hay minutas ni transcripciones; no se registró ningún compromiso | 0 | — |

### Desde cuándo lo declarado no se sostiene
No se puede fechar con una serie, porque en la carpeta hay un solo estado declarado (rojo, 34 %, corte 2026-10-15). Lo que sí se puede decir:

- Los hitos «Ingeniería básica aprobada» (2025-11-21) e «Ingeniería de detalle aprobada» (2026-03-24) figuran como cumplidos sin evidencia de aprobación en ningún documento. Es el primer hito sin sustento: 2025-11-21.
- «Licencia y permisos obtenidos» figura «cerrado» con fecha vigente 2026-12-19, posterior a la fecha de esta corrida, y tampoco tiene evidencia.
- Con los tres hitos cerrados, el plan sostiene 100 %; lo declarado es 34 %. La brecha es de 66 puntos.
- El informe declara rojo, pero no da cuenta de estas señales: hitos cumplidos sin evidencia, avance contra plan, desviación de costo (proyección 21.3 % sobre lo aprobado) ni desviación de tiempo.

Qué se siguió reportando después de 2025-11-21: no hay documentos de seguimiento entre esa fecha y 2026-10-05, así que no se sabe qué se reportó en ese tiempo.

### Dinero
Aprobado 4.200.000.000 COP; comprometido 2.648.414.321 (63.1 %); ejecutado 1.211.699.567 (28.8 %); proyección 5.095.962.103, 21.3 % sobre lo aprobado. Los costos de CC-01 y CC-02 (60.000.000 y 232.000.000 COP) están autorizados, pero ningún documento muestra un presupuesto aprobado nuevo; el acta sigue siendo la única fuente del aprobado.

### Lecciones ancladas a un hecho
- **Hecho:** CC-01 (2026-10-05) y CC-02 (2026-10-12) se autorizan «por el comité» sin nombrarlo, y miden contra una «línea base vigente» sin fecha. **Efecto:** no se puede reconstruir desde los documentos quién aprobó los 146 días ni sobre qué fecha se contaron.
- **Hecho:** el cronograma v3 (2026-10-15) mueve el cierre sin motivo escrito y no hay v2. **Efecto:** la replanificación existe en la fecha, no en una decisión documentada.
- **Hecho:** la carpeta no tiene ningún documento de 2025-T4 a 2026-T3, y el primer hito vencía el 2025-11-21. **Efecto:** la aprobación de ingeniería básica y de detalle no se puede verificar.

### Lo que no sé
Qué pasó entre 2025-07-11 y 2026-10-05; cuántos meses estuvo declarado un estado sin sustento; si hubo cambios de gobierno; qué comité autorizó los CC; por qué el v1 trae los hitos como «cerrado» el día de la aprobación (parece un campo de plantilla, no un hecho); fase, autoridad y producto del proyecto (el acta dice «No aplica» para el producto).

Esto no atribuye intención: que el atraso no tenga rastro entre 2025 y 2026 no dice que alguien lo callara. Sirve para tener esa conversación con datos. ¿Quieres llevar esta historia al comité del 2026-10-29, donde hay una decisión sobre los CC y el v3, o dejarla para el cierre del proyecto?

---
**Pie de rigor:** cifras copiadas de `portafolio.py compute` (corte 2026-10-18); cada hecho cita el documento de la carpeta del proyecto. Borrador de trabajo: la verificación es de quien lo lea.
