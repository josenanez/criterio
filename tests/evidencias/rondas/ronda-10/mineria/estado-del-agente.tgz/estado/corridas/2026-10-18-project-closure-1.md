# Corrida del 2026-10-18 · project-closure

13 proyectos · 42 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Cierre provisional de PRY-202: el proyecto no ha terminado (cierre vigente 2026-11-30, ensayo de disponibilidad fallido). Criterio de éxito sin evidencia; dos hitos sin soporte; CC-01 sin aprobador identificable; no se sabe si el presupuesto incluye los 190 M de CC-01. No se archivó.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Cierre de PRY-202 · Planta de tratamiento de agua. Sale de la ficha `estado/records/PRY-202.json`, del cálculo `portafolio.py compute` (corte 2026-10-18) y de seis documentos: acta de constitución (2025-12-09), cronogramas v1 y v2, solicitud CC-01, acta de recibo de básica, informe de avance 2026-10-13 y comité 2026-10-12.

## Cierre — PRY-202 Planta de tratamiento de agua — 2026-10-18

**Advertencia previa: los documentos no sustentan que este proyecto haya terminado.** El cronograma vigente (v2) cierra el 2026-11-30, que aún no llega. El informe del 2026-10-13 dice que el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite. Cerrarlo hoy sería una decisión de alguien, no un cumplimiento. Lo que sigue es un acta de cierre **provisional**, con lo que se puede y no se puede afirmar. No se la dejó como cierre definitivo.

### Contra lo comprometido
**Criterio de éxito:** «Planta de tratamiento de agua en producción y medido» (acta de constitución, 2025-12-09, sección «Criterio de éxito»).
**Se cumplió:** no se puede determinar. Ningún documento muestra la planta en producción ni una medición. El único dato de medición, el primer ensayo de disponibilidad, no alcanzó lo pactado.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Ingeniería básica aprobada (2026-02-19) | Cumplido | Acta de recibo del 2026-10-13, firmada por Sandra Gil. El recibo es ocho meses posterior a la fecha del hito. |
| Ingeniería de detalle aprobada (2026-04-23) | Declarado cumplido, **sin evidencia** | Ninguna. El cálculo marca 178 días sin soporte. |
| Licencia y permisos obtenidos (2026-06-25) | Declarado cumplido, **sin evidencia** | Ninguna. El cálculo marca 115 días sin soporte. |
| Montaje e instalación (base 2026-08-27, vigente 2026-11-30) | Figura cumplido en v2 con fecha vigente futura, **sin evidencia** | Ninguna. Es contradictorio: un hito no puede estar cerrado con fecha posterior al propio cronograma. |

Alcance del acta: «Componente 1, Componente 2, Componente 3», sin descripción. Con eso no se puede contrastar qué se entregó de cada componente. Es un vacío del acta, no del cierre.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre» (acta original, sin enumerar) | No consta | 2025-12-09 |

No hay recorte de alcance registrado. Hay lo contrario: CC-01 **amplía** el alcance (ver abajo) sin decir qué se agrega.

### Números finales
Todavía no hay cifras finales: el proyecto sigue abierto. Se muestran las vigentes al 2026-10-18.

| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-27 | 2026-11-30 | No existe (no ha ocurrido) | +95 días (37.8 %) |
| Presupuesto (COP) | 2.400.000.000 | 2.400.000.000 | No existe | Proyección 2.358.092.650 (-1.7 % sobre lo aprobado) |

Replanificaciones: **1** (v1 → v2, aprobada el 2026-10-13). Desviación contra la vigente: 0 días.

Dinero según el informe del 2026-10-13: aprobado 2.400.000.000; comprometido 1.633.608.660 (68.1 %); ejecutado 1.308.832.360 (54.5 %); disponible real 766.391.340. Todo en COP.

Observaciones que no se pueden cerrar con los documentos:
- **El presupuesto no recoge CC-01.** El cambio suma 190.000.000 COP, pero el aprobado sigue en 2.400.000.000. No se sabe si la proyección de 2.358.092.650 incluye esos 190.000.000. Sin ese dato, el «-1.7 %» no se puede leer como ahorro.
- **El avance declarado (84 %) está 16 puntos por debajo de lo que sostiene el cronograma.** Cuatro de cuatro hitos figuran cumplidos, lo que implica 100 %. Uno de los dos números está mal.
- **El estado declarado es «verde».** Con +95 días contra la base original, dos hitos sin evidencia y un ensayo fallido, el cálculo marca tres señales que el informe no explica.

### RAID al cierre
**Materializados:**
- Atraso de +95 días contra la línea base original. Es la consecuencia que CC-01 formalizó el 2026-10-10.
- Primer ensayo de disponibilidad por debajo de lo pactado (informe 2026-10-13), sin doliente.

**No materializados:** ninguno se puede afirmar. El único riesgo registrado, «Ventana de parada de planta definida por operaciones», sigue abierto, sin probabilidad, impacto ni doliente.

**Abiertos, con doliente:**
- Compromiso «Entregar el punto 40», de Carlos Peña, para el 2026-10-18 (hoy), estado abierto. Hay doliente con nombre, pero Carlos Peña no figura entre los asistentes del comité y no se sabe qué es el «punto 40».
- Sin doliente (por tanto **no están cerrados ni transferibles**): el ensayo de disponibilidad que se repite, y el riesgo de la ventana de parada.

### Lecciones
Solo entran las que se anclan a un hecho documentado. Con estos documentos son pocas, y casi todas son sobre gobierno, no sobre ejecución.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cierre pactado era 2026-08-27 y se movió a 2026-11-30 mediante CC-01 y el cronograma v2. La solicitud es del 2026-10-10, cuando el cierre original ya había pasado | 2026-08-27 → 2026-10-10 → 2026-10-13 | Los 95 días de atraso se formalizaron después de vencida la fecha, no antes. La base original quedó incumplida sin cambio aprobado a tiempo | Pedir el cambio antes de la fecha base, no después |
| CC-01 lo pidió Sandra Gil, que además es patrocinadora y gerente, y dice «Autorizada por el comité» sin decir cuál ni cuándo. El comité del 2026-10-12 lista a Sandra Gil dos veces como única asistente y no menciona CC-01 | 2026-10-10 y 2026-10-12 | La aprobación de +95 días y +190.000.000 COP no tiene aprobador identificable distinto de quien la pidió | Registrar quién aprueba, con qué fecha y con qué quórum |
| El hito «Ingeniería básica aprobada» (2026-02-19) tiene acta de recibo del 2026-10-13. Los hitos de detalle (2026-04-23) y licencia (2026-06-25) figuran cumplidos sin acta | 2026-02-19 a 2026-10-13 | Tres de cuatro hitos «cumplidos» no se sostienen con documentos | Exigir acta de recibo al cerrar cada hito, en su fecha |

No se registra ninguna lección sobre causas técnicas del atraso: los documentos no dicen por qué se movió la fecha. El motivo de la línea base v2 figura como «no encontrado».

### Sin dato
- Si el proyecto terminó. Lo vigente dice que no: cierre previsto 2026-11-30.
- Qué es «Componente 1, 2 y 3», y qué agrega la «ampliación de alcance» de CC-01.
- Motivo del atraso de 95 días (la v2 no trae razón).
- Qué comité autorizó CC-01, en qué fecha, y con qué asistentes.
- Si el presupuesto o la proyección incluyen los 190.000.000 COP de CC-01.
- Fase, autoridad y producto de la ficha: no aparecen. El acta dice «No aplica» en producto.
- Proveedores: ninguno registrado, aunque el proyecto tiene compras y un presupuesto de obra.
- Qué es el «punto 40» y si se entregó hoy.
- Evidencia de producción y medición, que es el criterio de éxito.

### Qué haría falta para cerrar de verdad
1. Actas de recibo de ingeniería de detalle, licencia y montaje.
2. Resultado del ensayo repetido de disponibilidad y la medición en producción.
3. Doliente con nombre para el ensayo, la ventana de parada y lo que quede abierto.
4. Acta del comité que autorizó CC-01.

### Archivo
No se movió la carpeta a `archivo/` ni se congeló la ficha. Con el proyecto sin terminar, eso lo tendría que decidir una persona en el comité. Queda ofrecido para cuando exista el cierre declarado.
