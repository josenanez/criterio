*Fichas cargadas: las 13 de `estado/records` (PRY-199 a PRY-211), corte 2026-10-18 (el informe más viejo es el de PRY-204, 2026-09-30). Cifras copiadas de `portafolio.py compute` (as_of 2026-10-18). Criterios aplicados: governance-artifacts y raid-taxonomy. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-18.*

# Comité de proyectos — 2026-10-29 (material preparado el 2026-10-18)
6 decisiones · 6 escalamientos sin decisión asociada · 10 proyectos con hallazgos (13 en el portafolio, 47 señales abiertas)

## Decisiones del comité anterior
No hay registro de un comité anterior en la carpeta (ni acta, ni minuta de comité de PMO, ni salida previa de `/steering-pack`). El ciclo no se puede cerrar: no sé qué se decidió, qué se hizo ni qué sigue abierto. Si hubo comité, hace falta su acta.

## Decisiones de hoy

### [1] ¿Quién aprueba los cambios de línea base de cada proyecto, y hasta qué umbral?
**Proyecto:** los 13 · **Quién decide:** el comité de la PMO (nadie más puede asignarse esa facultad) · **Si no se decide hoy:** los 13 proyectos siguen con `identity.authority` vacío; cada solicitud de cambio, incluidas las de los puntos 2 a 5, queda sin un aprobador demostrable.

La autoridad del gerente no figura en ninguna de las 13 actas (13 de 13 sin autoridad). Es el primer punto porque los demás dependen de él.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Todo cambio de línea base va al comité que nombra el acta de cada proyecto (Seguridad, Inversiones, Tecnología, Operaciones, Ambiental), hasta fijar umbrales | Sin cambio en ningún proyecto; cambia quién firma | Una decisión por comité en lugar de una por gerente | No declarado |
| B. El comité fija ahora umbrales de tiempo y costo por debajo de los cuales decide el gerente o el patrocinador | Igual | Más ágil para cambios pequeños | Los umbrales los fija el comité; yo no propongo cifras (la PMO usa 10 % de desviación como umbral de alerta, no de autoridad) |
| C. No definir nada | Igual | Igual | Los cambios siguen aprobándose sin facultad demostrable |

**Recomendación:** A ahora, B en el siguiente comité. Hoy no hay base documental para fijar umbrales, y A permite decidir los puntos 2 a 5 con un aprobador identificable.

### [2] ¿Se aprueba el CC-01 de PRY-208 (ampliación de alcance, +26 días, 52.000.000 COP)?
**Proyecto:** PRY-208 Trazabilidad del mineral (declarado rojo, 78 % de avance declarado) · **Quién decide:** Comité de Tecnología según el acta; la autoridad individual no consta. Solicitante: Ricardo Salas (gerente). Patrocinador: Jorge Medina · **Si no se decide hoy:** la línea base ya se movió 26 días sin autorización (`rebaseline_unauthorized`: 26 movidos, 0 autorizados) y la fecha vigente de cierre, 2027-02-22, no tiene respaldo aprobado.

La solicitud dice «ampliación de alcance» sin describir qué entra. Proyección 1.220.321.053 COP contra 1.200.000.000 aprobados (+1,7 %). Montaje previsto 2026-11-07; el proveedor no ha confirmado la fecha de la última entrega (208-D1, sin doliente).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Entra lo que describa la solicitud (hoy no está descrito) | +26 días, regulariza el movimiento ya hecho | +52.000.000 COP |
| B. Rechazar | Sin ampliación | La línea base vuelve a la original; los 26 días quedan como atraso | Sin costo adicional |
| C. Aplazar hasta tener descripción del alcance y fecha escrita del proveedor | Pendiente | Se decide sin certeza de fecha, pero con la evidencia pedida | Sin costo mientras tanto |

**Recomendación:** C, con el plazo de este comité como límite. No hay forma de evaluar una ampliación cuyo alcance no está escrito. Si no llegan ambos documentos, B.

### [3] ¿Se retiene todo pago pendiente de CT-546 y CT-852 (PRY-201) hasta que existan las actas de recibo?
**Proyecto:** PRY-201 Ampliación de la relavera · **Quién decide:** no se puede determinar (autoridad no encontrada). Patrocinador: Natalia Ospina; Comité de Seguridad según el acta · **Si no se decide hoy:** los licenciamientos de ambos contratos siguen vencidos (227 días en CT-546, 268 en CT-852) y el contrato exige acta firmada para facturar; cada pago adicional se hace sin ese respaldo.

Hechos: CT-546 facturó 2.519.443.535 COP (FV-1546) contra 1.810.007.449 COP con acta, una diferencia de 709.436.086 COP. CT-852 facturó 4.289.910.924 COP (FV-2852) y no existe ningún acta de recibo para sus dos entregables «recibidos». No tengo vigencia ni preaviso de ninguno de los dos contratos, ni el valor de los pagos pendientes.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos y exigir las actas | Sin cambio | Puede frenar a los proveedores; 2 licenciamientos ya vencidos | Evita nuevos pagos sin respaldo; no recupera lo facturado |
| B. Seguir pagando contra la declaración del gerente | Sin cambio | Sin fricción | Los 709.436.086 COP y los 4.289.910.924 COP quedan sin respaldo documental |
| C. A y además pedir auditoría de lo ya facturado | Sin cambio | Más largo | Costo de la auditoría: no consta |

**Recomendación:** A. Es la única que no empeora lo ya facturado, y las actas, si existen, resuelven el asunto. Pedir antes las condiciones completas de ambos contratos. C si las actas no aparecen.

### [4] ¿Se aprueba mover el cierre de PRY-201 en 30 días (de 2026-12-15 a 2027-01-14)?
**Proyecto:** PRY-201 · **Quién decide:** sin determinar; propuesta provisional, Comité de Seguridad (aprobó el presupuesto) · **Si no se decide hoy:** rige el cierre del 2026-12-15, que es lo único aprobado. El informe del 2026-10-08 ya reporta la parada de planta reprogramada, así que la fecha real puede ser otra y la desviación se acumula sin registro.

No existe solicitud escrita: no consta quién la pidió, por qué, ni qué costo tiene. La proyección ya supera lo aprobado en 2,8 % (18.496.508.384 contra 18.000.000.000 COP), con verde declarado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | No declarado | +30 días, línea base 2 | No declarado; alguien lo absorbe o no se escribió |
| B. Rechazar | Sin cambio | Cierre 2026-12-15 | La proyección sigue en +2,8 % |
| C. Devolver para solicitud formal con motivo, costo y vínculo con la parada de planta | Sin cambio | Decisión en el comité siguiente | Sin cambio |

**Recomendación:** C. No hay datos para decidir A ni B.

### [5] ¿Ratifica el comité los cambios ya «autorizados» de PRY-202 (CC-01) y PRY-205 (CC-01 y CC-02)?
**Proyecto:** PRY-202 (Comité de Inversiones) y PRY-205 (Comité de Seguridad) · **Quién decide:** los comités del acta · **Si no se decide hoy:** las líneas base ya se movieron en el sistema (PRY-202 +95 días, 37,8 %; PRY-205 +146 días, 39,5 %) sobre una autorización que solo consta como una frase en la propia solicitud.

Hechos: las tres solicitudes dicen «Autorizada por el comité» y no hay acta que lo respalde. Las tres las firma Sandra Gil. En PRY-202 es patrocinadora, gerente y solicitante a la vez. En PRY-205 son dos cambios en siete días (2026-10-05 y 2026-10-12: +30 días y 60.000.000 COP, +116 días y 232.000.000 COP); el proyecto está en rojo y la proyección es 5.095.962.103 COP contra 4.200.000.000 aprobados (+21,3 %, sobre el umbral de 10 %). PRY-202 costo CC-01: +190.000.000 COP.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar los tres con acta | Ampliaciones se mantienen | +95 días (202), +146 días (205) quedan formalizados | +190.000.000 (202); +60.000.000 y +232.000.000 (205) |
| B. Ratificar PRY-202 y exigir a PRY-205 un replan completo | 205 se revisa | 205 con nueva fecha defendible | 205 con la proyección reconciliada |
| C. No ratificar; devolver las líneas base y repetir la aprobación con acta | Se suspenden las ampliaciones | Se pierde lo ya movido | Se suspenden los costos |

**Recomendación:** B. PRY-205 declara rojo, tiene el desvío de costo más alto del portafolio y dos cambios seguidos; aprobarlos sin replan es acumular desviación. PRY-202 puede ratificarse con acta y un firmante distinto del solicitante.

### [6] ¿Se fija un responsable único en Operaciones para confirmar por escrito la ventana de parada de planta?
**Proyecto:** PRY-201, 202, 203, 204, 210 y 211 (dependencia); 199, 201, 206, 207, 209 y 210 (incidencia reportada) · **Quién decide:** quien tenga autoridad sobre Operaciones; no consta en ninguna ficha. Hay comité de Operaciones en PRY-209 y PRY-211 · **Si no se decide hoy:** sigue una dependencia declarada, no acordada, con 10 de 13 informes que mencionan la parada o su reprogramación, sin doliente. Los documentos no dicen si es la misma parada en todos.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un responsable nombrado fija y confirma una ventana común | Sin cambio | Una fecha única para los 10 proyectos | No declarado |
| B. Cada gerente la negocia por su cuenta | Sin cambio | Puede dar ventanas incompatibles | No declarado |
| C. Primero confirmar si es la misma parada, luego decidir | Sin cambio | Un ciclo más | No declarado |

**Recomendación:** C si la PMO puede confirmarlo antes del comité; si no, A. La duda sobre si es una sola parada es real, pero no debe demorar el nombramiento.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-207 | Fecha de cierre del acta 2026-07-30 ya pasó; declara verde 34 %; sin cronograma ni hitos | 2026-07-30 | Un plan o un cierre formal. Nadie lo ha pedido |
| PRY-210 | Fecha de fin 2026-08-29 pasó; declara amarillo con 69 % de avance; el plan sustenta 100 % | 2026-08-29 | Solicitud de cambio con nueva fecha o explicación del avance |
| PRY-209 | Ejecutado 9.952.505.540 COP por encima de lo comprometido 5.669.206.680 COP (55,3 % ejecutado, 31,5 % comprometido). Es incoherente | Dato del corte 2026-10-13 | Que el gerente aclare la cifra; hoy no sé cuál está mal |
| PRY-200 | Riesgo materializado (rotación de ingeniero, dos semanas perdidas) llevado aún como riesgo. Avance 57 % con plan que sustenta 75–100 %. Montaje previsto 2026-11-05 | 2026-10-17 | Plan de recuperación con doliente. Sin doliente hoy |
| PRY-204 | Entregables vencidos de proveedores: licenciamiento 102 días (Equipos Pesados Andinos) y 87 días (Servicios Ambientales del Norte), bolsa de horas 13 días | 2026-07-08 | Gestión con proveedores. Mismo proveedor, Servicios Ambientales del Norte, con CT-852 en PRY-201 |
| Portafolio | Los 35 ítems RAID del registro no tienen doliente ni fecha, ni probabilidad ni impacto. No hay forma de saber si algo lleva dos períodos sin movimiento | 2026-10-18 | Que cada gerente asigne doliente. No propongo nombres |

## Para conocimiento
- **PRY-199** Cambio de luminarias: verde, 20 % declarado (plan 20–40 %). Sin señales.
- **PRY-200** Mantenimiento predictivo: ver escalamientos. Verde contradicho.
- **PRY-201** Ampliación de la relavera: puntos 3 y 4. Verde contradicho, 11 señales.
- **PRY-202** Planta de tratamiento de agua: punto 5. Verde contradicho.
- **PRY-203** Despacho automático: verde, 37 % contra plan 50–75 %. Proveedor que podría no llegar completo a la siguiente fase, dicho en reunión el 2026-10-18 y sin registrar. Compromiso de Óscar Ramírez para el 2026-10-28.
- **PRY-204** Monitoreo de taludes: ver escalamientos. Verde contradicho.
- **PRY-205** Sistema de gestión de seguridad: punto 5. Rojo.
- **PRY-206** Red privada LTE: verde, sin señales.
- **PRY-207** Gemelo digital: ver escalamientos.
- **PRY-208** Trazabilidad: punto 2. Rojo.
- **PRY-209** Electrificación: ver escalamientos. Verde, una señal de hito sin evidencia.
- **PRY-210** Relacionamiento comunitario: ver escalamientos. Amarillo.
- **PRY-211** Control de polvo: amarillo, 39 % contra plan 60–80 %. Tres hitos sin evidencia. Montaje previsto 2026-11-09 con proveedor sin fecha confirmada.

## Anexo

### Estado de cada proyecto (cifras de `compute`)
| Proyecto | Declara | Avance declarado / lo que sustenta el plan | Desv. de tiempo vs original | Proyección vs aprobado | Señales |
|---|---|---|---|---|---|
| PRY-199 | verde | 20 % / 20–40 % | 0 | 0,0 % | 0 |
| PRY-200 | verde | 57 % / 75–100 % | 0 | +4,8 % | 3 |
| PRY-201 | verde | 48 % / 80–100 % | 0 | +2,8 % | 11 |
| PRY-202 | verde | 84 % / 100 % | +95 días (37,8 %) | −1,7 % | 5 |
| PRY-203 | verde | 37 % / 50–75 % | 0 | −4,5 % | 2 |
| PRY-204 | verde | 31 % / 40–60 % | 0 | +4,2 % | 7 |
| PRY-205 | rojo | 34 % / 100 % | +146 días (39,5 %) | +21,3 % | 5 |
| PRY-206 | verde | 32 % / 25–50 % | 0 | +2,3 % | 0 |
| PRY-207 | verde | 34 % / sin plan en la ficha | 0 | −1,7 % | 0 |
| PRY-208 | rojo | 78 % / 60–80 % | +26 días (6,4 %) | +1,7 % | 3 |
| PRY-209 | verde | 42 % / 50–75 % | 0 | −0,6 % | 2 |
| PRY-210 | amarillo | 69 % / 100 % | 0 | −3,0 % | 5 |
| PRY-211 | amarillo | 39 % / 60–80 % | 0 | −2,0 % | 4 |

Verdes contradichos por la evidencia: 6 (PRY-200, 201, 202, 203, 204 y 209). Hitos «cumplidos» sin evidencia de recibo: 9 de 13 proyectos.

### Contradicciones abiertas
- PRY-201: declara 48 % y verde; el plan, con 4 de 5 hitos cumplidos, sustenta 80–100 %. Hay más hitos «cumplidos» que avance, y un montaje «cumplido» el 2026-09-16 con la última entrega del proveedor sin fecha.
- PRY-199, PRY-204 y PRY-206 reportan en sus informes un ensayo de disponibilidad o una parada de planta reprogramada que no corresponden a su fase. Son frases repetidas palabra por palabra en varios informes. Verificar con el gerente.
- PRY-200 reporta 3 de 4 hitos cumplidos y 57 % de avance.

### Vacíos de información
- Autoridad de cambio: vacía en 13 de 13. Fase (`identity.phase`): vacía en las fichas con corte de esta corrida.
- Sin minutas en la carpeta: PRY-201, 205, 206, 207 y 210. No pude buscar riesgos ni compromisos dichos en reunión en esos cinco.
- Ninguna dependencia apunta a un código PRY. El cruce entre proyectos no detecta nada, y eso no prueba que no existan.
- Vigencia y preaviso de CT-546 y CT-852: sin dato. Facturado de CT-597 (PRY-204): sin dato.
- Las 13 fichas cuentan 0 fuentes marcadas como evidencia, aunque la carpeta tiene algunas actas de recibo (por ejemplo en PRY-200, 203, 208 y 209). No verifiqué si el cálculo las reconoce para los hitos señalados; conviene revisarlo antes de dar por cierta la lista de «hitos sin evidencia».
- PRY-201: la solicitud de 30 días no está escrita en ninguna parte.

---
**Pie.** Versión de la familia 0.5.0 · términos v1.1 · fichas aplicadas: las 13 de `estado/records`, más las salidas previas de change-control, raid-log y vendor-tracking del 2026-10-18 · campos inciertos: autoridad de cambio, fase, doliente RAID, evidencia de hitos, vigencia de contratos · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
Borrador de trabajo para verificar contra los documentos citados; no es una decisión ni asesoría.
