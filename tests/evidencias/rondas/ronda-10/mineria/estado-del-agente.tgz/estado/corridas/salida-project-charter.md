Hay acta previa: `2026-04-22-acta-constitucion.docx`, aprobada el 2026-04-22 por el Comité de Tecnología (hace 179 días). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Acta — PRY-206 · Red privada LTE en mina
**Estado:** existe, del 2026-04-22

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** Ni monto ni tipo de cambio en ningún documento de la carpeta. | Nadie puede decir si Jorge Medina podía decidir por sí mismo cualquier cambio. Hoy la proyección al cierre (COP 4.296.957.949) supera el aprobado (COP 4.200.000.000) en COP 96.957.949 (+2,3 %): sin umbral declarado no se sabe si eso lo resuelve el gerente o debe subir al Comité de Tecnología. Tampoco hay base para juzgar si un cambio futuro fue aprobado por quien tenía la facultad. |
| Objetivo de negocio | **Presente pero es la solución:** «Entregar red privada lte en mina para Mina». | No dice qué mejora para el negocio ni cuánto. Sin objetivo medible no se puede saber si el proyecto sirvió, solo si se instaló. |
| Alcance | **Vacío de contenido:** «Componente 1, Componente 2, Componente 3». | Los componentes no están nombrados. Un cambio de alcance (el informe cita un posible cambio en la licencia ambiental «que puede mover el alcance») no tiene contra qué compararse. |
| Exclusiones | **Genérica:** «Lo que otro proyecto cubre». | No nombra el otro proyecto ni qué cubre. No evita la discusión de alcance: la deja abierta. |
| Patrocinador | Cumple: Felipe Arango (persona). Gerente: Jorge Medina. | — |
| Supuestos y restricciones | **Ausentes.** Dependencias: «Ninguna declarada». | El cronograma tiene un hito de «Licencia y permisos obtenidos» (2027-03-08) y el informe reporta riesgo de licencia ambiental y de bloqueo de la vía: hay dependencias externas que el acta declara inexistentes. Si fallan, no hay supuesto roto que lo registre. |
| Criterio de éxito | **No medible:** «Red privada LTE en producción y medido». | No dice qué se mide (cobertura, latencia, disponibilidad), con qué umbral ni **quién lo mide**. El cierre no tendría contra qué declararse. |
| Cadencia del comité | **Ausente.** Comité nombrado: Comité de Tecnología. | No hay frecuencia de reporte pactada; no se puede decir si el proyecto está en silencio ante su comité. |
| Hitos principales | Presentes en el cronograma v1 (no en el acta). | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice «Entregar red privada lte en mina para Mina» (acta, sección Objetivo del negocio).
**Alcance:** pendiente de definir. El acta lista «Componente 1, Componente 2, Componente 3» sin descripción.
**Exclusiones:** pendiente de definir. El acta dice «Lo que otro proyecto cubre», sin nombrar el proyecto.
**Patrocinador:** Felipe Arango · **Gerente:** Jorge Medina (acta).
**Autoridad del gerente:** pendiente de definir. No aparece en ningún documento.
**Comité al que reporta:** Comité de Tecnología (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. (Dependencias declaradas: «Ninguna declarada».)
**Presupuesto aprobado:** COP 4.200.000.000, por el Comité de Tecnología el 2026-04-22 (acta). **Fechas:** inicio 2026-05-02, cierre 2027-06-19 (acta).
**Criterio de éxito:** «Red privada LTE en producción y medido» (acta), sin métrica · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2026-04-22): Ingeniería básica aprobada 2026-08-13 (recibida el 2026-10-17 según acta de recibo); Ingeniería de detalle aprobada 2026-11-24; Licencia y permisos obtenidos 2027-03-08; Montaje e instalación 2027-06-19.

### Observaciones fuera del acta
- El acta de recibo de la ingeniería básica tiene fecha 2026-10-17, 65 días después del hito de línea base (2026-08-13), y el cronograma lo muestra como «cerrado» con fecha vigente 2026-08-13, sin línea base nueva. No se pudo contrastar qué pasó entre ambas fechas: no hay minutas en la carpeta.
- El informe del 2026-10-16 declara verde, 32 % de avance, con 38,6 % del presupuesto ejecutado y 73,4 % comprometido. Eso no es objeto de esta revisión; lo cubre `/status-report`.

## Después
- El acta quedó sin autoridad declarada: puedo preparar la definición de autoridad del gerente como punto para el Comité de Tecnología (es una decisión, no un trámite). El próximo comité de la PMO está fijado para 2026-10-29.
- De la revisión salen supuestos implícitos (licencia y permisos en plazo, acceso a la mina) que puedo pasar al registro RAID con `/raid-log`.

---
**Pie de rigor.** Leí 4 documentos: acta de constitución, cronograma v1, informe de avance del 2026-10-16 y acta de recibo del 2026-10-17. No hay minutas ni solicitudes de cambio, así que no sé qué se habló o decidió fuera de estos documentos. La autoridad del gerente, los supuestos, las restricciones, la cadencia del comité y quién mide el criterio de éxito no están en ningún documento y no los completé. La verificación de las citas es suya.
