# Rostrum — para mirarlo un rato

**Términos:** vigentes (v1.1, familia 0.5.0), aceptados por José Francisco Ñáñez el 2026-10-18. No hizo falta registrar de nuevo.

**Modo elegido: «para mirarlo un rato».** Se levanta, se mira y se apaga. Escucha solo en `127.0.0.1:8787`, en este equipo, sin tocar nada de seguridad. Lo que se pierde: el patrocinador no tiene un enlace que funcione mañana.

Informe encontrado en `reportes/` (generado hoy 2026-10-18, 13 proyectos, 6 productos). Estado en `estado/`.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores con más de una cosa | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | El comité y el patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto; enlaza al producto que le dio origen | Quien gerencia, y quien pregunta |
| `/productos` | Listado de productos y proyectos que no dicen qué producto construyen | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto; enlaza a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El enlace proyecto ↔ producto va en los dos sentidos: quien entra por un producto puede descubrir que lo construyen proyectos que reportan a comités distintos, y que ninguno lo ve completo.

El portal lleva el nombre «Portafolio de proyectos» (de `organization.name`).

## Cola de peticiones

El formulario de la portada solo escribe un archivo en `estado/peticiones/`. El servidor no puede correr el agente, y eso es deliberado. Las peticiones abiertas las cuenta `due` y rompen el silencio de `/portfolio-wake`. Se marcan con `portafolio.py answered --state estado --id <id>`.

## Lo que Rostrum no hace

- No calcula: sirve lo que `informe.py` ya escribió. Abrir la página no lee documentos.
- No escribe fichas: el único archivo que crea es la petición.
- No autentica.
- No manda correos ni notificaciones.

## Cierre

Este modo es solo para esta máquina: el enlace `http://127.0.0.1:8787/` no sirve para pasárselo al patrocinador. Si quiere que la persona patrocinadora tenga un enlace, el siguiente paso es «que quede corriendo» (`--abierto`), que pide a la organización un host y puerto internos y publicarlo detrás de su control de acceso. El informe servido es el de 2026-10-18; se desactualiza cuando se corra de nuevo `/portfolio-report html` (la portada muestra su fecha).
