# Corrida del 2026-10-18 · portfolio-wake

13 proyectos · 21 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Barrido: 80 documentos, 0 cambiaron. 18 citas de PRY-203 reportadas sin resolver aunque los archivos existen (probable ruta de la ficha), sin verificar. Confirmación mensual no corrida: sin interlocutor y sin fichas en estado/records.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## 2026-10-18

**Revisé:** 80 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada. El barrido corrió y no hay documentos nuevos, cambiados, renombrados ni borrados.

### Citas que no resuelven
`index` reporta 18 campos de PRY-203 con la fuente «sin resolver» (acta de constitución del 2025-12-27, cronograma v1 e informe de avance del 2026-10-10). Esos tres archivos sí existen en `documentos/proyectos/PRY-203-despacho-automático-de-flota/`. La ficha de PRY-203 está en `estado/PRY-203-despacho-automático-de-flota/records/PRY-203.json`, no en `estado/records/`, así que lo más probable es que el índice la compare contra una ruta distinta. No lo puedo afirmar; queda como hallazgo abierto y no toqué la ficha.

### Peticiones atendidas
No corrí `requests`: `due` no marcó `requests`.

### Preguntas
La confirmación mensual tocaba (cinco campos), pero esta sesión no tiene a nadie que responda y `estado/records/` está vacío, así que no hay fichas de donde elegir los cinco campos por importancia. No hice preguntas y la confirmación no queda marcada como corrida.

**Vuelvo el 2026-10-19.** El informe de comité es el 2026-10-27, para el comité del 2026-10-29.
