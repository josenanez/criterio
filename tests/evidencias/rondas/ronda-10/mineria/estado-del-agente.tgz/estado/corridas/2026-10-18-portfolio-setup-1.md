# Corrida del 2026-10-18 · portfolio-setup

3 proyectos · 80 documentos, 54 releídos y 26 sin cambio · 73 s · 9 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 5 |
| `progress_vs_plan` | 2 |
| `declared_vs_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |

0 preguntas (todas por defecto, sesión sin interfaz); primer resultado en una sola sesión, sin medición de reloj; 3 proyectos (PRY-203, 208, 211), 9 señales: hitos cerrados sin acta, verde contradicho en PRY-203, re-línea base sin autorizar en PRY-208

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

Respuestas por defecto, dichas en una línea cada una (no hubo a quién preguntar): eres PMO (hay 13 proyectos); comité cada dos semanas, próximo 2026-10-29 (fecha supuesta, corrígela cuando me digas la real); informe como página (HTML); estado en `estado/` e informes en `reportes/`, junto a la carpeta de documentos.

**Miré:** 80 documentos en 13 proyectos · formatos: .md (39), .docx (12), .pdf (12), .xlsx (9), .csv (6), .json (1), .txt (1) · más reciente: 2026-10-18
**Eres:** PMO del portafolio
**Te aviso:** dos días antes del comité del 2026-10-29 (cada dos semanas)
**En:** página
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.5.0 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 del .md 9c54c0c517603 b1… (9c54c0c51760b1663e…)

### Probé con tres proyectos

Los de documentación más reciente: PRY-203, PRY-208 y PRY-211.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-203 Despacho automático de flota | 15 | Patrocina Felipe Arango, gerente Jorge Medina (acta 2025-12-27). Presupuesto 4.200 M COP; comprometido 2.957 M, ejecutado 2.066 M. Cierre 2027-02-09. Declara verde, 37 % (informe 2026-10-10). Tiene su propia ficha de gerente (`ficha-pm.json`), guardada aparte | Autoridad del gerente, fase, proveedores |
| PRY-208 Trazabilidad del mineral | 7 | Patrocina Jorge Medina, gerente Ricardo Salas. Presupuesto 1.200 M COP; ejecutado 591 M. Cierre vigente 2027-02-22 (cronograma v2; el acta decía 2027-01-27). Declara rojo, 78 % (informe 2026-10-13). Solicitud de cambio CC-01 pendiente: +26 días, +52 M COP | Autoridad, fase, proveedores |
| PRY-211 Control de polvo en vías | 4 | Patrocina Carlos Peña, gerente Andrés Lozano. Presupuesto 9.500 M COP; comprometido 7.152 M, ejecutado 4.155 M. Cierre 2027-02-18. Declara amarillo, 39 % (informe 2026-10-18) | Producto (el acta dice «No aplica»), autoridad, fase, proveedores |

**Hallazgos (los que levantó el cálculo):**

- **PRY-203 · verde contradicho por el plan** (`declared_vs_evidence`, `progress_vs_plan`): declara verde con 37 %, pero con 2 de 4 hitos cerrados el plan sustenta entre 50 % y 75 %. La brecha es de 13 puntos, y en sentido de atraso respecto de lo que el plan sostiene.
- **PRY-208 · dos hitos declarados cerrados sin acta** (`milestone_met_without_evidence`): «Ingeniería básica aprobada» (2026-03-08) y «Licencia y permisos obtenidos» (2026-08-17). El cronograma los da por cerrados; no hay documento que lo pruebe. La ingeniería de detalle sí tiene acta (2026-10-13).
- **PRY-208 · cambio de línea base sin autorización** (`rebaseline_unauthorized`): el cronograma v2 (2026-10-13) movió el cierre 26 días, y la CC-01 que lo respalda sigue pendiente de comité.
- **PRY-211 · tres hitos cerrados sin acta** (`milestone_met_without_evidence`): ingeniería básica (2026-01-09), ingeniería de detalle (2026-04-20) y licencia y permisos (2026-07-30).
- **PRY-211 · avance por debajo del plan** (`progress_vs_plan`): declara 39 %; con 3 de 5 hitos cerrados el plan sustenta entre 60 % y 80 %. Brecha de 21 puntos.
- Los tres proyectos tienen la autoridad del gerente sin declarar (`no_authority`). Total: 9 señales en 3 proyectos.

Los compromisos de las reuniones de PRY-203 no los releí en esta prueba: están en la ficha del gerente, guardada entera.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-210, salvo los tres ya leídos), 65 documentos en dos lotes, uno tras otro. Con lo visto, unos pocos minutos por proyecto: del orden de media hora a una hora de trabajo continuo.

### Lo que le falta a tu carpeta
- Ninguno de los tres proyectos trae el documento de autoridad del gerente: sin él, el control de cambios no sabe qué puede decidir sin subir a comité.
- Faltan actas de recibo de hitos que los cronogramas dan por cerrados (5 en estos tres proyectos). Si existen, súbelas con la fecha en el nombre.
- PRY-211 está leído desde un acta de hace 13 meses, sin confirmación posterior de patrocinador, gerente ni presupuesto.
- La carpeta `estado/` ya tenía estado de otro agente para PRY-203 (agente de proyecto); convive con el del portafolio, pero conviene decidir quién escribe qué.
- Ninguna carpeta de proveedor ni contrato visible en estos tres; en PRY-199, PRY-201 y PRY-204 sí hay contratos y facturas, que irán en el barrido completo.
