# Corrida del 2026-10-18 · status-report

13 proyectos · 29 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

Estado de PRY-201 con verde declarado (2026-10-08) contradicho: 4 hitos cumplidos sin evidencia, avance 48% vs 80-100% del plan, facturación CT-546 sobre lo aceptado, 2 licenciamientos vencidos. Sin dato: autoridad, fase, minutas/reuniones, valoración de riesgos.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Informe de la ficha `estado/records/PRY-201.json` (actualizada el 2026-10-18), recalculada con `portafolio.py compute` al 2026-10-18. Umbrales de `config.json`.

## PRY-201 · Ampliación de la relavera — estado al 2026-10-18

**Declara el gerente (Mauricio Pérez):** verde · 48% · al 2026-10-08 (hace 10 días; la declaración no está vencida) — `20-seguimiento/2026-10-08-informe-avance.pdf`
**Sustento documental:** contradicho. Cero fuentes de evidencia en la ficha; las cifras declaradas no tienen respaldo independiente.
**Lo que el semáforo no explica** (`declared.unaccounted_signals`, alerta `declared_vs_evidence`):
- `milestone_met_without_evidence`: 4 hitos «cumplidos» sin evidencia.
- `progress_vs_plan`: declara 48%; el plan sustenta entre 80% y 100% (4 de 5 hitos cumplidos). Brecha: 32.0 puntos. El avance declarado queda por debajo de lo que dicen los hitos: o los hitos no están cumplidos, o el 48% está mal.
- `vendor_deliverable_late`: dos entregables de licenciamiento pendientes y vencidos.
- `vendor_invoiced_over_accepted`: CT-546 facturado por encima de lo aceptado.

**Último documento:** 2026-10-08 (10 días de silencio; umbral 15 — no hay alerta de silencio) · **Última reunión:** sin dato (no hay minutas en la carpeta).

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-15 | 2026-12-15 | 0 días (0 vs original, 0 vs vigente) |
| Presupuesto aprobado | COP 18.000.000.000 | COP 18.000.000.000 | Proyección COP 18.496.508.384: 2.8% sobre lo aprobado (umbral 10%) |

Presupuesto (informe del 2026-10-08): comprometido COP 11.971.394.314 (66.5%), ejecutado COP 10.279.560.112 (57.1%), disponible real COP 6.028.605.686.

Replanificaciones: 0. Solo existe la línea base v1 (2025-09-12, aprobación del acta). Cambios formales registrados: 0.

### Hitos
Todas las fechas vigentes son iguales a las de línea base (cronograma v1, 2025-09-12).

| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2025-12-20 | 2025-12-20 | cumplido | ninguna (302 días) |
| Ingeniería de detalle aprobada | 2026-03-20 | 2026-03-20 | cumplido | ninguna (212 días) |
| Licencia y permisos obtenidos | 2026-06-18 | 2026-06-18 | cumplido | ninguna (122 días) |
| Montaje e instalación | 2026-09-16 | 2026-09-16 | cumplido | ninguna (32 días) |
| Pruebas en operación | 2026-12-15 | 2026-12-15 | pendiente | — |

### Dónde no coincide
- **Verde vs. evidencia (informe 2026-10-08):** el gerente reporta verde, pero los cuatro hitos «cumplidos» no tienen ningún documento que lo sustente, y el 48% de avance no cuadra con 4 de 5 hitos cumplidos.
- **CT-546 Automatización de Procesos Ltda.:** facturado COP 2.519.443.535 (factura 2026-09-28) frente a COP 1.810.007.449 aceptado; diferencia COP 709.436.086. Solo la «Bolsa de horas de ingeniería» está aceptada, con acta de recibo del 2026-09-05. «Licenciamiento del software» (vencía 2026-03-05) sigue pendiente, 227 días tarde.
- **CT-852 Servicios Ambientales del Norte:** facturado COP 4.289.910.924 (factura 2026-09-18), igual a la suma de los dos entregables que figuran como aceptados («Bolsa de horas de ingeniería» y «Calibración de sensores»). Ninguno de los dos tiene acta de recibo, así que la aceptación no está respaldada. «Licenciamiento del software» (vencía 2026-01-23) sigue pendiente, 268 días tarde.
- **Dentro del propio informe del 2026-10-08:** declara una parada de planta reprogramada (incidencia) y un proveedor que no ha confirmado fecha de la última entrega, con el estado en verde.

### Abierto
**Riesgos e incidencias sin movimiento:** ninguno registrado con fecha de último movimiento, así que no se pueden contar días.
- Riesgo: «Ventana de parada de planta definida por operaciones» — sin responsable, probabilidad, impacto ni fecha.
- Riesgo: «El proveedor no ha confirmado la fecha de la última entrega» — sin responsable, probabilidad, impacto ni fecha.
- Incidencia: «Se reprogramó la parada de planta por la ventana de mantenimiento» — desde 2026-10-08, sin responsable.

**Compromisos vencidos:** ninguno; tampoco hay compromisos registrados, porque no hay minutas.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Autoridad de decisión del proyecto: no aparece en ningún documento.
- Fase: no aparece en ningún documento.
- Producto: el acta dice «No aplica».
- Última reunión y compromisos: no hay minutas en la carpeta.
- Evidencia de cumplimiento de los 4 hitos y actas de recibo de 2 entregables de CT-852.
- Probabilidad, impacto, responsable y fecha de los riesgos.
- Campos de identidad, plan y presupuesto aprobado con 13 meses de antigüedad (acta de 2025-09-12; umbral 12 meses): hay que confirmarlos.

### Qué sigue
No hay desviación en fecha ni en costo por encima del umbral, pero las facturas por encima de lo aceptado (CT-546) y los entregables aceptados sin acta (CT-852) pueden exceder la autoridad del gerente, y esa autoridad no está definida en ningún documento. Ofrezco preparar el punto de comité del 2026-10-29 sobre esto con `/steering-pack`.

---
**Pie:** criterio-portfolio 0.5.0 · ficha PRY-201 actualizada el 2026-10-18, a partir de documentos hasta el 2026-10-08 · campos inciertos: autoridad, fase, evidencia de hitos, riesgos sin valoración, campos con 13 meses de antigüedad · Términos v1.1 aceptados el 2026-10-18 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
