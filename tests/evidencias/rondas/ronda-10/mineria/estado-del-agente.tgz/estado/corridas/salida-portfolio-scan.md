## Barrido — 2026-10-18

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hizo falta registrarlos de nuevo.

**Documentos:** 80 en la carpeta · 54 leídos · 26 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia
**Formatos:** 39 md, 12 docx, 12 pdf, 9 xlsx, 6 csv, 1 json, 1 txt. Plan: 1 lote de 10 proyectos, ejecutado tal cual, sin diferidos.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan (1 línea base, 5 hitos), dinero, 1 contrato (3 entregables), 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase, factura del contrato |
| PRY-200 Mantenimiento predictivo de camiones | 6 | identidad, plan (4 hitos), dinero, 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase, proveedores |
| PRY-201 Ampliación de la relavera | 8 | identidad, plan (5 hitos), dinero, 2 contratos (5 entregables, 2 facturas), 2 riesgos, 1 incidencia | producto (el acta dice «No aplica»), autoridad, fase |
| PRY-202 Planta de tratamiento de agua | 7 | identidad, plan (2 líneas base, 4 hitos), dinero, CC-01, 1 riesgo, 1 incidencia, 1 compromiso | producto, autoridad, fase, proveedores, motivo de la línea base v2 |
| PRY-204 Monitoreo de taludes | 7 | identidad, plan (5 hitos), dinero, 2 contratos (7 entregables, 1 factura), 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase, factura de CT-597 |
| PRY-205 Sistema de gestión de seguridad | 6 | identidad, plan (líneas base v1 y v3, 3 hitos), dinero, CC-01 y CC-02, 1 riesgo, 1 incidencia | producto, autoridad, fase, proveedores, motivo de la v3 |
| PRY-206 Red privada LTE en mina | 4 | identidad, plan (4 hitos), dinero, 2 riesgos, 1 incidencia | producto, autoridad, fase, proveedores |
| PRY-207 Gemelo digital de la planta | 2 | identidad, plan (solo línea base del acta), dinero, 2 riesgos, 3 incidencias | autoridad, fase, hitos (no hay cronograma), proveedores |
| PRY-209 Electrificación de equipos | 5 | identidad, plan (4 hitos), dinero, 2 riesgos, 1 incidencia, 1 compromiso | producto, autoridad, fase, proveedores |
| PRY-210 Programa de relacionamiento comunitario | 3 | identidad, plan (4 hitos), dinero, 2 riesgos, 1 incidencia | producto, autoridad, fase, proveedores |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-203, PRY-208, PRY-211 | Nada: sin cambio por hash, no se abrieron ni se reescribieron | plan-lectura |

### Lo que hay que mirar (lo extraje tal cual; el cálculo y las señales las da el script)
- **Hitos cerrados sin acta de recibo:** en todos los proyectos salvo los que tienen acta citada en la ficha. Solo hay acta para: PRY-199 (básica), PRY-200 (básica y detalle), PRY-202 (básica), PRY-206 (básica), PRY-209 (detalle). El resto de hitos «cerrado» queda con `evidence` vacío.
- **Contratos con entregables «recibido» sin acta:** PRY-201 CT-852 (2 entregables, factura FV-2852 por 4.289.910.924) y PRY-204 CT-387 (bolsa de horas, factura FV-2387 por 1.573.545.600). En PRY-201 CT-546 hay un acta, pero la factura FV-1546 (2.519.443.535) no coincide con el monto de un entregable (1.810.007.449).
- **Cambios de cronograma:** PRY-202 pasó a v2 (cierre 2026-11-30) y PRY-205 a v3 (2026-12-19), con CC-01 (y CC-02 en 205) «autorizadas por el comité» sin decir cuál; en PRY-205 falta el cronograma v2 en la carpeta.
- **PRY-207:** el acta fija cierre 2026-07-30 y no hay ningún documento posterior de plan; el informe de 2026-10-11 declara verde y 34%.
- **PRY-209:** el informe declara ejecutado mayor que comprometido.
- **PRY-210:** declara amarillo con 69% y sus cuatro hitos figuran cerrados con cierre previsto 2026-08-29.
- **Compromisos con responsable ausente de la reunión:** PRY-199 (Carlos Peña), PRY-200 (Carlos Peña), PRY-202 (Carlos Peña), PRY-204 (Liliana Torres). Compromisos abiertos con fecha: 5.
- **PRY-203:** el plan de lectura reporta 17 campos de `pm_record` cuya fuente ya no resuelve (acta, cronograma e informe); no los toqué, porque su ficha no entró en el plan.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | 80 de 80 convertidos |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

*Pie: criterio-portfolio 0.5.0 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 204, 205, 206, 207, 209, 210) · campos en `not_found`: autoridad y fase en las 10; producto en 6; proveedores en 7; factura en 2 contratos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
