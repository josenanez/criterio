Fuentes: ficha PRY-205 (estado/records/PRY-205.json) y cálculo de `portafolio.py compute`, al 2026-10-18. Documentos: acta de constitución (2025-07-11), informe de avance (2026-10-15), cronograma v3 (2026-10-15), solicitudes de cambio CC-01 (2026-10-05) y CC-02 (2026-10-12). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Presupuesto — PRY-205 Sistema de gestión de seguridad, al 2026-10-18
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 4.200.000.000 | 100 | 00-gobierno/2025-07-11-acta-constitucion.docx | 2025-07-11 |
| Comprometido | 2.648.414.321 | 63.1 | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |
| Ejecutado | 1.211.699.567 | 28.8 | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |
| Proyección al cierre | 5.095.962.103 | 21.3 por encima del aprobado | 20-seguimiento/2026-10-15-informe-avance.pdf | 2026-10-15 |

**Disponible real** (aprobado menos comprometido): 1.551.585.679 COP

La proyección es una declaración del informe de avance, no un dato medido. Tiene la misma fecha que el informe (3 días) y es posterior a los dos cambios aprobados (10-05 y 10-12), así que no está vencida frente a ellos. El informe no dice si la proyección ya incluye el costo de esos cambios.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 4.200.000.000 | no declarado | 21.3 % de la proyección sobre el aprobado de 2025 |

Replanificaciones de presupuesto: ninguna registrada como línea base de costo. La única línea base que la ficha lleva es la de cronograma (v1 de 2025-07-11 y v3 de 2026-10-15; no hay v2 en la carpeta; la v3 no declara motivo).
Dos cambios aprobados con impacto de costo: CC-01 (60.000.000 COP adicionales) y CC-02 (232.000.000 COP adicionales). Ningún documento declara el aprobado vigente que resulta de ellos, y no lo calculo: el script no lo da. El aprobado de 4.200.000.000 sigue siendo el del acta de 2025. Ambos cambios dicen "el comité" sin indicar cuál.

### Ejecución frente a avance
Ejecutado 28.8 % · Hitos cumplidos 3 de 3 · Avance declarado 34 %.
Los números de dinero y el avance declarado (28.8 % frente a 34 %) están cerca entre sí. La contradicción está en los hitos: el cronograma v3 marca 3 de 3 como cumplidos (el plan sostendría 100 %), 66 puntos por encima del avance declarado, y ninguno tiene evidencia de recibo.

### Alertas
- **Proyección excede el aprobado:** 5.095.962.103 contra 4.200.000.000 COP, 21.3 % por encima (umbral 10 %).
- **Retraso contra la línea base original:** 146 días, 39.5 % (umbral 10 %). Contra la vigente: 0 días. El corrimiento está aprobado en CC-01 y CC-02 (+30 y +116 días).
- **Hitos cumplidos sin evidencia:** "Ingeniería básica aprobada" (vencía 2025-11-21, hace 331 días) e "Ingeniería de detalle aprobada" (2026-03-24, hace 208 días). Además, "Licencia y permisos obtenidos" figura como cumplido con fecha vigente 2026-12-19, que aún no llega, y también sin evidencia.
- **Avance declarado frente al plan:** 34 % declarado contra 100 % que sostienen los hitos.
- **Comprometido (63.1 %) por debajo del umbral de 90 %:** no hay alerta por este concepto.
- El informe declara estado rojo, pero no da cuenta de estas cuatro señales: hitos cumplidos sin evidencia, avance contra plan, variación de costo y variación de tiempo.

### Sin dato
- Presupuesto aprobado vigente tras CC-01 y CC-02.
- Motivo de la replanificación de la línea base v3 y la versión v2.
- Si la proyección incluye los 292 millones de los cambios aprobados. (Los dos montos están en las solicitudes; la proyección no dice si los cuenta.)
- Evidencia de aceptación de los tres hitos.
- Producto, autoridad y fase del proyecto (campos sin dato en la ficha). Los campos de identidad y presupuesto aprobado tienen 15 meses de antigüedad, por encima del umbral de 12.
- Contratos de proveedores: la ficha no registra ninguno, así que no hay detalle por proveedor.

### Después
La proyección excede el aprobado: se puede preparar la solicitud de cambio con `/criterio-portfolio:change-control`. No la preparo aquí, porque nadie puede confirmarlo en esta prueba.

---
Rigor: las cifras salen de la ficha y del cálculo del script, con la fuente y la fecha de cada una. No leí los documentos originales de nuevo en esta corrida. Esta lectura no sustituye la verificación de quien responde por el proyecto; el hito "cumplido" que declara el cronograma no es un hito aceptado mientras no haya evidencia.
