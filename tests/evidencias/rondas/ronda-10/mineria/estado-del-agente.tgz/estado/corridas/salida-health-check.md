Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hizo falta registrarlos de nuevo.

## Diagnóstico · PRY-202 Planta de tratamiento de agua · 2026-10-18

**Leí:** 7 documentos · 2025-12-09 a 2026-10-13 · formatos: Markdown (5), CSV (1), XLSX (1)
**No pude leer:** ninguno de la carpeta del proyecto. Busqué el código PRY-202 en las demás carpetas solo en archivos de texto; los .docx, .pdf y .xlsx de otros proyectos no los abrí, así que una mención ahí no la vería.

### Dictamen
**Sostenido:** 3 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 3 (13 afirmaciones evaluadas)

Desde esta carpeta se puede afirmar el presupuesto aprobado (2.400.000.000 COP) y que el cierre se movió del 2026-08-27 al 2026-11-30. CC-01 y el cronograma v2 coinciden en esos 95 días. No se puede afirmar el avance real, el gasto real ni que el comité autorizó el cambio. El estado «Verde» del informe del 2026-10-13 lo contradicen el propio informe y el cronograma. Cinco de los siete documentos son del 10 al 13 de octubre de 2026 y ninguno cae entre diciembre de 2025 y esa fecha. La evidencia de los hitos cerrados falta casi toda.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Sandra Gil | 00-gobierno/2025-12-09-acta-constitucion.md |
| Gerente | Sandra Gil (la misma persona que el patrocinador) | 00-gobierno/2025-12-09-acta-constitucion.md |
| Autoridad declarada | No está declarada en ningún documento | — |
| Comité | Comité de Inversiones. La minuta del 2026-10-12 lista como asistentes «Sandra Gil, Sandra Gil»: una sola persona | 30-reuniones/2026-10-12-comite-semanal.md |

Sin autoridad declarada y con patrocinador, gerente y única asistente del comité en una sola persona, no hay aprobador independiente a la vista. El acta tiene además el alcance en blanco (Componente 1, 2, 3).

### Contra el plan
- Línea base original: cierre 2026-08-27 (Montaje e instalación). Se conserva en la columna `fecha_linea_base` del cronograma v2.
- Vigente: 2026-11-30. Una replanificación: CC-01 (2026-10-10, «Ampliación de alcance», +95 días y 190.000.000 COP adicionales), recogida en el cronograma v2 del 2026-10-13.
- Desviación contra la original: **95 días (37.8%)**. Contra la vigente: 0 días. El umbral de la configuración es 10%.
- CC-01 dice «Autorizada por el comité» sin fecha, sin nombre y sin acta. La minuta del 2026-10-12 trata solo «Avance» y «Compromisos» y no menciona CC-01.
- La «ampliación de alcance» no dice qué se amplía, y el alcance del acta es un marcador de posición, así que no se puede medir.
- El informe del 2026-10-13 sigue mostrando Aprobado 2.400.000.000: el costo adicional de CC-01 no aparece en ninguna línea base de presupuesto.

### Las cuatro cifras
Todas vienen del informe de avance del 2026-10-13 (una declaración). Ningún contrato, factura ni libro las respalda.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería de detalle aprobada | 2026-04-23 | 178 | Acta de recibo de la ingeniería de detalle |
| Licencia y permisos obtenidos | 2026-06-25 | 115 | Resolución o licencia del permiso, y su acta de recibo |

Dos notas más que el script no cuantifica, por lo que no escribo días:
- **Montaje e instalación** figura «cerrado» en el cronograma v2, con fecha vigente 2026-11-30, que es futura. No hay acta. La fecha original (2026-08-27) ya pasó.
- **Ingeniería básica aprobada** (vencía el 2026-02-19) sí tiene acta de recibo, pero es del 2026-10-13, firmada por Sandra Gil como quien recibe. Es el único hito con evidencia en la carpeta.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.633.608.660 (68.1%) | 1.308.832.360 (54.5%) | 2.358.092.650 (−1.7% sobre lo aprobado) | 766.391.340 |

Cifras en COP, copiadas de `portafolio.py compute`. Fuente única: informe de avance, es decir, declaración.

### Lo que se dijo y nadie registró
No existe ningún registro RAID en la carpeta.
- **Incidencia:** «El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite» (informe 2026-10-13). Sin fecha de repetición, sin dueño, sin acta del ensayo.
- **Dependencia:** la «ventana de parada de planta definida por operaciones» (informe) y el «plan de arranque» acordado con operaciones. El acta declara «Ninguna declarada» como dependencia. El informe la lista como riesgo, pero es una dependencia: no tiene probabilidad, dueño ni fecha.
- **Compromiso:** Carlos Peña, «Entregar el punto 40», para el 2026-10-18 (hoy). El «punto 40» no está definido en ningún documento y Carlos Peña no aparece en el acta ni como asistente. Todavía no está vencido; la próxima corrida lo revisa.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado «Verde» | Informe 2026-10-13: «Verde» | El mismo informe: ensayo de disponibilidad fallido y repetido; CC-01 y v2: 95 días (37.8%) de desviación; 2 hitos cerrados sin evidencia |
| Avance 84% | Informe 2026-10-13: 84% | Cronograma v2: 4 de 4 hitos «cerrado» (el plan sostiene 100%) |
| Montaje e instalación «cerrado» | Cronograma v2: «cerrado» | Informe 2026-10-13: el ensayo de disponibilidad no alcanzó lo pactado y se repite; el criterio de éxito del acta es «en producción y medido» |

Observación, no cuenta como contradicción: el cronograma v1, con fecha del 2025-12-09 (antes del inicio, el 2025-12-19), ya marca los cuatro hitos «cerrado». Eso no pudo ser cierto ese día, así que la integridad de la línea base original no se puede verificar desde el archivo. Los hitos de detalle, licencia y montaje figuran cerrados mientras la ingeniería básica solo se recibió el 2026-10-13.

### Sin sustento
Lo que nada contradice y nada respalda:
1. Comprometido, ejecutado y proyección (informe, sin contrato ni factura).
2. Ingeniería de detalle aprobada «cerrado» (sin acta).
3. Licencia y permisos obtenidos «cerrado» (sin documento).
4. CC-01 «Autorizada por el comité», con sus 190.000.000 COP y 95 días.
5. «Se acordó con operaciones el plan de arranque» (sin acta ni correo).
6. «Se actualizó el presupuesto de la obra con el área de compras» (sin documento, y el aprobado sigue igual).
7. El ensayo fallido y su repetición (sin registro del ensayo). Es una admisión del propio gerente: la tomo como dicha y no probada.

Sostenidas: presupuesto aprobado 2.400.000.000 COP (acta de constitución), ingeniería básica aprobada recibida el 2026-10-13 (acta de recibo) y el cierre movido a 2026-11-30 (CC-01 y cronograma v2 coinciden en los 95 días).

### Lo que esta carpeta no permite saber
- **Si el comité aprobó CC-01.** Sin eso, los 95 días y los 190.000.000 COP no tienen aprobación verificable, y la desviación contra la vigente (0 días) descansa en un cambio no probado.
- **Quién tiene autoridad sobre el proyecto.** Sin ella, las fechas nuevas son fechas que alguien escribió.
- **El avance real.** No hay actas de 3 de los 4 hitos ni registro del ensayo de disponibilidad. El 84% y el 100% del plan no se pueden dirimir.
- **El gasto real.** No hay contrato, factura ni libro. Los 766.391.340 COP de disponible real dependen de cifras declaradas.
- **Qué se amplió y qué incluye el alcance.** El acta tiene componentes sin nombre.
- **Qué pasó entre 2025-12-09 y 2026-10-10.** No hay documentos en ese tramo; el proyecto o su carpeta estuvieron callados diez meses. Desde la carpeta no puedo decir de quién es el silencio.
- **Si el cronograma v1 es el original.** Ver la observación sobre sus estados.
- **Fase del proyecto y producto asociado:** campos sin dato en la ficha (el acta dice «No aplica» para producto).

### Pie de rigor
Las cifras derivadas (95 días, 37.8%, 178 y 115 días, 68.1%, 54.5%, −1.7%, disponible real, 84% frente a 100%) están copiadas de `portafolio.py compute` (corte 2026-10-18). Separé lo declarado (informe, CC-01, cronogramas) de lo probado (acta de constitución y acta de recibo de la ingeniería básica); de los 13 puntos evaluados, solo 3 están sostenidos. Las inferencias mías son tres: que «Ventana de parada» es una dependencia y no un riesgo, que el cronograma v1 no pudo estar cerrado en su fecha, y que el cronograma v2 tiene los hitos en orden lógico inverso. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

### Siguiente paso posible
Puedo llevar las 3 contradicciones y los 7 puntos sin sustento a Sandra Gil como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta (acta de comité de CC-01, actas de detalle, licencia y montaje, registro del ensayo, contratos y facturas, definición de «punto 40»).
