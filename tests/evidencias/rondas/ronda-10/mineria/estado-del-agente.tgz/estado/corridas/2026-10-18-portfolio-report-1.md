# Corrida del 2026-10-18 · portfolio-report

13 proyectos · 80 documentos, 0 releídos y 80 sin cambio · 35 s · 47 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `progress_vs_plan` | 7 |
| `declared_vs_evidence` | 6 |
| `vendor_deliverable_late` | 5 |
| `vendor_accepted_without_evidence` | 3 |
| `variance_time` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `variance_cost` | 1 |
| `rebaseline_unauthorized` | 1 |

El informe quedó en `/home/claude/banco/ronda-10/mineria/espacio/reportes/index.html`.

6 verdes contradichos por la evidencia; 21 hitos cumplidos sin evidencia; PRY-205 con costo +21,3 % y PRY-208 con replanificación no autorizada

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-18
13 proyectos · 10 con hallazgos (47 señales) · fichas de `estado/records/` (13, generadas el 2026-10-18; declaraciones de avance entre 2026-09-30 y 2026-10-18) · ninguna con más de una semana sin barrido.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea previa es `snapshots/2026-10-18.json`, del mismo día; el diff dio 0 cambios).

## Contradicciones abiertas
Vacía: ningún campo en `ambiguous` en las 13 fichas.

## Hitos vencidos sin evidencia
Ningún hito vencido sin marcar. Lo que sí hay son **21 hitos declarados cumplidos sin evidencia** (señal `milestone_met_without_evidence`), en 9 proyectos:
PRY-201 (4), PRY-210 (4), PRY-211 (3), PRY-200 (1), PRY-202 (2), PRY-204 (2), PRY-205 (2), PRY-208 (2), PRY-209 (1). El detalle por hito, con fecha y días, está en cada página de proyecto.

## Proyectos en silencio
Vacía: el máximo es PRY-201 con 10 días, bajo el umbral de 15.

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias por código.

## Sin sustento
6 proyectos declaran verde y el script los contradice (`declared_vs_evidence`): PRY-200, PRY-201, PRY-202, PRY-203, PRY-204, PRY-209.
Avance declarado por debajo de lo que sostiene el plan (`progress_vs_plan`, 7 proyectos): PRY-205 (34% vs 100%, 66 puntos), PRY-201 (48% vs 80–100%), PRY-210 (69% vs 100%), PRY-211 (39% vs 60–80%), PRY-200 (57% vs 75–100%), PRY-202 (84% vs 100%), PRY-203 (37% vs 50–75%).
Proveedores: 5 entregables atrasados (PRY-201 ×2, PRY-204 ×3), 3 aceptados sin evidencia (PRY-201 ×2, PRY-204 ×1) y 1 facturación por encima de lo aceptado (PRY-201).

## Vacíos de información
Ningún proyecto tiene autoridad registrada (13 de 13). Cada ficha tiene entre 2 y 4 campos faltantes. PRY-201, PRY-205, PRY-210 y PRY-211 tienen 11–12 campos con más de 12 meses de antigüedad.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Luminarias campamento | verde | sin señales | 0 d | 0 d | 0 |
| PRY-200 Mantenimiento predictivo | verde | contradicho | 0 d | 0 d | 0 |
| PRY-201 Relavera | verde | contradicho | 0 d | 0 d | 0 |
| PRY-202 Planta de agua | verde | contradicho | +95 d (37,8 %) | 0 d | 1 |
| PRY-203 Despacho de flota | verde | contradicho | 0 d | 0 d | 0 |
| PRY-204 Monitoreo de taludes | verde | contradicho | 0 d | 0 d | 0 |
| PRY-205 Sistema de seguridad | rojo | consistente; costo +21,3 % | +146 d (39,5 %) | 0 d | 1 |
| PRY-206 Red LTE | verde | sin señales | 0 d | 0 d | 0 |
| PRY-207 Gemelo digital | verde | sin señales | 0 d | 0 d | 0 |
| PRY-208 Trazabilidad | rojo | replanificación no autorizada de 26 d | +26 d | 0 d | 1 |
| PRY-209 Electrificación | verde | contradicho | 0 d | 0 d | 0 |
| PRY-210 Relacionamiento comunitario | amarillo | 4 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-211 Control de polvo | amarillo | 3 hitos sin evidencia | 0 d | 0 d | 0 |

## Necesito que confirmes
No armé la confirmación del mes: el script no me dijo que tocara y no la inventé. Candidatos si quieres hacerla: los campos viejos de PRY-201, PRY-205, PRY-210 y PRY-211.

## Dónde quedó el informe
`/home/claude/banco/ronda-10/mineria/espacio/reportes/` (23 páginas, 13 de proyecto y 6 de producto). 7 proyectos no tienen producto asignado: PRY-201, 202, 205, 206, 209, 210, 211.
- `index.html`: vista por campo, con la cadena de evidencia. Para quien va a actuar.
- `decisiones.html`: vista por decisión, para el patrocinador.

Pie: criterio-portfolio 0.5.0 · 13 fichas del 2026-10-18 · campos inciertos: 0 contradicciones, 2–4 faltantes por ficha · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
