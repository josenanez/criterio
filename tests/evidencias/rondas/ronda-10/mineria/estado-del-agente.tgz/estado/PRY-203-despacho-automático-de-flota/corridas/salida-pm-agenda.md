## Reunión de seguimiento — PRY-203 Despacho automático de flota · 2026-11-01
8 puntos · 40 minutos · 6 personas requeridas (Jorge Medina, María Restrepo, Diana Molina, Elena Duarte, Óscar Ramírez, Laura Vélez)

Borrador al 2026-10-18. La fecha sale de la cadencia configurada (comité semanal, próximo 2026-11-01; las notas de hoy dicen «en dos semanas», que coincide). No pediste tope de tiempo: propongo 40 minutos. Los vencidos de la tabla «Vence antes de la próxima» pasan a «Vencido sin evidencia» el 11-01 si nadie presenta acta, así que conviene volver a correr `/pm-agenda` el 10-31.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y decidir si se destraba aquí o sube a comité** · 10 min · **María Restrepo, con Jorge Medina**
> Prometido para el 2026-12-19, y antes para el 12-05, el 11-19, el 11-11, el 10-27, el 10-14 y originalmente el 10-02. Seis reprogramaciones; la fecha vigente se corrió 78 días contra la primera promesa.
> Fuente: 30-reuniones/2026-09-06-comite-semanal.md (promesa) y 2026-10-18-notas-reunion.txt (última fecha).
> **Si no se resuelve hoy:** la fecha sigue corriéndose cada semana; seis veces no es un problema de seguimiento sino un bloqueo que nadie ha nombrado.

> **[2] Nombrar qué bloquea «Cerrar la prueba 2» y fijar una fecha que alguien pueda sostener** · 7 min · **Diana Molina**
> Prometido para el 2026-11-08, y antes para el 10-31, el 10-19, el 10-09 y originalmente el 09-29 (el 09-06 se dijo «por definir»). Cuatro reprogramaciones.
> Fuente: 30-reuniones/2026-09-06-comite-semanal.md y 30-reuniones/2026-10-11-comite-semanal.md.
> **Si no se resuelve hoy:** pasa a quinta reprogramación; con la fecha actual del 11-08 vence una semana después de esta reunión.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 | Entregar el documento o decir qué lo frena (fuente: 2026-09-13-comite-semanal.md) | 2 |
| Elena Duarte | Validar el ambiente 20 | 2026-10-12 | Ídem (fuente: 2026-10-04-comite-semanal.md) | 2 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-13 | El 10-04 dijo que ya lo entregó: presentar el acta de recibo o reabrirlo con fecha (fuente: 2026-09-13-comite-semanal.md, reprogramado a 10-13 en 2026-09-27) | 3 |

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar como riesgo que el proveedor podría no llegar con el equipo completo para la siguiente fase, con dueño. Se comentó el 10-18 y nadie lo anotó (2026-10-18-notas-reunion.txt). Óscar Ramírez ya tiene la revisión con el proveedor para el 10-28. | Jorge Medina, con Óscar Ramírez | Un riesgo hablado y no registrado no tiene dueño ni fecha, y la revisión del 10-28 pasa sin llevarlo | 4 |
| Dueño del riesgo «Ventana de parada de planta definida por operaciones»: está en el informe del 10-10 sin dueño, probabilidad ni impacto (20-seguimiento/2026-10-10-informe-avance.md). | Jorge Medina | Sigue abierto sin dueño; el informe reporta además que la parada ya se reprogramó una vez | 2 |
| Fecha del «ajuste del presupuesto»: se prometió «la otra semana» y nadie dijo fecha (2026-10-18-notas-reunion.txt). | Laura Vélez | Compromiso sin fecha no puede vencer, y por eso nadie lo persigue | 2 |

### Vence antes de la próxima · 8 min, solo confirmar con «sí hay acta» o «no»
Los tres de la primera fila vencen el 10-18; el resto, hasta el 10-31. Si el 11-01 no hay acta, pasan a vencidos.

| Quién | Qué | Para cuándo |
|---|---|---|
| Paula Céspedes | Revisar el anexo 3 (reprogramado 1 vez) | 2026-10-18 |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 |
| Javier Hoyos | Cerrar la prueba 18 (reprogramado 1 vez) | 2026-10-18 |
| Carlos Peña | Revisar el anexo 19 | 2026-10-19 |
| Óscar Ramírez | Actualizar la matriz 14 | 2026-10-21 |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-21 |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-22 |
| Carlos Peña | Confirmar la fecha 7 | 2026-10-24 |
| Carlos Peña | Enviar el documento 9 (reprogramado 1 vez) | 2026-10-24 |
| Paula Céspedes | Entregar el punto 16 | 2026-10-26 |
| Sandra Gil | Entregar el punto 8 (reprogramado 2 veces) | 2026-10-27 |
| Javier Hoyos | Confirmar la fecha 15 (reprogramado 1 vez) | 2026-10-28 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 |
| Felipe Arango | Aprobar el diseño 21 | 2026-10-30 |
| Felipe Arango | Entregar el punto 24 | 2026-10-30 |
| Elena Duarte | Enviar el documento 17 | 2026-10-31 |
| Laura Vélez | Revisar el anexo 11 (reprogramado 2 veces; el 10-11 dijo que ya lo entregó, sin acta) | 2026-10-31 |
| Hito | Licencia y permisos obtenidos, línea base 2026-11-01, pendiente y sin evidencia | 2026-11-01 |

Carlos Peña concentra 4 de los 18 compromisos.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Natalia Ospina · Validar el ambiente 4 (vencido desde 2026-10-02, el vencido más viejo) | Solo asistió a las reuniones del 09-06 y 09-13; no está en la sala. El 09-13 dijo que ya lo validó y no hay acta. | Jorge Medina consigue el acta o la respuesta por fuera; si no aparece, entra a la agenda del 11-08 con su nombre |
| Quién tiene la autoridad del proyecto | La ficha no la tiene en ningún documento (identity.authority) | Material del comité del 11-01; `/pm-escalate` |
| Si los puntos 1 o 2 resultan ser un bloqueo que excede la autoridad del gerente | Seis y cuatro reprogramaciones piden una decisión que esta sala puede no tener | `/pm-escalate` para formularlo; `/pm-commitments` para el compromiso |
| Estado «verde» y 37 % declarados (informe del 10-10) frente a 2 de 4 hitos cumplidos, 4 vencidos y 2 reprogramados en serie | Es la declaración del gerente contra la evidencia, no un tema de seguimiento de compromisos | `/pm-report`; es del gerente |

### Anexo — no se repasa en la reunión
No hay corrida anterior de `diff` (es la primera, «baseline_run»), así que no puedo decir qué quedó igual desde la última reunión. Lo que sí se ve cerrado y no se repasa:
- María Restrepo · Validar el ambiente 12 — cerrado con 20-seguimiento/2026-09-27-acta-recibo-12.md.
- Carlos Peña · Aprobar el diseño 13 — cerrado con 20-seguimiento/2026-10-04-acta-recibo-13.md.
- Hito «Ingeniería básica aprobada» y «Ingeniería de detalle aprobada» — cumplidos, con acta de recibo (11 y 18 de octubre).

Quedaron fuera por tiempo: nada. Suman 40 de 40 minutos. Este comando no convoca a nadie: citar a la reunión es del gerente, Jorge Medina.
