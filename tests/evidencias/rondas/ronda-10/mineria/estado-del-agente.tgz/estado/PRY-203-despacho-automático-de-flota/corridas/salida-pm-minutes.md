# Acta — Despacho automático de flota (PRY-203) · 2026-10-18
**Asistieron:** Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil, Óscar Ramírez · **Fuente:** 2026-10-18-notas-reunion.txt · **Ausentes con tema en agenda:** la fuente no trae agenda. Natalia Ospina no figura entre los asistentes y tiene «Validar el ambiente 4» vencido hace 16 días.

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos otra vez.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| María Restrepo | Enviar el documento 1 (notas, l.4: «no alcanzó, se compromete para el 19/12/2026») | 2026-12-19 | **Reprogramado 6 veces** (original 2026-10-02 → 10-14 → 10-27 → 11-11 → 11-19 → 12-05 → 12-19). Pasa el umbral de 3. |
| Óscar Ramírez | Revisión con el proveedor (notas, l.6) | 2026-10-28 | Nuevo |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto (notas, l.5: «la otra semana»). Nadie dijo una fecha; queda con `due_date: no_declarada` y no se le calculó una. |

## Decisiones
Ninguna. Las notas no registran que nadie haya decidido algo ni qué se descartó.

## Quedó sin decidir
Nada declarado como pendiente de decisión en las notas.

## Intenciones sin doliente
Ninguna en esta reunión.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase (notas, l.7: «nadie lo anotó como riesgo») | No se atribuye: las notas dicen «se comentó» | Riesgo (dependencia de proveedor) | No. Entra ahora a la ficha, sin probabilidad, impacto ni dueño, porque la reunión no los dio. |

El riesgo toca directamente la revisión con el proveedor que Óscar Ramírez tiene para el 2026-10-28. La ficha tampoco lista al proveedor en `vendors`.

## Cerrado en esta reunión
Se omite: ningún documento cierra algo en esta reunión.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «próxima reunión en dos semanas» (2026-11-01) | Comité semanal | Notas 2026-10-18 · config del proyecto (`committee: weekly`; `committee_next: 2026-11-01`) |

Es leve: la fecha coincide con `committee_next`. Lo que choca es que el comité pasa de semanal a cada dos semanas, y las notas no dicen que se haya decidido. No cambia ningún campo de la ficha.

## Sin resolver de la transcripción
- «revisión con el proveedor, queda para el 2026-10-28» (l.6): no dice qué revisión ni si Óscar Ramírez la dirige o solo asiste. Se registró a su nombre porque la línea abre con él.
- «lo de "enviar el documento 1" no alcanzó» (l.4): no dice por qué no alcanzó.
- Tres compromisos vencen hoy (Paula Céspedes, anexo 3; Carlos Peña, prueba 10; Javier Hoyos, prueba 18) y las notas no los mencionan. Ni se cierran ni se dan por cumplidos.
- Siguen vencidos sin que la reunión los tocara: Natalia Ospina (ambiente 4), María Restrepo (diseño 5), Elena Duarte (matriz 6 y ambiente 20).

## Recalculo (`portafolio.py compute`)
Sin `record_issues`. 9 alertas. La ficha declara **verde** (informe del 2026-10-10) y las señales de compromisos vencidos, reprogramados y avance contra plan la contradicen: declara 37 %, el plan sostiene entre 50 % y 75 % (2 de 4 hitos). Los 4 vencidos y los 2 reprogramados son los de arriba. El sin-fecha es Laura Vélez.

**Siguiente:** `/pm-commitments` para ver el seguimiento completo; `/pm-publish` si quieres que la PMO vea la ficha. El acta es tuya: no se escribió en la carpeta de reuniones.
