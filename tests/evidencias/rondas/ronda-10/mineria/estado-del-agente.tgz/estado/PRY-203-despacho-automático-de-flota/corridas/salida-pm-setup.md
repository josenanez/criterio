Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 14 documentos (7 minutas: seis comités semanales del 2026-09-06 al 2026-10-11 y las notas del 2026-10-18; 4 actas de recibo; un informe de avance; el cronograma; el acta de constitución). Todos se pudieron leer; formatos .md, .txt, .pdf y .xlsx. La más reciente es del 2026-10-18.

Las cuatro preguntas, con la respuesta sugerida (nadie respondió en esta prueba):
1. Proyecto y gerente: PRY-203, Despacho automático de flota, gerente Jorge Medina, como dice el acta de constitución.
2. Reunión de seguimiento: semanal, los domingos, que es el día de las minutas. Las notas de hoy dicen «próxima reunión en dos semanas», así que quedó anotada la del 2026-11-01.
3. Estado: `estado/PRY-203-despacho-automático-de-flota`, fuera de la carpeta de documentación.
4. Términos: versión 1.1, mostrados con su enlace a la nota legal (https://www.josenanez.com/es/agents/criterio-pmo/legal). José Francisco Ñáñez los aceptó con fecha 2026-10-18, según lo indicado para esta prueba.

**Términos:** aceptados para la versión 0.5.0 (términos 1.1) por José Francisco Ñáñez · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 ffa4799dee7ac84c… (md) y 23531460258f311e… (pdf)

Leí las siete reuniones de la más vieja a la más nueva: 26 compromisos en total. La ficha quedó en `estado/PRY-203-despacho-automático-de-flota/records/PRY-203.json`, sin sellar: leí reuniones, actas y el informe, y falta revisar el resto de la carpeta antes de darla por leída.

### Lo que está abierto, y cuántas veces se ha movido

**Reprogramados** (señal de `compute`: 3 o más veces)

| Quién | Qué | Para cuándo | Veces | Cita |
|---|---|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-12-19 | 6 (prometido el 2026-10-02; luego 10-14, 10-27, 11-11, 11-19, 12-05, 12-19) | `30-reuniones/2026-09-06-comite-semanal.md` … `2026-10-18-notas-reunion.txt` («no alcanzó, se compromete para el 19/12/2026») |
| Diana Molina | Cerrar la prueba 2 | 2026-11-08 | 4 (primera fecha 2026-09-29; luego 10-09, 10-19, 10-31, 11-08) | `30-reuniones/2026-09-13-comite-semanal.md` … `2026-10-11-comite-semanal.md` |

El 2026-09-06 la prueba 2 estaba «por definir»: poner el 2026-09-29 no cuenta como reprogramación.

**Vencidos sin evidencia** (señal de `compute`)

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Natalia Ospina | Validar el ambiente 4 | 2026-10-02 | 16 | `30-reuniones/2026-09-06-comite-semanal.md` |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 | 12 | `30-reuniones/2026-09-13-comite-semanal.md` |
| Elena Duarte | Validar el ambiente 20 | 2026-10-12 | 6 | `30-reuniones/2026-10-04-comite-semanal.md` |
| María Restrepo | Aprobar el diseño 5 | 2026-10-13 | 5 | `30-reuniones/2026-09-13-comite-semanal.md` |

Dos de ellos tienen un «ya lo entregué» dicho en reunión, y ningún acta lo prueba:
- Natalia Ospina, «validar el ambiente 4», lo dijo el 2026-09-13 (`30-reuniones/2026-09-13-comite-semanal.md`). No volvió a aparecer en ninguna minuta.
- María Restrepo, «aprobar el diseño 5», lo dijo el 2026-10-04 (`30-reuniones/2026-10-04-comite-semanal.md`). Ya no figura en la tabla de ese día ni de las siguientes.

Un tercer caso es parecido pero no está vencido: Laura Vélez dijo el 2026-10-11 que ya entregó «revisar el anexo 11», cuya fecha vigente es 2026-10-31. Tampoco hay acta (`30-reuniones/2026-10-11-comite-semanal.md`).

**Cumplidos con acta:** Validar el ambiente 12 (María Restrepo, acta del 2026-09-27) y Aprobar el diseño 13 (Carlos Peña, acta del 2026-10-04).

**Reprogramados menos de tres veces**
- Paula Céspedes, revisar el anexo 3: de 2026-09-15 a 2026-10-18 (1 vez).
- Sandra Gil, entregar el punto 8: 09-23 → 10-03 → 10-27 (2 veces).
- Laura Vélez, revisar el anexo 11: 09-24 → 10-16 → 10-31 (2 veces).
- Carlos Peña, enviar el documento 9: 10-17 → 10-24 (1 vez).
- Javier Hoyos, confirmar la fecha 15: 10-10 → 10-28, y cerrar la prueba 18: 10-09 → 10-18 (1 vez cada uno).

**Los demás abiertos y al día:** Carlos Peña (confirmar la fecha 7, 2026-10-24; cerrar la prueba 10, 2026-10-18; revisar el anexo 19, 2026-10-19), Óscar Ramírez (actualizar la matriz 14, 2026-10-21; confirmar la fecha 23, 2026-10-21; revisión con el proveedor, 2026-10-28), Paula Céspedes (entregar el punto 16, 2026-10-26), Elena Duarte (enviar el documento 17, 2026-10-31), Felipe Arango (aprobar el diseño 21 y entregar el punto 24, ambos 2026-10-30) y Laura Vélez (actualizar la matriz 22, 2026-10-22).

### Sin fecha
- Laura Vélez, «mandar el ajuste del presupuesto»: «la otra semana» (`2026-10-18-notas-reunion.txt`). Nadie dijo un día. No puede estar vencido, y por eso es el que desaparece de los informes. Conviene preguntar la fecha en la próxima reunión.

### Contra lo que dice el informe
El informe del 2026-10-10 declara **verde** y **37 %** de avance (`20-seguimiento/2026-10-10-informe-avance.md`). `compute` levantó contra esa declaración:
- `progress_vs_plan`: con 2 de 4 hitos cerrados, el plan sustenta entre 50 y 75 %; el declarado queda 13 puntos por debajo.
- 4 compromisos vencidos y 2 reprogramados 3 o más veces, que el informe no menciona (`declared_vs_evidence`).

Samuel no declara el estado: el estado lo declaras tú. Esto es contra qué se contrasta.

Presupuesto, según el informe: aprobado 4.200.000.000 COP, comprometido 2.957.170.074 (70,4 %), ejecutado 2.066.157.295 (49,2 %), proyección al cierre 4.010.077.163 (−4,5 % contra lo aprobado). Sin señal de costo.

Otras notas:
- **Riesgo sin registrar:** en la reunión de hoy se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y nadie lo anotó como riesgo (`2026-10-18-notas-reunion.txt`). Quedó en la ficha, sin dueño ni probabilidad. El informe solo lista un riesgo: la ventana de parada de planta.
- **Hitos cerrados con acta tardía:** el cronograma los fecha el 2026-04-15 (ingeniería básica) y el 2026-07-24 (ingeniería de detalle). Sus actas de recibo son del 2026-10-11 y del 2026-10-18, el día de hoy. `compute` no levantó señal por esto: las actas existen.
- **Fecha de cierre:** 2027-02-09, igual a la del acta de constitución. El cronograma no trae versión más reciente, así que no hay desviación.
- **Quién es quién:** el acta nombra a Jorge Medina como gerente y a Felipe Arango como patrocinador. Los términos los aceptó José Francisco Ñáñez; si esa persona es la gerente del proyecto, conviene corregirlo.

### Qué le falta a tu carpeta
- Minutas anteriores al 2026-09-06: el proyecto empezó en enero y solo hay siete reuniones. Los compromisos que aparecen «por primera vez» el 09-13 o el 09-20 pueden venir de antes.
- Acta de recibo para «validar el ambiente 4», «aprobar el diseño 5» y «revisar el anexo 11»: sin ellas, lo que dijeron que entregaron se ve igual que lo incumplido.
- Cronograma vigente: solo hay la v1 de 2025-12-27, con todas las fechas vigentes iguales a la línea base.
- Alcance, autoridad del gerente y fase del proyecto: el acta dice «Componente 1, 2 y 3», sin autoridad ni etapa.
- Las notas del 2026-10-18 son un .txt sin formato de minuta; con una minuta como las de comité la lectura sería más precisa.

**Cuándo vuelvo:** el 2026-11-01, la próxima reunión según las notas de hoy. Antes, si cambia algo en la carpeta.
