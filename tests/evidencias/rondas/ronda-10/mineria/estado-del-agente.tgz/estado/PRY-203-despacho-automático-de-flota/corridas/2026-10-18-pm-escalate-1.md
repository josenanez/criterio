# Corrida del 2026-10-18 · pm-escalate

1 proyectos · 38 s · 9 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `commitment_undated` | 1 |
| `declared_vs_evidence` | 1 |

Paquete de una decisión: quién declara la autoridad del gerente (identity.authority no existe en ningún documento). No formulé el bloqueo del documento 1 (6 reprogramaciones) ni la prueba 2 (4): ninguna fuente dice la causa. No corrí impact: ninguna fecha se mueve y no hay días ni dependencias declaradas. Costos de las opciones no están en los documentos.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-203 Despacho automático de flota · 2026-10-18

Corrida sin interfaz: nadie respondió preguntas. No pasaste un tema, así que revisé lo que la ficha deja como escalable. Términos 1.1 ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta registrarlos de nuevo.

**Resultado en una línea:** hay un punto que escala y está listo (quién tiene la autoridad), uno que escala pero no puedo formular por falta de datos (el bloqueo de María Restrepo) y no armé paquete para lo demás.

### ¿Quién declara y firma por escrito qué puede decidir el gerente del proyecto: el patrocinador Felipe Arango, o el Comité de Seguridad?

**Quién decide:** Comité de Seguridad, que aprobó el acta y el presupuesto el 2025-12-27. El patrocinador es Felipe Arango. El acta no dice quién puede decidir qué; esto es lo que hay que dejar escrito. · **Si no se decide hoy:** el comité del **2026-11-01** (configuración) se reúne sin que nadie sepa si lo que se le pide a Jorge Medina está dentro de su autoridad. Ese día los compromisos que vencen sin acta pasan a vencidos, y los bloqueos de María Restrepo y Diana Molina llegan a esa mesa sin saber si ella puede resolverlos. Esta consecuencia la infiero de las fechas; ningún documento la declara.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta, firmada por el patrocinador (Felipe Arango), con límites de decisión del gerente en alcance, tiempo y costo | Solo la autoridad del gerente | Antes del 2026-11-01 si se pide ya (no hay dato de cuánto tarda la firma) | No hay cifra en ningún documento |
| B. El Comité de Seguridad la declara el 2026-11-01 y queda en su acta | Autoridad del gerente, y de paso la del comité sobre el proyecto | Se resuelve el 2026-11-01; hasta entonces el gerente decide sin saber el límite | No hay cifra en ningún documento |
| C. No se declara | Ninguno | Ninguno | Cada punto que suba se devuelve con «eso lo decide usted» o se decide sin que valga |

**Recomiendo:** A, y que B la ratifique el 11-01. La adenda es la forma más corta de llegar al comité con la autoridad ya escrita. Tu acta no tiene sección de autoridad, y el campo `identity.authority` está vacío en la ficha («no aparece en ningún documento»).

### Lo que revisé y no armé como paquete

| Qué | Por qué escala | Por qué no lo formulo aún |
|---|---|---|
| María Restrepo · «Enviar el documento 1» | Reprogramado 6 veces (umbral configurado: 3); promesa original 2026-10-02, vigente 2026-12-19, 78 días | Ningún documento dice qué la bloquea, ni quién es el doliente fuera del proyecto. Sin eso no hay pregunta cerrada ni opciones con costo. Primero: Jorge Medina le pregunta qué la frena (la agenda ya lo pone como punto 1). Si el bloqueo excede tu autoridad, vuelve aquí. |
| Diana Molina · «Cerrar la prueba 2» | Reprogramado 4 veces | Igual: causa no documentada |
| Riesgo: proveedor podría no llegar con el equipo completo (notas del 10-18) | No escala. No está registrado ni tiene dueño; es un riesgo sin plan, no uno con mitigación vencida | Se registra primero, con dueño (Óscar Ramírez tiene la revisión con el proveedor el 10-28). Hoy la ficha no tiene proveedor ni contrato (`vendors` vacío) |
| Natalia Ospina · «Validar el ambiente 4» (vencido desde 10-02) | No escala: se destraba con una llamada | Jorge Medina consigue el acta o la respuesta |
| Estado verde y 37 % frente a 2 de 4 hitos cumplidos | No es escalamiento; es la declaración contra la evidencia | `/pm-report` |

### A quién alcanza
No calculé el efecto: lo que se escala no mueve ninguna fecha, y `impact` necesita un número de días que no hay. La ficha no tiene dependencias declaradas (el acta dice «Ninguna declarada») ni otros proyectos cruzados, así que no puedo decir a qué otro proyecto alcanzaría ni cuál gerente habría que llamar. Si el bloqueo del documento 1 resulta ser de otra área, se corre `impact` entonces.

### Mis hitos por los que pasa
Ninguno. «Licencia y permisos obtenidos» (línea base 2026-11-01) está pendiente y sin evidencia: es el hito más cercano en riesgo, pero nada de lo que escala aquí lo mueve.

### De dónde sale esto
- Autoridad no declarada: 00-gobierno/2025-12-27-acta-constitucion.md (sin sección de autoridad; comité, patrocinador y presupuesto aprobados el 2025-12-27); ficha records/PRY-203.json, `identity.authority` no encontrado. Búsqueda de «autoridad», «facultad», «decide» y «bloque» en todos los documentos del proyecto: sin resultados.
- Reprogramaciones y fechas: records/PRY-203.json, compromisos de María Restrepo y Diana Molina; fuentes 30-reuniones/2026-09-06 a 2026-10-11 y 2026-10-18-notas-reunion.txt.
- Comité próximo 2026-11-01 y umbral de 3 reprogramaciones: .criterio/proyecto/PRY-203/config.json.
- Riesgo del proveedor: 2026-10-18-notas-reunion.txt.

### Lo que no sé
Los costos de las opciones, el tiempo de la firma, la causa de las reprogramaciones y si el 11-01 hay quórum. Nadie aquí tiene esa información en un documento, y no la inventé.

**No escala solo:** llevar esto al patrocinador o al comité es tuyo, Jorge Medina.
