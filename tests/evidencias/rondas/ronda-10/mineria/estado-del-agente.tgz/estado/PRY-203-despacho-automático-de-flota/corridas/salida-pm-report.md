# PRY-203 Despacho automático de flota — semana del 2026-10-12 al 2026-10-18

> Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18). Nadie respondió la pregunta de la declaración en esta corrida de prueba; el informe sale con esa línea en blanco, como corresponde.

**Declara el gerente (esta semana):** — sin declarar. No se pidió ni se propuso un estado.
**Última declaración en los documentos:** verde · 37 % · al 2026-10-10 (hace 8 días, dentro del umbral de 14) — `20-seguimiento/2026-10-10-informe-avance.md`
**Sustento documental:** contradicho. Hay `declared_vs_evidence`: la declaración «verde» no explica tres señales.
**Lo que el semáforo no explica:** `progress_vs_plan`, `commitment_overdue`, `commitment_rescheduled`.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: esta es la primera instantánea (`snapshots/2026-10-18.json`) y el diff devolvió 0 cambios. No puedo decir qué cambió desde la semana pasada; sí puedo decir cómo está hoy. Desde la próxima corrida el cuadro tendrá Estaba / Está.

Lo que entró al registro en la lectura de hoy (no es comparación, es lo recién visto):
- Compromiso sin fecha: Laura Vélez, «Mandar el ajuste del presupuesto» (`2026-10-18-notas-reunion.txt`).
- Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-18).
- Acta de recibo de «Ingeniería de detalle aprobada» fechada 2026-10-18.

## Lo que sigue igual y sigue mal
Sin corrida previa no se puede medir «desde cuándo» por comparación. Se dan los días contados desde la fecha de vencimiento o desde la fecha original:

| Qué | Desde | Días así |
|---|---|---|
| Natalia Ospina — Validar el ambiente 4 | vence 2026-10-02 | 16 |
| Elena Duarte — Actualizar la matriz 6 | vence 2026-10-06 | 12 |
| Elena Duarte — Validar el ambiente 20 | vence 2026-10-12 | 6 |
| María Restrepo — Aprobar el diseño 5 | vence 2026-10-13 | 5 |
| Avance declarado 37 % vs. 50–75 % que sostiene el plan | informe del 2026-10-10 | 8 (desde la declaración) |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-02-09 | 2027-02-09 | 0 días |
| Presupuesto | COP 4.200.000.000 | COP 4.200.000.000 | proyección COP 4.010.077.163 (−4,5 %) |

Replanificaciones: 0. Las dos columnas coinciden porque la línea base es única (v1, 2025-12-27) y no se ha movido.

Avance: declarado 37 %; el plan sostiene entre 50 % y 75 %; 2 de 4 hitos cumplidos; brecha de 13 puntos, por debajo del plan.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Licencia y permisos obtenidos | 2026-11-01 | 2026-11-01 | ninguna (pendiente; faltan 14 días) |

Hitos cumplidos, para contexto: «Ingeniería básica aprobada» (base 2026-04-15; acta de recibo del 2026-10-11) e «Ingeniería de detalle aprobada» (base 2026-07-24; acta de recibo del 2026-10-18). Las actas de recibo son posteriores a la fecha base; lo señalo sin juzgarlo, porque el cálculo no lo marca como hito sin evidencia.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 2.957.170.074 (70,4 %) | 2.066.157.295 (49,2 %) | 4.010.077.163 | 1.242.829.926 |

Cifras en COP, tomadas del informe de avance del 2026-10-10. Disponible real = aprobado − comprometido. El umbral de comprometido (90 %) no se cruza.

## Abierto
**Reprogramados:**
- María Restrepo, «Enviar el documento 1»: 6 veces (original 2026-10-02 → 10-14, 10-27, 11-11, 11-19, 12-05, 12-19). Supera el umbral de 3.
- Diana Molina, «Cerrar la prueba 2»: 4 veces (original 2026-09-29 → 10-09, 10-19, 10-31, 11-08). Supera el umbral de 3.

**Vencidos sin evidencia:** los cuatro de la tabla anterior (Ospina, Duarte ×2, Restrepo).
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto».
**RAID sin movimiento:** «Ventana de parada de planta definida por operaciones» no tiene probabilidad, impacto, dueño, fecha ni último movimiento. El riesgo del proveedor se movió hoy pero también carece de dueño, valoración y fecha.
**Proveedor:** no hay proveedores registrados en la ficha (`vendors` sin dato).

## Lo que necesito de alguien
- **Jorge Medina (gerente):** declarar estado y avance de esta semana, a la vista de las señales de arriba.
- **María Restrepo:** fecha firme para «Enviar el documento 1» y respuesta sobre «Aprobar el diseño 5».
- **Diana Molina:** fecha firme o motivo de fondo para «Cerrar la prueba 2».
- **Natalia Ospina y Elena Duarte:** evidencia o nueva fecha de sus tres compromisos vencidos.
- **Laura Vélez:** fecha para el ajuste del presupuesto.
- **Registrar el riesgo del proveedor** con dueño, probabilidad e impacto.
- **Material de comité:** los dos compromisos reprogramados por encima del umbral son punto de comité (próximo: 2026-11-01).

## Lo que no se sabe
**Sin dato:** autoridad (`identity.authority`), fase (`identity.phase`) y proveedores (`vendors`). La falta de autoridad impide saber quién decide lo que excede al gerente.
**Silencio:** último documento hace 0 días (2026-10-18) · última reunión hace 0 días (2026-10-18). El proyecto no está en silencio.
Además, en el cálculo 0 fuentes están marcadas como evidencia, 2 como declaración y 146 sin marcar.

---
*Pie:* ficha `records/PRY-203.json`, actualizada el 2026-10-18; corte al 2026-10-18; 3 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
