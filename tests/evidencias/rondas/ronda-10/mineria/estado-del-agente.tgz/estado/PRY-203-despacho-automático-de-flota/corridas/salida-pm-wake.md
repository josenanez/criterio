## PRY-203 Despacho automático de flota · 2026-10-18

**Revisé:** 15 documentos · 15 nuevos para el índice (primer barrido; ninguno cambió después) · 1 minuta nueva (2026-10-18-notas-reunion.txt), ya extraída en la ficha

### Lo que se venció solo
Sin corrida anterior del reloj, comparo contra la ficha de hoy. Vencidos sin evidencia:
- Natalia Ospina · Validar el ambiente 4 · 2026-10-02 (16 días). Dijo «ya lo entregué» el 2026-09-13; no hay acta de recibo.
- Elena Duarte · Actualizar la matriz 6 · 2026-10-06 (12 días).
- Elena Duarte · Validar el ambiente 20 · 2026-10-12 (6 días).
- María Restrepo · Aprobar el diseño 5 · 2026-10-13 (5 días). Dijo «ya lo entregué» el 2026-10-04; no hay acta.

Vencen hoy sin evidencia en el expediente: Paula Céspedes (Revisar el anexo 3), Carlos Peña (Cerrar la prueba 10), Javier Hoyos (Cerrar la prueba 18).

Reprogramados que cruzaron el umbral de 3: María Restrepo · Enviar el documento 1 (6 veces; ahora 2026-12-19, fuente: 2026-10-18-notas-reunion.txt) y Diana Molina · Cerrar la prueba 2 (4 veces; ahora 2026-11-08).

Sin fecha: Laura Vélez · Mandar el ajuste del presupuesto («la otra semana»).

Hitos: sin hitos vencidos sin evidencia; «Licencia y permisos obtenidos» vence el 2026-11-01.

Riesgo no registrado: en las notas de hoy se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; quedó en la ficha, sin dueño ni probabilidad.

### La reunión
Próximo comité el 2026-11-01, en 14 días; el informe toca el 2026-10-31. Todavía no toca `/pm-agenda` ni `/pm-report`. La reunión de hoy tiene notas y su minuta ya está extraída; no hay acta pendiente.

### Tu ficha publicada
Al día: se publicó hoy con corte al 2026-10-18 y la ficha no cambió desde entonces.

**Vuelvo el 2026-10-19.**
