Publiqué la ficha en `/home/claude/banco/ronda-10/mineria/espacio/documentos/proyectos/PRY-203-despacho-automático-de-flota/00-gobierno/ficha-pm.json`, con corte al 2026-10-18.

**Lleva:** 18 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`; además `vendors` sin datos) · declara **verde** al 2026-10-10 (informe de avance, 8 días de antigüedad)

**Lo más viejo que va ahí:** la identidad, el alcance, el presupuesto aprobado y las fechas de plan, del 2025-12-27 (acta de constitución y cronograma v1), unos 10 meses; no pasa de un año.

**Fecha de cierre:** `plan.end_date` es 2027-02-09, del cronograma v1. No hay un cronograma más nuevo en `10-plan/`, así que la fecha vigente y la de la línea base coinciden. No hay desfase contra el acta.

**Antes de que la PMO lo lea, ten presente:** el estado declarado es verde y el cálculo de hoy lo contradice con tres señales: avance declarado 37 % frente a 50–75 % que sustenta el plan (2 de 4 hitos cumplidos), 4 compromisos vencidos sin evidencia y 2 compromisos reprogramados 4 y 6 veces. Es tu declaración y la ficha la marca como declarada; no la cambié.

**Ocho campos que Vera contrastará:** sponsor (Felipe Arango), manager (Jorge Medina), committee (Comité de Seguridad), product (despacho de flota), end_date (2027-02-09), approved (COP 4.200.000.000), status (verde) y as_of (2026-10-10), todos con cita.

Esta corrida no avisa a nadie: Vera la encontrará en su próximo barrido.
