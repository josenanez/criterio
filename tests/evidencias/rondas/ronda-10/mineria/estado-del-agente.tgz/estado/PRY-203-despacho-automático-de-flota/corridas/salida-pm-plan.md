# Plan — PRY-203 Despacho automático de flota · borrador del 2026-10-18
**Desde:** acta de constitución del 2025-12-27 (`00-gobierno/2025-12-27-acta-constitucion.md`) · **Criterio de éxito:** «Despacho automático de flota en producción y medido» (acta, sección Criterio de éxito). No dice cuánto, medido contra qué, ni quién lo mide.

Nota de contexto: el proyecto no está en arranque. El acta tiene 10 meses, hay un cronograma v1 (2025-12-27) y el informe del 2026-10-10 reporta 37 %. Este borrador es una reconstrucción de la WBS desde el acta, no un plan nuevo. No crea línea base: ya existe la v1.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| Alcance real: «Componente 1, 2, 3» y «Fuera de alcance: lo que otro proyecto cubre» son texto de plantilla | No se puede derivar una WBS del alcance. Los entregables de abajo salen del cronograma v1, no del acta. |
| Autoridad del gerente no declarada | No se sabe qué puede decidir quien planifica (reprogramar, mover presupuesto) y qué hay que subir. |
| Dependencias: «Ninguna declarada» | El orden de abajo es solo lógica del trabajo. La licencia y permisos y la ventana de parada de planta (informe 10-10) dependen de terceros que el acta no nombra. |
| Criterio de éxito sin umbral ni método de medición | «Medido» no tiene indicador ni meta; el entregable final no se puede aceptar contra nada. |
| Patrocinador: sí está (Felipe Arango). Comité: Comité de Seguridad (para un proyecto de Finanzas, cuyo objetivo no es de seguridad; el acta no explica la razón) | Las excepciones tienen a quién llegar, pero no está claro si ese comité es el foro correcto. |

Se sigue marcándolo; ningún hueco se rellenó.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | Sin definir (el acta de recibo del 2026-10-11 firma «Recibido por: Jorge Medina»; no dice quién aprueba) | Del cronograma v1 (no del acta); recibido según acta del 2026-10-11 | Vacía |
| 2 | Ingeniería de detalle aprobada | Sin definir (igual: acta de recibo del 2026-10-18, Jorge Medina) | Del cronograma v1; recibido según acta del 2026-10-18 | Vacía |
| 3 | Licencia y permisos obtenidos | Sin definir | Del cronograma v1 (en curso, fecha 2026-11-01) | Vacía |
| 4 | Montaje e instalación | Sin definir | Del cronograma v1 (en curso, fecha 2027-02-09) | Vacía |
| 5 | Despacho automático en producción y medido | Sin definir (el acta nombra al patrocinador, no dice que acepte) | Del acta (criterio de éxito); no figura como hito en el cronograma v1 | Vacía |
| 6 | Plan de arranque de equipos acordado con operaciones | Sin definir | Supuesto: sale del informe 2026-10-10 («se acordó con operaciones el plan de arranque»), no del acta ni del cronograma | Vacía |
| 7 | Ensayo de disponibilidad de equipos | Sin definir | Supuesto: informe 2026-10-10 («no alcanzó lo pactado y se repite»); no hay umbral pactado a la vista | Vacía |

Los nodos 1 a 4 son hitos del cronograma, no necesariamente entregables aceptables; falta confirmar qué recibe y acepta alguien en cada uno. Los compromisos de comité («Enviar el documento 1», «Cerrar la prueba 2», …) no se vincularon a ningún nodo: sus nombres no permiten saber de qué entregable son parte, y asignarlos sería inventar.

## Orden
- 1 → 2 (detalle sobre básica): consistente con el cronograma v1.
- 3 (licencia y permisos) y 4 (montaje): el cronograma los muestra en curso a la vez; el acta no declara si el montaje necesita la licencia. Sin definir.
- 7 (ensayo) antes de 5 (producción): supuesto; el informe no lo dice así.
- 6 (plan de arranque) antes de 4 y 5: supuesto.
- 5 al final, por definición del criterio de éxito.
Sin fechas.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son la totalidad de los entregables del proyecto | Hay trabajo fuera del plan (el acta no lo desmiente ni lo confirma). |
| El plan de arranque y el ensayo de disponibilidad son entregables propios | Si son parte del montaje, las filas 6 y 7 sobran; si no, faltan hitos en la línea base. |
| El montaje depende de la licencia y permisos | Si no depende, hay holgura que el plan no usa; si depende, y la licencia vence el 2026-11-01, el montaje (2027-02-09) queda sin margen. |
| El proveedor llega con el equipo completo a la siguiente fase | Las notas del 2026-10-18 dicen que podría no llegar y que nadie lo registró como riesgo. Es un supuesto que falla y hoy no está en el RAID. |

Al aprobarse el plan, pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Alcance real (los tres componentes) | Sin definir; el acta lo firma el patrocinador (Felipe Arango) |
| Quién acepta cada entregable | Sin definir; no lo dice ningún documento |
| Autoridad del gerente al planificar | Sin definir |
| Meta e indicador de «medido» | Sin definir |
| Dependencias externas (licencia, parada de planta, proveedor) | Sin definir |
| Por qué un proyecto de Finanzas lo gobierna el Comité de Seguridad | Sin definir |

## Proyectos análogos
La configuración no apunta a una carpeta de fichas de la PMO, y en el estado de este proyecto solo existe su propia ficha. No hay proyectos análogos a la vista. No se estima por analogía.

Dato del propio proyecto, no análogo: el cronograma v1 da «Ingeniería básica aprobada» y «Ingeniería de detalle aprobada» como cerradas el 2026-04-15 y el 2026-07-24 (fecha vigente igual a la línea base), pero sus actas de recibo están fechadas el 2026-10-11 y el 2026-10-18. Es una discrepancia entre documentos, que no se resuelve aquí; sirve para la pregunta 1 de abajo.

## Preguntas para el equipo
1. Ingeniería básica y de detalle: el cronograma las da por cerradas en abril y julio, y las actas de recibo son de octubre. ¿Qué fecha es la real y por qué la vigente no cambió?
2. ¿Cuánto toma la licencia y permisos obtenidos, y quién es la autoridad que la emite?
3. ¿Cuánto toma el montaje e instalación, y qué necesita para empezar?
4. ¿Cuánto toma repetir el ensayo de disponibilidad y qué umbral hay que alcanzar?
5. ¿Cuánto toma el plan de arranque y cuándo es la ventana de parada de planta?
6. ¿Cuánto toma pasar a producción y medir, y qué indicador y meta cuentan como «medido»?
7. ¿Qué cubren los componentes 1, 2 y 3 del alcance?
8. ¿Quién acepta cada entregable?
9. ¿Con qué equipo llega el proveedor a la siguiente fase y quién responde si no llega completo?

## Para comprometer una fecha falta
- Disponibilidad real del equipo: no está en ningún documento (hay 11 asistentes al comité y 19 compromisos abiertos; no hay asignación de tiempo).
- Fecha y capacidad del proveedor para la siguiente fase (la revisión con el proveedor está para el 2026-10-28, según las notas del 2026-10-18).
- Ventana de la parada de planta: el informe del 2026-10-10 dice que se reprogramó y no da la nueva fecha.
- Fecha de la licencia y permisos: el cronograma dice 2026-11-01 y sigue en curso.
- Ajuste de presupuesto: Laura Vélez quedó de enviarlo «la otra semana» (notas del 2026-10-18). Hay 4.200.000.000 COP aprobados, 2.957.170.074 comprometidos y proyección de cierre 4.010.077.163 (informe 10-10); esa proyección no se contrastó aquí.

Esta es una estructura, no un compromiso: la fecha es decisión de Jorge Medina.
