# Corrida del 2026-10-18 · pm-commitments

1 proyectos · 28 s · 9 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `commitment_undated` | 1 |
| `declared_vs_evidence` | 1 |

María Restrepo (documento 1, 6 reprogramaciones) y Diana Molina (prueba 2, 4); 4 vencidos sin evidencia; 1 sin fecha (Laura Vélez)

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-203 Despacho automático de flota · al 2026-10-18

24 compromisos abiertos de 26 registrados: 4 vencidos sin evidencia, 2 reprogramados 3 veces o más, 1 sin fecha, 2 cerrados con documento.

### Se viene reprogramando

> **María Restrepo** · Enviar el documento 1
> Prometido para el 2026-10-02, y antes para el 10-14, el 10-27, el 11-11, el 11-19, el 12-05 y ahora el **2026-12-19**. **Seis reprogramaciones** (la última, el 2026-10-18); la fecha vigente se corrió 78 días contra la primera promesa.
> Fuentes: 30-reuniones/2026-09-06-comite-semanal.md (promesa) y 2026-10-18-notas-reunion.txt (última fecha).
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Diana Molina** · Cerrar la prueba 2
> Prometido para el 2026-09-29 (el 09-06 se dijo «por definir»), y antes para el 10-09, el 10-19, el 10-31 y ahora el **2026-11-08**. **Cuatro reprogramaciones**, la última el 2026-10-11.
> Fuentes: 30-reuniones/2026-09-06-comite-semanal.md y 30-reuniones/2026-10-11-comite-semanal.md.
> **Cuatro veces tampoco es seguimiento: es un bloqueo sin nombre.**

### Vencidos sin evidencia

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Natalia Ospina | Validar el ambiente 4 | 2026-10-02 | 16 días |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 | 12 días |
| Elena Duarte | Validar el ambiente 20 | 2026-10-12 | 6 días |
| María Restrepo | Aprobar el diseño 5 | 2026-10-13 | 5 días |

Dos de ellos tienen una versión de «ya lo entregué» sin documento:
- Natalia Ospina dijo el 2026-09-13 que ya había validado el ambiente 4; no hay acta de recibo en el expediente.
- María Restrepo dijo el 2026-10-04 que ya había entregado el diseño 5; no hay acta de recibo y desapareció de la tabla de las minutas siguientes.

Siguen abiertos hasta que haya documento.

Además, Laura Vélez dijo el 2026-10-11 que ya entregó «Revisar el anexo 11» (vigente al 2026-10-31); sin acta, sigue abierto, aunque aún no está vencido.

### Vencen esta semana
Con fecha entre el 2026-10-18 (hoy) y el 2026-10-25:

| Quién | Qué | Para cuándo |
|---|---|---|
| Paula Céspedes | Revisar el anexo 3 (reprogramado 1 vez) | 2026-10-18 (hoy) |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 (hoy) |
| Javier Hoyos | Cerrar la prueba 18 (reprogramado 1 vez) | 2026-10-18 (hoy) |
| Carlos Peña | Revisar el anexo 19 | 2026-10-19 |
| Óscar Ramírez | Actualizar la matriz 14 | 2026-10-21 |
| Óscar Ramírez | Confirmar la fecha 23 | 2026-10-21 |
| Laura Vélez | Actualizar la matriz 22 | 2026-10-22 |
| Carlos Peña | Confirmar la fecha 7 | 2026-10-24 |
| Carlos Peña | Enviar el documento 9 (reprogramado 1 vez) | 2026-10-24 |

Carlos Peña concentra 4 de los 9. Los tres de hoy vencen mañana sin evidencia si nadie la presenta.

### Sin fecha

| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; nadie dijo una fecha) | 2026-10-18 |

No puede estar vencido, y por eso se cuenta aparte.

### Cerrados desde la última revisión
- María Restrepo · Validar el ambiente 12 — cerrado con 20-seguimiento/2026-09-27-acta-recibo-12.md.
- Carlos Peña · Aprobar el diseño 13 — cerrado con 20-seguimiento/2026-10-04-acta-recibo-13.md.

### Contexto
El informe de avance del 2026-10-10 declara el proyecto en **verde**. Contra eso, el cálculo encuentra 4 compromisos vencidos, 2 reprogramados en serie y un avance declarado de 37 % que el plan sustenta entre 50 % y 75 % (2 de 4 hitos cumplidos): una desviación de 13 puntos.

### Qué sigue
Hay dos compromisos reprogramados tres veces o más (María Restrepo, 6; Diana Molina, 4). Ofrezco formularlos como decisión para el comité del 2026-11-01: qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente, y en la ficha la autoridad del proyecto no aparece en ningún documento. Y como cambiaron cosas respecto de la ficha publicada, ofrezco `/pm-publish` para que la PMO lo vea.

Este comando no le escribe a nadie ni juzga por qué no se cumplió: perseguirlo es del gerente, Jorge Medina.
