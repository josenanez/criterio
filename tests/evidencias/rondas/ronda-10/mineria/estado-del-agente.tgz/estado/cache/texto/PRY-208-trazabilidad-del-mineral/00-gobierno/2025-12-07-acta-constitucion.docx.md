<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2025-12-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Tecnología

Patrocinador: Jorge Medina

Gerente de proyecto: Ricardo Salas

Comité: Comité de Tecnología

Producto asociado: trazabilidad

Fecha de aprobación: 2025-12-07

Objetivo del negocio

Entregar trazabilidad del mineral para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Tecnología el 2025-12-07.

Fechas comprometidas

Fecha

Inicio

2025-12-17

Cierre

2027-01-27

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
