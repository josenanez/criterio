<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2025-12-16-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-03-14 | 2026-03-14 | cerrado
Ingeniería de detalle aprobada | 2026-06-01 | 2026-06-01 | cerrado
Licencia y permisos obtenidos | 2026-08-19 | 2026-08-19 | cerrado
Montaje e instalación | 2026-11-05 | 2026-11-05 | en curso
