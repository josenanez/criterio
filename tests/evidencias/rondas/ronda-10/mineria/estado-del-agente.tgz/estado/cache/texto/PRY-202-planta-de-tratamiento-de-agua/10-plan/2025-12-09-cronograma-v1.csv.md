<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2025-12-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-02-19,2026-02-19,cerrado
Ingeniería de detalle aprobada,2026-04-23,2026-04-23,cerrado
Licencia y permisos obtenidos,2026-06-25,2026-06-25,cerrado
Montaje e instalación,2026-08-27,2026-08-27,cerrado
