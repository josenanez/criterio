<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-05-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-03,2026-07-03,cerrado
Ingeniería de detalle aprobada,2026-08-25,2026-08-25,cerrado
Licencia y permisos obtenidos,2026-10-18,2026-10-18,en curso
Montaje e instalación,2026-12-10,2026-12-10,en curso
Pruebas en operación,2027-02-02,2027-02-02,en curso
