<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2025-12-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-03-08 | 2026-03-08 | cerrado
Ingeniería de detalle aprobada | 2026-05-28 | 2026-05-28 | cerrado
Licencia y permisos obtenidos | 2026-08-17 | 2026-08-17 | cerrado
Montaje e instalación | 2026-11-07 | 2026-11-07 | en curso
Pruebas en operación | 2027-01-27 | 2027-01-27 | en curso
