<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2026-04-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-08-13,2026-08-13,cerrado
Ingeniería de detalle aprobada,2026-11-24,2026-11-24,en curso
Licencia y permisos obtenidos,2027-03-08,2027-03-08,en curso
Montaje e instalación,2027-06-19,2027-06-19,en curso
