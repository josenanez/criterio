<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Planta de tratamiento de agua

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **84%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se actualizó el presupuesto de la obra con el área de compras
- Se acordó con operaciones el plan de arranque de los equipos

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.633.608.660 |
| Ejecutado | 1.308.832.360 |
| Proyección al cierre | 2.358.092.650 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
