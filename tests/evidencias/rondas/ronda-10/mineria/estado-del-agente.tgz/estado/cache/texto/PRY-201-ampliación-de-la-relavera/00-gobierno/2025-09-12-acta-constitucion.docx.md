<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2025-09-12-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Geología

Patrocinador: Natalia Ospina

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2025-09-12

Objetivo del negocio

Entregar ampliación de la relavera para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Seguridad el 2025-09-12.

Fechas comprometidas

Fecha

Inicio

2025-09-22

Cierre

2026-12-15

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
