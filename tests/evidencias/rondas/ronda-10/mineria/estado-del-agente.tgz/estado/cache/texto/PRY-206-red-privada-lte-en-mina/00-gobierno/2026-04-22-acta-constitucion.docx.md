<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2026-04-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Mina

Patrocinador: Felipe Arango

Gerente de proyecto: Jorge Medina

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2026-04-22

Objetivo del negocio

Entregar red privada lte en mina para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Tecnología el 2026-04-22.

Fechas comprometidas

Fecha

Inicio

2026-05-02

Cierre

2027-06-19

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
