<!-- origen: PRY-204-monitoreo-de-taludes/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Monitoreo de taludes

**Fecha:** 2026-10-17
**Asistentes:** Elena Duarte, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 16 | 2026-11-02 |
