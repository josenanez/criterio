<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2025-09-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-12-20 | 2025-12-20 | cerrado
Ingeniería de detalle aprobada | 2026-03-20 | 2026-03-20 | cerrado
Licencia y permisos obtenidos | 2026-06-18 | 2026-06-18 | cerrado
Montaje e instalación | 2026-09-16 | 2026-09-16 | cerrado
Pruebas en operación | 2026-12-15 | 2026-12-15 | en curso
