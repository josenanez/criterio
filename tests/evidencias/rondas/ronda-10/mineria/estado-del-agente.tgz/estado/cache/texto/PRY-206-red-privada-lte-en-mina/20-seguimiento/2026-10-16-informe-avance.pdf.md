<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-16
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 32%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se acordó con operaciones el plan de arranque de los equipos
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.083.188.211
Ejecutado 1.620.925.113
Proyección al cierre 4.296.957.949

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
