<!-- origen: PRY-208-trazabilidad-del-mineral/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Trazabilidad del mineral

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 10 | 2026-10-19 |
