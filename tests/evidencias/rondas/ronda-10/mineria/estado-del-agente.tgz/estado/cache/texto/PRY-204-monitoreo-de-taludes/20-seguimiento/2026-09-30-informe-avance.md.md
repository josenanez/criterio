<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-09-30-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-09-30
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **31%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 12.758.477.836 |
| Ejecutado | 6.516.713.704 |
| Proyección al cierre | 18.754.541.341 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Ventana de parada de planta definida por operaciones
