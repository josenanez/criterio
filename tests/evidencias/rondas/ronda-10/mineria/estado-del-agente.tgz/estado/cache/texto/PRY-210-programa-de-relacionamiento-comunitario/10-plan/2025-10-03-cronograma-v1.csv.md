<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2025-10-03-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-01-01,2026-01-01,cerrado
Ingeniería de detalle aprobada,2026-03-22,2026-03-22,cerrado
Licencia y permisos obtenidos,2026-06-10,2026-06-10,cerrado
Montaje e instalación,2026-08-29,2026-08-29,cerrado
