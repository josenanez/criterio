<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 69%

Lo que pasó en el periodo
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.439.525.833
Ejecutado 1.363.991.303
Proyección al cierre 6.597.389.844

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Bloqueo de la vía de acceso a la mina
