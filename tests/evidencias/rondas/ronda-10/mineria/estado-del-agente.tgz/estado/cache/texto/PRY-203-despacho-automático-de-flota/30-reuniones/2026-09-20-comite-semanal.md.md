<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-09-20-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-09-20
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-27 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-09 |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-15 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-06 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 7 | por definir |
| Sandra Gil | Entregar el punto 8 | 2026-10-03 |
| Carlos Peña | Enviar el documento 9 | 2026-10-17 |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 |
| Laura Vélez | Revisar el anexo 11 | 2026-09-24 |
| María Restrepo | Validar el ambiente 12 | 2026-10-16 |
