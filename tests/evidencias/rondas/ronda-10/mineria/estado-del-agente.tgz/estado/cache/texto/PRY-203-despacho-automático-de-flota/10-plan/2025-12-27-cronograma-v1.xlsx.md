<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2025-12-27-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-04-15 | 2026-04-15 | cerrado
Ingeniería de detalle aprobada | 2026-07-24 | 2026-07-24 | cerrado
Licencia y permisos obtenidos | 2026-11-01 | 2026-11-01 | en curso
Montaje e instalación | 2027-02-09 | 2027-02-09 | en curso
