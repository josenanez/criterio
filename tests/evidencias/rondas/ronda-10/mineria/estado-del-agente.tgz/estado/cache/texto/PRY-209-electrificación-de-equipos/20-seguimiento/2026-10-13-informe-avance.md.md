<!-- origen: PRY-209-electrificación-de-equipos/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-13
**Gerente:** Felipe Arango

## Estado declarado

**Verde**

Avance reportado: **42%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se acordó con operaciones el plan de arranque de los equipos

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 5.669.206.680 |
| Ejecutado | 9.952.505.540 |
| Proyección al cierre | 17.896.433.934 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio en la licencia ambiental que puede mover el alcance
