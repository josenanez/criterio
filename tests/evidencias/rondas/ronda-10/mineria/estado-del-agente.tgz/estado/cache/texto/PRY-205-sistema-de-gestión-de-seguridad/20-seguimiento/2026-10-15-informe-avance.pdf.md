<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Sistema de gestión de seguridad
Código: PRY-205
Fecha de corte: 2026-10-15
Gerente: Sandra Gil

Estado declarado
Rojo
Avance reportado: 34%

Lo que pasó en el periodo
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.648.414.321
Ejecutado 1.211.699.567
Proyección al cierre 5.095.962.103

Riesgos abiertos
- Concentración del conocimiento en una sola persona
