<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/2025-07-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de seguridad

Código: PRY-205

Área dueña: Medio Ambiente

Patrocinador: Laura Vélez

Gerente de proyecto: Sandra Gil

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2025-07-11

Objetivo del negocio

Entregar sistema de gestión de seguridad para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Seguridad el 2025-07-11.

Fechas comprometidas

Fecha

Inicio

2025-07-21

Cierre

2026-07-26

Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

Dependencias declaradas

• Ninguna declarada
