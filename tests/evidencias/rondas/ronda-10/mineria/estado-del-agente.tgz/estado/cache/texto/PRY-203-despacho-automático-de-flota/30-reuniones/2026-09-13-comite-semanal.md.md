<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-09-13-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-09-13
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Jorge Medina, María Restrepo, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-14 |
| Diana Molina | Cerrar la prueba 2 | 2026-09-29 |
| Paula Céspedes | Revisar el anexo 3 | 2026-09-15 |
| María Restrepo | Aprobar el diseño 5 | 2026-10-06 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 7 | por definir |
| Sandra Gil | Entregar el punto 8 | 2026-09-23 |

## Lo que se dijo

- Natalia Ospina dice que ya entregó «validar el ambiente 4». No se presentó acta.
