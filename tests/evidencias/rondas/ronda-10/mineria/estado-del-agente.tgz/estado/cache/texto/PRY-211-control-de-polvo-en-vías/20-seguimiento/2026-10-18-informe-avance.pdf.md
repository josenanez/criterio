<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Control de polvo en vías
Código: PRY-211
Fecha de corte: 2026-10-18
Gerente: Andrés Lozano

Estado declarado
Amarillo
Avance reportado: 39%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 7.152.487.669
Ejecutado 4.155.044.224
Proyección al cierre 9.308.969.517

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- El proveedor no ha confirmado la fecha de la última entrega
