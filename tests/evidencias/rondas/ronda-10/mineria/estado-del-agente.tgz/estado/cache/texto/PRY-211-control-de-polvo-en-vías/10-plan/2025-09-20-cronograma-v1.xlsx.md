<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2025-09-20-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-01-09 | 2026-01-09 | cerrado
Ingeniería de detalle aprobada | 2026-04-20 | 2026-04-20 | cerrado
Licencia y permisos obtenidos | 2026-07-30 | 2026-07-30 | cerrado
Montaje e instalación | 2026-11-09 | 2026-11-09 | en curso
Pruebas en operación | 2027-02-18 | 2027-02-18 | en curso
