<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2026-04-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Logística
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Operaciones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar electrificación de equipos para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Operaciones el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2027-02-19 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
