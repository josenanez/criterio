<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ampliación de la relavera
Código: PRY-201
Fecha de corte: 2026-10-08
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 48%

Lo que pasó en el periodo
- Se actualizó el presupuesto de la obra con el área de compras
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 11.971.394.314
Ejecutado 10.279.560.112
Proyección al cierre 18.496.508.384

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- El proveedor no ha confirmado la fecha de la última entrega
