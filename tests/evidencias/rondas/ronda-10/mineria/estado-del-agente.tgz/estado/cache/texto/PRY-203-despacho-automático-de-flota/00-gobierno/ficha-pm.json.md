<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-203",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "name": {
 "value": "Despacho automático de flota",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Finanzas",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "product": {
 "value": "despacho de flota",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found",
 "note": "no aparece en ningún documento"
 },
 "sponsor": {
 "value": "Felipe Arango",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "manager": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Seguridad",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found",
 "note": "no aparece en ningún documento"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-10-informe-avance.md",
 "source_date": "2026-10-10",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 37,
 "source": "20-seguimiento/2026-10-10-informe-avance.md",
 "source_date": "2026-10-10",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-10",
 "source": "20-seguimiento/2026-10-10-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-01-06",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "end_date": {
 "value": "2027-02-09",
 "source": "10-plan/2025-12-27-cronograma-v1.xlsx",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-12-27",
 "start_date": "2026-01-06",
 "end_date": "2027-02-09",
 "reason": "aprobación inicial del acta de constitución",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2026-04-15",
 "current_date": "2026-04-15",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-11-acta-recibo-ingeniería-básica-aprobada.pdf",
 "source": "10-plan/2025-12-27-cronograma-v1.xlsx"
 },
 {
 "name": "Ingeniería de detalle aprobada",
 "baseline_date": "2026-07-24",
 "current_date": "2026-07-24",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-18-acta-recibo-ingeniería-de-detalle-aprobada.pdf",
 "source": "10-plan/2025-12-27-cronograma-v1.xlsx"
 },
 {
 "name": "Licencia y permisos obtenidos",
 "baseline_date": "2026-11-01",
 "current_date": "2026-11-01",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-12-27-cronograma-v1.xlsx"
 },
 {
 "name": "Montaje e instalación",
 "baseline_date": "2027-02-09",
 "current_date": "2027-02-09",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2025-12-27-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "approved": {
 "value": 4200000000,
 "source": "00-gobierno/2025-12-27-acta-constitucion.md",
 "source_date": "2025-12-27",
 "state": "found"
 },
 "committed": {
 "value": 2957170074,
 "source": "20-seguimiento/2026-10-10-informe-avance.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "executed": {
 "value": 2066157295,
 "source": "20-seguimiento/2026-10-10-informe-avance.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "projection": {
 "value": 4010077163,
 "source": "20-seguimiento/2026-10-10-informe-avance.md",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Ventana de parada de planta definida por operaciones",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-10-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; se comentó en la reunión y nadie lo anotó como riesgo",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Enviar el documento 1"
 },
 "due_date": {
 "value": "2026-12-19"
 },
 "original_due_date": {
 "value": "2026-10-02"
 },
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-12-05",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 {
 "due_date": "2026-12-19",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina"
 },
 "what": {
 "value": "Cerrar la prueba 2"
 },
 "due_date": {
 "value": "2026-11-08"
 },
 "original_due_date": {
 "value": "2026-09-29"
 },
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ],
 "note": "el 2026-09-06 se prometió «por definir»; la primera fecha, 2026-09-29, se puso el 2026-09-13"
 },
 {
 "who": {
 "value": "Paula Céspedes"
 },
 "what": {
 "value": "Revisar el anexo 3"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-09-15"
 },
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Natalia Ospina"
 },
 "what": {
 "value": "Validar el ambiente 4"
 },
 "due_date": {
 "value": "2026-10-02"
 },
 "original_due_date": {
 "value": "2026-10-02"
 },
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "el 2026-09-13 dijo que ya lo entregó; no se presentó acta y no vuelve a aparecer en ninguna minuta"
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Aprobar el diseño 5"
 },
 "due_date": {
 "value": "2026-10-13"
 },
 "original_due_date": {
 "value": "2026-10-06"
 },
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ],
 "note": "el 2026-10-04 dijo que ya lo entregó; no se presentó acta y ya no figura en la tabla de ese día ni de las siguientes"
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Actualizar la matriz 6"
 },
 "due_date": {
 "value": "2026-10-06"
 },
 "original_due_date": {
 "value": "2026-10-06"
 },
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Confirmar la fecha 7"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": {
 "value": "2026-10-24"
 },
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«por definir» el 2026-09-13, 09-20 y 09-27; la primera fecha, 2026-10-24, se puso el 2026-10-04"
 },
 {
 "who": {
 "value": "Sandra Gil"
 },
 "what": {
 "value": "Entregar el punto 8"
 },
 "due_date": {
 "value": "2026-10-27"
 },
 "original_due_date": {
 "value": "2026-09-23"
 },
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-03",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Enviar el documento 9"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": {
 "value": "2026-10-17"
 },
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Cerrar la prueba 10"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-10-18"
 },
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Revisar el anexo 11"
 },
 "due_date": {
 "value": "2026-10-31"
 },
 "original_due_date": {
 "value": "2026-09-24"
 },
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ],
 "note": "el 2026-10-11 dijo que ya lo entregó; no se presentó acta y desaparece de la tabla"
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Validar el ambiente 12"
 },
 "due_date": {
 "value": "2026-10-16"
 },
 "original_due_date": {
 "value": "2026-10-16"
 },
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-27-acta-recibo-12.md"
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Aprobar el diseño 13"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-10-18"
 },
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-04-acta-recibo-13.md"
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Actualizar la matriz 14"
 },
 "due_date": {
 "value": "2026-10-21"
 },
 "original_due_date": {
 "value": "2026-10-21"
 },
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Confirmar la fecha 15"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-10"
 },
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Paula Céspedes"
 },
 "what": {
 "value": "Entregar el punto 16"
 },
 "due_date": {
 "value": "2026-10-26"
 },
 "original_due_date": {
 "value": "2026-10-26"
 },
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«por definir» el 2026-09-27 y 10-04; la primera fecha se puso el 2026-10-11"
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Enviar el documento 17"
 },
 "due_date": {
 "value": "2026-10-31"
 },
 "original_due_date": {
 "value": "2026-10-31"
 },
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«por definir» el 2026-10-04; la primera fecha se puso el 2026-10-11"
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Cerrar la prueba 18"
 },
 "due_date": {
 "value": "2026-10-18"
 },
 "original_due_date": {
 "value": "2026-10-09"
 },
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Revisar el anexo 19"
 },
 "due_date": {
 "value": "2026-10-19"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Validar el ambiente 20"
 },
 "due_date": {
 "value": "2026-10-12"
 },
 "original_due_date": {
 "value": "2026-10-12"
 },
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Aprobar el diseño 21"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": {
 "value": "2026-10-30"
 },
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Actualizar la matriz 22"
 },
 "due_date": {
 "value": "2026-10-22"
 },
 "original_due_date": {
 "value": "2026-10-22"
 },
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Confirmar la fecha 23"
 },
 "due_date": {
 "value": "2026-10-21"
 },
 "original_due_date": {
 "value": "2026-10-21"
 },
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Entregar el punto 24"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": {
 "value": "2026-10-30"
 },
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«la otra semana»: nadie dijo una fecha"
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisión con el proveedor"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-28"
 },
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-18",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors"
 ],
 "open_conflicts": [],
 "read_scope": "las 7 reuniones (2026-09-06 a 2026-10-18), las 4 actas de recibo, el informe, el cronograma y el acta de constitución"
 }
}
