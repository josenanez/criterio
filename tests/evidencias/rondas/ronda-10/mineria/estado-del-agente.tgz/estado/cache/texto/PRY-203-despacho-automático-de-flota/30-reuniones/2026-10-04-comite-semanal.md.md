<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-04-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Despacho automático de flota

**Fecha:** 2026-10-04
**Asistentes:** Carlos Peña, Diana Molina, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Paula Céspedes, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-19 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-31 |
| Paula Céspedes | Revisar el anexo 3 | 2026-10-18 |
| Elena Duarte | Actualizar la matriz 6 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 7 | 2026-10-24 |
| Sandra Gil | Entregar el punto 8 | 2026-10-03 |
| Carlos Peña | Enviar el documento 9 | 2026-10-24 |
| Carlos Peña | Cerrar la prueba 10 | 2026-10-18 |
| Laura Vélez | Revisar el anexo 11 | 2026-10-31 |
| Óscar Ramírez | Actualizar la matriz 14 | 2026-10-21 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-10 |
| Paula Céspedes | Entregar el punto 16 | por definir |
| Elena Duarte | Enviar el documento 17 | por definir |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-09 |
| Carlos Peña | Revisar el anexo 19 | 2026-10-19 |
| Elena Duarte | Validar el ambiente 20 | 2026-10-12 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Carlos Peña): recibido, acta de recibo del 2026-10-04.

## Lo que se dijo

- María Restrepo dice que ya entregó «aprobar el diseño 5». No se presentó acta.
