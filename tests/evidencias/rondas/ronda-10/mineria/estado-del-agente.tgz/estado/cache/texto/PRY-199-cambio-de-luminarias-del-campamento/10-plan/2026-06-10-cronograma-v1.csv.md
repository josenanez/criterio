<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/10-plan/2026-06-10-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-10-07,2026-10-07,cerrado
Ingeniería de detalle aprobada,2027-01-24,2027-01-24,en curso
Licencia y permisos obtenidos,2027-05-13,2027-05-13,en curso
Montaje e instalación,2027-08-30,2027-08-30,en curso
Pruebas en operación,2027-12-17,2027-12-17,en curso
