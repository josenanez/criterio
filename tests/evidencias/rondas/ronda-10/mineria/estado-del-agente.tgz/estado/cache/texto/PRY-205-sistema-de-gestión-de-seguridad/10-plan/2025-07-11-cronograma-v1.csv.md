<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-07-11-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-11-21,2025-11-21,cerrado
Ingeniería de detalle aprobada,2026-03-24,2026-03-24,cerrado
Licencia y permisos obtenidos,2026-07-26,2026-07-26,cerrado
