<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-12-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de camiones

Código: PRY-200

Área dueña: Finanzas

Patrocinador: Carlos Peña

Gerente de proyecto: Sandra Gil

Comité: Comité Ambiental

Producto asociado: monitoreo de flota

Fecha de aprobación: 2025-12-16

Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Finanzas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité Ambiental el 2025-12-16.

Fechas comprometidas

Fecha

Inicio

2025-12-26

Cierre

2026-11-05

Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

Dependencias declaradas

• Ninguna declarada
