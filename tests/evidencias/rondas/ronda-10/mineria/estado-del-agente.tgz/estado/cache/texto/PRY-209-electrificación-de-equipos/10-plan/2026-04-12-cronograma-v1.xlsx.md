<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2026-04-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-07-06 | 2026-07-06 | cerrado
Ingeniería de detalle aprobada | 2026-09-20 | 2026-09-20 | cerrado
Licencia y permisos obtenidos | 2026-12-05 | 2026-12-05 | en curso
Montaje e instalación | 2027-02-19 | 2027-02-19 | en curso
