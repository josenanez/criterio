# Caso de negocio — Permisos de trabajo digitales (PRD-308) · borrador del 2026-10-18
**Desde:** la definición de producto del 2025-10-01 y el caso de negocio de la misma fecha · **Cifras con fuente:** 1 de 1 afirmada (declarada); 0 medidas; costos: 0

**Términos:** vigentes (versión 0.5.0, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no hubo que registrarlos de nuevo.

> Este documento arma la estructura y la trazabilidad. No proyecta ingresos, no calcula retorno ni recuperación, y no recomienda aprobar ni rechazar. Con lo que hay en la carpeta, lo que existe hoy es **una propuesta, no un caso de negocio evaluable** (ver Costos).

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Supervisores no tiene permisos de trabajo digitales.» (`00-definicion/2025-10-01-definicion-producto.md`, El problema, 2025-10-01).
- **Para quién:** Supervisores (misma fuente, Segmento). El supuesto del caso habla de «Operaciones»; ningún documento dice si es el mismo grupo.
- **Sustento de la demanda:** una sola entrevista con un cliente sin nombre, 2025-09-27: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-27-entrevistas.md`). Una voz, sin rol, sin cifra, con 12 meses de antigüedad (umbral 12).
- **Propuesta:** la definición dice «Propuesta principal», que no describe nada.

## Qué se construye
Los 9 requerimientos decididos (aceptados) según el acta del Comité de producto del 2026-10-15 (`30-decisiones/2026-10-15-comite-producto.docx`). Los 3 propuestos (REQ-4801, 4804, 4810) no entran al caso hasta que se decidan.

| Requerimiento | Estado (desde) | Doliente | Criterio de aceptación | Evidencia de demanda |
|---|---|---|---|---|
| REQ-4800 | aceptado (2026-06-29) | Ricardo Salas | se verifica en producción | Cliente entrevistado (2025-09-27) |
| REQ-4802 | aceptado (2026-06-12) | Gustavo Neira | se verifica en producción | **ninguna: nadie lo pidió** |
| REQ-4803 | aceptado (2026-03-24) | María Restrepo | **falta** | **ninguna** |
| REQ-4805 | aceptado (2026-05-16) | Beatriz Cuéllar | **falta** | Cliente entrevistado (2025-09-27) |
| REQ-4806 | aceptado (2026-03-29) | Carlos Peña | **falta** | **ninguna** |
| REQ-4807 | aceptado (2026-07-10) | Gustavo Neira | se verifica en producción | Cliente entrevistado (2025-09-27) |
| REQ-4808 | aceptado (2026-05-11) | Elena Duarte | **falta** | Cliente entrevistado (2025-09-27) |
| REQ-4809 | aceptado (2026-06-19) | **sin asignar** | se verifica en producción | **ninguna** |
| REQ-4811 | aceptado (2026-08-05) | María Restrepo | se verifica en producción | Cliente entrevistado (2025-09-27) |

Los 5 con evidencia salen de **una misma entrevista**; el acta cuenta cinco pedidos, la fuente es una. Ninguno tiene proyecto que lo ejecute (columna «Proyecto que lo ejecuta» en «—»; la definición dice «Ninguno declarado»).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 98.890 | **Declarada** | Caso de negocio, «Cifras que sostienen el caso» (`00-definicion/2025-10-01-caso-de-negocio.md`), preparado por Javier Hoyos | 2025-10-01 |
| Retorno esperado | «en 24 meses» — **sin monto** | Declarada sin cifra | Caso de negocio, «Retorno esperado» | 2025-10-01 |
| Adopción por Operaciones | sin cifra (sin umbral de adopción) | **Supuesta** | Definición, Supuestos (declarado 2026-05-13) | 2026-05-13 |

- **Método de 98.890:** el caso da la cifra sin método ni base; no se puede reconstruir de dónde sale.
- **No hay ninguna cifra medida.** La carpeta de métricas no existe.
- Una cifra de fuente pública no se ha añadido: no se rellena con referencias del sector.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 98.890 (caso de negocio, 2025-10-01) | **No hay medición** | Sin serie, no hay brecha calculable (umbral 20 %). No es una contradicción: es una afirmación que nadie mide. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — (vacío 1) |
| Contratos o cotizaciones | No hay | — |
| Costo declarado del equipo | No hay | — |
| Operación / mantenimiento | No hay | — |

El costo de construir es el primer vacío. Sin él no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «Operaciones adopta la herramienta» (declarado 2026-05-13; 158 días sin verificar, umbral 30). El anexo del 2026-08-08 dice «se confirmó» con una «entrevista con doce clientes», pero esa entrevista no está en `10-descubrimiento` (la única es 2025-09-27, un cliente). Lo cuento como **no verificado**. | La cifra de 98.890 al mes y el retorno quedan sin base: ambos dependen de que se use. | Javier Hoyos (gerente de producto) aportando las notas de las doce entrevistas y un criterio de adopción que se pueda ver (cuántos, haciendo qué, en qué plazo). |
| Que «Supervisores» y «Operaciones» sean el mismo grupo | El volumen y la adopción se refieren a poblaciones distintas. | Javier Hoyos. |
| Que la demanda de 2025-09-27 siga vigente | Los 5 requerimientos con evidencia pierden sustento (ya cumplen 12 meses). | Una ronda nueva de entrevistas; la hace quien dirija el descubrimiento. |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y de operar) | Sin costo no hay caso, hay propuesta | Quien presupueste: el negocio / Javier Hoyos |
| Monto del retorno esperado | «Retorno esperado en 24 meses» no se puede medir ni contrastar sin cifra | El negocio (autor del caso: Javier Hoyos) |
| Método y base de 98.890 al mes | Una cifra sin método no se defiende en comité | Javier Hoyos |
| Serie medida de volumen_mensual | No hay contra qué contrastar la cifra declarada | El sistema donde el producto vive / quien mida |
| Criterio de éxito | Sin él el producto no se puede cerrar meses después | Comité de producto, nombrando persona |
| Alternativas consideradas y qué pasa si no se hace | El comité no puede comparar contra nada | Javier Hoyos |
| Qué es «el plan» que el comité del 2026-10-15 decidió mantener | No hay plan escrito | Javier Hoyos |
| Propuesta real (hoy «Propuesta principal») | El caso no dice qué se construye | Javier Hoyos |
| Quién decidió cada aceptación y cuándo | El acta del 2026-10-15 (un solo asistente) lista las 9 aceptaciones de marzo a agosto; no hay acta de cada fecha. Confirmar si existen actas anteriores fuera de la carpeta. | Comité de producto |
| Doliente de REQ-4809; criterio de aceptación de REQ-4803, 4805, 4806, 4808; quién pidió REQ-4802, 4803, 4806, 4809 | Se van a construir 4 cosas que nadie pidió | Doliente de cada una / Comité de producto |
| País y sector | Sin ellos no se puede hacer el barrido normativo (datos personales, firma y retención de permisos digitales) | Javier Hoyos |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento escribe un criterio de éxito, ni la métrica ni su fecha de corte. Lo único cercano es volumen_mensual = 98.890, sin plazo, y «retorno en 24 meses», sin monto; ninguno es un criterio verificable. Sin esto el producto no se puede cerrar meses después. Lo debe definir el Comité de producto.

## Si hay otros productos publicados
No hay otros productos publicados a la vista desde esta configuración; no se hizo el cruce de `/product-overlap`. Si se publican, hay que contrastar volumen_mensual para no sumar transacciones que otro caso también cuente.

## Lo que este documento deja fuera a propósito
No calculo ingresos, retorno ni periodo de recuperación, y no recomiendo aprobar o rechazar: con una cifra declarada sin método, un supuesto sin verificar y cero costos, cualquier número sería una opinión.

## Después
Ofrezco pasar los 3 supuestos de arriba al seguimiento (assumption-tracking), empezando por «Operaciones adopta la herramienta», que lleva 158 días sin verificarse. No ofrezco `/product-charter`: el caso no está cerrado (sin costo, sin criterio de éxito).
