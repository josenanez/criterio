# Corrida del 2026-10-18 · product-requirements

PRD-308 · 12 requerimientos · 23 s · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

4 aceptados sin evidencia (4802, 4803, 4806, 4809); 9 aceptados sin proyecto; 3 propuestos sin decidir; 1 sin doliente

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Registro — Permisos de trabajo digitales (PRD-308) · al 2026-10-18
12 requerimientos · 9 decididos · 55,6 % con evidencia · 0 % con proyecto que lo ejecuta

Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-18, versión 1.1); no se registraron de nuevo.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4802 | Requerimiento REQ-4802 | aceptado (2026-06-12) | Gustavo Neira |
| REQ-4803 | Requerimiento REQ-4803 | aceptado (2026-03-24) | María Restrepo |
| REQ-4806 | Requerimiento REQ-4806 | aceptado (2026-03-29) | Carlos Peña |
| REQ-4809 | Requerimiento REQ-4809 | aceptado (2026-06-19) | sin asignar |

Ninguno tiene una sola cita de quien lo pidió. Cierra el vacío quien lo doliera: el doliente aporta la fuente o el Comité de producto lo devuelve a propuesto.

### Decidido y nadie lo está construyendo
Los 9 aceptados (REQ-4800, 4802, 4803, 4805, 4806, 4807, 4808, 4809, 4811) no tienen proyecto que los ejecute: 0 % trazado. La columna «Proyecto que lo ejecuta» del acta del 2026-10-15 está en «—» para los 12. Quien lo cierra: Javier Hoyos (gerente de producto), con `/product-trace` y, para los que tengan evidencia y criterio, `/product-charter`.

| REQ | Decidido el |
|---|---|
| REQ-4803 | 2026-03-24 |
| REQ-4806 | 2026-03-29 |
| REQ-4808 | 2026-05-11 |
| REQ-4805 | 2026-05-16 |
| REQ-4802 | 2026-06-12 |
| REQ-4809 | 2026-06-19 |
| REQ-4800 | 2026-06-29 |
| REQ-4807 | 2026-07-10 |
| REQ-4811 | 2026-08-05 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4809 | Requerimiento REQ-4809 | «sin asignar» (aceptado el 2026-06-19) |

Quien lo cierra: el Comité de producto, nombrando una persona.

### Sin criterio de aceptación
Solo los decididos.
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4803 | Requerimiento REQ-4803 | aceptado | María Restrepo |
| REQ-4805 | Requerimiento REQ-4805 | aceptado | Beatriz Cuéllar |
| REQ-4806 | Requerimiento REQ-4806 | aceptado | Carlos Peña |
| REQ-4808 | Requerimiento REQ-4808 | aceptado | Elena Duarte |

(Los propuestos no se evalúan en este punto.)

### Decidido sin documento que lo respalde
El único documento de decisión es el acta del Comité de producto del 2026-10-15, con un solo asistente (Javier Hoyos) y la decisión «Se mantiene el plan». Las 9 aceptaciones son de fechas anteriores (2026-03-24 a 2026-08-05); el acta las lista, pero no hay un documento de la fecha en que se decidió cada una ni constancia de quién decidió. Es una observación sobre la forma del registro, no una señal calculada: confírmese si existen actas anteriores que no están en la carpeta.

### Lleva meses y nadie lo decide
Umbral: 60 días. Quién tiene la facultad: Comité de producto (según la configuración).
| REQ | Título | Propuesto hace | Doliente |
|---|---|---|---|
| REQ-4804 | Requerimiento REQ-4804 | 213 días (2026-03-19) | Jorge Medina |
| REQ-4801 | Requerimiento REQ-4801 | 120 días (2026-06-20) | Beatriz Cuéllar |
| REQ-4810 | Requerimiento REQ-4810 | 86 días (2026-07-24) | Natalia Ospina |

Se propone decidirlos (aceptar, descartar o pedir evidencia); no se cierran por viejos.

### Evidencia vieja
Umbral: 12 meses. Toda la evidencia del registro es una misma entrevista con un cliente, del 2025-09-27 («Lo necesito y hoy no lo tengo.», tema: Necesidad principal).
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4800, 4801, 4804, 4805, 4807, 4808, 4810, 4811 | 2025-09-27 | 12 meses |

### Además, de la definición
- Supuesto sin verificar hace 158 días: «Operaciones adopta la herramienta» (umbral 30 días).
- La cifra del caso de negocio (volumen_mensual 98.890, 2025-10-01) no tiene medición contra la cual contrastarla.
- La definición no declara criterio de éxito.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 9 | 0 | 0 | 0 |

Siguiente paso: `/product-trace` para los 9 decididos sin proyecto.
