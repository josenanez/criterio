# Corrida del 2026-10-18 · product-wake

PRD-308 · 12 requerimientos · 25 s · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Primera revisión, sin corte previo: se reportó la línea base (3 sin decidir, 1 supuesto sin verificar, evidencia de 12 meses). No pude confirmar trazas por falta de carpeta de fichas; éxito del producto y medición del volumen no están en ningún documento.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Permisos de trabajo digitales (PRD-308) · 2026-10-18

**Desde el corte anterior:** no hay corte anterior. Esta es la primera revisión (`last: null`), así que `crossed` no existe todavía y lo de abajo es la línea base, no novedad. El corte que se deja hoy es contra el que la próxima corrida dirá qué cruzó.

Términos: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que volver a registrarlos.

### Qué toca
Solo `review` (cada 30 días). No toca comité ni informe.

### Estado del registro (12 requerimientos: 9 aceptados, 3 propuestos)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4804 | 213 días (umbral 60) | Quién tiene la facultad de decidirlo; llevarlo al comité | Jorge Medina (doliente); decide: Comité de producto |
| Sin decidir | REQ-4801 | 120 días | ídem | Beatriz Cuéllar |
| Sin decidir | REQ-4810 | 86 días | ídem | Natalia Ospina |
| Supuesto sin verificar | "Operaciones adopta la herramienta" | 158 días (umbral 30) | La verificación citada (entrevista a doce clientes, 2026-08-08) no existe en 10-descubrimiento; la única entrevista es la de un cliente, 2025-09-27. Hace falta esa entrevista, o tratar el supuesto como riesgo | Javier Hoyos |
| Evidencia vencida | 8 requerimientos | 12 meses | Toda la evidencia es una entrevista de un cliente del 2025-09-27: la definición queda sin sustento vigente de demanda | Javier Hoyos |

Aceptados sin evidencia: REQ-4802, REQ-4803, REQ-4806, REQ-4809. Aceptados sin criterio de aceptación: REQ-4803, 4805, 4806, 4808. Sin doliente: REQ-4809. Aceptados que nadie construye (sin proyecto): los 9.

### Las trazas
Sin la carpeta de fichas de proyectos, ninguna traza se da por confirmada: 0 de 9 aceptados trazados. No se confirmó nada.

### Del descubrimiento
Sin documentos nuevos. La carpeta tiene los mismos 5 documentos que el caché de texto.

### Lo que no sé
- Éxito del producto: no está en ningún documento.
- Cifra declarada de volumen mensual (98.890): sin medición que la contraste.
- Quién decide: el acta nombra al comité, pero ningún documento dice quién tiene la facultad.

**Vuelvo el 2026-11-17.**
