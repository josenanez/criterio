<!-- origen: 00-definicion/2025-10-01-caso-de-negocio.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2025-10-01
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.890 | Caso de negocio, 2025-10-01 |

## Retorno esperado

Retorno esperado en 24 meses.
