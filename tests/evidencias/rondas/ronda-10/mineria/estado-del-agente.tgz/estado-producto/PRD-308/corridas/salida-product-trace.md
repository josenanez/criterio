## Trazabilidad — Permisos de trabajo digitales (PRD-308) · al 2026-10-18
9 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Ningún requerimiento tiene proyecto asignado: en el acta del comité del 2026-10-15 la columna «Proyecto que lo ejecuta» es «—» para los 12. Los 9 aceptados, con su fecha de decisión y su doliente según el registro:

| REQ | Título | Decidido el | Doliente |
|---|---|---|---|
| REQ-4803 | Requerimiento REQ-4803 | 2026-03-24 | María Restrepo |
| REQ-4806 | Requerimiento REQ-4806 | 2026-03-29 | Carlos Peña |
| REQ-4808 | Requerimiento REQ-4808 | 2026-05-11 | Elena Duarte |
| REQ-4805 | Requerimiento REQ-4805 | 2026-05-16 | Beatriz Cuéllar |
| REQ-4802 | Requerimiento REQ-4802 | 2026-06-12 | Gustavo Neira |
| REQ-4809 | Requerimiento REQ-4809 | 2026-06-19 | sin asignar |
| REQ-4800 | Requerimiento REQ-4800 | 2026-06-29 | Ricardo Salas |
| REQ-4807 | Requerimiento REQ-4807 | 2026-07-10 | Gustavo Neira |
| REQ-4811 | Requerimiento REQ-4811 | 2026-08-05 | María Restrepo |

Quién los decidió: el registro no lo dice; el acta del 2026-10-15 solo lista a Javier Hoyos como asistente. Esos mismos 9 llevan señal `requirement_untraced`.

### La traza no se confirma
Ninguna: no hay trazas que confirmar porque ningún requerimiento declara proyecto. No hay `trace_not_confirmed`.

### Lo que un proyecto construye y el registro no tiene
Ninguno detectado. Se revisaron las 13 fichas (PRY-199 a PRY-211): ninguna nombra PRD-308 ni «Permisos de trabajo digitales». Las que declaran producto apuntan a otros: PRY-199 → PRD-299; PRY-200 → monitoreo de flota; PRY-203 → despacho de flota; PRY-204 → alerta de taludes; PRY-207 → gemelo digital; PRY-208 → trazabilidad. Las otras 7 (PRY-201, 202, 205, 206, 209, 210, 211) tienen el campo producto vacío, y eso es un hallazgo del lado de esas fichas, no de este registro.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4800 | aceptado | 2026-06-29 | — | no | — |
| REQ-4801 | propuesto | — | — | no | — |
| REQ-4802 | aceptado | 2026-06-12 | — | no | — |
| REQ-4803 | aceptado | 2026-03-24 | — | no | — |
| REQ-4804 | propuesto | — | — | no | — |
| REQ-4805 | aceptado | 2026-05-16 | — | no | — |
| REQ-4806 | aceptado | 2026-03-29 | — | no | — |
| REQ-4807 | aceptado | 2026-07-10 | — | no | — |
| REQ-4808 | aceptado | 2026-05-11 | — | no | — |
| REQ-4809 | aceptado | 2026-06-19 | — | no | — |
| REQ-4810 | propuesto | — | — | no | — |
| REQ-4811 | aceptado | 2026-08-05 | — | no | — |

La cadena se rompe en el segundo eslabón: la decisión existe (acta del comité del 2026-10-15), pero ningún requerimiento apunta a un proyecto. Los 3 propuestos (REQ-4801, 4804, 4810) no están decididos, así que aún no cuentan como brecha de construcción.

### Sin fichas a la vista
Hay fichas de 13 proyectos y se leyeron todas. Como ningún requerimiento declara proyecto, no había traza que confirmar contra ellas.

**Siguiente paso:** hay 9 decididos sin proyecto. `/product-charter` sirve para el que ya esté listo para serlo; REQ-4800, 4807 y 4811 son los de decisión más reciente con aceptación y evidencia.
