# Corrida del 2026-10-18 · product-setup

PRD-308 · 12 requerimientos · 25 s · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

0 preguntas a la persona (4 respuestas por defecto, sesión sin interfaz); minutos hasta el primer resultado: sin medir; 5 documentos, 12 requerimientos, 0 con proyecto; sin criterio de éxito, sin serie medida, supuesto con verificación citada que no existe en la carpeta

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

> El comando no entregó su resultado (`--salida`): la corrida registra las cifras, pero lo que dijo se quedó en la conversación.
