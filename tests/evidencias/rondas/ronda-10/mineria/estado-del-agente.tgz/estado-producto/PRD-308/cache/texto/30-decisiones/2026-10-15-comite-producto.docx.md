<!-- origen: 30-decisiones/2026-10-15-comite-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de producto · Permisos de trabajo digitales

Fecha: 2026-10-15

Asistentes: Javier Hoyos

Requerimientos revisados

ID

Requerimiento

Doliente

Criterio de aceptación

Quién lo pidió

Estado

Desde

Proyecto que lo ejecuta

REQ-4800

Requerimiento REQ-4800

Ricardo Salas

se verifica en producción

Cliente entrevistado

aceptado

2026-06-29

—

REQ-4801

Requerimiento REQ-4801

Beatriz Cuéllar

se verifica en producción

Cliente entrevistado

propuesto

2026-06-20

—

REQ-4802

Requerimiento REQ-4802

Gustavo Neira

se verifica en producción

—

aceptado

2026-06-12

—

REQ-4803

Requerimiento REQ-4803

María Restrepo

—

—

aceptado

2026-03-24

—

REQ-4804

Requerimiento REQ-4804

Jorge Medina

se verifica en producción

Cliente entrevistado

propuesto

2026-03-19

—

REQ-4805

Requerimiento REQ-4805

Beatriz Cuéllar

—

Cliente entrevistado

aceptado

2026-05-16

—

REQ-4806

Requerimiento REQ-4806

Carlos Peña

—

—

aceptado

2026-03-29

—

REQ-4807

Requerimiento REQ-4807

Gustavo Neira

se verifica en producción

Cliente entrevistado

aceptado

2026-07-10

—

REQ-4808

Requerimiento REQ-4808

Elena Duarte

—

Cliente entrevistado

aceptado

2026-05-11

—

REQ-4809

Requerimiento REQ-4809

sin asignar

se verifica en producción

—

aceptado

2026-06-19

—

REQ-4810

Requerimiento REQ-4810

Natalia Ospina

se verifica en producción

Cliente entrevistado

propuesto

2026-07-24

—

REQ-4811

Requerimiento REQ-4811

María Restrepo

se verifica en producción

Cliente entrevistado

aceptado

2026-08-05

—

Decisiones

• Se mantiene el plan
