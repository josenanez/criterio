<!-- origen: 10-descubrimiento/2025-09-27-entrevistas.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Entrevistas · Permisos de trabajo digitales

**Ronda:** Ronda · 2025-09-27
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-09-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
