# Corrida del 2026-10-18 · product-setup

PRD-308 · 12 requerimientos · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

0 preguntas a la persona (4 respuestas por defecto, sesión sin interfaz); minutos hasta el primer resultado: sin medir; 5 documentos, 12 requerimientos, 0 con proyecto; sin criterio de éxito, sin serie medida, supuesto con verificación citada que no existe en la carpeta

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Listo — Permisos de trabajo digitales (PRD-308)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una entrevista, 2025-09-27) · la definición del 2025-10-01 · lo más reciente es el acta del comité del 2026-10-15. Todos se leyeron (4 .md y 1 .docx convertido); no hay formatos ilegibles.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.5.0 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 05a6d5118354… (md) / 335e499393eaf35a… (pdf)

**Instalación (sesión sin interfaz, respuestas sugeridas):** quién eres y qué producto: Javier Hoyos, gerente de PRD-308 «Permisos de trabajo digitales» (del caso de negocio). Quién decide: «Comité de producto» (el acta lo nombra; ningún documento dice qué persona decide). Estado: `estado-producto/PRD-308`. Términos: aceptados con el nombre indicado.

**Material de descubrimiento:** existe, pero es mínimo: una entrevista, con un solo cliente sin nombre y una sola frase. La carpeta de métricas no existe.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Supervisores no tiene permisos de trabajo digitales» | Una entrevista con un cliente: «Lo necesito y hoy no lo tengo» (no dice que sea supervisor) | 2025-09-27 |
| volumen_mensual = 98.890 | Solo el propio caso de negocio; ninguna serie medida | 2025-10-01 |
| Retorno esperado en 24 meses | Nada: no hay cifra de retorno | 2025-10-01 |
| Supuesto «Operaciones adopta la herramienta» → «se confirmó» | La verificación del 2026-08-08 cita «la entrevista con doce clientes del 2026-08-08», que no está en la carpeta | 2026-08-08 |
| 12 requerimientos en el comité (9 aceptados, 3 propuestos) | Acta del comité; 5 de los 9 aceptados llevan evidencia (55.6 %), todos la misma entrevista | 2026-10-15 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo escribe: el cierre no tendrá contra qué juzgarse.
- **Que alguien esté midiendo el volumen mensual.** Hay una cifra declarada (98.890) y ninguna serie medida a la vista: no se puede contrastar.
- **La propuesta.** Dice «Propuesta principal»; no describe nada.
- **El retorno.** «Retorno esperado en 24 meses» sin monto.
- **Quién decide, como persona.** Solo figura «Comité de producto».
- **La entrevista de doce clientes del 2026-08-08**, que sostiene la verificación del supuesto: no existe en la carpeta de descubrimiento.
- **Qué es «el plan» que el comité mantiene** («Se mantiene el plan»): no hay plan escrito.
- **Qué necesita cada requerimiento:** los 12 se llaman «Requerimiento REQ-48xx»; ninguno dice el problema.
- **Proyecto que construya algo:** 0 de 9 requerimientos aceptados tienen proyecto (la definición dice «Ninguno declarado»).

### Señales del cálculo (copiadas de `compute`)
- 9 aceptados sin proyecto que los ejecute.
- 4 aceptados sin evidencia de demanda: REQ-4802, 4803, 4806, 4809.
- 4 aceptados sin criterio de aceptación: REQ-4803, 4805, 4806, 4808.
- 1 aceptado sin doliente: REQ-4809 («sin asignar»).
- 3 propuestos sin decidir hace 60 días o más: REQ-4801 (120 días), REQ-4804 (213), REQ-4810 (86).
- 8 requerimientos con evidencia vencida (12 meses): toda sale de la entrevista del 2025-09-27.
- 1 supuesto sin verificar documentado: «Operaciones adopta la herramienta», 158 días desde que se declaró (2026-05-13).

### Supuestos sobre los que está escrita
Uno: «Operaciones adopta la herramienta», declarado el 2026-05-13 —siete meses después de la definición del 2025-10-01—. Dice estar verificado con una entrevista que no se puede ver. Además, el supuesto habla de «Operaciones» y el segmento de la definición es «Supervisores». Lo dejé como no verificado hasta que aparezca esa entrevista.

### Qué le falta a tu carpeta
- Las transcripciones de la entrevista de doce clientes del 2026-08-08, y de cualquier otra con fecha reciente.
- La serie medida del volumen mensual con su fuente.
- Las decisiones del comité con su fecha y sus descartados, para distinguir lo descartado de lo que nadie miró.
- El criterio de éxito y la propuesta en palabras.

**Nota de lectura:** el acta atribuye 8 requerimientos a «Cliente entrevistado»; como existe una sola entrevista, la ligué a ella como evidencia. Si hubo otras, el registro está sobrestimando una sola fuente.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
