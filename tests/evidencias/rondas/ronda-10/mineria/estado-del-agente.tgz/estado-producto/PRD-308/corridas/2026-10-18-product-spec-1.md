# Corrida del 2026-10-18 · product-spec

PRD-308 · 12 requerimientos · 40 s · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador sin sección de comportamiento: 9 aceptados sin necesidad ni criterio verificable; 3 propuestos fuera. Dijo que no sabe: obligaciones normativas (sin barrido posible), verificación real del supuesto de adopción, quién integra el comité.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

> **Borrador del 2026-10-18, escrito por el agente. Lo cierra Javier Hoyos (gerente de producto); lo aprueba el Comité de producto. Este agente no firma ni aprueba.**
> Términos aceptados por José Francisco Ñáñez el 2026-10-18 (v1.1): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

# Especificación — Permisos de trabajo digitales (PRD-308) · borrador del 2026-10-18

**Resultado en una línea:** el registro no alcanza para especificar comportamiento. Ninguno de los 9 requerimientos aceptados dice qué necesita ni cómo se verifica; por eso esta especificación tiene alcance y vacíos, pero **no tiene sección de comportamiento**: escribirla sería inventarla.

Registro de origen: `estado-producto/PRD-308/requirements/` (12 requerimientos, actualizado el 2026-10-18), construido desde el acta del comité del 2026-10-15. Se especifican los `aceptado` (9); no hay ninguno en `en_construccion`; los 3 `propuesto` (REQ-4801, REQ-4804, REQ-4810) quedan fuera porque nadie los ha decidido.

## Qué problema resuelve

«El segmento Supervisores no tiene permisos de trabajo digitales.» (`00-definicion/2025-10-01-definicion-producto.md`, «El problema»). Para: Supervisores. La definición **no dice** qué es un permiso de trabajo en este contexto, qué hoy hacen en su lugar, ni el criterio de éxito del producto. La propuesta dice solo «Propuesta principal», que es texto de relleno y no describe nada.

## Alcance

### Entra
Los 9 requerimientos aceptados, **solo como identificadores**: REQ-4800, 4802, 4803, 4805, 4806, 4807, 4808, 4809, 4811 (acta del 2026-10-15). Todos tienen el título genérico «Requerimiento REQ-48xx» y la necesidad sin registrar, así que no hay contenido que entre más allá del número.

### No entra
- REQ-4801, REQ-4804, REQ-4810: están `propuesto`, sin decisión. Especificarlos sería decidir por el comité.
- Cualquier comportamiento, flujo, pantalla o integración: ningún documento los describe.
- Diseño técnico, estimación, costo y fechas: no son de este documento.
- Otros segmentos distintos de Supervisores: la definición no los menciona.

## Comportamiento

**Sin secciones.** El campo «necesidad» de los 9 requerimientos aceptados figura como no encontrado y los títulos son genéricos. Una sección de comportamiento hoy sería texto del agente, no del registro, y no tendría requerimiento al que citar.

## Criterios de aceptación

El único criterio que existe en el registro es «se verifica en producción». **No pasa la prueba**: no dice qué se observa, con qué umbral ni quién lo mira, así que dos personas no llegarían a la misma respuesta. No lo reescribí con un número porque el número lo tendría que fijar quien es dueño del requerimiento.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4800, 4802, 4807, 4809, 4811 | No definido | **No**: no es un criterio verificable; además el producto no declara proyecto que lo construya, así que no consta que vaya a haber una producción |
| (ninguno) | REQ-4803, 4805, 4806, 4808 | — | **No hay criterio** |

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| Operaciones adopta la herramienta (declarado el 2026-05-13) | **No consta.** El anexo del 2026-08-08 dice «se confirmó» con «la entrevista con doce clientes del segmento», pero esa entrevista no está en `10-descubrimiento`; la única es la del 2025-09-27 con un solo cliente. Una confirmación citada y no hallada no cuenta como verificación. | Javier Hoyos (autor del anexo no identificado en el documento: confirmar quién lo hizo) aportando las entrevistas |

No hay supuestos registrados por requerimiento (los 12 vienen con la lista vacía).

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada requerimiento aceptado (los 9 sin necesidad ni título propio) | No se puede escribir comportamiento ni criterios; el comité aceptó sin que el registro diga qué | Cada doliente (ver abajo); Javier Hoyos consolida |
| Criterio de aceptación verificable | «Se verifica en producción» deja la discusión de si quedó bien para después de construir | Dolientes de REQ-4800, 4802, 4807, 4809, 4811 |
| Sin criterio alguno: REQ-4803, 4805, 4806, 4808 | No se pueden aceptar sin criterio sin que la aceptación sea de fe | María Restrepo (4803), Beatriz Cuéllar (4805), Carlos Peña (4806), Elena Duarte (4808) |
| Doliente de REQ-4809 («sin asignar») | Un requerimiento aceptado que nadie defiende ni cierra | Comité de producto (asignar); Javier Hoyos (convocar) |
| Evidencia de demanda de REQ-4802, 4803, 4806, 4809 (sin evidencia) y de los demás (una sola cita genérica, «Lo necesito y hoy no lo tengo», del 2025-09-27, que no nombra el requerimiento) | Aceptados sin que conste quién los pidió; el acta dice «Cliente entrevistado» sin identificarlo | Javier Hoyos |
| Casos borde: sin conexión, permiso duplicado, permiso vencido, revocado o emitido y no recibido por el supervisor, quién autoriza y quién firma | No hay comportamiento definido; lo decidiría quien construya | Dolientes de cada requerimiento, a propuesta de Javier Hoyos |
| Criterio de éxito del producto (no encontrado) | No hay contra qué verificar que el conjunto funcionó | Javier Hoyos / Comité de producto |
| Proyecto que construye el producto («Ninguno declarado»; la columna «Proyecto que lo ejecuta» del acta está vacía en los 12) y equipos que tendrían que intervenir | La decisión del comité «Se mantiene el plan» no remite a ningún plan ni proyecto; lo que otro equipo deba hacer no está acordado con nadie | Comité de producto; con la aceptación, `/product-charter` |
| Obligaciones normativas | No se hizo el barrido: la definición no dice qué contiene un permiso de trabajo ni qué datos de personas maneja, y sin eso no puedo decir si toca seguridad laboral, datos personales o retención. **No afirmo que no haya obligaciones; afirmo que no se sabe.** | Javier Hoyos con el área jurídica/de cumplimiento de la organización |
| Quién decide: el acta nombra al Comité de producto, pero ningún documento dice quién lo integra; asistió solo Javier Hoyos | Una decisión de aceptación tomada por una sola persona | Comité de producto |

## Requerimientos aceptados que esta especificación no cubre

Ninguno de los 9 queda cubierto por una sección de comportamiento, por la misma razón de fondo. Se dice la razón específica:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 (Ricardo Salas) | Necesidad no registrada; criterio no verificable |
| REQ-4802 | Requerimiento REQ-4802 (Gustavo Neira) | Necesidad no registrada; criterio no verificable; sin evidencia de quién lo pidió |
| REQ-4803 | Requerimiento REQ-4803 (María Restrepo) | Necesidad no registrada; sin criterio; sin evidencia |
| REQ-4805 | Requerimiento REQ-4805 (Beatriz Cuéllar) | Necesidad no registrada; sin criterio |
| REQ-4806 | Requerimiento REQ-4806 (Carlos Peña) | Necesidad no registrada; sin criterio; sin evidencia |
| REQ-4807 | Requerimiento REQ-4807 (Gustavo Neira) | Necesidad no registrada; criterio no verificable |
| REQ-4808 | Requerimiento REQ-4808 (Elena Duarte) | Necesidad no registrada; sin criterio |
| REQ-4809 | Requerimiento REQ-4809 (sin doliente) | Necesidad no registrada; criterio no verificable; sin doliente ni evidencia |
| REQ-4811 | Requerimiento REQ-4811 (María Restrepo) | Necesidad no registrada; criterio no verificable |

## Después

**No ofrezco `/product-charter` todavía**: los vacíos no están cerrados y el producto no tiene criterio de éxito. Cuando cada requerimiento aceptado tenga necesidad y criterio verificable, se vuelve a correr `/product-spec`.

---
*Pie: sale del registro de requerimientos de PRD-308 (12 requerimientos, actualizado el 2026-10-18; acta del comité del 2026-10-15). Cubre 0 de los 9 aceptados con comportamiento; 9 aceptados listados en el alcance sin contenido; 3 propuestos fuera. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
