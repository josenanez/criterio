## Definición — Permisos de trabajo digitales (PRD-308) · contrastada al 2026-10-18
**Documento:** `00-definicion/2025-10-01-definicion-producto.md` (con el caso de negocio del mismo día y la verificación del 2026-08-08) · **del** 2025-10-01 · 7 afirmaciones
**Términos:** vigentes (versión 0.5.0, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no hubo que registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que la definición afirma. Lo que hay es distinto: afirmaciones que nadie sostiene (abajo).

### El negocio y los datos
Ninguna métrica pasa del umbral de 20 %: no hay medida contra la cual comparar (`claim_vs_metric`: `measured` = null, `gap_pct` = null).

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| volumen_mensual = 98.890 | Caso de negocio, 2025-10-01 | La carpeta de métricas no existe. Nadie está midiendo lo que el caso de negocio afirmó; no es una contradicción. |
| Retorno esperado en 24 meses | Caso de negocio, 2025-10-01 | Ni siquiera trae cifra: no se puede medir algo que no tiene monto. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo escribe. `compute` lo trae en `unknown`.
- **La propuesta.** Dice «Propuesta principal» y no describe nada.
- **El monto del retorno.** «Retorno esperado en 24 meses», sin cifra.
- **Quién decide, como persona.** Solo figura «Comité de producto»; ningún documento nombra quién.
- **Cómo se llega a 98.890 al mes.** El caso de negocio da la cifra sin método ni base.
- **Que quien tiene el problema sea «Supervisores».** La única voz (un cliente sin nombre) no dice su rol.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»; 0 de 9 requerimientos aceptados tienen proyecto.
- **Qué es «el plan»** que el comité del 2026-10-15 decidió mantener: no hay plan escrito.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «Operaciones adopta la herramienta» (declarado el 2026-05-13) | 158 (umbral 30) | Las transcripciones o notas de la «entrevista con doce clientes del 2026-08-08», que el anexo cita y que no está en `10-descubrimiento`. Además, el supuesto habla de «Operaciones» y la definición de «Supervisores»: hay que decir si son el mismo grupo. Y un criterio de adopción que se pueda ver (cuántos, haciendo qué, en qué plazo); «adopta» no se puede desmentir como está escrito. |

El anexo del 2026-08-08 dice «se confirmó», pero la entrevista que lo respalda no se puede ver. Lo cuento como **no verificado** hasta que aparezca.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Supervisores no tiene permisos de trabajo digitales» | Una entrevista con un cliente sin nombre: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-27-entrevistas.md`) | 2025-09-27 | Débil: una sola voz, dicha y no pagada, sin rol y sin cifra. Es lo más bajo de la jerarquía de demanda. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema de Supervisores | Entrevista del 2025-09-27 | 12 meses (umbral 12) |
| 8 de los 12 requerimientos del comité | La misma entrevista del 2025-09-27 | 12 meses |

Los 8 requerimientos con evidencia vencida salen de **una sola** entrevista; el registro cuenta ocho, pero la fuente es una.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de los trabajadores y supervisores que firmarían los permisos | No dicho en ningún documento | — | — | No tengo la norma a la vista |
| Firma o validez de un permiso de trabajo digital, y su retención | No dicho en ningún documento | — | — | No tengo la norma a la vista |

La definición no nombra país ni sector, así que no puedo citar una norma sin inventarla. Esto no dice que cumpla ni que no cumpla: va a revisión jurídica una vez se diga el país.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Problema:** está escrito (una frase), pero con una sola voz y vencida.
- **Para quién:** «Supervisores», sin que la evidencia diga que lo sean; y el supuesto habla de «Operaciones».
- **Quién decide:** solo «Comité de producto»; falta la persona.

**Lo que dejo fuera a propósito:** no digo si la demanda alcanza ni si el producto va a gustar; eso es del comité y de la estrategia.

**Después:** el supuesto «Operaciones adopta la herramienta» lleva 158 días sin verificarse. Ofrezco convertirlo en riesgo con doliente (raid-taxonomy). La definición no está cerrada, así que no ofrezco `/product-charter`.
