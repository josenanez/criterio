# Corrida del 2026-10-18 · product-charter

PRD-308 · 12 requerimientos · 51 s · 30 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador de acta de REQ-4800 sin firmar; ficha no creada. Vacíos: necesidad, criterio de aceptación verificable, éxito, evidencia (1 entrevista de hace >12 meses), verificación del supuesto (entrevista de 12 clientes no existe), patrocinador, gerente, autoridad, presupuesto, hitos, barrido normativo.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Permisos de trabajo digitales (REQ-4800) · borrador del 2026-10-18
**Producto:** PRD-308 · Permisos de trabajo digitales · **Requerimientos:** REQ-4800

> Verificación previa (requirement-record): REQ-4800 está **aceptado**, pero tiene vacíos que impiden darlo por completo: necesidad sin describir, criterio de aceptación no verificable, evidencia de una sola entrevista de hace más de 12 meses, y autoridad no declarada en la definición. Siguiendo la respuesta sugerida («seguir sin él marcándolo como vacío del acta»), se redacta el borrador y **cada faltante queda como vacío; nada se rellenó**.

## Qué problema resuelve
«El segmento Supervisores no tiene permisos de trabajo digitales.» — `documentos/productos/PRD-308/00-definicion/2025-10-01-definicion-producto.md` (El problema).
**Vacío:** el requerimiento REQ-4800 no tiene necesidad descrita (`need`: no encontrada). Su título es genérico («Requerimiento REQ-4800») y la propuesta de la definición es texto de relleno («Propuesta principal»). El acta no puede decir qué construye REQ-4800 en concreto.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No dice cómo.** Sin métrica, umbral, plazo ni quién verifica. | `documentos/productos/PRD-308/30-decisiones/2026-10-15-comite-producto.docx` (fila REQ-4800) |

La definición del producto no declara criterio de éxito (`definition.success`: no encontrado). Tal como está, el cierre del proyecto no se podría juzgar meses después.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 (aceptado desde 2026-06-29; doliente: Ricardo Salas) | Entrevista con un cliente, 2025-09-27: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) — `documentos/productos/PRD-308/10-descubrimiento/2025-09-27-entrevistas.md`. Es una sola entrevista, no menciona REQ-4800, y tiene 12 meses y 3 semanas, por encima del umbral de 12 meses (`evidence_stale_months`). |

### No entra
Razón: este borrador cubre solo REQ-4800. Ningún documento dice por qué los demás quedan fuera; lo único que se puede afirmar es lo que el acta del comité de 2026-10-15 registra de cada uno. **La razón de exclusión es de quien firma, no del agente.**

| REQ | Estado en el comité (2026-10-15) | Por qué no entra |
|---|---|---|
| REQ-4801, REQ-4804, REQ-4810 | propuesto | No están aceptados: no hay decisión de construir. |
| REQ-4802 | aceptado | Fuera de esta acta; sin razón documentada. Sin «quién lo pidió». |
| REQ-4803, REQ-4806 | aceptado | Fuera de esta acta; sin razón documentada. Sin criterio de aceptación ni «quién lo pidió». |
| REQ-4805, REQ-4808 | aceptado | Fuera de esta acta; sin razón documentada. Sin criterio de aceptación. |
| REQ-4807, REQ-4811 | aceptado | Fuera de esta acta; sin razón documentada. |
| REQ-4809 | aceptado | Fuera de esta acta; sin doliente ni «quién lo pidió». |

Ninguno tiene proyecto que lo ejecute (columna «Proyecto que lo ejecuta»: «—»; la definición dice «Ninguno declarado»).

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no hay base documental para proponer a una persona. Javier Hoyos es el gerente **de producto** (definición, 2025-10-01), no consta como gerente de proyecto. Asignarlo es de quien tiene la autoridad.
- **Comité:** Comité de producto — `30-decisiones/2026-10-15-comite-producto.docx` (título). Asistió una sola persona: Javier Hoyos.
- **Autoridad del gerente del proyecto:** no declarada. La autoridad del producto («Comité de producto») está marcada en la ficha como propuesta por defecto en la instalación: ningún documento dice quién decide.
- **Doliente del requerimiento:** Ricardo Salas (acta del comité, 2026-10-15).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «Operaciones adopta la herramienta» (declarado el 2026-05-13) — `00-definicion/2025-10-01-definicion-producto.md` (Supuestos) | **No.** El anexo del 2026-08-08 dice «se confirmó» con «la entrevista con doce clientes del segmento del 2026-08-08», pero esa entrevista **no está en `10-descubrimiento`**; la única es la de 2025-09-27, con un cliente. Además, el segmento es Supervisores y el supuesto habla de Operaciones. Lleva más de 30 días sin verificar (`assumption_unverified_days`). | Sin nombrar. Se propone registrarlo como riesgo (raid-taxonomy) con doliente a asignar por el gerente del proyecto. |
| Cifra del caso de negocio: `volumen_mensual` = 98.890 (2025-10-01) | **No.** Su única fuente es el propio caso de negocio; no hay serie medida con la cual contrastarla. | Sin nombrar. Dato a verificar antes de usarlo como línea base de beneficio. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Permisos de trabajo digitales (registro y firma de autorizaciones de trabajo) | No determinada | Ningún documento cita una norma | **Sin barrido.** No se hizo el barrido normativo; este borrador no opina sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Necesidad de REQ-4800 (título y propuesta de relleno) | El proyecto arranca sin saber qué construye | Gerente de producto (Javier Hoyos) con el doliente (Ricardo Salas) |
| Criterio de aceptación verificable | El cierre no se puede juzgar; «se verifica en producción» admite cualquier resultado | Doliente y gerente de producto |
| Criterio de éxito del producto | Sin referencia contra la cual medir el beneficio | Gerente de producto |
| Evidencia de demanda: una entrevista, de hace más de 12 meses, que no menciona REQ-4800 | El proyecto se sostiene en una frase genérica | Gerente de producto (nueva ronda de descubrimiento) |
| Verificación real del supuesto de adopción | El riesgo de no adopción entra sin medir | Gerente de producto |
| Patrocinador | Nadie con autoridad para desbloquear | Comité de producto |
| Gerente del proyecto y su autoridad | Un gerente que no sabe qué puede decidir escala todo o no escala nada | Quien tiene la autoridad de asignar |
| Presupuesto e hitos | No declarados en ningún documento; la ficha nacería sin ellos | Patrocinador / comité |
| Barrido normativo | Obligaciones sin descubrir | Gerente de producto con Legal |
| Razón de exclusión de los demás REQ | La discusión del tercer mes | Quien firma el acta |

---
**Esto es un borrador.** Lo firma el patrocinador o la persona que el Comité de producto designe (ninguno está nombrado). **La ficha del proyecto no se creó** y no se creará hasta que el acta esté firmada; el estado declarado nunca lo escribe este comando.

**Qué sigue y para quién:** una vez firmada, se crea la ficha con `portafolio.py init`. Su gerente instala `criterio-project` y corre primero `/pm-setup`; al publicar su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.

*Términos vigentes (v1.1): Criterio produce borradores, no decisiones ni asesoría; la verificación de cada cita es suya. Aceptados por José Francisco Ñáñez el 2026-10-18.*
