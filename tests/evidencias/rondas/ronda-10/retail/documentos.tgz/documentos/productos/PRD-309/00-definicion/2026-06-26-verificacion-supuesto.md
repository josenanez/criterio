# Verificación del supuesto · Tarjeta de la tienda

**Fecha:** 2026-06-26

**Supuesto:** La regulación de datos lo permite

**Con qué se verificó:** la medición del piloto del 2026-06-26

**Resultado:** se confirmó.
