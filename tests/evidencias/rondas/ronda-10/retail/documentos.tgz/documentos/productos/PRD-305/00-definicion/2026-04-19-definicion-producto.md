# Definición de producto · Entrega rápida

**Código:** PRD-305
**Gerente de producto:** Javier Hoyos
**Segmento:** Pequeños negocios
**Fecha de la definición:** 2026-04-19

## El problema

El segmento Pequeños negocios no tiene entrega rápida.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-06-22 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
