# Tablero de métricas · Entrega rápida

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 212.414 | 2026-10-06 |
