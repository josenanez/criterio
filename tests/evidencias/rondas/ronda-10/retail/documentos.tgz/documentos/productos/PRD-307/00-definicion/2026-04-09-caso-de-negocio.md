# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-04-09
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 198.583 | Caso de negocio, 2026-04-09 |

## Retorno esperado

Retorno esperado en 24 meses.
