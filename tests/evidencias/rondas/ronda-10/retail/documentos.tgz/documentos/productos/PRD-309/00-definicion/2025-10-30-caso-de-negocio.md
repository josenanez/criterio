# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2025-10-30
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 81.721 | Caso de negocio, 2025-10-30 |

## Retorno esperado

Retorno esperado en 24 meses.
