# Definición de producto · App de clientes

**Código:** PRD-306
**Gerente de producto:** Carlos Peña
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-04-25

## El problema

El segmento Jóvenes no tiene app de clientes.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin descuento** · declarado el 2026-04-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
