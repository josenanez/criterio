# Entrevistas · Entrega rápida

**Ronda:** Ronda · 2026-03-07
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-03-07

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
