# Tablero de métricas · App de clientes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 53.286 | 2026-10-02 |
