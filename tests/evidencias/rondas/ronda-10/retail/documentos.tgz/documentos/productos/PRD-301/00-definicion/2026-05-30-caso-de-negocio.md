# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2026-05-30
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 260.108 | Caso de negocio, 2026-05-30 |

## Retorno esperado

Retorno esperado en 24 meses.
