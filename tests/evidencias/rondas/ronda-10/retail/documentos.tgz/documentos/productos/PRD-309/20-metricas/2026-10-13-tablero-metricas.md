# Tablero de métricas · Tarjeta de la tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 81.043 | 2026-10-13 |
