# Definición de producto · Tarjeta de la tienda

**Código:** PRD-309
**Gerente de producto:** Carlos Peña
**Segmento:** Hogares
**Fecha de la definición:** 2025-10-30

## El problema

El segmento Hogares no tiene tarjeta de la tienda.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-04-01 · verificado con la medición del piloto del 2026-06-26 (anexo «Verificación del supuesto» del 2026-06-26)

## Proyectos que lo construyen

- Ninguno declarado
