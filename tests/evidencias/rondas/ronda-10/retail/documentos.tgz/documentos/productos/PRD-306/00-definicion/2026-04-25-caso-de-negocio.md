# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-04-25
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 56.831 | Caso de negocio, 2026-04-25 |

## Retorno esperado

Retorno esperado en 24 meses.
