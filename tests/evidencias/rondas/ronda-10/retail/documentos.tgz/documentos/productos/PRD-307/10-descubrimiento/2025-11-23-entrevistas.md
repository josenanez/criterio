# Entrevistas · Compra y recoge

**Ronda:** Ronda · 2025-11-23
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-11-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
