# Comité de producto · Puntos de fidelización

**Fecha:** 2026-10-12
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4101 | Requerimiento REQ-4101 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-02 | — |
| REQ-4102 | Requerimiento REQ-4102 | Sandra Gil | se verifica en producción | — | propuesto | 2026-05-11 | — |
| REQ-4103 | Requerimiento REQ-4103 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-08 | — |
| REQ-4104 | Requerimiento REQ-4104 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-23 | — |
| REQ-4105 | Requerimiento REQ-4105 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-16 | — |
| REQ-4106 | Requerimiento REQ-4106 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-26 | — |
| REQ-4107 | Requerimiento REQ-4107 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4108 | Requerimiento REQ-4108 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-28 | — |
| REQ-4109 | Requerimiento REQ-4109 | Jorge Medina | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-20 | — |
| REQ-4110 | Requerimiento REQ-4110 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-06-24 | — |
| REQ-4111 | Requerimiento REQ-4111 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-17 | — |

## Decisiones

- Se mantiene el plan
