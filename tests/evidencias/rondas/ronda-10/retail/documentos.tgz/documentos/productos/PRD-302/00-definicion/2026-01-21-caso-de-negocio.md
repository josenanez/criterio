# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2026-01-21
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 206.212 | Caso de negocio, 2026-01-21 |

## Retorno esperado

Retorno esperado en 24 meses.
