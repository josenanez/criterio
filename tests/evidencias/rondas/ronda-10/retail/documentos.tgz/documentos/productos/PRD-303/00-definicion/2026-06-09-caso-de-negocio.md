# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2026-06-09
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 61.682 | Caso de negocio, 2026-06-09 |

## Retorno esperado

Retorno esperado en 24 meses.
