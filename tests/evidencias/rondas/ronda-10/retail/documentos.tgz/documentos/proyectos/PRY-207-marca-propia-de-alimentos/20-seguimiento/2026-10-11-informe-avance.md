# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-10-11
**Gerente:** Felipe Arango

## Estado declarado

**Rojo**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.019.862.693 |
| Ejecutado | 1.719.581.740 |
| Proyección al cierre | 3.145.988.102 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
- El proveedor no ha confirmado la fecha de la última entrega
