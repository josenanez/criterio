# Acta de constitución · Domicilios en dos horas

**Código:** PRY-208
**Área dueña:** Finanzas
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Expansión
**Producto asociado:** entrega rápida
**Fecha de aprobación:** 2025-07-08

## Objetivo del negocio

Entregar domicilios en dos horas para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Expansión el 2025-07-08.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-18 |
| Cierre | 2026-02-13 |

## Criterio de éxito

Domicilios en dos horas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
