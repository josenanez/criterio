# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-09-27
**Asistentes:** Andrés Lozano, Camilo Beltrán, Diana Molina, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-10-16 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-24 |
| María Restrepo | Revisar el anexo 3 | 2026-10-22 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-12 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Camilo Beltrán | Revisar el anexo 11 | 2026-10-11 |
| Liliana Torres | Validar el ambiente 12 | 2026-10-06 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 |
| Liliana Torres | Actualizar la matriz 14 | 2026-10-11 |
| Diana Molina | Confirmar la fecha 15 | 2026-10-13 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-09 |

## Lo que se dijo

- Carlos Peña dice que ya entregó «actualizar la matriz 6». No se presentó acta.
