# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.993.137.030 |
| Ejecutado | 1.956.675.604 |
| Proyección al cierre | 4.291.015.842 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
