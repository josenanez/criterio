# Acta de constitución · Tienda en línea

**Código:** PRY-200
**Área dueña:** Comercial
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Arquitectura
**Producto asociado:** venta en línea
**Fecha de aprobación:** 2026-01-10

## Objetivo del negocio

Entregar tienda en línea para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Arquitectura el 2026-01-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-20 |
| Cierre | 2027-01-02 |

## Criterio de éxito

Tienda en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
