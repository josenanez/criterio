# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-10-18
**Asistentes:** Gustavo Neira, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 5 | 2026-10-16 |
