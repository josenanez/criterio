# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-10-04
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-11-02 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-14 |
| María Restrepo | Revisar el anexo 3 | 2026-10-22 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-31 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Liliana Torres | Validar el ambiente 12 | 2026-10-06 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 |
| Diana Molina | Confirmar la fecha 15 | 2026-10-27 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-09 |
| Carlos Peña | Enviar el documento 17 | 2026-10-18 |
| Jorge Medina | Cerrar la prueba 18 | 2026-10-24 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-17 |
| Paula Céspedes | Validar el ambiente 20 | por definir |

## Cerrados en esta reunión

- Revisar el anexo 11 (Camilo Beltrán): recibido, acta de recibo del 2026-10-04.

## Lo que se dijo

- Liliana Torres dice que ya entregó «actualizar la matriz 14». No se presentó acta.
