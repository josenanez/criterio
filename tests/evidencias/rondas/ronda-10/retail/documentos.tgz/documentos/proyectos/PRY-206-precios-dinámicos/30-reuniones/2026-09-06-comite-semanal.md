# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-09-06
**Asistentes:** Andrés Lozano, Javier Hoyos, Liliana Torres, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-09-13 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-14 |
| María Restrepo | Revisar el anexo 3 | 2026-10-02 |
| Javier Hoyos | Validar el ambiente 4 | 2026-09-20 |
