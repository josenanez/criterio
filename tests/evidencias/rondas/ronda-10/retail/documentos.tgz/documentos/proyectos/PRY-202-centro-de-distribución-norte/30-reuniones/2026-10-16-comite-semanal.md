# Comité Comercial · Centro de distribución norte

**Fecha:** 2026-10-16
**Asistentes:** Jorge Medina, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 37 | 2026-10-02 |
| Rubén Cárdenas | Entregar el punto 35 | 2026-11-12 |
