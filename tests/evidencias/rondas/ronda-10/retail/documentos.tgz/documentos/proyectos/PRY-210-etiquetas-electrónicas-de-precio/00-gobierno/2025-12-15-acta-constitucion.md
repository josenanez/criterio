# Acta de constitución · Etiquetas electrónicas de precio

**Código:** PRY-210
**Área dueña:** Comercio electrónico
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-15

## Objetivo del negocio

Entregar etiquetas electrónicas de precio para Comercio electrónico.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité Comercial el 2025-12-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-25 |
| Cierre | 2027-03-14 |

## Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

## Dependencias declaradas

- Ninguna declarada
