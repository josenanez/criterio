# Comité de Expansión · Domicilios en dos horas

**Fecha:** 2026-10-06
**Asistentes:** Camilo Beltrán, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 35 | por definir |
