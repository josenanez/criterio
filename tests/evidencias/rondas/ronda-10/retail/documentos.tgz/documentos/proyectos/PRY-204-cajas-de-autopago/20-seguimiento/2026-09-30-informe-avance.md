# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-09-30
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **55%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 800.208.609 |
| Ejecutado | 947.118.565 |
| Proyección al cierre | 2.251.879.432 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
