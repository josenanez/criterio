# Informe de avance · Domicilios en dos horas

**Código:** PRY-208
**Fecha de corte:** 2026-10-07
**Gerente:** Camilo Beltrán

## Estado declarado

**Rojo**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 14.480.871.456 |
| Ejecutado | 4.408.959.068 |
| Proyección al cierre | 22.832.718.095 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
