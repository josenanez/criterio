<!-- origen: 00-definicion/2026-05-30-definicion-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Definición de producto · Venta en línea

Código: PRD-300

Gerente de producto: Diana Molina

Segmento: Pequeños negocios

Fecha de la definición: 2026-05-30

El problema

El segmento Pequeños negocios no tiene venta en línea.

La propuesta

• Propuesta principal

Supuestos

• El cliente paga por la entrega rápida · declarado el 2026-03-21 · verificado con el documento técnico del proveedor del 2026-09-14 (anexo «Verificación del supuesto» del 2026-09-14)

Proyectos que lo construyen

• Ninguno declarado
