# Caso de negocio — Venta en línea (PRD-300) · borrador del 2026-10-18
**Desde:** la definición del 2026-05-30 y el caso de negocio del 2026-05-30 · **Cifras con fuente:** 1 de 1 (y esa 1 es declarada, no medida)

## Qué problema resuelve, y para quién
«El segmento Pequeños negocios no tiene venta en línea.» Segmento: Pequeños negocios. (Definición de producto, `00-definicion/2026-05-30-definicion-producto.docx`, 2026-05-30.)

La propuesta en la definición dice solo «Propuesta principal», sin contenido. El **criterio de éxito no está declarado** en ningún documento.

## Qué se construye
Los 15 requerimientos del registro están `aceptado`; ninguno está en construcción, entregado ni descartado (comité de producto, `30-decisiones/2026-10-13-comite-producto.docx`, 2026-10-13). Todos tienen persona como doliente. Ninguno tiene proyecto que lo ejecute.

| Grupo | Requerimientos | Evidencia de demanda |
|---|---|---|
| Aceptados con cita de «Cliente entrevistado» | REQ-4000, 4002, 4005, 4006, 4007, 4008, 4010, 4013, 2028 (9) | La misma frase para los nueve: «Lo necesito y hoy no lo tengo» (entrevistas, 2025-08-30; 13 meses, umbral 12). No nombra al cliente ni la vincula a un requerimiento. |
| Aceptados **sin ninguna cita** de quién lo pidió | REQ-4001, 4003, 4004, 4009, 4011, 4012 (6) | Ninguna. |

Sin criterio de aceptación: REQ-2028, 4000, 4011, 4013.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 162.820 | **Declarada** | Caso de negocio, tabla «Cifras que sostienen el caso» (Diana Molina) | 2026-05-30 |
| Retorno esperado | «en 24 meses» | **Sin cifra** | Caso de negocio, sección «Retorno esperado» | 2026-05-30 |

Notas:
- La fuente de 162.820 es el propio caso de negocio: la cifra se cita a sí misma. No hay documento de origen detrás. Tampoco dice qué se cuenta (transacciones, pedidos, visitas) ni cómo se calculó.
- El «retorno en 24 meses» no trae monto, base ni método. No es una cifra; es una frase. No se convierte en una.
- No hay ninguna cifra **medida**: no existe serie de métricas con fuente y corte para este producto.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 162.820 (2026-05-30) | **No existe serie medida** | Sin contraste posible: el producto no tiene datos medidos en la carpeta. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Sin dato** | Ningún documento |
| Contratos, cotizaciones, proveedor | **Sin dato** | Ningún documento (se menciona un «proveedor» en la verificación del supuesto, sin contrato ni monto) |
| Costo declarado del equipo | **Sin dato** | Ningún documento |

El costo de construir no está en ningún documento. Es el **primer vacío**: sin él esto es una propuesta, no un caso de negocio evaluable.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El cliente paga por la entrega rápida» (declarado 2026-03-21) | El volumen y el retorno que dependan de que el cliente pague por la entrega rápida no se sostienen. El caso no dice qué parte depende de esto. | Marcado como verificado el 2026-09-14, pero **con el documento técnico del proveedor, no con evidencia de demanda de clientes** (`00-definicion/2026-09-14-verificacion-supuesto.md`; el documento técnico mismo no está en la carpeta). Falta quién lo verifique con clientes. |
| Implícito: 162.820 al mes es alcanzable | Todo el caso numérico cae. | Nadie lo ha afirmado como supuesto; está implícito. Pasa a seguimiento. |
| Implícito: la evidencia de 2025-08-30 sigue vigente | Nueve requerimientos quedan sin demanda sostenida. | Gerente de producto. |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y contratos/cotizaciones) | Sin costo no hay caso: hay propuesta | El negocio (Diana Molina) / quien cotice |
| Origen y definición de 162.820 mensual | La cifra se cita a sí misma | Diana Molina |
| Monto y método del «retorno esperado» | Hoy no es evaluable | El negocio |
| Criterio de éxito de la definición | Sin él no se puede cerrar ni verificar meses después | Diana Molina / Comité de producto |
| Serie medida del producto | No se puede contrastar lo declarado | El sistema donde el producto vive |
| Qué pasa si no se hace; alternativas consideradas | El comité no tiene contra qué comparar | El negocio |
| Cuándo se sabrá si funcionó (fecha de corte) | Convierte el criterio de éxito en verificable | Comité de producto |
| Evidencia de demanda para 6 requerimientos aceptados sin cita | Se va a construir lo que nadie pidió | Dolientes: A. Lozano, S. Gil, R. Salas, G. Neira, P. Céspedes, J. Hoyos |
| Evidencia por requerimiento (la entrevista es una sola frase genérica de hace 13 meses) | Demanda no atribuible | Gerente de producto |
| Proyecto que ejecute los requerimientos | Sin proyecto, no hay costo ni plazo | Comité de producto (`/product-trace`) |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito. La única métrica es volumen_mensual = 162.820, sin fecha de corte ni umbral de «funcionó». Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno a la vista (la carpeta `estado/` está vacía). No se pudo hacer el cruce de `/product-overlap`: queda sin comprobar si otro caso de negocio cuenta las mismas transacciones.

---
*No se calculó ingreso, retorno, ahorro ni recuperación de la inversión, y no se recomienda aprobar ni rechazar: eso es del Comité de producto. Siguiente paso ofrecido: pasar los supuestos a seguimiento (assumption-tracking); `/product-charter` solo si el caso se aprueba.*
