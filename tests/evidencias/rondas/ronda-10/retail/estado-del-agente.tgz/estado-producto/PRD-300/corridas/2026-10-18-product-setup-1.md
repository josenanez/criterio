# Corrida del 2026-10-18 · product-setup

PRD-300 · 15 requerimientos · 31 s · 34 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_acceptance` | 4 |

0 preguntas respondidas (4 tomadas por defecto); no medí minutos; 15 requerimientos levantados: 6 sin evidencia, 9 con evidencia vencida (13 meses), 4 sin criterio, 15 sin proyecto; sin criterio de éxito ni serie de volumen_mensual. Hubo que abrir corrida-inicio para poder sellar

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Venta en línea (PRD-300)

**Lo que miré:** 5 documentos (3 .docx, 2 .md; todos legibles) · 1 de descubrimiento (una entrevista, 2025-08-30) · la definición del 2026-05-30, el caso de negocio del 2026-05-30, la verificación de supuesto del 2026-09-14 y el acta del comité de producto del 2026-10-13 (lo más reciente).
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-18 para la versión 1.1 (plugin 0.5.0) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 05a6d511835489a1…

**Preguntas (nadie respondió; tomé la sugerida):** producto PRD-300 «Venta en línea», gerente Diana Molina (del caso de negocio y la definición) · decide el Comité de producto (propuesta por defecto: ningún documento dice quién decide) · el estado vive en `estado-producto/PRD-300`, hermana de la documentación, no en `estado/` · términos aceptados con el nombre indicado.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Pequeños negocios no tiene venta en línea» | Una sola entrevista: «Lo necesito y hoy no lo tengo» (tema: necesidad principal). No dice quién es el cliente, de qué segmento, ni qué necesita | 2025-08-30 (13 meses) |
| «El cliente paga por la entrega rápida» | Un supuesto, declarado el 2026-03-21 y marcado «se confirmó» con un documento técnico del proveedor. Un documento del proveedor no dice qué paga el cliente | 2026-09-14 |
| volumen_mensual = 162.820 | Solo el caso de negocio, que es quien lo afirma. Sin serie medida ni fuente | 2026-05-30 |
| «Retorno esperado en 24 meses» | Solo el caso de negocio. Sin cifra ni cálculo | 2026-05-30 |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito:** no existe. El producto no se podrá cerrar contra nada.
- **Quién decide qué se construye:** ningún documento lo nombra; el acta solo lista a Diana Molina como asistente.
- **La propuesta:** la definición tiene el título «Propuesta principal» y nada debajo.
- **Qué mide volumen_mensual ni de dónde sale 162.820:** no hay ninguna serie medida. Nadie está midiendo lo que el negocio afirmó, así que no se puede contrastar.
- **De dónde sale el retorno de 24 meses.**
- **Qué proyecto construye este producto:** la definición dice «Ninguno declarado» y ninguno de los 15 requerimientos tiene proyecto (0 de 15 trazados, 0,0 %).
- **Cuál es «el plan» que el comité mantuvo:** el acta dice «Se mantiene el plan» y no hay plan entre los documentos.
- **Qué pidió cada requerimiento:** los 15 se llaman «Requerimiento REQ-xxxx» y ninguno describe el problema.
- **Quién decidió cada aceptación:** el acta da la fecha («Desde»), no quién.

### Supuestos sobre los que está escrita
Uno, el de la entrega rápida (arriba). Está marcado como verificado, pero con una fuente que no es de demanda.

### El registro: 15 requerimientos, todos «aceptado» en el acta del 2026-10-13
- **Sin evidencia de demanda: 6** (REQ-4001, 4003, 4004, 4009, 4011, 4012). Con evidencia: 9 (60,0 %).
- **Con evidencia vencida: 9** (REQ-2028, 4000, 4002, 4005, 4006, 4007, 4008, 4010, 4013). Todas apuntan a la misma entrevista, de hace 13 meses.
- **Sin criterio de aceptación: 4** (REQ-2028, 4000, 4011, 4013). En los otros 11 el criterio es «se verifica en producción», que no dice qué se verifica.
- **Sin proyecto que los ejecute: 15 de 15.**
- Los 9 que citan evidencia comparten una sola entrevista de un cliente sin nombre. El acta dice «Cliente entrevistado» sin decir cuál; no puedo vincular esa cita a cada requerimiento.
- REQ-2028 sale de la serie numérica de los demás (REQ-40xx) y fue aceptado el 2026-10-08, hace 10 días. Lo dejo tal cual lo escribe el acta.
- Los 15 doliente son personas. Dos de los dolientes (Diana Molina en REQ-4002 y 4007) son también la gerente de producto.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una sola, de una sola persona, y sin ella no se sabe a qué requerimiento corresponde.
- La serie medida de volumen_mensual con su fuente.
- Las decisiones del comité con quién decidió. Sin ellas, un requerimiento descartado se ve igual que uno que nadie miró (el acta no tiene ninguno descartado).
- Un criterio de éxito y la lista de proyectos.

Siguiente paso: `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién lo pidió.
