**No publiqué la ficha de PRD-300 (Venta en línea): la configuración no define una carpeta de productos publicados.**

`config.json` solo trae `paths.documents` y `paths.state`. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ni inventé ninguna carpeta; no escribí ningún archivo de ficha.

Términos: ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

**La ficha que se publicaría, con corte al 2026-10-18** (calculada con `compute` y `publish`):

**Llevaría:** 15 requerimientos · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Pequeños negocios
**Métricas:** volumen_mensual = 162820, del documento `00-definicion/2026-05-30-caso-de-negocio.md` (2026-05-30)

Los 15 requerimientos (REQ-2028, REQ-4000 a REQ-4013) están en estado «aceptado» y ninguno tiene proyecto que lo ejecute. Cuando se publique, `/product-overlap` solo podrá cruzar la métrica y el segmento, no proyectos compartidos.

**Para desbloquear:** acordar la carpeta común (por ejemplo `productos/publicados/`), configurarla y volver a correr el comando; entonces escribiría `PRD-300.json` ahí.
