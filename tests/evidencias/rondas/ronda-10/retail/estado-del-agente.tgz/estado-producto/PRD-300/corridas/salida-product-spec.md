> **Borrador de trabajo, no una especificación aprobada.** Lo cierra Diana Molina (gerente de producto); la aprobación es del Comité de producto, y este agente no puede darla.

# Especificación — Venta en línea (PRD-300) · borrador del 2026-10-18

## Qué problema resuelve

«El segmento Pequeños negocios no tiene venta en línea.» (`00-definicion/2026-05-30-definicion-producto.docx`). La definición no dice qué significa que el problema esté resuelto: el criterio de éxito del producto **no está en ningún documento**. La propuesta de la definición es una sola línea («Propuesta principal»), sin contenido.

## Alcance

### Entra
Los 15 requerimientos en `aceptado` del registro, según el acta del comité del 2026-10-13: REQ-4000 a REQ-4013 y REQ-2028. **Entran solo por estar aceptados, no porque se sepa qué piden** (ver Comportamiento).

### No entra
- Cualquier requerimiento que no esté en `aceptado` o `en_construccion`: el registro no trae ninguno.
- Lo que la definición no menciona. No hay documento que diga qué queda fuera del producto; esta lista no se puede escribir desde el registro y la tiene que escribir quien decide el alcance (Diana Molina).
- Diseño, arquitectura, estimación, costo y fechas: no son de este documento.

## Comportamiento

**No se puede redactar.** Los 15 requerimientos tienen como título «Requerimiento REQ-xxxx» y ninguno tiene su necesidad escrita (`need: no encontrado` en los 15). Describir qué hace cada uno sería inventarlo. La única cita de necesidad que existe es una frase de un cliente anónimo, «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2025-08-30-entrevistas.docx`), que no dice qué es «lo». Cubre: ninguno.

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4001, 4002, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4010, 4012 (11) | No hay forma: no dice qué se observa, ni cuánto, ni quién decide que pasó. Dos personas mirando lo construido no llegarían a la misma respuesta. | **No es un criterio.** Es el lugar donde iría uno; fuente: `30-decisiones/2026-10-13-comite-producto.docx` |
| *(sin criterio)* | REQ-4000, 4011, 4013, 2028 (4) | — | — |

No propongo criterios medibles: sin saber qué pide cada requerimiento, cualquier cifra (p. ej. «menos de 3 s en el percentil 95») sería inventada. Tampoco hay constancia de que la organización mida hoy algo de producción: la carpeta de métricas del estado está vacía.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El cliente paga por la entrega rápida» (declarado 2026-03-21) | **Marcado como verificado, pero no se sostiene como demanda:** se verificó el 2026-09-14 contra el documento técnico del proveedor, no contra evidencia de clientes (`00-definicion/2026-09-14-verificacion-supuesto.md`). Un documento del proveedor dice qué se puede entregar, no que alguien pague por ello. Se trata como **no verificado**. | Diana Molina, con evidencia de demanda (entrevistas, ventas, pruebas de precio) |
| «El volumen mensual es 162.820» (`caso-de-negocio.md`) | La fuente que cita la cifra es el propio caso de negocio, de la misma fecha: es circular. No hay serie medida. | Diana Molina (autora del caso) con un dato medido |

Además, la única entrevista es de 2025-08-30 (más de 13 meses; el umbral configurado es 12), es una sola persona sin nombre, y el registro la vincula a 9 requerimientos solo porque el acta dice «Cliente entrevistado» como solicitante.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada uno de los 15 requerimientos (título y necesidad) | No hay especificación posible; el equipo construiría lo que cada uno imagine | El doliente de cada uno (ver tabla de dolientes abajo) |
| Criterio de aceptación en REQ-4000, 4011, 4013, 2028 | Nadie podrá decir cuándo están terminados | Camilo Beltrán (4000), Paula Céspedes (4011), Ricardo Salas (4013), Andrés Lozano (2028) |
| Criterio verificable en los otros 11 («se verifica en producción») | Se discutirá si quedó bien después de construir | Los dolientes: Andrés Lozano (4001), Diana Molina (4002, 4007), Sandra Gil (4003, 4006), Ricardo Salas (4004), Camilo Beltrán (4005), Mauricio Pérez (4008), Gustavo Neira (4009), Elena Duarte (4010), Javier Hoyos (4012) |
| Quién pidió REQ-4001, 4003, 4004, 4009, 4011, 4012 (6 aceptados sin solicitante) | Aceptados sin que conste que alguien los pidió | Diana Molina |
| Quién decidió la aceptación: el acta no nombra a quien decide, y el único asistente es Diana Molina (`autoridad`: el config dice «Comité de producto», la definición no la declara) | No consta quién tiene la autoridad de lo aceptado | Comité de producto |
| Prioridad de los 15 (no hay ninguna) | Todos aceptados, ninguno ordenado | Diana Molina / Comité de producto |
| Criterio de éxito del producto | No se puede saber si el producto funcionó | Diana Molina |
| Casos borde (sin conexión, pago duplicado, abandono antes de la confirmación, etc.) | Comportamiento decidido por quien construya | Los dolientes, una vez exista la necesidad de cada requerimiento |
| Lo que otro equipo tiene que hacer: la definición dice «Proyectos que lo construyen: Ninguno declarado» y los 15 tienen «Proyecto que lo ejecuta: —». No hay constancia de acuerdo con ningún equipo | Lo aceptado no tiene quién lo construya | Diana Molina |
| Obligaciones normativas: la definición no dice si hay cobros, datos personales de clientes o consumidor financiero. No se corrió el barrido normativo porque no hay de qué partir; no se afirma que no apliquen | Una obligación puede aparecer en la construcción | Diana Molina, con el área legal |
| «Se mantiene el plan» (única decisión del acta): no hay plan en ningún documento | La decisión no se puede contrastar con nada | Diana Molina |

## Requerimientos aceptados que esta especificación no cubre

| ID | Título | Por qué no |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | Sin necesidad escrita ni criterio de aceptación |
| REQ-4000 | Requerimiento REQ-4000 | Sin necesidad escrita ni criterio de aceptación |
| REQ-4001 | Requerimiento REQ-4001 | Sin necesidad escrita; criterio no verificable; sin solicitante |
| REQ-4002 | Requerimiento REQ-4002 | Sin necesidad escrita; criterio no verificable |
| REQ-4003 | Requerimiento REQ-4003 | Sin necesidad escrita; criterio no verificable; sin solicitante |
| REQ-4004 | Requerimiento REQ-4004 | Sin necesidad escrita; criterio no verificable; sin solicitante |
| REQ-4005 | Requerimiento REQ-4005 | Sin necesidad escrita; criterio no verificable |
| REQ-4006 | Requerimiento REQ-4006 | Sin necesidad escrita; criterio no verificable |
| REQ-4007 | Requerimiento REQ-4007 | Sin necesidad escrita; criterio no verificable |
| REQ-4008 | Requerimiento REQ-4008 | Sin necesidad escrita; criterio no verificable |
| REQ-4009 | Requerimiento REQ-4009 | Sin necesidad escrita; criterio no verificable; sin solicitante |
| REQ-4010 | Requerimiento REQ-4010 | Sin necesidad escrita; criterio no verificable |
| REQ-4011 | Requerimiento REQ-4011 | Sin necesidad, criterio ni solicitante |
| REQ-4012 | Requerimiento REQ-4012 | Sin necesidad escrita; criterio no verificable; sin solicitante |
| REQ-4013 | Requerimiento REQ-4013 | Sin necesidad escrita ni criterio de aceptación |

Resultado: **0 de 15 cubiertos con comportamiento.** Es lo que el registro permite; rellenarlo daría un documento completo y falso.

## Después

No ofrezco `/product-charter`: con los vacíos abiertos y sin criterio de éxito del producto, no corresponde pasar a proyecto. Primer paso útil: que cada doliente escriba la necesidad de su requerimiento.

---
*Pie: sale del registro `estado-producto/PRD-300/requirements` (15 requerimientos, todos cubiertos por la revisión y ninguno cubierto por la especificación), construido sobre el acta del comité del 2026-10-13 y los documentos de `documentos/productos/PRD-300`; registro actualizado el 2026-10-18. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-18: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
