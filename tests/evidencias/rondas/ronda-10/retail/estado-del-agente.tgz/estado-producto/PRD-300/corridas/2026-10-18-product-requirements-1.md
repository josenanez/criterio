# Corrida del 2026-10-18 · product-requirements

PRD-300 · 15 requerimientos · 33 s · 34 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_acceptance` | 4 |

15 aceptados: 6 sin evidencia, 4 sin criterio de aceptación, 9 con evidencia vieja, 15 sin proyecto que los ejecute (fichas vacías)

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Registro — Venta en línea (PRD-300) · al 2026-10-18
15 requerimientos · 15 decididos · 60% con evidencia · 0% con proyecto que lo ejecuta

Los 15 están en estado `aceptado`; no hay ninguno propuesto, en construcción, entregado ni descartado. Las cifras salen de `producto.py compute`. La carpeta de fichas de proyectos (`estado/`) está vacía, así que el 0% significa «ninguna traza que confirmar», no que se haya comprobado que nadie lo construye.

### Se va a construir y nadie lo pidió
Aceptados sin una sola cita de quien lo pidió. Va primero. Quien lo cierra es el doliente; quien decide si se sostiene sin evidencia es el Comité de producto, que es la autoridad que dice la configuración.

| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4001 | Requerimiento REQ-4001 | aceptado (2026-07-12) | Andrés Lozano |
| REQ-4003 | Requerimiento REQ-4003 | aceptado (2026-05-05) | Sandra Gil |
| REQ-4004 | Requerimiento REQ-4004 | aceptado (2026-08-10) | Ricardo Salas |
| REQ-4009 | Requerimiento REQ-4009 | aceptado (2026-04-11) | Gustavo Neira |
| REQ-4011 | Requerimiento REQ-4011 | aceptado (2026-05-09) | Paula Céspedes |
| REQ-4012 | Requerimiento REQ-4012 | aceptado (2026-08-22) | Javier Hoyos |

### Decidido y nadie lo está construyendo
Los 15 aceptados no tienen proyecto que los ejecute, y la carpeta de fichas está vacía. Ninguno puede confirmarse como en construcción.

| REQ | Título | Decidido el |
|---|---|---|
| REQ-4006 | Requerimiento REQ-4006 | 2026-03-31 |
| REQ-4009 | Requerimiento REQ-4009 | 2026-04-11 |
| REQ-4008 | Requerimiento REQ-4008 | 2026-04-20 |
| REQ-4003 | Requerimiento REQ-4003 | 2026-05-05 |
| REQ-4011 | Requerimiento REQ-4011 | 2026-05-09 |
| REQ-4013 | Requerimiento REQ-4013 | 2026-06-17 |
| REQ-4010 | Requerimiento REQ-4010 | 2026-06-23 |
| REQ-4001 | Requerimiento REQ-4001 | 2026-07-12 |
| REQ-4002 | Requerimiento REQ-4002 | 2026-07-23 |
| REQ-4007 | Requerimiento REQ-4007 | 2026-07-30 |
| REQ-4005 | Requerimiento REQ-4005 | 2026-08-06 |
| REQ-4000 | Requerimiento REQ-4000 | 2026-08-07 |
| REQ-4004 | Requerimiento REQ-4004 | 2026-08-10 |
| REQ-4012 | Requerimiento REQ-4012 | 2026-08-22 |
| REQ-2028 | Requerimiento REQ-2028 | 2026-10-08 |

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 15 tienen una persona como doliente.

### Sin criterio de aceptación
Solo los decididos. Los cuatro son aceptados.

| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado | Andrés Lozano |
| REQ-4000 | Requerimiento REQ-4000 | aceptado | Camilo Beltrán |
| REQ-4011 | Requerimiento REQ-4011 | aceptado | Paula Céspedes |
| REQ-4013 | Requerimiento REQ-4013 | aceptado | Ricardo Salas |

REQ-4011 aparece también en la primera tabla: sin criterio y sin evidencia.

### Decidido sin documento que lo respalde
`compute` no calcula esta señal. En `documentos/productos/PRD-300/30-decisiones/` hay un solo documento, `2026-10-13-comite-producto.docx`. Las 15 decisiones tienen fecha anterior a ese acta (la más reciente es del 2026-10-08), y no se ha comprobado que el acta recoja alguna de ellas. No se afirma ni que estén respaldadas ni que no.

### Lleva meses y nadie lo decide
Ninguno: no hay requerimientos en estado `propuesto`.

### Evidencia vieja
Nueve requerimientos se sostienen solo en lo más nuevo de 2025-08-30, hace 13 meses (el umbral es 12).

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2028 | 2025-08-30 | 13 meses |
| REQ-4000 | 2025-08-30 | 13 meses |
| REQ-4002 | 2025-08-30 | 13 meses |
| REQ-4005 | 2025-08-30 | 13 meses |
| REQ-4006 | 2025-08-30 | 13 meses |
| REQ-4007 | 2025-08-30 | 13 meses |
| REQ-4008 | 2025-08-30 | 13 meses |
| REQ-4010 | 2025-08-30 | 13 meses |
| REQ-4013 | 2025-08-30 | 13 meses |

Los nueve citan la misma frase: «Lo necesito y hoy no lo tengo». El acta de las entrevistas la atribuye a «Cliente entrevistado», sin nombrar al cliente ni vincularla a un requerimiento concreto. Es evidencia genérica repetida, no una por requerimiento.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 0 | 15 | 0 | 0 | 0 |

## Qué sigue
Hay 15 decididos que nadie está construyendo: corresponde `/product-trace`. Aceptados con evidencia y criterio pero con la evidencia vieja, como REQ-4002, REQ-4005, REQ-4006, REQ-4007, REQ-4008 y REQ-4010, pueden ir a `/product-charter` cuando alguien renueve la evidencia.

Vacíos que `compute` no puede calcular y quedan sin dato: `success` (criterio de éxito de la definición) y `authority` (el estado no la trae, aunque la configuración dice Comité de producto).
