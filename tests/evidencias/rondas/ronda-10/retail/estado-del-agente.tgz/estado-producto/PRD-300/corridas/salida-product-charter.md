# Acta de constitución — Venta en línea (REQ-4000) · borrador del 2026-10-18
**Producto:** PRD-300 Venta en línea · **Requerimientos:** REQ-4000

> Sesión de prueba sin interfaz: términos vigentes (v1.1, familia 0.5.0), ya registrados a nombre de José Francisco Ñáñez el 2026-10-18. En cada pregunta se tomó la respuesta sugerida.

## Verificación previa (paso 1)
| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | **Cumple.** Estado «aceptado» desde 2026-08-07 (30-decisiones/2026-10-13-comite-producto.docx). |
| Criterios de aceptación verificables | **Falta.** El comité muestra «—» para REQ-4000. |
| Evidencia de demanda con cita | **Débil.** Una cita («Lo necesito y hoy no lo tengo», 10-descubrimiento/2025-08-30-entrevistas.docx) de un «Cliente entrevistado» sin nombre, sin vínculo a este requerimiento y con 13,6 meses de antigüedad (umbral: 12). |
| Autoridad declarada en la definición | **Falta.** La ficha del producto la tiene en `not_found`. La configuración dice «Comité de producto», pero la definición no lo dice. |

Se sigue sin ellos (respuesta sugerida): los cuatro quedan como vacíos del acta, no rellenados.

## Qué problema resuelve
«El segmento Pequeños negocios no tiene venta en línea.» (00-definicion/2026-05-30-definicion-producto.docx). Qué necesidad concreta cubre REQ-4000: **no está dicho en ningún documento** (campo `need` vacío; el título es solo «Requerimiento REQ-4000»).

## Criterio de éxito
**No hay.** REQ-4000 no tiene criterios de aceptación y la definición del producto no declara criterio de éxito. Sin esto el cierre no se podrá juzgar.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Una cita sin nombre ni vínculo (2025-08-30), vencida por antigüedad. Doliente: Camilo Beltrán. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4001 a REQ-4013, REQ-2028 | (los demás del comité del 2026-10-13) | Esta acta solo cubre REQ-4000. Ninguno tiene proyecto asignado; el motivo de dejarlos fuera es el alcance del argumento, no una decisión del comité. **El comité no lo ha dicho.** |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no se nombra; esa decisión es de quien tiene la autoridad. Para contexto, el gerente del producto es Diana Molina (definición, 2026-05-30), y no consta que sea gerente del proyecto.
- **Comité:** Comité de producto (configuración). La asistencia del 2026-10-13 fue solo Diana Molina.
- **Autoridad del gerente del proyecto:** no está dicho.
- **Quién decidió aceptar REQ-4000:** no consta (`decision.who` vacío). Fecha: 2026-08-07.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El cliente paga por la entrega rápida (declarado 2026-03-21) | Marcado como verificado el 2026-09-14, **pero con el documento técnico del proveedor, no con evidencia de demanda de clientes** (00-definicion/2026-09-14-verificacion-supuesto.md). Se trata como no verificado en lo que importa. | Sin doliente asignado: lo propone el acta, lo asigna el gerente del proyecto. |
| La cifra de volumen mensual 162.820 sostiene el caso | Sin contraste contra datos medidos; solo declarada (00-definicion/2026-05-30-caso-de-negocio.md). | Ídem. |

Además, REQ-4000 no declara supuestos propios.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Venta en línea | No se hizo barrido: ningún documento describe qué datos o pagos maneja REQ-4000. | — | **Sin barrido.** Hay que hacerlo cuando REQ-4000 diga qué construye. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Necesidad concreta de REQ-4000 | El proyecto arranca sin saber qué construye. | Camilo Beltrán (doliente) |
| Criterios de aceptación | No hay criterio de éxito; el cierre no se puede juzgar. | Camilo Beltrán con Diana Molina |
| Evidencia de demanda vinculada y vigente | La aceptación descansa en una cita anónima de hace 13,6 meses. | Diana Molina |
| Autoridad declarada | El gerente no sabrá qué puede decidir: escala todo o nada. | Comité de producto |
| Quién aceptó REQ-4000 | No se sabe quién tomó la decisión. | Comité de producto |
| Patrocinador | Nadie responde por el presupuesto ni los cambios de alcance. | Comité de producto |
| Presupuesto e hitos | El acta no declara ninguno. | Patrocinador, cuando exista |

---
**Esto es un borrador.** Lo firma una persona con autoridad (por determinar; no consta quién). **La ficha del proyecto no se creó** (se crea después de la firma, con `portafolio.py init`) y `declared` quedará siempre vacío para el gerente.

**Qué sigue:** quien sea nombrado gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza y Alba sabrá si el producto se está construyendo.
