## Definición — Venta en línea (PRD-300) · contrastada al 2026-10-18
**Documento:** 00-definicion/2026-05-30-definicion-producto.docx · **del** 2026-05-30 · 6 afirmaciones (más el caso de negocio del mismo día y el anexo de verificación del 2026-09-14)

*Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.*
*Esto es un borrador de trabajo. Cada dato lleva la cita del documento; la verificación es de quien lo lee.*

### Lo que la evidencia contradice
Nada. Ningún documento de la carpeta dice lo contrario de lo que afirma la definición. Eso no significa que esté sostenida: casi todo cae en las secciones de abajo.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa el umbral (20 %), porque no hay nada medido con qué compararla |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 162.820 | 00-definicion/2026-05-30-caso-de-negocio.md, tabla «Cifras que sostienen el caso» (2026-05-30) | PRD-300 no tiene carpeta `20-metricas` ni ninguna serie medida. El cálculo devuelve `measured: null`. No es contradicción: nadie mide lo que el caso de negocio afirmó. Además la fuente que cita la cifra es el propio caso de negocio (se cita a sí mismo), y no dice 162.820 de qué ni de quién. |

### No está dicho en ninguna parte
- **La propuesta.** La definición tiene el encabezado «La propuesta» con una sola viñeta, «Propuesta principal», sin contenido. No dice qué se va a construir.
- **Cuántos pequeños negocios tienen el problema, ni cuántos lo han pedido.** «El segmento Pequeños negocios no tiene venta en línea» se afirma sin cifra ni fuente.
- **Qué pagaría el cliente ni cuánto.** El supuesto habla de entrega rápida, pero ningún documento dice un precio, una tarifa o un ingreso.
- **El retorno.** El caso de negocio dice «Retorno esperado en 24 meses» y no da una cifra, una base ni un cálculo.
- **Que el cliente entrevistado sea un pequeño negocio.** El acta de entrevistas (2025-08-30) deja la cita «Lo necesito y hoy no lo tengo» atribuida a «Cliente entrevistado», sin nombre, sin segmento y sin decir qué es «lo». No se asume que sea de este segmento ni de este producto.
- **Quién decide.** La configuración nombra al «Comité de producto» como autoridad; ningún documento de la definición lo dice (el cálculo trae `authority: null`).
- **El criterio de éxito.** Ver el final.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «El cliente paga por la entrega rápida» · declarado el 2026-03-21 | El registro lo da por verificado, así que el cálculo no lo marca. Lleva 211 días declarado y 34 desde el «se confirmó» del 2026-09-14. | La verificación citada es el documento técnico **del proveedor** (anexo del 2026-09-14, que dice solo «se confirmó» sin decir qué mostró el documento). Un documento del proveedor sirve para saber si la entrega rápida se puede dar, no si el cliente paga por ella. Por la jerarquía de demand-evidence, para sostenerlo hace falta que alguien haya pagado por entrega rápida (ventas, cobros, un piloto) o, como mínimo, un cliente identificado diciendo cuánto pagaría. Mientras tanto queda como supuesto con una verificación que no es de demanda. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe una necesidad de venta en línea («Lo necesito y hoy no lo tengo») | 10-descubrimiento/2025-08-30-entrevistas.docx, una cita de un cliente sin nombre | 2025-08-30 | Débil: una sola cita dicha, sin pago ni compromiso, de un cliente anónimo, y no se ve que sea del segmento. Es lo más bajo de la jerarquía. |

No hay en la carpeta evidencia de que alguien haya pagado, firmado una carta de intención o usado un piloto.

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema / la necesidad | Entrevista del 2025-08-30 | 13 meses (el umbral son 12) |

Es la única evidencia de demanda de la carpeta; así que toda ella está envejecida. El cálculo marca además `evidence_stale` en 9 de los 15 requerimientos aceptados, todos apoyados en esa misma cita.

### Lo normativo que toca
La definición no dice qué datos recoge, cómo se cobra ni en qué país opera. Lo de abajo sale de lo que una venta en línea suele implicar, **no de lo que el documento declara**. No se cita ninguna norma porque ningún documento de la carpeta la trae ni el país está declarado.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos de compradores y de los pequeños negocios (inferido) | no declarado | Tratamiento de datos personales: autorización y finalidad | — | no tengo la norma a la vista |
| Cobro de la venta en línea (inferido) | no declarado | Medios y sistemas de pago | — | no tengo la norma a la vista |
| Venta a consumidores y entrega rápida (inferido) | no declarado | Protección al consumidor en comercio electrónico | — | no tengo la norma a la vista |
| Conservación de las transacciones (inferido) | no declarado | Retención y trazabilidad | — | no tengo la norma a la vista |

Este barrido va a revisión jurídica; no dice si el producto cumple y no la reemplaza. Lo primero que hace falta es declarar el país.

### Lo que falta para cerrar la definición
- **Criterio de éxito: no está declarado** (`success: null`). Sin él la definición no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Quién decide:** no consta en los documentos (ver arriba).
- **Para quién:** está («Pequeños negocios»), pero sin tamaño ni evidencia de que el entrevistado lo sea.
- **El problema:** está escrito en una frase, sin cifra.
- Además, la propuesta está vacía y la definición declara «Proyectos que lo construyen: Ninguno declarado», mientras el comité del 2026-10-13 mantuvo el plan con 15 requerimientos aceptados y ninguno trazado a un proyecto.

**Después:** el supuesto del cliente que paga por la entrega rápida puede pasar a riesgo con doliente (raid-taxonomy) si se quiere. La definición no está cerrada, así que no se ofrece `/product-charter`.
