<!-- origen: 30-decisiones/2026-10-13-comite-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de producto · Venta en línea

Fecha: 2026-10-13

Asistentes: Diana Molina

Requerimientos revisados

ID

Requerimiento

Doliente

Criterio de aceptación

Quién lo pidió

Estado

Desde

Proyecto que lo ejecuta

REQ-4000

Requerimiento REQ-4000

Camilo Beltrán

—

Cliente entrevistado

aceptado

2026-08-07

—

REQ-4001

Requerimiento REQ-4001

Andrés Lozano

se verifica en producción

—

aceptado

2026-07-12

—

REQ-4002

Requerimiento REQ-4002

Diana Molina

se verifica en producción

Cliente entrevistado

aceptado

2026-07-23

—

REQ-4003

Requerimiento REQ-4003

Sandra Gil

se verifica en producción

—

aceptado

2026-05-05

—

REQ-4004

Requerimiento REQ-4004

Ricardo Salas

se verifica en producción

—

aceptado

2026-08-10

—

REQ-4005

Requerimiento REQ-4005

Camilo Beltrán

se verifica en producción

Cliente entrevistado

aceptado

2026-08-06

—

REQ-4006

Requerimiento REQ-4006

Sandra Gil

se verifica en producción

Cliente entrevistado

aceptado

2026-03-31

—

REQ-4007

Requerimiento REQ-4007

Diana Molina

se verifica en producción

Cliente entrevistado

aceptado

2026-07-30

—

REQ-4008

Requerimiento REQ-4008

Mauricio Pérez

se verifica en producción

Cliente entrevistado

aceptado

2026-04-20

—

REQ-4009

Requerimiento REQ-4009

Gustavo Neira

se verifica en producción

—

aceptado

2026-04-11

—

REQ-4010

Requerimiento REQ-4010

Elena Duarte

se verifica en producción

Cliente entrevistado

aceptado

2026-06-23

—

REQ-4011

Requerimiento REQ-4011

Paula Céspedes

—

—

aceptado

2026-05-09

—

REQ-4012

Requerimiento REQ-4012

Javier Hoyos

se verifica en producción

—

aceptado

2026-08-22

—

REQ-4013

Requerimiento REQ-4013

Ricardo Salas

—

Cliente entrevistado

aceptado

2026-06-17

—

REQ-2028

Requerimiento REQ-2028

Andrés Lozano

—

Cliente entrevistado

aceptado

2026-10-08

—

Decisiones

• Se mantiene el plan
