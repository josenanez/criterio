<!-- origen: 00-definicion/2026-05-30-caso-de-negocio.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2026-05-30
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 162.820 | Caso de negocio, 2026-05-30 |

## Retorno esperado

Retorno esperado en 24 meses.
