# Corrida del 2026-10-18 · product-trace

PRD-300 · 15 requerimientos · 26 s · 34 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 15 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_without_acceptance` | 4 |

15 requerimientos decididos y ninguno con proyecto; PRY-200 dice ejecutar «venta en línea» y ningún REQ lo nombra

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Venta en línea (PRD-300) · al 2026-10-18
15 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Los 15 requerimientos están aceptados y ninguno tiene proyecto: la columna «Proyecto que lo ejecuta» del acta del comité del 2026-10-13 (`30-decisiones/2026-10-13-comite-producto.docx`) es «—» en todos.

| REQ | Título | Decidido el | Por quién (doliente) |
|---|---|---|---|
| REQ-4006 | Requerimiento REQ-4006 | 2026-03-31 | Sandra Gil |
| REQ-4009 | Requerimiento REQ-4009 | 2026-04-11 | Gustavo Neira |
| REQ-4008 | Requerimiento REQ-4008 | 2026-04-20 | Mauricio Pérez |
| REQ-4003 | Requerimiento REQ-4003 | 2026-05-05 | Sandra Gil |
| REQ-4011 | Requerimiento REQ-4011 | 2026-05-09 | Paula Céspedes |
| REQ-4013 | Requerimiento REQ-4013 | 2026-06-17 | Ricardo Salas |
| REQ-4010 | Requerimiento REQ-4010 | 2026-06-23 | Elena Duarte |
| REQ-4001 | Requerimiento REQ-4001 | 2026-07-12 | Andrés Lozano |
| REQ-4002 | Requerimiento REQ-4002 | 2026-07-23 | Diana Molina |
| REQ-4007 | Requerimiento REQ-4007 | 2026-07-30 | Diana Molina |
| REQ-4005 | Requerimiento REQ-4005 | 2026-08-06 | Camilo Beltrán |
| REQ-4000 | Requerimiento REQ-4000 | 2026-08-07 | Camilo Beltrán |
| REQ-4004 | Requerimiento REQ-4004 | 2026-08-10 | Ricardo Salas |
| REQ-4012 | Requerimiento REQ-4012 | 2026-08-22 | Javier Hoyos |
| REQ-2028 | Requerimiento REQ-2028 | 2026-10-08 | Andrés Lozano |

El más antiguo lleva más de 6 meses decidido sin proyecto (REQ-4006, 2026-03-31).

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar, porque ningún REQ nombra un proyecto.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-200 · Tienda en línea | producto: «venta en línea» (acta de constitución, 2026-01-10) | Sí: ningún REQ de PRD-300 nombra PRY-200 |

La coincidencia es por nombre, no por código: la ficha no trae «PRD-300». Es un candidato a verificar, no una traza confirmada. Es probable que PRY-200 esté construyendo parte de lo decidido sin que el registro lo sepa.

Las fichas de PRY-203, PRY-206, PRY-209, PRY-210 y PRY-211 no dicen qué producto ejecutan (hallazgo del otro lado, no de este registro); no se les puede atribuir ni descartar relación con PRD-300.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| Los 15 (REQ-2028, REQ-4000 a REQ-4013) | aceptado | comité de producto, fechas arriba | — | No | — |

La cadena se rompe en el segundo eslabón: de la decisión al proyecto. Las fichas se leyeron (13, en `estado/records`); ninguna nombra un REQ.

### Sin fichas a la vista
Todas las fichas disponibles se pasaron al cálculo. No se puede confirmar nada porque no hay trazas declaradas, no por falta de fichas.

### Cobertura
Con evidencia de demanda: 9 de 15 (60 %); trazados: 0 de 15 (0 %). Cada uno de los 15 lleva además la señal `requirement_untraced`.

Si alguno ya está listo para volverse proyecto, `/product-charter`. Si PRY-200 resulta ser el que lo construye, la conversación es con su gerente de proyecto.
