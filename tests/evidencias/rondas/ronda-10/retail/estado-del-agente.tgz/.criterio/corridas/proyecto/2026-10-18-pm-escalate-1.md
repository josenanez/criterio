# Corrida · 2026-10-18-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:47:41 · **Fin:** 2026-10-18T08:48:50 · **Duración:** 69 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 53 | 22 | Paquete de 4 puntos: autoridad no declarada en el acta, factura FV-1980 de CT-980 sin acta de recibo, CC-01 sin firma ni línea base de costo, dos compromisos reprogramados 5 y 6 veces. No sé: vencimiento y estado de pago de FV-1980, cláusulas de multa de CT-980, quién firmó CC-01, dependencias de otros proyectos; no se estimaron costos de opciones sin dato. |

Por señal (`pm-escalate`): `commitment_overdue` 6, `vendor_deliverable_late` 4, `milestone_met_without_evidence` 3, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_time` 1, `progress_vs_plan` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-206 y dejé la corrida registrada (`2026-10-18-pm-escalate-1`).

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-18, v0.5.0), así que no los registré de nuevo. Como no había tema en la invocación, usé lo que ya estaba marcado como escalable en el informe y la agenda de hoy. El paquete tiene cuatro puntos:

0. **Autoridad del gerente:** el acta no declara ninguna facultad de decisión. Es el primer punto: sin esa tabla, cualquiera de los otros se puede devolver con un «eso lo decide usted». La pregunta para el Comité de Expansión es si adopta la tabla como adenda al acta.
1. **Factura FV-1980 de CT-980 (599.677.238 COP):** el contrato la condiciona a un acta de recibo firmada por el gerente, y no hay ninguna. Hay tres opciones: retener, pagar y regularizar después, o reclamar. Recomiendo retener, con el reclamo preparado.
2. **CC-01 (+53 días, +106.000.000 COP):** dice «autorizada por el comité» sin decir cuál comité, quién firmó ni qué alcance agrega, y no hay línea base de costo. Recomiendo ratificarla solo si el comité describe el alcance.
3. **Compromisos reprogramados:** «Enviar el documento 1» (Liliana Torres, 6 veces) y «Cerrar la prueba 2» (Paula Céspedes, 5 veces). Recomiendo una fecha límite y un responsable de destrabar con nombre.

El cálculo de efecto con +53 días no alcanza a ningún otro proyecto. Eso solo significa que la carpeta de estado contiene únicamente PRY-206 y que el acta dice «Ninguna dependencia declarada». Tampoco pasa por ningún hito más: solo por «Despliegue en la cadena». El cálculo no dice cuántos días se mueve cada proyecto alcanzado, porque la ficha no tiene holgura por actividad.

No pude responder, y el paquete lo dice:
- el vencimiento y el estado de pago de FV-1980, así que no hay fecha de consecuencia para el punto 1;
- si CT-980 tiene cláusulas de multa o de terminación;
- quién firmó CC-01;
- qué costo tiene cada opción donde no hay dato, que dejé como «sin dato» y no estimé.

No incluí los vencidos de Hoyos, Medina, Torres, Salas y Gil, ni los compromisos sin fecha, porque se resuelven en la reunión o con una llamada.

Archivos en `/home/claude/banco/ronda-10/retail/espacio/estado/PRY-206-precios-dinámicos/corridas/`:
- `salida-pm-escalate.md`
