# Corrida · 2026-10-18-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-210 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-18T09:08:15 · **Fin:** 2026-10-18T09:08:59 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 28 | 63 | Revisión del acta PRY-210 (2025-12-15): sin autoridad del gerente, alcance/exclusiones con texto de plantilla, éxito no medible, sin quien mida; atrasos de hitos sin replanificación; no se redactó nada. No sé si existen anexos fuera de la carpeta. |

Por señal (`project-charter`): `milestone_met_without_evidence` 21, `commitment_overdue` 9, `progress_vs_plan` 7, `vendor_deliverable_late` 6, `declared_vs_evidence` 5, `commitment_undated` 4, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `vendor_invoiced_over_accepted` 1, `milestone_overdue` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1, `change_without_baseline` 1

## Lo que el agente mostró

Hay acta previa de PRY-210, del 2025-12-15. La revisé y no redacté nada. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hizo falta registrarlos de nuevo.

**Qué falta en el acta y qué consecuencia tiene**
- **Autoridad del gerente:** no existe. Ningún documento dice hasta qué monto ni qué cambio de fechas o alcance decide Óscar Ramírez sin subir al Comité Comercial.
- **Objetivo de negocio:** solo repite la solución ("Entregar etiquetas electrónicas de precio"). No hay nada contra qué medir si el proyecto sirvió.
- **Alcance y exclusiones:** son texto de plantilla ("Componente 1, 2, 3" y "Lo que otro proyecto cubre"). Ningún cambio de alcance se puede reconocer como tal.
- **Criterio de éxito:** "En producción y medido" no es medible, y nadie queda como responsable de medirlo.
- **Supuestos y restricciones:** no existen. Las dependencias dicen "Ninguna declarada", pero el informe del 2026-10-15 reporta que el proveedor no ha confirmado su última entrega.
- **Cadencia del comité e hitos:** el acta no escribe la cadencia, y los hitos están solo en el cronograma v1.

**Lo que el acta vacía deja a la vista en los otros documentos**
- **Atrasos sin replanificar:**
  - El diseño se recibió el 2026-10-06 y estaba previsto para el 2026-04-15, unos 174 días de atraso.
  - El ambiente de pruebas se recibió el 2026-10-18 y estaba previsto para el 2026-08-04, unos 75 días.
  - El cronograma sigue con fecha vigente igual a la línea base.
- **Estado declarado:** el informe del 2026-10-15 dice Verde y 79% de avance. Ese mismo informe reporta una prueba de carga fallida y dos semanas perdidas.
- **Presupuesto:** comprometido más ejecutado suman 4.004.902.578 COP, y la proyección al cierre es 3.915.554.441. No concilian; lo dejo para budget-tracking.

No sé si hay otra acta o anexo fuera de la carpeta, ni qué se habló en el comité fuera de los documentos.

**Siguientes pasos que ofrezco**
- Llevar la definición de la autoridad del gerente al próximo Comité Comercial (2026-10-25), como decisión.
- Pasar al registro RAID la dependencia del proveedor, la prueba de carga repetida y la rotación del desarrollador clave.

La corrida quedó registrada como `2026-10-18-project-charter-1` (28 segundos). El conteo de hallazgos que devolvió el script cubre los 13 proyectos del portafolio. PRY-210 figura sin señales de otros comandos.

Archivos en `/home/claude/banco/ronda-10/retail/espacio/estado/corridas/`:
- `salida-project-charter.md`
