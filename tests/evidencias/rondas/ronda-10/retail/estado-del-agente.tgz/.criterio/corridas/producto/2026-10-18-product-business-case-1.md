# Corrida · 2026-10-18-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:35:48 · **Fin:** 2026-10-18T08:36:34 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 15 | — | 30 | 34 | Caso armado con 1 cifra declarada (volumen_mensual 162.820, que se cita a sí misma) y 0 medidas. Dijo que no sabe: costo de construir, monto del retorno, criterio de éxito, serie medida, fecha de corte; supuesto verificado solo con documento del proveedor; 6 requerimientos sin cita; cruce con otros productos no posible (estado/ vacío). |

Por señal (`product-business-case`): `requirement_untraced` 15, `evidence_stale` 9, `requirement_accepted_without_evidence` 6, `requirement_without_acceptance` 4

## Lo que el agente mostró

# Caso de negocio — Venta en línea (PRD-300) · borrador del 2026-10-18

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18, así que no hubo que registrar nada nuevo.

**Resultado: esto es una propuesta, no un caso de negocio evaluable.** El documento tiene 1 cifra con fuente, y es declarada, no medida. El borrador completo está en `estado-producto/PRD-300/corridas/salida-product-business-case.md`.

- **Problema y segmento:** "El segmento Pequeños negocios no tiene venta en línea" (definición, 2026-05-30). La propuesta dice solo "Propuesta principal", sin contenido, y no hay criterio de éxito en ningún documento.
- **Qué se construye:** los 15 requerimientos están aceptados y ninguno tiene proyecto que lo ejecute.
  - Nueve citan la misma frase de las entrevistas del 2025-08-30: "Lo necesito y hoy no lo tengo". Tiene 13 meses, y el umbral es 12.
  - Seis no tienen ninguna cita de quién los pidió.
  - Cuatro no tienen criterio de aceptación.
- **Cifras:**
  - `volumen_mensual` = 162.820. Es una cifra declarada, y su fuente es el propio caso de negocio, que la cita a sí misma. No dice qué se cuenta.
  - Retorno esperado: dice "en 24 meses", sin monto, base ni método. No lo traté como cifra.
  - No hay ninguna cifra medida, así que no pude contrastar lo declarado contra una serie.
- **Costos:** no hay costo de construir, contratos, cotizaciones ni costo del equipo en ningún documento. Es el primer vacío.
- **Supuesto "El cliente paga por la entrega rápida":** figura como verificado el 2026-09-14, pero con el documento técnico del proveedor, no con evidencia de demanda de clientes. Ese documento tampoco está en la carpeta.
- **Cómo se sabrá si funcionó:** no está declarado.
- **Otros productos publicados:** no hay ninguno a la vista, porque `estado/` está vacío. No se pudo hacer el cruce de overlap.

El borrador no calcula ingreso, retorno ni recuperación de la inversión, y no recomienda aprobar ni rechazar. Eso le toca al Comité de producto.

Registré la corrida como `2026-10-18-product-business-case-1` (30 segundos, 15 requerimientos, 34 hallazgos). Como siguiente paso, puedo pasar los supuestos a seguimiento con assumption-tracking.
