# Corrida · 2026-10-18-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-307

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-307

**Inicio:** 2026-10-18T09:16:15 · **Fin:** 2026-10-18T09:16:24 · **Duración:** 9 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No hay configuración para PRD-307: solo existe `.criterio/producto/PRD-300/config.json`, es decir, un producto configurado y con otro código. No la busco en otro sitio ni la invento, y no sustituyo PRD-307 por PRD-300 sin que lo pidan.

Me detengo aquí. No corrí `terminos`, `overlap` ni `corrida`, y no se registró nada.

Para seguir hay dos caminos:
- Correr `/criterio-product:product-setup` para PRD-307.
- Repetir `/criterio-product:product-overlap PRD-300`, si ese era el producto que querían.
