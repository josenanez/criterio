# Corrida · 2026-10-18-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:56:33 · **Fin:** 2026-10-18T08:57:04 · **Duración:** 30 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 17 | 63 | 83 documentos sin cambio, 0 por releer. 19 citas de PRY-206 sin el prefijo de carpeta del proyecto: no resuelven aunque los archivos existen. No se corrigió ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 21, `commitment_overdue` 9, `progress_vs_plan` 7, `vendor_deliverable_late` 6, `declared_vs_evidence` 5, `commitment_undated` 4, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `commitment_rescheduled` 2, `vendor_invoiced_over_accepted` 1, `milestone_overdue` 1, `variance_time` 1, `vendor_invoiced_without_delivery` 1, `change_without_baseline` 1

## Lo que el agente mostró

Terminé la corrida de `/document-index`, que quedó registrada como `2026-10-18-document-index-1`. No hay nada que releer, pero hay 19 citas rotas en PRY-206.

## Carpeta al 2026-10-18

- **Documentos:** 83. Los 83 están sin cambio, y hay 0 por releer.
- **Contenido cambiado, reguardados, renombrados, borrados:** ninguno.
- **Formatos ilegibles:** el índice no reporta ninguno.
- **Citas que dejaron de resolver:** 19 campos, todos de PRY-206.
  - Las fichas de los otros proyectos, como PRY-203, citan con el prefijo `PRY-203-reposición-automática/…`. Las de PRY-206 citan sin el prefijo `PRY-206-precios-dinámicos/`.
  - Los archivos sí existen en la carpeta, así que lo que falla es la cita.
  - Los documentos citados son el acta de constitución, el informe de avance del 2026-10-15, el cronograma v2 y las facturas CT-847 y CT-980.
  - Mientras no se corrijan, el informe sigue mostrando esos datos como sustentados aunque su cita no se pueda abrir.

No hace falta `/portfolio-scan`, porque no hay documentos por releer. Queda pendiente corregir las 19 citas de PRY-206, de una en una y mostrando cada cambio. No toqué ninguna ficha.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no volví a registrarlos.

La salida completa quedó en `estado/corridas/salida-document-index.md`.
