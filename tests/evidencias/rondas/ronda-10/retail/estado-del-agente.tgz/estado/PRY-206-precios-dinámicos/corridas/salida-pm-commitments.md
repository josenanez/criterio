## Compromisos — PRY-206 Precios dinámicos · al 2026-10-18

23 compromisos abiertos: 6 vencidos sin evidencia, 3 sin fecha y 2 reprogramados más de tres veces. 3 cerrados con documento.

### Se viene reprogramando

> **Liliana Torres** · Enviar el documento 1
> Prometido para el 2026-09-13, y antes para el 09-30, el 10-09, el 10-16, el 11-02, el 11-19 y ahora el **2026-12-03** (6 reprogramaciones; la última se dijo hoy, en `2026-10-18-notas-reunion.txt`).
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Paula Céspedes** · Cerrar la prueba 2
> Prometido para el 2026-09-14, y antes para el 09-23, el 10-11, el 10-24, el 11-14 y ahora el **2026-11-25** (5 reprogramaciones, la última el 2026-10-11).
> **Cinco veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

Ambos pasan el umbral de 3 reprogramaciones que fija la configuración. Paula Céspedes es además la patrocinadora del proyecto (acta de constitución): el bloqueo está en quien debería destrabarlo.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 | 12 días |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 | 9 días |
| Javier Hoyos | Entregar el punto 16 | 2026-10-09 | 9 días |
| Liliana Torres | Actualizar la matriz 14 | 2026-10-11 | 7 días |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 | 3 días |
| Sandra Gil | Entregar el punto 24 | 2026-10-17 | 1 día |

Dos casos de «ya lo entregué» sin documento, que siguen abiertos:
- **Liliana Torres**, matriz 14 (vencida): dijo el 2026-10-04 que ya la entregó; no hay acta ni entregable en el expediente (`30-reuniones/2026-10-04-comite-semanal.md`). Dejó de aparecer en la lista desde ese día.
- **Carlos Peña**, matriz 6 (vence el 10-21) y **Jorge Medina**, prueba 18 (vence el 10-24): también dijeron que ya entregaron (comités del 09-27 y del 10-11) y tampoco hay documento. Siguen abiertos hasta que lo haya.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Carlos Peña | Enviar el documento 17 | 2026-10-18 (hoy) |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-21 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Jorge Medina | Cerrar la prueba 18 | 2026-10-24 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Paula Céspedes | Validar el ambiente 20 | 2026-10-04 |
| Beatriz Cuéllar | Confirmar la fecha 23 | 2026-10-11 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-18 |

No pueden estar vencidos, por eso se cuentan aparte. «La otra semana» no es una fecha: no se la inventé.

### Cerrados con documento
| Quién | Qué | Documento |
|---|---|---|
| María Restrepo | Revisar el anexo 3 | `20-seguimiento/2026-10-11-acta-recibo-3.md` |
| Jorge Medina | Aprobar el diseño 5 | `20-seguimiento/2026-09-20-acta-recibo-5.md` |
| Camilo Beltrán | Revisar el anexo 11 | `20-seguimiento/2026-10-04-acta-recibo-11.md` |

### Lo que sigue
- Los dos compromisos reprogramados pasan de tres veces. Puedo formularlos como decisión para el comité (`/pm-escalate`): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente, por eso sube.
- Los compromisos nuevos del 10-18 (Liliana Torres, Laura Vélez, Óscar Ramírez) ya están en la ficha. Si quieres que la PMO los vea, `/pm-publish`.
