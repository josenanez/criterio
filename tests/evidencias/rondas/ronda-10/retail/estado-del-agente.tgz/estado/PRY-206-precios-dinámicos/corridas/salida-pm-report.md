# Precios dinámicos (PRY-206) — corte al 2026-10-18

**Declara el gerente (esta semana):** SIN DECLARAR · la sesión no tuvo a nadie que declarara y el sistema no propone un estado. Línea en blanco, a propósito.
*Última declaración en los documentos (no es de hoy):* rojo · 47 % · al 2026-10-15 (`20-seguimiento/2026-10-15-informe-avance.pdf`), hace 3 días, vigente por umbral (14 días).
**Sustento documental:** de lo que declara el informe del 15-oct, el rojo está sostenido por las señales; no hay verde contradicho. Pero 0 fuentes son evidencia: 6 son declaración y 13 sin marcar.
**Lo que el semáforo no explica (contra el rojo del 15-oct):** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, avance por debajo del plan, desviación de tiempo, entregables de proveedor vencidos, facturado sin entrega (7 señales).

## Qué cambió esta semana
Primera corrida del informe: no hay corrida anterior contra la cual comparar (el diff dio 0 cambios contra el snapshot de hoy). Lo que entró en los últimos días y conviene mirar:
| Qué | Estaba | Está | |
|---|---|---|---|
| CC-01, ampliación de alcance (2026-10-17) | Línea base v1: cierre 2026-11-13 | Línea base v2: cierre 2027-01-05 (+53 días; +106.000.000 COP) | «el comité (el documento no dice cuál ni quién firmó)» |
| Acta de recibo del ambiente de pruebas (2026-10-15) | Hito sin evidencia | Hito con evidencia | único hito cumplido que sí la tiene |
| Notas del 2026-10-18 | — | Riesgo dicho y no registrado: el proveedor podría no llegar con el equipo completo; compromiso de Laura Vélez sin fecha | |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Diseño de la experiencia aprobado» cumplido sin evidencia | 2026-05-27 | 144 |
| Hito «Integración con el ERP» cumplido sin evidencia | 2026-08-20 | 59 |
| Hito «Piloto en tiendas» cumplido sin evidencia | 2026-10-02 | 16 |
| Licenciamiento (Tecnología para Tiendas, CT-980) pendiente | 2026-07-02 | 108 |
| Bolsa de horas (Sistemas Comerciales del Norte, CT-847) pendiente | 2026-07-17 | 93 |
| Configuración del catálogo (CT-847) pendiente | 2026-09-02 | 46 |
| Bolsa de horas (CT-980) pendiente | 2026-09-18 | 30 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-11-13 | 2027-01-05 | +53 días (25 %) contra la original; 0 contra la vigente |
| Presupuesto | 9.500.000.000 COP aprobado (acta) | sin línea base de costo v2 registrada; CC-01 pide +106.000.000 | proyección 9.737.352.769 = +2,5 % sobre lo aprobado |

Replanificaciones: 1 — 2026-10-17, CC-01, ampliación de alcance, +53 días. La desviación contra la vigente es 0 porque la vigente se movió con el atraso.
Avance: declarado 47 %, el plan sostiene entre 80 y 100 % (4 de 5 hitos cumplidos): 33 puntos por detrás.

### Hitos de las próximas cuatro semanas (hasta 2026-11-15)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Despliegue en la cadena | 2026-11-13 | 2027-01-05 | pendiente; salió de la ventana con CC-01 |

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 3.611.179.640 (38 %) | 2.375.369.823 (25 %) | 9.737.352.769 | 5.888.820.360 (aprobado − comprometido) |

Comprometido, ejecutado y proyectado son declaración del informe del 15-oct, no evidencia.

## Abierto
**Reprogramados:** Liliana Torres, «Enviar el documento 1», 6 veces (original 2026-09-13, hoy 2026-12-03) · Paula Céspedes, «Cerrar la prueba 2», 5 veces (original 2026-09-14, hoy 2026-11-25). Ambos son material de comité (umbral: 3).
**Vencidos sin evidencia:** Jorge Medina, Confirmar la fecha 7 (2026-10-06, 12 d) · Javier Hoyos, Validar el ambiente 4 (2026-10-09, 9 d) · Javier Hoyos, Entregar el punto 16 (2026-10-09, 9 d) · Liliana Torres, Actualizar la matriz 14 (2026-10-11, 7 d) · Ricardo Salas, Aprobar el diseño 13 (2026-10-15, 3 d) · Sandra Gil, Entregar el punto 24 (2026-10-17, 1 d).
**Sin fecha:** Paula Céspedes (Validar el ambiente 20), Beatriz Cuéllar (Confirmar la fecha 23), Laura Vélez (ajuste del presupuesto, «la otra semana»).
**RAID sin movimiento:** concentración del conocimiento en una persona y cambio regulatorio de datos personales (sin dueño, sin fecha, sin fecha de último movimiento); incidencia de rotación del desarrollador clave (sin dueño ni fecha de inicio). El riesgo del proveedor sin equipo completo salió de reunión y nadie lo registró.
**Proveedor:**
- Vencidos: CT-847, 2 (bolsa de horas, catálogo); CT-980, 2 (licenciamiento, bolsa de horas).
- Aceptado sin documento: CT-847, licenciamiento de la plataforma.
- Facturado sin entrega: CT-980, 599.677.238 COP facturados, 0 de 2 entregables aceptados.
- CT-847: 410.335.213 facturados = lo aceptado.

## Lo que necesito de alguien
- **Comité (excede al gerente):** quién autorizó CC-01 y firma que lo respalde; falta la línea base de costo con +106.000.000.
- **Comité:** los dos compromisos reprogramados 5 y 6 veces.
- **Comité / contratos:** factura de CT-980 sin entrega aceptada.
- Javier Hoyos, Jorge Medina, Liliana Torres, Ricardo Salas, Sandra Gil: evidencia o nueva fecha de lo vencido.
- Dueños de las actas de recibo de los hitos de diseño, ERP y piloto, y del licenciamiento de CT-847.
- Andrés Lozano: la declaración de estado de esta semana.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto; probabilidad, impacto y dueño de todos los riesgos; fecha de inicio de la incidencia.
**Silencio:** último documento hace 1 día (2026-10-17, CC-01) · última reunión de comité hace 7 días (2026-10-11); notas del 2026-10-18.

---
Ficha `estado/PRY-206-precios-dinámicos/records/PRY-206.json`, con corte al 2026-10-18. Campos sin dato: 3 (identity.product, identity.authority, identity.phase). Términos aceptados por José Francisco Ñáñez el 2026-10-18 (v0.5.0): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

Siguiente paso: hay dos compromisos reprogramados más de 3 veces y 25 % de desviación contra la original; puedo armar el punto de comité con la decisión formulada. Aquí no ofrezco `/pm-publish` por contradicción de la declaración porque no hay declaración nueva que contrastar.
