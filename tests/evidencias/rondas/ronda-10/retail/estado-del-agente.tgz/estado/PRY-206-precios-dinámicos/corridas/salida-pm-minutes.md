# Acta — Precios dinámicos (PRY-206) · 2026-10-18
**Asistieron (14):** Andrés Lozano, Carlos Peña, Diana Molina, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-18-notas-reunion.txt` (9 líneas) · **Ausentes con tema en agenda:** las notas no traen agenda, así que no se puede decir. Estuvieron en el comité del 2026-10-11 y hoy no: María Restrepo, Beatriz Cuéllar (tiene un compromiso abierto sin fecha) y Camilo Beltrán (venía del 09-27).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-12-03 | **Reprogramado por 6.ª vez.** Original 2026-09-13; luego 09-30, 10-09, 10-16, 11-02, 11-19 y ahora 12-03. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 03/12/2026» (línea 4). |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 | Nuevo. Las notas no dicen de cuál proveedor (hay dos con contrato: CT-847 y CT-980). Cita: «revisión con el proveedor, queda para el 2026-10-28» (línea 6). |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Cita: «queda de mandar el ajuste del presupuesto la otra semana» (línea 5). «La otra semana» no es una fecha; no se le calculó una. |

Con la misma condición siguen abiertos de reuniones anteriores: Paula Céspedes, *Validar el ambiente 20*, y Beatriz Cuéllar, *Confirmar la fecha 23*. Son 3 sin fecha en total.

## Decisiones
Ninguna. Las notas no registran una decisión con quién la tomó ni qué se descartó.

## Quedó sin decidir
Nada se presenta como pendiente de decisión en las notas.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No consta: la nota dice «se comentó», sin nombre | Riesgo (evento incierto, aún no ocurrido) | No. No hay RAID documentado; ninguno de los tres riesgos de la ficha menciona al proveedor. Ya quedó en la ficha, sin probabilidad, impacto ni dueño. |

No dice de cuál proveedor habla. Dato de contexto del expediente, sin concluir nada: CT-847 tiene 2 entregables vencidos sin recibo y CT-980 tiene 2 vencidos y 599.677.238 COP facturados sin ningún entregable aceptado.

## Cerrado en esta reunión
Nada. Nadie dijo que hubiera entregado algo, y de todos modos no habría cerrado sin documento.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «próxima reunión en dos semanas» (línea 8), es decir, hacia el 2026-11-01 | `cycle.committee: weekly`; los comités van cada domingo desde el 09-06 | notas 2026-10-18 · configuración del proyecto. Coincide con `committee_next: 2026-11-01`, pero no con «weekly». |

Es una discrepancia de cadencia, no de un campo de la ficha. Si el comité pasó a ser quincenal, hay que actualizar la configuración; si no, hoy faltó fijar la reunión de 10-25.

## Sin resolver de la transcripción
- «03/12/2026» (línea 4): leída como 3 de diciembre de 2026 (día/mes). Como 12 de marzo ya habría pasado, es la lectura que cuadra; confirmar con Liliana Torres.
- «la otra semana» (línea 5): sin fecha.
- «el proveedor» (líneas 6 y 7): sin nombre, y puede ser el mismo en las dos o no.
- Línea 7: no consta quién lo dijo.

---
**Recalculado (`compute`, 2026-10-18):** 0 `record_issues`. Compromisos: 6 vencidos sin evidencia (Hoyos ×2, Medina, Salas, Torres *matriz 14*, Gil), 3 sin fecha, 2 reprogramados 3 veces o más (Torres 6, Céspedes 5). Hallazgos de la ficha en total: 22.

**Después:** `/pm-commitments` para el seguimiento completo con lo que entró hoy. `/pm-publish` no hace falta por esta acta: ningún campo de la ficha oficial cambió. Esta acta sale en la conversación y la guardas tú.
