# Corrida del 2026-10-18 · pm-escalate

1 proyectos · 53 s · 22 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `vendor_deliverable_late` | 4 |
| `milestone_met_without_evidence` | 3 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Paquete de 4 puntos: autoridad no declarada en el acta, factura FV-1980 de CT-980 sin acta de recibo, CC-01 sin firma ni línea base de costo, dos compromisos reprogramados 5 y 6 veces. No sé: vencimiento y estado de pago de FV-1980, cláusulas de multa de CT-980, quién firmó CC-01, dependencias de otros proyectos; no se estimaron costos de opciones sin dato.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-206 Precios dinámicos · 2026-10-18

Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-18, v0.5.0). Sin tema en la invocación: armé el paquete con lo que ya estaba marcado como escalable en el informe y la agenda de hoy (`salida-pm-report.md`, `salida-pm-agenda.md`).

### 0. Primero: el acta no declara la autoridad del gerente

El acta del 2026-04-05 (`00-gobierno/2026-04-05-acta-constitucion.docx`) trae patrocinador, gerente, comité, presupuesto y fechas, pero **ninguna facultad de decisión**: ni topes de gasto, ni quién aprueba cambios, ni quién autoriza pagos a proveedores. La ficha lo registra como `identity.authority: not_found`.
Por eso no puedo decir, con cita, qué de lo que sigue excede a Andrés Lozano. Lo que sigue lo escalo por los criterios de la tabla (afecta el presupuesto aprobado por el comité, compromiso reprogramado 3+ veces, doliente fuera del proyecto), no contra una facultad escrita.

**Pregunta cerrada:** ¿El Comité de Expansión adopta, como adenda al acta, la tabla de facultades del gerente (sí / no)? Hasta que no, cada punto de abajo se puede devolver con un «eso lo decide usted».
**Quién decide:** Comité de Expansión (aprobó el acta). **Si no se decide:** el 2026-11-01 (próximo comité según la configuración) los puntos 1 a 3 llegan sin que conste a quién le toca decidirlos.

---

### 1. Factura de CT-980 radicada sin entrega aceptada

### ¿Se retiene el pago de la factura FV-1980 (599.677.238 COP, Tecnología para Tiendas) hasta que exista acta de recibo firmada, o se paga y se regulariza la entrega después?

**Quién decide:** no consta en el acta (ver punto 0). El contrato fija solo la condición: *«Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto»* (`00-gobierno/2026-04-12-contrato-ct-980.md`). Esa acta no existe en la carpeta; firmarla sin entrega sí sería decisión del gerente, y no la tomo por él.
**Si no se decide hoy:** no puedo poner fecha. La factura (`20-seguimiento/2026-09-09-factura-ct-980.md`) dice «radicada en cuentas por pagar» y no trae vencimiento, ni dice si ya se pagó. **Dato que falta y que cambia la urgencia: la fecha de vencimiento y el estado de pago de FV-1980.**

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener hasta acta de recibo | Los 2 entregables (licenciamiento, vencido desde 2026-07-02; bolsa de horas, desde 2026-09-18) siguen sin recibo | Sin dato: depende de cuándo entregue el proveedor. Despliegue ya está en 2027-01-05 | 0 COP hoy; riesgo de fricción con el proveedor, sin estimar |
| B. Pagar y exigir la entrega después | Se acepta la entrega sin acta; el contrato se incumple en su propia condición | Sin efecto directo en fechas | 599.677.238 COP salen sin entrega verificada (6,3 % de lo aprobado); recuperarlos si no entrega: sin dato |
| C. Reclamo formal por incumplimiento de fechas | Ambos entregables vencidos (108 y 30 días a hoy) | Abre una discusión contractual; duración sin dato | Sin dato; el contrato en la carpeta no trae cláusula de multa ni de terminación |

**Recomiendo:** A, con el reclamo (C) listo si en una fecha que fije el comité no hay entrega. El contrato condiciona el pago al acta; B reescribe esa condición sin que nadie con facultad la haya cambiado.

**Nota sobre la cifra:** la factura es igual al monto de *un* entregable (599.677.238), no de los dos (1.199.354.476); el concepto dice «Entregables del contrato» sin precisar cuál. Hay que preguntarle al proveedor qué cobra.

### 2. CC-01 aprobado sin firma ni línea base de costo

### ¿El comité confirma por escrito que autorizó CC-01 (+53 días, +106.000.000 COP) y registra la línea base de costo v2, o se devuelve la solicitud?

**Quién decide:** Comité de Expansión (dueño de la línea base de presupuesto según el acta). **Si no se decide:** la línea base v2 de fechas (cierre 2027-01-05) ya está en la ficha, pero el documento dice solo «Autorizada por el comité», sin cuál comité, quién firmó ni fecha. Con proyección de 9.737.352.769 COP contra 9.500.000.000 aprobados, el sobrecosto declarado ya supera lo aprobado en 237.352.769 COP y no hay base de costo que lo cubra. Sin fecha límite externa en los documentos; el 2026-11-01 es el próximo comité.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 con acta firmada y línea base de costo v2 | Ampliación (sin detalle del alcance en el documento) | Cierre 2027-01-05 (+53 días sobre 2026-11-13) | +106.000.000 COP; presupuesto vigente 9.606.000.000 (la proyección de 9.737.352.769 lo excede en 131.352.769) |
| B. Devolverla por falta de sustento | Se mantiene el alcance original | Cierre vuelve a 2026-11-13 en papel, con 47 % de avance declarado | 0 COP adicionales; el atraso no desaparece |

**Recomiendo:** A, pero condicionada a que el comité diga cuál es el alcance ampliado. «Ampliación de alcance» sin descripción no se puede medir ni cerrar.

### 3. Dos compromisos reprogramados 5 y 6 veces

### ¿El comité fija una fecha límite y un responsable de destrabar para «Enviar el documento 1» (Liliana Torres, 6 reprogramaciones, hoy 2026-12-03) y «Cerrar la prueba 2» (Paula Céspedes, 5, hoy 2026-11-25), o los declara bloqueados?

**Quién decide:** Comité (Paula Céspedes es a la vez patrocinadora y dueña de la prueba 2; esa parte no la puede destrabar quien está en el comité de la causa). **Si no se decide:** el 2026-12-03 será la séptima fecha del documento 1 y el 2026-11-25 la sexta de la prueba 2.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fecha límite firme + responsable de destrabar con nombre | Sin cambio | Documento 1: 2026-12-03 como tope; prueba 2: 2026-11-25 | Sin dato |
| B. Declarar ambos bloqueados y escalar la causa | Sin cambio | Sin fecha; sin dato de qué más depende de ellos | Sin dato |

**Recomiendo:** A, con la causa dicha por escrito en el comité. Seis reprogramaciones sin causa nombrada son un bloqueo que nadie ha querido nombrar.

---

### A quién alcanza

Calculé `impact` con +53 días (el cambio de CC-01): **no alcanza a ningún otro proyecto**. Eso significa solo que la carpeta de estado contiene únicamente PRY-206 y que el acta declara «Ninguna dependencia declarada»; no que ningún otro proyecto dependa de este. **Falta confirmar con el comité y la PMO si Comercio electrónico u otros proyectos esperan el despliegue en la cadena.** Cuántos días se mueve cada alcanzado no se calcula (necesita holgura por actividad, que la ficha no tiene).

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| (ninguno en la ficha) | — | sin dato | sin dato |

### Mis hitos por los que pasa

El cálculo corre sobre el cierre vigente (2027-01-05); como CC-01 ya está en la línea base v2, el +53 de la corrida es una **simulación de otro corrimiento igual**, no el efecto de CC-01.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Despliegue en la cadena | 2027-01-05 | 79 días desde hoy (cierre simulado: 2027-02-27) |

### De dónde sale esto

- Autoridad no declarada: `00-gobierno/2026-04-05-acta-constitucion.docx` (sin sección de facultades); ficha `identity.authority: not_found`.
- Condición de pago y entregables de CT-980: `00-gobierno/2026-04-12-contrato-ct-980.md`; factura: `20-seguimiento/2026-09-09-factura-ct-980.md`. Ningún entregable de CT-980 tiene acta de recibo en `20-seguimiento/`.
- CC-01: `20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md`. Presupuesto aprobado: acta, 9.500.000.000 COP. Proyección 9.737.352.769 COP: `20-seguimiento/2026-10-15-informe-avance.pdf` (declaración, no evidencia).
- Reprogramaciones: ficha, comités `30-reuniones/2026-09-06` a `2026-10-11` y `2026-10-18-notas-reunion.txt`.

### Lo que no sé

La fecha de vencimiento y el estado de pago de FV-1980; qué entregable cubre; si CT-980 tiene cláusulas de multa o terminación (el contrato en la carpeta no las trae); quién firmó CC-01 y qué alcance agrega; quién es dueño de cada contrato; el efecto en otros proyectos.

### Qué no escala

Los vencidos de Hoyos, Medina, Torres (matriz 14), Salas y Gil, y los compromisos sin fecha (Vélez, Céspedes, Cuéllar): se destraban con una llamada o en la reunión (agenda del 11-01). El riesgo del proveedor sin equipo completo: lo registra el gerente en el RAID, no es decisión de comité todavía.

**Después:** si el comité decide, registro la decisión con fecha y documento. Esto produce el paquete; llevarlo al comité es del gerente.
