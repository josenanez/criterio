Publiqué la ficha en `/home/claude/banco/ronda-10/retail/espacio/documentos/proyectos/PRY-206-precios-dinámicos/00-gobierno/ficha-pm.json`, con corte al 2026-10-18.

**Lleva:** 17 campos con dato · 3 sin decir en ninguna parte (`identity.product`, `identity.authority`, `identity.phase`) · declara **rojo** al 2026-10-15 (47 % de avance, declarado en `20-seguimiento/2026-10-15-informe-avance.pdf`, tiene 3 días)

**Lo más viejo que va ahí:** `identity.*`, `plan.start_date`, `plan.scope_summary` y `money.approved`, todos del acta de constitución del 2026-04-05 (196 días; no pasa de un año).

**Fecha de cierre:** `plan.end_date` = 2027-01-05, del cronograma v2 (2026-10-15), que es el más reciente y coincide con la línea base v2 aprobada por CC-01. La original (2026-11-13) va en `plan.baseline`.

**Para tener presente antes de que la PMO la lea:**
- Tres hitos figuran como cumplidos sin evidencia de recibo: Diseño de la experiencia, Integración con el ERP y Piloto en tiendas.
- CC-01 dice «el comité», sin decir cuál ni quién firmó.
- Tecnología para Tiendas Ltda. (CT-980) tiene facturado 599.677.238 COP sin ningún entregable aceptado.
- El avance declarado (47 %) está por debajo de lo que sustenta el plan (80–100 %).

**Términos:** vigentes (v0.5.0), aceptados por José Francisco Ñáñez el 2026-10-18.
