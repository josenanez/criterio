## Listo — PRY-206 · Precios dinámicos

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 20 documentos · 7 minutas (6 comités semanales del 2026-09-06 al 2026-10-11 y las notas del 2026-10-18, que están sueltas en la raíz del proyecto, no en `30-reuniones/`) · la última del 2026-10-18. Leí las 7, de la más vieja a la más nueva, y las 4 actas de recibo. Los 5 formatos (.md, .csv, .txt, .docx, .pdf) se pudieron leer.

**Respuestas que tomé por defecto (sin interfaz):**
1. Eres Andrés Lozano, gerente de PRY-206 · Precios dinámicos (acta de constitución).
2. Tu reunión es el comité semanal de los domingos (todas las minutas caen en domingo); las notas del 2026-10-18 dicen «próxima reunión en dos semanas», así que dejé la próxima el 2026-11-01.
3. El estado queda en `estado/PRY-206-precios-dinámicos`.
4. Términos: aceptados a nombre de José Francisco Ñáñez, fecha 2026-10-18, según lo indicado para esta prueba.

**Términos:** aceptados para la versión 0.5.0 (texto 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 ffa4799dee7ac84c… (md) y 23531460258f311e… (pdf)

### Lo que está abierto, y cuántas veces se ha movido
De 26 compromisos: 3 cumplidos con acta, 6 vencidos, 3 sin fecha, 14 abiertos con fecha.

**Los que se vienen moviendo**
| Quién | Qué | Primera promesa | Para cuándo hoy | Veces movido |
|---|---|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-09-13 (minuta 2026-09-06) | 2026-12-03 (notas 2026-10-18) | **6** |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-14 (minuta 2026-09-06) | 2026-11-25 (comité 2026-10-11) | **5** |

Las fechas de «Enviar el documento 1»: 09-13 → 09-30 → 10-09 → 10-16 → 11-02 → 11-19 → 12-03. Las de «Cerrar la prueba 2»: 09-14 → 09-23 → 10-11 → 10-24 → 11-14 → 11-25. Ninguna minuta sola lo muestra; sale de leerlas en orden. Y esta semana nadie habló de «Cerrar la prueba 2» en las notas.

**Vencidos sin evidencia**
| Quién | Qué | Para | Días | Cita |
|---|---|---|---|---|
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 | 12 | comité 2026-09-13 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 | 9 | comité 2026-09-06 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-09 | 9 | comité 2026-09-27 |
| Liliana Torres | Actualizar la matriz 14 | 2026-10-11 | 7 | comité 2026-09-27 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 | 3 | comité 2026-09-27 |
| Sandra Gil | Entregar el punto 24 | 2026-10-17 | 1 | comité 2026-10-11 |

**Dicen que ya entregaron, sin acta (no se cierran):**
- Carlos Peña, «Actualizar la matriz 6» (dicho el 2026-09-27; vigente 2026-10-21).
- Liliana Torres, «Actualizar la matriz 14» (dicho el 2026-10-04; ya figura vencido arriba).
- Jorge Medina, «Cerrar la prueba 18» (dicho el 2026-10-11; vigente 2026-10-24).
Los tres dejaron de aparecer en la lista del comité desde el día que lo dijeron.

**Cumplidos con acta de recibo:** Aprobar el diseño 5 (Jorge Medina, 2026-09-20), Revisar el anexo 11 (Camilo Beltrán, 2026-10-04), Revisar el anexo 3 (María Restrepo, 2026-10-11).

**Abiertos con fecha, aún no vencidos:** Carlos Peña (matriz 6, 10-21; documento 17, 10-18, vence hoy), Gustavo Neira (punto 8, 10-23; diseño 21, 11-05; matriz 22, 11-03), Rubén Cárdenas (documento 9, 10-31), Paula Céspedes (prueba 10, 11-01), Liliana Torres (ambiente 12, 10-27), Diana Molina (fecha 15, 10-27), Mauricio Pérez (anexo 19, 10-28), Jorge Medina (prueba 18, 10-24), Óscar Ramírez (revisión con el proveedor, 10-28).

### Sin fecha
Nadie los fechó, así que no pueden aparecer vencidos:
- Paula Céspedes — Validar el ambiente 20 («por definir» desde el 2026-10-04).
- Beatriz Cuéllar — Confirmar la fecha 23 («por definir», 2026-10-11).
- Laura Vélez — Mandar el ajuste del presupuesto («la otra semana», notas 2026-10-18).

### Otras señales que levantó el cálculo
- **Plazo:** el cierre pasó del 2026-11-13 al 2027-01-05: 53 días, 25.0 % sobre la línea base original. La solicitud CC-01 (ampliación de alcance, +106.000.000 COP, autorizada por el comité) explica los 53 días; registré una línea base nueva sin borrar la original.
- **Tu estado declarado es rojo, con 47 %.** El cálculo levantó siete señales que el informe del 2026-10-15 no menciona (solo habla de la rotación de personal y de dos riesgos): compromisos vencidos, compromisos reprogramados, hitos cerrados sin acta, avance contra plan, desviación de plazo, entregables tardíos de proveedores y factura sin entrega.
- **Avance:** el cronograma tiene 4 de 5 hitos cerrados, lo que sostendría entre 80 y 100 %; declaras 47 %, 33 puntos por debajo. Las dos cifras no cuadran y no sé cuál es la correcta: ver los hitos cerrados sin acta, más abajo.
- **Hitos cerrados sin acta:** Diseño de la experiencia aprobado (144 días), Integración con el ERP (59), Piloto en tiendas (16). Solo «Ambiente de pruebas certificado» tiene acta, y está fechada el 2026-10-15, cuando el cronograma lo da por cerrado desde el 2026-07-09.
- **Proveedores:** Tecnología para Tiendas Ltda. (CT-980) facturó 599.677.238 COP el 2026-09-09 sin ningún entregable aceptado (licenciamiento, 108 días tarde; bolsa de horas, 30). Sistemas Comerciales del Norte (CT-847) tiene la bolsa de horas 93 días tarde y la configuración del catálogo 46, y su licenciamiento figura «recibido» sin acta.
- **Dinero:** ejecutado 2.375.369.823 de 9.500.000.000 COP (25.0 %), comprometido 38 %, proyección al cierre 9.737.352.769 (2.5 % sobre lo aprobado). No incluye aún los 106.000.000 de CC-01.
- **Riesgo dicho y no registrado** (notas 2026-10-18): el proveedor podría no llegar con el equipo completo para la siguiente fase. Quedó en la ficha, sin dueño.
- **Sin dato en ningún documento:** producto asociado, autoridad del gerente y fase.

### Qué le falta a tu carpeta
- Actas de recibo de los hitos que el cronograma da por cerrados (3) y del licenciamiento de CT-847.
- Acta de recibo para los 3 compromisos que dicen «ya lo entregué».
- Las notas del 2026-10-18 están fuera de `30-reuniones/`, y no dicen nada de la mayoría de los compromisos abiertos: sin ellas no sé si «Cerrar la prueba 2» o «Confirmar la fecha 7» se movieron otra vez.
- El acta de constitución no declara dependencias ni autoridad del gerente.
- Cuál comité autorizó CC-01, y el presupuesto aprobado después de ella.

**Cuándo vuelvo:** el comité del 2026-11-01 (semanal, domingos; las notas dicen «en dos semanas»).

*Leí todas las minutas (7), así que no quedó nada sin leer. La ficha no está sellada: leí las minutas y los documentos del proyecto, pero no la di por leída entera.*
