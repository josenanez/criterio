## Reunión de seguimiento — PRY-206 Precios dinámicos · 2026-11-01
2 reprogramados, 5 vencidos, 4 decisiones y 1 ronda de vencimientos · 43 minutos · 10 personas requeridas (Torres, Céspedes, Medina, Hoyos, Salas, Gil, Ramírez, Vélez, Lozano y, para la ronda, los dolientes de la tabla)

**Fecha:** la configuración fija `committee_next: 2026-11-01`. Las notas del 2026-10-18 dicen «próxima reunión en dos semanas», pero la cadencia configurada es semanal (ver punto 7). **Cálculo al 2026-10-18:** es la primera corrida sobre este expediente, así que no hay foto anterior (`diff` = línea de partida) y no puedo decir qué cambió desde la última vez; tomé como «reunión anterior» el comité del 2026-10-18. Asistencia asumida: la de ese día. Lo que venza o se mueva entre hoy y el 11-01 hay que recalcularlo antes de convocar.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y quién lo destraba** · 8 min · **Liliana Torres** (+ Paula Céspedes, patrocinadora)
> Prometido para el 2026-12-03, y antes para el 11-19, 11-02, 10-16, 10-09, 09-30 y 09-13 (6 reprogramaciones).
> Fuente: `30-reuniones/2026-09-06-comite-semanal.md` (origen) y `2026-10-18-notas-reunion.txt` (última fecha, línea 4)
> **Si no se resuelve hoy:** el 12-03 cae un mes después de la fecha del comité y, con esta cadencia, será la séptima fecha. Seis veces no es seguimiento, es un bloqueo sin nombre. Sale de la reunión con causa, responsable de quitarla y fecha, o sube a comité con `/pm-escalate`.

> **[2] Qué impide cerrar la prueba 2** · 8 min · **Paula Céspedes**
> Prometido para el 2026-11-25, y antes para el 11-14, 10-24, 10-11, 09-23 y 09-14 (5 reprogramaciones).
> Fuente: `30-reuniones/2026-09-06-comite-semanal.md` (origen) y `30-reuniones/2026-10-11-comite-semanal.md` (última fecha)
> **Si no se resuelve hoy:** Paula Céspedes es también la patrocinadora (acta de constitución). Si el bloqueo está en quien debería destrabarlo, la reunión no lo mueve y esto pasa a ser punto de comité.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Jorge Medina | Confirmar la fecha 7 (antes 09-28) | 2026-10-06 (`30-reuniones/2026-09-13-comite-semanal.md`) | La fecha, o decir que no la tiene | 2 |
| Javier Hoyos | Validar el ambiente 4 (antes 09-20) y Entregar el punto 16 | 2026-10-09 (`30-reuniones/2026-09-06-comite-semanal.md`, `2026-09-27-comite-semanal.md`) | Entregarlos, o fecha con nombre del impedimento | 4 |
| Liliana Torres | Actualizar la matriz 14 | 2026-10-11 (`30-reuniones/2026-09-27-comite-semanal.md`) | Dijo el 10-04 que ya la entregó; no hay acta ni entregable. Traer el documento o reabrirla | 3 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 (`30-reuniones/2026-09-27-comite-semanal.md`) | Aprobar o decir qué le falta | 2 |
| Sandra Gil | Entregar el punto 24 | 2026-10-17 (`30-reuniones/2026-10-11-comite-semanal.md`) | Entregarlo o fecha | 2 |

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[3]** Cuál proveedor es la «revisión con el proveedor» del 10-28 (hay dos contratos: CT-847 y CT-980), y quién es dueño del riesgo «el proveedor podría no llegar con el equipo completo» | Óscar Ramírez y Andrés Lozano | La revisión del 10-28 llega sin alcance, y el riesgo sigue sin dueño, probabilidad ni impacto. Fuente: `2026-10-18-notas-reunion.txt`, líneas 6 y 7 (en la línea 7 no consta quién lo dijo) | 5 |
| **[4]** Fecha para «Mandar el ajuste del presupuesto» («la otra semana» no es fecha) | Laura Vélez | Sigue sin poder vencer y sin poder reclamarse. Fuente: línea 5 de las notas del 10-18 | 2 |
| **[5]** Fecha para «Validar el ambiente 20» | Paula Céspedes | Mismo caso: dicho el 2026-10-04, sin fecha. Fuente: `30-reuniones/2026-10-04-comite-semanal.md` | 2 |
| **[6]** Cadencia del comité: ¿semanal o quincenal? | Andrés Lozano | La configuración dice semanal y la reunión dijo «dos semanas». Si es quincenal, actualizar la configuración; si no, falta fijar el 10-25. Fuente: notas del 10-18, línea 8 | 2 |

### Vence antes de la próxima
Una ronda de 3 minutos **[7]**: cada doliente confirma sí/no. Si alguno dice no, la fecha se mueve ahora y no en la reunión siguiente.

| Quién | Qué | Para cuándo |
|---|---|---|
| Carlos Peña | Enviar el documento 17 | 2026-10-18 (hoy) |
| Carlos Peña | Actualizar la matriz 6 (dijo que ya la entregó; sin documento) | 2026-10-21 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Jorge Medina | Cerrar la prueba 18 (dijo que ya la entregó; sin documento) | 2026-10-24 |
| Liliana Torres | Validar el ambiente 12 | 2026-10-27 |
| Diana Molina | Confirmar la fecha 15 | 2026-10-27 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-28 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-31 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-11-01 (el día de la reunión) |
| CT-847, Sistemas Comerciales del Norte | Soporte del primer trimestre | 2026-10-19 |

Si no hay documento, no se cierran.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| CT-980 (Tecnología para Tiendas): 599.677.238 COP facturados el 09-09 sin ningún entregable aceptado; licenciamiento (07-02) y bolsa de horas (09-18) vencidos sin recibo | Decidir sobre pago o reclamo al proveedor excede la autoridad del gerente. Ningún dueño del contrato aparece en la asistencia | `/pm-escalate` y material de comité |
| CT-847 (Sistemas Comerciales del Norte): bolsa de horas (07-17) y configuración del catálogo (09-02) vencidas sin recibo; licenciamiento figura aceptado pero sin documento de aceptación | Igual: la aceptación formal y la factura no las mueve esta sala | `/pm-escalate` y material de comité |
| Proyección de costo 9.737.352.769 COP contra aprobado 9.500.000.000 COP (informe del 2026-10-15); CC-01 suma 106.000.000 COP | Presupuesto y su línea base son del comité. CC-01 figura aprobado por «el comité» sin decir cuál ni quién firmó | Comité (`/pm-escalate`); el ajuste de Laura Vélez (punto 4) es su insumo |
| Beatriz Cuéllar: «Confirmar la fecha 23», sin fecha desde el 10-11 | No estuvo el 10-18; su doliente no va a estar | Contacto directo del gerente |
| María Restrepo, Camilo Beltrán | Ausentes el 10-18; sus compromisos ya están cerrados con documento | Nada que tratar |

### Anexo — sin cambios (no hay foto anterior; es lo que no vence ni se mueve antes del 11-01)
- Gustavo Neira · Aprobar el diseño 21 · 2026-11-05
- Gustavo Neira · Actualizar la matriz 22 · 2026-11-03
- Cerrados con documento: María Restrepo (anexo 3), Jorge Medina (diseño 5), Camilo Beltrán (anexo 11)
- Hitos cumplidos: diseño, ambiente de pruebas, integración ERP y piloto. Despliegue en la cadena movido de 2026-11-13 a 2027-01-05 por CC-01
- Estado declarado el 10-15: rojo, 47 %

Suma: 16 + 13 + 11 + 3 = 43 min, 2 de margen. **Quedaron fuera por tiempo:** nada. **Descartado por no ser de la sala:** los tres temas de contrato y presupuesto de la tabla anterior.

**Lo que no sé:** qué se decidió o quedó pendiente de decidir en la reunión (las notas del 10-18 no registran decisiones); el dueño del contrato de cada proveedor; quién estará el 11-01.

**Después:** `/pm-minutes` sobre las notas de esa reunión. `/pm-escalate` para los dos reprogramados si no se nombra el bloqueo, y para los temas de proveedor.
