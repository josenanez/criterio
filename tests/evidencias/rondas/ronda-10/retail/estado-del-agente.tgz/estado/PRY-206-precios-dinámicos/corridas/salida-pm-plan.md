# Plan — PRY-206 Precios dinámicos · borrador del 2026-10-18
**Desde:** el acta de constitución del 2026-04-05 (`00-gobierno/2026-04-05-acta-constitucion.docx`) · **Criterio de éxito:** «Precios dinámicos en producción y medido.» (acta)

**Antes de leer el plan:** este proyecto no está arrancando. Inició el 2026-04-15, ya tiene cronograma v1 (2026-04-05) y v2 (2026-10-15), cuatro de cinco hitos cerrados y una solicitud de cambio CC-01 autorizada el 2026-10-17. Hice el borrador desde el acta, como pide el comando, y lo contrasto con lo que ya existe. No toca la línea base: la vigente es la v2 (cierre 2027-01-05) y este borrador no la reemplaza.

Los términos vigentes ya estaban aceptados por José Francisco Ñáñez (versión 1.1, 2026-10-18), así que no hubo que registrar nada nuevo.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** Dice «Componente 1, Componente 2, Componente 3» y fuera de alcance «Lo que otro proyecto cubre» | No se puede saber qué entregables entran. La WBS no se puede derivar del acta: tuve que apoyarme en los hitos del cronograma y en los contratos. «Lo que otro proyecto cubre» no dice qué proyecto ni qué |
| **Criterio de éxito sin medida.** «En producción y medido» no dice medido contra qué, ni con qué umbral | Nadie puede aceptar el cierre del último entregable. «Medido» puede ser una medición o un resultado, y el acta no lo dice |
| **Autoridad del gerente no declarada** (en la ficha: `identity.authority` no encontrado) | No sé qué puede decidir Andrés Lozano al planificar y qué hay que subir. Lo señalo en cada punto que lo toca |
| **Dependencias: «Ninguna declarada»** | El plan hereda esa ausencia. Hay dos proveedores con contrato y un ERP integrado; que no figuren como dependencia es un hueco, no una ausencia |
| **Producto asociado: «No aplica»** | Un proyecto de precios dinámicos sin producto asociado deja sin dueño el «medido» del criterio de éxito |
| **Objetivo del negocio genérico** («Entregar precios dinámicos para Comercio electrónico») | No hay meta de negocio contra la cual medir el criterio de éxito |

Hay patrocinador (Paula Céspedes), gerente (Andrés Lozano) y comité (Comité de Expansión). Esos tres sí están. Sigo adelante marcando los huecos y sin rellenarlos.

## WBS
Del acta no sale ningún nodo terminal aceptable (los «Componentes» no son entregables). Lo que sigue sale de otros documentos y por eso va como **supuesto**, con su cita. El acta no declara estos nodos.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado (hito, 2026-05-27, cerrado) | Sin definir | Supuesto · `10-plan/2026-10-15-cronograma-v2.csv`; sin acta de recibo | vacía |
| 2 | Ambiente de pruebas certificado (hito, 2026-07-09, cerrado) | Sin definir | Supuesto · cronograma v2; acta de recibo en `20-seguimiento/2026-10-15-acta-recibo-ambiente-de-pruebas-certificado.pdf` | vacía |
| 3 | Integración con el ERP (hito, 2026-08-20, cerrado) | Sin definir | Supuesto · cronograma v2; sin acta de recibo | vacía |
| 4 | Piloto en tiendas (hito, 2026-10-02, cerrado) | Sin definir | Supuesto · cronograma v2; sin acta de recibo | vacía |
| 5 | Despliegue en la cadena (hito; 2026-11-13 en v1, 2027-01-05 en v2) | Sin definir | Supuesto · cronograma v1 y v2. El cierre 2026-11-13 sí es del acta | vacía |
| 6 | Medición de precios dinámicos en producción | Sin definir | **Del acta** (criterio de éxito: «en producción y medido»). No figura como hito en ningún cronograma | vacía |
| 7 | CT-847 · Licenciamiento de la plataforma (2026-05-31, 410.335.213 COP) | Gerente del proyecto, por acta de recibo firmada | Supuesto · `00-gobierno/2026-04-13-contrato-ct-847.docx` (la condición de pago dice quién firma) | vacía |
| 8 | CT-847 · Bolsa de horas de desarrollo (2026-07-17, 410.335.213 COP) | Gerente del proyecto | Supuesto · contrato CT-847 | vacía |
| 9 | CT-847 · Configuración del catálogo (2026-09-02, 410.335.213 COP) | Gerente del proyecto | Supuesto · contrato CT-847 | vacía |
| 10 | CT-847 · Soporte del primer trimestre (2026-10-19, 410.335.213 COP) | Gerente del proyecto | Supuesto · contrato CT-847 | vacía |
| 11 | CT-980 · Licenciamiento de la plataforma (2026-07-02, 599.677.238 COP) | Gerente del proyecto | Supuesto · `00-gobierno/2026-04-12-contrato-ct-980.md` | vacía |
| 12 | CT-980 · Bolsa de horas de desarrollo (2026-09-18, 599.677.238 COP) | Gerente del proyecto | Supuesto · contrato CT-980 | vacía |
| 13 | CC-01 · Ampliación de alcance | Sin definir | Supuesto · `20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md`. El documento no dice qué se agrega. **Duración: +53 días sobre la línea base vigente** (esa cifra sí es citable) | +53 días (CC-01) |
| 14 | Lo que cubren los 9.500.000.000 COP aparte de los contratos | Sin definir | Sin definir. Los dos contratos suman 2.840.695.328 COP; el resto del presupuesto no tiene entregable a la vista | vacía |

Observaciones sobre la tabla:
- En los entregables de contrato, quien acepta es el mismo gerente que planifica. Eso es lo que dice la condición de pago; no hay un aceptante del lado del negocio.
- Los nodos 1 a 5 son hitos, no entregables. Cada uno necesita decirse como algo que alguien recibe («el diseño firmado por…»), y eso no está escrito.
- Los entregables de CT-847 y CT-980 comparten nombre («Licenciamiento de la plataforma», «Bolsa de horas de desarrollo») con montos distintos. El plan no dice si son el mismo trabajo cubierto dos veces o dos trabajos distintos.

## Orden
Por dependencia, sin fechas. Lo que sigue lo infiero del orden de los hitos; **ninguna dependencia está declarada**, así que todo el orden es supuesto.

1. Diseño de la experiencia aprobado.
2. Ambiente de pruebas certificado (necesita licenciamiento de la plataforma, nodos 7 y 11, si el ambiente corre sobre ella: supuesto).
3. Integración con el ERP (necesita el ambiente de pruebas).
4. Piloto en tiendas (necesita la integración con el ERP y la configuración del catálogo, nodo 9).
5. Despliegue en la cadena (necesita el piloto).
6. Medición en producción (necesita el despliegue). Es lo que cierra el criterio de éxito.
7. CC-01: no se puede ordenar, porque no dice qué agrega.
8. Soporte del primer trimestre (nodo 10): no sé si arranca tras el despliegue o antes. El contrato no lo dice.

Los hitos 1 a 4 figuran como cerrados en el cronograma v2, y solo el 2 tiene acta de recibo en la carpeta.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v2 son los entregables del proyecto | La WBS describe una parte del trabajo, y el alcance real («Componente 1, 2 y 3») queda sin cubrir |
| El orden diseño → pruebas → ERP → piloto → despliegue → medición es el de dependencia real | El plan aparenta un camino crítico que no lo es |
| Los entregables de CT-847 y CT-980 son trabajos distintos | Se está pagando dos veces lo mismo, o la WBS cuenta de más |
| El gerente es quien acepta los entregables de proveedor | Falta un aceptante del negocio, y la factura se aprueba sin quien usa el entregable |
| Los hitos marcados como cerrados lo están | Cuatro de cinco hitos figuran cerrados en el cronograma y solo uno tiene acta. Si no están cerrados, el despliegue depende de trabajo sin terminar |
| CC-01 fue autorizado por quien tenía autoridad | El documento dice «Autorizada por el comité» sin decir cuál ni quién firmó; la línea base v2 (2027-01-05) descansa en eso |
| El proveedor llega con el equipo completo a la siguiente fase | Se dijo en la reunión del 2026-10-18 que podría no ocurrir (`2026-10-18-notas-reunion.txt`); nadie lo registró como riesgo |

Estos pasan a riesgos del proyecto cuando el plan se apruebe. Hoy el RAID no tiene ningún supuesto registrado (`raid.assumptions` vacío en la ficha).

## Sin definir
| Qué | Quién lo define |
|---|---|
| Alcance real: qué son los Componentes 1, 2 y 3 | Patrocinador (Paula Céspedes) con el gerente |
| Qué proyecto cubre lo que el acta deja fuera de alcance | Patrocinador |
| Medida del «medido»: qué métrica, qué umbral, quién la mide | Patrocinador. El acta no nombra producto |
| Autoridad del gerente al planificar | Patrocinador / comité |
| Quién acepta cada hito como entregable (nodos 1 a 6) | Patrocinador |
| Qué agrega CC-01 y qué comité lo autorizó | Gerente, para documentarlo; comité, para confirmarlo |
| A qué entregables corresponde el resto del presupuesto (6.659.304.672 COP fuera de los dos contratos) | Gerente con el área dueña (Comercio electrónico) |
| Dependencias | Gerente, con los dueños de ERP y proveedores |
| Fase actual del proyecto (la ficha no la tiene) | Gerente |

## Proyectos análogos
No hay ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, y en el espacio solo aparece la documentación de PRY-206 (y una configuración de producto, PRD-300, que no es un proyecto análogo). Es la respuesta correcta: no traigo referencias y por eso no hay estimación por analogía.

Lo único comparable es el propio proyecto: el cierre pasó de 2026-11-13 a 2027-01-05 (+53 días, CC-01). Es historia de este proyecto, no un análogo.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto tomó (o cuánto falta para) el **diseño de la experiencia** y quién lo aceptó?
2. ¿Cuánto toma certificar el **ambiente de pruebas**, y qué cubre el acta del 2026-10-15?
3. ¿Cuánto tomó la **integración con el ERP**, y dónde está el acta de recibo?
4. ¿Cuánto duró el **piloto en tiendas**, en cuántas tiendas, y qué resultado cerró el hito?
5. ¿Cuánto toma el **despliegue en la cadena** y qué lo hace terminado tienda por tienda?
6. ¿Cuánto toma la **medición** antes de poder declarar «medido», y contra qué baseline?
7. ¿Cuánto toma cada uno de los **entregables de CT-847** (bolsa de horas, catálogo, soporte)? El contrato da fechas, no duraciones.
8. ¿Cuánto toma cada uno de los **entregables de CT-980**, y por qué sus dos entregables siguen «pendiente» si ya hay factura por 599.677.238 COP?
9. ¿De dónde sale el **+53 días** de CC-01: qué trabajo concreto lo explica?
10. ¿Qué hay detrás del **resto del presupuesto** y cuánto tarda?

## Para comprometer una fecha falta
Nada de esto está en un documento:
- **Disponibilidad real del equipo.** El informe de avance declara dos semanas perdidas por rotación de un desarrollador clave y un riesgo de concentración de conocimiento en una persona, sin dueño.
- **Fecha del proveedor.** El proveedor «podría no llegar con el equipo completo» para la siguiente fase; la revisión con el proveedor (Óscar Ramírez) quedó para 2026-10-28.
- **Ventana de despliegue en la cadena.** No hay ninguna fecha de ventana ni restricción de calendario comercial escrita.
- **Qué entra en CC-01**, porque de eso depende cuánto dura lo que queda.
- Además, el calendario de los compromisos abiertos del comité (varios vencidos) no está cruzado con ningún entregable de la WBS.

Este borrador no compromete ninguna fecha. Las fechas que aparecen son las ya escritas en el acta, los contratos y el cronograma v2. La fecha la compromete el gerente.

## Fuera del plan, pero lo vi
- CT-980 muestra factura por 599.677.238 COP (2026-09-09) con sus dos entregables en «pendiente» y sin acta de recibo en la carpeta. La condición de pago exige acta firmada. Lo dejo para `vendor-control`; no lo resuelvo aquí.

## Después
Si el plan se aprueba, ofrezco registrarlo como línea base original y pasar los supuestos al RAID con doliente. Una advertencia: la línea base original de este proyecto ya existe (v1, 2026-04-05), así que lo que correspondería es una revisión de la v2 vigente, con control de cambios.
