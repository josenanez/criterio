<!-- origen: PRY-203-reposición-automática/10-plan/2026-06-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-09-06,2026-09-06,cerrado
Ambiente de pruebas certificado,2026-11-14,2026-11-14,en curso
Integración con el ERP,2027-01-21,2027-01-21,en curso
Piloto en tiendas,2027-03-31,2027-03-31,en curso
Despliegue en la cadena,2027-06-07,2027-06-07,en curso
