<!-- origen: PRY-200-tienda-en-línea/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Tienda en línea

Fecha: 2026-10-14

Asistentes: Jorge Medina, Gustavo Neira

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Ricardo Salas

Entregar el punto 10

2026-11-13
