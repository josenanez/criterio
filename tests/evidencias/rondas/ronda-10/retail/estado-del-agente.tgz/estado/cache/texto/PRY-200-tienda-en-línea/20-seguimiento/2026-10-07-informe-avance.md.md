<!-- origen: PRY-200-tienda-en-línea/20-seguimiento/2026-10-07-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-07
**Gerente:** Jorge Medina

## Estado declarado

**Verde**

Avance reportado: **26%**

## Lo que pasó en el periodo

- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se levantó un hallazgo de seguridad en los medios de pago
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 14.923.236.992 |
| Ejecutado | 8.020.333.404 |
| Proyección al cierre | 18.137.414.819 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
