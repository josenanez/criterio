<!-- origen: PRY-208-domicilios-en-dos-horas/30-reuniones/2026-10-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Domicilios en dos horas

**Fecha:** 2026-10-06
**Asistentes:** Camilo Beltrán, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 35 | por definir |
