<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-04-18-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-06-21 | 2026-06-21 | cerrado
Ambiente de pruebas certificado | 2026-08-15 | 2026-08-15 | cerrado
Integración con el ERP | 2026-10-09 | 2026-10-09 | en curso
Piloto en tiendas | 2026-12-02 | 2026-12-02 | en curso
Despliegue en la cadena | 2027-01-26 | 2027-01-26 | en curso
