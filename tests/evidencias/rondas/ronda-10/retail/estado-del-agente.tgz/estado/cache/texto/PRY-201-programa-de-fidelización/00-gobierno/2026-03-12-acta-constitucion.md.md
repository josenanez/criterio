<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2026-03-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Tecnología
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité Comercial
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2026-03-12

## Objetivo del negocio

Entregar programa de fidelización para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité Comercial el 2026-03-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-22 |
| Cierre | 2027-01-01 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
