<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2025-06-26-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-11-07,2025-11-07,cerrado
Ambiente de pruebas certificado,2026-03-12,2026-03-12,cerrado
Integración con el ERP,2026-07-15,2026-07-15,cerrado
Piloto en tiendas,2026-11-16,2026-11-16,en curso
