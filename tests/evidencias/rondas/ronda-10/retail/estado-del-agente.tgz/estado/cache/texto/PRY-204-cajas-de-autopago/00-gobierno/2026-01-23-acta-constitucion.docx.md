<!-- origen: PRY-204-cajas-de-autopago/00-gobierno/2026-01-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cajas de autopago

Código: PRY-204

Área dueña: Talento humano

Patrocinador: Javier Hoyos

Gerente de proyecto: Elena Duarte

Comité: Comité de Cadena de Abastecimiento

Producto asociado: autopago en tienda

Fecha de aprobación: 2026-01-23

Objetivo del negocio

Entregar cajas de autopago para Talento humano.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Cadena de Abastecimiento el 2026-01-23.

Fechas comprometidas

Fecha

Inicio

2026-02-02

Cierre

2027-07-07

Criterio de éxito

Cajas de autopago en producción y medido.

Dependencias declaradas

• Ninguna declarada
