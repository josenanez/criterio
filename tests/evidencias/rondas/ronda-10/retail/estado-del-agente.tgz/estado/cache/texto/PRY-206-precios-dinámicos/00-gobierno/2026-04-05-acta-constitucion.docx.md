<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2026-04-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Comercio electrónico

Patrocinador: Paula Céspedes

Gerente de proyecto: Andrés Lozano

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-04-05

Objetivo del negocio

Entregar precios dinámicos para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Expansión el 2026-04-05.

Fechas comprometidas

Fecha

Inicio

2026-04-15

Cierre

2026-11-13

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
