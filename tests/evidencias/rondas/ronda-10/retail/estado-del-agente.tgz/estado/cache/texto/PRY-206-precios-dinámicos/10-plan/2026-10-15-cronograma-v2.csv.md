<!-- origen: PRY-206-precios-dinámicos/10-plan/2026-10-15-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-05-27,2026-05-27,cerrado
Ambiente de pruebas certificado,2026-07-09,2026-07-09,cerrado
Integración con el ERP,2026-08-20,2026-08-20,cerrado
Piloto en tiendas,2026-10-02,2026-10-02,cerrado
Despliegue en la cadena,2026-11-13,2027-01-05,en curso
