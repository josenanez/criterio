<!-- origen: PRY-201-programa-de-fidelización/10-plan/2026-03-12-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-05-18,2026-05-18,cerrado
Ambiente de pruebas certificado,2026-07-14,2026-07-14,cerrado
Integración con el ERP,2026-09-09,2026-09-09,cerrado
Piloto en tiendas,2026-11-05,2026-11-05,en curso
Despliegue en la cadena,2027-01-01,2027-01-01,en curso
