<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pago con QR en caja
Código: PRY-205
Fecha de corte: 2026-10-18
Gerente: Natalia Ospina

Estado declarado
Rojo
Avance reportado: 77%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- La validación con dos tiendas se extendió una semana por el conteo de inventario

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.515.511.924
Ejecutado 383.723.374
Proyección al cierre 2.270.114.693

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
