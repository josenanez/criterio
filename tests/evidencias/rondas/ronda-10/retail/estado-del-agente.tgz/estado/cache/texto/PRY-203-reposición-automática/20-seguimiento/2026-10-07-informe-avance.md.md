<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-07-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Reposición automática

**Código:** PRY-203
**Fecha de corte:** 2026-10-07
**Gerente:** Paula Céspedes

## Estado declarado

**Rojo**

Avance reportado: **31%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 639.825.267 |
| Ejecutado | 509.290.888 |
| Proyección al cierre | 1.136.933.245 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- Concentración del conocimiento en una sola persona
