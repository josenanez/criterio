<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/10-plan/2025-12-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-15 | 2026-04-15 | cerrado
Ambiente de pruebas certificado | 2026-08-04 | 2026-08-04 | cerrado
Integración con el ERP | 2026-11-23 | 2026-11-23 | en curso
Piloto en tiendas | 2027-03-14 | 2027-03-14 | en curso
