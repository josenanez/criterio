<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-08-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Centro de distribución norte

Código: PRY-202

Área dueña: Abastecimiento

Patrocinador: Felipe Arango

Gerente de proyecto: Jorge Medina

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2025-08-23

Objetivo del negocio

Entregar centro de distribución norte para Abastecimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité Comercial el 2025-08-23.

Fechas comprometidas

Fecha

Inicio

2025-09-02

Cierre

2027-02-20

Criterio de éxito

Centro de distribución norte en producción y medido.

Dependencias declaradas

• Ninguna declarada
