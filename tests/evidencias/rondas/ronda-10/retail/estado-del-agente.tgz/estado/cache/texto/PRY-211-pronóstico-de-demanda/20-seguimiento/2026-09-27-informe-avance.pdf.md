<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pronóstico de demanda
Código: PRY-211
Fecha de corte: 2026-09-27
Gerente: Gustavo Neira

Estado declarado
Amarillo
Avance reportado: 77%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 2.824.489.362
Ejecutado 5.067.183.548
Proyección al cierre 9.152.034.764

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
