<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-05-26-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración del ERP

**Código:** PRY-209
**Área dueña:** Mercadeo
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-26

## Objetivo del negocio

Entregar migración del erp para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Arquitectura el 2026-05-26.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-05 |
| Cierre | 2027-10-11 |

## Criterio de éxito

Migración del ERP en producción y medido.

## Dependencias declaradas

- Ninguna declarada
