<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité Comercial · Etiquetas electrónicas de precio

Fecha: 2026-10-14

Asistentes: Óscar Ramírez, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Jorge Medina

Entregar el punto 27

2026-11-01
