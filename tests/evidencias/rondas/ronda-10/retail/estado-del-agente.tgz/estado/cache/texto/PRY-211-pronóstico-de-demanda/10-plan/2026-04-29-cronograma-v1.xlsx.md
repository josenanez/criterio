<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2026-04-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-09 | 2026-07-09 | cerrado
Ambiente de pruebas certificado | 2026-09-09 | 2026-09-09 | cerrado
Integración con el ERP | 2026-11-09 | 2026-11-09 | en curso
Piloto en tiendas | 2027-01-10 | 2027-01-10 | en curso
Despliegue en la cadena | 2027-03-13 | 2027-03-13 | en curso
