<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-17
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **86%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.647.230.813 |
| Ejecutado | 860.644.236 |
| Proyección al cierre | 4.046.399.504 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
