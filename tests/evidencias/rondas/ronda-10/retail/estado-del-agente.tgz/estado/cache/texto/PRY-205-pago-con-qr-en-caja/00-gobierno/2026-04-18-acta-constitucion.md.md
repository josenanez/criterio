<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2026-04-18-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Talento humano
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Expansión
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2026-04-18

## Objetivo del negocio

Entregar pago con qr en caja para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Expansión el 2026-04-18.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-28 |
| Cierre | 2027-01-26 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
