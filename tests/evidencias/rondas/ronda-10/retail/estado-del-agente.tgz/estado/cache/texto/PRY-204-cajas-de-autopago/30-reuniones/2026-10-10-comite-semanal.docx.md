<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cadena de Abastecimiento · Cajas de autopago

Fecha: 2026-10-10

Asistentes: Elena Duarte, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Elena Duarte

Entregar el punto 31

2026-10-29
