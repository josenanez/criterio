<!-- origen: PRY-204-cajas-de-autopago/10-plan/2026-01-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-06-12,2026-06-12,cerrado
Ambiente de pruebas certificado,2026-10-20,2026-10-20,en curso
Integración con el ERP,2027-02-27,2027-02-27,en curso
Piloto en tiendas,2027-07-07,2027-07-07,en curso
