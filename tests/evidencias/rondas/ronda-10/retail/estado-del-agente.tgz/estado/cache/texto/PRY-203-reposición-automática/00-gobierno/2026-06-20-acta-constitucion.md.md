<!-- origen: PRY-203-reposición-automática/00-gobierno/2026-06-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Reposición automática

**Código:** PRY-203
**Área dueña:** Comercial
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-06-20

## Objetivo del negocio

Entregar reposición automática para Comercial.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité Comercial el 2026-06-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-30 |
| Cierre | 2027-06-07 |

## Criterio de éxito

Reposición automática en producción y medido.

## Dependencias declaradas

- Ninguna declarada
