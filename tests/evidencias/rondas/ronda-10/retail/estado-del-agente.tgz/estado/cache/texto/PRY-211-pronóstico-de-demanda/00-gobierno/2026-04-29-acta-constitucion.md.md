<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2026-04-29-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pronóstico de demanda

**Código:** PRY-211
**Área dueña:** Finanzas
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-29

## Objetivo del negocio

Entregar pronóstico de demanda para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité Comercial el 2026-04-29.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-09 |
| Cierre | 2027-03-13 |

## Criterio de éxito

Pronóstico de demanda en producción y medido.

## Dependencias declaradas

- Ninguna declarada
