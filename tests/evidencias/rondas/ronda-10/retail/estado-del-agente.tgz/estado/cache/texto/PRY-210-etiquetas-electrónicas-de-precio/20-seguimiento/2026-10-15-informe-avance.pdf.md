<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-15
Gerente: Óscar Ramírez

Estado declarado
Verde
Avance reportado: 79%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.731.508.632
Ejecutado 2.273.393.946
Proyección al cierre 3.915.554.441

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
