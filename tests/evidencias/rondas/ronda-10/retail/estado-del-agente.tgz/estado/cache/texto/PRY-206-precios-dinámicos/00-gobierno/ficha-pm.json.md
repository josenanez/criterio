<!-- origen: PRY-206-precios-dinámicos/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-206",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "name": {
 "value": "Precios dinámicos",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Comercio electrónico",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Paula Céspedes",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "manager": {
 "value": "Andrés Lozano",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Expansión",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "rojo",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 47,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-15",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-04-15",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "end_date": {
 "value": "2027-01-05",
 "source": "10-plan/2026-10-15-cronograma-v2.csv",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-04-05",
 "start_date": "2026-04-15",
 "end_date": "2026-11-13",
 "reason": "Aprobación del acta de constitución por el Comité de Expansión",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx"
 },
 {
 "version": 2,
 "approved_on": "2026-10-17",
 "start_date": "2026-04-15",
 "end_date": "2027-01-05",
 "reason": "CC-01, ampliación de alcance (+53 días sobre la línea base vigente), autorizada por el comité",
 "source": "20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño de la experiencia aprobado",
 "baseline_date": "2026-05-27",
 "current_date": "2026-05-27",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-15-cronograma-v2.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-07-09",
 "current_date": "2026-07-09",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-15-acta-recibo-ambiente-de-pruebas-certificado.pdf",
 "source": "10-plan/2026-10-15-cronograma-v2.csv"
 },
 {
 "name": "Integración con el ERP",
 "baseline_date": "2026-08-20",
 "current_date": "2026-08-20",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-15-cronograma-v2.csv"
 },
 {
 "name": "Piloto en tiendas",
 "baseline_date": "2026-10-02",
 "current_date": "2026-10-02",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-15-cronograma-v2.csv"
 },
 {
 "name": "Despliegue en la cadena",
 "baseline_date": "2026-11-13",
 "current_date": "2027-01-05",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-10-15-cronograma-v2.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3 (sin más detalle en el acta)",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "exclusions": [
 {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 }
 ]
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2026-04-05-acta-constitucion.docx",
 "source_date": "2026-04-05",
 "state": "found"
 },
 "committed": {
 "value": 3611179640,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 2375369823,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 9737352769,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": "Sistemas Comerciales del Norte",
 "contract_ref": "CT-847",
 "deliverables": [
 {
 "name": "Licenciamiento de la plataforma",
 "due_date": "2026-05-31",
 "amount": 410335213,
 "state": "accepted",
 "evidence": null
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-07-17",
 "amount": 410335213,
 "state": "pending",
 "evidence": null
 },
 {
 "name": "Configuración del catálogo",
 "due_date": "2026-09-02",
 "amount": 410335213,
 "state": "pending",
 "evidence": null
 },
 {
 "name": "Soporte del primer trimestre",
 "due_date": "2026-10-19",
 "amount": 410335213,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": 410335213,
 "source": "20-seguimiento/2026-09-06-factura-ct-847.pdf",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "source": "00-gobierno/2026-04-13-contrato-ct-847.docx"
 },
 {
 "name": "Tecnología para Tiendas Ltda.",
 "contract_ref": "CT-980",
 "deliverables": [
 {
 "name": "Licenciamiento de la plataforma",
 "due_date": "2026-07-02",
 "amount": 599677238,
 "state": "pending",
 "evidence": null
 },
 {
 "name": "Bolsa de horas de desarrollo",
 "due_date": "2026-09-18",
 "amount": 599677238,
 "state": "pending",
 "evidence": null
 }
 ],
 "invoiced": {
 "value": 599677238,
 "source": "20-seguimiento/2026-09-09-factura-ct-980.md",
 "source_date": "2026-09-09",
 "state": "found"
 },
 "source": "00-gobierno/2026-04-12-contrato-ct-980.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 {
 "what": "Cambio en la regulación de datos personales que puede mover el alcance",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión; nadie lo anotó como riesgo)",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-17",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+53 días sobre la línea base vigente",
 "cost_impact": "106.000.000 COP adicionales",
 "decision": "approved",
 "decided_by": "el comité (el documento no dice cuál ni quién firmó)",
 "source": "20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": "Liliana Torres",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-03",
 "original_due_date": "2026-09-13",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 {
 "due_date": "2026-12-03",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-25",
 "original_due_date": "2026-09-14",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-23",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-25",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-11-acta-recibo-3.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-09",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-20-acta-recibo-5.md"
 },
 {
 "who": "Carlos Peña",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-01",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ],
 "notes": "En el comité del 2026-09-27 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-09-27-comite-semanal.md). Dejó de aparecer en la lista desde ese día."
 },
 {
 "who": "Jorge Medina",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-06",
 "original_due_date": "2026-09-28",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "notes": "Sin fecha ('por definir') en los comités del 2026-09-20, 09-27 y 10-04; la primera fecha, 2026-11-01, se dijo el 2026-10-11 (30-reuniones/2026-10-11-comite-semanal.md)."
 },
 {
 "who": "Camilo Beltrán",
 "what": "Revisar el anexo 11",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-04-acta-recibo-11.md"
 },
 {
 "who": "Liliana Torres",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "notes": "En el comité del 2026-10-04 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-10-04-comite-semanal.md). Dejó de aparecer en la lista desde ese día."
 },
 {
 "who": "Diana Molina",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-09",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "notes": "En el comité del 2026-10-11 dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-10-11-comite-semanal.md). Dejó de aparecer en la lista desde ese día."
 },
 {
 "who": "Mauricio Pérez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Validar el ambiente 20",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-11-05",
 "original_due_date": "2026-11-05",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-03",
 "original_due_date": "2026-11-03",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Confirmar la fecha 23",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto («la otra semana»)",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
