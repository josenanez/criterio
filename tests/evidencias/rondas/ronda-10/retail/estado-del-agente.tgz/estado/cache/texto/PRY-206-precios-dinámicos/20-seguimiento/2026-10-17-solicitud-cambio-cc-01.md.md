<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-17-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Precios dinámicos
**Fecha:** 2026-10-17
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +53 días sobre la línea base vigente |
| Costo | 106.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
