<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2025-06-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Marca propia de alimentos

Código: PRY-207

Área dueña: Logística

Patrocinador: Camilo Beltrán

Gerente de proyecto: Felipe Arango

Comité: Comité de Transformación Digital

Producto asociado: marca propia

Fecha de aprobación: 2025-06-26

Objetivo del negocio

Entregar marca propia de alimentos para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Transformación Digital el 2025-06-26.

Fechas comprometidas

Fecha

Inicio

2025-07-06

Cierre

2026-11-16

Criterio de éxito

Marca propia de alimentos en producción y medido.

Dependencias declaradas

• Ninguna declarada
