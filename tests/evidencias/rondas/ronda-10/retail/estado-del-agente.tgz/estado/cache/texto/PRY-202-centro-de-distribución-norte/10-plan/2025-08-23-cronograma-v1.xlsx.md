<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2025-08-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-12-18 | 2025-12-18 | cerrado
Ambiente de pruebas certificado | 2026-04-04 | 2026-04-04 | cerrado
Integración con el ERP | 2026-07-20 | 2026-07-20 | cerrado
Piloto en tiendas | 2026-11-05 | 2026-11-05 | en curso
Despliegue en la cadena | 2027-02-20 | 2027-02-20 | en curso
