<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2025-07-08-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-08-29 | 2025-08-29 | cerrado
Ambiente de pruebas certificado | 2025-10-10 | 2025-10-10 | cerrado
Integración con el ERP | 2025-11-21 | 2025-11-21 | cerrado
Piloto en tiendas | 2026-01-02 | 2026-01-02 | cerrado
Despliegue en la cadena | 2026-02-13 | 2026-02-13 | cerrado
