<!-- origen: PRY-209-migración-del-erp/10-plan/2026-05-26-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-10-06 | 2026-10-06 | cerrado
Ambiente de pruebas certificado | 2027-02-06 | 2027-02-06 | en curso
Integración con el ERP | 2027-06-10 | 2027-06-10 | en curso
Piloto en tiendas | 2027-10-11 | 2027-10-11 | en curso
