<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Precios dinámicos
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Andrés Lozano

Estado declarado
Rojo
Avance reportado: 47%

Lo que pasó en el periodo
- Se recibió el concepto de Jurídica sobre los términos de uso
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.611.179.640
Ejecutado 2.375.369.823
Proyección al cierre 9.737.352.769

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
