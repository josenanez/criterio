<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-10-11
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Carlos Peña, Diana Molina, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-11-19 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-25 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-31 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-11-01 |
| Liliana Torres | Validar el ambiente 12 | 2026-10-27 |
| Ricardo Salas | Aprobar el diseño 13 | 2026-10-15 |
| Diana Molina | Confirmar la fecha 15 | 2026-10-27 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-09 |
| Carlos Peña | Enviar el documento 17 | 2026-10-18 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-28 |
| Paula Céspedes | Validar el ambiente 20 | por definir |
| Gustavo Neira | Aprobar el diseño 21 | 2026-11-05 |
| Gustavo Neira | Actualizar la matriz 22 | 2026-11-03 |
| Beatriz Cuéllar | Confirmar la fecha 23 | por definir |
| Sandra Gil | Entregar el punto 24 | 2026-10-17 |

## Cerrados en esta reunión

- Revisar el anexo 3 (María Restrepo): recibido, acta de recibo del 2026-10-11.

## Lo que se dijo

- Jorge Medina dice que ya entregó «cerrar la prueba 18». No se presentó acta.
