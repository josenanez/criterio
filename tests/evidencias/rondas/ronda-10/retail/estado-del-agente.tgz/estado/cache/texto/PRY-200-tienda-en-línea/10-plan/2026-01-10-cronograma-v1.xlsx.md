<!-- origen: PRY-200-tienda-en-línea/10-plan/2026-01-10-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-03-30 | 2026-03-30 | cerrado
Ambiente de pruebas certificado | 2026-06-07 | 2026-06-07 | cerrado
Integración con el ERP | 2026-08-16 | 2026-08-16 | cerrado
Piloto en tiendas | 2026-10-24 | 2026-10-24 | en curso
Despliegue en la cadena | 2027-01-02 | 2027-01-02 | en curso
