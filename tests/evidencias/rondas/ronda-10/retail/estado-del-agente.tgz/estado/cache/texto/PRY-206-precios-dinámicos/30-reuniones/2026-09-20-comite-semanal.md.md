<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-09-20-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-09-20
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Paula Céspedes, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-10-09 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-11 |
| María Restrepo | Revisar el anexo 3 | 2026-10-22 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-21 |
| Jorge Medina | Confirmar la fecha 7 | 2026-10-06 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-23 |
| Rubén Cárdenas | Enviar el documento 9 | 2026-10-12 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Camilo Beltrán | Revisar el anexo 11 | 2026-10-11 |
| Liliana Torres | Validar el ambiente 12 | 2026-10-06 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Jorge Medina): recibido, acta de recibo del 2026-09-20.
