<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-09-13-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Expansión · Precios dinámicos

**Fecha:** 2026-09-13
**Asistentes:** Andrés Lozano, Carlos Peña, Gustavo Neira, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-09-30 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-09-23 |
| María Restrepo | Revisar el anexo 3 | 2026-10-02 |
| Javier Hoyos | Validar el ambiente 4 | 2026-10-09 |
| Jorge Medina | Aprobar el diseño 5 | 2026-09-29 |
| Carlos Peña | Actualizar la matriz 6 | 2026-10-01 |
| Jorge Medina | Confirmar la fecha 7 | 2026-09-28 |
| Gustavo Neira | Entregar el punto 8 | 2026-10-08 |
