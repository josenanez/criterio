<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-08-19-acta-recibo-ct-600-licenciamiento-de-la-plataforma.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento de la plataforma
Proyecto: PRY-205 · Pago con QR en caja
Fecha de recibo: 2026-08-19
Recibido por: Natalia Ospina
Se recibe a satisfacción el entregable Licenciamiento de la plataforma.
Contrato CT-600 · Datos y Demanda S.A.S..
