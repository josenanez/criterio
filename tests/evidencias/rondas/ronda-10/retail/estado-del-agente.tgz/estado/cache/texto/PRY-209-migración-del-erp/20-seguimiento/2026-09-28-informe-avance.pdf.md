<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-09-28
Gerente: Elena Duarte

Estado declarado
Verde
Avance reportado: 61%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.003.392.488
Ejecutado 1.063.520.052
Proyección al cierre 3.401.366.949

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
