<!-- origen: PRY-206-precios-dinámicos/2026-10-18-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión precios dinámicos — 2026-10-18
estuvieron: Andrés Lozano, Carlos Peña, Diana Molina, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Liliana Torres dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 03/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-28
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
