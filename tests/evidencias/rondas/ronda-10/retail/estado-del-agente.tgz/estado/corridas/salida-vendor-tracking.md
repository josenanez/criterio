Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18; comprobante en `.criterio/terminos/`). Sin preguntas pendientes: no hubo ninguna que contestar.

**Sale de:** contratos `00-gobierno/2026-03-02-contrato-ct-144.md` y `2026-03-05-contrato-ct-836.md`; `20-seguimiento/2026-06-09-acta-recibo-ct-144-licenciamiento-de-la-plataforma.pdf`, `2026-09-02-factura-ct-144.pdf`, `2026-09-05-factura-ct-836.pdf`, `2026-10-17-informe-avance.md`; ficha `estado/records/PRY-201.json`; cifras de `portafolio.py compute` (corte 2026-10-18).

## Proveedores — PRY-201 Programa de fidelización al 2026-10-18

Un solo proveedor, **Tecnología para Tiendas Ltda.**, con dos contratos. El informe de avance del 2026-10-17 declara el proyecto en **verde, 86 %**.

### Tecnología para Tiendas Ltda. — contrato CT-144
**Vigencia:** firmado 2026-03-02; fin, renovación y preaviso: sin dato (el contrato no los trae) · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma (154.265.280) | 2026-06-08 | `accepted` | Acta de recibo 2026-06-09, firmada por Sandra Gil (1 día después de la fecha) | Factura FV-1144, 2026-09-02, 154.265.280 |
| Bolsa de horas de desarrollo (154.265.280) | 2026-08-26 | `pending` — **53 días tarde** | Ninguna | No |
| Configuración del catálogo (154.265.280) | 2026-11-12 | `pending` | Ninguna | No |

Facturado 154.265.280 contra aceptado con acta 154.265.280: cuadra. Pero la factura dice solo «Entregables del contrato CT-144», sin desglose; que corresponda al licenciamiento es una inferencia por el monto.

### Tecnología para Tiendas Ltda. — contrato CT-836
**Vigencia:** firmado 2026-03-05; fin, renovación y preaviso: sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma (311.826.194) | 2026-07-04 | `accepted` según el contrato («recibido») | **Ninguna: no hay acta de recibo** | Factura FV-2836, 2026-09-05, 419.283.282 (global) |
| Bolsa de horas de desarrollo (311.826.194) | 2026-10-17 | `pending` — **1 día tarde** | Ninguna | No |

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado vs aceptado, CT-836 | Cada entregable se factura contra acta de recibo firmada por el gerente. Aceptado: 311.826.194 | Facturado 419.283.282: **107.457.088 por encima** de lo aceptado | contrato CT-836; factura FV-2836 |
| Aceptación de CT-836 | Columna Estado: «recibido» | No existe acta de recibo. Con el criterio de evidencia, el aceptado sustentado es 0 y toda la factura (419.283.282) queda sin sustento | contrato CT-836; carpeta `20-seguimiento` |
| Monto facturado | Los dos entregables de CT-836 suman 623.652.388 | La factura de 419.283.282 no coincide con ningún entregable ni con la suma; el concepto no lo explica | contrato CT-836; FV-2836 |
| Estado del proyecto | — | El informe declara verde, 86 %; el script ve 3 hitos «cumplidos» sin evidencia, sobrecosto proyectado de 22,6 % (4.046.399.504 sobre 3.300.000.000) y dos entregables del proveedor vencidos | informe 2026-10-17; `compute` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-836 · Licenciamiento de la plataforma | `accepted` (contrato: «recibido») | Fecha comprometida 2026-07-04; sin fecha de recibo |

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| CT-144 · Bolsa de horas de desarrollo | Contrato CT-144 | 2026-08-26 | 53 |
| CT-836 · Bolsa de horas de desarrollo | Contrato CT-836 | 2026-10-17 | 1 |

Compromisos dichos en reuniones: ninguno registrado; la carpeta no tiene minutas (`30-reuniones` no existe para este proyecto), así que no puedo decir qué prometió el proveedor en comité.

### Sin dato
- Fecha de terminación, renovación automática y preaviso de **ambos** contratos: ninguno los declara. No puedo decir si hay un preaviso por vencer antes del cierre del proyecto (2027-01-01).
- Qué entregable cubre cada factura: ninguna lo desglosa.
- Si la factura FV-2836 ya se pagó: solo dice «radicada en cuentas por pagar».
- Hay dos contratos con el mismo proveedor y los mismos nombres de entregable («Licenciamiento de la plataforma», «Bolsa de horas de desarrollo»); no hay documento que explique si se solapan. No lo afirmo, lo dejo como pregunta.

## Después
- **Llevar a comité:** FV-2836 radicada por 419.283.282 sin acta de recibo del licenciamiento CT-836; pedir a Sandra Gil el acta o suspender el trámite de pago hasta tenerla. La diferencia contra lo aceptado declarado es 107.457.088.
- Pedir al proveedor y a la gerente el estado de las dos bolsas de horas vencidas.
- Pedir los contratos completos (vigencia y preaviso) antes de decir nada sobre renovación.

*Pie de rigor: borrador de trabajo; no es decisión ni asesoría. Cada dato lleva la cita del documento y la verificación es de quien lo lee. Las cifras derivadas se copiaron de `portafolio.py compute`; las facturas se leyeron como PDF de una página, sin desglose.*
