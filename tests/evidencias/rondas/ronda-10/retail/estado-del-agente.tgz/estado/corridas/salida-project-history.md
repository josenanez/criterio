## Historia · PRY-206 Precios dinámicos · 2026-04-05 a 2026-10-18

**Leí:** 20 documentos del proyecto entre 2026-04-05 y 2026-10-18 (acta de constitución, 2 contratos, 2 cronogramas, 8 documentos de seguimiento, 6 minutas de comité y las notas del 2026-10-18). Además la ficha `ficha-pm.json` y la salida de `compute`, que se derivan de esos documentos y no cuentan como documentos leídos.
**Trimestres sin un solo documento:** ninguno. Pero entre el contrato CT-980 (2026-04-12) y el contrato CT-847 (2026-04-13) por un lado, y la primera minuta (2026-09-06) por otro, no hay ni un documento. En ese hueco caen tres de los cuatro hitos que el plan da por cerrados (2026-05-27, 2026-07-09 y 2026-08-20).

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no se volvieron a registrar.

### En una línea
Un proyecto aprobado el 2026-04-05 para cerrar el 2026-11-13 quedó, el 2026-10-17, con cierre el 2027-01-05 por una sola ampliación de alcance (CC-01, +53 días). El cronograma que ya trae esa fecha nueva es del 2026-10-15, dos días antes de que CC-01 se autorizara. El informe del 2026-10-15 declara Rojo y 47 %, pero el plan da por cerrados 4 de 5 hitos (lo que sustenta entre 80 % y 100 %), y de esos cuatro solo uno tiene acta en la carpeta. Hay 599.677.238 COP facturados por CT-980 sin ningún entregable aceptado.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 53 días (25.0 %) | No calculable: hay una sola declaración (2026-10-15) | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-05 | Acta de constitución (.docx) | Nace el proyecto: 9.500.000.000 COP, inicio 2026-04-15, cierre 2026-11-13. Patrocinadora Paula Céspedes, gerente Andrés Lozano, Comité de Expansión. Dependencias: «ninguna declarada». |
| 2026-04-05 | Cronograma v1 (.csv) | Línea base de 5 hitos. El archivo lleva esa fecha, pero muestra como «cerrado» hitos con fechas hasta 2026-10-02: su contenido es posterior a su fecha. |
| 2026-04-12 | Contrato CT-980 (Tecnología para Tiendas Ltda.) | 2 entregables de 599.677.238 COP, ambos «pendiente». Se factura contra acta de recibo firmada por el gerente. |
| 2026-04-13 | Contrato CT-847 (Sistemas Comerciales del Norte) | 4 entregables de 410.335.213 COP. El de licenciamiento (vence 2026-05-31) figura «recibido» en un contrato fechado antes de ese vencimiento. |
| 2026-04-13 a 2026-09-06 | (ninguno) | Sin documentos. Vencen los hitos del 2026-05-27, 2026-07-09 y 2026-08-20, y los entregables de CT-980 (2026-07-02) y CT-847 (2026-05-31, 2026-07-17). |
| 2026-09-06 | Minuta de comité · Factura FV-2847 (CT-847) | Primera minuta: 4 compromisos abiertos, 5 asistentes. Se radica una factura por 410.335.213 COP. |
| 2026-09-09 | Factura FV-1980 (CT-980) | Se radica por 599.677.238 COP; no hay acta de recibo de ningún entregable de CT-980. |
| 2026-09-13 | Minuta de comité | Los compromisos pasan de 4 a 8; las dos primeras fechas se mueven. |
| 2026-09-20 | Minuta de comité · Acta de recibo del diseño 5 | Primer cierre con acta. 11 compromisos abiertos. |
| 2026-09-27 | Minuta de comité | 14 compromisos abiertos. Carlos Peña dice que entregó «actualizar la matriz 6»; no hay acta. |
| 2026-10-04 | Minuta de comité · Acta de recibo del anexo 11 | Liliana Torres dice que entregó «actualizar la matriz 14»; no hay acta. |
| 2026-10-11 | Minuta de comité · Acta de recibo del anexo 3 | 18 compromisos abiertos, 13 asistentes. Jorge Medina dice que entregó «cerrar la prueba 18»; no hay acta. |
| 2026-10-15 | Informe de avance · Cronograma v2 · Acta de recibo «Ambiente de pruebas certificado» | Estado Rojo, 47 %. El cronograma v2 ya mueve «Despliegue en la cadena» de 2026-11-13 a 2027-01-05. El acta recibe un hito cuya fecha en el plan es 2026-07-09. |
| 2026-10-17 | Solicitud de cambio CC-01 | Ampliación de alcance, +53 días sobre la línea base vigente, +106.000.000 COP. «Autorizada por el comité», sin nombrar cuál ni quién firmó. |
| 2026-10-18 | Notas de reunión (.txt) | Liliana Torres vuelve a mover «enviar el documento 1» (sexta vez, al 2026-12-03). Se comenta un riesgo de proveedor que nadie anotó. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-17 | 2027-01-05 | Ampliación de alcance (CC-01) | Solicitud de cambio CC-01, que dice «autorizada por el comité» sin nombrar el comité ni quién firmó. |

Atraso acumulado contra la línea base original: 53 días, 25.0 %. Contra la vigente: 0 días.
Dos hechos que conviene tener presentes:
- El cronograma v2 con la fecha nueva tiene fecha 2026-10-15; la autorización es del 2026-10-17.
- `compute` marca CC-01 como aprobado sin línea base nueva; la línea base 2 de la ficha tiene como única fuente la propia solicitud.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| (ninguna) | Sin cambios documentados de patrocinador, gerente o comité. | Acta del 2026-04-05 frente al informe del 2026-10-15: el mismo gerente, Andrés Lozano. |

Lo que sí se ve: la asistencia al comité pasa de 5 personas (2026-09-06) a 13 (2026-10-11) y 14 en las notas del 2026-10-18, sin que ningún documento diga por qué.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Liliana Torres | Enviar el documento 1 | 6 | original 2026-09-13 → 2026-09-30, 2026-10-09, 2026-10-16, 2026-11-02, 2026-11-19, 2026-12-03 |
| Paula Céspedes (patrocinadora) | Cerrar la prueba 2 | 5 | original 2026-09-14 → 2026-09-23, 2026-10-11, 2026-10-24, 2026-11-14, 2026-11-25 |

Otros compromisos: 6 vencidos sin evidencia, 3 sin fecha, y 3 «ya lo entregué» sin acta, tras lo cual el compromiso desapareció de la lista (Carlos Peña, Liliana Torres, Jorge Medina).

### Desde cuándo lo declarado no se sostiene
Solo hay una declaración en la carpeta, el informe del 2026-10-15. Con una sola no se puede decir desde cuándo se deslizó el estado declarado, y no lo invento. Lo que sí se ve:
- **Primer hito sin evidencia:** «Diseño de la experiencia aprobado», fecha 2026-05-27, cerrado en el plan y sin acta en la carpeta. Siguen sin evidencia «Integración con el ERP» (2026-08-20) y «Piloto en tiendas» (2026-10-02).
- **Qué se siguió reportando:** el informe del 2026-10-15 no menciona CC-01 ni el atraso y trae 47 %. Los hitos cerrados que muestra el plan sustentan entre 80 % y 100 %, una distancia de 33 puntos. También deja sin dueño ni fecha el riesgo de concentración del conocimiento y la pérdida de dos semanas por rotación.
- Las 7 señales del script sin explicación en el informe: compromisos vencidos, compromisos reprogramados, hitos sin evidencia, avance contra plan, desviación en tiempo, entregables tardíos del proveedor y facturación sin entrega.

### Lecciones ancladas a un hecho
1. **Un hito cerrado necesita su acta archivada.** El hito de 2026-05-27 consta como cerrado en un cronograma fechado 2026-04-05 y sigue sin acta el 2026-10-18; el acta del hito «Ambiente de pruebas certificado» (fecha de plan 2026-07-09) se firmó el 2026-10-15. Efecto: 3 de los 4 hitos cerrados no se pueden sustentar.
2. **No facturar sin acta de recibo.** CT-980 dice que cada entregable se factura contra acta. FV-1980 (2026-09-09, 599.677.238 COP) se radicó sin ninguna. Efecto: 599.677.238 COP facturados con 0 entregables aceptados. En CT-847, FV-2847 (2026-09-06, 410.335.213 COP) se apoya en un entregable marcado «recibido» sin acta en la carpeta.
3. **La fecha nueva no precede a su autorización.** El cronograma v2 con 2027-01-05 es del 2026-10-15 y CC-01 es del 2026-10-17. Efecto: durante dos días el plan vigente no coincidió con la línea base aprobada.
4. **Un «ya lo entregué» sin acta no cierra el compromiso.** Pasó 3 veces (2026-09-27, 2026-10-04, 2026-10-11) y el compromiso dejó de aparecer en la lista sin acta. Efecto: 3 compromisos que `compute` sigue contando como abiertos o vencidos.

Quedan sin lección: la causa del atraso (el informe solo habla de rotación de un desarrollador) y cuál es el comité de CC-01. No hay hecho que las ancle.

### Lo que no sé
- Qué se habló fuera de estos documentos, incluidos los 146 días de silencio documental entre abril y septiembre.
- Si existe la serie de informes de avance anteriores al del 2026-10-15; no están en la carpeta.
- Quién firmó la autorización de CC-01.
- Si la proyección de 9.737.352.769 COP incluye los 106.000.000 COP de CC-01.

### Pie de rigor
Borrador de trabajo sobre 20 documentos de la carpeta; cada dato sale del documento citado y las cifras derivadas, de `compute` al 2026-10-18. Los 146 días del hueco documental son un recuento mío de fechas (no salen de `compute`) y conviene verificarlos. No atribuyo intención: que el atraso quedara sin documentar entre abril y septiembre no dice que alguien lo ocultara. La verificación es suya.

Puedo llevar esta historia al cierre del proyecto, o al comité si hay una decisión que sale de ella (por ejemplo, quién respalda CC-01 y qué se hace con las dos facturas).
