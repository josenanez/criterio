# Rostrum — Retail (modo: para mirarlo un rato)

Términos: ya vigentes para esta versión (0.5.0, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta pedirlos de nuevo.

Elegiste «para mirarlo un rato» (sesión sin interfaz: tomé la forma sugerida). Se levanta en segundos y se apaga con Ctrl-C. No exige nada a seguridad.

- Informe servido: `reportes/` (ya existe: 13 proyectos, 7 productos, decisiones).
- Estado: `estado/`
- Dirección: `http://127.0.0.1:8787`, solo en este equipo.
- Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto; enlaza a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto; enlaza a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda correos.

Las peticiones del formulario se quedan en cola hasta que el agente despierte (`portafolio.py due` / `requests`); una abierta rompe el silencio de `/portfolio-wake`.

Para que quede corriendo después: `--abierto`, que no trae autenticación y hay que publicarlo detrás del control de acceso de la organización (host y puerto dentro de la red, equipo encendido, nada más).

Cierre: este enlace es solo tuyo (127.0.0.1); no se lo pases a nadie. El informe es del 2026-10-18 (09:13); la portada muestra su fecha y se desactualiza en cuanto cambien los documentos hasta regenerarlo con `/portfolio-report html`.
