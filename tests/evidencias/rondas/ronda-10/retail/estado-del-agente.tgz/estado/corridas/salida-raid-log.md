**De qué documentos sale:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211), que a su vez citan los informes de avance, las actas de constitución y las minutas de `documentos/proyectos/`; releí las minutas, notas de reunión y la sección "Dependencias declaradas" de cada acta. No hay RAID previo con historial de movimiento: las fichas solo traen lo que cada informe de avance lista como "riesgos abiertos" y lo que reporta como problema.

## RAID — portafolio (13 proyectos) al 2026-10-18
13 riesgos · 0 supuestos · 21 incidencias · 6 dependencias (40 ítems)
40 sin doliente · 40 sin fecha · 40 sin probabilidad ni impacto · 1 no registrado formalmente
"Sin movimiento": no se puede medir. Cada proyecto tiene un solo informe y ningún ítem trae fecha de último movimiento, así que no hay dos períodos que comparar.

### Reclasificado
- **6 "El proveedor no ha confirmado la fecha de la última entrega"** (PRY-200, 202, 207, 208, 209, 210) venían como riesgo. Dependen de un tercero y ya es un hecho que no confirmó, así que pasan a **dependencia declarada**, no acordada. Ninguna lleva código de proyecto porque el proveedor es externo.
- Ninguna acta declara dependencias ("Ninguna declarada" en las 13). **No hay dependencias entre proyectos**, así que el cruce de portafolio (la contraparte movió su fecha) no tiene nada que cruzar. Eso no prueba que no existan: puede que no se hayan declarado.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-200-3, PRY-201-2 | Incidencia | Hallazgo de seguridad en los medios de pago | sin doliente | 2026-10-07 / 2026-10-17 | Sin doliente ni fecha de resolución, en proyectos que declaran verde. Decisión: quién lo resuelve y para cuándo. |
| PRY-200-2, 201-3, 203-3, 204-2, 210-2 | Incidencia | La prueba de carga de temporada no alcanzó el umbral y se repite | sin doliente | 2026-09-30 a 2026-10-17 | Cinco proyectos con el mismo problema, con la temporada cerca. Decisión: si se trata como un asunto de portafolio con un solo doliente. |
| PRY-199-4, 201-4, 203-4, 204-3, 207-3, 208-3 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | sin doliente | 2026-09-30 a 2026-10-17 | Afecta a seis proyectos a la vez. La línea base no refleja la fecha real. En PRY-208 la fecha fin de la ficha (2026-02-13) ya pasó. Decisión: replanificar con control de cambios. |
| PRY-206-3 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-18 | Dicho en reunión y sin registrar. Hay una revisión con el proveedor comprometida para 2026-10-28 (Óscar Ramírez). Decisión: formalizarlo antes de esa revisión. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase ("nadie lo anotó como riesgo") | Riesgo | PRY-206, notas de reunión | 2026-10-18 |

Las demás minutas (PRY-199, 200, 202, 203, 204, 206 comités de 2026-09-06 a 2026-10-11, 208, 210, 211) solo traen tablas de compromisos; no dicen ningún riesgo al pasar. No agregué nada que no esté dicho.

### Sin doliente o sin fecha
Los 40 ítems carecen de doliente, fecha, probabilidad e impacto. Es un hallazgo, no se rellenó. Escala de valoración: ninguna definida en la configuración; al valorar se usaría alta, media y baja.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-200-1 | Proveedor (sin contrato en la carpeta) | No | No confirmó la fecha de la última entrega |
| PRY-202-1 | Proveedor (sin contrato en la carpeta) | No | Ídem |
| PRY-207-2 | Proveedor (sin contrato en la carpeta) | No | Ídem |
| PRY-208-2 | Proveedor (sin contrato en la carpeta) | No | Ídem |
| PRY-209-1 | Proveedor | No | Ídem |
| PRY-210-1 | Proveedor | No | Ídem |

### Registro completo
Prob., impacto, doliente y fecha: "no dicho" en todos. Último movimiento: fecha del informe en que se reporta, o "sin movimiento registrado".

| Id | Tipo | Qué | Último movimiento |
|---|---|---|---|
| PRY-199-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-199-2 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | sin movimiento registrado |
| PRY-199-3 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-10-16 |
| PRY-199-4 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-10-16 |
| PRY-200-1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-200-2 | Incidencia | Prueba de carga de temporada bajo el umbral pactado; se repite | desde 2026-10-07 |
| PRY-200-3 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-07 |
| PRY-200-4 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-10-07 |
| PRY-201-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-201-2 | Incidencia | Hallazgo de seguridad en los medios de pago | desde 2026-10-17 |
| PRY-201-3 | Incidencia | Prueba de carga de temporada bajo el umbral pactado; se repite | desde 2026-10-17 |
| PRY-201-4 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-10-17 |
| PRY-202-1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-203-1 | Riesgo | Congelamiento de cambios en temporada alta | sin movimiento registrado |
| PRY-203-2 | Riesgo | Concentración del conocimiento en una sola persona | sin movimiento registrado |
| PRY-203-3 | Incidencia | Prueba de carga de temporada bajo el umbral pactado; se repite | desde 2026-10-07 |
| PRY-203-4 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-10-07 |
| PRY-204-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-204-2 | Incidencia | Prueba de carga de temporada bajo el umbral pactado; se repite | desde 2026-09-30 |
| PRY-204-3 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-09-30 |
| PRY-205-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-205-2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-10-18 |
| PRY-205-3 | Incidencia | Validación con dos tiendas extendida una semana por el conteo de inventario | desde 2026-10-18 |
| PRY-206-1 | Riesgo | Concentración del conocimiento en una sola persona | sin movimiento registrado |
| PRY-206-2 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-206-3 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | 2026-10-18 |
| PRY-206-4 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-10-15 |
| PRY-207-1 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | sin movimiento registrado |
| PRY-207-2 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-207-3 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-10-11 |
| PRY-208-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-208-2 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-208-3 | Incidencia | Despliegue reprogramado por el congelamiento de fin de año; ningún cronograma posterior a v1 recoge la nueva fecha | desde 2026-10-07 |
| PRY-208-4 | Incidencia | Validación con dos tiendas extendida una semana por el conteo de inventario | desde 2026-10-07 |
| PRY-209-1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-210-1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega | sin movimiento registrado |
| PRY-210-2 | Incidencia | Prueba de carga de temporada bajo el umbral pactado; se repite | desde 2026-10-15 |
| PRY-210-3 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-10-15 |
| PRY-211-1 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | sin movimiento registrado |
| PRY-211-2 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | desde 2026-09-27 |

## Lo que no sé
- Si los mismos textos repetidos entre proyectos (rotación del desarrollador en seis, regulación de datos en siete) son el mismo hecho o un texto de plantilla de los informes. Cada ítem cita su informe, pero no lo verifiqué contra otra fuente.
- La fecha "desde" de una incidencia es la del informe que la reporta, no la fecha en que ocurrió.
- Si los ítems tienen doliente fuera de los documentos. Solo digo lo que los documentos muestran.
- Si PRY-199 y PRY-205 (jefes de tienda, validación de tiendas) comparten recursos con otros proyectos: ningún documento lo dice.

## Después
Puedo subir a comité los cuatro grupos de "Necesitan decisión ahora", cada uno con la decisión formulada. También puedo proponer dolientes para los 40 ítems sin doliente (proponer, no asignar). ¿Quieres que lo haga?

*Pie de rigor: borrador de trabajo hecho solo con los documentos citados, sin asesoría; la verificación es tuya. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-18 (v1.1, familia 0.5.0).*
