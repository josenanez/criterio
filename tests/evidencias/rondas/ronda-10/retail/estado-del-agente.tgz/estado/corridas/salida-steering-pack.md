**Fichas cargadas:** las 13 de `estado/records/` (PRY-199 a PRY-211), con corte 2026-10-18; PRY-206 trae además la ficha del gerente. Cifras derivadas copiadas de `portafolio.py compute` (corte 2026-10-18). Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta registrarlos de nuevo.

# Comité de proyectos — 2026-10-25
7 decisiones · 6 escalamientos sin decisión asociada · 11 proyectos con hallazgos de 13 (63 señales abiertas; 5 proyectos que declaran verde están contradichos por sus documentos: PRY-200, 201, 202, 204 y 209)

La fecha 2026-10-25 es el próximo comité según la configuración. El paquete se preparó el 2026-10-18.

## Decisiones del comité anterior
No hay registro. La carpeta no tiene minuta ni acta de un comité de PMO anterior, y ninguna ficha guarda decisiones de comité de portafolio. No puedo decir qué se decidió ni qué quedó abierto; el ciclo se empieza a cerrar a partir de este comité (ver «Después»).

El único antecedente es de proyecto: PRY-206 CC-01 figura aprobada por «el comité» sin decir cuál ni quién firmó (decisión 3).

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro previo | — | — | — |

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de fecha, de presupuesto y de pago en cada proyecto, y se declara por escrito?
**Proyecto:** los 13 (`identity.authority` no aparece en ninguna ficha: 13 de 13). · **Quién decide:** el comité mismo, con los patrocinadores. Ningún documento dice quién más puede fijarlo. · **Si no se decide hoy:** las decisiones 3 a 5 se votan sin poder verificar que quien las toma tiene la facultad, y una aprobación como CC-01 de PRY-206 («el comité», sin firma) se repite.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar hoy umbrales de autoridad (gerente, patrocinador, comité) y anotarlos en cada acta | Sin cambio | Una sesión; registrar en las 13 actas: sin dato de cuánto toma | Sin dato |
| B. Fijar la regla solo para los proyectos con decisión hoy (PRY-200, 201, 206, 208) | Sin cambio | Más corto; deja 9 sin regla | Sin dato |
| C. No fijarla; el comité decide caso a caso | Sin cambio | Ninguno hoy | Cada decisión queda sin autoridad comprobable |

**Recomendación:** A. Es la causa común de las decisiones 3, 4 y 5 y cuesta una sesión. Es recomendación mía, no una cláusula de ningún documento.

### [2] ¿Se suspende el trámite de pago a Tecnología para Tiendas Ltda. en PRY-201 y PRY-206 hasta que haya acta de recibo de lo facturado?
**Proyectos:** PRY-201 (CT-836) y PRY-206 (CT-980), mismo proveedor. · **Quién decide:** no determinable (decisión 1); quien aprueba el pago consta en el contrato CT-836 como el gerente, que firma el acta de recibo. · **Si no se decide hoy:** FV-2836 sigue «radicada en cuentas por pagar» (no sé si ya se pagó) y la facturación de PRY-206 sigue sin entrega aceptada.

Lo que muestran los documentos:
- **PRY-201 · CT-836:** facturado 419.283.282 COP contra aceptado declarado 311.826.194. La diferencia es 107.457.088 COP. El licenciamiento figura «recibido» sin acta de recibo; con evidencia el aceptado sustentado es 0. El monto facturado no coincide con ningún entregable ni con su suma (623.652.388).
- **PRY-206 · CT-980:** facturado 599.677.238 COP, aceptado 0 de 2 entregables, con licenciamiento 108 días tarde y bolsa de horas 30 días tarde.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender el pago de ambas facturas hasta acta de recibo firmada | Sin cambio | Puede tensar la relación; el efecto en las entregas pendientes del proveedor es sin dato | No se paga lo no sustentado: 419.283.282 en PRY-201 y 599.677.238 en PRY-206, si no se pagaron aún |
| B. Pagar solo lo aceptado con acta (PRY-201: 154.265.280 de CT-144 ya cuadra) y retener el resto | Sin cambio | Ídem | Retención parcial; el monto exacto depende de las actas |
| C. Dejar el trámite como está | Sin cambio | Ninguno | Riesgo de pagar sobre entregables sin recibo |

**Recomendación:** A hasta que aparezcan las actas, y pedir a la gerente de PRY-201 (Sandra Gil, que firmó el acta de CT-144) el acta o su ausencia. Primero verificar en cuentas por pagar si alguna ya se pagó: ningún documento lo dice.

### [3] ¿Ratifica el comité la solicitud de cambio CC-01 de PRY-206 (+53 días, +106.000.000 COP, ampliación de alcance) con acta firmada, o la devuelve?
**Proyecto:** PRY-206 Precios dinámicos. · **Quién decide:** no determinable; el documento dice «el comité» sin nombrar cuál ni quién firmó. · **Si no se decide hoy:** `compute` marca CC-01 como aprobada sin línea base nueva (`change_without_baseline`, 53 días) y el atraso contra el original queda en 53 días (25,0 %) sin respaldo de aprobación.

Datos: solicitada 2026-10-17; alcance «ampliación sin detalle de qué se amplía»; fin vigente 2027-01-05; proyección 9.737.352.769 COP contra aprobado 9.500.000.000 COP (+2,5 %). El proyecto declara rojo, 47 % contra 80-100 % que sostiene el plan (4 de 5 hitos cumplidos, 3 sin evidencia).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta firmada y abrir línea base 2 (la 1 no se borra) | Ampliación; hay que definir qué se amplía | +53 días | +106.000.000 COP |
| B. Devolverla para completar el alcance y el motivo antes de aprobar | Se define primero | El atraso sigue sin aprobación mientras tanto | Sin dato |
| C. Rechazarla y volver a la fecha original | Sin la ampliación | Se pide plan de recuperación; viabilidad sin dato | Sin los 106.000.000 |

**Recomendación:** B. Hoy no se puede juzgar el cambio porque ni el comité que lo aprobó ni el alcance están en el documento. Ratificar sin eso convertiría un atraso de 53 días en línea base.

### [4] ¿Aprueba el comité mover 30 días la salida de PRY-200 (2027-01-02 → 2027-02-01) y decide qué pasa con el piloto del 2026-10-24?
**Proyecto:** PRY-200 Tienda en línea. · **Quién decide:** el Comité de Arquitectura, por defecto (sin autoridad declarada); patrocinador Gustavo Neira, gerente Jorge Medina. · **Si no se decide hoy:** el piloto del 2026-10-24 ocurre o no antes de que nadie decida si se mueve. Los 18.000.000.000 COP aprobados se proyectan en 18.137.414.819 (+0,8 %) sin el cambio.

Falta: quién pide el cambio, el motivo, el costo y si el piloto se mueve (todos «no consta»). El proyecto declara verde, 26 %, contra 60-80 % que sostiene el plan.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar +30 días, con piloto movido | Sin cambio declarado | Cierre 2027-02-01 | Sin dato; 30 días más de equipo no están costeados |
| B. Aprobar +30 días, piloto se mantiene | Sin cambio declarado | Cierre 2027-02-01; el piloto corre con las 3 incidencias abiertas | Sin dato |
| C. Devolver hasta tener solicitante, motivo y costo | Sin cambio | Cierre vigente 2027-01-02 | Ninguno hoy |

**Recomendación:** C. La solicitud no se puede evaluar completa. Pedir solicitante, motivo, costo y decisión sobre el piloto antes del 2026-10-24, y citar un comité corto si hace falta. Esto es recomendación mía.

### [5] PRY-208: ¿se revisa el presupuesto y se replanifica, o se congela el gasto hasta verificar el avance real?
**Proyecto:** PRY-208 Domicilios en dos horas. · **Quién decide:** no determinable (decisión 1). · **Si no se decide hoy:** el proyecto sigue gastando contra una fecha de cierre pasada y una proyección fuera de umbral.

Datos: fecha fin en la ficha 2026-02-13, vencida; ningún documento la reemplaza. Proyección 22.832.718.095 COP contra aprobado 18.000.000.000 (+26,8 %); comprometido 14.480.871.456 (80,4 %); ejecutado 4.408.959.068 (24,5 %). Declara rojo y 37 %, mientras los 5 hitos figuran cumplidos (4 sin evidencia). Los datos de identidad tienen 15 meses de antigüedad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Congelar nuevos compromisos y verificar el avance con evidencia antes de decidir | Sin cambio | Una verificación; duración sin dato | No se agrega comprometido a los 14.480.871.456 |
| B. Aprobar ya un presupuesto y fecha nuevos | Sin dato | Fecha nueva sin sustento | Hasta la proyección de 22.832.718.095 |
| C. Recortar alcance para volver a 18.000.000.000 | Se recorta; qué, sin dato | Sin dato | Dentro del aprobado |

**Recomendación:** A. Los documentos no dicen cuál es el avance real (cinco hitos cumplidos frente a 37 %). Aprobar plata nueva sobre esa contradicción no tiene base.

### [6] ¿Se replanifica con control de cambios el despliegue de los seis proyectos afectados por el congelamiento de fin de año?
**Proyectos:** PRY-199, 201, 203, 204, 207 y 208 (incidencia en sus seis informes; ningún cronograma posterior a v1 recoge la fecha nueva). · **Quién decide:** no determinable. Afecta a varios proyectos, así que excede al gerente de cada uno. · **Si no se decide hoy:** la línea base de los seis no refleja la fecha real y los porcentajes de atraso que reporta el portafolio se miden contra una fecha que ya no rige.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Una solicitud de cambio por proyecto, con la fecha posterior al congelamiento | Sin dato | Fecha nueva por proyecto; sin dato | Sin dato |
| B. Una sola decisión de portafolio sobre la ventana de despliegue y luego cambios individuales | Sin dato | Más coherente entre proyectos; sin dato de duración | Sin dato |
| C. Mantener las fechas v1 | Sin cambio | Se sabe que no se cumplirán | Sin dato |

**Recomendación:** B, porque una ventana común evita seis fechas distintas para el mismo congelamiento. Los documentos no traen la ventana ni sus fechas: hay que pedirlas.

### [7] ¿Quién es el responsable único del hallazgo de seguridad en medios de pago y de la prueba de carga de temporada que no alcanzó el umbral?
**Proyectos:** hallazgo de seguridad en PRY-200 y PRY-201; prueba de carga en PRY-200, 201, 203, 204 y 210. · **Quién decide:** no determinable; ninguno tiene doliente en los documentos. · **Si no se decide hoy:** siguen 7 incidencias sin doliente ni fecha de resolución, con la temporada cerca y dos proyectos que declaran verde con el hallazgo abierto.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un doliente de portafolio por cada asunto, con fecha de resolución | Sin cambio | Fecha a fijar hoy | Sin dato |
| B. Que cada gerente asigne el suyo | Sin cambio | Más lento; riesgo de resolver cinco veces lo mismo | Sin dato |
| C. Dejarlas en cada informe | Sin cambio | Ninguno | Sin dato; el estado «verde» sigue sin reflejarlas |

**Recomendación:** A. Es el mismo problema en varios proyectos. Si el texto repetido entre informes es el mismo hecho o una plantilla, no lo verifiqué (ver «Anexo»).

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-201 | Proyección 4.046.399.504 COP contra aprobado 3.300.000.000 (+22,6 %), con avance declarado 86 % y verde | Informe 2026-10-17 | Explicación de la gerente antes del comité; sale de umbral (10 %) |
| PRY-205 | Declara rojo, 77 % contra 40-60 % que sostiene el plan; hito «Integración con el ERP» vencido hace 9 días (2026-10-09) | 2026-10-09 | Fecha nueva del hito y por qué el porcentaje declarado supera al plan |
| PRY-206 | 6 compromisos vencidos (Javier Hoyos ×2, Jorge Medina, Ricardo Salas, Liliana Torres, Sandra Gil) y 2 reprogramados 6 y 5 veces (Liliana Torres, Paula Céspedes), 3 sin fecha | Desde 2026-10-06 | Decidir si la reprogramación continua se trata como un problema de la gerencia |
| PRY-206 | Riesgo dicho en reunión y sin registrar: el proveedor podría no llegar con el equipo completo; revisión con el proveedor el 2026-10-28 (Óscar Ramírez) | 2026-10-18 | Registrarlo con doliente antes del 2026-10-28 |
| PRY-206 | Sistemas Comerciales del Norte (CT-847): 2 entregables vencidos hace 93 y 46 días y un licenciamiento aceptado sin acta | Desde 2026-07-17 | Estado de las bolsas y el acta |
| PRY-202 y PRY-203 | Compromisos vencidos: Jorge Medina, «punto 37», 16 días; Carlos Peña, «punto 39», 10 días. PRY-203 declara rojo | 2026-10-02 y 2026-10-08 | Fecha y evidencia de cada uno |

## Para conocimiento
- **PRY-199** Iluminación LED: verde, 20 %; sin señales abiertas.
- **PRY-200** Tienda en línea: verde contradicho (26 % contra 60-80 %); decisión 4.
- **PRY-201** Programa de fidelización: verde contradicho; decisiones 2 y 6.
- **PRY-202** Centro de distribución norte: verde contradicho; 3 hitos cumplidos sin evidencia; datos de identidad de 14 meses.
- **PRY-203** Reposición automática: rojo declarado; compromiso vencido.
- **PRY-204** Cajas de autopago: verde con un hito cumplido sin evidencia.
- **PRY-205** Pago con QR: rojo; ver escalamientos.
- **PRY-206** Precios dinámicos: rojo; decisiones 2 y 3.
- **PRY-207** Marca propia de alimentos: rojo, 26 % contra 75-100 %; fin vigente 2026-11-16; datos de 16 meses.
- **PRY-208** Domicilios en dos horas: rojo; decisión 5.
- **PRY-209** Migración del ERP: verde contradicho solo por avance (61 % contra 25-50 %, adelantado).
- **PRY-210** Etiquetas electrónicas de precio: verde, 79 %; sin señales abiertas.
- **PRY-211** Pronóstico de demanda: amarillo, 77 % contra 40-60 %; compromiso de María Restrepo vencido 2 días.

## Anexo

### Estado de cada proyecto
| Proyecto | Declara | Avance declarado | Plan sostiene | Señales | Silencio (días) |
|---|---|---|---|---|---|
| PRY-199 | verde | 20,0 % | 20-40 % | 0 | 2 |
| PRY-200 | verde | 26,0 % | 60-80 % | 4 | 4 |
| PRY-201 | verde | 86,0 % | 60-80 % | 9 | 1 |
| PRY-202 | verde | 67,0 % | 60-80 % | 5 | 2 |
| PRY-203 | rojo | 31,0 % | 20-40 % | 2 | 11 |
| PRY-204 | verde | 55,0 % | 25-50 % | 2 | 8 |
| PRY-205 | rojo | 77,0 % | 40-60 % | 3 | 0 |
| PRY-206 | rojo | 47,0 % | 80-100 % | 23 | 0 |
| PRY-207 | rojo | 26,0 % | 75-100 % | 3 | 7 |
| PRY-208 | rojo | 37,0 % | 100 % | 7 | 5 |
| PRY-209 | verde | 61,0 % | 25-50 % | 2 | 0 |
| PRY-210 | verde | 79,0 % | 50-75 % | 0 | 0 |
| PRY-211 | amarillo | 77,0 % | 40-60 % | 3 | 0 |

Total: 63 señales en 11 de 13 proyectos; 0 sin línea base; 0 problemas de ficha.

### Contradicciones abiertas
- Verde declarado contra la evidencia: PRY-200, 201, 202, 204, 209.
- Hitos «cumplidos» sin evidencia en PRY-200, 201, 202, 203, 204, 205, 206, 207, 208 y 211. En las fichas ninguna fuente está marcada como evidencia (0 en las 13), así que este recuento no distingue un hito sin respaldo de un respaldo que la ficha no pudo marcar.
- PRY-208: 5 de 5 hitos cumplidos contra 37 % declarado.
- PRY-206: compute registra la línea base movida 53 días y a la vez marca CC-01 sin línea base nueva.

### Vacíos de información
- Autoridad (`identity.authority`): ausente en 13 de 13. Fase (`identity.phase`): ausente en 13 de 13. Producto: ausente en PRY-202, 203, 206, 209, 210 y 211.
- Datos de identidad y plan con más de 12 meses: PRY-202 (14), PRY-207 (16), PRY-208 (15).
- Fechas de fin, renovación y preaviso de los contratos CT-144 y CT-836: sin dato.
- Si FV-2836 y las facturas de CT-980 ya se pagaron: sin dato.
- Los textos repetidos entre proyectos (rotación del desarrollador en seis, regulación de datos personales en siete) pueden ser el mismo hecho o texto de plantilla: no lo verifiqué.
- Dependencias entre proyectos: ninguna declarada (13 de 13 actas dicen «Ninguna declarada»); eso no prueba que no existan.

## Pie
Criterio, familia 0.5.0 · fichas aplicadas: 13 (`estado/records/`, corte 2026-10-18) · términos vigentes v1.1, aceptados por José Francisco Ñáñez el 2026-10-18: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

**Campos inciertos:** quién tiene autoridad en cada proyecto; quién firmó CC-01; si las facturas se pagaron; el costo de los cambios de PRY-200 y PRY-206 sobre horas; si los incidentes repetidos son hechos distintos; la fecha y el responsable de cada incidencia.

Borrador de trabajo, no decisión ni asesoría. Cada dato viene de un documento citado en la ficha y la verificación es de quien lo lee.

## Después
Cuando el comité sesione puedo registrar sus decisiones en las fichas. Ahí se cierra el ciclo y el material del próximo comité empieza con «Decisiones del comité anterior» llena.
