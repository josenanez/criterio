# Corrida del 2026-10-18 · project-closure

13 proyectos · 42 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Cierre por decisión de PRY-208, que sigue en rojo con 37% y sin cierre declarado. Criterio de éxito sin evidencia de producción ni medición. No supo: fecha de despliegue, alcance real, aceptación de 4 de 5 hitos, dolientes de RAID, qué es el punto 35.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Cierre de PRY-208 sobre su ficha (`estado/records/PRY-208.json`) y estos cinco documentos de `documentos/proyectos/PRY-208-domicilios-en-dos-horas/`: acta de constitución (2025-07-08), cronograma v1 (2025-07-08), informe de avance (2026-10-07), acta de recibo del piloto (2026-10-13) y comité semanal (2026-10-06). Cifras de `portafolio.py compute`, corrida del 2026-10-18. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-18.

## Cierre — PRY-208 Domicilios en dos horas — 2026-10-18

**Antes de nada:** ningún documento de la carpeta declara que el proyecto terminó. El último informe (2026-10-07) lo declara en **rojo, con 37 % de avance**, y habla de un despliegue reprogramado. Este cierre es, por tanto, un **cierre por decisión, no por cumplimiento**: sirve para dejar el balance de lo que hay, no para certificar que el proyecto terminó.

### Contra lo comprometido
**Criterio de éxito:** "Domicilios en dos horas en producción y medido." (acta de constitución, 2025-07-08, sección Criterio de éxito.)
**Se cumplió:** **no se puede determinar**. En la carpeta no hay evidencia de puesta en producción ni de medición del tiempo de entrega. Es lo que el criterio exige, y su ausencia no equivale a que no se haya hecho.

| Entregable comprometido (hito del cronograma v1) | Fecha base | Estado declarado | Evidencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-08-29 | cumplido | ninguna |
| Ambiente de pruebas certificado | 2025-10-10 | cumplido | ninguna |
| Integración con el ERP | 2025-11-21 | cumplido | ninguna |
| Piloto en tiendas | 2026-01-02 | cumplido | acta de recibo del 2026-10-13 (Camilo Beltrán): una línea, "se recibe a satisfacción"; sin criterios de aceptación ni firma del patrocinador |
| Despliegue en la cadena | 2026-02-13 | cumplido | ninguna |

- El script marca 4 de los 5 hitos como "cumplido sin evidencia" (415, 373, 331 y 247 días desde su fecha base).
- El avance declarado (37 %) no cuadra con los hitos declarados (5 de 5, que sostendrían 100 %): diferencia de 63,0 puntos. Los documentos no explican cuál de las dos cifras es la correcta.
- El único hito con evidencia es el piloto, recibido el 2026-10-13, después de su fecha base del 2026-01-02.
- El acta define el alcance como "Componente 1, 2, 3" sin detalle. Con ese texto no se puede contrastar qué se entregó contra qué se comprometió.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato. El acta solo dice "Lo que otro proyecto cubre" (texto sin contenido). No hay solicitud de cambio ni decisión de comité que recorte alcance. | — | — |

El riesgo de regulación de datos personales "puede mover el alcance" (informe 2026-10-07), pero no hay decisión registrada.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-02-13 | 2026-02-13 (ningún cronograma posterior a v1) | no documentada | no calculable: el informe dice que el despliegue se reprogramó, pero no da fecha nueva |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | ejecutado 4.408.959.068 · comprometido 14.480.871.456 · proyección al cierre 22.832.718.095 | proyección **26,8 %** sobre lo aprobado |

- Replanificaciones registradas: **0**. Hay una reprogramación declarada en el informe sin línea base nueva ni solicitud de cambio.
- Ejecutado: 24,5 % del aprobado. Comprometido: 80,4 %. Disponible real: 3.519.128.544 COP.
- Sin cambios de control registrados (0).
- La fecha comprometida de cierre pasó hace 247 días y el proyecto sigue abierto. El script reporta desviación de 0 días solo porque la fecha vigente nunca se movió en el cronograma; no significa que no haya atraso.

### RAID al cierre
**Materializados:** el atraso del despliegue (incidencia; el informe del 2026-10-07 lo atribuye al congelamiento de fin de año) y la extensión de una semana de la validación en dos tiendas por conteo de inventario. Ninguno tiene dueño ni fecha.
**No materializados:** ninguno se puede afirmar. Los dos riesgos del informe siguen abiertos.
**Abiertos, con doliente:** ninguno tiene doliente con nombre. Por eso no están cerrados.
- Regulación de datos personales que puede mover el alcance: sin dueño, sin probabilidad ni impacto.
- El proveedor no ha confirmado la fecha de la última entrega: sin dueño. No hay contrato de proveedor en la carpeta.
- Reprogramación del despliegue por congelamiento de temporada: sin dueño.
- Validación con dos tiendas extendida una semana: sin dueño.
- Compromiso de Andrés Lozano, "Entregar el punto 35" (comité 2026-10-06): sin fecha ("por definir") y sin explicación de qué es el "punto 35".

### Lecciones
Solo entran las que se pueden anclar a un documento.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta se aprobó con alcance "Componente 1, 2, 3" y exclusiones "Lo que otro proyecto cubre", sin contenido | 2025-07-08 | Hoy no se puede contrastar lo entregado con lo comprometido, ni decir qué quedó fuera | No aprobar un acta cuyo alcance y exclusiones no se puedan verificar |
| Cuatro hitos figuran como cumplidos sin acta de recibo o documento equivalente | fechas base 2025-08-29 a 2026-02-13 | El 37 % declarado y los 5 de 5 hitos no se pueden reconciliar | Exigir el documento de aceptación al marcar un hito como cumplido |
| El piloto se recibió el 2026-10-13, con fecha base 2026-01-02, sin que el cronograma v1 se actualizara | 2026-10-13 | El cronograma v1 sigue siendo el único y no refleja el atraso | Registrar cada reprogramación como cambio con línea base nueva |
| La proyección de costo supera lo aprobado en 26,8 % sin solicitud de cambio de presupuesto | corte 2026-10-07 | Sobrecosto proyectado sin autorización documentada | Pedir el cambio de presupuesto cuando la proyección supere lo aprobado, no al final |

Quedan fuera las lecciones sobre el proveedor y la regulación: ningún documento ancla esos hechos más allá de la mención del informe.

### Sin dato
- Si el servicio de domicilios en dos horas está en producción y si se midió, que es el criterio de éxito.
- Fecha real o prevista del despliegue; ningún cronograma posterior a v1.
- Detalle del alcance (Componentes 1, 2 y 3) y quién decidió sus exclusiones.
- Evidencia de aceptación de 4 de los 5 hitos.
- Quién aprobó el recibo del piloto más allá del gerente, y con qué criterios.
- Autoridad y fase del proyecto (campos no hallados en la ficha).
- Qué es el "punto 35" y para cuándo.
- Contrato, entregables y facturación del proveedor mencionado.
- Doliente de cada riesgo e incidencia abiertos.
- Documentos de identidad y plan con 15 meses de antigüedad (acta y cronograma v1).

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto está declarado en rojo y abierto, y archivarlo lo sacaría del barrido diario con 7 señales abiertas. Para cerrarlo hace falta que el patrocinador (Ricardo Salas) declare la decisión de cierre, o que aparezca evidencia de producción y medición.
