# Corrida del 2026-10-18 · document-index

13 proyectos · 17 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

83 documentos sin cambio, 0 por releer. 19 citas de PRY-206 sin el prefijo de carpeta del proyecto: no resuelven aunque los archivos existen. No se corrigió ninguna ficha.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-18

**Documentos:** 83 · **Sin cambio:** 83 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Todas son de PRY-206. 19 campos citan una ruta sin el prefijo de la carpeta del proyecto (`PRY-206-precios-dinámicos/`). Los archivos sí existen en la carpeta; la ficha los cita mal.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-206 | identity.code, name, business_area, sponsor, manager, committee (6) | 00-gobierno/2026-04-05-acta-constitucion.docx |
| PRY-206 | plan.start_date, scope_summary, exclusions[0] (3) | 00-gobierno/2026-04-05-acta-constitucion.docx |
| PRY-206 | money.approved | 00-gobierno/2026-04-05-acta-constitucion.docx |
| PRY-206 | declared.status, progress_pct, as_of (3) | 20-seguimiento/2026-10-15-informe-avance.pdf |
| PRY-206 | money.committed, executed, projection (3) | 20-seguimiento/2026-10-15-informe-avance.pdf |
| PRY-206 | plan.end_date | 10-plan/2026-10-15-cronograma-v2.csv |
| PRY-206 | vendors[0].invoiced | 20-seguimiento/2026-09-06-factura-ct-847.pdf |
| PRY-206 | vendors[1].invoiced | 20-seguimiento/2026-09-09-factura-ct-980.md |

Mientras no se corrijan, el informe muestra esos datos como sustentados sin que la cita se pueda abrir.

### Formatos que no se pudieron leer
El índice no reporta ninguno.

### Siguiente paso
No hay nada que releer, así que no hace falta `/portfolio-scan`. Queda pendiente corregir las citas de PRY-206 anteponiendo `PRY-206-precios-dinámicos/`, de una en una y mostrando el cambio. No se ha tocado ninguna ficha.
