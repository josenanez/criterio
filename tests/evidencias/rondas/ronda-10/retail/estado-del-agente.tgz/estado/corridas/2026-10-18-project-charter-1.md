# Corrida del 2026-10-18 · project-charter

13 proyectos · 28 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Revisión del acta PRY-210 (2025-12-15): sin autoridad del gerente, alcance/exclusiones con texto de plantilla, éxito no medible, sin quien mida; atrasos de hitos sin replanificación; no se redactó nada. No sé si existen anexos fuera de la carpeta.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Hay acta previa: `00-gobierno/2025-12-15-acta-constitucion.md`, aprobada el 2025-12-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Acta — PRY-210 · Etiquetas electrónicas de precio
**Estado:** existe, del 2025-12-15 (modo revisar; no se redactó nada)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | No existe | Nada dice hasta qué monto ni qué cambio de fechas o alcance decide Óscar Ramírez sin subir al comité. Todo cambio termina en el Comité Comercial, o se decide sin autoridad pactada. |
| Objetivo de negocio | Presente pero vacío: "Entregar etiquetas electrónicas de precio para Comercio electrónico" | Es la solución repetida, no un objetivo. No hay nada contra qué medir si el proyecto sirvió. |
| Alcance | Texto de plantilla: "Componente 1, 2, 3" | No define qué se construye, así que ningún cambio de alcance se puede reconocer como tal. |
| Exclusiones | Texto de plantilla: "Lo que otro proyecto cubre" | No nombra proyecto ni tema. Cualquier reclamo de alcance queda sin referencia. |
| Criterio de éxito | "En producción y medido" | No dice qué se mide, con qué meta, ni cuándo. El cierre no se puede juzgar. |
| Quién mide el éxito | No existe | Nadie responde por declarar cumplido el criterio. |
| Supuestos y restricciones | No existen | Las dependencias dicen "Ninguna declarada", pero el informe del 2026-10-15 reporta que el proveedor no ha confirmado la última entrega. Esa dependencia nunca se declaró. |
| Comité y cadencia | Comité nombrado (Comité Comercial); cadencia no | No se sabe cada cuánto debe rendir cuentas. |
| Hitos | No están en el acta | Están solo en el cronograma v1; el acta no los respalda como compromiso. |
| Patrocinador | Cumple: Javier Hoyos | — |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo repite la solución).
**Alcance:** pendiente de definir (el acta tiene marcadores de plantilla).
**Exclusiones:** pendiente de definir.
**Patrocinador:** Javier Hoyos · **Gerente:** Óscar Ramírez (acta de constitución, 2025-12-15)
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento.
**Comité al que reporta:** Comité Comercial (acta) · **Cadencia:** pendiente de definir (el comité del 2026-10-14 se reunió, pero la cadencia pactada no está escrita).
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir. Hay presupuesto aprobado de 4.200.000.000 COP, inicio 2025-12-25 y cierre 2027-03-14 (acta).
**Criterio de éxito:** "En producción y medido" (no medible) · **Lo mide:** pendiente de definir.
**Hitos principales (cronograma v1, no acta):** Diseño de la experiencia 2026-04-15; Ambiente de pruebas 2026-08-04; Integración con el ERP 2026-11-23; Piloto en tiendas 2027-03-14.

### Lo que el acta vacía deja a la vista en el resto de documentos
- Las actas de recibo son del 2026-10-06 (diseño, hito previsto el 2026-04-15) y del 2026-10-18 (ambiente de pruebas, previsto el 2026-08-04). Son unos 174 y 75 días de atraso. El cronograma sigue con fecha vigente igual a la línea base, sin ninguna replanificación aprobada.
- El informe del 2026-10-15 declara Verde y 79% de avance, mientras reporta una prueba de carga fallida, dos semanas perdidas y una entrega del proveedor sin fecha. El 2026-10-18 se recibió el ambiente de pruebas certificado, aunque la prueba de carga se repite.
- Presupuesto del informe: ejecutado 2.273.393.946 sobre aprobado 4.200.000.000 (54%). Comprometido más ejecutado suman 4.004.902.578, y la proyección al cierre es 3.915.554.441. No concilian entre sí; eso es para budget-tracking, no para el acta.
- El comité del 2026-10-14 registra un compromiso de Jorge Medina ("Entregar el punto 27", para 2026-11-01). No hay contexto de qué es ese punto ni de quién lo asignó.

No sé: si hay otra acta o anexo fuera de la carpeta, qué se habló en el comité fuera del documento, ni si existe una autoridad delegada por política general de la organización.

## Después
- El acta quedó sin autoridad declarada. Ofrezco llevar esa definición al Comité Comercial (próximo comité semanal, 2026-10-25) como decisión: monto y tipo de cambio que Óscar Ramírez puede resolver sin comité. Es una decisión, no un trámite.
- De esta revisión salen supuestos candidatos al registro RAID: la entrega del proveedor (dependencia no declarada), la prueba de carga repetida y la rotación del desarrollador clave. Ofrezco pasarlos con `/raid-log`.

---
**Pie de rigor:** revisión hecha solo sobre los 6 documentos de PRY-210 en la carpeta (acta, cronograma, 2 actas de recibo, informe de avance, minuta del comité). Cada dato sale del documento citado; lo que no está queda como pendiente de definir, no completado. Es un borrador de trabajo: la verificación es de quien lo lee.
