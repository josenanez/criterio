# Corrida del 2026-10-18 · portfolio-wake

13 proyectos · 30 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Barrido: 83 documentos sin cambios, nada que releer. 18 citas de PRY-206 sin resolver en el índice, aunque los archivos existen; causa sin determinar. Confirmación: 5 preguntas sobre PRY-206, sin respuesta. No se revisaron peticiones ni se leyeron las fichas de los otros 12 proyectos.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## 2026-10-18

**Revisé:** 83 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada nuevo en los documentos: el barrido no encontró archivos nuevos, cambiados, renombrados ni borrados, así que no se corrió `/portfolio-scan`.

Un hallazgo del índice, sin relación con cambios: 18 citas de la ficha de PRY-206 (identidad, estado declarado, plan, presupuesto y facturado de los dos proveedores) apuntan a archivos que sí existen en la carpeta, pero que el índice no resolvió (`source_missing`). Las rutas citadas son relativas a la carpeta del proyecto, no a la carpeta de documentos del portafolio. No se corrigió la ficha: queda abierto saber si la causa es el formato de ruta de la ficha publicada o la forma en que el índice las busca.

### Peticiones atendidas
No se revisó la cola de peticiones: `due` no marcó `requests`.

### Preguntas
Confirmación periódica (primera corrida, 5 campos de PRY-206). Nadie respondió en esta sesión de prueba, así que quedan registradas como preguntadas el 2026-10-18, sin respuesta. No se repiten.

1. Hito «Diseño de la experiencia aprobado» (2026-05-27), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Fuente: `10-plan/2026-10-15-cronograma-v2.csv`.
2. Hito «Integración con el ERP» (2026-08-20), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Misma fuente.
3. Hito «Piloto en tiendas» (2026-10-02), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Misma fuente.
4. CT-847, «Bolsa de horas de desarrollo», vencía el 2026-07-17 y sigue pendiente. ¿Se entregó, se reprogramó o se canceló? Fuente: ficha de PRY-206, proveedores.
5. Fase del proyecto: no figura en ningún documento (`not_found`). ¿En qué fase está? Fuente: ficha de PRY-206, identidad.

**Vuelvo el 2026-10-19.**
