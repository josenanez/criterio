# Corrida del 2026-10-18 · portfolio-report

13 proyectos · 83 documentos, 0 releídos y 83 sin cambio · 29 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

El informe quedó en `/home/claude/banco/ronda-10/retail/espacio/reportes/index.html`.

Informe html: 5 verdes contradichos (PRY-200, 201, 202, 204, 209); revisar PRY-206, PRY-201 y PRY-208

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-18
13 proyectos · 11 con hallazgos · 63 señales · fichas cargadas de `estado/records/` (13 fichas, as_of 2026-10-18; la antigüedad de cada ficha no se verificó por separado)

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18). En corto: Criterio produce borradores de trabajo, no decisiones ni asesoría; puede equivocarse, y por eso cada dato trae la cita del documento de donde salió: la verificación es suya. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Formato `html`: informe generado por `informe.py` en `reportes/` (24 páginas).
- `reportes/index.html` — vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión. Para el patrocinador / comité.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`) y por producto.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea `2026-10-18` es de hoy mismo; el diff da 0 cambios).

## Contradicciones abiertas
Declaradas "verde" contra lo que sustentan los documentos (5 proyectos): PRY-200, PRY-201, PRY-202, PRY-204, PRY-209. Detalle por campo y con las dos fuentes en `index.html`.

## Hitos vencidos sin evidencia
- PRY-205 Pago con QR — «Integración con el ERP», vencido 2026-10-09 (9 días).
- Hitos declarados cumplidos sin evidencia: PRY-200 (2), PRY-201 (3), PRY-202 (3), PRY-203 (1), PRY-204 (1), PRY-205 (1), PRY-206 (3), PRY-207 (2), PRY-208 (4), PRY-211 (1).

## Proyectos en silencio
Vacía: ninguno supera 15 días. El más callado es PRY-203 (11 días).

## Dependencias en riesgo
Sin dependencias declaradas por código que se hayan roto en esta corrida.

## Sin sustento
Avance declarado frente a lo que el plan soporta: PRY-208 (37 % vs 100 %), PRY-207 (26 % vs 75-100 %), PRY-200 (26 % vs 60-80 %), PRY-206 (47 % vs 80-100 %); por encima del plan: PRY-209, PRY-205 y PRY-211.

## Vacíos de información
Ningún proyecto tiene autoridad de aprobación registrada (13 de 13). 6 proyectos sin producto: PRY-202, 203, 206, 209, 210, 211.

## Estado general
| Proyecto | Señales destacadas |
|---|---|
| PRY-206 Precios dinámicos | +53 días vs original (25 %), cambio CC-01 sin línea base, 7 compromisos vencidos, 2 reprogramados 5-6 veces, proveedor facturado sin entrega |
| PRY-201 Fidelización | Costo +22,6 % sobre aprobado; facturado sobre lo aceptado en 107,5 M |
| PRY-208 Domicilios | Costo +26,8 % sobre aprobado |
| PRY-199, PRY-210 | Sin señales |

Los cálculos salen de `portafolio.py compute`; no se recalculó nada a mano.

## Necesito que confirmes
Ninguna pregunta este mes en esta corrida de prueba (sin interfaz).

---
Pie: criterio-portfolio 0.5.0 · fichas aplicadas con fecha 2026-10-18 · campos inciertos: autoridad sin registrar en los 13 proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
