**Fuente:** fichas del estado (`estado/`), recalculadas con `portafolio.py compute` al 2026-10-18. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Productos al 2026-10-18 — «puntos de fidelización»

**«Puntos de fidelización» tiene un solo proyecto: PRY-201 Programa de fidelización.** La vista por producto no aporta nada distinto a la del proyecto, así que no armo sección de producto. Lo que el cálculo da para ese proyecto:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| puntos de fidelización | 1 (PRY-201) | 9 alertas | 2027-01-01 (PRY-201) | 3.300.000.000 COP | 2.647.230.813 COP (80,2 %) |

Las cuatro cifras de dinero están completas en PRY-201 (ejecutado 860.644.236 COP, 26,1 %; proyección 4.046.399.504 COP, 22,6 % sobre lo aprobado).

**Lo que hay que ver (PRY-201):**
- El informe del 2026-10-17 declara **verde** y avance 86 %; el plan sustenta entre 60 y 80 %. Cuatro señales abiertas no están reconocidas en esa declaración: hitos, costo, entregable tardío del proveedor y facturación.
- Tres hitos declarados cumplidos sin evidencia: «Diseño de la experiencia aprobado» (venció 2026-05-18, 153 días), «Ambiente de pruebas certificado» (2026-07-14, 96 días), «Integración con el ERP» (2026-09-09, 39 días).
- Costo: proyección 22,6 % sobre lo aprobado, contra un umbral de 10 %.
- Proveedor Tecnología para Tiendas Ltda.: dos «Bolsa de horas de desarrollo» pendientes (CT-144, 53 días de atraso; CT-836, 1 día); «Licenciamiento de la plataforma» (CT-836) aceptado sin evidencia; facturado 419.283.282 COP contra 311.826.194 COP aceptado (diferencia 107.457.088 COP, en CT-836).

**Dependencias internas:** ninguna, el producto tiene un solo proyecto. Tampoco hay dependencias declaradas en la ficha de PRY-201.

**Fecha comprometida del producto:** 2027-01-01, de PRY-201 (sin replanificaciones, desviación 0 días).

**Faltan en la ficha:** autoridad (`identity.authority`) y fase (`identity.phase`).

### Proyectos sin producto declarado
Nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | Abastecimiento |
| PRY-203 Reposición automática | Comercial |
| PRY-206 Precios dinámicos | Comercio electrónico |
| PRY-209 Migración del ERP | Mercadeo |
| PRY-210 Etiquetas electrónicas de precio | Comercio electrónico |
| PRY-211 Pronóstico de demanda | Finanzas |

**Qué no sé:** si alguno de esos seis sirve a «puntos de fidelización» (p. ej. PRY-209 Migración del ERP, cuando PRY-201 tiene el hito «Integración con el ERP»). Las fichas no lo dicen y no lo supongo; es una pregunta para las áreas dueñas.

*Pie de rigor: borrador de trabajo hecho solo con las fichas; cada cifra sale del cálculo y la verificación contra los documentos es de la PMO. De PRY-201 hay 0 fuentes de evidencia, 3 de declaración y 17 sin marcar.*
