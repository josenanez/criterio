## 2026-10-18

**Revisé:** 83 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada nuevo en los documentos: el barrido no encontró archivos nuevos, cambiados, renombrados ni borrados, así que no se corrió `/portfolio-scan`.

Un hallazgo del índice, sin relación con cambios: 18 citas de la ficha de PRY-206 (identidad, estado declarado, plan, presupuesto y facturado de los dos proveedores) apuntan a archivos que sí existen en la carpeta, pero que el índice no resolvió (`source_missing`). Las rutas citadas son relativas a la carpeta del proyecto, no a la carpeta de documentos del portafolio. No se corrigió la ficha: queda abierto saber si la causa es el formato de ruta de la ficha publicada o la forma en que el índice las busca.

### Peticiones atendidas
No se revisó la cola de peticiones: `due` no marcó `requests`.

### Preguntas
Confirmación periódica (primera corrida, 5 campos de PRY-206). Nadie respondió en esta sesión de prueba, así que quedan registradas como preguntadas el 2026-10-18, sin respuesta. No se repiten.

1. Hito «Diseño de la experiencia aprobado» (2026-05-27), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Fuente: `10-plan/2026-10-15-cronograma-v2.csv`.
2. Hito «Integración con el ERP» (2026-08-20), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Misma fuente.
3. Hito «Piloto en tiendas» (2026-10-02), marcado cumplido sin evidencia de recibo. ¿Qué documento lo respalda? Misma fuente.
4. CT-847, «Bolsa de horas de desarrollo», vencía el 2026-07-17 y sigue pendiente. ¿Se entregó, se reprogramó o se canceló? Fuente: ficha de PRY-206, proveedores.
5. Fase del proyecto: no figura en ningún documento (`not_found`). ¿En qué fase está? Fuente: ficha de PRY-206, identidad.

**Vuelvo el 2026-10-19.**
