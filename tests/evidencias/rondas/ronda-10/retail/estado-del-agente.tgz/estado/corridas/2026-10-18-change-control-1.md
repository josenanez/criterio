# Corrida del 2026-10-18 · change-control

13 proyectos · 29 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

Solicitud PRY-200 +30 días a la salida: impacto de portafolio 0 (sin dependencias declaradas); autoridad no declarada en el acta, va a comité por defecto; no se creó línea base nueva. No sabía: solicitante, motivo, costo, destino del piloto del 2026-10-24.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Ficha de la que sale: `estado/records/PRY-200.json` (Tienda en línea, actualizada 2026-10-18). Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

## Solicitud de cambio — PRY-200 Tienda en línea — 2026-10-18

**Qué se pide:** mover la salida a producción 30 días (hito «Despliegue en la cadena»: 2027-01-02 → 2027-02-01, que es el cierre del proyecto).
**Quién lo pide:** no consta en ningún documento. Se pidió por la invocación, sin solicitante nombrado.
**Por qué:** no está dicho en la solicitud. El informe de avance del 2026-10-07 registra tres incidencias abiertas que podrían explicarlo, pero ningún documento las vincula con este cambio, así que no lo afirmo: prueba de carga de temporada por debajo del umbral (se repite), hallazgo de seguridad en medios de pago, y dos semanas perdidas por rotación de un desarrollador clave. Ninguna tiene responsable.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, sin detalle) | Sin cambio declarado | 0 declarado |
| Tiempo | Cierre 2027-01-02 (línea base 1, única) | 2027-02-01 | +30 días |
| Costo | Aprobado 18.000.000.000 COP; comprometido 14.923.236.992; ejecutado 8.020.333.404; proyección 18.137.414.819 | No declarado | Sin dato |

- **Alcance sin impacto declarado:** si el alcance no cambia y el tiempo sube 30 días, alguien absorbe el cambio en horas o en calidad. Nadie lo dice. Hay que preguntarlo.
- **Costo sin impacto declarado:** la proyección ya supera lo aprobado en 137.414.819 COP (0,76 %) antes de mover nada. Treinta días más de equipo no están costeados en ningún documento. No calculo una cifra: no hay tarifa ni dotación en la carpeta.
- **Piloto en tiendas (2026-10-24, pendiente, a 6 días):** la solicitud no dice si se mueve con la salida o se mantiene. Sin esa respuesta no se puede evaluar el cambio completo.
- **Nota sobre la fecha:** el hito es el único tiempo que mueve la solicitud; las fechas de los otros hitos cumplidos no cambian.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado | `impact` devolvió 0 alcanzados directos, 0 indirectos, 0 que no sostienen fecha, 0 dependencias sin confirmar | — |

**Esto no significa que nadie dependa de PRY-200.** El acta dice «Ninguna declarada» y ninguna otra ficha cita PRY-200. Lo único que sé es que no hay dependencia declarada. Cuántos días se mueve cada actividad no se puede calcular: la ficha no tiene holgura por actividad.

### Quién decide
**Autoridad requerida:** no determinable. El acta no declara umbrales de autoridad (`identity.authority`: no encontrado). Por eso es el hallazgo de fondo.
**Según:** acta de constitución del 2026-01-10. Solo dice que el Comité de Arquitectura aprobó el presupuesto. No dice qué cambios de fecha puede aprobar el gerente, el patrocinador o el comité.
**Va a comité:** sí, por defecto. Sin autoridad declarada, lo prudente es llevarlo al Comité de Arquitectura (patrocinador: Gustavo Neira; gerente: Jorge Medina). Es una recomendación mía, no una cláusula del acta. Próximo comité de PMO según la configuración: 2026-10-25.

### Si no se aprueba
El proyecto sigue con cierre 2027-01-02 y 26 % de avance declarado al 2026-10-07 (informe de avance, sin verificar contra evidencia). Con tres incidencias abiertas sin dueño y un piloto a 6 días, la fecha vigente tiene riesgo que el informe de avance no refleja: aparece en verde. No evalué la salud del proyecto en esta corrida; ese es el trabajo de `/health-check`.

### Si se aprueba
Línea base 2 — cierre 2027-02-01 · presupuesto: sin cambio declarado (18.000.000.000 COP) · motivo: **por completar, no consta en la solicitud**.
Desviación acumulada contra la línea base original: **+30 días** en tiempo (2027-01-02 → 2027-02-01) · costo: sin dato del cambio; la proyección actual ya está +137.414.819 COP sobre lo aprobado.
La línea base 1 no se toca. El conteo de replanificaciones pasa de 0 a 1. Desde ahí toda desviación se reporta contra dos referencias. Reconciliación: la línea base se movería 30 días y el cambio aún no tiene documento aprobado. Si se mueve sin aprobación quedarían 30 días sin autorizar (`unauthorized_days`).

### Qué no sé
- Quién pide el cambio y por qué.
- Si el piloto del 2026-10-24 se mueve.
- El impacto en costo y en horas.
- Quién tiene autoridad para aprobarlo.
- Si hay dependientes no declarados.

### Después
Esta solicitud no se registró como aprobada ni se creó línea base nueva: nadie con autoridad la aprobó. Lo que sigue: llevarla al Comité de Arquitectura con el motivo, el costo y la decisión sobre el piloto completos. Si el comité la aprueba, registro la línea base 2 con el acta que la apruebe.

Respuestas tomadas por defecto en esta sesión sin interfaz: términos ya vigentes; solicitante, motivo y costo se dejaron como «no consta» en vez de inventarlos.
