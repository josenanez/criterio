## Listo — Retail

**Miré:** 83 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: 42 .md, 15 .pdf, 10 .docx, 7 .csv, 7 .xlsx, 1 .json, 1 .txt · más reciente: 2026-10-18
**Eres:** PMO del portafolio (hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; próximo comité 2026-10-25, informe el 2026-10-23
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.5.0 (términos 1.1), fecha 2026-10-18 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 del .md 9c54c0c51760b1…

Sesión de prueba sin interfaz: tomé las respuestas sugeridas (rol PMO, comité semanal, presentación, estado en `estado/`, informes en `reportes/`). El próximo comité (2026-10-25) es una suposición mía a partir del ritmo semanal de las actas; corrígela si no es esa.

### Probé con tres proyectos

Elegí PRY-209, PRY-210 y PRY-211: los tres con documentación del 2026-09-27 al 2026-10-18 que no tenían una selección mejor (varios proyectos empatan en la fecha más reciente).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-209 Migración del ERP | 4 | Patrocinador Felipe Arango, gerente Elena Duarte, presupuesto 3.300 M COP, cierre 2027-10-11 (acta 2026-05-26). Reporta verde con 61 % (informe 2026-09-28) | Producto, facultad del gerente, fase |
| PRY-210 Etiquetas electrónicas de precio | 6 | Patrocinador Javier Hoyos, gerente Óscar Ramírez, presupuesto 4.200 M COP, cierre 2027-03-14. Verde con 79 % (informe 2026-10-15); 2 hitos cerrados con acta de recibo | Producto, facultad del gerente, fase |
| PRY-211 Pronóstico de demanda | 5 | Patrocinadora Sandra Gil, gerente Gustavo Neira, presupuesto 9.500 M COP, cierre 2027-03-13. Amarillo con 77 % (informe 2026-09-27) | Producto, facultad del gerente, fase |

### Hallazgos (los que levantó `compute`)

- **PRY-209 · `declared_vs_evidence` y `progress_vs_plan`:** declara 61 % y verde, pero solo 1 de 4 hitos está cumplido; el plan sostiene entre 25 % y 50 %. Es el verde que los documentos no sostienen. El único hito cerrado (Diseño de la experiencia aprobado, plan 2026-10-06) tiene acta de recibo del 2026-10-18.
- **PRY-211 · `progress_vs_plan`:** declara 77 %; con 2 de 5 hitos cumplidos el plan sostiene entre 40 % y 60 % (17 puntos de diferencia).
- **PRY-211 · `milestone_met_without_evidence`:** "Diseño de la experiencia aprobado" figura cerrado en el cronograma (fecha 2026-07-09, hace 101 días) y no hay acta de recibo que lo pruebe.
- **PRY-211 · `commitment_overdue`:** María Restrepo, "Entregar el punto 5", para el 2026-10-16, vencido hace 2 días (comité del 2026-10-18).
- **PRY-210:** sin señales levantadas. Los problemas del informe (prueba de carga de temporada que no alcanzó el umbral, rotación de un desarrollador) quedaron en la ficha como incidencias, pero `compute` no los levantó como señal, así que no son hallazgo.

Totales de las tres: 2 proyectos con señales, 5 señales, 1 verde contradicho, 3 sin facultad del gerente declarada. Sin desviación de fechas ni de costo (ninguna línea base se movió; proyección dentro de ±7 % del presupuesto).

### El portafolio completo
10 proyectos más (PRY-199 a PRY-208, 68 documentos), en un lote, uno tras otro. Con estos tres tomó unos pocos minutos por proyecto; calcula del orden de media hora a una hora.

### Lo que le falta a tu carpeta
- Ninguna de las tres actas de constitución dice qué producto sirve ni hasta dónde puede decidir el gerente sin subir a comité.
- Alcance, "fuera de alcance" y dependencias de las actas son texto genérico ("Componente 1", "Lo que otro proyecto cubre", "Ninguna declarada"); no se puede contrastar el alcance real.
- Los hitos cerrados en los cronogramas no siempre tienen acta de recibo (PRY-211 diseño).
- Los compromisos de comité no traen fecha de cuándo se prometieron más allá de la reunión, y alguno nombra a quien no asistió (María Restrepo, Jorge Medina).
- No hay actas de comité de PRY-209, y el informe de avance de PRY-209 y PRY-211 tiene 20 días o más.
- No se leyó ficha de contratos de proveedor en estos tres proyectos (no hay contratos en sus carpetas).
Ninguno es bloqueante.
