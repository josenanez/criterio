# Corrida del 2026-10-18 · portfolio-scan

13 proyectos · 83 documentos, 0 releídos y 83 sin cambio · 271 s · 63 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 6 |
| `declared_vs_evidence` | 5 |
| `commitment_undated` | 4 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `milestone_overdue` | 1 |
| `variance_time` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `change_without_baseline` | 1 |

10 proyectos leídos y sellados (PRY-199 a PRY-208), 68 de 83 documentos; PRY-209/210/211 sin cambio (15 documentos). Nada movido: no existe entrada/. Sin ilegibles. Mirar: hitos cerrados sin acta, facturas de PRY-201 y PRY-206 sin acta, CC-01 de PRY-206 sin firma, compromisos vencidos y reprogramados en PRY-206, despliegue reprogramado sin fecha en 6 proyectos.

Contra la corrida del 2026-10-18: +58 hallazgos.

## Lo que produjo

## Barrido — 2026-10-18

**Documentos:** 83 en la carpeta · 68 leídos · 15 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha (PRY-199 a PRY-211) · 10 actualizados en esta corrida (PRY-199 a PRY-208) · 3 sin cambio (PRY-209, PRY-210, PRY-211) · 0 sin carpeta propia

Formatos: 42 .md, 15 .pdf, 10 .docx, 7 .csv, 7 .xlsx, 1 .json, 1 .txt. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, presupuesto, plan, contrato CT-199, 2 riesgos, 1 compromiso | autoridad, fase, facturado CT-199 |
| PRY-200 Tienda en línea | 5 | identidad, presupuesto, plan, 3 incidencias, 1 compromiso | autoridad, fase |
| PRY-201 Programa de fidelización | 8 | identidad, presupuesto, plan, CT-144 y CT-836 con 2 facturas | autoridad, fase |
| PRY-202 Centro de distribución norte | 4 | identidad, presupuesto, plan, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-203 Reposición automática | 4 | identidad, presupuesto, plan, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-204 Cajas de autopago | 4 | identidad, presupuesto, plan, 1 compromiso | autoridad, fase |
| PRY-205 Pago con QR en caja | 7 | identidad, presupuesto, plan, CT-600 con acta y factura | autoridad, fase |
| PRY-206 Precios dinámicos | 21 | identidad, presupuesto, plan v1 y v2, CT-980, CT-847, CC-01, 26 compromisos, 1 riesgo dicho en reunión; `ficha-pm.json` guardada aparte en `pm_record` | producto («No aplica»), autoridad, fase |
| PRY-207 Marca propia de alimentos | 4 | identidad, presupuesto, plan | autoridad, fase |
| PRY-208 Domicilios en dos horas | 5 | identidad, presupuesto, plan, 1 compromiso | autoridad, fase |

Ninguna de estas diez fichas existía antes de esta corrida; las tres anteriores (PRY-209, 210, 211) no se tocaron.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| (ninguno) | Las fichas PRY-209, 210 y 211 no cambiaron: sus 15 documentos tienen el mismo hash. | — |

### Lo que conviene mirar (lectura de los documentos; las señales las calcula el script)
- **Hitos declarados cerrados sin acta que lo pruebe:** PRY-200 (2 de 3), PRY-201 (3 de 3), PRY-202 (3 de 3), PRY-203 (1), PRY-204 (1), PRY-205 (1), PRY-206 (3 de 4), PRY-207 (2 de 3), PRY-208 (4 de 5), PRY-199 tiene el acta de su único hito cerrado. Las actas que existen son de «Ambiente de pruebas certificado» o de «Piloto en tiendas» y se citan solo para ese hito, y varias son muy posteriores a la fecha del hito (PRY-200: hito 2026-06-07, acta 2026-10-06).
- **Estado declarado contra lo que muestran los documentos:** PRY-208 declara rojo con 37 % de avance, pero su cronograma v1 da los cinco hitos por cerrados, con cierre en 2026-02-13. PRY-201 declara verde con 86 % de avance y 860.644.236 COP ejecutados de 3.300.000.000 aprobados; su proyección (4.046.399.504) supera lo aprobado.
- **Facturas contra entregables sin acta:** PRY-201: FV-2836 por 419.283.282 COP contra CT-836, cuyo único entregable recibido vale 311.826.194 y no tiene acta; PRY-206: FV-1980 por 599.677.238 COP contra CT-980, con los dos entregables «pendiente», y FV-2847 por 410.335.213 COP contra CT-847, cuyo licenciamiento figura «recibido» en el contrato sin acta. PRY-205 y PRY-201/CT-144 tienen acta y factura por un entregable cada una.
- **Presupuesto:** PRY-208 proyecta 22.832.718.095 COP contra 18.000.000.000 aprobados. PRY-204 declara ejecutado (947.118.565) mayor que comprometido (800.208.609).
- **Cambio de alcance en PRY-206:** CC-01 (2026-10-17) amplía el alcance, +53 días y +106.000.000 COP, «autorizada por el comité» sin decir cuál ni quién firmó. El cronograma v2 es del 2026-10-15, dos días antes de la solicitud. El acta de constitución no deja autoridad del gerente.
- **Compromisos vencidos o reprogramados:** PRY-202 (Jorge Medina, punto 37, 2026-10-02, dicho el 2026-10-16), PRY-203 (Carlos Peña, punto 39, 2026-10-08). En PRY-206, «Enviar el documento 1» (Liliana Torres) lleva seis reprogramaciones, de 2026-09-13 a 2026-12-03, y «Cerrar la prueba 2» (Paula Céspedes) cinco; hay 6 vencidos y tres compromisos que su dueño dijo haber entregado sin presentar acta.
- **Despliegue «reprogramado» sin fecha:** los informes de PRY-199, 201, 203, 204, 207 y 208 dicen que se reprogramó el despliegue; ningún cronograma posterior a v1 recoge la nueva fecha.
- **Riesgo dicho en reunión y no registrado (PRY-206):** el proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-18).
- **PRY-206 y su gerente:** la ficha del gerente (`ficha-pm.json`) quedó en `pm_record`, sin mezclar con la mía; el contraste entre las dos lo calcula el script.
- **Gobierno:** no hay cambio de patrocinador ni de gerente entre documentos. Carlos Peña (PRY-199 y PRY-203) y Ricardo Salas (PRY-200) tienen compromisos en comités a los que no figuran como asistentes.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 83 archivos se leyeron; los .docx, .xlsx y .pdf pasaron por `texto.py` al caché y las citas apuntan al original. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/`. `2026-10-18-notas-reunion.txt` está suelto en la raíz de PRY-206 y se leyó donde está. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

**Pie:** plugin criterio-portfolio 0.5.0 · fichas escritas y selladas: PRY-199, 200, 201, 202, 203, 204, 205, 206, 207, 208 · campos en `not_found`: autoridad y fase en las diez fichas; producto en PRY-202, 203 y 206; facturado de CT-199 · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
