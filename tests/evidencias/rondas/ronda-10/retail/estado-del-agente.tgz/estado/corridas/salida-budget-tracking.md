Documentos de los que sale: la ficha `estado/records/PRY-201.json` y el cálculo de `portafolio.py compute` (as_of 2026-10-18). Términos vigentes (aceptados por José Francisco Ñáñez, 2026-10-18).

## Presupuesto — PRY-201 Programa de fidelización al 2026-10-18
**Moneda:** COP (única; no hay otras monedas ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100 | 00-gobierno/2026-03-12-acta-constitucion.md | 2026-03-12 |
| Comprometido | 2.647.230.813 | 80.2 | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Ejecutado | 860.644.236 | 26.1 | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |
| Proyección al cierre | 4.046.399.504 | 22.6 por encima del aprobado | 20-seguimiento/2026-10-17-informe-avance.md | 2026-10-17 |

**Disponible real** (aprobado menos comprometido): 652.769.187 COP

La proyección es una declaración del informe de avance, no un dato duro. Tiene un día de antigüedad y no hay movimientos de presupuesto posteriores (no hay solicitudes de cambio registradas), así que no está vencida frente a ellos.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 3.300.000.000 | 3.300.000.000 | 0 |
| Proyección frente al aprobado | | | +22.6 % (umbral 10 %) |

Replanificaciones de presupuesto: 0

### Ejecución frente a avance
Ejecutado 26.1 % · Hitos cumplidos 3 de 5 · El informe declara 86 % de avance, pero el plan solo sustenta entre 60 y 80 %, y los tres hitos "cumplidos" no tienen evidencia. Con 80.2 % ya comprometido y solo 26.1 % ejecutado, el 86 % declarado no cuadra con el dinero causado: hay mucho por causar o el avance está sobredeclarado.

### Alertas
- **Proyección por encima del aprobado: 22.6 %**, contra un umbral de 10 % (proyección 4.046.399.504 frente a 3.300.000.000 aprobados).
- **Comprometido 80.2 %**: por debajo del umbral de 90 %, pero con solo 652.769.187 COP disponibles reales frente a una proyección que excede el aprobado.
- **Facturado por encima de lo aceptado**, Tecnología para Tiendas Ltda., contrato CT-836: facturado 419.283.282, aceptado 311.826.194, diferencia 107.457.088 COP (montos declarados 2 de 2). El contrato CT-144 factura 154.265.280, igual a lo aceptado.
- **Entregables vencidos del proveedor**: "Bolsa de horas de desarrollo", pendiente, 53 días (CT-144, vencía 2026-08-26) y 1 día (CT-836, vencía 2026-10-17). "Licenciamiento de la plataforma" figura aceptado sin evidencia de recibo.
- **Estado declarado verde** (informe del 2026-10-17) frente a señales abiertas de costo, proveedor y evidencia: el verde no está sustentado.

### Sin dato
- Presupuesto original distinto del vigente: no hay documento de cambio; se asume igual porque no existe otro, y no está declarado.
- Detalle por proveedor del comprometido: la ficha no lo desglosa.
- Responsable de autoridad y fase del proyecto (`identity.authority`, `identity.phase`): no declarados.
- No hay tasa de cambio ni otra moneda declarada.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). También puedo detallar el comprometido por proveedor, empezando por la diferencia facturada de CT-836.

---
**Pie de rigor:** cifras copiadas de `portafolio.py compute`; las tres cifras no aprobadas provienen de un informe de avance (declaración, sin evidencia independiente: 0 fuentes de evidencia, 3 de declaración, 17 sin marcar). La verificación contra los documentos originales es suya. Criterio produce borradores de trabajo, no decisiones ni asesoría.
