# Corrida · 2026-10-18-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-200 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-18T08:15:44 · **Fin:** 2026-10-18T08:16:48 · **Duración:** 65 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 48 | 65 | Solicitud de +30 días a salida a producción de PRY-200. No evaluable tal cual: 30 días sobre el cierre v1 (2026-08-31) cae el 2026-09-30, ya vencido. Sin solicitante, motivo, fecha nueva ni impacto de alcance. Autoridad no declarada, va a comité por defecto. Impacto en portafolio 0 solo porque no hay dependencias declaradas. No leí el contrato CT-892 ni sé la holgura por actividad. |

Por señal (`change-control`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Solicitud de cambio PRY-200 (crédito de libranza digital): mover la salida a producción 30 días

La solicitud no se puede evaluar tal como está escrita. Los términos v1.1 ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

**Por qué no se puede evaluar:**
- La línea base vigente es la v1, con salida a producción el 2026-08-31. Treinta días más dan el 2026-09-30, que ya pasó (hoy es 2026-10-18).
- No consta quién lo pide, el motivo, la fecha nueva concreta ni el impacto en alcance. Los 30 días desde hoy (2026-11-17) son una hipótesis mía y no los usé en los cálculos.
- El cronograma marca «Salida a producción» como cerrado, pero el informe del 13 de octubre declara rojo y 67 % de avance. No hay evidencia de salida a producción.

**Impacto en las tres dimensiones:**
- **Alcance:** sin impacto declarado, así que nadie dijo quién absorbe la diferencia.
- **Tiempo:** el atraso contra la línea base original es de al menos 48 días hoy, y los 30 pedidos se sumarían a ellos. El piloto con asociados tenía fecha 2026-07-07 y se recibió el 2026-10-10, sin replanificar.
- **Costo:** la proyección es 20.616.543.260 COP contra 18.000.000.000 aprobados, es decir +2.616.543.260 (14,5 %), por encima del umbral de 10 %.

**Efecto en el portafolio:** el cálculo devuelve cero proyectos alcanzados, pero solo porque el acta dice «Ninguna declarada» en dependencias. El informe menciona la dependencia del proveedor del core cooperativo, así que probablemente hay una dependencia real con PRY-202 (por el nombre) que nadie declaró. La ficha no tiene holgura por actividad, así que no puedo decir cuántos días se movería otro proyecto.

**Quién decide:** la ficha no tiene autoridad declarada, y ese es el hallazgo de fondo. Va al Consejo de Administración por defecto, porque aprobó el presupuesto y la proyección lo excede.

**Si se aprueba:** sería la línea base 2, sin fecha, monto ni motivo hasta que quien pide los defina. La línea base 1 no se toca.

**No verifiqué:**
- El texto del contrato CT-892 con Talento Solidario, así que no sé si su vigencia cubre una salida desplazada.
- El estado de los entregables del proveedor, que también tienen fechas vencidas.

El siguiente paso es llevarlo al Consejo con fecha y costo definidos, y declarar antes la dependencia con el proyecto del core.

La salida completa y la corrida quedaron guardadas en `estado/corridas/salida-change-control.md` y `estado/corridas/2026-10-18-change-control-1.md`.
