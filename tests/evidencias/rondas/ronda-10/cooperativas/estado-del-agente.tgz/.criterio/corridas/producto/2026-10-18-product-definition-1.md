# Corrida · 2026-10-18-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T07:48:44 · **Fin:** 2026-10-18T07:49:30 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 29 | 27 | La evidencia sostiene solo que existe una necesidad dicha por un cliente; criterio de éxito, propuesta y cifra de volumen no tienen sustento |

Por señal (`product-definition`): `requirement_untraced` 12, `requirement_without_owner` 5, `requirement_undecided` 4, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 2, `assumption_unverified` 1

## Lo que el agente mostró

## Definición — Microcrédito (PRD-305) · contrastada al 2026-10-18

La evidencia solo sostiene que un cliente dijo que necesita microcrédito. El criterio de éxito, la propuesta y la cifra de volumen no tienen sustento. La definición es de 2025-12-01 y tiene 7 afirmaciones.

**Términos.** Ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

- **Contradicciones:** ninguna. Casi no hay evidencia con la que contradecir.
- **Cifras:** `volumen_mensual` = 166.254 no tiene ninguna serie medida. Nadie mide lo que el caso de negocio afirmó, y el documento no dice de dónde sale la cifra.
- **No está dicho en ninguna parte:**
  - la propuesta, que dice solo «Propuesta principal»;
  - el criterio de éxito, pues el retorno esperado en 24 meses no trae cifra;
  - el tamaño del segmento;
  - cuánto pagaría el cliente;
  - qué proveedor es y cuál es el tiempo pactado;
  - quién decide dentro del comité;
  - qué plan «se mantiene»;
  - qué proyecto lo construye.
- **Supuesto:** «El proveedor cumple el tiempo pactado» lleva 146 días sin verificar, con un umbral de 30. Para verificarlo hace falta nombrar al proveedor y escribir el plazo pactado con su fuente, y luego una fecha de entrega comprobada. El supuesto está fechado 2026-05-25 dentro de un documento fechado 2025-12-01. Lo señalo y no lo resuelvo.
- **Evidencia a favor:** una entrevista del 2025-12-30 («Lo necesito y hoy no lo tengo»). Es débil, porque nadie pagó ni se comprometió, y la entrevista no dice si esa persona es del segmento. Tiene unos 9,6 meses y cruza el umbral de 12 meses el 2026-12-30.
- **Normativo:** el producto toca crédito, datos personales y retención de información. Ningún documento dice el país, así que no cito norma: «no tengo la norma a la vista». Eso va a revisión jurídica.
- **Para cerrar la definición:** falta el criterio de éxito y la propuesta está vacía. Sin criterio de éxito no se puede cerrar, así que no ofrezco `/product-charter`.

Como siguiente paso, puedo convertir el supuesto del proveedor en un riesgo con doliente.

La corrida quedó registrada como `2026-10-18-product-definition-1`: 27 hallazgos, 29 segundos. Los 27 salen de las señales sobre los requerimientos, que es el cálculo del comando; no son hallazgos propios de la definición. La salida completa está en `estado-producto/PRD-305/corridas/salida-product-definition.md`.
