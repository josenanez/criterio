# Corrida · 2026-10-18-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-18T08:21:04 · **Fin:** 2026-10-18T08:21:54 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 33 | 65 | Revisión del acta PRY-203 (2025-09-28): falta autoridad del gerente, objetivo medible, alcance descrito, supuestos, restricciones, cadencia, hitos y quién mide el éxito. No sé si hay una versión más reciente del acta fuera de la carpeta ni qué proyecto cubre lo excluido. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

**Acta previa:** sí existe, del 2025-09-28. Es la única versión que hay en la carpeta. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

## Acta PRY-203 · Aportes sociales en línea

El acta tiene los nombres, pero casi todo lo demás está vacío o no se puede medir.

| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | Ausente | Hasta qué monto y qué cambio de alcance decide Andrés Lozano sin subir al comité no está dicho. El proyecto está en rojo, con un riesgo normativo y un ajuste de reglamento pedido por el Consejo, así que todo sube al Consejo de Administración por defecto. |
| Objetivo de negocio | Describe la solución, no un resultado | No hay con qué juzgar si el 59% de avance vale algo. |
| Alcance | "Componente 1, 2 y 3", sin describirlos | Ningún pedido nuevo se puede clasificar como dentro o fuera del alcance. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar el proyecto | No delimita nada. |
| Criterio de éxito | "En producción y medido" | No dice qué se mide, con qué valor ni quién lo mide. |
| Supuestos, restricciones, cadencia, hitos | Ausentes | No hay nada que verificar. Solo hay fechas de inicio y de cierre. |
| Dependencias | "Ninguna declarada" | Es difícil de creer con un riesgo normativo abierto y un reglamento por ajustar. |
| Patrocinador, gerente y comité | Cumplen | Natalia Ospina, Andrés Lozano y el Consejo de Administración. |

**Hechos del informe del 2026-10-11 que muestran por qué importan estos vacíos:**
- **Cierre vencido:** la fecha de cierre del acta, 2026-05-26, pasó hace 145 días. No hay línea base nueva que la mueva.
- **Presupuesto:** ejecutado más comprometido es el 92,0% del aprobado, por encima del umbral de 90%. La proyección supera lo aprobado en 19.120.193 COP (0,8%).

**Lo que no sé:** si existe una versión más reciente del acta fuera de la carpeta. Tampoco sé qué son los tres componentes ni qué proyecto cubre lo excluido. Verifica los porcentajes, que calculé yo sobre las cifras del informe.

**Siguiente paso:** como no hay autoridad declarada, la llevaría al comité como una decisión con una pregunta cerrada: ¿hasta qué monto y qué tipo de cambio decide el gerente sin subir al Consejo? De esta revisión no salieron supuestos para el registro RAID, porque el acta no trae ninguno.

La salida completa está en `/home/claude/banco/ronda-10/cooperativas/espacio/estado/corridas/salida-project-charter.md`. La corrida quedó registrada como `2026-10-18-project-charter-1`.
