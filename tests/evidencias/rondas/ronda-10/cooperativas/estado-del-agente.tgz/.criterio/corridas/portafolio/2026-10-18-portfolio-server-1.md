# Corrida · 2026-10-18-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:27:48 · **Fin:** 2026-10-18T08:28:19 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 65 | puerto 8787, carpeta del informe reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Rostrum está corriendo en modo «para mirarlo un rato» en **http://127.0.0.1:8787/**, y solo se ve desde este equipo. La portada responde 200 y `/estado.json` muestra 13 proyectos, 8 productos y 0 peticiones abiertas.

- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los volví a mostrar ni a registrar.
- **Modo:** elegí «para mirarlo un rato», la respuesta sugerida, porque nadie podía contestar.
- **Informe:** ya existía en `reportes/`, así que no hizo falta correr `/portfolio-report html`.
- **Secciones:**
  - `/pmo`: cómo va el portafolio.
  - `/decisiones`: lo que necesita una decisión.
  - `/proyectos` y `/p/<código>`: el listado y el informe de cada proyecto.
  - `/productos` y `/producto/<nombre>`: el listado y el informe de cada producto.
  - `/corridas`: las corridas registradas (32).
  - `/estado.json`: la frescura del informe.
- **Qué no hace:** no calcula, no escribe fichas, no autentica y no manda nada. Lo único que escribe son las peticiones del formulario, en `estado/peticiones/`.
- **Corrida registrada:** `2026-10-18-portfolio-server-1`. Lo que le mostré a la persona está en `estado/corridas/salida-portfolio-server.md`. La corrida dice «informe: null», y no entendí por qué, porque `reportes/` sí tiene informe.
- **Qué enlace pasar:** ninguno todavía. Con `127.0.0.1` el patrocinador no puede abrirlo; solo funciona en este equipo. Para un enlace estable hay que pasar a «que quede corriendo» (`--abierto`) y pedir un host y puerto internos, publicarlo detrás del control de acceso de la organización y mantener el equipo encendido.
- **Cuándo queda desactualizado:** el informe es del 2026-10-18 a las 13:26 UTC. La próxima corrida no está programada (`proxima_corrida: null`); si hace falta algo más reciente, corre `/portfolio-report html`.
- **Cómo parar:** el servidor sigue en segundo plano. Se apaga con `pkill -f servidor.py`, y su log está en `/tmp/claude-0/-home-claude-banco-ronda-10-cooperativas-espacio/692b0e4d-0e89-5e8d-a391-2cabbf233557/scratchpad/rostrum.log`.
