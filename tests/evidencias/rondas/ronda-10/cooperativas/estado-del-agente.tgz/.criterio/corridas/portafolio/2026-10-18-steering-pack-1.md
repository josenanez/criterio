# Corrida · 2026-10-18-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:23:18 · **Fin:** 2026-10-18T08:25:22 · **Duración:** 123 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 107 | 65 | Paquete de comité de 6 decisiones y 7 escalamientos sobre 13 fichas. Dijo que no sabe: la autoridad de los gerentes (0 de 13), el comité de 12 de 13 proyectos, si el +84 días de CC-01 repite el atraso de la v2 de PRY-210, y que no existe comité anterior registrado. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

El material del comité está listo y la corrida quedó registrada como `2026-10-18-steering-pack-1`. Tiene 6 decisiones y 7 escalamientos sin decisión asociada. La corrida midió 107 segundos y sobre 13 fichas. No midió el número de documentos.

Los términos v1.1 ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18, así que no los registré otra vez. No hubo preguntas que responder.

**Decisiones del paquete** (el texto completo está en `estado/corridas/salida-steering-pack.md`):
1. **Autoridad de los gerentes:** hay que fijar por escrito el monto y el tipo de cambio que cada gerente decide solo. Ninguna de las 13 fichas la declara, así que este punto va primero. Recomiendo un umbral único provisional.
2. **PRY-210, CC-01 y línea base v2:** CC-01 es una ampliación de alcance de 168000000 COP y +84 días. El cronograma v2 ya mueve la salida esos mismos 84 días sin aprobación.
3. **Talento Solidario Ltda.:** facturó 179497627 COP sobre lo aceptado en PRY-200 y 948184688 COP en PRY-209. Recomiendo retener nuevos pagos hasta tener las actas de aceptación.
4. **Sobrecosto:** PRY-200 proyecta +14.5 % y PRY-207 proyecta +27.9 %. PRY-207 se declara en verde.
5. **Riesgos compartidos sin doliente:** el «cambio normativo del supervisor» aparece en 5 proyectos y la «dependencia del proveedor del core» en 4.
6. **PRY-201:** declara verde y 91 %, pero su fecha de fin ya venció y no tiene ninguna solicitud de cambio. Recomiendo formalizar el atraso con una solicitud de cambio.

**Lo que el paquete no puede afirmar:**
- No hay comité anterior registrado, así que la sección de decisiones previas queda vacía.
- No sé si el +84 días de CC-01 es el mismo atraso que ya aplica la v2 de PRY-210 o uno adicional. Hay que aclararlo antes de votar.
- Solo leí la ficha de PRY-210 para saber quién es el comité de cada proyecto.
- Los montos aceptados del punto 3 salen de declaraciones en las fichas, no de actas de recibo.

Para cerrar el ciclo, puedo registrar las decisiones en las fichas cuando el comité sesione. La próxima sesión está configurada para el 2026-10-25.

Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
