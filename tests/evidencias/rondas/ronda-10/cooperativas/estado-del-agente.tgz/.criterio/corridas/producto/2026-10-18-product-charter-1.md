# Corrida · 2026-10-18-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4500

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4500

**Inicio:** 2026-10-18T07:51:34 · **Fin:** 2026-10-18T07:52:17 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 28 | 27 | Borrador de acta de REQ-4500, sin firmar y sin ficha creada. Declaró vacíos: criterios de aceptación, necesidad, autoridad, patrocinador, gerente, evidencia específica y barrido normativo. |

Por señal (`product-charter`): `requirement_untraced` 12, `requirement_without_owner` 5, `requirement_undecided` 4, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 2, `assumption_unverified` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4500 (producto PRD-305, Microcrédito). Todavía no se puede firmar bien: faltan datos clave y los dejé marcados como vacíos, sin rellenarlos. No creé la ficha del proyecto, porque eso va después de la firma de una persona.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré otra vez. Nadie podía responder, así que seguí con las respuestas sugeridas.

**Qué dice el borrador**
- **Problema:** el del producto es «El segmento Asociados urbanos no tiene microcrédito». El requerimiento no dice cuál es su necesidad: el acta del comité solo nombra «Requerimiento REQ-4500».
- **Criterio de éxito:** ninguno. El requerimiento no tiene criterios de aceptación y el caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra.
- **Evidencia de demanda:** una sola frase de una entrevista de 2025-12-30 («Lo necesito y hoy no lo tengo»). No nombra este requerimiento.
- **Gobierno:**
  - Hay doliente, Felipe Arango.
  - No consta quién decidió aceptarlo, ni patrocinador, ni gerente propuesto.
  - Tampoco está dicha la autoridad del gerente. La autoridad de producto, «Comité de producto», se propuso en la instalación.
- **Supuesto que pasa al proyecto como riesgo:** «El proveedor cumple el tiempo pactado», sin verificar. Ningún documento dice qué proveedor ni qué tiempo se pactó.
- **Normativa:** no hice el barrido de obligaciones. El acta lo deja como pendiente antes de firmar.
- **Alcance excluido:** REQ-4501 a REQ-4515 quedan fuera, pero ningún documento dice por qué. No inventé la razón.

**Qué sigue:** quien se nombre gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

La corrida quedó registrada como `2026-10-18-product-charter-1`, con la salida guardada.

Archivos en `estado-producto/PRD-305/corridas/`:
- `salida-product-charter.md`
