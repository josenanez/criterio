# Corrida · 2026-10-18-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:10:38 · **Fin:** 2026-10-18T08:11:02 · **Duración:** 24 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 11 | 65 | 75 documentos sin cambio, 0 por releer; 17 citas de PRY-201 no resuelven (rutas ausentes del índice); causa no determinada |

Por señal (`document-index`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Carpeta al 2026-10-18

**Documentos:** 75 · **Sin cambio:** 75 · **Hay que releer:** 0

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hubo que registrarlos de nuevo.

- **Contenido, renombrados, borrados:** no cambió, se renombró ni se borró ningún documento. Tampoco hubo reguardados ni formatos ilegibles.
- **Citas que dejaron de resolver:** hay 17, todas de PRY-201. Apuntan a tres documentos que no aparecen en el índice:
  - `00-gobierno/2025-06-01-acta-constitucion.md` (11 campos): identidad (código, nombre, área, producto, patrocinador, gerente, comité), fecha de inicio, alcance, exclusiones y presupuesto aprobado.
  - `20-seguimiento/2026-10-17-informe-avance.md` (5 campos): estado declarado, avance, comprometido, ejecutado y proyección.
  - `10-plan/2025-06-01-cronograma-v1.csv` (1 campo): fecha de fin.
- **Causa:** no la determiné. Puede ser una ruta mal escrita en la ficha o un documento que está fuera de la carpeta, y eso hay que mirarlo en la ficha. Mientras tanto el informe muestra esos datos como sustentados sin estarlo.
- **Barrido:** no hay nada que releer, así que no ofrezco `/portfolio-scan`. Lo único pendiente es corregir las citas de PRY-201, una por una y mostrando cada cambio.

La corrida quedó registrada como `2026-10-18-document-index-1` y tardó 11 segundos. El texto completo de la salida está en `estado/corridas/salida-document-index.md`.

La corrida también reporta 65 hallazgos de señales sobre las fichas, por ejemplo hitos cumplidos sin evidencia y compromisos vencidos. No salen de este índice, y no los revisé ni los validé.
