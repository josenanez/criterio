# Corrida · 2026-10-18-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-18T08:16:54 · **Fin:** 2026-10-18T08:17:52 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 42 | 65 | Historia de PRY-210 sobre 7 documentos: 1 replanificación sin motivo ni aprobación (84 días, 33.6 %), 4 hitos cerrados sin evidencia. No pude calcular meses declarando sin sustento ni saber qué pasó entre 2025-09-30 y 2026-10-08. |

Por señal (`project-history`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Historia · PRY-210 Corresponsales rurales · 2025-09-30 a 2026-10-17

Leí 7 documentos, de 2025-09-30 a 2026-10-17. Los términos ya estaban vigentes (v1.1, José Francisco Ñáñez, 2026-10-18), así que no hizo falta registrarlos de nuevo. El resumen de los términos es que esto es un borrador de trabajo, no una decisión ni una asesoría. Cada dato lleva su cita y la verificación es suya.

**En una línea:** el proyecto se aprobó el 2025-09-30, con cierre el 2026-06-17 y 2.400.000.000 COP. No dejó ningún documento hasta octubre de 2026. Entonces aparecen en nueve días un acta de recibo, una solicitud de cambio pendiente (CC-01), un comité y un cronograma v2. Ese cronograma mueve el cierre al 2026-09-09, una fecha que ya había pasado. El informe del 2026-10-17 declara amarillo y 69 %.

**Las cuatro cifras:**
- **Replanificaciones:** 1.
- **Atraso contra el original:** 84 días (33.6 %).
- **Meses declarando sin sustento:** no se puede calcular, porque el script no da la cifra y solo hay un estado declarado con fecha.
- **Cambios de gobierno:** 0.

**Los hallazgos principales:**
- **Silencio:** no hay documentos en 2025-T4 ni en 2026-T1, T2 y T3.
- **Replanificación:** la v2 se registró el 2026-10-17, 39 días después de su propia fecha nueva. No tiene motivo documentado ni aprobación. CC-01 sigue pendiente, y el comité del 2026-10-12 no la trata. El cálculo registra 84 días movidos y 0 autorizados.
- **Posible doble conteo:** CC-01 pide los mismos 84 días "sobre la línea base vigente", y la v2 ya los había movido. Ningún documento aclara si es el mismo cambio contado dos veces.
- **Hitos sin evidencia:** cuatro figuran como "cerrado" sin acta de recibo. El primero es "Diseño funcional aprobado", con fecha 2025-11-29. Los otros tres son la integración con el core, el piloto y la salida a producción. Solo "Ambiente de pruebas certificado" tiene acta, fechada 2026-10-08.
- **Contradicción:** el cronograma marca los 5 hitos como cerrados, mientras el informe declara 69 %. El hueco es de 31 puntos.
- **Compromisos:** solo hay uno, de Gustavo Neira, para el 2026-10-26. No se repitió.

**Lo que no sé:**
- Qué pasó entre 2025-09-30 y 2026-10-08.
- Cuántos meses lleva declarando sin sustento.
- El motivo de la replanificación.

No atribuyo intención a nadie. Puedo llevar esta historia al comité, con CC-01 como punto de entrada.

La salida completa está en `estado/corridas/salida-project-history.md`. La corrida quedó registrada como `2026-10-18-project-history-1`, con 42 segundos medidos por el script. El número de documentos leídos no quedó medido (`documentos: null`).
