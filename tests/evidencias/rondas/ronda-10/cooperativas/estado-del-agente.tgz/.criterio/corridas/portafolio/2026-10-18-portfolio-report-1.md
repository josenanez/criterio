# Corrida · 2026-10-18-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:26:11 · **Fin:** 2026-10-18T08:26:57 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 75 | 28 | 65 | Primer punto de partida sin delta; 4 verdes contradichos (PRY-201, 204, 206, 207); PRY-210 con línea base movida sin autorización; facturación sobre lo aceptado en PRY-200 y PRY-209. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 8, `commitment_overdue` 7, `progress_vs_plan` 6, `commitment_undated` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_accepted_without_evidence` 2, `vendor_invoiced_over_accepted` 2, `milestone_overdue` 2, `variance_time` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

# Portafolio — 2026-10-18

El informe en HTML quedó generado en `/home/claude/banco/ronda-10/cooperativas/espacio/reportes/`, con 25 páginas. Cubre 13 proyectos, 10 de ellos con hallazgos (65 señales en total). Cargué las 13 fichas de `estado/records/`, todas del 2026-10-18, y ninguna tiene más de una semana sin barrido. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré de nuevo.

**Qué cambió:** no hay delta. La única instantánea es la de hoy, así que este es el punto de partida.

**Dónde va cada vista**
- `index.html` es la vista por campo, con la cadena de evidencia completa. Es para quien va a actuar.
- `decisiones.html` es la vista por decisión, para el patrocinador. Solo trae lo que excede la facultad de quien gerencia.
- El PDF sale de imprimir el HTML.

**Lo que hay que mirar**
- **Verdes sin sustento:** PRY-201, PRY-204, PRY-206 y PRY-207 declaran verde y la evidencia lo contradice.
- **Línea base movida:** PRY-210 la movió 84 días (+33,6 %) sin autorización.
- **Facturado sobre lo aceptado:** Talento Solidario Ltda. facturó 948,2 M COP de más en PRY-209 y 179,5 M COP de más en PRY-200.
- **Costo:** PRY-207 va +27,9 % y PRY-200 va +14,5 %.
- **Hitos vencidos:** PRY-201 tiene uno de 14 días y PRY-207 uno de 7.
- **Hitos "cumplidos" sin evidencia:** hay 23 en 8 proyectos. El más viejo es el diseño funcional de PRY-201, con 334 días.
- **Vacíos de información:** ningún proyecto tiene autoridad definida (13 de 13) y 5 no tienen producto asignado.
- **Sin señales:** PRY-199, PRY-203 y PRY-205.

No hay contradicciones entre documentos ni proyectos en silencio (el mayor es PRY-205, con 12 días).

La confirmación mensual de cinco campos no se pidió: nadie podía responder en esta sesión sin interfaz.

Las fichas están en `estado/records/`, no en `estado/fichas/`, y las usé de ahí. La corrida quedó registrada como `2026-10-18-portfolio-report-1`, con la salida guardada en `estado/corridas/salida-portfolio-report.md`.

Pie: criterio-portfolio 0.5.0 · fichas del 2026-10-18 · campos inciertos: ninguno marcado · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

¿Preparo el material de comité (el próximo es el 2026-10-25) o entro al detalle de los proyectos con hallazgos?
