# Corrida del 2026-10-18 · pm-commitments

1 proyectos · 24 s · 14 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `commitment_rescheduled` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_undated` | 2 |
| `milestone_overdue` | 1 |
| `declared_vs_evidence` | 1 |

Reprogramado: Beatriz Cuéllar (6 veces), Paula Céspedes (5), Diana Molina (4); 5 vencidos sin evidencia (Lozano x2, Ospina, Gil, Salas); 2 sin fecha (Vélez)

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Compromisos — Apertura de ahorro en línea (PRY-201) · al 2026-10-18

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que pedirlos de nuevo.

26 compromisos en la ficha: 2 cerrados con documento, 5 vencidos sin evidencia, 2 sin fecha, 17 abiertos con fecha. Tres se vienen reprogramando 3 veces o más. Cifras de `portafolio.py compute`, sin `record_issues`.

### Se viene reprogramando

> **Beatriz Cuéllar** · Enviar el documento 1
> Prometido para el 2026-12-20, y antes para el 12-06, y antes para el 11-27, el 11-10, el 10-22 y el 10-12. La primera promesa fue el 2026-09-22. **Seis reprogramaciones.**
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Fuentes: comités semanales del 09-13 al 10-11 y notas del 2026-10-18.

> **Paula Céspedes** · Cerrar la prueba 2
> Prometido para el 2026-12-02, y antes para el 11-20, el 11-05, el 10-28 y el 10-15. La primera promesa fue el 2026-10-02. **Cinco reprogramaciones.** Fuentes: comités del 09-13 al 10-11.

> **Diana Molina** · Validar el ambiente 4
> Prometido para el 2026-11-22, y antes para el 11-13, el 10-31 y el 10-19. La primera promesa fue el 2026-09-29. **Cuatro reprogramaciones.** Fuentes: comités del 09-20 al 10-11.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Andrés Lozano | Revisar el anexo 11 | 2026-09-27 | 21 días |
| Andrés Lozano | Revisar el anexo 3 (reprogramado una vez) | 2026-10-04 | 14 días |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 | 11 días |
| Sandra Gil | Aprobar el diseño 21 | 2026-10-14 | 4 días |
| Ricardo Salas | Actualizar la matriz 6 (reprogramado una vez) | 2026-10-15 | 3 días |

Andrés Lozano dijo el 2026-09-27 que el anexo 11 ya lo entregó; no hay acta ni documento en el expediente que lo respalde, así que sigue abierto. Dos de sus tres compromisos están vencidos.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-18 (hoy) |
| Laura Vélez | Confirmar la fecha 23 | 2026-10-18 (hoy) |
| Laura Vélez | Enviar el documento 9 (reprogramado una vez) | 2026-10-20 |
| Beatriz Cuéllar | Actualizar la matriz 14 (reprogramado una vez) | 2026-10-21 |
| Gustavo Neira | Enviar el documento 17 | 2026-10-22 |

Las notas de hoy no mencionan los dos de hoy; no los doy por cumplidos ni por vencidos. Gustavo Neira dijo el 2026-10-11 que el documento 17 ya lo entregó; no hay acta en el expediente.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Confirmar la fecha 15 | 2026-09-27 |
| Laura Vélez | Enviar el ajuste del presupuesto («la otra semana») | 2026-10-18 |

Los dos son de la misma persona y no pueden estar vencidos; por eso se cuentan aparte. El primero lleva 21 días sin fecha.

### Cerrados desde la última revisión
No hay revisión anterior de compromisos; estos son los que la ficha tiene cerrados contra documento:
| Quién | Qué | Documento |
|---|---|---|
| Andrés Lozano | Confirmar la fecha 7 | `20-seguimiento/2026-09-20-acta-recibo-7.md` |
| Jorge Medina | Cerrar la prueba 10 | `20-seguimiento/2026-10-04-acta-recibo-10.md` |

### Lo que cruza con el informe
El informe del 2026-10-17 declara **verde** y 91 %. Contra eso: el hito «Integración con el core cooperativo» venció el 2026-10-04 (14 días), dos hitos están marcados como cumplidos sin evidencia, hay compromisos vencidos y reprogramados. La declaración no tiene respaldo en esas señales; decidir qué se hace con ello es del gerente.

### Después
Hay tres compromisos reprogramados 3 veces o más; el de Beatriz Cuéllar supera por mucho el umbral. Se puede formularlo como decisión para el comité con `/pm-escalate`: qué se pide, qué pasa si no se decide y quién tiene la facultad. La ficha no cambió en esta corrida, así que `/pm-publish` no hace falta por esto.
