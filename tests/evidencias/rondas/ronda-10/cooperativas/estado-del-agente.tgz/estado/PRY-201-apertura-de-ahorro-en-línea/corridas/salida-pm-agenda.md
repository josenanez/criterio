## Reunión de seguimiento — Apertura de ahorro en línea (PRY-201) · 2026-11-01
6 puntos · 45 minutos · 9 personas requeridas

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que pedirlos de nuevo.

**Antes de usarla:**
- Fecha: no vino en el argumento; tomé `committee_next` de la configuración (2026-11-01), que coincide con el «próxima reunión en dos semanas» de las notas del 10-18. La configuración dice comité **semanal los domingos**, así que el domingo 10-25 también tocaría: confírmalo. Si hay reunión el 10-25, esta agenda se corre a esa fecha.
- Duración: tampoco vino; asumí 45 minutos.
- No hay reunión anterior contra la cual comparar (`diff` dio «sin foto previa»). Armé la agenda con la ficha al 2026-10-18; lo que venza entre hoy y el 11-01 hay que volver a mirarlo con evidencia antes de la reunión.

### Lo que no se destraba solo

> **[1] Qué bloquea el documento 1 y quién lo puede quitar** · 12 min · **Beatriz Cuéllar** (y quien tenga la facultad de destrabar; el expediente no la nombra: `identity.authority` no encontrada)
> Prometido para el 2026-12-20, y antes para el 12-06, el 11-27, el 11-10, el 10-22, el 10-12. La primera promesa fue el 2026-09-22. **Seis reprogramaciones.**
> Fuente: comités semanales del 09-13 al 10-11 y notas del 2026-10-18 (línea 4).
> **Si no se resuelve hoy:** la fecha sigue corriéndose una semana por reunión, y ya va tres meses después de la promesa original. Seis veces no es seguimiento: es un bloqueo sin nombrar. Resultado esperado: el bloqueo con nombre y dueño, o el compromiso formulado como decisión de comité (`/pm-escalate`). Beatriz también tiene «Aprobar el diseño 5» (2 reprogramaciones, vence 11-04) y «Entregar el punto 16» (1, vence 11-06): se mencionan, no se discuten aparte.

> **[2] Qué le falta a la prueba 2 para cerrarse** · 8 min · **Paula Céspedes**
> Prometido para el 2026-12-02, y antes para el 11-20, el 11-05, el 10-28 y el 10-15. La primera promesa fue el 2026-10-02. **Cinco reprogramaciones.**
> Fuente: comités del 09-13 al 10-11.
> **Si no se resuelve hoy:** el cierre de pruebas se corre otra semana; la prueba se acerca al fin de año sin respaldar el hito del core.

> **[3] Qué impide validar el ambiente 4** · 6 min · **Diana Molina**
> Prometido para el 2026-11-22, y antes para el 11-13, el 10-31 y el 10-19. La primera promesa fue el 2026-09-29. **Cuatro reprogramaciones.**
> Fuente: comités del 09-20 al 10-11.
> **Si no se resuelve hoy:** pasa el 10-31 sin cumplirse y suma la quinta reprogramación.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Andrés Lozano | Revisar el anexo 11 | 2026-09-27 (21 días al 10-18) | El documento o el acta: dijo el 09-27 que ya lo entregó y no hay nada en el expediente | 2 |
| Andrés Lozano | Revisar el anexo 3 (reprogramado 1 vez) | 2026-10-04 (14 días) | Fecha real o evidencia | 2 |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 (11 días) | Evidencia o nueva fecha (es de la gerente; se declara, no se discute) | 2 |
| Sandra Gil | Aprobar el diseño 21 | 2026-10-14 (4 días) | La aprobación o quién la bloquea | 2 |
| Ricardo Salas | Actualizar la matriz 6 (reprogramado 1 vez) | 2026-10-15 (3 días) | Evidencia o nueva fecha | 2 |

Gustavo Neira dijo el 10-11 que el documento 17 ya lo entregó (vence 10-22) y tampoco hay acta: se incluye en la verificación, sin punto aparte.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar como riesgo que el proveedor no llegue con el equipo completo a la siguiente fase, con probabilidad, impacto y dueño (se comentó el 10-18, «nadie lo anotó como riesgo»; los tres riesgos de la ficha están sin dueño ni fecha) | Natalia Ospina, con Óscar Ramírez (revisión con el proveedor, 10-28) | Sigue sin dueño un riesgo que se sumaría al hito «Integración con el core cooperativo», vencido desde el 2026-10-04 | 6 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-11-04 |
| Beatriz Cuéllar | Entregar el punto 16 | 2026-11-06 |
| Gustavo Neira | Aprobar el diseño 13 (2 reprogramaciones) | 2026-11-09 |
| Natalia Ospina | Cerrar la prueba 18 | 2026-11-09 |

(Los que vencen entre el 10-19 y el 10-31 —entre ellos Mauricio Pérez, Laura Vélez, Rubén Cárdenas, Ricardo Salas, Liliana Torres y Óscar Ramírez— pasarán a «vencido sin evidencia» el 11-01 si no hay documento; se revisan contra evidencia al llegar, no se discuten.)

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Hito «Integración con el core cooperativo», vencido el 2026-10-04 sin evidencia, contra un informe que declara verde y 91 % | Excede lo que esta sala decide: el expediente no nombra autoridad del proyecto (`identity.authority` no encontrada); el patrocinador es Elena Duarte y no figura entre los asistentes | Comité (Comité de Crédito); `/pm-escalate` |
| Qué estado declarar en el informe (verde vs. las señales abiertas) | Es del gerente; el agente solo muestra contra qué | `/pm-report` |
| Cadencia del comité (semanal vs. quincenal) | Es una confirmación del gerente, no un tema para la sala | Confirmarlo antes de convocar |
| Dos compromisos sin fecha de Laura Vélez («Confirmar la fecha 15», desde el 09-27; «ajuste del presupuesto», «la otra semana») | No son punto de reunión: basta que ella dé fecha por mensaje antes | Mensaje previo del gerente |

### Anexo — sin cambios (no se repasa)
No hay reunión previa de seguimiento que compare, así que «sin cambios» se mide contra la ficha del 2026-10-18. Abiertos con fecha, sin vencer ni reprogramarse más de una vez, que no entran como punto:
- Jorge Medina · Cerrar la prueba 10 — cerrado con `20-seguimiento/2026-10-04-acta-recibo-10.md`
- Andrés Lozano · Confirmar la fecha 7 — cerrado con `20-seguimiento/2026-09-20-acta-recibo-7.md`
- Ricardo Salas · Revisar el anexo 19 (10-28) y Entregar el punto 24 (10-27)
- Rubén Cárdenas · Entregar el punto 8 (10-30; 2 reprogramaciones)
- Liliana Torres · Actualizar la matriz 22 (10-31)

**Suma:** 12 + 8 + 6 + 10 + 6 = 42 minutos de puntos, con 3 de margen. Nada quedó fuera por tiempo.

**Personas requeridas:** Beatriz Cuéllar, Paula Céspedes, Diana Molina, Andrés Lozano, Natalia Ospina, Sandra Gil, Ricardo Salas, Óscar Ramírez y quien tenga la facultad sobre el bloqueo del punto 1 (sin nombre en el expediente). La agenda no convoca a nadie: convocar es del gerente.

**Después:** cuando termine, `/pm-minutes` sobre las notas; los compromisos entran a `/pm-commitments`. Para el punto 1, `/pm-escalate`.
