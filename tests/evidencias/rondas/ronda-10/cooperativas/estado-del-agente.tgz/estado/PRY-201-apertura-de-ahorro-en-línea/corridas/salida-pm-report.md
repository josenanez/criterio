# Apertura de ahorro en línea (PRY-201) — corte al 2026-10-18

**Declara el gerente (Natalia Ospina) hoy:** — sin declaración. Nadie respondió en esta sesión; la línea queda en blanco a propósito.
**Declaración documentada más reciente:** verde · 91 % · al 2026-10-17 (`20-seguimiento/2026-10-17-informe-avance.md`, 1 día de antigüedad). Es lo que dice el documento, no una declaración de hoy.
**Sustento documental:** contradicho. 0 fuentes de evidencia, 2 declaraciones, 15 sin marcar.
**Lo que el semáforo no explica:** hito vencido, hitos «cumplidos» sin evidencia, compromisos vencidos y compromisos reprogramados.

## Qué cambió esta semana
Es la primera instantánea de este proyecto (2026-10-18), así que no hay corrida anterior contra la cual comparar. `diff`: 0 cambios. No puedo decir qué cambió desde la semana pasada. Desde esta corrida sí se podrá.

## Lo que sigue igual y sigue mal
Sin corrida previa, «desde cuándo» se toma de las fechas de vencimiento en los documentos.

| Qué | Desde | Días así |
|---|---|---|
| Hito «Integración con el core cooperativo» vencido | 2026-10-04 | 14 |
| Andrés Lozano: revisar el anexo 11 | 2026-09-27 | 21 |
| Andrés Lozano: revisar el anexo 3 | 2026-10-04 | 14 |
| Natalia Ospina: validar el ambiente 20 | 2026-10-07 | 11 |
| Sandra Gil: aprobar el diseño 21 | 2026-10-14 | 4 |
| Ricardo Salas: actualizar la matriz 6 | 2026-10-15 | 3 |
| Hito «Diseño funcional aprobado» (cumplido, sin evidencia) | 2025-11-18 | 334 |
| Hito «Ambiente de pruebas certificado» (cumplido, sin evidencia) | 2026-04-27 | 174 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-04 | 2026-10-04 | 0 días contra ambas |
| Presupuesto aprobado | COP 18.000.000.000 | COP 18.000.000.000 | 0 % |

Replanificaciones: 0. La fecha de cierre (2026-10-04) ya pasó hace 14 días y el hito de integración con el core sigue abierto. La desviación en 0 viene de que nadie movió la línea base, no de que se cumpliera el plan.

Avance declarado 91 %. El plan sostiene entre 67 % y 100 % (2 de 3 hitos cumplidos), y esos 2 cumplidos no tienen evidencia.

### Hitos de las próximas cuatro semanas
Ninguno. Los 3 hitos del plan están cumplidos (2, sin evidencia) o vencidos (1).

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 13.196.888.150 (73,3 %) | 6.420.513.826 (35,7 %) | 18.779.394.290 (+4,3 % sobre lo aprobado) | 4.803.111.850 |

Cifras en COP. El disponible real es aprobado menos comprometido. La proyección supera lo aprobado en 4,3 %, por debajo del umbral de 10 %.

## Abierto
**Reprogramados (primero):**
- Beatriz Cuéllar, «Enviar el documento 1»: 6 veces. Original 2026-09-22; hoy 2026-12-20.
- Paula Céspedes, «Cerrar la prueba 2»: 5 veces. Original 2026-10-02; hoy 2026-12-02.
- Diana Molina, «Validar el ambiente 4»: 4 veces. Original 2026-09-29; hoy 2026-11-22.

Los dos primeros pasan el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:** los cinco de la tabla anterior (Lozano ×2, Salas, Ospina, Gil).
**Sin fecha:**
- Laura Vélez, «Confirmar la fecha 15» (comité del 2026-09-27).
- Laura Vélez, «Enviar el ajuste del presupuesto» («la otra semana», notas del 2026-10-18).

**RAID sin movimiento:** no hay datos en esta corrida.
**Proveedor:** sin proveedores registrados.

## Lo que necesito de alguien
- **Natalia Ospina:** declarar estado y avance con las señales de arriba a la vista; la línea está en blanco.
- **Natalia Ospina:** aportar evidencia documental de los hitos «Diseño funcional aprobado» y «Ambiente de pruebas certificado», o corregir su estado.
- **Sandra Gil / Andrés Lozano / Ricardo Salas:** cerrar o reprogramar con fecha lo vencido.
- **Laura Vélez:** fechar sus dos compromisos.
- **Material de comité (excede al gerente):** la fecha de cierre del 2026-10-04 ya pasó sin replanificar, y hay dos compromisos reprogramados 5 y 6 veces. Se recomienda armar el punto de comité con la decisión formulada.

## Lo que no se sabe
**Sin dato:** `identity.authority`, `identity.phase`. Otros 12 campos de identidad, plan y presupuesto aprobado tienen 16 meses (fuente del 2025-06-01).
**Silencio:** último documento hace 0 días (2026-10-18) · última reunión: notas del 2026-10-18, hace 0 días.

---
Ficha: PRY-201, estado al 2026-10-18 · 2 campos sin dato · términos v1.1 (criterio-project 0.5.0): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
