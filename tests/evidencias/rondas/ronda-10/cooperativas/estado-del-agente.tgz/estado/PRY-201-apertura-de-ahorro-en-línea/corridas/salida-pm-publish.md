Publiqué la ficha en `documentos/proyectos/PRY-201-apertura-de-ahorro-en-línea/00-gobierno/ficha-pm.json`, con corte al 2026-10-18.

**Lleva:** 17 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · declara **verde** al 2026-10-17 (91 % de avance, declarado por la gerente en `20-seguimiento/2026-10-17-informe-avance.md`)

**Lo más viejo que va ahí:** los datos de identidad, plan y presupuesto aprobado (`identity.*`, `plan.start_date`, `plan.end_date`, `plan.scope_summary`, `plan.exclusions`, `money.approved`), todos del acta y el cronograma del 2025-06-01, 16 meses; pasa de un año.

**Antes de publicar**
- Recalculé la ficha (`compute`, corte 2026-10-18). Fecha de cierre: `plan.end_date` = 2026-10-04, del último hito del único cronograma que hay (`10-plan/2025-06-01-cronograma-v1.csv`, v1). No hay cronograma más nuevo, así que la fecha vigente y la de la línea base coinciden.
- Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos otra vez.

**Lo que la PMO va a ver junto al «verde» declarado** (14 alertas; el estado declarado no las explica):
- Hito «Integración con el core cooperativo» vencido hace 14 días (2026-10-04).
- Dos hitos declarados cumplidos sin evidencia: «Diseño funcional aprobado» y «Ambiente de pruebas certificado».
- 5 compromisos vencidos (Lozano ×2, Salas, Ospina, Gil), 3 reprogramados 4 a 6 veces (Cuéllar, Céspedes, Molina) y 2 sin fecha (Vélez).
- Dinero (COP): aprobado 18.000.000.000; comprometido 13.196.888.150 (73,3 %); ejecutado 6.420.513.826 (35,7 %); proyección 18.779.394.290 (4,3 % sobre lo aprobado).

La ficha es una copia del registro del estado, con el esquema de project-record. El estado «verde» sigue siendo una declaración tuya, y la ficha lo marca así.
