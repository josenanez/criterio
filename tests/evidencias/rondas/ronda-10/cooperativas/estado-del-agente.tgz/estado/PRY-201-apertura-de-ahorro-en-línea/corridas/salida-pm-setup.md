## Listo — PRY-201 · Apertura de ahorro en línea

**Lo que miré:** 12 documentos · 7 reuniones (6 minutas del comité y las notas del 2026-10-18) · la última del 2026-10-18 · todos los formatos se pudieron leer. Leí las siete en orden, de la más vieja a la más nueva.
**Quién eres y cuándo reúnes:** tomé lo que dice el acta de constitución: gerente Natalia Ospina, patrocinadora Elena Duarte, Comité de Crédito. El comité cae los domingos, cada semana (así están fechadas las minutas); las notas dicen «próxima reunión en dos semanas», así que anoté el 2026-11-01.
**Dónde guardo lo que encuentro:** `estado/PRY-201-apertura-de-ahorro-en-línea`.
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.1 (familia 0.5.0), el 2026-10-18 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 ffa4799dee7ac84c… Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

> El acta nombra gerente a Natalia Ospina, pero la aceptación de términos quedó a nombre de José Francisco Ñáñez, como pidió la prueba. Si el gerente es otra persona, dímelo y lo ajusto.

### Lo que está abierto, y cuántas veces se ha movido
Son 26 compromisos en las siete reuniones: 2 cerrados con acta de recibo, 5 vencidos sin evidencia, 2 sin fecha y 17 abiertos con fecha.

**Los que se han movido más (todos siguen abiertos):**

| Quién | Qué | Para cuándo hoy | Veces que se movió |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-20 | 6 · prometido el 2026-09-22; luego 10-12, 10-22, 11-10, 11-27, 12-06 y 12-20 (de 30-reuniones/2026-09-06-comite-semanal.md a 2026-10-18-notas-reunion.txt) |
| Paula Céspedes | Cerrar la prueba 2 | 2026-12-02 | 5 · prometido el 2026-10-02; luego 10-15, 10-28, 11-05, 11-20 y 12-02 |
| Diana Molina | Validar el ambiente 4 | 2026-11-22 | 4 · prometido el 2026-09-29; luego 10-19, 10-31, 11-13 y 11-22 |

Otros tres se han movido dos veces (Beatriz Cuéllar, «Aprobar el diseño 5»; Rubén Cárdenas, «Entregar el punto 8»; Gustavo Neira, «Aprobar el diseño 13»), pero el script no los marca porque no llegan al umbral de 3.

**Vencidos sin evidencia:**

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Andrés Lozano | Revisar el anexo 3 | 2026-10-04 | 14 | 30-reuniones/2026-09-06-comite-semanal.md |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-27 | 21 | 30-reuniones/2026-09-20-comite-semanal.md |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-15 | 3 | 30-reuniones/2026-09-13-comite-semanal.md |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 | 11 | 30-reuniones/2026-10-04-comite-semanal.md |
| Sandra Gil | Aprobar el diseño 21 | 2026-10-14 | 4 | 30-reuniones/2026-10-11-comite-semanal.md |

En «Revisar el anexo 11», Andrés Lozano dijo el 2026-09-27 que ya lo entregó, pero no se presentó acta; por eso no lo di por cerrado. Con «Enviar el documento 17» (Gustavo Neira, dicho el 2026-10-11) pasa lo mismo, aunque su fecha, 2026-10-22, aún no llega.

**Cerrados con acta:** Confirmar la fecha 7 (Andrés Lozano, acta de recibo del 2026-09-20) y Cerrar la prueba 10 (Jorge Medina, acta de recibo del 2026-10-04).

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos:
- Laura Vélez · Confirmar la fecha 15 — «por definir» desde el 2026-09-27, tres reuniones seguidas (30-reuniones/2026-09-27-comite-semanal.md).
- Laura Vélez · Enviar el ajuste del presupuesto — «la otra semana» (2026-10-18-notas-reunion.txt). No calculé una fecha.

### Lo que contrasta con tu informe
El informe del 2026-10-17 declara **verde** y 91 % (20-seguimiento/2026-10-17-informe-avance.md). El script levantó contra esa declaración:
- El hito «Integración con el core cooperativo» venció el 2026-10-04, hace 14 días, y el cronograma lo tiene «en curso».
- Los hitos «Diseño funcional aprobado» y «Ambiente de pruebas certificado» están declarados cerrados en el cronograma, sin acta que lo pruebe.
- Los 5 compromisos vencidos y los 3 reprogramados de arriba.

Sobre el presupuesto, el script da proyección de 18.779.394.290 COP contra 18.000.000.000 aprobados (4,3 % por encima); queda por debajo del umbral de 10 % y no levantó señal.

Aparte, las notas del 2026-10-18 recogen que el proveedor podría no llegar con el equipo completo para la siguiente fase y que nadie lo anotó como riesgo; lo dejé en la ficha como riesgo sin dueño ni valoración.

### Qué le falta a tu carpeta
- Actas de recibo de lo entregado: solo hay 2 para 26 compromisos, y ninguna para los hitos cerrados del cronograma.
- Un cronograma posterior al v1: el hito de integración con el core ya está vencido y no hay replanificación.
- El acta de constitución no define la autoridad del gerente, ni la fase, y su alcance son «Componente 1, 2 y 3» sin descripción.
- Minutas de antes del 2026-09-06: no hay, así que la historia de los compromisos empieza ahí.

**Cuándo vuelvo:** cada semana, el domingo; la próxima reunión según las notas es el 2026-11-01.
