## Apertura de ahorro en línea (PRY-201) · 2026-10-18

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que pedirlos de nuevo.

**Revisé:** 13 documentos · 13 sin hash previo en el índice (primer barrido) · 1 minuta sin extraer: ninguna. Las 6 actas de comité y las notas del 2026-10-18 ya estaban extraídas en la ficha por las corridas de hoy (pm-setup, pm-minutes), así que no repetí la extracción.

### Lo que se venció solo
No hay una corrida de barrido anterior con la que comparar (`sweep.last` vacío), así que no puedo decir qué cruzó «desde ayer». Lo que está cruzado hoy, igual que en las corridas de hoy y sin cambio (14 señales):

- Vencidos sin evidencia (5): Andrés Lozano, anexo 11 (21 días) y anexo 3 (14 días); Natalia Ospina, ambiente 20 (11 días); Sandra Gil, diseño 21 (4 días); Ricardo Salas, matriz 6 (3 días).
- Reprogramados 3 veces o más: Beatriz Cuéllar, documento 1 (6 veces; fecha actual 2026-12-20); Paula Céspedes, prueba 2 (5); Diana Molina, ambiente 4 (4).
- Hito «Integración con el core cooperativo» vencido hace 14 días (2026-10-04) y sin evidencia.
- Informe del 2026-10-17 en verde y 91 %, contradicho por las señales anteriores.
- Vencen hoy y las notas no los mencionan, así que no los doy por cumplidos ni por vencidos: Mauricio Pérez (ambiente 12) y Laura Vélez (fecha 23).

### La reunión
El comité es el 2026-11-01, en 14 días; el informe toca el 2026-10-31. Todavía no toca ofrecer agenda ni informe. El acta de la reunión de hoy ya está hecha a partir de las notas.

### Tu ficha publicada
Está al día: la ficha se publicó después de la última actualización del expediente y no ha cambiado desde entonces.

**Vuelvo el 2026-10-19.**
