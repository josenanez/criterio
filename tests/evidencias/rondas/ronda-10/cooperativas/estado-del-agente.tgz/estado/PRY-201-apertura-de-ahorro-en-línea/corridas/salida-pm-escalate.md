## Para decisión — PRY-201 Apertura de ahorro en línea · 2026-10-18

### ¿Confirma el Comité de Crédito, por escrito y con fecha, qué puede decidir por sí sola la gerente de proyecto (Natalia Ospina) en alcance, fechas y presupuesto, y desde qué umbral debe escalar?

**Quién decide:** Comité de Crédito, con la patrocinadora Elena Duarte (acta de constitución, 2025-06-01) · **Si no se decide hoy:** sin fecha en los documentos. El efecto concreto es que cualquier desvío, y hoy hay varios, se escala o se calla sin una vara declarada, y un punto dirigido a quien no puede decidirlo se devuelve. Pongo como fecha límite razonable el comité del 2026-11-01 (`cycle.committee_next`), que es una fecha de agenda y no un vencimiento que los documentos declaren.

**Por qué este es el punto que escala:** el acta no declara autoridad del gerente. El campo `identity.authority` está en `not_found`. El acta nombra patrocinador, gerente y comité, y fija presupuesto y fechas, pero no dice qué puede mover el gerente sin pasar por el comité. Con eso, nada de lo demás se puede dirigir con certeza a quien tiene la facultad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité declara la autoridad ahora (adenda al acta) | Ninguno | Una sesión | Ninguno directo; fija desde qué desvío se escala |
| B. Se queda como está y todo desvío se lleva al comité | Ninguno | Carga fija en cada sesión | Ninguno directo; el comité recibe también lo que el gerente podría resolver |
| C. Se declara en el siguiente cambio de línea base | Ninguno | Se espera a que haya un cambio | Hasta entonces el vacío sigue |

*No estimé costos en pesos ni en días para estas opciones: ningún documento los da, y no los invento.*

**Recomiendo:** A. Cuesta una sesión y es lo que hace que los puntos de abajo se puedan dirigir a quien corresponde. Los puntos 1 y 2 de abajo son precisamente los que hoy no se sabe si exceden o no la autoridad.

### Lo que no armo como paquete, y por qué

Esto cumple el criterio de escalamiento, pero no tiene todavía una decisión que se responda con una palabra. Lo que falta es lo que se dice en cada caso:

1. **Presupuesto.** La proyección al cierre es 18.779.394.290 COP contra 18.000.000.000 aprobados: 779.394.290 por encima (4,33 %). El informe del 2026-10-17 la declara con estado **verde**. Falta saber si ese margen está dentro de la autoridad de la gerente. Sin autoridad declarada no se puede decir si esto escala o se resuelve dentro del proyecto. Una vez que el comité conteste el punto de arriba, esto se clasifica. No hay solicitud de cambio registrada (`changes` vacío).
2. **Hito vencido.** *Integración con el core cooperativo*: fecha de línea base y vigente 2026-10-04, estado `pending`. Lleva 14 días vencido, sin reprogramación ni evidencia de recibo. Es también la fecha de cierre del proyecto. Falta una fecha nueva propuesta por quien la tiene, y sin ella no hay efecto que calcular.
3. **Compromisos reprogramados más de tres veces** (criterio de escalamiento: «reprogramado tres veces»). Por estas razones suben, pero la decisión es de otra persona:
   - Beatriz Cuéllar, *Enviar el documento 1*: original 2026-09-22, hoy 2026-12-20, **5 reprogramaciones**, 89 días de corrimiento.
   - Paula Céspedes, *Cerrar la prueba 2*: original 2026-10-02, hoy 2026-12-02, **5 reprogramaciones**, 61 días.
   - Diana Molina, *Validar el ambiente 4*: original 2026-09-29, hoy 2026-11-22, **4 reprogramaciones**, 54 días.

   Antes que escalar, una llamada a cada doliente para saber qué lo traba. Si el obstáculo es de otro proyecto o de otra área, ahí sí hay una decisión que formular.
4. **Riesgo no registrado.** El proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-18; «nadie lo anotó como riesgo»). Se suma a «el proveedor no ha confirmado la fecha de la última entrega» y a la «dependencia del proveedor del core cooperativo», ambos sin probabilidad, impacto, doliente ni fecha. El acta dice «Dependencias declaradas: ninguna», lo que contradice el riesgo del core. Como riesgos sin doliente no tienen plan, aún no se pueden calificar como «mitigación vencida».

### A quién alcanza

**No lo calculé.** No hay un cambio de fecha formulado, y el comando `impact` necesita un número de días. Ningún documento propone uno; inventarlo sería fabricar el efecto. Cuando exista una fecha nueva para el hito de integración con el core, corre `/pm-escalate cambio <nueva fecha>` y el cálculo sale con los proyectos alcanzados, sus gerentes y la dependencia sin confirmar. Aun así, el hito depende del core cooperativo, así que es probable que PRY-202 (Core cooperativo) esté alcanzado. **Es una sospecha, no un dato.** No lo verifiqué contra la ficha de ese proyecto.

### Mis hitos por los que pasa

No aplica: no hay cambio de fecha en este paquete. Para el hito *Integración con el core cooperativo* (2026-10-04, pendiente) el cálculo queda pendiente de la nueva fecha.

### De dónde sale esto

- Autoridad no declarada: `00-gobierno/2025-06-01-acta-constitucion.md` (sin sección de autoridad; presupuesto, fechas y «Dependencias declaradas: Ninguna declarada»).
- Proyección y estado verde: `20-seguimiento/2026-10-17-informe-avance.md`.
- Hito pendiente: `10-plan/2025-06-01-cronograma-v1.csv`.
- Reprogramaciones: `30-reuniones/2026-09-06` a `2026-10-11-comite-semanal.md` y `2026-10-18-notas-reunion.txt`.
- Riesgo no anotado: `2026-10-18-notas-reunion.txt`.
- Fecha del comité: `.criterio/proyecto/PRY-201/config.json`.

**Qué no sé:** qué facultades tiene la gerente en la práctica (no está escrito), cuántos días se corre cada proyecto alcanzado, y si el margen sobre el presupuesto está aprobado por algún canal que no esté en la carpeta.
