# Plan — Apertura de ahorro en línea (PRY-201) · borrador del 2026-10-18
**Desde:** acta de constitución del 2025-06-01 (`00-gobierno/2025-06-01-acta-constitucion.md`) · **Criterio de éxito:** «Apertura de ahorro en línea en producción y medido.»

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que registrarlos de nuevo.

**Una cosa antes de leer el plan:** esta acta tiene 16 meses y el cierre comprometido en ella (2026-10-04) ya pasó sin que el hito de integración con el core esté cerrado. Esto no es un primer borrador de un proyecto que arranca: es una descomposición del trabajo que queda, hecha sobre un acta que no lo describe. Lo que sigue lo trata así.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío:** «Componente 1, 2, 3» sin descripción | No se puede descomponer por entregable lo que el acta no nombra. La WBS de abajo no puede partir los componentes; quedan como nodos «sin definir» |
| **Fuera de alcance vacío:** «Lo que otro proyecto cubre», sin decir qué ni cuál proyecto | No se sabe qué no construir. Riesgo de duplicar o de omitir trabajo que otro proyecto creía tener cubierto |
| **Sin autoridad declarada** (`identity.authority` no encontrada) | No se sabe qué puede decidir la gerente al planificar y qué debe subir a Elena Duarte o al Comité de Crédito |
| **Criterio de éxito sin umbral:** «en producción y medido» | «Medido» no dice qué métrica ni qué valor. Sin eso no se puede saber cuándo el último entregable está aceptado |
| **Dependencias: «Ninguna declarada»**, mientras el informe del 2026-10-17 declara dependencia del proveedor del core cooperativo | El acta contradice los documentos posteriores; el plan hereda una dependencia que oficialmente no existe |
| **Un solo hito intermedio** con fecha de línea base en el cronograma v1; no hay entregables, solo tres hitos | El cronograma no sirve de WBS: son hitos, no cosas que alguien recibe y acepta |

Hay patrocinador (Elena Duarte), presupuesto (18.000.000.000 COP) y gerente: eso sí está.

## WBS
Solo se descompone lo que un documento permite nombrar. Ningún nodo terminal tiene aceptador declarado en el acta.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Sin definir (el acta no lo dice) | Del acta/cronograma v1 — hito cerrado, línea base 2025-11-18 | — (cerrado) |
| 2 | Ambiente de pruebas certificado | Sin definir | Del cronograma v1 — hito cerrado, línea base 2026-04-27 | — (cerrado) |
| 3 | Integración con el core cooperativo | Sin definir | Del cronograma v1 — hito «en curso», línea base 2026-10-04 (vencida) | vacía |
| 4 | Componente 1 | Sin definir | Del acta, sin descripción | vacía |
| 5 | Componente 2 | Sin definir | Del acta, sin descripción | vacía |
| 6 | Componente 3 | Sin definir | Del acta, sin descripción | vacía |
| 7 | Última entrega del proveedor | Sin definir | Informe 2026-10-17: «el proveedor no ha confirmado la fecha de la última entrega»; no se sabe qué contiene | vacía |
| 8 | Ajuste del reglamento antes del piloto | Consejo de Administración lo pidió; quién acepta, sin definir | Informe 2026-10-17 («El Consejo de Administración pidió ajustar el reglamento antes del piloto»); no está en el acta | vacía |
| 9 | Piloto | Sin definir | **Supuesto:** el informe lo menciona como paso posterior al ajuste del reglamento; no hay descripción ni fecha | vacía |
| 10 | Revisión de requisitos no funcionales con arquitectura | Sin definir | Informe 2026-10-17 («se acordó con arquitectura cómo se revisan»); el entregable resultante no está definido | vacía |
| 11 | Apertura de ahorro en línea en producción | Sin definir (el acta cita el criterio, no a quien lo acepta) | Del acta, criterio de éxito | vacía |
| 12 | Medición de la apertura en producción | Sin definir | Del acta («y medido»), sin métrica | vacía |
| 13 | Ajuste del presupuesto | Elena Duarte / Comité de Crédito: **supuesto**, por ser quien aprobó el presupuesto | Notas 2026-10-18 (Laura Vélez, «la otra semana»); proyección 18.779.394.290 COP excede lo aprobado (18.000.000.000) en 779.394.290 | vacía |

## Orden
Sin fechas. Solo qué necesita qué:

- 1 → 2 → 3 (ya está en ese orden en el cronograma v1; 1 y 2 cerrados).
- 3 (integración con el core) → 4, 5, 6 **si** los componentes dependen del core. **Supuesto:** el acta no dice qué es cada componente, así que esta dependencia no se puede confirmar.
- 7 (última entrega del proveedor) → 3: **supuesto**, la integración con el core depende del proveedor del core (informe 2026-10-17), pero no se sabe si «la última entrega» es la misma cosa.
- 8 (reglamento) → 9 (piloto): lo dice el informe («antes del piloto»).
- 9 → 11 → 12: producción tras el piloto, medición tras producción. **Supuesto**, por lectura del criterio de éxito.
- 10 (requisitos no funcionales) → 11: **supuesto**.
- 13 (presupuesto) no tiene predecesor documentado; condiciona a todo lo que queda por ejecutar.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| El piloto es un paso entre el reglamento y producción | Si no hay piloto, o es otra cosa, el camino a producción cambia y el nodo 9 desaparece |
| Los componentes 1–3 dependen de la integración con el core | Si son independientes, pueden avanzar en paralelo y el atraso del hito 3 los afecta menos |
| «La última entrega» del proveedor y la integración con el core son entregables distintos | Si son lo mismo, los nodos 3 y 7 se funden y el riesgo del proveedor se concentra en un solo punto |
| El aceptador del ajuste de presupuesto es el Comité de Crédito (quien aprobó el original) | Si la autoridad está en otro lado (el acta no la declara), el ajuste puede estar yendo al sitio equivocado |
| Producción y medición son dos entregables distintos | Si se aceptan juntos, el nodo 12 es parte del 11 |

Estos pasan a RAID como supuestos en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los componentes 1, 2 y 3 | Natalia Ospina con Elena Duarte (patrocinadora): el acta no lo dice |
| Qué queda fuera de alcance y qué proyecto lo cubre | Elena Duarte |
| Autoridad de la gerente de proyecto | Elena Duarte / Comité de Crédito |
| Quién acepta cada entregable | Elena Duarte (patrocinadora) |
| Métrica y umbral de «medido» | Área dueña (Cartera y cobranza) y Elena Duarte |
| Contenido de «la última entrega» del proveedor | Natalia Ospina con el proveedor |
| Qué es el piloto, su alcance y su criterio de salida | Sin dueño en ningún documento |
| Qué entregable sale de la revisión de requisitos no funcionales con arquitectura | Sin dueño en ningún documento |
| Si el ajuste del reglamento entra en el alcance del proyecto | Elena Duarte / Consejo de Administración |
| Por qué cartera y cobranza es área dueña de un producto de ahorro a la vista | Elena Duarte — el acta no lo explica, no es un hallazgo del plan sino una pregunta de coherencia |

## Proyectos análogos
Ninguno a la vista: la configuración (`.criterio/proyecto/PRY-201/config.json`) no apunta a una carpeta de fichas de la PMO, y en esta carpeta solo está PRY-201. Es la respuesta correcta y evita una falsa precisión: no hay referencia de cuánto se corrió un proyecto parecido.

Lo único que hay como referencia **interna** es la historia de este mismo proyecto: el hito de integración con el core lleva su línea base en 2026-10-04 y sigue «en curso» el 2026-10-18 (cronograma v1; el cronograma no tiene fecha vigente distinta de la de línea base). Es un hecho, no una estimación.

## Preguntas para el equipo
Una por cada duración vacía:

1. ¿Cuánto toma terminar la integración con el core cooperativo (nodo 3), y qué falta exactamente? *(Quien más sabe: Natalia Ospina y el proveedor.)*
2. ¿Qué son los componentes 1, 2 y 3, y cuánto toma cada uno? (nodos 4–6)
3. ¿Qué contiene «la última entrega» del proveedor y cuándo la confirma? (nodo 7; Óscar Ramírez tiene la revisión con el proveedor para el 2026-10-28)
4. ¿Cuánto toma ajustar el reglamento y quién lo hace? (nodo 8)
5. ¿Qué es el piloto, a cuántos socios, durante cuánto tiempo y con qué criterio de salida? (nodo 9)
6. ¿Qué se revisa en los requisitos no funcionales y cuánto toma? (nodo 10)
7. ¿Cuánto separa el piloto de producción? (nodo 11)
8. ¿Qué se mide, con qué umbral, y cuánto tiempo hay que medir antes de aceptar? (nodo 12)
9. ¿Cuánto toma tramitar el ajuste de presupuesto y quién lo aprueba? (nodo 13; Laura Vélez ya quedó de enviarlo «la otra semana», sin fecha)

## Para comprometer una fecha falta
Nada de esto está en un documento:

- **Disponibilidad real del equipo.** 24 compromisos abiertos o vencidos en el registro, varios reprogramados una y otra vez (p. ej. «Enviar el documento 1», de Beatriz Cuéllar, se ha movido 6 veces: del 2026-09-22 al 2026-12-20). No se sabe qué capacidad real tiene cada persona.
- **La fecha del proveedor.** El informe dice que no ha confirmado la fecha de la última entrega, y las notas del 2026-10-18 añaden que podría no llegar con el equipo completo a la siguiente fase (nadie lo anotó como riesgo).
- **La ventana de producción y de piloto.** No hay ningún documento que diga cuándo se puede salir a producción ni cuándo el Consejo de Administración aceptaría un piloto.
- **Una decisión sobre el cierre vencido.** El cierre comprometido (2026-10-04) pasó. Replanificar es un cambio de línea base y necesita aprobación (Comité de Crédito); este borrador no lo hace.
- **Una decisión sobre el presupuesto.** La proyección (18.779.394.290 COP) supera el aprobado (18.000.000.000 COP) por 779.394.290 COP, mientras el estado declarado es verde. Eso no es un dato del plan sino una pregunta para el comité.

## Después
Cuando alguien apruebe el plan, ofrece registrarlo como línea base nueva (sin borrar la v1 de 2025-06-01) y pasar los supuestos al RAID con doliente.
