# Acta — Apertura de ahorro en línea (PRY-201) · 2026-10-18
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez (13) · **Fuente:** `2026-10-18-notas-reunion.txt` · **Ausentes con tema en agenda:** las notas no traen agenda, así que no puedo decir quién faltó a algo que se iba a tratar. Frente a la reunión del 2026-10-11 no faltó nadie, y Óscar Ramírez aparece por primera vez.

Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que volver a pedirlos.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-20 | **Reprogramado 6 veces.** Prometido para el 2026-09-22; luego 10-12, 10-22, 11-10, 11-27, 12-06 y 12-20. Línea 4: «lo de "enviar el documento 1" no alcanzó, se compromete para el 20/12/2026» |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 | Nuevo. Línea 6: «revisión con el proveedor, queda para el 2026-10-28» (ver «Sin resolver») |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — «la otra semana» (línea 5). No calculé una fecha. |

Laura Vélez ya tenía otro compromiso sin fecha desde el 2026-09-27 («Confirmar la fecha 15»); con este son dos.

## Decisiones
Ninguna. Las notas no registran ninguna decisión tomada por nadie.

## Quedó sin decidir
Nada se dejó planteado como pregunta abierta en las notas; no hay un «por qué» ni una «facultad» que anotar.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase (línea 7: «nadie lo anotó como riesgo») | No dice quién; las notas lo atribuyen a la sala («se comentó») | Riesgo | **No.** El informe del 2026-10-17 lista dos riesgos con el proveedor —que no ha confirmado la fecha de la última entrega, y la dependencia del proveedor del core—, pero ninguno habla de equipo incompleto. Queda en la ficha sin probabilidad, impacto ni dueño, porque nadie los dio. |

## Cerrado en esta reunión
Nada. (Se omite: ninguna promesa se cerró contra un documento.)

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (→ 2026-11-01) | Comité semanal, domingos | Notas 2026-10-18 · config del proyecto y minutas semanales del 2026-09-06 al 2026-10-11 |

No es un campo de la ficha del proyecto. Pero si el comité pasó a quincenal, la configuración sigue diciendo semanal y los avisos del domingo 2026-10-25 saldrían sin reunión. Confírmalo.

Además, el informe del 2026-10-17 declara **verde** y 91 %, y esta reunión suma una sexta reprogramación del documento 1. No es una contradicción de campo, pero va en la misma dirección que lo que ya levantó el cálculo (ver abajo).

## Sin resolver de la transcripción
- «20/12/2026»: lo leí como 20 de diciembre (día/mes), el único orden posible con ese 20. Quedó escrito 2026-12-20.
- «Lo de "enviar el documento 1" no alcanzó»: no dice qué no alcanzó. Lo leí como que la fecha anterior (2026-12-06) no se cumple; no lo afirma.
- «Revisión con el proveedor, queda para el 2026-10-28»: no dice si Óscar Ramírez la hace, la agenda o solo asiste. Lo registré como suyo porque es el único nombre; si es solo la fecha de una reunión, no es un compromiso de Óscar.
- «La otra semana» (Laura Vélez): relativo a una reunión del 2026-10-18; puede ser la semana del 10-19 o la del 10-26. Por eso va sin fecha.
- «Próxima reunión en dos semanas»: tomé 2026-11-01, que coincide con `committee_next`.
- Las notas no dicen nada de los compromisos de hoy: Mauricio Pérez (Validar el ambiente 12) y Laura Vélez (Confirmar la fecha 23) vencen el 2026-10-18 y no se mencionan. No los cierro ni los doy por vencidos.

---
### Recalculado contra la ficha (`portafolio.py compute`, sin `record_issues`)
Hoy 26 compromisos: 2 cerrados con acta de recibo, 5 vencidos sin evidencia, 2 sin fecha, 17 abiertos con fecha. Reprogramados 3+ veces: Beatriz Cuéllar (6), Paula Céspedes (5), Diana Molina (4). El hito «Integración con el core cooperativo» venció el 2026-10-04 (14 días). Lo declarado (verde, 91 %) no tiene respaldo en esas señales. Esta reunión no cambió ninguna cifra del cálculo salvo el segundo compromiso sin fecha y el de Óscar Ramírez, que ya estaban en la ficha.

**Qué sigue:** `/pm-commitments` para el seguimiento completo. No hace falta `/pm-publish` por esta acta: ningún campo de la ficha cambia por lo que se dijo hoy.

*El acta sale aquí y la guardas tú; no escribí nada en tu carpeta de reuniones.*
