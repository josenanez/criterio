Cierre de PRY-200 sobre su ficha (`estado/records/PRY-200.json`, actualizada 2026-10-18) y sus seis documentos: acta de constitución (2025-11-20), contrato CT-892 (2025-11-21), cronograma v1 (2025-11-20), factura FV-1892 (2026-09-25), acta de recibo del piloto (2026-10-10) e informe de avance (2026-10-13). Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-18 (versión 0.5.0). Cifras derivadas: salida de `portafolio.py compute`, copiadas sin recalcular a mano.

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-18

**Conclusión previa:** el proyecto **no tiene declaración de terminado**. El último documento (2026-10-13) lo declara en **rojo, 67 %**, con la fecha de cierre pactada (2026-08-31) vencida. Lo que sigue es el cierre que los documentos permiten, no un cierre por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Crédito de libranza digital en producción y medido." (acta de constitución, 2025-11-20, sección Criterio de éxito). No define qué se mide, con qué indicador ni con qué umbral.
**Se cumplió:** **no se puede determinar.** Ningún documento muestra el producto en producción ni una medición.

El alcance del acta son "Componente 1; Componente 2; Componente 3" sin descripción. Por eso no hay entregables comprometidos contra los que contrastar. Lo único contrastable son los 5 hitos del cronograma v1 y los 4 entregables del contrato CT-892.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Hito: Diseño funcional aprobado (2026-01-23) | Cerrado según el cronograma | Ninguna (el hito vencía hace 268 días) |
| Hito: Ambiente de pruebas certificado (2026-03-19) | Cerrado según el cronograma | Ninguna (213 días) |
| Hito: Integración con el core cooperativo (2026-05-13) | Cerrado según el cronograma | Ninguna (158 días) |
| Hito: Piloto con asociados (2026-07-07) | Cerrado | Acta de recibo del 2026-10-10, firmada por Gustavo Neira. Es posterior a la fecha del hito. |
| Hito: Salida a producción (2026-08-31) | Cerrado según el cronograma | Ninguna (48 días). El acta del piloto es posterior a esta fecha, así que el orden de los hechos no cuadra. |
| CT-892 Licenciamiento del módulo (2026-01-29, 823.489.299) | "en curso" | Ninguna; 262 días vencido |
| CT-892 Bolsa de horas de desarrollo (2026-03-30, 823.489.299) | "pendiente" | Ninguna; 202 días vencido |
| CT-892 Parametrización de líneas de crédito (2026-05-30, 823.489.299) | "recibido" | **Sin acta de recibo.** El contrato exige acta firmada por el gerente. |
| CT-892 Mesa de ayuda del primer trimestre (2026-07-29, 823.489.299) | "en curso" | Ninguna; 81 días vencido |

Contradicción de fondo: el cronograma marca los 5 hitos como cerrados (el plan respalda 100 %), pero el gerente declara 67 % y estado rojo. Una de las dos cosas es falsa y los documentos no dicen cuál. Cuatro de los cinco hitos "cerrados" no tienen evidencia.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| **Sin dato.** No hay ninguna decisión registrada de recortar alcance. | — | — |

El acta solo dice "Lo que otro proyecto cubre", sin nombrar cuál. No hay solicitudes de cambio en la ficha (0). Como el alcance nunca se describió, tampoco se puede probar que se haya recortado ni que no.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-31 | 2026-08-31 | **Sin dato** (no hay fecha real de terminación) | 0 días registrados (la línea base nunca se movió) |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | Ejecutado 10.475.680.794 (58,2 %); comprometido 7.409.726.138 (41,2 %); proyección al cierre 20.616.543.260 | **+14,5 %** sobre lo aprobado (señal `variance_cost`, umbral 10 %) |

Replanificaciones: **0**.

La desviación de fecha de 0 días no significa que el proyecto fuera puntual. Significa que nadie replanificó: la fecha pactada pasó sin que la línea base cambiara ni se registrara un cambio.

Disponible real según el script: 10.590.273.862 COP. La proyección supera el aprobado y ninguna aprobación de presupuesto adicional consta en los documentos.

Facturación del proveedor: la factura FV-1892 (2026-09-25, "radicada en cuentas por pagar") es por **1.002.986.926 COP**. Lo aceptado según la ficha es 823.489.299 COP, una diferencia de **179.497.627 COP**. Además, esa aceptación (Parametrización) no tiene acta de recibo. Con evidencia documental, lo aceptado es 0 COP.

### RAID al cierre
**Materializados:** ninguno se puede confirmar. Los hechos que el cierre encuentra (hitos vencidos, entregables sin recibo, sobrecosto) no están registrados como riesgos ni incidencias en la ficha.

**No materializados:** ninguno se puede afirmar.

**Abiertos, con doliente:** hay dos riesgos en el informe del 2026-10-13, y los dos **sin dueño, probabilidad, impacto ni fecha**. Sin doliente con nombre no están cerrados ni se pueden dejar cerrados.
- Concentración del conocimiento en una sola persona. Sin dueño.
- Dependencia del proveedor del core cooperativo. Sin dueño. El acta declaraba "Ninguna declarada" en dependencias.

Pendientes que no tienen registro pero que salen de este cierre y necesitan doliente:
- Los 3 entregables vencidos de CT-892 y la factura FV-1892 por encima de lo aceptado. Esto lo decide quien aprueba el pago, que no consta en los documentos.
- La falta de evidencia de 4 hitos "cerrados".

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta aprobó un alcance de "Componente 1, 2, 3" y un criterio de éxito "en producción y medido" sin indicador. | 2025-11-20 | Hoy no se puede determinar si el proyecto cumplió, ni si hubo recorte de alcance. | No aprobar el acta sin alcance descrito ni criterio de éxito medible. |
| Se firmó el contrato CT-892 con pago "contra acta de recibo firmada por el gerente"; hay 4 entregables y la ficha solo encuentra un acta de recibo (la del piloto, que no es de proveedor). | 2025-11-21 / 2026-09-25 | Se radicó FV-1892 por 1.002.986.926 COP frente a 823.489.299 aceptados (179.497.627 de diferencia); 3 entregables siguen vencidos. | No radicar facturas sin el acta de recibo de cada entregable adjunta. |
| El cronograma v1 nunca se replanificó aunque la fecha de cierre (2026-08-31) pasó con el gerente declarando 67 % y rojo. | 2026-08-31 en adelante | La desviación de fecha queda en 0 días y no refleja el atraso real. | Registrar el cambio y la nueva línea base cuando el plan deja de ser válido, sin borrar la original. |
| Hitos marcados como cerrados sin acta ni evidencia (4 de 5). | Desde 2026-01-23 | El plan dice 100 % y la declaración 67 %; no se sabe cuál es real. | Exigir el documento de aprobación para cerrar un hito. |

### Sin dato
- Fecha real de terminación y estado real del producto (¿está en producción? ¿se mide?).
- Quién declara el cierre y quién autoriza (el campo autoridad está sin dato en la ficha).
- Fase actual del proyecto (sin dato en la ficha).
- Actas de recibo de los 4 entregables de CT-892 y de los hitos 1, 2, 3 y 5.
- Aprobación del sobrecosto proyectado (+14,5 %) y de la factura por encima de lo aceptado.
- Descripción del alcance y qué proyecto cubre lo que quedó fuera.
- Riesgos con dueño, probabilidad, impacto y fecha.

### Sobre el archivo
Ofrecer mover la carpeta a `archivo/` y congelar la ficha: **no lo hice**, y lo dejo para la decisión de la PMO. Hoy no hay una declaración de cierre de nadie con autoridad, y el cierre no lo respalda ningún documento. Sacar el proyecto del barrido diario lo dejaría sin seguimiento con 3 entregables vencidos y una factura por encima de lo aceptado. Cuando haya cierre por decisión, quedaría registrado como "cerrado por decisión" y no "por cumplimiento".

### Pie de rigor
- Leído: los 6 documentos del proyecto y la ficha. Los PDF (factura y acta del piloto) los leí en su texto; no verifiqué firmas.
- No verificado: que el producto esté en producción, que el piloto haya existido más allá del acta, y que la factura siga sin pagarse.
- Las cifras de desviación, porcentajes, días y diferencias de dinero salen de `portafolio.py compute`. No calculé ninguna aparte.
- Lo declarado por el gerente (rojo, 67 %, riesgos) está en el informe del 2026-10-13, con 5 días de antigüedad. Es declaración, no evidencia.
