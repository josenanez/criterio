# Corrida del 2026-10-18 · vendor-tracking

13 proyectos · 36 s · 65 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 8 |
| `commitment_overdue` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `milestone_overdue` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Proveedor Talento Solidario (CT-892): 0 de 4 entregables con acta; facturado 1.002.986.926 vs aceptado declarado 823.489.299 (dif. 179.497.627). Sin dato: vigencia, renovación y preaviso del contrato, desglose de la factura, reuniones con el proveedor.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Salgo de estos documentos de PRY-200 (Crédito de libranza digital): contrato CT-892 (2025-11-21), acta de constitución (2025-11-20), cronograma v1 (2025-11-20), factura FV-1892 (2026-09-25), acta de recibo del piloto (2026-10-10) e informe de avance (2026-10-13). Las cifras derivadas salen de `portafolio.py compute` al 2026-10-18.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

## Proveedores — PRY-200 Crédito de libranza digital al 2026-10-18

### Talento Solidario Ltda. — contrato CT-892
**Vigencia:** firmado el 2025-11-21; inicio y fin no declarados en el contrato · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2026-01-29 · 823.489.299 COP | `unknown` (el contrato dice "en curso") | Ninguna | Sin desglose |
| Bolsa de horas de desarrollo | 2026-03-30 · 823.489.299 COP | `pending` (el contrato dice "pendiente") | Ninguna | Sin desglose |
| Parametrización de líneas de crédito | 2026-05-30 · 823.489.299 COP | Declarado `accepted` ("recibido"), sin respaldo | Ninguna | Sin desglose |
| Mesa de ayuda del primer trimestre | 2026-07-29 · 823.489.299 COP | `unknown` (el contrato dice "en curso") | Ninguna | Sin desglose |

Facturado en total: **1.002.986.926 COP** (factura FV-1892, 2026-09-25, "Entregables del contrato CT-892", radicada en cuentas por pagar). Entregables con acta de recibo: **0 de 4**.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado vs. aceptado | Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto | Se facturaron 1.002.986.926 COP; el único entregable declarado aceptado vale 823.489.299 COP; diferencia **179.497.627 COP**. La cifra es la que da el script, que cuenta como aceptado el entregable que solo el contrato declara "recibido". Si se exige acta, lo aceptado con evidencia es 0 | Contrato CT-892; factura FV-1892 |
| Factura sin desglose | Cuatro entregables de 823.489.299 COP cada uno | La factura dice "Entregables del contrato CT-892" y no nombra cuáles cobra. 1.002.986.926 no coincide con ninguno de los montos de la tabla | Contrato CT-892; factura FV-1892 |
| Acta de recibo | La condición de pago pide acta por entregable | La única acta en la carpeta recibe el "Piloto con asociados", que es un hito del cronograma y no un entregable de CT-892 | Acta de recibo 2026-10-10; contrato CT-892 |
| Avance vs. plan | El cronograma marca los 5 hitos como cerrados (100 %) | El informe declara 67 %: diferencia de 33 puntos | Cronograma v1; informe de avance 2026-10-13 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Parametrización de líneas de crédito | "recibido" (contrato) | Vencía el 2026-05-30; sin acta ni correo |
| Licenciamiento del módulo | "en curso" | Vencido hace 262 días (2026-01-29) |
| Bolsa de horas de desarrollo | "pendiente" | Vencido hace 202 días (2026-03-30) |
| Mesa de ayuda del primer trimestre | "en curso" | Vencido hace 81 días (2026-07-29) |

Tres entregables llevan fecha pasada, sin evidencia y sin entrega declarada (262, 202 y 81 días). El cuarto figura recibido, pero ningún documento lo prueba. Hitos del cronograma cerrados sin evidencia: Diseño funcional aprobado (268 días desde su fecha), Ambiente de pruebas certificado (213), Integración con el core cooperativo (158) y Salida a producción (48). Solo el piloto tiene acta.

### Compromisos del proveedor vencidos
Ninguno que pueda afirmar. La carpeta no tiene reuniones con el proveedor (no hay `30-reuniones`) y la ficha no registra compromisos. Eso no demuestra que no existan.

### Sin dato
- **Vigencia, renovación automática y preaviso de CT-892:** el contrato no los trae. No puedo decir si hay un preaviso por vencer ni compararlo con el cierre del proyecto, que estaba en 2026-08-31 y sigue sin línea base nueva.
- **Qué cobra la factura FV-1892:** no hay desglose por entregable.
- **Si la factura se pagó:** dice "radicada en cuentas por pagar", sin fecha de pago.
- **Actas o correos de aceptación** de los cuatro entregables del contrato.
- **Costo:** la proyección al cierre es 20.616.543.260 COP contra 18.000.000.000 aprobados (14,5 % por encima). Es contexto: el informe no atribuye nada de eso al proveedor.

### Qué haría
La factura FV-1892 está radicada y puede pagarse contra un solo entregable declarado recibido y sin acta. Sugiero frenar el pago hasta tener las actas, o hasta que la factura diga qué cobra. Si quiere, lo llevo a comité (próximo: 2026-10-25) como entregables facturados sin evidencia, y pido el contrato completo con su vigencia y preaviso.

---
**Pie de rigor.** Todo sale de seis documentos de la carpeta; lo hablado fuera de ellos no lo conozco. El informe de avance declara estado rojo y no menciona al proveedor ni las señales anteriores. Las cifras derivadas se copian de `compute`; la lectura de qué cuenta como aceptación es mía y debe verificarse contra los originales citados.
