Fuente: ficha `estado/records/PRY-200.json` y salida de `portafolio.py compute` al 2026-10-18. Documentos: acta de constitución (2025-11-20), informe de avance (2026-10-13), factura CT-892 (2026-09-25), contrato CT-892 (2025-11-21), cronograma v1 (2025-11-20).

## Presupuesto — PRY-200 Crédito de libranza digital al 2026-10-18
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 18.000.000.000 | — | 00-gobierno/2025-11-20-acta-constitucion.md | 2025-11-20 |
| Comprometido | 7.409.726.138 | 41.2% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Ejecutado | 10.475.680.794 | 58.2% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Proyección al cierre | 20.616.543.260 | 14.5% por encima del aprobado | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 10.590.273.862 COP

Lectura: el comprometido (41.2%) es menor que el ejecutado (58.2%). No sé si el informe de avance declara el comprometido incluyendo lo ya ejecutado o aparte; el documento no lo aclara. Por eso el «disponible real» de arriba puede estar sobreestimado si ambos son aditivos. Pendiente de confirmar con quien firma el informe.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto | 18.000.000.000 | 18.000.000.000 | 0 (sin cambios de presupuesto registrados) |
| Fecha de fin | 2026-08-31 | 2026-08-31 | 0 días |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0.
La proyección excede el aprobado en 14.5%, por encima del umbral de 10% de la configuración, y sin solicitud de cambio que la respalde.

### Ejecución frente a avance
Ejecutado 58.2% · Hitos cumplidos 5 de 5 · Avance declarado 67%.
Lectura: el cronograma da por cumplidos todos los hitos (el plan soporta 100%), pero el avance declarado es 67% (33 puntos de diferencia), la fecha de fin (2026-08-31) pasó hace 48 días y el proyecto sigue ejecutando. Los hitos y el gasto no cuentan la misma historia.
Cuatro de los cinco hitos «cumplidos» no tienen evidencia en los documentos: Diseño funcional aprobado (2026-01-23), Ambiente de pruebas certificado (2026-03-19), Integración con el core cooperativo (2026-05-13) y Salida a producción (2026-08-31).

### Alertas
- **Proyección sobre el aprobado:** 20.616.543.260 frente a 18.000.000.000 (14.5%, umbral 10%).
- **Facturado por encima de lo aceptado (CT-892, Talento Solidario Ltda.):** facturado 1.002.986.926; aceptado 823.489.299; diferencia 179.497.627 COP. Son 4 entregables con monto declarado de 4.
- **Entregables del proveedor vencidos sin aceptación:** Licenciamiento del módulo (vencido hace 262 días, estado desconocido), Bolsa de horas de desarrollo (202 días, pendiente), Mesa de ayuda del primer trimestre (81 días, estado desconocido).
- **Entregable aceptado sin evidencia:** Parametrización de líneas de crédito (solo consta «recibido» en el informe).
- **Desalineación avance/hitos:** ver arriba.
- Comprometido: 41.2%, por debajo del umbral de 90%. No hay alerta de tope.
- La declaración del gerente (informe del 2026-10-13, estado rojo) tiene 5 días de antigüedad. No explica estas señales: hitos sin evidencia, avance contra plan, desviación de costo, entregables vencidos y facturado sobre aceptado.

### Sin dato
- Si el comprometido incluye o excluye lo ejecutado (ver arriba).
- Cualquier cifra de presupuesto con fuente distinta del informe de avance: comprometido, ejecutado y proyección son declaraciones del informe del 2026-10-13, sin soporte contable en la carpeta.
- Autoridad y fase del proyecto (`identity.authority`, `identity.phase`): no declaradas.
- Evidencia de recibo de los cuatro entregables del proveedor.

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`). También puedo detallar el CT-892 por entregable (`/criterio-portfolio:vendor-tracking`). No lo hago sin que lo pidas.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale del script `compute` y de los documentos citados; la verificación es de quien lo lea. No sé lo que se haya hablado fuera de esos documentos.
