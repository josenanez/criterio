# Corrida del 2026-10-18 · product-view

13 proyectos · 24 s · 65 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 8 |
| `commitment_overdue` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `milestone_overdue` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Producto recaudos con un solo proyecto (PRY-211): sin sección de producto. Señal: hito declarado cumplido sin evidencia. Reportados 5 proyectos sin producto y los 13 sin autoridad. No se sabe si esos 5 sirven a recaudos.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

**Vista por producto: `recaudos`.** Sale de las fichas en `estado/records` y del cálculo `portafolio.py compute`, con corte al 2026-10-18. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Producto `recaudos` al 2026-10-18

`recaudos` tiene un solo proyecto, PRY-211 *Cobranza digital*. La vista por producto no aporta nada con un solo proyecto, así que no armo la sección de producto. No hay suma entre proyectos, ni dependencias internas, ni fecha "más tardía" que comparar. Lo que sí dice la ficha de ese único proyecto:

- Fecha comprometida: 2027-03-23. Desviación contra la línea base original y la vigente: 0 días. Replanificaciones: 0.
- Señal abierta (1): el hito «Ambiente de pruebas certificado» (vencía 2026-10-03, hace 15 días) está declarado como cumplido (`met`) y no hay evidencia que lo sostenga. Las fuentes de la ficha son 0 de evidencia, 2 de declaración y 15 sin marcar.
- Avance declarado: 54,0 %. El plan sostiene entre 50 y 75 % (2 de 4 hitos cumplidos), y la brecha es de 0 puntos.
- Dinero (COP): aprobado 1.200.000.000; comprometido 621.239.148 (51,8 %); ejecutado 472.063.577 (39,3 %); proyección 1.250.123.404 (4,2 % sobre lo aprobado, bajo el umbral de 10 %). Las cuatro cifras vienen completas.
- Declarado por el gerente: amarillo, al 2026-10-11 (7 días). El agente no valida el color. La señal de arriba queda sin explicar en esa declaración.
- Sin declarar en la ficha: `identity.authority` e `identity.phase`. Nadie figura como autoridad del proyecto.
- Sin proveedores ni dependencias registradas.

## Proyectos sin producto declarado

Hay 5 de los 13 proyectos del portafolio sin `identity.product`. Tampoco hay autoridad declarada en ninguno de los 13.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | Operaciones |
| PRY-205 Prevención de lavado de activos | Bienestar social |
| PRY-208 Motor de crédito | Operaciones |
| PRY-209 Convenios de libranza con empresas | Crédito |
| PRY-210 Corresponsales rurales | Riesgo y Cumplimiento |

Consecuencia: nadie puede responder por el conjunto al que sirven, incluido `recaudos`. No puedo decir si alguno de estos cinco también construye `recaudos`, porque ninguna ficha lo declara. PRY-209 comparte nombre con el producto «crédito de libranza» (PRY-200), pero no lo afirmo sin la declaración del dueño.

PRY-199 tiene declarado el producto `PRD-299`, que parece un código y no un nombre como los demás. Lo señalo y no lo corrijo.

## Después

No hay dependencias internas que llevar al comité de producto. La decisión pendiente para el comité (2026-10-25) es que el dueño de cada uno de los 5 proyectos declare a qué producto sirve.

---
**Pie de rigor.** Cifras copiadas de `compute` (corte 2026-10-18). El hito «Ambiente de pruebas certificado» no tiene evidencia en la carpeta, así que no sé si se cumplió. No sé a qué producto sirven los 5 proyectos sin producto. Criterio produce borradores de trabajo, no decisiones: la verificación contra los documentos es suya.
