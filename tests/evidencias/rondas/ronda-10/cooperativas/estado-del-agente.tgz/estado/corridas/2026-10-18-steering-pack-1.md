# Corrida del 2026-10-18 · steering-pack

13 proyectos · 107 s · 65 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 8 |
| `commitment_overdue` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `milestone_overdue` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de comité de 6 decisiones y 7 escalamientos sobre 13 fichas. Dijo que no sabe: la autoridad de los gerentes (0 de 13), el comité de 12 de 13 proyectos, si el +84 días de CC-01 repite el atraso de la v2 de PRY-210, y que no existe comité anterior registrado.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

**Carga:** 13 fichas de `estado/records` (PRY-199 a PRY-211), recalculadas con `portafolio.py compute` al 2026-10-18. Criterios aplicados: raid-taxonomy y governance-artifacts. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta pedir aceptación de nuevo y no hubo preguntas pendientes.

# Comité de proyectos — 2026-10-25 (material preparado el 2026-10-18)
6 decisiones · 7 escalamientos sin decisión asociada · 10 proyectos con hallazgos (de 13)

> Todas las cifras derivadas salen de la salida de `compute`. Donde el script no da una cifra (por ejemplo, la suma de dos sobrefacturaciones) no se calcula aquí.
> Las fichas no registran la autoridad del gerente en ninguno de los 13 proyectos (`totals.no_authority` = 13). Por eso el campo «Quién decide» solo se llena cuando una ficha lo declara; el punto 1 trata justamente esto.

## Decisiones del comité anterior
No hay comité anterior registrado en el estado: no existe ninguna corrida previa de `steering-pack` ni acta de comité en las fichas. El ciclo no se puede cerrar y el comité arranca sobre el vacío. Este material se declara como primer paquete.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin decisiones previas registradas | n/d | n/d | n/d |

## Decisiones de hoy

### [1] ¿Se fija por escrito, antes del próximo comité, el monto y el tipo de cambio que cada gerente de proyecto puede decidir sin subir al comité?
**Proyecto:** los 13 · **Quién decide:** no determinable; ninguna ficha declara autoridad. Este es el primer punto del comité. · **Si no se decide hoy:** todo cambio y todo sobrecosto seguirá subiendo al comité, o se decidirá sin facultad. Hoy ya pasa: PRY-210 movió su línea base 84 días sin aprobación (punto 2).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. El comité fija un umbral único para todo el portafolio | Uniforme; no se ajusta a proyectos de distinto tamaño | Rápido, se puede aprobar hoy | Los aprobados van de 1200000000 COP (PRY-211) a 18000000000 COP (PRY-200, 201, 207, 209); un umbral único protege poco a los pequeños o frena a los grandes |
| B. Cada patrocinador lo fija en el acta de su proyecto | Ajustado a cada proyecto | Lento: 13 actas por revisar | Sin costo directo; riesgo de criterios dispares |
| C. No se define; todo sube al comité | Sin cambios | Cada cambio espera la sesión semanal | Sin costo directo; carga del comité |

**Recomendación:** A como regla provisional hasta que B esté hecho. Sin umbral, ninguno de los demás puntos de este paquete se puede dirigir a alguien con facultad comprobada.

### [2] PRY-210 — ¿Se aprueba CC-01 y se reconoce la línea base v2, o se rechaza y se vuelve a la v1?
**Proyecto:** PRY-210 Corresponsales rurales · **Quién decide:** el acta nombra como comité al Consejo de Administración; la ficha no declara autoridad. La solicitud dice «Pendiente de presentación al comité». · **Si no se decide hoy:** la «Salida a producción» seguirá declarada como cumplida (2026-09-09) sobre un cronograma v2 que nadie aprobó, y el atraso de 84 días (33.6 % sobre la línea base original) sigue sin dueño.

Hechos: CC-01, solicitada el 2026-10-11, es una ampliación de alcance con +84 días sobre la línea base vigente y 168000000 COP adicionales; decisión pendiente. El cronograma v2 (2026-10-17) ya mueve la salida de 2026-06-17 a 2026-09-09 sin motivo ni aprobación citados (`rebaseline_unauthorized`: 84 días movidos, 0 autorizados). No puedo determinar si el +84 de CC-01 es el mismo atraso ya aplicado en la v2 o uno adicional. La respuesta cambia el cálculo, y se debe aclarar antes de votar. Además hay un hallazgo de seguridad abierto desde 2026-10-17, sin doliente.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar la v2 como línea base nueva, con motivo y aprobador | Ampliado | Salida de 2026-09-09 queda como fecha vigente; la v1 se conserva | +168000000 COP; disponible real hoy 515250985 COP |
| B. Rechazar CC-01 y volver a la v1 | Original | Salida original 2026-06-17; el proyecto queda con atraso reconocido de 84 días | Sin costo adicional |
| C. Aplazar hasta que el gerente aclare si el +84 es el mismo | Sin cambio | El proyecto sigue sobre una línea base sin aprobar | Sin cambio |

**Recomendación:** C solo si la aclaración llega antes del comité; si no, A con el hallazgo de seguridad como condición de cierre. No se recomienda B: el hito figura como cumplido y volver a la v1 lo contradiría sin evidencia.

### [3] PRY-200 y PRY-209 — ¿Se retienen nuevos pagos a Talento Solidario Ltda. hasta que haya acta de aceptación de lo ya facturado?
**Proyecto:** PRY-200 (CT-892) y PRY-209 (CT-102) · **Quién decide:** no determinable (sin autoridad declarada). · **Si no se decide hoy:** se sigue pagando sobre entregables sin aceptación.

Hechos: en CT-892 se facturó 1002986926 COP contra 823489299 COP aceptados (diferencia 179497627 COP). En CT-102 se facturó 3038412141 COP contra 2090227453 COP aceptados (diferencia 948184688 COP). Los entregables atrasados de este proveedor: PRY-200, licenciamiento (262 días, estado desconocido), bolsa de horas (202 días, pendiente) y mesa de ayuda (81 días, estado desconocido); PRY-209, licenciamiento (242 días, pendiente) y parametrización (45 días, pendiente). En ambos contratos hay un entregable «aceptado» sin evidencia de aceptación en la carpeta. Los montos aceptados vienen de declaraciones en las fichas, no de actas de recibo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener nuevos pagos hasta tener actas de aceptación o nota crédito | Sin cambio | Puede frenar al proveedor y atrasar más lo pendiente | Protege el diferencial de 179497627 COP y 948184688 COP |
| B. Seguir pagando contra un plan de aceptación con fechas | Sin cambio | Se mantiene el ritmo | El diferencial queda expuesto hasta que se cumpla el plan |
| C. No intervenir | Sin cambio | Sin cambio | Exposición completa; no hay evidencia que respalde lo facturado de más |

**Recomendación:** A, con una revisión de las actas en una semana. Lo facturado por encima de lo aceptado no tiene sustento documentado, y retener es reversible, mientras que pagar no lo es.

### [4] PRY-200 y PRY-207 — ¿Se exige un plan de contención de costo antes de la próxima sesión, o se autoriza ampliación de presupuesto?
**Proyecto:** PRY-200 y PRY-207 · **Quién decide:** no determinable. · **Si no se decide hoy:** ambos siguen ejecutando sobre una proyección que supera el umbral del 10 %.

Hechos: PRY-200 proyecta 20616543260 COP contra 18000000000 COP aprobados (+14.5 %), ejecutado 58.2 %, declarado rojo. PRY-207 proyecta 23020726508 COP contra 18000000000 COP (+27.9 %), ejecutado 52.2 %, **declarado verde** el 2026-10-06, con hito de pruebas vencido hace 7 días, un compromiso vencido hace 16 días y un avance declarado de 62 % frente al 25-50 % que sustenta el plan.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Plan de contención por proyecto (recorte de alcance o de compromisos) antes del 2026-10-25 | Puede reducirse | Sin cambio inmediato | Busca volver bajo el 10 % sin nuevo presupuesto |
| B. Autorizar ampliación | Se mantiene | Se mantiene | +14.5 % y +27.9 % sobre lo aprobado; quién autoriza el monto está por definir (punto 1) |
| C. Congelar nuevos compromisos hasta decidir | Se detiene lo no comprometido | Posible atraso | Evita crecer el sobrecosto |

**Recomendación:** A para ambos, con C aplicado de inmediato en PRY-207. Sin plan no se puede dimensionar una ampliación, y el 27.9 % de PRY-207 no coincide con el verde que reporta.

### [5] ¿Nombra el comité un doliente único para dos riesgos compartidos que hoy no tienen ninguno?
**Proyecto:** el riesgo «Cambio normativo del supervisor» aparece en PRY-202, 203, 205, 206 y 210; el riesgo «Dependencia del proveedor del core cooperativo» aparece en PRY-200, 202, 207 y 209. · **Quién decide:** el comité. · **Si no se decide hoy:** nueve fichas siguen con riesgos sin doliente, probabilidad ni impacto declarados, y ningún gerente puede mitigarlos solo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un doliente por riesgo, a nivel de portafolio | Sin cambio | Responde antes de la próxima sesión | Sin costo directo |
| B. Cada gerente lo gestiona en su proyecto | Sin cambio | Esfuerzo duplicado | Sin costo directo; seguirá dividido |
| C. Se acepta el riesgo y se deja constancia | Sin cambio | Sin cambio | Exposición no cuantificada (probabilidad e impacto «no declarados») |

**Recomendación:** A. Ambos cruzan proyectos y por eso cumplen el criterio de escalamiento «afecta a otro proyecto». Las fichas no declaran quién es el proveedor del core ni quién lleva la relación normativa; eso lo debe aportar el comité.

### [6] PRY-201 — ¿Se formaliza el atraso con una solicitud de cambio, o se exige recuperar la fecha vigente?
**Proyecto:** PRY-201 Apertura de ahorro en línea · **Quién decide:** no determinable. · **Si no se decide hoy:** el proyecto sigue en verde con 91 % declarado, sin base que lo sustente.

Hechos: fecha de fin 2026-10-04 ya vencida; hito «Integración con el core cooperativo» vencido hace 14 días; los hitos «Diseño funcional aprobado» (334 días) y «Ambiente de pruebas certificado» (174 días) figuran cumplidos sin evidencia; cinco compromisos vencidos (de 3 a 21 días); tres reprogramados: Beatriz Cuéllar 6 veces, Paula Céspedes 5 veces, Diana Molina 4 veces; dos compromisos de Laura Vélez sin fecha, uno es enviar el «ajuste del presupuesto». El avance sustentado por el plan es 67-100 %. Presupuesto: comprometido 73.3 %, proyección +4.3 %. No hay ninguna solicitud de cambio registrada (`changes.total` = 0).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Solicitud de cambio formal con nueva fecha y línea base nueva (la actual se conserva) | Sin cambio | La fecha se mueve y se reconoce | A la espera del ajuste de presupuesto prometido, sin fecha; proyección actual +4.3 % |
| B. Mantener la fecha y exigir plan de recuperación | Posible recorte | Presión sobre una fecha ya vencida | Sin dato |
| C. Declarar el estado real (no verde) y diferir la decisión una semana | Sin cambio | Una semana más con la fecha vencida | Sin cambio |

**Recomendación:** A. La fecha de fin ya pasó, así que B pide recuperar un tiempo que no existe. Antes de la sesión, el gerente debe presentar la evidencia de los dos hitos sin respaldo; sin ella el comité aprobaría sobre declaraciones.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-204 | Declarado verde (2026-10-13); fin 2026-10-01 vencido; 5 de 5 hitos cumplidos sin evidencia; avance declarado 67 % frente a 100 % sustentado; Soluciones Solidarias, parametrización (CT-387), 83 días sin estado | Fin: 2026-10-01 | Actas de recibo de los 5 hitos y estado del entregable; confirmación del proveedor de la última entrega (riesgo sin doliente) |
| PRY-203 | Declarado rojo, 59 %; fecha de cierre del acta 2026-05-26 ya pasó; no hay cronograma ni solicitud de cambio | Fecha del acta: 2026-05-26 | Nueva fecha o cierre; hoy nadie ha pedido nada |
| PRY-205 | Declarado rojo, 31 %; fecha del acta 2026-07-14 ya pasó; sin cronograma; 12 días sin movimiento | Fecha del acta: 2026-07-14 | Igual que PRY-203; además, razón del silencio |
| PRY-202 | Core cooperativo, amarillo, 67 % frente a 100 % sustentado; fin 2026-08-10 ya pasó; 3 hitos cumplidos sin evidencia; prueba de carga que no alcanzó el umbral y se repite | Fin: 2026-08-10 | Evidencia de los hitos; fecha nueva. Es el core del que dependen otros proyectos (punto 5) |
| PRY-208 | Motor de crédito, amarillo, 48 % frente a 75-100 % sustentado; fin 2026-11-22 | n/d | Plan de recuperación o replanificación antes del fin; compromiso de Camilo Beltrán sin fecha |
| PRY-206 | Verde declarado el 2026-10-01 (17 días de antigüedad); compromiso de Natalia Ospina vencido hace 6 días | 2026-10-12 | Entrega del punto 35 o nueva fecha |
| PRY-209 | Amarillo; licenciamiento de Red Rural de Pagos (CT-661) vencido hace 176 días y bolsa de horas hace 12, ambos sin estado; sin factura de CT-661 en la carpeta | 2026-04-25 | Estado de los dos entregables |

## Para conocimiento
- PRY-199 Cambio de mobiliario: sin alertas; verde, 20 %. Sin factura de CT-199 en la carpeta.
- PRY-200 Libranza digital: ver puntos 3 y 4; rojo; 4 hitos cumplidos sin evidencia.
- PRY-201 Ahorro en línea: ver punto 6.
- PRY-202 Core cooperativo: ver escalamientos y punto 5.
- PRY-203 Aportes sociales: ver escalamientos; rojo.
- PRY-204 Tarjeta débito: ver escalamientos.
- PRY-205 Prevención de lavado de activos: ver escalamientos; rojo.
- PRY-206 Pagos con QR: ver escalamientos; presupuesto proyectado -3.6 %.
- PRY-207 Microcrédito rural: ver punto 4.
- PRY-208 Motor de crédito: ver escalamientos.
- PRY-209 Convenios de libranza: ver punto 3 y escalamientos.
- PRY-210 Corresponsales rurales: ver punto 2.
- PRY-211 Cobranza digital: un hito («Ambiente de pruebas certificado», 2026-10-03) cumplido sin evidencia; el resto sin alertas.

## Anexo

**Declarado en verde y contradicho** (`green_contradicted` = 4): PRY-201, PRY-204, PRY-206, PRY-207.

**Contradicciones entre documentos (campo `conflicts`):** vacío en los 13 proyectos. Hay una pregunta abierta que el script no resuelve: PRY-201 tiene vencido el hito «Integración con el core cooperativo», mientras PRY-202, 204, 200, 209 y 210 declaran cumplido un hito del mismo nombre, en varios casos sin evidencia. Puede ser el mismo trabajo o no; no se afirma.

**Vacíos de información:**
- Autoridad del gerente: sin dato en 13 de 13. Fase del proyecto: sin dato en los 13.
- Producto sin declarar: PRY-202, 205, 208, 209, 210.
- Campos con más de 12 meses de antigüedad (umbral `stale_field_months` = 12): PRY-201 (16 meses), PRY-202 (14), PRY-203 (13), PRY-204 (13), PRY-205 (16), PRY-210 (13).
- Riesgos sin doliente, probabilidad ni impacto declarados: en todas las fichas que los listan.
- Fuentes clasificadas como evidencia por el script: 0 en los 13 proyectos; lo que se cita proviene de declaraciones o de documentos sin marcar.
- PRY-201 tiene dos fichas (la de PMO y la del gerente) con los mismos campos desactualizados.
- PRY-203 y PRY-205: la «fecha de fin» es la del acta, no la de un cronograma.
- Factura sin carpeta: PRY-199 (CT-199) y PRY-209 (CT-661).

**Cifras de la cartera (`totals`):** 13 proyectos, 10 con alertas, 65 alertas en total, 8 productos, 0 proyectos sin línea base, 0 problemas de ficha.

**Qué no sé:** si el +84 días de CC-01 es el mismo atraso de la v2; quién es el comité en 12 de 13 proyectos (solo se leyó la ficha de PRY-210); quién es el proveedor del core o el dueño de la relación con el supervisor.

---
Versión del agente criterio-portfolio 0.5.0 · términos v1.1 · fichas aplicadas: 13, a 2026-10-18 · campos inciertos: autoridad, fase y comité (según arriba), más montos aceptados que provienen de declaraciones · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
