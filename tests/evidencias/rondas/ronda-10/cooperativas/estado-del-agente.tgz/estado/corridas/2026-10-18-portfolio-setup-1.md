# Corrida del 2026-10-18 · portfolio-setup

3 proyectos · 75 documentos, 51 releídos y 24 sin cambio · 120 s · 22 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 6 |
| `commitment_overdue` | 5 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `progress_vs_plan` | 2 |
| `milestone_overdue` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (sesión sin interfaz, respuestas por defecto); primer resultado sobre 3 proyectos (PRY-201, PRY-202, PRY-208) en una sola conversación, sin cronómetro exacto; compute levantó 22 señales: PRY-201 verde contradicho, hitos cerrados sin acta en los tres, brechas de avance en PRY-202 y PRY-208

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Cooperativa

**Miré:** 75 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: md 37, pdf 15, csv 10, docx 9, xlsx 2, json 1, txt 1 · más reciente: 2026-10-18
**Eres:** PMO del portafolio (propuesta por defecto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; el próximo, tomado como el 2026-10-25, se informa el 2026-10-23
**En:** presentación
**Términos:** aceptados para la versión 1.1 (familia 0.5.0) por José Francisco Ñáñez el 2026-10-18 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 del comprobante (md) 9c54c0c51760b166…

Respuestas por defecto que tomé sin preguntar: rol PMO, comité semanal (los archivos se llaman `comite-semanal`), próxima fecha de comité 2026-10-25 (supuesto mío, sin confirmar), presentación como formato, estado en `estado/` e informes en `reportes/`, junto a la carpeta de documentos. Preguntas hechas: 0.

### Probé con tres proyectos

Los de documentación más reciente: PRY-201, PRY-202 y PRY-208 (los tres con documentos del 2026-10-18). Fichas en `estado/records/` y selladas.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Apertura de ahorro en línea | 13 | Patrocinadora Elena Duarte y gerente Natalia Ospina (acta 2025-06-01). Presupuesto 18.000.000.000 COP; proyección 18.779.394.290 (4,3 % sobre lo aprobado). Declara **verde, 91 %** (informe 2026-10-17). Cierre 2026-10-04. Tiene ficha del gerente (`ficha-pm.json`), guardada aparte. | Autoridad del gerente y etapa. Ningún acta prueba los hitos cerrados. |
| PRY-202 Core cooperativo | 5 | Patrocinador Mauricio Pérez y gerente Diana Molina. Presupuesto 6.800.000.000 COP; proyección 7.054.849.455 (3,7 % sobre lo aprobado). Declara **amarillo, 67 %** (informe 2026-10-14). Cierre 2026-08-10. | Producto (el acta dice «No aplica»), autoridad y etapa. Acta de recibo solo del primer hito. |
| PRY-208 Motor de crédito | 6 | Patrocinador Javier Hoyos y gerente Felipe Arango. Presupuesto 6.800.000.000 COP; proyección 6.843.787.816 (0,6 % sobre lo aprobado). Declara **amarillo, 48 %** (informe 2026-10-18). Cierre 2026-11-22. | Producto («No aplica»), autoridad y etapa. Acta de recibo de 2 de los 3 hitos cerrados. |

### Hallazgos (levantados por `compute`, con el nombre de portfolio-health)

22 señales en los tres proyectos.

**PRY-201** — 14 señales:
- **El verde no se sostiene** (`declared_vs_evidence`): declara verde con el hito «Integración con el core cooperativo» vencido hace 14 días (`milestone_overdue`, plan del 2026-10-04), 5 compromisos vencidos y 3 compromisos reprogramados varias veces.
- **Hitos cerrados sin acta** (`milestone_met_without_evidence`): «Diseño funcional aprobado» (2025-11-18) y «Ambiente de pruebas certificado» (2026-04-27). El cronograma los da por cerrados y no hay documento que lo pruebe. Las dos actas de recibo de la carpeta son de compromisos de reunión, no de estos hitos.
- **Compromisos vencidos** (`commitment_overdue`): Andrés Lozano, «Revisar el anexo 3» (14 días); Ricardo Salas, «Actualizar la matriz 6» (3 días); Andrés Lozano, «Revisar el anexo 11» (21 días; dijo el 09-27 que ya lo entregó y no hay acta); Natalia Ospina, «Validar el ambiente 20» (11 días); Sandra Gil, «Aprobar el diseño 21» (4 días).
- **Reprogramados** (`commitment_rescheduled`): Beatriz Cuéllar, «Enviar el documento 1», 6 veces (de 2026-09-22 a 2026-12-20); Paula Céspedes, «Cerrar la prueba 2», 5 veces (de 2026-10-02 a 2026-12-02); Diana Molina, «Validar el ambiente 4», 4 veces (de 2026-09-29 a 2026-11-22).
- **Sin fecha** (`commitment_undated`): Laura Vélez, «Confirmar la fecha 15» y «Enviar el ajuste del presupuesto» (en las notas del 10-18 dijo «la otra semana»).

**PRY-202** — 5 señales:
- **Avance contra plan** (`progress_vs_plan`): declara 67 % y sus 4 hitos están cerrados (el plan sostiene 100 %), una brecha de 33 puntos. Declara amarillo con el cierre del 2026-08-10 ya pasado.
- **Hitos cerrados sin acta**: «Ambiente de pruebas certificado», «Integración con el core cooperativo» y «Piloto con asociados». Solo «Diseño funcional aprobado» tiene acta, firmada el 2026-10-06, 10 meses después de su fecha de plan.
- **Sin fecha**: Rubén Cárdenas, «Entregar el punto 6».

**PRY-208** — 3 señales:
- **Avance contra plan**: declara 48 % con 3 de 4 hitos cerrados (el plan sostiene entre 75 % y 100 %), una brecha de 27 puntos.
- **Hito cerrado sin acta**: «Diseño funcional aprobado» (2026-03-15).
- **Sin fecha**: Camilo Beltrán, «Entregar el punto 38».

Sin autoridad documentada en ninguno de los tres (`no_authority`: 3).

### El portafolio completo
10 proyectos más (PRY-199, PRY-200 y PRY-203 a PRY-207, PRY-209 a PRY-211), unos 50 documentos por leer; dos lotes, uno tras otro, en esta conversación. Estimo del orden de 20 a 30 minutos, tomando como referencia lo que costaron estos tres; es una estimación, no una medida.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- **Ninguna acta dice hasta dónde llega la autoridad del gerente.** Los tres proyectos quedan sin ese dato, y sin él no se puede saber si un cambio excede su facultad.
- **Los alcances son placeholders.** Las actas dicen «Componente 1, 2 y 3» sin describirlos, así que no hay contra qué contrastar un cambio de alcance.
- **Los hitos se cierran en el cronograma y no en un acta.** En los tres proyectos hay hitos «cerrado» sin acta de recibo; en PRY-202 el único recibo llegó 10 meses después de la fecha del plan.
- **Las actas de constitución tienen entre 10 y 16 meses.** Patrocinador, gerente, alcance y presupuesto no tienen confirmación posterior en PRY-201 y PRY-202 (PRY-208 está al día).
- **PRY-202 y PRY-208 dicen «Producto asociado: No aplica»**, así que no entran a la vista por producto.
- **Las notas de la reunión del 2026-10-18 de PRY-201 están sueltas en la raíz del proyecto**, fuera de `30-reuniones/`, y sin formato de acta. De ahí salieron un compromiso reprogramado y un riesgo que nadie había registrado (el proveedor podría no llegar con el equipo completo).
- **PRY-202 reporta ante el «Comité de Educación»**, que no parece corresponder a un proyecto de core cooperativo. Conviene confirmar que el nombre del comité es correcto.
