## Diagnóstico · PRY-200 Crédito de libranza digital · 2026-10-18

**Leí:** 6 documentos de la carpeta del proyecto · 2025-11-20 a 2026-10-13 · formatos: md (2), docx (1), csv (1), pdf (2). Además busqué el código, el nombre y el contrato CT-892 en los otros 121 documentos del espacio (127 en total): ninguno menciona a PRY-200.
**No pude leer:** nada quedó sin leer. Los dos PDF (factura y acta de recibo) son de una página y los leí como imagen.

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 13 · **Contradicho:** 4

- Sostenido (4): estado rojo; presupuesto aprobado de 18.000.000.000 COP; Piloto con asociados cerrado (acta de recibo); factura FV-1892 radicada por 1.002.986.926 COP.
- Contradicho (4): avance de 67%; Piloto en su fecha vigente 2026-07-07; factura contra lo aceptado; "ninguna dependencia declarada".
- Sin sustento (13): comprometido, ejecutado y proyección (3); los hitos Diseño funcional, Ambiente de pruebas, Integración con el core y Salida a producción como cerrados (4); Parametrización "recibido" (1); Licenciamiento y Mesa de ayuda "en curso" (2); Bolsa de horas "pendiente" (1); los dos riesgos del informe (2).

Desde esta carpeta se puede afirmar que el proyecto se declara en rojo y que su propia proyección supera el presupuesto aprobado en 14,5%. No se puede afirmar nada del avance real: de los cinco hitos que el cronograma da por cerrados, solo uno tiene un documento que lo respalde, y ese documento es posterior en más de tres meses a la fecha del hito. Lo único que muestra pagos es una factura que supera lo aceptado.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Javier Hoyos | 00-gobierno/2025-11-20-acta-constitucion.md |
| Gerente | Gustavo Neira | 00-gobierno/2025-11-20-acta-constitucion.md |
| Autoridad declarada | No está en ningún documento | — |
| Comité | Consejo de Administración (aprobó el presupuesto el 2025-11-20); no hay actas de comité en la carpeta | 00-gobierno/2025-11-20-acta-constitucion.md |

El acta describe el alcance como "Componente 1, 2 y 3" y la exclusión como "Lo que otro proyecto cubre", sin nombrar cuál. Sin autoridad declarada para el gerente, no hay desviación aprobada: hay fechas que alguien escribió.

### Contra el plan
Línea base original y vigente: la misma, versión 1, aprobada 2025-11-20, cierre 2026-08-31 (cronograma-v1.csv). Replanificaciones: 0. Cambios registrados: 0. Desviación en tiempo contra la original y contra la vigente: 0 días, porque el cronograma nunca se movió. No es medición de cumplimiento: el cierre del 2026-08-31 ya pasó y el informe de 2026-10-13 declara 67%, con lo cual el proyecto está atrasado sin que ningún documento lo reconozca como cambio.

El cronograma está fechado 2025-11-20 y ya trae los cinco hitos en estado "cerrado". Un archivo de la aprobación no puede registrar cierres de 2026: fue editado después sin dejar otra versión.

Avance declarado 67% contra 5 de 5 hitos cerrados que muestra el cronograma: 33 puntos de diferencia (`compute`).

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-01-23 | 268 | Acta de aprobación del diseño |
| Ambiente de pruebas certificado | 2026-03-19 | 213 | Certificado o acta del ambiente |
| Integración con el core cooperativo | 2026-05-13 | 158 | Acta de pruebas de integración |
| Salida a producción | 2026-08-31 | 48 | Acta de paso a producción |

Piloto con asociados: cronograma 2026-07-07; acta de recibo del 2026-10-10 (firmada por el gerente, sin criterio de aceptación ni firma de nadie más). Tiene evidencia, pero llegó en una fecha distinta a la que el cronograma muestra, y tres días antes del informe.

Con "Salida a producción" cerrado al 2026-08-31, el criterio de éxito del acta ("en producción y medido") debería ser comprobable; en la carpeta no hay nada de producción ni de medición.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 18.000.000.000 | 7.409.726.138 (41,2%) | 10.475.680.794 (58,2%) | 20.616.543.260 (+14,5%) | 10.590.273.862 |

Cifras de `compute`. Las tres últimas columnas vienen solo del informe del gerente; ningún libro, extracto ni presupuesto las respalda. Observación: el ejecutado es mayor que el comprometido, lo que no cuadra con cómo se mide el compromiso; el "disponible real" del script se calcula contra lo comprometido y por eso no es un dato confiable aquí. La desviación de costo (14,5%) supera el umbral de 10% y es la proyección del propio gerente.

**Proveedor Talento Solidario Ltda. · CT-892** (cuatro entregables de 823.489.299 COP cada uno; la condición de pago es acta de recibo firmada por el gerente):

| Entregable | Fecha | Estado en el contrato | Evidencia |
|---|---|---|---|
| Licenciamiento del módulo | 2026-01-29 | en curso (262 días vencido) | ninguna |
| Bolsa de horas de desarrollo | 2026-03-30 | pendiente (202 días vencido) | ninguna |
| Parametrización de líneas de crédito | 2026-05-30 | recibido | no hay acta de recibo |
| Mesa de ayuda del primer trimestre | 2026-07-29 | en curso (81 días vencido) | ninguna |

Facturado: 1.002.986.926 COP (FV-1892, 2026-09-25, radicada en cuentas por pagar). Aceptado con soporte: 823.489.299 COP como máximo, y ni siquiera ese tiene acta. Diferencia facturada sobre lo aceptado: 179.497.627 COP. La única acta de recibo de la carpeta es la del Piloto, que no es un entregable del contrato. La factura dice "Entregables del contrato CT-892" sin decir cuáles.

### Lo que se dijo y nadie registró
No hay minutas ni transcripciones de este proyecto, así que no hay nada que contrastar contra un registro. Lo único dicho: el informe cuenta que "se acordó con arquitectura cómo se revisan los requisitos no funcionales", sin responsable, fecha ni minuta. Los dos riesgos del informe (concentración del conocimiento en una persona; dependencia del proveedor del core) no tienen probabilidad, impacto, dueño ni fecha, y no hay registro RAID. No hay compromisos con fecha.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 67% | Informe 2026-10-13: 67% | Cronograma: 5 de 5 hitos cerrados (100%) |
| Piloto en su fecha vigente | Cronograma: 2026-07-07, cerrado | Acta de recibo: 2026-10-10 |
| Factura por entregables del CT-892 | Factura FV-1892: 1.002.986.926 COP | Contrato: 823.489.299 COP por entregable, contra acta de recibo; hay a lo sumo uno "recibido", sin acta |
| Sin dependencias | Acta de constitución: "Ninguna declarada" | Informe: riesgo de dependencia del proveedor del core cooperativo |

### Sin sustento
- Comprometido 7.409.726.138, ejecutado 10.475.680.794 y proyección 20.616.543.260: solo están en el informe del gerente.
- Cuatro hitos "cerrados" (Diseño funcional, Ambiente de pruebas, Integración con el core, Salida a producción): solo los afirma el cronograma, sin acta ni certificado.
- Parametrización de líneas de crédito "recibido", Licenciamiento y Mesa de ayuda "en curso", Bolsa de horas "pendiente": estados escritos en el contrato firmado el 2025-11-21, es decir, anteriores a cualquier ejecución. Un contrato firmado ese día no puede saber que algo ya fue recibido.
- Los dos riesgos abiertos del informe.
- El estado rojo no tiene serie: hay un solo informe (2026-10-13), así que no se puede decir si el rojo es nuevo o viejo.

### Lo que esta carpeta no permite saber
- Cuánto se avanzó de verdad: faltan actas de los cuatro hitos restantes; sin ellas no se sabe si el 67% o el 100% es el dato correcto.
- Si el proyecto está en producción: no hay documento de salida ni de medición; el criterio de éxito no se puede evaluar.
- Quién autoriza al gerente a mover fechas o presupuesto: no hay autoridad declarada ni control de cambios, y el cierre pasó sin replanificación.
- Cuánto se debe al proveedor: faltan las actas de recibo de los entregables; la factura puede estar pagando 179.497.627 COP sobre lo aceptado, o entregables sin recibir.
- Cuánta plata se gastó: no hay ningún soporte contable de comprometido ni de ejecutado, y las dos cifras no son coherentes entre sí.
- Qué decidió el Consejo de Administración después del 2025-11-20: no hay actas de comité.
- Cuál es la fase del proyecto: ningún documento la dice.

### Rigor
Los documentos son 6; el diagnóstico no asume nada del informe de avance, que escribe el gerente evaluado. Las cifras derivadas salen de `compute` (as_of 2026-10-18); los días de vencimiento y los porcentajes se copiaron de su salida. La suma de afirmaciones (21) está desglosada arriba para que se verifique. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

**Siguiente paso posible:** preparar el punto de comité con la lista de lo que falta, y llevar las cuatro contradicciones al gerente como preguntas, una por una.
