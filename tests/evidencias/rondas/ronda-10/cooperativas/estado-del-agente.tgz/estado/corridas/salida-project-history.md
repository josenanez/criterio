## Historia · PRY-210 Corresponsales rurales · 2025-09-30 a 2026-10-17

**Leí:** 7 documentos entre 2025-09-30 y 2026-10-17 (acta de constitución, cronograma v1, cronograma v2, acta de recibo, solicitud de cambio CC-01, comité del 2026-10-12, informe de avance). Términos vigentes (v1.1, José Francisco Ñáñez, 2026-10-18); no hizo falta registrarlos de nuevo.
**Trimestres sin un solo documento:** 2025-T4, 2026-T1, 2026-T2 y 2026-T3. Entre el acta del 2025-09-30 y el 2026-10-08 no hay nada escrito.

### En una línea
El proyecto se aprobó el 2025-09-30 con cierre el 2026-06-17 y presupuesto de 2.400.000.000 COP, y no dejó documentos hasta octubre de 2026. Entonces aparecen en nueve días un acta de recibo (2026-10-08), una solicitud de cambio pendiente (2026-10-11), un comité (2026-10-12) y, el 2026-10-17, un cronograma v2 que mueve el cierre al 2026-09-09 —una fecha ya pasada— junto con un informe en amarillo con 69 % de avance. El atraso de 84 días se registró después de que la fecha nueva también venció, sin motivo ni aprobación escritos.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 84 días (33.6 %) | No se puede calcular: el script no da la cifra y solo hay un estado declarado fechado (2026-10-17). Hito más antiguo cerrado sin evidencia: 2025-11-29 | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-09-30 | `00-gobierno/2025-09-30-acta-constitucion.md` | Aprobación: patrocinadora María Restrepo, gerente Liliana Torres, comité Consejo de Administración. Inicio 2025-10-10, cierre 2026-06-17, 2.400.000.000 COP. El alcance dice "Componente 1/2/3" y el objetivo repite el nombre del proyecto. |
| 2025-09-30 | `10-plan/2025-09-30-cronograma-v1.csv` | Línea base original: 5 hitos, todos con estado "cerrado". Su fecha de cierre es posterior a la del documento. |
| 2026-10-08 | `20-seguimiento/2026-10-08-acta-recibo-ambiente-de-pruebas-certificado.pdf` | Única evidencia de recibo: "Ambiente de pruebas certificado", recibido por Liliana Torres. El hito vencía el 2026-01-18. |
| 2026-10-11 | `20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md` | Pide ampliación de alcance: +84 días "sobre la línea base vigente" y 168.000.000 COP adicionales. Autorización: "Pendiente de presentación al comité". |
| 2026-10-12 | `30-reuniones/2026-10-12-comite-semanal.md` | Comité con Liliana Torres y María Restrepo. Temas: "Avance" y "Compromisos". No menciona CC-01. Un compromiso: Gustavo Neira, "Entregar el punto 28", para 2026-10-26. |
| 2026-10-17 | `10-plan/2026-10-17-cronograma-v2.csv` | "Salida a producción" pasa de 2026-06-17 a 2026-09-09. Todos los hitos siguen "cerrado". |
| 2026-10-17 | `20-seguimiento/2026-10-17-informe-avance.md` | Amarillo, 69 %. Hallazgo de seguridad en la revisión de arquitectura. Riesgos: aprobación del reglamento por el Consejo y cambio normativo del supervisor. Proyección 2.395.222.885 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-17 (fecha del archivo v2) | 2026-09-09 (antes 2026-06-17; +84 días) | **Sin motivo documentado.** CC-01 pide +84 días por "ampliación de alcance", pero no dice que sea el motivo de v2. | **Ninguno.** CC-01 sigue pendiente; el cálculo registra 84 días movidos y 0 autorizados. |

Las dos fechas coinciden en 84 días, pero CC-01 los pide "sobre la línea base vigente", y v2 ya los había movido. No sé si es el mismo cambio contado dos veces o dos pedidos distintos; ningún documento lo aclara.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos. | — |

La ficha no tiene producto, autoridad ni fase. El acta dice "Producto asociado: No aplica".

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió: solo hay un compromiso, de Gustavo Neira ("Entregar el punto 28"), con fecha 2026-10-26 y sin vencer. | 1 | 2026-10-26 |

Gustavo Neira no figura entre los asistentes del 2026-10-12, y "el punto 28" no se identifica en ningún documento.

### Desde cuándo lo declarado no se sostiene
- **Desde 2025-11-29**, primer hito sin evidencia: "Diseño funcional aprobado". Siguen "Integración con el core cooperativo" (2026-03-09), "Piloto con asociados" (2026-04-28) y "Salida a producción" (2026-09-09). Los cuatro figuran "cerrado" sin acta de recibo.
- Solo "Ambiente de pruebas certificado" tiene acta, fechada 2026-10-08, y su hito vencía el 2026-01-18.
- Lo que se siguió reportando: el cronograma v2 marca los 5 hitos como cerrados (la señal de avance contra plan da 100 %), y el informe del 2026-10-17 declara 69 %, amarillo. El hueco es de 31 puntos.
- Con la información disponible no puedo decir si es un deslizamiento gradual, porque no hay un solo documento entre 2025-09-30 y 2026-10-08.

### Lecciones ancladas a un hecho
- **Hecho:** el cronograma v2 (2026-10-17) mueve el cierre a 2026-09-09, 39 días antes de su propia fecha. **Efecto:** la replanificación no pudo servir para gestionar el atraso, solo para registrarlo después.
- **Hecho:** CC-01 (2026-10-11) está "pendiente de presentación al comité" y el comité del 2026-10-12 no lo trata. **Efecto:** el atraso de 84 días quedó con 0 días autorizados.
- **Hecho:** el acta de constitución (2025-09-30) define el alcance como "Componente 1/2/3". **Efecto:** no hay alcance contra el cual medir la "ampliación" que pide CC-01.

### Lo que no sé
- Qué pasó entre 2025-09-30 y 2026-10-08; si existe documentación fuera de la carpeta, no la vi.
- Cuántos meses lleva el proyecto declarando sin sustento. Falta una serie de estados declarados.
- El motivo de la replanificación y su relación con CC-01.

No atribuyo intención: el que el atraso no se documentara a tiempo no dice que alguien lo ocultara. Eso se conversa con las personas, con estos datos delante.

Puedo llevar esta historia al comité o al cierre del proyecto si hay una decisión que salga de ella. Aquí el punto de entrada sería CC-01.

**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada dato sale de los 7 documentos citados y las cifras vienen de `portafolio.py compute` (2026-10-18). La verificación es de quien lo lee.
