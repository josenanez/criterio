## Carpeta al 2026-10-18

**Documentos:** 75 · **Sin cambio:** 75 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
17 citas, todas del proyecto PRY-201.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | pm_record.identity.code | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.name | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.business_area | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.product | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.sponsor | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.manager | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.identity.committee | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.declared.status | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-201 | pm_record.declared.progress_pct | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-201 | pm_record.plan.start_date | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.plan.end_date | 10-plan/2025-06-01-cronograma-v1.csv |
| PRY-201 | pm_record.plan.scope_summary | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.plan.exclusions | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.money.approved | 00-gobierno/2025-06-01-acta-constitucion.md |
| PRY-201 | pm_record.money.committed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-201 | pm_record.money.executed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-201 | pm_record.money.projection | 20-seguimiento/2026-10-17-informe-avance.md |

Ninguno de los 75 documentos cambió, se renombró o se borró, y aun así estas citas no resuelven: la ficha de PRY-201 apunta a rutas que no están en el índice. Mientras no se corrija, el informe sigue mostrando esos datos como sustentados sin estarlo. No se sabe por qué no resuelven (ruta escrita distinta, documento fuera de la carpeta); eso hay que mirarlo en la ficha.

### Formatos que no se pudieron leer
Ninguno.

---
Nada que releer, así que no hay barrido que ofrecer. Lo único pendiente es revisar las citas de PRY-201.
