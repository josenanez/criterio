## 2026-10-18

**Revisé:** 75 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada cruzó un umbral porque nada se releyó. Una anomalía del índice, no del proyecto: `index` reporta 17 campos de PRY-201 como `source_missing` (código, nombre, área, producto, patrocinador, gerente, comité, estado declarado, avance, fechas, alcance, exclusiones y las cuatro cifras de dinero). Los archivos citados existen en la carpeta (`00-gobierno/2025-06-01-acta-constitucion.md`, `10-plan/2025-06-01-cronograma-v1.csv`, `20-seguimiento/2026-10-17-informe-avance.md`). Lo más probable es que las citas de `pm_record` estén escritas relativas a la carpeta del proyecto y el índice las busque desde la raíz de documentos. Es una hipótesis: no la verifiqué ni corregí la ficha.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión. Las dejo hechas una sola vez, sobre PRY-201 (dato actual y fecha de la fuente):

1. **Hito «Integración con el core cooperativo»:** figura `pending` con fecha 2026-10-04 (cronograma v1, 2025-06-01) y ya pasaron 14 días. ¿Cuál es la fecha vigente, o ya se cumplió y con qué evidencia?
2. **Estado declarado «verde», avance 91%** (informe del 2026-10-17): ¿se sostiene con el hito anterior vencido?
3. **Autoridad (`identity.authority`):** no encontrada. ¿Quién aprueba cambios de este proyecto?
4. **Fase (`identity.phase`):** no encontrada. ¿En qué fase está?
5. **Riesgo «el proveedor no ha confirmado la fecha de la última entrega»** (informe del 2026-10-17): sin dueño, probabilidad, impacto ni fecha. ¿Quién lo lleva?

Además, para el comité: Andrés Lozano y Gustavo Neira dicen que entregaron y no hay acta de recibo (anexo 11 y documento 17); Beatriz Cuéllar lleva 6 reprogramaciones del documento 1 (22-sep → 20-dic).

**Vuelvo el 2026-10-19.**
