*Informe generado desde la ficha `estado/records/PRY-201.json`, recalculada con `portafolio.py compute` el 2026-10-18. Fecha de corte de la declaración: 2026-10-17.*

## PRY-201 · Apertura de ahorro en línea — estado al 2026-10-18

**Declara el gerente:** verde · 91% · al 2026-10-17 (Natalia Ospina, informe de avance; 1 día de antigüedad, no está vencida)
**Sustento documental:** contradicho. Ningún dato del proyecto viene marcado como evidencia (0 de 34 fuentes); 4 son declaración y 30 no están marcadas. Dos hitos figuran «cumplidos» sin evidencia.
**Lo que el semáforo no explica:** `milestone_overdue`, `milestone_met_without_evidence`, `commitment_overdue`, `commitment_rescheduled`
**Último documento:** 2026-10-18 (notas de reunión; 0 días de silencio) · **Última reunión:** 2026-10-18 según el nombre del archivo de notas; la última acta de comité es del 2026-10-11

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-04 | 2026-10-04 | 0 días (sin replanificaciones), pero el cierre ya pasó hace 14 días y el hito final sigue pendiente |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | Proyección 18.779.394.290 = 4,3 % sobre lo aprobado (umbral 10 %: no lo cruza) |

Replanificaciones: 0. Sin solicitudes de cambio registradas.
Avance: declara 91 %; el plan sostiene entre 67 % y 100 % (2 de 3 hitos cumplidos), brecha 0 puntos. Pero esos 2 hitos no tienen evidencia.
Dinero: comprometido 13.196.888.150 (73,3 %), ejecutado 6.420.513.826 (35,7 %), disponible real 4.803.111.850.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2025-11-18 | 2025-11-18 | cumplido (declarado) | Ninguna, 334 días |
| Ambiente de pruebas certificado | 2026-04-27 | 2026-04-27 | cumplido (declarado) | Ninguna, 174 días |
| Integración con el core cooperativo | 2026-10-04 | 2026-10-04 | pendiente, vencido 14 días | Ninguna |

### Dónde no coincide
- **Informe de avance (2026-10-17):** verde y 91 %. **Cronograma v1 (2025-06-01) y comités del 2026-09-06 al 2026-10-11:** el hito de cierre venció el 2026-10-04 sin cumplirse, hay 5 compromisos vencidos y 3 reprogramados varias veces. El verde no cubre nada de eso; es la alerta `declared_vs_evidence`.
- El informe no menciona el hito vencido ni los compromisos. Su sección «Lo que pasó» habla de requisitos no funcionales y de un ajuste al reglamento pedido por el Consejo, que no figura en ningún riesgo ni solicitud de cambio.

### Abierto
**Riesgos e incidencias sin movimiento:** ninguno. Los 3 riesgos se movieron el 2026-10-17 y el 2026-10-18, pero los 3 carecen de probabilidad, impacto, dueño y fecha. Uno solo salió de una reunión («el proveedor podría no llegar con el equipo completo», notas del 2026-10-18) y nadie lo registró.
**Compromisos vencidos:**
- Andrés Lozano, «Revisar el anexo 11», vencido el 2026-09-27 (21 días)
- Andrés Lozano, «Revisar el anexo 3», vencido el 2026-10-04 (14 días)
- Natalia Ospina, «Validar el ambiente 20», vencido el 2026-10-07 (11 días)
- Sandra Gil, «Aprobar el diseño 21», vencido el 2026-10-14 (4 días)
- Ricardo Salas, «Actualizar la matriz 6», vencido el 2026-10-15 (3 días)

**Compromisos reprogramados:**
- Beatriz Cuéllar, «Enviar el documento 1»: 6 veces, de 2026-09-22 a 2026-12-20
- Paula Céspedes, «Cerrar la prueba 2»: 5 veces, de 2026-10-02 a 2026-12-02
- Diana Molina, «Validar el ambiente 4»: 4 veces, de 2026-09-29 a 2026-11-22

**Sin fecha:** Laura Vélez, «Confirmar la fecha 15» (comité del 2026-09-27) y «Enviar el ajuste del presupuesto» («la otra semana», notas del 2026-10-18).
**Dependencias sin confirmar:** la ficha no registra ninguna dependencia entre proyectos. El riesgo «dependencia del proveedor del core cooperativo» está como riesgo, no como dependencia.

### Sin dato
- Autoridad de aprobación y fase del proyecto: no encontradas.
- Evidencia de cumplimiento de los dos hitos «cumplidos».
- Datos de proveedor: la ficha no trae ninguno, aunque existen actas de recibo (2026-09-20 y 2026-10-04) en `20-seguimiento`. Este informe no las cruza; eso corresponde a `/vendor-tracking`.
- Campos de identidad y plan con 16 meses de antigüedad (acta del 2025-06-01), por encima del umbral de 12 meses. Entre ellos están el área de negocio, que dice «Cartera y cobranza» para un producto de ahorro, y el presupuesto aprobado. Confirmar con el gerente.

### Después
La desviación de costo está bajo el umbral. Lo que sí merece punto de comité son el cierre vencido con verde declarado y la cadena de compromisos reprogramados. Puedo preparar el punto con `/steering-pack`.

---
*criterio-portfolio 0.5.0 · ficha PRY-201 con declaración del 2026-10-17 y cálculo del 2026-10-18 · campos inciertos: autoridad, fase, evidencia de hitos, proveedor · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-18: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
