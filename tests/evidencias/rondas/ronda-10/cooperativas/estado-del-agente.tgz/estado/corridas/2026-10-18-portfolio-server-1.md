# Corrida del 2026-10-18 · portfolio-server

13 proyectos · 65 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 8 |
| `commitment_overdue` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `milestone_overdue` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Rostrum — modo «para mirarlo un rato»

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18; comprobante ya registrado). No hizo falta aceptarlos de nuevo.

Forma elegida: **para mirarlo un rato** (respuesta sugerida; nadie contestó en esta sesión de prueba y, si no se sabe cuál, se empieza por esta).

Informe encontrado en `reportes/` (portada, proyectos PRY-199 a PRY-211, productos, decisiones). Se sirve tal cual; el servidor no genera nada.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia y quien pregunta |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El portal lleva el nombre «Cooperativa» en todas las páginas (viene de la configuración).

## Lo que Rostrum no hace
- No calcula: sirve lo que `informe.py` ya escribió. Dos personas ven lo mismo.
- No escribe fichas: solo crea peticiones, en `estado/peticiones/`.
- No autentica. Para dejarlo corriendo (`--abierto`) hay que pedir a la organización: un host y puerto internos, publicarlo detrás de su control de acceso, y que el equipo siga encendido. Nada más.
- No manda correos ni notificaciones.

## Cierre
Este modo no sirve para pasar un enlace al patrocinador: `127.0.0.1` solo funciona en este equipo. Quien quiera mirarlo, lo hace aquí, ahora. El informe es del día en que se generó (la portada lo dice); si hace falta uno más reciente, `/portfolio-report html` antes de levantarlo. Para un enlace estable, la segunda forma («que quede corriendo») con la conversación de seguridad.
