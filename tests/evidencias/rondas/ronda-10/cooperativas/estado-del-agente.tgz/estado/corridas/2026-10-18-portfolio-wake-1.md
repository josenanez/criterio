# Corrida del 2026-10-18 · portfolio-wake

13 proyectos · 31 s · 65 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 8 |
| `commitment_overdue` | 7 |
| `progress_vs_plan` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_accepted_without_evidence` | 2 |
| `vendor_invoiced_over_accepted` | 2 |
| `milestone_overdue` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |

Barrido sin documentos cambiados (75/75); 17 campos de PRY-201 marcados source_missing por el índice aunque los archivos existen (posible desajuste de ruta relativa, no verificado); 5 preguntas de confirmación dejadas sin respuesta; sin peticiones. No sé si la ficha de PRY-201 está desactualizada respecto del hito vencido del 2026-10-04.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## 2026-10-18

**Revisé:** 75 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada cruzó un umbral porque nada se releyó. Una anomalía del índice, no del proyecto: `index` reporta 17 campos de PRY-201 como `source_missing` (código, nombre, área, producto, patrocinador, gerente, comité, estado declarado, avance, fechas, alcance, exclusiones y las cuatro cifras de dinero). Los archivos citados existen en la carpeta (`00-gobierno/2025-06-01-acta-constitucion.md`, `10-plan/2025-06-01-cronograma-v1.csv`, `20-seguimiento/2026-10-17-informe-avance.md`). Lo más probable es que las citas de `pm_record` estén escritas relativas a la carpeta del proyecto y el índice las busque desde la raíz de documentos. Es una hipótesis: no la verifiqué ni corregí la ficha.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión. Las dejo hechas una sola vez, sobre PRY-201 (dato actual y fecha de la fuente):

1. **Hito «Integración con el core cooperativo»:** figura `pending` con fecha 2026-10-04 (cronograma v1, 2025-06-01) y ya pasaron 14 días. ¿Cuál es la fecha vigente, o ya se cumplió y con qué evidencia?
2. **Estado declarado «verde», avance 91%** (informe del 2026-10-17): ¿se sostiene con el hito anterior vencido?
3. **Autoridad (`identity.authority`):** no encontrada. ¿Quién aprueba cambios de este proyecto?
4. **Fase (`identity.phase`):** no encontrada. ¿En qué fase está?
5. **Riesgo «el proveedor no ha confirmado la fecha de la última entrega»** (informe del 2026-10-17): sin dueño, probabilidad, impacto ni fecha. ¿Quién lo lleva?

Además, para el comité: Andrés Lozano y Gustavo Neira dicen que entregaron y no hay acta de recibo (anexo 11 y documento 17); Beatriz Cuéllar lleva 6 reprogramaciones del documento 1 (22-sep → 20-dic).

**Vuelvo el 2026-10-19.**
