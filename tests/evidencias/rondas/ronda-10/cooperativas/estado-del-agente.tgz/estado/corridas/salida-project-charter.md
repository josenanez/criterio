Acta previa: sí, existe, del 2025-09-28 (`PRY-203-aportes-sociales-en-línea/00-gobierno/2025-09-28-acta-constitucion.docx`). Es la única versión; no hay revisiones posteriores en la carpeta.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

## Acta — PRY-203 · Aportes sociales en línea
**Estado:** existe, del 2025-09-28

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Andrés Lozano sin subir al comité. | Hoy el proyecto reporta rojo, con un riesgo normativo que "puede mover el alcance" y un pedido del Consejo de ajustar el reglamento. Cualquiera de esos cambios llega al Consejo de Administración por defecto, porque no hay umbral que diga que el gerente podía resolverlo. Y el proyecto proyecta pasarse del presupuesto: nadie sabe si ese margen lo decide el gerente o el Consejo. |
| Objetivo de negocio | **Es la solución, no el negocio.** "Entregar aportes sociales en línea para Cartera y cobranza" describe lo que se construye. No hay beneficio, cifra ni resultado esperado. | No hay contra qué juzgar si el 59% de avance vale algo. El proyecto puede terminar "entregado" sin haber logrado nada que alguien pueda medir. |
| Alcance | **Vacío en la práctica.** Dice "Componente 1; Componente 2; Componente 3" y no los describe. | Cualquier pedido nuevo (el ajuste de reglamento, el cambio normativo) no se puede clasificar como dentro o fuera de alcance. Sin eso el control de cambios no tiene con qué comparar. |
| Exclusiones | **Presentes pero sin contenido.** Dice "Lo que otro proyecto cubre", sin nombrar ningún proyecto. | No sirve para delimitar. Si dos proyectos construyen lo mismo, esta línea no lo evita ni lo detecta. |
| Patrocinador | Cumple: Natalia Ospina, persona con nombre. | — |
| Gerente | Cumple: Andrés Lozano. | — |
| Comité y cadencia | Comité: Consejo de Administración (cumple). **Cadencia: ausente.** | No se sabe cada cuánto debe reportarse ni cuándo el proyecto se debía ver. Un informe de avance del 2026-10-11 es lo único que hay después del acta. |
| Supuestos | **Ausentes.** No hay sección. | No hay nada que verificar ni que pasar al registro RAID. Es lo que fallaría primero si el supervisor cambia la norma. |
| Restricciones | **Ausentes.** No hay sección. | El cierre contable de fin de mes ya reprogramó la salida y el acta no lo preveía como restricción. |
| Dependencias | Declara "Ninguna declarada". | Es una declaración de ausencia, no una verificación. Con un riesgo normativo y un reglamento por ajustar, que no haya ninguna dependencia es difícil de creer. |
| Criterio de éxito | **Presente pero no medible.** "Aportes sociales en línea en producción y medido." No dice qué se mide, con qué valor ni quién lo mide. | "Y medido" promete una medición que nadie definió. El cierre no se puede contrastar. |
| Hitos | **Ausentes.** Solo hay inicio y cierre. | El cronograma es la fecha de cierre y nada más. Sin hitos no hay atraso intermedio que detectar antes del final. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice: "Entregar aportes sociales en línea para Cartera y cobranza." (acta, sección Objetivo del negocio)
**Alcance:** "Componente 1; Componente 2; Componente 3". El acta no los describe. (acta, sección Alcance)
**Exclusiones:** "Lo que otro proyecto cubre". No nombra el proyecto. (acta, sección Fuera de alcance)
**Patrocinador:** Natalia Ospina · **Gerente:** Andrés Lozano (acta)
**Autoridad del gerente:** pendiente de definir. No aparece en el acta ni en el informe de avance.
**Comité al que reporta:** Consejo de Administración (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Aportes sociales en línea en producción y medido." (acta) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. El acta solo trae inicio 2025-10-08 y cierre 2026-05-26.
**Presupuesto aprobado:** 2.400.000.000 COP, por el Consejo de Administración el 2025-09-28 (acta).

### Lo que el informe del 2026-10-11 dice sobre el acta
Esto no es parte del acta; son hechos del informe que muestran por qué importan los vacíos:
- **La fecha de cierre del acta, 2026-05-26, ya pasó hace 145 días** y el proyecto sigue en ejecución con 59% de avance declarado. No hay en la carpeta ninguna línea base nueva ni cambio aprobado que mueva esa fecha. El acta sigue siendo la única línea base y está vencida.
- **Ejecutado más comprometido = 2.208.076.389 COP, 92,0% del aprobado**, por encima del umbral de 90% de la configuración. Ejecutado solo: 1.278.281.381 (53,3%), contra un avance declarado de 59%.
- **La proyección al cierre, 2.419.120.193 COP, supera lo aprobado en 19.120.193 COP (0,8%).** Es poco, pero es el tipo de decisión que la autoridad del gerente debería decir quién toma.
- Dos hechos del periodo (reprogramación de la salida y ajuste de reglamento pedido por el Consejo) son cambios que el acta no sabe clasificar, porque su alcance no está descrito.

### Después
- **Autoridad sin declarar:** lo propongo como decisión para el comité, no como trámite. Pregunta cerrada: ¿hasta qué monto y qué tipo de cambio de alcance decide el gerente de PRY-203 sin subir al Consejo de Administración? Si nadie decide, todo seguirá subiendo al Consejo.
- **Supuestos:** de esta revisión no salieron supuestos declarados que pasar al registro RAID, porque el acta no trae ninguno. Lo que sí salió es que el riesgo normativo y la reprogramación existen en el informe; ya están en la ficha.
- Falta la fecha de cierre vigente: la persona que pueda confirmarla es el gerente o el patrocinador.

### Pie de rigor
- **Leí:** el acta (2025-09-28) y el informe de avance (2026-10-11), los dos únicos documentos de la carpeta del proyecto, y la ficha PRY-203.
- **No sé:** si existe una versión más reciente del acta o un cambio aprobado fuera de la carpeta; si la autoridad del gerente está definida en un reglamento del Consejo de Administración que no está en esta carpeta; qué son los Componentes 1 a 3; qué proyecto cubre lo excluido.
- **Verifica tú:** los cálculos de porcentaje (hechos sobre las cifras del informe) y que el acta .docx no tenga contenido que el convertidor de texto haya omitido (tablas, comentarios, cambios con control de cambios).
- Esta revisión no completa ningún campo con lo razonable: lo que no está, queda marcado como pendiente de definir.
