# Portafolio — 2026-10-18
13 proyectos · 10 con hallazgos (65 señales) · último barrido 2026-10-18

Fichas cargadas: 13, de `estado/records/` (fecha 2026-10-18; ninguna con más de una semana sin barrido). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Qué cambió desde la corrida anterior
Sin cambios desde la instantánea 2026-10-18. Es el punto de partida: no hay delta con qué comparar.

## Contradicciones abiertas
Vacía: ningún proyecto tiene campos con `record_issues`. La contradicción que sí hay es entre lo declarado y la evidencia (ver "Estado general").

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-201 | Integración con el core cooperativo | 2026-10-04 | 14 |
| PRY-207 | Ambiente de pruebas certificado | 2026-10-11 | 7 |

Hitos declarados cumplidos sin evidencia (PRY-200: 4, PRY-201: 2, PRY-202: 3, PRY-204: 5, PRY-208: 1, PRY-209: 3, PRY-210: 4, PRY-211: 1). El más viejo: PRY-201 "Diseño funcional aprobado", 334 días.

## Proyectos en silencio
Vacía: ninguno supera 15 días (el mayor es PRY-205, con 12).

## Dependencias en riesgo
Sin dependencias entre proyectos detectadas por el script. Sí hay riesgo por proveedor compartido: Talento Solidario Ltda. en PRY-200 y PRY-209.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | verde (2026-10-17) | Hito vencido, 5 compromisos vencidos, 3 reprogramados 4–6 veces |
| PRY-204 | verde (2026-10-13) | 5 hitos "cumplidos" sin evidencia, 67 % declarado frente a 100 % que sostiene el plan |
| PRY-206 | verde (2026-10-01) | Compromiso vencido hace 6 días |
| PRY-207 | verde (2026-10-06) | Hito vencido, costo +27,9 %, compromiso vencido |

## Vacíos de información
- Ningún proyecto tiene autoridad definida (13 de 13).
- Sin producto asignado: PRY-202, 205, 208, 209, 210.
- Compromisos sin fecha: PRY-201 (2), PRY-202, PRY-208.

## Estado general
| Proyecto | Señales destacadas |
|---|---|
| PRY-210 | Línea base movida 84 días sin autorización (+33,6 %); 4 hitos sin evidencia |
| PRY-209 | Facturado sobre lo aceptado: 948,2 M COP (Talento Solidario); entregables vencidos |
| PRY-200 | Costo +14,5 % (proyección 20.616 M frente a 18.000 M); facturado sobre lo aceptado: 179,5 M COP |
| PRY-207 | Costo +27,9 %; hito vencido |
| PRY-201 | 14 señales; verde declarado contradicho |
| PRY-204 | 8 señales; verde declarado contradicho |
| PRY-206 | verde declarado contradicho |
| PRY-202, 208, 211 | Hitos sin evidencia |
| PRY-199, 203, 205 | Sin señales |

## Necesito que confirmes
No toca este mes: sin confirmación periódica en esta corrida (sesión sin interfaz).

---
## Archivos
- `reportes/index.html` — vista por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — vista por decisión, para el patrocinador. Solo lo que excede la facultad de quien gerencia.
- Además: 13 páginas de proyecto, 8 de producto, `productos.html` y `proyectos.html` (25 páginas en total). El PDF sale de imprimir el HTML.

Pie: criterio-portfolio 0.5.0 · fichas del 2026-10-18 · campos inciertos: ninguno marcado · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
