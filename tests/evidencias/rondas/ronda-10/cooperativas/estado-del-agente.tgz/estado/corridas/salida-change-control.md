Sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-18), el acta de constitución, el cronograma v1, el informe de avance del 2026-10-13 y el acta de recibo del piloto.

## Solicitud de cambio — PRY-200 Crédito de libranza digital — 2026-10-18

**Qué se pide:** mover 30 días la salida a producción. · **Quién lo pide:** no consta en ningún documento. · **Por qué:** no consta; la solicitud no trae motivo.

### Hallazgo previo: la solicitud no se puede evaluar tal como está escrita

- La línea base vigente es la v1, aprobada el 2025-11-20 (cronograma-v1.csv). Salida a producción: **2026-08-31**.
- Mover 30 días desde esa fecha da **2026-09-30**, que ya pasó (hoy es 2026-10-18). No es un cambio de fecha: es reconocer un atraso ya consumido y pedir además otro.
- El cronograma v1 marca «Salida a producción» como *cerrado* con fecha vigente 2026-08-31, pero el informe del 2026-10-13 declara **rojo y 67 % de avance**, y el criterio de éxito del acta («en producción y medido») no tiene ninguna evidencia de salida. Ese «cerrado» no está sustentado.
- Hace falta que quien pide indique la **fecha nueva concreta** y el motivo. Si se contaran 30 días desde hoy sería 2026-11-17, pero eso es una hipótesis mía, no lo que pide el documento, y no la uso en los cálculos.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3; el acta no los describe | Sin declarar | Sin impacto declarado. Si no se toca el alcance y se mueven fecha y costo, nadie dijo quién absorbe la diferencia. |
| Tiempo | Cierre 2026-08-31 (v1). A hoy lleva 48 días de atraso sin producción evidenciada | 2026-09-30 si se aplica literal (ya vencida) | +30 días pedidos, sobre 48 ya corridos. Contra la v1, el atraso mínimo al día de hoy es 48 días y crece hasta que haya fecha aprobada. |
| Costo | Aprobado 18.000.000.000 COP. Ejecutado 10.475.680.794. Comprometido 7.409.726.138 | Proyección al cierre 20.616.543.260 (informe 2026-10-13) | **+2.616.543.260 COP (14,5 %) sobre lo aprobado**, por encima del umbral de 10 %. La solicitud no declara costo del cambio; esta cifra es la proyección que el gerente ya reporta. |

Otras señales que cambian la lectura:
- **Piloto con asociados:** línea base 2026-07-07, acta de recibo del 2026-10-10 (95 días después) y la ficha sigue con fecha vigente 2026-07-07. Hay un atraso real que ningún documento replanifica.
- **Ejecutado frente a avance:** 58,2 % del presupuesto ejecutado contra 67 % de avance declarado. Si se suma lo comprometido al ejecutado (suponiendo que son montos distintos, el informe no lo aclara) se llega a 17.885.406.932 COP, 99,4 % de lo aprobado, con 33 % de avance por entregar.
- **Proveedor CT-892 (Talento Solidario):** cuatro entregables de 823.489.299 COP cada uno. Solo la parametrización de líneas figura como recibida (el gerente lo declara, sin acta); licenciamiento y mesa de ayuda dicen «en curso» con fecha vencida, y la bolsa de horas sigue pendiente. Facturado: 1.002.986.926 COP. En esta corrida no leí el texto del contrato (.docx), así que **no sé si la vigencia de CT-892 cubre una salida desplazada**; hay que verificarlo.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno por dependencia declarada | El cálculo (`impact`, +30 días, nuevo cierre 2026-09-30) devuelve 0 proyectos alcanzados, 0 que no puedan sostener fecha y 0 dependencias sin confirmar | — |

Esto **no** significa que no haya efecto: el acta de PRY-200 dice «Ninguna declarada» y la ficha no tiene dependencias, de modo que el cálculo no tiene por dónde recorrer. Pero el informe lista como riesgo la «dependencia del proveedor del core cooperativo» y el hito «Integración con el core cooperativo» se cerró el 2026-05-13. Eso apunta a una dependencia real con el proyecto del core (PRY-202, por nombre) que nunca se declaró ni se acordó con el otro lado. Tampoco puedo decir cuántos días se movería ningún otro proyecto: la ficha no tiene holgura por actividad.

### Quién decide
**Autoridad requerida:** no determinable. La ficha no tiene autoridad declarada (`identity.authority`: no encontrada) y el acta no fija umbrales de cambio. · **Según:** acta de constitución 2025-11-20: el presupuesto lo aprobó el Consejo de Administración, que figura como comité. · **Va a comité:** **sí**, por defecto. Con la proyección en +14,5 % sobre un presupuesto que aprobó el Consejo, y sin autoridad escrita que diga que alguien más puede aprobarlo, esto no se resuelve por debajo de ese órgano. Que el proyecto llegue a este punto sin autoridad declarada es el hallazgo de fondo.

### Si no se aprueba
El proyecto sigue con una línea base cuya fecha de cierre venció hace 48 días, un hito de salida marcado «cerrado» sin evidencia, estado rojo y una proyección de costo por encima de lo aprobado. Es decir: sigue sin un plan vigente que alguien haya aprobado. Esa situación no es neutra: cada día añade desviación contra una referencia que ya no describe el proyecto.

### Si se aprueba
Línea base 2 — cierre **[fecha por definir por quien pide]** · presupuesto **[monto por definir; la proyección reportada es 20.616.543.260 COP]** · motivo: **[no declarado]**.
Desviación acumulada contra la línea base original: **tiempo, al menos 48 días a hoy (más lo que sume la fecha nueva); costo, +2.616.543.260 COP proyectados (14,5 %)**. La línea base 1 no se toca. No hay cambios registrados en la ficha (`changes` vacío), así que la nueva línea base sería la primera replanificación y hoy no hay ningún documento que autorice los días ya corridos.

### Lo que no sé
- Quién pide el cambio, por qué y a qué fecha concreta.
- El impacto en alcance.
- La vigencia del contrato CT-892.
- Si hay dependencias reales con otros proyectos (ver arriba).
- Cuántos días se mueve cada proyecto afectado: eso necesita holgura por actividad y no está en las fichas.

### Siguiente paso
Llevarlo al Consejo de Administración con la fecha y el costo definidos por quien lo pide. Si eso se aprueba, registrar la línea base 2 con ese documento como soporte. Antes, declarar la dependencia con el proyecto del core y acordarla con su gerente.

*Pie de rigor: borrador de trabajo; cada cifra sale de los documentos citados y su verificación es suya. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-18.*
