## Barrido — 2026-10-18

Encontré 75 documentos en `documentos/proyectos` (13 carpetas de proyecto). Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta volver a registrarlos. Plan de lectura: 1 lote de 10 proyectos, uno tras otro, sin subagentes.

**Documentos:** 75 en la carpeta · 51 leídos · 24 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 3 sin cambio (PRY-201, PRY-202, PRY-208) · 0 sin carpeta propia
**Formatos:** 37 .md, 15 .pdf, 10 .csv, 9 .docx, 2 .xlsx, 1 .json, 1 .txt

Leí 51 de 75 documentos. Los otros 24 son de PRY-201, PRY-202 y PRY-208, que ya tenían ficha y no cambiaron; no los abrí.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, 5 hitos, dinero, 1 contrato (3 entregables), 1 riesgo, 1 compromiso | autoridad, fase, factura de CT-199 |
| PRY-200 Crédito de libranza digital | 6 | identidad, plan, 5 hitos, dinero, 1 contrato (4 entregables), factura, 2 riesgos | autoridad, fase |
| PRY-203 Aportes sociales en línea | 2 | identidad, plan (sin cronograma), dinero, 1 riesgo, 2 incidencias | autoridad, fase |
| PRY-204 Tarjeta débito para asociados | 7 | identidad, plan, 5 hitos, dinero, 1 contrato (2 actas de recibo), factura, 2 riesgos | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 2 | identidad, plan (sin cronograma), dinero, 2 riesgos | producto (el acta dice «No aplica»), autoridad, fase |
| PRY-206 Pagos con QR | 5 | identidad, plan, 4 hitos, dinero, 1 riesgo, 2 compromisos | autoridad, fase |
| PRY-207 Microcrédito rural | 5 | identidad, plan, 4 hitos, dinero, 1 riesgo, 2 incidencias, 1 compromiso | autoridad, fase |
| PRY-209 Convenios de libranza con empresas | 7 | identidad, plan, 5 hitos, dinero, 2 contratos (6 entregables), 1 factura, 2 riesgos, 2 incidencias, 1 compromiso | producto («No aplica»), autoridad, fase, factura de CT-661 |
| PRY-210 Corresponsales rurales | 7 | identidad, 2 líneas base, 5 hitos, dinero, solicitud de cambio CC-01, 2 riesgos, 1 incidencia, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 4 | identidad, plan, 4 hitos, dinero, 1 riesgo, 3 incidencias | autoridad, fase |

`identity.authority` y `identity.phase` quedan en `not_found` en los diez proyectos: ningún acta dice hasta qué monto decide el gerente sin subir a comité, ni en qué etapa está el proyecto.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-210 | Hay dos líneas base: la v1 (cierre 2026-06-17) y una v2 que mueve «Salida a producción» al 2026-09-09. El cronograma v2 no dice el motivo ni quién lo aprobó. | `PRY-210-corresponsales-rurales/10-plan/2026-10-17-cronograma-v2.csv` |

Ninguna otra ficha existía antes. PRY-201, PRY-202 y PRY-208 no se tocaron.

### Lo que hay que mirar (lo que dicen los documentos; los cálculos los hace el informe)
- **Hitos declarados cerrados sin acta que los pruebe.** Los registré como `met` con la evidencia vacía, tal como lo declara el cronograma:
  - PRY-200: 4 de 5 (solo «Piloto con asociados» tiene acta, y es del 2026-10-10, contra una fecha de línea base del 2026-07-07).
  - PRY-204: 5 de 5.
  - PRY-209: 3 de 3 cerrados.
  - PRY-210: 4 de 5 (el acta es del ambiente de pruebas).
  - PRY-211: 1 («Ambiente de pruebas certificado»).
- **Facturado contra lo aceptado.**
  - PRY-200: factura FV-1892 por 1.002.986.926 COP; el contrato CT-892 declara un solo entregable recibido (823.489.299 COP) y ningún acta lo prueba.
  - PRY-209: factura FV-1102 por 3.038.412.141 COP; CT-102 declara un solo entregable recibido (2.090.227.453 COP), también sin acta.
  - PRY-204 cuadra: 2 actas de recibo (2026-01-14 y 2026-04-17) y una factura por 211.508.066 COP, igual a 2 × 105.754.033.
  - PRY-199 no tiene factura, y el primer entregable vence el 2026-11-17.
- **Proyecto sin cronograma y con la fecha de cierre del acta ya pasada:** PRY-203 (cierre 2026-05-26, avance 59%, «rojo») y PRY-205 (cierre 2026-07-14, avance 31%, «rojo»).
- **Presupuesto.**
  - Proyección al cierre declarada por encima de lo aprobado: PRY-200 (20.616.543.260 contra 18.000.000.000), PRY-207 (23.020.726.508 contra 18.000.000.000), y por poco PRY-203, PRY-204, PRY-205 y PRY-211.
  - Ejecutado mayor que comprometido, lo que es incoherente: PRY-200 y PRY-203.
- **Cambio sin decidir:** PRY-210 CC-01 (ampliación de alcance, +84 días, +168.000.000 COP) está «pendiente de presentación al comité». Mientras tanto el cronograma v2 ya movió una fecha, sin citar la solicitud.
- **Compromisos con fecha ya vencida al registrarse y sin evidencia de entrega:** PRY-206 (Natalia Ospina, punto 35, para el 2026-10-12) y PRY-207 (Elena Duarte, punto 33, para el 2026-10-02).
- **Salida reprogramada sin fecha nueva:** PRY-203, 207, 209 y 211 dicen que «se reprogramó la salida por el cierre contable» y no dan la nueva fecha.
- **Declarado «verde» con señales en contra:** PRY-207 (verde, 62%; perdió dos semanas por rotación de un desarrollador clave; su propia proyección, 23.020.726.508 COP, supera lo aprobado). Lo digo como contraste, sin juzgar.

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | Los 75 archivos se convirtieron a texto sin error. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | — | No existe una carpeta `entrada/` en `documentos/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

### Observaciones sobre lo que no se tocó
- PRY-201 tiene su `ficha-pm.json` publicada por su gerente, cuyas rutas de fuente (`00-gobierno/…`) son relativas a la carpeta del proyecto y no a la raíz de documentación. Por eso el índice reporta 17 fuentes de `pm_record` que «no resuelven» (identidad, estado declarado, fechas y dinero). No es un archivo faltante: el contrato de la ficha pide la ruta relativa a la raíz. Se lo dejo señalado a quien publica esa ficha. No la modifiqué.
- Hay una nota suelta en la carpeta de PRY-201 (`2026-10-18-notas-reunion.txt`), fuera de `30-reuniones/`. No cambió desde la corrida anterior.

## Después

Hay más de un proyecto con ficha: puedo generar el informe consolidado (`/criterio-portfolio:portfolio-report`). Las contradicciones, los hitos sin acta y los compromisos vencidos que aparecen arriba entrarían ahí.

---
Criterio Portfolio 0.5.0 · fichas tocadas: 10 (PRY-199, 200, 203, 204, 205, 206, 207, 209, 210, 211) · campos en `not_found`: 23 (`identity.authority` ×10, `identity.phase` ×10, `identity.product` ×3 en PRY-205, 209 y 210) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
