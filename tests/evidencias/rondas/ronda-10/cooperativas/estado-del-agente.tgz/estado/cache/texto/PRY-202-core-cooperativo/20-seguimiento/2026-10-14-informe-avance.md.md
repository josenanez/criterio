<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Core cooperativo

**Código:** PRY-202
**Fecha de corte:** 2026-10-14
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 5.239.839.176 |
| Ejecutado | 1.443.778.097 |
| Proyección al cierre | 7.054.849.455 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Cambio normativo del supervisor que puede mover el alcance
