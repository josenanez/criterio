<!-- origen: PRY-208-motor-de-crédito/10-plan/2025-12-11-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-03-15,2026-03-15,cerrado
Ambiente de pruebas certificado,2026-06-07,2026-06-07,cerrado
Integración con el core cooperativo,2026-08-30,2026-08-30,cerrado
Piloto con asociados,2026-11-22,2026-11-22,en curso
