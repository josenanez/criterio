<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Corresponsales rurales

**Fecha:** 2026-10-12
**Asistentes:** Liliana Torres, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 28 | 2026-10-26 |
