<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-01-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-01
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **33%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.822.765.772 |
| Ejecutado | 697.043.394 |
| Proyección al cierre | 4.049.447.863 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
