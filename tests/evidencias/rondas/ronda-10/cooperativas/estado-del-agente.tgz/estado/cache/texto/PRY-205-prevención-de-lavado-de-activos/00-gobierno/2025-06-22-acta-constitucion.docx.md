<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-06-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Bienestar social

Patrocinador: Andrés Lozano

Gerente de proyecto: Javier Hoyos

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2025-06-22

Objetivo del negocio

Entregar prevención de lavado de activos para Bienestar social.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Riesgos el 2025-06-22.

Fechas comprometidas

Fecha

Inicio

2025-07-02

Cierre

2026-07-14

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
