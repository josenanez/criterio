<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-18-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-18
**Asistentes:** Diana Molina, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 6 | por definir |
