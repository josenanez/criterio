<!-- origen: PRY-202-core-cooperativo/10-plan/2025-08-31-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-12-02,2025-12-02,cerrado
Ambiente de pruebas certificado,2026-02-24,2026-02-24,cerrado
Integración con el core cooperativo,2026-05-18,2026-05-18,cerrado
Piloto con asociados,2026-08-10,2026-08-10,cerrado
