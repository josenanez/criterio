<!-- origen: PRY-201-apertura-de-ahorro-en-línea/30-reuniones/2026-09-20-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-09-20
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-22 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-28 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-04 |
| Diana Molina | Validar el ambiente 4 | 2026-10-19 |
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-10-20 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-15 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 |
| Laura Vélez | Enviar el documento 9 | 2026-10-06 |
| Jorge Medina | Cerrar la prueba 10 | 2026-10-07 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-27 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-18 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Andrés Lozano): recibido, acta de recibo del 2026-09-20.
