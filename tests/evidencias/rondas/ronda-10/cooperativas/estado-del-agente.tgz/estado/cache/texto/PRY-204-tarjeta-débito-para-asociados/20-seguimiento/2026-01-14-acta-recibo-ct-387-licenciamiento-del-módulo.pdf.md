<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-01-14-acta-recibo-ct-387-licenciamiento-del-módulo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento del módulo
Proyecto: PRY-204 · Tarjeta débito para asociados
Fecha de recibo: 2026-01-14
Recibido por: Javier Hoyos
Se recibe a satisfacción el entregable Licenciamiento del módulo.
Contrato CT-387 · Soluciones Solidarias S.A.S..
