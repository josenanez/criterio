<!-- origen: PRY-210-corresponsales-rurales/10-plan/2025-09-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-29,2025-11-29,cerrado
Ambiente de pruebas certificado,2026-01-18,2026-01-18,cerrado
Integración con el core cooperativo,2026-03-09,2026-03-09,cerrado
Piloto con asociados,2026-04-28,2026-04-28,cerrado
Salida a producción,2026-06-17,2026-06-17,cerrado
