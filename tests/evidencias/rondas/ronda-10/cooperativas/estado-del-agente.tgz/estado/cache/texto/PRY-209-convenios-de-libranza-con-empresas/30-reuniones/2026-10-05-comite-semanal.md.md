<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Convenios de libranza con empresas

**Fecha:** 2026-10-05
**Asistentes:** Liliana Torres, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 5 | 2026-11-02 |
