<!-- origen: PRY-201-apertura-de-ahorro-en-línea/30-reuniones/2026-09-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-09-06
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Natalia Ospina, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-09-22 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-02 |
| Andrés Lozano | Revisar el anexo 3 | 2026-09-16 |
| Diana Molina | Validar el ambiente 4 | 2026-09-29 |
