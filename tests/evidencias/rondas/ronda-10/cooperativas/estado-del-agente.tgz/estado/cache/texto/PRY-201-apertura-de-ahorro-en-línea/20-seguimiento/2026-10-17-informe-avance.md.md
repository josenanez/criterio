<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-17-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Apertura de ahorro en línea

**Código:** PRY-201
**Fecha de corte:** 2026-10-17
**Gerente:** Natalia Ospina

## Estado declarado

**Verde**

Avance reportado: **91%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 13.196.888.150 |
| Ejecutado | 6.420.513.826 |
| Proyección al cierre | 18.779.394.290 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Dependencia del proveedor del core cooperativo
