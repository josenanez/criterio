<!-- origen: PRY-201-apertura-de-ahorro-en-línea/30-reuniones/2026-09-13-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-09-13
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-10-12 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-10-15 |
| Andrés Lozano | Revisar el anexo 3 | 2026-09-16 |
| Diana Molina | Validar el ambiente 4 | 2026-09-29 |
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-09-30 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-09-26 |
| Andrés Lozano | Confirmar la fecha 7 | 2026-10-03 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-02 |
