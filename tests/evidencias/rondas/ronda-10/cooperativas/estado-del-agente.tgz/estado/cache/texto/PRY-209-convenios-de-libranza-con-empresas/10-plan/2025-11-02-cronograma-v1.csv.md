<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2025-11-02-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-09,2026-02-09,cerrado
Ambiente de pruebas certificado,2026-05-10,2026-05-10,cerrado
Integración con el core cooperativo,2026-08-07,2026-08-07,cerrado
Piloto con asociados,2026-11-05,2026-11-05,en curso
Salida a producción,2027-02-03,2027-02-03,en curso
