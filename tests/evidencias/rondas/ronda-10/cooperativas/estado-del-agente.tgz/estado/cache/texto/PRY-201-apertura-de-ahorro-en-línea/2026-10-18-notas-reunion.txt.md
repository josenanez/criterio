<!-- origen: PRY-201-apertura-de-ahorro-en-línea/2026-10-18-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión apertura de ahorro en línea — 2026-10-18
estuvieron: Andrés Lozano, Beatriz Cuéllar, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Beatriz Cuéllar dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 20/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-28
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
