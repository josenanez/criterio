<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-10-06
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 31%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se recibió el concepto pendiente del ente supervisor

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.386.718.213
Ejecutado 1.785.518.877
Proyección al cierre 3.352.928.946

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
- Concentración del conocimiento en una sola persona
