<!-- origen: PRY-211-cobranza-digital/10-plan/2026-04-05-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-07-09,2026-07-09,cerrado
Ambiente de pruebas certificado,2026-10-03,2026-10-03,cerrado
Integración con el core cooperativo,2026-12-27,2026-12-27,en curso
Piloto con asociados,2027-03-23,2027-03-23,en curso
