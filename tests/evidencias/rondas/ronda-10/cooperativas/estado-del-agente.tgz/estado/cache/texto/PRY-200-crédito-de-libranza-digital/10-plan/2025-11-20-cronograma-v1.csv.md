<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-11-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-23,2026-01-23,cerrado
Ambiente de pruebas certificado,2026-03-19,2026-03-19,cerrado
Integración con el core cooperativo,2026-05-13,2026-05-13,cerrado
Piloto con asociados,2026-07-07,2026-07-07,cerrado
Salida a producción,2026-08-31,2026-08-31,cerrado
