<!-- origen: PRY-206-pagos-con-qr/10-plan/2026-05-13-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-20,2026-09-20,cerrado
Ambiente de pruebas certificado,2027-01-18,2027-01-18,en curso
Integración con el core cooperativo,2027-05-18,2027-05-18,en curso
Piloto con asociados,2027-09-15,2027-09-15,en curso
