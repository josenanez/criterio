<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-04-05-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Tecnología

Patrocinador: María Restrepo

Gerente de proyecto: Camilo Beltrán

Comité: Consejo de Administración

Producto asociado: recaudos

Fecha de aprobación: 2026-04-05

Objetivo del negocio

Entregar cobranza digital para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Consejo de Administración el 2026-04-05.

Fechas comprometidas

Fecha

Inicio

2026-04-15

Cierre

2027-03-23

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
