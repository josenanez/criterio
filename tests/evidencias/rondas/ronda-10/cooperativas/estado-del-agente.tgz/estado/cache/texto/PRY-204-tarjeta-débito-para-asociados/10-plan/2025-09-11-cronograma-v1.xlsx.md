<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2025-09-11-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-12-05 | 2025-12-05 | cerrado
Ambiente de pruebas certificado | 2026-02-18 | 2026-02-18 | cerrado
Integración con el core cooperativo | 2026-05-04 | 2026-05-04 | cerrado
Piloto con asociados | 2026-07-18 | 2026-07-18 | cerrado
Salida a producción | 2026-10-01 | 2026-10-01 | cerrado
