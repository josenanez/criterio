<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2025-06-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-18,2025-11-18,cerrado
Ambiente de pruebas certificado,2026-04-27,2026-04-27,cerrado
Integración con el core cooperativo,2026-10-04,2026-10-04,en curso
