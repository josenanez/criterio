<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2026-04-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Ahorro y aportes

Patrocinador: Felipe Arango

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Crédito

Producto asociado: microcrédito

Fecha de aprobación: 2026-04-16

Objetivo del negocio

Entregar microcrédito rural para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Crédito el 2026-04-16.

Fechas comprometidas

Fecha

Inicio

2026-04-26

Cierre

2027-03-28

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
