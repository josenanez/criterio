<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2025-06-01-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Apertura de ahorro en línea

**Código:** PRY-201
**Área dueña:** Cartera y cobranza
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Crédito
**Producto asociado:** ahorro a la vista
**Fecha de aprobación:** 2025-06-01

## Objetivo del negocio

Entregar apertura de ahorro en línea para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Crédito el 2025-06-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-11 |
| Cierre | 2026-10-04 |

## Criterio de éxito

Apertura de ahorro en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
