<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Convenios de libranza con empresas

**Código:** PRY-209
**Fecha de corte:** 2026-10-11
**Gerente:** Liliana Torres

## Estado declarado

**Amarillo**

Avance reportado: **80%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó la salida por el cierre contable de fin de mes
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 10.284.283.842 |
| Ejecutado | 7.853.517.069 |
| Proyección al cierre | 17.473.872.386 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del proveedor del core cooperativo
