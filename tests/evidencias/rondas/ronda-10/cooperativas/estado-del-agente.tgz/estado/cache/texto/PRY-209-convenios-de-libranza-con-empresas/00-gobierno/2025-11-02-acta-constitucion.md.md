<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2025-11-02-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Convenios de libranza con empresas

**Código:** PRY-209
**Área dueña:** Crédito
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Liliana Torres
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-11-02

## Objetivo del negocio

Entregar convenios de libranza con empresas para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Riesgos el 2025-11-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-12 |
| Cierre | 2027-02-03 |

## Criterio de éxito

Convenios de libranza con empresas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
