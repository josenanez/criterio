<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2025-09-11-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Tarjeta débito para asociados

**Código:** PRY-204
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Javier Hoyos
**Comité:** Consejo de Administración
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2025-09-11

## Objetivo del negocio

Entregar tarjeta débito para asociados para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Consejo de Administración el 2025-09-11.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-21 |
| Cierre | 2026-10-01 |

## Criterio de éxito

Tarjeta débito para asociados en producción y medido.

## Dependencias declaradas

- Ninguna declarada
