<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** Camilo Beltrán

## Estado declarado

**Amarillo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 621.239.148 |
| Ejecutado | 472.063.577 |
| Proyección al cierre | 1.250.123.404 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
