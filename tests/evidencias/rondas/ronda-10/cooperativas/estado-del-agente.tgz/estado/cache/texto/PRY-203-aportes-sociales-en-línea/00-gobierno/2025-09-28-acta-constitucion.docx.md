<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-09-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Aportes sociales en línea

Código: PRY-203

Área dueña: Cartera y cobranza

Patrocinador: Natalia Ospina

Gerente de proyecto: Andrés Lozano

Comité: Consejo de Administración

Producto asociado: aportes sociales

Fecha de aprobación: 2025-09-28

Objetivo del negocio

Entregar aportes sociales en línea para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Consejo de Administración el 2025-09-28.

Fechas comprometidas

Fecha

Inicio

2025-10-08

Cierre

2026-05-26

Criterio de éxito

Aportes sociales en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
