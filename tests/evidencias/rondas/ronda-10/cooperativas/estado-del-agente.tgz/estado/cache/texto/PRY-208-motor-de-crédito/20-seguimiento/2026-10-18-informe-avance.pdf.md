<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de crédito
Código: PRY-208
Fecha de corte: 2026-10-18
Gerente: Felipe Arango

Estado declarado
Amarillo
Avance reportado: 48%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.133.758.969
Ejecutado 3.935.886.685
Proyección al cierre 6.843.787.816

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
- Concentración del conocimiento en una sola persona
