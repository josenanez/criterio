<!-- origen: PRY-206-pagos-con-qr/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-10-17
**Asistentes:** Elena Duarte, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 39 | 2026-11-03 |
| Natalia Ospina | Entregar el punto 35 | 2026-10-12 |
