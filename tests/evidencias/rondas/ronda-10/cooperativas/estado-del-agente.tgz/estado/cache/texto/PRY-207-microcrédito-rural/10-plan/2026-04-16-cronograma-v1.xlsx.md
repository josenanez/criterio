<!-- origen: PRY-207-microcrédito-rural/10-plan/2026-04-16-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-19 | 2026-07-19 | cerrado
Ambiente de pruebas certificado | 2026-10-11 | 2026-10-11 | en curso
Integración con el core cooperativo | 2027-01-03 | 2027-01-03 | en curso
Piloto con asociados | 2027-03-28 | 2027-03-28 | en curso
