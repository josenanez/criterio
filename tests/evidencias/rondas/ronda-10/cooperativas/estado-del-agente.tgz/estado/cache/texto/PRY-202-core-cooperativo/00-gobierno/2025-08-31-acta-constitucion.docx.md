<!-- origen: PRY-202-core-cooperativo/00-gobierno/2025-08-31-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core cooperativo

Código: PRY-202

Área dueña: Operaciones

Patrocinador: Mauricio Pérez

Gerente de proyecto: Diana Molina

Comité: Comité de Educación

Producto asociado: No aplica

Fecha de aprobación: 2025-08-31

Objetivo del negocio

Entregar core cooperativo para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Educación el 2025-08-31.

Fechas comprometidas

Fecha

Inicio

2025-09-10

Cierre

2026-08-10

Criterio de éxito

Core cooperativo en producción y medido.

Dependencias declaradas

• Ninguna declarada
