<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-10-06
Gerente: Beatriz Cuéllar

Estado declarado
Verde
Avance reportado: 62%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 13.226.845.918
Ejecutado 9.390.594.481
Proyección al cierre 23.020.726.508

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
