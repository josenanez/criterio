<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-201",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "name": {
 "value": "Apertura de ahorro en línea",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Cartera y cobranza",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "product": {
 "value": "ahorro a la vista",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Elena Duarte",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "manager": {
 "value": "Natalia Ospina",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Crédito",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 91,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-06-11",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "end_date": {
 "value": "2026-10-04",
 "source": "10-plan/2025-06-01-cronograma-v1.csv",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-06-01",
 "start_date": "2025-06-11",
 "end_date": "2026-10-04",
 "reason": "Aprobación inicial del acta de constitución",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2025-11-18",
 "current_date": "2025-11-18",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2025-06-01-cronograma-v1.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-04-27",
 "current_date": "2026-04-27",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2025-06-01-cronograma-v1.csv"
 },
 {
 "name": "Integración con el core cooperativo",
 "baseline_date": "2026-10-04",
 "current_date": "2026-10-04",
 "state": "pending",
 "evidence": "",
 "source": "10-plan/2025-06-01-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3 (el acta no los describe)",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 18000000000,
 "source": "00-gobierno/2025-06-01-acta-constitucion.md",
 "source_date": "2025-06-01",
 "state": "found"
 },
 "committed": {
 "value": 13196888150,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "executed": {
 "value": 6420513826,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "projection": {
 "value": 18779394290,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "Dependencia del proveedor del core cooperativo",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarada",
 "due_date": "no_declarada",
 "last_moved": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Beatriz Cuéllar",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-20",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-12-06",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 {
 "due_date": "2026-12-20",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-12-02",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-04",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-04",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Diana Molina",
 "what": "Validar el ambiente 4",
 "due_date": "2026-11-22",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-06",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-22",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-11-04",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-15",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-03",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-20-acta-recibo-7.md"
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-30",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-04-acta-recibo-10.md"
 },
 {
 "who": "Andrés Lozano",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-27",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Andrés Lozano dijo el 2026-09-27 que ya lo entregó; no se presentó acta (30-reuniones/2026-09-27-comite-semanal.md)"
 },
 {
 "who": "Mauricio Pérez",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-11-09",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Confirmar la fecha 15",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-06",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-22",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Gustavo Neira dijo el 2026-10-11 que ya lo entregó; no se presentó acta (30-reuniones/2026-10-11-comite-semanal.md)"
 },
 {
 "who": "Natalia Ospina",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-11-09",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Ricardo Salas",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-31",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Enviar el ajuste del presupuesto (\"la otra semana\")",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-18",
 "documents_seen": [
 {
 "path": "00-gobierno/2025-06-01-acta-constitucion.md",
 "date": "2025-06-01"
 },
 {
 "path": "10-plan/2025-06-01-cronograma-v1.csv",
 "date": "2025-06-01"
 },
 {
 "path": "20-seguimiento/2026-09-20-acta-recibo-7.md",
 "date": "2026-09-20"
 },
 {
 "path": "20-seguimiento/2026-10-04-acta-recibo-10.md",
 "date": "2026-10-04"
 },
 {
 "path": "20-seguimiento/2026-10-17-informe-avance.md",
 "date": "2026-10-17"
 },
 {
 "path": "2026-10-18-notas-reunion.txt",
 "date": "2026-10-18"
 },
 {
 "path": "30-reuniones/2026-09-06-comite-semanal.md",
 "date": "2026-09-06"
 },
 {
 "path": "30-reuniones/2026-09-13-comite-semanal.md",
 "date": "2026-09-13"
 },
 {
 "path": "30-reuniones/2026-09-20-comite-semanal.md",
 "date": "2026-09-20"
 },
 {
 "path": "30-reuniones/2026-09-27-comite-semanal.md",
 "date": "2026-09-27"
 },
 {
 "path": "30-reuniones/2026-10-04-comite-semanal.md",
 "date": "2026-10-04"
 },
 {
 "path": "30-reuniones/2026-10-11-comite-semanal.md",
 "date": "2026-10-11"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
