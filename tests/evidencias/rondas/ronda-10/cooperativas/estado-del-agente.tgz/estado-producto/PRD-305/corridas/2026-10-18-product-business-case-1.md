# Corrida del 2026-10-18 · product-business-case

PRD-305 · 16 requerimientos · 34 s · 27 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_without_owner` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada (volumen_mensual 166.254, sin origen ni unidad), 0 medidas (metrics vacío), costo de construir ausente, retorno sin cifra, criterio de éxito ausente, 12 requerimientos aceptados sin proyecto y 3 sin evidencia de demanda. No se produjeron cifras.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Microcrédito (PRD-305) · borrador del 2026-10-18
**Desde:** definición del 2025-12-01 y caso de negocio del 2025-12-01 · **Cifras con fuente:** 1 de 1 (la única cifra es declarada; ninguna es medida)

Términos vigentes y registrados a nombre de José Francisco Ñáñez (2026-10-18). Este documento es un borrador de trabajo: no produce cifras, no calcula retorno y no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
«El segmento Asociados urbanos no tiene microcrédito.» — `00-definicion/2025-12-01-definicion-producto.md` (El problema), 2025-12-01.
Segmento: Asociados urbanos (misma definición, cabecera).
La propuesta no está escrita: la definición dice solo «Propuesta principal», sin contenido.

## Qué se construye
Entran los 12 requerimientos aceptados del comité del 2026-10-07 (`30-decisiones/2026-10-07-comite-producto.md`). Los 4 propuestos (REQ-4502, 4503, 4504, 4510) quedan fuera del caso hasta que se decidan. Ninguno tiene proyecto que lo ejecute (columna «Proyecto» en «—» en el acta; la definición dice «Ninguno declarado»).

| Requerimiento | Estado (desde) | Doliente | Evidencia de demanda |
|---|---|---|---|
| REQ-4500 | aceptado (2026-08-06) | Felipe Arango | Entrevista 2025-12-30, que no lo nombra. Sin criterio de aceptación |
| REQ-4501 | aceptado (2026-06-16) | Laura Vélez | Entrevista 2025-12-30, que no lo nombra |
| REQ-4505 | aceptado (2026-08-11) | sin asignar | Entrevista 2025-12-30, que no lo nombra |
| REQ-4506 | aceptado (2026-05-31) | sin asignar | Entrevista 2025-12-30, que no lo nombra |
| REQ-4507 | aceptado (2026-07-05) | María Restrepo | **Ninguna**: el acta no dice quién lo pidió |
| REQ-4508 | aceptado (2026-08-25) | María Restrepo | Entrevista 2025-12-30, que no lo nombra |
| REQ-4509 | aceptado (2026-08-29) | Ricardo Salas | Entrevista 2025-12-30, que no lo nombra |
| REQ-4511 | aceptado (2026-05-06) | Laura Vélez | **Ninguna**; además sin criterio de aceptación |
| REQ-4512 | aceptado (2026-08-09) | Elena Duarte | Entrevista 2025-12-30, que no lo nombra |
| REQ-4513 | aceptado (2026-03-28) | Andrés Lozano | Entrevista 2025-12-30, que no lo nombra |
| REQ-4514 | aceptado (2026-08-17) | Javier Hoyos | **Ninguna**: el acta no dice quién lo pidió |
| REQ-4515 | aceptado (2026-08-19) | Laura Vélez | Entrevista 2025-12-30, que no lo nombra |

La «evidencia» de 9 de los 12 es una sola cita de un cliente, anónimo, en la única entrevista de la ronda: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). Respalda que existe la necesidad general; no respalda ningún requerimiento en particular. El acta no dice quién decidió cada aceptación.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 166.254 | **Declarada** | `00-definicion/2025-12-01-caso-de-negocio.md` (Cifras que sostienen el caso). La fuente que cita es el propio caso de negocio: no hay documento de origen más atrás. No dice la unidad (¿créditos?, ¿transacciones?, ¿pesos?) | 2025-12-01 |
| Retorno esperado | «en 24 meses», **sin cifra** | Sin valor | Mismo documento. No es una cifra: no hay porcentaje, monto ni base | 2025-12-01 |

No hay cifras medidas: la carpeta `metrics/` de PRD-305 está vacía, no hay serie contra la cual contrastar.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 166.254 (2025-12-01) | No hay serie medida | No se puede contrastar. Y como el producto no existe todavía («no tiene microcrédito»), no está claro qué sistema mediría un volumen de un producto que aún no opera |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — (ver Vacíos, el primero) |
| Costo del equipo | No declarado | — |
| Contratos / cotizaciones del proveedor | No hay | — |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-25, **sin verificar**; ~146 días, el umbral de la configuración es 30) | Nadie lo ha escrito. Además la definición no nombra proveedor, ni un «tiempo pactado», ni un contrato | Sin asignar |
| **Implícito:** el volumen de 166.254 mensuales es alcanzable | Nadie lo ha escrito: el caso entero (retorno en 24 meses) depende de esta cifra | Sin asignar |
| **Implícito:** una entrevista a un solo cliente basta como demanda del segmento | Nadie lo ha escrito | Sin asignar |

Los dos implícitos son supuestos, no cifras declaradas: se ofrecen para pasarlos a assumption-tracking.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y de operar) | Sin él no hay caso, solo propuesta | Ricardo Salas (gerente de producto) con quien tenga el presupuesto; no se sabe quién |
| Origen y unidad de 166.254 mensuales | Es la única cifra y su fuente es ella misma | Ricardo Salas (autor del caso) |
| Qué significa «Retorno esperado en 24 meses» (cifra, base y cómo se mide) | Sin cifra no es verificable | Ricardo Salas / el negocio |
| Criterio de éxito | Ningún documento lo define | Comité de producto |
| Contenido de la propuesta | La definición dice solo «Propuesta principal» | Ricardo Salas |
| Qué pasa si no se hace | No está en el caso | Ricardo Salas |
| Alternativas consideradas | No están en el caso | Ricardo Salas |
| Proyecto que construye el producto | «Ninguno declarado»: hay 12 requerimientos aceptados sin quien los ejecute | Comité de producto |
| Quién pidió REQ-4507, 4511, 4514; criterio de aceptación de REQ-4500 y 4511; doliente de REQ-4505 y 4506 | Un requerimiento aceptado sin esto no tiene sustento | Comité de producto |
| Más evidencia de demanda que la entrevista del 2025-12-30 (tiene 9,5 meses; el umbral de vigencia es 12) | Una cita sola, anónima, sostiene todo | Ricardo Salas |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento define criterio de éxito, métrica ni fecha de corte. El caso solo dice «Retorno esperado en 24 meses». Sin esto el producto no se podrá cerrar meses después con un resultado verificable. Quien lo define es el Comité de producto; este borrador no lo propone.

## Si hay otros productos publicados
Se buscó la cifra 166.254 en los documentos de los demás productos de la carpeta (PRD-299 a PRD-309) y en el estado de producto: solo aparece en PRD-305. No hay fichas de otros productos publicadas a la vista, así que el cruce solo cubre lo que hay en los documentos; no se detecta métrica doble.

## Después
Se ofrece pasar los supuestos (el del proveedor y los dos implícitos) a assumption-tracking, para que no queden dentro del caso sin que nadie los vuelva a mirar. `/product-charter` solo tiene sentido cuando el caso se apruebe, y para eso falta, como mínimo, el costo.
