# Corrida del 2026-10-18 · product-setup

PRD-305 · 16 requerimientos · 33 s · 27 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_without_owner` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

0 preguntas a la persona (sesión sin interfaz, 4 con respuesta por defecto); tiempo no medido como conversación; 4 documentos, 16 requerimientos levantados; sin criterio de éxito, sin serie de volumen_mensual, 12 aceptados sin proyecto

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que había en la carpeta:** 4 documentos (los 4 en Markdown, todos legibles) · 1 de descubrimiento (una ronda de entrevistas, 2025-12-30) · caso de negocio y definición, ambos del 2025-12-01 · lo más reciente es el acta del comité del 2026-10-07. Sin transcripciones, sin tickets, sin encuestas y sin ninguna serie medida.

**Las cuatro preguntas** (sesión sin interfaz, respuesta por defecto en cada una):
1. Producto: Microcrédito (PRD-305); gerente: Ricardo Salas, tal como lo dice la definición.
2. Quién decide qué se construye: Comité de producto. Es una propuesta mía: el acta no dice quién decide dentro del comité, y el único asistente que registra es Ricardo Salas.
3. Dónde guardo lo que encuentro: `estado-producto/PRD-305`, hermana de `documentos/`.
4. Términos: ver abajo.

## Listo — Microcrédito (PRD-305)

**Lo que miré:** 4 documentos · 1 de descubrimiento · la definición del 2025-12-01
**Términos:** aceptados para la versión 0.5.0 (texto 1.1) por José Francisco Ñáñez, 2026-10-18 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 05a6d511835489a1…

**Levantado desde lo escrito:** `producto.json` y 16 requerimientos (REQ-4500 a REQ-4515, del acta del 2026-10-07): 12 aceptados, 4 propuestos. Ninguno tiene proyecto que lo ejecute.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Los Asociados urbanos no tienen microcrédito | Una sola entrevista: un «cliente entrevistado» dice «Lo necesito y hoy no lo tengo». No dice que sea Asociado urbano ni cuántos más lo viven | 2025-12-30 |
| El volumen mensual será de 166.254 | Solo el propio caso de negocio. Ninguna serie medida a la vista: nadie está midiendo lo que el negocio afirmó | 2025-12-01 |
| El proveedor cumple el tiempo pactado | Un supuesto declarado, sin verificar: 146 días | declarado 2026-05-25 |
| Propuesta principal | Nada: la definición escribe «Propuesta principal» y no dice cuál es | 2025-12-01 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben.
- **El retorno.** «Retorno esperado en 24 meses», sin cifra, sin cálculo y sin fuente.
- **La propuesta.** Qué se va a construir no está escrito.
- **El proyecto.** La definición dice «Ninguno declarado» y los 12 requerimientos aceptados tampoco tienen uno (12 de 12 sin traza). El acta dice «Se mantiene el plan», y ningún documento tiene ese plan.
- **Quién decide dentro del comité.** El acta registra un solo asistente, Ricardo Salas, que además es el gerente y el doliente de REQ-4509. Ninguna decisión del acta tiene «quién decidió».
- **El problema de cada requerimiento.** Los 16 se llaman «Requerimiento REQ-45xx»: el acta no dice qué se necesita.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», sin verificar. Es la única condición escrita de la que depende el producto, y ningún documento dice quién es el proveedor ni cuál es el tiempo pactado. (La definición está fechada el 2025-12-01 y el supuesto, el 2026-05-25: el documento se tocó después de su fecha y nadie lo dice.)

### Qué hay en el registro (cifras de `compute`)
- 12 aceptados, 9 con evidencia (75.0%), 0 con proyecto (0.0%).
- Aceptados sin evidencia: REQ-4507, REQ-4511, REQ-4514 (el acta no dice quién los pidió).
- Aceptados sin criterio de aceptación: REQ-4500, REQ-4511.
- Sin doliente: REQ-4502, REQ-4504, REQ-4505, REQ-4506, REQ-4510 (dos de ellos, REQ-4505 y REQ-4506, ya están aceptados).
- Propuestos sin decidir hace más de 60 días: REQ-4502 (74), REQ-4503 (64), REQ-4504 (84), REQ-4510 (104).
- La evidencia de los otros 12 es la misma entrevista, la única, y no nombra ninguno de los requerimientos: sostiene que hay una necesidad, no que se pidiera cada uno. Todavía no pasa el umbral de 12 meses (`evidence_stale` no se levanta).

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: las transcripciones de las entrevistas (hoy hay una página, de un solo cliente), la serie de `volumen_mensual` con su fuente, el criterio de éxito, y las decisiones del comité con quién decide y por qué: sin ellas un requerimiento descartado se ve igual que uno que nadie miró.

**Siguiente:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién lo pidió.

*Nota técnica:* `sellar` exigió abrir la corrida con `corrida-inicio`, que este comando dice que no lleva; lo hice por eso. El tiempo de la corrida queda medido desde ahí, no desde el inicio de la conversación.
