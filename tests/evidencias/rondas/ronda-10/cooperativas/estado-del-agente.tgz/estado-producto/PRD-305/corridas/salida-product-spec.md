# Especificación — Microcrédito (PRD-305) · borrador del 2026-10-18

**Esto es un borrador. Lo cierra Ricardo Salas (gerente de producto); el agente no aprueba ni decide alcance.**

**Resumen honesto:** del registro salen 12 requerimientos aceptados, pero ninguno tiene escrito el problema que resuelve, y 10 de los 12 traen un criterio de aceptación que no se puede verificar («se verifica en producción»). Por eso este borrador **no tiene sección de comportamiento**: escribirla habría sido inventarla. Lo que sí entrega es el alcance que sale del registro y los vacíos, cada uno con dueño.

## Qué problema resuelve

«El segmento Asociados urbanos no tiene microcrédito.» (`00-definicion/2025-12-01-definicion-producto.md`, «El problema», 2025-12-01).

La propuesta no está dicha: la definición solo dice «Propuesta principal», sin contenido. Tampoco hay criterio de éxito en ningún documento; el caso de negocio dice «Retorno esperado en 24 meses», sin cifra.

## Alcance

### Entra (12 requerimientos en `aceptado`; no hay ninguno en `en_construccion`)

Fuente de todos: `30-decisiones/2026-10-07-comite-producto.md` (2026-10-07).

| REQ | Doliente | Aceptado desde |
|---|---|---|
| REQ-4500 | Felipe Arango | 2026-08-06 |
| REQ-4501 | Laura Vélez | 2026-06-16 |
| REQ-4505 | sin asignar | 2026-08-11 |
| REQ-4506 | sin asignar | 2026-05-31 |
| REQ-4507 | María Restrepo | 2026-07-05 |
| REQ-4508 | María Restrepo | 2026-08-25 |
| REQ-4509 | Ricardo Salas | 2026-08-29 |
| REQ-4511 | Laura Vélez | 2026-05-06 |
| REQ-4512 | Elena Duarte | 2026-08-09 |
| REQ-4513 | Andrés Lozano | 2026-03-28 |
| REQ-4514 | Javier Hoyos | 2026-08-17 |
| REQ-4515 | Laura Vélez | 2026-08-19 |

Los títulos del registro son genéricos («Requerimiento REQ-45xx»): el acta solo los nombra, no los describe.

### No entra

- **REQ-4502, REQ-4503, REQ-4504, REQ-4510**: siguen en `propuesto`; especificarlos sería decidir por el comité. REQ-4502, REQ-4504 y REQ-4510 además están sin doliente.
- **Cualquier propuesta de valor**: la «Propuesta principal» está vacía, así que nada de lo que la desarrolle está en el registro.
- **Todo lo que la definición no menciona**: segmentos distintos de Asociados urbanos, y cualquier requerimiento que no esté en el acta del 2026-10-07.

## Comportamiento

**No redactado.** Para los 12 requerimientos, el campo «necesidad» figura como no encontrado («El acta no dice el problema; solo nombra el requerimiento»). Describir qué hace el producto sería rellenar con lo razonable. Se redacta cuando cada doliente declare el problema de su requerimiento.

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4501, 4505, 4506, 4507, 4508, 4509, 4512, 4513, 4514, 4515 (10) | **No hay forma:** no dice qué se observa, ni con qué umbral. Dos personas mirando lo construido no llegarían a la misma respuesta. | **No es verificable todavía.** Es un hallazgo: es la ubicación de la verificación, no un criterio. |
| *(ninguno)* | REQ-4500, REQ-4511 (2) | — | — |

Este borrador **no propone criterios nuevos**: sin la necesidad de cada requerimiento, cualquier umbral (tiempos, montos, porcentajes) sería inventado. Y tampoco hay evidencia de qué mide hoy la organización.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-05-25, `definicion-producto.md`) | No. 146 días sin verificar; el umbral configurado es 30. | Sin dueño nombrado en los documentos. Propuesto: Ricardo Salas lo asigna. El proveedor ni el «tiempo pactado» están identificados en ningún documento. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Problema/necesidad de los 12 requerimientos** (no está en ninguna parte) | No se puede escribir comportamiento ni criterios; la especificación queda como lista de nombres. | Cada doliente; Ricardo Salas las reúne |
| **Criterio de aceptación**: ausente en REQ-4500 y REQ-4511; no verificable en los otros 10 | Nadie puede decir si lo construido quedó bien; la discusión ocurre después de construir. | Dolientes de cada REQ; Ricardo Salas valida |
| **Doliente de REQ-4505 y REQ-4506** (aceptados «sin asignar») | Aceptados que nadie defiende ni puede aclarar; REQ-4506 lleva aceptado desde 2026-05-31. | Ricardo Salas (comité de producto) |
| **Quién decidió la aceptación**: el campo «quién decidió» está sin dato en los 12 | No se sabe a quién preguntar por qué se aceptó. | Comité de producto (el acta no nombra quién decide dentro de él) |
| **Casos borde**: ningún documento define comportamiento ante fallos, duplicados, abandono o rechazo | Quedan decididos por quien construya. | Dolientes, una vez exista la necesidad |
| **Quién lo pidió**: REQ-4507, REQ-4511 y REQ-4514 están aceptados sin evidencia de demanda; los otros 9 apoyan en una sola entrevista (2025-12-30) que no nombra ningún requerimiento | Se acepta sin que nadie lo haya pedido, o con una cita que no los sustenta. | Ricardo Salas |
| **Proyecto que los construye**: ninguno de los 12 tiene proyecto; la definición dice «Ninguno declarado» | Lo aceptado no tiene quién lo construya. Y el supuesto del proveedor depende de un contrato que no aparece. | Ricardo Salas / Comité de producto |
| **Lo que otro equipo debe hacer**: no hay documento. El proveedor del supuesto es el único tercero que asoma y no está acordado en ninguno. | No se sabe si hay dependencia no negociada. | Ricardo Salas |
| **Obligaciones normativas**: no se hizo el barrido (`regulatory-sweep`). Un microcrédito toca crédito al consumidor y datos personales; ningún documento dice qué obligaciones aplican ni quién responde por ellas. | Una obligación no resuelta aparece cuando ya está construido. | Jurídico/cumplimiento; sin nombre en los documentos. Lo pide Ricardo Salas |
| **Prioridad**: no está en ningún requerimiento | No hay criterio de orden. | Comité de producto |

## Requerimientos aceptados que esta especificación no cubre

Ninguna sección de comportamiento los cubre, por las razones de arriba. Es lo más importante de este borrador:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Sin necesidad escrita; sin criterio de aceptación |
| REQ-4501 | Requerimiento REQ-4501 | Sin necesidad escrita; criterio no verificable |
| REQ-4505 | Requerimiento REQ-4505 | Sin necesidad; sin doliente; criterio no verificable |
| REQ-4506 | Requerimiento REQ-4506 | Sin necesidad; sin doliente; criterio no verificable |
| REQ-4507 | Requerimiento REQ-4507 | Sin necesidad; sin evidencia de quién lo pidió; criterio no verificable |
| REQ-4508 | Requerimiento REQ-4508 | Sin necesidad; criterio no verificable |
| REQ-4509 | Requerimiento REQ-4509 | Sin necesidad; criterio no verificable |
| REQ-4511 | Requerimiento REQ-4511 | Sin necesidad; sin criterio; sin evidencia; aceptado desde 2026-05-06 |
| REQ-4512 | Requerimiento REQ-4512 | Sin necesidad; criterio no verificable |
| REQ-4513 | Requerimiento REQ-4513 | Sin necesidad; criterio no verificable; aceptado desde 2026-03-28 |
| REQ-4514 | Requerimiento REQ-4514 | Sin necesidad; sin evidencia de quién lo pidió; criterio no verificable |
| REQ-4515 | Requerimiento REQ-4515 | Sin necesidad; criterio no verificable |

## Después

**No se ofrece `/product-charter`.** La especificación no tiene los vacíos cerrados, y el producto no tiene criterio de éxito.

---
*Sale del registro `estado-producto/PRD-305/requirements/` (16 requerimientos; 12 aceptados, 4 propuestos), construido sobre el acta del comité del 2026-10-07 y la definición del 2025-12-01. Cubre 12 requerimientos en alcance y 0 con comportamiento especificado. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
