## Definición — Microcrédito (PRD-305) · contrastada al 2026-10-18
**Documento:** `00-definicion/2025-12-01-definicion-producto.md` (con `2025-12-01-caso-de-negocio.md`) · **del** 2025-12-01 · 7 afirmaciones

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ningún documento dice lo contrario de lo que la definición afirma. Pero esto no es buena noticia: casi no hay evidencia con la que contradecir.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque no hay serie medida con la que comparar. Ver la sección siguiente.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 166.254 | Caso de negocio, 2025-12-01 (cifras que sostienen el caso) | No hay serie medida ni fecha de medición. El documento tampoco dice de dónde sale la cifra, ni «volumen» de qué: solicitudes, desembolsos o monto. Nadie está midiendo lo que el negocio afirmó. |

### No está dicho en ninguna parte
- **La propuesta.** La definición dice solo «Propuesta principal», sin contenido: no hay qué se ofrece, a qué monto, plazo o tasa.
- **El criterio de éxito.** Ningún documento lo define. El caso de negocio dice «Retorno esperado en 24 meses», sin cifra y sin cómo se mide.
- **Cuántos son los Asociados urbanos** y cuántos de ellos quieren microcrédito. El tamaño del segmento no aparece.
- **Qué haría el cliente y cuánto pagaría.** Ningún documento recoge disposición a pagar, precio ni compromiso.
- **De dónde sale 166.254** y con qué supuestos se llegó a esa cifra.
- **Qué proveedor, y cuál es el «tiempo pactado»** del supuesto. Sin eso el supuesto no tiene un valor contra el cual verificarlo.
- **Quién decide dentro del Comité de producto.** El acta del 2026-10-07 solo lista a Ricardo Salas como asistente.
- **Qué plan «se mantiene».** La decisión del comité (2026-10-07) dice «Se mantiene el plan», pero ningún documento contiene un plan.
- **Qué proyecto construye el producto.** La definición dice «Ninguno declarado»; los 12 requerimientos aceptados siguen sin proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-05-25) | 146 (umbral: 30) | Nombrar al proveedor y escribir el tiempo pactado con su fuente (contrato u oferta); luego una fecha de entrega comprobada contra ese plazo, o un acta de recibo. Hoy no hay ninguno de los dos. |

Nota de fechas: el supuesto aparece declarado el 2026-05-25 dentro de un documento fechado 2025-12-01; el documento se editó después sin cambiar su fecha, o una de las dos fechas está mal. No lo resuelvo; lo señalo.

Todavía no es un riesgo registrado. Ofrezco convertirlo en riesgo con doliente (raid-taxonomy), porque a 146 días ya lo es.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento no tiene microcrédito | Una entrevista a un cliente: «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2025-12-30-entrevistas.md`, tema «Necesidad principal») | 2025-12-30 | **Débil.** Es una persona diciendo que lo usaría; nadie pagó ni se comprometió. La entrevista no dice si es del segmento Asociados urbanos. |
| El segmento es Asociados urbanos | La propia definición | 2025-12-01 | Es una decisión de alcance, no una afirmación que se contraste. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento no tiene microcrédito | Entrevista del 2025-12-30 | ~9,6 meses. Aún bajo el umbral de 12 meses; lo cruza el 2026-12-30. Es la única evidencia de demanda del producto. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Crédito a personas (consumidor financiero) | No declarado en la configuración ni en los documentos | — | — | No tengo la norma a la vista |
| Datos personales de los asociados | No declarado | — | — | No tengo la norma a la vista |
| Retención de información | No declarado | — | — | No tengo la norma a la vista |

Un microcrédito toca por naturaleza esas tres áreas, pero ningún documento dice el país ni la entidad supervisora, así que no cito ninguna norma. Esto no dice que cumpla ni que no cumpla; eso va a revisión jurídica.

### Lo que falta para cerrar la definición
- **Criterio de éxito: no declarado.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- Problema y para quién: están (una frase cada uno).
- Quién decide: el Comité de producto; falta quién dentro de él.
- Además falta la propuesta, que está vacía.

**Después:** la definición no está cerrada, así que no ofrezco `/product-charter`.
