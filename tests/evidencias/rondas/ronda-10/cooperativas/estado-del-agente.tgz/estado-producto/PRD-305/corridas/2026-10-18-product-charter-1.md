# Corrida del 2026-10-18 · product-charter

PRD-305 · 16 requerimientos · 28 s · 27 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_without_owner` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

Borrador de acta de REQ-4500, sin firmar y sin ficha creada. Declaró vacíos: criterios de aceptación, necesidad, autoridad, patrocinador, gerente, evidencia específica y barrido normativo.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Microcrédito (REQ-4500) · borrador del 2026-10-18
**Producto:** PRD-305 Microcrédito · **Requerimientos:** REQ-4500

> **Términos:** vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta volver a registrarlos.
> **Verificación previa (requirement-record):** REQ-4500 está **aceptado** (acta del comité 2026-10-07). **Faltan tres cosas:** criterios de aceptación, necesidad redactada y autoridad del gerente. Sin respuesta de nadie en esta sesión, se sigue **marcándolas como vacíos del acta** (la respuesta sugerida) y no se rellenan.

## Qué problema resuelve
Del producto: «El segmento Asociados urbanos no tiene microcrédito.»
(`documentos/productos/PRD-305/00-definicion/2025-12-01-definicion-producto.md`, «El problema»).
Del requerimiento: **no está dicho.** El acta del comité solo nombra «Requerimiento REQ-4500», sin descripción
(`30-decisiones/2026-10-07-comite-producto.md`).

## Criterio de éxito
**No definido.** Es un vacío.
- REQ-4500 no tiene criterio de aceptación: la columna del acta del comité trae «—».
- El producto tampoco define éxito: el caso de negocio dice solo «Retorno esperado en 24 meses», sin cifra (`00-definicion/2025-12-01-caso-de-negocio.md`).
- La propuesta de la definición dice solo «Propuesta principal», sin contenido.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4500 | «Requerimiento REQ-4500» (sin descripción de la necesidad) | Una entrevista: «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, 2025-12-30, tema «Necesidad principal»; `10-descubrimiento/2025-12-30-entrevistas.md`). **La entrevista no nombra este requerimiento**, tiene casi 10 meses y es la única de la ronda. Evidencia débil, y no es específica de REQ-4500. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4501 … REQ-4515 | los demás del acta del comité de 2026-10-07 | Esta acta solo cubre REQ-4500. **Ningún documento dice por qué quedan fuera**, y no se inventa la razón. Quien firme debe confirmarlo (ver vacíos). |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. La definición nombra a **Ricardo Salas** como *gerente de producto*, que es otro rol. Este comando propone, no nombra.
- **Comité:** Comité de producto (acta 2026-10-07; asistió solo Ricardo Salas).
- **Autoridad del gerente:** **no está dicha.** La autoridad de producto, «Comité de producto», se propuso en la instalación y el acta no dice quién decide dentro del comité.
- **Doliente del requerimiento:** Felipe Arango (acta del comité 2026-10-07).
- **Quién decidió aceptarlo:** no consta. La decisión aparece como «aceptado» con fecha 2026-08-06, anterior al acta que la recoge.
- **Prioridad:** no está dicha.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-05-25; `00-definicion/2025-12-01-definicion-producto.md`) | No | Riesgo del proyecto, a registrar con doliente (a asignar por el gerente del proyecto). Ningún documento dice qué proveedor ni qué tiempo se pactó. Además, la fecha de declaración es posterior a la del documento. |

REQ-4500 no declara supuestos propios.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito a asociados (consumidor financiero, datos personales) | No barrido. Ningún documento del producto cita obligaciones. | — | **Sin resolver.** Falta correr el barrido normativo antes de firmar. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4500 | El cierre no se puede juzgar meses después: no hay contra qué medir el éxito. | Felipe Arango (doliente), con Ricardo Salas |
| Necesidad del requerimiento (qué problema resuelve) | El proyecto arranca sin saber qué construye. | Felipe Arango |
| Criterio de éxito del producto y cifra del retorno | El «retorno en 24 meses» no es verificable. | Ricardo Salas |
| Autoridad del gerente del proyecto | El gerente escala todo o no escala nada. | Comité de producto |
| Patrocinador y gerente propuesto | No hay quién firme ni quién reciba la ficha. | Comité de producto |
| Evidencia de demanda específica de REQ-4500 | Se construye sobre una frase genérica que no lo nombra. | Ricardo Salas |
| Quién decidió la aceptación | No se puede rastrear la decisión. | Comité de producto |
| Razón de exclusión de REQ-4501 … REQ-4515 | Discusión de alcance al tercer mes. | Ricardo Salas |
| Cifra «volumen_mensual 166.254»: sin unidad ni fuente más allá del propio caso de negocio | No contrastable con datos. | Ricardo Salas |

---
**Esto es un borrador.** Lo firma una persona con autoridad; **este comando no firma ni da por firmado.**
No se creó la ficha del proyecto (`portafolio.py init`): se crea después de la firma. El estado declarado nunca lo escribe este agente.

**Qué sigue, y para quién:** quien sea nombrado gerente del proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella. Desde ahí, Alba sabe si su producto se está construyendo sin preguntarle a nadie.
