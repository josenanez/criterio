**No publiqué nada.** La configuración de PRD-305 (`.criterio/producto/PRD-305/config.json`) no define una carpeta de productos publicados (solo `paths.documents` y `paths.state`), y no existe ninguna `publicados/` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé la ruta ni creé la carpeta.

**Lo que habría llevado la ficha (corte 2026-10-18):**
- **Requerimientos:** 16 (12 aceptados, 4 propuestos) · **Proyectos:** 0 (ningún requerimiento está trazado a un proyecto) · **Métricas afirmadas:** 1
- **Segmento declarado:** Asociados urbanos
- **Métrica:** volumen_mensual, 166254.0, de `documentos/productos/PRD-305/00-definicion/2025-12-01-caso-de-negocio.md` (Cifras que sostienen el caso), fechada 2025-12-01; sin medición contra la que contrastarla.

**Para publicar:** acordar la carpeta común y agregarla a la configuración; luego se corre de nuevo.
