# Corrida del 2026-10-18 · product-trace

PRD-305 · 16 requerimientos · 36 s · 27 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 12 |
| `requirement_without_owner` | 5 |
| `requirement_undecided` | 4 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |

12 decididos y ninguno con proyecto; PRY-207 dice ejecutar microcrédito y ningún REQ lo nombra

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Microcrédito (PRD-305) · al 2026-10-18
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: 13 (PRY-199 a PRY-211, en `estado/records`). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

### Decidido y nadie lo está construyendo
Los 12 requerimientos aceptados tienen la columna «Proyecto que lo ejecuta» en «—» en el acta del comité de producto del 2026-10-07 (`documentos/productos/PRD-305/30-decisiones/2026-10-07-comite-producto.md`), y esa acta decide solo «Se mantiene el plan». Ninguno entró en el alcance de un proyecto, según el registro.

| REQ | Título | Decidido el | Doliente |
|---|---|---|---|
| REQ-4513 | Requerimiento REQ-4513 | 2026-03-28 | Andrés Lozano |
| REQ-4511 | Requerimiento REQ-4511 | 2026-05-06 | Laura Vélez |
| REQ-4506 | Requerimiento REQ-4506 | 2026-05-31 | sin asignar |
| REQ-4501 | Requerimiento REQ-4501 | 2026-06-16 | Laura Vélez |
| REQ-4507 | Requerimiento REQ-4507 | 2026-07-05 | María Restrepo |
| REQ-4500 | Requerimiento REQ-4500 | 2026-08-06 | Felipe Arango |
| REQ-4512 | Requerimiento REQ-4512 | 2026-08-09 | Elena Duarte |
| REQ-4505 | Requerimiento REQ-4505 | 2026-08-11 | sin asignar |
| REQ-4514 | Requerimiento REQ-4514 | 2026-08-17 | Javier Hoyos |
| REQ-4515 | Requerimiento REQ-4515 | 2026-08-19 | Laura Vélez |
| REQ-4508 | Requerimiento REQ-4508 | 2026-08-25 | María Restrepo |
| REQ-4509 | Requerimiento REQ-4509 | 2026-08-29 | Ricardo Salas |

Nota: la columna es «doliente» (dueño del requerimiento). El acta no registra quién tomó cada decisión de aceptar. Los títulos son genéricos en el registro.
El de mayor antigüedad es REQ-4513, con 204 días desde que se planteó.

### La traza no se confirma
Ningún requerimiento dice ejecutarlo un proyecto, así que no hay traza que confirmar ni desacuerdo entre registro y ficha.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-207 · Microcrédito rural | Sí: «microcrédito» (acta de constitución 2026-04-16, `PRY-207-microcrédito-rural/00-gobierno/2026-04-16-acta-constitucion.docx`) | Sí: ninguno de los 16 REQ lo nombra |

Matiz: la ficha escribe el nombre del producto («microcrédito»), no el código PRD-305, y el proyecto es «rural» mientras la definición de PRD-305 habla de «Asociados urbanos». Puede ser este producto o uno vecino. Hay que ir a ver; esto no lo decide.
Otros 7 proyectos nombran otros productos y 5 (PRY-202, 205, 208, 209, 210) tienen el campo producto vacío en su ficha. Eso último es un hallazgo de ese lado, no de este registro.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4500, 4501, 4505, 4506, 4507, 4508, 4509, 4511, 4512, 4513, 4514, 4515 | aceptado | comité de producto, acta 2026-10-07 (fechas arriba) | — (cadena rota aquí) | no | — |
| REQ-4502, 4503, 4504, 4510 | propuesto | sin decidir (64 a 104 días) | — | no | — |

La cadena se rompe en el eslabón decisión → proyecto, en los 12 aceptados. Los 4 propuestos no tienen decisión, así que no entran en la brecha de lo decidido.

### Sin fichas a la vista
No aplica a ningún proyecto con traza, porque ninguno la tiene. Las 13 fichas estaban disponibles.
