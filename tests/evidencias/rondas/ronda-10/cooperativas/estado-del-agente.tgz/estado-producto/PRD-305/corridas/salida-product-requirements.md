## Registro — Microcrédito (PRD-305) · al 2026-10-18
16 requerimientos · 12 decididos · 75% con evidencia · 0% con proyecto que lo ejecuta

*Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta registrarlos de nuevo.*

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4511 | Requerimiento REQ-4511 | aceptado el 2026-05-06 | Laura Vélez |
| REQ-4507 | Requerimiento REQ-4507 | aceptado el 2026-07-05 | María Restrepo |
| REQ-4514 | Requerimiento REQ-4514 | aceptado el 2026-08-17 | Javier Hoyos |

Ninguno tiene una sola cita de quien lo pidió. Además, el acta del comité solo los nombra: no dice el problema.

### Decidido y nadie lo está construyendo
Los 12 aceptados (REQ-4500, 4501, 4505, 4506, 4507, 4508, 4509, 4511, 4512, 4513, 4514, 4515) no tienen proyecto en ninguna ficha de `estado/`. Los más viejos:
| REQ | Título | Decidido el | |
|---|---|---|---|
| REQ-4513 | Requerimiento REQ-4513 | 2026-03-28 | hace 204 días |
| REQ-4511 | Requerimiento REQ-4511 | 2026-05-06 | hace 165 días |
| REQ-4506 | Requerimiento REQ-4506 | 2026-05-31 | hace 140 días |
| REQ-4501 | Requerimiento REQ-4501 | 2026-06-16 | hace 124 días |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4505 | Requerimiento REQ-4505 | sin doliente (aceptado) |
| REQ-4506 | Requerimiento REQ-4506 | sin doliente (aceptado) |
| REQ-4502 | Requerimiento REQ-4502 | «sin asignar» (propuesto) |
| REQ-4504 | Requerimiento REQ-4504 | sin doliente (propuesto) |
| REQ-4510 | Requerimiento REQ-4510 | sin doliente (propuesto) |

Quién lo cierra: Ricardo Salas (gerente de producto) nombra al doliente de los dos aceptados; los tres propuestos lo reciben cuando el comité los decida.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | aceptado |
| REQ-4511 | Requerimiento REQ-4511 | aceptado |

Quién lo cierra: sus dolientes, Felipe Arango (REQ-4500) y Laura Vélez (REQ-4511).

### Decidido sin documento que lo respalde
Los 12 aceptados citan el acta del comité del 2026-10-07 como fuente de la decisión, pero en ninguno el acta dice **quién** decidió. Es un vacío de forma: el documento existe, falta el nombre. La facultad es del Comité de producto.

Sobre el sustento de la demanda, véase «Se va a construir y nadie lo pidió» (REQ-4507, 4511, 4514, sin evidencia).

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4510 | Requerimiento REQ-4510 | 104 días (2026-07-06) | Comité de producto |
| REQ-4504 | Requerimiento REQ-4504 | 84 días (2026-07-26) | Comité de producto |
| REQ-4502 | Requerimiento REQ-4502 | 74 días (2026-08-05) | Comité de producto |
| REQ-4503 | Requerimiento REQ-4503 | 64 días (2026-08-15) | Comité de producto |

Propuesta: llevarlos a decisión en el próximo comité mensual (aceptar o descartar). No se cierran por viejos. REQ-4502 tiene como única evidencia una entrevista que no nombra el requerimiento.

### Evidencia vieja
Sin hallazgo: lo más nuevo que sostiene los requerimientos es del 2025-12-30 (unos 9,6 meses), por debajo del umbral de 12 meses. Cruzará el umbral hacia el 2026-12-30.

### Fuera del registro, pero en la definición
- Supuesto sin verificar hace 146 días: «El proveedor cumple el tiempo pactado» (umbral 30 días).
- La definición no declara criterio de éxito.
- La cifra declarada `volumen_mensual` = 166.254 (caso de negocio, 2025-12-01) no tiene medición contra la que contrastarla.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 12 | 0 | 0 | 0 |

Señales: sin trazabilidad 12 · sin doliente 5 · sin decidir 4 · aceptado sin evidencia 3 · sin criterio de aceptación 2 · supuesto sin verificar 1.

**Siguiente paso:** `/product-trace` para los 12 decididos que nadie construye. Para `/product-charter`, los que ya están aceptados, con evidencia, con criterio y con doliente son REQ-4501, 4508, 4509, 4512, 4513 y 4515.
