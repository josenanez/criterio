## Microcrédito (PRD-305) · 2026-10-18

**Primera revisión: no hay corte anterior**, así que nada se puede llamar "cruzó desde el corte". Lo de abajo es la línea base. Desde la próxima corrida solo se reportará lo que cambie. Plan de lectura: 4 documentos, ninguno nuevo ni cambiado; solo se recalculó.

**Cifras:** 16 requerimientos, 12 aceptados y 4 propuestos. 9 de 16 tienen evidencia (75 %). 0 de 16 tienen traza a un proyecto (0 %).

### Lo que necesita decisión (para el comité)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 d) | REQ-4510 | 104 días, desde 2026-07-06 | Sin doliente. Hace falta que alguien con facultad lo decida | Comité de producto; doliente sin nombrar |
| Propuesto sin decidir | REQ-4504 | 84 días, desde 2026-07-26 | Sin doliente y sin evidencia. Decidir si se sostiene | Comité de producto; doliente sin nombrar |
| Propuesto sin decidir | REQ-4502 | 74 días, desde 2026-08-05 | Sin doliente ni criterio de aceptación | Comité de producto; doliente sin nombrar |
| Propuesto sin decidir | REQ-4503 | 64 días, desde 2026-08-15 | Decisión del comité | Elena Duarte (doliente) |
| Supuesto sin verificar (umbral 30 d) | "El proveedor cumple el tiempo pactado" | 146 días | Hace falta una verificación contra el proveedor. Pasado el umbral conviene tratarlo como riesgo registrado (assumption-tracking) | Ricardo Salas (gerente de producto) |

### Aceptados que nadie está construyendo
Los 12 aceptados están sin traza: REQ-4500, 4501, 4505 a 4509 y 4511 a 4515. Los más viejos son REQ-4513 (aceptado el 2026-03-28), REQ-4511 (2026-05-06) y REQ-4506 (2026-05-31).

**Trazas:** con la carpeta de fichas a la vista (13 fichas, `estado/records`), ninguna ficha de proyecto nombra a PRD-305 ni a sus REQ. No hay ninguna traza para confirmar. Tampoco se perdió ninguna.

### Aceptados con huecos
- Sin evidencia de demanda: REQ-4507, REQ-4511 y REQ-4514.
- Sin criterio de aceptación: REQ-4500 y REQ-4511. REQ-4511 además no tiene evidencia.
- Aceptados sin doliente: REQ-4505 y REQ-4506.

### Del descubrimiento
No hay documentos nuevos. Todo el sustento sigue siendo de una sola fecha, 2025-12-30. Con el umbral de 12 meses, esa evidencia se vence el 2026-12-30.

### Lo que el registro no sabe
- El éxito del producto (`success`) no está definido en ningún documento.
- La cifra declarada del caso de negocio (volumen mensual 166.254, del 2025-12-01) no tiene medición contra la cual contrastarla. No hay serie en `metrics`, así que no se puede decir si hay brecha.
- El inventario marcó como "fuente no encontrada" 7 campos de identidad y definición. Parece un problema de ruta relativa de las citas, no de contenido; conviene revisarlo antes del comité.

**Vuelvo el 2026-11-17.**
