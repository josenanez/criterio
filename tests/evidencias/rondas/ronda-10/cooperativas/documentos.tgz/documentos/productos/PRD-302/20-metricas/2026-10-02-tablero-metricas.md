# Tablero de métricas · Aportes sociales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 98.057 | 2026-10-02 |
