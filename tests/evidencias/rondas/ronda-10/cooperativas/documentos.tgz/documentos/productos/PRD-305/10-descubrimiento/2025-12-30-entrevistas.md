# Entrevistas · Microcrédito

**Ronda:** Ronda · 2025-12-30
**Realizadas por:** Ricardo Salas

### Cliente entrevistado · 2025-12-30

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
