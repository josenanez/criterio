# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-04-25
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 63.603 | Caso de negocio, 2026-04-25 |

## Retorno esperado

Retorno esperado en 24 meses.
