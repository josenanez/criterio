# Tablero de métricas · Ahorro a la vista

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 253.213 | 2026-10-08 |
