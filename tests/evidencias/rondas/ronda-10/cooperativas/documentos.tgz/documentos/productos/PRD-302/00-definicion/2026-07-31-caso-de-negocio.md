# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2026-07-31
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 163.069 | Caso de negocio, 2026-07-31 |

## Retorno esperado

Retorno esperado en 24 meses.
