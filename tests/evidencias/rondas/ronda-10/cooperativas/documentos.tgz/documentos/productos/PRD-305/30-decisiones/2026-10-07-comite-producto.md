# Comité de producto · Microcrédito

**Fecha:** 2026-10-07
**Asistentes:** Ricardo Salas

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4501 | Requerimiento REQ-4501 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4502 | Requerimiento REQ-4502 | sin asignar | — | Cliente entrevistado | propuesto | 2026-08-05 | — |
| REQ-4503 | Requerimiento REQ-4503 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-15 | — |
| REQ-4504 | Requerimiento REQ-4504 | sin asignar | se verifica en producción | — | propuesto | 2026-07-26 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4506 | Requerimiento REQ-4506 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4507 | Requerimiento REQ-4507 | María Restrepo | se verifica en producción | — | aceptado | 2026-07-05 | — |
| REQ-4508 | Requerimiento REQ-4508 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4509 | Requerimiento REQ-4509 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-29 | — |
| REQ-4510 | Requerimiento REQ-4510 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-06 | — |
| REQ-4511 | Requerimiento REQ-4511 | Laura Vélez | — | — | aceptado | 2026-05-06 | — |
| REQ-4512 | Requerimiento REQ-4512 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-09 | — |
| REQ-4513 | Requerimiento REQ-4513 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-28 | — |
| REQ-4514 | Requerimiento REQ-4514 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-08-17 | — |
| REQ-4515 | Requerimiento REQ-4515 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-19 | — |

## Decisiones

- Se mantiene el plan
