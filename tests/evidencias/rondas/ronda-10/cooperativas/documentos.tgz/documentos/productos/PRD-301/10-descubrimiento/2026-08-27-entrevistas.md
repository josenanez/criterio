# Entrevistas · Ahorro a la vista

**Ronda:** Ronda · 2026-08-27
**Realizadas por:** Diana Molina

### Cliente entrevistado · 2026-08-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
