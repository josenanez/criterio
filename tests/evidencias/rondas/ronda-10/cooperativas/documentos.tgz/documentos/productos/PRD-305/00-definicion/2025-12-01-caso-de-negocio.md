# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2025-12-01
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 166.254 | Caso de negocio, 2025-12-01 |

## Retorno esperado

Retorno esperado en 24 meses.
