# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2025-10-25
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 290.195 | Caso de negocio, 2025-10-25 |

## Retorno esperado

Retorno esperado en 24 meses.
