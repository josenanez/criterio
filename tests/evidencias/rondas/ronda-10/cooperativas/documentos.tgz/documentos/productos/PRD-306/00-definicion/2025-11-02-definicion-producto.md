# Definición de producto · Recaudos

**Código:** PRD-306
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Asociados rurales
**Fecha de la definición:** 2025-11-02

## El problema

El segmento Asociados rurales no tiene recaudos.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-03-25 · verificado con la entrevista con doce clientes del segmento del 2026-06-05 (anexo «Verificación del supuesto» del 2026-06-05)

## Proyectos que lo construyen

- Ninguno declarado
