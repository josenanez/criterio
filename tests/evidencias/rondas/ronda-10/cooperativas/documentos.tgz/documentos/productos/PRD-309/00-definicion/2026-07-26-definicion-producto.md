# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Asociados rurales
**Fecha de la definición:** 2026-07-26

## El problema

El segmento Asociados rurales no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-09-17 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
