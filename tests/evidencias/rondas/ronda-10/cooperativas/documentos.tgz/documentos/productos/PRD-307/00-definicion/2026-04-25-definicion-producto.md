# Definición de producto · Auxilios de solidaridad

**Código:** PRD-307
**Gerente de producto:** Gustavo Neira
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-04-25

## El problema

El segmento Microempresarios no tiene auxilios de solidaridad.

## La propuesta

- Propuesta principal

## Supuestos

- **El core soporta el volumen** · declarado el 2026-04-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
