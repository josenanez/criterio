# Comité de producto · Crédito de libranza

**Fecha:** 2026-10-12
**Asistentes:** Paula Céspedes

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-08-13 | — |
| REQ-4001 | Requerimiento REQ-4001 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4002 | Requerimiento REQ-4002 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-05-17 | — |
| REQ-4003 | Requerimiento REQ-4003 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-27 | — |
| REQ-4004 | Requerimiento REQ-4004 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-04 | — |
| REQ-4005 | Requerimiento REQ-4005 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-12 | — |
| REQ-4006 | Requerimiento REQ-4006 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-20 | — |
| REQ-4007 | Requerimiento REQ-4007 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-07-14 | — |
| REQ-4008 | Requerimiento REQ-4008 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-04-15 | — |
| REQ-4009 | Requerimiento REQ-4009 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-14 | — |
| REQ-4010 | Requerimiento REQ-4010 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-03-22 | — |
| REQ-4011 | Requerimiento REQ-4011 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4012 | Requerimiento REQ-4012 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4013 | Requerimiento REQ-4013 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-06 | — |

## Decisiones

- Se mantiene el plan
