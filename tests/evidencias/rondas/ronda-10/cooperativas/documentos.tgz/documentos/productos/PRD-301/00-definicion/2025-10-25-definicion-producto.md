# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Diana Molina
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-10-25

## El problema

El segmento Asociados urbanos no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-05-23 · verificado con el concepto jurídico de cumplimiento del 2026-09-20 (anexo «Verificación del supuesto» del 2026-09-20)

## Proyectos que lo construyen

- Ninguno declarado
