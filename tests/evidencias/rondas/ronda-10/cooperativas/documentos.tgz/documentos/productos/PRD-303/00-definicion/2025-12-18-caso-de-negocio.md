# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2025-12-18
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 165.425 | Caso de negocio, 2025-12-18 |

## Retorno esperado

Retorno esperado en 24 meses.
