# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2026-07-26
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 278.919 | Caso de negocio, 2026-07-26 |

## Retorno esperado

Retorno esperado en 24 meses.
