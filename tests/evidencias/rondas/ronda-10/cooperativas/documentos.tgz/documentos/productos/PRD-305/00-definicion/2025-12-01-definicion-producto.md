# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** Ricardo Salas
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2025-12-01

## El problema

El segmento Asociados urbanos no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-25 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
