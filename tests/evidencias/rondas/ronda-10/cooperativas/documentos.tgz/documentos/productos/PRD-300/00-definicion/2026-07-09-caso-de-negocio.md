# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-07-09
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.825 | Caso de negocio, 2026-07-09 |

## Retorno esperado

Retorno esperado en 24 meses.
