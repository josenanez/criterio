# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 109.629 | 2026-10-01 |
