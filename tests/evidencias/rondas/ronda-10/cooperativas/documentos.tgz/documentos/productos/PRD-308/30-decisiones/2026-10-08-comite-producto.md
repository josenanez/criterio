# Comité de producto · Remesas familiares

**Fecha:** 2026-10-08
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-25 | — |
| REQ-4801 | Requerimiento REQ-4801 | Carlos Peña | se verifica en producción | — | propuesto | 2026-06-25 | — |
| REQ-4802 | Requerimiento REQ-4802 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-11 | — |
| REQ-4803 | Requerimiento REQ-4803 | Carlos Peña | se verifica en producción | — | propuesto | 2026-05-12 | — |
| REQ-4804 | Requerimiento REQ-4804 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-11 | — |
| REQ-4805 | Requerimiento REQ-4805 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-13 | — |
| REQ-4806 | Requerimiento REQ-4806 | Elena Duarte | se verifica en producción | — | propuesto | 2026-06-08 | — |
| REQ-4807 | Requerimiento REQ-4807 | Rubén Cárdenas | — | — | aceptado | 2026-05-29 | — |
| REQ-4808 | Requerimiento REQ-4808 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-14 | — |
| REQ-4809 | Requerimiento REQ-4809 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-29 | — |
| REQ-4810 | Requerimiento REQ-4810 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-4811 | Requerimiento REQ-4811 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-07 | — |

## Decisiones

- Se mantiene el plan
