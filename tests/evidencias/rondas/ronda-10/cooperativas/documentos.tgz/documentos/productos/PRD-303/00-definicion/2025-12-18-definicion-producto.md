# Definición de producto · Tarjeta débito

**Código:** PRD-303
**Gerente de producto:** Laura Vélez
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-12-18

## El problema

El segmento Jóvenes no tiene tarjeta débito.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-11 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
