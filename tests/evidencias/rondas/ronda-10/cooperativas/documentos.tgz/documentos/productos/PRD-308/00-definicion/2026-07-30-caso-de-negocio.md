# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-07-30
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 139.244 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
