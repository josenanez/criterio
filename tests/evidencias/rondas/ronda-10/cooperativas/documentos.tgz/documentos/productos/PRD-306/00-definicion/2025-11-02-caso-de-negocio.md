# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-11-02
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 88.464 | Caso de negocio, 2025-11-02 |

## Retorno esperado

Retorno esperado en 24 meses.
