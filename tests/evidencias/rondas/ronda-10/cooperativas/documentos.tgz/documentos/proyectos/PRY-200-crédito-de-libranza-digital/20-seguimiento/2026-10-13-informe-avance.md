# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-13
**Gerente:** Gustavo Neira

## Estado declarado

**Rojo**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 7.409.726.138 |
| Ejecutado | 10.475.680.794 |
| Proyección al cierre | 20.616.543.260 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Dependencia del proveedor del core cooperativo
