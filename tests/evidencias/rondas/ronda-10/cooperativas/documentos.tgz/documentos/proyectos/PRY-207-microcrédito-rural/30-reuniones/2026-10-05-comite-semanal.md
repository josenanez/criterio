# Comité de Crédito · Microcrédito rural

**Fecha:** 2026-10-05
**Asistentes:** Beatriz Cuéllar, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 33 | 2026-10-02 |
