# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Operaciones
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Riesgos
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-05-13

## Objetivo del negocio

Entregar pagos con qr para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Riesgos el 2026-05-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-23 |
| Cierre | 2027-09-15 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
