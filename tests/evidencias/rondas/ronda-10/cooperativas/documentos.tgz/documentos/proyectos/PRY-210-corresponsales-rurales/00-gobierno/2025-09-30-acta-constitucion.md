# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Liliana Torres
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-30

## Objetivo del negocio

Entregar corresponsales rurales para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Consejo de Administración el 2025-09-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-10 |
| Cierre | 2026-06-17 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
