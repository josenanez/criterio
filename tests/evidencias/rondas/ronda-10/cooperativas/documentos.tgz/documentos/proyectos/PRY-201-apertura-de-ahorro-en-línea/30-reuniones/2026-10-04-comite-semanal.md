# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-10-04
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Gustavo Neira, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-27 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-20 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-04 |
| Diana Molina | Validar el ambiente 4 | 2026-11-13 |
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-11-04 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-15 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-13 |
| Laura Vélez | Enviar el documento 9 | 2026-10-06 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-18 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-20 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-21 |
| Laura Vélez | Confirmar la fecha 15 | por definir |
| Beatriz Cuéllar | Entregar el punto 16 | 2026-11-06 |
| Gustavo Neira | Enviar el documento 17 | 2026-10-22 |
| Natalia Ospina | Cerrar la prueba 18 | 2026-10-23 |
| Ricardo Salas | Revisar el anexo 19 | 2026-10-28 |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 |

## Cerrados en esta reunión

- Cerrar la prueba 10 (Jorge Medina): recibido, acta de recibo del 2026-10-04.
