# Acta de constitución · Cambio de mobiliario de agencias

**Código:** PRY-199
**Área dueña:** Crédito
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Consejo de Administración
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-10

## Objetivo del negocio

Entregar cambio de mobiliario de agencias para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Consejo de Administración el 2026-06-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-20 |
| Cierre | 2027-12-17 |

## Criterio de éxito

Cambio de mobiliario de agencias en producción y medido.

## Dependencias declaradas

- Ninguna declarada
