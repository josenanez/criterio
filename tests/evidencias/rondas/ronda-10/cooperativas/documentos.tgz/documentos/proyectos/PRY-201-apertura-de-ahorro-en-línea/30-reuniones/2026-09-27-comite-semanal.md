# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-09-27
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-11-10 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-11-05 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-04 |
| Diana Molina | Validar el ambiente 4 | 2026-10-31 |
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-10-20 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-15 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-13 |
| Laura Vélez | Enviar el documento 9 | 2026-10-06 |
| Jorge Medina | Cerrar la prueba 10 | 2026-10-20 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-18 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-10 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-02 |
| Laura Vélez | Confirmar la fecha 15 | por definir |
| Beatriz Cuéllar | Entregar el punto 16 | 2026-10-21 |

## Lo que se dijo

- Andrés Lozano dice que ya entregó «revisar el anexo 11». No se presentó acta.
