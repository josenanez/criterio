# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-17
**Gerente:** Liliana Torres

## Estado declarado

**Amarillo**

Avance reportado: **69%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.884.749.015 |
| Ejecutado | 660.737.359 |
| Proyección al cierre | 2.395.222.885 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
- Cambio normativo del supervisor que puede mover el alcance
