# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-13
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.884.995.084 |
| Ejecutado | 556.812.565 |
| Proyección al cierre | 2.471.500.191 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
