# Comité de Riesgos · Motor de crédito

**Fecha:** 2026-10-12
**Asistentes:** Felipe Arango, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 38 | por definir |
