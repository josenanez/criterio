# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-18
**Asistentes:** Diana Molina, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 6 | por definir |
