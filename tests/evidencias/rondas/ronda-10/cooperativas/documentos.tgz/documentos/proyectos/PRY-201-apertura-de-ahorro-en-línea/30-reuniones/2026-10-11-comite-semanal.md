# Comité de Crédito · Apertura de ahorro en línea

**Fecha:** 2026-10-11
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Enviar el documento 1 | 2026-12-06 |
| Paula Céspedes | Cerrar la prueba 2 | 2026-12-02 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-04 |
| Diana Molina | Validar el ambiente 4 | 2026-11-22 |
| Beatriz Cuéllar | Aprobar el diseño 5 | 2026-11-04 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-15 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-30 |
| Laura Vélez | Enviar el documento 9 | 2026-10-20 |
| Mauricio Pérez | Validar el ambiente 12 | 2026-10-18 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-11-09 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-21 |
| Laura Vélez | Confirmar la fecha 15 | por definir |
| Beatriz Cuéllar | Entregar el punto 16 | 2026-11-06 |
| Natalia Ospina | Cerrar la prueba 18 | 2026-11-09 |
| Ricardo Salas | Revisar el anexo 19 | 2026-10-28 |
| Natalia Ospina | Validar el ambiente 20 | 2026-10-07 |
| Sandra Gil | Aprobar el diseño 21 | 2026-10-14 |
| Liliana Torres | Actualizar la matriz 22 | 2026-10-31 |
| Laura Vélez | Confirmar la fecha 23 | 2026-10-18 |
| Ricardo Salas | Entregar el punto 24 | 2026-10-27 |

## Lo que se dijo

- Gustavo Neira dice que ya entregó «enviar el documento 17». No se presentó acta.
