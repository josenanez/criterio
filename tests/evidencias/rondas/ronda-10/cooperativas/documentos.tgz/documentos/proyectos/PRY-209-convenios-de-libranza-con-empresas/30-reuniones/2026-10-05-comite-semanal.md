# Comité de Riesgos · Convenios de libranza con empresas

**Fecha:** 2026-10-05
**Asistentes:** Liliana Torres, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 5 | 2026-11-02 |
