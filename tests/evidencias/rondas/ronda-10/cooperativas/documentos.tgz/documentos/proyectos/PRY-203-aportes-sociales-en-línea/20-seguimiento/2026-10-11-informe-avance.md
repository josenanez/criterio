# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-10-11
**Gerente:** Andrés Lozano

## Estado declarado

**Rojo**

Avance reportado: **59%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 929.795.008 |
| Ejecutado | 1.278.281.381 |
| Proyección al cierre | 2.419.120.193 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
