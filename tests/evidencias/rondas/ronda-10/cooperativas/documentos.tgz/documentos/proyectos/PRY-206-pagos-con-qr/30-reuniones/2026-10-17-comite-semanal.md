# Comité de Riesgos · Pagos con QR

**Fecha:** 2026-10-17
**Asistentes:** Elena Duarte, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 39 | 2026-11-03 |
| Natalia Ospina | Entregar el punto 35 | 2026-10-12 |
