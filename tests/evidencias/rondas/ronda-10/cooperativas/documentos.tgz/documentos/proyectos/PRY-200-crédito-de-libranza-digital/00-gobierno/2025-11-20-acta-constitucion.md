# Acta de constitución · Crédito de libranza digital

**Código:** PRY-200
**Área dueña:** Ahorro y aportes
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Gustavo Neira
**Comité:** Consejo de Administración
**Producto asociado:** crédito de libranza
**Fecha de aprobación:** 2025-11-20

## Objetivo del negocio

Entregar crédito de libranza digital para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Consejo de Administración el 2025-11-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-30 |
| Cierre | 2026-08-31 |

## Criterio de éxito

Crédito de libranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
