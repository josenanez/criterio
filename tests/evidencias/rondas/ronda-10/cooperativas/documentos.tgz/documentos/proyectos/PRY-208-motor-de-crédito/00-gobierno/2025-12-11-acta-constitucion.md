# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Operaciones
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-11

## Objetivo del negocio

Entregar motor de crédito para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Riesgos el 2025-12-11.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-21 |
| Cierre | 2026-11-22 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
