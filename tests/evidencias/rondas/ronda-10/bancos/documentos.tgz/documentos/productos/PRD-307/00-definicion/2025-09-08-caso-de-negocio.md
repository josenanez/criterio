# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2025-09-08
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 282.214 | Caso de negocio, 2025-09-08 |

## Retorno esperado

Retorno esperado en 24 meses.
