# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2026-06-03
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 216.912 | Caso de negocio, 2026-06-03 |

## Retorno esperado

Retorno esperado en 24 meses.
