# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-06-18
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 154.357 | Caso de negocio, 2026-06-18 |

## Retorno esperado

Retorno esperado en 24 meses.
