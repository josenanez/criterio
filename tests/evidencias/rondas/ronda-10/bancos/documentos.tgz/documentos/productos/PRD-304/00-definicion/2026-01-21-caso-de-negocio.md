# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-01-21
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 263.889 | Caso de negocio, 2026-01-21 |

## Retorno esperado

Retorno esperado en 24 meses.
