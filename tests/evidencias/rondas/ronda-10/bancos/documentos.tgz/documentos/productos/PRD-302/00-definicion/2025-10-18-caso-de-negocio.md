# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-10-18
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 61.609 | Caso de negocio, 2025-10-18 |

## Retorno esperado

Retorno esperado en 24 meses.
