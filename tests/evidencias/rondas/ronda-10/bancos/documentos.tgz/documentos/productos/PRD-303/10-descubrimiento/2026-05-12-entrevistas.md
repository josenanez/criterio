# Entrevistas · Cuenta PyME

**Ronda:** Ronda · 2026-05-12
**Realizadas por:** Paula Céspedes

### Cliente entrevistado · 2026-05-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
