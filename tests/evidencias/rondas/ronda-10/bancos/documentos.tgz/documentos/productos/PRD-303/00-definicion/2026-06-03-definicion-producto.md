# Definición de producto · Cuenta PyME

**Código:** PRD-303
**Gerente de producto:** Paula Céspedes
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-06-03

## El problema

El segmento Microcomercio no tiene cuenta pyme.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-09-14 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
