# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2026-05-22
**Realizadas por:** Elena Duarte

### Cliente entrevistado · 2026-05-22

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
