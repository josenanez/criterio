# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2026-07-30
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 95.206 | Caso de negocio, 2026-07-30 |

## Retorno esperado

Retorno esperado en 24 meses.
