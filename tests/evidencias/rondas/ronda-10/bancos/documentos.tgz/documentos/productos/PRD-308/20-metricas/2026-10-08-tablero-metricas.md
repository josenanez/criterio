# Tablero de métricas · Cuenta de ahorros joven

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 86.192 | 2026-10-08 |
