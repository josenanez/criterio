# Comité de producto · Crédito hipotecario digital

**Fecha:** 2026-10-12
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-06-18 | — |
| REQ-4201 | Requerimiento REQ-4201 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-06-09 | — |
| REQ-4202 | Requerimiento REQ-4202 | Óscar Ramírez | — | — | aceptado | 2026-08-13 | — |
| REQ-4203 | Requerimiento REQ-4203 | Óscar Ramírez | — | — | propuesto | 2026-06-11 | — |
| REQ-4204 | Requerimiento REQ-4204 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4205 | Requerimiento REQ-4205 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-21 | — |
| REQ-4206 | Requerimiento REQ-4206 | Rubén Cárdenas | se verifica en producción | — | propuesto | 2026-04-04 | — |
| REQ-4207 | Requerimiento REQ-4207 | Óscar Ramírez | se verifica en producción | — | propuesto | 2026-05-14 | — |
| REQ-4208 | Requerimiento REQ-4208 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-04-01 | — |
| REQ-4209 | Requerimiento REQ-4209 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4210 | Requerimiento REQ-4210 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-30 | — |
| REQ-4211 | Requerimiento REQ-4211 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-09 | — |
| REQ-4212 | Requerimiento REQ-4212 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4213 | Requerimiento REQ-4213 | sin asignar | se verifica en producción | — | aceptado | 2026-03-28 | — |

## Decisiones

- Se mantiene el plan
