# Tablero de métricas · Ahorro programado

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 120.000 | 2026-10-12 |
