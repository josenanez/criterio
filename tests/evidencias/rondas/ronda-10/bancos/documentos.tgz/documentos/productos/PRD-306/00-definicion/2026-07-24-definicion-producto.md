# Definición de producto · Microseguros

**Código:** PRD-306
**Gerente de producto:** Liliana Torres
**Segmento:** PyME
**Fecha de la definición:** 2026-07-24

## El problema

El segmento PyME no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-18 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
