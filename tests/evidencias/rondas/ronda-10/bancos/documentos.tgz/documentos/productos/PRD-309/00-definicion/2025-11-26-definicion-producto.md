# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Ricardo Salas
**Segmento:** Microcomercio
**Fecha de la definición:** 2025-11-26

## El problema

El segmento Microcomercio no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-04-03 · verificado con la medición del piloto del 2026-07-04 (anexo «Verificación del supuesto» del 2026-07-04)

## Proyectos que lo construyen

- Ninguno declarado
