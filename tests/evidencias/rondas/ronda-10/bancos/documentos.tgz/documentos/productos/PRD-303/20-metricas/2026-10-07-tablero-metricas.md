# Tablero de métricas · Cuenta PyME

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 140.906 | 2026-10-07 |
