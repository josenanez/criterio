# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2025-08-31
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 296.787 | Caso de negocio, 2025-08-31 |

## Retorno esperado

Retorno esperado en 24 meses.
