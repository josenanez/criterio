# Comité de producto · Remesas familiares

**Fecha:** 2026-10-05
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-01 | — |
| REQ-4701 | Requerimiento REQ-4701 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-04-05 | — |
| REQ-4702 | Requerimiento REQ-4702 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-18 | — |
| REQ-4703 | Requerimiento REQ-4703 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-29 | — |
| REQ-4704 | Requerimiento REQ-4704 | sin asignar | se verifica en producción | — | propuesto | 2026-06-11 | — |
| REQ-4705 | Requerimiento REQ-4705 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-23 | — |
| REQ-4706 | Requerimiento REQ-4706 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-22 | — |
| REQ-4707 | Requerimiento REQ-4707 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-06-01 | — |
| REQ-4708 | Requerimiento REQ-4708 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-08 | — |
| REQ-4709 | Requerimiento REQ-4709 | María Restrepo | — | — | aceptado | 2026-07-27 | — |
| REQ-4710 | Requerimiento REQ-4710 | Gustavo Neira | — | Cliente entrevistado | aceptado | 2026-04-10 | — |
| REQ-4711 | Requerimiento REQ-4711 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-07-26 | — |
| REQ-4712 | Requerimiento REQ-4712 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-22 | — |
| REQ-4713 | Requerimiento REQ-4713 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |

## Decisiones

- Se mantiene el plan
