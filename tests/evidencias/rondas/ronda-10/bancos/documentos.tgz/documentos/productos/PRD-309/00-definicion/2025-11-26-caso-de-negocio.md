# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2025-11-26
**Preparado por:** Ricardo Salas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 263.526 | Caso de negocio, 2025-11-26 |

## Retorno esperado

Retorno esperado en 24 meses.
