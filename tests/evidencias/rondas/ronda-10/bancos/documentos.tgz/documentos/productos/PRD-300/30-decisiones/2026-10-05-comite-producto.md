# Comité de producto · Pagos QR comercios

**Fecha:** 2026-10-05
**Asistentes:** Laura Vélez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-06-27 | — |
| REQ-4001 | Requerimiento REQ-4001 | Gustavo Neira | se verifica en producción | — | propuesto | 2026-05-20 | — |
| REQ-4002 | Requerimiento REQ-4002 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-15 | — |
| REQ-4003 | Requerimiento REQ-4003 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-14 | — |
| REQ-4004 | Requerimiento REQ-4004 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-10 | — |
| REQ-4005 | Requerimiento REQ-4005 | Andrés Lozano | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-21 | — |
| REQ-4006 | Requerimiento REQ-4006 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-18 | — |
| REQ-4007 | Requerimiento REQ-4007 | sin asignar | — | — | aceptado | 2026-03-20 | — |
| REQ-4008 | Requerimiento REQ-4008 | Jorge Medina | se verifica en producción | — | propuesto | 2026-03-18 | — |
| REQ-4009 | Requerimiento REQ-4009 | Beatriz Cuéllar | — | — | aceptado | 2026-08-11 | — |
| REQ-4010 | Requerimiento REQ-4010 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-30 | — |
| REQ-4011 | Requerimiento REQ-4011 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-08 | — |
| REQ-4012 | Requerimiento REQ-4012 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-05-07 | — |
| REQ-4013 | Requerimiento REQ-4013 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-05-12 | — |

## Decisiones

- Se mantiene el plan
