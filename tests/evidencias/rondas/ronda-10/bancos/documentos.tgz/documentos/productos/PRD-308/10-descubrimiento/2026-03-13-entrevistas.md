# Entrevistas · Cuenta de ahorros joven

**Ronda:** Ronda · 2026-03-13
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2026-03-13

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
