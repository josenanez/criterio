# Acta de constitución · Core de depósitos

**Código:** PRY-201
**Área dueña:** Tesorería
**Patrocinador:** Liliana Torres
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta de ahorros
**Fecha de aprobación:** 2026-03-19

## Objetivo del negocio

Entregar core de depósitos para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Arquitectura el 2026-03-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-29 |
| Cierre | 2027-06-21 |

## Criterio de éxito

Core de depósitos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
