# Comité de Transformación Digital · Cobranza digital

**Fecha:** 2026-10-09
**Asistentes:** Beatriz Cuéllar, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 16 | 2026-10-22 |
