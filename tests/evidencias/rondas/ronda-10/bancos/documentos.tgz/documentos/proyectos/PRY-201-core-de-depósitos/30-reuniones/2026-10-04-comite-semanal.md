# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-04
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-09 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-11-19 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-24 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-08 |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 |
| Diana Molina | Confirmar la fecha 7 | 2026-11-05 |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-10-15 |
| Sandra Gil | Revisar el anexo 11 | 2026-10-14 |
| Sandra Gil | Validar el ambiente 12 | por definir |
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 |
| Paula Céspedes | Actualizar la matriz 14 | 2026-10-08 |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-14 |
| Elena Duarte | Enviar el documento 17 | 2026-10-13 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-26 |
| Paula Céspedes | Validar el ambiente 20 | 2026-10-28 |

## Cerrados en esta reunión

- Enviar el documento 9 (Ricardo Salas): recibido, acta de recibo del 2026-10-04.
