# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-09-20
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Felipe Arango, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-14 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-23 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-06 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-26 |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-20 |
| Diana Molina | Confirmar la fecha 7 | 2026-09-22 |
| Diana Molina | Entregar el punto 8 | 2026-10-04 |
| Ricardo Salas | Enviar el documento 9 | 2026-09-27 |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-09-30 |
| Sandra Gil | Revisar el anexo 11 | 2026-10-14 |
| Sandra Gil | Validar el ambiente 12 | por definir |

## Cerrados en esta reunión

- Revisar el anexo 3 (Camilo Beltrán): recibido, acta de recibo del 2026-09-20.
