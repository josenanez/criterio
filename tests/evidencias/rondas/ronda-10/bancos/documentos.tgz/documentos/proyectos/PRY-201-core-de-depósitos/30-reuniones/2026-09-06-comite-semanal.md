# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-09-06
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-09-24 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-09-29 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-18 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-14 |
