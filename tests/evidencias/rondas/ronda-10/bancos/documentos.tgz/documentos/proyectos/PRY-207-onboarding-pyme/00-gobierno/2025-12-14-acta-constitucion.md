# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Banca de Personas
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Banca Empresas
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2025-12-14

## Objetivo del negocio

Entregar onboarding pyme para Banca de Personas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Banca Empresas el 2025-12-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-24 |
| Cierre | 2026-08-01 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
