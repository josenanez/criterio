# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Débito contactless
**Fecha:** 2026-10-17
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +117 días sobre la línea base vigente |
| Costo | 234.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
