# Informe de avance · Cobranza digital

**Código:** PRY-211
**Fecha de corte:** 2026-10-11
**Gerente:** Beatriz Cuéllar

## Estado declarado

**Verde**

Avance reportado: **61%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.525.044.204 |
| Ejecutado | 1.165.890.630 |
| Proyección al cierre | 7.076.297.734 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Disponibilidad del equipo de seguridad para la revisión final
