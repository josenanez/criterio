# Acta de constitución · Portal de proveedores

**Código:** PRY-210
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Medios de Pago
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-11

## Objetivo del negocio

Entregar portal de proveedores para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-09-11.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-21 |
| Cierre | 2027-01-14 |

## Criterio de éxito

Portal de proveedores en producción y medido.

## Dependencias declaradas

- Ninguna declarada
