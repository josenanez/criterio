# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-11
**Asistentes:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-19 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-11-27 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-24 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-08 |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 |
| Diana Molina | Confirmar la fecha 7 | 2026-11-05 |
| Sandra Gil | Revisar el anexo 11 | 2026-10-26 |
| Sandra Gil | Validar el ambiente 12 | por definir |
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-28 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-26 |
| Paula Céspedes | Validar el ambiente 20 | 2026-10-28 |
| Rubén Cárdenas | Aprobar el diseño 21 | 2026-10-15 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-25 |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 |
| Gustavo Neira | Entregar el punto 24 | 2026-11-06 |

## Cerrados en esta reunión

- Enviar el documento 17 (Elena Duarte): recibido, acta de recibo del 2026-10-11.

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «cerrar la prueba 10». No se presentó acta.
- Paula Céspedes dice que ya entregó «actualizar la matriz 14». No se presentó acta.
- Javier Hoyos dice que ya entregó «entregar el punto 16». No se presentó acta.
