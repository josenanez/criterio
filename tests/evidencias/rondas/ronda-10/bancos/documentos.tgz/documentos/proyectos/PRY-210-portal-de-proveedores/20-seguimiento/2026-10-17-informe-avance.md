# Informe de avance · Portal de proveedores

**Código:** PRY-210
**Fecha de corte:** 2026-10-17
**Gerente:** Ricardo Salas

## Estado declarado

**Rojo**

Avance reportado: **48%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.765.771.095 |
| Ejecutado | 2.045.359.196 |
| Proyección al cierre | 3.896.316.249 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- Concentración del conocimiento en una sola persona
