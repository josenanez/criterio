# Acta de recibo · Revisar el anexo 3

**Proyecto:** PRY-201 · Core de depósitos
**Fecha de recibo:** 2026-09-20
**Recibido por:** Carlos Peña

Se recibe a satisfacción: **Revisar el anexo 3**, compromiso de Camilo Beltrán.
