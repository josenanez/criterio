# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 25 | 2026-10-09 |
