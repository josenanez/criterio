# Informe de avance · Onboarding PyME

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Carlos Peña

## Estado declarado

**Rojo**

Avance reportado: **47%**

## Lo que pasó en el periodo

- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 547.535.160 |
| Ejecutado | 435.822.796 |
| Proyección al cierre | 1.222.741.909 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio regulatorio en discusión que puede mover el alcance
