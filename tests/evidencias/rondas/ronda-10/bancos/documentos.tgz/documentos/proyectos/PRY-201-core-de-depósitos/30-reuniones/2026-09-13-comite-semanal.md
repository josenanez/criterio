# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-09-13
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-05 |
| Andrés Lozano | Cerrar la prueba 2 | 2026-10-10 |
| Camilo Beltrán | Revisar el anexo 3 | 2026-09-18 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-23 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-26 |
| Felipe Arango | Actualizar la matriz 6 | 2026-09-20 |
| Diana Molina | Confirmar la fecha 7 | 2026-09-22 |
| Diana Molina | Entregar el punto 8 | 2026-10-04 |
