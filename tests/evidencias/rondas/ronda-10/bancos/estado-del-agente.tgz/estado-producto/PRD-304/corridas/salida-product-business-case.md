# Caso de negocio — Tarjeta de crédito digital (PRD-304) · borrador del 2026-10-18
**Desde:** la definición del 2026-01-21 y el caso de negocio del 2026-01-21 · **Cifras con fuente:** 2 de 2 cifras numéricas (el «retorno» no trae cifra y va a vacíos)

*Borrador de trabajo, no decisión ni asesoría. Las cifras son del negocio: este documento no proyecta ingresos, no calcula retorno y no recomienda aprobar ni rechazar. La verificación es de quien lo lea.*

Términos: vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no se registraron de nuevo.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Personas no tiene tarjeta de crédito digital.» (`00-definicion/2026-01-21-definicion-producto.docx`, 2026-01-21). No trae medida de tamaño.
- **Para quién:** Personas (misma definición).
- **Criterio de éxito:** no está declarado en ningún documento.

## Qué se construye
17 requerimientos decididos (aceptados) de 18; el 18.º, REQ-4401, está propuesto hace 65 días y queda fuera del caso. Fuente: acta del Comité de producto, 2026-10-18 (`30-decisiones/2026-10-18-comite-producto.docx`) y el registro.

| Grupo | Requerimientos | Estado | Evidencia de demanda |
|---|---|---|---|
| Con cita | REQ-2030, 4400, 4403, 4404, 4405, 4406, 4407, 4408, 4411, 4412, 4414, 4415 (12) | aceptado | Una entrevista de cliente, 2025-10-03: «Lo necesito y hoy no lo tengo.» **No nombra ningún requerimiento** y ya cruzó el umbral de 12 meses |
| Sin cita de quien lo pidió | REQ-2038, 4402, 4409, 4410, 4413 (5) | aceptado | Ninguna. REQ-4410 lleva 212 días aceptado sin sustento |

Además: ninguno de los 17 tiene proyecto que lo ejecute; REQ-4407 y REQ-4408 no tienen doliente; REQ-4400, 4412 y 4414 no tienen criterio de aceptación.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (declarado) | 263.889 | Declarada | Caso de negocio, Liliana Torres (`00-definicion/2026-01-21-caso-de-negocio.md`) | 2026-01-21 |
| volumen_mensual (medido) | 272.644 | Medida | Tablero de métricas, bodega de datos (`20-metricas/2026-10-15-tablero-metricas.md`) | corte 2026-10-15 |
| Retorno esperado | «en 24 meses», sin cifra | Declarada, sin valor | Caso de negocio | 2026-01-21 |
| «La demanda se sostiene sin campaña» | — | **Supuesta** (marcada verificada, no comprobable) | Definición; anexo `00-definicion/2026-09-11-verificacion-supuesto.md` | declarada 2026-08-02, verificada 2026-09-11 |

Qué mide `volumen_mensual` (¿solicitudes, tarjetas activas, transacciones?) no lo define ni el caso ni el tablero.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 263.889 | 272.644 (+3,3 %; umbral 20 %) | Caso de negocio 2026-01-21 · Tablero 2026-10-15 |

No pasa el umbral: es imprecisión, no contradicción. La serie tiene un solo punto, sin tendencia, y sin definición de la métrica la cercanía no se puede leer como confirmación.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | — | No está en ningún documento |
| Contratos / cotizaciones del proveedor | — | No hay en la carpeta |
| Costo del equipo | — | No declarado |

**El costo de construir es el primer vacío:** sin él no hay caso de negocio que evaluar, hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La demanda declarada se sostiene sin campaña | Las 263.889/272.644 mensuales dependerían de una campaña que el caso no presupuesta ni menciona | Sin nombre. La verificación dice solo «se confirmó»; el documento técnico del proveedor del 2026-09-11 no está en la carpeta y un documento de proveedor no es evidencia de demanda |
| `volumen_mensual` significa lo mismo en el caso y en el tablero | La coincidencia de 3,3 % no sería confirmación | Quien produce el tablero (bodega de datos) y la gerente de producto |
| La necesidad de una entrevista (2025-10-03) representa al segmento | Los 17 requerimientos quedan sin demanda sustentada | Descubrimiento: nueva ronda de evidencia |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso evaluable | Negocio / Liliana Torres, con contratos o cotizaciones |
| Cifra y supuestos del retorno a 24 meses | «Retorno esperado» sin monto ni porcentaje no se puede medir ni contrastar | Negocio |
| Qué mide `volumen_mensual` | Define si las dos cifras son comparables | Bodega de datos / gerente de producto |
| Tamaño del problema (cuántas personas del segmento sin tarjeta digital) | Sostiene la demanda | Negocio |
| Evidencia de pago o uso del cliente, sin campaña | El supuesto central no tiene dato de comportamiento | Descubrimiento / datos |
| Documento técnico del proveedor del 2026-09-11 | La verificación del supuesto no se puede comprobar | Quien lo recibió |
| Alternativas consideradas y qué pasa si no se hace | No aparecen en ningún documento | Negocio |
| Quién decide | Hay un comité, ninguna persona nombrada | Comité de producto |
| País de operación | Sin él no se puede nombrar la norma aplicable (crédito al consumidor, pagos, datos personales) | Gerente de producto |
| Proyecto que construye el producto | 0 de 17 requerimientos con proyecto; la definición dice «Ninguno declarado» | Comité de producto |

## Cómo se sabrá si funcionó
**No está declarado.** No hay criterio de éxito, ni métrica, ni fecha de corte en ningún documento. Sin esto el producto no se puede cerrar meses después. Es el vacío que convierte el resto en no verificable.

## Si hay otros productos publicados
No hay ningún otro producto publicado a la vista; no hubo cruce de cifras con otros casos de negocio.

## Después
- Pasar los supuestos a seguimiento con assumption-tracking (el de «sin campaña» primero).
- `/product-charter` no se ofrece todavía: faltan criterio de éxito, decisor y costo.
