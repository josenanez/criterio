# Corrida del 2026-10-18 · product-charter

PRD-304 · 18 requerimientos · 38 s · 41 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |

Borrador de acta de REQ-4400 con 9 vacíos marcados (sin criterio de aceptación, sin quien decidió, evidencia débil y de 12,5 meses, sin autoridad, sin patrocinador ni gerente, sin país para lo normativo). Ficha no creada: falta la firma.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

**Términos:** ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hizo falta volver a registrarlos.

## Verificación previa de REQ-4400

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | **Sí.** Estado «aceptado» desde 2026-07-25 (`30-decisiones/2026-10-18-comite-producto.docx`). Quién decidió: **no está dicho**; el acta del comité solo dice «Se mantiene el plan» y lista como asistente a Liliana Torres. |
| Criterios de aceptación verificables | **Falta.** La columna del comité trae «—». |
| Evidencia de demanda con cita | **Débil.** La única es la entrevista del 2025-10-03 («Lo necesito y hoy no lo tengo.»); no nombra este requerimiento y tiene más de 12 meses (umbral configurado: 12). |
| Autoridad declarada en la definición | **Falta.** La definición no la declara; el comité de producto aparece decidiendo, pero ningún documento nombra a una persona que decida. |

Respuesta sugerida tomada (sesión sin interfaz): seguir sin esos elementos, marcados como vacíos del acta y sin rellenarlos.

---

# Acta de constitución — Tarjeta de crédito digital (REQ-4400) · borrador del 2026-10-18
**Producto:** PRD-304 · Tarjeta de crédito digital · **Requerimientos:** REQ-4400

## Qué problema resuelve
«El segmento Personas no tiene tarjeta de crédito digital.» (`00-definicion/2026-01-21-definicion-producto.docx`, 2026-01-21). Lo que REQ-4400 aporta a ese problema **no está dicho**: el título del registro es genérico («Requerimiento REQ-4400») y no hay descripción de la necesidad (`need: not_found`).

## Criterio de éxito
**No hay.** Ni REQ-4400 (comité, columna «Criterio de aceptación»: «—») ni la definición (`success: not_found`) traen uno. Sin esto el cierre no se puede juzgar meses después. Lo único medible a la vista es del producto, no del requerimiento: el caso de negocio declara `volumen_mensual` = 263.889 (2026-01-21) y el tablero mide 272.644 (corte 2026-10-15), una diferencia de +3,3 %, por debajo del umbral de 20 %. Eso no es criterio de éxito de este requerimiento.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 (sin título descriptivo) | Entrevista del 2025-10-03, «Lo necesito y hoy no lo tengo.», tema «Necesidad principal»; **no nombra el requerimiento** y tiene 12,5 meses. Pidió: «Cliente entrevistado» (comité 2026-10-18). |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4401 a REQ-4415, REQ-2030, REQ-2038 | Los otros 17 requerimientos del registro | No se pidieron en este acta (argumento: REQ-4400). Entrar o no es decisión del gerente de producto; el acta no lo asume. Varios están aceptados y sin proyecto trazado. |

## Gobierno
- **Patrocinador:** no está dicho.
- **Gerente propuesto:** no está dicho. Liliana Torres es la gerente de **producto** (definición, 2026-01-21), no se propone como gerente del proyecto. El doliente del requerimiento es Natalia Ospina (comité, 2026-10-18).
- **Comité:** Comité de producto (comité 2026-10-18).
- **Autoridad del gerente:** no está dicha en ningún documento.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| La demanda declarada se sostiene sin campaña (declarado 2026-08-02; la definición es del 2026-01-21) | Dice «sí», pero la verificación (`2026-09-11-verificacion-supuesto.md`) cita un documento técnico del proveedor que **no está en la carpeta**; el anexo solo dice «se confirmó». No se puede comprobar. | Sin doliente nombrado. Se registra como riesgo con **doliente por asignar** (el doliente lo asigna la persona que firma). |

REQ-4400 no declara supuestos propios (`assumptions: []`).

## Restricciones normativas sin resolver
El país no está declarado en ningún documento, así que ninguna norma está a la vista. Esto va a revisión jurídica; no dice si el producto cumple.

| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito para personas (consumidor financiero) | Información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Tarjeta / medio de pago | Medios y sistemas de pago | — | no tengo la norma a la vista |
| Datos personales y financieros de solicitantes | Tratamiento de datos personales | — | no tengo la norma a la vista |
| Proveedor externo y posible nube | Encargo de tratamiento y transferencia a otro país | — | no tengo la norma a la vista |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación de REQ-4400 | El proyecto no tiene contra qué cerrarse; el éxito se discute al final. | Natalia Ospina (doliente) con el gerente de producto |
| Quién decidió aceptarlo | Una aceptación sin persona que la sostenga; «se mantiene el plan» no es decisión de nadie. | Comité de producto, nombrando a la persona |
| Evidencia de demanda que nombre este requerimiento y no tenga más de 12 meses | La demanda del proyecto descansa en una frase general de hace 12,5 meses. | Liliana Torres (gerente de producto) |
| Autoridad del gerente | Un proyecto que escala todo o no escala nada. | Quien firma el acta |
| Patrocinador y gerente de proyecto | No hay a quién le quede la ficha. | Quien firma el acta |
| Descripción y título del requerimiento | No se sabe qué se construye. | Natalia Ospina |
| Verificación comprobable del supuesto (documento del proveedor) | El supuesto pasa a riesgo con una verificación que nadie puede revisar. | Liliana Torres, pidiéndolo al proveedor |
| País, para el barrido normativo | Obligaciones sin norma; revisión jurídica pendiente. | Gerente de producto con jurídico |
| Fecha del supuesto (declarado 2026-08-02 en una definición del 2026-01-21) | La definición se editó después de su fecha y no lo dice. | Liliana Torres |

---
**Esto es un borrador.** Lo firma una persona con autoridad sobre el producto; este acta no nombra quién, porque ningún documento lo dice. **La ficha del proyecto no se creó:** se crea después de la firma, y `declared` (el estado) quedará vacío porque lo declara el gerente del proyecto.

## Después
El gerente del proyecto, una vez designado, instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella, y Alba sabrá si su producto se está construyendo sin preguntarle a nadie. Hasta entonces, REQ-4400 sigue sin proyecto trazado.
