# Corrida del 2026-10-18 · product-spec

PRD-304 · 18 requerimientos · 67 s · 41 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |

Borrador-esqueleto: 17 aceptados en alcance, REQ-4401 (propuesto) fuera. No se escribió comportamiento: need no está dicho en 17/17. Criterios: 3 sin criterio, 14 no verificables. Dije que no sé: país, norma aplicable, decisor, contenido del documento del proveedor, otros equipos.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

> **Borrador para cierre del gerente de producto.** Lo escribe el agente; lo cierra Liliana Torres (gerente de producto, PRD-304) con la autoridad del Comité de producto. Este agente no aprueba, no diseña, no estima.

# Especificación — Tarjeta de crédito digital (PRD-304) · borrador del 2026-10-18

**Lo primero que hay que saber:** el registro no permite escribir comportamiento. En los 17 requerimientos aceptados el campo `need` (el problema que cada uno resuelve) está en `not_found`, y el acta del comité los llama «Requerimiento REQ-44xx» sin más título. Rellenar eso con lo razonable para una tarjeta de crédito digital sería inventar la especificación. Lo que sigue es, por eso, el **esqueleto con los huecos a la vista**, no una especificación completa.

## Qué problema resuelve

«El segmento Personas no tiene tarjeta de crédito digital.» — `00-definicion/2026-01-21-definicion-producto.docx`.

La definición no dice nada más: ni qué hace la tarjeta, ni el criterio de éxito del producto (`success`: no está dicho en ninguna parte), ni país, ni proyecto que lo construya («Ninguno declarado»).

## Alcance

### Entra
Los 17 requerimientos en estado `aceptado` (acta del comité de producto, 2026-10-18). De cada uno solo se sabe lo de esta tabla; **de qué trata, no**.

| REQ | Doliente | Aceptado desde | Criterio tal como está escrito |
|---|---|---|---|
| REQ-4400 | Natalia Ospina | 2026-07-25 | — (vacío) |
| REQ-4402 | Ricardo Salas | 2026-07-10 | «se verifica en producción» |
| REQ-4403 | Paula Céspedes | 2026-05-23 | «se verifica en producción» |
| REQ-4404 | Mauricio Pérez | 2026-08-15 | «se verifica en producción» |
| REQ-4405 | Rubén Cárdenas | 2026-04-05 | «se verifica en producción» |
| REQ-4406 | María Restrepo | 2026-06-11 | «se verifica en producción» |
| REQ-4407 | sin asignar | 2026-07-09 | «se verifica en producción» |
| REQ-4408 | sin asignar | 2026-05-03 | «se verifica en producción» |
| REQ-4409 | Diana Molina | 2026-08-30 | «se verifica en producción» |
| REQ-4410 | Jorge Medina | 2026-03-20 | «se verifica en producción» |
| REQ-4411 | Natalia Ospina | 2026-05-20 | «se verifica en producción» |
| REQ-4412 | Óscar Ramírez | 2026-08-05 | — (vacío) |
| REQ-4413 | Felipe Arango | 2026-07-14 | «se verifica en producción» |
| REQ-4414 | Elena Duarte | 2026-08-20 | — (vacío) |
| REQ-4415 | Beatriz Cuéllar | 2026-05-08 | «se verifica en producción» |
| REQ-2030 | Ricardo Salas | 2026-10-07 | «se verifica en producción» |
| REQ-2038 | Gustavo Neira | 2026-10-08 | «se verifica en producción» |

### No entra
- **REQ-4401** (Carlos Peña): está `propuesto`, nadie decidió que se haga. Especificarlo sería escribir el documento dos veces.
- Todo lo que no esté en el registro. El acta solo decide «Se mantiene el plan»; no dice qué plan, y ningún documento lo describe.
- Diseño, arquitectura, estimación, fechas: no son de este documento.
- Lo que el producto hace con datos o con dinero: **no está dicho en ninguna parte**, así que no está dentro ni fuera; está sin decidir (ver Vacíos).

## Comportamiento

**No se puede escribir ninguna sección.** Cada sección tendría que citar los requerimientos que cubre y decir qué hace el producto; para los 17 el registro tiene `need = not_found`. Cobertura de comportamiento: **0 de 17**. Agrupar los requerimientos por tema (por ejemplo «originación» o «pagos») sería poner en el registro algo que nadie escribió.

## Criterios de aceptación

Ninguno de los criterios registrados pasa la prueba de las dos personas que llegan a la misma respuesta.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | 14: REQ-4402 a 4411 (salvo 4401), 4413, 4415, 2030, 2038 | No lo dice: no hay umbral, ni qué se mide, ni quién mide | **No es verificable.** Es una fecha de verificación, no un criterio |
| — (no hay criterio) | REQ-4400, REQ-4412, REQ-4414 | — | **Falta** |

Lo único medido en producción es `volumen_mensual`, **un solo punto**: 272.644 (tablero de métricas, corte 2026-10-15). No hay serie, y el tablero no define la unidad (¿transacciones, tarjetas, monto?). Aun si un criterio quisiera apoyarse en eso, ninguno lo cita.

Este agente no propone umbrales ni redacta criterios para estos requerimientos: sin saber qué hace cada uno, cualquier número sería inventado.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (declarado 2026-08-02, `producto.json`) | El registro dice **sí**, con «documento técnico del proveedor del 2026-09-11». **Ese documento no está en la carpeta**; el anexo solo dice «se confirmó», sin cifra ni método. Tampoco se sabe cuál es la «demanda declarada»: el caso de negocio solo declara `volumen_mensual` = 263.889. Además la fecha del supuesto (2026-08-02) es posterior a la de la definición que lo contiene (2026-01-21). | La gerente de producto, Liliana Torres, tendría que obtener el documento del proveedor y citarlo; hasta entonces yo no lo trataría como verificado con cita |
| Demanda: la única evidencia es una entrevista de 2025-10-03 («Lo necesito y hoy no lo tengo.»), de un cliente sin nombre, que **no nombra ningún requerimiento** y tiene unos 12,5 meses (umbral de la configuración: 12) | — no es un supuesto declarado por nadie; se lista como base de la demanda | Liliana Torres (la realizó) |

Supuestos por requerimiento: ninguno declarado en los 17. Esto no significa que no existan; significa que nadie los escribió, y este agente no los infiere.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| **Qué hace cada requerimiento** (`need` vacío en 17/17; títulos genéricos) | No hay especificación posible: se aprobaría un documento sin contenido | Cada doliente por requerimiento; Liliana Torres para consolidar |
| **Criterio de aceptación**: falta en REQ-4400, 4412, 4414; no verificable en los otros 14 («se verifica en producción») | Imposible discutir «¿quedó bien?» antes de construir; se discutirá después | Dolientes: Natalia Ospina (4400), Óscar Ramírez (4412), Elena Duarte (4414); los otros 14, sus dolientes |
| **Doliente sin asignar**: REQ-4407, REQ-4408 | Nadie responde por qué se pidió ni por si quedó bien | Liliana Torres (asigna) |
| **Proyecto que ejecute los 17 aceptados**: ninguno tiene `traces.project`; la definición dice «Ninguno declarado». 13 de los 17 llevan más de 60 días aceptados sin proyecto | Lo decidido no lo construye nadie; el estado `aceptado` exige un proyecto | Comité de producto; hoy ningún documento nombra a una persona que decida (el acta dice «Se mantiene el plan» sin decisor) |
| **Quién decidió** cada aceptación: `decision.who` en `not_found` para los 17; la fecha «desde» y el acta de 2026-10-18 son lo único citable | La decisión no es rastreable a una persona | Comité de producto / Liliana Torres |
| **Evidencia de demanda por requerimiento**: ninguna en REQ-4402, 4409, 4410, 4413, 2038; en los otros 12 es la entrevista genérica de 2025-10-03 | Se aceptó sin sustento citable | Dolientes; Liliana Torres |
| **Criterio de éxito del producto** (`success`: no está dicho) y significado de `volumen_mensual` (unidad, qué cuenta). Declarado 263.889 vs medido 272.644 (+3,3 %, por debajo del umbral de 20 %: no es hallazgo) | No hay con qué juzgar si el producto funciona; la cifra coincide pero no se sabe de qué | Liliana Torres |
| **Casos borde** (sin conexión, operación duplicada, abandono a mitad de un flujo, etc.): no se pueden enumerar porque no se sabe qué flujos existen | Se decidirán al construir, por quien construya | Dolientes con el equipo que construya |
| **Qué otro equipo tiene que hacer algo**: ningún documento nombra otro equipo. El único tercero es «el proveedor» (citado solo como verificador del supuesto), sin nombre ni rol en la construcción | Dependencias sin acordar descubiertas durante la construcción | Liliana Torres |
| **Obligaciones normativas** (tabla siguiente) | Se descubren con el producto construido | Revisión jurídica de la organización (persona no nombrada en los documentos); Liliana Torres la convoca |

### Barrido normativo (insumo para revisión jurídica; no dice si cumple)

El **país no está dicho** en ningún documento, y las obligaciones cambian por país. Por eso no cito ninguna norma ni artículo: sería inventarla.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Un producto de crédito para personas naturales (segmento «Personas») | no está dicho | Obligaciones de quien atiende consumidor financiero (información previa, cobros, reclamos) y de quien otorga crédito | — | no tengo la norma a la vista |
| Presumiblemente datos personales del solicitante y su uso (la definición no dice qué recoge) | no está dicho | Autorización y finalidad; si hay encargo a un tercero (el «proveedor»); si hay transferencia a otro país | — | no tengo la norma a la vista |
| Aceptación de condiciones por canal digital (no dicho si ocurre) | no está dicho | Prueba del consentimiento / firma | — | sin resolver |
| Conservación y trazabilidad de operaciones | no está dicho | Plazo y acceso | — | sin resolver |

Nada de lo anterior está resuelto con un documento de la organización. Lo que queda abierto debería entrar al registro como restricción del requerimiento o como riesgo con doliente; este borrador no lo hace por sí solo.

## Requerimientos aceptados que esta especificación no cubre

Ninguno de los 17 está cubierto **en comportamiento**; todos están listados en el alcance solo por identificador.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4400, 4402, 4403, 4404, 4405, 4406, 4407, 4408, 4409, 4410, 4411, 4412, 4413, 4414, 4415, 2030, 2038 | «Requerimiento REQ-xxxx» (sin título descriptivo en ninguna fuente) | `need` no está dicho en ninguna parte; sin él no hay sección que escribir |

Fuera por estado (no es un olvido): REQ-4401 (`propuesto`).

## Siguiente paso

No ofrezco `/product-charter` todavía: los vacíos no están cerrados (ni un criterio verificable, ni proyecto, ni decisor). Lo que desbloquea esto, en orden: que cada doliente escriba qué problema resuelve su requerimiento, que se nombre quién decide en el comité, y que alguien traiga el documento del proveedor.

---
**Pie.** Sale del registro en `estado-producto/PRD-304/requirements/` (18 requerimientos: 17 aceptados cubiertos en alcance, 1 propuesto fuera), con el acta del comité de 2026-10-18 como fuente de los estados y la definición de 2026-01-21. Borrador del 2026-10-18. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0 (aceptados por José Francisco Ñáñez el 2026-10-18).
