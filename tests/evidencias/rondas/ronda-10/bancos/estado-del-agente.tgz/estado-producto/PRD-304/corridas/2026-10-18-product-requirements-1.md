# Corrida del 2026-10-18 · product-requirements

PRD-304 · 18 requerimientos · 19 s · 41 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |

5 aceptados sin evidencia (REQ-2038, 4402, 4409, 4410, 4413); 2 sin doliente; 3 sin criterio; 1 sin decidir 65 días; 17 sin proyecto

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Registro — Tarjeta de crédito digital (PRD-304) · al 2026-10-18
18 requerimientos · 17 decididos · 70.6% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2038 | Requerimiento REQ-2038 | aceptado (2026-10-08) | Gustavo Neira |
| REQ-4402 | Requerimiento REQ-4402 | aceptado (2026-07-10) | Ricardo Salas |
| REQ-4409 | Requerimiento REQ-4409 | aceptado (2026-08-30) | Diana Molina |
| REQ-4410 | Requerimiento REQ-4410 | aceptado (2026-03-20) | Jorge Medina |
| REQ-4413 | Requerimiento REQ-4413 | aceptado (2026-07-14) | Felipe Arango |

Ninguno tiene una sola cita de quien lo pidió. REQ-4410 lleva 212 días aceptado sin sustento.

### Decidido y nadie lo está construyendo
Los 17 aceptados: ninguno tiene proyecto que lo ejecute (0%).
| REQ | Decidido el |
|---|---|
| REQ-4410 | 2026-03-20 |
| REQ-4405 | 2026-04-05 |
| REQ-4408 | 2026-05-03 |
| REQ-4415 | 2026-05-08 |
| REQ-4411 | 2026-05-20 |
| REQ-4403 | 2026-05-23 |
| REQ-4406 | 2026-06-11 |
| REQ-4407 | 2026-07-09 |
| REQ-4402 | 2026-07-10 |
| REQ-4413 | 2026-07-14 |
| REQ-4400 | 2026-07-25 |
| REQ-4412 | 2026-08-05 |
| REQ-4404 | 2026-08-15 |
| REQ-4414 | 2026-08-20 |
| REQ-4409 | 2026-08-30 |
| REQ-2030 | 2026-10-07 |
| REQ-2038 | 2026-10-08 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4407 | Requerimiento REQ-4407 | sin doliente (aceptado 2026-07-09) |
| REQ-4408 | Requerimiento REQ-4408 | sin doliente (aceptado 2026-05-03) |

Los otros 16 tienen una persona como doliente.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | aceptado |
| REQ-4412 | Requerimiento REQ-4412 | aceptado |
| REQ-4414 | Requerimiento REQ-4414 | aceptado |

### Decidido sin documento que lo respalde
Esta señal no la calculó el script en esta corrida; no la afirmo ni la descarto. Los 17 aceptados traen fecha de decisión, pero la corrida no verificó el documento de cada decisión.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4401 | Requerimiento REQ-4401 | 65 días (desde 2026-08-14; umbral 60) | Comité de producto (autoridad en la configuración); doliente Carlos Peña, gerente de producto Liliana Torres |

Se propone decidirlo (aceptar o descartar con su documento), no cerrarlo por viejo.

### Evidencia vieja
Lo más nuevo que los sostiene es del 2025-10-03, 12 meses (umbral 12): REQ-2030, 4400, 4401, 4403, 4404, 4405, 4406, 4407, 4408, 4411, 4412, 4414, 4415 (13 en total).
Es la misma cita en todos: una entrevista de cliente («Lo necesito y hoy no lo tengo.», tema Necesidad principal) que **no nombra ningún requerimiento**. Es evidencia de la necesidad general, no de cada requerimiento. REQ-4401 está propuesto, por lo que esto no es un vacío exigible en él.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 1 | 17 | 0 | 0 | 0 |

## Aparte
- Definición: el volumen mensual declarado (263.889) frente al medido (272.644, tablero del 2026-10-15) difiere 3.3%, bajo el umbral de 20%. No es hallazgo.
- El criterio de éxito del producto no está dicho en ninguna parte.
- Por proyecto: 17 de 17 decididos sin traza a un proyecto (requirement_untraced).

Siguiente paso posible: `/product-trace` para los 17 decididos que nadie construye. Ninguno cumple aún evidencia + criterio + doliente fresca para `/product-charter`, salvo revisión: REQ-2030 tiene criterio y evidencia (de 12 meses).
