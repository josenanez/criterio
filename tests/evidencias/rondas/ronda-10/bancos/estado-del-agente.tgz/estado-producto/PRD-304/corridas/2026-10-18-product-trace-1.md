# Corrida del 2026-10-18 · product-trace

PRD-304 · 18 requerimientos · 30 s · 41 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |

17 requerimientos decididos y ninguno tiene proyecto; ninguna ficha dice ejecutar PRD-304

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Tarjeta de crédito digital (PRD-304) · al 2026-10-18
17 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Nota de la corrida: la configuración apunta a `estado` como carpeta de fichas, pero ahí hay archivos de cadencia y de corridas (`corridas.json` es una lista) que hacen fallar el cálculo. Las fichas reales están en `estado/records/`, y con esa carpeta se corrió el cálculo. Si esa no es la carpeta que corresponde, hay que corregir `paths.fichas` en la configuración.

### Decidido y nadie lo está construyendo
Los 17 requerimientos aceptados tienen `project: null`; ninguno entró al alcance de un proyecto. Decisión citada en `documentos/productos/PRD-304/30-decisiones/2026-10-18-comite-producto.docx` (aceptado, estado revisado en el comité). En ningún caso el documento dice quién decidió, y esa celda queda como «no figura» en vez de suponerla (la autoridad configurada es el Comité de producto).

| REQ | Título | Decidido el | Por quién | Días sin proyecto |
|---|---|---|---|---|
| REQ-4410 | Requerimiento REQ-4410 | 2026-03-20 | no figura | 212 |
| REQ-4405 | Requerimiento REQ-4405 | 2026-04-05 | no figura | 196 |
| REQ-4408 | Requerimiento REQ-4408 | 2026-05-03 | no figura | 168 |
| REQ-4415 | Requerimiento REQ-4415 | 2026-05-08 | no figura | 163 |
| REQ-4411 | Requerimiento REQ-4411 | 2026-05-20 | no figura | 151 |
| REQ-4403 | Requerimiento REQ-4403 | 2026-05-23 | no figura | 148 |
| REQ-4406 | Requerimiento REQ-4406 | 2026-06-11 | no figura | 129 |
| REQ-4407 | Requerimiento REQ-4407 | 2026-07-09 | no figura | 101 |
| REQ-4402 | Requerimiento REQ-4402 | 2026-07-10 | no figura | 100 |
| REQ-4413 | Requerimiento REQ-4413 | 2026-07-14 | no figura | 96 |
| REQ-4400 | Requerimiento REQ-4400 | 2026-07-25 | no figura | 85 |
| REQ-4412 | Requerimiento REQ-4412 | 2026-08-05 | no figura | 74 |
| REQ-4404 | Requerimiento REQ-4404 | 2026-08-15 | no figura | 64 |
| REQ-4414 | Requerimiento REQ-4414 | 2026-08-20 | no figura | 59 |
| REQ-4409 | Requerimiento REQ-4409 | 2026-08-30 | no figura | 49 |
| REQ-2030 | Requerimiento REQ-2030 | 2026-10-07 | no figura | 11 |
| REQ-2038 | Requerimiento REQ-2038 | 2026-10-08 | no figura | 10 |

Fuera de la lista: REQ-4401 sigue en «propuesto» (65 días sin decidir); no está decidido, así que todavía no es una brecha de construcción.

### La traza no se confirma
Ninguna. Ningún requerimiento nombra un proyecto, así que no hay traza que confirmar contra una ficha. Esta tabla no está vacía porque todo coincida, sino porque no hay eslabón registro → proyecto que cruzar.

### Lo que un proyecto construye y el registro no tiene
Ninguno. De las 13 fichas leídas (PRY-199 a PRY-211), ninguna dice ejecutar PRD-304:
- Declaran otro producto: PRY-199 (PRD-299), PRY-200 (crédito de consumo), PRY-201 (cuenta de ahorros), PRY-203 (APIs de datos), PRY-204 (tarjeta débito), PRY-206 (pagos QR), PRY-207 (cuenta PyME), PRY-209 (nómina empresarial), PRY-211 (recaudos).
- No declaran producto (campo vacío en la ficha, hallazgo del otro lado): PRY-202, PRY-205, PRY-208, PRY-210. Alguno de estos podría ser el que construye la tarjeta, pero la ficha no lo dice y no se infiere.

### La cadena completa
Cada eslabón decisión tiene cita (el acta del comité del 2026-10-18); la cadena se rompe en el segundo eslabón: ninguno tiene proyecto y, por lo tanto, tampoco entregables.

| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 17 requerimientos (REQ-2030, 2038, 4400, 4402–4415) | aceptado | comité, ver tabla de arriba | — | — | — |
| REQ-4401 | propuesto | sin decisión | — | — | — |

### Sin fichas a la vista
Hay fichas de 13 proyectos, pero ninguna se pudo usar para confirmar una traza porque no existe traza. Tampoco hay ficha publicada con nombre «tarjeta de crédito digital» ni con el código PRD-304; si el proyecto que la construye existe, su ficha no está en la carpeta o aún no se escribió.
