## Tarjeta de crédito digital (PRD-304) · 2026-10-18

**Corte anterior:** no existe (es la primera corrida de `product-wake`). Por eso no puedo separar lo que "cruzó un umbral desde entonces": todo lo de abajo es la línea base, y desde la próxima corrida solo se reportará lo nuevo.

**Qué tocaba:** `review` (nunca se había corrido; cadencia de 30 días). No tocan `report` ni `crossed`.

### Lo que necesita decisión del Comité de producto
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Requerimiento sin decidir (umbral 60 días) | REQ-4401 | 65 días (planteado el 2026-08-14) | Saber quién tiene la facultad de decidirlo; llevarlo al comité | Doliente: Carlos Peña. Facultad: Comité de producto |
| Aceptado sin criterio de aceptación | REQ-4400, REQ-4412, REQ-4414 | decidido hace 85, 74 y 59 días | Redactar el criterio antes de construir | Natalia Ospina, Óscar Ramírez, Elena Duarte |
| Aceptado sin doliente | REQ-4407, REQ-4408 | decidido hace 101 y 168 días | Nombrar a quién lo pidió | Sin dueño |
| Aceptado sin evidencia de demanda | REQ-2038, REQ-4402, REQ-4409, REQ-4410, REQ-4413 | de 10 a 212 días | Evidencia de que alguien lo pidió | Gustavo Neira, Ricardo Salas, Diana Molina, Jorge Medina, Felipe Arango |

### Evidencia que se queda sin sustento
13 requerimientos se apoyan en la misma entrevista del 2025-10-03, que cumple 12 meses (umbral 12). Además, la entrevista no nombra ninguno de ellos: dice «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). Si esa entrevista envejece, la afirmación de la definición de que el segmento Personas no tiene tarjeta de crédito digital queda sin sustento fechado. Hace falta evidencia de demanda más reciente.

### Las trazas
17 de 18 requerimientos están aceptados y **ninguno tiene proyecto asignado** (`requirement_untraced`, 17 de 17). No hay trazas que confirmar contra las fichas: hay que decidir quién construye lo aceptado.

### Del descubrimiento
Sin documentos nuevos que releer (no se releyó ninguno; `reread_unchanged` es falso). No se verificó el contenido de los documentos en esta corrida: las cifras salen del registro ya construido.

### Definición
- Declarado contra medido: `volumen_mensual` 263.889 declarado y 272.644 medido (2026-10-15), brecha de 3,3 % (umbral 20 %). No hay contradicción.
- Criterio de éxito: no está dicho en ninguna parte (`success`).
- Supuestos sin verificar: ninguno registrado.

### Lo que no sé
- La carpeta de fichas de la configuración (`estado`) mezcla archivos que no son fichas y `compute` falla con ella. Usé `estado/records`, la carpeta que sí tiene las fichas. La configuración conviene corregirla.
- Sin corte anterior no puedo decir qué es nuevo.

**Vuelvo el 2026-11-17.**
