## Definición — Tarjeta de crédito digital (PRD-304) · contrastada al 2026-10-18
**Documento:** `00-definicion/2026-01-21-definicion-producto.docx` (con `2026-01-21-caso-de-negocio.md`) · **del** 2026-01-21 · 5 afirmaciones (problema, segmento, volumen mensual, supuesto de demanda sin campaña, retorno en 24 meses)

*Borrador de trabajo, no decisión ni asesoría. Cada dato lleva la cita del documento; la verificación es de quien lo lea.*

### Lo que la evidencia contradice
Nada. Ninguna fuente contradice a otra con las fechas a la vista.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 263.889 | 272.644 | +3,3 % (umbral 20 %) | Caso de negocio, 2026-01-21 · Tablero de métricas (bodega de datos), corte 2026-10-15 |

La diferencia no pasa el umbral: es imprecisión, no contradicción. La serie tiene **un solo punto**; no se ve tendencia.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses | Caso de negocio, 2026-01-21 | La afirmación no trae cifra (ni porcentaje ni monto), así que no hay contra qué medir. Tampoco hay serie de ingresos ni de costo. |

### No está dicho en ninguna parte
- **Criterio de éxito.** Ningún documento lo declara.
- **Quién decide.** El acta del 2026-10-18 muestra al «Comité de producto» decidiendo («Se mantiene el plan»); ningún documento nombra a una persona. Asiste solo la gerente de producto.
- **Qué mide `volumen_mensual`.** Ni el caso de negocio ni el tablero lo definen (¿solicitudes, tarjetas activas, transacciones?). Sin eso, la cercanía de las dos cifras (3,3 %) no se puede leer como confirmación.
- **Cuánta gente del segmento Personas está sin tarjeta digital.** La definición afirma el problema sin cifra.
- **Qué significa «demanda declarada» y «sin campaña»** en el supuesto: ningún documento define la demanda ni la campaña contra la que se compara.
- **Cuánto pagaría o usaría el cliente.** No hay evidencia de pago ni de uso en la carpeta.
- **Monto y supuestos del retorno** (ver arriba).
- **En qué país opera el producto.** No está en la definición ni en la configuración (relevante para lo normativo).
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»; el registro muestra 17 requerimientos aceptados, ninguno trazado a un proyecto.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La demanda declarada se sostiene sin campaña (declarado 2026-08-02) | 0: figura verificado el 2026-09-11 (40 días después de declararse), pero **la verificación no se puede comprobar** | Poner en la carpeta el documento técnico del proveedor del 2026-09-11: el anexo solo dice «se confirmó» y no incluye método, datos ni cifra. Además, un documento técnico de proveedor no es evidencia de demanda en la jerarquía (pagó > dijo que usaría); haría falta un dato de comportamiento de clientes sin campaña. También: el supuesto lleva fecha 2026-08-02 dentro de una definición fechada 2026-01-21, así que la definición se editó después de su fecha sin que quede otra versión. |

Sin supuestos sin verificar según la marca del registro. Supuesto que no se puede desmentir como está escrito: «demanda declarada» no tiene referente, así que difícilmente se verificará de verdad.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe la necesidad en Personas («no tiene tarjeta de crédito digital») | Entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal), ronda de Liliana Torres | 2025-10-03 | Débil: una sola persona que dijo, no que pagó; es de antes de la definición; no establece que el segmento entero carezca del producto. |
| Volumen mensual de ~264 mil | Tablero de métricas, 272.644 | 2026-10-15 | Dato medido y coincidente (+3,3 %), pero un punto y sin definición de la métrica. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del cliente (sostiene 13 de los 18 requerimientos) | Entrevista del 2025-10-03 | 12 meses (umbral 12): cruzó el umbral. Además la entrevista no nombra ninguno de esos requerimientos. |

### Lo normativo que toca
País no declarado en ningún documento; todo queda en el estado «no tengo la norma a la vista». Esto va a revisión jurídica, no la reemplaza, y no dice si el producto cumple.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Producto de crédito para personas (consumidor financiero): información previa, reclamos, cobros | no declarado | Obligaciones de quien atiende consumidor financiero | — | no tengo la norma a la vista |
| Tarjeta / medio de pago: quién emite y mueve dinero, autorizaciones y reportes | no declarado | Medios y sistemas de pago | — | no tengo la norma a la vista |
| Datos personales y financieros de los solicitantes (autorización, finalidad, encargados) | no declarado | Tratamiento de datos personales | — | no tengo la norma a la vista |
| Proveedor externo interviene (documento técnico del proveedor) y posible infraestructura en nube | no declarado | Encargo de tratamiento y transferencia a otro país | — | no tengo la norma a la vista |
| Solicitud y aceptación digital de condiciones | no declarado | Firma y prueba del consentimiento | — | no tengo la norma a la vista |
| Conservación de la información de transacciones | no declarado | Retención y trazabilidad | — | no tengo la norma a la vista |

Primer paso: declarar el país; con eso el barrido puede nombrar norma y artículo en vez de dejar el vacío.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. **Sin él la definición no se puede cerrar**: el cierre se juzga contra él meses después.
- **Quién decide:** hay un comité, no una persona.
- **Problema y para quién:** sí están (problema: «El segmento Personas no tiene tarjeta de crédito digital»; para quién: Personas), pero el problema no trae medida de tamaño.
- **Proyecto que construye el producto:** ninguno declarado.

Por eso no se ofrece `/product-charter` todavía. Sí se ofrece convertir en riesgo con doliente (raid-taxonomy) la verificación del supuesto que no se puede comprobar, y declarar el país para el barrido normativo.

*Contexto (no es de esta definición, viene del registro de requerimientos): 17 de 18 requerimientos aceptados sin proyecto trazado; 5 aceptados sin evidencia; 3 sin criterio de aceptación; 2 sin doliente; 1 propuesto hace 65 días.*
