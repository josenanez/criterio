# Corrida del 2026-10-18 · product-setup

PRD-304 · 18 requerimientos · 32 s · 41 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 17 |
| `evidence_stale` | 13 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_undecided` | 1 |

0 preguntas respondidas por la persona (4 tomadas por defecto, sesión sin interfaz); tiempo aproximado, corrida-inicio solo para poder sellar; 6 documentos, 18 requerimientos levantados; 17 aceptados sin proyecto, 13 con evidencia vencida, 5 aceptados sin evidencia, falta criterio de éxito

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Tarjeta de crédito digital (PRD-304)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 6 documentos · 1 de descubrimiento (una ronda de entrevistas del 2025-10-03, con una sola cita de un solo cliente) · la definición y el caso de negocio del 2026-01-21 · lo más reciente es el acta del comité de producto del 2026-10-18. Los 6 se leyeron (md y docx); no hay formatos que no pueda leer.
**Términos:** aceptados para la versión 1.1 (familia 0.5.0) por José Francisco Ñáñez, 2026-10-18 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 05a6d511835489a1…

**Sin interfaz, respuestas por defecto (4):**
- Quién eres y qué producto es: Liliana Torres, gerente de Tarjeta de crédito digital (PRD-304), segmento Personas, tal como dice la definición.
- Quién decide qué se construye: «Comité de producto». Es lo único que los documentos permiten proponer; ninguno nombra a una persona que decida.
- Dónde guardo el estado: `estado-producto/PRD-304`, hermana de la documentación, separada de `estado/` (la del portafolio).
- Términos: ya registrados arriba.

**Levantado:** `producto.json` y 18 requerimientos del acta del comité (17 aceptados, 1 propuesto), solo con lo que está escrito. Lo que ningún documento dice queda como `not_found`. Lectura sellada sobre los 6 documentos.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Personas no tiene tarjeta de crédito digital | Una cita: «Lo necesito y hoy no lo tengo» (entrevistas, un cliente). Sostiene que una persona la necesita; no mide el segmento | 2025-10-03 |
| Volumen mensual de 263.889 (caso de negocio) | El tablero mide 272.644 al corte del 2026-10-15: diferencia de 3,3 %, por debajo del umbral de 20 %. Coincide | Declarado 2026-01-21 · medido 2026-10-15 |
| La demanda declarada se sostiene sin campaña | Un supuesto. El anexo del 2026-09-11 dice «se confirmó» y cita un documento técnico del proveedor | Supuesto 2026-08-02 · verificado 2026-09-11 |
| Retorno esperado en 24 meses | Nada: sin cifra, sin cálculo, sin fuente | — |
| Los 17 requerimientos aceptados responden a demanda | 12 citan «cliente entrevistado», es decir, la misma entrevista de 2025-10-03, que no nombra ninguno de ellos. 5 no citan a nadie | 2025-10-03 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito del producto.** No existe en la definición ni en el caso de negocio. Sin él, nada se puede cerrar después.
- **Quién decide, como persona.** El acta solo registra un asistente, Liliana Torres, y la decisión «Se mantiene el plan» sin decir qué plan ni quién lo mantiene. Tampoco hay quién aceptó cada requerimiento.
- **Qué es la «propuesta».** La definición dice solo «Propuesta principal».
- **De dónde sale el retorno a 24 meses.**
- **Qué sostiene que la demanda se sostiene sin campaña.** El documento del proveedor del 2026-09-11 no está en la carpeta, y un documento técnico de un proveedor no es evidencia de que alguien pidió algo. La verificación se registró como el anexo la declara, pero no se pudo comprobar.
- **Un proyecto que construya algo.** La definición dice «Ninguno declarado», y los 17 requerimientos aceptados tienen «—» en proyecto: 0 de 17 trazados (0,0 %).
- **Qué cuenta el volumen mensual.** El tablero mide 272.644 de un producto sin proyecto declarado y no dice qué se está contando.

### Lo que el registro ya muestra (calculado, no estimado)
- **Aceptados sin proyecto:** 17 de 17.
- **Evidencia vencida (más de 12 meses):** 13 requerimientos. Toda la evidencia es la entrevista del 2025-10-03.
- **Aceptados sin evidencia:** 5 (REQ-2038, REQ-4402, REQ-4409, REQ-4410, REQ-4413). Con evidencia: 12 de 17 (70,6 %).
- **Aceptados sin criterio de aceptación:** 3 (REQ-4400, REQ-4412, REQ-4414).
- **Sin doliente:** 2 (REQ-4407, REQ-4408, «sin asignar»).
- **Propuesto sin decidir:** REQ-4401, 65 días.
- Nota: REQ-2030 y REQ-2038 llevan otra numeración y fecha de octubre; se registraron como están y conviene confirmar que son de este producto.

### Supuestos sobre los que está escrita
Uno declarado: «La demanda declarada se sostiene sin campaña» (declarado 2026-08-02, verificado 2026-09-11 según el anexo). La definición lleva fecha 2026-01-21 pero contiene texto de agosto y septiembre; no dice cuándo se revisó.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas: hay una cita y no se sabe cuántos clientes hablaron. Sin ellas, la demanda de 17 requerimientos descansa en una frase.
- Una entrevista o serie de demanda más reciente que octubre de 2025.
- El documento técnico del proveedor del 2026-09-11.
- La serie histórica de `volumen_mensual` (hay un solo punto, 2026-10-15) y qué cuenta.
- El criterio de éxito, y las decisiones del comité por requerimiento: sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.

### Después
`/product-discovery` sobre el material de entrevistas: ahí los temas se vuelven requerimientos con la cita de quién lo pidió.

*Nota técnica: sellar exigió abrir una corrida (`corrida-inicio`) y reescribir la ficha después; por eso el tiempo hasta el primer resultado queda registrado de forma aproximada.*
