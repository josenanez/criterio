# Corrida · 2026-10-18-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:03:17 · **Fin:** 2026-10-18T08:04:18 · **Duración:** 61 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 36 | 14 | Escala un punto: el acta no declara la autoridad del gerente. Sin impact: no hay fecha que se mueva ni días declarados. Los compromisos de 3+ reprogramaciones no se formularon: las minutas no dicen la causa. Costos y días de las opciones: no están en los documentos, no se inventaron. |

Por señal (`pm-escalate`): `commitment_overdue` 8, `commitment_rescheduled` 3, `commitment_undated` 2, `progress_vs_plan` 1

## Lo que el agente mostró

Para PRY-201 solo escala un punto: el acta de constitución no declara qué puede decidir el gerente por sí mismo. Armé el paquete de decisión sobre ese punto y registré la corrida.

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18, así que no los registré de nuevo. Como nadie podía responder, tomé "lo que ya está marcado como escalable".

**La pregunta cerrada:** ¿se declara por escrito la autoridad del gerente y el tope desde el que sube (opción A), o se sigue escalando caso por caso (opción B)?

- **Quién decide:** el acta no dice quién define la autoridad. Propongo al Comité de Arquitectura con la patrocinadora Liliana Torres, y el paquete lo marca como propuesta mía, no como lo que dice el acta.
- **Si no se decide hoy:** el comité del 2026-11-01 llega sin saber a quién subir lo que pida el hito "Ambiente de pruebas certificado" del 2026-11-08, que sigue pendiente y sin evidencia. Las notas del 10-18 dicen "próxima reunión en dos semanas", así que esa fecha puede cambiar.
- **Recomiendo A**, porque sin autoridad escrita no se puede clasificar ningún otro escalamiento.

**Lo que no pude calcular:**
- **Costos y duración de las opciones:** no hay cifras en los documentos y no las inventé; las tablas lo dicen.
- **A quién alcanza:** no corrí `impact`, porque este punto no mueve ninguna fecha. El acta tampoco declara dependencias con otros proyectos.

**Lo que no armé como paquete:**
- **Documento 1 (Diana Molina), prueba 2 (Andrés Lozano) y ambiente 4 (Natalia Ospina):** cumplen la regla de tres o más reprogramaciones (6, 5 y 3 movimientos), pero las minutas no dicen la causa. Sin causa no puedo decir si exceden tu autoridad ni formular las opciones.
- **Fecha del documento 1:** está escrita "03/12/2026". La leí como 3 de diciembre (día/mes); conviene que la confirmes.
- **Riesgo del proveedor:** no escala, es tuyo registrarlo. La revisión con el proveedor, de Óscar Ramírez, es el 2026-10-28.

Archivos en `estado/PRY-201-core-de-depósitos/corridas/`:
- `salida-pm-escalate.md`
- `2026-10-18-pm-escalate-1.md`
