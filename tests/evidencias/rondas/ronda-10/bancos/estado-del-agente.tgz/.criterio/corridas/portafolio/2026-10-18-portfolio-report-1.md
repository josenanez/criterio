# Corrida · 2026-10-18-portfolio-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-report html

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:26:43 · **Fin:** 2026-10-18T08:27:36 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-report` | 13 | 77 | 35 | 67 | Verdes contradichos (PRY-200, 204, 206, 211) y 23 hitos cumplidos sin evidencia; ningún proyecto con patrocinador identificado. |

Por señal (`portfolio-report`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Generé el informe HTML del portafolio y registré la corrida: 13 proyectos, 11 con hallazgos y 67 señales en total.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hubo nada que registrar. Las fichas están en `estado/records/` y son del 2026-10-18, sin ninguna vieja. La configuración pedía `pptx`, pero usé `html` porque lo indicaste en el comando.

**Dónde quedó**
- **`index.html`:** la vista por campo, con la cadena de evidencia de cada dato. Es para quien va a actuar.
- **`decisiones.html`:** la vista por decisión. Es para el patrocinador y el comité.
- **Resto de la carpeta:** una página por proyecto, por producto, y `proyectos.html` y `productos.html`, 26 páginas en total.

Todo está en `/home/claude/banco/ronda-10/bancos/espacio/reportes/`.

**Qué cambió:** nada. La única instantánea anterior es la de hoy, así que este informe es punto de partida y no hay diferencias que reportar.

**Lo más importante**
- **Verdes contradichos:** cuatro proyectos se declaran en verde y la evidencia no lo sostiene: PRY-200, PRY-204, PRY-206 y PRY-211.
- **Hitos sin respaldo:** 23 hitos figuran como cumplidos sin documento que lo respalde. Hay además 2 vencidos, uno en PRY-200 (4 días) y otro en PRY-210 (8 días).
- **Silencio:** PRY-200 lleva 19 días sin documentos nuevos.
- **Costo:** cuatro proyectos superan el umbral del 10 %: PRY-204, PRY-208, PRY-209 y PRY-210. Los tres últimos están entre +18 % y +21 %.
- **Tiempo:** tres proyectos superan el umbral del 10 % de atraso frente a la línea base original: PRY-207, PRY-210 y PRY-211.
- **Gobierno:** ningún proyecto tiene patrocinador identificado, 13 de 13. PRY-210 tiene además una replanificación de línea base sin autorización.
- **Compromisos:** hay 10 vencidos sin evidencia, 2 sin fecha y 3 reprogramados; casi todos en PRY-201.
- **Proveedores:** en PRY-202 y PRY-210 hay entregables tarde, un entregable aceptado sin evidencia y una factura por encima de lo aceptado.

No hay preguntas de confirmación este mes; tomé la respuesta sugerida y las dejé para la corrida mensual.

Lo que mostré está en `estado/corridas/salida-portfolio-report.md`. La corrida quedó registrada como `2026-10-18-portfolio-report-1` y tardó 35 segundos. Las 77 fuentes estaban sin cambios y no se releyó ninguna.

¿Preparo el material de comité para el 2026-10-25 o entramos al detalle de los cuatro verdes contradichos?
