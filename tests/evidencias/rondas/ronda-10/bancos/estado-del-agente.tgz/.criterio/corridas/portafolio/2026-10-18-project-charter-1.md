# Corrida · 2026-10-18-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-18T08:22:09 · **Fin:** 2026-10-18T08:22:57 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 32 | 67 | Revisión del acta PRY-203 (2025-06-14): faltan autoridad del gerente, supuestos/restricciones, hitos, cadencia y quién mide el éxito; objetivo, alcance y exclusiones son genéricos. No sé qué se acordó fuera de los dos documentos leídos (acta e informe de avance); no hay minutas. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Acta PRY-203 Open Banking: revisión

**Acta previa:** sí, del 2025-06-14. Los términos ya estaban vigentes (José Francisco Ñáñez, 2026-10-18, v0.5.0), así que no los volví a registrar.

**Vacíos, con su consecuencia:**
- **Autoridad de Laura Vélez:** no está. Todo cambio de monto o alcance sube al Comité de Riesgos. Hoy pesa porque hay un cambio regulatorio en discusión que puede mover el alcance.
- **Objetivo de negocio:** es la solución ("Entregar open banking…"), no un resultado medible. El cierre no tiene contra qué compararse.
- **Alcance y exclusiones:** son marcadores sin contenido ("Componente 1, 2, 3" y "Lo que otro proyecto cubre"). Cualquier solicitud de cambio se discute sin referencia.
- **Criterio de éxito:** "en producción y medido", sin métrica ni umbral. Tampoco dice quién lo mide.
- **Supuestos, restricciones, hitos y cadencia del comité:** no están. Del acta solo salen inicio y cierre.
- **Patrocinador y gerente:** presentes con nombre (Ricardo Salas y Laura Vélez).

**Fuera del acta, pero relevante:** el cierre comprometido era el 2026-08-10 y ya pasó. El informe declara Verde con 40% de avance. No encontré una línea base nueva. Lo dejé señalado para `/status-report` y `/change-control`; las cifras del informe son declaraciones y no las contrasté.

**Lo que no sé:** solo leí dos documentos, el acta y el informe de avance. No hay minutas, así que no sé si la autoridad del gerente se acordó fuera de ellos.

**Siguientes pasos que ofrezco:**
- Llevar la definición de autoridad al comité.
- Pasar los supuestos al registro RAID.

La salida completa quedó en `estado/corridas/salida-project-charter.md`. La corrida quedó registrada como `2026-10-18-project-charter-1`.
