# Corrida · 2026-10-18-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T07:49:48 · **Fin:** 2026-10-18T07:50:39 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 18 | — | 36 | 41 | Caso de negocio armado: 2 cifras con fuente (declarada 263.889 vs medida 272.644, +3,3 %, bajo umbral). Dijo que no sabe: costo de construir, cifra del retorno a 24 meses, qué mide volumen_mensual, criterio de éxito, decisor, país, proyecto; el supuesto 'sin campaña' no es comprobable. Sin otros productos publicados para cruzar. |

Por señal (`product-business-case`): `requirement_untraced` 17, `evidence_stale` 13, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 3, `requirement_without_owner` 2, `requirement_undecided` 1

## Lo que el agente mostró

Armé el caso de negocio de PRD-304 (Tarjeta de crédito digital) y registré la corrida. El documento deja dos cifras con fuente y diez vacíos, y el primer vacío es el costo de construir. Sin costo, lo que hay es una propuesta, no un caso evaluable.

Los términos ya estaban vigentes y aceptados (v1.1, 2026-10-18, José Francisco Ñáñez), así que no los registré de nuevo.

**Cifras con fuente**
- **Declarada:** el volumen mensual es 263.889 (caso de negocio, 2026-01-21).
- **Medida:** el volumen mensual es 272.644 (tablero de métricas, corte 2026-10-15).
- **Contraste:** la diferencia es +3,3 %, bajo el umbral de 20 %. La serie tiene un solo punto. Ni el caso ni el tablero definen qué mide `volumen_mensual`, así que la cercanía no confirma nada.

**Supuesto central:** «la demanda se sostiene sin campaña» figura como verificado, pero el documento del proveedor en que se apoya no está en la carpeta. El anexo solo dice «se confirmó». Lo dejé como supuesto, no como cifra declarada.

**Vacíos nombrados**
- **Costo y retorno:** no hay costo de construir, y el «retorno esperado en 24 meses» no trae cifra.
- **Éxito y decisión:** no hay criterio de éxito, así que el documento dice que sin él no se podrá cerrar el producto. Tampoco hay una persona que decida: solo aparece el comité.
- **Alcance:** no se declara el país ni qué mide `volumen_mensual`.
- **Alternativas:** no se dice qué se consideró ni qué pasa si no se hace.
- **Trazabilidad:** 0 de 17 requerimientos aceptados tienen proyecto, y 5 se aceptaron sin cita de quien los pidió.

No hay otros productos publicados, así que no hubo cruce de cifras. No ofrecí `/product-charter` porque faltan criterio de éxito, decisor y costo. Sí queda sugerido pasar el supuesto «sin campaña» a assumption-tracking.

La corrida quedó registrada con id `2026-10-18-product-business-case-1`.

Archivos en `estado-producto/PRD-304/corridas/`:
- `salida-product-business-case.md`
