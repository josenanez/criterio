# Corrida · 2026-10-18-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:24:09 · **Fin:** 2026-10-18T08:25:59 · **Duración:** 110 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 92 | 67 | Paquete de comité: 6 decisiones (autoridad, PRY-210, PRY-204, PRY-208, PRY-209, PRY-202) y 5 escalamientos. No sabe: quién tiene autoridad (13/13 sin registrar), qué decidió el comité anterior (sin registro), si el CC-01 de PRY-204 tiene acta, ni las diferencias de costo no calculadas por el script. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

Armé el paquete del comité del 2026-10-25 con 6 decisiones y 5 escalamientos. Se apoya en las 13 fichas (PRY-199 a PRY-211), con corte al 2026-10-18.

Las cifras salen de `compute`. Dos que escribí a partir de los documentos: los 204.000.000 y 234.000.000 COP de los cambios CC-01 son los impactos declarados en cada solicitud, no cálculos míos.

**Términos:** ya estaban vigentes (versión 1.1, aceptada el 2026-10-18 por José Francisco Ñáñez). No registré un comprobante nuevo.

**Decisiones del comité**
1. **Autoridad:** definir quién aprueba cambios de línea base y presupuesto. La autoridad falta en los 13 proyectos, y recomiendo resolverlo antes que los demás puntos.
2. **PRY-210 (Portal de proveedores):** el cambio CC-01 está pendiente (+102 días, +204.000.000 COP), pero la línea base ya se movió 102 días sin autorización. Ricardo Salas es a la vez gerente y patrocinador, así que no puede ser quien apruebe. Recomiendo aprobar solo con un replan.
3. **PRY-204 (Débito contactless):** el cambio CC-01 figura aprobado por el comité (+117 días, +234.000.000 COP) pero la línea base no se movió, y no hay acta que lo respalde. La proyección de costo está +10.4% sobre lo aprobado. Recomiendo ratificarlo en acta y registrar la línea base nueva.
4. **PRY-208 y PRY-209:** las dos proyectan +20.8% y +20.3% sobre el presupuesto. Declaran 40% y 37% de avance con todos sus hitos cumplidos, tres de cada uno sin evidencia. Recomiendo congelar hasta reconciliar hitos y avance.
5. **PRY-202 (Migración a la nube):** se facturó 80.288.517 COP por encima de lo aceptado, y el licenciamiento del motor lleva 228 días vencido. Recomiendo retener pagos nuevos hasta que haya evidencia de aceptación.

Las recomendaciones son juicio del material, no cifras. Cuando no pude calcular el efecto de una opción, lo dice la tabla.

**Escalamientos sin decisión:** PRY-200, 201, 205, 206 y 211, cada uno con lo que se necesita del gerente antes del comité.

**Lo que no sé**
- No hay registro de decisiones del comité anterior, así que esa sección dice exactamente eso.
- Ninguna fuente de las 13 fichas está marcada como evidencia: todo es declaración o sin marcar.

La salida completa está en `estado/corridas/salida-steering-pack.md` y la corrida quedó registrada como `2026-10-18-steering-pack-1` (92 segundos, 67 hallazgos). Cuando el comité sesione, puedo registrar sus decisiones en las fichas.
