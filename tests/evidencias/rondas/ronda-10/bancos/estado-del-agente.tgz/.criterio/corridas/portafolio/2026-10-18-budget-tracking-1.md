# Corrida · 2026-10-18-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-18T08:15:22 · **Fin:** 2026-10-18T08:16:13 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 37 | 67 | Presupuesto PRY-210: proyección 18,1% sobre aprobado; comprometido declarado menor que ejecutado (incoherente); sin evidencia contable; CC-01 pendiente. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Presupuesto — PRY-210 Portal de proveedores al 2026-10-18

Salen de la ficha de PRY-210 y de `portafolio.py compute`. Los documentos de origen son el acta de constitución, el informe de avance del 2026-10-17, la solicitud de cambio CC-01 y el cronograma v2. Los términos v1.1 estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18. Todo está en COP.

| | Monto (COP) | % del aprobado | Fuente |
|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | Acta, 2025-09-11 |
| Comprometido | 1.765.771.095 | 53,5% | Informe de avance, 2026-10-17 (declaración) |
| Ejecutado | 2.045.359.196 | 62,0% | Informe de avance, 2026-10-17 (declaración) |
| Proyección al cierre | 3.896.316.249 | 18,1% sobre el aprobado | Informe de avance, 2026-10-17 (declaración) |

- **Disponible real:** 1.534.228.905 COP, pero no es confiable. El comprometido declarado es menor que el ejecutado, y lo ejecutado debería estar dentro de lo comprometido. Una de las dos cifras está mal o mide otra cosa.
- **Contra la línea base:** el presupuesto aprobado sigue en 3.300.000.000 y no hay replanificaciones de presupuesto aprobadas. CC-01 está pendiente, sin decisión: pide 204.000.000 COP adicionales y +102 días. El cronograma v2 ya movió el cierre de 2027-01-14 a 2027-04-26 sin autorización.
- **Ejecución frente a avance:** se ha ejecutado el 62,0% con el 48,0% de avance declarado. El plan sostiene entre 60% y 80%. Hay 3 de 5 hitos cumplidos, y solo "Integración con el core" tiene evidencia.
- **Alertas:**
  - La proyección supera el aprobado en 18,1%, con umbral de 10%.
  - El comprometido es incoherente con el ejecutado.
  - El gasto va por encima del avance.
  - Integra Sistemas (CT-137) tiene 2 entregables vencidos sin recibo, y lo facturado (268.808.113) es igual a lo aceptado.
- **Sin dato:**
  - No hay presupuesto vigente distinto del original.
  - No hay evidencia contable del ejecutado: las tres cifras de gasto son declaraciones del gerente.
  - La fuente del aprobado tiene 13 meses, por encima del umbral de 12.

Si quiere, preparo la solicitud de cambio de presupuesto, porque la proyección excede el aprobado. También puedo detallar el comprometido por proveedor para aclarar la incoherencia.

La corrida quedó registrada como `2026-10-18-budget-tracking-1`, con 9 señales abiertas en PRY-210. El informe completo está en `estado/corridas/salida-budget-tracking.md`.
