# Corrida · 2026-10-18-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4400

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4400

**Inicio:** 2026-10-18T07:52:18 · **Fin:** 2026-10-18T07:53:12 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 18 | — | 38 | 41 | Borrador de acta de REQ-4400 con 9 vacíos marcados (sin criterio de aceptación, sin quien decidió, evidencia débil y de 12,5 meses, sin autoridad, sin patrocinador ni gerente, sin país para lo normativo). Ficha no creada: falta la firma. |

Por señal (`product-charter`): `requirement_untraced` 17, `evidence_stale` 13, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 3, `requirement_without_owner` 2, `requirement_undecided` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4400, pero con 9 vacíos que no rellené. La ficha del proyecto no se creó, porque nadie ha firmado el acta. El texto completo está en `estado-producto/PRD-304/corridas/salida-product-charter.md`.

**Términos:** ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-18), así que no los volví a registrar.

**Qué falta en REQ-4400.** Tomé la respuesta sugerida y seguí sin esos elementos, marcados como vacíos:
- **Criterio de aceptación:** no tiene. La definición tampoco trae criterio de éxito.
- **Quién lo aceptó:** el comité solo dice «Se mantiene el plan», y ningún documento nombra a una persona que decida.
- **Evidencia de demanda:** es débil. La única es la entrevista del 2025-10-03, que no nombra el requerimiento y tiene más de 12 meses (el umbral configurado es 12).
- **Autoridad del gerente, patrocinador y gerente del proyecto:** no están dichos en ningún documento.
- **Supuesto de demanda sin campaña:** pasa al proyecto como riesgo sin doliente asignado. Su verificación cita un documento técnico del proveedor que no está en la carpeta.
- **Restricciones normativas:** quedan todas como «no tengo la norma a la vista», porque ningún documento declara el país.
- **Otros 17 requerimientos del registro:** quedan fuera del alcance de esta acta.

**Qué sigue.** Alguien con autoridad sobre el producto firma el acta, y el gerente del proyecto, ya designado, instala `criterio-project` y corre `/pm-setup`.

La corrida quedó registrada como `2026-10-18-product-charter-1`, en 38 segundos.
