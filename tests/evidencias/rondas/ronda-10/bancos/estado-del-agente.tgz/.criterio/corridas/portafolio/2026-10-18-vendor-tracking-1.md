# Corrida · 2026-10-18-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-18T08:16:18 · **Fin:** 2026-10-18T08:17:15 · **Duración:** 57 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 41 | 67 | Proveedor Redes del Norte (CT-812): factura FV-1812 de 614.970.173 COP frente a 534.681.656 aceptados (diferencia 80.288.517); bolsa de horas aceptada sin acta; licenciamiento pendiente 228 días. No supe: vigencia y preaviso del contrato, desglose de la factura, reuniones con el proveedor. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

La corrida de proveedores de PRY-202 (Migración a la nube) quedó hecha y registrada. Hay una factura radicada de 614.970.173 COP que no cuadra con lo aceptado.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré otra vez. Las cifras derivadas salen del cálculo del script (`compute`). Una carpeta de PRY-202 sin reuniones ni ficha de PM limita el análisis.

**Redes del Norte Ltda., contrato CT-812** (3 entregables de 267.340.828 COP cada uno):
- **Licenciamiento del motor:** pendiente y vencido hace 228 días (comprometido para el 2026-03-04). El proyecto debía cerrar el 2026-09-25 y el informe de avance no lo menciona.
- **Bolsa de horas de desarrollo:** el cálculo la cuenta como aceptada, pero no hay acta de recibo. Solo el contrato la marca "recibido", y eso es una declaración.
- **Parametrización del tarifario:** aceptada, con acta del 2026-08-20.
- **Factura FV-1812 (2026-10-01):** cobra 614.970.173 COP frente a 534.681.656 aceptados, una diferencia de 80.288.517 COP. No desglosa los entregables que cobra, y el contrato exige acta de recibo para facturar. Como solo una acta está en la carpeta, la diferencia real sería mayor, pero el script no la calcula y no la escribí.
- **Avance:** el informe declara 51 % y estado amarillo, mientras el cronograma marca 5 de 5 hitos cumplidos, todos sin documento de evidencia.

**Sin dato:** vigencia, renovación y preaviso del contrato (no los trae, así que no sé si hay un preaviso por vencer), el desglose de la factura, el acta de la bolsa de horas y las reuniones con el proveedor. Tampoco pude revisar compromisos vencidos del proveedor.

Recomiendo llevar el tema al comité del 2026-10-25, antes del pago, con dos preguntas: quién tiene el acta de la bolsa de horas y a qué entregables corresponde FV-1812. No lo he llevado.

Archivos en `estado/corridas/`:
- `salida-vendor-tracking.md`
- `2026-10-18-vendor-tracking-1.md`
