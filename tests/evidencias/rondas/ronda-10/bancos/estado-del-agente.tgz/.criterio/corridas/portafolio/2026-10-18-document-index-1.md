# Corrida · 2026-10-18-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:11:56 · **Fin:** 2026-10-18T08:12:23 · **Duración:** 27 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 15 | 67 | 77 documentos sin cambio, 0 por releer. 101 citas de PRY-201 marcadas como no resueltas pese a que los archivos existen en su carpeta; probable diferencia de resolución de ruta relativa, sin confirmar. |

Por señal (`document-index`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Carpeta al 2026-10-18

**Documentos:** 77 · **Sin cambio:** 77 · **Hay que releer:** 0

No cambió, se reguardó, se renombró ni se borró ningún documento. Ningún proyecto necesita recálculo, así que no hay barrido que ofrecer.

**Citas que dejaron de resolver:** el índice marca 101 campos de la ficha de PRY-201 como no resueltos. Cubren identidad, estado declarado, plan, hitos, dinero y compromisos 0–25. Los 9 documentos citados sí existen en `documentos/proyectos/PRY-201-core-de-depósitos/`. Mi hipótesis es que las citas van relativas a la carpeta del proyecto y el índice las busca desde la raíz de `documentos/proyectos`. No lo he confirmado leyendo el script. Ninguna otra ficha tiene citas rotas.

**Formatos que no se pudieron leer:** ninguno, porque este comando no lee documentos.

**Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no hizo falta registrarlos de nuevo.

**Corrida registrada:** `2026-10-18-document-index-1`, con 15 segundos medidos. Dejé la salida completa en `estado/corridas/salida-document-index.md`. El registro de la corrida incluye 67 hallazgos en 13 proyectos, que no vienen del índice sino de las fichas ya calculadas. No los analicé aquí.
