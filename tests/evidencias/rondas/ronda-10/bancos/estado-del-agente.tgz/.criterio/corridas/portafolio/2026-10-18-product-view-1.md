# Corrida · 2026-10-18-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view nómina empresarial

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:26:05 · **Fin:** 2026-10-18T08:26:38 · **Duración:** 33 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 19 | 67 | Producto de un solo proyecto (PRY-209); sin sección de producto. Reportó 4 proyectos sin producto y PRD-299 sin normalizar. No sabe autoridad ni fase de PRY-209, ni el área dueña de los proyectos sin producto. |

Por señal (`product-view`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## Nómina empresarial, al 2026-10-18

Salgo de las fichas en `estado`, recalculadas hoy. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los registré otra vez.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209 Nómina electrónica) | 5 alertas | 2026-07-21 (vencida hace 89 días) | COP 4.200.000.000 | COP 2.805.816.203 |

Este producto tiene un solo proyecto, PRY-209. La vista por producto no aporta más que la ficha del proyecto, así que no armé sección de producto. Tampoco hay dependencias internas que cruzar.

Lo que dice la ficha de PRY-209:
- **Avance:** declara 37,0 %, pero los 4 hitos del plan figuran como cumplidos y respaldan 100 %. La brecha es de 63,0 puntos.
- **Hitos cumplidos sin evidencia:**
  - «Diseño funcional aprobado», que vence el 2026-01-06, hace 285 días.
  - «Integración con el core», que vence el 2026-05-17, hace 154 días.
  - «Piloto con usuarios internos», que vence el 2026-07-21, hace 89 días.
- **Costo:** la proyección es COP 5.052.016.044 contra COP 4.200.000.000 aprobados, 20,3 % por encima. Lo ejecutado es COP 2.347.857.763 (55,9 %), lo comprometido es el 66,8 % y lo disponible real es COP 1.394.183.797.
- **Informe de avance:** declara estado rojo, pero no reconoce estas tres señales.
- **Dinero:** el proyecto trae las cuatro cifras, así que la suma no está incompleta.
- **Lo que no sé:** la autoridad del proyecto y su fase, porque faltan en la ficha. Además, 24 campos de la ficha vienen de una fuente del 2025-10-23, con 12 meses de antigüedad.

Hay 4 proyectos sin producto declarado: PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión y PRY-210 Portal de proveedores. Nadie puede responder por el conjunto al que sirven. No afirmo su área dueña, porque el cálculo no la entrega.

PRY-199 declara el producto «PRD-299», que es un código y no un nombre. Conviene confirmar que está normalizado.

La verificación de las citas es de quien lee. No crucé documentos fuera de las fichas.

La corrida quedó registrada como `2026-10-18-product-view-1`, con el texto en `estado/corridas/salida-product-view.md`.
