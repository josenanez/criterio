# Corrida · 2026-10-18-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T07:48:49 · **Fin:** 2026-10-18T07:49:43 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 18 | — | 39 | 41 | De la definición, el volumen mensual lo sostiene el dato medido (+3,3 %); el problema solo lo sostiene una entrevista de hace 12 meses; el supuesto de demanda sin campaña se dio por verificado con un documento que no está en la carpeta; faltan criterio de éxito, quien decide y el país para lo normativo |

Por señal (`product-definition`): `requirement_untraced` 17, `evidence_stale` 13, `requirement_accepted_without_evidence` 5, `requirement_without_acceptance` 3, `requirement_without_owner` 2, `requirement_undecided` 1

## Lo que el agente mostró

La corrida de `/product-definition` para PRD-304 (Tarjeta de crédito digital) terminó y quedó registrada en 39 segundos. El único cálculo que hace el comando, el contraste de la cifra de volumen, sale sin contradicción.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18), así que no los volví a registrar.
- **Contradicciones:** ninguna.
- **Volumen mensual:** el caso de negocio declara 263.889 y el tablero del 2026-10-15 mide 272.644. La diferencia es de +3,3 %, bajo el umbral del 20 %. La serie tiene un solo punto, y ningún documento define qué mide esa métrica.
- **Retorno en 24 meses:** nadie lo mide, porque la afirmación no trae cifra.
- **Problema ("Personas no tiene tarjeta digital"):** lo sostiene una sola entrevista del 2025-10-03, que ya cruzó el umbral de 12 meses. Es evidencia débil: una persona que dijo, no que pagó.
- **Supuesto "la demanda se sostiene sin campaña":** figura como verificado con un documento técnico del proveedor del 2026-09-11. Ese documento no está en la carpeta, y el anexo solo dice "se confirmó". El supuesto además lleva fecha 2026-08-02 dentro de una definición fechada 2026-01-21.
- **Lo normativo:** el país no aparece en ningún documento, así que los seis temas que toca el producto quedan en "no tengo la norma a la vista". Los temas son consumidor financiero, medios de pago, datos personales, proveedor o nube, consentimiento digital y retención. No cité ninguna norma.
- **Lo que falta para cerrar la definición:**
  - El criterio de éxito.
  - Una persona que decida; hoy solo figura el Comité de producto.
  - Un proyecto declarado que construya el producto; la definición dice "Ninguno declarado" y los 17 requerimientos aceptados no están trazados a ninguno.

Por esto último no ofrecí `/product-charter`. Sí ofrezco registrar como riesgo con doliente la verificación del supuesto que no se puede comprobar, y declarar el país para repetir el barrido normativo.

Lo que le mostré a la persona quedó en `estado-producto/PRD-304/corridas/salida-product-definition.md`. La corrida contó 41 hallazgos sobre los requerimientos, y el registro de la corrida se guardó como `2026-10-18-product-definition-1`.
