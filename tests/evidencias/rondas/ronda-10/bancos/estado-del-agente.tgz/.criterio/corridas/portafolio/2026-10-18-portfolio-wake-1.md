# Corrida · 2026-10-18-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-18; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-18T08:27:38 · **Fin:** 2026-10-18T08:28:21 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 29 | 67 | Barrido: 77 documentos sin cambios, nada que recalcular. Confirmación: 5 campos de PRY-201 preguntados, sin respuesta (sesión sin interfaz). 118 citas de PRY-201 marcadas sin resolver aunque los archivos existen; probable desajuste de ruta, no confirmado. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 23, `commitment_overdue` 10, `progress_vs_plan` 8, `declared_vs_evidence` 4, `variance_cost` 4, `commitment_rescheduled` 3, `vendor_deliverable_late` 3, `variance_time` 3, `milestone_overdue` 2, `commitment_undated` 2, `silent` 1, `vendor_accepted_without_evidence` 1, `vendor_invoiced_over_accepted` 1, `change_without_baseline` 1, `rebaseline_unauthorized` 1

## Lo que el agente mostró

## 2026-10-18

**Revisé:** 77 documentos. Ninguno cambió y no recalculé ningún proyecto. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-18, así que no hubo que registrarlos de nuevo.

**Umbrales:** ninguno cruzó. El barrido corrió, y no encontró documentos nuevos, cambiados, renombrados ni borrados.

**Citas sin resolver:** `index` marca 118 citas de PRY-201 como no resueltas. Los archivos sí existen en `documentos/proyectos/PRY-201-core-de-depósitos/`. Parece un desajuste de ruta entre la ficha del proyecto y el record, no documentos perdidos. No lo he confirmado y queda para revisar a mano.

**Peticiones:** no había ninguna pendiente.

**Preguntas de la confirmación:** nadie las puede responder en esta sesión, así que quedan registradas como «preguntada el 2026-10-18, sin respuesta». Son cinco campos de PRY-201:
1. `identity.authority`: no aparece en ningún documento.
2. `identity.phase`: no aparece en ningún documento.
3. `money.committed` (935.701.138 COP): sale solo de la declaración del informe de avance del 2026-10-16.
4. `money.executed`: sale solo de esa misma declaración.
5. `money.projection`: sale solo de esa misma declaración.

**Registro de la corrida:** `corrida` la guardó con 29 segundos y 67 hallazgos abiertos en los 13 proyectos. Esos hallazgos vienen de corridas anteriores, no de hoy.

La salida está en `estado/corridas/salida-portfolio-wake.md`.

**Vuelvo el 2026-10-19.**
