Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hubo que volver a registrarlos.

# Acta — PRY-201 Core de depósitos · 2026-10-18
**Asistieron:** Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez (13) · **Fuente:** `2026-10-18-notas-reunion.txt` · **Ausentes con tema en agenda:** no se puede decir, las notas no traen agenda. Javier Hoyos (tiene abierto «Entregar el punto 16») y Ricardo Salas no figuran entre los asistentes.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-12-03 | **Reprogramado 6 veces.** Promesa original 2026-09-24. Cadena: 10-05 → 10-14 → 10-27 → 11-09 → 11-19 → 12-03. Nota: «no alcanzó, se compromete para el 03/12/2026». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 | Nuevo. «Queda para el 2026-10-28»: lo tomo como compromiso con fecha; si fue solo una fecha tentativa, el gerente lo corrige. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», que no es una fecha; no le inventé una. |

(Ya estaba sin fecha desde antes: Sandra Gil, «Validar el ambiente 12», «por definir» desde el 09-20. Esta reunión no la tocó.)

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Si el riesgo del equipo del proveedor se registra, y con qué respuesta | Se comentó y nadie lo anotó | Las notas no lo dicen |
| Cuándo entrega Laura Vélez el ajuste de presupuesto | «La otra semana» | Las notas no lo dicen |

## Intenciones sin doliente
Ninguna en estas notas. La frase sobre el proveedor es un riesgo, no una intención, y va en la sección siguiente.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas dicen «nadie lo anotó como riesgo» | Las notas no atribuyen la frase a nadie | Riesgo (evento posible, no ocurrido). Si ya se supiera, sería incidencia | **No.** El único riesgo registrado es «dependencia del calendario de liberaciones del core» (informe del 10-16), y es otro. Queda en la ficha con `registered: false` y sin responsable. |

## Cerrado en esta reunión
Nada. No se presentó ningún documento.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité (`cycle.committee`) | «Próxima reunión en dos semanas» (≈ 2026-11-01) | `weekly`, semanal, domingo | Notas 2026-10-18 · config de Samuel (2026-10-18). `committee_next` ya dice 2026-11-01, así que la fecha coincide pero la cadencia no. Si pasan a quincenal, hay que cambiar la configuración. |
| Dependencias | Se habla de un proveedor y de su equipo para la siguiente fase | «Ninguna declarada»; `vendors` vacío en la ficha | Notas 2026-10-18 · acta de constitución 2026-03-19 |

Ningún campo de gobierno (patrocinador, cierre, comité) cambió en la reunión.

## Sin resolver de la transcripción
- «03/12/2026» está en formato ambiguo. Lo leí como 3 de diciembre (dd/mm), la única lectura que cae hacia adelante y sigue la cadena de fechas; leído mm/dd sería 12 de marzo, ya pasado. Confirmar con Diana Molina.
- «Revisión con el proveedor, queda para el 2026-10-28»: no dice si es la fecha en que Óscar entrega la revisión o la fecha de la reunión con el proveedor.
- «La otra semana» no dice a partir de qué día se cuenta.
- Las notas no dicen quién comentó lo del proveedor.

---
**Recálculo (`compute`):** sin `record_issues`. Con lo que entró hoy: 2 compromisos sin fecha (Laura Vélez y Sandra Gil), 3 reprogramados en forma repetida (Diana Molina 6, Andrés Lozano 5, Natalia Ospina 3) y 8 vencidos sin evidencia (son de reuniones anteriores; esta reunión no los movió). Declarado: amarillo, 70 %; el plan sostiene 25–50 % (1 de 4 hitos).

**Después:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por la ficha de gobierno, pero sí si cambian la cadencia del comité o se registra el proveedor. El acta sale aquí y la guardas tú.
