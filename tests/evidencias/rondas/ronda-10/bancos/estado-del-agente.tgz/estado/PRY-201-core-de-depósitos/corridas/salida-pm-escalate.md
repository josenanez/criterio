Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hubo que volver a registrarlos.

Sin argumento y sin nadie a quien preguntar, tomé «lo que ya está marcado como escalable» y lo contrasté con la ficha del 2026-10-18 y los documentos del proyecto. Escala un solo punto, y es el que la regla pone primero.

## Para decisión — PRY-201 Core de depósitos · 2026-10-18

### ¿Qué puede decidir por sí mismo el gerente del proyecto, y hasta qué tope: se declara por escrito (opción A) o se sigue sin declarar (opción B)?

**Quién decide:** el acta no declara autoridad, así que no puedo citar quién la define. El acta fue aprobada por el Comité de Arquitectura (2026-03-19) y nombra como patrocinador a Liliana Torres; propongo que lo decida el Comité de Arquitectura con el patrocinador, y lo marco como propuesta mía, no como lo que dice el acta · **Si no se decide hoy:** el comité semanal está fijado para el 2026-11-01 (configuración) y el hito «Ambiente de pruebas certificado» vence el 2026-11-08 sin evidencia. Sin autoridad declarada, la decisión que ese hito pida no se puede clasificar como «mía» o «del comité», y el punto llega el 11-08 sin saber a quién subirlo. (Las notas del 10-18 dicen «próxima reunión en dos semanas»; si la cadencia cambió, el 11-01 no aplica y la fecha de corte es otra.)

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| **A.** El comité declara por escrito la autoridad del gerente (qué cambios de fecha, de presupuesto y de alcance decide solo, y desde qué tope sube) y se anexa al acta | Un anexo al acta; el alcance del proyecto no cambia | Una decisión del comité; no tengo una duración sustentada en los documentos | Sin costo monetario declarado; el costo es la atención del comité |
| **B.** No se declara; el gerente escala caso por caso | Sin cambio | Cada caso espera comité y se discute primero si el comité era el foro | Sin costo monetario declarado; el costo es la demora de cada decisión y el riesgo de decisiones que «se tomaron y no valían» |

No tengo cifras de ningún costo ni número de días: no están en los documentos y no los inventé.

**Recomiendo:** A. Sin la autoridad escrita, los tres compromisos que ya llevan tres o más movimientos (documento 1, prueba 2, ambiente 4) no se pueden clasificar como escalables o no, y el único riesgo registrado no tiene responsable.

### A quién alcanza
No calculé el efecto con `impact`: este punto no mueve ninguna fecha, así que no hay `--days` que pasarle y no voy a inventar uno. Si la decisión de A hace que se mueva el hito del 11-08 u otro, se corre con los días reales. Tampoco hay en la ficha otro proyecto que dependa de este: el acta dice «Ninguna declarada» en dependencias.

### Mis hitos por los que pasa
Ninguno por este punto, por la misma razón. Para referencia, el próximo hito en plan es «Ambiente de pruebas certificado», 2026-11-08, pendiente y sin evidencia.

### Lo que revisé y no armé como paquete
- **Documento 1 (Diana Molina), prueba 2 (Andrés Lozano), ambiente 4 (Natalia Ospina):** cumplen la regla «reprogramado tres veces o más» (6, 5 y 3 movimientos), pero las minutas no dicen la causa, y sin causa no puedo decir si excede tu autoridad o se destraba con una llamada. Tampoco puedo formular las opciones. Cuando la persona diga en la sala qué la bloquea, se corre `/pm-escalate` sobre esa causa. Un detalle: la fecha del documento 1 está escrita «03/12/2026» y se leyó 3 de diciembre (dd/mm); confírmala.
- **Riesgo del proveedor («podría no llegar con el equipo completo para la siguiente fase»):** no escala. Es un riesgo sin registrar y sin responsable, y registrarlo es tuyo. La revisión con el proveedor de Óscar Ramírez es el 2026-10-28.
- **Ambiente 12 (Sandra Gil), «por definir» en cuatro reuniones:** se resuelve con una fecha dicha en la sala, no con un comité.

### De dónde sale esto
- Autoridad no encontrada: `00-gobierno/2026-03-19-acta-constitucion.md` (sin sección de autoridad ni de umbrales); ficha `identity.authority`, estado `not_found`; búsqueda de «autoridad», «facultad», «escal», «atribuci», «umbral» en los documentos del proyecto sin resultados.
- Comité aprobador y patrocinador: mismo acta, 2026-03-19.
- Hito del 11-08: `10-plan/2026-03-19-cronograma-v1.xlsx` (ficha, hitos).
- Fecha del comité: configuración, `cycle.committee_next` 2026-11-01; cadencia en duda: `2026-10-18-notas-reunion.txt`.
- Reprogramaciones: minutas del 09-06 al 10-11 y notas del 10-18 (ficha, `commitments`).

Este paquete no escala solo: llevarlo al comité es tuyo.
