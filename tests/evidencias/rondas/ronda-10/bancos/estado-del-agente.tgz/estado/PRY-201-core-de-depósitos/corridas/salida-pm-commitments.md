## Compromisos — PRY-201 Core de depósitos · al 2026-10-18

22 compromisos abiertos de 26 registrados (4 cerrados con acta). Cifras de `portafolio.py compute`: 3 reprogramados, 8 vencidos sin evidencia, 2 sin fecha.

### Se viene reprogramando

> **Diana Molina** · Enviar el documento 1
> Prometido para el 2026-12-03, y antes para el 11-19, el 11-09, el 10-27, el 10-14 y el 10-05; la primera promesa fue el 2026-09-24. **Seis reprogramaciones.**
> Fuentes: minutas del 09-13, 09-20, 09-27, 10-04, 10-11 y notas del 10-18.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Aviso de lectura: las notas del 10-18 escriben «03/12/2026». Se leyó dd/mm (3 de diciembre); leída mm/dd sería marzo, anterior a la reunión. Conviene confirmarla con Diana.

> **Andrés Lozano** · Cerrar la prueba 2
> Prometido para el 2026-11-27, y antes para el 11-19, el 11-07, el 10-23 y el 10-10; la primera promesa fue el 2026-09-29. **Cinco reprogramaciones.**

> **Natalia Ospina** · Validar el ambiente 4
> Prometido para el 2026-10-24, y antes para el 10-06, el 09-23; la primera promesa fue el 2026-09-14. **Tres reprogramaciones.**
> Vence esta semana: queda por ver si se cumple o se mueve por cuarta vez.

Las minutas no dicen por qué se movieron; el motivo es del gerente. Dato de contexto: el hito «Ambiente de pruebas certificado» está en el plan para el 2026-11-08.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 | 15 días |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 | 11 días |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-08 (reprogramado una vez; original 09-26) | 10 días |
| Paula Céspedes | Actualizar la matriz 14 | 2026-10-08 | 10 días |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 | 9 días |
| Javier Hoyos | Entregar el punto 16 | 2026-10-14 | 4 días |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-10-15 (reprogramado una vez; original 09-30) | 3 días |
| Rubén Cárdenas | Aprobar el diseño 21 | 2026-10-15 | 3 días |

Con «ya lo entregué» y sin documento:
- **Mauricio Pérez** dijo el 10-11 que ya entregó «cerrar la prueba 10». No hay acta de recibo en el expediente.
- **Paula Céspedes** dijo lo mismo de «actualizar la matriz 14». No hay acta.
- **Javier Hoyos** dijo lo mismo de «entregar el punto 16». No hay acta.

Siguen abiertos hasta que haya un documento que los respalde.

Aprobar el diseño 5 (Andrés Lozano): el acta de recibo del 2026-10-18 certifica «Diseño funcional aprobado», pero no nombra este compromiso. No se da por cerrado. Hay que preguntarle al gerente si es el mismo.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 |
| Natalia Ospina | Validar el ambiente 4 (ya reprogramado 3 veces, arriba) | 2026-10-24 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-25 |

Andrés Lozano concentra cuatro compromisos abiertos: dos de ellos, la prueba 2 y el diseño 5, ya están atrasados o reprogramados.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 2026-09-20 («por definir» en cuatro reuniones seguidas: 09-20, 09-27, 10-04, 10-11) |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-18 («la otra semana», que no es una fecha) |

No pueden estar vencidos; por eso se cuentan aparte. El de Sandra Gil lleva 28 días sin fecha.

### Cerrados desde la última revisión
Ninguno nuevo en esta revisión. Los cuatro ya cerrados (Camilo Beltrán, Diana Molina «punto 8», Ricardo Salas, Elena Duarte) tienen su acta de recibo en el expediente.

### Para tener en cuenta
- Las notas del 10-18 también dejan a Óscar Ramírez con «revisión con el proveedor» para el 2026-10-28 (al día) y un riesgo comentado que nadie registró: el proveedor podría no llegar con el equipo completo en la siguiente fase. Eso es de `/pm-minutes` y del RAID, no de este informe.
- Las notas dicen «próxima reunión en dos semanas», mientras la configuración tiene comité semanal (domingo). Los tres bloqueos de arriba no esperan dos semanas.

### Siguiente paso
Hay compromisos reprogramados tres veces o más. Se puede formular una decisión para el comité (qué se pide, qué pasa si no se decide, quién tiene la facultad), porque desbloquear documento 1, prueba 2 y ambiente 4 excede la autoridad del gerente. Dime si lo preparo con `/pm-escalate`.

La ficha no cambió en esta corrida, así que no hace falta `/pm-publish`.
