Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hubo que volver a registrarlos.

## PRY-201 Core de depósitos · 2026-10-18

**Revisé:** 16 documentos · 16 nuevos para el índice (primer barrido, `last: null`) · 1 minuta sin procesar: ninguna. Las notas del 2026-10-18 y las seis actas de comité ya estaban extraídas en la ficha; no volví a extraer ni dejé copias. Contra la foto de hoy, `diff`: 0 cambios.

### Lo que se venció solo
Primer barrido: no hay corrida anterior contra la cual decir qué cruzó desde entonces. Lo que está vencido hoy, sin evidencia:

| Quién | Qué | Debía | Días | Fuente |
|---|---|---|---|---|
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 | 15 | 30-reuniones/2026-09-27-comite-semanal.md |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 | 11 | 30-reuniones/2026-09-13-comite-semanal.md |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-08 | 10 | 30-reuniones/2026-09-13-comite-semanal.md |
| Paula Céspedes | Actualizar la matriz 14 | 2026-10-08 | 10 | 30-reuniones/2026-09-27-comite-semanal.md |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 | 9 | 30-reuniones/2026-09-27-comite-semanal.md |
| Javier Hoyos | Entregar el punto 16 | 2026-10-14 | 4 | 30-reuniones/2026-09-27-comite-semanal.md |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-10-15 | 3 | 30-reuniones/2026-09-20-comite-semanal.md |
| Rubén Cárdenas | Aprobar el diseño 21 | 2026-10-15 | 3 | 30-reuniones/2026-10-11-comite-semanal.md |

Mauricio Pérez, Paula Céspedes y Javier Hoyos dijeron el 10-11 que «ya entregó» tres de ellos; no se presentó acta de recibo, así que siguen vencidos.

Reprogramados que superan el umbral (3): Diana Molina «Enviar el documento 1» (6 veces, original 2026-09-24, hoy 2026-12-03; fecha escrita «03/12/2026», leída dd/mm, por confirmar con ella), Andrés Lozano «Cerrar la prueba 2» (5), Natalia Ospina «Validar el ambiente 4» (3).
Sin fecha: Sandra Gil «Validar el ambiente 12» y Laura Vélez «Mandar el ajuste del presupuesto» («la otra semana»).
Declarado amarillo, 70 %; el plan sostiene 25–50 % (1 de 4 hitos).

### La reunión
Comité el 2026-11-01, a 14 días: aún no toca agenda. El informe toca el 2026-10-31. El acta de la reunión de hoy ya se redactó en esta sesión (`/pm-minutes`); no hay reunión pasada sin acta. Las notas dicen «próxima reunión en dos semanas» y la configuración dice semanal: la cadencia está por aclarar.

### Tu ficha publicada
`/pm-publish` corrió hoy a las 08:05 y la ficha no cambió desde entonces: no está vieja.

**Vuelvo el 2026-10-19.**
