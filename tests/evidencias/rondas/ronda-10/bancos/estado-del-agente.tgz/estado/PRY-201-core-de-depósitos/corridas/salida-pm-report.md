Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hay nada que registrar de nuevo.
Declaración: nadie puede responder en esta sesión, así que uso la que el gerente ya dejó escrita en su informe del 2026-10-16. No propongo ninguna.

# Core de depósitos (PRY-201) — semana del 2026-10-11 al 2026-10-18

**Declara el gerente (Carlos Peña):** amarillo · 70 % · al 2026-10-16 (`20-seguimiento/2026-10-16-informe-avance.pdf`, de hace 2 días)
**Sustento documental:** sin sustento en el avance. El plan sostiene entre 25 % y 50 % (1 de 4 hitos cumplido), y el declarado va 20 puntos por encima. El amarillo como color no lo contradice ninguna señal, pero no explica varias (ver abajo).
**Lo que el semáforo no explica:** compromisos vencidos (8), compromisos reprogramados (3, uno 6 veces) y el avance contra el plan.

## Qué cambió esta semana

La comparación contra la corrida anterior sale vacía: esta es la primera instantánea del proyecto, no hay una previa contra la que comparar. Lo que sigue se reconstruye con los documentos fechados en la semana, no con un diff.

| Qué | Estaba | Está | |
|---|---|---|---|
| Hito «Diseño funcional aprobado» | pendiente, sin evidencia | cumplido; acta de recibo del 2026-10-18 | cerrado |
| Diana Molina, «Enviar el documento 1» | 2026-11-19 (5.ª fecha) | 2026-12-03 (6.ª fecha), notas del 2026-10-18 | peor |
| Andrés Lozano, «Cerrar la prueba 2» | 2026-11-19 | 2026-11-27 (5.ª fecha, dicha el 10-11) | peor |
| Sandra Gil, «Revisar el anexo 11» | 2026-10-14 | 2026-10-26 (dicha el 10-11) | peor |
| Elena Duarte, «Cerrar la prueba 18» | 2026-10-19 | 2026-10-28 (dicha el 10-11) | peor |
| Compromisos nuevos | | Rubén Cárdenas (diseño 21), Andrés Lozano (matriz 22, fecha 23), Gustavo Neira (punto 24), Laura Vélez (ajuste del presupuesto, sin fecha), Óscar Ramírez (revisión con el proveedor, 10-28) | nuevo |
| Riesgo nuevo, dicho en reunión y sin registrar | | El proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-18) | nuevo |
| Cerrados con acta de recibo | | Elena Duarte, «Enviar el documento 17» (acta del 10-11) | cerrado |
| Declaración del gerente | | amarillo · 70 % al 2026-10-16 | nueva |

## Lo que sigue igual y sigue mal

| Qué | Desde | Días así |
|---|---|---|
| Sandra Gil, «Aprobar el diseño 13»: vencido, nunca reprogramado | 2026-10-03 | 15 |
| Sandra Gil, «Validar el ambiente 12»: «por definir» en las reuniones del 09-20, 09-27, 10-04 y 10-11 | 2026-09-20 | 28 sin fecha |
| Felipe Arango, «Actualizar la matriz 6» | 2026-10-07 | 11 |
| Andrés Lozano, «Aprobar el diseño 5» | 2026-10-08 | 10 |
| Paula Céspedes, «Actualizar la matriz 14» (dijo el 10-11 que ya lo entregó; no hay acta) | 2026-10-08 | 10 |
| Paula Céspedes, «Confirmar la fecha 15» | 2026-10-09 | 9 |
| Javier Hoyos, «Entregar el punto 16» (dijo el 10-11 que ya lo entregó; no hay acta) | 2026-10-14 | 4 |
| Mauricio Pérez, «Cerrar la prueba 10» (dijo el 10-11 que ya lo entregó; no hay acta) | 2026-10-15 | 3 |
| Rubén Cárdenas, «Aprobar el diseño 21» | 2026-10-15 | 3 |
| Riesgo «Dependencia del calendario de liberaciones del core», sin dueño | 2026-10-16 | 2 |

«Desde» es la fecha de vencimiento. Como no hay informe anterior, no puedo decir cuáles de estos ya estaban en el de la semana pasada.

## Contra el plan

| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-06-21 | 2027-06-21 | 0 días |
| Presupuesto aprobado | COP 1.200.000.000 | COP 1.200.000.000 | proyección COP 1.104.493.088 (−8,0 %) |

Replanificaciones: 0.

Contra esas dos columnas el proyecto no se ha movido. Los compromisos sí: llevan entre 40 y 70 días corridos desde su fecha original (Diana Molina 70, Andrés Lozano 59, Natalia Ospina 40) sin que el cronograma lo recoja. Un plan que no se replanifica mientras los compromisos se corren es el caso que conviene mirar.

Hay un dato más para confirmar con el gerente: el hito «Diseño funcional aprobado» tenía fecha base 2026-07-19 y la única evidencia de cierre es un acta fechada 2026-10-18, 91 días después. El cronograma no registra esa desviación.

### Hitos de las próximas cuatro semanas (hasta 2026-11-15)

| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ambiente de pruebas certificado | 2026-11-08 | 2026-11-08 | ninguna (pendiente) |

A 21 días de ese hito hay dos compromisos sobre ambientes abiertos: «Validar el ambiente 4» (Natalia Ospina, reprogramado 3 veces, hoy 10-24) y «Validar el ambiente 12» (Sandra Gil, sin fecha). Que alimenten el hito es una lectura por el nombre; hay que confirmarlo.

## Las cifras (COP)

Las tres últimas cifras salen del informe de avance del gerente (declaración), no de un documento contable.

| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 1.200.000.000 | 935.701.138 (78,0 %) | 739.016.329 (61,6 %) | 1.104.493.088 | **264.298.862** (aprobado menos comprometido) |

El comprometido está por debajo del umbral del 90 %. Con 70 % de avance declarado y 61,6 % de lo aprobado ejecutado, el gasto no va por delante del avance declarado.

## Abierto

**Reprogramados:**
- Diana Molina, «Enviar el documento 1»: 6 veces. Original 2026-09-24, hoy 2026-12-03. La fecha de las notas está escrita «03/12/2026»; la leí como 3 de diciembre. Si fuera 12 de marzo, sería otra cosa: confirmar.
- Andrés Lozano, «Cerrar la prueba 2»: 5 veces. Original 2026-09-29, hoy 2026-11-27.
- Natalia Ospina, «Validar el ambiente 4»: 3 veces. Original 2026-09-14, hoy 2026-10-24.

Los tres superan el umbral de 3 reprogramaciones.

Otros con una reprogramación: Diana Molina «Confirmar la fecha 7» (2 veces, hoy 11-05), Andrés Lozano «Aprobar el diseño 5», Felipe Arango «Actualizar la matriz 6», Sandra Gil «Revisar el anexo 11», Elena Duarte «Cerrar la prueba 18».

**Vencidos sin evidencia (8):** los de la tabla anterior, de Sandra Gil a Rubén Cárdenas. Tres de sus dueños (Mauricio Pérez, Paula Céspedes, Javier Hoyos) dijeron el 10-11 que ya entregaron; ninguno presentó acta. «Aprobar el diseño 5» (Andrés Lozano) podría haberlo cubierto el acta de recibo del diseño funcional del 10-18, pero esa acta no lo nombra, así que no lo doy por cerrado.

**Sin fecha (2):** Sandra Gil, «Validar el ambiente 12»; Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana» no es fecha).

**RAID sin movimiento:** ninguno; los dos riesgos son de esta semana (10-16 y 10-18). Los dos están sin dueño, y el segundo no está registrado.

**Proveedor:** el proyecto no tiene proveedores en la ficha. Aun así, las notas del 10-18 hablan de uno: Óscar Ramírez tiene una «Revisión con el proveedor» el 10-28 y se comentó el riesgo de que no llegue con el equipo completo. Sin contrato ni entregables cargados no puedo contrastar vencidos, aceptados ni facturado.

## Lo que necesito de alguien

- **Carlos Peña:** confirmar si el acta de recibo del 10-18 cierra «Aprobar el diseño 5»; confirmar la fecha de Diana Molina (3 de diciembre o 12 de marzo); asignar dueño a los dos riesgos y decidir si el del proveedor se registra; explicar el 70 % frente a los 25–50 % que sostiene el plan.
- **Mauricio Pérez, Paula Céspedes, Javier Hoyos:** el acta de recibo de lo que dijeron haber entregado el 10-11.
- **Sandra Gil:** una fecha para «Validar el ambiente 12» y el estado de «Aprobar el diseño 13», vencido hace 15 días.
- **Laura Vélez:** una fecha para el ajuste del presupuesto.
- **Diana Molina y Andrés Lozano:** una fecha en que sí vayan a entregar, o decir que no.

La ficha no trae la autoridad del proyecto, así que no puedo marcar qué de lo anterior excede al gerente.

## Lo que no se sabe

**Sin dato:** autoridad del proyecto y fase. Sin la primera no se sabe a quién escalar lo que supere al gerente. Tampoco hay proveedores, contratos ni cambios en la ficha.
**Silencio:** último documento hace 0 días (notas de reunión del 2026-10-18) · último informe de avance hace 2 días · última reunión hace 0 días (2026-10-18; el comité semanal anterior fue el 10-11). No hay silencio.

---
Ficha `PRY-201.json` (esquema 0.2), actualizada el 2026-10-18, sin sellar. 2 campos sin dato. De las fuentes de la ficha, 6 son declaración del gerente y ninguna está marcada como evidencia independiente. Próximo comité: 2026-11-01. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
