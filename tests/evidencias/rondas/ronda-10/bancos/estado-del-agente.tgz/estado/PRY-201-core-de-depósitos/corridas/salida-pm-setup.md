Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta. (1) Proyecto PRY-201 · Core de depósitos, gerente Carlos Peña, según el acta de constitución del 2026-03-19. (2) Reunión de seguimiento los domingos (las minutas del 09-06 al 10-11 caen en domingo); las notas del 10-18 dicen «próxima reunión en dos semanas», así que anoté 2026-11-01. (3) Estado en `estado/PRY-201-core-de-depósitos`. (4) Términos, abajo.

**Términos (versión 1.1, familia 0.5.0):**
Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Aceptación registrada a nombre de José Francisco Ñáñez, fecha 2026-10-18, por lo que indicó en el argumento de la sesión.

## Listo — Core de depósitos (PRY-201)

**Lo que miré:** 15 documentos · 7 minutas (6 comités semanales, del 2026-09-06 al 2026-10-11, más las notas del 2026-10-18) · la última del 2026-10-18 · 5 actas de recibo · el informe de avance del 2026-10-16 (PDF) · el cronograma (xlsx). Todo se pudo leer; no hay formatos ilegibles. Leí las siete minutas de la más vieja a la más nueva. La ficha **no está sellada**.
**Términos:** aceptados para la versión 0.5.0 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 del Markdown ffa4799dee7ac84c…

### Lo que está abierto, y cuántas veces se ha movido

26 compromisos en total: 4 cumplidos con acta, 8 vencidos sin evidencia, 2 sin fecha, 12 vigentes. Los que `compute` marcó como reprogramados tres veces o más van primero.

| Quién | Qué | Para cuándo | Movido | Cita |
|---|---|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-12-03 (primera promesa: 2026-09-24) | **6 veces**: 10-05, 10-14, 10-27, 11-09, 11-19, 12-03 | minutas 09-06 a 10-11 y notas 10-18 («no alcanzó, se compromete para el 03/12/2026»; leí dd/mm) |
| Andrés Lozano | Cerrar la prueba 2 | 2026-11-27 (primera: 2026-09-29) | **5 veces**: 10-10, 10-23, 11-07, 11-19, 11-27 | minutas 09-06 a 10-11 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-24 (primera: 2026-09-14) | **3 veces**: 09-23, 10-06, 10-24 | minutas 09-06 a 10-11 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-08 | 1 vez (primera: 2026-09-26) · **vencido 10 días, sin evidencia** | minutas 09-13 y 09-27 |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 | 1 vez (primera: 2026-09-20) · **vencido 11 días, sin evidencia** | minutas 09-13 y 09-27 |
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 | 0 · **vencido 15 días, sin evidencia** | minuta 09-27 |
| Paula Céspedes | Actualizar la matriz 14 | 2026-10-08 | 0 · **vencido 10 días, sin evidencia** · el 10-11 dijo que ya lo entregó, no se presentó acta | minutas 09-27 y 10-11 |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 | 0 · **vencido 9 días, sin evidencia** | minuta 09-27 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-14 | 0 · **vencido 4 días, sin evidencia** · el 10-11 dijo que ya lo entregó, no se presentó acta | minutas 09-27 y 10-11 |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-10-15 | 1 vez (primera: 2026-09-30) · **vencido 3 días, sin evidencia** · el 10-11 dijo que ya lo entregó, no se presentó acta | minutas 09-20, 10-04 y 10-11 |
| Rubén Cárdenas | Aprobar el diseño 21 | 2026-10-15 | 0 · **vencido 3 días, sin evidencia** | minuta 10-11 |
| Diana Molina | Confirmar la fecha 7 | 2026-11-05 (primera: 2026-09-22) | 2 veces: 10-15, 11-05 | minutas 09-13 a 10-11 |
| Sandra Gil | Revisar el anexo 11 | 2026-10-26 (primera: 2026-10-14) | 1 vez | minutas 09-20 y 10-11 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-28 (primera: 2026-10-19) | 1 vez | minutas 10-04 y 10-11 |
| Mauricio Pérez | Revisar el anexo 19 | 2026-10-26 | 0 | minuta 10-04 |
| Paula Céspedes | Validar el ambiente 20 | 2026-10-28 | 0 | minuta 10-04 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-25 | 0 | minuta 10-11 |
| Andrés Lozano | Confirmar la fecha 23 | 2026-10-19 | 0 | minuta 10-11 |
| Gustavo Neira | Entregar el punto 24 | 2026-11-06 | 0 | minuta 10-11 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-28 | 0 | notas 10-18 |

**Cumplidos, con acta de recibo:** Revisar el anexo 3 (Camilo Beltrán, acta 09-20) · Entregar el punto 8 (Diana Molina, acta 09-27) · Enviar el documento 9 (Ricardo Salas, acta 10-04; se había movido de 09-27 a 10-12) · Enviar el documento 17 (Elena Duarte, acta 10-11).

**Una duda para ti:** el acta de recibo del 2026-10-18 certifica «Diseño funcional aprobado», pero no nombra el compromiso «Aprobar el diseño 5» (Andrés Lozano). No lo di por cumplido. Si es el mismo, dímelo y lo cierro con esa acta.

### Sin fecha
- **Sandra Gil · Validar el ambiente 12:** «por definir» en cuatro reuniones seguidas (09-20, 09-27, 10-04, 10-11).
- **Laura Vélez · Mandar el ajuste del presupuesto:** dijo «la otra semana» el 10-18; eso no es una fecha y no la calculé.

Ninguno de los dos puede aparecer como vencido, y por eso mismo son los que desaparecen de los informes.

### Otras señales que levantó el cálculo
- **Avance declarado contra el plan:** el informe del 10-16 declara 70% y estado amarillo; el cronograma tiene 1 de 4 hitos cerrados y con eso el plan sustenta entre 25 % y 50 %. Es la diferencia entre lo que declaras y lo que muestran los documentos; la decisión sobre el estado es tuya.
- **Presupuesto (informe 10-16, COP):** aprobado 1.200.000.000 · comprometido 935.701.138 (78,0 %) · ejecutado 739.016.329 (61,6 %) · proyección 1.104.493.088, que queda 8,0 % por debajo del aprobado. No levantó señal de presupuesto.
- **Hito «Diseño funcional aprobado»:** cerrado en el cronograma, con acta de recibo del 2026-10-18. El cronograma lo tenía para el 2026-07-19.
- **Riesgo que nadie registró:** en las notas del 10-18 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. El informe del 10-16 solo lista «dependencia del calendario de liberaciones del core». Lo dejé en la ficha, marcado como no registrado.
- **Fechas:** el cierre vigente es 2027-06-21, igual al del acta; no hay replanificaciones en lo que leí.

### Qué le falta a tu carpeta
- Acta de recibo de «Cerrar la prueba 10», «Actualizar la matriz 14» y «Entregar el punto 16»: tres personas dijeron el 10-11 que ya entregaron y no hay documento; sin él se ven igual que un incumplimiento.
- El acta de constitución no trae autoridad del gerente (hasta qué monto o cambio puede decidir sin subir a comité) ni fase; el alcance dice «Componente 1, 2, 3», y no declara dependencias.
- Un cronograma posterior al v1 del 2026-03-19, si existe: el que leí no tiene ningún hito movido desde marzo.
- Un compromiso con la fecha escrita 03/12/2026 admite dos lecturas; confírmame que es 3 de diciembre.

**Cuándo vuelvo:** tu reunión es semanal, los domingos, y las notas del 10-18 anuncian la próxima en dos semanas: el 2026-11-01. Vuelvo el día antes, el sábado 2026-10-31.
