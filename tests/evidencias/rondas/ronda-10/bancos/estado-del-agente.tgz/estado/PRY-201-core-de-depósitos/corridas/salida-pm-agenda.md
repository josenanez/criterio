Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18): no hubo que volver a registrarlos.

Supuestos de esta corrida, sin nadie a quien preguntar: la fecha es **2026-11-01** (`committee_next` de la configuración) y el tiempo es **45 minutos** (ni el argumento ni la configuración traen uno; si son otros, se recorta o se amplía por el final de la lista). `diff` dice que no hay corrida anterior, así que no puedo mostrar qué cambió desde la última reunión: el punto de partida es la minuta del 10-11, las notas del 10-18 y el cálculo de hoy.

## Reunión de seguimiento — PRY-201 Core de depósitos · 2026-11-01
7 puntos · 40 minutos (5 de margen) · 12 personas requeridas: Carlos Peña, Diana Molina, Andrés Lozano, Natalia Ospina, Sandra Gil, Felipe Arango, Paula Céspedes, Mauricio Pérez, Rubén Cárdenas, Javier Hoyos, Óscar Ramírez, Gustavo Neira.

**Esta agenda se arma con el estado del 2026-10-18. Vuelve a correr `/pm-agenda` el 2026-10-31**: varios compromisos vencen entre hoy y la reunión (ver el cierre) y los que no tengan acta pasan a «vencido sin evidencia».

### Lo que no se destraba solo
Tres compromisos reprogramados tres veces o más. Los tres dolientes estuvieron en la reunión del 10-18 (Diana, Andrés y Natalia). Las minutas no dicen por qué se movieron; ese motivo lo pone el gerente, no yo.

> **[1] Que Diana Molina nombre qué le impide enviar el documento 1, y que quede una fecha confirmada o un bloqueo escrito** · 8 min · **Diana Molina**
> Prometido para el 2026-12-03, y antes para el 11-19, el 11-09, el 10-27, el 10-14 y el 10-05; la primera promesa fue el 2026-09-24. Seis reprogramaciones.
> Fuente: minutas del 09-06, 09-13, 09-20, 09-27, 10-04 y 10-11, y notas del 10-18.
> Confirmar en la sala la fecha de las notas: dicen «03/12/2026», se leyó 3 de diciembre (dd/mm); leída mm/dd sería marzo, ya pasado.
> **Si no se resuelve hoy:** hay una séptima fecha sin motivo dicho, para un documento prometido originalmente para el 09-24.

> **[2] Que Andrés Lozano diga qué falta para cerrar la prueba 2, y si el acta del 10-18 («Diseño funcional aprobado») cierra su «Aprobar el diseño 5»** · 8 min · **Andrés Lozano**
> Cerrar la prueba 2: prometido para el 2026-11-27, y antes para el 11-19, el 11-07, el 10-23 y el 10-10; la primera promesa fue el 2026-09-29. Cinco reprogramaciones.
> Aprobar el diseño 5: vencido desde el 10-08 (original 09-26). El acta de recibo del 10-18 certifica el hito pero no nombra este compromiso; no lo di por cerrado. Si Carlos Peña lo confirma antes, ese minuto se libera.
> Andrés concentra además «Actualizar la matriz 22» (10-25) y «Confirmar la fecha 23» (10-19): cuatro abiertos en total.
> Fuente: minutas del 09-06, 09-13, 09-20, 09-27, 10-04 y 10-11; acta de recibo 2026-10-18.
> **Si no se resuelve hoy:** la prueba 2 queda con un sexto movimiento y el diseño 5 sigue contado como vencido.

> **[3] Que Natalia Ospina confirme si validó el ambiente 4 (vence el 2026-10-24) o diga qué lo bloquea** · 5 min · **Natalia Ospina**
> Prometido para el 2026-10-24, y antes para el 10-06 y el 09-23; la primera promesa fue el 2026-09-14. Tres reprogramaciones.
> Fuente: minutas del 09-06, 09-13, 09-20 y 09-27.
> Si para el 11-01 hay acta de recibo, este punto sale de la agenda y sus 5 minutos pasan al margen. Contexto, no relación documentada: el hito «Ambiente de pruebas certificado» está en el plan para el 2026-11-08.
> **Si no se resuelve hoy:** cuarto movimiento, con el hito del 11-08 a una semana.

### Vencido sin evidencia
Más viejo primero. Cada uno se resuelve con un documento o con una fecha nueva dicha en voz alta; «ya lo entregué» sin acta no cierra nada.

| Quién | Qué | Desde (al 10-18) | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Sandra Gil | Aprobar el diseño 13 | 2026-10-03 (15 días) | Aprobación con documento, o fecha | 2 |
| Felipe Arango | Actualizar la matriz 6 | 2026-10-07 (11 días; original 09-20) | Documento o fecha | 1 |
| Paula Céspedes | Actualizar la matriz 14 | 2026-10-08 (10 días); dijo el 10-11 que ya la entregó | Acta de recibo, o aclarar que no | 1 |
| Paula Céspedes | Confirmar la fecha 15 | 2026-10-09 (9 días) | Fecha confirmada | 1 |
| Javier Hoyos | Entregar el punto 16 | 2026-10-14 (4 días); dijo el 10-11 que ya lo entregó | Acta de recibo, o aclarar que no | 1 |
| Mauricio Pérez | Cerrar la prueba 10 | 2026-10-15 (3 días; original 09-30); dijo el 10-11 que ya lo entregó | Acta de recibo, o aclarar que no | 1 |
| Rubén Cárdenas | Aprobar el diseño 21 | 2026-10-15 (3 días) | Aprobación con documento, o fecha | 1 |

Fuente: minutas del 09-13 (Felipe), 09-20 (Mauricio), 09-27 (Sandra, Paula, Javier) y 10-11 (Rubén y las tres afirmaciones de «ya lo entregué»). El diseño 5 de Andrés está en el punto 2. Subtotal: 8 min.

**Javier Hoyos no figura entre los asistentes del 10-18.** Si no va a estar, su fila no es de esta reunión: se le pide el acta directamente antes. Decide el gerente.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Registrar o no el riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase», con responsable y respuesta. Hoy es `registered: false`, sin responsable. Óscar Ramírez tiene «revisión con el proveedor» el 2026-10-28, antes de la reunión: el resultado informa la decisión. | Las notas no dicen quién tiene la facultad; propongo al gerente, Carlos Peña, para el registro | Se vuelve a comentar «por si acaso» y nadie lo anotó en dos reuniones, que es lo que pasó el 10-18. El único riesgo registrado es otro (dependencia del calendario de liberaciones del core) y tampoco tiene responsable | 5 |
| Fecha para «Validar el ambiente 12» (Sandra Gil), «por definir» desde el 09-20 en cuatro reuniones seguidas (09-20, 09-27, 10-04, 10-11); al 11-01 son 42 días | Sandra Gil con Carlos Peña | Sigue sin poder vencerse, y por eso no sale en ningún cálculo de atraso | 2 |

Fuente: notas 2026-10-18 (riesgo); minutas 09-20, 09-27, 10-04 y 10-11 (ambiente 12); informe de avance 2026-10-16 (riesgo registrado). Subtotal: 7 min.

### Vence antes de la próxima
Lo que cae entre el 11-02 y la reunión siguiente (11-08 si el comité sigue semanal).

| Quién | Qué | Para cuándo |
|---|---|---|
| Diana Molina | Confirmar la fecha 7 (ya reprogramada 2 veces; original 09-22) | 2026-11-05 |
| Gustavo Neira | Entregar el punto 24 | 2026-11-06 |
| (plan) | Hito «Ambiente de pruebas certificado», sin evidencia | 2026-11-08 |

Fuente: minutas del 10-04 y 10-11; cronograma v1 del 2026-03-19. Subtotal: 4 min, y Gustavo Neira solo se cita para este punto.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Desbloquear el documento 1, la prueba 2 y el ambiente 4 si el bloqueo que se nombre en los puntos 1 a 3 excede al gerente | Los tres llevan 3 a 6 movimientos y las minutas no dicen la causa; si la causa pide una facultad que Carlos Peña no tiene, la sala no la resuelve | Comité: `/pm-commitments` ya lo ofreció; formularlo con `/pm-escalate` una vez haya causa dicha |
| La cadencia del comité: la configuración dice semanal (domingo) y las notas del 10-18 dicen «próxima reunión en dos semanas» | Es del gerente y no necesita la sala; de ella depende si el siguiente comité cae el 11-08 (el día del hito) o el 11-15 | Decisión de Carlos Peña antes del 10-31; si cambia, se actualiza la configuración |
| Fecha para «Mandar el ajuste del presupuesto» (Laura Vélez), dicho el 10-18 como «la otra semana» | Laura no tiene nada más abierto que requiera la sala | Se le pide una fecha por mensaje esta semana |
| Estado declarado 70 % amarillo frente a lo que sustenta el plan (1 de 4 hitos, 25–50 %) | Es del informe de la semana, no de una reunión de compromisos | `/pm-report` |

### Anexo — al día al 2026-10-18, no se repasa
Sin corrida anterior para comparar, esto es lo que está abierto y dentro de plazo en el cálculo de hoy. Si el 10-31 no tiene acta, sube a «vencido sin evidencia».
- Andrés Lozano · Confirmar la fecha 23 · vence 2026-10-19
- Andrés Lozano · Actualizar la matriz 22 · vence 2026-10-25
- Sandra Gil · Revisar el anexo 11 · vence 2026-10-26 (reprogramado una vez; original 10-14)
- Mauricio Pérez · Revisar el anexo 19 · vence 2026-10-26
- Óscar Ramírez · Revisión con el proveedor · vence 2026-10-28
- Elena Duarte · Cerrar la prueba 18 · vence 2026-10-28 (reprogramado una vez; original 10-19)
- Paula Céspedes · Validar el ambiente 20 · vence 2026-10-28
- Cerrados con acta: Camilo Beltrán, Diana Molina («punto 8»), Ricardo Salas, Elena Duarte («documento 17»).

---
Esta agenda no convoca a nadie ni dirige la reunión. Cuando termine, `/pm-minutes` sobre la transcripción o las notas.
