# Plan — PRY-201 · Core de depósitos · borrador del 2026-10-18
**Desde:** acta de constitución del 2026-03-19 (`00-gobierno/2026-03-19-acta-constitucion.md`) · **Criterio de éxito:** «Core de depósitos en producción y medido» (acta, sección Criterio de éxito)

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-18 (versión 1.1, familia 0.5.0); no hizo falta registrarlos de nuevo.

**Una advertencia antes de leer:** el acta es de marzo y el proyecto lleva siete meses en ejecución (el informe del 2026-10-16 declara 70 % y amarillo). Esto no es un plan «desde cero» sino un borrador de WBS reconstruido sobre un acta que ya está en marcha. Existe un cronograma v1 (`10-plan/2026-03-19-cronograma-v1.xlsx`) con cuatro hitos; no hay WBS ni versión posterior del plan.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1 / 2 / 3», sin decir qué son | La WBS no puede descomponerse por entregable: los tres componentes no son algo que alguien reciba y acepte. Cualquier descomposición que haga yo sería inventada. |
| **Objetivo de negocio genérico:** «Entregar core de depósitos para Tesorería» | No dice qué cambia para Tesorería; no ayuda a decidir qué entra y qué no. |
| **Criterio de éxito sin umbral:** «en producción y medido» | No dice medido contra qué ni cuánto. «Medido» no se puede aceptar ni rechazar. |
| **Fuera de alcance vacío en la práctica:** «Lo que otro proyecto cubre» | No nombra el otro proyecto. No se puede saber dónde termina este. |
| **Autoridad del gerente no declarada** (`identity.authority`: no encontrada en la ficha) | No se sabe qué puede decidir Carlos Peña al planificar y qué debe subir a la patrocinadora (Liliana Torres) o al Comité de Arquitectura. |
| **Dependencias: «Ninguna declarada»**, pese a que el informe del 2026-10-16 registra la dependencia del calendario de liberaciones del core | El plan hereda una dependencia cero que el propio proyecto contradice. |
| **Cierre 2027-06-21 en el acta, pero sin hitos** | Las fechas de los hitos solo están en el cronograma v1, no en el acta; el acta no comprometió ninguna intermedia. |

Sí están: patrocinador (Liliana Torres), gerente (Carlos Peña), comité, presupuesto (1.200.000.000 COP, 2026-03-19) y fechas de inicio y cierre. Sigo adelante marcando los huecos; no los relleno.

## WBS
Solo hay material para un primer nivel, y viene del cronograma, no del acta. Los hitos del cronograma son momentos, no entregables aceptables; los tomo como el único esqueleto citable y lo declaro así.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Recibido por Carlos Peña (acta de recibo 2026-10-18); quién lo aprobó por el negocio: **sin definir** | Supuesto: hito del cronograma v1, no está en el acta | Del inicio (2026-03-29) a la fecha de línea base (2026-07-19): 112 días. Recibido el 2026-10-18, 91 días después de esa fecha (acta de recibo vs. cronograma) |
| 2 | Ambiente de pruebas certificado | **Sin definir** (quién certifica) | Supuesto: hito del cronograma v1 | vacía |
| 3 | Integración con el core | **Sin definir** | Supuesto: hito del cronograma v1 | vacía |
| 4 | Piloto con usuarios internos | **Sin definir** | Supuesto: hito del cronograma v1 (su fecha coincide con el cierre del acta) | vacía |
| 5 | Core de depósitos en producción y medido | Liliana Torres como patrocinadora, **supuesto**: el acta no dice quién acepta | Del acta (criterio de éxito) | vacía |
| 6 | Componentes 1, 2 y 3 | **Sin definir** | Del acta, pero sin contenido: no se descompone | vacía |

Observación: entre el piloto (4) y «en producción y medido» (5) no hay ningún hito. Ni el paso a producción ni la medición aparecen como entregables en el cronograma.

## Orden
Sin fechas. Lo que el material permite decir:
- 1 → 2 → 3 → 4 → 5, en el orden que trae el cronograma v1. Que cada uno **necesite** al anterior es un supuesto mío: el cronograma lista fechas, no dependencias.
- 3 (integración con el core) depende del calendario de liberaciones del core, riesgo que ya declara el informe del 2026-10-16 y que el acta no menciona.
- 6 (componentes) no se puede ordenar: no se sabe qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son los entregables del proyecto | Hay entregables sin hito y sin fecha; el plan queda corto sin que se vea. |
| El orden 1→2→3→4→5 es de dependencia y no solo de calendario | Si hay trabajo en paralelo, la ruta crítica es otra. |
| Los «Componentes 1–3» del acta están contenidos en los cuatro hitos | Si no, hay alcance sin plan. |
| La patrocinadora acepta el criterio de éxito final | Si no, el cierre no tiene quién lo firme. |
| El cronograma v1 de marzo sigue siendo la referencia vigente (no hay versión posterior) | Si hubo replanificaciones no documentadas, se está planificando contra una referencia vieja. |

Estos pasan a riesgos del proyecto cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Carlos Peña con la patrocinadora (Liliana Torres) |
| Umbral de «medido» en el criterio de éxito | Liliana Torres (patrocinadora) |
| Quién acepta cada uno de los hitos 2, 3 y 4 | Liliana Torres / Comité de Arquitectura; el acta no lo dice |
| Qué otro proyecto cubre lo que queda fuera de alcance | Carlos Peña, con la PMO |
| Autoridad del gerente de proyecto | Comité de Arquitectura / patrocinadora |
| Fase del proyecto (`identity.phase`: no encontrada) | Carlos Peña |
| Si el compromiso «Aprobar el diseño 5» (Andrés Lozano, abierto, vencido el 2026-10-08) es el mismo que el «Diseño funcional aprobado» recibido el 2026-10-18 | Carlos Peña (la ficha no lo da por cerrado) |
| Proveedor y alcance contractual: la ficha no tiene ningún proveedor registrado (`vendors` vacío), aunque las notas del 2026-10-18 hablan de uno | Carlos Peña |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-201 no apunta a una carpeta de fichas de la PMO, así que no busqué análogos. Es la respuesta correcta y evita una falsa precisión: no hay referencia para estimar duraciones.

El único dato de comparación es del propio proyecto: el hito «Diseño funcional aprobado» (línea base 2026-07-19) tiene acta de recibo del 2026-10-18, 91 días después. Es un dato de este proyecto, no una estimación para los demás hitos.

## Preguntas para el equipo
Una por duración vacía (y las que bloquean la WBS):
1. ¿Cuánto toma certificar el ambiente de pruebas, y quién lo certifica? (hito 2; la validación del ambiente 4 de Natalia Ospina lleva tres reprogramaciones, hoy 2026-10-24)
2. ¿Cuánto toma la integración con el core, y con qué liberaciones del core cuenta? (hito 3)
3. ¿Cuánto toma preparar y correr el piloto con usuarios internos, y quiénes son? (hito 4)
4. ¿Cuánto toma pasar a producción y qué se mide, contra qué línea y con qué umbral? (hito 5)
5. ¿Qué son los Componentes 1, 2 y 3, y quién recibe cada uno?
6. ¿Qué entregables concretos hay dentro de cada hito? Hoy ninguno se puede descomponer con lo escrito.
7. ¿Quién es el proveedor, qué entrega y para cuándo? ¿Con qué equipo llega a la siguiente fase?
8. ¿En qué consiste el ajuste de presupuesto que Laura Vélez prometió «la otra semana»?

## Para comprometer una fecha falta
Nada de esto está en un documento:
- **Disponibilidad real del equipo:** 13 personas asistieron a la reunión, pero ningún documento dice cuánto tiempo tiene cada una para el proyecto.
- **Fecha del proveedor y composición de su equipo para la siguiente fase:** las notas del 2026-10-18 dicen que podría no llegar completo; no hay contrato en la carpeta.
- **Ventana de ambientes de pruebas y de producción** (cuándo hay disponibilidad).
- **Calendario de liberaciones del core:** el informe lo cita como dependencia, sin fechas.
- **Presupuesto ajustado:** el ajuste está pendiente (Laura Vélez, sin fecha) y el actual se compromete contra los 1.200.000.000 COP del acta.

Ninguna fecha queda comprometida en este borrador. La fecha es del gerente.

## Después
Cuando el plan se apruebe, puedo registrarlo como línea base: hoy la ficha tiene la v1 del 2026-03-19 y esa sería la original. Los supuestos de arriba pasarían al RAID con doliente; y el riesgo comentado en reunión (el proveedor podría no llegar con el equipo completo), que nadie anotó, debería entrar de una vez.
