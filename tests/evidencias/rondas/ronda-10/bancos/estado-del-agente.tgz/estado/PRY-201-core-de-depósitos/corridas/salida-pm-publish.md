Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que registrarlos de nuevo.

Recalculé la ficha antes de publicar (corte 2026-10-18). Fecha de cierre: `plan.end_date` = 2027-06-21, igual a la del acta y a la del único cronograma que existe (v1, 2026-03-19); no hay cronograma más nuevo, así que no hay diferencia entre vigente y original (`plan.baseline` v1).

Antes de escribir: 87 campos con dato, 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`). El estado declarado es **amarillo** al 2026-10-16 (avance declarado 70 %, informe de avance). Lo más viejo es del 2026-03-19 (acta y cronograma), 7 meses, dentro del umbral de un año.

Publiqué la ficha en `documentos/proyectos/PRY-201-core-de-depósitos/00-gobierno/ficha-pm.json`, con corte al 2026-10-18.

**Lleva:** 87 campos con dato · 2 sin decir en ninguna parte · declara **amarillo** al 2026-10-16

**Lo más viejo que va ahí:** acta de constitución y cronograma v1, del 2026-03-19 — no pasa de un año.

Nota: la PMO verá que el 70 % declarado va por delante de lo que sustenta el plan (1 de 4 hitos cumplidos, entre 25 % y 50 %). Es una señal que ya está en la ficha, no algo que este comando añada.
