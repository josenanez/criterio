## Listo — Banco Ejemplo

**Miré:** 77 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: 34 .md, 15 .pdf, 12 .docx, 7 .csv, 7 .xlsx, 1 .json, 1 .txt · más reciente: 2026-10-18
**Eres:** PMO del portafolio (varios proyectos; tomé la respuesta sugerida)
**Te aviso:** dos días antes del comité del 2026-10-25, semanal (tus actas se llaman "comité semanal"; la fecha del próximo la supuse, corrígela si no es esa)
**En:** presentación
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.5.0 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.5.0-2026-10-18.md` y `.pdf` · SHA-256 9c54c0c51760b166…

Configuración en `.criterio/portafolio/config.json`. Lo que Vera va encontrando queda en `estado/` y los informes irán a `reportes/`.

### Probé con tres proyectos

Tomé PRY-203, PRY-209 y PRY-210, que tienen documentos del 2026-10-17 o 18 (PRY-201 empata en fecha; lo dejé para el barrido completo porque ya tiene su propio agente de proyecto).

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-203 Open Banking | 2 | Gerente Laura Vélez, patrocinador Ricardo Salas. Declara verde, 40%. Aprobado 2.400 M COP, ejecutado 720 M, proyección 2.239 M. Cierre comprometido 2026-08-10 (acta de constitución). | Cronograma, autoridad del gerente, fase. |
| PRY-209 Nómina electrónica | 5 | Gerente Javier Hoyos, patrocinador Rubén Cárdenas. Declara rojo, 37%. Aprobado 4.200 M, ejecutado 2.348 M, proyección 5.052 M. Cuatro hitos declarados cerrados; cierre 2026-07-21. | Autoridad del gerente, fase. Acta de recibo de 3 de los 4 hitos. |
| PRY-210 Portal de proveedores | 10 | Gerente y patrocinador son la misma persona (Ricardo Salas). Declara rojo, 48%. Aprobado 3.300 M, ejecutado 2.045 M, proyección 3.896 M. Contrato CT-137 con Integra Sistemas (4 entregables de 268,8 M). Cierre vigente 2027-04-26 (original 2027-01-14). | Producto (el acta dice "No aplica"), autoridad, fase. Acta de recibo de 2 de los 3 hitos cerrados. |

### Hallazgos (señales que levantó `compute`)

**PRY-209 Nómina electrónica** — 5 señales, el gerente ya lo declara en rojo pero ninguna de estas está explicada en su informe:
- `progress_vs_plan`: declara 37%, y el cronograma tiene los 4 hitos cerrados (100%): 63 puntos de diferencia.
- `milestone_met_without_evidence` ×3: Diseño funcional aprobado (venció 2026-01-06), Integración con el core (2026-05-17) y Piloto con usuarios internos (2026-07-21) figuran cerrados y no hay acta que lo pruebe. Solo Ambiente de pruebas certificado tiene acta (2026-10-08).
- `variance_cost`: la proyección (5.052 M) supera el aprobado en 20,3 %.

**PRY-210 Portal de proveedores** — 9 señales:
- `variance_time`: +102 días contra la línea base original (21,2 %).
- `rebaseline_unauthorized`: el cronograma v2 (2026-10-17) mueve la salida a producción 102 días, y la solicitud de cambio CC-01 (2026-10-07) sigue "pendiente de presentación al comité": 0 días autorizados.
- `milestone_overdue`: Piloto con usuarios internos, previsto 2026-10-10, 8 días vencido.
- `milestone_met_without_evidence` ×2: Diseño funcional aprobado y Ambiente de pruebas certificado, cerrados sin acta. Integración con el core sí la tiene (2026-10-18).
- `progress_vs_plan`: declara 48%; el plan sostiene entre 60 y 80 %.
- `variance_cost`: la proyección supera el aprobado en 18,1 %.
- `vendor_deliverable_late` ×2: Bolsa de horas de desarrollo (181 días) y Parametrización del tarifario (75 días) siguen pendientes. Está facturado 268,8 M y hay un solo entregable aceptado por ese valor.

**PRY-203 Open Banking** — `compute` no levantó señales.

### El portafolio completo
10 proyectos más (PRY-199, 200, 201, 202, 204, 205, 206, 207, 208, 211), 74 documentos. Estimado: dos lotes, uno tras otro, unos 30 a 40 minutos de lectura en esta conversación (estimación mía a partir de estos tres; no la medí).

### Lo que le falta a tu carpeta
- **PRY-203 no tiene cronograma.** Su cierre comprometido (2026-08-10) ya pasó, el proyecto declara 40 % en verde y nada en la carpeta actualiza esa fecha. No es una señal calculada; es lo que la carpeta no permite saber.
- **Ningún proyecto declara la autoridad del gerente** (hasta qué monto decide sin comité): 3 de 3 en esta muestra.
- **Patrocinador y gerente coinciden en PRY-210**, y en su comité Ricardo Salas aparece dos veces en la lista de asistentes.
- **Compromisos con responsable ausente:** en el comité del 2026-10-18 de PRY-209 el compromiso es de Gustavo Neira, y en el del 2026-10-14 de PRY-210 de María Restrepo; ninguno figura entre los asistentes de su acta. Los registré como abiertos, con fecha 2026-11-08 y 2026-11-15.
- Hay una carpeta `estado/PRY-201-core-de-depósitos/` con el estado del agente de proyecto; convive con este estado y no la toqué.

Ninguno es bloqueante: esto funciona con lo que haya.

*Preguntas hechas: 0 (sesión sin interfaz; todo con la respuesta sugerida).*
