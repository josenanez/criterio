# Corrida del 2026-10-18 · budget-tracking

13 proyectos · 37 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Presupuesto PRY-210: proyección 18,1% sobre aprobado; comprometido declarado menor que ejecutado (incoherente); sin evidencia contable; CC-01 pendiente.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-210 (estado/records/PRY-210.json) y cifras recalculadas con `portafolio.py compute` al 2026-10-18. Documentos: acta de constitución (2025-09-11), informe de avance (2026-10-17), solicitud de cambio CC-01 (2026-10-07), cronograma v2 (2026-10-17). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez, 2026-10-18).

## Presupuesto — PRY-210 Portal de proveedores al 2026-10-18
**Moneda:** COP (única; no hay contratos en otra moneda)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100% | Acta de constitución | 2025-09-11 |
| Comprometido | 1.765.771.095 | 53,5% | Informe de avance (declaración) | 2026-10-17 |
| Ejecutado | 2.045.359.196 | 62,0% | Informe de avance (declaración) | 2026-10-17 |
| Proyección al cierre | 3.896.316.249 | 118,1% (18,1% sobre el aprobado) | Informe de avance (declaración) | 2026-10-17 |

**Disponible real** (aprobado menos comprometido): 1.534.228.905 COP — **no es confiable**: el comprometido declarado (1.765.771.095) es menor que el ejecutado (2.045.359.196). Lo ejecutado debería estar contenido en lo comprometido; una de las dos cifras está mal o mide otra cosa. Mientras no se aclare, no hay holgura demostrable. Con la proyección en 118,1%, el disponible real tampoco alcanza para el cierre.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | 0% (ninguna replanificación de presupuesto aprobada) |
| Fecha de cierre (referencia de tiempo) | 2027-01-14 | 2027-04-26 | +102 días (21,2%) contra la original; 0 contra la vigente |

Replanificaciones de presupuesto: 0. Hay una solicitud pendiente, CC-01 (2026-10-07): 204.000.000 COP adicionales y +102 días, sin decisión ni decisor. La línea base de tiempo v2 (2026-10-17) ya refleja esos 102 días, sin autorización: la señal `rebaseline_unauthorized` marca 102 días movidos y 0 autorizados.

### Ejecución frente a avance
Ejecutado 62,0% · Hitos cumplidos 3 de 5 · Avance declarado 48,0%, y el plan sostiene entre 60% y 80% (12 puntos atrás). Se gasta por encima del avance declarado y el proyecto va atrasado frente al plan: es la señal que este informe busca. Además, de los 3 hitos "cumplidos", solo "Integración con el core" tiene evidencia (acta de recibo); "Diseño funcional aprobado" y "Ambiente de pruebas certificado" no la tienen.

### Alertas
- **Proyección por encima del aprobado:** 18,1% sobre 3.300.000.000, umbral 10%. El informe de avance la declara y no explica de dónde sale.
- **Comprometido menor que ejecutado:** incoherencia entre las dos cifras declaradas (ver arriba).
- **Ejecución desalineada del avance:** ejecutado 62,0% contra avance declarado 48,0%.
- **Comprometido (53,5%) bajo el umbral de 90%:** no alerta por sí solo, pero dada la incoherencia anterior no se debe leer como tranquilidad.
- **Proveedor Integra Sistemas Ltda. (CT-137):** facturado 268.808.113 COP, igual a lo aceptado; 2 entregables vencidos sin recibo: "Bolsa de horas de desarrollo" (181 días) y "Parametrización del tarifario" (75 días).
- **Cambio sin autorización:** CC-01 pendiente y la línea base de tiempo ya movida.

### Sin dato
- Presupuesto vigente aprobado distinto del original: no existe documento que lo declare (solo hay una cifra aprobada).
- Comprometido, ejecutado y proyección son declaraciones del gerente (0 fuentes de evidencia contable en la ficha). La proyección y las otras dos llevan fecha 2026-10-17, así que no son más viejas que ningún movimiento de presupuesto documentado.
- Fuente contable del ejecutado (facturas, ERP): no hay. Solo se encontró la factura de CT-137 de 2026-09-30.
- Aprobado: la fuente tiene 13 meses, sobre el umbral de 12.
- Tasa de cambio: no aplica.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto, o detallar el comprometido por proveedor para resolver la incoherencia del comprometido frente al ejecutado.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de la ficha y de `portafolio.py compute`; la verificación contra los documentos citados es de quien lo lee. Lo que no está declarado se marcó `not_found`.
