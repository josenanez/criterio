# Corrida del 2026-10-18 · portfolio-report

13 proyectos · 77 documentos, 0 releídos y 77 sin cambio · 35 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

El informe quedó en `/home/claude/banco/ronda-10/bancos/espacio/reportes/index.html`.

Verdes contradichos (PRY-200, 204, 206, 211) y 23 hitos cumplidos sin evidencia; ningún proyecto con patrocinador identificado.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-18
Banco Ejemplo · 13 proyectos · 11 con hallazgos (67 señales) · fichas de `estado/records/`, instantánea y último barrido del 2026-10-18 (ninguna con más de una semana).

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Qué cambió desde 2026-10-18
Sin cambios desde la corrida anterior. La única instantánea previa es la de hoy (2026-10-18); este informe es punto de partida, no hay delta que reportar.

## Contradicciones abiertas
Sin campos en conflicto entre fuentes en esta corrida (0 problemas de ficha). Sí hay contradicción entre lo declarado y la evidencia: ver «Estado general».

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-200 Originación digital | Integración con el core | 2026-10-14 | 4 |
| PRY-210 Portal de proveedores | Piloto con usuarios internos | 2026-10-10 | 8 |

Además, 23 hitos figuran como cumplidos sin documento que lo respalde (detalle por proyecto en `index.html`).

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-200 Originación digital | 19 | 2026-09-29 (informe de avance) |

## Dependencias en riesgo
Ninguna señal de dependencia rota en esta corrida.

## Sin sustento
- Verdes contradichos por la evidencia (4): PRY-200 (silencio 19 días, hito vencido), PRY-204 (costo +10,4 %), PRY-206 (compromiso vencido, hitos sin evidencia), PRY-211 (atraso +31,2 %, avance 61 % frente a hitos que sostienen 100 %).
- Avance declarado frente a lo que sostiene el plan: 8 proyectos con brecha (PRY-201 declara 70 % y el plan sostiene 25–50 %; PRY-209 declara 37 % con 4/4 hitos cumplidos).
- Proveedores: 3 entregables tarde, 1 aceptado sin evidencia, 1 facturación por encima de lo aceptado.

## Vacíos de información
- Ningún proyecto tiene autoridad (patrocinador) identificada: 13 de 13.
- 4 proyectos sin producto asociado: PRY-202, PRY-205, PRY-208, PRY-210.
- Compromisos de reunión en el portafolio: 10 vencidos sin evidencia, 2 sin fecha y 3 reprogramados (la mayoría en PRY-201).

## Estado general
| Proyecto | Desviación tiempo vs original | Desviación costo | Replanificaciones |
|---|---|---|---|
| PRY-204 Débito contactless | — | +10,4 % (CC-01 sin línea base, 117 días) | 0 |
| PRY-207 Onboarding PyME | +88 d (40 %) | — | 1 |
| PRY-208 Motor de decisión | — | +20,8 % | 0 |
| PRY-209 Nómina electrónica | — | +20,3 % | 0 |
| PRY-210 Portal de proveedores | +102 d (21,2 %) | +18,1 % | 1 |
| PRY-211 Cobranza digital | +64 d (31,2 %) | — | 1 |
| PRY-199, PRY-203 | sin señales | sin señales | 0 |

Hay además un re-baseline sin autorización. Los demás proyectos están en `index.html`.

## Necesito que confirmes
Ninguna pregunta de confirmación en esta corrida (prueba sin interfaz; se toma la respuesta sugerida: diferirlas a la corrida mensual).

---
Criterio Portfolio v0.5.0 · fichas aplicadas: 13, del 2026-10-18 · campos inciertos: ninguno marcado como ambiguo · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

Archivos del informe (en `reportes/`):
- `index.html` — por campo, con la cadena de evidencia: para quien va a actuar.
- `decisiones.html` — por decisión: para el patrocinador y el comité.
- Una página por proyecto, por producto, `proyectos.html` y `productos.html` (26 páginas).
