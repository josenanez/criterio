# Corrida del 2026-10-18 · health-check

13 proyectos · 93 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Diagnóstico de PRY-202 desde 6 documentos: 6 sostenidas, 11 sin sustento, 3 contradicciones (avance 51% vs 5 de 5 hitos cerrados; salida a producción; factura sobre lo aceptado). Dijo que no sabe: avance real, ejecutado, autoridad del gerente, minutas del comité.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-202 Migración a la nube · 2026-10-18

**Leí:** 6 documentos · de 2025-12-06 a 2026-10-11 · formatos: md (2), docx (1), xlsx (1), pdf (2)
**No pude leer:** ninguno. Busqué también menciones de PRY-202, CT-812 y Redes del Norte en las demás carpetas de proyectos y productos: no hay ninguna fuera de la carpeta del proyecto, así que no existe una minuta ajena que lo mencione.

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 11 · **Contradicho:** 3 (20 en total; la lista está al final de cada bloque).

Desde esta carpeta se puede afirmar el marco: quién patrocina, quién gerencia, cuánto se aprobó, qué se firmó con el proveedor, que una de las tres entregas contractuales tiene acta de recibo y que hay una factura radicada. No se puede afirmar el avance: el informe declara 51 % y amarillo, mientras el cronograma marca los cinco hitos como cerrados, incluida la salida a producción del 2026-09-25. Ningún hito cerrado tiene documento de evidencia. El dinero ejecutado, el comprometido y la proyección salen solo del informe de avance. Lo facturado supera lo aceptado según el script en 80.288.517 COP, y esa cifra de «aceptado» ya cuenta una entrega sin acta.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Gustavo Neira | acta de constitución, 2025-12-06 |
| Gerente | Javier Hoyos | acta de constitución, 2025-12-06 |
| Autoridad declarada | **No está.** Ningún documento dice qué puede aprobar el gerente | — |
| Comité | Comité de Arquitectura (aprobó el presupuesto el 2025-12-06). No hay ninguna minuta suya en la carpeta | acta de constitución |

El acta tiene texto de plantilla sin llenar: alcance «Componente 1, Componente 2, Componente 3», exclusión «Lo que otro proyecto cubre», objetivo «Entregar migración a la nube para Banca Hipotecaria». El criterio de éxito, «en producción y medido», no trae ninguna métrica. La dependencia declarada es «Ninguna», aunque un hito es la integración con el core. Sin autoridad declarada no hay desviación aprobada: lo que existe son fechas que alguien escribió.

### Contra el plan
- **Línea base:** hay una sola (v1, aprobada el 2025-12-06, cierre 2026-09-25, fuente `10-plan/2025-12-06-cronograma-v1.xlsx`). Replanificaciones: 0. Desviación en días contra la original y contra la vigente: 0 y 0 (salida del script).
- Ese 0 mide que nadie replanificó, no que el proyecto vaya a tiempo. En el cronograma, `fecha_vigente` es igual a `fecha_linea_base` en los cinco hitos.
- El informe del 2026-10-11 dice que el equipo perdió dos semanas por la rotación de un desarrollador clave. El cronograma no recoge ese efecto, y no hay solicitud de cambio ni línea base nueva.
- El cronograma se llama «v1» y lleva fecha 2025-12-06, pero tiene estados «cerrado» que solo pudieron escribirse después. No hay historial que diga quién los puso ni cuándo.
- La fecha de cierre comprometida (2026-09-25) venció hace 23 días. Contra ella el avance declarado es 51 %, y el plan respalda 100 % (5 de 5 hitos): 49,0 puntos de brecha, en el sentido de atraso.

### Hitos vencidos sin evidencia
Los cinco figuran como «cerrado»: ninguno aparece como vencido y abierto. Ninguno tiene documento de evidencia.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-02-10 | 250 | Acta de aprobación del diseño |
| Ambiente de pruebas certificado | 2026-04-08 | 193 | Certificado o acta del ambiente |
| Integración con el core | 2026-06-04 | 136 | Acta de integración o de pruebas |
| Piloto con usuarios internos | 2026-07-30 | 80 | Informe o acta de cierre del piloto |
| Salida a producción | 2026-09-25 | 23 | Acta de paso a producción |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 3.300.000.000 | 1.661.270.154 (50,3 %) | 1.587.108.579 (48,1 %) | 3.241.959.414 (−1,8 % sobre lo aprobado) | 1.638.729.846 |

- **Aprobado:** el acta de constitución lo respalda.
- **Comprometido, ejecutado y proyección:** salen solo del informe de avance de quien gerencia. Ningún documento de contabilidad o de compras los respalda.
- **Proveedor Redes del Norte, contrato CT-812.** Tres entregas de 267.340.828 COP cada una:
  - Licenciamiento del motor: vencía el 2026-03-04, está «pendiente», lleva 228 días de atraso y no tiene acta.
  - Bolsa de horas: aparece «recibido» en el contrato, sin acta de recibo.
  - Parametrización del tarifario: vencía el 2026-08-07 y tiene acta de recibo del 2026-08-20, firmada por Javier Hoyos, como exige la condición de pago.
- **Facturado:** la factura FV-1812 del 2026-10-01 es por 614.970.173 COP, radicada en cuentas por pagar. El concepto dice solo «Entregables del contrato CT-812» y no detalla cuáles.
- **Aceptado:** 534.681.656 COP según el script, que cuenta como aceptadas la bolsa de horas y la parametrización. La diferencia a favor del proveedor es 80.288.517 COP. Esa cifra de «aceptado» incluye la bolsa de horas, que no tiene acta; el documento solo respalda una entrega, la parametrización.

### Lo que se dijo y nadie registró
- **No hay minutas, ni registro de riesgos, ni registro de compromisos** en la carpeta. Por eso no hay compromisos vencidos, y eso no significa que no los haya.
- El único riesgo («Concentración del conocimiento en una sola persona») y la única incidencia («pérdida de dos semanas por rotación») están en el informe de avance, sin responsable, fecha ni mitigación.
- El hecho de que el licenciamiento lleve 228 días sin entrega no aparece como riesgo ni como incidencia en ningún lado.
- Las pruebas: el informe dice que «se ajustó el plan de pruebas con el área de seguridad», con el ambiente de pruebas ya certificado desde abril. Nadie lo registró como cambio ni como dependencia.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance del 51 % | Informe de avance 2026-10-11: 51 %, amarillo | Cronograma: 5 de 5 hitos cerrados (100 %) |
| «Salida a producción» cerrada, 2026-09-25 | Cronograma: cerrado | Informe 2026-10-11: 51 % y plan de pruebas aún en ajuste; el criterio de éxito exige producción |
| La factura corresponde a entregables recibidos | Factura FV-1812: 614.970.173 COP | Contrato CT-812: licenciamiento pendiente. El script da 80.288.517 COP facturados sobre lo aceptado, y solo una entrega tiene acta |

### Sin sustento
Lo que ningún documento respalda ni contradice, 11 afirmaciones:
1. Comprometido de 1.661.270.154 COP.
2. Ejecutado de 1.587.108.579 COP.
3. Proyección de 3.241.959.414 COP.
4. Diseño funcional aprobado: cerrado.
5. Ambiente de pruebas certificado: cerrado.
6. Integración con el core: cerrada.
7. Piloto con usuarios internos: cerrado.
8. Bolsa de horas «recibida».
9. Estado «amarillo»: no hay criterio escrito del que salga.
10. Pérdida de dos semanas por la rotación del desarrollador.
11. Riesgo de concentración del conocimiento.

Las 6 sostenidas son: presupuesto aprobado; patrocinador, gerente y comité nombrados; fechas de inicio y cierre comprometidas (acta y cronograma coinciden); parametrización recibida; factura FV-1812 existente y radicada; licenciamiento pendiente (el contrato lo dice y no hay acta que lo contradiga, aunque la columna de estado del contrato no tiene fecha, y un contrato firmado el 2025-12-07 no pudo traerla escrita así).

### Lo que esta carpeta no permite saber
- **Si el proyecto salió a producción.** Falta el acta de paso a producción. Sin ella, el cierre del hito del 2026-09-25 y el 51 % no se pueden reconciliar.
- **Cuál es el avance real.** Faltan los documentos de evidencia de los cinco hitos.
- **Cuánto se ha gastado de verdad.** Falta el reporte de contabilidad o de compras con lo ejecutado y lo comprometido. Hoy el 48,1 % ejecutado es palabra del gerente.
- **Si se pagó o se puede pagar bien la factura.** Falta el detalle de qué entregas cubre y el acta de la bolsa de horas. Hasta entonces, 80.288.517 COP de la factura no tienen entrega aceptada que los respalde.
- **Qué puede decidir el gerente.** Falta la autoridad declarada. Sin ella no se puede decir si algún cambio de fechas o de dinero estaría aprobado.
- **Si el Comité de Arquitectura sigue el proyecto.** No hay minutas.
- **Cuánto cuesta el atraso del licenciamiento.** Falta un documento que diga qué depende de él.

### Después
Esta carpeta no permite diagnosticar el avance ni el dinero ejecutado. Es un resultado, no una disculpa. Queda ofrecido: (a) preparar el punto del comité del 2026-10-25 con la lista de lo que falta; (b) llevar al gerente las tres contradicciones como preguntas, una por una. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

---
Criterio Portfolio 0.5.0 · Diagnóstico de PRY-202 del 2026-10-18 desde 6 documentos (2025-12-06 a 2026-10-11); declaración del informe del 2026-10-11 · Campos inciertos: autoridad, producto y fase; avance, comprometido, ejecutado y proyección (solo declaración) · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
