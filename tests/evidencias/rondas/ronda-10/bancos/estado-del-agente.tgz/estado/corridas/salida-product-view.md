Fuente: cálculo de `portafolio.py compute` sobre las fichas en `estado`, con corte al 2026-10-18. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18).

## Productos al 2026-10-18

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209 Nómina electrónica) | 5 alertas | 2026-07-21 (PRY-209, vencida hace 89 días) | COP 4.200.000.000 | COP 2.805.816.203 |

**nómina empresarial tiene un solo proyecto (PRY-209), así que la vista por producto no aporta más que la ficha del proyecto.** No hay sección de producto, ni dependencias internas que cruzar (`dependencies` está vacío).

Lo que dice la ficha de PRY-209:
- Avance: declara 37,0 %, pero el plan tiene 4 de 4 hitos como cumplidos y respalda 100 %. Brecha de 63,0 puntos.
- Hitos dados por cumplidos sin evidencia: «Diseño funcional aprobado» (vence 2026-01-06, 285 días), «Integración con el core» (2026-05-17, 154 días) y «Piloto con usuarios internos» (2026-07-21, 89 días).
- Costo: proyección COP 5.052.016.044 contra aprobado COP 4.200.000.000, es decir 20,3 % por encima. Ejecutado COP 2.347.857.763 (55,9 %); comprometido 66,8 %; disponible real COP 1.394.183.797.
- El informe de avance (2026-10-18) declara estado rojo. Las tres señales de arriba no figuran entre las que el informe reconoce.
- Dinero: el único proyecto del producto trae las cuatro cifras (1 de 1), así que la suma no es parcial.
- No sé: quién es la autoridad del proyecto ni su fase (`identity.authority` e `identity.phase` faltan). Además, 24 campos de la ficha vienen de una fuente del 2025-10-23, con 12 meses de antigüedad.

Cada fuente de la ficha está marcada como declaración o sin marcar; ninguna es evidencia (0 de 36).

**Proyectos sin producto declarado** (cada uno es un hallazgo de gobierno: nadie puede responder por el conjunto al que sirven):
PRY-202 Migración a la nube, PRY-205 Prevención de lavado de activos, PRY-208 Motor de decisión, PRY-210 Portal de proveedores. El área dueña no sale del cálculo; no la afirmo.

Aparte: PRY-199 declara el producto «PRD-299», un código y no un nombre; parece que no está normalizado contra los demás productos. Conviene confirmarlo.

Pie de rigor: los datos son los de las fichas, con las citas que ellas traen. La verificación es de quien lee. No se cruzaron documentos fuera de las fichas.
