# Corrida del 2026-10-18 · status-report

13 proyectos · 32 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Informe de PRY-200: declara verde 75% (2026-09-29) sin sustento documental; hito Integración con el core vencido 4 días, 2 hitos cumplidos sin evidencia, 19 días en silencio. Dijo que no sabe: última reunión, autoridad, fase, y si la reprogramación declarada movió fechas.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Informe sale de la ficha `estado/records/PRY-200.json` (actualizada 2026-10-18), recalculada con `compute` al 2026-10-18. Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-18 (versión 1.1).

## PRY-200 Originación digital — estado al 2026-10-18

**Declara el gerente:** verde · 75% · al 2026-09-29 (Laura Vélez, informe de avance; 19 días de antigüedad, aún dentro del umbral de 30 días de `declaration_stale`)
**Sustento documental:** sin sustento. La ficha no tiene ningún dato marcado como evidencia (0 evidencia, 6 declaración, 13 sin marcar).
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `silent` (alerta `declared_vs_evidence`: reporta verde y hay evidencia que ese verde no cubre).
**Último documento:** 2026-09-29 (informe de avance) · **Última reunión:** sin dato — no hay actas ni transcripciones en la carpeta del proyecto.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-02-14 | 2027-02-14 | 0 días (contra original y contra vigente) |
| Presupuesto | 4.200.000.000 COP aprobado | proyección 4.383.262.818 COP | +4,4% sobre lo aprobado (umbral 10%) |

Ejecutado 1.078.552.588 COP (25,7%); comprometido 1.565.345.910 COP (37,3%); disponible real 2.634.654.090 COP. Las cifras de dinero son declaradas en el informe, no contrastadas con ningún documento financiero.

Replanificaciones: 0 registradas. Pero el informe del 2026-09-29 dice «Se reprogramó la salida por ventana de cambio del área de operaciones», y ni la línea base ni los hitos muestran una fecha movida ni hay solicitud de cambio. O hubo un cambio no formalizado o el cronograma está desactualizado; los documentos no permiten decir cuál.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-02-10 | 2026-02-10 | cumplido (declarado) | ninguna — 250 días sin sustento |
| Ambiente de pruebas certificado | 2026-06-13 | 2026-06-13 | cumplido (declarado) | ninguna — 127 días sin sustento |
| Integración con el core | 2026-10-14 | 2026-10-14 | pendiente, **vencido hace 4 días** | — |
| Piloto con usuarios internos | 2027-02-14 | 2027-02-14 | pendiente | — |

Avance declarado 75%; el plan sustenta entre 50% y 75% (2 de 4 hitos cumplidos, y esos dos sin evidencia). La brecha en puntos es 0, pero solo si se aceptan como ciertos los dos hitos sin sustento.

### Dónde no coincide
- **Verde vs. hito vencido:** el informe del 2026-09-29 declara verde; el cronograma v1 (2025-09-30) fija «Integración con el core» al 2026-10-14 y sigue pendiente 4 días después. No hay documento posterior al 2026-09-29 que diga qué pasó.
- **Verde vs. silencio:** 19 días sin un documento nuevo (umbral 15).
- **Hitos cumplidos sin evidencia:** ningún acta de aprobación ni certificado en la carpeta respalda los dos hitos marcados como cumplidos.
- **Reprogramación declarada, plan sin mover:** ver arriba.

### Abierto
**Riesgos e incidencias sin movimiento:** riesgo «Concentración del conocimiento en una sola persona» (informe 2026-09-29), sin responsable, fecha ni plan de mitigación en los documentos. Incidencia: la reprogramación de la salida por ventana de cambio (misma fuente).
**Compromisos vencidos:** ninguno registrado — no por estar al día, sino porque no hay actas de las que extraerlos.
**Dependencias sin confirmar:** ninguna registrada. La ventana de cambio de Operaciones es una dependencia implícita que nadie registró como tal.

### Sin dato
- Autoridad del gerente (`identity.authority`) y fase (`identity.phase`).
- Última reunión, compromisos y cambios: la carpeta solo tiene acta de constitución, cronograma v1 e informe de avance.
- Proveedores: ninguno registrado.
- Casi toda la identidad y el plan salen del acta y el cronograma de 2025-09-30, con 13 meses de antigüedad (sobre el umbral de 12 meses): código, nombre, área, producto, patrocinador, gerente, comité, fechas, alcance, exclusiones, moneda y aprobado.

### Siguiente paso
La alerta `declared_vs_evidence` y el hito vencido justifican llevar el caso a comité (próximo: 2026-10-25). Si la reprogramación de la salida movió fechas, corresponde una solicitud de cambio. Puedo preparar cualquiera de las dos si lo pides.

---
Criterio Portfolio 0.5.0 · Ficha de PRY-200 actualizada el 2026-10-18; declaración del 2026-09-29 · Campos inciertos: autoridad, fase, última reunión, fechas y presupuesto con 13 meses · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0
