# Corrida del 2026-10-18 · change-control

13 proyectos · 32 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Solicitud PRY-202 +30 días sin solicitante, motivo ni costo; fecha vigente ya vencida hace 23 días; hito de salida marcado met sin evidencia; sin autoridad ni dependencias declaradas; impacto en portafolio 0 por falta de dependencias, no se calculó holgura.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-202.json` (corte 2026-10-11) y del acta `PRY-202-migración-a-la-nube/00-gobierno/2025-12-06-acta-constitucion.md`. Términos vigentes (v0.5.0), aceptados por José Francisco Ñáñez el 2026-10-18.

## Solicitud de cambio — PRY-202 Migración a la nube — 2026-10-18

**Qué se pide:** mover 30 días la salida a producción (hito «Salida a producción»). **Quién lo pide:** no consta en ningún documento de la carpeta. **Por qué:** no consta. El único hecho cercano es el informe del 2026-10-11: «el equipo perdió dos semanas por rotación de un desarrollador clave»; son 14 días, no 30, y nadie lo liga a esta solicitud.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, 2025-12-06) | Sin cambio declarado | 0 declarado |
| Tiempo | Línea base 1: cierre 2026-09-25 | 2026-10-25 | +30 días |
| Costo | Aprobado 3.300.000.000 COP; proyección declarada 3.241.959.414 | No se sabe | **No declarado** |

- **Costo:** nadie dijo cuánto cuesta un mes más (equipo, proveedor CT-812, ambientes). La proyección declarada deja 58.040.586 COP de margen (1,8 % del aprobado); no he calculado ni inventado un costo del mes adicional.
- **Alcance sin impacto:** mover la fecha sin tocar alcance ni costo significa que alguien lo absorbe en horas no pagadas o en calidad (el plan de pruebas ya se ajustó con seguridad y el riesgo abierto es la concentración del conocimiento en una persona). Hay que decir quién.

### Hallazgo que cambia la solicitud: la fecha ya pasó
- La fecha vigente (2026-09-25) venció hace **23 días** y el proyecto sigue en 51 % declarado, amarillo (informe 2026-10-11). Esto no es un cambio previo: es una **regularización**. Mover 30 días desde 2026-09-25 da 2026-10-25, solo 7 días en el futuro.
- La ficha marca «Salida a producción» como `met` con evidencia **nula**, y lo mismo los otros cuatro hitos. Es contradictorio con el 51 % y con el criterio de éxito («en producción y medido»). **Ningún documento sustenta que se haya salido a producción.** Hay que aclararlo antes de aprobar nada.
- Si 30 días bastan es otra pregunta sin respuesta: con 51 % de avance reportado y el último hito sin evidencia, no hay base en los documentos para decir que 2026-10-25 es alcanzable.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | El cálculo (`impact`) no alcanza a nadie: 0 directos, 0 indirectos, 0 que no puedan sostener fecha, 0 dependencias sin confirmar | — |

Esto **no significa que no haya efecto**: el acta declara «Dependencias: Ninguna declarada» y la ficha tiene `raid.dependencies` vacío. Un proyecto de migración a la nube de Banca Hipotecaria sin ninguna dependencia declarada es más probablemente una omisión que un hecho. Lo que el cálculo tampoco dice: cuántos días se mueve cada hito intermedio o cada actividad; eso requiere holgura por actividad, que la ficha no tiene.

### Quién decide
**Autoridad requerida:** no determinable. **Según:** el acta no declara autoridad para cambios (`identity.authority`: no encontrado). Lo único declarado es que el presupuesto y la línea base los aprobó el Comité de Arquitectura el 2025-12-06. **Va a comité:** sí, por defecto, al Comité de Arquitectura, que aprobó la línea base original; el hallazgo de fondo es que nadie tiene umbral escrito para decidir por menos.

### Si no se aprueba
El proyecto sigue contra una fecha (2026-09-25) vencida hace 23 días, con 51 % de avance declarado y un hito marcado cumplido sin evidencia. Quedaría atraso sin cobertura de gobierno.

### Si se aprueba
Línea base 2 — cierre 2026-10-25 · presupuesto: **sin definir** (3.300.000.000 COP vigente hasta que alguien declare otro) · motivo: **pendiente** (el documento que la aprobaría no existe).
Desviación acumulada contra la línea base original: **+30 días** de tiempo (línea base 1: 2026-09-25) · costo: no calculable hoy (solo la proyección declarada de 3.241.959.414 COP, que es −1,8 % contra el aprobado y no incluye el mes adicional). Es la primera replanificación: el conteo de replanificaciones pasa de 0 a 1. La línea base 1 no se toca.

### Reconciliación de cambios
`changes` vacío: no hay cambios aprobados registrados, así que los 30 días no tienen autorización documentada. Cualquier movimiento de fecha hecho antes de este paquete quedaría como no autorizado.

### Otras cosas de la ficha que el comité debería ver al decidir (fuera de este cambio)
- CT-812: facturado 614.970.173 COP frente a dos entregables aceptados por 534.681.656 COP; el tercero («Licenciamiento del motor», vencido 2026-03-04) sigue pendiente y sin acta de recibo. Diferencia: 80.288.517 COP facturados sin entregable aceptado que los cubra.
- Concentración del conocimiento en una persona: es el riesgo que ya se materializó en la rotación; un mes más de plazo no lo mitiga.

### Preguntas que el paquete no puede responder solo
Quién lo pide y por qué; cuánto cuesta el mes adicional; si la salida a producción realmente ocurrió; qué dependencias tiene el proyecto; quién puede aprobar un cambio de esta magnitud.

## Después
Esto debe ir al Comité de Arquitectura. No registro línea base nueva: no hay aprobación de quien pueda darla. Si se aprueba, se registra con la fecha, el motivo y el acta de la aprobación.

---
**Pie de rigor:** sale de la ficha PRY-202 (corte 2026-10-11, tres campos sin encontrar: producto, autoridad, fase) y del acta del 2025-12-06. El estado y los montos de ejecución son declaración del gerente, no medición. No leí más documentos que esos dos. El efecto en el portafolio es lo que dicen las dependencias declaradas, que aquí son ninguna.
