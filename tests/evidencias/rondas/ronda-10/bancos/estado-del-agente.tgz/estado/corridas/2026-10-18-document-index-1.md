# Corrida del 2026-10-18 · document-index

13 proyectos · 15 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

77 documentos sin cambio, 0 por releer. 101 citas de PRY-201 marcadas como no resueltas pese a que los archivos existen en su carpeta; probable diferencia de resolución de ruta relativa, sin confirmar.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-18

**Documentos:** 77 · **Sin cambio:** 77 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | 101 campos de `pm_record` (identidad, declarado, plan, hitos, dinero, compromisos 0–25) | `00-gobierno/2026-03-19-acta-constitucion.md`, `10-plan/2026-03-19-cronograma-v1.xlsx`, `20-seguimiento/2026-10-16-informe-avance.pdf`, `30-reuniones/2026-09-06 … 2026-10-11-comite-semanal.md`, `2026-10-18-notas-reunion.txt` |

Aclaración: el índice las marca como no resueltas, pero los 9 documentos citados existen en `documentos/proyectos/PRY-201-core-de-depósitos/` con esas mismas rutas relativas. Las citas de la ficha van relativas a la carpeta del proyecto y el índice parece resolverlas desde la raíz de `documentos/proyectos`. No lo he confirmado leyendo el script; es una hipótesis. Ninguna otra ficha tiene citas rotas.

### Formatos que no se pudieron leer
Este comando no lee documentos; no se intentó leer ninguno.

### Siguiente paso
Nada que releer ni proyecto que recalcular (`projects_to_recompute` vacío). No hay barrido que ofrecer.
