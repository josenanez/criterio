## Carpeta al 2026-10-18

**Documentos:** 77 · **Sin cambio:** 77 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-201 | 101 campos de `pm_record` (identidad, declarado, plan, hitos, dinero, compromisos 0–25) | `00-gobierno/2026-03-19-acta-constitucion.md`, `10-plan/2026-03-19-cronograma-v1.xlsx`, `20-seguimiento/2026-10-16-informe-avance.pdf`, `30-reuniones/2026-09-06 … 2026-10-11-comite-semanal.md`, `2026-10-18-notas-reunion.txt` |

Aclaración: el índice las marca como no resueltas, pero los 9 documentos citados existen en `documentos/proyectos/PRY-201-core-de-depósitos/` con esas mismas rutas relativas. Las citas de la ficha van relativas a la carpeta del proyecto y el índice parece resolverlas desde la raíz de `documentos/proyectos`. No lo he confirmado leyendo el script; es una hipótesis. Ninguna otra ficha tiene citas rotas.

### Formatos que no se pudieron leer
Este comando no lee documentos; no se intentó leer ninguno.

### Siguiente paso
Nada que releer ni proyecto que recalcular (`projects_to_recompute` vacío). No hay barrido que ofrecer.
