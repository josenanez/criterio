# Corrida del 2026-10-18 · portfolio-wake

13 proyectos · 29 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Barrido: 77 documentos sin cambios, nada que recalcular. Confirmación: 5 campos de PRY-201 preguntados, sin respuesta (sesión sin interfaz). 118 citas de PRY-201 marcadas sin resolver aunque los archivos existen; probable desajuste de ruta, no confirmado.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

## 2026-10-18

**Revisé:** 77 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18); no hubo que registrarlos de nuevo.

### Lo que cruzó un umbral
Nada. El barrido corrió y no había documentos nuevos, cambiados, renombrados ni borrados.

Una nota sobre las citas: `index` marca como "sin resolver" 118 citas de PRY-201 (acta de constitución, cronograma, informe de avance y actas de comité). Los archivos sí existen en `documentos/proyectos/PRY-201-core-de-depósitos/`. Parece un desajuste en cómo se escribe la ruta (la ficha del proyecto la cita sin el nombre de carpeta, el record con él), no documentos perdidos. No lo he confirmado; queda para revisar a mano.

### Peticiones atendidas
Ninguna pendiente.

### Preguntas
Nadie las puede responder en esta sesión de prueba; quedan registradas como preguntadas el 2026-10-18, sin respuesta. Cinco campos de PRY-201, elegidos por importancia:
1. `identity.authority`: no encontrado en ningún documento. ¿Quién tiene la autoridad de aprobación del proyecto?
2. `identity.phase`: no encontrado. ¿En qué fase está el proyecto?
3. `money.committed` (935.701.138 COP): viene de una declaración del informe de avance del 2026-10-16. ¿Hay un documento contable que lo sustente?
4. `money.executed`: declarado en el mismo informe y sin documento contable.
5. `money.projection`: declarada en el mismo informe y sin documento contable.

**Vuelvo el 2026-10-19.**
