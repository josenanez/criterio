# Corrida del 2026-10-18 · vendor-tracking

13 proyectos · 41 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Proveedor Redes del Norte (CT-812): factura FV-1812 de 614.970.173 COP frente a 534.681.656 aceptados (diferencia 80.288.517); bolsa de horas aceptada sin acta; licenciamiento pendiente 228 días. No supe: vigencia y preaviso del contrato, desglose de la factura, reuniones con el proveedor.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

**Sale de:** los 6 documentos de PRY-202 en `documentos/proyectos/PRY-202-migración-a-la-nube/` (acta de constitución, contrato CT-812, cronograma v1, acta de recibo del 2026-08-20, factura FV-1812, informe de avance del 2026-10-11) y del cálculo de `portafolio.py compute` al 2026-10-18. No hay reuniones, ni actas de comité, ni ficha de PM en la carpeta de este proyecto.

## Proveedores — PRY-202 Migración a la nube al 2026-10-18

### Redes del Norte Ltda. — contrato CT-812
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-12-07) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-03-04 · 267.340.828 COP | `pending`, con 228 días de atraso | Ninguna. El contrato mismo lo marca "pendiente" | La factura FV-1812 cobra "Entregables del contrato CT-812" y no los desglosa, así que no se puede decir si lo incluye |
| Bolsa de horas de desarrollo | 2026-05-21 · 267.340.828 COP | `accepted` en el cálculo, **sin documento que lo pruebe** | Solo la columna "Estado: recibido" del contrato, que es una declaración. No hay acta de recibo | Ídem |
| Parametrización del tarifario | 2026-08-07 · 267.340.828 COP | Aceptado | Acta de recibo del 2026-08-20, firmada por Javier Hoyos (`20-seguimiento/2026-08-20-acta-recibo-ct-812-parametrización-del-tarifario.pdf`) | Ídem |

Factura FV-1812, 2026-10-01: **614.970.173 COP**, radicada en cuentas por pagar (`20-seguimiento/2026-10-01-factura-ct-812.pdf`).

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Monto facturado frente a lo aceptado | Cada entregable vale 267.340.828 COP y se factura "contra acta de recibo firmada por el gerente del proyecto" | Facturado 614.970.173 COP frente a 534.681.656 COP aceptados: **80.288.517 COP de diferencia** (señal `vendor_invoiced_over_accepted`, montos declarados 3 de 3) | Contrato CT-812; factura FV-1812 |
| Base de lo "aceptado" | Marca dos entregables como "recibido" | Solo uno tiene acta de recibo. Los 534.681.656 COP que usa el cálculo incluyen la bolsa de horas, que no tiene acta; la diferencia real contra lo probado por documento es mayor. El script no la calcula y no la escribo | Contrato CT-812; acta de recibo del 2026-08-20 |
| Condición de pago | Acta de recibo firmada | De tres entregables hay un acta; la factura es por un monto que no corresponde a un solo entregable | Contrato CT-812; factura FV-1812 |
| Avance declarado frente al plan | — | El informe declara 51 % de avance y estado amarillo; el cronograma tiene 5 de 5 hitos marcados como cumplidos (el plan sostendría 100 %). Brecha de 49 puntos. Ningún hito tiene documento de evidencia (`milestone_met_without_evidence`: Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core, Piloto con usuarios internos, Salida a producción) | Informe de avance del 2026-10-11; cronograma v1 |
| Cierre del proyecto | Cierre comprometido el 2026-09-25 (acta de constitución) | Hace 23 días que pasó la fecha; el licenciamiento del motor sigue pendiente, y el informe de avance no lo menciona ni como riesgo | Acta de constitución; contrato CT-812; informe de avance |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Bolsa de horas de desarrollo | Recibido (contrato) / `accepted` | Comprometido para 2026-05-21; sin acta |
| Licenciamiento del motor | Pendiente, vencido sin declarar entrega | 2026-03-04 (228 días) |

### Compromisos del proveedor vencidos
Ninguno detectado. Eso no es lo mismo que "ninguno hay": la carpeta de PRY-202 no tiene reuniones (`30-reuniones` no existe), así que lo que el proveedor haya prometido en comité no se pudo revisar.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso del contrato CT-812: el contrato no los trae. No puedo decir si hay un preaviso por vencer.
- Desglose de la factura FV-1812: no dice qué entregables cobra.
- Acta de recibo de la bolsa de horas de desarrollo. Hay que pedirla o confirmar que no existe.
- Reuniones con el proveedor.
- Ficha del proyecto: faltan producto, autoridad y fase (`identity.product`, `identity.authority`, `identity.phase`); el acta de constitución dice "No aplica" en producto.

## Después
Hay una factura de 614.970.173 COP radicada, con una diferencia de 80.288.517 COP sobre lo aceptado según el cálculo, y con un entregable sin acta y otro vencido hace 228 días. Antes del pago conviene llevarlo a comité (el siguiente es el 2026-10-25) con dos preguntas: quién tiene el acta de la bolsa de horas, y a qué entregables corresponde exactamente FV-1812. Sugiero llevarlo; no lo he hecho.

## Pie de rigor
- Documentos leídos: los 6 indicados arriba. Cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-18); ninguna calculada a mano.
- El informe de avance y el contrato son declaraciones del proyecto o del acuerdo; solo el acta de recibo del 2026-08-20 y la factura son documentos de hecho. Fuentes con evidencia en la ficha: 0.
- No sé lo que se habló fuera de estos documentos. Puede haber un acta o un correo que no está en la carpeta.
- Es un borrador de trabajo: la verificación es suya.
