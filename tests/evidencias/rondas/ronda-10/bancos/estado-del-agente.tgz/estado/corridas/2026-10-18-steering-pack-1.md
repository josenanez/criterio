# Corrida del 2026-10-18 · steering-pack

13 proyectos · 92 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

Paquete de comité: 6 decisiones (autoridad, PRY-210, PRY-204, PRY-208, PRY-209, PRY-202) y 5 escalamientos. No sabe: quién tiene autoridad (13/13 sin registrar), qué decidió el comité anterior (sin registro), si el CC-01 de PRY-204 tiene acta, ni las diferencias de costo no calculadas por el script.

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** 13 (PRY-199 a PRY-211), corte del 2026-10-18 (`compute` con fecha de corrida 2026-10-18). Términos vigentes: versión 1.1, aceptada el 2026-10-18 por José Francisco Ñáñez para la familia 0.5.0; el comprobante ya existía, así que no se registró uno nuevo.

# Comité de proyectos — 2026-10-25 (material preparado el 2026-10-18)
6 decisiones · 5 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (67 señales abiertas)

## Decisiones del comité anterior
No hay decisiones del comité anterior registradas en las fichas ni en el estado. No se puede decir qué se decidió, qué se hizo ni qué sigue abierto. Una excepción declarada en los documentos: tres solicitudes de cambio (PRY-204 CC-01, PRY-207 CC-01, PRY-211 CC-01) figuran «aprobadas por el comité», pero no hay acta del comité en la carpeta que lo sustente (ver D3).

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base y presupuesto en cada proyecto, y a qué comité se le asigna?
**Proyecto:** los 13 · **Quién decide:** el patrocinador ejecutivo de la PMO (no hay otro que lo pueda fijar: la autoridad no está registrada en ningún proyecto) · **Si no se decide hoy:** los puntos 2 a 6 se discuten sin que conste que quien los resuelva tenga la facultad, y se repite lo de PRY-210 (línea base movida sin aprobador).

Hecho: `identity.authority` no se encontró en 13 de 13 proyectos. Las fichas sí nombran un comité por proyecto (Transformación Digital, Riesgos, Arquitectura, Banca Empresas, Medios de Pago), pero eso no dice hasta qué monto o días puede aprobar cada uno.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar una matriz de autoridad (monto y días) por comité y registrarla en cada acta de constitución | Sin cambio | Quedan definidos antes de decidir los puntos 2 a 6 | Sin costo directo calculable con los datos |
| B. Que el comité de hoy decida los puntos 2 a 6 y la matriz se defina después | Sin cambio | Se decide ya, con el riesgo de revisar después | No calculable |

**Recomendación:** A, aprobada al inicio de la sesión. Es juicio de este material, no una cifra: sin ella no se sabe a quién se le devuelve cada punto.

### [2] PRY-210 Portal de proveedores — ¿Se aprueba CC-01 (ampliación de alcance) o se restituye la línea base original?
**Proyecto:** PRY-210 · **Quién decide:** sin facultad registrada; la ficha da el Comité de Medios de Pago. Ojo: el gerente y el patrocinador de la ficha son la misma persona (Ricardo Salas), así que el aprobador no puede ser quien pide el cambio. · **Si no se decide hoy:** la línea base ya movida 102 días sin autorización queda como la vigente, y la desviación contra la original (102 días, 21.2%) deja de verse.

Hechos: CC-01 pedida el 2026-10-07, estado «pendiente», sin decisor. Declara +102 días y 204.000.000 COP adicionales. El script cuenta 102 días de línea base movida y 0 autorizados (`rebaseline_unauthorized`). Proyección de costo 3.896.316.249 COP contra 3.300.000.000 aprobados (+18.1%). Hito «Piloto con usuarios internos» vencido hace 8 días (fecha 2026-10-10). Dos entregables del proveedor Integra Sistemas Ltda. vencidos y pendientes (181 y 75 días). Estado declarado: rojo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 tal como viene | Ampliado | +102 días (fin vigente 2027-04-26) | +204.000.000 COP declarados; la proyección ya está +18.1% sobre lo aprobado, y no consta si la incluye |
| B. Rechazar y restituir la línea base original | Sin ampliación | Atraso de 102 días queda visible contra la original | Sin los 204.000.000 COP; la proyección de +18.1% sigue ahí |
| C. Aprobar solo con replan que muestre evidencia de los hitos y plan para los dos entregables vencidos | Ampliado, condicionado | A definir en el replan; no calculable hoy | A definir; no calculable hoy |

**Recomendación:** C. Aprobar hoy sin replan sería firmar 102 días y 204.000.000 COP sobre un proyecto con dos hitos declarados cumplidos sin evidencia y dos entregables del proveedor vencidos. Es una recomendación de criterio.

### [3] PRY-204 Débito contactless — ¿Se confirma CC-01 y se mueve la línea base, o se revisa la aprobación?
**Proyecto:** PRY-204 · **Quién decide:** sin facultad registrada; la ficha da el Comité de Banca Empresas · **Si no se decide hoy:** el cambio queda «aprobado» sin línea base nueva; el atraso de 117 días no se mide contra nada, y el proyecto se sigue reportando en verde.

Hechos: CC-01 pedida el 2026-10-17, ampliación de alcance, +117 días y 234.000.000 COP, marcada «aprobada por el comité». La línea base no se movió (0 días movidos contra 117 aprobados). Proyección 2.650.534.633 COP contra 2.400.000.000 aprobados (+10.4%, sobre el umbral de 10%); comprometido 85.6% del aprobado. Declarado verde el 2026-10-13, contradicho por la señal de costo. No hay acta del comité que respalde la aprobación.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 en acta y registrar la línea base nueva (la anterior se conserva) | Ampliado | +117 días registrados | +234.000.000 COP declarados; proyección ya en +10.4% |
| B. Revisar la aprobación: sin acta no hay cambio vigente | Sin ampliación hasta ratificar | Sin movimiento de línea base | Sin los 234.000.000 COP por ahora |

**Recomendación:** A, si el comité confirma que aprobó; solo así el cambio queda con línea base y el verde deja de ser contradictorio. Si nadie puede confirmarlo, B.

### [4] PRY-208 Motor de decisión — ¿Se autoriza más presupuesto o se recorta alcance?
**Proyecto:** PRY-208 · **Quién decide:** sin facultad registrada; la ficha da el Comité de Transformación Digital · **Si no se decide hoy:** la proyección (+20.8%) sigue creciendo sin un tope aprobado, con un proyecto que ya pasó su fecha de fin.

Hechos: proyección 5.073.552.071 COP contra 4.200.000.000 aprobados (+20.8%). Ejecutado 1.741.882.527 COP (41.5%), mayor que lo comprometido registrado (1.608.878.183 COP, 38.3%). Avance declarado 40%, mientras los 4 hitos figuran cumplidos (el plan sustentaría 100%) y tres de ellos sin evidencia. Fin vigente 2026-07-10. Rojo declarado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto hasta la proyección | Completo | Requiere nueva fecha de fin; no calculable con los datos | Hasta 5.073.552.071 COP |
| B. Mantener el aprobado y recortar alcance | Reducido (a definir) | A definir | 4.200.000.000 COP |
| C. Congelar hasta que el gerente reconcilie hitos y avance con evidencia | Sin cambio | Se detiene | Sin gasto nuevo mientras se congela; el gasto ya ejecutado no cambia |

**Recomendación:** C como paso previo a A o B: hoy no se sabe cuánto trabajo falta (avance 40% contra 4 de 4 hitos), y cualquier monto sería una cifra sin sustento.

### [5] PRY-209 Nómina electrónica — ¿Se autoriza más presupuesto o se recorta alcance?
**Proyecto:** PRY-209 · **Quién decide:** sin facultad registrada; la ficha da el Comité de Arquitectura · **Si no se decide hoy:** igual que PRY-208: proyección +20.3% sin tope y sin fecha de fin vigente (2026-07-21, ya pasada).

Hechos: proyección 5.052.016.044 COP contra 4.200.000.000 aprobados (+20.3%). Ejecutado 2.347.857.763 COP (55.9%). Avance declarado 37% con 4 de 4 hitos cumplidos (el plan sustentaría 100%), tres sin evidencia. Rojo declarado el 2026-10-18.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto hasta la proyección | Completo | Nueva fecha; no calculable | Hasta 5.052.016.044 COP |
| B. Mantener el aprobado y recortar alcance | Reducido (a definir) | A definir | 4.200.000.000 COP |
| C. Congelar hasta reconciliar hitos y avance con evidencia | Sin cambio | Se detiene | Sin gasto nuevo mientras se congela |

**Recomendación:** C, por la misma razón que PRY-208. Este material no distingue cuál de las dos es la causa: planes optimistas o avance mal declarado.

### [6] PRY-202 Migración a la nube — ¿Se retienen pagos a Redes del Norte hasta que haya evidencia de aceptación?
**Proyecto:** PRY-202 (contrato CT-812) · **Quién decide:** sin facultad registrada; la ficha da el Comité de Arquitectura · **Si no se decide hoy:** la facturación por encima de lo aceptado sigue abierta y el entregable de licenciamiento (228 días vencido) no tiene fecha ni consecuencia.

Hechos: facturado 614.970.173 COP contra 534.681.656 aceptados: diferencia 80.288.517 COP (`vendor_invoiced_over_accepted`). «Licenciamiento del motor» pendiente, vencido hace 228 días (fecha 2026-03-04). «Bolsa de horas de desarrollo» figura aceptada sin evidencia. Los 5 hitos figuran cumplidos sin evidencia (fin 2026-09-25) y el avance declarado es 51% (el plan sustentaría 100%). Amarillo declarado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener pagos nuevos y pedir al proveedor la evidencia de aceptación y la fecha del licenciamiento | Sin cambio | El licenciamiento sigue pendiente hasta que el proveedor responda | 80.288.517 COP facturados por encima de lo aceptado quedan en discusión |
| B. Regularizar: aceptar formalmente lo facturado | Sin cambio | Cierra la diferencia | Reconoce los 80.288.517 COP sin evidencia |

**Recomendación:** A. Con la evidencia que hay, B reconocería un pago que ningún documento sustenta.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200 Originación digital | Verde declarado el 2026-09-29, contradicho por 3 señales: silencio de 19 días, hito «Integración con el core» vencido hace 4 días (2026-10-14) y 2 hitos cumplidos sin evidencia | Sin informe desde 2026-09-29 | Que el gerente (Laura Vélez) responda con estado y evidencia antes del comité |
| PRY-201 Core de depósitos | 8 compromisos vencidos (3 a 15 días); 3 reprogramados (6, 5 y 3 veces: Diana Molina 6, Andrés Lozano 5, Natalia Ospina 3); 2 sin fecha; avance declarado 70% contra un plan que sustenta 25–50% | Reprogramaciones desde 2026-09-14 | Fechas firmes y un doliente por cada compromiso reprogramado más de 3 veces |
| PRY-205 Prevención de lavado de activos | Fin vigente 2026-10-21; avance declarado 59% contra un plan que sustenta 75–100%; declaración de 24 días de antigüedad; 2 hitos cumplidos sin evidencia | Declaración del 2026-09-24 | Estado actualizado y decisión de replan antes del 2026-10-21 |
| PRY-206 Billetera y QR | Verde declarado el 2026-10-02 (16 días), contradicho por un compromiso vencido (Elena Duarte, 9 días) y 2 hitos cumplidos sin evidencia | 2026-10-09 | Entrega del compromiso o nueva fecha, y evidencia de los hitos |
| PRY-211 Cobranza digital | Verde declarado el 2026-10-11 con 64 días de desviación contra la original (31.2%), avance 61% contra un plan que sustenta 100%, y 3 hitos sin evidencia. El cambio que movió la línea base figura aprobado | Desviación desde el cambio aprobado | Que el gerente reconcilie avance y hitos, y que el estado deje de ser verde si no hay evidencia |

## Para conocimiento
- PRY-199 Renovación de cajeros automáticos: sin señales abiertas; sin evidencia directa (0 documentos de evidencia, 6 declaraciones).
- PRY-203 Open Banking: sin señales abiertas; fin vigente 2026-08-10 ya pasado y avance declarado 40%; la fecha no está marcada como señal.
- PRY-207 Onboarding PyME: rojo declarado; 88 días de desviación contra la original (40.0%) con la línea base movida 88 días y cambio aprobado; avance 47% contra un plan que sustenta 100%; fin vigente 2026-10-28.

## Anexo
**Estado por proyecto (declarado → lo que sustentan los documentos).** Declarado verde: 6 proyectos (PRY-199, 200, 203, 204, 206, 211), de los cuales 4 están contradichos por señales (200, 204, 206, 211). Amarillo: 201, 202, 205. Rojo: 207, 208, 209, 210.

**Contradicciones abiertas.** Las listadas arriba. Además: en PRY-201 el avance declarado (70%) está por encima de lo que el plan sustenta (25–50%), es decir, adelantado, no atrasado.

**Vacíos de información.**
- `identity.authority` y `identity.phase` faltan en los 13 proyectos.
- `identity.product` falta en PRY-202, 205, 208 y 210.
- `vendors[0].invoiced` falta en PRY-199.
- Campos con 12 meses o más de antigüedad: PRY-200, 203, 204, 209 y 210 (acta de constitución sin actualizar).
- Ninguna ficha tiene fuentes marcadas como evidencia (0 de evidencia en los 13); todo es declaración o sin marcar.
- No hay supuestos ni dependencias registrados en ningún proyecto.
- No se midió el tiempo ni el costo de los cambios aprobados salvo el impacto declarado en cada solicitud.

**Riesgos dichos en reunión que nadie registró.** PRY-201: «el proveedor podría no llegar con el equipo completo para la siguiente fase» (notas del 2026-10-18).

---
*Pie: criterio-portfolio 0.5.0 · términos versión 1.1 · fichas aplicadas: 13 (PRY-199 a PRY-211, corte 2026-10-18) · campos inciertos: autoridad y fase (13/13), producto (4), antigüedad de 12 meses o más (5 proyectos) · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0*
