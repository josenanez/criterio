# Corrida del 2026-10-18 · portfolio-scan

13 proyectos · 77 documentos, 0 releídos y 77 sin cambio · 169 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

10 fichas nuevas escritas y selladas; 3 sin cambio (PRY-203, 209, 210). No hay entrada/; no se movió nada. Notas de reunión de PRY-201 sueltas en la raíz del proyecto. PRY-204 sin cronograma.

Contra la corrida del 2026-10-18: +53 hallazgos.

## Lo que produjo

## Barrido — 2026-10-18

**Términos:** vigentes (v1.1, familia 0.5.0), aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta registrarlos de nuevo.

**Documentos:** 77 en la carpeta · 60 leídos · 17 sin cambio desde la corrida anterior (PRY-203, PRY-209 y PRY-210) · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 200, 201, 202, 204, 205, 206, 207, 208, 211) · 0 sin carpeta propia
**Formatos:** 34 .md, 15 .pdf, 12 .docx, 7 .csv, 7 .xlsx, 1 .json, 1 .txt. Plan de un solo lote de 10 proyectos, ejecutado uno tras otro, sin subagentes. Nada diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros | 6 | identidad, 5 hitos, presupuesto, contrato CT-199 (3 entregables), 1 compromiso | autoridad, fase, facturado |
| PRY-200 Originación digital | 3 | identidad, 4 hitos, presupuesto, declarado | autoridad, fase |
| PRY-201 Core de depósitos | 16 | identidad, 4 hitos, presupuesto, 25 compromisos con historial, ficha del gerente (`pm_record`) | autoridad, fase |
| PRY-202 Migración a la nube | 6 | identidad, 5 hitos, presupuesto, contrato CT-812 y factura FV-1812 | producto («No aplica»), autoridad, fase |
| PRY-204 Débito contactless | 3 | identidad, presupuesto, declarado, solicitud CC-01 | cronograma (no existe), autoridad, fase |
| PRY-205 Prevención de lavado | 4 | identidad, 4 hitos, presupuesto, declarado | producto («No aplica»), autoridad, fase |
| PRY-206 Billetera y QR | 4 | identidad, 3 hitos, presupuesto, 1 compromiso | autoridad, fase |
| PRY-207 Onboarding PyME | 7 | identidad, 4 hitos (cronogramas v1 y v2), CC-01 | autoridad, fase |
| PRY-208 Motor de decisión | 5 | identidad, 4 hitos, presupuesto, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 6 | identidad, 4 hitos (v1 y v2), CC-01, 1 compromiso | autoridad, fase |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| — | Ninguno: PRY-203, PRY-209 y PRY-210 no tuvieron cambios y no se abrieron. | — |

### Lo que vi al leer (hechos citados; el cálculo lo hace el código, no yo)
- **Hitos cerrados sin acta que los pruebe:** PRY-200 (2), PRY-202 (5), PRY-205 (2), PRY-206 (2), PRY-207 (2), PRY-208 (3), PRY-211 (4). Se registraron como `met` con `evidence` vacío; no los dejé abiertos.
- **Actas de recibo que sí sustentan un hito:** PRY-199, 201, 205, 207 (dos), 208 — «Diseño funcional aprobado» en todas, más «Ambiente de pruebas» en PRY-207. Ojo: las actas de PRY-199, 201, 205, 207 y 208 son de octubre de 2026, mientras la fecha de línea base del hito es anterior (por ejemplo PRY-208: 2026-01-26 contra acta del 2026-10-06).
- **Contradicción de fechas en PRY-207 y PRY-211:** la fecha de cierre del acta (2026-08-01 y 2026-09-11) se movió a 2026-10-28 y 2026-11-14 en un cronograma v2, con CC-01 «autorizada por el comité» (+88 y +64 días); se registró línea base v2 sin tocar la v1. PRY-204 tiene CC-01 (+117 días, 234.000.000 COP) pero ningún cronograma: su cierre sigue siendo 2026-05-20, ya pasado, y declara verde con 33%.
- **PRY-202:** cierre comprometido 2026-09-25 ya vencido; declara amarillo y 51%, pero el cronograma tiene los 5 hitos como cerrados. Factura FV-1812 por 614.970.173 COP; solo hay acta de recibo de uno de los tres entregables del contrato CT-812 (267.340.828 cada uno). El contrato marca otro como «recibido» sin acta, y el tercero como pendiente.
- **PRY-208:** declara rojo; ejecutado (1.741.882.527) supera lo comprometido (1.608.878.183). Cierre comprometido 2026-07-10 ya vencido.
- **PRY-201 — compromisos:** 25 compromisos extraídos de 6 comités y de las notas del 2026-10-18. «Enviar el documento 1» (Diana Molina) lleva 6 reprogramaciones, de 2026-09-24 a 2026-12-03; «Cerrar la prueba 2» (Andrés Lozano), 5. Tres personas dicen haber entregado (Mauricio Pérez, Paula Céspedes, Javier Hoyos) sin acta. Marqué `overdue` los que vencieron sin acta.
- **PRY-201 — riesgo sin registrar:** las notas del 2026-10-18 dicen que el proveedor podría no llegar con el equipo completo; nadie lo anotó. Lo levanté en `raid.risks`.
- **PRY-201 — ficha del gerente:** `ficha-pm.json` se guardó entera en `pm_record`, sin mezclarla con mi lectura.
- **Compromisos fuera de PRY-201:** PRY-206 (Elena Duarte, punto 25, vencido 2026-10-09), PRY-208 (María Restrepo, punto 40, vencido 2026-10-05), PRY-199 (Carlos Peña, vence 2026-11-07), PRY-211 (Camilo Beltrán, vence 2026-10-22). Además, el comité de PRY-199 lista a Carlos Peña, quien no asistió a esa reunión.
- **Plazos sin fecha:** dos compromisos de PRY-201 quedaron `no_declarada` («por definir» y «la otra semana»).
- **Acta de PRY-199:** alcance y exclusiones son texto de plantilla («Componente 1…», «Lo que otro proyecto cubre») en todas las actas; los guardé tal cual.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 77 documentos se convirtieron a texto. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | No hay carpeta `entrada/` en la documentación; no moví nada. | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-201-core-de-depósitos/2026-10-18-notas-reunion.txt` | No es pendiente de proyecto (nombra PRY-201), pero está suelto en la raíz de la carpeta y no en `30-reuniones/`. Lo leí donde está y no lo moví; propongo moverlo. |

### Cierre
Versión del plugin 0.5.0 · 10 fichas escritas y selladas, 3 sin tocar · campos en `not_found`: `authority` y `phase` en las 10 fichas, `product` en PRY-202, 205 y 208, y los datos de dinero de ninguna. PRY-204 sin cronograma. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.5.0

**Siguiente paso:** hay más de un proyecto, así que puedo generar el informe consolidado con `/criterio-portfolio:portfolio-report`.
