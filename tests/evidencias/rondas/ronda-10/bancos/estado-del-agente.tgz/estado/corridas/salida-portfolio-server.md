# Rostrum — para mirarlo un rato

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18; comprobante en `.criterio/terminos/`). No hizo falta registrarlos de nuevo.

Modo elegido: **para mirarlo un rato** (respuesta sugerida; la persona no indicó otra cosa, y es por donde se empieza).

Informe encontrado en `reportes/` (13 proyectos, 8 productos, decisiones, listado). Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado, `--puerto 8788`. Se para con Ctrl-C. El portal lleva «Banco Ejemplo» en todas las páginas.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio, mirando todo junto | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda nada.

Enlace: `http://127.0.0.1:8787/` solo sirve en este equipo; no se le pasa a nadie. Para que el patrocinador tenga un enlace estable, hay que pasar a «que quede corriendo» (host, puerto y control de acceso de la organización). El informe es del 2026-10-18; se desactualiza al siguiente barrido o cuando cambie algún documento.
