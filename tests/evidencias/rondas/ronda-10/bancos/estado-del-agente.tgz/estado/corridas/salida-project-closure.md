Fuente: ficha `estado/records/PRY-202.json` y documentos de `PRY-202-migración-a-la-nube` (acta de constitución 2025-12-06, contrato CT-812, cronograma v1, acta de recibo 2026-08-20, factura 2026-10-01, informe de avance 2026-10-11). Cifras de `portafolio.py compute` (corte 2026-10-18). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-18.

## Cierre — PRY-202 Migración a la nube — 2026-10-18

**Lectura corta:** nadie ha declarado el cierre de este proyecto en los documentos, y lo que sí hay no sostiene que esté terminado. El informe del 2026-10-11 lo reporta en amarillo con 51 % de avance, cuando el cronograma ya vencía en su totalidad el 2026-09-25. Este documento es un cierre *preliminar*: dice qué se puede y qué no se puede cerrar hoy. No es un acta de cierre firmable.

### Contra lo comprometido
**Criterio de éxito:** "Migración a la nube en producción y medido." (acta de constitución, 2025-12-06). No define qué se mide, con qué umbral ni quién lo mide.
**Se cumplió:** no se puede determinar. Ningún documento muestra la migración en producción ni una medición. El único hito de producción, "Salida a producción" (2026-09-25), figura como cumplido sin evidencia, y el mismo informe de avance reporta 51 %.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Alcance: Componente 1, 2 y 3 | Sin desglose; el acta no dice qué es cada componente | Ninguna |
| Diseño funcional aprobado (2026-02-10) | Declarado cumplido | Sin evidencia (250 días) |
| Ambiente de pruebas certificado (2026-04-08) | Declarado cumplido | Sin evidencia (193 días) |
| Integración con el core (2026-06-04) | Declarado cumplido | Sin evidencia (136 días) |
| Piloto con usuarios internos (2026-07-30) | Declarado cumplido | Sin evidencia (80 días) |
| Salida a producción (2026-09-25) | Declarado cumplido | Sin evidencia (23 días) |
| CT-812 Licenciamiento del motor (vence 2026-03-04) | Pendiente, 228 días de atraso | Ninguna |
| CT-812 Bolsa de horas de desarrollo (2026-05-21) | Aceptado | Sin acta de recibo |
| CT-812 Parametrización del tarifario (2026-08-07) | Aceptado | Acta de recibo 2026-08-20 |

Los cinco hitos aparecen "cumplidos" en la ficha, pero ninguno tiene evidencia y el avance declarado (51 %) contradice esa lectura: el plan soportaría 100 %, y la brecha es de 49 puntos.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta; no nombra el proyecto) | Acta de constitución | 2025-12-06 |

No hay solicitudes de cambio registradas (0). Tampoco hay recorte de alcance documentado, pero con el alcance descrito como "Componente 1, 2, 3" no se puede comprobar si se entregó todo ni si se recortó algo.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-25 | 2026-09-25 | Sin dato (no hay cierre real) | 0 días registrados; no es una medición del cierre real, porque el proyecto sigue sin terminar según el avance declarado |
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | Ejecutado 1.587.108.579 COP (48,1 %); comprometido 1.661.270.154 COP (50,3 %) | Proyección 3.241.959.414 COP, −1,8 % |

Replanificaciones: 0. La línea base tiene una sola versión (2025-12-06). Los 0 días de desviación en fecha significan que nadie ha movido el plan, no que el proyecto haya cumplido: la fecha de cierre pasó hace 23 días. Disponible real: 1.638.729.846 COP. Las cifras de dinero son declaradas en el informe de avance, no verificadas contra contabilidad.

### RAID al cierre
**Materializados:** el equipo perdió dos semanas por rotación de un desarrollador clave (informe 2026-10-11), sin fecha precisa del hecho. Es el riesgo de dependencia de una persona, ya materializado en parte.
**No materializados:** sin dato. El riesgo de "concentración del conocimiento en una sola persona" figura abierto, no cerrado.
**Abiertos, con doliente:**
- Concentración del conocimiento en una sola persona. El informe no nombra doliente. El gerente es Javier Hoyos, pero eso no equivale a un doliente asignado del riesgo.
- Licenciamiento del motor (CT-812), pendiente, 228 días vencido. Sin doliente nombrado.
- Facturado por encima de lo aceptado: Redes del Norte Ltda. facturó 614.970.173 COP el 2026-10-01 y lo aceptado suma 534.681.656 COP. Diferencia: 80.288.517 COP. Sin doliente nombrado.
- Bolsa de horas aceptada sin acta de recibo. Sin doliente nombrado.

Lo abierto sin doliente no está cerrado. El cierre no puede declararse hasta que alguien con nombre asuma cada punto.

### Lecciones
Solo entran las que se pueden anclar a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El licenciamiento del motor (CT-812) tenía fecha 2026-03-04 y sigue pendiente | 2026-03-04 a 2026-10-18 | 228 días de atraso en el entregable que el resto del contrato necesita | Sin dato sobre la causa; ningún documento la explica. Se puede decir que un entregable vencido 228 días con otros dos "aceptados" detrás no debió pasar sin escalar |
| Se facturó más de lo aceptado | 2026-10-01 | 80.288.517 COP facturados sin aceptación que los respalde | Condicionar cada pago a un acta de recibo del entregable |
| Cinco hitos marcados "cumplidos" sin evidencia, y el avance declarado en 51 % | 2026-02-10 a 2026-09-25 | La fecha de cierre pasó sin que nadie lo notara; el estado "amarillo" no refleja un plan vencido | Un hito se marca cumplido solo con el documento que lo prueba |
| Rotación de un desarrollador clave | Sin fecha precisa; informe de 2026-10-11 | Dos semanas perdidas | Sin dato sobre fecha ni sobre efecto en un hito |

No se incluyen lecciones sobre comunicación, gobierno o dimensionamiento: no hay hecho documentado que las sustente.

### Sin dato
- Si la migración está en producción, y cualquier medición del criterio de éxito.
- Qué son los Componentes 1, 2 y 3, y por tanto si el alcance se entregó.
- Evidencia de los cinco hitos y del acta de recibo de la bolsa de horas.
- Qué proyecto cubre lo "fuera de alcance".
- Fecha real de cierre, y gasto real verificado contra contabilidad.
- Doliente de cada punto abierto; producto asociado y fase (la ficha los marca no encontrados).
- Causa del atraso del licenciamiento.

### Después
Ofrezco mover la carpeta a `archivo/` y congelar la ficha, pero **no lo hago**: el cierre no está declarado y quedan puntos abiertos sin doliente. Archivar sacaría el proyecto del barrido diario justo cuando tiene cuatro señales sin explicar. Sugiero que el comité decida si cierra el proyecto *por decisión*, no por cumplimiento, o si se replanifica.
