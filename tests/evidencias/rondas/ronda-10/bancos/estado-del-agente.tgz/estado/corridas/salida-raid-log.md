**Sale de:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211, RAID tomado de los informes de avance); las 6 minutas del comité de PRY-201 y las notas de reunión del 2026-10-18; las minutas de PRY-206, PRY-209 y PRY-211 (.md) y de PRY-199, PRY-208 y PRY-210 (.docx); las 4 solicitudes de cambio CC-01 (PRY-204, 207, 210, 211); los informes de avance en .md de PRY-202 y PRY-210; y las secciones «Dependencias declaradas» de las actas de constitución legibles como texto. **No releí** los informes en PDF ni los cronogramas: de ellos uso solo lo que la ficha ya cita. PRY-200, 202, 203, 204, 205, 207 no tienen ninguna minuta en la carpeta.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-18). No hizo falta registrarlos de nuevo.

## RAID — portafolio (13 proyectos) al 2026-10-18
10 riesgos · 0 supuestos · 16 incidencias · 9 dependencias (después de reclasificar; en las fichas hay 19 riesgos, 16 incidencias y 0 dependencias)
35 sin doliente · 35 sin fecha · sin movimiento: no se puede medir · 1 no registrado formalmente

Ningún ítem de ninguna ficha trae doliente, fecha, probabilidad, impacto ni mitigación: solo el texto y el informe donde se leyó. Por eso **no califiqué probabilidad ni impacto** y no apliqué el criterio de escalamiento por puntaje; lo que sigue sube por otras razones, dichas en cada fila.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-201/b (provisional) | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-18 | Dicho en reunión y sin registrar. Decisión: ¿se formaliza? El compromiso de «revisión con el proveedor» (Óscar Ramírez) es para el 2026-10-28, así que hay fecha para llegar con una respuesta |
| Core (4 proyectos) | Dependencia | «Dependencia del calendario de liberaciones del core» en PRY-201, 205, 206 y 210, hoy registrada como riesgo | sin doliente | 2026-09-24 (la más antigua) | Cuatro proyectos dependen del mismo calendario y ninguna acta lo declara (todas dicen «Ninguna declarada»). Decisión: nombrar de qué proyecto o equipo depende cada uno y quién es el doliente. Los informes dicen «el core», no un código |
| PRY-210 | Incidencia + dependencia | Estado declarado Rojo; dos historias fuera del sprint por dependencia con el core; solicitud CC-01 (+102 días, 204.000.000 COP) «pendiente de presentación al comité» | sin doliente | 2026-10-07 (CC-01) | Es el único proyecto en rojo con una dependencia del core y un cambio de alcance sin presentar. Decisión: llevar CC-01 al comité con la dependencia a la vista |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-201, notas de reunión | 2026-10-18 |

Es el único. Leí todas las minutas disponibles y ninguna otra trae un riesgo dicho al pasar. Las afirmaciones del comité del 2026-10-11 de PRY-201 («ya entregó… no se presentó acta», tres veces) son compromisos sin evidencia, no riesgos: son de `/pm-commitments`, no las metí aquí. Tampoco el «por definir» de «Validar el ambiente 12» ni la fecha ambigua «03/12/2026» de las notas (3 de diciembre o 12 de marzo).

### Sin doliente o sin fecha
Los 35 ítems. Falta doliente y fecha en todos; no los rellené ni propongo nombre aquí. El detalle está en el registro completo. Faltan además, en los 10 riesgos y 9 dependencias: probabilidad, impacto y mitigación.

### Reclasificaciones (con el porqué)
| Ítem | Estaba como | Pasa a | Por qué |
|---|---|---|---|
| Dependencia del calendario de liberaciones del core (PRY-201, 205, 206, 210) | Riesgo | Dependencia | Depende de alguien fuera del proyecto, y ya ocurre, no es una posibilidad |
| El proveedor no ha confirmado la fecha de la última entrega (PRY-204, 207) | Riesgo | Dependencia | Depende del proveedor, que es externo |
| Disponibilidad del equipo de seguridad para la revisión final (PRY-199, 204, 211) | Riesgo | Dependencia | Depende de un equipo fuera del proyecto. Es propuesta: si el equipo de seguridad está dentro, vuelve a riesgo |
| Se ajustó el plan de pruebas con el área de seguridad (PRY-201, 205) | Incidencia | A revisar | Describe un ajuste, no un problema ocurrido. Si cambió fechas o alcance es un cambio; si no, no es RAID |
| Se recibió la aprobación regulatoria pendiente (PRY-204) | Incidencia | Cerrada | Ya se resolvió; no queda nada abierto |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| Core (PRY-201, 205, 206, 210) | «El core» (sin código de proyecto) | No | No puedo cruzar contra la fecha de otro proyecto porque nadie dice cuál. Si fuera PRY-201 (Core de depósitos): su línea base es única (v1, cierre 2027-06-21), sin replanificar, pero en el comité semanal el compromiso «Enviar el documento 1» (Diana Molina) pasó de 2026-09-24 a 2026-11-19 en seis reuniones. Es una inferencia mía; no está en ningún documento |
| Proveedor sin fecha de última entrega (PRY-204, 207) | Proveedor (sin nombre en la ficha) | No | PRY-207 ya tiene dos líneas base (cierre 2026-08-01 → 2026-10-28) y CC-01 autorizada (+88 días). PRY-204 tiene CC-01 autorizada (+117 días) y una sola línea base con cierre 2026-05-20 |
| Equipo de seguridad (PRY-199, 204, 211) | Área de seguridad | No | Sin información de su calendario |

### Registro completo
Los ids son provisionales (ninguna ficha trae id de RAID). «Último movimiento» es la fecha del único informe donde aparece: no hay historial que permita decir si algo se movió.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199/r1 | Dependencia (propuesta) | Disponibilidad del equipo de seguridad para la revisión final | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-16 |
| PRY-199/i1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | no registrado | sin doliente | sin fecha | visto 2026-10-16 |
| PRY-200/r1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-09-29 |
| PRY-200/i1 | Incidencia | Se reprogramó la salida por ventana de cambio de operaciones | — | no registrado | sin doliente | sin fecha | visto 2026-09-29 |
| PRY-201/r1 | Dependencia | Calendario de liberaciones del core | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-16 |
| PRY-201/b | Riesgo (no formal) | Proveedor podría no llegar con el equipo completo | no registrada | no registrado | sin doliente | sin fecha | dicho 2026-10-18 |
| PRY-201/i1 | Incidencia (a revisar) | Se ajustó el plan de pruebas con seguridad | — | no registrado | sin doliente | sin fecha | visto 2026-10-16 |
| PRY-202/r1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-11 |
| PRY-202/i1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no registrado | sin doliente | sin fecha | visto 2026-10-11 |
| PRY-203/r1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-18 |
| PRY-203/r2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-18 |
| PRY-203/i1 | Incidencia | La prueba de carga no alcanzó el umbral y se repite | — | no registrado | sin doliente | sin fecha | visto 2026-10-18 |
| PRY-204/r1 | Dependencia | Proveedor sin confirmar fecha de la última entrega | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-13 |
| PRY-204/r2 | Dependencia (propuesta) | Disponibilidad del equipo de seguridad | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-13 |
| PRY-204/i1 | Incidencia (cerrada) | Se recibió la aprobación regulatoria pendiente | — | — | sin doliente | sin fecha | visto 2026-10-13 |
| PRY-204/i2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no registrado | sin doliente | sin fecha | visto 2026-10-13 |
| PRY-204/i3 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | no registrado | sin doliente | sin fecha | visto 2026-10-13 |
| PRY-205/r1 | Dependencia | Calendario de liberaciones del core | no registrada | no registrado | sin doliente | sin fecha | visto 2026-09-24 |
| PRY-205/i1 | Incidencia (a revisar) | Se ajustó el plan de pruebas con seguridad | — | no registrado | sin doliente | sin fecha | visto 2026-09-24 |
| PRY-205/i2 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | no registrado | sin doliente | sin fecha | visto 2026-09-24 |
| PRY-206/r1 | Dependencia | Calendario de liberaciones del core | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-02 |
| PRY-206/i1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | no registrado | sin doliente | sin fecha | visto 2026-10-02 |
| PRY-207/r1 | Dependencia | Proveedor sin confirmar fecha de la última entrega | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-14 |
| PRY-207/r2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-14 |
| PRY-207/i1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | no registrado | sin doliente | sin fecha | visto 2026-10-14 |
| PRY-208/r1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-15 |
| PRY-208/i1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | — | no registrado | sin doliente | sin fecha | visto 2026-10-15 |
| PRY-208/i2 | Incidencia | Se reprogramó la salida por ventana de cambio de operaciones | — | no registrado | sin doliente | sin fecha | visto 2026-10-15 |
| PRY-209/r1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-18 |
| PRY-210/r1 | Dependencia | Calendario de liberaciones del core | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-17 |
| PRY-210/r2 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-17 |
| PRY-210/i1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | no registrado | sin doliente | sin fecha | visto 2026-10-17 |
| PRY-211/r1 | Riesgo | Concentración del conocimiento en una sola persona | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-11 |
| PRY-211/r2 | Dependencia (propuesta) | Disponibilidad del equipo de seguridad | no registrada | no registrado | sin doliente | sin fecha | visto 2026-10-11 |
| PRY-211/i1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | no registrado | sin doliente | sin fecha | visto 2026-10-11 |

### Lo que no sé
- **Movimiento:** cada ítem tiene una sola observación; no hay historial, así que no puedo decir cuáles llevan dos períodos sin moverse ni cuáles tienen mitigación vencida.
- **Supuestos:** ninguno en las fichas ni en los documentos leídos. No inventé ninguno.
- **Incidencias que los informes citan y la ficha no trajo:** en PRY-210 el informe del 2026-10-17 también menciona «dos historias fuera del sprint» y la aprobación regulatoria recibida, y la ficha solo guarda el hallazgo de seguridad; en PRY-202 el informe menciona el ajuste del plan de pruebas y la ficha solo guarda la rotación. La ficha de esos dos proyectos no recoge todas las líneas del informe; las incluí en esta tabla solo si la ficha las trae. Conviene releer los informes en PDF de los demás para comprobar si les pasa lo mismo.
- **Cuál es «el core»:** no hay código de proyecto en ningún documento.

## Después
Puedo subir a comité los tres ítems de «Necesitan decisión ahora». No asigné doliente a nadie. Para proponer uno haría falta que me digas quién gerencia cada proyecto en cada caso; las fichas traen el gerente, pero el doliente de un riesgo es otra decisión.

**Pie de rigor:** borrador de trabajo hecho a partir de los documentos citados; no sé lo que se habló fuera de ellos. Verifica cada cita antes de actuar. Lo que no pude medir está en «Lo que no sé».
