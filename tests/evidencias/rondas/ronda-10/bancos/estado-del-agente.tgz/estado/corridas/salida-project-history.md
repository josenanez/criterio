## Historia · PRY-210 Portal de proveedores · 2025-09-11 a 2026-10-18

**Leí:** 10 documentos entre 2025-09-11 y 2026-10-18 (los .docx, .xlsx y .pdf, en su texto convertido; la cita apunta al original)
**Trimestres sin un solo documento:** 2025-T4 (oct–dic 2025) y 2026-T2 (abr–jun 2026)

Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-18; no hizo falta registrarlos de nuevo.

### En una línea
El proyecto se aprobó el 2025-09-11 con cierre el 2027-01-14 y 3.300.000.000 COP. Después hay cuatro meses sin documentos (2025-T4), un acta de recibo (2026-01-15), otro hueco de un trimestre (2026-T2) y una concentración de documentos entre el 2026-09-30 y el 2026-10-18. En esas tres semanas se pidió una ampliación de alcance de 102 días (CC-01, 2026-10-07), se publicó un cronograma v2 que ya mueve la salida a producción al 2027-04-26 (2026-10-17) y se firmó el acta de la Integración con el core (2026-10-18), cuyo hito vencía el 2026-07-06. El informe de avance del 2026-10-17 declara rojo y 48%, y no menciona la solicitud de cambio ni el cronograma nuevo.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 102 días (21.2 %) | No calculable: hay una sola declaración (2026-10-17) y el script no entrega esta cifra | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-09-11 | `00-gobierno/2025-09-11-acta-constitucion.md` | Nace el proyecto: inicio 2025-09-21, cierre 2027-01-14, 3.300.000.000 COP. Patrocinador y gerente: Ricardo Salas. Dependencias: "Ninguna declarada". |
| 2025-09-11 | `10-plan/2025-09-11-cronograma-v1.xlsx` | Línea base v1, cierre 2027-01-14. Ver nota de fecha abajo. |
| 2025-09-12 | `00-gobierno/2025-09-12-contrato-ct-137.docx` | Contrato con Integra Sistemas Ltda.: 4 entregables de 268.808.113 COP cada uno. Se factura contra acta de recibo firmada por el gerente. |
| 2026-01-15 | `20-seguimiento/2026-01-15-acta-recibo-ct-137-licenciamiento-del-motor.md` | Se recibe el Licenciamiento del motor (comprometido para 2026-01-04). Único entregable del contrato con acta. |
| 2026-09-30 | `20-seguimiento/2026-09-30-factura-ct-137.pdf` | Factura FV-1137 por 268.808.113 COP, concepto "Entregables del contrato CT-137", radicada en cuentas por pagar. |
| 2026-10-07 | `20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +102 días y +204.000.000 COP. "Pendiente de presentación al comité". |
| 2026-10-14 | `30-reuniones/2026-10-14-comite-semanal.docx` | Comité: temas "Avance" y "Compromisos". CC-01 no aparece. Un compromiso (María Restrepo, "Entregar el punto 28", para 2026-11-15). |
| 2026-10-17 | `10-plan/2026-10-17-cronograma-v2.csv` | Salida a producción pasa de 2027-01-14 a 2027-04-26. Los demás hitos no cambian. Sin motivo ni aprobación escritos. |
| 2026-10-17 | `20-seguimiento/2026-10-17-informe-avance.md` | Declara rojo y 48 %. Ejecutado 2.045.359.196 COP; proyección 3.896.316.249 COP. |
| 2026-10-18 | `20-seguimiento/2026-10-18-acta-recibo-integración-con-el-core.pdf` | Se recibe la Integración con el core, hito con fecha 2026-07-06. |

**Nota de fecha.** El cronograma v1 lleva fecha 2025-09-11 en el nombre, pero marca "cerrado" tres hitos con fechas de 2025-12-26, 2026-04-01 y 2026-07-06. Un documento de septiembre de 2025 no puede registrar eso. Lo ubiqué en la fecha del nombre, pero su contenido se editó después. No puedo decir cuándo.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-17 | 2027-04-26 (+102 días sobre la original del 2027-01-14) | Ninguno en el cronograma v2. CC-01 pide los mismos +102 días por ampliación de alcance. | Ninguno. CC-01 sigue pendiente de comité; el script marca 102 días movidos y 0 autorizados. |

El cronograma v2 conserva la fecha de línea base original (2027-01-14) y mueve solo la vigente. Eso es correcto como método. Falta la aprobación.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente ni comité en los documentos leídos. | — |

Es una ausencia de cambios, y también un dato de estructura. En todos los documentos, Ricardo Salas figura como patrocinador, gerente, solicitante de CC-01 y quien recibe los entregables (actas de 2026-01-15 y 2026-10-18). En el comité del 2026-10-14 figura como único asistente, listado dos veces. Ningún documento de la carpeta trae una segunda firma. No es una acusación; es lo que hay en los documentos.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió. Hay un solo compromiso abierto: María Restrepo, "Entregar el punto 28" | 1 | 2026-11-15 |

Solo hay un acta de reunión (2026-10-14), así que no se puede ver una repetición. "El punto 28" no se puede rastrear a ningún tema del acta, que lista solo dos.

### Desde cuándo lo declarado no se sostiene
- **Fecha:** el primer hito declarado cumplido sin evidencia es **Diseño funcional aprobado**, con fecha 2025-12-26, dentro del trimestre sin documentos 2025-T4. Le sigue **Ambiente de pruebas certificado**, 2026-04-01, que cae justo al empezar el otro trimestre sin documentos (2026-T2). El script los cuenta como 296 y 200 días de vencidos sin evidencia.
- **Lo que se siguió reportando:** el cronograma v2 (2026-10-17) mantiene ambos como cumplidos. El avance declarado es 48 %, mientras el plan sostiene entre 60 % y 80 % (brecha de 12.0 puntos, por detrás). De los 3 hitos declarados cumplidos de 5, solo 1 tiene acta (Integración con el core, fechada el 2026-10-18, un día después del cronograma que ya la marcaba cerrada).
- **Límite:** hay una sola declaración de estado en la carpeta. No hay serie, así que no puedo fechar un deslizamiento; solo puedo señalar el primer hito sin respaldo.
- **Lo que sí está dicho:** el informe declara rojo. El estado no oculta el problema. Lo que no recoge son 7 señales que el script detecta: replanificación sin autorizar, variación de tiempo, variación de costo, avance contra plan, hito vencido, hitos cumplidos sin evidencia y entregables del proveedor atrasados.

Otros hechos de la serie:
- **Piloto con usuarios internos:** vencía el 2026-10-10, está pendiente y el script lo cuenta 8 días vencido. El cronograma v2 no lo movió; movió solo la salida a producción.
- **Dinero:** ejecutado 62.0 % del aprobado contra comprometido 53.5 %, es decir, ejecutado por encima de comprometido. La proyección supera lo aprobado en 18.1 %. CC-01 pide 204.000.000 COP adicionales, sin aprobar. No puedo saber si la proyección los incluye.
- **Proveedor CT-137:** 1 de 4 entregables con acta. Bolsa de horas de desarrollo (2026-04-20, 181 días) y Parametrización del tarifario (2026-08-04, 75 días) están pendientes. La factura FV-1137 coincide en monto con un entregable (el único aceptado, 268.808.113 COP) pero no dice cuál. Fue emitida el 2026-09-30, mucho después del acta del 2026-01-15.

### Lecciones ancladas a un hecho
1. **Una fecha se movió antes de ser aprobada.** Hecho: el 2026-10-17 el cronograma v2 fijó el cierre en 2027-04-26, 10 días después de CC-01 (2026-10-07, pendiente) y 3 días después de un comité (2026-10-14) que no la trató. Efecto: 102 días de atraso (21.2 %) sin documento que los autorice.
2. **Hitos cerrados sin acta.** Hecho: Diseño funcional (2025-12-26) y Ambiente de pruebas (2026-04-01) figuran como cerrados y ningún documento lo sustenta. Efecto: el avance de 48 % contra un plan que sostiene entre 60 % y 80 %, y dos de los tres hitos "cumplidos" sin respaldo.
3. **El pago depende de un acta, y ninguna factura nombra su entregable.** Hecho: el contrato exige acta de recibo para facturar y la factura FV-1137 (2026-09-30) cita solo "entregables del contrato CT-137". Efecto: con un único acta (2026-01-15) no se puede ligar la factura a su entregable por el texto.
4. **Todos los roles en una persona.** Hecho: el acta de constitución del 2025-09-11 asigna patrocinio y gerencia a la misma persona. Efecto: ningún documento posterior (CC-01, actas de recibo, comité del 2026-10-14) tiene una segunda firma.

### Qué no sé
- Cuándo se editó el cronograma v1 para marcar hitos como cerrados.
- Si la proyección de 3.896.316.249 COP incluye CC-01.
- Qué hay detrás de "la aprobación regulatoria pendiente desde el trimestre anterior" que menciona el informe: no hay documento.
- Qué ocurrió en 2025-T4 y 2026-T2, trimestres sin un solo documento.
- Los días entre fechas que no salen del script (por ejemplo, entre el vencimiento del hito de integración y su acta) no los calculé.

**Qué no dice esta historia:** no atribuyo intención. Que el atraso quedara sin autorizar no dice que alguien lo ocultara: sirve para tener esa conversación con datos. La tiene una persona.

**Siguiente paso posible:** llevar esta historia al comité (el próximo es el 2026-10-25), donde CC-01 está pendiente de decisión, o al cierre del proyecto.

---
**Pie de rigor.** Leí 10 documentos de PRY-210, fechados del 2025-09-11 al 2026-10-18. Las cifras salen de `portafolio.py compute` con corte 2026-10-18 y las copié tal cual; donde el script no da una cifra, lo digo. El estado declarado, el avance y los importes de dinero vienen del informe del 2026-10-17, que es una declaración, no una evidencia. Los documentos .docx, .xlsx y .pdf los leí en su texto convertido. Lo que se habló fuera de los documentos no lo sé. La verificación de cada dato es de quien lo use, con la cita en la mano.
