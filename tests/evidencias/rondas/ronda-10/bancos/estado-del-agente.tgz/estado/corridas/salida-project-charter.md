Acta previa: sí existe, del 2025-06-14 (`PRY-203-open-banking/00-gobierno/2025-06-14-acta-constitucion.docx`). Términos vigentes (José Francisco Ñáñez, 2026-10-18, v0.5.0). Modo: revisar.

## Acta — PRY-203 Open Banking
**Estado:** existe, del 2025-06-14

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está.** El acta no dice hasta qué monto ni qué cambio de alcance puede decidir Laura Vélez sin subir al Comité de Riesgos. | Toda decisión de dinero o alcance sube al comité por defecto. Hoy pesa: hay un cambio regulatorio en discusión que "puede mover el alcance" y una prueba de carga que se repite, y nadie sabe si eso lo decide la gerente o el comité. |
| Objetivo de negocio | Presente pero es una descripción de la solución: "Entregar open banking para Riesgo y Cumplimiento". No dice qué cambia para el negocio, ni cuánto. | No se puede decir si el proyecto valió la pena, solo si se entregó algo. El cierre no tiene contra qué medirse. |
| Alcance | "Componente 1, Componente 2, Componente 3". Son marcadores sin contenido. | Nadie puede decir qué entra y qué no; cualquier solicitud de cambio se discute sin referencia. |
| Exclusiones | "Lo que otro proyecto cubre". No nombra el otro proyecto ni qué cubre. | Riesgo de que el trabajo caiga entre dos proyectos o se duplique, y no hay a quién reclamarlo. |
| Criterio de éxito | "Open Banking en producción y medido." Sin umbral, sin cifra, sin plazo. | "Medido" no dice qué métrica ni contra qué valor. El éxito se puede declarar con cualquier resultado. |
| Quién mide el éxito | **No está.** | Quien reporta el avance es también quien declara el éxito; no hay medición independiente. |
| Supuestos y restricciones | **No están.** El acta solo declara "Dependencias: Ninguna declarada". | La regulación pendiente y la dependencia de una sola persona (ambas aparecen después en el informe de avance) nacieron sin registro de origen. "Ninguna declarada" no es lo mismo que ninguna. |
| Hitos principales | **No están.** Solo inicio (2025-06-24) y cierre (2026-08-10). | Sin hitos intermedios, el único punto de control era la fecha final. Esa fecha ya pasó (hace 69 días al 2026-10-18) y no hay línea base nueva registrada. |
| Cadencia del comité | **No está.** Se nombra el comité (Comité de Riesgos) pero no cada cuánto reporta el proyecto. | Sin cadencia pactada, nada obliga a llevar el proyecto al comité antes de que venza una fecha. |
| Patrocinador / Gerente | Presentes con nombre: Ricardo Salas / Laura Vélez. | — |
| Presupuesto y fechas | Presentes: 2.400.000.000 COP, aprobado por el Comité de Riesgos el 2025-06-14; inicio 2025-06-24, cierre 2026-08-10. | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar open banking para Riesgo y Cumplimiento", que es la solución, no el objetivo. (acta, 2025-06-14)
**Alcance:** "Componente 1, Componente 2, Componente 3" — sin descripción; pendiente de definir. (acta)
**Exclusiones:** "Lo que otro proyecto cubre" — no identifica proyecto; pendiente de definir. (acta)
**Patrocinador:** Ricardo Salas · **Gerente:** Laura Vélez (acta)
**Autoridad del gerente:** pendiente de definir — no está en ningún documento.
**Comité al que reporta:** Comité de Riesgos (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Open Banking en producción y medido" (acta); sin métrica ni umbral. · **Lo mide:** pendiente de definir.
**Hitos principales:** solo inicio 2025-06-24 y cierre 2026-08-10 (acta); sin hitos intermedios.

### Lo que el acta no explica y el informe de avance sí muestra
El informe del 2026-10-18 declara estado Verde y 40% de avance, con cierre comprometido al 2026-08-10, ya vencido. Presupuesto: aprobado 2.400.000.000, comprometido 794.475.669, ejecutado 719.949.354, proyección al cierre 2.238.706.754 (cifras declaradas por la gerente, no verificadas contra otro documento). No encuentro una línea base nueva ni acta de cambio que mueva la fecha. Esto es un hallazgo de estado, no de acta; lo dejo señalado porque un acta con criterio de éxito, hitos y autoridad definidos habría obligado a decidir esto antes. Corresponde a `/status-report` y `/change-control`.

### Después
- El acta quedó sin autoridad declarada: ofrezco preparar la definición para llevarla al Comité de Riesgos. Es una decisión (monto y tipo de cambio que decide la gerente), no un trámite. No la propongo con cifras: eso lo fija el comité.
- De la revisión salen supuestos que nadie registró (regulación pendiente de aprobación, conocimiento concentrado en una persona): ofrezco pasarlos al registro RAID con `/raid-log`.

### Pie de rigor
Leí dos documentos: el acta (2025-06-14) y el informe de avance (2026-10-18). No hay minutas ni plan en la carpeta de este proyecto, así que no sé qué se acordó fuera de ellos (por ejemplo, si la autoridad del gerente se definió en una reunión o en una política general del banco). Las cifras del informe son declaraciones; no las contrasté. Nada en esta salida es decisión: son borradores para que la gerencia y el comité los confirmen.
