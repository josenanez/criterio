# Corrida del 2026-10-18 · portfolio-server

13 proyectos · 67 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `commitment_overdue` | 10 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 4 |
| `variance_cost` | 4 |
| `commitment_rescheduled` | 3 |
| `vendor_deliverable_late` | 3 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `commitment_undated` | 2 |
| `silent` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `change_without_baseline` | 1 |
| `rebaseline_unauthorized` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-18: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-18; comprobante en `.criterio/terminos/`). No hizo falta registrarlos de nuevo.

Modo elegido: **para mirarlo un rato** (respuesta sugerida; la persona no indicó otra cosa, y es por donde se empieza).

Informe encontrado en `reportes/` (13 proyectos, 8 productos, decisiones, listado). Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado, `--puerto 8788`. Se para con Ctrl-C. El portal lleva «Banco Ejemplo» en todas las páginas.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio, mirando todo junto | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda nada.

Enlace: `http://127.0.0.1:8787/` solo sirve en este equipo; no se le pasa a nadie. Para que el patrocinador tenga un enlace estable, hay que pasar a «que quede corriendo» (host, puerto y control de acceso de la organización). El informe es del 2026-10-18; se desactualiza al siguiente barrido o cuando cambie algún documento.
