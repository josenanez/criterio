<!-- origen: PRY-199-renovación-de-cajeros-automáticos/00-gobierno/2026-06-10-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Renovación de cajeros automáticos

**Código:** PRY-199
**Área dueña:** Banca de Personas
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Transformación Digital
**Producto asociado:** PRD-299
**Fecha de aprobación:** 2026-06-10

## Objetivo del negocio

Entregar renovación de cajeros automáticos para Banca de Personas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-06-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-20 |
| Cierre | 2027-12-17 |

## Criterio de éxito

Renovación de cajeros automáticos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
