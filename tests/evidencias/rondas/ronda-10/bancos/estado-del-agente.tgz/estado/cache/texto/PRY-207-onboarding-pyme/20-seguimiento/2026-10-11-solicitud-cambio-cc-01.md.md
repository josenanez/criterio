<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-11
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +88 días sobre la línea base vigente |
| Costo | 176.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
