<!-- origen: PRY-201-core-de-depósitos/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-201",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "name": {
 "value": "Core de depósitos",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "business_area": {
 "value": "Tesorería",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "product": {
 "value": "cuenta de ahorros",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "manager": {
 "value": "Carlos Peña",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Arquitectura",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 70,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-16",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "plan": {
 "start_date": {
 "value": "2026-03-29",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "end_date": {
 "value": "2027-06-21",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-03-19",
 "start_date": "2026-03-29",
 "end_date": "2027-06-21",
 "reason": "Aprobación inicial por el Comité de Arquitectura",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-07-19",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "current_date": {
 "value": "2026-07-19",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-18-acta-recibo-diseño-funcional-aprobado.md"
 }
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-11-08",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "current_date": {
 "value": "2026-11-08",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Integración con el core",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-03-01",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "current_date": {
 "value": "2027-03-01",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Piloto con usuarios internos",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-06-21",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "current_date": {
 "value": "2027-06-21",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-03-19-cronograma-v1.xlsx",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3 (sin más detalle en el acta)",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "approved": {
 "value": 1200000000,
 "source": "00-gobierno/2026-03-19-acta-constitucion.md",
 "source_date": "2026-03-19",
 "state": "found"
 },
 "committed": {
 "value": 935701138,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 739016329,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 1104493088,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Dependencia del calendario de liberaciones del core",
 "owner": null,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (comentado en reunión; nadie lo anotó como riesgo)",
 "owner": null,
 "source": "2026-10-18-notas-reunion.txt",
 "source_date": "2026-10-18",
 "registered": false
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-03"
 },
 "original_due_date": {
 "value": "2026-09-24"
 },
 "stated_on": {
 "value": "2026-09-06"
 },
 "source": {
 "value": "30-reuniones/2026-09-06-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 {
 "due_date": "2026-12-03",
 "stated_on": "2026-10-18",
 "source": "2026-10-18-notas-reunion.txt"
 }
 ],
 "note": "Notas del 2026-10-18: «no alcanzó, se compromete para el 03/12/2026». Se leyó dd/mm (3 de diciembre); la fecha está escrita en formato ambiguo."
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-27"
 },
 "original_due_date": {
 "value": "2026-09-29"
 },
 "stated_on": {
 "value": "2026-09-06"
 },
 "source": {
 "value": "30-reuniones/2026-09-06-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-18"
 },
 "original_due_date": {
 "value": "2026-09-18"
 },
 "stated_on": {
 "value": "2026-09-06"
 },
 "source": {
 "value": "30-reuniones/2026-09-06-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-20-acta-recibo-3.md"
 }
 },
 {
 "who": {
 "value": "Natalia Ospina",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-06-comite-semanal.md",
 "source_date": "2026-09-06",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": {
 "value": "2026-09-14"
 },
 "stated_on": {
 "value": "2026-09-06"
 },
 "source": {
 "value": "30-reuniones/2026-09-06-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-09-23",
 "stated_on": "2026-09-13",
 "source": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-20",
 "source": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-08"
 },
 "original_due_date": {
 "value": "2026-09-26"
 },
 "stated_on": {
 "value": "2026-09-13"
 },
 "source": {
 "value": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ],
 "note": "El acta de recibo del 2026-10-18 certifica «Diseño funcional aprobado» pero no nombra este compromiso; no se da por cerrado. Para confirmar con el gerente si es el mismo."
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-07"
 },
 "original_due_date": {
 "value": "2026-09-20"
 },
 "stated_on": {
 "value": "2026-09-13"
 },
 "source": {
 "value": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-05"
 },
 "original_due_date": {
 "value": "2026-09-22"
 },
 "stated_on": {
 "value": "2026-09-13"
 },
 "source": {
 "value": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-13-comite-semanal.md",
 "source_date": "2026-09-13",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-04"
 },
 "original_due_date": {
 "value": "2026-10-04"
 },
 "stated_on": {
 "value": "2026-09-13"
 },
 "source": {
 "value": "30-reuniones/2026-09-13-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-27-acta-recibo-8.md"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12"
 },
 "original_due_date": {
 "value": "2026-09-27"
 },
 "stated_on": {
 "value": "2026-09-20"
 },
 "source": {
 "value": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-27",
 "source": "30-reuniones/2026-09-27-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-04-acta-recibo-9.md"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15"
 },
 "original_due_date": {
 "value": "2026-09-30"
 },
 "stated_on": {
 "value": "2026-09-20"
 },
 "source": {
 "value": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-04",
 "source": "30-reuniones/2026-10-04-comite-semanal.md"
 }
 ],
 "note": "El 2026-10-11 dijo que ya lo entregó; no se presentó acta. Salió de la tabla de abiertos ese día sin acta de recibo."
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26"
 },
 "original_due_date": {
 "value": "2026-10-14"
 },
 "stated_on": {
 "value": "2026-09-20"
 },
 "source": {
 "value": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-20-comite-semanal.md",
 "source_date": "2026-09-20",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-09-20"
 },
 "source": {
 "value": "30-reuniones/2026-09-20-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«por definir» en las reuniones del 09-20, 09-27, 10-04 y 10-11."
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-03"
 },
 "original_due_date": {
 "value": "2026-10-03"
 },
 "stated_on": {
 "value": "2026-09-27"
 },
 "source": {
 "value": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-08"
 },
 "original_due_date": {
 "value": "2026-10-08"
 },
 "stated_on": {
 "value": "2026-09-27"
 },
 "source": {
 "value": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "El 2026-10-11 dijo que ya lo entregó; no se presentó acta."
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-09"
 },
 "original_due_date": {
 "value": "2026-10-09"
 },
 "stated_on": {
 "value": "2026-09-27"
 },
 "source": {
 "value": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-27-comite-semanal.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14"
 },
 "original_due_date": {
 "value": "2026-10-14"
 },
 "stated_on": {
 "value": "2026-09-27"
 },
 "source": {
 "value": "30-reuniones/2026-09-27-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "El 2026-10-11 dijo que ya lo entregó; no se presentó acta."
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-13"
 },
 "original_due_date": {
 "value": "2026-10-13"
 },
 "stated_on": {
 "value": "2026-10-04"
 },
 "source": {
 "value": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-11-acta-recibo-17.md"
 }
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": {
 "value": "2026-10-04"
 },
 "source": {
 "value": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-11",
 "source": "30-reuniones/2026-10-11-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-26"
 },
 "original_due_date": {
 "value": "2026-10-26"
 },
 "stated_on": {
 "value": "2026-10-04"
 },
 "source": {
 "value": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-04-comite-semanal.md",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-28"
 },
 "stated_on": {
 "value": "2026-10-04"
 },
 "source": {
 "value": "30-reuniones/2026-10-04-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15"
 },
 "original_due_date": {
 "value": "2026-10-15"
 },
 "stated_on": {
 "value": "2026-10-11"
 },
 "source": {
 "value": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-25"
 },
 "original_due_date": {
 "value": "2026-10-25"
 },
 "stated_on": {
 "value": "2026-10-11"
 },
 "source": {
 "value": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": {
 "value": "2026-10-11"
 },
 "source": {
 "value": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-11-comite-semanal.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06"
 },
 "original_due_date": {
 "value": "2026-11-06"
 },
 "stated_on": {
 "value": "2026-10-11"
 },
 "source": {
 "value": "30-reuniones/2026-10-11-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-18-notas-reunion.txt",
 "source_date": "2026-10-18",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-18-notas-reunion.txt",
 "source_date": "2026-10-18",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-10-18"
 },
 "source": {
 "value": "2026-10-18-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Fecha dicha: «la otra semana» (no es fecha)."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-18-notas-reunion.txt",
 "source_date": "2026-10-18",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-18-notas-reunion.txt",
 "source_date": "2026-10-18",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-10-28"
 },
 "stated_on": {
 "value": "2026-10-18"
 },
 "source": {
 "value": "2026-10-18-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-18",
 "sealed": false,
 "scope_note": "Leídas las 6 minutas (2026-09-06 a 2026-10-11), las notas del 2026-10-18 y las 5 actas de recibo. No sellada.",
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ]
 }
}
