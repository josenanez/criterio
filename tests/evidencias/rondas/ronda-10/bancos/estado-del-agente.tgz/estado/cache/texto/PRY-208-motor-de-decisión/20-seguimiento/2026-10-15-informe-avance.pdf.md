<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de decisión
Código: PRY-208
Fecha de corte: 2026-10-15
Gerente: Beatriz Cuéllar

Estado declarado
Rojo
Avance reportado: 40%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.608.878.183
Ejecutado 1.741.882.527
Proyección al cierre 5.073.552.071

Riesgos abiertos
- Concentración del conocimiento en una sola persona
