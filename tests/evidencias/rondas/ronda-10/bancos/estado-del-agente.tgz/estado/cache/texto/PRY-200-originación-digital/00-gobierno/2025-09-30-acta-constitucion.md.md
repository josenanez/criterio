<!-- origen: PRY-200-originación-digital/00-gobierno/2025-09-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Originación digital

**Código:** PRY-200
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Riesgos
**Producto asociado:** crédito de consumo
**Fecha de aprobación:** 2025-09-30

## Objetivo del negocio

Entregar originación digital para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Riesgos el 2025-09-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-10 |
| Cierre | 2027-02-14 |

## Criterio de éxito

Originación digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
