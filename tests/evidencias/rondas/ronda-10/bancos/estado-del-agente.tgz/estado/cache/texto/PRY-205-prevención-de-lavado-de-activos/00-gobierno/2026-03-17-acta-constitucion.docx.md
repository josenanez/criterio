<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-03-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Banca Empresas

Patrocinador: Sandra Gil

Gerente de proyecto: Felipe Arango

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2026-03-17

Objetivo del negocio

Entregar prevención de lavado de activos para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Riesgos el 2026-03-17.

Fechas comprometidas

Fecha

Inicio

2026-03-27

Cierre

2026-10-21

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
