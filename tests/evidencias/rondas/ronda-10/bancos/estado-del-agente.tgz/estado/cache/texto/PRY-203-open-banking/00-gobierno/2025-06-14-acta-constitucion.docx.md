<!-- origen: PRY-203-open-banking/00-gobierno/2025-06-14-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Riesgo y Cumplimiento

Patrocinador: Ricardo Salas

Gerente de proyecto: Laura Vélez

Comité: Comité de Riesgos

Producto asociado: APIs de datos

Fecha de aprobación: 2025-06-14

Objetivo del negocio

Entregar open banking para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Riesgos el 2025-06-14.

Fechas comprometidas

Fecha

Inicio

2025-06-24

Cierre

2026-08-10

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
