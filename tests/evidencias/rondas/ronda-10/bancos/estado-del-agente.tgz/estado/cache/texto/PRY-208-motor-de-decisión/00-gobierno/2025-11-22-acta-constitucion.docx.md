<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2025-11-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Banca Empresas

Patrocinador: Felipe Arango

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2025-11-22

Objetivo del negocio

Entregar motor de decisión para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2025-11-22.

Fechas comprometidas

Fecha

Inicio

2025-12-02

Cierre

2026-07-10

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
