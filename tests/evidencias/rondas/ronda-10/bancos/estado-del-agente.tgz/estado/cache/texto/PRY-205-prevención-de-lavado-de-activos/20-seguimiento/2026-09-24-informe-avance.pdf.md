<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-09-24
Gerente: Felipe Arango

Estado declarado
Amarillo
Avance reportado: 59%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.909.019.480
Ejecutado 875.383.340
Proyección al cierre 3.254.312.740

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
