<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-12
**Asistentes:** Rubén Cárdenas, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 25 | 2026-10-09 |
