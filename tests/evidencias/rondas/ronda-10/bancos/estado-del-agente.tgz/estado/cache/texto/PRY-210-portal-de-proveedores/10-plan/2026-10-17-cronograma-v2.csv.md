<!-- origen: PRY-210-portal-de-proveedores/10-plan/2026-10-17-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-12-26,2025-12-26,cerrado
Ambiente de pruebas certificado,2026-04-01,2026-04-01,cerrado
Integración con el core,2026-07-06,2026-07-06,cerrado
Piloto con usuarios internos,2026-10-10,2026-10-10,en curso
Salida a producción,2027-01-14,2027-04-26,en curso
