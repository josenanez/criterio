<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-09-29-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-09-29
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 75%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.565.345.910
Ejecutado 1.078.552.588
Proyección al cierre 4.383.262.818

Riesgos abiertos
- Concentración del conocimiento en una sola persona
