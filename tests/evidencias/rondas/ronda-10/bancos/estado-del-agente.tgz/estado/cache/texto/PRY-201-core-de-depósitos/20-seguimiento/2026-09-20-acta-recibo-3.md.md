<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-09-20-acta-recibo-3.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Revisar el anexo 3

**Proyecto:** PRY-201 · Core de depósitos
**Fecha de recibo:** 2026-09-20
**Recibido por:** Carlos Peña

Se recibe a satisfacción: **Revisar el anexo 3**, compromiso de Camilo Beltrán.
