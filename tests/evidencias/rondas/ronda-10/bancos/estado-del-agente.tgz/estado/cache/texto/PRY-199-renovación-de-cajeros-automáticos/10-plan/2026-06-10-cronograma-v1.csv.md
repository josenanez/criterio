<!-- origen: PRY-199-renovación-de-cajeros-automáticos/10-plan/2026-06-10-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-10-07,2026-10-07,cerrado
Ambiente de pruebas certificado,2027-01-24,2027-01-24,en curso
Integración con el core,2027-05-13,2027-05-13,en curso
Piloto con usuarios internos,2027-08-30,2027-08-30,en curso
Salida a producción,2027-12-17,2027-12-17,en curso
