<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-10-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Nómina electrónica

Código: PRY-209

Área dueña: Medios de Pago

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Javier Hoyos

Comité: Comité de Arquitectura

Producto asociado: nómina empresarial

Fecha de aprobación: 2025-10-23

Objetivo del negocio

Entregar nómina electrónica para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Arquitectura el 2025-10-23.

Fechas comprometidas

Fecha

Inicio

2025-11-02

Cierre

2026-07-21

Criterio de éxito

Nómina electrónica en producción y medido.

Dependencias declaradas

• Ninguna declarada
