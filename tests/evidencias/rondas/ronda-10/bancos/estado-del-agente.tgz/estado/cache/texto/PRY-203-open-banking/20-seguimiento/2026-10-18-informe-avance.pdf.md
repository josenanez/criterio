<!-- origen: PRY-203-open-banking/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Open Banking
Código: PRY-203
Fecha de corte: 2026-10-18
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 40%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 794.475.669
Ejecutado 719.949.354
Proyección al cierre 2.238.706.754

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio regulatorio en discusión que puede mover el alcance
