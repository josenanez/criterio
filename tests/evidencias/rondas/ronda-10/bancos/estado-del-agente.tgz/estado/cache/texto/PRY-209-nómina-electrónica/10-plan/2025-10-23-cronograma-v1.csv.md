<!-- origen: PRY-209-nómina-electrónica/10-plan/2025-10-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-06,2026-01-06,cerrado
Ambiente de pruebas certificado,2026-03-12,2026-03-12,cerrado
Integración con el core,2026-05-17,2026-05-17,cerrado
Piloto con usuarios internos,2026-07-21,2026-07-21,cerrado
