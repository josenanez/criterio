<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-02-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Riesgo y Cumplimiento

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Transformación Digital

Producto asociado: recaudos

Fecha de aprobación: 2026-02-08

Objetivo del negocio

Entregar cobranza digital para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Transformación Digital el 2026-02-08.

Fechas comprometidas

Fecha

Inicio

2026-02-18

Cierre

2026-09-11

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
