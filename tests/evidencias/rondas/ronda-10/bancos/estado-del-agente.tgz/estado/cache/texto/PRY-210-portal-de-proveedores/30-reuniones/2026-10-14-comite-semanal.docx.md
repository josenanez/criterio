<!-- origen: PRY-210-portal-de-proveedores/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Portal de proveedores

Fecha: 2026-10-14

Asistentes: Ricardo Salas, Ricardo Salas

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

María Restrepo

Entregar el punto 28

2026-11-15
