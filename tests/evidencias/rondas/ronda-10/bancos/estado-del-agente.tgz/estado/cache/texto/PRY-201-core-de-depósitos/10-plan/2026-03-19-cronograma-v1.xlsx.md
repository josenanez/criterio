<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-03-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-19 | 2026-07-19 | cerrado
Ambiente de pruebas certificado | 2026-11-08 | 2026-11-08 | en curso
Integración con el core | 2027-03-01 | 2027-03-01 | en curso
Piloto con usuarios internos | 2027-06-21 | 2027-06-21 | en curso
