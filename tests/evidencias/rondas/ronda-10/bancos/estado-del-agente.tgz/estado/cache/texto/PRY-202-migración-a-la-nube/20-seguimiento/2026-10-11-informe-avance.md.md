<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-11
**Gerente:** Javier Hoyos

## Estado declarado

**Amarillo**

Avance reportado: **51%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.661.270.154 |
| Ejecutado | 1.587.108.579 |
| Proyección al cierre | 3.241.959.414 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
