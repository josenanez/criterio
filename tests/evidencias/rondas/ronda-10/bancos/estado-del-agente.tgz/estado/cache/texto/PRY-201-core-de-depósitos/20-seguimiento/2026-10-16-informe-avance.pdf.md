<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-10-16
Gerente: Carlos Peña

Estado declarado
Amarillo
Avance reportado: 70%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 935.701.138
Ejecutado 739.016.329
Proyección al cierre 1.104.493.088

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
