<!-- origen: PRY-206-billetera-y-qr/10-plan/2026-02-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-26,2026-05-26,cerrado
Ambiente de pruebas certificado,2026-08-30,2026-08-30,cerrado
Integración con el core,2026-12-04,2026-12-04,en curso
