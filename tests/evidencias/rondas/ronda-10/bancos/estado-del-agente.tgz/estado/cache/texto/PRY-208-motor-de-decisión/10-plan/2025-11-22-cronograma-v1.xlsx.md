<!-- origen: PRY-208-motor-de-decisión/10-plan/2025-11-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-26 | 2026-01-26 | cerrado
Ambiente de pruebas certificado | 2026-03-22 | 2026-03-22 | cerrado
Integración con el core | 2026-05-16 | 2026-05-16 | cerrado
Piloto con usuarios internos | 2026-07-10 | 2026-07-10 | cerrado
