<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Cobranza digital

**Fecha:** 2026-10-09
**Asistentes:** Beatriz Cuéllar, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 16 | 2026-10-22 |
