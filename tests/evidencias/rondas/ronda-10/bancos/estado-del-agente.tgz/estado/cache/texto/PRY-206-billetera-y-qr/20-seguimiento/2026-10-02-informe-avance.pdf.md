<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-02-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-02
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 72%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.683.522.448
Ejecutado 1.558.478.090
Proyección al cierre 6.427.630.209

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
