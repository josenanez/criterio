<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-08-20-acta-recibo-ct-812-parametrización-del-tarifario.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Parametrización del tarifario
Proyecto: PRY-202 · Migración a la nube
Fecha de recibo: 2026-08-20
Recibido por: Javier Hoyos
Se recibe a satisfacción el entregable Parametrización del tarifario.
Contrato CT-812 · Redes del Norte Ltda..
