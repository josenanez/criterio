<!-- origen: PRY-200-originación-digital/10-plan/2025-09-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-10,2026-02-10,cerrado
Ambiente de pruebas certificado,2026-06-13,2026-06-13,cerrado
Integración con el core,2026-10-14,2026-10-14,en curso
Piloto con usuarios internos,2027-02-14,2027-02-14,en curso
