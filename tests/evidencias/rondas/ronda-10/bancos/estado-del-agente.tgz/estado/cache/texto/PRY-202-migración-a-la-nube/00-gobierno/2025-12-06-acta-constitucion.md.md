<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-12-06-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Migración a la nube

**Código:** PRY-202
**Área dueña:** Banca Hipotecaria
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-06

## Objetivo del negocio

Entregar migración a la nube para Banca Hipotecaria.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Arquitectura el 2025-12-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-16 |
| Cierre | 2026-09-25 |

## Criterio de éxito

Migración a la nube en producción y medido.

## Dependencias declaradas

- Ninguna declarada
