<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Portal de proveedores
**Fecha:** 2026-10-07
**Solicitante:** Ricardo Salas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +102 días sobre la línea base vigente |
| Costo | 204.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
