<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Transformación Digital · Motor de decisión

Fecha: 2026-10-14

Asistentes: Beatriz Cuéllar, Felipe Arango

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

María Restrepo

Entregar el punto 40

2026-10-05
