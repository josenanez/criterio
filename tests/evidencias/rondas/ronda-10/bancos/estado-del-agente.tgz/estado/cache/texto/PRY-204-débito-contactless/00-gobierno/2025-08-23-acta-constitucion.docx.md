<!-- origen: PRY-204-débito-contactless/00-gobierno/2025-08-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Tecnología

Patrocinador: Javier Hoyos

Gerente de proyecto: María Restrepo

Comité: Comité de Banca Empresas

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-08-23

Objetivo del negocio

Entregar débito contactless para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Banca Empresas el 2025-08-23.

Fechas comprometidas

Fecha

Inicio

2025-09-02

Cierre

2026-05-20

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
