<!-- origen: PRY-211-cobranza-digital/10-plan/2026-02-08-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-10 | 2026-04-10 | cerrado
Ambiente de pruebas certificado | 2026-05-31 | 2026-05-31 | cerrado
Integración con el core | 2026-07-22 | 2026-07-22 | cerrado
Piloto con usuarios internos | 2026-09-11 | 2026-09-11 | cerrado
