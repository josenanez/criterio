<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2026-02-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Banca Empresas
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Banca Empresas
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-02-09

## Objetivo del negocio

Entregar billetera y qr para Banca Empresas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Banca Empresas el 2026-02-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-19 |
| Cierre | 2026-12-04 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
