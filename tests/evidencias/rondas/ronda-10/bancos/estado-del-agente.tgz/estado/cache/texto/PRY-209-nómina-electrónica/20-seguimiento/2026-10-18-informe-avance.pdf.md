<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-18-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-18
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 37%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.805.816.203
Ejecutado 2.347.857.763
Proyección al cierre 5.052.016.044

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
