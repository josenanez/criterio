<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-12-06-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-10 | 2026-02-10 | cerrado
Ambiente de pruebas certificado | 2026-04-08 | 2026-04-08 | cerrado
Integración con el core | 2026-06-04 | 2026-06-04 | cerrado
Piloto con usuarios internos | 2026-07-30 | 2026-07-30 | cerrado
Salida a producción | 2026-09-25 | 2026-09-25 | cerrado
