<!-- origen: PRY-201-core-de-depósitos/2026-10-18-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión core de depósitos — 2026-10-18
estuvieron: Andrés Lozano, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Diana Molina dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 03/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-28
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
