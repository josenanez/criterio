<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Débito contactless

**Código:** PRY-204
**Fecha de corte:** 2026-10-13
**Gerente:** María Restrepo

## Estado declarado

**Verde**

Avance reportado: **33%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 2.054.513.478 |
| Ejecutado | 670.875.958 |
| Proyección al cierre | 2.650.534.633 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Disponibilidad del equipo de seguridad para la revisión final
