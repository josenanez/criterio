<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-03-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-18,2026-05-18,cerrado
Ambiente de pruebas certificado,2026-07-09,2026-07-09,cerrado
Integración con el core,2026-08-30,2026-08-30,cerrado
Piloto con usuarios internos,2026-10-21,2026-10-21,en curso
