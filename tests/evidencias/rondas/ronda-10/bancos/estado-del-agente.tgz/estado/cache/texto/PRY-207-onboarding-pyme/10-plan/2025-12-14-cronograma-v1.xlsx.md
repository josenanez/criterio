<!-- origen: PRY-207-onboarding-pyme/10-plan/2025-12-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-17 | 2026-02-17 | cerrado
Ambiente de pruebas certificado | 2026-04-13 | 2026-04-13 | cerrado
Integración con el core | 2026-06-07 | 2026-06-07 | cerrado
Piloto con usuarios internos | 2026-08-01 | 2026-08-01 | cerrado
