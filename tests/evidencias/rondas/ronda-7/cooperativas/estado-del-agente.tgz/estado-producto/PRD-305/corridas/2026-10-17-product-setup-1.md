# Corrida del 2026-10-17 · product-setup

PRD-305 · 17 requerimientos · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 8 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

0 preguntas hechas (4 con respuesta sugerida, sin interfaz); primer resultado en una sola conversación; 5 documentos, 17 requerimientos (9 aceptados, 9 sin proyecto, 14 evidencias de 13 meses), sin autoridad ni criterio de éxito; sellar no corrió

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que encontré en `documentos/productos/PRD-305`:** 5 documentos, todos legibles (3 `.md`, 2 `.docx`). Solo 1 es material de descubrimiento: una entrevista del 2025-09-06 con una sola cita. Hay caso de negocio y definición (ambos del 2026-04-03), un tablero de métricas (2026-10-09) y el acta del comité de producto (2026-10-17). Lo más reciente es del 2026-10-17.

**Las cuatro preguntas.** Nadie contesta en esta sesión, así que tomé la respuesta sugerida en cada una:
1. **Producto y gerente:** PRD-305 · Microcrédito · María Restrepo, tal como están en la definición y en el caso de negocio.
2. **Quién decide qué se construye:** ningún documento lo dice. Lo dejé sin dato, que es lo honesto, y no puse el nombre de la gerente.
3. **Dónde guardo lo que encuentre:** `estado-producto/PRD-305`, hermana de la carpeta de documentación. No usé `estado/`, que es de otro agente.
4. **Términos:** te muestro el texto tal cual. José Francisco Ñáñez lo aceptó para esta prueba el 2026-10-17, y así quedó registrado.

> Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

## Listo — Microcrédito (PRD-305)

**Lo que miré:** 5 documentos · 1 de descubrimiento · la definición del 2026-04-03
**Términos:** aceptados para la versión 0.3.13 (texto 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a…

**Lo que levanté con lo escrito:** la ficha `producto.json`, la serie `volumen_mensual` y 17 requerimientos (REQ-4500 a REQ-4515 y REQ-2037): 9 aceptados y 8 propuestos. No creé ninguno que el acta no nombre. Lo que no está escrito quedó en `not_found`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Microempresarios no tiene microcrédito» | **Parcialmente.** Una entrevista con un cliente: «Lo necesito y hoy no lo tengo.» La entrevista no dice que sea microempresario ni que hable de microcrédito, aunque lleva ese título | 2025-09-06 (13 meses) |
| «La demanda se sostiene sin campaña» (supuesto) | **Un supuesto.** La definición dice «verificado con el documento técnico del proveedor del 2026-06-14», pero ese documento no está en la carpeta. Aunque estuviera, un documento técnico del proveedor no es evidencia de demanda | declarado 2026-04-06 · 194 días sin verificar |
| Volumen mensual esperado: 216.930 | **Contrastada con una serie.** El tablero mide 207.028 al 2026-10-09. La diferencia es 4,6 %, por debajo del umbral del 20 %: es imprecisión, no contradicción | caso de negocio 2026-04-03 · tablero 2026-10-09 |
| 9 requerimientos aceptados con «cliente entrevistado» como quien lo pidió | **Una sola entrevista de 2025-09-06, con una sola cita, que no nombra ninguno de los 17 requerimientos.** Las 14 evidencias que pude citar quedan con 13 meses (umbral: 12) | 2025-09-06 |

### Lo que no está dicho en ninguna parte
- **Quién decide qué se construye.** Ni la definición, ni el caso de negocio, ni el acta lo nombran. Sin eso no hay acta de constitución posible.
- **El criterio de éxito.** Nadie escribió cómo se sabrá que el producto funcionó. El caso de negocio dice «Retorno esperado en 24 meses» sin cifra, sin base y sin fecha de partida.
- **La propuesta.** La definición dice solo «Propuesta principal». No describe qué se ofrece.
- **Qué mide `volumen_mensual`.** Ni el caso de negocio ni el tablero definen la métrica. Y la definición dice que el segmento «no tiene microcrédito», mientras el tablero ya mide un volumen mensual de 207.028. Con esos documentos no puedo decir qué se está contando.
- **El problema como hecho de mercado.** Que ningún microempresario tenga microcrédito, incluso en otras entidades, no lo afirma ni lo niega ningún documento.
- **Qué plan se «mantiene».** La única decisión del acta es «Se mantiene el plan». No hay ningún plan en la carpeta.
- **Quién decidió cada aceptación.** El acta registra los estados, no a quién los decidió. El único asistente es la gerente del producto.
- **Qué proyecto construye algo.** La definición dice «Ninguno declarado». De los 9 aceptados, 0 tiene proyecto (0,0 %). Existe un PRY-207 «Microcrédito rural», pero sus documentos no nombran PRD-305. No los enlacé.

### Supuestos sobre los que está escrita
Uno declarado: «La demanda se sostiene sin campaña». Los otros no se declaran, aunque la definición descansa en ellos: que la entrevista de 2025 sigue vigente y que el segmento está desatendido.

### Lo que el registro de requerimientos ya muestra
Son hallazgos de lectura, no una revisión completa. Para eso está `/product-requirements`.
- **Aceptados sin proyecto:** 9 de 9.
- **Aceptados sin criterio de aceptación:** 3 (REQ-2037, REQ-4501, REQ-4514). En los demás el criterio es «se verifica en producción», que no se puede comprobar.
- **Aceptados sin doliente:** REQ-4503 y REQ-4514. Propuesto sin doliente: REQ-4513.
- **Aceptado sin ninguna evidencia:** REQ-4504.
- **Propuestos sin decidir:** 8, entre 72 días (REQ-4512) y 206 días (REQ-4509). El umbral es 60.
- **REQ-2037** sale de la numeración 45xx y se aceptó el 2026-10-04, hace 13 días.

### Qué le falta a tu carpeta
- Las **transcripciones de las entrevistas.** Hoy hay una sola cita y no nombra ningún requerimiento. Con más material, `/product-discovery` puede darle a cada requerimiento la cita de quién lo pidió.
- La **serie de la métrica** con su definición. Hoy hay un solo punto, del 2026-10-09: no hay serie.
- El **documento técnico del proveedor** del 2026-06-14 que, según la definición, verifica el supuesto.
- **Quién decide**, el criterio de éxito y las decisiones del comité con quién las tomó. Sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.

**No pude sellar la lectura.** `sellar` exige una corrida abierta con `corrida-inicio`, y este comando dice que aquí no se usa. No escribí el sello a mano. La próxima corrida releerá los 5 documentos.

### Después
`/product-discovery` sobre el material de entrevistas. Ahí los temas se vuelven requerimientos con la cita de quién lo pidió.
