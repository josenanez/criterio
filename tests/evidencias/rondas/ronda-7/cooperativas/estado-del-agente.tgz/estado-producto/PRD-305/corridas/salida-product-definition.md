Términos: vigentes (texto 1.1, versión 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17. Comprobante ya registrado en `.criterio/terminos/`; no se pidió de nuevo.

## Definición — Microcrédito (PRD-305) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-04-03-definicion-producto.md` (con `2026-04-03-caso-de-negocio.md`) · **del** 2026-04-03 · 6 afirmaciones

Las 6: (1) el segmento Microempresarios no tiene microcrédito; (2) el segmento es Microempresarios; (3) la propuesta es «Propuesta principal»; (4) la demanda se sostiene sin campaña; (5) volumen_mensual de 216.930; (6) retorno esperado en 24 meses.

### Lo que la evidencia contradice
Nada. La única cifra comparable (volumen_mensual) queda por debajo del umbral, ver abajo.

### El negocio y los datos
Ninguna métrica pasa el umbral (20 %). Para constancia: volumen_mensual declarado 216.930 (caso de negocio, 2026-04-03) contra medido 207.028 (tablero de métricas, bodega de datos, corte 2026-10-09): diferencia 4,6 %. Es imprecisión, no contradicción. La serie tiene un solo punto, sin definición de la métrica (`definition_state: not_found`), así que tampoco se sabe si ambas cifras miden lo mismo.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado «en 24 meses» | Caso de negocio, 2026-04-03 | Sin cifra declarada ni serie que la mida; no se puede contrastar |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo declara.
- **Quién decide (autoridad):** ningún documento lo nombra; el comité del 2026-10-17 solo lista a María Restrepo como asistente.
- **Qué es «Propuesta principal»:** la propuesta de valor es un marcador sin contenido.
- **Qué es «microcrédito» para este producto:** monto, plazo, tasa o canal; la definición no lo dice.
- **Por qué el segmento «no tiene microcrédito»:** la afirmación no trae dato de mercado ni fuente.
- **Qué mide volumen_mensual:** unidades, desembolsos o solicitudes; no hay definición.
- **Cuánto se espera de retorno, ni sobre qué inversión.**
- **Proyectos que lo construyen:** «Ninguno declarado».

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La demanda se sostiene sin campaña (declarado 2026-04-06) | 194 (umbral 30) | El documento técnico del proveedor del 2026-06-14, que la definición cita como verificación pero no está en la carpeta; o una serie de volumen de un período sin campaña, con las fechas de las campañas. Además, «sin campaña» no define qué cuenta como campaña ni cuánto tiempo, y así escrito es difícil de desmentir. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Hay una necesidad del producto | Entrevista, cliente sin nombre: «Lo necesito y hoy no lo tengo.» | 2025-09-06 | Débil: una sola voz, dicha, no pagada; no dice qué es «lo», ni que sea microcrédito, ni que sea microempresario. Solo el título del documento la liga al producto. |
| volumen_mensual ≈ 216.930 | Tablero de métricas: 207.028 | 2026-10-09 | Medida, pero una sola observación y sin definición de la métrica. Sostiene el orden de magnitud, no una tendencia. |

Las afirmaciones 1 y 2 de la lista (problema y segmento) no tienen otra evidencia que esa entrevista; la 3 y la 6 no tienen contenido que sostener.

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del producto / problema | Entrevista del 2025-09-06 (es la evidencia de 14 requerimientos) | 13 meses (umbral 12) |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de solicitantes | No declarado en la configuración ni en los documentos | — | — | no tengo la norma a la vista |
| Consumidor financiero / crédito | No declarado | — | — | no tengo la norma a la vista |
| Retención de información | No declarado | — | — | no tengo la norma a la vista |

Un microcrédito toca por naturaleza esas tres áreas; ningún documento dice en qué país se ofrece, por lo que no cito norma. Esto no dice si el producto cumple. Va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** falta.
- Problema y para quién: están declarados (1 frase cada uno), pero sin evidencia vigente.

**Después:** el supuesto de la demanda lleva 194 días sin verificarse; conviene registrarlo como riesgo con doliente (`raid-taxonomy`). La definición no está cerrada, así que no corresponde `/product-charter` todavía.
