# Corrida del 2026-10-17 · product-wake

PRD-305 · 17 requerimientos · 29 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 8 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

Primera revisión del registro: 8 requerimientos sin decidir, 1 supuesto sin verificar, evidencia de 13 meses, 0 trazas. No se confirmaron trazas (sin carpeta de fichas). Dijo que no sabe: criterio de éxito y autoridad de decisión.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Microcrédito (PRD-305) · 2026-10-17

**Primera revisión del registro** (no había corte anterior, así que todo lo de abajo es nuevo): 17 requerimientos, 9 aceptados y 8 propuestos. Solo toca `review`; no hay `crossed` porque no existía un corte previo contra el cual comparar.

### Cruzó un umbral (60 días) sin que nadie decidiera
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4509 | 206 días (desde 2026-03-25) | Una decisión con facultad para tomarla | Felipe Arango (doliente) |
| Propuesto sin decidir | REQ-4510 | 199 días | ídem | Elena Duarte |
| Propuesto sin decidir | REQ-4508 | 195 días | ídem; además no tiene criterio de aceptación ni evidencia | Gustavo Neira |
| Propuesto sin decidir | REQ-4515 | 183 días | ídem | Gustavo Neira |
| Propuesto sin decidir | REQ-4507 | 173 días | ídem | Beatriz Cuéllar |
| Propuesto sin decidir | REQ-4513 | 161 días | ídem; además sin doliente y sin evidencia | sin asignar |
| Propuesto sin decidir | REQ-4506 | 146 días | ídem; además sin criterio de aceptación | Diana Molina |
| Propuesto sin decidir | REQ-4512 | 72 días | ídem | Camilo Beltrán |

El dato que falta es **quién tiene la facultad de decidir**: la configuración dice `authority: not_found`. Sin ese nombre, ninguno de los ocho tiene a quién llevarse. El comité de producto de hoy (2026-10-17) registra como única decisión «Se mantiene el plan» y no resuelve ninguno. Ofrezco llevarlos al próximo comité como paquete de decisiones.

### Supuesto sin verificar
- **«La demanda se sostiene sin campaña»**: 194 días sin verificarse (umbral 30). Para verificarlo haría falta una serie de volumen mensual en un periodo sin campaña activa, con fecha y fuente. Pasó de largo el punto en que conviene tratarlo como riesgo registrado (assumption-tracking). Hoy el volumen medido es 207.028 frente a 216.930 declarados en el caso de negocio (4,6 % de brecha, bajo el umbral de 20 %), pero eso no dice nada sobre campaña.

### Evidencia que envejeció
La única evidencia de demanda es la entrevista del **2025-09-06** (13 meses; umbral 12), citada por 14 requerimientos. Dos cosas que conviene decir tal cual: la entrevista **no nombra** ninguno de esos requerimientos (se vincula por el tema «Necesidad principal»), y la afirmación de la definición que se queda sin sustento fechado es que *Microempresarios no tiene microcrédito*. Todos los requerimientos con evidencia dependen de ese mismo documento.

### Aceptado sin sustento
- **REQ-4504**: aceptado (2026-06-22) sin ninguna evidencia de quién lo pidió.
- **Sin criterio de aceptación estando aceptados**: REQ-2037, REQ-4501, REQ-4514.
- **Sin doliente**: REQ-4503 (aceptado), REQ-4513, REQ-4514.

### Lo aceptado que nadie construye
Los 9 requerimientos aceptados (REQ-2037, 4500–4505, 4511, 4514) no tienen proyecto que los ejecute; el acta del comité de hoy los muestra todos con «—». Trazados: 0 %. **Las trazas no se confirman:** no hay carpeta de fichas configurada ni a la vista, y sin ella ninguna traza se da por confirmada.

### Del descubrimiento
Documentos nuevos desde el último barrido: ninguno. Sigue siendo la entrevista de 2025-09-06 y el tablero de métricas del 2026-10-09. No ofrezco `/product-discovery` ni `/product-definition` por cambios.

### Lo que no sé
- La **definición no declara criterio de éxito** (`success` vacío).
- **No hay autoridad de decisión identificada** (`authority`).
- El contenido del acta del comité de hoy lo leí hasta «Se mantiene el plan»; no vi más texto de decisiones.

**Vuelvo el 2026-11-16.**
