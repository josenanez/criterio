**No publiqué la ficha de PRD-305 (Microcrédito).** No hay carpeta de productos publicados: la configuración (`.criterio/producto/PRD-305/config.json`) no define ninguna y no existe una carpeta `publicados` en el espacio de trabajo. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la inventé ni creé ninguna carpeta (sesión sin interfaz: nadie podía autorizarlo).

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

**La ficha quedó calculada, con corte al 2026-10-17, y esto es lo que llevaría:**

- **Producto:** PRD-305 · Microcrédito · gerente María Restrepo
- **Requerimientos:** 17 (9 aceptados, 8 propuestos), cada uno con id, título y estado
- **Proyectos:** 0. Ningún requerimiento tiene proyecto asignado, así que no hay nada que cruzar por proyecto.
- **Métricas afirmadas:** 1
  - `volumen_mensual`: 216930, del caso de negocio `documentos/productos/PRD-305/00-definicion/2026-04-03-caso-de-negocio.md` (2026-04-03)
- **Segmento declarado:** Microempresarios

**Para tener en cuenta antes de publicar:** como la ficha no lleva proyectos, `/product-overlap` solo podría cruzar por métrica y por segmento.

**Qué hace falta:** que la organización acuerde la carpeta común de fichas publicadas y que quede indicada para este producto. Con eso, el comando escribe `PRD-305.json` allí.
