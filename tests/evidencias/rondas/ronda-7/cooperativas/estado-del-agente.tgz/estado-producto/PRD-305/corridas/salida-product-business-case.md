Términos: vigentes (texto 1.1, versión 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17. El comprobante ya está en `.criterio/terminos/`; no se pidió de nuevo.

# Caso de negocio — Microcrédito (PRD-305) · borrador del 2026-10-17
**Desde:** la definición del 2026-04-03 (`00-definicion/2026-04-03-definicion-producto.md`) y el caso de negocio del 2026-04-03 (`00-definicion/2026-04-03-caso-de-negocio.md`) · **Cifras con fuente:** 1 de 1 cifra numérica (la fuente es el propio caso, es decir, declarada). El «retorno esperado» no trae cifra.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Microempresarios no tiene microcrédito.» (definición, 2026-04-03). No trae dato de mercado ni fuente.
- **Para quién:** Microempresarios (definición, 2026-04-03).

## Qué se construye
Los 9 requerimientos decididos (aceptados). Los 8 propuestos quedan fuera del caso hasta que alguien los decida.

| Requerimiento | Estado | Doliente | Evidencia de demanda |
|---|---|---|---|
| REQ-2037 | aceptado (2026-10-04) | Elena Duarte | Entrevista a cliente, 2025-09-06 (no nombra el requerimiento) |
| REQ-4500 | aceptado (2026-06-23) | Camilo Beltrán | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4501 | aceptado (2026-05-08) | Ricardo Salas | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4502 | aceptado (2026-04-10) | Paula Céspedes | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4503 | aceptado (2026-07-19) | **sin doliente** | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4504 | aceptado (2026-06-22) | Paula Céspedes | **ninguna** |
| REQ-4505 | aceptado (2026-08-29) | Carlos Peña | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4511 | aceptado (2026-07-23) | Jorge Medina | Entrevista, 2025-09-06 (no lo nombra) |
| REQ-4514 | aceptado (2026-07-14) | **sin doliente** | Entrevista, 2025-09-06 (no lo nombra) |

La única voz de demanda es una entrevista de cliente sin nombre: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-06-entrevistas.docx`, 13 meses de antigüedad; el umbral es 12). Ningún requerimiento tiene proyecto que lo construya («Ninguno declarado» en la definición).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 216.930 | **Declarada** | Caso de negocio, María Restrepo | 2026-04-03 |
| volumen_mensual | 207.028 | **Medida** (un solo punto, sin definición de la métrica) | Bodega de datos, tablero de producto (`20-metricas/2026-10-09-tablero-metricas.md`) | corte 2026-10-09 |
| Retorno esperado «en 24 meses» | sin valor | **Supuesta** | Caso de negocio: la frase no trae monto, base ni inversión | 2026-04-03 |
| «La demanda se sostiene sin campaña» | — | **Supuesta** (la definición dice «verificado con el documento técnico del proveedor del 2026-06-14»; ese documento no está en la carpeta) | Definición | declarada 2026-04-06 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 216.930 | 207.028 | Caso de negocio, 2026-04-03 · tablero de métricas, corte 2026-10-09 |

Diferencia de 9.902, el 4,6 %: bajo el umbral de 20 %, no es hallazgo, pero va dentro del caso. Además la serie tiene un solo punto y nadie define si «volumen» es solicitudes, desembolsos o unidades, así que no se sabe si las dos cifras miden lo mismo.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no está en ningún documento** | — |
| Costo del equipo, contratos, cotizaciones | no están en ningún documento | — |

**Este es el primer vacío.** Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La demanda se sostiene sin campaña (194 días sin verificar; umbral 30) | El volumen declarado depende de gasto en campaña que el caso no incluye | Quien tenga el documento técnico del proveedor del 2026-06-14 o una serie de volumen de un periodo sin campaña. Doliente: sin nombrar |
| Retorno en 24 meses | No hay base para evaluar si se cumple | El negocio: debe declarar monto y base |
| El segmento no tiene microcrédito | Si ya lo tiene en otra entidad, el problema es otro | Sin dato de mercado; quién lo produce no está dicho |
| La entrevista de 2025-09-06 representa al segmento | Una sola voz sostiene 14 requerimientos | Descubrimiento de producto |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso | El negocio / quien tenga la facultad (sin nombrar) |
| Cifra de retorno y su base | «Retorno esperado en 24 meses» no se puede contrastar | El negocio |
| Qué hace «volumen_mensual» y su definición | Sin definición, declarada y medida pueden no ser comparables | Dueño de la métrica en la bodega de datos |
| Qué pasa si no se hace | No hay línea base ni alternativa dicha | El negocio |
| Alternativas consideradas | Ninguna aparece | El negocio |
| Criterio de éxito (no está en ningún documento) | Sin él el producto no se puede cerrar meses después | María Restrepo, con quien tenga la facultad |
| Quién decide (`authority: not_found`) | Los 8 requerimientos propuestos llevan entre 72 y 206 días sin decisión | Alguien con facultad |
| Documento técnico del proveedor, 2026-06-14 | Es la verificación declarada del único supuesto | Quien lo citó |
| Contenido de la «Propuesta principal» | La propuesta es un marcador vacío | María Restrepo |
| País y obligaciones normativas | Un microcrédito toca datos personales, consumidor financiero y retención; ningún documento dice el país, por eso no cito norma. Va a revisión jurídica | Jurídico |
| Acta original de las decisiones | El único documento de decisión es del 2026-10-17, pero las decisiones van del 2026-04-10 al 2026-10-04 | Quien lleve el comité |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento fija criterio de éxito, métrica objetivo ni fecha de corte. Lo único cercano es el «retorno esperado en 24 meses», que no es verificable porque no tiene cifra. Sin esto, el producto no se puede cerrar meses después. Lo debe declarar el negocio; no lo propongo yo.

## Si hay otros productos publicados
No hay fichas publicadas de otros productos a la vista. Hay carpetas de documentos de otros 11 productos (PRD-299 a PRD-309), y todos declaran un `volumen_mensual` en su caso de negocio. Ningún valor coincide con el de este producto (216.930), así que no hay duplicado literal. Pero como la métrica no tiene definición en ninguna parte, **no puedo decir si cuentan las mismas transacciones**. Sumar esos volúmenes sin esa definición daría una cifra que quizá no existe. Cuando haya fichas publicadas, el cruce de `/product-overlap` lo resuelve.

---
Este documento no proyecta ingresos, no calcula retorno y no recomienda aprobar ni rechazar.

**Después:** conviene pasar los supuestos al seguimiento con `assumption-tracking`. `/product-charter` todavía no corresponde: el costo y el criterio de éxito no están dichos.
