Sin preguntas (sesión sin interfaz): al faltar piezas, se sigue marcándolas como vacío del acta, que es la respuesta sugerida. Términos ya vigentes para la versión 0.3.13 (aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.

**Verificación previa (requirement-record).** REQ-4500 está *aceptado* (comité, «Desde» 2026-06-23), pero:
- **Criterio de aceptación:** existe, y es «se verifica en producción». Eso es un lugar, no un criterio verificable: no dice qué se mide ni contra qué umbral.
- **Evidencia de demanda:** una sola entrevista (2025-09-06), genérica, que **no nombra este requerimiento**; además tiene 13 meses y el umbral de vigencia es 12.
- **Autoridad:** `not_found` en la definición y en la configuración.
- **Quién decidió:** no consta. El comité del 2026-10-17 lista como asistente solo a María Restrepo, y su única decisión escrita es «Se mantiene el plan».

Se sigue marcándolos como vacíos del acta; no se rellenan.

# Acta de constitución — Microcrédito · REQ-4500 · borrador del 2026-10-17
**Producto:** PRD-305 Microcrédito · **Requerimientos:** REQ-4500

## Qué problema resuelve
«El segmento Microempresarios no tiene microcrédito.» (`documentos/productos/PRD-305/00-definicion/2026-04-03-definicion-producto.md`, 2026-04-03).
El requerimiento en sí no tiene su necesidad redactada: el campo *necesidad* está vacío en el registro (`estado-producto/PRD-305/requirements/REQ-4500.json`). Su título es solo «Requerimiento REQ-4500» (comité 2026-10-17). **Este acta no puede decir qué resuelve REQ-4500 en particular**, solo el problema del producto.

## Criterio de éxito
| Criterio | Cómo se verifica | Cita |
|---|---|---|
| «se verifica en producción» | **No está dicho.** Falta qué se mide, con qué valor y quién lo da por cumplido. | `30-decisiones/2026-10-17-comite-producto.docx` |

La definición del producto tampoco declara criterio de éxito (`definition.success`: no encontrado). Sin esto el cierre no se podrá juzgar.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 (doliente: Camilo Beltrán) | Entrevista «Cliente entrevistado», 2025-09-06: «Lo necesito y hoy no lo tengo.», tema «Necesidad principal». **No nombra el requerimiento y tiene 13 meses.** |

### No entra
Esta acta se pidió solo para REQ-4500; ninguno de los demás se evaluó para entrar. Fuente de estados y fechas: comité del 2026-10-17.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4501 | Requerimiento REQ-4501 | Aceptado, no incluido en esta solicitud; sin criterio de aceptación |
| REQ-4502 | Requerimiento REQ-4502 | Aceptado, no incluido en esta solicitud |
| REQ-4503 | Requerimiento REQ-4503 | Aceptado, no incluido en esta solicitud; sin doliente asignado |
| REQ-4504 | Requerimiento REQ-4504 | Aceptado, no incluido en esta solicitud; sin quién lo pidió |
| REQ-4505 | Requerimiento REQ-4505 | Aceptado, no incluido en esta solicitud |
| REQ-4511 | Requerimiento REQ-4511 | Aceptado, no incluido en esta solicitud |
| REQ-4514 | Requerimiento REQ-4514 | Aceptado, no incluido en esta solicitud; sin doliente ni criterio de aceptación |
| REQ-2037 | Requerimiento REQ-2037 | Aceptado, no incluido en esta solicitud; sin criterio de aceptación; su código no sigue la serie 45xx |
| REQ-4506, 4507, 4508, 4509, 4510, 4512, 4513, 4515 | Requerimientos de la lista | Siguen en *propuesto*: sin decisión del gerente de producto no hay acta posible |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no se propone a nadie. María Restrepo es la gerente del *producto* (definición, 2026-04-03), no se ha dicho que lo sea del proyecto. Asignar a una persona es de quien tiene la autoridad.
- **Comité:** comité de producto mensual (configuración). El del 2026-10-17 tuvo como único asistente a María Restrepo; no consta quórum ni quién decide.
- **Autoridad del gerente:** no está dicha (`authority: not_found`).
- **Decisión que aceptó REQ-4500:** estado «aceptado, desde 2026-06-23» en el comité del 2026-10-17; **quién la tomó no consta.**

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La demanda se sostiene sin campaña» (declarado 2026-04-06) | **No.** La definición dice «verificado con el documento técnico del proveedor del 2026-06-14»; ese documento no está en la carpeta, y su fecha es posterior a la de la propia definición (2026-04-03). | Gerente del proyecto (aún sin nombrar); se registra como riesgo con esa persona como doliente en cuanto exista |

Contraste de la cifra del caso de negocio: volumen mensual declarado 216.930 (2026-04-03) contra 207.028 medido (tablero, 2026-10-09). Diferencia de 4,6 %, por debajo del umbral de 20 %: no es hallazgo.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Un microcrédito toca crédito al consumidor, datos personales y retención de información | No identificada | No se hizo el barrido normativo; en la carpeta no hay ningún documento normativo | **Sin resolver** |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad del gerente | El proyecto escala todo o no escala nada | Quien firma el acta |
| Criterio de éxito verificable | El cierre no se podrá juzgar | María Restrepo con Camilo Beltrán (doliente) |
| Necesidad de REQ-4500 | No hay a qué contrastar lo entregado | Camilo Beltrán |
| Evidencia que nombre el requerimiento, y vigente | La demanda del proyecto descansa en una frase genérica de hace 13 meses | María Restrepo |
| Quién decidió aceptar REQ-4500 | No se puede probar que el gerente de producto lo decidió | María Restrepo |
| Patrocinador, gerente del proyecto, comité | Nadie responde por el proyecto | Quien firma el acta |
| Documento técnico del proveedor (2026-06-14) | El supuesto de demanda sigue sin verificar | María Restrepo |
| Barrido de obligaciones normativas | Posibles obligaciones sin ver | Área legal / cumplimiento |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para hacerlo (sin identificar en los documentos). **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`. `declared` (el estado) queda vacío por diseño.

**Qué sigue, y para quién:** quien firme cierra los vacíos de arriba. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
