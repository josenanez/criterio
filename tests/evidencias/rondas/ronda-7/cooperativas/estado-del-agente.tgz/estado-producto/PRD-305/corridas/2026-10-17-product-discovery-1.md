# Corrida del 2026-10-17 · product-discovery

PRD-305 · 17 requerimientos · 25 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 8 |
| `requirement_without_acceptance` | 3 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

1 entrevista con 1 cita, ya citada como evidencia en 14 requerimientos; ningún tema nuevo, ningún requerimiento creado. No sé qué es lo que el cliente necesita ni si es microempresario. sellar se negó (la ficha no se escribió en esta corrida) y no se forzó.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: vigentes (texto 1.1, versión 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17. Comprobante ya registrado en `.criterio/terminos/`; no se pidió de nuevo.

## Descubrimiento — Microcrédito (PRD-305) · 1 pieza de descubrimiento al 2026-10-17

El plan de lectura marcó 5 documentos sin leer (nada sellado antes). Solo 1 es material de descubrimiento: `10-descubrimiento/2025-09-06-entrevistas.docx`. Los otros 4 (definición, caso de negocio, tablero, acta del comité) se leyeron para cruzar contra el registro, no para sacar temas.

### Temas
> **Necesidad principal (sin concretar)** — 1 de 1 pieza
> — *«Lo necesito y hoy no lo tengo.»* · Cliente entrevistado (sin nombre, sin segmento), 2025-09-06
> **En el registro:** ya es `evidence` en 14 requerimientos (REQ-2037, 4500–4507, 4509–4512, 4514, 4515). La propia entrevista no nombra ninguno de ellos.

Sobre la cita: no dice qué es «lo» que necesita ni que sea microcrédito. Tampoco dice que el entrevistado sea microempresario. Lo único que liga la cita al producto es el título del documento.

### Dicho y nunca convertido en nada
Ninguno. La única cita ya está citada como evidencia en 14 requerimientos. El problema es el contrario: una cita sin contenido sostiene 14 requerimientos.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| «Lo necesito y hoy no lo tengo.» | Cliente entrevistado | 2025-09-06 |

Se registra como dicho una vez. No se promueve ni se descarta.

### Afirmaciones numéricas de los entrevistados
Ninguna.

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna. La entrevista ya estaba en el registro y no lo contradice.

### Lo que el recálculo (`compute`) dice, sin añadir nada mío
- 17 requerimientos: 9 aceptados, 8 propuestos. 8 con evidencia (88,9 %); 0 con proyecto.
- `evidence_stale`: 14. Toda la evidencia es esa entrevista, con 13 meses (umbral 12).
- `requirement_untraced`: 9. `requirement_undecided`: 8, entre 72 y 206 días (umbral 60).
- `requirement_without_acceptance`: 3. `requirement_without_owner`: 3. `requirement_accepted_without_evidence`: 1 (REQ-4504).
- `assumption_unverified`: 1, «La demanda se sostiene sin campaña», 194 días.
- Sin dato: criterio de éxito y quién decide.

### Lo que no hice
- No creé requerimientos: no hay tema nuevo que proponer.
- No tengo las transcripciones de las demás entrevistas. Con una sola cita no hay conteo de «N de N» que valga.
- No sellé la lectura: `sellar` se negó («la ficha producto.json no se escribió en esta corrida»). No escribí el sello a mano. La próxima corrida releerá los 5 documentos.

**1 pieza leída, ningún tema que el registro no tenga ya.**

### Después
Hace falta más material de entrevistas, con su transcripción, para que `/product-discovery` produzca temas. Para ver los vacíos del registro completo: `/product-requirements`.
