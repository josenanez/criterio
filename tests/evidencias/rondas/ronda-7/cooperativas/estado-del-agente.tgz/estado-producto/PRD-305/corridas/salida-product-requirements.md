## Registro — Microcrédito (PRD-305) · al 2026-10-17
17 requerimientos · 9 decididos · 88.9% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4504 | Requerimiento REQ-4504 | aceptado (decidido 2026-06-22) | Paula Céspedes |

Aceptado sin una sola cita de quien lo pidió.

Aviso sobre el 88.9%: las 14 evidencias que hay son la misma entrevista del 2025-09-06 («Lo necesito y hoy no lo tengo.», tema «Necesidad principal»), y la entrevista no nombra ninguno de estos requerimientos. Cuenta como evidencia en el registro, pero no sustenta ningún requerimiento en concreto.

### Decidido y nadie lo está construyendo
Los 9 aceptados no tienen proyecto (trazados: 0 de 9, 0%). No se encontró ninguna ficha de proyecto en `estado/`, así que tampoco hay con qué confirmar una traza.
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4502 | Requerimiento REQ-4502 | 2026-04-10 |
| REQ-4501 | Requerimiento REQ-4501 | 2026-05-08 |
| REQ-4504 | Requerimiento REQ-4504 | 2026-06-22 |
| REQ-4500 | Requerimiento REQ-4500 | 2026-06-23 |
| REQ-4514 | Requerimiento REQ-4514 | 2026-07-14 |
| REQ-4503 | Requerimiento REQ-4503 | 2026-07-19 |
| REQ-4511 | Requerimiento REQ-4511 | 2026-07-23 |
| REQ-4505 | Requerimiento REQ-4505 | 2026-08-29 |
| REQ-2037 | Requerimiento REQ-2037 | 2026-10-04 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4503 | Requerimiento REQ-4503 | sin doliente (aceptado) |
| REQ-4514 | Requerimiento REQ-4514 | sin doliente (aceptado) |
| REQ-4513 | Requerimiento REQ-4513 | sin doliente (propuesto, 161 días) |

Quién lo cerraría: la gerente de producto, María Restrepo, nombrando una persona por requerimiento.

### Sin criterio de aceptación
Solo los decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-2037 | Requerimiento REQ-2037 | aceptado |
| REQ-4501 | Requerimiento REQ-4501 | aceptado |
| REQ-4514 | Requerimiento REQ-4514 | aceptado |

Quién lo cerraría: el doliente de cada uno (Elena Duarte, Ricardo Salas y, para REQ-4514, quien sea nombrado doliente).

### Decidido sin documento que lo respalde
Ninguno. Los 9 aceptados remiten a `documentos/productos/PRD-305/30-decisiones/2026-10-17-comite-producto.docx`.

Nota: ese documento es del 2026-10-17, pero las fechas de decisión del registro van de 2026-04-10 a 2026-10-04. El documento no puede ser el acta original de las decisiones anteriores a su fecha; conviene que alguien lo confirme.

### Lleva meses y nadie lo decide
Umbral: 60 días. Los 8 propuestos lo superan.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4509 | Requerimiento REQ-4509 (Felipe Arango) | 206 días | no documentado |
| REQ-4510 | Requerimiento REQ-4510 (Elena Duarte) | 199 días | no documentado |
| REQ-4508 | Requerimiento REQ-4508 (Gustavo Neira) | 195 días | no documentado |
| REQ-4515 | Requerimiento REQ-4515 (Gustavo Neira) | 183 días | no documentado |
| REQ-4507 | Requerimiento REQ-4507 (Beatriz Cuéllar) | 173 días | no documentado |
| REQ-4513 | Requerimiento REQ-4513 (sin doliente) | 161 días | no documentado |
| REQ-4506 | Requerimiento REQ-4506 (Diana Molina) | 146 días | no documentado |
| REQ-4512 | Requerimiento REQ-4512 (Camilo Beltrán) | 72 días | no documentado |

La configuración dice `authority: not_found`: ningún documento dice quién decide. Ese es el vacío de fondo. La gerente de producto es María Restrepo, pero no consta que tenga la facultad de decidir. Propuesta: decidirlos o descartarlos en el próximo comité mensual, empezando por los más viejos. No se cierran por viejos.

### Evidencia vieja
Umbral: 12 meses. Los 14 requerimientos con evidencia se sostienen en lo mismo.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-2037, 4500, 4501, 4502, 4503, 4505, 4506, 4507, 4509, 4510, 4511, 4512, 4514, 4515 | Entrevista a cliente, 2025-09-06 | 13 meses |

### Además, en la definición
- Supuesto sin verificar: «La demanda se sostiene sin campaña», 194 días (umbral 30).
- Éxito de la definición y facultad de decisión: no están dichos en ningún documento.
- Cifra declarada contra medida: volumen mensual declarado 216.930 (2026-04-03) frente a 207.028 medido (2026-10-09), brecha 4.6%, bajo el umbral del 20%. No es hallazgo.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 8 | 9 | 0 | 0 | 0 |

Siguiente paso: hay 9 requerimientos decididos que nadie construye, así que se ofrece `/product-trace`. REQ-4500, 4502, 4503, 4505 y 4511 son aceptados, con evidencia y con criterio; de ellos solo REQ-4503 está sin doliente. Para convertir uno en proyecto, `/product-charter`.
