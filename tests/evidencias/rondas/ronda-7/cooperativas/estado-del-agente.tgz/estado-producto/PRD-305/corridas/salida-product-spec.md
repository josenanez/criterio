> **Borrador de la especificación de Microcrédito (PRD-305). Lo cierra María Restrepo, gerente de producto; este agente no aprueba.**

# Especificación — Microcrédito (PRD-305) · borrador del 2026-10-17

**Resultado en una línea:** el registro permite escribir el alcance, pero **no el comportamiento**. Ninguno de los 9 requerimientos aceptados tiene una necesidad descrita ni un título más allá de su código, y ningún criterio de aceptación pasa la prueba de «dos personas llegan a la misma respuesta». No relleno el comportamiento con lo razonable: queda como vacío con dueño.

## Qué problema resuelve
«El segmento Microempresarios no tiene microcrédito.» (definición, `documentos/productos/PRD-305/00-definicion/2026-04-03-definicion-producto.md`, 2026-04-03). El criterio de éxito del producto **no está dicho en ninguna parte** de la definición. Tampoco hay proyecto declarado que lo construya («Ninguno declarado»).

## Alcance
### Entra
Los 9 requerimientos en estado `aceptado`, según el acta del comité (`30-decisiones/2026-10-17-comite-producto.docx`): REQ-2037, REQ-4500, REQ-4501, REQ-4502, REQ-4503, REQ-4504, REQ-4505, REQ-4511, REQ-4514.

### No entra
- Los 8 requerimientos en `propuesto` (REQ-4506, 4507, 4508, 4509, 4510, 4512, 4513, 4515): nadie los ha decidido, y especificarlos sería escribir el documento dos veces. El más antiguo, REQ-4509, lleva propuesto desde 2026-03-25 (206 días; el umbral configurado es 60).
- Diseño técnico, estimación, costo y fechas: no son de este documento.
- Cualquier comportamiento que el registro no describa.

## Comportamiento
**No se redacta ninguna sección.** Cada requerimiento aceptado tiene la necesidad en `not_found` y su título es solo el código. Escribir comportamiento sería inventar lo que el comité decidió. Lo único que el registro sostiene por requerimiento:

| REQ | Dueño | Aceptado el | Evidencia de demanda |
|---|---|---|---|
| REQ-2037 | Elena Duarte | 2026-10-04 | Entrevista 2025-09-06 (genérica) |
| REQ-4500 | Camilo Beltrán | 2026-06-23 | Entrevista 2025-09-06 (genérica) |
| REQ-4501 | Ricardo Salas | 2026-05-08 | Entrevista 2025-09-06 (genérica) |
| REQ-4502 | Paula Céspedes | 2026-04-10 | Entrevista 2025-09-06 (genérica) |
| REQ-4503 | **sin dueño** | 2026-07-19 | Entrevista 2025-09-06 (genérica) |
| REQ-4504 | Paula Céspedes | 2026-06-22 | **ninguna** |
| REQ-4505 | Carlos Peña | 2026-08-29 | Entrevista 2025-09-06 (genérica) |
| REQ-4511 | Jorge Medina | 2026-07-23 | Entrevista 2025-09-06 (genérica) |
| REQ-4514 | **sin dueño** | 2026-07-14 | Entrevista 2025-09-06 (genérica) |

«Genérica»: la cita es «Lo necesito y hoy no lo tengo.» y la entrevista no nombra ningún requerimiento; es la misma frase para todos, así que no sustenta a ninguno en particular. En ningún caso consta quién tomó la decisión de aceptar.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4500, 4502, 4503, 4504, 4505, 4511 | No es verificable: no dice qué se observa, ni umbral, ni quién lo observa. Dos personas pueden discrepar. | **No.** No es un criterio; es un lugar donde se mirará. |
| *(ninguno)* | REQ-2037, REQ-4501, REQ-4514 | — | — |

No propongo un criterio sustituto: depende de la necesidad, que no está.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La demanda se sostiene sin campaña» (declarado 2026-04-06) | **No.** La definición dice «verificado con el documento técnico del proveedor del 2026-06-14»; ese documento no está en la carpeta, y su fecha es posterior a la de la definición (2026-04-03). | María Restrepo, aportando el documento o declarándolo sin verificar |

Contexto de cifras: el caso de negocio declara `volumen_mensual` = 216.930 (2026-04-03); el tablero mide 207.028 (corte 2026-10-09), un 4,6 % menos, por debajo del umbral de 20 % configurado. Pero la métrica **no tiene definición escrita** y la serie tiene un solo punto, así que no puede decirse si el volumen se sostiene o cae.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Necesidad y título de cada uno de los 9 requerimientos aceptados | No se puede escribir comportamiento; el equipo construiría lo que interprete | Cada dueño por requerimiento (tabla arriba); María Restrepo para REQ-4503 y REQ-4514 |
| Dueño de REQ-4503 y REQ-4514 | Aceptados sin doliente: nadie responde por ellos | María Restrepo |
| Criterio de aceptación de REQ-2037, 4501, 4514 | Sin forma de saber si quedó bien | Dueños: Elena Duarte, Ricardo Salas, y quien se asigne a REQ-4514 |
| Criterio verificable en lugar de «se verifica en producción» (6 requerimientos) | La discusión de si quedó bien ocurrirá después de construir | Dueños de REQ-4500, 4502, 4503, 4504, 4505, 4511 |
| Quién decidió aceptar cada requerimiento | La decisión no es rastreable; el acta no lo nombra | María Restrepo / secretaría del comité |
| Evidencia de demanda propia de REQ-4504 (ninguna) y específica para los demás | Aceptado sin que conste que alguien lo pidió | Paula Céspedes (REQ-4504); dueños del resto |
| Criterio de éxito del producto | Sin referencia para juzgar si el producto funcionó | María Restrepo |
| Casos borde (rechazo de solicitud, solicitud duplicada, cliente que abandona a mitad, falta de conexión) | No hay comportamiento definido; lo decidiría quien construya | María Restrepo con los dueños |
| Qué hace otro equipo (proyecto, riesgos, cobranza, canales) | No hay proyecto declarado ni acuerdo con ningún equipo; la trazabilidad a entregables está vacía en los 9 | María Restrepo; PMO para asignar proyecto |
| Obligaciones normativas | Un microcrédito toca consumidor financiero y datos personales, pero ningún documento del producto cita una obligación. No hago el barrido sin fuente ni opino sobre cumplimiento. | Cumplimiento/jurídico, a petición de María Restrepo |
| Definición de `volumen_mensual` | Los criterios basados en volumen no se pueden medir | María Restrepo / dueño del tablero |
| Autoridad del producto (`authority`: no encontrada) | No consta quién cierra este borrador con firma | Patrocinador del producto, por nombrar |

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-2037 | Requerimiento REQ-2037 | Sin necesidad ni criterio de aceptación |
| REQ-4500 | Requerimiento REQ-4500 | Sin necesidad; criterio no verificable |
| REQ-4501 | Requerimiento REQ-4501 | Sin necesidad ni criterio de aceptación |
| REQ-4502 | Requerimiento REQ-4502 | Sin necesidad; criterio no verificable |
| REQ-4503 | Requerimiento REQ-4503 | Sin necesidad ni dueño; criterio no verificable |
| REQ-4504 | Requerimiento REQ-4504 | Sin necesidad ni evidencia; criterio no verificable |
| REQ-4505 | Requerimiento REQ-4505 | Sin necesidad; criterio no verificable |
| REQ-4511 | Requerimiento REQ-4511 | Sin necesidad; criterio no verificable |
| REQ-4514 | Requerimiento REQ-4514 | Sin necesidad, dueño ni criterio de aceptación |

Los 9 quedan en alcance pero ninguno tiene sección de comportamiento, por eso aparecen todos aquí.

---
**Pie:** sale del registro `estado-producto/PRD-305/requirements/` (17 requerimientos: 9 aceptados, 8 propuestos), con documentos hasta 2026-10-17. Cubre 9 requerimientos en alcance, 0 con comportamiento redactado. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal (aceptados por José Francisco Ñáñez, 2026-10-17, v0.3.13). Borrador; lo cierra María Restrepo.

**Después:** no ofrezco `/product-charter`: los vacíos no están cerrados y no hay criterio de éxito del producto.
