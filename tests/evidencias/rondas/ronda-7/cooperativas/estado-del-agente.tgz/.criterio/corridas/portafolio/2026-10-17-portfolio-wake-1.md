# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:17:20 · **Fin:** 2026-10-17T15:18:05 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 31 | 66 | Barrido: 89 documentos sin cambios, 0 proyectos recalculados. Confirmación: 5 preguntas propuestas sobre PRY-200, sin respuesta (sesión sin interfaz). 15 citas del pm_record de PRY-200 no resuelven por ruta sin prefijo de carpeta; los archivos existen. No sé si esas rutas las corrige el publicador de la ficha. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## 2026-10-17

**Revisé:** 89 documentos · 0 cambiaron · 0 proyectos recalculados

Los términos están vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Hoy tocaban el barrido y la confirmación. El informe de comité toca el 2026-10-22, porque el comité es el 2026-10-24.

### Lo que cruzó un umbral
Nada. No hubo documentos nuevos, cambiados, renombrados ni borrados.

El índice marca 15 campos del `pm_record` de PRY-200 como «fuente no encontrada». Los archivos sí existen en la carpeta del proyecto. La ficha del portafolio cita con el prefijo de la carpeta del proyecto y esas citas resuelven. La copia de `pm_record` incrustada cita sin ese prefijo y no resuelven. Es una diferencia en la forma de la ruta, no un documento perdido. No la corregí. No sé si la corrige quien publica la ficha del proyecto.

### Peticiones atendidas
Ninguna. No había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión, así que no le pregunté a nadie. Dejé propuestas cinco preguntas sobre PRY-200. Son los campos de dinero y fecha de fin cuya cita no resolvía:
1. ¿Sigue vigente el presupuesto aprobado (COP 2.400.000.000)? Viene del acta de constitución del 2025-06-26.
2. Comprometido, del informe de avance del 2026-10-13.
3. Ejecutado, del mismo informe.
4. Proyección, del mismo informe.
5. Fecha de fin, del cronograma v1 del 2025-06-26. ¿Es la vigente o hubo replanificación?

Tomé la respuesta sugerida: dejarlas abiertas, sin respuesta.

**Vuelvo el 2026-10-18.**

La corrida quedó registrada como `2026-10-17-portfolio-wake-1`. Duró 31 segundos. El cálculo de documentos leídos no quedó medido.
