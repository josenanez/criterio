# Corrida · 2026-10-17-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:18:09 · **Fin:** 2026-10-17T15:18:39 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 66 | puerto 8787, carpeta del informe reportes, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Rostrum está corriendo en `http://127.0.0.1:8787/`, en modo «para mirarlo un rato». Lo abrí con `curl` a `/estado.json` y respondió. No miré las otras páginas ni abrí ningún navegador.

- **Pregunta del modo:** nadie podía responder, así que tomé la sugerida (empezar por «rato»).
- **Términos:** ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17), así que no los volví a pedir.
- **Quién lo ve:** solo este equipo (`127.0.0.1`). El proceso quedó en segundo plano y su salida va a `/tmp/claude-0/rostrum.log`. Para pararlo, termina el proceso de `servidor.py`.
- **Qué sirve:** la carpeta `reportes/` con los 13 proyectos (PRY-199 a PRY-211) y 8 productos. Lo marca como «Cooperativa» porque le pasé la configuración.
- **Rutas:** `/`, `/pmo`, `/decisiones`, `/proyectos`, `/productos`, `/corridas` (32) y `/estado.json`.
- **Peticiones:** hay 0 abiertas.
- **Registro:** la salida está en `estado/corridas/salida-portfolio-server.md` y la corrida quedó como `2026-10-17-portfolio-server-1`.

**Qué enlace a quién:** `http://127.0.0.1:8787/` solo sirve a quien lo levantó. Si el patrocinador necesita un enlace que funcione mañana, hace falta el modo «que quede corriendo». Eso requiere un host y un puerto internos, publicados detrás del control de acceso de la organización, porque el servidor no autentica. Conviene tener esa conversación con seguridad después de haberlo visto funcionar.

**Cuándo se desactualiza:** el informe es del 2026-10-17 a las 20:16 UTC. Regenéralo con `/portfolio-report html` antes del comité del 2026-10-24, con 2 días de antelación según la configuración.
