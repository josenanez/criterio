# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-205 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-17T15:11:01 · **Fin:** 2026-10-17T15:11:48 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 33 | 66 | Revisión del acta PRY-205 (2025-07-09): falta autoridad del gerente, supuestos/restricciones, hitos, cadencia, quién mide el éxito; objetivo, alcance y exclusiones son marcadores vacíos. Cierre 2026-01-01 vencido 289 días sin línea base nueva. No sé si hay autoridad delegada fuera de la carpeta ni qué cubre cada componente; originales en documentos/proyectos ausentes, se leyó el caché. |

Por señal (`project-charter`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

El acta de PRY-205 (Prevención de lavado de activos) tiene los campos de gobierno casi vacíos. Falta la autoridad del gerente, los supuestos y restricciones, los hitos, la cadencia y quién mide el éxito. La corrida quedó registrada como `2026-10-17-project-charter-1`.

- **Acta previa:** sí existe una, del 2025-07-09. Es la única de la carpeta, sin cronograma.
- **Términos:** ya estaban vigentes, versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré otra vez.
- **Autoridad del gerente:** no figura. Nada dice hasta qué monto ni qué cambio puede decidir Ricardo Salas sin subir al Comité de Riesgos. La proyección (COP 4.267.213.372) ya supera lo aprobado (COP 4.200.000.000) en COP 67.213.372, y nadie tiene declarado quién lo resuelve.
- **Campos con marcadores vacíos:**
  - El objetivo repite el nombre del proyecto.
  - El alcance es "Componente 1, 2, 3", sin descripción.
  - La exclusión es "Lo que otro proyecto cubre", sin nombrar cuál.
  - El criterio de éxito, "en producción y medido", no tiene métrica ni dueño.
- **Plazo:** el cierre comprometido (2026-01-01) lleva 289 días vencido. No hay línea base nueva ni solicitud de cambio que lo reconozca. El informe del 2026-09-27 declara "amarillo, 55 %" sin mencionarlo.
- **Presupuesto:** el informe del 2026-09-27 reporta ejecutado (COP 1.684.933.618) mayor que comprometido (COP 1.472.743.776), lo cual es inusual. Lo dejé como punto a aclarar con el gerente, sin interpretarlo.
- **Lo que no sé:**
  - Si existe una autoridad delegada en alguna política fuera de la carpeta.
  - Qué cubre cada componente.
  - Si hubo decisiones del comité sobre el cierre vencido.
- **Fuentes:** la carpeta de originales `documentos/proyectos` está vacía en esta sesión. Leí el texto convertido del caché, cuya cabecera apunta al original.
- **Para el comité:** propongo llevar la definición de la autoridad del gerente al Comité de Riesgos. Los supuestos faltantes pueden pasar al registro RAID. No ejecuté ninguno de los dos.

La salida completa quedó en `estado/corridas/salida-project-charter.md`. El registro de la corrida cuenta 13 proyectos y 66 hallazgos de todo el portafolio, no solo de PRY-205.
