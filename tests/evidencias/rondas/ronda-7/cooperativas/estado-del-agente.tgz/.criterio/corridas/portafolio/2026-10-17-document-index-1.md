# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:00:52 · **Fin:** 2026-10-17T15:01:31 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 26 | 66 | 89 documentos, 0 por releer, 0 cambios. 15 citas de PRY-200 marcadas source_missing aunque los archivos citados existen; probable diferencia de ruta (prefijo del proyecto), sin confirmar. |

Por señal (`document-index`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

No cambió el contenido de ningún documento. Tampoco hay documentos solo reguardados, renombrados, movidos ni borrados. No hace falta correr `/portfolio-scan`.

**Citas que no resuelven:** el índice marca 15 citas de PRY-200 como `source_missing`. Los tres archivos citados sí están en la carpeta del proyecto:
- `00-gobierno/2025-06-26-acta-constitucion.docx`: 11 campos.
- `10-plan/2025-06-26-cronograma-v1.csv`: `plan.end_date`.
- `20-seguimiento/2026-10-13-informe-avance.md`: `money.committed`, `executed` y `projection`.

Es probable que sea un fallo de rutas, no una cita rota. La ficha cita con el prefijo del proyecto (`PRY-200-crédito-de-libranza-digital/00-gobierno/…`) y el índice reporta la ruta sin ese prefijo. No lo verifiqué en el código del script. Lo dejé escrito como una señal por confirmar.

No hubo formatos ilegibles, porque este comando no lee documentos.

**Términos:** ya estaban vigentes para la versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17, así que no registré una aceptación nueva.

**Corrida:** quedó registrada como `2026-10-17-document-index-1` (26 segundos, 13 proyectos). La salida está en `estado/corridas/salida-document-index.md`.

La corrida también devolvió 66 hallazgos abiertos de corridas anteriores, entre ellos 23 de `milestone_met_without_evidence`. No salen de este índice.
