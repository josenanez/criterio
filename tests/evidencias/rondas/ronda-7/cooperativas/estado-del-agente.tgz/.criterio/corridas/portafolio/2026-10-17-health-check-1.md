# Corrida · 2026-10-17-health-check-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:health-check PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-17T15:02:18 · **Fin:** 2026-10-17T15:04:45 · **Duración:** 147 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `health-check` | 13 | — | 130 | 66 | Diagnóstico de PRY-202 desde 9 documentos. Dictamen: 4 sostenidas, 9 sin sustento, 2 contradichas. Dijo que no se puede saber el avance real, la fecha de cierre vigente, lo pagado a CT-645 ni la conciliación de comprometido y ejecutado. No recomendó detener ni continuar. |

Por señal (`health-check`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé el diagnóstico de PRY-202 (Core cooperativo). La carpeta no permite saber el avance real del proyecto.

Los términos ya estaban vigentes (v1.1), así que no los registré de nuevo. Leí los 9 documentos del proyecto, del 2025-06-22 al 2026-10-15. Ningún otro proyecto del portafolio habla de PRY-202.

De las 15 afirmaciones que evalué, 4 quedan sostenidas, 9 sin sustento y 2 contradichas.

- **Sostenido:** el estado rojo declarado y el presupuesto aprobado (4.200.000.000 COP). También se sostiene la bolsa de horas de CT-171, recibida con acta y facturada.
- **Avance:** el cronograma v1 marca los 5 hitos como cerrados, y el informe del 2026-10-15 dice 46% y rojo. Solo hay acta de recibo de uno de los cinco hitos.
- **Contradicho:** el ambiente de pruebas figura cerrado el 2025-11-09 y su acta es del 2026-10-09. «Salida a producción» figura cerrada, pero el informe dice que la prueba de carga se repite.
- **Fecha de cierre:** el cierre previsto, 2026-05-23, pasó hace 147 días. No hay cronograma v2, solicitud de cambio ni autoridad declarada que apruebe una fecha nueva.
- **Dinero:** el ejecutado (1.958.849.265) es mayor que el comprometido (1.682.354.379) dentro del mismo informe. No hay factura ni acta de CT-645.
- **Sin registrar:** dos riesgos y tres incidencias del informe no están en ningún registro, y el acta dice «dependencias: ninguna». El compromiso de Paula Céspedes no tiene fecha, ella no asistió a la reunión y el «punto 4» no existe en la minuta.

No recomendé detener ni continuar. Ofrezco preparar el punto de comité con lo que falta, o llevar las contradicciones al gerente como preguntas, una por una.

La corrida quedó registrada como `2026-10-17-health-check-1`. Las cifras derivadas (días, porcentajes, disponible real) salen de `compute`. Ese cálculo corre sobre la ficha que ya existía de PRY-202, y contrasté sus valores con los 9 documentos. El pie de rigor no está definido en el plugin, así que escribí uno propio.

Archivos en `/home/claude/banco/ronda-7/cooperativas/espacio/estado/corridas/`:
- `salida-health-check.md`
