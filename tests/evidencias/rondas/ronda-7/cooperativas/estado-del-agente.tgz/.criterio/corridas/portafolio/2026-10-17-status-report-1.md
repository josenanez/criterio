# Corrida · 2026-10-17-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-205

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-205

**Inicio:** 2026-10-17T15:01:36 · **Fin:** 2026-10-17T15:02:14 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 24 | 66 | Estado de PRY-205: declarado amarillo 55% sin sustento documental; silencio de 20 días; cierre 2026-01-01 vencido sin línea base nueva ni hitos. No se sabe: reuniones, cronograma, producto, autoridad, fase. |

Por señal (`status-report`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé el informe de estado de PRY-205 y dejé la corrida registrada como `2026-10-17-status-report-1`. El informe completo está en `estado/corridas/salida-status-report.md`.

**PRY-205 · Prevención de lavado de activos, al 2026-10-17**
- **Lo que declara el gerente:** Ricardo Salas reporta amarillo y 55 % de avance, con fecha 2026-09-27.
- **Sustento documental:** ninguno. De los 14 documentos de la ficha, ninguno está marcado como evidencia. El único de seguimiento es el propio informe de avance.
- **Silencio:** lleva 20 días sin un documento nuevo, y el umbral es de 15. El semáforo declarado no lo explica.
- **Plan:** el cierre estaba fijado en 2026-01-01 y ya pasó. No hay línea base nueva, replanificaciones registradas ni hitos, así que el script da 0 días de desviación. Eso es falta de registro, no cumplimiento.
- **Presupuesto:** aprobado COP 4.200.000.000, con una proyección de +1,6 %. El ejecutado (COP 1.684.933.618) supera al comprometido (COP 1.472.743.776), y ningún otro documento lo aclara.
- **Abierto:** hay un hallazgo de seguridad y una reprogramación de la salida, ambos sin dueño desde 2026-09-27. También hay un riesgo de concentración del conocimiento sin valorar.
- **Sin dato:** producto, autoridad, fase, reuniones y cronograma. Once campos del acta tienen 15 meses de antigüedad.

**Pendiente (no lo preparé):** el punto de comité para el Comité de Riesgos (2026-10-24) y una solicitud de cambio que formalice la nueva fecha de cierre.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada nuevo. Nadie respondió preguntas, como se pidió.
