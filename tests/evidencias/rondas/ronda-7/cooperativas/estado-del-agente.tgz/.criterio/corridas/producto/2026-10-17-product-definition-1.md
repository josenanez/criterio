# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:38:48 · **Fin:** 2026-10-17T14:39:31 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 17 | — | 27 | 39 | La evidencia sostiene poco: una entrevista de 13 meses y una cifra a 4,6 % del tablero; criterio de éxito y quién decide no están dichos |

Por señal (`product-definition`): `evidence_stale` 14, `requirement_untraced` 9, `requirement_undecided` 8, `requirement_without_acceptance` 3, `requirement_without_owner` 3, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1

## Lo que el agente mostró

Contrasté la definición de Microcrédito (PRD-305) contra la evidencia: sostiene poco. Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-17), así que no los pedí de nuevo. La salida completa quedó en `estado-producto/PRD-305/corridas/salida-product-definition.md` y la corrida se registró con el id `2026-10-17-product-definition-1`.

- **Qué se contrastó:** 6 afirmaciones de la definición y el caso de negocio, ambos del 2026-04-03.
- **Contradicciones:** ninguna. El volumen_mensual declarado es 216.930 y el medido es 207.028 (tablero del 2026-10-09). La diferencia es 4,6 %, por debajo del umbral de 20 %. Es una sola observación y la métrica no tiene definición.
- **Afirmación numérica que nadie mide:** el retorno esperado «en 24 meses». No trae cifra ni serie.
- **Evidencia de la necesidad:** es una sola entrevista de 13 meses (2025-09-06), con una cita sin contenido: «Lo necesito y hoy no lo tengo.» El umbral de antigüedad es 12 meses. Sostiene el problema y el segmento, y también 14 requerimientos del registro.
- **Supuesto sin verificar:** «La demanda se sostiene sin campaña» lleva 194 días. La definición dice que está verificado con un documento técnico del proveedor del 2026-06-14, pero ese documento no está en la carpeta.
- **No está dicho en ninguna parte:**
  - el criterio de éxito;
  - quién decide;
  - qué es la «Propuesta principal» (es un marcador vacío);
  - qué incluye «microcrédito»;
  - qué mide volumen_mensual;
  - qué proyecto lo construye.
- **Lo normativo:** toca datos personales, consumidor financiero y retención de información. Ningún documento dice el país, así que lo dejé como «no tengo la norma a la vista» y no cité ninguna norma.
- **Para cerrar la definición:** faltan el criterio de éxito y quién decide. Mientras falten, no corresponde `/product-charter`. Conviene registrar el supuesto de la demanda como riesgo con doliente.
