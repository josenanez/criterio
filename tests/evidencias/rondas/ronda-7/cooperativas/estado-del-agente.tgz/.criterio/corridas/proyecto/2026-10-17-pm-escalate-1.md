# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:51:03 · **Fin:** 2026-10-17T14:52:05 · **Duración:** 62 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 44 | 12 | Dos puntos: autoridad no declarada en el acta, y sobrecosto de +244.653.523 (10,19 %). No calculé impact: ningún documento propone días. No consta el costo de la opción B ni la fecha de cierre nueva. |

Por señal (`pm-escalate`): `commitment_overdue` 4, `milestone_met_without_evidence` 2, `commitment_undated` 2, `commitment_rescheduled` 2, `progress_vs_plan` 1, `variance_cost` 1

## Lo que el agente mostró

## Para decisión — Crédito de libranza digital (PRY-200) · 2026-10-17

Armé el paquete de escalamiento de PRY-200 con dos puntos. Dos datos no los tengo y quedan declarados en el paquete: el efecto sobre otros proyectos y el costo de una de las opciones.

**Términos:** ya estaban vigentes y registrados a nombre de José Francisco Ñáñez (2026-10-17). No pedí aceptación de nuevo.

### Punto 0: ¿quién puede decidir qué?
- **El problema:** el acta de constitución no declara la autoridad del gerente, así que este punto va primero.
- **Pregunta cerrada:** ¿Se confirma por escrito que los cambios de presupuesto sobre los COP 2.400.000.000 los decide el Consejo de Administración y las reprogramaciones de compromisos, Jorge Medina?
- **Si no se decide hoy:** el comité del 2026-10-31 puede decidir el punto 1 sin tener la facultad, y la decisión se devuelve.

### Punto 1: sobrecosto proyectado
- **Pregunta cerrada:** ¿Se ajusta el presupuesto a la proyección de COP 2.644.653.523 (+COP 244.653.523, +10,19 %), o se mantiene en COP 2.400.000.000 y se recorta alcance?
- **Quién decide:** el Consejo de Administración, que aprobó el presupuesto original. Es lo más probable, pero el acta no lo declara.
- **Opciones:**
  - **A, aprobar la proyección:** cuesta +COP 244.653.523. No hay fecha de cierre nueva en ningún documento.
  - **B, mantener COP 2.400.000.000:** habría que recortar alcance, y ningún documento dice qué ni cuánto cuesta. Este costo queda como "no consta".
- **Si no se decide hoy:** ningún documento trae una fecha de vencimiento, y no la inventé. El punto se aplaza con cada comité sin decisión; el próximo es el 2026-10-31.
- **Recomiendo A**, con la condición de que venga con fecha de cierre nueva. El cierre vigente (2026-01-08) pasó hace 282 días, con avance declarado de 28 % y estado rojo. Esto es recomendación mía, no un dato del expediente.
- **Control de cambios:** al aprobarse, entra como línea base v2 y la v1 no se toca.

### Lo que no calculé
- **`impact`:** no lo corrí, porque ningún documento propone un cambio de fecha y habría tenido que inventar los días.
- **Proyectos y hitos alcanzados:** quedan "no calculado". El acta declara "ninguna dependencia", lo que no prueba que no haya otros proyectos afectados.
- **Opción B:** Laura Vélez quedó de mandar "el ajuste del presupuesto la otra semana", sin fecha. Probablemente esa pieza llene las celdas que faltan.

### Lo que no escala
Las reprogramaciones de Gustavo Neira y Sandra Gil cumplen el criterio, pero ya son los puntos 1 y 2 de la agenda del 2026-10-31. Quién acepta una reprogramación es el punto 0. Los vencidos de Felipe Arango, Laura Vélez y Carlos Peña se destraban con una llamada.

La corrida quedó registrada como `2026-10-17-pm-escalate-1`: 44 segundos, 1 proyecto, 12 señales abiertas.

Archivos están en `estado/PRY-200-crédito-de-libranza-digital/corridas/`:
- `salida-pm-escalate.md`
