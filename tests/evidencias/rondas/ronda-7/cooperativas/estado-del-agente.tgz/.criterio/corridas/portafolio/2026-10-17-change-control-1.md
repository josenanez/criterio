# Corrida · 2026-10-17-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-17T15:06:46 · **Fin:** 2026-10-17T15:07:36 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 35 | 66 | Solicitud PRY-201 +30 días (2026-11-08 a 2026-12-08). Impacto en portafolio 0 porque no hay dependencias declaradas. Dijo que no sabe: quién pide y por qué, impacto en alcance y costo, autoridad de cambios (no está en el acta), vigencia de CT-797 y CT-856, días por actividad. Va a comité por defecto. |

Por señal (`change-control`): `milestone_met_without_evidence` 23, `vendor_deliverable_late` 9, `progress_vs_plan` 8, `commitment_overdue` 6, `commitment_undated` 4, `declared_vs_evidence` 3, `variance_time` 3, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `milestone_overdue` 2, `silent` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Armé la solicitud de cambio de PRY-201 para mover la salida a producción de 2026-11-08 a 2026-12-08 (+30 días). Va a comité, porque el acta no declara quién puede aprobar cambios, y la corrida quedó registrada. Salí de la ficha de PRY-201 (Apertura de ahorro en línea), que hoy tiene una sola línea base, la v1 del 2026-03-22.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los volví a registrar.

**Impacto**
- **Tiempo:** +30 días, un 13,0 % sobre los 231 días del plan. Faltan 22 días para el cierre actual.
- **Costo:** la solicitud no declara ningún monto, así que el costo de esos 30 días no lo estimé. Aun sin ellos, la proyección (COP 1.236.335.536) ya supera lo aprobado (COP 1.200.000.000) en COP 36.335.536, un 3,0 %.
- **Alcance:** tampoco está declarado. La solicitud no dice quién absorbe 30 días más de equipo y proveedores.
- **Portafolio:** el cálculo da 0 proyectos afectados, pero solo porque PRY-201 no tiene dependencias declaradas. No significa que no haya efecto. Tampoco hay holgura por actividad, así que no sé cuántos días se movería cada una.

**Quién decide**
- El acta no declara autoridad de cambios. Por defecto va al comité, cuyo próximo encuentro es el 2026-10-24.
- No registré una línea base nueva, porque nadie con autoridad la ha aprobado.

**Contexto que pesa**
- El informe de avance del 2026-10-16 dice que la salida ya se reprogramó por el cierre contable de fin de mes. No existe un cronograma posterior a v1 que lo registre, así que aprobar esto formaliza algo ya decidido sin documento.
- El proyecto está en rojo, con 62 % de avance, un hallazgo de seguridad abierto y un riesgo normativo, ambos sin responsable.
- CT-856 tiene dos entregables vencidos sin acta de recibo.
- No sé cuándo vencen CT-797 y CT-856, así que no puedo decir si alcanzan al 2026-12-08.

**Lo que falta para completar el paquete:** quién pide el cambio y su motivo por escrito, el impacto en alcance y costo, la autoridad de cambios y las dependencias de PRY-201 con otros proyectos.

El texto completo está en `estado/corridas/salida-change-control.md`. La corrida se registró como `2026-10-17-change-control-1`.
