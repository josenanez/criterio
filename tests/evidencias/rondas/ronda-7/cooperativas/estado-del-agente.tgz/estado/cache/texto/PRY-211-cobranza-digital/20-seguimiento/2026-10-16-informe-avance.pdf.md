<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-16
Gerente: Felipe Arango

Estado declarado
Amarillo
Avance reportado: 74%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 13.761.216.501
Ejecutado 7.270.682.904
Proyección al cierre 18.775.312.801

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
