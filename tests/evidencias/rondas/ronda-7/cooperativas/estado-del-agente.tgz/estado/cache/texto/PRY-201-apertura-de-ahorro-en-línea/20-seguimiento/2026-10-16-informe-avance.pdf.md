<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-16
Gerente: Óscar Ramírez

Estado declarado
Rojo
Avance reportado: 62%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 513.279.152
Ejecutado 523.807.850
Proyección al cierre 1.236.335.536

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
