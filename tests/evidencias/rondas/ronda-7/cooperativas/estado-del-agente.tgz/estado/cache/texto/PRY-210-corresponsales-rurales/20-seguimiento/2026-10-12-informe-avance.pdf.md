<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Corresponsales rurales
Código: PRY-210
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 73%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se ajustó el plan de pruebas con el área de seguridad
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.429.106.824
Ejecutado 1.479.278.446
Proyección al cierre 3.153.806.778

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
