<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2026-03-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-15,2026-05-15,cerrado
Ambiente de pruebas certificado,2026-06-28,2026-06-28,cerrado
Integración con el core cooperativo,2026-08-12,2026-08-12,cerrado
Piloto con asociados,2026-09-25,2026-09-25,cerrado
Salida a producción,2026-11-08,2026-11-08,en curso
