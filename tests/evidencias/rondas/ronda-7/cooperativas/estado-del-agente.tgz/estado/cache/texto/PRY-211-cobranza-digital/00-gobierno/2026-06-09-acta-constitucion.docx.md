<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-06-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Bienestar social

Patrocinador: Andrés Lozano

Gerente de proyecto: Felipe Arango

Comité: Comité de Riesgos

Producto asociado: recaudos

Fecha de aprobación: 2026-06-09

Objetivo del negocio

Entregar cobranza digital para Bienestar social.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Riesgos el 2026-06-09.

Fechas comprometidas

Fecha

Inicio

2026-06-19

Cierre

2027-10-03

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
