<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-10-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-10
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-11-20 |
| Sandra Gil | Cerrar la prueba 2 | 2026-12-07 |
| Felipe Arango | Entregar el punto 8 | 2026-10-24 |
| Gustavo Neira | Enviar el documento 9 | 2026-11-01 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-11-11 |
| Sandra Gil | Entregar el punto 16 | 2026-11-29 |
| Felipe Arango | Enviar el documento 17 | 2026-10-07 |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-08 |
| Jorge Medina | Revisar el anexo 19 | 2026-10-21 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-20 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-16 |
| María Restrepo | Confirmar la fecha 23 | 2026-10-19 |
| Beatriz Cuéllar | Entregar el punto 24 | 2026-11-07 |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Javier Hoyos): recibido, acta de recibo del 2026-10-10.
- Cerrar la prueba 10 (Elena Duarte): recibido, acta de recibo del 2026-10-10.
- Aprobar el diseño 13 (Carlos Peña): recibido, acta de recibo del 2026-10-10.
- Actualizar la matriz 14 (Beatriz Cuéllar): recibido, acta de recibo del 2026-10-10.
- Confirmar la fecha 15 (Mauricio Pérez): recibido, acta de recibo del 2026-10-10.
- Validar el ambiente 20 (Liliana Torres): recibido, acta de recibo del 2026-10-10.
