<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-13
**Gerente:** Rubén Cárdenas

## Estado declarado

**Rojo**

Avance reportado: **28%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.398.098.317 |
| Ejecutado | 929.267.306 |
| Proyección al cierre | 2.644.653.523 |

## Riesgos abiertos

- Cambio normativo del supervisor que puede mover el alcance
- Concentración del conocimiento en una sola persona
