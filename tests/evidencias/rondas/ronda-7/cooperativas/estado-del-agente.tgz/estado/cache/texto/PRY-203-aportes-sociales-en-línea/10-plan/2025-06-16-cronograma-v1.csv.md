<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2025-06-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-09-02,2025-09-02,cerrado
Ambiente de pruebas certificado,2025-11-10,2025-11-10,cerrado
Integración con el core cooperativo,2026-01-17,2026-01-17,cerrado
