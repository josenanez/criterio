<!-- origen: PRY-206-pagos-con-qr/00-gobierno/2025-05-12-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pagos con QR

Código: PRY-206

Área dueña: Operaciones

Patrocinador: María Restrepo

Gerente de proyecto: Andrés Lozano

Comité: Consejo de Administración

Producto asociado: pagos QR

Fecha de aprobación: 2025-05-12

Objetivo del negocio

Entregar pagos con qr para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Consejo de Administración el 2025-05-12.

Fechas comprometidas

Fecha

Inicio

2025-05-22

Cierre

2026-03-25

Criterio de éxito

Pagos con QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
