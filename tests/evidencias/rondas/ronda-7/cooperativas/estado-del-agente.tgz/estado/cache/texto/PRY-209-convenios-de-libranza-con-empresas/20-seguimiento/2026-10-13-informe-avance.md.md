<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Convenios de libranza con empresas

**Código:** PRY-209
**Fecha de corte:** 2026-10-13
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **58%**

## Lo que pasó en el periodo

- Se reprogramó la salida por el cierre contable de fin de mes
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.124.921.446 |
| Ejecutado | 1.322.736.441 |
| Proyección al cierre | 3.304.090.349 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio normativo del supervisor que puede mover el alcance
