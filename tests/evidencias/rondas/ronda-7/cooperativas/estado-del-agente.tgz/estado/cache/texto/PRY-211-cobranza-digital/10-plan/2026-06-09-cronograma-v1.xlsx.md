<!-- origen: PRY-211-cobranza-digital/10-plan/2026-06-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-11-23 | 2026-11-23 | en curso
Ambiente de pruebas certificado | 2027-04-29 | 2027-04-29 | en curso
Integración con el core cooperativo | 2027-10-03 | 2027-10-03 | en curso
