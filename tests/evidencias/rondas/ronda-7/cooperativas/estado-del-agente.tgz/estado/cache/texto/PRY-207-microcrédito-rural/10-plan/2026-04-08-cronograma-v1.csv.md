<!-- origen: PRY-207-microcrédito-rural/10-plan/2026-04-08-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-10-05,2026-10-05,en curso
Ambiente de pruebas certificado,2027-03-25,2027-03-25,en curso
Integración con el core cooperativo,2027-09-11,2027-09-11,en curso
