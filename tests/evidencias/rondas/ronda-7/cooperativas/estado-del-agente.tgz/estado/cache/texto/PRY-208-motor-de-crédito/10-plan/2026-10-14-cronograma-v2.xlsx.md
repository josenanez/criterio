<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-28 | 2026-06-28 | cerrado
Ambiente de pruebas certificado | 2026-09-07 | 2026-09-07 | cerrado
Integración con el core cooperativo | 2026-11-17 | 2026-11-17 | en curso
Piloto con asociados | 2027-01-26 | 2027-03-26 | en curso
