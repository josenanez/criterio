<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-10-15-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Tarjeta débito para asociados
**Fecha:** 2026-10-15
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +116 días sobre la línea base vigente |
| Costo | 232.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
