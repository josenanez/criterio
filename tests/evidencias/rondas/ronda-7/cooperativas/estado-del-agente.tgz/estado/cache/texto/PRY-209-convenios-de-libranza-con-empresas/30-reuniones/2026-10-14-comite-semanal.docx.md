<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Crédito · Convenios de libranza con empresas

Fecha: 2026-10-14

Asistentes: Camilo Beltrán, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 10

2026-10-19
