<!-- origen: PRY-210-corresponsales-rurales/10-plan/2025-05-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-02,2025-11-02,cerrado
Ambiente de pruebas certificado,2026-04-05,2026-04-05,cerrado
Integración con el core cooperativo,2026-09-06,2026-09-06,cerrado
