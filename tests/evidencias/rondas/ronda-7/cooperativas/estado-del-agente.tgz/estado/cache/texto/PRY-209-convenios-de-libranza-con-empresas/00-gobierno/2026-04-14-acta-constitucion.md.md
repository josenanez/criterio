<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2026-04-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Convenios de libranza con empresas

**Código:** PRY-209
**Área dueña:** Canales digitales
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Crédito
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-14

## Objetivo del negocio

Entregar convenios de libranza con empresas para Canales digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Crédito el 2026-04-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-24 |
| Cierre | 2027-09-10 |

## Criterio de éxito

Convenios de libranza con empresas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
