<!-- origen: PRY-202-core-cooperativo/00-gobierno/2025-06-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core cooperativo

Código: PRY-202

Área dueña: Tesorería

Patrocinador: Javier Hoyos

Gerente de proyecto: Ricardo Salas

Comité: Comité de Crédito

Producto asociado: No aplica

Fecha de aprobación: 2025-06-23

Objetivo del negocio

Entregar core cooperativo para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Crédito el 2025-06-23.

Fechas comprometidas

Fecha

Inicio

2025-07-03

Cierre

2026-05-23

Criterio de éxito

Core cooperativo en producción y medido.

Dependencias declaradas

• Ninguna declarada
