<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core cooperativo
Código: PRY-202
Fecha de corte: 2026-10-15
Gerente: Ricardo Salas

Estado declarado
Rojo
Avance reportado: 46%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.682.354.379
Ejecutado 1.958.849.265
Proyección al cierre 3.898.984.622

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
