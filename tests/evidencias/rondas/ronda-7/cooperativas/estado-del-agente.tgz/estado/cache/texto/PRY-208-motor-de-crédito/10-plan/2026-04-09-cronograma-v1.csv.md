<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-04-09-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-06-28,2026-06-28,cerrado
Ambiente de pruebas certificado,2026-09-07,2026-09-07,cerrado
Integración con el core cooperativo,2026-11-17,2026-11-17,en curso
Piloto con asociados,2027-01-26,2027-01-26,en curso
