<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-06-26-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-08-21,2025-08-21,cerrado
Ambiente de pruebas certificado,2025-10-07,2025-10-07,cerrado
Integración con el core cooperativo,2025-11-23,2025-11-23,cerrado
Piloto con asociados,2026-01-08,2026-01-08,cerrado
