<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-19
**Asistentes:** Camilo Beltrán, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Mauricio Pérez, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-10-05 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-15 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-09-27 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-10-09 |
| Felipe Arango | Entregar el punto 8 | por definir |
| Gustavo Neira | Enviar el documento 9 | 2026-09-29 |
| Elena Duarte | Cerrar la prueba 10 | 2026-10-10 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-10-07 |
| Javier Hoyos | Validar el ambiente 12 | por definir |

## Cerrados en esta reunión

- Revisar el anexo 3 (Paula Céspedes): recibido, acta de recibo del 2026-09-19.
- Validar el ambiente 4 (Laura Vélez): recibido, acta de recibo del 2026-09-19.

## Lo que se dijo

- Paula Céspedes dice que ya entregó «confirmar la fecha 7». No se presentó acta.
