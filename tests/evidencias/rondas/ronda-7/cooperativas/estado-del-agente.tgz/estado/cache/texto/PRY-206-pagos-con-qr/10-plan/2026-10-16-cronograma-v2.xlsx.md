<!-- origen: PRY-206-pagos-con-qr/10-plan/2026-10-16-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-07-22 | 2025-07-22 | cerrado
Ambiente de pruebas certificado | 2025-09-21 | 2025-09-21 | cerrado
Integración con el core cooperativo | 2025-11-22 | 2025-11-22 | cerrado
Piloto con asociados | 2026-01-22 | 2026-01-22 | cerrado
Salida a producción | 2026-03-25 | 2026-04-30 | cerrado
