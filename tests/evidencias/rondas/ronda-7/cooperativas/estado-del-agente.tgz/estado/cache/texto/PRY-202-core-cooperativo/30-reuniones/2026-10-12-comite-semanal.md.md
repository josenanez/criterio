<!-- origen: PRY-202-core-cooperativo/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Core cooperativo

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 4 | por definir |
