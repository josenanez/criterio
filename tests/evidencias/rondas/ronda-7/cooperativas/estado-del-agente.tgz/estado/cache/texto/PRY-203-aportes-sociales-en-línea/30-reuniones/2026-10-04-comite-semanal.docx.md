<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Educación · Aportes sociales en línea

Fecha: 2026-10-04

Asistentes: María Restrepo, Óscar Ramírez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Jorge Medina

Entregar el punto 13

2026-10-14
