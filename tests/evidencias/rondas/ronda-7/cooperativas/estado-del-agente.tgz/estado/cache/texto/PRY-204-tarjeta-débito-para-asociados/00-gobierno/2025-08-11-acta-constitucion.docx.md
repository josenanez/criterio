<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2025-08-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tarjeta débito para asociados

Código: PRY-204

Área dueña: Riesgo y Cumplimiento

Patrocinador: Laura Vélez

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Riesgos

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-08-11

Objetivo del negocio

Entregar tarjeta débito para asociados para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Riesgos el 2025-08-11.

Fechas comprometidas

Fecha

Inicio

2025-08-21

Cierre

2026-10-04

Criterio de éxito

Tarjeta débito para asociados en producción y medido.

Dependencias declaradas

• Ninguna declarada
