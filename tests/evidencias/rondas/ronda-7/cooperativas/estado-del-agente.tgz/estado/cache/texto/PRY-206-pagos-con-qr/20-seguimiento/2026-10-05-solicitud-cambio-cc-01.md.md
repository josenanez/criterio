<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Pagos con QR
**Fecha:** 2026-10-05
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +36 días sobre la línea base vigente |
| Costo | 72.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
