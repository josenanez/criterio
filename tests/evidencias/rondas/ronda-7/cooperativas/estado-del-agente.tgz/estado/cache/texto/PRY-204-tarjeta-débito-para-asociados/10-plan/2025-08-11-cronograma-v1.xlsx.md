<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2025-08-11-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-12-01 | 2025-12-01 | cerrado
Ambiente de pruebas certificado | 2026-03-13 | 2026-03-13 | cerrado
Integración con el core cooperativo | 2026-06-24 | 2026-06-24 | cerrado
Piloto con asociados | 2026-10-04 | 2026-10-04 | en curso
