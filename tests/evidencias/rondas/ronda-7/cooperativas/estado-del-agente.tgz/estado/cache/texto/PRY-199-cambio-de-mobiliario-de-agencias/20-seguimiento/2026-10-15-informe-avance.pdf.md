<!-- origen: PRY-199-cambio-de-mobiliario-de-agencias/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cambio de mobiliario de agencias
Código: PRY-199
Fecha de corte: 2026-10-15
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se reprogramó la salida por el cierre contable de fin de mes
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Concentración del conocimiento en una sola persona
