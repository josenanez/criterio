<!-- origen: PRY-207-microcrédito-rural/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Microcrédito rural

**Fecha:** 2026-10-17
**Asistentes:** Paula Céspedes, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 37 | 2026-10-16 |
