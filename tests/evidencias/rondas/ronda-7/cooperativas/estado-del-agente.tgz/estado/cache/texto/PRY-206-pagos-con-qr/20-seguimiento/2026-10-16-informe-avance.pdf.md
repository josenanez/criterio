<!-- origen: PRY-206-pagos-con-qr/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pagos con QR
Código: PRY-206
Fecha de corte: 2026-10-16
Gerente: Andrés Lozano

Estado declarado
Rojo
Avance reportado: 45%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes
- Se recibió el concepto pendiente del ente supervisor

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 682.946.035
Ejecutado 448.689.025
Proyección al cierre 1.522.401.880

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
