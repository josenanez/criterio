<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-04-14-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-10-09 | 2026-10-09 | en curso
Ambiente de pruebas certificado | 2027-03-26 | 2027-03-26 | en curso
Integración con el core cooperativo | 2027-09-10 | 2027-09-10 | en curso
