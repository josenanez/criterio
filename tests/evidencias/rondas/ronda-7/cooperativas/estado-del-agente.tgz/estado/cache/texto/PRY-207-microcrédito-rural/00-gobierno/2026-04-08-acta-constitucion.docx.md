<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2026-04-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Tesorería

Patrocinador: Óscar Ramírez

Gerente de proyecto: Paula Céspedes

Comité: Consejo de Administración

Producto asociado: microcrédito

Fecha de aprobación: 2026-04-08

Objetivo del negocio

Entregar microcrédito rural para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Consejo de Administración el 2026-04-08.

Fechas comprometidas

Fecha

Inicio

2026-04-18

Cierre

2027-09-11

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
