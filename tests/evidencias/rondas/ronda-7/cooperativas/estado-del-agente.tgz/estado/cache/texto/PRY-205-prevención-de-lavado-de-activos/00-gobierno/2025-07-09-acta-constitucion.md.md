<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-07-09-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Prevención de lavado de activos

**Código:** PRY-205
**Área dueña:** Operaciones
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-09

## Objetivo del negocio

Entregar prevención de lavado de activos para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité de Riesgos el 2025-07-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-19 |
| Cierre | 2026-01-01 |

## Criterio de éxito

Prevención de lavado de activos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
