<!-- origen: PRY-204-tarjeta-débito-para-asociados/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tarjeta débito para asociados
Código: PRY-204
Fecha de corte: 2026-10-08
Gerente: Mauricio Pérez

Estado declarado
Rojo
Avance reportado: 79%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 549.756.602
Ejecutado 270.993.900
Proyección al cierre 1.135.772.783

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
- Dependencia del proveedor del core cooperativo
