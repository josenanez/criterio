<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-03
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-11-03 |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-19 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-10-24 |
| Felipe Arango | Entregar el punto 8 | 2026-10-03 |
| Gustavo Neira | Enviar el documento 9 | 2026-10-24 |
| Elena Duarte | Cerrar la prueba 10 | 2026-10-10 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-11-11 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-30 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-18 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-10 |
| Sandra Gil | Entregar el punto 16 | 2026-11-11 |
| Felipe Arango | Enviar el documento 17 | 2026-10-07 |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-08 |
| Jorge Medina | Revisar el anexo 19 | por definir |
| Liliana Torres | Validar el ambiente 20 | 2026-10-24 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Mauricio Pérez): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- Javier Hoyos dice que ya entregó «validar el ambiente 12». No se presentó acta.
