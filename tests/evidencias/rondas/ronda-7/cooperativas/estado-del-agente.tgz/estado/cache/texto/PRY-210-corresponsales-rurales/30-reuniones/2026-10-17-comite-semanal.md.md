<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-10-17
**Asistentes:** Mauricio Pérez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 23 | 2026-10-21 |
