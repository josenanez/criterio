<!-- origen: PRY-200-crédito-de-libranza-digital/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "name": {
 "value": "Crédito de libranza digital",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Tesorería",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "product": {
 "value": "crédito de libranza",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "manager": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "committee": {
 "value": "Consejo de Administración",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "rojo",
 "progress_pct": 28,
 "as_of": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2025-07-06",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "end_date": {
 "value": "2026-01-08",
 "source": "10-plan/2025-06-26-cronograma-v1.csv",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-06-26",
 "start_date": "2025-07-06",
 "end_date": "2026-01-08",
 "reason": "Aprobación inicial por el Consejo de Administración",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2025-08-21",
 "current_date": "2025-08-21",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-17-acta-recibo-diseño-funcional-aprobado.pdf",
 "source": "10-plan/2025-06-26-cronograma-v1.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2025-10-07",
 "current_date": "2025-10-07",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-06-26-cronograma-v1.csv"
 },
 {
 "name": "Integración con el core cooperativo",
 "baseline_date": "2025-11-23",
 "current_date": "2025-11-23",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2025-06-26-cronograma-v1.csv"
 },
 {
 "name": "Piloto con asociados",
 "baseline_date": "2026-01-08",
 "current_date": "2026-01-08",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-piloto-con-asociados.pdf",
 "source": "10-plan/2025-06-26-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3 (el acta no los describe)",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 2400000000,
 "source": "00-gobierno/2025-06-26-acta-constitucion.docx",
 "source_date": "2025-06-26",
 "state": "found"
 },
 "committed": {
 "value": 1398098317,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 929267306,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 2644653523,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Cambio normativo del supervisor que puede mover el alcance",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarado",
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "Concentración del conocimiento en una sola persona",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarado",
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión; nadie lo registró como riesgo)",
 "probability": "no_declarada",
 "impact": "no_declarada",
 "owner": "no_declarado",
 "due_date": null,
 "last_moved": null,
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un desarrollador clave",
 "since": null,
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 {
 "what": "La prueba de carga no alcanzó el umbral pactado y se repite",
 "since": null,
 "owner": "no_declarado",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Gustavo Neira",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-04",
 "original_due_date": "2026-09-12",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-25",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-04",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-12-07",
 "original_due_date": "2026-09-14",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Revisar el anexo 3",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-3.md"
 },
 {
 "who": "Laura Vélez",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-18",
 "original_due_date": "2026-09-18",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-4.md"
 },
 {
 "who": "Mauricio Pérez",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-10",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-5.md"
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-6.md"
 },
 {
 "who": "Paula Céspedes",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "nota": "Paula Céspedes dijo el 2026-09-19 que ya lo entregó; no hay acta de recibo, y el compromiso dejó de aparecer en la lista desde el 2026-09-26. Vencido sin evidencia."
 },
 {
 "who": "Felipe Arango",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Enviar el documento 9",
 "due_date": "2026-11-01",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-10.md"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Revisar el anexo 11",
 "due_date": "2026-11-11",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Validar el ambiente 12",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "nota": "Javier Hoyos dijo el 2026-10-03 que ya lo entregó; no hay acta de recibo, y el compromiso dejó de aparecer en la lista. Sigue abierto."
 },
 {
 "who": "Carlos Peña",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-30",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-13.md"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-18",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-14.md"
 },
 {
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-15.md"
 },
 {
 "who": "Sandra Gil",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-29",
 "original_due_date": "2026-10-22",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-07",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-20.md"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-16",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-07",
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "nota": "Dicho como «la otra semana»; no es una fecha y no se calculó."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "nota": "Las notas dicen «queda para el 2026-10-27»; no se unió a «Aprobar el diseño 21» porque nada dice que sea lo mismo."
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
