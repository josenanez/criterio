<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Aportes sociales en línea
Código: PRY-203
Fecha de corte: 2026-10-08
Gerente: María Restrepo

Estado declarado
Verde
Avance reportado: 28%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.354.841.763
Ejecutado 2.591.181.263
Proyección al cierre 6.393.451.915

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
