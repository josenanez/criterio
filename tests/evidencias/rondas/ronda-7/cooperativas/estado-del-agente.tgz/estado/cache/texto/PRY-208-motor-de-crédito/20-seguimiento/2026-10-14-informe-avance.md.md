<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **73%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.583.371.666 |
| Ejecutado | 2.645.112.684 |
| Proyección al cierre | 6.616.900.150 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
