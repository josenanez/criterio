<!-- origen: PRY-202-core-cooperativo/10-plan/2025-06-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-09-05 | 2025-09-05 | cerrado
Ambiente de pruebas certificado | 2025-11-09 | 2025-11-09 | cerrado
Integración con el core cooperativo | 2026-01-13 | 2026-01-13 | cerrado
Piloto con asociados | 2026-03-19 | 2026-03-19 | cerrado
Salida a producción | 2026-05-23 | 2026-05-23 | cerrado
