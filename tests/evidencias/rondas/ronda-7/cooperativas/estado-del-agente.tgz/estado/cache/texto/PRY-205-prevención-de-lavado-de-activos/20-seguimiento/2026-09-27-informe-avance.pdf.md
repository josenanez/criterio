<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-09-27-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-09-27
Gerente: Ricardo Salas

Estado declarado
Amarillo
Avance reportado: 55%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.472.743.776
Ejecutado 1.684.933.618
Proyección al cierre 4.267.213.372

Riesgos abiertos
- Concentración del conocimiento en una sola persona
