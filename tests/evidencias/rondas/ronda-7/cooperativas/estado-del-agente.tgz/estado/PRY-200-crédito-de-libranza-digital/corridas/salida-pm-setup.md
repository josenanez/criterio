## Listo — PRY-200 · Crédito de libranza digital

Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

**Lo que miré:** 21 documentos · 6 minutas del comité (2026-09-05 a 2026-10-10) más las notas del 2026-10-17 · la más reciente es del 2026-10-17. Leí las seis minutas en orden, de la más vieja a la más nueva, y las 11 actas de recibo. Todo es legible: .md, .csv, .docx, .pdf y .txt.

**Cómo quedó (preguntas con la respuesta sugerida, sin interfaz):**
- Eres Rubén Cárdenas, gerente de PRY-200 (acta de constitución).
- Tu reunión es el sábado (todas las minutas caen en sábado). Las notas del 17 dicen «próxima reunión en dos semanas»: la anoté para el 2026-10-31.
- El estado queda en `estado/PRY-200-crédito-de-libranza-digital`, junto a la documentación y fuera de ella.
- Términos: te mostré el texto de la versión 1.1 y los registré a nombre de José Francisco Ñáñez, por el sí que trae la sesión de prueba.

**Términos:** aceptados para la versión 0.3.13 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb…

### Lo que está abierto, y cuántas veces se ha movido
Son 26 compromisos en total: 9 cumplidos con acta de recibo, 4 vencidos sin evidencia, 11 abiertos con fecha y 2 sin fecha.

| Quién | Qué | Para cuándo | Reprogramado | Cita |
|---|---|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-12-04 | **6 veces** (original 2026-09-12) | notas 2026-10-17; primera vez en `30-reuniones/2026-09-05-comite-semanal.md` |
| Sandra Gil | Cerrar la prueba 2 | 2026-12-07 | **5 veces** (original 2026-09-14) | `30-reuniones/2026-10-10-comite-semanal.md`; primera vez en la del 2026-09-05 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-11-11 | 2 veces (original 2026-10-07) | `30-reuniones/2026-10-10-comite-semanal.md` |
| Gustavo Neira | Enviar el documento 9 | 2026-11-01 | 2 veces (original 2026-09-29) | `30-reuniones/2026-10-10-comite-semanal.md` |
| Sandra Gil | Entregar el punto 16 | 2026-11-29 | 2 veces (original 2026-10-22) | `30-reuniones/2026-10-10-comite-semanal.md` |
| Felipe Arango | Entregar el punto 8 | 2026-10-24 | 1 vez (original 2026-10-03) | `30-reuniones/2026-10-10-comite-semanal.md` |
| Beatriz Cuéllar | Entregar el punto 24 | 2026-11-07 | — | `30-reuniones/2026-10-10-comite-semanal.md` |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | — | notas 2026-10-17 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-20 | — | `30-reuniones/2026-10-10-comite-semanal.md` |
| María Restrepo | Confirmar la fecha 23 | 2026-10-19 | — | `30-reuniones/2026-10-10-comite-semanal.md` |
| Jorge Medina | Revisar el anexo 19 | 2026-10-21 | — (primera fecha; antes era «por definir») | `30-reuniones/2026-10-10-comite-semanal.md` |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-16 | **vencido hace 1 día, sin evidencia** | `30-reuniones/2026-10-10-comite-semanal.md` |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-08 | **vencido hace 9 días, sin evidencia** | `30-reuniones/2026-10-03-comite-semanal.md` |
| Felipe Arango | Enviar el documento 17 | 2026-10-07 | **vencido hace 10 días, sin evidencia** | `30-reuniones/2026-10-03-comite-semanal.md` |
| Paula Céspedes | Confirmar la fecha 7 | 2026-10-10 | **vencido hace 7 días, sin evidencia** | `30-reuniones/2026-09-12-comite-semanal.md` |

Dos cosas que ninguna minuta sola muestra:
- **El documento 1 y la prueba 2** llevan seis y cinco reprogramaciones, una por reunión. No son compromisos vencidos: son uno cada uno, con un bloqueo que nadie ha nombrado. Se reprogramaron de nuevo en la reunión más reciente en que aparecen. La lista y su historia completa está en la ficha.
- **«Confirmar la fecha 7»**: Paula Céspedes dijo el 2026-09-19 que ya lo entregó y no se presentó acta; desde la minuta del 2026-09-26 el compromiso ya no aparece. Que alguien diga que entregó no lo cierra: sigue vencido sin evidencia.

### Sin fecha
Estos no pueden estar vencidos, y por eso mismo son los que desaparecen de los informes:
- **Javier Hoyos · Validar el ambiente 12** — «por definir» el 2026-09-19 y el 2026-09-26. El 2026-10-03 dijo que ya lo entregó, sin acta, y dejó de aparecer en la lista. (`30-reuniones/2026-10-03-comite-semanal.md`)
- **Laura Vélez · Mandar el ajuste del presupuesto** — dicho el 2026-10-17 como «la otra semana». No lo convertí en fecha. (notas 2026-10-17)

### Lo que las señales dicen (salida de `compute`, al 2026-10-17)
- **Estado declarado: rojo, 28 %** (informe del 2026-10-13). El cronograma v1 trae los 4 hitos como cerrados, así que el avance que respalda el plan es 100 %: **72 puntos de brecha** entre lo que declaras y lo que dice el cronograma.
- **Dos hitos cerrados sin acta que lo pruebe:** «Ambiente de pruebas certificado» (fecha 2025-10-07, 375 días) e «Integración con el core cooperativo» (fecha 2025-11-23, 328 días). Los otros dos sí tienen acta: «Diseño funcional aprobado» (2026-10-17) y «Piloto con asociados» (2026-10-10). Ojo: la acta de recibo 4, «Validar el ambiente 4», es de un compromiso, no certifica el hito del ambiente de pruebas.
- **Costo:** la proyección al cierre es 2.644.653.523 COP contra 2.400.000.000 aprobados, **10,2 % por encima**. Ejecutado: 929.267.306 (38,7 %). Comprometido: 1.398.098.317 (58,3 %).
- **Fecha de cierre:** la vigente que sale del cronograma es 2026-01-08, igual a la del acta de constitución. Solo hay un cronograma (v1) y ningún documento reprograma el cierre, aunque ya pasó y el proyecto se declara en rojo.
- **Riesgo que se dijo y nadie anotó:** en las notas del 2026-10-17, que el proveedor podría no llegar con el equipo completo para la siguiente fase. Lo dejé en la ficha como riesgo, sin dueño.
- Tu informe declara dos riesgos (cambio normativo del supervisor, conocimiento concentrado en una persona) y dos hechos que ya pasaron (rotación de un desarrollador clave, prueba de carga que se repite); están en la ficha con su cita.

### Qué le falta a tu carpeta
- **Actas de recibo de dos hitos:** ambiente de pruebas certificado e integración con el core; sin ellas se ven igual que hitos sin cumplir.
- **Un cronograma vigente:** solo existe el v1; no hay uno que dé cuenta de la salida que tu informe dice que se reprogramó.
- **Minuta formal del 2026-10-17:** hoy solo hay notas, y no traen quién cerró qué.
- **En el acta de constitución:** no dice hasta qué monto o cambio de alcance puedes decidir sin subir a comité (`authority`), ni la fase; los tres componentes del alcance están como «Componente 1, 2, 3».
- **Actas de recibo de los compromisos que dicen haber entregado** (Confirmar la fecha 7, Validar el ambiente 12).

La ficha quedó sin sellar: leí las minutas y las actas, no tu proyecto entero.

**Cuándo vuelvo:** el sábado 2026-10-31, tu próxima reunión según las notas.
