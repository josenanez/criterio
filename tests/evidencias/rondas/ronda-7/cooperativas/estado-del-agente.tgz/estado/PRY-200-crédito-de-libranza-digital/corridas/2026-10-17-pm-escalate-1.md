# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 44 s · 12 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `milestone_met_without_evidence` | 2 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `variance_cost` | 1 |

Dos puntos: autoridad no declarada en el acta, y sobrecosto de +244.653.523 (10,19 %). No calculé impact: ningún documento propone días. No consta el costo de la opción B ni la fecha de cierre nueva.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Para decisión — Crédito de libranza digital (PRY-200) · 2026-10-17

Dos puntos escalan, en este orden. El primero no es el que venías a subir, pero sin él el segundo puede volver devuelto.

### Punto 0 — ¿Quién puede decidir qué?

**Qué pasa:** el acta de constitución del 2025-06-26 no declara la autoridad del gerente (`identity.authority`: no consta). Dice quién aprobó el presupuesto (Consejo de Administración) y quién patrocina (Jorge Medina), pero no hasta dónde puede decidir Rubén Cárdenas sobre costo, fechas o reprogramaciones.

**Pregunta cerrada:** ¿Se confirma por escrito que los cambios de presupuesto sobre los COP 2.400.000.000 aprobados los decide el Consejo de Administración, y que las reprogramaciones de compromisos las decide Jorge Medina? *(Sí / No, y quién.)*

**Quién decide:** Consejo de Administración o el patrocinador; el acta no lo dice. Es la pregunta misma.
**Si no se decide hoy:** el comité del 2026-10-31 (`committee_next`) puede decidir el punto 1 sin tener la facultad, y la decisión se devuelve.

---

### Punto 1 — ¿Se aprueba el sobrecosto proyectado?

**¿Se ajusta el presupuesto de COP 2.400.000.000 a la proyección declarada de COP 2.644.653.523 (+COP 244.653.523, +10,19 %), o se mantiene en COP 2.400.000.000 y se recorta alcance?**

**Quién decide:** Consejo de Administración (aprobó el presupuesto original; es lo más probable, pero el acta no declara la facultad: ver punto 0) · **Si no se decide hoy:** no hay en ningún documento una fecha de vencimiento de oferta ni de contrato, y no la invento. Lo que sí consta: hay COP 1.398.098.317 comprometidos y COP 929.267.306 ejecutados, y la proyección ya supera el umbral de 10 % de la configuración. El punto se aplaza con cada comité que pasa sin decisión; la próxima fecha de comité es el 2026-10-31.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar la proyección como línea base v2 | Sin cambio declarado | No consta: el cierre vigente (2026-01-08) ya pasó hace 282 días y no hay fecha nueva en ningún documento | +COP 244.653.523 (total COP 2.644.653.523) |
| B. Mantener COP 2.400.000.000 | Habría que recortar; ningún documento dice qué | No consta | Sin sobrecosto; lo que cuesta recortar no consta |

*No tengo ningún documento que cuantifique la opción B ni que dé fecha a la opción A. Laura Vélez quedó de mandar «el ajuste del presupuesto la otra semana» (notas del 2026-10-17); sin fecha concreta. Probablemente esa pieza llene estas celdas.*

**Recomiendo:** A, condicionada a que venga con fecha de cierre nueva — la proyección de costo no se sostiene sola cuando el plan vigente terminó hace nueve meses con avance declarado de 28 % y estado rojo; aprobar plata sin fecha deja la próxima desviación sin línea base contra la cual medirla. Esto es una recomendación mía, no un dato del expediente.

**Esto es control de cambios, no solo escalamiento:** al aprobarse, entra como línea base v2 y la v1 (2025-06-26) no se toca.

### A quién alcanza

No calculé el efecto: `portafolio.py impact` pide un número de días y ningún documento propone un cambio de fecha; inventarlo sería fabricar el resultado. El acta declara «Dependencias: ninguna declarada» y la ficha tiene `dependencies: []` y `vendors: []`. Eso no prueba que no haya otros proyectos alcanzados, solo que nadie los declaró. Cuando exista una fecha propuesta: `/pm-escalate cambio <fecha>`.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| No calculado | — | — | — |

### Mis hitos por los que pasa

No calculado, por lo mismo. Lo que sí consta: los cuatro hitos tienen fecha vigente igual a la de línea base y todos pasada; «Ambiente de pruebas certificado» e «Integración con el core cooperativo» figuran cumplidos sin acta de recibo.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Diseño funcional aprobado | 2025-08-21 | no calculado |
| Ambiente de pruebas certificado | 2025-10-07 | no calculado |
| Integración con el core cooperativo | 2025-11-23 | no calculado |
| Piloto con asociados | 2026-01-08 | no calculado |

### Lo que no escala

- Las seis reprogramaciones de «Enviar el documento 1» (Gustavo Neira) y las cinco de «Cerrar la prueba 2» (Sandra Gil) cumplen el criterio de reprogramado tres veces. Aun así no armé paquete aparte: quién acepta una reprogramación es el punto 0, y ya están como puntos 1 y 2 en la agenda del 2026-10-31.
- Los vencidos de Felipe Arango, Laura Vélez y Carlos Peña se destraban con una llamada.

### De dónde sale esto

- Autoridad no declarada; presupuesto aprobado por el Consejo, patrocinador, comité: `00-gobierno/2025-06-26-acta-constitucion.docx`.
- Presupuesto aprobado, comprometido, ejecutado y proyección; estado rojo y 28 %: `20-seguimiento/2026-10-13-informe-avance.md`.
- Fechas de hitos y cierre 2026-01-08: `10-plan/2025-06-26-cronograma-v1.csv`.
- «Mandar el ajuste del presupuesto»: `2026-10-17-notas-reunion.txt`, línea 5.
- Próximo comité 2026-10-31 y umbral de 10 %: `.criterio/proyecto/PRY-200/config.json`.
- Derivados míos: +COP 244.653.523 = 2.644.653.523 − 2.400.000.000 (10,19 %); 282 días = del 2026-01-08 al 2026-10-17.
