## Compromisos — Crédito de libranza digital (PRY-200) · al 2026-10-17

26 compromisos en la ficha: 9 cerrados con documento, 17 abiertos (4 vencidos, 2 sin fecha, 2 reprogramados 3 o más veces).

### Se viene reprogramando

> **Gustavo Neira** · Enviar el documento 1
> Prometido para el 2026-12-04, y antes para el 2026-11-20, el 2026-11-03, el 2026-10-26, el 2026-10-05 y el 2026-09-25. La primera promesa fue el 2026-09-12.
> **Seis reprogramaciones en cinco semanas no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.**

> **Sandra Gil** · Cerrar la prueba 2
> Prometido para el 2026-12-07, y antes para el 2026-11-19, el 2026-11-03, el 2026-10-15 y el 2026-09-27. La primera promesa fue el 2026-09-14.
> **Cinco reprogramaciones: el mismo patrón. La fecha vigente quedó casi tres meses después de la original.**

Por debajo del umbral de 3, pero para vigilar (2 reprogramaciones cada uno): Gustavo Neira · Enviar el documento 9 (vigente 2026-11-01), Camilo Beltrán · Revisar el anexo 11 (vigente 2026-11-11) y Sandra Gil · Entregar el punto 16 (vigente 2026-11-29). Gustavo Neira y Sandra Gil aparecen con dos compromisos movidos cada uno.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Felipe Arango | Enviar el documento 17 | 2026-10-07 | 10 días |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-08 | 9 días |
| Paula Céspedes | Confirmar la fecha 7 | 2026-10-10 | 7 días |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-16 | 1 día |

Paula Céspedes dijo el 2026-09-19 que ya lo entregó; no hay acta de recibo en el expediente que lo respalde, y el compromiso dejó de aparecer en la lista desde el 2026-09-26.

### Vencen esta semana (hasta el 2026-10-24)
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Confirmar la fecha 23 | 2026-10-19 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-20 |
| Jorge Medina | Revisar el anexo 19 | 2026-10-21 |
| Felipe Arango | Entregar el punto 8 (reprogramado una vez; original 2026-10-03) | 2026-10-24 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Javier Hoyos | Validar el ambiente 12 | 2026-09-19 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-17 |

No pueden estar vencidos y por eso se cuentan aparte. Javier Hoyos dijo el 2026-10-03 que ya lo entregó; no hay acta de recibo y el compromiso dejó de aparecer en la lista. Sigue abierto. De Laura Vélez, las notas dicen «la otra semana»: no es una fecha y no se calculó una.

Además, Óscar Ramírez tiene «Revisión con el proveedor» para el 2026-10-27, abierto y en fecha. No se unió a «Aprobar el diseño 21» porque nada dice que sea lo mismo.

### Cerrados con documento
Los 9 cierran contra un acta de recibo del expediente (es la primera revisión de compromisos de este proyecto, así que no hay corte anterior contra el cual restar):

| Quién | Qué | Documento |
|---|---|---|
| Paula Céspedes | Revisar el anexo 3 | 20-seguimiento/2026-09-19-acta-recibo-3.md |
| Laura Vélez | Validar el ambiente 4 | 20-seguimiento/2026-09-19-acta-recibo-4.md |
| Mauricio Pérez | Aprobar el diseño 5 | 20-seguimiento/2026-10-03-acta-recibo-5.md |
| Javier Hoyos | Actualizar la matriz 6 | 20-seguimiento/2026-10-10-acta-recibo-6.md |
| Elena Duarte | Cerrar la prueba 10 | 20-seguimiento/2026-10-10-acta-recibo-10.md |
| Carlos Peña | Aprobar el diseño 13 | 20-seguimiento/2026-10-10-acta-recibo-13.md |
| Beatriz Cuéllar | Actualizar la matriz 14 | 20-seguimiento/2026-10-10-acta-recibo-14.md |
| Mauricio Pérez | Confirmar la fecha 15 | 20-seguimiento/2026-10-10-acta-recibo-15.md |
| Liliana Torres | Validar el ambiente 20 | 20-seguimiento/2026-10-10-acta-recibo-20.md |
