# Crédito de libranza digital (PRY-200) — semana del 2026-10-10 al 2026-10-17

**Declara el gerente (Rubén Cárdenas):** rojo · 28% · al 2026-10-13 (4 días; vigente)
**Sustento documental:** el rojo está sustentado por las señales; el 28% está contradicho por el cronograma (4 de 4 hitos cerrados).
**Lo que el semáforo no explica:** compromisos vencidos (4), compromisos reprogramados (2), hitos cerrados sin evidencia (2), avance contra plan (28% contra 100%), sobrecosto proyectado (10,2%).

> Sobre la declaración: en esta sesión nadie respondió. No propuse ningún estado. Usé la declaración que ya está en la ficha, la del informe de avance del 2026-10-13 firmado por el gerente. Si el gerente declara otra cosa hoy, hay que corregirla.

## Qué cambió esta semana
Sin comparación posible. Esta es la primera corrida con instantánea para este proyecto, y `diff` no tiene una corrida anterior contra la cual comparar (0 cambios). Lo que sí consta en la semana:

| Qué | Estaba | Está | |
|---|---|---|---|
| Compromisos cerrados con acta de recibo (comité 2026-10-10) | abiertos | 6 cerrados (matriz 6, prueba 10, diseño 13, matriz 14, fecha 15, ambiente 20) | cerrado |
| Informe de avance | — | rojo, 28%, 2026-10-13 | nuevo |
| Notas de la reunión del 2026-10-17 | — | Gustavo Neira reprograma el documento 1 al 2026-12-04; Laura Vélez promete el ajuste del presupuesto «la otra semana»; revisión con proveedor el 2026-10-27 | nuevo |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Hito «Ambiente de pruebas certificado» cerrado sin evidencia | 2025-10-07 | 375 |
| Hito «Integración con el core cooperativo» cerrado sin evidencia | 2025-11-23 | 328 |
| Fecha de cierre del plan vencida (2026-01-08) con avance declarado de 28% | 2026-01-08 | 282 |
| Felipe Arango · Enviar el documento 17 (vencido) | 2026-10-07 | 10 |
| Laura Vélez · Cerrar la prueba 18 (vencido) | 2026-10-08 | 9 |
| Paula Céspedes · Confirmar la fecha 7 (vencido) | 2026-10-10 | 7 |
| Carlos Peña · Actualizar la matriz 22 (vencido) | 2026-10-16 | 1 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-01-08 | 2026-01-08 | 0 días, pero la fecha ya pasó hace 282 días |
| Presupuesto | COP 2.400.000.000 | COP 2.400.000.000 | proyección COP 2.644.653.523 → +COP 244.653.523 (+10,2%), sobre el umbral de 10% |

Replanificaciones: 0. La desviación en días sale cero porque el plan nunca se movió, no porque el proyecto esté a tiempo. El informe del gerente menciona una «salida reprogramada por el cierre contable», pero ninguna línea base nueva lo respalda.

### Hitos de las próximas cuatro semanas
No hay. Los cuatro hitos del cronograma están fechados entre 2025-08-21 y 2026-01-08 y constan como cerrados. Con 28% de avance declarado, el cronograma no describe el trabajo que falta.

| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Diseño funcional aprobado | 2025-08-21 | 2025-08-21 | acta de recibo 2026-10-17 |
| Ambiente de pruebas certificado | 2025-10-07 | 2025-10-07 | **sin evidencia** |
| Integración con el core cooperativo | 2025-11-23 | 2025-11-23 | **sin evidencia** |
| Piloto con asociados | 2026-01-08 | 2026-01-08 | acta de recibo 2026-10-10 |

Las actas de recibo de los dos hitos con evidencia son de octubre de 2026, y los hitos vencían en 2025 y enero de 2026.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.398.098.317 (58,3%) | 929.267.306 (38,7%) | 2.644.653.523 | 1.001.901.683 |

El disponible real es aprobado menos comprometido. La proyección supera lo aprobado, así que ese disponible no alcanza para llegar al cierre.

## Abierto
**Reprogramados:**
- Gustavo Neira · Enviar el documento 1: 6 veces. Original 2026-09-12, hoy 2026-12-04.
- Sandra Gil · Cerrar la prueba 2: 5 veces. Original 2026-09-14, hoy 2026-12-07.

**Vencidos sin evidencia:** Felipe Arango (documento 17, 10 días), Laura Vélez (prueba 18, 9 días), Paula Céspedes (fecha 7, 7 días), Carlos Peña (matriz 22, 1 día).
**Sin fecha:** Javier Hoyos (validar el ambiente 12, desde el comité del 2026-09-19); Laura Vélez (ajuste del presupuesto, «la otra semana»).
**RAID sin movimiento:** tres riesgos (cambio normativo del supervisor, concentración del conocimiento en una persona, proveedor sin equipo completo) sin probabilidad, impacto, dueño ni fecha. Dos incidencias (rotación del desarrollador clave, prueba de carga repetida) sin dueño ni fecha de inicio. El tercer riesgo se dijo en la reunión del 2026-10-17 y nadie lo registró.
**Proveedor:** la ficha no tiene entregables de proveedor cargados, aunque hay una revisión con el proveedor el 2026-10-27.

## Lo que necesito de alguien
- **Gustavo Neira y Sandra Gil:** nombrar qué bloquea el documento 1 y la prueba 2. Seis y cinco reprogramaciones en pocas semanas no se explican con el seguimiento.
- **Laura Vélez:** fecha concreta para el ajuste del presupuesto, porque la proyección ya pasa el umbral.
- **Rubén Cárdenas:** registrar el riesgo del proveedor y asignar dueño a los riesgos y las incidencias abiertas.
- **Excede la autoridad del gerente (material de comité):** sobrecosto de 10,2% sobre el presupuesto aprobado, y una línea base que no refleja el trabajo pendiente.

## Lo que no se sabe
**Sin dato:** autoridad que aprueba (`identity.authority`) y fase del proyecto (`identity.phase`). Hay 12 campos con más de 12 meses de antigüedad (todos de la fecha del acta, 2025-06-26). Todo el sustento documental está sin marcar: 0 fuentes de evidencia, 0 de declaración y 15 sin marcar.
**Silencio:** último documento hace 0 días (2026-10-17) · última reunión hace 0 días (notas del 2026-10-17; último comité formal el 2026-10-10, hace 7 días).

---
Ficha: `estado/PRY-200-crédito-de-libranza-digital/records/PRY-200.json`, con corte al 2026-10-17 (declaración al 2026-10-13). Campos sin dato: 2. Términos y nota legal (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

**Después:** hay dos compromisos reprogramados 5 y 6 veces (umbral: 3) y un sobrecosto sobre el umbral. Ofrezco armar el punto de comité con la decisión formulada (`/pm-escalate`). La declaración (rojo) no está contradicha por la evidencia, así que `/pm-publish` no es urgente por esa razón.
