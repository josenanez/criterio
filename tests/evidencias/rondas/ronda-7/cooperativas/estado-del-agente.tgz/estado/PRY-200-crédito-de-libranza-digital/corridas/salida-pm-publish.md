Publiqué la ficha en `/home/claude/banco/ronda-7/cooperativas/espacio/documentos/proyectos/PRY-200-crédito-de-libranza-digital/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 18 campos con dato (15 de identidad, plan y dinero + estado, avance y fecha de corte declarados) · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · declara **rojo** al 2026-10-13 (28 % de avance, declarado por el gerente en `20-seguimiento/2026-10-13-informe-avance.md`)

**Lo más viejo que va ahí:** los 12 campos que salen del acta de constitución (código, nombre, área, producto, patrocinador, gerente, comité, inicio, fin, alcance, exclusiones y presupuesto aprobado), del 2025-06-26 — 16 meses, más de un año. Ningún documento posterior los confirma ni los cambia.

**Fecha de cierre:** `plan.end_date` = 2026-01-08, del cronograma v1 (2025-06-26), que es el único que hay; no hay uno más nuevo, así que vigente y línea base coinciden.

**Lo que la PMO va a ver, y conviene que sepas:**
- Declaras rojo y la ficha lo marca como declarado. Cinco señales del cálculo no aparecen en tu informe: compromisos vencidos, compromisos reprogramados, hitos cerrados sin evidencia, avance contra plan y desviación de costo.
- Avance declarado 28 % frente a 4 de 4 hitos cerrados (brecha de 72 puntos).
- Dos hitos figuran cerrados sin acta de recibo: «Ambiente de pruebas certificado» (vencía 2025-10-07) e «Integración con el core cooperativo» (vencía 2025-11-23).
- Proyección de 2.644.653.523 COP contra 2.400.000.000 aprobados: 10,2 % por encima.
- Cuatro compromisos vencidos, dos sin fecha y dos reprogramados cinco o seis veces.
- Ningún documento nombra autoridad ni fase.

Nada más se tocó en la carpeta de documentación. Vera la leerá en su próximo barrido; este comando no avisa a nadie.
