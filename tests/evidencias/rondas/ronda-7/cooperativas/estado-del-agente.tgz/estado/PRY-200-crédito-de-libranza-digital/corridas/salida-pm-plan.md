# Plan — Crédito de libranza digital (PRY-200) · borrador del 2026-10-17
**Desde:** `00-gobierno/2025-06-26-acta-constitucion.docx` (aprobada el 2025-06-26) · **Criterio de éxito:** «Crédito de libranza digital en producción y medido.»

*Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17): no hizo falta registrarlos de nuevo. Sesión sin interfaz: no hubo preguntas; se tomó la respuesta sugerida en cada una (se partió del único acta que existe).*

## Antes de leer el plan: este no es un arranque
El acta es de junio de 2025 y comprometía el cierre al 2026-01-08. Hoy es 2026-10-17: el proyecto lleva más de nueve meses pasado de esa fecha y el informe del 2026-10-13 lo declara en **rojo, 28 %**. Este borrador reconstruye la estructura desde el acta; **no sustituye una replanificación** y no corrige la línea base (eso es `change-control`).

Una contradicción que el plan hereda y no resuelve: `10-plan/2025-06-26-cronograma-v1.csv` marca los cuatro hitos como «cerrado» con fecha vigente = fecha de línea base (la última, 2026-01-08), mientras el informe dice 28 % de avance y proyecta 2.644.653.523 COP contra 2.400.000.000 aprobados (informe, 2026-10-13). Ambas cosas no pueden ser ciertas a la vez; este plan no elige.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** «Componente 1, Componente 2, Componente 3», sin describirlos | No se puede descomponer en entregables. Los tres nodos de la WBS quedan «sin definir»; cualquier nombre que les pusiera sería inventado |
| **Exclusión vacía:** «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué | No se sabe dónde termina este proyecto; el riesgo de duplicar o de dejar un hueco entre dos proyectos |
| **Criterio de éxito sin umbral:** «en producción y medido» no dice medido contra qué ni con qué cifra | Se puede declarar éxito con cualquier medición; el nodo «medición» no tiene condición de aceptación |
| **Sin autoridad declarada** (el campo no existe en el acta) | No se sabe qué puede decidir el gerente al planificar y qué debe subir; por eso este borrador no decide nada de eso |
| **Dependencias: «Ninguna declarada»** | El orden de abajo sale solo de la lógica del trabajo, no de dependencias externas. Las notas del 2026-10-17 mencionan al proveedor como condicionante de «la siguiente fase», y el acta no lo recoge |
| **Sin quién acepta** cada entregable | La columna «Quién lo acepta» queda sin definir. El patrocinador (Jorge Medina) está en el acta, pero el acta no dice que sea quien acepta |

Patrocinador sí está declarado (Jorge Medina), así que las excepciones tienen a quién llevarse. Se sigue planificando marcando estos vacíos; no se rellenaron.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 (el acta no lo describe) | sin definir | **del acta**, sólo el nombre; contenido: **sin definir** | vacía |
| 2 | Componente 2 (ídem) | sin definir | **del acta**, sólo el nombre; contenido: **sin definir** | vacía |
| 3 | Componente 3 (ídem) | sin definir | **del acta**, sólo el nombre; contenido: **sin definir** | vacía |
| 4 | Diseño funcional aprobado | sin definir | **supuesto**: es un hito del cronograma v1, no del acta; no sé si es entregable de un componente o transversal | vacía |
| 5 | Ambiente de pruebas certificado | sin definir | **supuesto**: hito del cronograma v1 | vacía |
| 6 | Integración con el core cooperativo | sin definir | **supuesto**: hito del cronograma v1 | vacía |
| 7 | Piloto con asociados | sin definir | **supuesto**: hito del cronograma v1 | vacía |
| 8 | Crédito de libranza digital en producción | sin definir | **del acta** (criterio de éxito) | vacía |
| 9 | Medición del crédito en producción | sin definir | **del acta** («y medido»); qué se mide y contra qué: **sin definir** | vacía |

Las duraciones quedan vacías: el acta no trae ninguna y el cronograma v1 sólo trae fechas de hito (sin duración por nodo), que además el informe de avance contradice. Donde el cronograma coincide con el acta es en el cierre: 2026-01-08, ya vencido.

## Orden
Sin fechas; sólo qué necesita qué. Los números remiten a la WBS.
- 4 (diseño funcional) antes de construir los componentes 1–3 y de integrar (6). *Supuesto*: es el orden lógico de cualquier construcción; el acta no lo dice.
- 5 (ambiente de pruebas) antes de la integración (6) y del piloto (7). *Supuesto.*
- 6 (integración con el core) antes del piloto (7). *Supuesto.*
- 1, 2, 3 (componentes): **no se puede ordenar entre sí ni respecto de 4–7** sin saber qué son.
- 7 (piloto) antes de 8 (producción). *Supuesto.*
- 8 (producción) antes de 9 (medición): sin producción no hay qué medir. Esto sí se deduce del criterio de éxito.
- La prueba de carga que «no alcanzó el umbral pactado y se repite» (informe, 2026-10-13) está en el camino entre 5/6 y 8; el informe no dice qué umbral ni de qué documento sale. **Sin definir.**

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cuatro hitos del cronograma v1 son entregables de este proyecto y siguen vigentes | Los nodos 4–7 sobran o faltan; si ya se cerraron, hay que reabrir la pregunta del 28 % |
| Diseño → ambiente → integración → piloto → producción → medición es el orden real | Se planifica un camino crítico equivocado |
| Los tres «componentes» no son los hitos 4–7 con otro nombre | La WBS duplica trabajo; o, si lo son, queda un hueco entre «componente» y «hito» |
| El proveedor mencionado en las notas del 2026-10-17 participa en la siguiente fase, con equipo completo | No hay equipo para ejecutar lo que falta; hoy ese riesgo no está registrado |
| El alcance no cambia por el cambio normativo del supervisor (riesgo del informe) | Se reabre el alcance, y el alcance ya está sin contenido |

Estos pasan al RAID con doliente en cuanto el plan se apruebe (`raid-taxonomy`).

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | El patrocinador (Jorge Medina) con el gerente; el acta no lo dice |
| Qué proyecto cubre lo excluido, y qué | El patrocinador / Consejo de Administración |
| Quién acepta cada entregable | El patrocinador; el acta no lo dice |
| Con qué cifra se declara «medido» | El patrocinador / área dueña (Tesorería) |
| Qué puede decidir el gerente al planificar (autoridad) | El patrocinador / Consejo de Administración |
| Umbral de la prueba de carga y documento donde se pactó | Sin dueño visible en la documentación |
| Fase del proyecto hoy (`identity.phase`) | El gerente |
| Qué es «la siguiente fase» de la que hablan las notas, y su proveedor | El gerente; no hay contrato de proveedor ni ficha de proveedor en la carpeta |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO ni hay otros proyectos en el espacio. Sin análogos no hay referencia, y es mejor decirlo que inventar una; **no se estima por analogía.**

Referencia interna, sólo como dato y no como estimación: el propio proyecto lleva sus compromisos de comité corridos varias veces (por ejemplo, «Enviar el documento 1» de Gustavo Neira, fijado primero para el 2026-09-12 y hoy para el 2026-12-04, con seis reprogramaciones; fuente: `30-reuniones/` y notas del 2026-10-17). Dice cómo se comporta este equipo con sus propias fechas, no cuánto tomará nada.

## Preguntas para el equipo
Una por duración vacía, y una por vacío que bloquea descomponer:
1. Nodo 1, 2 y 3 — ¿qué es cada componente, qué se entrega y quién lo recibe? (antes de preguntar cuánto toma)
2. Nodo 4 (diseño funcional) — ¿está realmente cerrado? El cronograma dice «cerrado»; el acta de recibo está fechada el 2026-10-17, no en 2025. ¿Cuánto falta, si algo?
3. Nodo 5 (ambiente de pruebas) — ¿cuánto toma recertificarlo, si la prueba de carga se repite?
4. Nodo 6 (integración con el core) — ¿cuánto toma, y qué dependencia tiene del equipo del core?
5. Nodo 7 (piloto) — ¿cuánto toma, con cuántos asociados, y cuándo se puede repetir si el anterior ya se hizo?
6. Nodo 8 (producción) — ¿cuánto toma, y qué ventana de sala de producción hay? («Se reprogramó la salida por el cierre contable de fin de mes», informe, 2026-10-13: ¿a cuándo?)
7. Nodo 9 (medición) — ¿qué se mide, con qué umbral y durante cuánto tiempo?
8. Prueba de carga — ¿cuál era el umbral pactado y cuánto toma repetirla?
9. Transversal — ¿con cuánta gente real cuenta el equipo después de la rotación del desarrollador clave?

## Para comprometer una fecha falta
Ninguna de estas tres está en un documento:
- **Disponibilidad real del equipo**, hoy afectada por la rotación del desarrollador clave y por la concentración del conocimiento en una persona (informe, 2026-10-13).
- **Fecha y compromiso del proveedor**: las notas del 2026-10-17 dicen que podría no llegar con el equipo completo; no hay contrato ni fecha en la carpeta.
- **Ventana de la sala de producción** y la restricción del cierre contable de fin de mes.

Además, falta la aprobación de la replanificación por quien tenga autoridad (hoy sin declarar), y la decisión de qué línea base se usa como referencia. **Esta fecha la compromete el gerente (Rubén Cárdenas); este borrador no propone ninguna.**

## Después
Si el plan se aprueba: registrarlo como nueva línea base *sin borrar la v1* (el cierre original 2026-01-08 sigue siendo la referencia contra la cual se mide la desviación) y pasar los supuestos al RAID con doliente. Mientras tanto, la línea base sigue siendo la única: la v1.
