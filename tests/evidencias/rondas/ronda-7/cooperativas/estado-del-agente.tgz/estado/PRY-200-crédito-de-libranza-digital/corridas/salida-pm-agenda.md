## Reunión de seguimiento — Crédito de libranza digital (PRY-200) · 2026-10-31
8 puntos · 40 minutos (de 45 supuestos) · 8 personas requeridas

Supuestos que tomé sin preguntar: la fecha es `committee_next` de la configuración (2026-10-31); la duración no está configurada, así que usé 45 minutos; y la configuración dice `weekly` mientras la reunión del 2026-10-17 dijo «en dos semanas», así que la agenda es para el 31 y no para el 24. Si la reunión es el 24, avísame y la rehago. Los datos están al 2026-10-17: lo que vence entre hoy y el 31 hay que volver a mirarlo el 2026-10-30 (`/pm-agenda 2026-10-31` ese día).

Personas requeridas: Gustavo Neira, Sandra Gil, Felipe Arango, Laura Vélez, Carlos Peña, Óscar Ramírez, Rubén Cárdenas y Jorge Medina (patrocinador, para el punto 1). María Restrepo, Camilo Beltrán y Beatriz Cuéllar no tienen nada que destrabar aquí.

### Lo que no se destraba solo

> **[1] Decidir si «Enviar el documento 1» se acepta por séptima vez, y qué lo está trabando** · 10 min · **Gustavo Neira; decide Jorge Medina**
> Prometido para el 2026-12-04, y antes para el 2026-11-20, el 2026-11-03, el 2026-10-26, el 2026-10-05 y el 2026-09-25. La primera promesa fue el 2026-09-12: son 12 semanas de atraso sobre la promesa original. También movió «Enviar el documento 9» dos veces (vigente 2026-11-01, un día después de esta reunión).
> Fuente: 30-reuniones/2026-09-05-comite-semanal.md (promesa original) y 2026-10-17-notas-reunion.txt (sexta reprogramación, aceptada «sin comentario»).
> **Qué tiene que quedar resuelto:** el bloqueo con nombre (qué falta y de quién depende), una fecha con su condición, o la decisión de escalarlo. Confirmar además que «04/12/2026» es 4 de diciembre (se leyó así; las notas no lo aclaran).
> **Si no se resuelve hoy:** la séptima fecha se acepta igual que la sexta, y el documento 9 arrastra el mismo patrón. En el expediente `identity.authority` no consta, así que no sé quién tiene la facultad de aceptar o rechazar la reprogramación; Jorge Medina figura como patrocinador en el acta de constitución y por eso lo propongo en la sala.

> **[2] «Cerrar la prueba 2»: bloqueo con nombre o decisión de escalar** · 8 min · **Sandra Gil**
> Prometido para el 2026-12-07, y antes para el 2026-11-19, el 2026-11-03, el 2026-10-15 y el 2026-09-27. La primera promesa fue el 2026-09-14 (12 semanas de atraso). También movió «Entregar el punto 16» dos veces (vigente 2026-11-29).
> Fuente: 30-reuniones/2026-09-05-comite-semanal.md y 30-reuniones/2026-10-10-comite-semanal.md (última reprogramación). Las notas del 2026-10-17 no mencionan este compromiso.
> **Qué tiene que quedar resuelto:** lo mismo que en el punto 1. Nada en el expediente dice si este bloqueo y el del punto 1 tienen relación; no la asumo, la pregunta es parte del punto.
> **Si no se resuelve hoy:** la fecha vigente ya quedó casi tres meses después de la original y sigue moviéndose sin que nadie diga por qué.

### Vencido sin evidencia
Días contados al 2026-10-17; el 31 serán 14 más.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Felipe Arango | Enviar el documento 17 | 2026-10-07 | Entregarlo con acta de recibo, o una fecha | 3 |
| Laura Vélez | Cerrar la prueba 18 | 2026-10-08 | Lo mismo. Y una fecha real para «Mandar el ajuste del presupuesto», que sigue en «la otra semana» | 4 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-16 | Lo mismo | 2 |
| Rubén Cárdenas | Hitos «Ambiente de pruebas certificado» (2025-10-07) e «Integración con el core cooperativo» (2025-11-23), dados por cumplidos sin acta de recibo | — | Decir quién tiene el acta, o devolverlos a pendientes | 3 |

Fuentes: 30-reuniones/2026-10-03-comite-semanal.md (documento 17 y prueba 18), 30-reuniones/2026-10-10-comite-semanal.md (matriz 22) y 10-plan/2025-06-26-cronograma-v1.csv (hitos). El de Paula Céspedes no está aquí: ver «No es de esta reunión».

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Nombrar dueño de los tres riesgos sin dueño: «el proveedor podría no llegar con el equipo completo» (dicho el 2026-10-17 sin atribuir quién; nadie lo registró), cambio normativo del supervisor y concentración del conocimiento (informe del 2026-10-13). Los tres están sin probabilidad, impacto ni dueño | Rubén Cárdenas, con Jorge Medina | Siguen sin doliente, y el del proveedor ni siquiera tiene contrato de referencia en la ficha (`vendors: []`) | 4 |
| Si la «Revisión con el proveedor» del 2026-10-27 es la misma cosa que «Aprobar el diseño 21» (vencía el 2026-10-20), o un compromiso aparte | Óscar Ramírez | Quedan dos compromisos abiertos del mismo dueño y no se sabe si el primero se reprogramó | 3 |

Fuente: 2026-10-17-notas-reunion.txt (líneas 6 y 7) y 20-seguimiento/2026-10-13-informe-avance.md.

### Vence antes de la próxima
Es el punto preventivo: 3 minutos para confirmar que quien tiene algo lo va a cumplir, sin repasarlo.

| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Confirmar la fecha 23 | 2026-10-19 |
| Óscar Ramírez | Aprobar el diseño 21 | 2026-10-20 |
| Jorge Medina | Revisar el anexo 19 | 2026-10-21 |
| Felipe Arango | Entregar el punto 8 (reprogramado una vez; original 2026-10-03) | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 |
| Gustavo Neira | Enviar el documento 9 (movido dos veces; vence un día después de la reunión) | 2026-11-01 |

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Paula Céspedes · «Confirmar la fecha 7» (vencido desde 2026-10-10) | Dijo el 2026-09-19 que ya lo entregó y no hay acta de recibo. Ella no aparece entre los asistentes del 2026-10-17 | Rubén se lo pide antes (acta de recibo o fecha), o la convoca. Si no responde, entra al anexo de vencidos |
| Javier Hoyos · «Validar el ambiente 12» (sin fecha desde 2026-09-19) | Dijo el 2026-10-03 que ya lo entregó, sin acta, y tampoco estuvo el 17. Sin fecha no puede vencer, pero sigue abierto | Igual que el anterior |
| Proyección de costo de COP 2.644.653.523 contra COP 2.400.000.000 aprobados (+10,2 %, por encima del umbral de 10 %) | Supera la autoridad del gerente: es un cambio de línea base. Además, el plan vigente aún termina el 2026-01-08 con avance declarado de 28 % y estado rojo | `/pm-escalate` para formularlo, o material del comité (Consejo de Administración) |
| Los dos hitos con acta de recibo (diseño funcional y piloto con asociados) | No tienen nada pendiente | — |

### Anexo — sin cambios desde la reunión del 2026-10-17
Es la primera lectura de este proyecto y no hay corte anterior que restar; tomé la reunión del 17 como corte. No se repasan en la reunión.
- Camilo Beltrán · Revisar el anexo 11 — 2026-11-11 (reprogramado 2 veces; vigilar)
- Beatriz Cuéllar · Entregar el punto 24 — 2026-11-07
- Sandra Gil · Entregar el punto 16 — 2026-11-29 (se toca dentro del punto 2)
- Incidencias sin dueño ni fecha de inicio: rotación del desarrollador clave (dos semanas perdidas) y prueba de carga que no alcanzó el umbral y se repite
- 9 compromisos cerrados con acta de recibo

Total: 10 + 8 + 12 + 7 + 3 = 40 minutos.

### Después
Cuando termine la reunión, `/pm-minutes` sobre la transcripción o las notas. Esta agenda no convoca a nadie: citar es del gerente. Dos cosas que no sé y que cambian la agenda: quién tiene la facultad de aceptar una reprogramación, y si las notas de cinco líneas del 2026-10-17 dejaron fuera algo que sí se dijo.
