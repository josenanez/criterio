# Acta — Crédito de libranza digital (PRY-200) · 2026-10-17
**Asistieron:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` (notas de 5 líneas, no transcripción) · **Ausentes con tema en agenda:** no se puede decir; las notas no traen agenda. La lista de asistentes es idéntica a la del 2026-10-10.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Gustavo Neira | Enviar el documento 1 («lo de enviar el documento 1 no alcanzó», línea 4) | 2026-12-04 | **Reprogramado por 6.ª vez.** Promesa original 2026-09-12; fechas: 09-25, 10-05, 10-26, 11-03, 11-20, 12-04 |
| Óscar Ramírez | Revisión con el proveedor («queda para el 2026-10-27», línea 6) | 2026-10-27 | Nuevo. Ver «Sin resolver» sobre su relación con «Aprobar el diseño 21» |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», línea 5). Eso no es una fecha y no se calculó |

(Ya había otro sin fecha en el expediente: Javier Hoyos, «Validar el ambiente 12». Esta reunión no lo tocó.)

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Si se sigue aceptando que «Enviar el documento 1» se reprograme una sexta vez | Se aceptó la fecha nueva sin comentario; lleva 12 semanas corridas de atraso sobre la promesa original | No consta en el expediente (`identity.authority` está en `not_found`) |

## Intenciones sin doliente
Ninguna en esta reunión.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» (línea 7; «nadie lo anotó como riesgo») | Las notas dicen «se comentó»: **no atribuyen quién** | Riesgo | No. Quedó en la ficha como riesgo sin probabilidad, impacto ni dueño, marcado «dicho en la reunión». Nadie es su doliente |

## Cerrado en esta reunión
Nada. Ningún compromiso se cerró contra documento. (Se omite el detalle de las secciones vacías.)

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-31) | `cycle.committee: weekly`; las seis reuniones previas fueron semanales | Notas 2026-10-17 · config de PRY-200. La fecha `committee_next: 2026-10-31` sí coincide con las dos semanas |

No contradice sponsor, gerente, fechas de cierre ni comité.

## Sin resolver de la transcripción
- «Gustavo Neira … se compromete para el 04/12/2026» (línea 4): se leyó 4 de diciembre (día/mes), porque el 12 de abril ya pasó y encaja con la tendencia de las fechas anteriores. Confirmar con Gustavo.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27» (línea 6): «queda para» podría ser una reprogramación de «Aprobar el diseño 21» (vencía el 2026-10-20) o un compromiso distinto. No se unieron porque nada lo dice; ambos siguen abiertos.
- «El proveedor» (línea 7): las notas no lo nombran y el expediente tiene `vendors: []`; no se sabe de cuál contrato se habla.
- Las notas no mencionan los cuatro compromisos que están vencidos sin evidencia (Paula Céspedes, Felipe Arango, Laura Vélez, Carlos Peña) ni nada sobre ellos: no se dijo si se cerraron o se reprogramaron.

## Cálculo (`compute`, sin `record_issues`)
Del expediente completo: 4 compromisos vencidos sin evidencia (Paula Céspedes 7 d, Felipe Arango 10 d, Laura Vélez 9 d, Carlos Peña 1 d), 2 sin fecha, 2 reprogramados 3 o más veces (Gustavo Neira 6, Sandra Gil 5).

## Después
`/pm-commitments` para el seguimiento completo con lo que entró hoy. `/pm-publish` no es urgente: ningún campo de la ficha cambió por esta reunión. **El acta sale aquí y la guardas tú; no se escribió en tu carpeta de reuniones.**
