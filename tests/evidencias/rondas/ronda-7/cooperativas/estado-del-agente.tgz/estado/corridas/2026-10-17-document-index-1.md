# Corrida del 2026-10-17 · document-index

13 proyectos · 26 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

89 documentos, 0 por releer, 0 cambios. 15 citas de PRY-200 marcadas source_missing aunque los archivos citados existen; probable diferencia de ruta (prefijo del proyecto), sin confirmar.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 15 citas de **PRY-200** como `source_missing`:

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-200 | identity.code, name, business_area, product, sponsor, manager, committee (7 campos) | 00-gobierno/2025-06-26-acta-constitucion.docx |
| PRY-200 | plan.start_date, scope_summary, exclusions (3 campos) | 00-gobierno/2025-06-26-acta-constitucion.docx |
| PRY-200 | money.approved | 00-gobierno/2025-06-26-acta-constitucion.docx |
| PRY-200 | plan.end_date | 10-plan/2025-06-26-cronograma-v1.csv |
| PRY-200 | money.committed, executed, projection (3 campos) | 20-seguimiento/2026-10-13-informe-avance.md |

**Lo que no puedo afirmar:** los tres archivos citados **sí existen** en la carpeta de PRY-200 y ningún documento figura como borrado, renombrado o cambiado. La ficha cita con la ruta completa (`PRY-200-crédito-de-libranza-digital/00-gobierno/…`) y el índice reporta la ruta sin el prefijo del proyecto. Lo más probable es una diferencia de resolución de rutas y no una cita rota, pero no lo verifiqué en el código del script. Trátalo como una señal por confirmar. Mientras tanto, esos 15 datos siguen sustentados por documentos presentes y sin cambio.

### Formatos que no se pudieron leer
Este comando no lee documentos, solo los cuenta y los compara. No se reportan formatos ilegibles.

---
Nada que releer: no hace falta `/portfolio-scan`. Queda por revisar la señal de citas de PRY-200 descrita arriba.
