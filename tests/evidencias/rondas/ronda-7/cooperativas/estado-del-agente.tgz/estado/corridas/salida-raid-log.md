## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-17

**Sale de:** las 13 fichas en `estado/records/`, los informes de avance, las actas de constitución, las solicitudes de cambio, las minutas de comité (13 en `30-reuniones/`) y `PRY-200…/2026-10-17-notas-reunion.txt`. Escala de valoración: la organización no define una; se usaría alta/media/baja, pero ningún ítem trae probabilidad ni impacto, así que no se inventa ninguna.

**44 ítems en el registro**, ya reclasificados: 10 riesgos · 0 supuestos · 23 incidencias · 10 dependencias · 1 riesgo absorbido por una incidencia
**44 sin doliente** · **ninguno con fecha de vencimiento** · **0 con movimiento medible** (ningún ítem trae "último movimiento"; no se puede decir "sin movimiento en dos períodos", solo que no hay con qué medirlo) · **1 no registrado formalmente**

> Ningún acta de constitución declara dependencias (las 13 dicen "Ninguna declarada"). Todas las dependencias de abajo salieron de los informes de avance, escritas como riesgos.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-199-01, PRY-203-19, PRY-204-24, PRY-207-34 | Dependencia | Dependencia del proveedor del core cooperativo | no declarado | informes 2026-10-08 a 10-15 | Afecta a otros proyectos: cuatro dependen de PRY-202, que está en rojo con 46% de avance y cuyo cronograma v1 lo da por cerrado (informe 2026-10-15). |
| PRY-204-26 | Incidencia | El cronograma v2 (2026-10-08) mueve el piloto 116 días; la solicitud de cambio CC-01 que lo pide es del 2026-10-15 y no ha llegado al comité | no declarado | 2026-10-15 | Excede la autoridad del gerente: el tiempo ya se movió sin cambio aprobado. |
| PRY-204-25 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto (el riesgo "aprobación del reglamento" ya ocurrió) | no declarado | 2026-10-08 | Doliente fuera del proyecto; se suma al corrimiento del piloto. |
| PRY-208-37 | Incidencia | El cronograma v2 mueve el piloto 59 días; CC-01 del 2026-10-13 pendiente de comité | no declarado | 2026-10-14 | Mismo caso que PRY-204: el movimiento precede a la aprobación. |
| PRY-200-07 | Riesgo no registrado | El proveedor podría no llegar con el equipo completo para la siguiente fase | no declarado | 2026-10-17 | Se suma a la pérdida de dos semanas por rotación y a una prueba de carga fallida; sin doliente ni fecha. |
| PRY-201-12, PRY-205-28 | Incidencia | Hallazgo de seguridad de la revisión de arquitectura | no declarado | 2026-10-16 y 2026-09-27 | En PRY-205 lleva 20 días abierto sin doliente ni fecha. |
| PRY-206-33 | Incidencia | Cronograma v2 cierra la salida a producción el 2026-04-30, pero las actas de recibo son del 2026-10-10 y 10-16; informe en rojo, 45% | no declarado | 2026-10-16 | Lo reportado no coincide con la evidencia. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo" | Riesgo (no registrado formalmente) | PRY-200, `2026-10-17-notas-reunion.txt` | 2026-10-17 |

Es el único. Las otras minutas (PRY-200 de septiembre y octubre, 199, 202, 203, 207, 209, 210 y 211) solo traen compromisos; no dicen nada que sea riesgo. No inventé ninguno. Las notas del 2026-10-17 dicen además que Laura Vélez "queda de mandar el ajuste del presupuesto la otra semana" (compromiso, no riesgo) y que Gustavo Neira vuelve a aplazar «enviar el documento 1» al 2026-12-04.

### Sin doliente o sin fecha
Faltan doliente y fecha en **los 44 ítems**; no se rellenaron. En 3 incidencias de PRY-200 tampoco hay fecha de inicio ("desde"). El detalle por ítem está en el registro completo (columnas Doliente y Fecha).

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-199-01 | PRY-202 (inferido: el proveedor del core es el de PRY-202) | No (declarada, no acordada) | Dependencia del proveedor del core cooperativo. PRY-202 está en rojo, 46% de avance (informe 2026-10-15) y tiene una incidencia de prueba de carga. |
| PRY-202-14 | Proveedor del core (propio proyecto) | No (declarada, no acordada) | Dependencia del proveedor del core cooperativo.  |
| PRY-202-15 | Consejo de Administración (externo al proyecto) | No (declarada, no acordada) | Aprobación del reglamento por el Consejo de Administración. En PRY-204 la misma aprobación ya fue observada por el Consejo (pidió ajustes antes del piloto). |
| PRY-203-19 | PRY-202 (inferido: el proveedor del core es el de PRY-202) | No (declarada, no acordada) | Dependencia del proveedor del core cooperativo. PRY-202 está en rojo, 46% de avance (informe 2026-10-15) y tiene una incidencia de prueba de carga. |
| PRY-203-20 | Consejo de Administración (externo al proyecto) | No (declarada, no acordada) | Aprobación del reglamento por el Consejo de Administración. En PRY-204 la misma aprobación ya fue observada por el Consejo (pidió ajustes antes del piloto). |
| PRY-204-24 | PRY-202 (inferido: el proveedor del core es el de PRY-202) | No (declarada, no acordada) | Dependencia del proveedor del core cooperativo. PRY-202 está en rojo, 46% de avance (informe 2026-10-15) y tiene una incidencia de prueba de carga. |
| PRY-206-31 | Proveedor externo (sin proyecto del portafolio) | No (declarada, no acordada) | El proveedor no ha confirmado la fecha de la última entrega. La fecha de la última entrega sigue sin confirmar. |
| PRY-207-34 | PRY-202 (inferido: el proveedor del core es el de PRY-202) | No (declarada, no acordada) | Dependencia del proveedor del core cooperativo. PRY-202 está en rojo, 46% de avance (informe 2026-10-15) y tiene una incidencia de prueba de carga. |
| PRY-208-35 | Proveedor externo (sin proyecto del portafolio) | No (declarada, no acordada) | El proveedor no ha confirmado la fecha de la última entrega. La fecha de la última entrega sigue sin confirmar. |
| PRY-209-39 | Proveedor externo (sin proyecto del portafolio) | No (declarada, no acordada) | El proveedor no ha confirmado la fecha de la última entrega. La fecha de la última entrega sigue sin confirmar. |

Reclasificadas: las que el informe llama "riesgo" y son algo que el proyecto necesita de un tercero sin controlarlo. El código PRY-202 se infiere por el nombre ("proveedor del core cooperativo"); ningún documento lo declara, así que hay que confirmarlo. PRY-202 no tiene cronograma posterior a v1, por lo que no consta que haya "movido su fecha" formalmente; consta que está en rojo y que su v1 contradice su informe.

### Reclasificado, y por qué
- 10 "riesgos" pasaron a **dependencia**: la prueba es que dependen de alguien fuera del proyecto (core, proveedor, Consejo).
- PRY-204 "aprobación del reglamento" pasó a **incidencia absorbida**: el Consejo ya pidió ajustes, así que dejó de ser futuro; ya existe la incidencia PRY-204-25.
- Los ítems de incidencia que comparan cronograma, acta e informe (PRY-202, 203, 206, 208, 211) son discrepancias entre documentos, más que hechos del proyecto; se dejaron como incidencias y quedan para que el gerente confirme.

### Registro completo
Ids propios de este barrido (código-número); ninguno viene del registro de los proyectos. "Prob." e "Impacto" no declarados donde no hay dato.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199-01 | Dependencia | Dependencia del proveedor del core cooperativo | no declarada | no declarada | no declarado | — | — |
| PRY-199-02 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarada | no declarado | — | — |
| PRY-199-03 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | no declarado | — | 2026-10-15 |
| PRY-199-04 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes; ningún cronograma posterior a v1 registra el movimiento | — | — | no declarado | — | 2026-10-15 |
| PRY-200-05 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarada | no declarado | — | — |
| PRY-200-06 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarada | no declarado | — | — |
| PRY-200-07 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión; nadie lo anotó como riesgo) | no declarada | no declarada | no declarado | — | — |
| PRY-200-08 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | no declarado | — | — |
| PRY-200-09 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | no declarado | — | — |
| PRY-200-10 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | no declarado | — | — |
| PRY-201-11 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarada | no declarado | — | — |
| PRY-201-12 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | — | — | no declarado | — | 2026-10-16 |
| PRY-201-13 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes; no existe cronograma posterior a v1 que registre la nueva fecha | — | — | no declarado | — | 2026-10-16 |
| PRY-202-14 | Dependencia | Dependencia del proveedor del core cooperativo | no declarada | no declarada | no declarado | — | — |
| PRY-202-15 | Dependencia | Aprobación del reglamento por el Consejo de Administración | no declarada | no declarada | no declarado | — | — |
| PRY-202-16 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | — | — | no declarado | — | 2026-10-15 |
| PRY-202-17 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | no declarado | — | 2026-10-15 |
| PRY-202-18 | Incidencia | El cronograma v1 declara cerrados los cinco hitos, incluida la salida a producción del 2026-05-23, y el informe del 2026-10-15 reporta 46% de avance en rojo; el acta de recibo del ambiente de pruebas es del 2026-10-09, frente a una fecha de hito del 2025-11-09 | — | — | no declarado | — | 2026-10-15 |
| PRY-203-19 | Dependencia | Dependencia del proveedor del core cooperativo | no declarada | no declarada | no declarado | — | — |
| PRY-203-20 | Dependencia | Aprobación del reglamento por el Consejo de Administración | no declarada | no declarada | no declarado | — | — |
| PRY-203-21 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes; no existe cronograma posterior a v1 que registre la nueva fecha | — | — | no declarado | — | 2026-10-08 |
| PRY-203-22 | Incidencia | El cronograma v1 declara cerrados los tres hitos y el cierre comprometido en el acta es 2026-01-17; el informe del 2026-10-08 reporta 28% de avance en verde | — | — | no declarado | — | 2026-10-08 |
| PRY-204-23 | Absorbido por incidencia | Aprobación del reglamento por el Consejo de Administración | no declarada | no declarada | no declarado | — | — |
| PRY-204-24 | Dependencia | Dependencia del proveedor del core cooperativo | no declarada | no declarada | no declarado | — | — |
| PRY-204-25 | Incidencia | El Consejo de Administración pidió ajustar el reglamento antes del piloto | — | — | no declarado | — | 2026-10-08 |
| PRY-204-26 | Incidencia | El cronograma v2 (2026-10-08) ya mueve el piloto 116 días; la solicitud de cambio CC-01 que pide ese tiempo es del 2026-10-15 y está pendiente de presentación al comité | — | — | no declarado | — | 2026-10-15 |
| PRY-205-27 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarada | no declarado | — | — |
| PRY-205-28 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura | — | — | no declarado | — | 2026-09-27 |
| PRY-205-29 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes; la carpeta no tiene cronograma que registre la fecha | — | — | no declarado | — | 2026-09-27 |
| PRY-206-30 | Riesgo | Concentración del conocimiento en una sola persona | no declarada | no declarada | no declarado | — | — |
| PRY-206-31 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | no declarado | — | — |
| PRY-206-32 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes | — | — | no declarado | — | 2026-10-16 |
| PRY-206-33 | Incidencia | El cronograma v2 declara cerrada la salida a producción con fecha 2026-04-30, pero las actas de recibo de la integración con el core (2026-10-10) y del piloto (2026-10-16) son posteriores; el informe del 2026-10-16 reporta 45% en rojo | — | — | no declarado | — | 2026-10-16 |
| PRY-207-34 | Dependencia | Dependencia del proveedor del core cooperativo | no declarada | no declarada | no declarado | — | — |
| PRY-208-35 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | no declarado | — | — |
| PRY-208-36 | Incidencia | La prueba de carga no alcanzó el umbral pactado y se repite | — | — | no declarado | — | 2026-10-14 |
| PRY-208-37 | Incidencia | El cronograma v2 (2026-10-14) ya mueve el piloto 59 días; la solicitud de cambio CC-01 que pide ese tiempo es del 2026-10-13 y está pendiente de presentación al comité | — | — | no declarado | — | 2026-10-14 |
| PRY-208-38 | Incidencia | El acta de recibo del diseño funcional es del 2026-10-15, posterior al informe del 2026-10-14; el hito tenía fecha 2026-06-28 | — | — | no declarado | — | 2026-10-15 |
| PRY-209-39 | Dependencia | El proveedor no ha confirmado la fecha de la última entrega | no declarada | no declarada | no declarado | — | — |
| PRY-209-40 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarada | no declarado | — | — |
| PRY-209-41 | Incidencia | Se reprogramó la salida por el cierre contable de fin de mes; no existe cronograma posterior a v1 que registre la nueva fecha | — | — | no declarado | — | 2026-10-13 |
| PRY-210-42 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarada | no declarado | — | — |
| PRY-211-43 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | no declarada | no declarada | no declarado | — | — |
| PRY-211-44 | Incidencia | El informe reporta 74% de avance y ningún hito del cronograma está cerrado (el primero vence el 2026-11-23) | — | — | no declarado | — | 2026-10-16 |

### Ofrezco
- Subir a comité (2026-10-24): la dependencia del core hacia PRY-202, las dos solicitudes CC-01 (204 y 208) y los dos hallazgos de seguridad. Cada una con su decisión formulada.
- Proponer doliente para los 44 ítems. Proponer, no asignar: no lo hice porque ningún documento dice quién es.

**Cierre de rigor.** Todo lo de arriba sale de las fichas y de los documentos citados; no leí PDF ni Excel originales en este barrido, solo el texto ya convertido y las fichas. No sé quién es doliente de nada, ni si los riesgos de los informes están vigentes. La clasificación de dependencias es mía y debe verificarse. 
