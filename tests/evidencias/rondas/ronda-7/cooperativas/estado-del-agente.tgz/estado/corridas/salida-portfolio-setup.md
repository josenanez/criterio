## Listo — Cooperativa

**Miré:** 89 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 38, .docx 17, .pdf 17, .xlsx 8, .csv 7, .json 1, .txt 1 · más reciente: 2026-10-17
**Eres:** PMO del portafolio (con varios proyectos, es lo que se propone)
**Te aviso:** dos días antes del comité (semanal; el próximo, 2026-10-24, que es el ritmo que muestran las minutas de la carpeta)
**En:** presentación (por defecto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 6d4b67767ea3a1ea…

Decisiones que tomé por ti, porque nadie podía responder: comité semanal con próxima fecha 2026-10-24, formato presentación, sin destinatarios, y estado e informes junto a tus documentos (`estado/`, `reportes/`). Cada vez que un comando pida un dato que no existe, lo diré en vez de inventarlo.

### Probé con tres proyectos

Los tres de documentación más reciente. Fichas escritas y selladas en `estado/records/`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Crédito de libranza digital | 22 | Gerente Rubén Cárdenas, patrocinador Jorge Medina, Consejo de Administración (acta 2025-06-26). Declara **rojo, 28%** (informe 2026-10-13). 2.400 M COP aprobados; comprometido 1.398 M, ejecutado 929 M, proyección 2.645 M. Cierre aprobado 2026-01-08, 4 hitos declarados cerrados. 25 compromisos en 7 reuniones. El gerente publicó su propia ficha (`ficha-pm.json`); quedó aparte, en `pm_record`. | Facultad del gerente, fase |
| PRY-207 Microcrédito rural | 4 | Gerente Paula Céspedes, patrocinador Óscar Ramírez, Consejo de Administración (acta 2026-04-08). Declara **amarillo, 37%** (2026-10-14). 1.200 M aprobados; comprometido 531 M, ejecutado 527 M, proyección 1.121 M. Cierre 2027-09-11. | Facultad del gerente, fase |
| PRY-210 Corresponsales rurales | 4 | Gerente Mauricio Pérez, patrocinador Rubén Cárdenas, Comité de Crédito (acta 2025-05-23). Declara **verde, 73%** (2026-10-12). 3.300 M aprobados; comprometido 2.429 M, ejecutado 1.479 M, proyección 3.154 M. Cierre aprobado 2026-09-06. | Producto (el acta dice «No aplica»), facultad del gerente, fase |

### Lo que levantó el cálculo (19 señales, las tres con alguna)

**PRY-210 · verde contradicho.** El informe dice verde y 73%, pero el cronograma declara sus 3 hitos cerrados y no hay un solo acta de recibo (`milestone_met_without_evidence`, 349, 195 y 41 días desde que vencieron). Con 3 de 3 hitos cerrados el plan sustenta 100% y el informe dice 73% (`progress_vs_plan`, 27 puntos). La fecha de cierre aprobada, 2026-09-06, ya pasó. Señal de portafolio: `declared_vs_evidence`.

**PRY-200 · rojo, y por buenas razones.**
- Avance declarado 28% contra 4 de 4 hitos cerrados (`progress_vs_plan`, 72 puntos). Dos de esos hitos no tienen acta: Ambiente de pruebas certificado (375 días) e Integración con el core cooperativo (328 días). Los actas que sí existen son de Diseño funcional (fechada 2026-10-17) y Piloto con asociados (2026-10-10).
- Proyección 10,2 % sobre lo aprobado (`variance_cost`).
- Compromisos vencidos: Paula Céspedes «Confirmar la fecha 7» (7 días; dijo que ya lo entregó y no hay acta), Felipe Arango «Enviar el documento 17» (10), Laura Vélez «Cerrar la prueba 18» (9), Carlos Peña «Actualizar la matriz 22» (1).
- Sin fecha: Javier Hoyos «Validar el ambiente 12» y Laura Vélez «Mandar el ajuste del presupuesto».
- Reprogramados: Gustavo Neira «Enviar el documento 1», 6 veces (del 2026-09-12 al 2026-12-04); Sandra Gil «Cerrar la prueba 2», 5 veces (del 2026-09-14 al 2026-12-07). Es un bloqueo que nadie ha nombrado.

**PRY-207 · amarillo con dos señales.** El hito Diseño funcional aprobado venció el 2026-10-05 (12 días) sin acta (`milestone_overdue`), y el compromiso de Diana Molina «Entregar el punto 37» (para 2026-10-16) venció un día antes de la reunión que lo registra (`commitment_overdue`).

No levantó: cambio de gobierno, contradicciones entre documentos, silencio (los tres tienen documentos de esta semana) ni diferencias entre la ficha del gerente y la mía en PRY-200.

### El portafolio completo
10 proyectos más (PRY-199, 201 a 206, 208, 209, 211) y 59 documentos, en 2 lotes uno tras otro. Con lo que tomó este ensayo, calculo del orden de 30 a 45 minutos de conversación; la siguiente corrida releerá solo lo que cambie.

### Lo que le falta a tu carpeta
- **Ningún acta dice hasta dónde decide el gerente** (3 de 3). Sin eso el control de cambios no puede saber si algo excede su facultad.
- **Datos viejos sin confirmar:** nombre, patrocinador, gerente, alcance y presupuesto de PRY-200 y PRY-210 vienen de actas de hace 16 y 17 meses; nadie los ha reconfirmado.
- **PRY-200 no tiene línea base nueva** aunque el cierre aprobado fue el 2026-01-08 y los compromisos llegan a diciembre de 2026.
- **Los hitos cerrados sin acta** (PRY-200: 2; PRY-210: 3) son lo que más mejoraría el análisis si aparecieran los actas de recibo.
- El alcance de los tres proyectos es «Componente 1, 2, 3» sin descripción.
- Las notas de la reunión de PRY-200 del 2026-10-17 están en la raíz del proyecto, fuera de `30-reuniones/`; el compromiso de Gustavo Neira trae la fecha como «04/12/2026» y la leí como 4 de diciembre.
- Solo PRY-200 tiene ficha de gerente (`ficha-pm.json`).

Ninguno de estos puntos bloquea nada: el análisis ya funciona con lo que hay.

### Siguiente paso
¿Corro el portafolio completo? Como eres PMO y tienes equipo, también puedo publicar el estándar en una carpeta compartida para que tus gerentes de proyecto usen los mismos criterios.
