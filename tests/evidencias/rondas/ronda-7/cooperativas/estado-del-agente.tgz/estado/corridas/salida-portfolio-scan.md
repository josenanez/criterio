## Barrido — 2026-10-17

**Términos:** vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

**Documentos:** 89 en la carpeta · 59 leídos · 30 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 201, 202, 203, 204, 205, 206, 208, 209, 211) · 3 sin cambio (PRY-200, 207, 210) · 0 sin carpeta propia

Formatos: 38 .md, 17 .docx, 17 .pdf, 8 .xlsx, 7 .csv, 1 .txt, 1 .json. Se leyeron 59 de 89; no quedó nada diferido (tope de 400 por corrida). Un solo lote de 10 proyectos, uno tras otro, sin subagentes.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, dinero, 1 contrato (3 entregables), 2 riesgos, 1 compromiso | autoridad, fase |
| PRY-201 Apertura de ahorro en línea | 10 | identidad, plan, dinero, 2 contratos (5 entregables, 2 facturas), 1 riesgo | autoridad, fase |
| PRY-202 Core cooperativo | 9 | identidad, plan, dinero, 2 contratos (5 entregables, 1 factura), 2 riesgos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-203 Aportes sociales en línea | 4 | identidad, plan, dinero, 2 riesgos, 1 compromiso | autoridad, fase |
| PRY-204 Tarjeta débito para asociados | 5 | identidad, plan (v1 y v2), dinero, CC-01, 2 riesgos | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 2 | identidad, plan (solo fechas del acta), dinero, 1 riesgo | producto («No aplica»), autoridad, fase; sin cronograma ni hitos |
| PRY-206 Pagos con QR | 9 | identidad, plan (v1 y v2), dinero, 1 contrato (3 entregables, 1 factura), CC-01, 2 riesgos | autoridad, fase |
| PRY-208 Motor de crédito | 6 | identidad, plan (v1 y v2), dinero, CC-01, 1 riesgo | producto («No aplica»), autoridad, fase |
| PRY-209 Convenios de libranza con empresas | 4 | identidad, plan, dinero, 2 riesgos, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 4 | identidad, plan, dinero, 1 riesgo, 1 compromiso | autoridad, fase |

En ningún proyecto aparece la autoridad del gerente ni la fase. Ninguna ficha quedó con campos en conflicto entre documentos.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| (ninguno) | Los 10 proyectos leídos no tenían ficha previa; PRY-200, 207 y 210 no cambiaron y no se releyeron. | — |

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 89 archivos se convirtieron a texto. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | La carpeta de documentos no tiene `entrada/`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | — |

## Lo que hay que mirar (sin esperar al informe)

**Línea base movida antes de que la autorice el comité**
- PRY-204: el cronograma v2 (2026-10-08) mueve el piloto del 2026-10-04 al 2027-01-28 (+116 días). La solicitud CC-01 que pide esos 116 días es del 2026-10-15 y dice «pendiente de presentación al comité».
- PRY-208: el cronograma v2 (2026-10-14) mueve el piloto del 2027-01-26 al 2027-03-26 (+59 días). CC-01 es del 2026-10-13 y sigue pendiente de presentación.
- PRY-206: el caso en regla. CC-01 (+36 días) figura «autorizada por el comité» y el v2 mueve la salida del 2026-03-25 al 2026-04-30. El documento no nombra qué comité.

**Proveedores**
- PRY-206: factura FV-1399 por 96.483.298 COP (2026-09-18) contra CT-399, y ninguno de sus tres entregables tiene acta de recibo; todos vencieron entre 2025-08 y 2026-01.
- PRY-202: CT-645 (Integración Financiera del Sur) tiene tres entregables de 493.722.333 COP, todos vencidos (2025-09-30, 2025-12-28, 2026-03-27) y sin acta; CT-171, Licenciamiento del módulo, venció el 2025-10-30 sin acta.
- PRY-201: CT-856, bolsa de horas (2026-08-01) y parametrización (2026-10-01) vencidas sin acta.
- PRY-199: CT-199 sin facturas; el primer entregable vence el 2026-11-16.

**Hitos declarados cerrados sin un acta que lo pruebe** (la declaración se conserva; falta el documento)
- PRY-201: 4 de 4 · PRY-202: 4 de 5 (solo el ambiente de pruebas tiene acta, del 2026-10-09 frente a una fecha de hito del 2025-11-09) · PRY-203: 3 de 3 · PRY-204: 3 de 3 · PRY-206: 3 de 5 (con acta: integración y piloto, ambas posteriores a la salida a producción declarada cerrada el 2026-04-30) · PRY-208: 1 de 2 (el diseño funcional sí tiene acta, del 2026-10-15; el hito era del 2026-06-28).
- PRY-209: el diseño funcional vencía el 2026-10-09, sigue «en curso» y sin acta.

**El estado declarado no cuadra con los documentos**
- PRY-203: verde con 28%, y el acta fijaba el cierre al 2026-01-17 con los tres hitos del cronograma cerrados.
- PRY-202: rojo con 46%, y el cronograma v1 declara cerrada la salida a producción del 2026-05-23.
- PRY-211: amarillo con 74% sin ningún hito cerrado (el primero vence el 2026-11-23).
- PRY-199: verde con 20%, con una prueba de carga que no alcanzó el umbral.
- PRY-205: amarillo con 55%, cierre del acta al 2026-01-01 y sin cronograma en la carpeta.
- Seis informes dicen «Se reprogramó la salida por el cierre contable» (PRY-199, 201, 203, 205, 206, 209) y ninguno tiene un cronograma posterior que registre la nueva fecha, salvo PRY-206.

**Dinero** (según los informes, sin recalcular)
- Ejecutado por encima de lo comprometido en el mismo informe: PRY-201, 202, 203, 205 y 209.
- PRY-205: proyección al cierre 4.267.213.372 sobre un aprobado de 4.200.000.000. PRY-206: proyección 1.522.401.880 sobre 1.200.000.000. PRY-211: 18.775.312.801 sobre 18.000.000.000. PRY-201: 1.236.335.536 sobre 1.200.000.000.

**Compromisos de minutas**
- PRY-203: Jorge Medina, «Entregar el punto 13», para el 2026-10-14; sin evidencia de entrega, vencido.
- PRY-202 (Paula Céspedes, punto 4) y PRY-211 (Óscar Ramírez, punto 28): fecha «por definir».
- PRY-199 (Carlos Peña, 2026-11-06) y PRY-209 (Óscar Ramírez, 2026-10-19): abiertos.
- En los cinco, quien se compromete no figura entre los asistentes de la reunión.

**Fuera del alcance de este barrido**
- PRY-200: el índice marca 15 citas de su `ficha-pm` que no resuelven desde la raíz de documentación (apuntan a rutas sin el prefijo de la carpeta del proyecto). No se tocó su ficha.

## Pie

criterio-portfolio 0.3.13 · términos v1.1 (aceptados por José Francisco Ñáñez, 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
Fichas tocadas: 10 (PRY-199, 201, 202, 203, 204, 205, 206, 208, 209, 211) · 3 sin cambio.
Campos en `not_found`: `identity.authority` e `identity.phase` en las 10; `identity.product` además en PRY-202, 205, 208 y 209.
