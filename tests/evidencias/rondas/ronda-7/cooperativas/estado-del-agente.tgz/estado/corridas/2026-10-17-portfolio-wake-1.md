# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 31 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Barrido: 89 documentos sin cambios, 0 proyectos recalculados. Confirmación: 5 preguntas propuestas sobre PRY-200, sin respuesta (sesión sin interfaz). 15 citas del pm_record de PRY-200 no resuelven por ruta sin prefijo de carpeta; los archivos existen. No sé si esas rutas las corrige el publicador de la ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 89 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Tocaban barrido y confirmación; el informe de comité toca el 2026-10-22 (comité el 2026-10-24).

### Lo que cruzó un umbral
Nada. Ningún documento nuevo, cambiado, renombrado ni borrado.

Una observación sobre citas: el índice marca 15 campos de `pm_record` de PRY-200 como «fuente no encontrada» (acta de constitución, cronograma v1, informe de avance del 2026-10-13). Los archivos sí existen en `documentos/proyectos/PRY-200-crédito-de-libranza-digital/`. La ficha del portafolio cita con el prefijo de la carpeta del proyecto y resuelve; la copia de `pm_record` incrustada cita sin ese prefijo y no. Es una diferencia de forma de la ruta, no un documento perdido. No la corregí: escribir las citas de esa copia le toca a quien publica la ficha del proyecto.

### Peticiones atendidas
Ninguna: no había peticiones en el servidor.

### Preguntas
Nadie responde en esta sesión, así que no se preguntó a nadie. Quedan propuestas cinco para PRY-200, elegidas por importancia, que son las de dinero y fecha de fin cuya cita no resolvía:
1. Presupuesto aprobado (COP 2.400.000.000), acta de constitución del 2025-06-26. ¿Sigue vigente?
2. Comprometido, informe de avance del 2026-10-13.
3. Ejecutado, informe de avance del 2026-10-13.
4. Proyección, informe de avance del 2026-10-13.
5. Fecha de fin, cronograma v1 del 2025-06-26. ¿Es la fecha vigente o hubo replanificación?

Respuesta sugerida tomada: dejarlas abiertas, sin respuesta.

**Vuelvo el 2026-10-18.**
