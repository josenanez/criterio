# Corrida del 2026-10-17 · status-report

13 proyectos · 24 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Estado de PRY-205: declarado amarillo 55% sin sustento documental; silencio de 20 días; cierre 2026-01-01 vencido sin línea base nueva ni hitos. No se sabe: reuniones, cronograma, producto, autoridad, fase.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-205.json` (actualizada 2026-10-17) y el cálculo de `portafolio.py compute` al 2026-10-17. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-17).

## PRY-205 · Prevención de lavado de activos — estado al 2026-10-17

**Declara el gerente (Ricardo Salas):** amarillo · 55% · al 2026-09-27 (hace 20 días; dentro de los 30 en que la declaración se considera vigente)
**Sustento documental:** sin sustento. De 14 fuentes de la ficha, 0 están marcadas como evidencia y 0 como declaración; 14 sin marcar. El único documento de seguimiento es el propio informe de avance (PDF), que es la declaración.
**Lo que el semáforo no explica:** `silent`: 20 días sin documento nuevo (desde 2026-09-27), por encima del umbral de 15.
**Último documento:** 2026-09-27 · **Última reunión:** sin dato (la ficha no tiene reuniones ni compromisos).

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-01-01 | 2026-01-01 | 0 días (0 replanificaciones registradas) |
| Presupuesto aprobado | COP 4.200.000.000 | COP 4.200.000.000 | proyección COP 4.267.213.372 (+1,6 %) |

Dinero (informe del 2026-09-27): comprometido COP 1.472.743.776 (35,1 %); ejecutado COP 1.684.933.618 (40,1 %); disponible real COP 2.727.256.224.
Observación: el ejecutado supera al comprometido, cosa que no debería pasar si lo ejecutado estuvo antes comprometido. Lo dice el informe; no hay otro documento que lo aclare.

Replanificaciones: 0 registradas. Pero el informe menciona que "se reprogramó la salida por el cierre contable de fin de mes" y la carpeta no tiene cronograma que registre la nueva fecha. La desviación de 0 días es, entonces, una ausencia de registro, no una medición de cumplimiento.

### Hitos
Sin hitos. La ficha no tiene cronograma (`plan.milestones` vacío); el acta de constitución fija solo inicio (2025-07-19) y cierre (2026-01-01). No se puede decir qué porcentaje respalda el plan.

### Dónde no coincide
- **Fecha de cierre vs. avance declarado:** el acta (2025-07-09) fija el cierre el 2026-01-01; ya pasó, y el informe del 2026-09-27 declara 55 % y amarillo, sin una fecha vigente nueva ni un cambio aprobado en `changes` (0 solicitudes). El script no marca esto como atraso porque no hay línea base nueva ni hitos contra los cuales medir; hay que mirarlo a ojo.
- **Semáforo vs. silencio:** amarillo declarado hace 20 días, sin documentos posteriores.
- **Alcance:** el acta enumera "Componente 1; 2; 3" y no los describe.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: concentración del conocimiento en una sola persona. Probabilidad, impacto, dueño y fecha: no declarados. Sin movimiento registrado.
- Incidencia: hallazgo de seguridad de la revisión de arquitectura, desde 2026-09-27, sin dueño (20 días).
- Incidencia: reprogramación de la salida por el cierre contable, desde 2026-09-27, sin dueño ni nueva fecha (20 días).
**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos; no es lo mismo que no haberlos).
**Dependencias sin confirmar:** ninguna registrada. La exclusión "lo que otro proyecto cubre" no nombra a cuál.

### Sin dato
- `identity.product`, `identity.authority`, `identity.phase`: no encontrados.
- 11 campos con más de 12 meses de antigüedad (15 meses, del acta de 2025-07-09): código, nombre, área, patrocinador (Felipe Arango), gerente, comité (Comité de Riesgos), inicio, cierre, alcance, exclusiones y presupuesto aprobado.
- Cronograma, hitos, reuniones, proveedores: no hay.
- El PDF del informe de avance no tiene huella de texto (`text_hash` nulo); conviene confirmar que se leyó completo.

### Después
No hay desviación sobre el umbral según el script, pero sí un cierre vencido sin base nueva, un hallazgo de seguridad sin dueño y un silencio de 20 días. Ofrezco preparar el punto de comité (Comité de Riesgos, próximo 2026-10-24) y una solicitud de cambio que formalice la nueva fecha de cierre. No lo he preparado.

---
Criterio portfolio 0.3.13 · ficha PRY-205 aplicada, actualizada el 2026-10-17 · campos inciertos: producto, autoridad, fase, y los 11 de más de 12 meses · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
