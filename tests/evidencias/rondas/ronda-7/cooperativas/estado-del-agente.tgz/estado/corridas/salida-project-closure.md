## Cierre — PRY-200 Crédito de libranza digital — 2026-10-17

**Sale de:** la ficha `estado/records/PRY-200.json`, el acta de constitución (2025-06-26), el cronograma v1, el informe de avance del 2026-10-13, las 6 actas de comité, las 12 actas de recibo, las notas del 2026-10-17 y la salida de `portafolio.py compute`. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

**Veredicto:** el proyecto **no se puede cerrar por cumplimiento**. Nadie lo ha declarado terminado; el último informe lo declara en **rojo, 28 %**. Si se cierra, se cierra por decisión del Consejo de Administración, no porque se haya cumplido. Esta acta es el borrador de ese cierre y no lo declara.

### Contra lo comprometido
**Criterio de éxito:** «Crédito de libranza digital en producción y medido.» (`00-gobierno/2025-06-26-acta-constitucion.docx`)
**Se cumplió:** **no se puede determinar**. Ningún documento muestra el producto en producción ni una medición. El acta de piloto con asociados (2026-10-10) recibe el piloto, pero un piloto no es producción. El avance declarado (28 %) contradice los 4 de 4 hitos marcados como cumplidos.

El acta no describe el alcance: dice «Componente 1; Componente 2; Componente 3» sin más. Por eso el contraste entregado contra comprometido solo se puede hacer con los 4 hitos del cronograma v1.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (línea base 2025-08-21) | Cumplido, con evidencia tardía | Acta de recibo del 2026-10-17: 422 días después de la fecha de línea base. No calculé esa cifra con el script; sale de comparar las dos fechas. |
| Ambiente de pruebas certificado (2025-10-07) | Declarado cumplido, **sin evidencia** (375 días desde su fecha) | Ninguna |
| Integración con el core cooperativo (2025-11-23) | Declarado cumplido, **sin evidencia** (328 días desde su fecha) | Ninguna |
| Piloto con asociados (2026-01-08) | Cumplido | Acta de recibo del 2026-10-10, 275 días después de la fecha de línea base (cifra mía, no del script) |

Los dos hitos sin evidencia son la mayor brecha del cierre. Los sigue necesitando el informe del 2026-10-13, que dice que «la prueba de carga no alcanzó el umbral pactado y se repite». Eso es difícil de conciliar con un ambiente de pruebas certificado.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Ninguna decisión de recorte registrada | — | — |

El acta solo excluye «lo que otro proyecto cubre», sin decir qué. No hay solicitudes de cambio (0 en el cómputo). No encontré recorte de alcance ni decisión que lo respalde. Con un alcance de «Componente 1, 2 y 3» sin describir, tampoco puedo decir si se recortó algo.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-01-08 | 2026-01-08 | **No hay fecha final** | No calculable |
| Presupuesto (COP) | 2.400.000.000 | 2.400.000.000 | Proyección 2.644.653.523 (no es cifra final) | +10,2 % sobre lo aprobado (señal `variance_cost`) |

Replanificaciones: **0**. La línea base no se movió (versión 1 única).

- Ejecutado: 929.267.306 (38,7 % de lo aprobado). Comprometido: 1.398.098.317 (58,3 %). Disponible real: 1.001.901.683.
- La fecha de cierre comprometida (2026-01-08) ya pasó y el proyecto sigue activo. El script devuelve atraso de 0 días porque nadie replanificó; es un 0 aparente, no un cumplimiento. La línea base no refleja la realidad y no hay una vigente distinta que la sustituya. No escribo un número de días de atraso porque el script no lo da.
- Las cifras de presupuesto son del informe del 2026-10-13, es decir, declaradas por el gerente y no verificadas con ningún documento contable. Hay un compromiso sin fecha: Laura Vélez «mandar el ajuste del presupuesto la otra semana» (notas del 2026-10-17).

### RAID al cierre
**Materializados:**
- Rotación de un desarrollador clave: el equipo perdió dos semanas (informe 2026-10-13). Está sin dueño ni fecha de inicio.
- Prueba de carga por debajo del umbral pactado, se repite (informe 2026-10-13). Sin dueño.

**No materializados (siguen como riesgos, sin valorar):**
- Cambio normativo del supervisor que puede mover el alcance.
- Concentración del conocimiento en una sola persona.
- El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión del 2026-10-17; nadie lo registró).

**Abiertos, con doliente:** ninguno de los riesgos ni las incidencias tiene dueño, probabilidad, impacto ni fecha. Por la regla del cierre, **no están cerrados**: no tienen doliente.

Compromisos abiertos que siguen después de cualquier cierre:
- Vencidos: Paula Céspedes, «Confirmar la fecha 7» (2026-10-10, 7 días); Felipe Arango, «Enviar el documento 17» (2026-10-07, 10 días); Laura Vélez, «Cerrar la prueba 18» (2026-10-08, 9 días); Carlos Peña, «Actualizar la matriz 22» (2026-10-16, 1 día).
- Sin fecha: Javier Hoyos, «Validar el ambiente 12»; Laura Vélez, «Mandar el ajuste del presupuesto».
- Reprogramados: Gustavo Neira, «Enviar el documento 1» (6 veces: del 2026-09-12 al 2026-12-04); Sandra Gil, «Cerrar la prueba 2» (5 veces: del 2026-09-14 al 2026-12-07).

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Dos hitos (ambiente de pruebas e integración con el core) se marcaron como cumplidos sin acta de recibo | Fechas de línea base 2025-10-07 y 2025-11-23; sin evidencia a 2026-10-17 | El avance real no se puede verificar; el comité decide con un 28 % que contradice 4 de 4 hitos | Un hito no se marca cumplido sin su acta de recibo |
| El acta de recibo del diseño funcional se emitió el 2026-10-17 para un hito con fecha 2025-08-21 | 2026-10-17 | La evidencia llega mucho después del hito; durante ese lapso el cumplimiento fue solo declarado | Exigir el acta en la fecha del hito |
| «Enviar el documento 1» se reprogramó 6 veces y «Cerrar la prueba 2» 5 veces, ambas desde septiembre | 2026-09-12 a 2026-10-17 | Cada reunión mueve la fecha sin que nadie diga la causa | Al segundo aplazamiento, escalar con causa y decisión |
| El acta se aprobó sin describir el alcance («Componente 1, 2 y 3») | 2025-06-26 | No se puede contrastar lo entregado contra lo comprometido | No aprobar un acta cuyo alcance no esté descrito |

No incluyo lecciones sobre la causa del atraso (rotación, prueba de carga) más allá del hecho: el informe las menciona pero no dice cuánto del atraso explica cada una. Tampoco sobre el proveedor: la ficha no tiene proveedores registrados (`vendors: []`).

### Sin dato
- Si el producto está o estuvo en producción y medido (el criterio de éxito).
- Cuántos días lleva de atraso el proyecto contra el cierre de 2026-01-08: ni el script ni las fechas vigentes lo dan, porque no hay replanificación registrada.
- Qué cubren «Componente 1, 2 y 3» y qué es «lo que otro proyecto cubre».
- Autoridad y fase del proyecto (campos no encontrados).
- Proveedor, contratos y facturación: ficha sin proveedores.
- Dueño, probabilidad, impacto y fecha de cada riesgo e incidencia.
- Contabilidad real: las cifras de presupuesto son declaradas, sin respaldo contable en la carpeta.
- Los 22 campos de la ficha vienen de documentos de 2025-06-26 (16 meses, sobre el umbral de 12) y no se han reconfirmado.

### Señales que el informe del 2026-10-13 no explica
`commitment_overdue`, `commitment_rescheduled`, `milestone_met_without_evidence`, `progress_vs_plan` y `variance_cost`.

### Qué haría falta para cerrarlo
1. Que el Consejo de Administración decida si cierra por decisión o replanifica (hoy hay 0 replanificaciones y una fecha vencida).
2. Actas de recibo de los dos hitos sin evidencia, o corregirlos como no cumplidos.
3. Dueño con nombre para cada riesgo e incidencia, y para cada compromiso vencido o reprogramado.
4. Descripción del alcance y una medición del producto en producción.

### Después
Ofrezco mover la carpeta a `archivo/` y congelar la ficha con su última instantánea **solo cuando** el Consejo declare el cierre. Hoy no lo recomiendo: el proyecto sigue activo, con 4 compromisos vencidos, y debe seguir en el barrido diario. No moví nada.

---
*Pie de rigor: cada cifra derivada sale de `portafolio.py compute` del 2026-10-17. Las dos cifras de días que calculé yo (422 y 275) las marco como tales. Los documentos de la carpeta son la única fuente; lo hablado fuera de ellos no lo conozco. Verifique las citas antes de usar esta acta.*
