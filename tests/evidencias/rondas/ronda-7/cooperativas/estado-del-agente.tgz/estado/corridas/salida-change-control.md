Sale de la ficha PRY-201 (Apertura de ahorro en línea), `estado/records/PRY-201.json`, actualizada 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-201 — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días (de 2026-11-08 a 2026-12-08). · **Quién lo pide:** no consta; la solicitud no lo dice y ningún documento de la carpeta trae una solicitud formal. · **Por qué:** no consta en la solicitud. El informe de avance del 2026-10-16 (`20-seguimiento/2026-10-16-informe-avance.pdf`) dice que la salida «se reprogramó por el cierre contable de fin de mes». Esa es la única razón escrita, y no es una solicitud de cambio.

### Línea base de partida
Una sola: v1, aprobada el 2026-03-22 por el Comité de Crédito, cierre 2026-11-08 (`10-plan/2026-03-22-cronograma-v1.csv`). Replanificaciones: 0. El cambio sería la primera.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 (el acta no los describe) | Sin declarar | No declarada. Si el alcance no cambia, alguien absorbe 30 días más de equipo y proveedores. |
| Tiempo | Salida a producción 2026-11-08 (faltan 22 días; hito pendiente) | 2026-12-08 | +30 días (+13,0 % sobre los 231 días del plan, 2026-03-22 a 2026-11-08) |
| Costo | Aprobado COP 1.200.000.000; comprometido 513.279.152; ejecutado 523.807.850; proyección 1.236.335.536 | Sin declarar | La proyección ya excede lo aprobado en COP 36.335.536 (+3,0 %), sin contar los 30 días. El costo de los 30 días no consta en ningún documento y no se estima aquí. |

**Quién absorbe lo no declarado:** alcance y costo quedan sin impacto declarado. Un retraso de 30 días sin costo ni alcance declarados lo absorbe el equipo en horas no presupuestadas, o los proveedores en contratos que no se prorrogaron. Los documentos no dicen vigencia de CT-797 ni de CT-856, así que no se puede decir si alcanzan al 2026-12-08.

**Contexto que pesa en la fecha:**
- El proyecto se declara en rojo (62 % de avance al 2026-10-16).
- Hay un hallazgo de seguridad abierto, sin responsable, desde el 2026-10-16.
- Hay un riesgo de cambio normativo del supervisor, sin probabilidad, impacto ni responsable.
- CT-856 (Talento Solidario) tiene dos entregables vencidos y pendientes: bolsa de horas (vencía 2026-08-01) y parametrización de líneas de crédito (vencía 2026-10-01). Ninguno tiene acta de recibo.
- La salida ya se reprogramó de hecho (informe del 2026-10-16) y no existe cronograma posterior a v1 que registre la fecha nueva. Aprobar esto formaliza algo que ya se decidió sin documento.

### Efecto en el portafolio
Cálculo con `portafolio.py impact`, 30 días: alcanza a **0 proyectos** (0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar). Hitos por los que pasa el cambio: «Salida a producción» (2026-11-08, a 22 días).

| Proyecto afectado | Cómo | Gerente |
| Ninguno | PRY-201 no declara dependencias (`raid.dependencies` vacío) | — |

**Esto no significa que no haya efecto.** Significa que ninguna dependencia está declarada. Las otras fichas no listan a PRY-201 como dependencia y la suya no lista ninguna; una dependencia no declarada no aparece en el cálculo. Tampoco se sabe cuántos días se movería cada actividad: la ficha no tiene holgura.

### Quién decide
**Autoridad requerida:** no se puede determinar. · **Según:** el acta de constitución (2026-03-22) no declara autoridad de cambios (`identity.authority`: no encontrado). Hay comité (Comité de Crédito) y sponsor (Felipe Arango), pero ningún documento dice qué umbral de tiempo o costo decide cada uno. · **Va a comité:** sí, por defecto. Sin autoridad declarada no hay base para decir que el gerente (Óscar Ramírez) o el sponsor puedan aprobarlo solos.

El hallazgo de fondo es la ausencia de esa autoridad, y es anterior a esta solicitud.

### Si no se aprueba
El proyecto sigue con la salida al 2026-11-08, en rojo y con 22 días por delante. El informe dice que la salida ya se reprogramó, así que la fecha vigente en los documentos y la que se opera dejan de coincidir. Hay un hallazgo de seguridad sin cerrar. Con la salida pendiente, el proyecto sale en falso o sale reprogramado sin aprobación.

### Si se aprueba
Línea base 2 — cierre 2026-12-08 · presupuesto: COP 1.200.000.000 si no se pide más (la proyección ya está en COP 1.236.335.536; sin costo declarado de los 30 días) · motivo: a confirmar por quien lo pide; el único documento es «cierre contable de fin de mes».
Replanificaciones: 0 → 1. La línea base v1 no se toca.
**Desviación acumulada contra la línea base original:** tiempo +30 días (2026-11-08 → 2026-12-08) · costo +COP 36.335.536 (+3,0 %) sobre la proyección actual, más el costo de los 30 días, que no consta.

Reconciliación: hoy `changes` está vacío. Se aprobaría un movimiento de 30 días de línea base con 30 días de impacto de tiempo autorizado por el cambio. Sin ese documento de aprobación, los 30 días quedarían como no autorizados.

### Lo que falta para que el paquete esté completo
1. Quién pide el cambio y su motivo, por escrito.
2. Impacto declarado en alcance y costo.
3. Autoridad de cambios del proyecto (acta).
4. Vigencia de CT-797 y CT-856 frente al 2026-12-08.
5. Dependencias de PRY-201 con otros proyectos, para que el cálculo de portafolio pueda decir algo.
6. Responsable del hallazgo de seguridad y de la reprogramación.

## Después
Va a comité: el próximo es el 2026-10-24. No se registra línea base nueva porque nadie con autoridad la ha aprobado, y no hay autoridad declarada contra la cual verificarlo.

*Pie de rigor: cifras de la ficha PRY-201 y del cálculo `impact`; los porcentajes son aritmética sobre esas cifras. No se estimó el costo de los 30 días ni el movimiento por actividad. Borrador de trabajo: la verificación es de quien decide.*
