Términos vigentes (versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

**Acta previa:** sí existe, del 2025-07-09 (`PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-07-09-acta-constitucion.md`). Es la única acta; no hay versiones posteriores ni cronograma en la carpeta. Nota: la carpeta de originales `documentos/proyectos` está vacía en esta sesión; leí el texto convertido que guarda el caché (`estado/cache/texto/…`), cuya cabecera apunta al original.

## Acta — PRY-205 Prevención de lavado de activos
**Estado:** existe, del 2025-07-09

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** | Ricardo Salas no tiene declarado hasta qué monto ni qué cambio de alcance decide sin subir al Comité de Riesgos. Hoy la proyección (COP 4.267.213.372) ya supera lo aprobado (COP 4.200.000.000) en COP 67.213.372 (+1,6 %), y nada dice si eso lo resuelve el gerente, el patrocinador o el comité. Todo sobrecosto o cambio termina en el comité por defecto. |
| Objetivo de negocio | Presente pero vacío: "Entregar prevención de lavado de activos para Operaciones" | Repite el nombre del proyecto; no dice qué resultado de negocio se busca ni cuánto. No hay forma de saber si el proyecto cumplió. |
| Alcance | Marcadores sin contenido: "Componente 1, 2, 3" | Ningún componente está descrito. Un cambio de alcance no se puede reconocer como cambio porque no hay alcance contra el cual compararlo. |
| Exclusiones | Genérica: "Lo que otro proyecto cubre" | No nombra ningún proyecto ni función. No protege contra que se le exija al proyecto lo que no le toca. |
| Patrocinador | Cumple: Felipe Arango (persona con nombre) | — |
| Supuestos y restricciones | **No están** | Nada de lo que el plan da por cierto está escrito; cuando algo falle no hay a qué compararlo. El informe del 2026-09-27 ya muestra un riesgo (concentración del conocimiento en una persona) que el acta no anticipó. |
| Criterio de éxito | Presente pero no medible: "en producción y medido" | No define qué se mide, con qué umbral ni cuándo. Tampoco dice quién lo mide, así que "medido" no se puede verificar al cierre. |
| Dependencias | "Ninguna declarada" | Declarar ninguna en un proyecto de este tipo, sin que alguien lo confirme, es una afirmación sin sustento; no puedo decir que sea falsa, solo que nadie la respalda. |
| Hitos | **No hay** (sin cronograma en la carpeta) | Solo existen inicio y cierre. El "55 %" reportado no se puede contrastar con ningún hito. |
| Fechas | Cierre comprometido 2026-01-01 | Lleva 289 días vencido a hoy (2026-10-17). El informe del 2026-09-27 no lo menciona y no hay línea base nueva ni solicitud de cambio: el atraso no está reconocido por ningún documento. |
| Comité y cadencia | Comité: Comité de Riesgos. Cadencia: **no está** | No se sabe cada cuánto debe reportar ni cuándo debe verlo el comité. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice solo "Entregar prevención de lavado de activos para Operaciones" (fuente: acta, 2025-07-09), que describe la solución, no un resultado medible.
**Alcance:** pendiente de definir. El acta lista "Componente 1, 2, 3" sin describirlos (fuente: acta).
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre", sin nombrar el proyecto (fuente: acta).
**Patrocinador:** Felipe Arango · **Gerente:** Ricardo Salas (fuente: acta)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento de la carpeta.
**Comité al que reporta:** Comité de Riesgos (fuente: acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Prevención de lavado de activos en producción y medido" (fuente: acta); sin métrica ni umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-07-19 y cierre 2026-01-01 (fuente: acta).
**Presupuesto aprobado:** COP 4.200.000.000, aprobado por el Comité de Riesgos el 2025-07-09 (fuente: acta).

### Lo que el informe más reciente (2026-09-27, declarado por el gerente) agrega y el acta no cubre
- Estado declarado amarillo, avance 55 %. Con el cierre vencido hace 289 días, "amarillo" no tiene un plazo contra el cual medirse.
- Comprometido COP 1.472.743.776 y ejecutado COP 1.684.933.618: el ejecutado es mayor que el comprometido, lo que es inusual y conviene aclarar con el gerente. No lo interpreto.
- Un hallazgo de seguridad abierto sin dueño y una salida reprogramada "por el cierre contable de fin de mes" sin fecha registrada.

### Lo que no sé
- Si existe una autoridad delegada al gerente en alguna política de la cooperativa fuera de esta carpeta.
- Si hubo reuniones o decisiones del Comité de Riesgos sobre el cierre vencido: la carpeta no tiene minutas de este proyecto.
- Qué cubre cada "Componente".

## Después
El acta quedó sin autoridad del gerente declarada. Propongo llevar esa definición al Comité de Riesgos: es una decisión (monto y tipo de cambio que Ricardo Salas puede decidir solo), no un trámite. Los vacíos de supuestos y la dependencia "ninguna" quedan como candidatos para el registro RAID (`/raid-log`). No ejecuté ninguno de los dos; no estaban pedidos.

**Pie de rigor:** borrador de trabajo basado solo en dos documentos (acta 2025-07-09 e informe 2026-09-27). Cada dato lleva su fuente; la verificación es suya.
