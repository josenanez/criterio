# Portafolio — 2026-10-17
13 proyectos · 12 con hallazgos (66 señales) · último barrido 2026-10-17

**Fichas cargadas:** 13 (`estado/records/PRY-199` … `PRY-211`), todas del barrido de hoy; ninguna con más de una semana. Instantánea de referencia: `estado/snapshots/2026-10-17.json`.

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17, familia 0.3.13). Criterio produce borradores de trabajo, no decisiones ni asesoría; procesa los documentos que se le indican y no sabe lo que se habló fuera de ellos; puede equivocarse, y por eso cada dato trae su cita: la verificación es suya. Los documentos se procesan en la infraestructura de la plataforma de IA. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

## Qué cambió desde la corrida anterior
Sin cambios: no hay instantánea anterior a la de hoy, así que este es el punto de partida y no hay delta.

## Contradicciones abiertas
3 proyectos en verde contradichos por la evidencia (señal `declared_vs_evidence`): PRY-203, PRY-209 y PRY-210. El detalle por campo, con las dos fuentes y las dos fechas, está en `reportes/index.html`.

## Hitos vencidos sin evidencia
- PRY-207 Microcrédito rural: 1 hito vencido.
- PRY-209 Convenios de libranza con empresas: 1 hito vencido.

Hitos dados por cumplidos sin evidencia: PRY-200 (2), PRY-201 (4), PRY-202 (4), PRY-203 (3), PRY-204 (3), PRY-206 (3), PRY-208 (1), PRY-210 (3).

## Proyectos en silencio
- PRY-205 Prevención de lavado de activos: 20 días (umbral 15).

## Dependencias en riesgo
Sin dependencias en riesgo detectadas por el script. 5 proyectos no están ligados a ningún producto (PRY-202, 205, 208, 209, 210), lo que impide cruzarlos por producto.

## Sin sustento
Avance declarado por encima de lo que sostiene el plan: PRY-200, 201, 202, 203, 206, 209, 210, 211.
Reprogramaciones de línea base sin autorización: PRY-204 (116 días de atraso contra la original) y PRY-208 (59 días).
Facturado sin entrega: PRY-206 (proveedor facturó sin entregable aceptado).

## Vacíos de información
Ningún proyecto tiene autoridad (patrocinador/aprobador) registrada: 13 de 13. Compromisos sin fecha: PRY-200 (2), PRY-202 (1), PRY-211 (1). Entregables de proveedor atrasados: PRY-201 (2), PRY-202 (4), PRY-206 (3).

## Estado general
| Proyecto | Señales | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Mobiliario de agencias | 0 | sin alertas | 0 d | 0 d | 0 |
| PRY-200 Crédito de libranza digital | 12 | desviación de costo; 4 compromisos vencidos | 0 d | 0 d | 0 |
| PRY-201 Apertura de ahorro en línea | 7 | hitos sin evidencia; proveedor atrasado | 0 d | 0 d | 0 |
| PRY-202 Core cooperativo | 9 | hitos sin evidencia; proveedor atrasado | 0 d | 0 d | 0 |
| PRY-203 Aportes sociales en línea | 6 | verde contradicho; compromiso vencido | 0 d | 0 d | 0 |
| PRY-204 Tarjeta débito | 5 | rebase sin autorización | 116 d | 0 d | 1 |
| PRY-205 Prevención de LA | 1 | en silencio 20 d | 0 d | 0 d | 0 |
| PRY-206 Pagos con QR | 10 | costo y tiempo; facturado sin entrega | 36 d | 0 d | 1 |
| PRY-207 Microcrédito rural | 2 | hito y compromiso vencidos | 0 d | 0 d | 0 |
| PRY-208 Motor de crédito | 3 | rebase sin autorización | 59 d | 0 d | 1 |
| PRY-209 Convenios de libranza | 3 | verde contradicho; hito vencido | 0 d | 0 d | 0 |
| PRY-210 Corresponsales rurales | 5 | verde contradicho | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | 2 | avance sobre plan; compromiso sin fecha | 0 d | 0 d | 0 |

## Necesito que confirmes
Esta corrida no pidió confirmación periódica de campos (sin interfaz, nadie responde; se deja para la siguiente). Pregunta cerrada pendiente de fondo: ¿quién es el patrocinador de cada proyecto? Ninguno lo tiene registrado.

## Dónde quedaron los informes
`reportes/` (25 páginas, generadas por `informe.py`):
- `reportes/index.html` — por campo, con la cadena de evidencia completa. Para quien va a actuar.
- `reportes/decisiones.html` — por decisión, para el patrocinador y el comité.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), por producto y `productos.html`, `proyectos.html`.
El PDF sale de imprimir el HTML.

---
Criterio Portfolio 0.3.13 · fichas aplicadas: 13, del 2026-10-17 · campos inciertos: autoridad de los 13 proyectos y los 5 proyectos sin producto · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
