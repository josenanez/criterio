# Corrida del 2026-10-17 · health-check

13 proyectos · 130 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico de PRY-202 desde 9 documentos. Dictamen: 4 sostenidas, 9 sin sustento, 2 contradichas. Dijo que no se puede saber el avance real, la fecha de cierre vigente, lo pagado a CT-645 ni la conciliación de comprometido y ejecutado. No recomendó detener ni continuar.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-202 Core cooperativo · 2026-10-17

**Términos:** vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17; no hubo que registrarlos de nuevo.
**Leí:** 9 documentos del proyecto · del 2025-06-22 al 2026-10-15 · formatos: 3 .docx, 1 .xlsx, 3 .md, 2 .pdf
**Además:** busqué «PRY-202», «CT-171», «CT-645» y «core cooperativo» en los demás proyectos del portafolio. Ninguna minuta ni informe de otro proyecto habla de PRY-202. Los demás documentos con esas palabras son otros cronogramas con un hito del mismo nombre y contratos de otros proyectos con uno de los dos proveedores.
**No pude leer:** nada. Los 9 convirtieron bien. Leí el texto convertido (caché) y cito el original; los dos PDF los leí como texto extraído, no como imagen, y no verifiqué firmas.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 2 (de 15 evaluadas; el detalle está abajo)

Desde esta carpeta se puede afirmar que el gerente declara el proyecto en rojo, que el presupuesto aprobado es de 4.200.000.000 COP, que un entregable de CT-171 (la bolsa de horas) se recibió con acta y se facturó, y que el ambiente de pruebas se recibió el 2026-10-09. No se puede afirmar el avance. El cronograma v1 dice 5 de 5 hitos cerrados, y el informe del 2026-10-15 dice 46% y rojo. Hay acta de recibo de uno solo de los cinco hitos, y esa acta contradice la fecha del cronograma. La carpeta no permite saber en qué punto está el proyecto, y la fecha de cierre del plan ya pasó sin que exista una nueva. Eso es el resultado del diagnóstico, no una falta de esfuerzo en leerlo.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Javier Hoyos | acta de constitución 2025-06-23 (PRY-202-core-cooperativo/00-gobierno/2025-06-23-acta-constitucion.docx) |
| Gerente | Ricardo Salas | acta de constitución 2025-06-23; informe 2026-10-15 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente ni hasta dónde | acta de constitución 2025-06-23 |
| Comité | Comité de Crédito, que aprobó el presupuesto y las fechas el 2025-06-23. Hay una sola minuta (2026-10-12), con asistentes Ricardo Salas y Javier Hoyos; no registra ninguna decisión | acta; PRY-202-core-cooperativo/30-reuniones/2026-10-12-comite-semanal.md |

El acta también tiene campos vacíos de contenido: alcance «Componente 1, 2 y 3» sin describirlos, «Fuera de alcance: lo que otro proyecto cubre», objetivo «Entregar core cooperativo para Tesorería», y dependencias «Ninguna declarada». Sin autoridad declarada no hay desviación aprobada: lo que hay son fechas que alguien escribió.

### Contra el plan
- **Línea base original:** v1, aprobada por el Comité de Crédito el 2025-06-23; inicio 2025-07-03, cierre 2026-05-23 (acta; PRY-202-core-cooperativo/10-plan/2025-06-23-cronograma-v1.xlsx).
- **Vigente:** no hay otra. No existe cronograma v2, ni solicitud de cambio, ni replanificación con motivo. `compute` da 0 replanificaciones y 0 días de desviación contra la original y contra la vigente. Eso es porque la columna de fecha vigente es idéntica a la de línea base en las cinco filas, no porque el proyecto vaya a tiempo.
- **El cronograma v1 no sirve como línea base limpia.** Lleva fecha de aprobación 2025-06-23 y a la vez marca como «cerrados» cinco hitos que, a esa fecha, estaban en el futuro, el último el 2026-05-23. El archivo se editó después de aprobarse, o su columna de estado es una anotación sin fecha. Sin historial de versiones no se puede saber cuál.
- **Avance contra plan (`compute`):** declarado 46%; el plan sostiene 100%; hitos cumplidos 5 de 5; brecha 54.0 puntos, en el sentido de atrasado.
- **La fecha de cierre del plan, 2026-05-23, ya pasó** hace 147 días (el mismo conteo que da `compute` para el hito «Salida a producción»). El informe no propone fecha nueva.

### Hitos vencidos sin evidencia
Días de vencido a hoy, de `compute`. Los cuatro figuran «cerrado» en el cronograma y no tienen documento que lo respalde.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2025-09-05 | 407 | Acta de recibo o de aprobación del diseño |
| Integración con el core cooperativo | 2026-01-13 | 277 | Acta de recibo de la integración |
| Piloto con asociados | 2026-03-19 | 212 | Acta de recibo del piloto, con resultados |
| Salida a producción | 2026-05-23 | 147 | Acta de salida y medición, porque el criterio de éxito del acta es «core cooperativo en producción y medido» |

El quinto hito, «Ambiente de pruebas certificado», sí tiene acta de recibo (2026-10-09, recibido por Ricardo Salas), pero la fecha del hito era 2025-11-09. El acta es casi once meses posterior a la fecha que el cronograma da por cerrada. Ese conteo de días no lo da `compute` y no lo escribo; las dos fechas están arriba.

### Dinero
Moneda COP. Todo viene del informe del 2026-10-15, salvo el aprobado, que viene del acta.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 1.682.354.379 | 1.958.849.265 | 3.898.984.622 | 2.517.645.621 |

`compute`: ejecutado 46.6% del aprobado, comprometido 40.1%, proyección 7.2% por debajo del aprobado (−7.2).

- **El ejecutado es mayor que el comprometido** dentro del mismo informe. Lo habitual es que lo comprometido incluya lo ejecutado. El informe no define los términos, así que no lo clasifico como error: queda sin sustento. La cifra de «disponible real» de `compute` coincide con aprobado menos comprometido; con el ejecutado como base sería otra, y no la escribo porque el script no la da.
- **El avance reportado (46%) y el ejecutado (46.6%) son casi iguales.** Nada en la carpeta muestra que el 46% se midió por entregables y no se tomó del gasto.
- **Proveedores:**

| Contrato | Proveedor | Entregables | Aceptados con acta | Facturado |
|---|---|---|---|---|
| CT-171 | Sistemas Cooperativos Ltda. | 2 | 1 (bolsa de horas, acta 2026-02-28) | 369.743.691 (FV-1171, 2026-09-21, «radicada en cuentas por pagar») |
| CT-645 | Integración Financiera del Sur | 3 | 0 | No hay factura en la carpeta |

La factura FV-1171 coincide con el monto del entregable aceptado y respeta la condición de pago de CT-171 (factura contra acta firmada por el gerente). Su concepto dice «Entregables del contrato CT-171», en plural, por el valor de uno solo.
Entregables vencidos y sin acta, de `compute`:
  - CT-171, Licenciamiento del módulo: 2025-10-30, 352 días.
  - CT-645, Licenciamiento del módulo: 2025-09-30, 382 días.
  - CT-645, Bolsa de horas de desarrollo: 2025-12-28, 293 días.
  - CT-645, Parametrización de líneas de crédito: 2026-03-27, 204 días.

Los dos contratos traen una columna «Estado» («recibido», «en curso») en documentos fechados el día de la firma, 2025-06-22 y 2025-06-30. Esos estados no podían existir en esa fecha, así que no los tomo como evidencia. La evidencia de recibo es el acta, y de CT-645 no hay ninguna.

### Lo que se dijo y nadie registró
No hay registro RAID en la carpeta. Todo esto está en el informe o en la minuta, sin probabilidad, impacto, responsable ni fecha.

| Qué | Tipo | Dónde está | Qué falta |
|---|---|---|---|
| Dependencia del proveedor del core cooperativo | Riesgo | Informe 2026-10-15 | El acta declara «dependencias: ninguna». El informe la trae como riesgo. Otro proyecto la repite en su informe (PRY-207, 2026-10-14), así que puede ser común |
| Aprobación del reglamento por el Consejo de Administración | Riesgo (por su forma, parece una dependencia externa) | Informe 2026-10-15 | Responsable, fecha, y no está en el acta |
| El equipo perdió dos semanas por rotación de un desarrollador clave | Incidencia | Informe 2026-10-15 | No hay solicitud de cambio ni efecto sobre fechas, que el proyecto no tiene vigentes |
| La prueba de carga no alcanzó el umbral pactado y se repite | Incidencia | Informe 2026-10-15 | El umbral pactado no figura en ningún documento de la carpeta |
| Se ajustó el plan de pruebas con el área de seguridad | Cambio al plan | Informe 2026-10-15 | Ninguna solicitud de cambio |
| Paula Céspedes: «Entregar el punto 4», para «por definir» | Compromiso sin fecha | Minuta 2026-10-12 | No figura entre los asistentes, ni en ningún otro documento. La minuta solo tiene dos temas («Avance» y «Compromisos»), así que el «punto 4» no existe en ella. `compute` lo marca como compromiso sin fecha |

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| «Ambiente de pruebas certificado» cerrado en 2025-11-09 | Cronograma v1: hito cerrado, fecha vigente 2025-11-09 | Acta de recibo: recibido el 2026-10-09 |
| «Salida a producción» cerrada (2026-05-23) | Cronograma v1: estado «cerrado» | Informe 2026-10-15: avance 46%, rojo, y «la prueba de carga no alcanzó el umbral pactado y se repite» |

Dos tensiones más que no cuento como contradicción, porque ninguna prueba nada por sí sola:
- Los hitos «Integración» (2026-01-13) y «Piloto con asociados» (2026-03-19) figuran cerrados, y el ambiente de pruebas certificado se recibió después, el 2026-10-09.
- El acta dice «Dependencias: ninguna» y el informe declara dos.

### Sin sustento
- **Avance 46%.** El informe no dice cómo se midió, y el plan sostiene 100%.
- **Diseño funcional aprobado, cerrado.** No hay acta.
- **Integración con el core cooperativo, cerrada.** No hay acta.
- **Piloto con asociados, cerrado.** No hay acta.
- **Comprometido 1.682.354.379.** No hay desglose por contrato ni libro de compromisos.
- **Ejecutado 1.958.849.265.** No hay libro ni conciliación, y es mayor que el comprometido.
- **Proyección al cierre 3.898.984.622.** No hay método ni fecha de cierre sobre la cual proyectar.
- **CT-645, bolsa de horas «en curso».** La dice el contrato, sin acta ni avance.
- **CT-645, parametrización «en curso».** Lo mismo.

Este bloque es el más largo, como casi siempre. Casi todo lo que hace verde o rojo a este proyecto está aquí.

### Lo que esta carpeta no permite saber
- **Cuál es el avance real.** Sin actas de cuatro de los cinco hitos, 46% y 100% siguen en pie a la vez. Consecuencia: un comité que decida con cualquiera de las dos cifras decide sobre algo que nadie ha comprobado.
- **Cuándo termina el proyecto.** El cierre previsto, 2026-05-23, ya pasó; no hay replanificación, solicitud de cambio ni autoridad declarada que apruebe una fecha. Consecuencia: hoy no hay fecha de cierre vigente que se pueda reportar, y los 147 días son atraso sin aprobar.
- **Qué se pagó a Integración Financiera del Sur.** No hay facturas ni actas de CT-645. Consecuencia: la carpeta no permite decir ni que no se ha pagado nada ni que lo pagado está recibido.
- **Si el comprometido y el ejecutado son correctos.** Sin libro ni contrato por contrato no se concilian. Consecuencia: el disponible real de 2.517.645.621 depende de una cifra sin verificar.
- **Qué umbral de la prueba de carga se pactó, y con quién.** No hay documento. Consecuencia: no se puede juzgar si la repetición es un atraso menor o una falla de fondo.
- **Quién es Paula Céspedes y qué es el «punto 4».** Consecuencia: el único compromiso registrado en el comité no se puede seguir.
- **Qué decidió el Comité de Crédito el 2026-10-12.** La minuta lista temas y un compromiso, y ninguna decisión.
- **Qué versión del cronograma fue la aprobada en 2025.** Consecuencia: la línea base no se puede usar como referencia firme.

No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar al gerente las contradicciones como preguntas, una por una.

**Pie de rigor:** esto es un borrador de trabajo; cada dato va con la cita del documento y verificarlo es de quien lo lea. Las cifras derivadas (días, porcentajes, brecha, disponible real) se copian de `portafolio.py compute`, que corre sobre la ficha ya existente de PRY-202; contrasté sus valores con los 9 documentos y coinciden. Lo que el script no da no lo calculé. El conteo 4/9/2 son afirmaciones que yo elegí y clasifiqué, y la lista está arriba. No sé lo que se habló fuera de los documentos.
