Vista por producto, solicitada: **crédito de libranza**. Sale del cálculo de `portafolio.py compute` sobre las fichas en `estado/`, con corte al 2026-10-17. Términos vigentes (versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| crédito de libranza | 1 (PRY-200) | 12 alertas | 2026-01-08 (PRY-200) | COP 2.400.000.000 | COP 1.398.098.317 |

**Este producto tiene un solo proyecto declarado: PRY-200 «Crédito de libranza digital».** La vista por producto no suma nada sobre la vista del proyecto, así que no armo la sección de grupo. Lo que sigue es la lectura de ese único proyecto, más lo que sí le importa al dueño del producto.

**Cifras de PRY-200** (las cuatro vienen en la ficha, la suma está completa):
- Aprobado COP 2.400.000.000; comprometido 1.398.098.317 (58,3 %); ejecutado 929.267.306 (38,7 %); proyección 2.644.653.523, o sea 10,2 % sobre lo aprobado (umbral 10 %).
- Disponible real: COP 1.001.901.683.

**Lo que hay que ver:**
- El gerente declara **rojo** y 28 % de avance (informe del 2026-10-13). El plan marca 4 de 4 hitos cumplidos, que sostendría 100 %: brecha de 72 puntos. Alguna de las dos cosas no es cierta, y los documentos no dicen cuál.
- Dos hitos figuran cumplidos sin evidencia: «Ambiente de pruebas certificado» (vencía 2025-10-07) e «Integración con el core cooperativo» (vencía 2025-11-23).
- Cuatro compromisos vencidos sin evidencia: Paula Céspedes, «Confirmar la fecha 7» (7 días); Felipe Arango, «Enviar el documento 17» (10 días); Laura Vélez, «Cerrar la prueba 18» (9 días); Carlos Peña, «Actualizar la matriz 22» (1 día).
- Dos compromisos sin fecha: Javier Hoyos, «Validar el ambiente 12»; Laura Vélez, «Mandar el ajuste del presupuesto» (notas del 2026-10-17).
- Dos compromisos reprogramados varias veces: Gustavo Neira, «Enviar el documento 1» (6 veces, original 2026-09-12, hoy 2026-12-04); Sandra Gil, «Cerrar la prueba 2» (5 veces, original 2026-09-14, hoy 2026-12-07).
- El gerente declara el rojo, pero cinco de las señales anteriores no aparecen en su informe (compromisos vencidos, reprogramados, hitos sin evidencia, brecha de avance y sobrecosto).

**Dependencias internas:** ninguna registrada. Con un solo proyecto no hay con quién cruzarlas.

**Fecha comprometida del producto:** 2026-01-08, que sale de PRY-200 (único proyecto). Es una fecha ya pasada al corte, y el cálculo no registra reprogramaciones (0 replanes, desviación 0 días contra la línea base); no sé si la fecha vigente se actualizó fuera de los documentos.

**Lo que no sé:** `identity.authority` y `identity.phase` no están en la ficha. Los campos de identidad, plan y dinero tienen fuente de 2025-06-26 (16 meses, sobre el umbral de 12). Ninguna de las 30 citas está marcada como evidencia o declaración, así que no puedo separar lo sustentado de lo dicho.

### Proyectos sin producto declarado (5 de 13)

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | no consta en el cálculo |
| PRY-205 Prevención de lavado de activos | no consta en el cálculo |
| PRY-208 Motor de crédito | no consta en el cálculo |
| PRY-209 Convenios de libranza con empresas | no consta en el cálculo |
| PRY-210 Corresponsales rurales | no consta en el cálculo |

Consecuencia: nadie puede responder por el conjunto al que sirven. **Para este pedido pesa sobre todo PRY-209:** por el nombre toca libranza, pero no declara producto, y no lo asigno por inferencia. Si sirve a «crédito de libranza», el producto tendría dos proyectos, sumaría COP 5.700.000.000 aprobados y su fecha más tardía pasaría a 2027-09-10. Además PRY-209 declara verde con un hito vencido hace 8 días («Diseño funcional aprobado», 2026-10-09) y una brecha de avance (declara 58 %, el plan sostiene entre 0 y 33 %). Esa suma y esa fecha no están en la vista hasta que alguien confirme la pertenencia. Pregunta abierta para el dueño del producto o la PMO: ¿PRY-209 sirve a crédito de libranza?

PRY-202 (Core cooperativo) y PRY-208 (Motor de crédito) también podrían estar relacionados con este producto (PRY-200 declara un hito de integración con el core), pero ningún documento declara esa dependencia y no la invento.

## Pie de rigor
Cifras copiadas de la salida de `portafolio.py compute` (corte 2026-10-17); cada alerta cita su fuente en la ficha. Las fichas son borradores de trabajo: la verificación contra los documentos es de quien decide. No sé lo que se habló fuera de los documentos.
