## Historia · PRY-206 Pagos con QR · 2025-05-12 a 2026-10-16

**Leí:** 9 documentos entre 2025-05-12 y 2026-10-16 (acta de constitución, contrato CT-399, dos cronogramas, factura, solicitud de cambio, dos actas de recibo e informe de avance). Dos de ellos son PDF (acta de recibo del core e informe de avance) leídos con pdftotext.
**Trimestres sin un solo documento:** 2025-T3, 2025-T4, 2026-T1 y 2026-T2. Entre el contrato (2025-05-20) y la factura (2026-09-18) la carpeta no tiene nada.

### En una línea
El proyecto se aprobó el 2025-05-12 con cierre el 2026-03-25 y presupuesto de 1.200.000.000 COP. Los documentos no dicen nada de él durante los siguientes 16 meses. Casi todo lo que se sabe quedó escrito entre el 2026-09-18 (factura) y el 2026-10-16: la solicitud de cambio CC-01 (10-05), la recepción de la integración con el core (10-10), y el día 10-16 el cronograma v2, la recepción del piloto y un informe de avance que declara rojo y 45 %. La mayor parte de lo que pasó entre mayo de 2025 y septiembre de 2026 no está documentado, y lo que se documentó en octubre de 2026 lo hizo después de fechas de 2025 y de abril de 2026.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 36 días (11,7 %) | No calculable: hay una sola declaración de estado (2026-10-16), no una serie | 0 en los documentos (ver nota en Gobierno) |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-05-12 | Acta de constitución (.docx) | Aprobación por el Consejo de Administración: 1.200.000.000 COP, inicio 2025-05-22, cierre 2026-03-25. Patrocinadora María Restrepo, gerente Andrés Lozano. Alcance descrito solo como "Componente 1, 2 y 3". |
| 2025-05-12 | Cronograma v1 (.csv) | Línea base original; cierre 2026-03-25. Ver nota sobre el estado de sus hitos más abajo. |
| 2025-05-20 | Contrato CT-399 (.md) | Integración Financiera del Sur; 3 entregables de 96.483.298 COP cada uno, con fechas 2025-08-14, 2025-11-07 y 2026-01-30. Pago contra acta de recibo firmada por el gerente. |
| 2026-09-18 | Factura FV-1399 (.md) | Factura de 96.483.298 COP por "Entregables del contrato CT-399", radicada en cuentas por pagar. No dice a cuál entregable corresponde. |
| 2026-10-05 | Solicitud de cambio CC-01 (.md) | Andrés Lozano pide ampliación de alcance: +36 días y 72.000.000 COP. "Autorizada por el comité", sin nombre ni fecha de decisión. |
| 2026-10-10 | Acta de recibo, integración con el core (.pdf) | Andrés Lozano recibe a satisfacción. El hito tenía fecha 2025-11-22. |
| 2026-10-16 | Cronograma v2 (.xlsx) | Nueva línea base: salida a producción pasa de 2026-03-25 a 2026-04-30. Los cinco hitos figuran "cerrado". |
| 2026-10-16 | Acta de recibo, piloto con asociados (.md) | Andrés Lozano recibe a satisfacción. El hito tenía fecha 2026-01-22. |
| 2026-10-16 | Informe de avance (.pdf) | Estado Rojo, avance 45 %. Proyección al cierre 1.522.401.880 COP. Reporta que "se reprogramó la salida por el cierre contable de fin de mes" y dos riesgos abiertos. |

Nota sobre el cronograma v1: el archivo lleva fecha 2025-05-12 en su nombre, pero todos sus hitos figuran "cerrado", incluidos los que vencían en 2026. O el estado se actualizó después sin cambiar el nombre del archivo, o la columna no significa "cumplido". No se puede resolver con lo que hay en la carpeta.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-16 (fecha de la v2) | 2026-04-30 | Ampliación de alcance, CC-01, +36 días | CC-01 (2026-10-05): "autorizada por el comité", sin nombrar al comité ni fechar la decisión |

La replanificación tiene motivo documentado. Lo que llama la atención es la fecha: la nueva fecha de cierre (2026-04-30) y la fecha de la línea base v2 (2026-10-16) tienen una diferencia de meses, y la solicitud CC-01 se pide "sobre la línea base vigente" cuando esa línea ya había vencido. El cambio se registró después del hecho, no antes. El atraso contra la original es de 36 días (11,7 %), por encima del umbral de 10 % de la configuración. Contra la línea base vigente es 0, por construcción.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente ni comité aparece en los documentos | — |

El único documento que nombra patrocinio, gerencia y comité es el acta de 2025-05-12; las actas y el informe de 2026 solo nombran a Andrés Lozano como gerente. Pero la carpeta no tiene correos ni minutas, que es donde esos cambios suelen aparecer: "0" significa que no hay rastro, no que no los haya habido. El comité que autorizó CC-01 no está nombrado.

### Compromisos que se repitieron
No hay minutas ni transcripciones en la carpeta, de modo que no se puede extraer ningún compromiso con doliente y fecha. El único dato cercano es el riesgo "el proveedor no ha confirmado la fecha de la última entrega" (informe del 2026-10-16), sin doliente ni fecha. No hay compromisos que se repitan porque no hay compromisos registrados.

### Desde cuándo lo declarado no se sostiene
No se puede fechar con precisión: de la serie de estados declarados solo existe un punto, el informe del 2026-10-16, y ese informe declara Rojo. Es decir, lo que el gerente declara como estado (rojo, 45 %) sí es coherente con las señales de riesgo. Lo que no se sostiene es el cronograma v2 del mismo día, que da los cinco hitos por cerrados (100 % del plan) frente al 45 % del propio informe, una brecha de 55 puntos.

Lo que sí se puede decir sobre el sustento de los hitos:
- **Sin acta ni otra evidencia:** Diseño funcional aprobado (fecha 2025-07-22, 452 días), Ambiente de pruebas certificado (2025-09-21, 391 días) y Salida a producción (2026-04-30, 170 días). El primer hito sin evidencia es Diseño funcional, el 2025-07-22.
- **Con acta, pero escrita mucho después de la fecha:** integración con el core (acta 2026-10-10 frente a fecha 2025-11-22) y piloto (acta 2026-10-16 frente a fecha 2026-01-22).
- **Contradicción interna:** el v2 da por cerrada la salida a producción el 2026-04-30, mientras el informe del mismo día dice que "se reprogramó la salida" y el acta de recibo del piloto es del 2026-10-16, posterior a esa fecha de salida.

Esto es ausencia de documento, no prueba de que el hito no ocurriera. El primer punto donde la carpeta deja de sostener el avance es 2025-07-22; después de eso, lo reportado se apoya en un cronograma que se escribió en octubre de 2026.

### Proveedor y dinero
- Los tres entregables de CT-399 siguen sin acta de recibo del proveedor: licenciamiento (vencido 2025-08-14, 429 días), bolsa de horas (2025-11-07, 344 días) y parametrización (2026-01-30, 260 días).
- Se facturó 96.483.298 COP el 2026-09-18 (FV-1399) y el contrato exige acta de recibo firmada para facturar. Las dos actas que existen son de hitos del proyecto y no mencionan al proveedor ni a CT-399.
- Proyección al cierre 1.522.401.880 COP frente a 1.200.000.000 aprobados: 26,9 % por encima, también sobre el umbral de 10 %. CC-01 suma 72.000.000 COP; el documento no dice si el presupuesto aprobado se modificó.

### Lecciones ancladas a un hecho
1. **Hecho:** los hitos de 2025 y de enero de 2026 se cerraron en actas fechadas 2026-10-10 y 2026-10-16. **Efecto:** durante 16 meses la carpeta no permite saber si el proyecto iba bien, y el atraso de 36 días se reconoció cuando la fecha original ya llevaba meses vencida.
2. **Hecho:** FV-1399 se radicó el 2026-09-18 sin acta de recibo del proveedor en la carpeta. **Efecto:** se pudo comprometer un pago que el contrato condiciona a esa acta.
3. **Hecho:** CC-01 dice "autorizada por el comité" sin nombrarlo ni fecharlo. **Efecto:** la aprobación del cambio de línea base no se puede verificar contra una decisión.

No atribuyo intención. Que el atraso quedara sin documentar no dice que alguien lo ocultara; puede ser que la documentación exista fuera de la carpeta. La conversación con quien lleva el proyecto es la que tiene que decirlo, ahora con estas fechas.

### Qué no sé
- Qué pasó entre 2025-05-20 y 2026-09-18: no hay documentos.
- Si los hitos sin acta se cumplieron.
- A cuál de los tres entregables corresponde la factura.
- Quién es el comité de CC-01 y cuándo decidió.
- Si el presupuesto aprobado cambió con CC-01.
- Cuántos meses lleva el estado declarado sin sustento: falta una serie de informes de avance anteriores.

Puedo llevar esta historia al cierre del proyecto, o al comité del 2026-10-24 si hay una decisión que salga de ella (por ejemplo, retener el pago de FV-1399 hasta tener el acta).

*Pie de rigor: borrador de trabajo, no asesoría. Cada dato sale de los 9 documentos citados; las cifras derivadas se copiaron de `portafolio.py compute` (as_of 2026-10-17). La verificación es suya.*
