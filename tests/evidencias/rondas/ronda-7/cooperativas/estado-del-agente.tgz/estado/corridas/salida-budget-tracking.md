Fuentes: ficha PRY-206 (`estado/records/PRY-206.json`) y salida de `portafolio.py compute` con corte 2026-10-17. Documentos de origen: acta de constitución (2025-05-12), informe de avance (2026-10-16), solicitud de cambio CC-01 (2026-10-05), factura CT-399 (2026-09-18), cronogramas v1 y v2.

## Presupuesto — PRY-206 Pagos con QR al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 1.200.000.000 | 100% | 00-gobierno/2025-05-12-acta-constitucion.docx | 2025-05-12 |
| Comprometido | 682.946.035 | 56.9% | 20-seguimiento/2026-10-16-informe-avance.pdf | 2026-10-16 |
| Ejecutado | 448.689.025 | 37.4% | 20-seguimiento/2026-10-16-informe-avance.pdf | 2026-10-16 |
| Proyección al cierre | 1.522.401.880 | 26.9% por encima del aprobado | 20-seguimiento/2026-10-16-informe-avance.pdf | 2026-10-16 |

**Disponible real** (aprobado menos comprometido): 517.053.965 COP

La proyección es una declaración del gerente (Andrés Lozano), no un dato duro. Es de 2026-10-16, posterior al último movimiento de presupuesto (CC-01, 2026-10-05), así que no está desfasada respecto de él.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 1.200.000.000 | no registrada | sin dato |

Replanificaciones de presupuesto: 0 registradas. Sí hay una replanificación de cronograma (v2, 2026-10-16, +36 días).

CC-01 (2026-10-05, "ampliación de alcance") declara **72.000.000 COP adicionales** y dice "autorizada por el comité" sin nombrar quién. Pero ningún documento deja una línea base de presupuesto nueva: el informe del 2026-10-16 sigue reportando 1.200.000.000 como aprobado. No calculo un presupuesto vigente porque el script no lo da y ningún documento lo declara.

### Ejecución frente a avance
Ejecutado 37.4% · Hitos cumplidos 5 de 5 declarados (3 sin evidencia) · Avance reportado 45%.
Lectura: el plan sostendría 100% de avance, el gerente reporta 45%, y el gasto va en 37.4%. Las tres cifras no se pueden reconciliar entre sí. La brecha de avance contra plan es de 55.0 puntos. El gasto no está desalineado del avance reportado (37.4% frente a 45%); lo que no cuadra es el estado de los hitos.

### Alertas
- **Proyección excede el aprobado:** 1.522.401.880 contra 1.200.000.000, 26.9% por encima (umbral de variación de costo: 10%). Aun con los 72.000.000 de CC-01 sumados, la brecha sigue abierta.
- **Comprometido:** 56.9%, por debajo del umbral de 90%. Sin alerta.
- **Factura sin entrega:** el proveedor Integración Financiera del Sur (CT-399) facturó 96.483.298 COP el 2026-09-18 y no hay ningún entregable aceptado de los 3; los 3 están vencidos (429, 344 y 260 días).
- **Hitos "cumplidos" sin evidencia:** Diseño funcional aprobado, Ambiente de pruebas certificado y Salida a producción (esta última con fecha 2026-04-30, hace 170 días; el informe del 2026-10-16 habla de reprogramar la salida).
- **Desviación de tiempo:** 36 días, 11.7% contra la línea base original (umbral 10%).
- **Aprobación de CC-01:** "el comité" sin nombre en el documento.

### Sin dato
- Presupuesto vigente tras CC-01 (ningún documento lo declara).
- Aprobador nombrado de CC-01.
- Fuente y fecha propias del comprometido y la proyección más allá del informe de avance: no hay contrato, acta de comité ni soporte contable que las respalde.
- Campos de identidad (autoridad, fase) no declarados; el presupuesto aprobado tiene 17 meses de antigüedad (límite: 12).

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`). El comprometido no está cerca del tope, así que no ofrezco el detalle por proveedor como urgente; si quiere ver la factura de CT-399, `/criterio-portfolio:vendor-tracking`.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de los documentos citados y del cálculo de `portafolio.py`; la verificación es suya. Lo que se habló fuera de esos documentos no lo conozco.*
