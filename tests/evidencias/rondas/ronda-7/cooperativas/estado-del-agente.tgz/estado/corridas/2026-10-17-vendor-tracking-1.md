# Corrida del 2026-10-17 · vendor-tracking

13 proyectos · 44 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Cruce de CT-797 y CT-856 de PRY-201: montos facturados y aceptados cuadran por contrato; CT-856 con dos entregables atrasados (77 y 16 días); factura FV-2797 del 2026-09-01 anterior al acta del 2026-09-14. No supe vigencia ni preaviso de los contratos, ni compromisos de proveedor (sin carpeta de reuniones), ni si las facturas se pagaron.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Salida de /vendor-tracking para PRY-201. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17): no hizo falta registrarlos de nuevo.

**Sale de:** la ficha `estado/records/PRY-201.json`, el cálculo `portafolio.py compute` al 2026-10-17, y los documentos de `PRY-201-apertura-de-ahorro-en-línea/`: los contratos CT-797 y CT-856 (00-gobierno), cuatro actas de recibo, dos facturas y el informe de avance del 2026-10-16 (20-seguimiento). No hay carpeta `30-reuniones` en este proyecto.

## Proveedores — PRY-201 Apertura de ahorro en línea al 2026-10-17

### Integración Financiera del Sur — contrato CT-797
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae fecha de firma, 2026-03-19, entregables y condición de pago)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo (132.724.032 COP) | 2026-06-21 | accepted | Acta de recibo 2026-06-23, firmada por Óscar Ramírez (`2026-06-23-acta-recibo-ct-797-licenciamiento-del-módulo.md`) | Factura FV-2797 del 2026-09-01, 265.448.064 COP en total para los dos entregables |
| Bolsa de horas de desarrollo (132.724.032 COP) | 2026-09-10 | accepted | Acta de recibo 2026-09-14, firmada por Óscar Ramírez (`2026-09-14-acta-recibo-ct-797-bolsa-de-horas-de-desarrollo.pdf`) | Misma factura FV-2797 |

El script da `late` vacío, `accepted_without_evidence` vacío, 2 de 2 aceptados, facturado 265.448.064 y aceptado 265.448.064: los montos cuadran.

### Talento Solidario Ltda. — contrato CT-856
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae fecha de firma, 2026-03-22)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo (120.335.879 COP) | 2026-06-01 | accepted | Acta de recibo 2026-06-16, firmada por Óscar Ramírez (`2026-06-16-acta-recibo-ct-856-licenciamiento-del-módulo.pdf`) | Factura FV-1856 del 2026-09-19, 120.335.879 COP |
| Bolsa de horas de desarrollo (120.335.879 COP) | 2026-08-01 | pending, atrasado 77 días | Ninguna | No consta |
| Parametrización de líneas de crédito (120.335.879 COP) | 2026-10-01 | pending, atrasado 16 días | Ninguna | No consta |

El script da 1 de 3 aceptados, facturado 120.335.879 y aceptado 120.335.879. El monto facturado coincide con el único entregable aceptado. No se levantó `vendor_invoiced_without_delivery`: ambos proveedores tienen entregables aceptados.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-797: la factura se emitió antes del acta del segundo entregable | "Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto" | La factura FV-2797 cubre los dos entregables y es del 2026-09-01. El acta de la Bolsa de horas es del 2026-09-14. Ese día no había acta para ese entregable. El script no lo marca porque cruza montos, no fechas. Esto lo vi leyendo las dos fechas. | `2026-03-19-contrato-ct-797.docx`, `2026-09-01-factura-ct-797.md`, `2026-09-14-acta-recibo-ct-797-bolsa-de-horas-de-desarrollo.pdf` |
| CT-797: la Bolsa de horas se recibió después de su fecha | Fecha comprometida 2026-09-10 | Acta del 2026-09-14 | Contrato CT-797 y su acta |
| CT-856: la factura dice "Entregables del contrato CT-856" sin decir cuál | Un entregable aceptado, con acta del 2026-06-16 | El valor facturado, 120.335.879 COP, es igual al monto de un entregable. La factura no nombra cuál, así que no puedo confirmar que sea el aceptado y no uno pendiente. | `2026-09-19-factura-ct-856.pdf`, `2026-06-16-acta-recibo-ct-856-licenciamiento-del-módulo.pdf` |
| La columna "Estado" de los contratos no es evidencia | Los dos contratos, firmados en marzo, traen "recibido" y "pendiente" en entregables con fechas posteriores a la firma | Es una columna actualizada después de la firma, y no sé cuándo ni quién. No la tomé como prueba de recibo; usé solo las actas. | `2026-03-19-contrato-ct-797.docx`, `2026-03-22-contrato-ct-856.docx` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Ninguno de los entregables de proveedor está marcado como entregado o aceptado sin acta (`accepted_without_evidence` vacío en ambos contratos). | n/a | n/a |

A nivel del proyecto sí hay un hallazgo del mismo tipo, aunque no es de proveedor. Los 4 hitos marcados `met` (Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core cooperativo, Piloto con asociados) no tienen evidencia en la carpeta. Pasaron sus fechas hace 155, 111, 66 y 22 días. El informe de avance declara 62% de avance y el cronograma sostiene entre 80% y 100%.

### Compromisos del proveedor vencidos
Sin dato. El proyecto no tiene `30-reuniones` y la ficha no registra compromisos. No puedo decir si algún proveedor prometió algo en comité.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de ambos contratos: no están en los documentos leídos. No puedo decir si algún preaviso vence antes del cierre del proyecto (salida a producción prevista el 2026-11-08, y el informe del 2026-10-16 dice que se reprogramó sin fecha nueva).
- Si las facturas FV-2797 y FV-1856 ya se pagaron: dicen "radicada en cuentas por pagar" y nada más.
- Qué entregable cubre la factura FV-1856.
- El informe de avance no dice nada sobre los proveedores.

## Qué haría con esto
- **Urgente:** CT-856 lleva dos entregables sin recibir, 77 y 16 días tarde, y ya hay una factura contra ese contrato. Antes de aprobar el pago de FV-1856, pedir a Óscar Ramírez que confirme contra cuál entregable se emitió.
- **Para comité:** la factura FV-2797 del 2026-09-01 se emitió contra un acta que se firmó el 2026-09-14. Conviene llevarlo a comité si la factura ya se pagó. Si sigue pendiente, basta que cuentas por pagar espere al acta, que ya existe.
- Conseguir las cláusulas de vigencia y preaviso de ambos contratos antes de la salida a producción.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato lleva su fuente; la verificación es de quien lo usa. Las cifras derivadas (77 y 16 días, montos aceptados y facturados) vienen de `portafolio.py compute`. La comparación de fechas entre factura y acta es mía, no del script. Solo conozco lo que está en los documentos.*
