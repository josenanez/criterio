# Corrida del 2026-10-17 · steering-pack

13 proyectos · 128 s · 66 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Paquete de comité 2026-10-24: 6 decisiones (autoridad de cambios, CC-01 de PRY-204 y PRY-208, replanificación de PRY-202, pagos a Integración Financiera del Sur, responsable de hallazgos de seguridad) y 7 escalamientos. No sé: quién autoriza cambios en ningún proyecto, el alcance de las tres CC-01, la fecha y el órgano que autorizó la CC-01 de PRY-206, vigencia de contratos ni si las facturas se pagaron. No había acta de comité anterior.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Cargué:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211), recalculadas con `portafolio.py compute` al 2026-10-17, más los resultados del día de `/raid-log`, `/change-control` y `/vendor-tracking` y las tres solicitudes CC-01 de la carpeta. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

# Comité de proyectos — 2026-10-24 (material preparado el 2026-10-17)
6 decisiones · 7 escalamientos · 12 de 13 proyectos con hallazgos (66 señales abiertas)

El comité tiene qué decidir: hay tres solicitudes de cambio, una de ellas ya ejecutada en el cronograma sin aprobación, y ninguno de los 13 proyectos declara quién aprueba cambios.

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| CC-01 de PRY-206 (+36 días, +COP 72.000.000), «Autorizada por el comité» | No consta. La solicitud es del 2026-10-05 y no trae fecha de decisión | La línea base de PRY-206 se movió 36 días y los 36 están autorizados (`unauthorized_days` 0). No hay acta de ese comité en la carpeta; la ficha mantiene el aprobado en COP 1.200.000.000 y no dice si ya incluye los COP 72.000.000 | Abierto: sin acta no se puede verificar quién decidió |

No encontré acta ni paquete de un comité de portafolio anterior. Las 13 minutas de `30-reuniones/` son reuniones semanales de proyecto y solo traen compromisos. No hay más decisiones que cerrar, y eso no significa que no se hayan tomado.

## Decisiones de hoy

### [1] ¿Qué órgano aprueba los cambios de tiempo y de costo de cada proyecto, y con qué umbrales?
**Proyecto:** los 13 · **Quién decide:** no consta; es el primer punto porque ningún documento lo dice · **Si no se decide hoy:** las decisiones 2 y 3 se toman sin poder comprobar que quien las toma tenga la facultad. Los 13 proyectos siguen con `authority` vacío, y las fichas nombran cuatro órganos distintos: Consejo de Administración (PRY-199, 200, 206, 207), Comité de Crédito (201, 202, 208, 209, 210), Comité de Riesgos (204, 205, 211) y Comité de Educación (203).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Este comité aprueba todo cambio de tiempo o costo, de forma transitoria, hasta que cada acta declare su autoridad | Los 13 proyectos pasan por un solo órgano | Una sesión semanal; las 3 solicitudes pendientes se ven el 2026-10-24 | Sin costo directo |
| B. Cada órgano de la ficha decide los cambios de sus proyectos, con umbrales escritos en cada acta | Cuatro órganos, 13 actas por enmendar | Las 3 solicitudes quedan a la espera de que cada órgano se reúna | Sin costo directo |
| C. No definirlo ahora | Sin cambio | Las 3 solicitudes y los 36 + 116 + 59 días ya movidos siguen sin base de validez | Sin costo directo |
**Recomendación:** A ahora y B después. Con A las tres solicitudes se pueden decidir con una facultad explícita, y B deja la autoridad escrita en cada acta. C deja sin base cualquier decisión de hoy.

### [2] ¿Se aprueba la CC-01 de PRY-204 (ampliación de alcance, +116 días, +COP 232.000.000)?
**Proyecto:** PRY-204 Tarjeta débito para asociados · **Quién decide:** la ficha nombra al Comité de Riesgos; sin autoridad declarada, lo que fije el punto 1 · **Si no se decide hoy:** los 116 días del cronograma v2 (2026-10-08) siguen como movimiento no autorizado (`unauthorized_days` 116, 28,4 % sobre el original) y la solicitud, del 2026-10-15, sigue «pendiente de presentación al comité».
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y abrir línea base 2 | Ampliado; la solicitud no dice qué se agrega | Cierre 2027-01-28 (ya en v2), +116 días | +COP 232.000.000 sobre COP 1.200.000.000 aprobados; la proyección actual es COP 1.135.772.783 (−5,4 %) |
| B. Rechazar | Sin ampliación | Hay que volver a v1 o replanificar: el piloto ya se movió en v2 | Sin adicional |
| C. Devolver para completar y decidir en la próxima sesión | Pedir la descripción del alcance nuevo y su motivo (¿el ajuste de reglamento que pidió el Consejo, PRY-204-25?) | Los 116 días siguen sin autorización mientras tanto | Sin adicional por ahora |
**Recomendación:** C. La solicitud dice «Ampliación de alcance» y nada más: sin saber qué se amplía ni por qué, no hay base para aprobar ni para rechazar. El solicitante (Mauricio Pérez) es el gerente del proyecto; falta quien la patrocine. El costo de esperar es una semana más de movimiento no autorizado.

### [3] ¿Se aprueba la CC-01 de PRY-208 (ampliación de alcance, +59 días, +COP 118.000.000)?
**Proyecto:** PRY-208 Motor de crédito · **Quién decide:** la ficha nombra al Comité de Crédito; sin autoridad declarada, lo que fije el punto 1 · **Si no se decide hoy:** los 59 días del cronograma v2 siguen como movimiento no autorizado (`unauthorized_days` 59, 20,9 % sobre el original); la solicitud es del 2026-10-13.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y abrir línea base 2 | Ampliado; la solicitud no dice qué se agrega | Cierre 2027-03-26 (ya en v2), +59 días | +COP 118.000.000 sobre COP 6.800.000.000 aprobados; la proyección actual es COP 6.616.900.150 (−2,7 %) |
| B. Rechazar | Sin ampliación | Volver a v1 o replanificar: el piloto ya se movió en v2 | Sin adicional |
| C. Devolver para completar y decidir en la próxima sesión | Pedir descripción del alcance y motivo | Los 59 días siguen sin autorización | Sin adicional por ahora |
**Recomendación:** C, por la misma razón que en el punto 2. Si el comité prefiere resolver ya, A es defendible aquí porque el proyecto lleva 73 % declarado con 2 de 4 hitos cumplidos (el plan sostiene 50–75 %), pero necesita que alguien diga qué alcance se amplía.

### [4] ¿Se ordena a PRY-202 (Core cooperativo) presentar una replanificación formal, y se confirma por escrito con PRY-199, 203, 204 y 207 la fecha en que el core estará disponible?
**Proyecto:** PRY-202, con 4 proyectos dependientes · **Quién decide:** la ficha nombra al Comité de Crédito; sin autoridad declarada, lo que fije el punto 1 · **Si no se decide hoy:** cuatro proyectos siguen dependiendo de un proyecto en rojo, con 46 % declarado, cuyo cronograma v1 cerraba el 2026-05-23 y lo da por cerrado en sus 5 hitos (147 días de la salida a producción sin evidencia).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. PRY-202 presenta solicitud de cambio con cronograma nuevo; cada dependiente confirma su fecha | Sin cambio de alcance declarado | Se conoce la fecha real del core y el efecto en los otros 4 | Aprobado COP 4.200.000.000; proyección COP 3.898.984.622 (−7,2 %); el cambio no declara costo |
| B. Diagnóstico independiente de PRY-202 antes de pedir nada | Sin cambio | Retrasa la replanificación lo que tarde el diagnóstico | Costo del diagnóstico: no consta |
| C. No actuar | Sin cambio | Los 4 dependientes siguen sin fecha confiable | Sin cambio |
**Recomendación:** A. Las fechas de los dependientes no se pueden sostener sin la del core, y hoy ningún documento la da. Si en dos semanas no llega la replanificación, pasar a B. Advertencia: el código PRY-202 se infiere del nombre «proveedor del core cooperativo»; ningún documento lo declara y hay que confirmarlo.

### [5] ¿Se suspende todo pago a Integración Financiera del Sur en PRY-202 y PRY-206 hasta que exista acta de recibo de cada entregable?
**Proyecto:** PRY-202 (CT-645), PRY-206 (CT-399), y PRY-201 (CT-797) como antecedente · **Quién decide:** no consta (los documentos no dicen quién autoriza pagos ni qué cláusulas aplican) · **Si no se decide hoy:** en PRY-206 ya hay COP 96.483.298 facturados con 0 entregables aceptados y los 3 vencidos (429, 344 y 260 días); en PRY-202 hay 3 vencidos (382, 293 y 204 días) y nada facturado según la ficha.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Suspender pagos nuevos en ambos contratos y revisar lo ya facturado | Sin cambio | Puede enfriar la relación con un proveedor que además es ruta crítica del core | Protege lo no pagado; si la factura de PRY-206 ya se pagó, queda por recuperar (no consta si se pagó) |
| B. Suspender solo en PRY-206, donde hay factura sin entrega | Sin cambio | Igual | Protege lo de PRY-206 |
| C. Seguir pagando por lo facturado | Sin cambio | Sin efecto | COP 96.483.298 pagados contra 0 entregables aceptados |
**Recomendación:** A. El proveedor tiene entregables vencidos en dos proyectos y una factura sin recibo en uno; el patrón se repite, y decidirlo proyecto por proyecto lo deja en manos de gerentes que no pueden cobrarle por otro proyecto. Antes de ejecutarlo, falta ver los contratos: la vigencia y los preavisos de CT-399 y CT-645 no están en los documentos leídos.

### [6] ¿Se designa un único responsable y una fecha límite para los hallazgos de seguridad de PRY-201 y PRY-205?
**Proyecto:** PRY-201 y PRY-205 · **Quién decide:** el sponsor de ambos es Felipe Arango; la facultad para designar no consta · **Si no se decide hoy:** el de PRY-205 sigue abierto sin responsable (20 días, desde 2026-09-27) y el de PRY-201 (desde 2026-10-16) puede llegar a la salida a producción sin dueño.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un responsable único para ambos, con fecha límite antes de cualquier salida a producción de PRY-201 | Cierra los dos hallazgos | Fecha por fijar por quien se designe | No declarado |
| B. Cada gerente es dueño del suyo | Cierra los dos hallazgos | Sin fecha común | No declarado |
| C. Esperar a la próxima revisión de arquitectura | Ninguno se cierra | Sin fecha | No declarado |
**Recomendación:** A. El hallazgo viene de la misma revisión de arquitectura en ambos proyectos y ninguno de los 44 ítems del registro RAID tiene doliente; un responsable único evita que cada uno espere al otro. No propongo un nombre: ningún documento dice quién.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-206 | Sobrecosto: proyección COP 1.522.401.880 contra COP 1.200.000.000 aprobados (+26,9 %); atraso de 36 días ya autorizado (+11,7 %) | Informe del 2026-10-16 | Una solicitud de presupuesto o un recorte; hoy no hay ninguna. Aclarar si los COP 72.000.000 de CC-01 están dentro del aprobado |
| PRY-200 | Rojo, 28 % declarado contra 100 % que sostiene el plan; proyección COP 2.644.653.523 contra COP 2.400.000.000 (+10,2 %); 4 compromisos vencidos, 2 sin fecha y 2 reprogramados 6 y 5 veces | Informe del 2026-10-13 | Que Laura Vélez entregue el ajuste de presupuesto (sin fecha, notas del 2026-10-17) y que el gerente explique las 2 reprogramaciones (Gustavo Neira y Sandra Gil); riesgo no registrado de que el proveedor no llegue con el equipo completo (PRY-200-07) |
| PRY-201 | Salida a producción movida +30 días (de 2026-11-08 a 2026-12-08) de hecho, sin solicitud formal ni cronograma que la registre | Informe del 2026-10-16 | Solicitud con solicitante, motivo, alcance y costo; no está lista y se devuelve. Vigencia de CT-797 y CT-856 frente al 2026-12-08 |
| PRY-205 | En silencio 20 días (umbral 15), última declaración 2026-09-27, amarillo y 55 %; fecha de cierre del acta 2026-01-01, vencida | 2026-09-27 | Que el gerente (Ricardo Salas) reporte, o que el sponsor diga si el proyecto sigue |
| PRY-203 | Declara verde y 28 %, mientras el plan sostiene 100 % con 3 hitos «cumplidos» sin evidencia; fecha de cierre del acta 2026-01-17 vencida | Informe del 2026-10-08 | Que el gerente concilie estado y cronograma |
| PRY-209 | Declara verde y 58 %, con el hito «Diseño funcional aprobado» vencido 8 días y ningún hito cumplido | Informe del 2026-10-13 | Que el gerente concilie estado, hito y avance |
| PRY-210 | Declara verde y 73 %, mientras el plan sostiene 100 % con 3 hitos «cumplidos» sin evidencia; fecha de cierre 2026-09-06 vencida | Informe del 2026-10-12 | Que el gerente concilie estado y cronograma |

## Para conocimiento
- PRY-199 Cambio de mobiliario de agencias: verde, 20 %; el cálculo no da señales, pero el registro RAID le abre 4 ítems, entre ellos la dependencia del core (punto 4).
- PRY-204 y PRY-208: ver puntos 2 y 3.
- PRY-207 Microcrédito rural: amarillo, 37 %; hito «Diseño funcional aprobado» vencido 12 días y un compromiso vencido 1 día (Diana Molina).
- PRY-211 Cobranza digital: amarillo, 74 % declarado contra un plan que sostiene entre 0 y 33 % (ningún hito cumplido); COP 18.000.000.000 aprobados, 76,5 % comprometido; un compromiso sin fecha (Óscar Ramírez).
- PRY-202, 205, 206, 200, 201, 203, 209, 210: ver puntos y escalamientos arriba.

## Anexo

### Estado de cada proyecto (declarado por el gerente; las señales son del cálculo)
| Proyecto | Declarado | Avance declarado | Señales abiertas | Sponsor / Gerente | Órgano de la ficha |
|---|---|---|---|---|---|
| PRY-199 | verde | 20 % | 0 | María Restrepo / Andrés Lozano | Consejo de Administración |
| PRY-200 | rojo | 28 % | 12 | Jorge Medina / Rubén Cárdenas | Consejo de Administración |
| PRY-201 | rojo | 62 % | 7 | Felipe Arango / Óscar Ramírez | Comité de Crédito |
| PRY-202 | rojo | 46 % | 10 | Javier Hoyos / Ricardo Salas | Comité de Crédito |
| PRY-203 | verde | 28 % | 6 | Óscar Ramírez / María Restrepo | Comité de Educación |
| PRY-204 | rojo | 79 % | 5 | Laura Vélez / Mauricio Pérez | Comité de Riesgos |
| PRY-205 | amarillo | 55 % | 1 | Felipe Arango / Ricardo Salas | Comité de Riesgos |
| PRY-206 | rojo | 45 % | 10 | María Restrepo / Andrés Lozano | Consejo de Administración |
| PRY-207 | amarillo | 37 % | 2 | Óscar Ramírez / Paula Céspedes | Consejo de Administración |
| PRY-208 | amarillo | 73 % | 3 | Beatriz Cuéllar / Sandra Gil | Comité de Crédito |
| PRY-209 | verde | 58 % | 3 | Javier Hoyos / Camilo Beltrán | Comité de Crédito |
| PRY-210 | verde | 73 % | 5 | Rubén Cárdenas / Mauricio Pérez | Comité de Crédito |
| PRY-211 | amarillo | 74 % | 2 | Andrés Lozano / Felipe Arango | Comité de Riesgos |

Totales del cálculo: 13 proyectos, 12 con señales, 66 señales, 3 verdes contradichos por la evidencia (PRY-203, 209, 210), 0 sin línea base.

### Contradicciones abiertas
- Los 3 verdes de arriba.
- Hitos marcados «cumplido» sin evidencia en la carpeta: PRY-200 (2), PRY-201 (4), PRY-202 (4), PRY-203 (3), PRY-204 (3), PRY-206 (3), PRY-208 (1), PRY-210 (3).
- PRY-206: el cronograma v2 cierra la salida a producción el 2026-04-30, pero las actas de recibo de la integración con el core (2026-10-10) y del piloto (2026-10-16) son posteriores.
- PRY-201, CT-797: la factura FV-2797 (2026-09-01) cubre dos entregables y el acta del segundo es del 2026-09-14.

### Vacíos de información
- `authority` y `phase` vacíos en los 13 proyectos.
- 44 ítems RAID sin doliente ni fecha de vencimiento; ninguno con movimiento medible.
- Vigencia y preaviso de los contratos de proveedor: sin dato en lo leído.
- Si las facturas de PRY-201 y PRY-206 ya se pagaron: no consta.
- Campos con más de 12 meses de antigüedad en 7 proyectos: PRY-200, 202, 203, 204, 205, 206 y 210.
- Dependencias entre proyectos: ningún acta las declara; las 10 del registro RAID salieron de informes de avance y no están confirmadas.

## Después
Una vez el comité sesione, ofrezco registrar las decisiones en las fichas, abrir la línea base 2 de las solicitudes que se aprueben y armar el cierre de ciclo para el comité siguiente.

*Pie de rigor: versión de la familia 0.3.13, términos v1.1. Fichas aplicadas: las 13 de `estado/records/` al 2026-10-17. Campos inciertos: el código PRY-202 como proveedor del core (inferido), la fecha y el órgano de la aprobación de la CC-01 de PRY-206, el alcance de las tres CC-01 (no descrito), y toda vigencia de contrato. Cifras derivadas copiadas de `portafolio.py compute`; los importes de las solicitudes son los que traen los documentos. No sumé importes que el cálculo no entrega. Borrador de trabajo, no decisión ni asesoría: la verificación es de quien decide. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
