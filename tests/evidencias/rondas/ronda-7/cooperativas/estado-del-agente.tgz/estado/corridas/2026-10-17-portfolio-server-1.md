# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 66 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 23 |
| `vendor_deliverable_late` | 9 |
| `progress_vs_plan` | 8 |
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 3 |
| `variance_time` | 3 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `milestone_overdue` | 2 |
| `silent` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

puerto 8787, carpeta del informe reportes, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Modo elegido: **para mirarlo un rato** (respuesta recibida: «rato»). Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), no hizo falta pedirlos de nuevo.

El informe existe: `reportes/` tiene los 13 proyectos (PRY-199 a PRY-211), 7 productos, `decisiones.html`, `proyectos.html`, `productos.html` e `index.html`. El servidor no genera el informe, lo sirve.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, **solo en este equipo**. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | La portada, con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores con más de una cosa | La PMO |
| `/decisiones` | Lo que necesita una decisión, como pregunta cerrada y con la consecuencia de no decidirla | El comité y el patrocinador |
| `/proyectos` | El listado, ordenado por lo que más pide atención | Todos |
| `/p/<código>` | El informe de un proyecto, con enlace a su producto | Quien gerencia y quien pregunta |
| `/productos` | El listado de productos y los proyectos que no dicen cuál construyen | Quien responde por un producto |
| `/producto/<nombre>` | El informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El portal lleva el nombre «Cooperativa» en todas las páginas, porque se le pasa `--config`.

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe ninguna ficha (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos.

**Qué enlace a quién:** en este modo nadie más puede abrirlo; `http://127.0.0.1:8787/` es solo para quien lo levantó. El patrocinador no tiene enlace que funcione mañana: para eso hace falta «que quede corriendo» (con `--abierto`, un host y puerto internos, publicado detrás del control de acceso de la organización; el servidor no autentica). Se puede hablar con seguridad después de haberlo visto funcionar.

**Cuándo queda desactualizado:** la portada lo dice con la fecha del informe. Hoy es 2026-10-17; el siguiente comité es el 2026-10-24, y el informe debería regenerarse con `/portfolio-report html` antes de esa fecha (2 días de antelación según la configuración).
