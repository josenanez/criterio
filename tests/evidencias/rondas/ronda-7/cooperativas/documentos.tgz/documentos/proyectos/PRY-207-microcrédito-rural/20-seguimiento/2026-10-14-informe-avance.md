# Informe de avance · Microcrédito rural

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Paula Céspedes

## Estado declarado

**Amarillo**

Avance reportado: **37%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 531.203.197 |
| Ejecutado | 526.980.576 |
| Proyección al cierre | 1.121.293.612 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
