# Comité de Crédito · Corresponsales rurales

**Fecha:** 2026-10-17
**Asistentes:** Mauricio Pérez, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 23 | 2026-10-21 |
