# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Pagos con QR
**Fecha:** 2026-10-05
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +36 días sobre la línea base vigente |
| Costo | 72.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
