# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-12
**Asistentes:** Felipe Arango, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 28 | por definir |
