# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Tarjeta débito para asociados
**Fecha:** 2026-10-15
**Solicitante:** Mauricio Pérez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +116 días sobre la línea base vigente |
| Costo | 232.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
