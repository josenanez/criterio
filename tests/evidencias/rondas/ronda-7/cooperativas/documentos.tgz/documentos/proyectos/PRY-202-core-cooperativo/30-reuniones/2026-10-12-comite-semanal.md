# Comité de Crédito · Core cooperativo

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 4 | por definir |
