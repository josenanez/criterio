# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-05
**Asistentes:** Gustavo Neira, Laura Vélez, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-09-12 |
| Sandra Gil | Cerrar la prueba 2 | 2026-09-14 |
| Paula Céspedes | Revisar el anexo 3 | 2026-10-03 |
| Laura Vélez | Validar el ambiente 4 | 2026-09-18 |
