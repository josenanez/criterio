# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-26
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Mauricio Pérez, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-10-26 |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-03 |
| Mauricio Pérez | Aprobar el diseño 5 | 2026-10-10 |
| Javier Hoyos | Actualizar la matriz 6 | 2026-10-09 |
| Felipe Arango | Entregar el punto 8 | 2026-10-03 |
| Gustavo Neira | Enviar el documento 9 | 2026-09-29 |
| Elena Duarte | Cerrar la prueba 10 | 2026-10-10 |
| Camilo Beltrán | Revisar el anexo 11 | 2026-10-21 |
| Javier Hoyos | Validar el ambiente 12 | por definir |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-18 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-18 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-10 |
| Sandra Gil | Entregar el punto 16 | 2026-10-22 |
