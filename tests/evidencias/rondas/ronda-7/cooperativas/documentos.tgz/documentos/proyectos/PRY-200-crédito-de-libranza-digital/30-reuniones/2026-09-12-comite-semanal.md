# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-09-12
**Asistentes:** Felipe Arango, Gustavo Neira, Javier Hoyos, Laura Vélez, Mauricio Pérez, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Enviar el documento 1 | 2026-09-25 |
| Sandra Gil | Cerrar la prueba 2 | 2026-09-27 |
| Paula Céspedes | Revisar el anexo 3 | 2026-10-19 |
| Laura Vélez | Validar el ambiente 4 | 2026-09-18 |
| Mauricio Pérez | Aprobar el diseño 5 | por definir |
| Javier Hoyos | Actualizar la matriz 6 | 2026-10-09 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-10-10 |
| Felipe Arango | Entregar el punto 8 | por definir |
