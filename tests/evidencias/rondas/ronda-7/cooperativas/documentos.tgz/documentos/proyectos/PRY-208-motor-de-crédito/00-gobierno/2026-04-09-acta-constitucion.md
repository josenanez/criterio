# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Ahorro y aportes
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Crédito
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-09

## Objetivo del negocio

Entregar motor de crédito para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Crédito el 2026-04-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-19 |
| Cierre | 2027-01-26 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
