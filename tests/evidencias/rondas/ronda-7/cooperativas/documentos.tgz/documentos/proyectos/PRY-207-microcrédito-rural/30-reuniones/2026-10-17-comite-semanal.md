# Consejo de Administración · Microcrédito rural

**Fecha:** 2026-10-17
**Asistentes:** Paula Céspedes, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Entregar el punto 37 | 2026-10-16 |
