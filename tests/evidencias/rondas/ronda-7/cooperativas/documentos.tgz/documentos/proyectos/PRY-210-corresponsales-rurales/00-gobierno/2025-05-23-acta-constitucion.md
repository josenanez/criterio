# Acta de constitución · Corresponsales rurales

**Código:** PRY-210
**Área dueña:** Tesorería
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Crédito
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-23

## Objetivo del negocio

Entregar corresponsales rurales para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Crédito el 2025-05-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-02 |
| Cierre | 2026-09-06 |

## Criterio de éxito

Corresponsales rurales en producción y medido.

## Dependencias declaradas

- Ninguna declarada
