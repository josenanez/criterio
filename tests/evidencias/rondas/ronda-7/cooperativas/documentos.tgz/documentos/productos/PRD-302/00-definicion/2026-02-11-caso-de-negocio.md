# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2026-02-11
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 226.296 | Caso de negocio, 2026-02-11 |

## Retorno esperado

Retorno esperado en 24 meses.
