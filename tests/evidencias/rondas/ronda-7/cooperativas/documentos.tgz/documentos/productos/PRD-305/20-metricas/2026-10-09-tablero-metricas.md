# Tablero de métricas · Microcrédito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 207.028 | 2026-10-09 |
