# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-02-10
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 248.253 | Caso de negocio, 2026-02-10 |

## Retorno esperado

Retorno esperado en 24 meses.
