# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2025-10-28
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 255.456 | Caso de negocio, 2025-10-28 |

## Retorno esperado

Retorno esperado en 24 meses.
