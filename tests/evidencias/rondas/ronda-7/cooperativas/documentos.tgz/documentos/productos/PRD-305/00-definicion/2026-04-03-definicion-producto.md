# Definición de producto · Microcrédito

**Código:** PRD-305
**Gerente de producto:** María Restrepo
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-04-03

## El problema

El segmento Microempresarios no tiene microcrédito.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-04-06 · verificado con el documento técnico del proveedor del 2026-06-14

## Proyectos que lo construyen

- Ninguno declarado
