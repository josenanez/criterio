# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Jorge Medina
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-04-21

## El problema

El segmento Microempresarios no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-13 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
