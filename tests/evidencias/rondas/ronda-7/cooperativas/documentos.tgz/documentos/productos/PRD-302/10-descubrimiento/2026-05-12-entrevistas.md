# Entrevistas · Aportes sociales

**Ronda:** Ronda · 2026-05-12
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-05-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
