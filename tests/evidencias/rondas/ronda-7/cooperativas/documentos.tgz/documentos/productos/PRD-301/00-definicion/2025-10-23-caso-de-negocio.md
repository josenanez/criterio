# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2025-10-23
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 72.801 | Caso de negocio, 2025-10-23 |

## Retorno esperado

Retorno esperado en 24 meses.
