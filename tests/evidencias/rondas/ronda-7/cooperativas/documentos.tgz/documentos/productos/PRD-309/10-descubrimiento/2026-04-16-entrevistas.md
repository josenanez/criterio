# Entrevistas · Microseguros

**Ronda:** Ronda · 2026-04-16
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2026-04-16

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
