# Definición de producto · Tarjeta débito

**Código:** PRD-303
**Gerente de producto:** Javier Hoyos
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-01-16

## El problema

El segmento Jóvenes no tiene tarjeta débito.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-06-16 · verificado con la entrevista con doce clientes del segmento del 2026-08-23

## Proyectos que lo construyen

- Ninguno declarado
