# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2025-12-27
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 209.651 | Caso de negocio, 2025-12-27 |

## Retorno esperado

Retorno esperado en 24 meses.
