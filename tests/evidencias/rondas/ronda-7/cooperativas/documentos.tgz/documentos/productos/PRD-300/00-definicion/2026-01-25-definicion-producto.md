# Definición de producto · Crédito de libranza

**Código:** PRD-300
**Gerente de producto:** Elena Duarte
**Segmento:** Pensionados
**Fecha de la definición:** 2026-01-25

## El problema

El segmento Pensionados no tiene crédito de libranza.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-12 · verificado con el documento técnico del proveedor del 2026-09-10

## Proyectos que lo construyen

- Ninguno declarado
