# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2026-04-03
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 216.930 | Caso de negocio, 2026-04-03 |

## Retorno esperado

Retorno esperado en 24 meses.
