# Comité de producto · Microseguros

**Fecha:** 2026-10-12
**Asistentes:** Mauricio Pérez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-11 | — |
| REQ-4901 | Requerimiento REQ-4901 | sin asignar | — | Cliente entrevistado | aceptado | 2026-03-25 | — |
| REQ-4902 | Requerimiento REQ-4902 | Ricardo Salas | — | Cliente entrevistado | propuesto | 2026-06-05 | — |
| REQ-4903 | Requerimiento REQ-4903 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-22 | — |
| REQ-4904 | Requerimiento REQ-4904 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-23 | — |
| REQ-4905 | Requerimiento REQ-4905 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4906 | Requerimiento REQ-4906 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4907 | Requerimiento REQ-4907 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4908 | Requerimiento REQ-4908 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-22 | — |
| REQ-4909 | Requerimiento REQ-4909 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-29 | — |
| REQ-4910 | Requerimiento REQ-4910 | Rubén Cárdenas | — | — | aceptado | 2026-03-29 | — |
| REQ-4911 | Requerimiento REQ-4911 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-08-04 | — |
| REQ-4912 | Requerimiento REQ-4912 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4913 | Requerimiento REQ-4913 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-07 | — |
| REQ-4914 | Requerimiento REQ-4914 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-06-02 | — |
| REQ-4915 | Requerimiento REQ-4915 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-30 | — |

## Decisiones

- Se mantiene el plan
