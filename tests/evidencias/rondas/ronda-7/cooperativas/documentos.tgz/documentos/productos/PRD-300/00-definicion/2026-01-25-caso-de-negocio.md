# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-01-25
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 164.832 | Caso de negocio, 2026-01-25 |

## Retorno esperado

Retorno esperado en 24 meses.
