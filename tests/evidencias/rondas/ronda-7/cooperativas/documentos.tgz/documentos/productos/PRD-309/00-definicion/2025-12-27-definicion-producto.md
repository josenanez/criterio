# Definición de producto · Microseguros

**Código:** PRD-309
**Gerente de producto:** Mauricio Pérez
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-12-27

## El problema

El segmento Jóvenes no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-07-04 · verificado con la entrevista con doce clientes del segmento del 2026-08-13

## Proyectos que lo construyen

- Ninguno declarado
