# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** Javier Hoyos
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-02-11

## El problema

El segmento Asociados urbanos no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-09-04 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
