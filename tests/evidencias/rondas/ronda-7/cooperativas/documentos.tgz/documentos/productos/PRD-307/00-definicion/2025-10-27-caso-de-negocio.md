# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2025-10-27
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 184.145 | Caso de negocio, 2025-10-27 |

## Retorno esperado

Retorno esperado en 24 meses.
