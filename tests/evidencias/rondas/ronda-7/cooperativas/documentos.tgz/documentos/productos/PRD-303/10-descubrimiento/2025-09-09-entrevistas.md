# Entrevistas · Tarjeta débito

**Ronda:** Ronda · 2025-09-09
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-09-09

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
