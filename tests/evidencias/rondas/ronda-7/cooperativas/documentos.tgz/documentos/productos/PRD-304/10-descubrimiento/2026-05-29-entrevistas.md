# Entrevistas · Pagos QR

**Ronda:** Ronda · 2026-05-29
**Realizadas por:** Jorge Medina

### Cliente entrevistado · 2026-05-29

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
