# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-01-16
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 135.944 | Caso de negocio, 2026-01-16 |

## Retorno esperado

Retorno esperado en 24 meses.
