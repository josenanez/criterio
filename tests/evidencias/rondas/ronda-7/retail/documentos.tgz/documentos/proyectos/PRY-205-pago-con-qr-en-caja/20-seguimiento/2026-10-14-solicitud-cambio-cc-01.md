# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Pago con QR en caja
**Fecha:** 2026-10-14
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +75 días sobre la línea base vigente |
| Costo | 150.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
