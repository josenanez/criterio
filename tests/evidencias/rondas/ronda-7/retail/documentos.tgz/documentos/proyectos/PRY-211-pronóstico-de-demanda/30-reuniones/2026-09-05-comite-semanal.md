# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-09-05
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Javier Hoyos, Liliana Torres, Natalia Ospina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | por definir |
| Javier Hoyos | Cerrar la prueba 2 | 2026-09-09 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-09-09 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-10 |
