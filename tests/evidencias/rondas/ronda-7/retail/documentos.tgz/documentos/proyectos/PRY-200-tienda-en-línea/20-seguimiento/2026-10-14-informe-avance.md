# Informe de avance · Tienda en línea

**Código:** PRY-200
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Rojo**

Avance reportado: **39%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.347.036.665 |
| Ejecutado | 2.214.748.739 |
| Proyección al cierre | 4.185.311.326 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
