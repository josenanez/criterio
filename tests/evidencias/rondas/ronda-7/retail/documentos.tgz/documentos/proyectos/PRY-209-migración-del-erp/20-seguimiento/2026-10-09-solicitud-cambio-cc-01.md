# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Migración del ERP
**Fecha:** 2026-10-09
**Solicitante:** Óscar Ramírez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +55 días sobre la línea base vigente |
| Costo | 110.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
