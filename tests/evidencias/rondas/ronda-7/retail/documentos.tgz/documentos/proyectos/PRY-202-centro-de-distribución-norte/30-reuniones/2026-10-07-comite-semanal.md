# Comité de Expansión · Centro de distribución norte

**Fecha:** 2026-10-07
**Asistentes:** Diana Molina, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 18 | 2026-11-01 |
