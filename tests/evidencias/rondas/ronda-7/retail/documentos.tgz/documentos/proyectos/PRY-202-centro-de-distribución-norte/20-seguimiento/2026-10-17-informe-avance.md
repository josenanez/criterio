# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-17
**Gerente:** Diana Molina

## Estado declarado

**Rojo**

Avance reportado: **26%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 912.352.720 |
| Ejecutado | 752.025.444 |
| Proyección al cierre | 1.514.819.185 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
