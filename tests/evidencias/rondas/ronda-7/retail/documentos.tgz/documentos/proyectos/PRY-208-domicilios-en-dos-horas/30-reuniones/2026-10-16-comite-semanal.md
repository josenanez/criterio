# Comité de Expansión · Domicilios en dos horas

**Fecha:** 2026-10-16
**Asistentes:** Óscar Ramírez, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 25 | 2026-11-10 |
