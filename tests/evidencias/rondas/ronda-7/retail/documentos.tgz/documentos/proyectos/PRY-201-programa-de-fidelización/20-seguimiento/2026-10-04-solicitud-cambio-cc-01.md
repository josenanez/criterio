# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-04
**Solicitante:** Carlos Peña

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +27 días sobre la línea base vigente |
| Costo | 54.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
