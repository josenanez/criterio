# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-10-24 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-29 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-10-16 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-10 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-29 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-17 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 |
| Elena Duarte | Entregar el punto 8 | 2026-10-16 |
| María Restrepo | Enviar el documento 9 | 2026-10-12 |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-17 |
| Diana Molina | Validar el ambiente 12 | 2026-10-09 |
| Laura Vélez | Aprobar el diseño 13 | por definir |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-16 |
| Ricardo Salas | Confirmar la fecha 15 | 2026-10-16 |
| Felipe Arango | Entregar el punto 16 | 2026-10-16 |
