# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-11-24 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-19 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-11-01 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 |
| Elena Duarte | Entregar el punto 8 | 2026-11-06 |
| María Restrepo | Enviar el documento 9 | 2026-10-27 |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-11-09 |
| Ricardo Salas | Confirmar la fecha 15 | 2026-10-16 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-25 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-12 |
| Paula Céspedes | Revisar el anexo 19 | 2026-10-29 |
| Mauricio Pérez | Aprobar el diseño 21 | 2026-10-18 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-20 |
| Beatriz Cuéllar | Confirmar la fecha 23 | 2026-11-05 |
| Camilo Beltrán | Entregar el punto 24 | 2026-10-22 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Natalia Ospina): recibido, acta de recibo del 2026-10-10.
- Validar el ambiente 12 (Diana Molina): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Felipe Arango dice que ya entregó «entregar el punto 16». No se presentó acta.
- Óscar Ramírez dice que ya entregó «validar el ambiente 20». No se presentó acta.
