# Acta de constitución · Precios dinámicos

**Código:** PRY-206
**Área dueña:** Logística
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité Comercial
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-06-02

## Objetivo del negocio

Entregar precios dinámicos para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité Comercial el 2025-06-02.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-12 |
| Cierre | 2025-12-22 |

## Criterio de éxito

Precios dinámicos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
