# Tablero de métricas · Tarjeta de la tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-10

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 208.658 | 2026-10-10 |
