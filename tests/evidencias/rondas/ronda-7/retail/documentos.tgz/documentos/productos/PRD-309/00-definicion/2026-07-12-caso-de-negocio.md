# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-07-12
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 272.424 | Caso de negocio, 2026-07-12 |

## Retorno esperado

Retorno esperado en 24 meses.
