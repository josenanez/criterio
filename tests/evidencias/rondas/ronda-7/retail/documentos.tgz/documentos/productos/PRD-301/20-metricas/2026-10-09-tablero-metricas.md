# Tablero de métricas · Puntos de fidelización

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 52.991 | 2026-10-09 |
