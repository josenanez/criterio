# Definición de producto · Marketplace

**Código:** PRD-308
**Gerente de producto:** Óscar Ramírez
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-07-21

## El problema

El segmento Clientes frecuentes no tiene marketplace.

## La propuesta

- Propuesta principal

## Supuestos

- **El cliente paga por la entrega rápida** · declarado el 2026-09-22 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
