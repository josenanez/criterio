# Comité de producto · Marketplace

**Fecha:** 2026-10-08
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-07-16 | — |
| REQ-4801 | Requerimiento REQ-4801 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4802 | Requerimiento REQ-4802 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-05 | — |
| REQ-4803 | Requerimiento REQ-4803 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-01 | — |
| REQ-4804 | Requerimiento REQ-4804 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4805 | Requerimiento REQ-4805 | Ricardo Salas | se verifica en producción | — | propuesto | 2026-08-21 | — |
| REQ-4806 | Requerimiento REQ-4806 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-22 | — |
| REQ-4807 | Requerimiento REQ-4807 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4808 | Requerimiento REQ-4808 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-08 | — |
| REQ-4809 | Requerimiento REQ-4809 | Carlos Peña | — | — | aceptado | 2026-04-22 | — |
| REQ-4810 | Requerimiento REQ-4810 | Diana Molina | se verifica en producción | — | propuesto | 2026-04-07 | — |
| REQ-4811 | Requerimiento REQ-4811 | Camilo Beltrán | se verifica en producción | — | aceptado | 2026-06-16 | — |
| REQ-4812 | Requerimiento REQ-4812 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4813 | Requerimiento REQ-4813 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-2028 | Requerimiento REQ-2028 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-04 | — |

## Decisiones

- Se mantiene el plan
