# Entrevistas · Compra y recoge

**Ronda:** Ronda · 2026-08-30
**Realizadas por:** Jorge Medina

### Cliente entrevistado · 2026-08-30

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
