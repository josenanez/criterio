# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2025-09-10
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 79.996 | Caso de negocio, 2025-09-10 |

## Retorno esperado

Retorno esperado en 24 meses.
