# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-04-28
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 152.040 | Caso de negocio, 2026-04-28 |

## Retorno esperado

Retorno esperado en 24 meses.
