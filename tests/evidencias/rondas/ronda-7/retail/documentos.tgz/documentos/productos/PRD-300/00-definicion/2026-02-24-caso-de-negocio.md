# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2026-02-24
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 240.127 | Caso de negocio, 2026-02-24 |

## Retorno esperado

Retorno esperado en 24 meses.
