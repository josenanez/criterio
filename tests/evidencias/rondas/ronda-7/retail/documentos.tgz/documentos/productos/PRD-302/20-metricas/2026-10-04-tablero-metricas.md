# Tablero de métricas · Autopago en tienda

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-04

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 61.646 | 2026-10-04 |
