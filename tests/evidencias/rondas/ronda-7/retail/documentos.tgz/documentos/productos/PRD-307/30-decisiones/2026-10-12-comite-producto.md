# Comité de producto · Compra y recoge

**Fecha:** 2026-10-12
**Asistentes:** Jorge Medina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Natalia Ospina | — | Cliente entrevistado | propuesto | 2026-04-29 | — |
| REQ-4701 | Requerimiento REQ-4701 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4702 | Requerimiento REQ-4702 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4703 | Requerimiento REQ-4703 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-16 | — |
| REQ-4704 | Requerimiento REQ-4704 | Felipe Arango | se verifica en producción | — | propuesto | 2026-04-23 | — |
| REQ-4705 | Requerimiento REQ-4705 | Elena Duarte | — | Cliente entrevistado | aceptado | 2026-06-29 | — |
| REQ-4706 | Requerimiento REQ-4706 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-27 | — |
| REQ-4707 | Requerimiento REQ-4707 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-08-29 | — |
| REQ-4708 | Requerimiento REQ-4708 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-07 | — |
| REQ-4709 | Requerimiento REQ-4709 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-06-10 | — |
| REQ-4710 | Requerimiento REQ-4710 | Carlos Peña | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-21 | — |
| REQ-4711 | Requerimiento REQ-4711 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-04 | — |
| REQ-4712 | Requerimiento REQ-4712 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4713 | Requerimiento REQ-4713 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-2035 | Requerimiento REQ-2035 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-02 | — |

## Decisiones

- Se mantiene el plan
