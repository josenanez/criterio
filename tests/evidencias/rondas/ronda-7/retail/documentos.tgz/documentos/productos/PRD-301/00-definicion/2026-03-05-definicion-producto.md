# Definición de producto · Puntos de fidelización

**Código:** PRD-301
**Gerente de producto:** Óscar Ramírez
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-03-05

## El problema

El segmento Clientes frecuentes no tiene puntos de fidelización.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-06 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
