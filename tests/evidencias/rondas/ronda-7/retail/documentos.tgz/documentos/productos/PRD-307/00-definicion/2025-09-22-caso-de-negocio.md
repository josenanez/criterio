# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2025-09-22
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 165.682 | Caso de negocio, 2025-09-22 |

## Retorno esperado

Retorno esperado en 24 meses.
