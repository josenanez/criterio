# Comité de producto · Marca propia

**Fecha:** 2026-10-16
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4400 | Requerimiento REQ-4400 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-08-30 | — |
| REQ-4401 | Requerimiento REQ-4401 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-04-11 | — |
| REQ-4402 | Requerimiento REQ-4402 | Paula Céspedes | — | — | aceptado | 2026-08-19 | — |
| REQ-4403 | Requerimiento REQ-4403 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-07 | — |
| REQ-4404 | Requerimiento REQ-4404 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-07-13 | — |
| REQ-4405 | Requerimiento REQ-4405 | sin asignar | — | — | aceptado | 2026-05-17 | — |
| REQ-4406 | Requerimiento REQ-4406 | Jorge Medina | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-26 | — |
| REQ-4407 | Requerimiento REQ-4407 | Paula Céspedes | — | — | aceptado | 2026-06-08 | — |
| REQ-4408 | Requerimiento REQ-4408 | Liliana Torres | se verifica en producción | — | aceptado | 2026-07-05 | — |
| REQ-4409 | Requerimiento REQ-4409 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-02 | — |
| REQ-4410 | Requerimiento REQ-4410 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-04-04 | — |
| REQ-4411 | Requerimiento REQ-4411 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-17 | — |
| REQ-4412 | Requerimiento REQ-4412 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-07 | — |
| REQ-4413 | Requerimiento REQ-4413 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-08 | — |

## Decisiones

- Se mantiene el plan
