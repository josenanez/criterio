Fuente: ficha `estado/records/PRY-205.json` (documentos de `PRY-205-pago-con-qr-en-caja`, el más reciente del 2026-10-14) y `portafolio.py compute` con corte 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Presupuesto — PRY-205 Pago con QR en caja al 2026-10-17
**Moneda:** COP (única; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 3.300.000.000 | 100 | 00-gobierno/2025-12-17-acta-constitucion.docx | 2025-12-17 |
| Comprometido | 3.152.315.214 | 95,5 | 20-seguimiento/2026-10-14-informe-avance.md (declaración) | 2026-10-14 |
| Ejecutado | 1.792.674.413 | 54,3 | 20-seguimiento/2026-10-14-informe-avance.md (declaración) | 2026-10-14 |
| Proyección al cierre | 3.379.087.994 | 102,4 (excede el aprobado en 2,4 %) | 20-seguimiento/2026-10-14-informe-avance.md (declaración) | 2026-10-14 |

**Disponible real** (aprobado menos comprometido): 147.684.786 COP

La proyección es una declaración del gerente, no un dato medido. Tiene la misma fecha que el último movimiento de presupuesto (CC-01, 2026-10-14), así que no es más vieja que él; aun así no sabemos si ya incorpora los 150.000.000 COP que CC-01 pide.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 3.300.000.000 | 3.300.000.000 | 0 (sin cambio aprobado) |

Replanificaciones de presupuesto: 0. La única solicitud con impacto en costo es CC-01 (2026-10-14): +150.000.000 COP, decisión **pendiente**, sin quien la haya decidido. No se suma al aprobado.

### Ejecución frente a avance
Ejecutado 54,3 % · Hitos cumplidos 2 de 4 (avance declarado 50 %) · En orden de magnitud van parejos, pero el segundo hito cumplido ("Ambiente de pruebas certificado", vencido el 2026-07-24) no tiene evidencia de recibo: con evidencia solo hay 1 de 4. El ejecutado, entonces, queda por encima de lo que los documentos sostienen como avance.

### Alertas
- **Comprometido 95,5 %, por encima del umbral de 90 %.** Con 54,3 % ejecutado, el presupuesto está casi agotado aunque no se haya causado: quedan 147.684.786 COP libres.
- **La proyección excede el aprobado (102,4 %).** Con holgura de 147.684.786 COP y proyección sobre el tope, no hay margen sin una decisión de presupuesto.
- **CC-01 sin decidir y cronograma v2 ya lo asume.** Hay +75 días de cierre (2027-02-19 → 2027-05-05) movidos en la línea base sin autorización (0 días autorizados). Desviación de tiempo contra la original: 75 días, 17,9 %, por encima del umbral de 10 %.
- El informe de avance del 2026-10-14 declara **verde**; las cuatro señales anteriores no están reconocidas en él.

### Sin dato
- Autoridad que aprueba el presupuesto (`identity.authority`): no encontrada.
- Fase del proyecto (`identity.phase`): no encontrada.
- Comprometido, ejecutado y proyección solo existen como declaración del informe de avance; ningún documento de soporte (contratos, facturas, extracto contable) los respalda. No hay proveedores registrados en la ficha, por lo que no se puede abrir el detalle por proveedor.
- Si la proyección incluye o no los 150.000.000 COP de CC-01: no se dice en ningún documento.

### Siguiente paso
La proyección excede el aprobado y el comprometido supera el umbral. Puedo preparar la solicitud de cambio de presupuesto (CC-01 ya está pendiente de presentación al comité) o el detalle por proveedor, este último solo si se aportan los contratos.

*Pie de rigor: borrador de trabajo generado por Criterio a partir de los documentos citados; no es decisión ni asesoría. Cada cifra sale de `portafolio.py compute` o de la ficha, y la verificación contra los documentos es suya.*
