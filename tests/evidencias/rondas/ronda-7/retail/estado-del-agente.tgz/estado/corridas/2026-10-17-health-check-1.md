# Corrida del 2026-10-17 · health-check

13 proyectos · 155 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico de PRY-211 sobre 20 archivos: dictamen 8 sostenidas, 12 sin sustento, 4 contradichas. Estado verde contradicho por la proyección del propio informe (+26,9%). Dijo que no sabe: autoridad del gerente, junio a agosto, pagos reales, vigencia del cronograma, alcance.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-211 Pronóstico de demanda · 2026-10-17

**Leí:** 20 archivos del proyecto · 2026-05-21 a 2026-10-17 · formatos: .md (14), .pdf (2), .docx (1), .xlsx (1), .txt (1), .json (1). Busqué también menciones del proyecto, de sus contratos (CT-842, CT-565) y de sus proveedores en las carpetas de los demás proyectos: no hay ninguna.
**No pude leer:** nada; los 19 documentos convertidos salieron completos. Un archivo, `00-gobierno/ficha-pm.json`, lo leí pero **no lo cuento como evidencia**: es el resumen que el gerente publicó de estos mismos documentos. No leí las salidas de corridas anteriores del agente, porque no son documentos del proyecto.

### Dictamen
**Sostenido:** 8 afirmaciones · **Sin sustento:** 12 · **Contradicho:** 4

- *Sostenidas (8):* patrocinador, gerente y comité (acta); presupuesto aprobado de 6.800.000.000 COP (acta); fechas comprometidas 2026-05-31 a 2026-11-30 (acta y cronograma coinciden); recibo de la Bolsa de horas de CT-842 (acta del 2026-08-20); y los cuatro compromisos cerrados con acta (diseño 5, matriz 6, ambiente 4, ambiente 12).
- *Contradichas (4):* el estado «verde»; la «reprogramación del despliegue»; la factura FV-1842 contra lo recibido en CT-842; la factura FV-2565 contra la ausencia de acta en CT-565.
- *Sin sustento (12):* avance 49%; comprometido; ejecutado; proyección; los tres hitos «cerrados»; la extensión de la validación con dos tiendas; y las cuatro entregas «ya hechas» dichas en comité sin acta (diseño 13, matriz 14, punto 16, ambiente 20).

Desde esta carpeta se puede afirmar que el proyecto tiene acta, patrocinador, gerente y comité, y que **el único documento que respalda el estado verde es el informe del propio gerente, que en su misma tabla de presupuesto proyecta 26,9% sobre lo aprobado**. Ninguno de los tres hitos que el cronograma da por cerrados tiene un documento de cierre. De los 6 entregables de los dos contratos, uno tiene acta de recibo, y ambas facturas están radicadas. No se puede afirmar quién autorizó cualquier desviación, porque la autoridad del gerente no está declarada, ni cuánto se ha gastado de verdad, porque no hay ningún registro contable en la carpeta.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Jorge Medina. Asistió a los comités del 2026-09-12, 09-19 y 09-26; no figura en los del 2026-10-03 y 10-10 ni en las notas del 2026-10-17. | `00-gobierno/2026-05-21-acta-constitucion.docx`; `30-reuniones/*` |
| Gerente | Andrés Lozano. Firma las actas de recibo. | acta de constitución; `20-seguimiento/*acta-recibo*` |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente en fechas, dinero o alcance. | acta de constitución (sin sección) |
| Comité | Comité Comercial, que aprobó el presupuesto el 2026-05-21. Las minutas de septiembre y octubre listan compromisos, y ninguna registra una decisión. | acta; `30-reuniones/*` |

Otros vacíos del acta: alcance «Componente 1, 2, 3» sin describir; exclusión «Lo que otro proyecto cubre» sin nombrar el proyecto; «Dependencias: Ninguna declarada» aunque hay dos contratos con proveedores; producto asociado «No aplica». El criterio de éxito (*«Pronóstico de demanda en producción y medido»*) está fechado en el cronograma con el despliegue el 2026-11-30, que es también la fecha de cierre: el documento no deja un periodo para «medido».

### Contra el plan
- **Línea base original (v1, aprobada 2026-05-21):** 2026-05-31 a 2026-11-30. Es la única. Fuente: acta y `10-plan/2026-05-21-cronograma-v1.xlsx`.
- **Vigente:** igual a la original; 0 replanificaciones, 0 días de atraso contra la original y contra la vigente.
- **Cambios aprobados:** 0. No hay solicitud de cambio ni acta de comité que mueva fechas o presupuesto.
- **Lo que el informe dice y el plan no muestra:** el informe del 2026-10-14 afirma que se reprogramó el despliegue; el cronograma sigue con 2026-11-30 en fecha de línea base y en fecha vigente. O la replanificación no se registró, o el cronograma está desactualizado. Los dos casos son un hallazgo.
- **Ojo con el archivo del cronograma:** lleva 2026-05-21 en el nombre y declara «cerrados» hitos cuyas fechas son de julio a septiembre; el nombre no refleja su última edición, y no se puede saber cuándo se marcó cada hito.
- **Avance:** declarado 49%. Si los 3 hitos «cerrados» fueran ciertos, el plan sostiene entre 60% y 80%; la diferencia contra el declarado es de 11,0 puntos hacia abajo. Las dos cifras no pueden ser ciertas a la vez, y los hitos no tienen evidencia.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-07-06 | 103 | Acta de aprobación del diseño, con firma del patrocinador o del comité |
| Ambiente de pruebas certificado | 2026-08-12 | 66 | Certificado o acta de pruebas del ambiente |
| Integración con el ERP | 2026-09-18 | 29 | Acta de pruebas de integración o de recibo |

Los tres están marcados «cerrado» en el cronograma y ninguno tiene documento en la carpeta. Tampoco hay explicación de cómo se certificó un ambiente y se cerró la integración con el ERP cuando, según ambos contratos, la plataforma sigue sin licenciar (ver Dinero).

Entregables de proveedores vencidos sin acta de recibo:
| Proveedor · entregable | Fecha | Días |
|---|---|---|
| Datos y Demanda (CT-842) · Licenciamiento de la plataforma | 2026-07-10 | 99 |
| Datos y Demanda (CT-842) · Configuración del catálogo | 2026-09-29 | 18 |
| Tecnología para Tiendas (CT-565) · Licenciamiento de la plataforma | 2026-08-06 | 72 |
| Tecnología para Tiendas (CT-565) · Bolsa de horas de desarrollo | 2026-10-12 | 5 |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 2.114.474.257 | 1.539.004.991 | 8.631.313.230 | 4.685.525.743 |

Ejecutado 22,6% y comprometido 31,1% del aprobado. **Proyección 26,9% sobre lo aprobado** (umbral configurado: 10%). Solo el aprobado viene de un documento de gobierno (el acta); comprometido, ejecutado y proyección son declaración del informe del 2026-10-14, sin libro, ni orden de compra, ni método de cálculo. El «disponible real» sale del comprometido declarado, y la proyección dice que no alcanzará.

Proveedores contra lo facturado (condición de pago de ambos contratos: «se factura contra acta de recibo firmada por el gerente»):
- **CT-842, Datos y Demanda:** facturado 1.197.938.594 (FV-1842, 2026-10-02, concepto «Entregables del contrato CT-842»). Recibido con acta: un entregable, 775.475.640. **Facturado sobre lo recibido: 422.462.954.** El monto facturado no coincide con ninguna combinación de las líneas del contrato, todas de 775.475.640.
- **CT-565, Tecnología para Tiendas:** facturado 723.840.453 (FV-2565, 2026-09-16, «Entregables del contrato CT-565»). Recibido con acta: 0 de 2 entregables. La factura es anterior a la fecha de la Bolsa de horas (2026-10-12) y el Licenciamiento (2026-08-06) está vencido sin acta.
- **No se pudo conciliar** el comprometido y el ejecutado del informe con los contratos y las facturas: el script no entrega esa conciliación y no se escribe una suma a mano. Falta el dato de qué pagó cuentas por pagar y cuándo.

### Lo que se dijo y nadie registró
- **Riesgo sin dueño ni registro:** «el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo» (notas del 2026-10-17). El informe lista un solo riesgo, el congelamiento de temporada alta. No se dice de cuál proveedor.
- **Ajuste de presupuesto sin solicitud de cambio:** Laura Vélez «queda de mandar el ajuste del presupuesto la otra semana» (2026-10-17). No es fecha, y no hay solicitud de cambio en la carpeta. Es coherente con una proyección 26,9% sobre lo aprobado que el informe no menciona.
- **Cuatro entregas «ya hechas» sin acta:** Laura Vélez (diseño 13) y Beatriz Cuéllar (matriz 14), el 2026-10-03; Felipe Arango (punto 16) y Óscar Ramírez (ambiente 20), el 2026-10-10. La condición documental del proyecto es el acta. Las minutas no dicen cómo llegó cada afirmación, y Laura Vélez (10-03) y Felipe Arango (10-10) no figuran entre los asistentes de esas reuniones. Los cuatro desaparecieron de la tabla de compromisos.
- **Compromisos vencidos sin evidencia (7):**
  - Paula Céspedes, Confirmar la fecha 7: 2026-09-26, 21 días.
  - Rubén Cárdenas, Cerrar la prueba 10: 2026-10-10, 7 días.
  - Óscar Ramírez, Validar el ambiente 20: 2026-10-10, 7 días.
  - Ricardo Salas, Cerrar la prueba 18: 2026-10-12, 5 días.
  - Beatriz Cuéllar, Actualizar la matriz 14: 2026-10-16, 1 día.
  - Ricardo Salas, Confirmar la fecha 15: 2026-10-16, 1 día.
  - Felipe Arango, Entregar el punto 16: 2026-10-16, 1 día.
- **Compromisos reprogramados (5):** Javier Hoyos, Cerrar la prueba 2, 6 veces (2026-09-09 → 2026-12-03, **posterior al cierre del proyecto**); Liliana Torres, documento 1, 4 veces (2026-09-29 → 2026-11-24); Beatriz Cuéllar, anexo 3, 4 veces (2026-09-09 → 2026-11-01); María Restrepo, documento 9, 3 veces; Óscar Ramírez, anexo 11, 3 veces (2026-10-06 → 2026-11-09).
- **Sin fecha (2):** Laura Vélez, Aprobar el diseño 13 («por definir») y Mandar el ajuste del presupuesto («la otra semana»).
- **Posible duplicado:** Óscar Ramírez, «revisión con el proveedor», 2026-10-27, y su «Revisar el anexo 11». Las notas no dicen si son el mismo compromiso.
- **Cadencia:** hay seis comités semanales seguidos (2026-09-05 a 2026-10-10); las notas del 2026-10-17 dicen «próxima reunión en dos semanas».
- **Fecha ambigua:** Javier Hoyos «03/12/2026» se leyó como 3 de diciembre (día/mes/año); no hay forma de confirmarlo desde el documento.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| El proyecto está en verde | Informe 2026-10-14: «Verde» | Mismo informe: proyección 8.631.313.230 contra aprobado 6.800.000.000 (+26,9%); además 3 hitos sin evidencia, 7 compromisos vencidos, 4 entregables de proveedor vencidos, facturación por encima de lo recibido |
| Se reprogramó el despliegue | Informe 2026-10-14 | Cronograma: Despliegue en la cadena con fecha base y vigente 2026-11-30; 0 cambios aprobados |
| CT-842 está facturado por «Entregables del contrato» | FV-1842: 1.197.938.594 | Contrato (pago contra acta) y acta del 2026-08-20: recibido 775.475.640 |
| CT-565 está facturado por «Entregables del contrato» | FV-2565: 723.840.453 | Contrato (pago contra acta): ninguna acta de recibo; Licenciamiento sin recibir y Bolsa de horas con fecha 2026-10-12 |

### Sin sustento
- **Avance 49%:** no hay método ni medición; lo que el plan sostiene (60%–80%) depende de hitos sin evidencia.
- **Comprometido, ejecutado y proyección:** solo en el informe; sin libro ni método.
- **Tres hitos «cerrados»** (ver arriba).
- **«La validación con dos tiendas se extendió una semana por el conteo de inventario»:** ningún documento la menciona, y el hito «Piloto en tiendas» sigue en 2026-10-24.
- **Cuatro entregas «ya hechas»** en comité (ver arriba).
*Los tres puntos que siguen son observaciones y no entran en el conteo de 12.*
- **Estado «en curso» de tres entregables de proveedor** (Licenciamiento y Configuración en CT-842, Licenciamiento en CT-565): el contrato lo escribe, sin acta ni informe del proveedor.
- **Riesgo «Congelamiento de cambios en temporada alta»:** solo el informe lo cita; sin dueño, probabilidad ni respuesta.
- **Los dos contratos con nombres de entregables iguales** (Licenciamiento de la plataforma; Bolsa de horas de desarrollo) con proveedores distintos: nada explica si el alcance se repite o se parte.

### Lo que esta carpeta no permite saber
- **Quién autoriza una desviación:** la autoridad del gerente no está declarada. Consecuencia: no se puede decir que la proyección, un atraso o un ajuste de presupuesto estén aprobados, ni quién debe aprobarlos.
- **Qué pasó entre 2026-05-31 y 2026-09-05:** no hay minutas, ni informes, ni actas de recibo salvo una (2026-08-20). Consecuencia: no hay cómo reconstruir los tres hitos «cerrados» ni dar una tendencia; el informe del 2026-10-14 es el único.
- **Cuánto se ha pagado y cuándo:** no hay registro de cuentas por pagar. Consecuencia: el ejecutado declarado no se puede conciliar con las dos facturas radicadas, y no se sabe si el exceso sobre lo recibido en CT-842 se pagó.
- **Si el cronograma está vigente:** sin fecha de última edición ni control de cambios. Consecuencia: la «reprogramación del despliegue» no se puede ni confirmar ni descartar.
- **Qué son los «Componente 1, 2 y 3» y qué cubre «otro proyecto»:** el alcance no tiene contenido. Consecuencia: no hay contra qué medir un entregable como terminado.
- **Si la ausencia del patrocinador desde el 2026-10-03 es del proyecto o de las minutas:** las notas del 2026-10-17 no traen cabecera de comité. Consecuencia: no se sabe si las decisiones de presupuesto se están tomando donde el acta dice.
- **De qué proveedor es el riesgo de equipo incompleto**, y si se relaciona con alguno de los entregables vencidos.

---
**Pie de rigor.** Cifras derivadas copiadas de `portafolio.py compute` (corrida del 2026-10-17); las fechas y montos del registro los verifiqué contra los documentos originales. Ninguna suma o diferencia fue calculada a mano. Lo declarado y lo probado van separados: del informe, el acta y el cronograma solo cuento como «sostenido» lo que otro documento independiente respalda. Es un borrador de trabajo, no una decisión ni asesoría: cada cita apunta al documento original, y la verificación es suya. No recomiendo detener, continuar ni reestructurar; eso lo decide quien tiene la facultad, y hoy el acta no dice quién es.

**Siguiente paso posible:** llevar las 4 contradicciones al gerente como preguntas, una por una, o preparar el punto de comité con la lista de lo que falta.
