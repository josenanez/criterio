Sale de: las 13 fichas (`estado/records/PRY-199` a `PRY-211`), los informes de avance, las 12 actas de constitución (sección de dependencias declaradas) y las minutas de reunión del portafolio (PRY-199, 201, 202, 203, 204, 206, 207, 208, 209 y 211, incluida la nota del 2026-10-17). De las seis minutas de comité de PRY-211 solo leí entera la del 2026-10-10; en las otras cinco busqué «riesgo» y «proveedor» y no apareció nada. PRY-200, 205 y 210 no tienen minutas en la carpeta. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## RAID — portafolio al 2026-10-17
13 riesgos · 0 supuestos · 5 incidencias · 1 dependencia
19 sin doliente · 19 sin movimiento registrado · 1 no registrado formalmente

Los 19 ítems de la ficha llegan sin probabilidad, impacto, doliente, fecha ni último movimiento. En ningún documento hay un campo de esos. No relleno ninguno. Cuando uso «alta, media, baja» es la escala por defecto, porque la organización no definió una, y la uso solo para ordenar.

Reclasificaciones:
- **PRY-203** «El proveedor no ha confirmado la fecha de la última entrega» estaba como riesgo. Pasa a **dependencia**: depende de un tercero fuera del proyecto. Sigue sin código de proyecto, porque la contraparte es un proveedor y no otro PRY.
- **PRY-204** y **PRY-211** «Congelamiento de cambios en temporada alta» estaba como riesgo. Ya ocurrió: ambos informes dicen que el despliegue se reprogramó por ese congelamiento. Ese hecho ya está registrado como incidencia en cada proyecto, así que el riesgo queda **duplicado y se pliega a la incidencia**.
- PRY-206 también tiene el riesgo «Congelamiento de cambios en temporada alta», pero su informe no dice que se haya materializado. Lo dejo como riesgo.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-203 / D1 | Dependencia | Proveedor sin confirmar la fecha de la última entrega (informe 2026-10-16) | no consta | no consta | Su doliente está fuera del proyecto y no ha confirmado. Es una dependencia declarada, no acordada. |
| PRY-211 / R-NR1 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | no consta | 2026-10-17 | Sale de una reunión con 14 asistentes. La nota dice que nadie lo anotó. Hay que decidir si se formaliza y quién lo lleva. |

Los demás criterios de escalamiento no se pueden evaluar. «Más de dos períodos sin movimiento» necesita un último movimiento que ninguna ficha tiene. Por eso no subo ningún otro ítem.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-211) | Riesgo | `PRY-211-pronóstico-de-demanda/2026-10-17-notas-reunion.txt` | 2026-10-17 |

Es el único. Las minutas de las otras reuniones de comité solo contienen compromisos, y los compromisos van a otra revisión.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| PRY-199 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | doliente, fecha, prob., impacto |
| PRY-199 | Riesgo | Concentración del conocimiento en una sola persona | doliente, fecha, prob., impacto |
| PRY-200 | Riesgo | Concentración del conocimiento en una sola persona | ídem |
| PRY-201 | Riesgo | Concentración del conocimiento en una sola persona | ídem |
| PRY-202 | Riesgo | Concentración del conocimiento en una sola persona | ídem |
| PRY-202 | Incidencia | Dos semanas perdidas por la rotación de un desarrollador clave | doliente, fecha de resolución |
| PRY-203 | Dependencia | Última entrega del proveedor | contraparte confirmada, fecha, doliente |
| PRY-204 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | doliente, fecha de la repetición |
| PRY-204 | Incidencia | Despliegue reprogramado por el congelamiento (sin cronograma nuevo en la carpeta) | doliente, nueva fecha |
| PRY-205 | Riesgo | Concentración del conocimiento en una sola persona | doliente, fecha, prob., impacto |
| PRY-206 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | ídem |
| PRY-206 | Riesgo | Congelamiento de cambios en temporada alta | ídem |
| PRY-207 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | ídem |
| PRY-208 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | ídem |
| PRY-209 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | ídem |
| PRY-210 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | ídem |
| PRY-211 | Incidencia | Despliegue reprogramado por el congelamiento (el cronograma de la carpeta sigue en v1, con el despliegue al 2026-11-30) | doliente, nueva fecha |
| PRY-211 | Incidencia | La validación con dos tiendas se extendió una semana por el conteo de inventario | doliente, cierre |
| PRY-211 | Riesgo (no reg.) | Proveedor sin el equipo completo | doliente, fecha, prob., impacto |

Observación sobre el contenido, sin sacar conclusión: tres frases se repiten casi literales en proyectos distintos. «Concentración del conocimiento…» aparece en 5 proyectos, «jefes de tienda» en 4 y «regulación de datos personales» en 2. Un riesgo igual en proyectos distintos puede ser real o puede ser texto de plantilla. Eso lo confirma cada gerente.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-203 / D1 | Proveedor (sin código de proyecto) | No | Sin fecha confirmada para la última entrega |

Las 12 actas de constitución dicen «Ninguna declarada» en dependencias, y ninguna ficha registra una dependencia entre proyectos. **El cruce entre proyectos no se pudo hacer: no hay con qué cruzar.** Eso no prueba que no existan. Pasa lo mismo con los 4 riesgos de «congelamiento de temporada alta» y los 4 de «jefes de tienda para el piloto», que apuntan a recursos o calendarios compartidos entre proyectos. Nadie los registró como dependencia, y no los reclasifico sin que alguien lo diga.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| (ver tabla «Sin doliente o sin fecha»: son los mismos 19 ítems) | | | no consta | no consta | no consta | no consta | no consta |

Los 19 ítems tienen el mismo vacío en estas cinco columnas. Repetirlos aquí con guiones no añade información.

## Fuera del RAID, para otra revisión
- PRY-211: el informe del 2026-10-14 dice verde con una proyección al cierre de 8.631.313.230 COP contra 6.800.000.000 aprobados. Eso lo cubre `budget-tracking` y `status-report`.
- PRY-211: en la nota del 2026-10-17, Javier Hoyos mueve «cerrar la prueba 2» del 2026-11-19 al 2026-12-03. El cronograma v1 termina el 2026-11-30. Es un compromiso que se movió, no un riesgo que alguien haya dicho. Lo recoge `commitment-tracking`.
- PRY-203: la minuta del 2026-10-14 lista un compromiso de Andrés Lozano con fecha 2026-10-04, anterior a la propia reunión. Es un tema de compromisos.

## Después
Dos propuestas, para que usted decida:
1. Subir a comité PRY-203/D1 (proveedor sin confirmar) y PRY-211 (proveedor sin equipo completo). En el segundo, la decisión es si se formaliza y quién la lleva.
2. Pedir a cada gerente un doliente y una fecha para los 19 ítems. No propongo nombres: no hay ningún documento que diga quién debería llevar cada uno.

## Lo que esta corrida no sabe
- Quién es el doliente de cualquier ítem.
- Cuánto tiempo lleva cada ítem abierto o cuándo se movió por última vez.
- Si los riesgos repetidos entre proyectos son reales.
- Si PRY-200, 205 y 210 tienen riesgos dichos en reuniones: no hay minutas de ellos en la carpeta.
