# Corrida del 2026-10-17 · product-view

13 proyectos · 22 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Producto con un solo proyecto (PRY-200), sin alertas calculadas; declarado en rojo sin causa visible y sin datos con evidencia. Seis proyectos sin producto declarado. No se leyeron documentos fuente; el área dueña no sale del cálculo.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de las fichas del portafolio «Portafolio retail», calculadas al 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17 — «venta en línea»

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| venta en línea | 1 (PRY-200) | 0 | 2027-05-03 | COP 4.200.000.000 | COP 3.347.036.665 |

**«Venta en línea» tiene un solo proyecto (PRY-200, Tienda en línea).** La vista por producto no aporta nada aquí, así que no armo sección de producto: lo que sigue es lo que el cálculo da para ese proyecto.

- **Señales abiertas:** ninguna. Sin atraso contra la línea base original ni la vigente (0 días), sin replanificaciones, sin compromisos vencidos, sin conflictos entre documentos. Último movimiento hace 3 días.
- **Dinero:** aprobado 4.200.000.000; comprometido 3.347.036.665 (79,7 %); ejecutado 2.214.748.739 (52,7 %); proyección **4.185.311.326** (−0,3 % sobre lo aprobado). Disponible real: 852.963.335. Trae las cuatro cifras, así que la suma está completa. Todo en COP.
- **Fecha comprometida del producto:** 2027-05-03, que sale de PRY-200 (único proyecto).
- **Dependencias internas:** no hay; con un solo proyecto no puede haberlas. La ficha tampoco declara dependencias con otros productos.

**Lo que sí hay que mirar, aunque no sea una alerta calculada:**
1. **El gerente declara el proyecto en rojo** (informe del 2026-10-14, avance declarado 39 %), y el cálculo no encuentra ninguna señal que lo explique (`unaccounted_signals` vacío). Ahí hay una diferencia entre lo declarado y lo medido, pero el rojo no tiene causa visible en los documentos leídos: pregúntale al gerente de PRY-200 qué lo motiva.
2. **Ninguno de los datos de la ficha tiene fuente de evidencia:** 0 con evidencia, 3 de declaración y 12 sin marcar. Que no haya alertas significa que no hay nada contra qué contradecir lo declarado, no que lo declarado esté sustentado.
3. **Faltan en la ficha** `identity.authority` (quién aprueba) y `identity.phase`.

### Proyectos sin producto declarado

Seis proyectos del portafolio no declaran producto, y nadie puede responder por el conjunto al que sirven: PRY-202 Centro de distribución norte, PRY-203 Reposición automática, PRY-206 Precios dinámicos, PRY-209 Migración del ERP, PRY-210 Etiquetas electrónicas de precio y PRY-211 Pronóstico de demanda. El cálculo no da el área dueña, así que no la escribo. Es un hallazgo de gobierno, y alguno podría pertenecer a «venta en línea» (por ejemplo Precios dinámicos o Pronóstico de demanda), pero eso no lo sustenta ningún documento y no lo asumo.

Además, PRY-199 (Iluminación LED en bodegas) declara «PRD-299», un código y no un producto con nombre. Conviene confirmar si es un producto real.

**Pie de rigor:** cifras copiadas de `portafolio.py compute` (2026-10-17). No leí documentos por mi cuenta; todo lo anterior sale de las fichas. Lo que se habló fuera de los documentos no lo sé.
