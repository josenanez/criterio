Soy Vera, el agente PMO de Criterio. Proceso la documentación que ya tienes y digo qué no se sostiene.

**Miré:** `documentos/proyectos`: 13 carpetas de proyecto (PRY-199 a PRY-211) y 80 documentos. Formatos: .md 39, .docx 15, .pdf 10, .xlsx 8, .csv 6, .json 1, .txt 1. Todos legibles. Documento más reciente: 2026-10-17.

## Listo — Portafolio retail

**Miré:** 80 documentos en 13 proyectos · formatos: .md, .docx, .pdf, .xlsx, .csv, .json, .txt · más reciente: 2026-10-17
**Eres:** PMO del portafolio (hay varios proyectos; era la respuesta sugerida)
**Te aviso:** cada semana, dos días antes del comité. Las carpetas traen actas de «comité semanal», así que tomé semanal; no tengo la fecha del próximo comité, y cuando la tengas la pongo.
**En:** página (HTML). La respuesta sugerida era presentación, pero el único formato que la configuración reconoce hoy es página; si quieres presentación o PDF, dímelo y lo cambio.
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) por José Francisco Ñáñez, 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 6d4b67767ea3a1ea…

Preguntas que hice: ninguna. La sesión era sin interfaz; cada respuesta fue la sugerida y las dije arriba.

La configuración quedó en `.criterio/portafolio/config.json` y verificada sin problemas. Lo que Vera va encontrando va en `estado/` y los informes irán en `reportes/`, junto a la carpeta de documentos y no dentro de `.criterio/`. Costo por corrida: proyectos de a diez, uno tras otro, hasta 400 documentos, sin releer lo que no cambió.

### Probé con tres proyectos

Los de documentación más reciente: PRY-202, PRY-204 y PRY-211 (los tres con documentos del 2026-10-17). Leí 30 documentos y dejé las tres fichas en `estado/records/`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Centro de distribución norte | 4 | Patrocinadora Liliana Torres y gerente Diana Molina (acta 2025-11-10). Cierre comprometido 2026-12-04. Presupuesto aprobado 1.200.000.000 COP. El informe del 2026-10-17 declara **rojo, 26%**, con proyección de 1.514.819.185 COP. Un compromiso abierto: Javier Hoyos, «Entregar el punto 18», 2026-11-01 (comité 2026-10-07). | Producto (el acta dice «No aplica»), facultad del gerente, fase. Ningún acta de recibo. |
| PRY-204 Cajas de autopago | 6 | Patrocinador Carlos Peña y gerente Rubén Cárdenas. Producto «autopago en tienda». Cierre comprometido 2026-08-26. Aprobado 4.200.000.000 COP; proyección 4.652.440.352 COP. El informe del 2026-10-09 declara **verde, 58%**. Hay actas de recibo del diseño (2026-10-06) y del ambiente de pruebas (2026-10-15). | Facultad del gerente, fase, cronograma nuevo (el informe dice que se reprogramó el despliegue y solo existe la v1). Acta de recibo de la integración con el ERP y del piloto. |
| PRY-211 Pronóstico de demanda | 20 | Patrocinador Jorge Medina y gerente Andrés Lozano. Cierre comprometido 2026-11-30. Aprobado 6.800.000.000 COP; proyección 8.631.313.230 COP. El informe del 2026-10-14 declara **verde, 49%**. Dos contratos de proveedor (CT-842, CT-565), seis comités, notas del 2026-10-17 y una ficha publicada por el gerente (`ficha-pm.json`), que quedó aparte, entera, en `pm_record`. | Producto («No aplica»), facultad del gerente, fase, dueño del riesgo del proveedor, actas de recibo de tres hitos. |

#### Lo que `compute` levantó (37 señales en los tres)

**PRY-202** (rojo declarado)
- `progress_vs_plan`: declara 26%; el cronograma sustenta entre 67% y 100% (2 de 3 hitos cumplidos). Diferencia de 41 puntos.
- `milestone_met_without_evidence`: «Diseño de la experiencia aprobado» (2026-03-26) y «Ambiente de pruebas certificado» (2026-07-31) figuran cerrados y no hay acta que lo pruebe.
- `variance_cost`: la proyección supera lo aprobado en 26,2%. Gastado: 62,7% del presupuesto; comprometido: 76,0%.

**PRY-204** (verde declarado, contradicho)
- `declared_vs_evidence`: el gerente declara verde y el cálculo levanta contra eso cuatro señales: `commitment_overdue`, `milestone_met_without_evidence`, `progress_vs_plan` y `variance_cost`.
- `progress_vs_plan`: declara 58%; los 4 hitos del cronograma figuran cumplidos (diferencia de 42 puntos). El plan v1 cerraba el 2026-08-26, 52 días antes del corte.
- `milestone_met_without_evidence`: «Integración con el ERP» (2026-05-12, 158 días) y «Piloto en tiendas» (2026-08-26, 52 días).
- `variance_cost`: proyección 10,8% sobre lo aprobado.
- `commitment_overdue`: Felipe Arango, «Entregar el punto 10», venció el 2026-10-13 (4 días).
- `commitment_undated`: Paula Céspedes, «Entregar el punto 19», sin fecha.

**PRY-211** (verde declarado, contradicho)
- `declared_vs_evidence`: verde frente a ocho señales (las de abajo).
- `progress_vs_plan`: declara 49%; el plan sustenta entre 60% y 80% (3 de 5 hitos). Diferencia de 11 puntos.
- `milestone_met_without_evidence`: los tres hitos cerrados (diseño, ambiente de pruebas, integración con el ERP) sin acta.
- `variance_cost`: proyección 26,9% sobre lo aprobado.
- `commitment_overdue`: siete vencidos sin evidencia, entre ellos Paula Céspedes «Confirmar la fecha 7» (21 días), Rubén Cárdenas «Cerrar la prueba 10» y Óscar Ramírez «Validar el ambiente 20» (7 días cada uno).
- `commitment_rescheduled`: cinco compromisos reprogramados tres veces o más. El de Javier Hoyos, «Cerrar la prueba 2», lleva seis: del 2026-09-09 al 2026-12-03.
- `commitment_undated`: Laura Vélez, «Aprobar el diseño 13» y «Mandar el ajuste del presupuesto».
- `vendor_deliverable_late`: CT-842 «Licenciamiento de la plataforma» (99 días) y «Configuración del catálogo» (18 días); CT-565 «Licenciamiento de la plataforma» (72 días) y «Bolsa de horas de desarrollo» (5 días).
- `vendor_invoiced_over_accepted`: Datos y Demanda (CT-842) facturó 1.197.938.594 COP y solo hay recibido un entregable de 775.475.640 COP; diferencia de 422.462.954 COP.
- `vendor_invoiced_without_delivery`: Tecnología para Tiendas (CT-565) facturó 723.840.453 COP (2026-09-16) y ningún entregable del contrato está recibido.

Sin facultad del gerente declarada en ninguno de los tres (`no_authority`: 3). En PRY-204 los campos tomados del acta de 2025-06 llevan 16 meses sin confirmación posterior.

### El portafolio completo

Faltan 10 proyectos y 50 documentos (PRY-199 a PRY-201, PRY-203, PRY-205 a PRY-210), en un lote, uno tras otro. Las tres fichas de esta prueba tomaron unos 171 segundos de corrida medidos por el script, sin contar la configuración y la lectura de la conversación; no es un tiempo extrapolable, porque PRY-211 (20 documentos) fue casi dos tercios de lo leído y los pendientes traen de 2 a 7 documentos cada uno.

### Lo que le falta a tu carpeta

Ninguno de estos hallazgos bloquea nada:
- Los nombres de archivo ya traen fecha (`AAAA-MM-DD-tema.ext`) y eso se aprovechó completo.
- Ningún proyecto declara qué puede decidir el gerente sin subir a comité, y el control de cambios depende de ese dato.
- Los hitos de los cronogramas figuran «cerrado» sin acta de recibo en 202, 204 (dos de cuatro) y 211. Un acta por hito dejaría cada cierre con prueba.
- En 204 y 211 los informes dicen que el despliegue se reprogramó y la carpeta solo tiene el cronograma v1. Un cronograma v2 dejaría la nueva fecha en una línea base.
- Los alcances son «Componente 1, 2 y 3» sin nombre, y las exclusiones dicen «lo que otro proyecto cubre»; no se puede comprobar contra nada.
- Dependencias entre proyectos: «Ninguna declarada» en las tres actas leídas.
- Las notas del 2026-10-17 de PRY-211 mencionan un riesgo del proveedor que nadie anotó; quedó en la ficha sin dueño.

## Qué sigue

¿Corro el portafolio completo? Como eres PMO, cuando tengas gerentes de proyecto con su propio equipo puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios; hoy no lo hice.
