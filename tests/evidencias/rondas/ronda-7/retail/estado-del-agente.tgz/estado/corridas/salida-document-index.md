## Carpeta al 2026-10-17

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 171 campos de la ficha de **PRY-211** (pronóstico de demanda) cuya fuente no resuelve, sobre 14 documentos citados:

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-211 | identidad (7), plan: inicio, alcance, exclusiones | 00-gobierno/2026-05-21-acta-constitucion.docx |
| PRY-211 | fin, 5 hitos × 4 campos | 10-plan/2026-05-21-cronograma-v1.xlsx |
| PRY-211 | estado declarado, avance, fecha, comprometido, ejecutado, proyección, riesgo 0, incidencias 0 y 1 | 20-seguimiento/2026-10-14-informe-avance.md |
| PRY-211 | proveedor CT-842 (nombre, referencia, 4 entregables) | 00-gobierno/2026-05-21-contrato-ct-842.md |
| PRY-211 | proveedor CT-565 (nombre, referencia, 2 entregables) | 00-gobierno/2026-05-25-contrato-ct-565.md |
| PRY-211 | facturado CT-842 | 20-seguimiento/2026-10-02-factura-ct-842.md |
| PRY-211 | facturado CT-565 | 20-seguimiento/2026-09-16-factura-ct-565.pdf |
| PRY-211 | riesgo 1, compromisos 24-25 | 2026-10-17-notas-reunion.txt |
| PRY-211 | compromisos 0-23 | 30-reuniones/2026-09-05 … 2026-10-10-comite-semanal.md (6 actas) |

Esto no es un borrado: los 14 archivos **existen** en `documentos/proyectos/PRY-211-pronóstico-de-demanda/`, y el nombre de la carpeta coincide con el de la ficha (ambos en NFC). El índice, además, no reporta ningún documento borrado ni renombrado. La causa no la sé; no la investigué más allá de esa comprobación. Las otras 12 fichas no tienen citas rotas.

### Formatos que no se pudieron leer
Ninguno reportado.

### Qué sigue
Hay cero documentos por releer y `projects_to_recompute` está vacío, así que no ofrezco un `/portfolio-scan`. Las citas de PRY-211 conviene revisarlas antes de confiar en esa ficha, pero no hay nada que releer.
