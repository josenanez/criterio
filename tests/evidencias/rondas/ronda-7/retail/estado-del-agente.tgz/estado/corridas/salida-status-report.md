Informe generado desde la ficha `estado/records/PRY-203.json` (actualizada 2026-10-17) y el cálculo de `portafolio.py compute` con corte 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## PRY-203 · Reposición automática — estado al 2026-10-17

**Declara el gerente (Gustavo Neira):** Rojo · 26 % · al 2026-10-16 (antigüedad de la declaración: 1 día)
**Sustento documental:** sustentado en lo esencial: el rojo coincide con el atraso que muestran los documentos. Pero el 26 % no cuadra con el plan (ver abajo) y toda la parte financiera es solo declaración.
**Lo que el semáforo no explica:** `commitment_overdue`, `milestone_overdue`, `progress_vs_plan` (así las lista el script en `declared.unaccounted_signals`).
**Último documento:** 2026-10-16 (días en silencio: 1) · **Última reunión:** 2026-10-14 (Comité de Arquitectura; asistentes: Gustavo Neira, Liliana Torres)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-11-28 | 2026-11-28 | 0 días contra la original y contra la vigente |
| Presupuesto aprobado | COP 3.300.000.000 | COP 3.300.000.000 | Proyección declarada COP 3.114.019.216: −5,6 % sobre lo aprobado |

Replanificaciones registradas: 0. El informe del 2026-10-16 dice «se reprogramó el despliegue por el congelamiento de temporada de fin de año», pero no hay una segunda línea base ni una solicitud de cambio, y las fechas de los hitos no cambiaron (ver «Dónde no coincide»).

Dinero (declarado, no verificado con ningún documento de evidencia): comprometido COP 2.518.562.063 (76,3 %), ejecutado COP 1.891.245.411 (57,3 %), disponible real COP 781.437.937.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-06-15 | 2026-06-15 | cumplido | Acta de recibo fechada 2026-10-09 |
| Ambiente de pruebas certificado | 2026-08-09 | 2026-08-09 | cumplido | Acta de recibo fechada 2026-10-16 |
| Integración con el ERP | 2026-10-04 | 2026-10-04 | **vencido 13 días**, sin evidencia | — |
| Piloto en tiendas | 2026-11-28 | 2026-11-28 | pendiente | — |

### Dónde no coincide
- **Avance contra plan:** el gerente declara 26 %; con 2 de 4 hitos cumplidos, el plan sostiene entre 50 % y 75 % (brecha de 24 puntos, el avance declarado está por debajo). Fuentes: informe de avance 2026-10-16 y cronograma v1 del 2026-04-11.
- **«Se reprogramó el despliegue»** (informe, 2026-10-16) contra un cronograma sin cambios: ninguna fecha de hito se movió y no hay línea base nueva. O la reprogramación no se formalizó, o el informe habla de algo que el plan no recoge. No lo puedo resolver con los documentos.
- **Actas de recibo tardías:** los dos hitos cumplidos tienen acta fechada el 2026-10-09 y el 2026-10-16, mucho después de sus fechas de línea base (2026-06-15 y 2026-08-09). Los documentos no dicen si el cumplimiento fue en la fecha y el acta llegó tarde, o si el hito se cumplió tarde.
- El rojo declarado sí es coherente con el atraso del hito del ERP; las tres señales de arriba son las que el semáforo, tal como está escrito, no explica.

### Abierto
**Riesgos e incidencias sin movimiento:** un riesgo, «El proveedor no ha confirmado la fecha de la última entrega» (informe 2026-10-16). Sin responsable, probabilidad, impacto, fecha ni último movimiento. No hay incidencias registradas.
**Compromisos vencidos:** Andrés Lozano, «Entregar el punto 27», prometido para el 2026-10-04, vencido hace 13 días. Se dijo en el comité del 2026-10-14, es decir, con una fecha ya pasada, y Andrés Lozano no figura entre los asistentes. No hay evidencia de entrega.
**Dependencias sin confirmar:** ninguna registrada. Sí consta que el proveedor no ha confirmado la última entrega, pero no hay proveedor ni contrato en la ficha.

### Sin dato
- `identity.product`: el acta dice «No aplica».
- `identity.authority`: no consta quién aprueba cambios y escalamientos; sin él no se puede juzgar si los riesgos exceden la autoridad del gerente.
- `identity.phase`: no consta.
- Proveedores: la ficha no tiene ninguno, aunque el informe habla de «la última entrega» de un proveedor.
- Alcance: el acta menciona «tres componentes sin nombre»; no se puede contrastar entregables contra componentes.
- Todas las cifras de dinero vienen de una sola fuente declarativa (el informe); no hay facturas ni actas que las respalden.

### Después
El hito del ERP vencido, el compromiso sin evidencia y la reprogramación sin línea base nueva justifican preparar el punto de comité. Si la reprogramación por el congelamiento de fin de año es real, procede una solicitud de cambio. Dime cuál de las dos prefieres.

---
Pie: criterio-portfolio 0.3.13 · ficha PRY-203 actualizada el 2026-10-17, sobre 6 documentos (el más reciente, 2026-10-16) · campos inciertos: producto, autoridad, fase · términos v1.1 (aceptados el 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
