**Sale de:** `estado/records/PRY-211.json` y de la salida de `portafolio.py compute` al 2026-10-17; contratos CT-842 y CT-565 (`00-gobierno`), factura FV-1842 y FV-2565, acta de recibo de la bolsa de horas de CT-842, informe de avance del 2026-10-14, las seis minutas del comité semanal (2026-09-05 a 2026-10-10) y las notas del 2026-10-17. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Proveedores — PRY-211 Pronóstico de demanda al 2026-10-17

El proyecto declara **verde** al 2026-10-14 (`20-seguimiento/2026-10-14-informe-avance.md`). En proveedores, los documentos no lo sostienen: hay cuatro entregables vencidos sin acta y los dos proveedores tienen facturado más de lo que hay aceptado.

### Datos y Demanda S.A.S. — contrato CT-842
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae la tabla de entregables y la condición de pago; `00-gobierno/2026-05-21-contrato-ct-842.md`)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-07-10 · 775.475.640 | `pending`, vencido hace 99 días | ninguna | sin desglose |
| Bolsa de horas de desarrollo | 2026-08-19 · 775.475.640 | `accepted` | acta de recibo del 2026-08-20, firmada por Andrés Lozano (`20-seguimiento/2026-08-20-acta-recibo-ct-842-bolsa-de-horas-de-desarrollo.pdf`) | sin desglose |
| Configuración del catálogo | 2026-09-29 · 775.475.640 | `pending`, vencido hace 18 días | ninguna | sin desglose |
| Soporte del primer trimestre | 2026-11-08 · 775.475.640 | `pending`, aún no vence | ninguna | sin desglose |

Facturado: **1.197.938.594** COP (FV-1842, 2026-10-02, «Entregables del contrato CT-842», radicada en cuentas por pagar). Aceptado con acta: **775.475.640** COP. Diferencia: **422.462.954** COP facturados sin entregable aceptado que los respalde.

### Tecnología para Tiendas Ltda. — contrato CT-565
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (`00-gobierno/2026-05-25-contrato-ct-565.md`, mismo formato)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma | 2026-08-06 · 723.840.453 | `pending`, vencido hace 72 días | ninguna | sin desglose |
| Bolsa de horas de desarrollo | 2026-10-12 · 723.840.453 | `pending`, vencido hace 5 días | ninguna | sin desglose |

Facturado: **723.840.453** COP (FV-2565, 2026-09-16, «Entregables del contrato CT-565», radicada en cuentas por pagar). Entregables aceptados: **0** de 2. El script levanta `vendor_invoiced_without_delivery`.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-842: monto facturado | «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto» | Un acta (bolsa de horas, 775.475.640) y una factura por 1.197.938.594; sobran 422.462.954 sin acta | contrato CT-842; acta 2026-08-20; FV-1842 |
| CT-565: factura sin entrega | Misma condición de pago | Cero actas; factura por 723.840.453, el monto exacto de un entregable, emitida el 2026-09-16, antes de que venciera la bolsa de horas (2026-10-12) | contrato CT-565; FV-2565 |
| Estado en el contrato vs. la fecha | Licenciamiento CT-842 figura «en curso» y Configuración del catálogo «en curso» | Ambos pasaron su fecha comprometida (99 y 18 días) sin acta; Licenciamiento CT-565 también «en curso», vencido 72 días | contratos; compute |
| Estado del proyecto | Informe del 2026-10-14: verde, 49 %, sin mención de proveedores | Cuatro entregables vencidos sin evidencia y dos facturas por encima de lo aceptado | informe de avance; compute |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-842 · Licenciamiento de la plataforma | `pending` (contrato: «en curso») | 2026-07-10 (99 días) |
| CT-842 · Configuración del catálogo | `pending` (contrato: «en curso») | 2026-09-29 (18 días) |
| CT-565 · Licenciamiento de la plataforma | `pending` (contrato: «en curso») | 2026-08-06 (72 días) |
| CT-565 · Bolsa de horas de desarrollo | `pending` | 2026-10-12 (5 días) |

Entregables declarados aceptados sin documento que lo pruebe (`accepted_without_evidence`): ninguno en los dos contratos. El único aceptado tiene acta.

### Compromisos del proveedor vencidos
Ninguno. Ninguna de las seis minutas del comité semanal ni las notas del 2026-10-17 nombran a Datos y Demanda ni a Tecnología para Tiendas, y no hay compromiso con fecha pasada atribuido a un proveedor. Lo más cercano:
- Óscar Ramírez, «Revisión con el proveedor», para el 2026-10-27 (notas del 2026-10-17); no vence todavía, y la ficha deja dicho que no se sabe si es el mismo compromiso que «Revisar el anexo 11».
- Las notas del 2026-10-17 recogen que «el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo». No dicen cuál proveedor y no hay dueño. Está en la ficha como riesgo sin registrar.

### Sin dato
- **Vigencia, terminación, renovación automática y preaviso** de CT-842 y CT-565: los contratos de la carpeta no traen esos campos. No puedo decir si hay un preaviso por vencer; hay que pedir el contrato completo, no solo la tabla de entregables.
- **Desglose de las facturas:** FV-1842 y FV-2565 dicen «Entregables del contrato», sin decir cuáles. La diferencia de 422.462.954 COP sale de comparar el total facturado con lo aceptado con acta, no de una línea de la factura.
- **Estado de pago:** ambas figuran «radicada en cuentas por pagar»; no hay documento que diga si ya se pagaron.
- **Otros documentos de aceptación** (correos, minutas): busqué mención de los proveedores en las minutas y no hay ninguna.
- **Cronograma:** `10-plan` sigue en v1, sin reflejar la reprogramación que dice el informe.

## Después

Las dos facturas están radicadas contra entregables sin acta. Antes de que se paguen, propongo llevarlo a comité: (1) detener o aclarar FV-2565 por 723.840.453 COP; (2) pedir a Datos y Demanda el desglose de FV-1842 y justificar o devolver 422.462.954 COP; (3) pedir los contratos completos para revisar vigencia y preaviso. ¿Lo preparo con `/criterio-portfolio:steering-pack PRY-211`?

*Pie de rigor: las cifras de días, diferencias y señales se copian de `portafolio.py compute` al 2026-10-17; los montos de contrato y factura, de los documentos citados. Cada afirmación se apoya en el documento nombrado; lo que no está en la carpeta aparece en «Sin dato». Es un borrador de trabajo: la verificación contra los originales es suya.*
