# Corrida del 2026-10-17 · steering-pack

13 proyectos · 87 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Paquete de 7 decisiones, 6 escalamientos, 13 fichas. Dijo que no sabe: quién aprueba (autoridad sin ficha en los 13), qué decidió el comité anterior (no hay registro), qué recorta el alcance menor, y las causas del rojo de PRY-200.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Criterio · steering-pack** — cargué las 13 fichas (PRY-199 a PRY-211) con estado al 2026-10-17, y las cifras salen de `portafolio.py compute` con fecha de corte 2026-10-17. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-17).

# Comité de proyectos — 2026-10-17
7 decisiones · 6 escalamientos sin decisión · 10 de 13 proyectos con hallazgos (61 señales; 5 proyectos en verde contradichos por su propia evidencia)

## Decisiones del comité anterior
No hay registro de un comité anterior en la carpeta de estado ni en las fichas (ningún acta ni decisión registrada). No puedo decir qué se decidió antes ni qué quedó abierto. Esto también es un hallazgo: el comité de hoy decide sin ciclo previo. La única mención es una propuesta de llevar a comité las facturas de PRY-211 (corrida vendor-tracking de hoy), que se recoge en la decisión 4.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base, sobrecostos y pagos extraordinarios en el portafolio?
**Proyecto:** los 13 · **Quién decide:** el propio comité (sin esto no se puede verificar quién decide en los demás puntos) · **Si no se decide hoy:** las decisiones 2 a 7 se toman sin que conste que quien las toma tiene la facultad, y los cambios ya movidos (PRY-205, PRY-209) siguen sin aprobador identificable.
La ficha no encontró `identity.authority` en ninguno de los 13 proyectos (`no_authority`: 13). PRY-201 muestra un cambio "aprobado por el comité (sin nombrarlo)".
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar hoy el aprobador por proyecto (y umbral) y dejarlo en el acta | ninguno | ninguno | ninguno |
| B. Aplazar y que cada gerente declare su autoridad por escrito antes del próximo comité | ninguno | decisiones 2-7 se retrasan hasta entonces | ninguno directo |
**Recomendación:** A. Sin esto el resto del paquete no es ejecutable.

### [2] PRY-205 Pago con QR en caja — ¿se aprueba CC-01 (ampliación de alcance, +75 días, +150.000.000 COP)?
**Proyecto:** PRY-205 · **Quién decide:** no consta (ver decisión 1) · **Si no se decide hoy:** la línea base v2 (fin 2027-05-05) ya fue movida el 2026-10-14 sin autorización: 75 días de variación contra la original (17.9%), 0 autorizados. Seguiría rigiendo un plan que nadie aprobó.
Contexto: aprobado 3.300.000.000 COP; comprometido 95.5%; disponible real 147.684.786 COP, menos que los 150.000.000 solicitados. El proyecto se declara en verde (2026-10-14).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y formalizar v2 | ampliado | fin 2027-05-05 (+75 días) | +150.000.000 COP, sin disponibilidad real para cubrirlo |
| B. Rechazar y volver a la línea base v1 | el original | fin 2027-02-19 | sin adicional; el atraso real queda visible |
| C. Aprobar con alcance recortado | parcial (qué recortar no está en los documentos) | entre ambos | por definir; el documento no lo da |
**Recomendación:** C o B, no A: aprobar A hoy comprometería 150.000.000 COP que superan lo disponible, sobre un proyecto en verde sin sustento (hito "Ambiente de pruebas certificado" cumplido sin evidencia). Condicionar cualquier aprobación a una fuente de fondos nombrada.

### [3] PRY-209 Migración del ERP — ¿se aprueba CC-01 (ampliación de alcance, +55 días, +110.000.000 COP)?
**Proyecto:** PRY-209 · **Quién decide:** no consta · **Si no se decide hoy:** igual que PRY-205: la línea base ya se movió 55 días (24.3% contra la original) con 0 autorizados.
Contexto: comprometido 55.9%, disponible real 1.456.419.932 COP, proyección 7.7% por debajo de lo aprobado; progreso declarado 55% contra 67-100% que sustenta el plan; dos hitos cumplidos sin evidencia.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y formalizar la línea base nueva | ampliado | +55 días | +110.000.000 COP (cubierto por el disponible) |
| B. Rechazar y volver a la original | el original | sin los 55 días | sin adicional |
**Recomendación:** A condicionada a que el gerente aporte la evidencia de los dos hitos marcados cumplidos (Diseño aprobado, Ambiente de pruebas), porque hay fondos pero no hay respaldo del avance. Si no la aporta en un período, volver a B.

### [4] PRY-211 Pronóstico de demanda — ¿se detienen los pagos a los dos proveedores hasta aclarar lo facturado?
**Proyecto:** PRY-211 · **Quién decide:** no consta · **Si no se decide hoy:** las facturas siguen radicadas y pueden pagarse. Hay 723.840.453 COP facturados por Tecnología para Tiendas (CT-565) sin ningún entregable aceptado, y 1.197.938.594 COP facturados por Datos y Demanda (CT-842) contra 775.475.640 COP aceptados: 422.462.954 COP de diferencia.
Contexto: entregables atrasados y pendientes — licenciamiento de la plataforma (99 días de atraso con Datos y Demanda; 72 con Tecnología para Tiendas), configuración del catálogo (18 días), bolsa de horas (5 días).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Detener ambas facturas y exigir actas y desglose | sin cambio | puede tensar a los proveedores | retiene 723.840.453 + 422.462.954 COP |
| B. Pagar lo aceptado y retener solo la diferencia | sin cambio | menor fricción | retiene 422.462.954 COP; paga 723.840.453 sin entrega |
| C. Pagar todo | sin cambio | ninguno | desembolsa lo facturado sin recibo |
**Recomendación:** A. Además, pedir los contratos completos para revisar vigencia y preaviso (los textos disponibles no los traen completos).

### [5] PRY-211 Pronóstico de demanda — ¿se exige un plan y un presupuesto reformulados antes de seguir?
**Proyecto:** PRY-211 · **Quién decide:** no consta · **Si no se decide hoy:** el proyecto sigue declarado en verde con proyección de 8.631.313.230 COP contra 6.800.000.000 aprobados (26.9% de desviación; umbral 10%). El cronograma de la carpeta sigue en v1 (despliegue 2026-11-30) aunque el despliegue se reprogramó por el congelamiento de fin de año.
Contexto: progreso declarado 49% contra 60-80% sustentado; 3 hitos cumplidos sin evidencia; 7 compromisos vencidos; 5 reprogramados 3 a 6 veces (uno, 6 veces: "Cerrar la prueba 2", de 2026-09-09 a 2026-12-03). Además un ajuste de presupuesto prometido por Laura Vélez, sin fecha.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir plan v2 y solicitud de cambio formal en el próximo comité | por definir | se formaliza el nuevo despliegue | se decide con cifras, no con el 26.9% |
| B. Aceptar la proyección ya y subir el presupuesto | sin cambio | sin cambio | +26.9% sobre lo aprobado |
| C. Congelar hasta resolver la decisión 4 | pausa | se detiene | detiene el gasto con proveedores |
**Recomendación:** A, con la decisión 4 resuelta primero. Subir presupuesto (B) sin plan nuevo sería aprobar un número sin respaldo.

### [6] PRY-202 Centro de distribución norte — ¿se aprueba más presupuesto, se recorta el alcance o se detiene?
**Proyecto:** PRY-202 · **Quién decide:** no consta · **Si no se decide hoy:** el proyecto, en rojo, sigue consumiendo: proyección de 1.514.819.185 COP contra 1.200.000.000 aprobados (26.2%); ejecutado 62.7% con 26% de avance declarado, contra 67-100% que sustenta el plan. Dos hitos cumplidos sin evidencia ("Diseño de la experiencia aprobado" y "Ambiente de pruebas certificado").
Contexto: la incidencia registrada es la rotación de un desarrollador clave (dos semanas perdidas). No hay solicitud de cambio abierta.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar presupuesto | sin cambio | por definir; el documento no lo da | la proyección: 1.514.819.185 COP |
| B. Recortar alcance al presupuesto aprobado | menor (no está definido cuánto) | por definir | 1.200.000.000 COP |
| C. Detener y revisar | pausa | se detiene | detiene el consumo |
**Recomendación:** B, pidiendo al gerente que traiga la solicitud de cambio formal; con 26% de avance y 62.7% gastado, A premia un gasto sin entrega a la vista.

### [7] Cinco proyectos en verde contradichos por su evidencia — ¿se exige re-diagnóstico y se suspende el verde?
**Proyectos:** PRY-204, PRY-205, PRY-206, PRY-207, PRY-211 · **Quién decide:** no consta · **Si no se decide hoy:** el comité sigue recibiendo un semáforo que su propia evidencia desmiente.
| Proyecto | Señales (del compute) |
|---|---|
| PRY-204 | 2 hitos sin evidencia, avance 58% vs 100% sustentado, costo +10.8%, compromiso vencido |
| PRY-205 | presupuesto comprometido 95.5%, línea base movida sin autorizar, hito sin evidencia (ver decisión 2) |
| PRY-206 | 3 hitos sin evidencia, avance 32% vs 100% sustentado, costo +21.4% (1.607.139.924 ejecutado contra 1.547.641.358 comprometido: ejecutado supera comprometido) |
| PRY-207 | avance declarado 49% con 0 hitos cumplidos (el plan sustenta 0-33%) |
| PRY-211 | ver decisión 5 |
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pasar los cinco a `health-check` y no aceptar verde hasta tener evidencia | ninguno | un período para los resultados | trabajo de revisión |
| B. Solo los tres con sobrecosto > 10% (PRY-204, PRY-206, PRY-211) | ninguno | menor | menor |
| C. Mantener el semáforo declarado | ninguno | ninguno | riesgo no medido |
**Recomendación:** A. En PRY-207 la señal inversa (adelantado sin hitos) es tan sospechosa como el atraso.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-203 | Hito "Integración con el ERP" vencido (2026-10-04) y compromiso de Andrés Lozano ("Entregar el punto 27") vencido; el riesgo del proveedor sin fecha de última entrega no tiene doliente | 13 días | Nueva fecha comprometida y doliente del riesgo; avance 26% contra 50-75% sustentado |
| PRY-201 | CC-01 (+27 días, +54.000.000 COP) figura aprobada por "el comité (sin nombrarlo)" y la línea base no se movió | 27 días | Nombre del aprobador (decisión 1) y nueva línea base formal |
| PRY-204 | Despliegue reprogramado por el congelamiento de fin de año sin cronograma nuevo en la carpeta; prueba de carga fallida que se repite | sin fecha | Cronograma v2 y su solicitud de cambio |
| PRY-211 | El proveedor podría no llegar con el equipo completo; se dijo en la reunión del 2026-10-17 y nadie lo registró | 2026-10-17 | Registrar el riesgo con doliente (probabilidad e impacto) |
| PRY-211 | Compromisos reprogramados varias veces: Javier Hoyos (6 veces), Liliana Torres (4), Beatriz Cuéllar (4), María Restrepo (3), Óscar Ramírez (3) | desde 2026-09-09 | Decidir qué se cierra o se cancela, y fecha firme |
| Portafolio | Todos los riesgos registrados (16) están sin doliente, sin probabilidad, sin impacto y sin fecha | no determinable | Completar el registro RAID |

## Para conocimiento
- PRY-199 Iluminación LED en bodegas: sin señales, verde, 2 días sin movimiento.
- PRY-200 Tienda en línea: sin señales de compute; declarado en rojo (39%, 2026-10-14) sin que el compute marque causa: pendiente de revisar.
- PRY-207 Marca propia de alimentos: verde, avance sin respaldo (decisión 7).
- PRY-208 Domicilios en dos horas: amarillo, 22% contra 50-75% sustentado; sin otra señal.
- PRY-210 Etiquetas electrónicas de precio: sin señales, verde.
- Ningún proyecto supera 15 días en silencio (máximo 10, PRY-201).

## Anexo
**Estado por proyecto (declarado → lo que sustenta la evidencia).**
| Proyecto | Declarado | Avance declarado | Plan sustenta | Proyección vs aprobado |
|---|---|---|---|---|
| PRY-199 | verde | 20% | 20-40% | 0% |
| PRY-200 | rojo | 39% | — | -0.3% |
| PRY-201 | amarillo | 73% | 25-50% | -1.0% |
| PRY-202 | rojo | 26% | 67-100% | +26.2% |
| PRY-203 | rojo | 26% | 50-75% | -5.6% |
| PRY-204 | verde | 58% | 100% | +10.8% |
| PRY-205 | verde | 50% | — | +2.4% |
| PRY-206 | verde | 32% | 100% | +21.4% |
| PRY-207 | verde | 49% | 0-33% | -0.4% |
| PRY-208 | amarillo | 22% | 50-75% | +4.1% |
| PRY-209 | amarillo | 55% | 67-100% | -7.7% |
| PRY-210 | verde | 67% | — | +2.1% |
| PRY-211 | verde | 49% | 60-80% | +26.9% |

**Contradicciones abiertas:** PRY-201 declara 73% avance con el plan sustentando 25-50% y 1 de 4 hitos cumplidos (adelantado, no atrasado). Ninguna ficha tiene conflicto formal abierto (`open_conflicts` vacío en las 13).

**Vacíos de información:**
- `identity.authority` no se encontró en ninguna ficha; `identity.phase` tampoco. `identity.product` falta en PRY-202, 203, 206, 209, 210 y 211.
- No hay actas de comités anteriores, por lo que el cierre del ciclo previo queda en blanco.
- Los proveedores de PRY-199 a PRY-210 (salvo PRY-211) no se evaluaron aquí; solo PRY-211 trae facturación contrastada.
- Para PRY-205 y PRY-209 la línea base nueva solo existe como cronograma v2; no hay aprobación que la respalde.
- Qué recorta una opción "de alcance menor" (decisiones 2 y 6) no está en los documentos; no lo inventé.

---
**Pie:** criterio-portfolio 0.3.13 · fichas aplicadas: 13 (PRY-199 a PRY-211), estado 2026-10-17 · campos inciertos: autoridad y fase (todas), producto (6 proyectos), probabilidad/impacto/doliente de los 16 riesgos · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
Quedan por decidir las 7 decisiones; una vez el comité sesione, puedo registrar lo que se decida en las fichas para que el material del próximo comité parta de ahí.
