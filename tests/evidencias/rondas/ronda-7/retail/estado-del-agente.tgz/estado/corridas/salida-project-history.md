## Historia · PRY-201 Programa de fidelización · 2026-06-10 a 2026-10-07

**Leí:** 7 documentos entre 2026-06-10 y 2026-10-07
**Trimestres sin un solo documento:** ninguno. Pero entre 2026-06-10 y 2026-09-28 no hay un solo documento, y el primer hito (2026-09-10) cae dentro de ese silencio.

**Términos:** ya estaban vigentes y aceptados por José Francisco Ñáñez (versión 1.1, 2026-10-17). No hizo falta registrarlos de nuevo.

### En una línea
El proyecto nació el 2026-06-10 con cierre comprometido al 2027-05-17. El 2026-09-28 el cronograma v2 movió el piloto al 2027-06-13 y el informe de avance declaró amarillo con 73%, cuando el plan sustenta entre 25% y 50% (1 de 4 hitos cumplidos). El 2026-10-04 aparecen el acta de recibo del primer hito y la solicitud de cambio CC-01 (+27 días, +54.000.000 COP), "autorizada por el comité" sin documento que lo muestre. Ningún documento del comité (2026-10-07) la menciona.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 27 días (8,2 %; umbral 10 %) | No calculable: hay una sola declaración (2026-09-28) | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-06-10 | `00-gobierno/2026-06-10-acta-constitucion.md` | Nace el proyecto. Presupuesto 1.200.000.000 COP. Inicio 2026-06-20, cierre 2027-05-17. Patrocinadora Paula Céspedes, gerente Carlos Peña. |
| 2026-06-10 | `10-plan/2026-06-10-cronograma-v1.csv` | Línea base de 4 hitos. Ver nota abajo: ya trae el primer hito como "cerrado". |
| 2026-09-28 | `10-plan/2026-09-28-cronograma-v2.xlsx` | Piloto en tiendas: línea base 2027-05-17, vigente 2027-06-13. Los otros tres hitos no cambian. La línea base original se conserva. |
| 2026-09-28 | `20-seguimiento/2026-09-28-informe-avance.pdf` | Declara amarillo, 73 %. Dice que "se reprogramó el despliegue por el congelamiento de temporada de fin de año". Proyección al cierre 1.188.493.706 COP. Riesgo abierto: concentración del conocimiento en una sola persona. |
| 2026-10-04 | `20-seguimiento/2026-10-04-acta-recibo-diseño-de-la-experiencia-aprobado.pdf` | Carlos Peña recibe "a satisfacción" el primer hito. Es la única evidencia de entregable de la carpeta. |
| 2026-10-04 | `20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md` | Ampliación de alcance: +27 días sobre la línea base vigente y +54.000.000 COP. Dice "Autorizada por el comité", sin fecha ni acta. |
| 2026-10-07 | `30-reuniones/2026-10-07-comite-semanal.md` | Asisten Carlos Peña y Paula Céspedes. Temas: "Avance" y "Compromisos". Un compromiso: Elena Duarte, "Entregar el punto 28", para 2026-10-21. |

**Nota de fecha.** El archivo `cronograma-v1.csv` lleva fecha 2026-06-10 y muestra el hito 1 como "cerrado". El acta de recibo de ese hito es del 2026-10-04. O el archivo se editó después de su fecha, o el estado se marcó antes del recibo. Los documentos no permiten saber cuál de las dos. La fecha del hito en línea base fue el 2026-09-10 y el recibo quedó escrito el 2026-10-04.

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-09-28 (cronograma v2) | 2027-06-13 (+27 días contra 2027-05-17) | En el informe de la misma fecha: congelamiento de temporada de fin de año, que habla de "despliegue" y no nombra el piloto. En CC-01 (2026-10-04): ampliación de alcance. Los dos motivos son distintos. | Ninguno con fecha y firma. CC-01 dice "autorizada por el comité", pero el comité del 2026-10-07 no la registra. |

- El script marca `change_without_baseline`: CC-01 (27 días) está aprobada sin una línea base nueva. La original se conserva y solo cambió la fecha vigente.
- La fecha ya estaba movida en el cronograma del 2026-09-28. La solicitud que la justifica es del 2026-10-04.
- El costo de CC-01 (+54.000.000 COP) no aparece en ningún documento presupuestal. El informe del 2026-09-28 mantiene el aprobado en 1.200.000.000 COP. No calculo el efecto sobre la proyección porque ningún dato dice si ya está incluido.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos. | — |

El acta asigna el proyecto, de Mercadeo, al "Comité de Cadena de Abastecimiento". No hay documento que explique por qué. No es un cambio, pero conviene preguntarlo. Faltan en la ficha `identity.authority` e `identity.phase`.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Elena Duarte | "Entregar el punto 28" | 1 | 2026-10-21 |

Nada se repitió, porque solo hay una minuta. El compromiso vence el 2026-10-21 y hoy no está vencido (corte 2026-10-17). Elena Duarte no figura entre los asistentes. "Punto 28" no remite a ningún documento de la carpeta.

### Desde cuándo lo declarado no se sostiene
- **Fecha:** 2026-09-28, la única declaración que existe. No se puede hablar de deslizamiento: hay un punto y no una serie.
- **Qué se declaró:** amarillo y 73 %. El plan sustenta entre 25 % y 50 %, con 1 de 4 hitos cumplidos (diferencia de 23 puntos por encima del tope). El script la marca como `progress_vs_plan`, "ahead".
- **Primer hito sin evidencia:** ninguno. El hito 1 tiene acta de recibo, pero es del 2026-10-04, posterior al informe del 2026-09-28. Los hitos 2 a 4 están "en curso" y ninguno vence aún.
- **Qué se siguió reportando después:** nada en la carpeta. Lo último es el comité del 2026-10-07, sin contenido sobre el avance.

### Lecciones ancladas a un hecho
1. **Una fecha se movió antes de que existiera la solicitud.** El cronograma v2 (2026-09-28) trae el piloto al 2027-06-13, y CC-01 (2026-10-04) pide los mismos 27 días. Efecto: la autorización quedó sin documento verificable, y la fecha vigente depende de una frase.
2. **Un alcance sin definir no se puede ampliar de forma medible.** El acta del 2026-06-10 lista "Componente 1, 2, 3". CC-01 pide una "ampliación de alcance" sin decir qué se agrega. Efecto: no se puede comprobar si los +27 días y +54.000.000 COP corresponden a algo.
3. **Un hueco documental que contiene el primer vencimiento.** Entre el 2026-06-10 y el 2026-09-28 no hay documentos, y en ese lapso venció el primer hito (2026-09-10). Efecto: el avance de 73 % se declaró sin ningún soporte previo.

### Lo que no sé
- Quién autorizó CC-01, cuándo y en qué reunión.
- Si el 73 % se mide contra el plan o contra otra cosa. El informe no lo dice.
- Si el costo de CC-01 está dentro de la proyección de 1.188.493.706 COP.
- Qué es el "punto 28".
- Por qué el cronograma v1 ya marca el hito 1 como cerrado.

Todo esto describe los documentos. No dice que nadie ocultara nada: esa conversación es de personas y esta historia sirve para tenerla con fechas.

**Siguiente paso posible:** llevar esta historia al comité, con una decisión puntual: ratificar CC-01 por escrito, con fecha y acta, y fijar la línea base nueva. También puedo preparar el cierre del proyecto cuando corresponda.

**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada dato sale de los siete documentos citados y las cifras derivadas, del cálculo de `portafolio.py compute` al 2026-10-17. La verificación es suya.
