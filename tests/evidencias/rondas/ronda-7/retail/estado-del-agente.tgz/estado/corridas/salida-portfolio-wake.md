## 2026-10-17

**Revisé:** 80 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se registraron de nuevo.
Tocaban el barrido diario y la confirmación periódica (primera corrida de ambos, sin registro previo). No hay peticiones en el servidor: `requests` no tocaba.

### Barrido
Ningún documento nuevo, cambiado, renombrado ni borrado, así que no se corrió `/portfolio-scan` y la ficha de ningún proyecto se tocó.

**Cita rota a mirar (PRY-211):** el índice marca como `source_missing` unas 190 citas de la ficha de PRY-211 (acta de constitución, cronograma, contratos, informe de avance, actas de comité, notas del 17 de octubre). Los archivos sí existen en la carpeta del proyecto, así que parece un desajuste de ruta en la ficha (citas relativas al proyecto, no a la carpeta de documentos) y no documentos borrados. No lo corregí: reescribir las citas es trabajo de `/portfolio-scan` sobre ese proyecto, y el índice no marcó nada para recalcular. Queda abierto.

### Lo que cruzó un umbral
Nada nuevo que se deba a este barrido (no hubo cambios). El cálculo vigente del portafolio sigue mostrando, sin cambio desde el último informe:
- **PRY-211:** 26 señales, entre ellas 7 compromisos vencidos, 5 reprogramados, entregables de proveedor tarde, facturado sobre lo aceptado y facturado sin entrega, y lo declarado contra la evidencia.
- **PRY-204, 205, 206, 207:** lo declarado no coincide con la evidencia (`declared_vs_evidence`).
- **PRY-205 y 209:** rebaselinea sin autorización (`rebaseline_unauthorized`).
- **PRY-201:** cambio sin línea base.

### Peticiones atendidas
Ninguna.

### Preguntas (confirmación: 5 campos, elegidos por importancia)
Sin nadie que responda en esta sesión, tomé la respuesta sugerida en cada una: **no cambiar la ficha y dejar el campo sin confirmar.** Quedan preguntadas hoy, 2026-10-17, sin respuesta. La próxima vez se reporta *«preguntada el 17, sin respuesta»* y no se repiten.

1. **PRY-211, estado declarado** (informe de avance del 2026-10-14): ¿lo que declara el gerente sigue siendo válido frente a los compromisos vencidos y la facturación sin entrega?
2. **PRY-205, estado declarado:** ¿puede mostrar la evidencia de los hitos que da por cumplidos y quién autorizó la nueva línea base?
3. **PRY-209, línea base vigente:** ¿quién aprobó el cambio de fechas que movió la línea base?
4. **PRY-204, estado declarado:** ¿qué documento sustenta los hitos cumplidos y las fechas de los compromisos sin fecha?
5. **PRY-206, estado declarado:** ¿qué documento sustenta los tres hitos cumplidos sin evidencia?

**Vuelvo el 2026-10-18.**
