**Acta previa:** sí existe, del 2026-04-10 (aprobada por el Comité de Transformación Digital). Modo: revisar.

## Acta — PRY-200 Tienda en línea
**Estado:** existe, del 2026-04-10

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | No está | No se sabe hasta qué monto ni qué cambio de alcance puede decidir Andrés Lozano sin subir a comité. El proyecto está en rojo; cualquier ajuste, por pequeño que sea, termina en el Comité de Transformación Digital. |
| Objetivo de negocio | Presente pero es la solución: "Entregar tienda en línea para Mercadeo" | No dice qué resultado de negocio se busca (ventas, margen, canal). Sin eso no hay forma de saber si la tienda "funcionó" ni de priorizar al recortar alcance. |
| Alcance | "Componente 1, 2, 3" sin nombre | No se puede verificar qué entra ni medir avance contra algo concreto. El 39% reportado no tiene contra qué compararse. |
| Exclusiones | "Lo que otro proyecto cubre" sin nombrar el proyecto | Cualquier frontera con otro proyecto (por ejemplo el que construye para el mismo producto "venta en línea") queda sin dueño y puede duplicarse o quedar sin cubrir. |
| Criterio de éxito | "En producción y medido": no dice qué se mide, con qué meta ni quién lo mide | El cierre no se puede declarar ni disputar con evidencia. |
| Supuestos y restricciones | No están | Nada que revisar cuando el plan cambie; los supuestos implícitos nunca llegan al registro RAID. |
| Dependencias | "Ninguna declarada" | Una tienda en línea sin ninguna dependencia (pagos, inventario, logística, seguridad) es poco creíble. El informe del 2026-10-14 menciona al área de seguridad, que el acta no contempla. |
| Hitos principales | No están (solo inicio y cierre) | Sin hitos intermedios no hay línea base contra la cual medir atraso; el campo `milestones` de la ficha está vacío. |
| Cadencia de reporte al comité | No está | Se desconoce cada cuánto debe revisar el comité el proyecto. |
| Patrocinador, gerente, comité | Presentes con nombre de persona | Sin hallazgo. |
| Presupuesto y fechas | Presentes (4.200.000.000 COP; 2026-04-20 a 2027-05-03) | Sin hallazgo en el acta. |

### Contenido
**Objetivo de negocio:** pendiente de definir como resultado medible. El acta solo dice "Entregar tienda en línea para Mercadeo" (acta, sección Objetivo del negocio).
**Alcance:** tres componentes sin nombre (acta, sección Alcance). Pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (acta). Pendiente nombrar qué proyecto y qué cubre.
**Patrocinador:** Paula Céspedes (acta) · **Gerente:** Andrés Lozano (acta)
**Autoridad del gerente:** pendiente de definir: monto y cambios sin comité no figuran en ningún documento.
**Comité al que reporta:** Comité de Transformación Digital (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Tienda en línea en producción y medido" (acta); sin métrica ni meta · **Lo mide:** pendiente de definir.
**Hitos principales:** inicio 2026-04-20 y cierre 2027-05-03 (acta); sin hitos intermedios. Pendiente de definir.

### Contexto que el acta no recoge (informe de avance del 2026-10-14)
- El gerente declara estado **rojo** con 39% de avance. Lo declarado es del gerente; el acta no permite contrastarlo contra hitos.
- Presupuesto, según el informe: comprometido 3.347.036.665 COP (79,7% del aprobado), ejecutado 2.214.748.739 COP (52,7%), proyección al cierre 4.185.311.326 COP (99,7%). El gasto ejecutado (52,7%) va por delante del avance declarado (39%). Son cifras declaradas, no verificadas contra facturas ni contratos.
- Tiempo transcurrido al corte: 177 de 378 días (46,8%), también por delante del 39% declarado.
- Riesgo abierto: concentración del conocimiento en una sola persona; sin probabilidad, impacto, dueño ni fecha.
- Dato que el informe no explica: el motivo del rojo. Solo registra el ajuste del plan de pruebas con seguridad.

**Fuentes:** `PRY-200-tienda-en-línea/00-gobierno/2026-04-10-acta-constitucion.docx`; `PRY-200-tienda-en-línea/20-seguimiento/2026-10-14-informe-avance.md`.

### Después
- El acta quedó sin autoridad del gerente declarada. Propuesta: llevar esa definición al Comité de Transformación Digital como una decisión (monto y tipo de cambio que Andrés Lozano puede resolver solo). Es una decisión del comité, no un trámite.
- De la revisión salen supuestos implícitos (que ninguna dependencia externa afecta el proyecto; que los tres componentes están definidos en otro lugar) y un riesgo sin valorar. Propuesta: pasarlos al registro RAID con `/raid-log`.
- Respuestas sugeridas tomadas sin interlocutor: queda ofrecido, no ejecutado.

### Pie de rigor
- **Qué se leyó:** el acta (2026-04-10), el informe de avance (2026-10-14) y la ficha del proyecto. No hay otros documentos del proyecto en la carpeta.
- **Qué no sé:** si los tres componentes, los hitos, la autoridad del gerente o el criterio de éxito están definidos en otro documento o se acordaron en reuniones; el motivo del estado rojo; si las cifras de presupuesto coinciden con contratos y facturas.
- **Qué no verifiqué:** el 39% de avance y las cifras financieras son declaración del gerente.
- Borrador de trabajo: la verificación es de quien lo recibe.
