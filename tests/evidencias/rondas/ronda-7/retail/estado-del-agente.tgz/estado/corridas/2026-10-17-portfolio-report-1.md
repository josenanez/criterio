# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 80 documentos, 0 releídos y 80 sin cambio · 37 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

El informe quedó en `/home/claude/banco/ronda-7/retail/espacio/reportes/index.html`.

Primera corrida del informe: sin delta. 5 verdes contradichos; revisar PRY-211 (facturado sobre lo aceptado).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17
13 proyectos · 10 con hallazgos (61 señales) · último barrido 2026-10-17 (13 fichas, todas del día)

Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17. Formato: html.

## Dónde quedó el informe
Carpeta `reportes/` (24 páginas):
- `reportes/index.html` — vista por campo, con la cadena de evidencia. Para quien va a actuar (PMO, gerentes de proyecto).
- `reportes/decisiones.html` — vista por decisión, solo lo que excede la facultad del gerente. Para el patrocinador y el comité.
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`), por producto (`producto-*.html`), `productos.html` y `proyectos.html`.
- El PDF sale de imprimir el HTML (modo claro, preparado para impresión).

## Qué cambió desde la corrida anterior
No hay instantánea previa distinta de la de hoy (`snapshots/2026-10-17.json`): este es el punto de partida, no hay delta. El diff dio 0 cambios.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-203 Reposición automática | Integración con el ERP (vencido, no cumplido) | 2026-10-04 | 13 |

## Hitos declarados cumplidos sin evidencia
| Proyecto | Hitos (días desde la fecha) |
|---|---|
| PRY-206 | Diseño (444), Integración ERP (347), Piloto (299) |
| PRY-204 | Integración ERP (158), Piloto en tiendas (52) |
| PRY-202 | Diseño (205), Ambiente de pruebas (78) |
| PRY-209 | Diseño (126), Ambiente de pruebas (51) |
| PRY-211 | Diseño (103), Ambiente de pruebas (66), Integración ERP (29) |
| PRY-205 | Ambiente de pruebas (85) |

## Proyectos en silencio
Vacía: ningún proyecto supera los 15 días (máximo, PRY-201 con 10).

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias por código.

## Sin sustento (verde contradicho por la evidencia)
5 proyectos declaran verde y las señales dicen otra cosa:
- PRY-211 Pronóstico de demanda (verde, 14-oct): 8 señales — 6 compromisos vencidos, 5 reprogramados (Javier Hoyos, 6 veces), proveedores con entregables atrasados, **facturado $1.197,9 M contra $775,5 M aceptado (Datos y Demanda) y $723,8 M facturados sin ningún entregable aceptado (Tecnología para Tiendas)**, proyección de costo +26,9 %.
- PRY-206 Precios dinámicos (verde, 14-oct): avance declarado 32 % con 4 de 4 hitos "cumplidos"; proyección +21,4 %; fecha fin 2025-12-22 ya vencida.
- PRY-204 Cajas de autopago (verde, 9-oct): avance 58 % con 4 de 4 hitos cumplidos; proyección +10,8 %; fecha fin 2026-08-26 vencida; un compromiso vencido y otro sin fecha.
- PRY-205 Pago con QR (verde, 14-oct): replanificación de 75 días (17,9 %) sin autorización; 95,5 % comprometido, disponible real $147,7 M.
- PRY-207 Marca propia (verde, 14-oct): avance declarado 49 % cuando el plan sostiene 0–33 % (0 de 3 hitos).

## Vacíos de información
- Los 13 proyectos sin autoridad (`identity.authority`) y sin fase.
- Sin producto: PRY-202, 203, 206, 209, 210, 211.
- PRY-204 y PRY-206: campos de identidad y plan con 16 meses de antigüedad (umbral 12).
- PRY-211: dueño del riesgo 2 sin registrar.
- PRY-199: facturación del proveedor sin dato.

## Estado general
| Proyecto | Declarado | Sustento | Desv. vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Iluminación LED | verde | sin señales | 0 d | 0 d | 0 |
| PRY-200 Tienda en línea | rojo | sin señales | 0 d | 0 d | 0 |
| PRY-201 Fidelización | amarillo | avance 73 % vs plan 25–50 %; cambio CC-01 (27 d) sin línea base nueva | +27 d (8,2 %) | 0 d | 1 |
| PRY-202 CD norte | rojo | avance 26 % vs plan 67–100 %; costo +26,2 %; 2 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-203 Reposición | rojo | hito ERP vencido 13 d; compromiso vencido (A. Lozano); avance 26 % vs 50–75 % | 0 d | 0 d | 0 |
| PRY-204 Autopago | verde | contradicho (ver arriba) | 0 d | 0 d | 0 |
| PRY-205 Pago QR | verde | contradicho (ver arriba) | +75 d (17,9 %) | 0 d | 1 |
| PRY-206 Precios dinámicos | verde | contradicho (ver arriba) | 0 d | 0 d | 0 |
| PRY-207 Marca propia | verde | contradicho (ver arriba) | 0 d | 0 d | 0 |
| PRY-208 Domicilios 2 h | amarillo | avance 22 % vs plan 50–75 % | 0 d | 0 d | 0 |
| PRY-209 Migración ERP | amarillo | +55 d sin autorización; 2 hitos sin evidencia; avance 55 % vs 67–100 % | +55 d (24,3 %) | 0 d | 1 |
| PRY-210 Etiquetas electrónicas | verde | sin señales | 0 d | 0 d | 0 |
| PRY-211 Pronóstico demanda | verde | contradicho (ver arriba) | 0 d | 0 d | 0 |

Cruce: PRY-209 (Migración del ERP) se corrió 55 días sin autorización, y los hitos de "Integración con el ERP" de PRY-203, 204, 206 y 211 son parte de los hitos cuestionados. Ninguna ficha declara la dependencia por código, así que es una lectura para verificar, no un hallazgo del script.

## Necesito que confirmes
La confirmación mensual de cinco campos no aplica en esta corrida (primera corrida, sin ciclo previo) y esta sesión no tiene interfaz.

---
criterio-portfolio 0.3.13 · fichas aplicadas: 13 (PRY-199 a PRY-211), todas del 2026-10-17 · campos inciertos: 13 sin autoridad, 13 sin fase, 6 sin producto, campos de identidad con 16 meses en PRY-204 y PRY-206 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
