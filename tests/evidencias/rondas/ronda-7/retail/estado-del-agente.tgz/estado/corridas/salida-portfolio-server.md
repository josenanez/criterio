# Rostrum — para mirarlo un rato

**Términos:** vigentes, no hubo que aceptarlos de nuevo (versión 1.1 de la familia 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17; comprobante en `.criterio/terminos/`).

**Forma elegida: «para mirarlo un rato».** La pregunta de las dos formas quedó sin respuesta en esta sesión sin interfaz; la sugerida es empezar por esta (se levanta en diez segundos y con eso en la mano la conversación con seguridad es otra). «Que quede corriendo» queda para después.

Hay informe: `reportes/` tiene 25 páginas HTML (portada, decisiones, proyectos PRY-199 a PRY-211, productos).

## Comando

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-7/retail/espacio/reportes --estado /home/claude/banco/ronda-7/retail/espacio/estado --config /home/claude/banco/ronda-7/retail/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8788`, solo en este equipo. El 8787 estaba ocupado por otro servidor (con otro portafolio), así que se usó `--puerto 8788`. Se para con Ctrl-C.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, como pregunta cerrada y con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El portal lleva «Portafolio retail» en todas las páginas.

## Lo que Rostrum no hace

- No calcula: sirve lo que `informe.py` ya escribió.
- No escribe fichas: solo crea peticiones en `estado/peticiones/`.
- No autentica (por eso en este modo solo escucha en local).
- No manda correos ni notificaciones.

## Cierre

El enlace `http://127.0.0.1:8788/` es solo para quien está en este equipo; no se le puede pasar a un patrocinador. El informe es del 2026-10-17 (16:02) y queda desactualizado en cuanto cambien las fichas o se vuelva a correr `/portfolio-report html`; la portada muestra su fecha. Para que un patrocinador tenga un enlace estable hay que pasar a «que quede corriendo» (`--abierto`, host y puerto dentro de la red, detrás del control de acceso de la organización).
