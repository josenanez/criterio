# Corrida del 2026-10-17 · project-closure

13 proyectos · 41 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Cierre de PRY-204: no se puede determinar el criterio de éxito (en producción y medido); 2 de 4 hitos sin acta de recibo, +10,8% de costo proyectado, estado verde contradicho por 4 señales, RAID sin doliente. Dije que no sé: cumplimiento del criterio, fecha real de cierre, alcance por componente, puntos 10 y 19. No archivé el proyecto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha `estado/records/PRY-204.json`; acta de constitución (2025-06-16), cronograma v1 (2025-06-16), informe de avance (2026-10-09), actas de recibo de 2026-10-06 y 2026-10-15, comité del 2026-10-17. Cifras de `portafolio.py compute` (corte 2026-10-17). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Cierre — PRY-204 Cajas de autopago — 2026-10-17

**Aviso previo:** la documentación no sostiene que el proyecto haya terminado. Este documento es el cierre que se puede hacer hoy: dice qué se puede y qué no se puede cerrar. Si se cierra, sería **por decisión**, no por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Cajas de autopago en producción y medido." (acta de constitución, 2025-06-16).
**Se cumplió:** **no se puede determinar**. No hay ningún documento de puesta en producción ni de medición. Lo contrario sí está documentado: el informe del 2026-10-09 dice que se reprogramó el despliegue por el congelamiento de fin de año y que la prueba de carga no alcanzó el umbral y se repite.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño de la experiencia aprobado (2025-10-10) | Recibido | Acta de recibo 2026-10-06 (~12 meses después de la fecha de línea base) |
| Ambiente de pruebas certificado (2026-01-25) | Recibido | Acta de recibo 2026-10-15 (PDF; ~9 meses después de la fecha de línea base) |
| Integración con el ERP (2026-05-12) | Declarado "cerrado" en el cronograma | **Sin evidencia de recibo** |
| Piloto en tiendas (2026-08-26) | Declarado "cerrado" en el cronograma | **Sin evidencia de recibo** |
| Despliegue en producción (implícito en el criterio de éxito) | No es un hito del cronograma | Reprogramado, sin cronograma nuevo en la carpeta |

El acta lista el alcance solo como "Componente 1, 2 y 3", sin nombres. Por eso no se puede contrastar entregado contra comprometido por componente.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato. No hay registro de recortes de alcance. El acta solo dice "lo que otro proyecto cubre". | — | — |

Control de cambios: 0 solicitudes registradas. El reprogramado del despliegue **no tiene solicitud de cambio ni línea base nueva**.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-26 | 2026-08-26 | **Sin dato** (no hay fecha real de terminación) | 0 días según el script, **no confiable**: sale de un cronograma que da los 4 hitos por cerrados mientras el informe dice que el despliegue se movió |
| Presupuesto (COP) | 4.200.000.000 aprobado | 4.200.000.000 (sin cambios aprobados) | Proyección 4.652.440.352 (declarada por el gerente); ejecutado 2.006.973.393 (47,8 %); comprometido 3.593.783.195 (85,6 %) | **+10,8 %** sobre lo aprobado (proyección, umbral 10 %) |

Replanificaciones: **0** registradas (la línea base v1 no ha cambiado). Hay un reprogramado de hecho sin registrar.

El ejecutado y el comprometido son cifras declaradas en el informe; no hay soporte contable en la carpeta. Con 47,8 % ejecutado, el gasto final no existe todavía.

### RAID al cierre
**Materializados:**
- Congelamiento de cambios en temporada alta: figura como riesgo abierto en el informe, y el mismo informe dice que ya obligó a reprogramar el despliegue. Se materializó parcialmente, y sigue en el registro como riesgo.
- Prueba de carga de temporada bajo el umbral pactado (incidencia, se repite).

**No materializados:** ninguno identificable con la documentación.

**Abiertos, con doliente:** hoy **ninguno tiene doliente con nombre**, por lo que el proyecto no está cerrado en este punto.
| Ítem | Doliente |
|---|---|
| Riesgo: congelamiento en temporada alta | Sin doliente |
| Incidencia: prueba de carga repetida | Sin doliente ni fecha de inicio |
| Incidencia: despliegue reprogramado sin cronograma nuevo | Sin doliente ni fecha de inicio |
| Compromiso: "Entregar el punto 10", Felipe Arango, vencido 4 días (para 2026-10-13) | Felipe Arango |
| Compromiso: "Entregar el punto 19", Paula Céspedes | Paula Céspedes, **sin fecha** |

Los "puntos 10 y 19" no se identifican en ningún documento. No se sabe qué son ni si pertenecen al cierre.

### Lecciones
Todas ancladas a un hecho documentado. No incluyo lecciones sobre causas que los documentos no explican.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El acta de recibo del diseño se firmó el 2026-10-06 para un hito con fecha de línea base 2025-10-10 | 2025-10-10 a 2026-10-06 | El cronograma lo muestra cerrado en fecha, pero el recibo llegó ~12 meses tarde; la línea base no refleja la realidad | Exigir el acta de recibo para dar un hito por cerrado en el cronograma |
| El ambiente de pruebas certificado tiene acta de recibo del 2026-10-15; la fecha de línea base era 2026-01-25 | 2026-01-25 a 2026-10-15 | Mismo efecto: ~9 meses entre fecha y recibo | Igual que arriba |
| Integración con ERP y piloto figuran cerrados sin acta de recibo | 2026-05-12; 2026-08-26 | 2 de 4 hitos "cumplidos" no se pueden sustentar (el script los marca 158 y 52 días sin evidencia) | Cierre de hito con evidencia o no cierra |
| El informe del 2026-10-09 declara **verde** y 58 % con 4 de 4 hitos cerrados, un despliegue reprogramado, una prueba de carga fallida y +10,8 % proyectado | 2026-10-09 | Estado declarado contradicho por 4 señales; el plan sostendría 100 %, el gerente dice 58 % | Que el estado verde exija conciliar las señales abiertas |
| El despliegue se reprogramó por el congelamiento de fin de año; el cronograma sigue sin hito de despliegue ni fecha nueva | 2026-10-09 | No hay fecha de cierre real; el criterio de éxito ("en producción y medido") no tiene hito que lo mida | Incluir el despliegue y la medición como hitos de la línea base desde el acta; calendarizar el congelamiento como supuesto o dependencia |
| El acta declaró "Dependencias: ninguna" y el despliegue depende del calendario de congelamiento de temporada | 2025-06-16 | Riesgo conocido de calendario no planeado | Revisar las dependencias estacionales en el acta |

### Sin dato
- Si las cajas están en producción y si se midió (el criterio de éxito).
- Fecha real de terminación y cronograma posterior al reprogramado.
- Acta de recibo de Integración con el ERP y de Piloto en tiendas.
- Nombres de los tres componentes del alcance; recortes de alcance y quién los decidió.
- Qué son los "puntos 10 y 19"; fecha del punto 19.
- Doliente de los dos ítems de incidencia y del riesgo; probabilidad e impacto.
- Gasto ejecutado con soporte contable; cifra final de presupuesto.
- Fase del proyecto y autoridad de aprobación (campos no encontrados en la ficha).
- Proveedores: ninguno registrado.
- Los datos de identidad del acta tienen 16 meses de antigüedad (umbral 12), aunque el cierre no los contradice.
- Lecciones sobre causas (por qué el recibo del diseño llegó tarde, por qué falló la prueba de carga): los documentos no lo explican.

### Después
Recomiendo **no mover la carpeta a `archivo/` todavía**. Con el criterio de éxito sin verificar y cuatro señales abiertas, el proyecto debería seguir en el barrido diario. La alternativa es una decisión explícita del patrocinador, Carlos Peña, de cerrar por decisión, dejando constancia de que no se cumplió o no se verificó el criterio. No archivé nada ni congelé la ficha: eso requiere que alguien lo decida.

*Pie de rigor: borrador de trabajo; no es una decisión ni asesoría. Cada dato viene de los documentos citados; la verificación es de quien lo usa. Nada de lo que se habló fuera de esos documentos está aquí.*
