# Corrida del 2026-10-17 · portfolio-scan

13 proyectos · 80 documentos, 0 releídos y 80 sin cambio · 222 s · 61 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 13 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 5 |
| `commitment_rescheduled` | 5 |
| `variance_cost` | 4 |
| `vendor_deliverable_late` | 4 |
| `commitment_undated` | 3 |
| `variance_time` | 2 |
| `rebaseline_unauthorized` | 2 |
| `change_without_baseline` | 1 |
| `milestone_overdue` | 1 |
| `budget_committed` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Se leyeron 50 de 80 documentos (10 proyectos nuevos, un lote, sin subagentes); 30 sin cambio (PRY-202, 204, 211). No existe entrada/: nada movido. Mirar: CC-01 pendientes de PRY-205 y PRY-209 con cronograma v2 ya movido; informes de PRY-203, 206 y 208 hablan de un cronograma reprogramado que no existe; 171 citas de ficha-pm.json de PRY-211 no resuelven desde la raíz de documentación.

Contra la corrida del 2026-10-17: +24 hallazgos.

## Lo que produjo

Soy Vera, el agente PMO de Criterio. Barrí `documentos/proyectos`: 80 documentos en 13 proyectos (PRY-199 a PRY-211). Formatos: .md 39, .docx 15, .pdf 10, .xlsx 8, .csv 6, .json 1, .txt 1. Todos legibles; no hay carpeta `entrada/`, así que no moví nada.

Términos: ya vigentes para la versión 0.3.13 (términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos otra vez.

## Barrido — 2026-10-17

**Documentos:** 80 en la carpeta · 50 leídos · 30 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Plan: 50 de 80 documentos, en un lote de 10 proyectos, uno tras otro, sin subagentes. Los 30 restantes eran los de PRY-202, PRY-204 y PRY-211, que el setup ya había leído y no cambiaron.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | Patrocinadora María Restrepo, gerente Andrés Lozano, producto PRD-299, aprobado 2.400.000.000 COP, cierre 2027-12-16. Contrato CT-199 (3 entregables de 144.000.000, ninguno recibido). Declara verde, 20%. | Facultad del gerente, fase, facturación del proveedor |
| PRY-200 Tienda en línea | 2 | Patrocinadora Paula Céspedes, gerente Andrés Lozano, producto «venta en línea», aprobado 4.200.000.000 COP, cierre 2027-05-03. Declara rojo, 39%. | Facultad, fase. No hay cronograma: ningún hito |
| PRY-201 Programa de fidelización | 7 | Gerente Carlos Peña, aprobado 1.200.000.000 COP. Dos líneas base (cierre 2027-05-17 → 2027-06-13). CC-01 aprobada (+27 días, +54.000.000 COP). Declara amarillo, 73%. | Facultad, fase |
| PRY-203 Reposición automática | 6 | Gerente Gustavo Neira, aprobado 3.300.000.000 COP, cierre 2026-11-28. Actas de recibo del diseño y del ambiente de pruebas. Declara rojo, 26%. | Producto (el acta dice «No aplica»), facultad, fase |
| PRY-205 Pago con QR en caja | 6 | Gerente Felipe Arango, aprobado 3.300.000.000 COP. Dos líneas base (cierre 2027-02-19 → 2027-05-05). CC-01 pendiente de comité. Declara verde, 50%. | Facultad, fase |
| PRY-206 Precios dinámicos | 5 | Gerente Mauricio Pérez, aprobado 4.200.000.000 COP, cierre original 2025-12-22. Declara verde, 32%. | Producto («No aplica»), facultad, fase |
| PRY-207 Marca propia de alimentos | 4 | Patrocinadora Diana Molina, gerente Andrés Lozano, aprobado 18.000.000.000 COP, cierre 2027-10-21. Declara verde, 49%. | Facultad, fase |
| PRY-208 Domicilios en dos horas | 6 | Gerente Óscar Ramírez, aprobado 2.400.000.000 COP, cierre 2027-03-17. Actas de recibo de dos hitos. Declara amarillo, 22%. | Facultad, fase |
| PRY-209 Migración del ERP | 6 | Gerente Óscar Ramírez, aprobado 3.300.000.000 COP. Dos líneas base (cierre 2026-11-11 → 2027-01-05). CC-01 pendiente de comité. Declara amarillo, 55%. | Producto («No aplica»), facultad, fase |
| PRY-210 Etiquetas electrónicas de precio | 2 | Gerente Elena Duarte, aprobado 6.800.000.000 COP, cierre 2027-03-31. Declara verde, 67%. | Producto («No aplica»), facultad, fase. No hay cronograma ni reuniones |

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-202, PRY-204, PRY-211 | Nada: los 30 documentos tienen el mismo hash. No se releyeron; sus fichas se recalcularon. | — |

### No pude leer
| Archivo | Por qué |
|---|---|
| Ninguno | — |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| Ninguno | No existe la carpeta `entrada/` | — |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| Ninguno | — |

## Lo que levantó el cálculo (13 proyectos, 61 señales)

Cinco proyectos declaran verde y el cálculo los contradice: PRY-204 y PRY-211 (del setup) y PRY-205, PRY-206 y PRY-207 (de este barrido). Por proyecto, lo nuevo:

- **PRY-205** (verde, 50%): CC-01 (+75 días, +150.000.000 COP) sigue «pendiente de presentación al comité», pero el cronograma v2 del mismo día ya mueve el piloto del 2027-02-19 al 2027-05-05. Señal `rebaseline_unauthorized`: 75 días movidos, 0 autorizados. Además comprometido 95,5% del presupuesto (quedan 147.684.786 COP) y el hito «Ambiente de pruebas certificado» figura cerrado sin acta.
- **PRY-209** (amarillo, 55%): mismo patrón, CC-01 (+55 días) pendiente de comité y cronograma v2 ya movido al 2027-01-05 (`rebaseline_unauthorized`, 55 días). Dos hitos cerrados sin acta (diseño, 126 días; ambiente de pruebas, 51).
- **PRY-206** (verde, 32%): el cronograma declara los cuatro hitos cerrados en 2025 y el cierre original era 2025-12-22; hoy sigue en ejecución. Solo existe acta de recibo del ambiente de pruebas (fechada 2026-10-14); diseño, integración y piloto cerrados sin acta (444, 347 y 299 días). Proyección 21,4% sobre lo aprobado. El informe declara comprometido (1.547.641.358) menor que ejecutado (1.607.139.924).
- **PRY-207** (verde, 49%): el cronograma no tiene ningún hito cumplido (plan sustenta 0–33%).
- **PRY-203** (rojo, 26%): hito «Integración con el ERP» vencido hace 13 días (2026-10-04). Compromiso de Andrés Lozano «Entregar el punto 27», con fecha 2026-10-04, anotado en el comité del 2026-10-14: nace vencido, 13 días.
- **PRY-208** (amarillo, 22%): el plan sustenta 50–75%; el avance declarado está 28 puntos por debajo.
- **PRY-201** (amarillo, 73%): `change_without_baseline`: CC-01 (+27 días) autorizada, y la línea base v2 es del 2026-09-28, anterior a la solicitud (2026-10-04). El avance declarado va 23 puntos por encima de lo que sustenta el plan.
- **PRY-199, PRY-200 y PRY-210**: sin señales. En PRY-200 (rojo) y PRY-210 (verde) no hay cronograma, así que el avance no se puede contrastar con nada.

Facultad del gerente: sin dato en las 13 fichas (`no_authority`: 13).

Contradicciones entre documentos: ninguna. Compromisos vencidos nuevos: 1 (PRY-203). Los que ya traía PRY-211 (siete vencidos, cinco reprogramados tres veces o más, y las dos facturas por encima de lo recibido) siguen igual; ya estaban en el informe del setup.

## Qué mirar

- **El informe de avance habla de un cronograma que no existe.** PRY-203, PRY-206 y PRY-208 dicen que «se reprogramó el despliegue», y en ninguno hay una versión 2 del cronograma. Pedirla.
- **Compromisos con responsable ausente.** En los comités de PRY-199, 201, 203, 206, 207 y 208 el responsable del compromiso no figura entre los asistentes (por ejemplo, Carlos Peña en el comité de PRY-199). Está anotado en cada compromiso.
- **Las citas de la ficha publicada de PRY-211 no se pueden seguir.** `ficha-pm.json` cita rutas relativas a la carpeta del proyecto (`00-gobierno/…`), no a la raíz de documentación, y 171 de sus citas no resuelven en `index`. No toqué esa ficha: es del gerente.
- **Las mismas personas aparecen en varios proyectos.** Andrés Lozano gerencia PRY-199, 200, 207 y 211; Óscar Ramírez, PRY-208 y 209. Es una lectura de las fichas, no un hallazgo calculado.
- **Aprobar, o no, los CC-01 de PRY-205 y PRY-209** antes de que las líneas base v2 se den por buenas.

Tiempo de la corrida: lo mide el script en `corrida`; no lo escribo aquí.

Ofrezco el informe consolidado (`/criterio-portfolio:portfolio-report`) para los 13 proyectos.

---
Criterio portfolio 0.3.13 · fichas tocadas: 10 (PRY-199, 200, 201, 203, 205, 206, 207, 208, 209, 210) · campos en `not_found`: `identity.authority` ×10, `identity.phase` ×10, `identity.product` ×4 (PRY-203, 206, 209, 210), facturación de CT-199 ×1 · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
