*Sale de la ficha PRY-211 (estado/records/PRY-211.json), con corte de informe al 2026-10-14 y notas de reunión del 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.*

## Solicitud de cambio — PRY-211 Pronóstico de demanda — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días. Se leyó como el hito «Despliegue en la cadena»: 2026-11-30 → 2026-12-30. La solicitud no dice qué hito es; es una lectura mía.
**Quién lo pide:** no consta en la solicitud ni en ningún documento de la carpeta.
**Por qué:** la solicitud no lo dice. El informe del 2026-10-14 menciona que «se reprogramó el despliegue por el congelamiento de temporada de fin de año». Es el único motivo en la carpeta y no está atado a este cambio.

### Línea base vigente
Solo existe la v1, aprobada el 2026-05-21 por el Comité Comercial (cronograma-v1.xlsx): cierre 2026-11-30, presupuesto aprobado COP 6.800.000.000. No hay línea base 2, ni solicitud de cambio, ni acta que autorice mover el despliegue (`changes: []`).

**Hallazgo previo:** el informe del 2026-10-14 dice que el despliegue ya se reprogramó, pero el cronograma sigue en v1 con el despliegue al 2026-11-30. Este cambio se está pidiendo sobre un plan que, según el propio informe, ya no es el que se ejecuta.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Tres componentes sin nombre en el acta («Componente 1, 2 y 3») | No declarado | Sin impacto declarado. Con el alcance sin describir, no se puede comprobar si cambia. |
| Tiempo | Despliegue y cierre 2026-11-30 | 2026-12-30 | +30 días. El piloto en tiendas (2026-10-24, a 7 días) no está dicho si se mueve. |
| Costo | Aprobado COP 6.800.000.000; el gerente proyecta COP 8.631.313.230 (declarado, sin soporte) | No declarado | La proyección ya supera lo aprobado en COP 1.831.313.230 (+26,9%). Este cambio no trae su costo. No lo estimo. |

**Quién absorbe lo no declarado:** alcance y costo quedan sin cifra. Un mes más de equipo y de proveedor no es gratis. Si no se aprueba presupuesto adicional, lo absorbe el presupuesto que ya está proyectado por encima de lo aprobado, o el proveedor. El piloto, además, queda sin fecha confirmada.

### Efecto en el portafolio
Cálculo con `portafolio.py impact` (PRY-211, +30 días): **0 proyectos alcanzados**, directos o indirectos. 0 no pueden sostener su fecha. 0 dependencias sin confirmar.

Eso no quiere decir que no haya efecto. **La ficha no declara ninguna dependencia** (`raid.dependencies: []`), así que el cálculo no tiene por dónde recorrer. Es un vacío de la ficha, no una conclusión. Hay que preguntar si algún proyecto depende de este, por ejemplo PRY-203 Reposición automática o PRY-206 Precios dinámicos, que es lo que cabría esperar de un pronóstico de demanda. Esos dos nombres son una conjetura mía por el tema, no un dato de la carpeta.

Hitos por los que pasa el cambio: «Piloto en tiendas» (2026-10-24, a 7 días) y «Despliegue en la cadena» (2026-11-30, a 44 días). Gerente: Andrés Lozano.

**Lo que no se puede decir:** cuántos días se mueve cada hito intermedio. Eso necesita holgura por actividad y la ficha no la tiene.

**Contexto que agrava el cambio, sin que sea el cambio:**
- Compromisos con reprogramaciones repetidas: «Cerrar la prueba 2» (Javier Hoyos) lleva 6 fechas y está hoy en 2026-12-03, a solo 27 días de la fecha nueva de despliegue (2026-12-30) y 3 días después de la fecha actual (2026-11-30). Ya no cabe en el plan vigente. «Enviar el documento 1» (Liliana Torres) lleva 4 reprogramaciones y está en 2026-11-24.
- Riesgo dicho en la reunión de hoy y sin registrar: el proveedor podría no llegar con el equipo completo para la siguiente fase. Sin responsable.
- Proveedores: CT-842 tiene facturado COP 1.197.938.594 con una sola entrega aceptada (COP 775.475.640 de valor). CT-565 tiene facturado COP 723.840.453 con ninguna entrega aceptada. Mover 30 días el despliegue aumenta la exposición de ambos contratos.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara autoridad de cambio (`identity.authority: not_found`). Ese es el hallazgo de fondo.
**Según:** acta de constitución 2026-05-21. Declara patrocinador Jorge Medina y comité Comité Comercial, pero ningún umbral de autoridad.
**Va a comité:** **sí, por defecto.** Sin autoridad escrita no hay base para que el gerente ni el patrocinador lo aprueben solos. Lo mínimo defendible es que lo vea el Comité Comercial, que aprobó la línea base original.

### Si no se aprueba
El proyecto sigue con el despliegue al 2026-11-30. El informe declara verde, pero dice que el despliegue ya se reprogramó, y los compromisos de cierre de pruebas están en diciembre. El plan v1 es insostenible tal como está escrito, y quedaría un atraso real que ningún documento autoriza.

### Si se aprueba
Línea base 2 — cierre 2026-12-30 · presupuesto: **no definido, falta el costo del cambio** · motivo: congelamiento de temporada de fin de año (según el informe del 2026-10-14; falta el documento que lo apruebe).
Desviación acumulada contra la línea base original: **+30 días** · costo: sin cifra aprobada. La proyección declarada ya está +26,9% sobre lo aprobado (umbral configurado: 10%).
La v1 no se toca. El conteo de replanificaciones pasa de 0 a 1.

### Qué no sé
- Quién lo pide y qué hito se mueve. Lo supuse.
- El costo y el alcance del cambio.
- Si hay dependientes: la ficha no declara ninguna.
- La autoridad de aprobación: el acta no la dice.
- Todas las cifras de dinero y el verde son declaración del gerente, sin soporte de la carpeta.

### Siguiente paso
Llevarlo al Comité Comercial con: quién lo pide, el hito exacto, el costo del cambio y la lista de dependientes. Si el comité lo aprueba, registrar la línea base 2 con el acta como documento de soporte. Si me das el acta de comité, la registro.
