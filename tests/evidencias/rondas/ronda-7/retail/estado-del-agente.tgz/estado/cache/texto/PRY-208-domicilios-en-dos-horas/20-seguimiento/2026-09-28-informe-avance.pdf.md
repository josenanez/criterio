<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Domicilios en dos horas
Código: PRY-208
Fecha de corte: 2026-09-28
Gerente: Óscar Ramírez

Estado declarado
Amarillo
Avance reportado: 22%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se recibió el concepto de Jurídica sobre los términos de uso

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.996.945.227
Ejecutado 658.971.094
Proyección al cierre 2.499.267.590

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
