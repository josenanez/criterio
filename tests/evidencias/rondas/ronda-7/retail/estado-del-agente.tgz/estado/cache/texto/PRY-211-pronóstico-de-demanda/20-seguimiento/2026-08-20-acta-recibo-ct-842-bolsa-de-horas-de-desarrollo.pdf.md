<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-08-20-acta-recibo-ct-842-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-211 · Pronóstico de demanda
Fecha de recibo: 2026-08-20
Recibido por: Andrés Lozano
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-842 · Datos y Demanda S.A.S..
