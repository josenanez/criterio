<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2026-01-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Domicilios en dos horas

Código: PRY-208

Área dueña: Mercadeo

Patrocinador: María Restrepo

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Expansión

Producto asociado: entrega rápida

Fecha de aprobación: 2026-01-21

Objetivo del negocio

Entregar domicilios en dos horas para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Expansión el 2026-01-21.

Fechas comprometidas

Fecha

Inicio

2026-01-31

Cierre

2027-03-17

Criterio de éxito

Domicilios en dos horas en producción y medido.

Dependencias declaradas

• Ninguna declarada
