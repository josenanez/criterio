<!-- origen: PRY-209-migración-del-erp/10-plan/2026-03-20-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-06-13 | 2026-06-13 | cerrado
Ambiente de pruebas certificado | 2026-08-27 | 2026-08-27 | cerrado
Integración con el ERP | 2026-11-11 | 2026-11-11 | en curso
