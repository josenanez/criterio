<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-10-14-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-10 | 2026-04-10 | cerrado
Ambiente de pruebas certificado | 2026-07-24 | 2026-07-24 | cerrado
Integración con el ERP | 2026-11-06 | 2026-11-06 | en curso
Piloto en tiendas | 2027-02-19 | 2027-05-05 | en curso
