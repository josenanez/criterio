<!-- origen: PRY-209-migración-del-erp/10-plan/2026-10-10-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-06-13,2026-06-13,cerrado
Ambiente de pruebas certificado,2026-08-27,2026-08-27,cerrado
Integración con el ERP,2026-11-11,2027-01-05,en curso
