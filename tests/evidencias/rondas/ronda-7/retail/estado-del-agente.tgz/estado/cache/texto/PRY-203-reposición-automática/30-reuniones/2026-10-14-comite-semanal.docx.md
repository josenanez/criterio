<!-- origen: PRY-203-reposición-automática/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Reposición automática

Fecha: 2026-10-14

Asistentes: Gustavo Neira, Liliana Torres

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Andrés Lozano

Entregar el punto 27

2026-10-04
