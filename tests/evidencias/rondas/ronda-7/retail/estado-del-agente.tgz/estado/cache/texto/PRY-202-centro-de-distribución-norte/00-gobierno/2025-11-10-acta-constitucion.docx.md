<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-11-10-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Centro de distribución norte

Código: PRY-202

Área dueña: Comercial

Patrocinador: Liliana Torres

Gerente de proyecto: Diana Molina

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2025-11-10

Objetivo del negocio

Entregar centro de distribución norte para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Expansión el 2025-11-10.

Fechas comprometidas

Fecha

Inicio

2025-11-20

Cierre

2026-12-04

Criterio de éxito

Centro de distribución norte en producción y medido.

Dependencias declaradas

• Ninguna declarada
