<!-- origen: PRY-203-reposición-automática/10-plan/2026-04-11-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-06-15,2026-06-15,cerrado
Ambiente de pruebas certificado,2026-08-09,2026-08-09,cerrado
Integración con el ERP,2026-10-04,2026-10-04,en curso
Piloto en tiendas,2026-11-28,2026-11-28,en curso
