<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2026-01-21-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-05-13,2026-05-13,cerrado
Ambiente de pruebas certificado,2026-08-24,2026-08-24,cerrado
Integración con el ERP,2026-12-05,2026-12-05,en curso
Piloto en tiendas,2027-03-17,2027-03-17,en curso
