<!-- origen: PRY-203-reposición-automática/00-gobierno/2026-04-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Reposición automática

Código: PRY-203

Área dueña: Mercadeo

Patrocinador: Liliana Torres

Gerente de proyecto: Gustavo Neira

Comité: Comité de Arquitectura

Producto asociado: No aplica

Fecha de aprobación: 2026-04-11

Objetivo del negocio

Entregar reposición automática para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2026-04-11.

Fechas comprometidas

Fecha

Inicio

2026-04-21

Cierre

2026-11-28

Criterio de éxito

Reposición automática en producción y medido.

Dependencias declaradas

• Ninguna declarada
