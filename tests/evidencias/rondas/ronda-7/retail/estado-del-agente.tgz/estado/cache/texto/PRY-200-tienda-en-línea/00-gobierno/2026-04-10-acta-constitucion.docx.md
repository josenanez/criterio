<!-- origen: PRY-200-tienda-en-línea/00-gobierno/2026-04-10-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tienda en línea

Código: PRY-200

Área dueña: Mercadeo

Patrocinador: Paula Céspedes

Gerente de proyecto: Andrés Lozano

Comité: Comité de Transformación Digital

Producto asociado: venta en línea

Fecha de aprobación: 2026-04-10

Objetivo del negocio

Entregar tienda en línea para Mercadeo.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2026-04-10.

Fechas comprometidas

Fecha

Inicio

2026-04-20

Cierre

2027-05-03

Criterio de éxito

Tienda en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
