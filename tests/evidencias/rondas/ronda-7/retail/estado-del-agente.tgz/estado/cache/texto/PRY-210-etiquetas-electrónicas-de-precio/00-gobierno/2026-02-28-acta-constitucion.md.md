<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/00-gobierno/2026-02-28-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Etiquetas electrónicas de precio

**Código:** PRY-210
**Área dueña:** Tiendas
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Transformación Digital
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-28

## Objetivo del negocio

Entregar etiquetas electrónicas de precio para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-02-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-10 |
| Cierre | 2027-03-31 |

## Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

## Dependencias declaradas

- Ninguna declarada
