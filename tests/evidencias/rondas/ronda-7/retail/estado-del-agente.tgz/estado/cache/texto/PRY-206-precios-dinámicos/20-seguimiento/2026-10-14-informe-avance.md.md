<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-14
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **32%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.547.641.358 |
| Ejecutado | 1.607.139.924 |
| Proyección al cierre | 5.098.280.908 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
- Congelamiento de cambios en temporada alta
