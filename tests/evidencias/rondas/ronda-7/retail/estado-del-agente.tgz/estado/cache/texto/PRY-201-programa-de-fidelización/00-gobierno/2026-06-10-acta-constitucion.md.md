<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2026-06-10-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Mercadeo
**Patrocinador:** Paula Céspedes
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2026-06-10

## Objetivo del negocio

Entregar programa de fidelización para Mercadeo.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-06-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-20 |
| Cierre | 2027-05-17 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
