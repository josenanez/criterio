<!-- origen: PRY-206-precios-dinámicos/10-plan/2025-06-02-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-07-30 | 2025-07-30 | cerrado
Ambiente de pruebas certificado | 2025-09-16 | 2025-09-16 | cerrado
Integración con el ERP | 2025-11-04 | 2025-11-04 | cerrado
Piloto en tiendas | 2025-12-22 | 2025-12-22 | cerrado
