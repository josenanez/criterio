<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de fidelización
Código: PRY-201
Fecha de corte: 2026-09-28
Gerente: Carlos Peña

Estado declarado
Amarillo
Avance reportado: 73%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 841.171.969
Ejecutado 381.879.879
Proyección al cierre 1.188.493.706

Riesgos abiertos
- Concentración del conocimiento en una sola persona
