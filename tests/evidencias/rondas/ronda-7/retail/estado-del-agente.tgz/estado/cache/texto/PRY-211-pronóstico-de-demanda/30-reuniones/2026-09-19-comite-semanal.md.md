<!-- origen: PRY-211-pronóstico-de-demanda/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-09-19
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-10-08 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-10-13 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-10-01 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-10 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-29 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-17 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 |
| Elena Duarte | Entregar el punto 8 | 2026-10-16 |
| María Restrepo | Enviar el documento 9 | 2026-10-01 |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-09-28 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-06 |
| Diana Molina | Validar el ambiente 12 | 2026-10-09 |
