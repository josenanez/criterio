<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-211",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "name": {
 "value": "Pronóstico de demanda",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "business_area": {
 "value": "Logística",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "authority": {
 "value": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "manager": {
 "value": "Andrés Lozano",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "committee": {
 "value": "Comité Comercial",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "phase": {
 "value": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 49,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-14",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-14-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2026-05-31",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "end_date": {
 "value": "2026-11-30",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-05-21",
 "start_date": "2026-05-31",
 "end_date": "2026-11-30",
 "reason": "línea base inicial, acta de constitución",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño de la experiencia aprobado",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-07-06",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "current_date": {
 "value": "2026-07-06",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-08-12",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "current_date": {
 "value": "2026-08-12",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Integración con el ERP",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-09-18",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "current_date": {
 "value": "2026-09-18",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Piloto en tiendas",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-24",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-24",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Despliegue en la cadena",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-11-30",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "current_date": {
 "value": "2026-11-30",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-05-21-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Tres componentes sin describir («Componente 1, 2 y 3»)",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "approved": {
 "value": 6800000000,
 "source": "00-gobierno/2026-05-21-acta-constitucion.docx",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "committed": {
 "value": 2114474257,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 1539004991,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 8631313230,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Datos y Demanda S.A.S.",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-842",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento de la plataforma",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-07-10",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "amount": {
 "value": 775475640,
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de desarrollo",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-08-19",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "amount": {
 "value": 775475640,
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "accepted"
 },
 "evidence": {
 "value": "20-seguimiento/2026-08-20-acta-recibo-ct-842-bolsa-de-horas-de-desarrollo.pdf"
 }
 },
 {
 "name": {
 "value": "Configuración del catálogo",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-29",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "amount": {
 "value": 775475640,
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Soporte del primer trimestre",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-08",
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "amount": {
 "value": 775475640,
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md",
 "source_date": "2026-05-21",
 "state": "found"
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "invoiced": {
 "value": 1197938594,
 "source": "20-seguimiento/2026-10-02-factura-ct-842.md",
 "source_date": "2026-10-02",
 "state": "found"
 },
 "source": "00-gobierno/2026-05-21-contrato-ct-842.md"
 },
 {
 "name": {
 "value": "Tecnología para Tiendas Ltda.",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-565",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento de la plataforma",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-08-06",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "amount": {
 "value": 723840453,
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de desarrollo",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "amount": {
 "value": 723840453,
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md",
 "source_date": "2026-05-25",
 "state": "found"
 },
 "state": {
 "value": "pending"
 },
 "evidence": {
 "value": null
 }
 }
 ],
 "invoiced": {
 "value": 723840453,
 "source": "20-seguimiento/2026-09-16-factura-ct-565.pdf",
 "source_date": "2026-09-16",
 "state": "found"
 },
 "source": "00-gobierno/2026-05-25-contrato-ct-565.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": {
 "value": "Congelamiento de cambios en temporada alta",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-14-informe-avance.md"
 },
 {
 "what": {
 "value": "El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "owner": {
 "value": null,
 "state": "not_found"
 },
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": {
 "value": "Se reprogramó el despliegue por el congelamiento de temporada de fin de año",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-14-informe-avance.md"
 },
 {
 "what": {
 "value": "La validación con dos tiendas se extendió una semana por el conteo de inventario",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-14-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-03",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-09",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-13",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-03",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "note": "Las notas del 2026-10-17 dicen «03/12/2026»; se leyó día/mes/año (3 de diciembre)."
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-01",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-09",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-01",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Natalia Ospina",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-4.md"
 }
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-03-acta-recibo-5.md"
 }
 },
 {
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-17",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-03-acta-recibo-6.md"
 }
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-26",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-26",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "Sigue en la tabla del 2026-10-10 con la misma fecha, ya pasada; ninguna minuta la reprogramó."
 },
 {
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-06",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-30",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-28",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-09",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-17",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-09",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-12.md"
 }
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "El 2026-10-03 dijo que ya lo entregó; no se presentó acta, por eso no se da por cumplido. Dejó de aparecer en la tabla."
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "El 2026-10-03 dijo que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "El 2026-10-10 dijo que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-25",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-29",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-10",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-10",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "El 2026-10-10 dijo que ya lo entregó; no se presentó acta. Dejó de aparecer en la tabla."
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-05",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-05",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "stated_on": "2026-10-17",
 "source": {
 "value": "2026-10-17-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Las notas dicen «la otra semana»; no es una fecha y se copia tal cual."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-27",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "stated_on": "2026-10-17",
 "source": {
 "value": "2026-10-17-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "No se sabe si es el mismo compromiso que «Revisar el anexo 11»; se registra aparte."
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "sealed": false,
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
