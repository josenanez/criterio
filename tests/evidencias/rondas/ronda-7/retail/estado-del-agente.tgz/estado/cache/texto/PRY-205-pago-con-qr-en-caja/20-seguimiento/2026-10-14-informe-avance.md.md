<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Felipe Arango

## Estado declarado

**Verde**

Avance reportado: **50%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 3.152.315.214 |
| Ejecutado | 1.792.674.413 |
| Proyección al cierre | 3.379.087.994 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
