<!-- origen: PRY-209-migración-del-erp/00-gobierno/2026-03-20-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración del ERP

Código: PRY-209

Área dueña: Comercial

Patrocinador: Natalia Ospina

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-03-20

Objetivo del negocio

Entregar migración del erp para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Expansión el 2026-03-20.

Fechas comprometidas

Fecha

Inicio

2026-03-30

Cierre

2026-11-11

Criterio de éxito

Migración del ERP en producción y medido.

Dependencias declaradas

• Ninguna declarada
