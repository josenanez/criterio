<!-- origen: PRY-204-cajas-de-autopago/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-10-09
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **58%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 3.593.783.195 |
| Ejecutado | 2.006.973.393 |
| Proyección al cierre | 4.652.440.352 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
