<!-- origen: PRY-207-marca-propia-de-alimentos/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Marca propia de alimentos

Fecha: 2026-10-14

Asistentes: Andrés Lozano, Diana Molina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Paula Céspedes

Entregar el punto 4

2026-10-25
