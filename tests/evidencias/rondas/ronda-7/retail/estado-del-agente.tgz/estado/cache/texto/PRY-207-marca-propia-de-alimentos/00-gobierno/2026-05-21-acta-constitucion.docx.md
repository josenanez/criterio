<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-05-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Marca propia de alimentos

Código: PRY-207

Área dueña: Comercio electrónico

Patrocinador: Diana Molina

Gerente de proyecto: Andrés Lozano

Comité: Comité de Arquitectura

Producto asociado: marca propia

Fecha de aprobación: 2026-05-21

Objetivo del negocio

Entregar marca propia de alimentos para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Arquitectura el 2026-05-21.

Fechas comprometidas

Fecha

Inicio

2026-05-31

Cierre

2027-10-21

Criterio de éxito

Marca propia de alimentos en producción y medido.

Dependencias declaradas

• Ninguna declarada
