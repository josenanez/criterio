<!-- origen: PRY-205-pago-con-qr-en-caja/20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Pago con QR en caja
**Fecha:** 2026-10-14
**Solicitante:** Felipe Arango

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +75 días sobre la línea base vigente |
| Costo | 150.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
