<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-15
Gerente: Elena Duarte

Estado declarado
Verde
Avance reportado: 67%

Lo que pasó en el periodo
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto de Jurídica sobre los términos de uso
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 2.644.786.948
Ejecutado 1.620.756.366
Proyección al cierre 6.944.150.629

Riesgos abiertos
- Cambio en la regulación de datos personales que puede mover el alcance
