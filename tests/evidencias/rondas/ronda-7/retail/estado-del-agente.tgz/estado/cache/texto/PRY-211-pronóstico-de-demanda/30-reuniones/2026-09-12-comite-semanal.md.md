<!-- origen: PRY-211-pronóstico-de-demanda/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-09-12
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Elena Duarte, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, Natalia Ospina, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-09-29 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-09-30 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-09-09 |
| Natalia Ospina | Validar el ambiente 4 | 2026-09-10 |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-29 |
| Jorge Medina | Actualizar la matriz 6 | 2026-10-06 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 |
| Elena Duarte | Entregar el punto 8 | 2026-09-30 |
