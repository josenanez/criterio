<!-- origen: PRY-201-programa-de-fidelización/10-plan/2026-06-10-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-09-10,2026-09-10,cerrado
Ambiente de pruebas certificado,2026-12-02,2026-12-02,en curso
Integración con el ERP,2027-02-23,2027-02-23,en curso
Piloto en tiendas,2027-05-17,2027-05-17,en curso
