<!-- origen: PRY-211-pronóstico-de-demanda/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Pronóstico de demanda

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Elena Duarte, Felipe Arango, Javier Hoyos, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Enviar el documento 1 | 2026-11-10 |
| Javier Hoyos | Cerrar la prueba 2 | 2026-11-12 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-10-24 |
| Natalia Ospina | Validar el ambiente 4 | 2026-10-20 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 |
| Elena Duarte | Entregar el punto 8 | 2026-10-16 |
| María Restrepo | Enviar el documento 9 | 2026-10-19 |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-30 |
| Diana Molina | Validar el ambiente 12 | 2026-10-09 |
| Ricardo Salas | Confirmar la fecha 15 | 2026-10-16 |
| Felipe Arango | Entregar el punto 16 | 2026-10-16 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-12 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-12 |
| Paula Céspedes | Revisar el anexo 19 | por definir |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-10 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Felipe Arango): recibido, acta de recibo del 2026-10-03.
- Actualizar la matriz 6 (Jorge Medina): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- Laura Vélez dice que ya entregó «aprobar el diseño 13». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «actualizar la matriz 14». No se presentó acta.
