<!-- origen: PRY-203-reposición-automática/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Reposición automática
Código: PRY-203
Fecha de corte: 2026-10-16
Gerente: Gustavo Neira

Estado declarado
Rojo
Avance reportado: 26%

Lo que pasó en el periodo
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.518.562.063
Ejecutado 1.891.245.411
Proyección al cierre 3.114.019.216

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
