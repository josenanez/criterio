<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración del ERP

**Código:** PRY-209
**Fecha de corte:** 2026-10-10
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **55%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.843.580.068 |
| Ejecutado | 942.727.077 |
| Proyección al cierre | 3.046.709.766 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
