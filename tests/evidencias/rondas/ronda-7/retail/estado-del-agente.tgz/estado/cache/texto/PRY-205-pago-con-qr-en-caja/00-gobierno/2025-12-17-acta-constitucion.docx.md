<!-- origen: PRY-205-pago-con-qr-en-caja/00-gobierno/2025-12-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pago con QR en caja

Código: PRY-205

Área dueña: Abastecimiento

Patrocinador: Óscar Ramírez

Gerente de proyecto: Felipe Arango

Comité: Comité de Arquitectura

Producto asociado: pago con QR

Fecha de aprobación: 2025-12-17

Objetivo del negocio

Entregar pago con qr en caja para Abastecimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2025-12-17.

Fechas comprometidas

Fecha

Inicio

2025-12-27

Cierre

2027-02-19

Criterio de éxito

Pago con QR en caja en producción y medido.

Dependencias declaradas

• Ninguna declarada
