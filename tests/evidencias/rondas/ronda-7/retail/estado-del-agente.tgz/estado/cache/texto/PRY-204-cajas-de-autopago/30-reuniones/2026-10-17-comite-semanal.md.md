<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Cajas de autopago

**Fecha:** 2026-10-17
**Asistentes:** Rubén Cárdenas, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 10 | 2026-10-13 |
| Paula Céspedes | Entregar el punto 19 | por definir |
