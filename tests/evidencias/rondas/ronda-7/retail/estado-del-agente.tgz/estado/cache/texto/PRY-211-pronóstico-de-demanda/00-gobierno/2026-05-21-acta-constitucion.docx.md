<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2026-05-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pronóstico de demanda

Código: PRY-211

Área dueña: Logística

Patrocinador: Jorge Medina

Gerente de proyecto: Andrés Lozano

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2026-05-21

Objetivo del negocio

Entregar pronóstico de demanda para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Comercial el 2026-05-21.

Fechas comprometidas

Fecha

Inicio

2026-05-31

Cierre

2026-11-30

Criterio de éxito

Pronóstico de demanda en producción y medido.

Dependencias declaradas

• Ninguna declarada
