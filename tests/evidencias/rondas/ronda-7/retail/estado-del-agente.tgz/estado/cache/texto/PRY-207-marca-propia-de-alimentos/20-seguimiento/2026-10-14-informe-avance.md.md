<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **49%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 7.484.592.869 |
| Ejecutado | 6.585.578.050 |
| Proyección al cierre | 17.933.301.147 |

## Riesgos abiertos

- Disponibilidad de los jefes de tienda para el piloto
