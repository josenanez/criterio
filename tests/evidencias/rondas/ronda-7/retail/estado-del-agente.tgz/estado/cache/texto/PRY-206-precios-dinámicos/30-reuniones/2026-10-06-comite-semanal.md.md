<!-- origen: PRY-206-precios-dinámicos/30-reuniones/2026-10-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Comercial · Precios dinámicos

**Fecha:** 2026-10-06
**Asistentes:** Mauricio Pérez, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 27 | 2026-11-10 |
