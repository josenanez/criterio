<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2025-11-10-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-03-26,2026-03-26,cerrado
Ambiente de pruebas certificado,2026-07-31,2026-07-31,cerrado
Integración con el ERP,2026-12-04,2026-12-04,en curso
