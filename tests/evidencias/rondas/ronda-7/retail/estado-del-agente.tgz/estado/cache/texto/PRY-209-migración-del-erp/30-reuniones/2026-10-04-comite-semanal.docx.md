<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Expansión · Migración del ERP

Fecha: 2026-10-04

Asistentes: Óscar Ramírez, Natalia Ospina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 35

2026-11-01
