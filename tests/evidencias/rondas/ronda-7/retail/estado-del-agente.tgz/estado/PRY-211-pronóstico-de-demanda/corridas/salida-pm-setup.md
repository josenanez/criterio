## Listo — PRY-211 · Pronóstico de demanda

**Lo que miré:** 19 documentos · 7 minutas (6 comités semanales del 2026-09-05 al 2026-10-10 y las notas del 2026-10-17) · la última del 2026-10-17. Leí las 7, de la más vieja a la más nueva, más 4 actas de recibo, el acta de constitución, el cronograma, los 2 contratos, las 2 facturas y el informe de avance. Todos los formatos se pudieron leer.
**Términos:** aceptados para la versión 0.3.13 (texto 1.1) por José Francisco Ñáñez, 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb… (md) y 28e9cfed31cb47fb… (pdf)

Preguntas (sesión sin interfaz, respuesta sugerida en cada una):
1. Quién eres y qué proyecto es: Andrés Lozano, gerente de PRY-211 · Pronóstico de demanda (acta de constitución).
2. Reunión de seguimiento: comité semanal, los sábados (las minutas son del 5, 12, 19 y 26 de septiembre y del 3, 10 y 17 de octubre). Las notas del 17 dicen «próxima reunión en dos semanas»: queda el 2026-10-31.
3. Dónde guardo lo que encuentro: `estado/PRY-211-pronóstico-de-demanda`.
4. Términos: aceptados con el sí dado por escrito en la invocación.

### Lo que está abierto, y cuántas veces se ha movido

El historial sale de leer las 7 minutas en orden. Son 26 compromisos: 4 cumplidos con acta, 7 vencidos sin evidencia, 13 abiertos con fecha y 2 sin fecha.

**Movidos tres veces o más (el bloqueo que nadie ha nombrado):**

| Quién | Qué | Primera fecha | Fecha vigente | Veces |
|---|---|---|---|---|
| Javier Hoyos | Cerrar la prueba 2 | 2026-09-09 | 2026-12-03 | 6 |
| Liliana Torres | Enviar el documento 1 | 2026-09-29 (el 09-05 era «por definir») | 2026-11-24 | 4 |
| Beatriz Cuéllar | Revisar el anexo 3 | 2026-09-09 | 2026-11-01 | 4 |
| María Restrepo | Enviar el documento 9 | 2026-10-01 | 2026-10-27 | 3 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-06 | 2026-11-09 | 3 |

Citas: `30-reuniones/2026-09-05-comite-semanal.md` a `30-reuniones/2026-10-10-comite-semanal.md` y `2026-10-17-notas-reunion.txt`. Las fechas de cada paso están en la ficha. Las notas del 17 dicen «03/12/2026» para Javier; lo leí como 3 de diciembre (día/mes/año).

**Vencidos sin evidencia (hoy 2026-10-17):**

| Quién | Qué | Para | Días | Cita |
|---|---|---|---|---|
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 | 21 | `30-reuniones/2026-09-12-comite-semanal.md`; sigue en la tabla del 10-10 con la misma fecha |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 | 7 | `30-reuniones/2026-09-19-comite-semanal.md` |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-10 | 7 | `30-reuniones/2026-10-03-comite-semanal.md`; el 10-10 dijo que ya lo entregó, sin acta |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-12 | 5 | `30-reuniones/2026-10-03-comite-semanal.md` |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-16 | 1 | `30-reuniones/2026-09-26-comite-semanal.md`; el 10-03 dijo que ya lo entregó, sin acta |
| Ricardo Salas | Confirmar la fecha 15 | 2026-10-16 | 1 | `30-reuniones/2026-09-26-comite-semanal.md` |
| Felipe Arango | Entregar el punto 16 | 2026-10-16 | 1 | `30-reuniones/2026-09-26-comite-semanal.md`; el 10-10 dijo que ya lo entregó, sin acta |

**Cumplidos, con acta:** Aprobar el diseño 5 (Felipe Arango) y Actualizar la matriz 6 (Jorge Medina), ambos con acta del 2026-10-03; Validar el ambiente 4 (Natalia Ospina) y Validar el ambiente 12 (Diana Molina), ambos con acta del 2026-10-10. Natalia movió el 4 una vez (de 09-10 a 10-20) y Jorge movió el 6 una vez.

**Abiertos con fecha, sin señal:** Elena Duarte (punto 8, 11-06, movido 2 veces), Andrés Lozano (documento 17, 10-25, movido 1), Paula Céspedes (anexo 19, 10-29), Mauricio Pérez (diseño 21, 10-18), Carlos Peña (matriz 22, 10-20), Beatriz Cuéllar (fecha 23, 11-05), Camilo Beltrán (punto 24, 10-22), Óscar Ramírez (revisión con el proveedor, 10-27).

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos:
- Laura Vélez · Aprobar el diseño 13 (`30-reuniones/2026-09-26-comite-semanal.md`). El 10-03 dijo que ya lo entregó, sin acta, y desapareció de la tabla.
- Laura Vélez · Mandar el ajuste del presupuesto (`2026-10-17-notas-reunion.txt`): «la otra semana» no es una fecha.

### Lo que el informe declara contra lo que muestran los documentos
El informe del 2026-10-14 declara **verde** y **49%** (`20-seguimiento/2026-10-14-informe-avance.md`). `compute` levantó contra esa declaración:
- **Costo:** proyección 8.631.313.230 COP contra 6.800.000.000 aprobados, 26,9 % por encima.
- **Avance:** el cronograma sostiene entre 60 % y 80 % (3 de 5 hitos cerrados); lo declarado es 49 %, 11 puntos por debajo.
- **Hitos cerrados sin acta:** Diseño de la experiencia aprobado (103 días), Ambiente de pruebas certificado (66) e Integración con el ERP (29). Ninguna de las actas de recibo los nombra.
- **Datos y Demanda S.A.S. (CT-842):** facturó 1.197.938.594 COP y lo aceptado con acta suma 775.475.640 COP, una diferencia de 422.462.954 COP. Licenciamiento (venció el 07-10, 99 días) y Configuración del catálogo (09-29, 18 días) siguen sin acta.
- **Tecnología para Tiendas Ltda. (CT-565):** facturó 723.840.453 COP y no tiene ningún entregable con acta. Licenciamiento (08-06, 72 días) y Bolsa de horas (10-12, 5 días) siguen vencidos.
- **Riesgos:** el informe solo trae «congelamiento de cambios en temporada alta». Las notas del 10-17 dicen que el proveedor podría no llegar con el equipo completo para la siguiente fase y que nadie lo anotó; quedó en la ficha, sin responsable.

El informe cuenta que se reprogramó el despliegue, pero el único cronograma de la carpeta (v1, 2026-05-21) sigue con el 2026-11-30. La fecha de cierre vigente en la ficha es esa, sin confirmación posterior.

### Qué le falta a tu carpeta
- Un cronograma posterior a la v1: el informe dice que el despliegue se reprogramó y no hay documento que traiga la fecha nueva.
- Actas de recibo de los tres hitos que el cronograma da por cerrados, y de los entregables de los dos contratos que ya se facturaron.
- Minutas anteriores al 2026-09-05: la primera que hay ya traía cuatro compromisos abiertos, así que su historia puede ser más larga.
- Las notas del 10-17 son un `.txt` de viñetas, sin la tabla de compromisos del comité; los compromisos de ese día se leyeron de las viñetas.
- El acta de constitución no trae facultades del gerente ni etapa, y declara las dependencias como «Ninguna declarada». Esos campos quedaron sin dato.

**Cuándo vuelvo:** el comité semanal de los sábados; las notas del 10-17 fijan la próxima reunión para el 2026-10-31, y paso a leer su minuta ese día.
