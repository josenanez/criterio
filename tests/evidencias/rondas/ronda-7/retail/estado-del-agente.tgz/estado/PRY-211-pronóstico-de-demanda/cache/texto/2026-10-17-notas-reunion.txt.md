<!-- origen: 2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión pronóstico de demanda — 2026-10-17
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

- Javier Hoyos dice que lo de «cerrar la prueba 2» no alcanzó, se compromete para el 03/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
