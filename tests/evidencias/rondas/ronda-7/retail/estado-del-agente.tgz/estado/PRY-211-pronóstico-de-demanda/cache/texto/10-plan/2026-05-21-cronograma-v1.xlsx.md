<!-- origen: 10-plan/2026-05-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-06 | 2026-07-06 | cerrado
Ambiente de pruebas certificado | 2026-08-12 | 2026-08-12 | cerrado
Integración con el ERP | 2026-09-18 | 2026-09-18 | cerrado
Piloto en tiendas | 2026-10-24 | 2026-10-24 | en curso
Despliegue en la cadena | 2026-11-30 | 2026-11-30 | en curso
