## Reunión de seguimiento — PRY-211 Pronóstico de demanda · 2026-10-31
11 puntos · 57 minutos · 10 personas requeridas

Supuestos (sin quien responda, se tomó la respuesta sugerida): fecha 2026-10-31, que es `committee_next` de la configuración y coincide con el «próxima reunión en dos semanas» de las notas del 10-17; duración de 60 minutos, porque no se pidió otra. Los datos están al 2026-10-17: **corre `/pm-agenda` de nuevo el 10-30**, porque en las dos semanas de por medio varios compromisos vencerán o se cerrarán.
Comparación: `diff` no tiene foto anterior (primera corrida), así que "qué cambió" se armó a mano contra la minuta del 10-10 y las notas del 10-17.

### Lo que no se destraba solo

> **[1] Que quede una causa dicha y una decisión: ¿se sostiene el 2026-12-03 para «Cerrar la prueba 2», o sube a comité?** · 10 min · **Javier Hoyos** (con Andrés Lozano)
> Prometido para el 2026-09-09, y antes para el 09-30, 10-13, 10-29, 11-12, 11-19, y ahora el 2026-12-03. **Seis reprogramaciones en siete semanas.** La fecha cae después del fin del proyecto (2026-11-30).
> Fuente: `30-reuniones/2026-09-05-comite-semanal.md` (origen) · `2026-10-17-notas-reunion.txt`, línea 4 (última; «03/12/2026» leído día/mes/año, confírmalo con Javier).
> **Si no se resuelve hoy:** la prueba queda prometida más allá del cierre y nadie ha dicho qué la bloquea. Ninguna minuta registra el motivo de las seis reprogramaciones.

> **[2] Qué bloquea «Enviar el documento 1» y qué fecha se sostiene con motivo** · 5 min · **Liliana Torres**
> Prometido para el 2026-09-29, y antes para el 10-08, 10-24, 11-10, y ahora el 2026-11-24. **Cuatro reprogramaciones.**
> Fuente: `30-reuniones/2026-09-05-comite-semanal.md` · `30-reuniones/2026-10-10-comite-semanal.md`
> **Si no se resuelve hoy:** pasa a la quinta; ya supera el umbral de 3 de la configuración.

> **[3] Qué bloquea «Revisar el anexo 3», y fecha para «Actualizar la matriz 14» (vencida) y «Confirmar la fecha 23»** · 7 min · **Beatriz Cuéllar**
> Anexo 3: prometido para el 2026-09-09, y antes para el 10-01, 10-16, 10-24, y ahora el 2026-11-01. **Cuatro reprogramaciones.** Matriz 14: vencía el 10-16; el 10-03 dijo que ya la entregó y no hay acta.
> Fuente: `30-reuniones/2026-09-05-comite-semanal.md` · `30-reuniones/2026-09-26-comite-semanal.md` · `30-reuniones/2026-10-10-comite-semanal.md`
> **Si no se resuelve hoy:** tres compromisos de la misma persona siguen sin motivo ni evidencia.

> **[4] Qué falta para «Enviar el documento 9»** · 4 min · **María Restrepo**
> Prometido para el 2026-10-01, y antes para el 10-12, 10-19, y ahora el 2026-10-27. **Tres reprogramaciones.**
> Fuente: `30-reuniones/2026-09-19-comite-semanal.md` · `30-reuniones/2026-10-10-comite-semanal.md`
> **Si no se resuelve hoy:** vence el 10-27, antes de la reunión; llega al 10-31 vencido o en cuarta reprogramación.

> **[5] Aclarar si «Revisión con el proveedor» (10-27) es «Revisar el anexo 11» (11-09), y qué cubre esa revisión** · 8 min · **Óscar Ramírez**
> Anexo 11: prometido para el 2026-10-06, y antes para el 10-17, 10-30, y ahora el 2026-11-09. **Tres reprogramaciones.** Si es el mismo compromiso que la revisión del 10-27, sería la cuarta. Además «Validar el ambiente 20» venció el 10-10: dijo que ya lo entregó y no hay acta.
> Fuente: `30-reuniones/2026-09-19-comite-semanal.md` · `30-reuniones/2026-10-10-comite-semanal.md` · `2026-10-17-notas-reunion.txt`, línea 6
> **Si no se resuelve hoy:** se cuenta dos veces o ninguna, y la revisión con el proveedor llega al 10-27 sin que se sepa si cubre los entregables vencidos (punto [5b]).

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 (21 días al 10-17) | Fecha confirmada o nueva fecha con motivo; sigue en la tabla del 10-10 con la fecha pasada | 3 |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 (7 días; reprogramado una vez desde el 09-28) | El documento de cierre o la causa | 3 |
| Ricardo Salas | Cerrar la prueba 18 (10-12) y Confirmar la fecha 15 (10-16) | 5 y 1 días | Un documento o una fecha para cada una | 4 |
| Laura Vélez | Aprobar el diseño 13 (sin fecha desde 09-26; el 10-03 dijo que ya lo entregó, sin acta) y Mandar el ajuste del presupuesto («la otra semana») | Sin fecha | Una fecha calendario para cada una; el ajuste, además, de qué es y a quién va | 4 |

Fuente: `30-reuniones/2026-09-12`, `2026-09-19`, `2026-09-26`, `2026-10-03` y `2026-10-10-comite-semanal.md`; `2026-10-17-notas-reunion.txt`, línea 5.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[10]** ¿Se hace el hito «Piloto en tiendas» (línea base 2026-10-24, pendiente)? El informe del 10-14 dice que se reprogramó el despliegue, pero no hay solicitud de cambio ni línea base nueva en el expediente | Andrés Lozano | El 10-31 el hito aparece vencido sin cambio aprobado. Fuente: `10-plan/2026-05-21-cronograma-v1.xlsx`, `20-seguimiento/2026-10-14-informe-avance.md` | 5 |
| **[11]** Dueño y proveedor del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase»: hoy está en la ficha sin dueño y sin decir cuál proveedor (CT-842 o CT-565) ni cuál es la siguiente fase | Andrés Lozano, con quien lo planteó | Sigue sin dueño; nadie lo mira hasta que ocurra. Fuente: `2026-10-17-notas-reunion.txt`, línea 7 | 4 |
| **[5b]** Qué entregables vencidos de proveedor cubre la revisión del 10-27: Licenciamiento (CT-842, 99 días), Configuración del catálogo (CT-842, 18), Licenciamiento (CT-565, 72), Bolsa de horas (CT-565, 5) | Óscar Ramírez informa; Andrés Lozano decide la ruta | Cuatro entregables vencidos sin acta de recibo. Fuente: `00-gobierno/2026-05-21-contrato-ct-842.md`, `00-gobierno/2026-05-25-contrato-ct-565.md` | (en [5]) |

Los puntos [6] a [9] son las filas de «Vencido sin evidencia», en ese orden (Céspedes, Cárdenas, Salas, Vélez); [5b] va dentro de los 8 minutos de [5]. Tiempos: 10 + 5 + 7 + 4 + 8 + 3 + 3 + 4 + 4 + 5 + 4 = **57 minutos**.

### Vence antes de la próxima
Al 10-31 estos habrán vencido o estarán cerrados con documento; no se repasan en la reunión. Si siguen abiertos el 10-30, `/pm-agenda` los sube a «Vencido sin evidencia».
| Quién | Qué | Para cuándo |
|---|---|---|
| Mauricio Pérez | Aprobar el diseño 21 | 2026-10-18 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-20 |
| Camilo Beltrán | Entregar el punto 24 | 2026-10-22 |
| Andrés Lozano | Enviar el documento 17 (reprogramado una vez desde el 10-12) | 2026-10-25 |
| Paula Céspedes | Revisar el anexo 19 | 2026-10-29 |

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Proyección de COP 8.631.313.230 contra COP 6.800.000.000 aprobados (+26,9 %), con el informe del 10-14 en verde | Excede la autoridad del gerente. El patrocinador (Jorge Medina) no aparece en las asistencias del 10-10 ni del 10-17; si va a estar el 10-31, entra | Comité, con `/pm-escalate`. El ajuste de Laura Vélez ([9]) es insumo |
| CT-565 facturado COP 723.840.453 sin ningún entregable aceptado; CT-842 facturado COP 1.197.938.594 contra COP 775.475.640 aceptados (diferencia COP 422.462.954) | Aprobar o frenar un pago no es del gerente. Fuente: `20-seguimiento/2026-09-16-factura-ct-565.pdf`, `2026-10-02-factura-ct-842.md` | Comité / patrocinador, con `/pm-escalate` |
| Felipe Arango · Entregar el punto 16 (venció el 10-16; el 10-10 dijo que ya lo entregó, sin acta) | No estuvo el 10-17; su punto es pedir un documento | Andrés Lozano se lo pide antes, por fuera |
| Tres hitos marcados «cumplido» sin documento (Diseño de la experiencia, Ambiente de pruebas, Integración con el ERP) | Es adjuntar actas, no discutir | Andrés Lozano, antes de la reunión |
| Estado «verde» del 10-14 contra 26 alertas calculadas | El estado lo declara el gerente | `/pm-report` |
| ¿La cadencia sigue semanal? La config dice semanal; las notas del 10-17 dicen «en dos semanas» | Define cuándo se vuelven a mirar los vencidos | Andrés Lozano, al convocar |

Lo pendiente de decidir de la reunión anterior: las notas del 10-17 no registran ninguna decisión ni asunto abierto, así que no entra nada por ahí.

### Anexo — sin cambios desde el 2026-10-10
- Elena Duarte · Entregar el punto 8 · 2026-11-06 (reprogramado dos veces, bajo el umbral de 3)
- Beatriz Cuéllar · Confirmar la fecha 23 · 2026-11-05 (cae en [3])
- Cerrados con documento: Validar el ambiente 4, Aprobar el diseño 5, Actualizar la matriz 6, Validar el ambiente 12

### Quién tiene que estar
Andrés Lozano, Javier Hoyos, Liliana Torres, Beatriz Cuéllar, María Restrepo, Óscar Ramírez, Paula Céspedes, Rubén Cárdenas, Ricardo Salas, Laura Vélez. No hacen falta: Elena Duarte, Mauricio Pérez, Carlos Peña, Camilo Beltrán.

### Después
Cuando termine la reunión, `/pm-minutes` sobre las notas; los compromisos que salgan entran a `/pm-commitments` con su cita. Este comando no convoca ni dirige la reunión.
