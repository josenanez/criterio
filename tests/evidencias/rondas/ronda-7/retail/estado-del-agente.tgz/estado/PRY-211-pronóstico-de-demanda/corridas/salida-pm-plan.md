# Plan — PRY-211 · Pronóstico de demanda · borrador del 2026-10-17
**Desde:** acta de constitución del 2026-05-21 (`00-gobierno/2026-05-21-acta-constitucion.docx`) · **Criterio de éxito:** «Pronóstico de demanda en producción y medido.» (sin métrica ni umbral)

> Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.
> Contexto: el proyecto ya está en ejecución (inicio 2026-05-31) y existe un cronograma v1 del 2026-05-21. Este borrador reconstruye la estructura desde el acta y los contratos; no reemplaza ni crea una línea base.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin describir:** «Componente 1, Componente 2, Componente 3» | No se puede saber qué entregables entran. La WBS por entregable no se puede bajar del acta; solo se sostienen los entregables que salen de los contratos y de los hitos del cronograma v1. |
| **Criterio de éxito sin medida:** «en producción y medido» no dice qué se mide, contra qué ni cuándo | Nadie puede aceptar el cierre ni decir si «medido» se cumplió. El entregable final queda sin criterio de aceptación. |
| **Autoridad del gerente no declarada** | No se sabe qué puede decidir quien planifica y qué hay que subir al patrocinador o al Comité Comercial. |
| **Exclusión vacía:** «Lo que otro proyecto cubre», sin decir cuál proyecto | No se sabe qué queda afuera ni quién lo cubre. |
| **Dependencias: «Ninguna declarada»**; sin embargo las notas del 2026-10-17 mencionan que el proveedor podría no llegar con el equipo completo para la siguiente fase | Un plan sin dependencias declaradas esconde la que ya se comentó en la reunión. |
| **Presupuesto sin desglose:** 6.800.000.000 COP aprobados; los dos contratos suman 4.549.583.466 COP | Quedan 2.250.416.534 COP sin destino documentado. |
| **Producto asociado: «No aplica»** | Sin producto dueño del resultado, nadie queda a cargo del pronóstico una vez en producción. |

Sí están: patrocinador (Jorge Medina), gerente (Andrés Lozano), comité (Comité Comercial), fechas de inicio (2026-05-31) y cierre (2026-11-30), presupuesto aprobado.

Se sigue marcando y no se rellena nada de lo anterior.

## WBS
Descompuesta por entregable. «Quién lo acepta»: los contratos dicen que cada entregable se factura contra acta de recibo firmada por el gerente del proyecto; eso es lo único escrito sobre aceptación.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado | sin definir (quién aprueba) | cronograma v1 (hito, 2026-07-06) | vacía |
| 2 | Ambiente de pruebas certificado | sin definir (quién certifica) | cronograma v1 (hito, 2026-08-12) | vacía |
| 3 | Integración con el ERP | sin definir | cronograma v1 (hito, 2026-09-18) | vacía |
| 4 | Piloto en tiendas | sin definir | cronograma v1 (hito, 2026-10-24) | vacía |
| 5 | Despliegue en la cadena | sin definir | cronograma v1 (hito, 2026-11-30) | vacía |
| 6 | CT-842 · Licenciamiento de la plataforma (Datos y Demanda) | Andrés Lozano (firma acta de recibo) | del contrato CT-842 (fecha 2026-07-10) | vacía |
| 7 | CT-842 · Bolsa de horas de desarrollo | Andrés Lozano | del contrato CT-842 (fecha 2026-08-19) | vacía |
| 8 | CT-842 · Configuración del catálogo | Andrés Lozano | del contrato CT-842 (fecha 2026-09-29) | vacía |
| 9 | CT-842 · Soporte del primer trimestre | Andrés Lozano | del contrato CT-842 (fecha 2026-11-08) | vacía |
| 10 | CT-565 · Licenciamiento de la plataforma (Tecnología para Tiendas) | Andrés Lozano | del contrato CT-565 (fecha 2026-08-06) | vacía |
| 11 | CT-565 · Bolsa de horas de desarrollo | Andrés Lozano | del contrato CT-565 (fecha 2026-10-12) | vacía |
| 12 | Componente 1, 2 y 3 del alcance | sin definir | del acta, sin descripción | vacía |
| 13 | Pronóstico en producción y medido (criterio de éxito) | sin definir | del acta, sin métrica | vacía |

Las fechas citadas son las de los contratos y del cronograma v1, no fechas de este plan. Las duraciones quedan vacías: ningún documento da duraciones, solo fechas de término.

## Orden
Solo dependencias, sin fechas.
- Los entregables de licenciamiento (6, 10) preceden a lo que usa la plataforma: configuración del catálogo (8) y bolsas de horas (7, 11). *Supuesto:* ningún documento lo dice.
- Ambiente de pruebas certificado (2) e integración con el ERP (3) preceden al piloto en tiendas (4), y este al despliegue en la cadena (5). *Supuesto*, por el nombre de los hitos.
- Configuración del catálogo (8) precede al piloto (4). *Supuesto.*
- Despliegue (5) precede a «en producción y medido» (13).
- Soporte del primer trimestre (9) solo tiene sentido después del despliegue (5). *Supuesto.*
- Componentes 1, 2 y 3 (12): sin definir, no se puede ordenar.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 5 hitos del cronograma v1 son los entregables del proyecto | Falta trabajo fuera de esa lista y el plan lo ignora. |
| Los Componentes 1, 2 y 3 del acta corresponden a los entregables de los contratos y los hitos | Hay alcance sin dueño ni contrato. |
| Quien acepta los entregables contractuales es el gerente (por la condición de pago), no el negocio | Se acepta sin el visto bueno de Logística. |
| El orden descrito arriba (licencia → catálogo → piloto → despliegue → soporte) | Hay rutas en paralelo o inversas y la secuencia cambia. |
| Los entregables de CT-842 y CT-565 no se solapan entre sí aunque tienen el mismo nombre (licenciamiento, bolsa de horas) | Se paga o se planifica dos veces lo mismo. |

Pasan a riesgos del proyecto (raid-taxonomy) cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Descripción de los Componentes 1, 2 y 3 | Patrocinador (Jorge Medina) / gerente |
| Qué se mide y con qué umbral para «medido» | Patrocinador / Logística |
| Autoridad del gerente al planificar | Patrocinador / Comité Comercial |
| Quién acepta cada hito del cronograma v1 | Patrocinador / gerente |
| Qué proyecto cubre lo excluido | Patrocinador |
| Destino de los 2.250.416.534 COP no cubiertos por contratos | Patrocinador / Comité Comercial |
| Dependencias reales (entre ellas la disponibilidad del equipo del proveedor) | Gerente con los proveedores |
| Producto o área que se hace cargo del pronóstico en operación | Patrocinador |

## Proyectos análogos
No hay ninguno a la vista: la configuración de PRY-211 no apunta a una carpeta de fichas de la PMO con otros proyectos. Esa es la respuesta; no se estima por analogía.

## Preguntas para el equipo
1. ¿Cuánto toma el licenciamiento de la plataforma de CT-842 y de CT-565, y están aprobados los dos o hay uno que sobra?
2. ¿Cuánto toma la configuración del catálogo y qué necesita como insumo?
3. ¿Cuánto toma cada bolsa de horas, y qué se construye con ellas?
4. ¿Cuánto toma el soporte del primer trimestre y cuándo arranca realmente?
5. ¿Cuánto toma el piloto en tiendas, y cuántas tiendas incluye?
6. ¿Cuánto toma el despliegue en la cadena, y qué significa «reprogramado» por el congelamiento de fin de año? El informe del 2026-10-14 dice que se reprogramó, pero el cronograma v1 sigue con 2026-11-30.
7. ¿Cuánto toma pasar de despliegue a «medido», y qué se mide?
8. ¿Qué son los Componentes 1, 2 y 3 y cuánto toma cada uno?
9. ¿Quién acepta cada hito y qué evidencia deja?

## Para comprometer una fecha falta
- La disponibilidad real del equipo del proyecto (ningún documento la trae).
- La fecha confirmada de cada proveedor, y si llegan con el equipo completo (las notas del 2026-10-17 dicen que podrían no llegar, sin dueño).
- La ventana de congelamiento de fin de año: el informe del 2026-10-14 la menciona, pero ningún documento dice sus fechas.
- La decisión sobre el alcance de los tres componentes.

Fuera de este comando, pero visible mientras se leía: CT-842 lleva facturados 1.197.938.594 COP con un solo entregable (775.475.640 COP) con acta de recibo en la carpeta, y CT-565 lleva facturados 723.840.453 COP sin acta de recibo. Eso es de `vendor-control`, no de este plan.

---
Este borrador no compromete ninguna fecha ni crea línea base. Si se aprueba, ofrece registrarlo como línea base original y pasar los supuestos al RAID con doliente.
