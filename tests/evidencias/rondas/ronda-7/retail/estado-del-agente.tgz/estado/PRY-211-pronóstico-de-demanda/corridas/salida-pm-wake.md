## PRY-211 · 2026-10-17

**Revisé:** 20 documentos · 20 nuevos para el índice (primer barrido) · 1 minuta (2026-10-17-notas-reunion.txt), cuyos compromisos ya estaban en la ficha desde la corrida de minutas de hoy; no extraje nada de nuevo.

### Lo que se venció solo
Siete compromisos con fecha anterior a hoy y sin acta de recibo en la carpeta (cita: ficha `records/PRY-211.json`, fuente `30-reuniones/2026-10-10-comite-semanal.md`):
- Paula Céspedes, Confirmar la fecha 7 (2026-09-26)
- Rubén Cárdenas, Cerrar la prueba 10 (2026-10-10)
- Óscar Ramírez, Validar el ambiente 20 (2026-10-10; dice que ya entregó, no presentó acta)
- Ricardo Salas, Cerrar la prueba 18 (2026-10-12)
- Beatriz Cuéllar, Actualizar la matriz 14 (2026-10-16)
- Ricardo Salas, Confirmar la fecha 15 (2026-10-16)
- Felipe Arango, Entregar el punto 16 (2026-10-16; dice que ya entregó, no presentó acta)

Reprogramados en el umbral (3 o más): Javier Hoyos, Cerrar la prueba 2 (6 veces, ahora 2026-12-03); Liliana Torres, Documento 1 (4); Beatriz Cuéllar, Anexo 3 (4); María Restrepo, Documento 9 (3); Óscar Ramírez, Anexo 11 (3).

Sin fecha: Laura Vélez (ajuste del presupuesto, «la otra semana») y Aprobar el diseño 13. Riesgo dicho en la reunión y sin registrar: el proveedor podría no llegar con el equipo completo para la siguiente fase (sin doliente).

### La reunión
Comité el 2026-10-31, a 14 días: aún no toca la agenda (se ofrece desde 1 día antes). Informe: toca el 2026-10-30.

### Tu ficha publicada
Al día: se publicó hoy y la ficha no cambió desde entonces.

**Vuelvo el 2026-10-18.**
