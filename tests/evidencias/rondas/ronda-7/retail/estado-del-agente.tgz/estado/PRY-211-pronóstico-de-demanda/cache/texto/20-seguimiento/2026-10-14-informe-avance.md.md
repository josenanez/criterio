<!-- origen: 20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Pronóstico de demanda

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **49%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.114.474.257 |
| Ejecutado | 1.539.004.991 |
| Proyección al cierre | 8.631.313.230 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
