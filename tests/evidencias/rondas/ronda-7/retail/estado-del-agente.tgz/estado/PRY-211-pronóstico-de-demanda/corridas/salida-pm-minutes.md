# Acta — Pronóstico de demanda (PRY-211) · 2026-10-17

**Asistieron (14):** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez
**Fuente:** `2026-10-17-notas-reunion.txt` (9 líneas, notas de alguien; no es transcripción)
**Ausentes con tema en agenda:** no se puede decir; las notas no traen agenda. Con compromisos abiertos y sin asistir: Felipe Arango (tiene «Entregar el punto 16», vencido) y Jorge Medina (sin compromisos abiertos). Las notas no registran que se haya hablado de ellos.

Términos: ya vigentes para la versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17; no se pidió de nuevo.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Javier Hoyos | Cerrar la prueba 2 | 2026-12-03 | **Reprogramado por 6.ª vez.** Original 2026-09-09; fechas: 09-30, 10-13, 10-29, 11-12, 11-19 y ahora 12-03. «Lo de cerrar la prueba 2 no alcanzó» (línea 4). Cae después del cierre del proyecto (2026-11-30). |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo (línea 6). Ver *Sin resolver*: puede o no ser su «Revisar el anexo 11». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dicho como «la otra semana» (línea 5); no es una fecha y no se le puso una. |

Laura Vélez ya tenía sin fecha «Aprobar el diseño 13» (2026-09-26); son dos sin fecha a su nombre.

## Decisiones
Ninguna. Las notas no registran que alguien decidiera algo.

## Quedó sin decidir
Las notas no nombran ningún asunto abierto como tal. No hay nada que registrar aquí sin inventarlo.

## Intenciones sin doliente
Ninguna en las notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase (línea 7: «nadie lo anotó como riesgo») | No identificado: las notas dicen «se comentó» | Riesgo | **No.** El RAID solo traía «Congelamiento de cambios en temporada alta». Entró a la ficha hoy, **sin dueño** (`owner: not_found`) y sin decir de cuál proveedor se trata. |

## Cerrado en esta reunión
Se omite: nada se cerró con documento.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (línea 8), es decir ~2026-10-31 | `cycle.committee: weekly`; `committee_next: 2026-10-31` | Notas 2026-10-17 · config.json. La fecha coincide; la frecuencia no. No se sabe si es una excepción o un cambio. |

Patrocinador, fecha de cierre y comité: la reunión no dijo nada distinto de la ficha.

## Sin resolver de la transcripción
- «se compromete para el 03/12/2026» (línea 4): se leyó día/mes/año (3 de diciembre). Como mes/día sería el 12 de marzo, que ya pasó, así que la lectura es casi seguro la correcta; confírmalo con Javier.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27» (línea 6): no se sabe si es el mismo compromiso que «Revisar el anexo 11» (vence 2026-11-09, ya reprogramado 3 veces) o uno nuevo. Se registró aparte; si es el mismo, sería una 4.ª reprogramación.
- «el proveedor podría no llegar con el equipo completo» (línea 7): no dice cuál proveedor (Datos y Demanda, CT-842, o Tecnología para Tiendas, CT-565), ni quién lo dijo, ni cuál es «la siguiente fase».
- «Laura Vélez queda de mandar el ajuste del presupuesto» (línea 5): no dice de qué ajuste se trata ni a quién se lo manda. El informe del 2026-10-14 proyecta COP 8.631.313.230 contra COP 6.800.000.000 aprobados (+26,9 %) y declara verde; las notas no dicen si el ajuste tiene que ver con eso.

## Lo que el recálculo de la ficha deja a la vista
- Las notas **no dicen nada** de los 7 compromisos que ya estaban vencidos (Paula Céspedes, Rubén Cárdenas, Beatriz Cuéllar, Ricardo Salas ×2, Felipe Arango, Óscar Ramírez), aunque casi todos asistieron. Siguen vencidos; que no se mencionen no los cierra.
- Con esta reunión: 5 compromisos con 3 o más reprogramaciones (Javier Hoyos 6, Liliana Torres 4, Beatriz Cuéllar 4, María Restrepo 3, Óscar Ramírez 3) y 2 sin fecha.
- La ficha sigue sin `record_issues`. Estado declarado: **verde** (2026-10-14), contra 26 alertas calculadas, de las cuales el recálculo marca 8 señales que el informe no recoge.
