# PRY-211 Pronóstico de demanda — semana del 2026-10-10 al 2026-10-17

*Sesión sin interfaz: nadie respondió preguntas. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*

**Declara el gerente (Andrés Lozano):** verde · 49 % · al 2026-10-14 (hace 3 días). Es la declaración que consta en `20-seguimiento/2026-10-14-informe-avance.md`. En esta corrida no se obtuvo una declaración nueva, porque nadie estaba para darla, y el agente no declara ni propone un estado.
**Sustento documental:** contradicho. Hay 8 señales de la evidencia que un verde no cubre, y 0 fuentes marcadas como evidencia (6 declaraciones, 227 sin marcar).
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia, avance contra plan, desviación de costo, entregables de proveedor vencidos, facturado por encima de lo aceptado, y facturado sin entrega.

## Qué cambió esta semana
Esta es la primera comparación del proyecto: no hay una corrida anterior contra la que medir, y `diff` devolvió 0 cambios. No se puede decir qué estaba y qué está. Lo que sigue es la foto de hoy, y la próxima corrida ya tendrá contra qué comparar.

## Lo que sigue igual y sigue mal
Sin corrida anterior no se sabe desde cuándo. Los días son los que miden los documentos.

| Qué | Desde (fecha comprometida) | Días así |
|---|---|---|
| Hito «Diseño de la experiencia aprobado» figura cumplido, sin evidencia | 2026-07-06 | 103 |
| Hito «Ambiente de pruebas certificado» figura cumplido, sin evidencia | 2026-08-12 | 66 |
| Hito «Integración con el ERP» figura cumplido, sin evidencia | 2026-09-18 | 29 |
| Datos y Demanda: «Licenciamiento de la plataforma» pendiente | 2026-07-10 | 99 |
| Tecnología para Tiendas: «Licenciamiento de la plataforma» pendiente | 2026-08-06 | 72 |
| Datos y Demanda: «Configuración del catálogo» pendiente | 2026-09-29 | 18 |
| Tecnología para Tiendas: «Bolsa de horas de desarrollo» pendiente | 2026-10-12 | 5 |
| Avance declarado 49 % frente a 60–80 % que sostiene el plan (3 de 5 hitos) | n/d | 11 puntos por debajo |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-11-30 | 2026-11-30 | 0 días |
| Presupuesto | COP 6.800.000.000 aprobado | COP 6.800.000.000 | proyección COP 8.631.313.230 = **+26,9 %** (umbral 10 %) |

Replanificaciones: 0. La fecha no se ha movido, pero el informe del 14 de octubre habla de que «se reprogramó el despliegue por el congelamiento de temporada», y la línea base sigue en 2026-11-30. Hay una reprogramación declarada que no consta en la línea base.

### Hitos de las próximas cuatro semanas (hasta 2026-11-14)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Piloto en tiendas (pendiente) | 2026-10-24 | 2026-10-24 | ninguna |

«Despliegue en la cadena» (2026-11-30) queda fuera de la ventana, pero es el cierre.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 2.114.474.257 (31,1 %) | 1.539.004.991 (22,6 %) | 8.631.313.230 | **4.685.525.743** (aprobado − comprometido) |

La proyección supera el aprobado en COP 1.831.313.230, aunque el disponible real parezca holgado.

## Abierto
**Reprogramados** (umbral 3):
- Javier Hoyos, «Cerrar la prueba 2»: 6 veces. Original 2026-09-09, hoy 2026-12-03.
- Liliana Torres, «Enviar el documento 1»: 4 veces. Original 2026-09-29, hoy 2026-11-24.
- Beatriz Cuéllar, «Revisar el anexo 3»: 4 veces. Original 2026-09-09, hoy 2026-11-01.
- María Restrepo, «Enviar el documento 9»: 3 veces. Original 2026-10-01, hoy 2026-10-27.
- Óscar Ramírez, «Revisar el anexo 11»: 3 veces. Original 2026-10-06, hoy 2026-11-09.

**Vencidos sin evidencia:**
- Paula Céspedes, «Confirmar la fecha 7», vencido el 2026-09-26 (21 días).
- Rubén Cárdenas, «Cerrar la prueba 10», 2026-10-10 (7 días).
- Óscar Ramírez, «Validar el ambiente 20», 2026-10-10 (7 días).
- Ricardo Salas, «Cerrar la prueba 18», 2026-10-12 (5 días).
- Beatriz Cuéllar, «Actualizar la matriz 14», 2026-10-16 (1 día).
- Ricardo Salas, «Confirmar la fecha 15», 2026-10-16 (1 día).
- Felipe Arango, «Entregar el punto 16», 2026-10-16 (1 día).

**Sin fecha:** Laura Vélez, «Aprobar el diseño 13» y «Mandar el ajuste del presupuesto».

**RAID sin movimiento:** no se puede medir. No hay corrida anterior ni fecha de revisión en los registros. Hay un riesgo sin responsable: «El proveedor podría no llegar con el equipo completo para la siguiente fase», que se dijo en reunión (notas del 2026-10-17) y nadie lo había registrado. El riesgo «Congelamiento de cambios en temporada alta» sigue abierto.

**Proveedor:**
- Datos y Demanda S.A.S. (CT-842): 4 entregables, 1 aceptado, 2 vencidos. Facturado COP 1.197.938.594 contra COP 775.475.640 aceptado: **COP 422.462.954 facturado por encima de lo aceptado.**
- Tecnología para Tiendas Ltda. (CT-565): 2 entregables, 0 aceptados, 2 vencidos. **Facturado COP 723.840.453 sin ninguna entrega aceptada.**

## Lo que necesito de alguien
- **Andrés Lozano:** declarar el estado y el avance de esta semana. La declaración vigente tiene 3 días, pero la evidencia la contradice. Dar la evidencia de los tres hitos «cumplidos» (diseño, ambiente de pruebas, ERP).
- **Laura Vélez:** poner fecha a dos compromisos.
- **Javier Hoyos:** decir qué impide cerrar la prueba 2, reprogramada 6 veces.
- **Quien apruebe pagos, con nombre pendiente de definir:** el sobrefacturado de COP 422 M a Datos y Demanda y los COP 724 M a Tecnología para Tiendas sin entrega son material de comité, no de este informe. La autoridad del proyecto no está definida en la ficha.
- **Material de comité** (no de este informe): desviación de costo de 26,9 % y compromisos reprogramados 3 o más veces.

## Lo que no se sabe
**Sin dato:** `identity.authority` (quién tiene autoridad sobre el proyecto), `identity.phase` (fase actual), `raid.risks[1].owner` (dueño del riesgo del proveedor). El producto asociado también está vacío.
**Silencio:** último documento hace 0 días (notas del 2026-10-17); último documento de seguimiento hace 3 días (informe del 2026-10-14); última reunión de comité hace 7 días (2026-10-10). Aun así, ninguna de las fuentes del estado está marcada como evidencia: solo hay declaraciones.

---
*Ficha: `records/PRY-211.json`, con corte al 2026-10-17. Van 3 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal*
