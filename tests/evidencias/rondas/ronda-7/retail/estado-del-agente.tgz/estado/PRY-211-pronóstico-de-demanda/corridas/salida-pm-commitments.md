## Compromisos — PRY-211 Pronóstico de demanda · al 2026-10-17

22 compromisos abiertos: 5 reprogramados 3 veces o más, 7 vencidos sin evidencia, 2 sin fecha. Cerrados con documento: 4. Las cifras salen de `portafolio.py compute`.

### Se viene reprogramando

> **Javier Hoyos** · Cerrar la prueba 2
> Prometido para el 2026-09-09, y antes para el 09-30, 10-13, 10-29, 11-12, 11-19, y ahora el 2026-12-03. **Seis reprogramaciones en siete semanas.**
> Las notas del 17-oct dicen «03/12/2026»; se leyó día/mes/año (3 de diciembre).

> **Liliana Torres** · Enviar el documento 1
> Prometido para el 2026-09-29, y antes para el 10-08, 10-24, 11-10, y ahora el 2026-11-24. **Cuatro reprogramaciones.**

> **Beatriz Cuéllar** · Revisar el anexo 3
> Prometido para el 2026-09-09, y antes para el 10-01, 10-16, 10-24, y ahora el 2026-11-01. **Cuatro reprogramaciones.**

> **María Restrepo** · Enviar el documento 9
> Prometido para el 2026-10-01, y antes para el 10-12, 10-19, y ahora el 2026-10-27. **Tres reprogramaciones.**

> **Óscar Ramírez** · Revisar el anexo 11
> Prometido para el 2026-10-06, y antes para el 10-17, 10-30, y ahora el 2026-11-09. **Tres reprogramaciones.**

**Cinco compromisos con tres o más reprogramaciones no son un problema de seguimiento: son bloqueos que nadie ha nombrado.** Ninguna minuta registra el motivo de las reprogramaciones; este comando no lo juzga.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-26 | 21 días (sigue en la tabla del 10-10 con la misma fecha; ninguna minuta la reprogramó) |
| Rubén Cárdenas | Cerrar la prueba 10 | 2026-10-10 | 7 días (reprogramado una vez, desde el 09-28) |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-10 | 7 días (el 10-10 dijo que ya lo entregó; no hay acta) |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-12 | 5 días |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-16 | 1 día (el 10-03 dijo que ya lo entregó; no hay acta) |
| Ricardo Salas | Confirmar la fecha 15 | 2026-10-16 | 1 día |
| Felipe Arango | Entregar el punto 16 | 2026-10-16 | 1 día (el 10-10 dijo que ya lo entregó; no hay acta) |

En tres casos la persona dijo que ya entregó y nada en el expediente lo respalda; siguen abiertos hasta que haya un documento.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Mauricio Pérez | Aprobar el diseño 21 | 2026-10-18 |
| Carlos Peña | Actualizar la matriz 22 | 2026-10-20 |
| Camilo Beltrán | Entregar el punto 24 | 2026-10-22 |

Justo después: Andrés Lozano (gerente) · Enviar el documento 17 · 2026-10-25, ya reprogramado una vez desde el 10-12.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Aprobar el diseño 13 | 2026-09-26 (el 10-03 dijo que ya lo entregó; sin acta; dejó de aparecer en la tabla) |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-17 («la otra semana», que no es una fecha) |

No pueden estar vencidos, y por eso mismo no aparecen en ningún informe. Los dos son de la misma persona.

### Cerrados con documento
| Quién | Qué | Documento |
|---|---|---|
| Natalia Ospina | Validar el ambiente 4 | `20-seguimiento/2026-10-10-acta-recibo-4.md` |
| Felipe Arango | Aprobar el diseño 5 | `20-seguimiento/2026-10-03-acta-recibo-5.md` |
| Jorge Medina | Actualizar la matriz 6 | `20-seguimiento/2026-10-03-acta-recibo-6.md` |
| Diana Molina | Validar el ambiente 12 | `20-seguimiento/2026-10-10-acta-recibo-12.md` |

### Nota aparte
Óscar Ramírez tiene «Revisión con el proveedor» para el 2026-10-27 (notas del 10-17). No se sabe si es el mismo compromiso que «Revisar el anexo 11»; se registra aparte.

### Lo que sigue
- Los cinco reprogramados ≥3 veces superan el umbral de la configuración (3). Ofrezco formular el de Javier Hoyos (seis veces) como decisión para el comité: qué se pide, qué pasa si no se decide y quién tiene la facultad.
- El informe de avance del 10-14 declara el proyecto en verde con siete compromisos vencidos y cinco reprogramados. Si quieres que la PMO lo vea, `/pm-publish`.
