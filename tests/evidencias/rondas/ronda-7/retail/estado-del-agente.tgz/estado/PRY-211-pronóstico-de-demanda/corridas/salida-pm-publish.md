Publiqué la ficha en `documentos/proyectos/PRY-211-pronóstico-de-demanda/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 171 campos con dato · 3 sin decir en ninguna parte (identity.authority, identity.phase, raid.risks[1].owner) · declara **verde** al 2026-10-14

**Lo más viejo que va ahí:** los campos del acta de constitución y del cronograma v1, del 2026-05-21 — menos de un año.

**Antes de publicar:**
- Recalculé la ficha hoy (`compute`). `plan.end_date` = 2026-11-30, tomada del último hito del único cronograma vigente (v1); coincide con la línea base original, sin replanificaciones.
- Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

**Ojo con lo que la PMO va a ver:** la declaración es **verde**, pero la ficha trae 26 señales que el informe no recoge: avance declarado 49 % contra 60–80 % que sustenta el plan; 3 hitos «cumplidos» sin evidencia; proyección de costo 26,9 % sobre lo aprobado; 7 compromisos vencidos y 5 reprogramados; entregables de proveedor atrasados; facturación por encima de lo aceptado (Datos y Demanda S.A.S.) y facturación sin entrega (Tecnología para Tiendas Ltda.). La declaración sigue siendo tuya y va marcada como declarada.
