# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 48 s · 26 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 7 |
| `commitment_rescheduled` | 5 |
| `vendor_deliverable_late` | 4 |
| `milestone_met_without_evidence` | 3 |
| `commitment_undated` | 2 |
| `progress_vs_plan` | 1 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `declared_vs_evidence` | 1 |

Paquete de decisión sobre la ampliación de presupuesto (+26,9 %) y el punto previo de autoridad no declarada en el acta. No se corrió impact: ninguna opción mueve fecha y el estado solo tiene este proyecto. No se sabe qué puede decidir el gerente, cómo se calculó la proyección, ni el costo de recortar alcance.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-211 Pronóstico de demanda · 2026-10-17

*Sesión sin interfaz: nadie respondió preguntas. No se indicó qué escalar; se tomó lo ya marcado como escalable en la corrida de informe (`corridas/salida-pm-report.md`). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).*

### Primero: el acta no declara la autoridad del gerente

El acta de constitución del 2026-05-21 no dice qué puede decidir Andrés Lozano (ni en presupuesto, ni en fechas, ni en pagos). Tampoco declara dependencias («Ninguna declarada»). La ficha tiene `identity.authority` vacío. **Este es el primer punto que escala**, porque sin él no se puede decir si lo que sigue excede o no la autoridad del gerente. Lo que pido es una frase del Comité Comercial o del patrocinador (Jorge Medina): qué monto y qué desvío de fecha puede decidir el gerente sin subir.

### ¿Se aprueba hoy ampliar el presupuesto de COP 6.800.000.000 a COP 8.631.313.230 (+COP 1.831.313.230, +26,9 %)?

**Quién decide:** no consta en el acta. Quien aprobó el presupuesto fue el Comité Comercial el 2026-05-21; por eso es el candidato, pero es una inferencia mía, no una facultad escrita. **Si no se decide hoy:** el próximo comité es el 2026-10-31 (14 días); el piloto en tiendas vence el 2026-10-24, antes de esa fecha, y el entregable «Soporte del primer trimestre» de CT-842 (COP 775.475.640) vence el 2026-11-08. Un punto que no se decide hasta el 31 llega a esa fecha de entrega sin presupuesto resuelto. Más allá de eso, el documento no dice qué se pierde por esperar (no hay una oferta con vencimiento ni una penalidad en los contratos que leí).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ampliar a 8.631.313.230 | Se mantiene | Cierre 2026-11-30 sin cambio declarado | +COP 1.831.313.230 sobre lo aprobado |
| B. Mantener 6.800.000.000 y recortar alcance | **No calculable**: el acta describe el alcance como «Componente 1, 2 y 3» sin contenido | **No calculable** | Tope COP 6.800.000.000; lo que se recorta no se puede valorar |

**Recomiendo:** responder **no a A hoy**, y pedir que el comité decida el 2026-10-31 con el ajuste que Laura Vélez quedó de mandar «la otra semana» (compromiso sin fecha). Razón: la proyección de COP 8.631 M se apoya en declaraciones, sin ninguna fuente marcada como evidencia, y hay COP 1.146 M facturados sin entrega aceptada (abajo) que pueden mover la cifra en cualquier dirección. Para que ese plazo sea real, el compromiso de Laura necesita fecha: sugiero el 2026-10-24.

### Lo que el gerente puede resolver sin comité

Esto no se escala; es de quien firma las actas de recibo. Según ambos contratos, cada entregable se factura contra acta de recibo firmada por el gerente del proyecto.
- **CT-565 (Tecnología para Tiendas):** facturado COP 723.840.453, 0 entregables aceptados.
- **CT-842 (Datos y Demanda):** facturado COP 1.197.938.594 contra COP 775.475.640 aceptado, o sea COP 422.462.954 por encima.

Qué hay que hacer: mostrar las actas que sustentan esas facturas, o no firmar más. Quién aprobó el pago no consta en lo que leí.

### A quién alcanza
No se calculó con `impact`: ninguna de las opciones mueve una fecha del proyecto (el cierre queda en 2026-11-30), y el estado solo tiene este proyecto, por lo que no hay otros proyectos ni gerentes que cruzar. La ficha no declara dependencias con otros proyectos; que la lista esté vacía puede ser una omisión del acta, no una ausencia real. Tampoco se estima cuánto se movería cada proyecto alcanzado.

### Mis hitos por los que pasa
Ninguno cambia de fecha con esta decisión. Cerca de ella están «Piloto en tiendas» (2026-10-24, pendiente, sin evidencia) y «Despliegue en la cadena» (2026-11-30).

### De dónde sale esto
- Presupuesto aprobado, comité, fechas, «Dependencias: Ninguna declarada» y ausencia de autoridad: `00-gobierno/2026-05-21-acta-constitucion.docx`.
- Proyección, comprometido, ejecutado, facturado y estado de hitos y entregables: `estado/PRY-211-pronóstico-de-demanda/records/PRY-211.json` (corte 2026-10-17), construido desde el informe `20-seguimiento/2026-10-14-informe-avance.md`.
- Condición de pago y fechas de entrega: `00-gobierno/2026-05-21-contrato-ct-842.md` y `00-gobierno/2026-05-25-contrato-ct-565.md`.
- Compromiso de Laura Vélez («mandar el ajuste del presupuesto la otra semana») y «próxima reunión en dos semanas»: `2026-10-17-notas-reunion.txt`.

### Lo que no sé
- Qué puede decidir el gerente, y quién aprueba pagos.
- Con qué se calculó la proyección de COP 8.631 M.
- Cuánto cuesta recortar alcance (el alcance no está descrito).
- Qué pasa con el piloto si no hay decisión antes del 24.
