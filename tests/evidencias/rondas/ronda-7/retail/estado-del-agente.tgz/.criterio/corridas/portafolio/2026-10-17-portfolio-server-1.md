# Corrida · 2026-10-17-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:04:29 · **Fin:** 2026-10-17T16:05:13 · **Duración:** 45 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 61 | puerto 8787, informe en reportes/, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Rostrum está corriendo en **http://127.0.0.1:8788/**, en modo «rato». Solo se ve desde este equipo.

- **Puerto:** el 8787 ya lo ocupaba otro servidor. Ese otro servidor sirve un portafolio distinto, con productos como ahorro a la vista y microcrédito. El de este portafolio usa el 8788, y lo comprobé con `/estado.json`. Registré la corrida antes de esta corrección, así que su nota dice 8787. El archivo de salida ya dice 8788.
- **Términos:** ya estaban vigentes. Los aceptó José Francisco Ñáñez el 2026-10-17, así que no hubo que registrar nada.
- **Modo:** nadie pudo contestar la pregunta de las dos formas. Tomé la sugerida, que es empezar por «para mirarlo un rato».
- **Qué hay:**
  - La portada y `/pmo`.
  - `/decisiones`.
  - `/proyectos`, con 13 proyectos (PRY-199 a PRY-211).
  - `/productos`, con 7 productos.
  - `/corridas`, con 32 corridas.
  - Hay 0 peticiones abiertas.
- **Qué no hace:** no calcula nada, solo sirve el informe ya generado. Tampoco escribe fichas, no autentica y no manda correos.
- **A quién pasarle el enlace:** a nadie. Un patrocinador no puede abrir 127.0.0.1. Para darle un enlace estable hay que pasar a «que quede corriendo», con `--abierto` y un host y puerto dentro de la red. La organización debe publicarlo detrás de su control de acceso, porque el servidor no autentica.
- **Cuándo se desactualiza:** el informe es del 2026-10-17. Se desactualiza cuando cambien las fichas o se vuelva a correr `/portfolio-report html`. La portada muestra su fecha.
- **Cómo pararlo:** al estar en segundo plano no hay Ctrl-C. Se para terminando su proceso, por ejemplo con `pkill -f "servidor.py"`. Ese comando mataría también cualquier otro servidor.py que esté corriendo.

La salida completa quedó en `estado/corridas/salida-portfolio-server.md`.
