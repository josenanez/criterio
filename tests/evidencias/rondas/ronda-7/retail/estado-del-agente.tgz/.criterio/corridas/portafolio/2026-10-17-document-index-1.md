# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:47:19 · **Fin:** 2026-10-17T15:48:01 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 29 | 61 | 80 documentos, 0 por releer. 171 campos de PRY-211 con cita que no resuelve aunque los archivos existen en disco; causa no determinada. |

Por señal (`document-index`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 80 · **Sin cambio:** 80 · **Hay que releer:** 0

No cambió ningún documento. No hay renombrados, borrados, reguardados ni formatos ilegibles. Por eso no ofrezco un `/portfolio-scan`: `projects_to_recompute` está vacío.

**Citas que dejaron de resolver.** El índice marca 171 campos de la ficha de **PRY-211** (pronóstico de demanda). Citan 14 documentos: el acta de constitución, el cronograma, el informe de avance, los contratos CT-842 y CT-565, sus dos facturas, las notas del 17-oct y las 6 actas del comité.

Esto no es un borrado. Los 14 archivos existen en `documentos/proyectos/PRY-211-pronóstico-de-demanda/`. El nombre de la carpeta coincide con el de la ficha, y los dos están normalizados igual. No sé la causa y no la investigué más allá de eso. Las otras 12 fichas no tienen citas rotas. Conviene revisar esas citas antes de confiar en la ficha de PRY-211.

**Términos.** Ya estaban vigentes: la versión 1.1 fue aceptada por José Francisco Ñáñez el 2026-10-17. No los registré de nuevo.

**Corrida registrada** como `2026-10-17-document-index-1`: duró 29 s. El resultado completo está en `estado/corridas/salida-document-index.md`.

La corrida también quedó con 61 señales abiertas sobre las fichas existentes, 26 de ellas en PRY-211. Este comando no las produce ni las revisa.
