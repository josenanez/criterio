# Corrida · 2026-10-17-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-211

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-211

**Inicio:** 2026-10-17T15:53:06 · **Fin:** 2026-10-17T15:54:06 · **Duración:** 60 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 47 | 61 | Cruce contrato/acta/factura de PRY-211 (CT-842, CT-565): 4 entregables vencidos sin acta; CT-842 facturado 422.462.954 COP sobre lo aceptado; CT-565 facturado 723.840.453 COP sin ningún entregable aceptado. Dije que no sé: vigencia, renovación y preaviso de ambos contratos (no están en la carpeta), desglose de las facturas y si se pagaron. |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Proveedores de PRY-211:** hay dos facturas radicadas por pagar contra entregables sin acta de recibo, y el proyecto se declara en verde. El informe del 2026-10-14 no menciona a los proveedores.

**Datos y Demanda (CT-842)**
- Solo la bolsa de horas tiene acta de recibo, del 2026-08-20, por 775.475.640 COP.
- La factura FV-1842, del 2026-10-02, es por 1.197.938.594 COP. Eso deja 422.462.954 COP facturados sin acta que los respalde.
- Licenciamiento de la plataforma está vencido hace 99 días y Configuración del catálogo hace 18, ambos sin acta.

**Tecnología para Tiendas (CT-565)**
- No tiene ningún entregable aceptado.
- La factura FV-2565, del 2026-09-16, es por 723.840.453 COP, el monto exacto de un entregable. La emitió antes de que venciera la bolsa de horas, el 2026-10-12.
- Licenciamiento está vencido hace 72 días y la bolsa de horas hace 5.

**Lo que no puedo decir**
- **Contratos:** vigencia, renovación y preaviso de ambos, porque los contratos de la carpeta solo traen la tabla de entregables. No sé si hay un preaviso por vencer.
- **Facturas:** no traen desglose por entregable y no sé si ya se pagaron.
- **Compromisos:** ninguna minuta nombra a los proveedores, así que no hay compromisos de proveedor vencidos. Las notas del 2026-10-17 dicen que el proveedor podría no llegar con el equipo completo, sin decir cuál y sin que nadie lo registrara como riesgo.

Propongo llevar las dos facturas a comité antes de que se paguen, y pedir los contratos completos. Si quieres, preparo ese paquete con `/criterio-portfolio:steering-pack PRY-211`.

**Registro de la corrida**
- **Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no registré nada nuevo.
- **Corrida:** quedó registrada como `2026-10-17-vendor-tracking-1`, con 47 segundos medidos.
- **Salida:** `estado/corridas/salida-vendor-tracking.md` es el informe completo, con la sección de lo que no se sabe.
- **Señales:** el registro cuenta 61 señales abiertas de todo el portafolio. Las 26 de PRY-211 incluyen las dos de proveedores (`vendor_invoiced_over_accepted` y `vendor_invoiced_without_delivery`).
