# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-17T15:58:11 · **Fin:** 2026-10-17T15:58:57 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 29 | 61 | Revisión del acta de PRY-200 (2026-04-10): faltan autoridad del gerente, objetivo medible, alcance nombrado, exclusiones concretas, criterio de éxito medible, supuestos, restricciones, hitos y cadencia. No sé si esos campos existen fuera del acta, el motivo del rojo, ni si las cifras financieras declaradas coinciden con contratos y facturas. |

Por señal (`project-charter`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Estoy cerrando la revisión del acta de PRY-200. La corrida ya quedó registrada (`2026-10-17-project-charter-1`), así que lo que sigue es resumirte el resultado.

## Acta — PRY-200 Tienda en línea
**Acta previa:** sí existe, del 2026-04-10, aprobada por el Comité de Transformación Digital. Modo: revisar. Los términos (v1.1) ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hubo que registrar nada.

### Qué falta y qué consecuencia tiene
| Campo | Consecuencia |
|---|---|
| **Autoridad del gerente** (no está) | No se sabe hasta qué monto ni qué cambio puede decidir Andrés Lozano sin comité. Con el proyecto en rojo, todo ajuste sube al Comité de Transformación Digital. |
| **Objetivo de negocio** | Dice "Entregar tienda en línea para Mercadeo", que es la solución y no un resultado. Sin resultado no se puede saber si funcionó ni qué recortar primero. |
| **Alcance** | Son "Componente 1, 2, 3" sin nombre. El 39% de avance reportado no tiene contra qué compararse. |
| **Exclusiones** | Dicen "lo que otro proyecto cubre" sin nombrar el proyecto. La frontera queda sin dueño. |
| **Criterio de éxito** | "En producción y medido", sin métrica, meta ni responsable. El cierre no se puede disputar con evidencia. |
| **Supuestos y restricciones** | No están. Nada llega al registro RAID. |
| **Dependencias** | "Ninguna declarada". No es creíble para una tienda en línea, y el informe ya menciona al área de seguridad. |
| **Hitos y cadencia** | Solo hay inicio y cierre. No hay línea base contra la cual medir atraso. |

Patrocinador (Paula Céspedes), gerente, comité, presupuesto (4.200.000.000 COP) y fechas están en el acta y no tienen hallazgo.

### Contexto del informe del 2026-10-14 (cifras declaradas por el gerente)
- **Estado y avance:** el gerente declara rojo con 39% de avance.
- **Gasto ejecutado:** 52,7% del aprobado, por delante del avance declarado.
- **Gasto comprometido y proyección:** 79,7% comprometido, y la proyección al cierre es el 99,7% del aprobado.
- **Tiempo transcurrido:** 46,8% (177 de 378 días), también por delante del 39%.
- **Riesgo abierto:** la concentración del conocimiento en una persona, sin dueño ni valoración.

### Después
- **Autoridad del gerente:** conviene llevar esa definición al comité como una decisión.
- **Supuestos y riesgo sin valorar:** pasarlos a `/raid-log`. Ambos quedan ofrecidos, no ejecutados.

### Lo que no sé
- No sé si alguno de estos campos está definido en otro documento o se acordó en reuniones. En la carpeta solo hay el acta y el informe de avance.
- No sé por qué el proyecto está en rojo; el informe solo menciona un ajuste del plan de pruebas.
- No verifiqué el 39% ni las cifras financieras contra contratos o facturas.

El texto completo quedó en `estado/corridas/salida-project-charter.md`. El registro de la corrida mostró 0 hallazgos de señales para PRY-200 y 61 en el portafolio de 13 proyectos, que esta revisión no analizó.
