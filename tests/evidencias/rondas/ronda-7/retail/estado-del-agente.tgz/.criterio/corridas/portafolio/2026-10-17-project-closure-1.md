# Corrida · 2026-10-17-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-17T15:59:02 · **Fin:** 2026-10-17T15:59:58 · **Duración:** 55 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 41 | 61 | Cierre de PRY-204: no se puede determinar el criterio de éxito (en producción y medido); 2 de 4 hitos sin acta de recibo, +10,8% de costo proyectado, estado verde contradicho por 4 señales, RAID sin doliente. Dije que no sé: cumplimiento del criterio, fecha real de cierre, alcance por componente, puntos 10 y 19. No archivé el proyecto. |

Por señal (`project-closure`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Terminé el cierre de PRY-204 y lo dejé registrado como corrida. La documentación no sostiene que el proyecto haya terminado, así que lo que se puede cerrar es solo una parte.

- **Términos:** ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.
- **Criterio de éxito:** el acta dice "Cajas de autopago en producción y medido". No hay ningún documento de puesta en producción ni de medición, y el informe del 2026-10-09 dice que el despliegue se reprogramó. Por eso el cumplimiento queda como "no se puede determinar".
- **Hitos:** solo 2 de los 4 tienen acta de recibo: el diseño y el ambiente de pruebas. Integración con el ERP y Piloto en tiendas figuran "cerrados" en el cronograma sin evidencia de recibo.
- **Fecha:** el script da 0 días de desviación y 0 replanificaciones registradas, pero no lo considero confiable. El despliegue se reprogramó sin cronograma nuevo en la carpeta, y no hay fecha real de terminación.
- **Presupuesto:** la proyección declarada es 4.652.440.352 COP contra 4.200.000.000 aprobados, que es +10,8 % (el umbral es 10 %). El ejecutado va en 47,8 % y es una cifra declarada, sin soporte contable.
- **Estado declarado:** el informe dice verde y 58 %, pero cuatro señales lo contradicen.
- **RAID:** ningún ítem abierto tiene doliente con nombre, salvo dos compromisos de comité cuyos "puntos 10 y 19" no se identifican en ningún documento. El del punto 10 lleva 4 días vencido. Por eso el proyecto no está cerrado en este punto.
- **Archivo:** no moví la carpeta a `archivo/` ni congelé la ficha. Si el patrocinador, Carlos Peña, quiere cerrarlo por decisión, esa decisión la toma él.
- **Corrida:** quedó registrada como `2026-10-17-project-closure-1`.

El acta de cierre completa, con el detalle de lecciones y de lo que no se pudo determinar, está en `estado/corridas/salida-project-closure.md`.
