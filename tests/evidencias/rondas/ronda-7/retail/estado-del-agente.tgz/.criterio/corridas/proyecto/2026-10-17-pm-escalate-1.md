# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:37:05 · **Fin:** 2026-10-17T15:38:10 · **Duración:** 64 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 48 | 26 | Paquete de decisión sobre la ampliación de presupuesto (+26,9 %) y el punto previo de autoridad no declarada en el acta. No se corrió impact: ninguna opción mueve fecha y el estado solo tiene este proyecto. No se sabe qué puede decidir el gerente, cómo se calculó la proyección, ni el costo de recortar alcance. |

Por señal (`pm-escalate`): `commitment_overdue` 7, `commitment_rescheduled` 5, `vendor_deliverable_late` 4, `milestone_met_without_evidence` 3, `commitment_undated` 2, `progress_vs_plan` 1, `variance_cost` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de decisión de PRY-211 y registré la corrida. No hubo preguntas que responder: los términos ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17. Como no indicaste qué escalar, tomé lo marcado como escalable en el informe de la corrida anterior.

- **Primero escala la autoridad.** El acta del 2026-05-21 no dice qué puede decidir Andrés Lozano, y tampoco declara dependencias. Pido una frase del Comité Comercial o del patrocinador, Jorge Medina, que fije qué monto y qué desvío de fecha puede decidir el gerente sin subir.
- **La decisión es una pregunta de sí o no.** ¿Se aprueba hoy ampliar el presupuesto de COP 6.800.000.000 a COP 8.631.313.230 (+26,9 %, +COP 1.831.313.230)?
  - **Recomiendo no a la ampliación hoy.** Que el comité decida el 2026-10-31 con el ajuste que Laura Vélez quedó de mandar. Ese compromiso no tiene fecha; sugiero el 2026-10-24.
  - **Razón:** la proyección se apoya en declaraciones, sin evidencia marcada, y hay COP 1.146 M facturados sin entrega aceptada.
  - **Quién decide:** el acta no lo dice. Propongo al Comité Comercial porque aprobó el presupuesto, pero es una inferencia mía.
  - **Si no se decide hoy:** el piloto en tiendas vence el 2026-10-24 y el entregable «Soporte del primer trimestre» de CT-842 (COP 775.475.640) vence el 2026-11-08, ambos antes o justo después del comité del 31. Los contratos que leí no dicen qué se pierde por esperar más allá de eso.
- **Las dos opciones.** A es ampliar el presupuesto. B es mantener COP 6.800 M y recortar alcance; su costo y su efecto en el tiempo no se pueden calcular, porque el acta describe el alcance solo como «Componente 1, 2 y 3».
- **No escala, lo resuelve el gerente.** Las facturas sin acta de recibo:
  - **CT-565:** COP 723.840.453 facturados sin ningún entregable aceptado.
  - **CT-842:** COP 422.462.954 por encima de lo aceptado.
  - Cada contrato factura contra un acta que firma el gerente, así que le toca mostrar las actas o dejar de firmar.
- **No corrí `impact`.** Ninguna opción mueve una fecha, y el estado solo tiene este proyecto, así que no hay otros proyectos ni gerentes que cruzar.
- **Lo que no sé:** qué puede decidir el gerente, quién aprueba los pagos, con qué se calculó la proyección de COP 8.631 M y qué pasa con el piloto si no hay decisión antes del 24.

Archivos en `estado/PRY-211-pronóstico-de-demanda/corridas/`:
- `salida-pm-escalate.md`

La corrida quedó registrada con el id `2026-10-17-pm-escalate-1`.
