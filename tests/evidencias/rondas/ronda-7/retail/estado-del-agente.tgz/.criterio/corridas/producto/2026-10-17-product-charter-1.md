# Corrida · 2026-10-17-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4900

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4900

**Inicio:** 2026-10-17T15:26:32 · **Fin:** 2026-10-17T15:27:23 · **Duración:** 51 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 13 | — | 35 | 32 | Borrador de acta para REQ-4900; ficha no creada (sin firma). Declaró vacíos: decisor de la aceptación, autoridad, criterio de éxito verificable, evidencia vigente, patrocinador, país para lo normativo. |

Por señal (`product-charter`): `requirement_untraced` 9, `evidence_stale` 9, `requirement_accepted_without_evidence` 4, `requirement_undecided` 4, `requirement_without_owner` 2, `requirement_without_acceptance` 2, `assumption_unverified` 1, `claim_vs_metric` 1

## Lo que el agente mostró

Dejé listo el borrador del acta de REQ-4900 (PRD-309, Tarjeta de la tienda). No creé la ficha del proyecto porque el acta no está firmada, y no escribí el estado declarado.

La corrida quedó registrada. El acta completa está en `estado-producto/PRD-309/corridas/salida-product-charter.md`.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.

REQ-4900 cumple las cuatro condiciones solo a medias. Como nadie podía responder, seguí adelante marcando cada falta como vacío del acta y sin rellenar nada:

- **Aceptación:** el requerimiento figura «aceptado» desde 2026-05-12, pero el registro no dice quién lo decidió. El único asistente al comité del 2026-10-13 fue Diana Molina.
- **Criterio de aceptación:** dice solo «se verifica en producción», sin métrica, umbral ni responsable. Tampoco hay criterio de éxito del producto en ningún documento.
- **Evidencia de demanda:** una sola entrevista de 2025-08-24, de hace 13 meses, que no nombra a Hogares ni la tarjeta.
- **Autoridad:** no está declarada. «Comité de producto» es solo una propuesta por defecto.

Otros vacíos que quedaron marcados en el acta:
- No hay patrocinador, presupuesto ni hitos.
- Los supuestos que se llevan al proyecto (proveedor, volumen mensual, interés de Hogares) quedan sin doliente para el riesgo.
- Falta el país para el barrido normativo, así que no cito ninguna norma.
- Los otros 12 requerimientos quedan fuera solo porque no se pidieron en esta invocación; su razón de fondo no está en ningún documento.

Antes de firmar conviene cerrar al menos quién decide y qué autoridad tiene el gerente. Después, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.
