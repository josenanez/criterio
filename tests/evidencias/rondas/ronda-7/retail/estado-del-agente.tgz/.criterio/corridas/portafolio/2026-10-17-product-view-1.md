# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view venta en línea

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:01:52 · **Fin:** 2026-10-17T16:02:29 · **Duración:** 36 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 22 | 61 | Producto con un solo proyecto (PRY-200), sin alertas calculadas; declarado en rojo sin causa visible y sin datos con evidencia. Seis proyectos sin producto declarado. No se leyeron documentos fuente; el área dueña no sale del cálculo. |

Por señal (`product-view`): `milestone_met_without_evidence` 13, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 5, `commitment_rescheduled` 5, `variance_cost` 4, `vendor_deliverable_late` 4, `commitment_undated` 3, `variance_time` 2, `rebaseline_unauthorized` 2, `change_without_baseline` 1, `milestone_overdue` 1, `budget_committed` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**«Venta en línea» tiene un solo proyecto, PRY-200 Tienda en línea, y no tiene alertas calculadas.** Con un solo proyecto la vista por producto no aporta nada, así que no armé sección de producto.

Las cifras salen de las fichas del portafolio «Portafolio retail», calculadas al 2026-10-17. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo nada que registrar.

- **Fecha comprometida:** 2027-05-03, sale de PRY-200. No hay atraso contra la línea base original ni la vigente, ni replanificaciones. Tampoco hay compromisos vencidos.
- **Dinero (COP):**

  | Concepto | Monto | % de lo aprobado |
  |---|---|---|
  | Aprobado | 4.200.000.000 | |
  | Comprometido | 3.347.036.665 | 79,7 % |
  | Ejecutado | 2.214.748.739 | 52,7 % |
  | Proyección | 4.185.311.326 | −0,3 % sobre lo aprobado |

  Trae las cuatro cifras, así que la suma está completa.
- **Dependencias:** no hay dependencias internas ni con otros productos.

**Tres cosas que sí conviene mirar:**
1. **El gerente declara el proyecto en rojo** (informe del 2026-10-14, avance declarado 39 %), pero el cálculo no encuentra ninguna señal que lo explique. Vale la pena preguntarle qué lo motiva.
2. **Ningún dato de la ficha tiene evidencia:** 0 con evidencia, 3 de declaración y 12 sin marcar. Que no haya alertas significa que no hay nada contra qué contradecir lo declarado, no que esté sustentado.
3. **A la ficha le faltan** `identity.authority` (quién aprueba) y `identity.phase`.

**Proyectos sin producto declarado:** seis (PRY-202, 203, 206, 209, 210 y 211). El cálculo no da el área dueña, así que no la escribí. Es un hallazgo de gobierno, porque nadie puede responder por el conjunto al que sirven. PRY-199 declara «PRD-299», un código y no un producto con nombre.

No leí documentos fuente; todo sale de las fichas. Lo que se habló fuera de los documentos no lo sé.

**Corrida registrada:** `2026-10-17-product-view-1`, 22 segundos sobre 13 proyectos. La salida completa quedó en `estado/corridas/salida-product-view.md`.
