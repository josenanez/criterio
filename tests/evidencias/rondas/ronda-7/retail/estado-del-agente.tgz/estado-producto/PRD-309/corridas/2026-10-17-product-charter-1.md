# Corrida del 2026-10-17 · product-charter

PRD-309 · 13 requerimientos · 35 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 2 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4900; ficha no creada (sin firma). Declaró vacíos: decisor de la aceptación, autoridad, criterio de éxito verificable, evidencia vigente, patrocinador, país para lo normativo.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Tarjeta de la tienda (REQ-4900) · borrador del 2026-10-17
**Producto:** PRD-309 · Tarjeta de la tienda · **Requerimientos:** REQ-4900

Términos: vigentes y ya aceptados por José Francisco Ñáñez el 2026-10-17 (v1.1, familia 0.3.13); no hizo falta registrarlos de nuevo.

## Antes de redactar: qué hay con qué
| Condición | Estado | Cita |
|---|---|---|
| Aceptado, no propuesto | **Sí en el registro, pero sin decisor nombrado.** Estado «aceptado» desde 2026-05-12; el acta del comité no dice quién decidió y el único asistente fue Diana Molina. | `30-decisiones/2026-10-13-comite-producto.docx` |
| Criterios de aceptación verificables | **Presente, pero no verificable.** Dice solo «se verifica en producción»: no dice qué se mide, con qué umbral ni quién lo verifica. | `30-decisiones/2026-10-13-comite-producto.docx` |
| Evidencia de demanda con cita | **Débil y vieja.** Una entrevista (2025-08-24, 13 meses): «Lo necesito y hoy no lo tengo.» No nombra el segmento Hogares ni la tarjeta; un solo entrevistado. | `10-descubrimiento/2025-08-24-entrevistas.md` |
| Autoridad declarada en la definición | **No.** «Comité de producto» es una propuesta por defecto; ningún documento dice qué puede decidir el gerente. | `producto.json` (nota de `identity.authority`) |

Se sigue sin ellos, como pide el comando, y cada uno queda marcado como vacío del acta; no se rellenó nada.

## Qué problema resuelve
«El segmento Hogares no tiene tarjeta de la tienda.» (`00-definicion/2026-07-12-definicion-producto.docx`, 2026-07-12.) El requerimiento REQ-4900 no trae necesidad propia: su campo «necesidad» no se encontró en ningún documento. Su título es solo «Requerimiento REQ-4900»; el acta no puede decir qué construye en concreto.

## Criterio de éxito
- Del requerimiento: «se verifica en producción» (`30-decisiones/2026-10-13-comite-producto.docx`, 2026-10-13). **Cómo se verifica: no está dicho.** Sin métrica, umbral ni fecha, el cierre no se podrá juzgar.
- Del producto: **no declarado en ningún documento** (`definition.success` sin hallar).
- Lo único medible que existe es `volumen_mensual`: 272.424 declarado (caso de negocio, 2026-07-12) contra 208.658 medido (tablero, corte 2026-10-10), 23,4 % por debajo de lo declarado. El tablero declara «definición no declarada» para la métrica. No se usa como criterio de éxito: sería elegirlo por el negocio.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 (sin título descriptivo) | Entrevista a cliente, 2025-08-24, «Lo necesito y hoy no lo tengo.» — débil, 13 meses |

### No entra
Los otros 12 requerimientos del registro (REQ-4901 a REQ-4911 y REQ-2026) quedan fuera de esta acta porque el comando se invocó solo con REQ-4900. **La razón de fondo por la que cada uno no entra no está en ningún documento**; no la invento. Estado según el acta del comité:
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4901, 4903, 4904, 4905, 4906, 4907, 4911, 2026 | Sin título descriptivo | Aceptados, pero no se pidieron en esta acta. Razón no declarada. |
| REQ-4902, 4908, 4909, 4910 | Sin título descriptivo | Siguen en «propuesto»; sin decisión del gerente de producto no hay acta. |

Además: el registro no dice qué cubre REQ-4900 y qué deja fuera. Esa línea (qué incluye la tarjeta: cerrada o con crédito, canales, segmentos aparte de Hogares) **no está dicha**.

## Gobierno
- **Patrocinador:** no dicho.
- **Gerente propuesto:** Diana Molina, gerente de producto (`00-definicion/2026-07-12-definicion-producto.docx`). Es propuesta; no la nombro como gerente del proyecto.
- **Doliente del requerimiento:** Óscar Ramírez (`30-decisiones/2026-10-13-comite-producto.docx`). No aparece en el acta como asistente.
- **Comité:** «Comité de producto», propuesto por defecto; el acta del 2026-10-13 solo tiene a Diana Molina como asistente. Su única decisión registrada es «Se mantiene el plan», y no hay plan en ningún documento.
- **Autoridad del gerente:** no dicha.
- **Quién decidió aceptar REQ-4900:** no dicho (`decision.who` vacío). Fecha de aceptación 2026-05-12, anterior a la definición del 2026-07-12.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-08-08 en una definición fechada 2026-07-12; 70 días) | No. Ningún documento nombra al proveedor ni el plazo. | **Sin doliente.** Se registra como riesgo del proyecto y lo asigna quien firme el acta; yo no lo adjudico. |
| El volumen mensual es 272.424 | No: el tablero mide 208.658 (-23,4 %). | Sin doliente. Se arrastra como riesgo de la línea base de demanda. |
| Hogares quiere la tarjeta | Solo con una entrevista de 13 meses | Sin doliente. |

Una cuarta afirmación, «Retorno esperado en 24 meses», no tiene cifra, supuesto ni serie. No es un supuesto verificable; es un vacío.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Una tarjeta de la tienda probablemente implica crédito o medio de pago al consumidor, datos personales y retención de información | No la puedo nombrar sin el país | — | **No tengo la norma a la vista.** No significa que no haya obligación ni que se cumpla. Pasa a revisión jurídica. Falta el país y si la tarjeta es cerrada o da crédito. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién decidió aceptar REQ-4900 | El proyecto nace de una decisión sin autor; si se discute, no hay a quién preguntar | El comité de producto (aún no nombrado) |
| Autoridad del gerente | El gerente escala todo o nada | Quien firma el acta |
| Criterio de éxito del producto | El cierre no se puede juzgar meses después | Diana Molina |
| Cómo se verifica «se verifica en producción» | El criterio de éxito del proyecto es una frase vacía | Óscar Ramírez (doliente) con Diana Molina |
| Necesidad y título de REQ-4900 | No se sabe qué entregable se construye | Óscar Ramírez |
| Evidencia de demanda vigente y específica de Hogares | Se arranca sobre una entrevista de 13 meses | Diana Molina |
| Patrocinador, presupuesto, hitos | No hay contra qué medir; este comando no los inventa | Quien firma |
| País y tipo de tarjeta | El barrido normativo no puede citar nada | Diana Molina / jurídico |
| Fecha real del supuesto del proveedor | El supuesto parece posterior a su propio documento | Quien escribió la definición |
| Plan: «Se mantiene el plan» sin plan en ningún documento | El plan lo hace el gerente del proyecto; el acta no lo trae | Gerente del proyecto |

Dato de contexto: ningún requerimiento tiene proyecto asignado y la definición dice «Ninguno declarado».

---
**Esto es un borrador.** Lo firma [quién: no dicho; lo nombra quien tenga la autoridad, no este comando]. **La ficha del proyecto no se creó:** el acta no está firmada, y crearla antes sería un proyecto que existe en el sistema y no en la organización. Tampoco se escribió `declared`: el estado lo declara el gerente del proyecto.

**Recomendación:** con cuatro vacíos de peso (decisor, autoridad, criterio de éxito verificable y evidencia vigente), conviene cerrar los dos primeros antes de firmar.

## Después
Cuando se firme, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; al publicar su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si su producto se está construyendo sin preguntarle a nadie.
