# Corrida del 2026-10-17 · product-trace

PRD-309 · 13 requerimientos · 24 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 2 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

9 requerimientos decididos el 2026-10-13 y ninguno tiene proyecto; ninguna ficha nombra PRD-309

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Tarjeta de la tienda (PRD-309) · al 2026-10-17
9 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Ningún requerimiento decidido tiene proyecto: la cadena se rompe en el segundo eslabón en los 9.

### Decidido y nadie lo está construyendo
Fuente de todas las decisiones: documentos/productos/PRD-309/30-decisiones/2026-10-13-comite-producto.docx (acta del 2026-10-13). El acta no dice quién decidió: "Por quién" no está dicho en ningún documento.

| REQ | Título | Decidido el | Por quién | Dueño |
|---|---|---|---|---|
| REQ-4903 | Requerimiento REQ-4903 | 2026-04-14 | no consta | María Restrepo |
| REQ-4907 | Requerimiento REQ-4907 | 2026-04-27 | no consta | sin dueño |
| REQ-4905 | Requerimiento REQ-4905 | 2026-05-04 | no consta | Jorge Medina |
| REQ-4900 | Requerimiento REQ-4900 | 2026-05-12 | no consta | Óscar Ramírez |
| REQ-4904 | Requerimiento REQ-4904 | 2026-05-29 | no consta | Jorge Medina |
| REQ-4901 | Requerimiento REQ-4901 | 2026-07-27 | no consta | Diana Molina |
| REQ-4911 | Requerimiento REQ-4911 | 2026-08-01 | no consta | Sandra Gil |
| REQ-4906 | Requerimiento REQ-4906 | 2026-08-21 | no consta | Diana Molina |
| REQ-2026 | Requerimiento REQ-2026 | 2026-10-06 | no consta | Sandra Gil |

El más viejo, REQ-4903, lleva 186 días decidido sin proyecto.

### La traza no se confirma
Ninguna: no hay trazas que confirmar, porque ningún requerimiento declara proyecto ejecutor.

### Lo que un proyecto construye y el registro no tiene
Ninguno hallado. Ninguna de las 13 fichas (PRY-199 a PRY-211, estado/records) nombra PRD-309 ni "Tarjeta de la tienda".

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2026 | aceptado | comité 2026-10-13 (decidido 2026-10-06) | — | — | — |
| REQ-4900 | aceptado | comité 2026-10-13 (decidido 2026-05-12) | — | — | — |
| REQ-4901 | aceptado | comité 2026-10-13 (decidido 2026-07-27) | — | — | — |
| REQ-4903 | aceptado | comité 2026-10-13 (decidido 2026-04-14) | — | — | — |
| REQ-4904 | aceptado | comité 2026-10-13 (decidido 2026-05-29) | — | — | — |
| REQ-4905 | aceptado | comité 2026-10-13 (decidido 2026-05-04) | — | — | — |
| REQ-4906 | aceptado | comité 2026-10-13 (decidido 2026-08-21) | — | — | — |
| REQ-4907 | aceptado | comité 2026-10-13 (decidido 2026-04-27) | — | — | — |
| REQ-4911 | aceptado | comité 2026-10-13 (decidido 2026-08-01) | — | — | — |

Fuera de la cadena, 4 requerimientos siguen en "propuesto" (REQ-4902, 4908, 4909, 4910): no están decididos, no son brecha de traza.

### Sin fichas a la vista
Se leyeron las 13 fichas. El hallazgo "sin proyecto" no viene de fichas faltantes sino de que el registro no asigna proyecto a ningún REQ.
Una salvedad: ninguna ficha declara qué producto ejecuta, así que la dirección "proyecto → producto" no se pudo contrastar a fondo.

### Después
Con 9 decididos sin proyecto, el siguiente paso es /criterio-product:product-charter para el que ya esté listo para serlo; REQ-4907 y REQ-4911 no (sin criterio de aceptación).
