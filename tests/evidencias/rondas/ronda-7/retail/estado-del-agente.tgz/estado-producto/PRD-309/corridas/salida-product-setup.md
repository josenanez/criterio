## Listo — Tarjeta de la tienda (PRD-309)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas del 2025-08-24, con una sola cita) · la definición y el caso de negocio del 2026-07-12 · lo más reciente es el acta del comité de producto del 2026-10-13. Todos legibles (2 son .docx; leí su texto directamente).
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1), fecha 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a…

**Preguntas (sesión sin interfaz, tomé la sugerida en cada una):**
1. Producto: Tarjeta de la tienda, PRD-309, gerente Diana Molina (del caso de negocio y la definición).
2. Quién decide: Comité de producto. Es una sugerencia mía: el acta registra estados pero no nombra quién decide, y el único asistente es Diana Molina.
3. Dónde guardo: `estado-producto/PRD-309`, hermana de la carpeta de documentación.
4. Términos: aceptados, ver arriba.

**Lo que dejé escrito:** `.criterio/producto/PRD-309/config.json` (verificada: ok), `estado-producto/PRD-309/producto.json`, 13 requerimientos en `requirements/` (los 13 que nombra el acta: 9 aceptados, 4 propuestos) y la serie `metrics/volumen_mensual.json`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Hogares no tiene tarjeta de la tienda | Nada propio. La única entrevista («Lo necesito y hoy no lo tengo») es de un cliente sin nombre y no dice segmento ni producto | 2025-08-24 |
| Volumen mensual de 272.424 | Solo el propio caso de negocio. El tablero mide 208.658 al 2026-10-10: el caso está 23,4 % por encima de lo medido | declarado 2026-07-12 · medido 2026-10-10 |
| Retorno esperado en 24 meses | Nada: no trae cifra, ni supuesto, ni serie | 2026-07-12 |
| El proveedor cumple el tiempo pactado | Es un supuesto, declarado el 2026-08-08 y sin verificar desde hace 70 días | 2026-08-08 |
| «Propuesta principal» | Nada: la definición no dice en qué consiste | 2026-07-12 |

### Lo que no está dicho en ninguna parte
- El criterio de éxito del producto.
- La cifra del retorno esperado, y con qué se mediría.
- En qué consiste la propuesta principal.
- Que Hogares lo pida: ninguna cita nombra el segmento.
- Quién decide qué se construye: el acta no lo dice.
- Qué proyecto ejecuta el producto («Ninguno declarado»), y por eso ninguno de los 9 requerimientos aceptados tiene traza (0,0 %).
- Qué cuenta como `volumen_mensual` (el tablero no define la métrica) y cómo venía antes de octubre: hay un solo punto medido.
- Qué necesita cada requerimiento: el acta solo trae el número y el nombre «Requerimiento REQ-49xx».
- Quién es el proveedor y qué tiempo se pactó.

### Qué dice el cálculo del registro (13 requerimientos)
- 9 con evidencia vencida (la única entrevista tiene 13 meses; el umbral es 12). Solo 5 de los 9 aceptados tienen evidencia de demanda (55,6 %).
- 4 aceptados sin ninguna evidencia: REQ-2026, REQ-4903, REQ-4904 y REQ-4907.
- 9 aceptados sin proyecto que los ejecute.
- 4 propuestos sin decidir, de 75 a 172 días: REQ-4902 (75), REQ-4908 (80), REQ-4910 (153), REQ-4909 (172).
- 2 sin doliente (REQ-4907, REQ-4910) y 2 aceptados sin criterio de aceptación (REQ-4907, REQ-4911). Donde hay criterio, es «se verifica en producción», que no dice qué se mide.
- El comité que los revisó tuvo un solo asistente, Diana Molina, que además es doliente de dos de ellos. La única decisión del acta es «Se mantiene el plan».

Una salvedad sobre mi propio trabajo: la evidencia que ligué a cada requerimiento sale de que el acta dice «Cliente entrevistado» y de que hay una sola ronda de entrevistas. La entrevista no menciona ningún requerimiento, así que ese vínculo es lectura del acta, no cita directa.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado», del 2026-08-08, sin verificar (70 días; el umbral es 30). No hay más. Que una definición con un proveedor de por medio traiga un solo supuesto también es un hallazgo.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas, y entrevistas más recientes que nombren a Hogares: hoy hay una cita de hace 13 meses.
- La serie de `volumen_mensual` con su definición y más de un punto; hoy nadie puede decir si 208.658 sube o baja.
- Un documento de decisión que nombre quién decide y qué decidió sobre cada requerimiento. Sin él, un requerimiento descartado se ve igual que uno que nadie miró.
- Una fuente para el 272.424 distinta del caso de negocio.

### Lo que no pude hacer
`sellar` (el sello de la lectura de documentos) respondió «no hay una corrida abierta: sellar va después de corrida-inicio». Este comando dice que aquí no va `corrida-inicio`, así que no lo abrí por mi cuenta. La lectura quedó sin sellar; conviene revisar esa instrucción del comando.

### Siguiente paso
`/product-discovery` sobre el material de entrevistas: ahí los temas se vuelven requerimientos con la cita de quién lo pidió. Con una sola cita hay poco que convertir; las entrevistas nuevas son lo que más movería este resultado.
