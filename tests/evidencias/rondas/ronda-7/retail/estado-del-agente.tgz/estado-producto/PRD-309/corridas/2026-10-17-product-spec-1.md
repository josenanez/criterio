# Corrida del 2026-10-17 · product-spec

PRD-309 · 13 requerimientos · 40 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 2 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador de especificación PRD-309: 9 aceptados sin título, necesidad ni criterio verificable; comportamiento no escrito para no inventarlo. Dije que no sé: país y normas, dueño de REQ-4907, definición de volumen_mensual (declarado 272.424 vs medido 208.658).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

> **Borrador, no especificación aprobada.** Lo escribió el agente desde el registro; lo cierra Diana Molina (gerente de producto) con el comité de producto. Este agente no aprueba.

# Especificación — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17

**Resultado en una línea:** el registro permite abrir la especificación, pero no escribir su comportamiento. Los 9 requerimientos aceptados no tienen título, necesidad ni prioridad, y su único criterio de aceptación («se verifica en producción») no se puede verificar. Por eso las secciones de abajo son estructura y vacíos, no comportamiento. Rellenarlos con lo razonable habría hecho que el borrador pareciera completo sin estarlo.

## Qué problema resuelve

«El segmento Hogares no tiene tarjeta de la tienda.» (definición de producto, 2026-07-12). Segmento: Hogares. Fuente: `documentos/productos/PRD-309/00-definicion/2026-07-12-definicion-producto.docx`.

La definición **no dice** qué es éxito (criterio de éxito: no encontrado) ni en qué consiste la «Propuesta principal» (el texto no la desarrolla). El caso de negocio dice «Retorno esperado en 24 meses» sin cifra, supuesto ni serie que lo mida (`2026-07-12-caso-de-negocio.md`).

## Alcance

### Entra
Los 9 requerimientos en estado `aceptado` (ninguno está en `en_construccion`). Se listan por ID porque el registro no les da título; todos se llaman «Requerimiento REQ-xxxx» en el acta del comité de 2026-10-13.

REQ-2026, REQ-4900, REQ-4901, REQ-4903, REQ-4904, REQ-4905, REQ-4906, REQ-4907, REQ-4911.

### No entra
- REQ-4902, REQ-4908, REQ-4909 y REQ-4910: están en `propuesto`. Nadie los decidió, y especificarlos sería escribir el documento dos veces.
- Todo lo que no está en el registro. Alcance funcional de la tarjeta (qué se aprueba, a quién, con qué límite, cobros, canales), diseño técnico, estimaciones, costo y fechas: el comando no los decide ni los propone.
- El alcance que salga del comité: este borrador propone el que sale del registro, y el registro es mínimo.

## Comportamiento

| Sección | Requerimientos que cubre | Contenido |
|---|---|---|
| Comportamiento principal | REQ-2026, 4900, 4901, 4903, 4904, 4905, 4906, 4907, 4911 | **No definido.** Ninguno de los 9 registra el campo `need` (qué necesita quien lo pidió). Solo hay un título genérico, así que escribir qué hace el sistema sería inventarlo. |
| Casos borde (sin conexión, operación duplicada, cliente que abandona antes de la confirmación, rechazo) | ninguno | **No definido** en ninguna fuente. Ver Vacíos. |

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «Se verifica en producción» (texto literal del acta del 2026-10-13) | REQ-2026, 4900, 4901, 4903, 4904, 4905, 4906 | No hay forma de verificarlo: no dice qué se observa, con qué umbral ni quién lo observa. Dos personas mirando lo construido pueden llegar a respuestas distintas. | **No.** No es un criterio sino un lugar donde ocurre la verificación. |
| *(sin criterio)* | REQ-4907, REQ-4911 | — | — |

No propongo cifras de reemplazo (latencia, porcentaje de aprobación, etc.). Esas son decisiones del negocio, y un número razonable puesto por el agente quedaría decidido sin que nadie lo decidiera. Lo que sí hay en los datos: la única métrica del producto, `volumen_mensual`, no tiene definición declarada en el tablero (`definition: "no declarada"`), así que tampoco sirve hoy como criterio.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (definición, 2026-07-12; declarado el 2026-08-08) | No. Sin verificar. | Sin dueño en el registro. Propongo a Diana Molina como gerente, que lo confirme o lo reasigne. |
| El volumen mensual del caso de negocio: 272.424 declarado el 2026-07-12. El tablero de la bodega de datos mide 208.658 al corte 2026-10-10, es decir 23,4 % menos. | No coincide. Los cortes son distintos y el tablero no declara cómo cuenta el volumen, así que no puedo decir cuál tiene razón. | Diana Molina (autora del caso) con el responsable del tablero, que el registro no nombra. |

El registro de requerimientos no trae supuestos por requerimiento (`assumptions: []` en los 9).

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Necesidad (`need`) de los 9 requerimientos aceptados | No se puede escribir comportamiento; el equipo construiría desde un título que no dice nada. | Cada dueño: Sandra Gil (REQ-2026, 4911), Óscar Ramírez (4900), Diana Molina (4901, 4906), María Restrepo (4903), Jorge Medina (4904, 4905). REQ-4907: sin dueño, ver abajo. |
| Criterio de aceptación verificable para REQ-2026, 4900, 4901, 4903, 4904, 4905, 4906 | «Se verifica en producción» deja la discusión de si quedó bien para después de construir. | Los mismos dueños, con Diana Molina como cierre. |
| Ausencia total de criterio en REQ-4907 y REQ-4911 | No hay con qué aceptar o rechazar lo construido. | Sandra Gil (4911); REQ-4907 sin dueño. |
| REQ-4907 no tiene dueño ni criterio ni evidencia | Aceptado el 2026-04-27 (hace ~6 meses) sin que nadie lo defienda. | Comité de producto: asignar dueño o devolverlo a `propuesto`. |
| Evidencia de demanda de REQ-2026, 4903, 4904, 4907 | Aceptados sin cita de quién lo pidió. Los otros 5 aceptados solo apuntan a una cita genérica de una entrevista de 2025-08-24 («Lo necesito y hoy no lo tengo.»), que no identifica qué se necesita. | Diana Molina (hizo las entrevistas) y los dueños. |
| Quién decidió cada aceptación (`decision.who` vacío en los 9) | El acta del 2026-10-13 registra los estados pero no nombra a quien decide; el único asistente listado es Diana Molina. No se puede rastrear la autoridad de la decisión. | Comité de producto. |
| Prioridad (no encontrada en ningún requerimiento) | Sin orden, no hay cómo decidir qué entra primero. | Diana Molina. |
| Criterio de éxito del producto (no encontrado) | Los criterios de cada requerimiento no tienen contra qué sumar. | Diana Molina / comité de producto. |
| Casos borde: sin conexión, operación duplicada, cliente se va antes de la confirmación, rechazo | Comportamiento indefinido en justo los casos donde el dinero y la reclamación aparecen. | Diana Molina, con quien construya. |
| Lo que otro equipo tiene que hacer: el supuesto del «proveedor» implica un tercero, y el producto no declara ningún proyecto (`projects: "Ninguno declarado"`). | Nadie construye ni se compromete con nadie. Nada acordado con ningún equipo. | Diana Molina; esto lo cierra el acta de constitución cuando haya criterio. |
| Obligaciones normativas | Ver tabla siguiente. | Jurídico/cumplimiento de la organización; Diana Molina lo lleva. |

### Barrido normativo (nombrar y citar; no dice si cumple)

La definición toca una **tarjeta de la tienda para hogares**: probablemente crédito o medio de pago al consumidor. El país no está declarado en ningún documento.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Datos personales de los solicitantes | no declarado | Autorización y finalidad | — | no tengo la norma a la vista |
| Tarjeta o crédito al consumidor (información previa, cobros, reclamos) | no declarado | Protección al consumidor financiero | — | no tengo la norma a la vista |
| Medio de pago o crédito de marca propia | no declarado | Reglas de sistemas de pago o de crédito | — | no tengo la norma a la vista |
| Retención y trazabilidad de operaciones | no declarado | Plazo y trazabilidad | — | no tengo la norma a la vista |
| Proveedor externo (supuesto del producto) | no declarado | Encargo del tratamiento y, si sale del país, transferencia | — | no tengo la norma a la vista |

No cito normas porque no las tengo a la vista ni conozco el país; inventar una cita sería peor que dejarlo así.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2026 | Requerimiento REQ-2026 | Sin necesidad, sin prioridad; criterio no verificable. Figura en el alcance pero sin comportamiento que escribir. |
| REQ-4900 | Requerimiento REQ-4900 | Ídem. |
| REQ-4901 | Requerimiento REQ-4901 | Ídem. |
| REQ-4903 | Requerimiento REQ-4903 | Ídem, y sin evidencia de demanda. |
| REQ-4904 | Requerimiento REQ-4904 | Ídem, y sin evidencia de demanda. |
| REQ-4905 | Requerimiento REQ-4905 | Ídem. |
| REQ-4906 | Requerimiento REQ-4906 | Ídem. |
| REQ-4907 | Requerimiento REQ-4907 | Sin dueño, sin criterio, sin evidencia, sin necesidad. |
| REQ-4911 | Requerimiento REQ-4911 | Sin criterio de aceptación y sin necesidad. |

Los 9 quedaron sin sección de comportamiento. No es que se decidiera dejarlos fuera: el registro no trae con qué escribirlos.

## Qué sigue

No ofrezco `/product-charter` todavía. Antes hacen falta los vacíos cerrados y un criterio de éxito.

---
**Pie.** Sale del registro `estado-producto/PRD-309/requirements/` (13 requerimientos, 9 aceptados; acta del comité de 2026-10-13, definición y caso de negocio de 2026-07-12, tablero de métricas de 2026-10-10). Cubre 0 de 9 aceptados con comportamiento, y los 9 con alcance y vacíos. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal
