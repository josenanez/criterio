## Descubrimiento — Tarjeta de la tienda (PRD-309) · 1 pieza nueva al 2026-10-17

Material leído: 1 pieza de descubrimiento, `10-descubrimiento/2025-08-24-entrevistas.md` (una ronda del 2025-08-24, realizada por Diana Molina, **un solo cliente entrevistado**). No hay tickets, encuestas ni otras notas de campo en la carpeta. Los otros 4 documentos del producto (definición, caso de negocio, tablero, comité) no son material de descubrimiento y se usaron solo para cruzar.

### Temas
Ninguno que se pueda llamar tema. Hay una sola voz y una sola cita:

> **Necesidad principal** (rótulo de la propia entrevista, no mío) — 1 de 1 piezas, 1 persona
> — *«Lo necesito y hoy no lo tengo.»* · Cliente entrevistado (sin nombre ni segmento), 2025-08-24
> **En el registro:** REQ-4900, 4901, 4902, 4905, 4906, 4908, 4909, 4910, 4911 (9 de 13) ya la citan como evidencia.

La cita **no dice qué es «lo»**: no nombra tarjeta, crédito, cupo ni canal. No puedo agrupar por problema porque el entrevistado no enunció ninguno.

### Dicho y nunca convertido en nada
Ninguno. La única cita ya está en el registro (9 requerimientos). El hallazgo va en el sentido contrario: la misma frase sostiene 9 requerimientos distintos, y una frase sin objeto no puede sostener a ninguno en particular.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| «Lo necesito y hoy no lo tengo.» | Cliente entrevistado (anónimo) | 2025-08-24 |

No se promueve y no se descarta. Todo lo del archivo se dijo una sola vez.

### Afirmaciones numéricas de los entrevistados
Ninguna.

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna. La entrevista no es nueva para el registro: ya figura como fuente de evidencia en 9 requerimientos, con fecha 2025-08-24.

### Lo que sí muestra el recálculo (no es descubrimiento, es el estado del registro)
- La evidencia de demanda tiene **13 meses** (2025-08-24) en los 9 requerimientos que la citan: señal `evidence_stale` ×9.
- 4 requerimientos aceptados sin ninguna evidencia: REQ-2026, REQ-4903, REQ-4904, REQ-4907.
- Con evidencia: 5 de 9 aceptados según el cálculo de totales (`with_evidence_pct` 55,6 %), y toda proviene de esta única entrevista.
- Ningún requerimiento tiene proyecto trazado (9 aceptados sin traza).

### Qué no sé
- Quién es el cliente entrevistado, de qué segmento, ni a qué se refiere «lo». La definición habla de Hogares; la entrevista no lo confirma.
- Si hubo más entrevistas en la ronda que no quedaron en el archivo.

### Sellado
`producto.py sellar` se negó: la ficha `producto.json` no se escribió en esta corrida y sellar daría por leído lo que no se actualizó. No lo forcé; la entrevista sigue sin sellar y la próxima corrida la volverá a listar.

### Después
Esta corrida no produce temas nuevos, así que no ofrezco `/product-requirements` como consecuencia. Lo que sí necesita la persona a cargo es una ronda nueva de entrevistas que pregunte *qué* se necesita: es lo único que puede dar contenido a esos 9 requerimientos.
