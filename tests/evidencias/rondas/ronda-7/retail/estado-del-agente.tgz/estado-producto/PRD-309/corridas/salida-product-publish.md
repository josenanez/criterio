No publiqué la ficha de PRD-309 (Tarjeta de la tienda), con corte al 2026-10-17.

**Motivo:** `.criterio/producto/PRD-309/config.json` no define la carpeta de productos publicados (solo `paths.documents` y `paths.state`) y no existe ninguna carpeta `publicados` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé ninguna carpeta ni escribí en otro sitio.

**Lo que habría publicado (calculado, no escrito):**
- 13 requerimientos (9 aceptados, 4 propuestos) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Hogares
- Métrica: volumen_mensual, 272424 declarado en `documentos/productos/PRD-309/00-definicion/2026-07-12-caso-de-negocio.md` (2026-07-12)

**Para destrabarlo:** acordar la carpeta común y configurarla; luego se vuelve a correr el comando. Ningún requerimiento tiene proyecto asignado, por eso la lista de proyectos va vacía.
