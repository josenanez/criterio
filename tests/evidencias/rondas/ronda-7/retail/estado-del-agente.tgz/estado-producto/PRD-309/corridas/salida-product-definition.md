## Definición — Tarjeta de la tienda (PRD-309) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-07-12-definicion-producto.docx` y `00-definicion/2026-07-12-caso-de-negocio.md` · **del** 2026-07-12 · 5 afirmaciones (la definición es corta: 1 problema, 1 segmento, 1 propuesta, 1 supuesto, 1 cifra, 1 retorno)

Términos: vigentes y ya aceptados por José Francisco Ñáñez el 2026-10-17 (v1.1, familia 0.3.13); no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Ninguna afirmación está contradicha por un documento de otra fuente. Lo único que no coincide es una cifra, y va en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 272.424 | 208.658 | 23,4 %, declarado por encima | Caso de negocio, 2026-07-12 · bodega de datos, tablero de producto, corte 2026-10-10 (`20-metricas/2026-10-10-tablero-metricas.md`) |

Dos salvedades: la serie tiene un solo punto, así que no dice si el volumen baja o si nunca llegó a la cifra; y el tablero declara «definición no declarada» para la métrica, por lo que no se sabe si mide lo mismo que el caso de negocio.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | `caso-de-negocio.md`, 2026-07-12 | Sin cifra, sin supuesto y sin serie que lo mida. Nadie está midiendo el retorno. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara.
- **En qué consiste la propuesta.** La definición solo dice «Propuesta principal» y no la desarrolla.
- **Cuánto es el retorno, y retorno de qué.** «Retorno esperado en 24 meses» no trae monto, base ni supuestos.
- **De dónde sale 272.424 mensuales.** El caso de negocio da el valor, pero no cómo se calculó ni qué cuenta como volumen.
- **Quién decide.** El acta del 2026-10-13 registra estados pero no nombra quién decide; el único asistente fue Diana Molina. «Comité de producto» es la autoridad propuesta por defecto.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado», y ninguno de los 13 requerimientos tiene proyecto.
- **Cuánto tamaño tiene el segmento Hogares.** No hay cifra de cuántos hogares son ni cuántos quieren la tarjeta.
- **Qué pasa si el proveedor no cumple.** El supuesto está, pero no hay plan para cuando falle.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado | 70 (declarado el 2026-08-08) | Tener a la vista el tiempo pactado (contrato o acuerdo de nivel de servicio) y un hito del proveedor ya entregado o vencido contra esa fecha. Hoy ningún documento nombra al proveedor ni el plazo. |

Nota: el supuesto figura «declarado el 2026-08-08» dentro de una definición fechada el 2026-07-12; quien la escribió debería aclarar cuál es la fecha real. Con 70 días y sin proyecto que dependa del proveedor, es candidato a registrarse como riesgo con doliente.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| «El segmento Hogares no tiene tarjeta de la tienda» | Una entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-24-entrevistas.md`) | 2025-08-24 | Débil. Es una persona que dijo que lo necesita; nadie pagó ni se inscribió. La cita no nombra el segmento Hogares ni la tarjeta, y quedó un solo entrevistado. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| «El segmento Hogares no tiene tarjeta de la tienda» | Entrevista del 2025-08-24 | 13 meses |

Esa misma entrevista es la única evidencia que citan los requerimientos con respaldo, de modo que 9 de ellos tienen evidencia de 13 meses.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Una tarjeta de la tienda probablemente implica crédito o medio de pago al consumidor, datos personales de los titulares y retención de información | No declarado en la definición ni en la configuración | No la puedo nombrar sin el país | — | **No tengo la norma a la vista.** Esto no significa que no haya obligación ni que se cumpla. |

Esto va a revisión jurídica; no la reemplaza. Para que el barrido nombre y cite, hace falta que la definición diga el país y si la tarjeta es solo de la tienda (cerrada) o también otorga crédito.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está declarado. Sin él el producto no se puede cerrar, porque el cierre se juzga contra ese criterio meses después.
- **Quién decide:** el acta no lo nombra; hoy es una propuesta por defecto.
- **Problema y para quién:** sí están (Hogares no tiene tarjeta de la tienda; segmento Hogares), aunque con evidencia débil y vieja.

### Después
- El supuesto del proveedor lleva 70 días sin verificar: ofrezco convertirlo en riesgo con doliente.
- La definición no está cerrada (sin criterio de éxito ni autoridad nombrada), así que no corresponde ofrecer `/product-charter`.
