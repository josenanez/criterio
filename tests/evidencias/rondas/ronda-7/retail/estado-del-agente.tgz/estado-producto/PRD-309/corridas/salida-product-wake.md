## Tarjeta de la tienda (PRD-309) · 2026-10-17

**Primera revisión: no hay corte anterior, así que nada se puede llamar "nuevo".** Lo siguiente es la línea base desde la que se medirá lo que cruce un umbral de aquí en adelante. 13 requerimientos (9 aceptados, 4 propuestos).

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4909 | 172 días (desde 2026-04-28) | Quién tiene la facultad de decidirlo; además no tiene criterio de aceptación | Rubén Cárdenas (doliente); decide el comité de producto |
| Propuesto sin decidir y sin doliente | REQ-4910 | 153 días (desde 2026-05-17) | Asignar doliente y llevarlo al comité | Sin doliente; decide el comité de producto |
| Propuesto sin decidir | REQ-4908 | 80 días (desde 2026-07-29) | Llevarlo al comité | Ricardo Salas |
| Propuesto sin decidir | REQ-4902 | 75 días (desde 2026-08-03) | Llevarlo al comité | Rubén Cárdenas |
| Supuesto sin verificar: «El proveedor cumple el tiempo pactado» | definición | 70 días | Un dato del proveedor (cumplimiento real contra el plazo pactado) que lo confirme o lo descarte; si sigue sin verificarse, registrarlo como riesgo (assumption-tracking) | Diana Molina (responsable del producto) |

### Aceptado sin sustento
- **Sin evidencia de demanda:** REQ-2026, REQ-4903, REQ-4904, REQ-4907.
- **Con evidencia vencida (13 meses, entrevista del 2025-08-24):** la afirmación de la definición de que Hogares «lo necesita y hoy no lo tiene» se apoya solo en esa entrevista. Afecta REQ-4900, 4901, 4905, 4906 y 4911 (aceptados) y REQ-4902, 4908, 4909, 4910 (propuestos).
- **Sin doliente:** REQ-4907 (aceptado) y REQ-4910.
- **Sin criterio de aceptación:** REQ-4907 y REQ-4911, ambos ya aceptados.

### Lo que el negocio declara contra lo que los datos miden
`volumen_mensual`: el caso de negocio (2026-07-12) declara 272.424; el tablero (2026-10-10) mide 208.658. Lo declarado está 23,4 % por encima.

### Las trazas
**Ninguna traza está confirmada.** La configuración no incluye carpeta de fichas de proyecto, y sin ella ninguna traza se da por confirmada. Los 9 requerimientos aceptados figuran sin proyecto que los construya.

### Del descubrimiento
No se releyeron documentos en esta corrida; solo se recalculó el registro. Hay una sola entrevista de descubrimiento en la carpeta (2025-08-24).

### Lo que no sé
El criterio de éxito de la definición no está dicho en ninguna parte (`success` vacío).

**Vuelvo el 2026-10-31.**
