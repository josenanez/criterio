# Corrida del 2026-10-17 · product-business-case

PRD-309 · 13 requerimientos · 35 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 2 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

Borrador del caso de negocio: 1 cifra declarada (272.424) contra 1 medida (208.658, 23,4 % por debajo); retorno sin cifra; costos sin ningún documento (primer vacío); criterio de éxito, autoridad y proyecto sin declarar. No se proyectó ni se calculó nada.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Tarjeta de la tienda (PRD-309) · borrador del 2026-10-17
**Desde:** `00-definicion/2026-07-12-definicion-producto.docx` y `2026-07-12-caso-de-negocio.md`, ambos del 2026-07-12 · **Cifras con fuente:** 1 de 2 con origen verificable (la medida). La declarada solo se cita a sí misma.

Términos: vigentes, ya aceptados por José Francisco Ñáñez el 2026-10-17 (v1.1, familia 0.3.13); no hizo falta registrarlos de nuevo.

**Lo primero:** este documento todavía no es un caso de negocio, es una propuesta. No hay ningún costo en ningún documento (ver «Los costos»), y esa es la razón.

## Qué problema resuelve, y para quién
«El segmento Hogares no tiene tarjeta de la tienda.» Segmento: Hogares. (`00-definicion/2026-07-12-definicion-producto.docx`, 2026-07-12.)
Lo sostiene una sola entrevista: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-24-entrevistas.md`, 2025-08-24, hace 13 meses). Es evidencia débil: un entrevistado, y la cita no nombra ni el segmento ni la tarjeta.

## Qué se construye
Entran al caso los 9 requerimientos decididos (aceptados). No hay ninguno en construcción ni entregado, y ninguno tiene proyecto que lo ejecute.

| Requerimiento | Estado | Decidido el | Evidencia de demanda |
|---|---|---|---|
| REQ-4903 | aceptado | 2026-04-14 | Sin cita de quien lo pidió (doliente: María Restrepo) |
| REQ-4907 | aceptado | 2026-04-27 | Sin cita; sin doliente; sin criterio de aceptación |
| REQ-4905 | aceptado | 2026-05-04 | Entrevista 2025-08-24 (13 meses) |
| REQ-4900 | aceptado | 2026-05-12 | Entrevista 2025-08-24 (13 meses) |
| REQ-4904 | aceptado | 2026-05-29 | Sin cita de quien lo pidió (doliente: Jorge Medina) |
| REQ-4901 | aceptado | 2026-07-27 | Entrevista 2025-08-24 (13 meses) |
| REQ-4911 | aceptado | 2026-08-01 | Entrevista 2025-08-24 (13 meses); sin criterio de aceptación |
| REQ-4906 | aceptado | 2026-08-21 | Entrevista 2025-08-24 (13 meses) |
| REQ-2026 | aceptado | 2026-10-06 | Sin cita de quien lo pidió (doliente: Sandra Gil) |

Los 9 citan un documento de decisión en `30-decisiones/2026-10-13-comite-producto.docx`. Los títulos del registro son genéricos («Requerimiento REQ-xxxx»): el caso no dice qué es cada uno. Quedan fuera los 4 propuestos sin decidir (REQ-4902, 4908, 4909, 4910).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (declarado) | 272.424 | Declarada | `00-definicion/2026-07-12-caso-de-negocio.md`. El documento da el valor, pero no cómo se calculó ni qué cuenta como volumen | 2026-07-12 |
| volumen_mensual (medido) | 208.658 | Medida | Bodega de datos, tablero de producto (`20-metricas/2026-10-10-tablero-metricas.md`). Definición de la métrica: «no declarada en el tablero» | Corte 2026-10-10 |
| «Retorno esperado en 24 meses» | sin cifra | Supuesta | Solo la frase, en `caso-de-negocio.md`. Sin monto, sin base, sin supuesto y sin serie | 2026-07-12 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 272.424 | 208.658 | Caso de negocio, 2026-07-12 · bodega de datos, corte 2026-10-10 |

La declarada está 23,4 % por encima de la medida (diferencia de 63.766). Dos salvedades. La serie tiene un solo punto, así que no se sabe si el volumen baja o si nunca llegó a la cifra. Y el tablero no declara la definición de la métrica, así que no se sabe si mide lo mismo que el caso.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento |
| Costo del equipo | **No hay** | Ningún documento |
| Contratos o cotizaciones (incluido el proveedor del supuesto) | **No hay** | Ningún documento nombra al proveedor |

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-08-08 dentro de una definición fechada 2026-07-12; 70 días sin verificar) | No se sabe: ni el proveedor ni el plazo ni el plan de contingencia están escritos | Diana Molina, con el contrato o el acuerdo de nivel de servicio |
| «Retorno esperado en 24 meses» (supuesto implícito, nadie lo afirmó con cifra) | No evaluable | El negocio: quien debe afirmar el monto y su base |
| El volumen de 272.424 es alcanzable (implícito en el caso) | La cifra declarada se contradice con la medida actual | Diana Molina |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| **Costo de construir** (y del equipo) | Primer vacío. Sin él no hay caso que evaluar, hay una propuesta | El negocio / Diana Molina |
| Monto, base y supuestos del «retorno esperado en 24 meses» | Es la afirmación central del caso y no tiene número | El negocio |
| De dónde sale 272.424 y qué cuenta como volumen | Sin ello no se sabe si la brecha con 208.658 es caída o diferencia de definición | Diana Molina; dueño del tablero de datos |
| Criterio de éxito | No está en ningún documento; sin él el producto no se puede cerrar | Diana Molina / comité de producto |
| Qué pasa si no se hace; alternativas consideradas | El caso no las menciona | Diana Molina |
| Tamaño del segmento Hogares (cuántos hogares, cuántos quieren la tarjeta) | No hay base para ninguna cifra de demanda | El negocio |
| Quién decide | El acta del 2026-10-13 no lo nombra (único asistente: Diana Molina); «comité de producto» es propuesta por defecto | Comité de producto |
| Qué proyecto lo construye | La definición dice «Ninguno declarado»; 0 de 13 requerimientos con proyecto | Diana Molina |
| País y si la tarjeta otorga crédito | Sin eso no se nombra la norma aplicable (datos personales, crédito o pagos al consumidor, retención). Va a revisión jurídica | Diana Molina, jurídica |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento fija el criterio de éxito, ni una métrica con fecha de corte. El único candidato implícito es `volumen_mensual`, con 272.424 declarado, pero hoy lo medido es 208.658 y el caso no lo dice como criterio. Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay fichas de otros productos publicadas a la vista. Hay carpetas de documentos de PRD-299 a PRD-308, pero no son fichas publicadas. Busqué las cifras 272.424 y 208.658 en ellas y solo aparecen en PRD-309. No se detecta doble conteo, aunque el cruce completo de `/product-overlap` necesita las fichas publicadas.

---
**No hice:** proyectar ingresos, calcular retorno o recuperación, estimar beneficios, rellenar vacíos con valores de referencia del sector, ni recomendar aprobar o rechazar. Decidir es del comité de producto.

**Después:** ofrezco pasar los 3 supuestos al seguimiento con assumption-tracking (el del proveedor es candidato a riesgo con doliente). `/product-charter` no corresponde todavía: faltan el criterio de éxito, la autoridad nombrada y los costos.
