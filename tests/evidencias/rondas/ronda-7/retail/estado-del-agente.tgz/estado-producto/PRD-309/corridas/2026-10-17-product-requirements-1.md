# Corrida del 2026-10-17 · product-requirements

PRD-309 · 13 requerimientos · 22 s · 32 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 9 |
| `evidence_stale` | 9 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 2 |
| `requirement_without_acceptance` | 2 |
| `assumption_unverified` | 1 |
| `claim_vs_metric` | 1 |

4 aceptados sin evidencia, 9 sin proyecto, 4 propuestos sin decidir, 2 sin doliente, 2 sin criterio

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Tarjeta de la tienda (PRD-309) · al 2026-10-17
13 requerimientos · 9 decididos · 55.6% con evidencia · 0% con proyecto que lo ejecuta

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2026 | Requerimiento REQ-2026 | aceptado | Sandra Gil |
| REQ-4903 | Requerimiento REQ-4903 | aceptado | María Restrepo |
| REQ-4904 | Requerimiento REQ-4904 | aceptado | Jorge Medina |
| REQ-4907 | Requerimiento REQ-4907 | aceptado | (sin doliente) |

Aceptados sin una sola cita de quien lo pidió.

### Decidido y nadie lo está construyendo
Los 9 aceptados, ninguno con proyecto que lo ejecute.
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4903 | Requerimiento REQ-4903 | 2026-04-14 |
| REQ-4907 | Requerimiento REQ-4907 | 2026-04-27 |
| REQ-4905 | Requerimiento REQ-4905 | 2026-05-04 |
| REQ-4900 | Requerimiento REQ-4900 | 2026-05-12 |
| REQ-4904 | Requerimiento REQ-4904 | 2026-05-29 |
| REQ-4901 | Requerimiento REQ-4901 | 2026-07-27 |
| REQ-4911 | Requerimiento REQ-4911 | 2026-08-01 |
| REQ-4906 | Requerimiento REQ-4906 | 2026-08-21 |
| REQ-2026 | Requerimiento REQ-2026 | 2026-10-06 |

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4907 | Requerimiento REQ-4907 | (vacío) — aceptado |
| REQ-4910 | Requerimiento REQ-4910 | (vacío) — propuesto |

Quién lo cierra: Diana Molina (gerente de producto) asigna doliente.

### Sin criterio de aceptación
Solo decididos.
| REQ | Título | Estado |
|---|---|---|
| REQ-4907 | Requerimiento REQ-4907 | aceptado |
| REQ-4911 | Requerimiento REQ-4911 | aceptado |

Quién lo cierra: el doliente (REQ-4911: Sandra Gil; REQ-4907: sin doliente, primero asignarlo). REQ-4909 tampoco lo tiene, pero está propuesto y no se le exige.

### Decidido sin documento que lo respalde
Ninguno: los 9 decididos citan un documento en 30-decisiones.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4909 | Requerimiento REQ-4909 | 172 días (2026-04-28) | Comité de producto |
| REQ-4910 | Requerimiento REQ-4910 | 153 días (2026-05-17) | Comité de producto |
| REQ-4908 | Requerimiento REQ-4908 | 80 días (2026-07-29) | Comité de producto |
| REQ-4902 | Requerimiento REQ-4902 | 75 días (2026-08-03) | Comité de producto |

Se propone llevarlos al comité para decidir (aceptar o descartar); no se cierran por viejos.

### Evidencia vieja
Lo más nuevo que sostiene a cada uno es la entrevista del 2025-08-24, hace 13 meses.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4900, 4901, 4905, 4906, 4911 (aceptados) | Entrevista 2025-08-24: «Lo necesito y hoy no lo tengo.» | 13 meses |
| REQ-4902, 4908, 4909, 4910 (propuestos) | Entrevista 2025-08-24 | 13 meses |

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 9 | 0 | 0 | 0 |

Fuera del registro, la definición también alerta: el caso de negocio declara un volumen mensual de 272.424 y el tablero mide 208.658 (23.4% por debajo); y el supuesto «El proveedor cumple el tiempo pactado» lleva 70 días sin verificarse.
