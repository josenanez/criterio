# Solicitud de cambio CC-01

**Proyecto:** PRY-202 · Planta de tratamiento de agua
**Fecha:** 2026-10-10
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +115 días sobre la línea base vigente |
| Costo | 230.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
