# Solicitud de cambio CC-01

**Proyecto:** PRY-200 · Mantenimiento predictivo de camiones
**Fecha:** 2026-10-08
**Solicitante:** Paula Céspedes

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +41 días sobre la línea base vigente |
| Costo | 82.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
