# Comité de Tecnología · Control de polvo en vías

**Fecha:** 2026-10-08
**Asistentes:** Gustavo Neira, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 23 | 2026-11-10 |
