# Comité de Seguridad · Gemelo digital de la planta

**Fecha:** 2026-10-15
**Asistentes:** Mauricio Pérez, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 22 | por definir |
