# Comité Ambiental · Monitoreo de taludes

**Fecha:** 2026-10-15
**Asistentes:** Paula Céspedes, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 34 | 2026-10-05 |
