# Comité Ambiental · Ampliación de la relavera

**Fecha:** 2026-10-05
**Asistentes:** Sandra Gil, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 11 | 2026-11-06 |
