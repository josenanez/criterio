# Informe de avance · Monitoreo de taludes

**Código:** PRY-204
**Fecha de corte:** 2026-10-13
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **31%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.403.599.699 |
| Ejecutado | 870.765.374 |
| Proyección al cierre | 3.925.588.988 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- Cambio en la licencia ambiental que puede mover el alcance
