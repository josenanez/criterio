# Comité de Seguridad · Programa de relacionamiento comunitario

**Fecha:** 2026-10-09
**Asistentes:** Laura Vélez, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Entregar el punto 8 | 2026-11-01 |
