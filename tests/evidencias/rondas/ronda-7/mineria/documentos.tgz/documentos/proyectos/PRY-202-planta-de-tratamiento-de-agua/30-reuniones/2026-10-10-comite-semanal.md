# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-10-10
**Asistentes:** Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-11-24 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-11-30 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-12-05 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-21 |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-25 |
| Paula Céspedes | Validar el ambiente 12 | 2026-10-23 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-12 |
| Gustavo Neira | Entregar el punto 16 | 2026-11-02 |
| Diana Molina | Cerrar la prueba 18 | 2026-11-16 |
| María Restrepo | Revisar el anexo 19 | 2026-10-20 |
| Laura Vélez | Aprobar el diseño 21 | por definir |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-05 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-24 |
| Mauricio Pérez | Entregar el punto 24 | 2026-11-01 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Andrés Lozano): recibido, acta de recibo del 2026-10-10.
- Confirmar la fecha 7 (Gustavo Neira): recibido, acta de recibo del 2026-10-10.
- Enviar el documento 17 (María Restrepo): recibido, acta de recibo del 2026-10-10.
- Validar el ambiente 20 (Óscar Ramírez): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Gustavo Neira dice que ya entregó «actualizar la matriz 6». No se presentó acta.
