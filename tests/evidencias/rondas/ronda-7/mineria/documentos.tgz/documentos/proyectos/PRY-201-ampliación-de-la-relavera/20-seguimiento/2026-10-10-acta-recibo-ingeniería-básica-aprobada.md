# Acta de recibo · Ingeniería básica aprobada

**Proyecto:** PRY-201 · Ampliación de la relavera
**Fecha de recibo:** 2026-10-10
**Recibido por:** Sandra Gil

Se recibe a satisfacción el entregable **Ingeniería básica aprobada**.
