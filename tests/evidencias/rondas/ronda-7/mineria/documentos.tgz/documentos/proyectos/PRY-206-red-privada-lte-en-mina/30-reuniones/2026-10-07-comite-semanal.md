# Comité Ambiental · Red privada LTE en mina

**Fecha:** 2026-10-07
**Asistentes:** Laura Vélez, Camilo Beltrán

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 31 | 2026-10-24 |
