# Comité Ambiental · Despacho automático de flota

**Fecha:** 2026-10-16
**Asistentes:** Sandra Gil, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 31 | por definir |
