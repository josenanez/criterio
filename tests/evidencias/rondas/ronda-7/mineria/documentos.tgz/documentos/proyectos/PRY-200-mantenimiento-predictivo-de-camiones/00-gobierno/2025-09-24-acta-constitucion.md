# Acta de constitución · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Área dueña:** Geología
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Operaciones
**Producto asociado:** monitoreo de flota
**Fecha de aprobación:** 2025-09-24

## Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Operaciones el 2025-09-24.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-04 |
| Cierre | 2026-10-22 |

## Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

## Dependencias declaradas

- Ninguna declarada
