# Solicitud de cambio CC-01

**Proyecto:** PRY-206 · Red privada LTE en mina
**Fecha:** 2026-10-06
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +47 días sobre la línea base vigente |
| Costo | 94.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
