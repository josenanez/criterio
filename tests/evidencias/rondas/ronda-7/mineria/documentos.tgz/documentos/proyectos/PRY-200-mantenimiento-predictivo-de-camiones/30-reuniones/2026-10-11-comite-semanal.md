# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-11
**Asistentes:** Paula Céspedes, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 12 | 2026-10-10 |
