# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-09-30
**Gerente:** Carlos Peña

## Estado declarado

**Amarillo**

Avance reportado: **67%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se actualizó el presupuesto de la obra con el área de compras
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.499.050.343 |
| Ejecutado | 737.107.602 |
| Proyección al cierre | 3.252.401.754 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
