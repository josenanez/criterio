# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-10
**Gerente:** Laura Vélez

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 676.048.260 |
| Ejecutado | 626.736.556 |
| Proyección al cierre | 2.381.014.536 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
