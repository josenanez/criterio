# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-01-27
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 262.589 | Caso de negocio, 2026-01-27 |

## Retorno esperado

Retorno esperado en 24 meses.
