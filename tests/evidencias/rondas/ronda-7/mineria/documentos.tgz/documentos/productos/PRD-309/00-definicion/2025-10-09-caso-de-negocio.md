# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2025-10-09
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 287.932 | Caso de negocio, 2025-10-09 |

## Retorno esperado

Retorno esperado en 24 meses.
