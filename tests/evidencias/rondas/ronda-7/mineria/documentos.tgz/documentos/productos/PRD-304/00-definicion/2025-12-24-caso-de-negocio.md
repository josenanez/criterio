# Caso de negocio · Trazabilidad

**Código:** PRD-304
**Fecha:** 2025-12-24
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 287.325 | Caso de negocio, 2025-12-24 |

## Retorno esperado

Retorno esperado en 24 meses.
