# Entrevistas · Alerta de fatiga

**Ronda:** Ronda · 2025-08-24
**Realizadas por:** Laura Vélez

### Cliente entrevistado · 2025-08-24

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
