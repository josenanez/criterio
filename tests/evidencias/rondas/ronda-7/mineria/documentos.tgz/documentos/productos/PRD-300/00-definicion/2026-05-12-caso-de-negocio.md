# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2026-05-12
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 211.941 | Caso de negocio, 2026-05-12 |

## Retorno esperado

Retorno esperado en 24 meses.
