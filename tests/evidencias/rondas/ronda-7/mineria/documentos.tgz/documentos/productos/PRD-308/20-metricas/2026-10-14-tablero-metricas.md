# Tablero de métricas · Permisos de trabajo digitales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-14

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 94.355 | 2026-10-14 |
