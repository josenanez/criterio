# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Carlos Peña
**Segmento:** Mantenimiento
**Fecha de la definición:** 2025-11-24

## El problema

El segmento Mantenimiento no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-08-19 · verificado con el concepto jurídico de cumplimiento del 2026-09-26

## Proyectos que lo construyen

- Ninguno declarado
