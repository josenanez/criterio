# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Felipe Arango
**Segmento:** Gerencia
**Fecha de la definición:** 2025-10-09

## El problema

El segmento Gerencia no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-09-18 · verificado con la entrevista con doce clientes del segmento del 2026-09-20

## Proyectos que lo construyen

- Ninguno declarado
