# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-07-12
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 124.092 | Caso de negocio, 2026-07-12 |

## Retorno esperado

Retorno esperado en 24 meses.
