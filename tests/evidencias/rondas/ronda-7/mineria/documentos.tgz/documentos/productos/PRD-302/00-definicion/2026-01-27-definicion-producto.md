# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Laura Vélez
**Segmento:** Gerencia
**Fecha de la definición:** 2026-01-27

## El problema

El segmento Gerencia no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-08-03 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
