# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-10-16
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-06-07 | — |
| REQ-4801 | Requerimiento REQ-4801 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4802 | Requerimiento REQ-4802 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-28 | — |
| REQ-4803 | Requerimiento REQ-4803 | Javier Hoyos | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-21 | — |
| REQ-4804 | Requerimiento REQ-4804 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-22 | — |
| REQ-4805 | Requerimiento REQ-4805 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-08-08 | — |
| REQ-4806 | Requerimiento REQ-4806 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4807 | Requerimiento REQ-4807 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4808 | Requerimiento REQ-4808 | Beatriz Cuéllar | — | Cliente entrevistado | propuesto | 2026-04-06 | — |
| REQ-4809 | Requerimiento REQ-4809 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-09 | — |
| REQ-4810 | Requerimiento REQ-4810 | Jorge Medina | — | — | propuesto | 2026-08-14 | — |
| REQ-4811 | Requerimiento REQ-4811 | sin asignar | — | — | propuesto | 2026-06-29 | — |
| REQ-4812 | Requerimiento REQ-4812 | Liliana Torres | — | — | aceptado | 2026-07-26 | — |
| REQ-4813 | Requerimiento REQ-4813 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-09-02 | — |

## Decisiones

- Se mantiene el plan
