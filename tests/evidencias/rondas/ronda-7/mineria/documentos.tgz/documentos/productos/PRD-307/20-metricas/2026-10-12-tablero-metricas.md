# Tablero de métricas · Reporte ambiental

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-12

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 80.963 | 2026-10-12 |
