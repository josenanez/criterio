# Caso de negocio · Reporte ambiental

**Código:** PRD-307
**Fecha:** 2026-04-07
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 110.771 | Caso de negocio, 2026-04-07 |

## Retorno esperado

Retorno esperado en 24 meses.
