# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2025-10-24
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 144.467 | Caso de negocio, 2025-10-24 |

## Retorno esperado

Retorno esperado en 24 meses.
