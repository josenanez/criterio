# Definición de producto · Reporte ambiental

**Código:** PRD-307
**Gerente de producto:** Mauricio Pérez
**Segmento:** Supervisores
**Fecha de la definición:** 2026-04-07

## El problema

El segmento Supervisores no tiene reporte ambiental.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-03-23 · verificado con la medición del piloto del 2026-08-17

## Proyectos que lo construyen

- Ninguno declarado
