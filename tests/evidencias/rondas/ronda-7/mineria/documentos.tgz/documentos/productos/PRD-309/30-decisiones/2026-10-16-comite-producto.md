# Comité de producto · Inspección con drones

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-08 | — |
| REQ-4901 | Requerimiento REQ-4901 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4902 | Requerimiento REQ-4902 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-04 | — |
| REQ-4903 | Requerimiento REQ-4903 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4904 | Requerimiento REQ-4904 | sin asignar | se verifica en producción | — | aceptado | 2026-07-23 | — |
| REQ-4905 | Requerimiento REQ-4905 | Diana Molina | se verifica en producción | — | propuesto | 2026-03-27 | — |
| REQ-4906 | Requerimiento REQ-4906 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-16 | — |
| REQ-4907 | Requerimiento REQ-4907 | Felipe Arango | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-13 | — |
| REQ-4908 | Requerimiento REQ-4908 | Diana Molina | se verifica en producción | — | propuesto | 2026-03-19 | — |
| REQ-4909 | Requerimiento REQ-4909 | Javier Hoyos | — | Cliente entrevistado | propuesto | 2026-07-03 | — |
| REQ-4910 | Requerimiento REQ-4910 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-24 | — |
| REQ-4911 | Requerimiento REQ-4911 | Andrés Lozano | — | Cliente entrevistado | aceptado | 2026-03-22 | — |
| REQ-4912 | Requerimiento REQ-4912 | Paula Céspedes | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-09 | — |
| REQ-4913 | Requerimiento REQ-4913 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-04 | — |
| REQ-2028 | Requerimiento REQ-2028 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-02 | — |
| REQ-2036 | Requerimiento REQ-2036 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-08 | — |

## Decisiones

- Se mantiene el plan
