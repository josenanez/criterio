# Corrida · 2026-10-17-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:07:42 · **Fin:** 2026-10-17T16:08:19 · **Duración:** 37 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 17 | — | 23 | 39 | Primera revisión sin corte previo: línea base de señales abiertas (3 sin decidir, 1 supuesto sin verificar, 14 con evidencia vencida). No confirmé trazas por falta de carpeta de fichas, no releí documentos ni contrasté el volumen declarado: no hay medición. |

Por señal (`product-wake`): `evidence_stale` 14, `requirement_untraced` 12, `requirement_without_acceptance` 6, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `requirement_without_owner` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Alerta de taludes (PRD-301) · 2026-10-17

Esta fue la primera revisión del producto y no había un corte anterior. Por eso no puedo decir qué cruzó un umbral *desde* el último corte. Lo que sigue es la línea base, es decir, lo que ya estaba abierto hoy. Desde ahora el comando reportará solo lo nuevo.

El registro tiene 17 requerimientos: 12 aceptados y 5 propuestos. Ninguno tiene traza a un proyecto.

**Para el comité de producto**
- **Propuestos sin decidir:** REQ-4103 lleva 203 días, REQ-4102 lleva 166 y REQ-4112 lleva 130. El umbral es 60 días. Los dolientes son Jorge Medina, Javier Hoyos y Liliana Torres.
- **Supuesto sin verificar:** «La red de la mina soporta el volumen» lleva 58 días, con umbral de 30. Para verificarlo hace falta medir la capacidad de la red contra el volumen declarado de 191.637 mensual. Ya pasó el punto en que conviene tratarlo como riesgo registrado. Lo lleva Natalia Ospina.

**Aceptados sin sustento**
- **Sin evidencia de demanda:** REQ-2030 y REQ-4108.
- **Sin criterio de aceptación:** REQ-4101, 4104, 4105, 4107, 4109 y 4114.
- **Sin doliente:** REQ-4100.
- **Sin construir:** los 12 aceptados no tienen proyecto asignado. Sin una carpeta de fichas no puedo confirmar ninguna traza.

**Evidencia vencida:** 14 requerimientos se sostienen solo en la entrevista del 2025-08-30, que ya tiene 13 meses (umbral 12). Esa entrevista atribuye el pedido a un «Cliente entrevistado» y no nombra ningún requerimiento.

**Lo que no pude hacer**
- **Cifra de volumen:** no la pude contrastar, porque no hay medición. Tampoco hay criterio de éxito definido.
- **Trazas:** no confirmé ninguna, porque la configuración no tiene carpeta de fichas.
- **Documentos:** no los releí.

La salida quedó en `estado-producto/PRD-301/corridas/salida-product-wake.md`. También quedó registrada la corrida `2026-10-17-product-wake-1` y el corte `snapshots/2026-10-17.json`.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta registrarlos de nuevo.

**Vuelvo el 2026-11-16.**
