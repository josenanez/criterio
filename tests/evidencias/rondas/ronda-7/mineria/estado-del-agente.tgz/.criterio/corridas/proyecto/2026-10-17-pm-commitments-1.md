# Corrida · 2026-10-17-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:32:58 · **Fin:** 2026-10-17T15:33:42 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 25 | 18 | Reprogramados 3+ veces: Javier Hoyos (6), Gustavo Neira (5), Camilo Beltrán (5); 5 vencidos sin evidencia y 2 sin fecha, 2 de ellos de Laura Vélez |

Por señal (`pm-commitments`): `commitment_overdue` 5, `commitment_rescheduled` 3, `milestone_met_without_evidence` 2, `commitment_undated` 2, `variance_time` 1, `progress_vs_plan` 1, `variance_cost` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

## Compromisos — PRY-202 Planta de tratamiento de agua · al 2026-10-17

La ficha tiene 26 compromisos: 21 abiertos y 5 cerrados con documento. Las cifras salen de `portafolio.py compute`, que no trajo `record_issues`. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré de nuevo.

### Se viene reprogramando
- **Javier Hoyos · Enviar el documento 1.** Seis reprogramaciones: del 09-08 al 09-29, 10-16, 10-28, 11-13, 11-24 y ahora el 12-08. Es un bloqueo que nadie ha nombrado. Las notas del 17 dicen «08/12/2026» y lo leí como día/mes. Si fuera mes/día no sería una fecha posible para esta serie.
- **Gustavo Neira · Cerrar la prueba 2.** Cinco reprogramaciones: del 09-12 al 10-01, 10-16, 10-24, 11-09 y ahora el 11-30.
- **Camilo Beltrán · Validar el ambiente 4.** Cinco reprogramaciones: del 09-23 al 10-12, 10-26, 11-12, 11-24 y ahora el 12-05.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Laura Vélez | Revisar el anexo 11 | 09-23 | 24 días |
| Andrés Lozano | Entregar el punto 8 | 10-04 | 13 días |
| Gustavo Neira | Actualizar la matriz 6 | 10-11 | 6 días |
| Rubén Cárdenas | Actualizar la matriz 14 | 10-12 | 5 días |
| Felipe Arango | Enviar el documento 9 | 10-15 | 2 días |

Laura Vélez (anexo 11), Andrés Lozano (punto 8) y Gustavo Neira (matriz 6) dijeron en comité que ya entregaron. En los tres casos «no se presentó acta» y no hay nada en el expediente que lo respalde, así que siguen abiertos.

### Vencen esta semana (hasta el 10-24)
- María Restrepo · Revisar el anexo 19 (10-20)
- Ricardo Salas · Aprobar el diseño 5 (10-21; ya reprogramado dos veces)
- Paula Céspedes · Validar el ambiente 12 (10-23)
- Diana Molina · Aprobar el diseño 13 (10-24)
- Javier Hoyos · Confirmar la fecha 23 (10-24)

### Sin fecha
- Laura Vélez · Aprobar el diseño 21 (dicho el 10-10)
- Laura Vélez · Mandar el ajuste del presupuesto (dicho el 10-17, «la otra semana»)

No pueden estar vencidos, por eso van aparte.

### Cerrados con documento
- Andrés Lozano · anexo 3 → `acta-recibo-3`
- Gustavo Neira · fecha 7 → `acta-recibo-7`
- Jorge Medina · fecha 15 → `acta-recibo-15`
- María Restrepo · documento 17 → `acta-recibo-17`
- Óscar Ramírez · ambiente 20 → `acta-recibo-20`

### Siguiente paso
Los tres compromisos reprogramados superan el umbral de 3 y exceden el seguimiento, así que se pueden formular como decisión para el comité con `/pm-escalate`. No lo hice.

El informe de avance del 16-10 declara el proyecto en verde. Si quiere que la PMO vea esto, `/pm-publish`.

La salida completa está en `estado/PRY-202-planta-de-tratamiento-de-agua/corridas/salida-pm-commitments.md`. La corrida quedó registrada como `2026-10-17-pm-commitments-1`.
