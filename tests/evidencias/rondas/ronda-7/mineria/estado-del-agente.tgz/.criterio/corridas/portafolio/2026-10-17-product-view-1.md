# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view monitoreo de flota

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T16:02:33 · **Fin:** 2026-10-17T16:03:22 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 35 | 86 | Producto con un solo proyecto (PRY-200), 5 alertas; sin dependencias internas. Reportó 7 proyectos sin producto declarado; no dijo su área dueña porque el cálculo no la trae. No explicó por qué lo ejecutado supera lo comprometido. |

Por señal (`product-view`): `milestone_met_without_evidence` 31, `progress_vs_plan` 9, `commitment_overdue` 8, `vendor_deliverable_late` 8, `declared_vs_evidence` 7, `variance_time` 5, `vendor_invoiced_without_delivery` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_accepted_without_evidence` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

**Monitoreo de flota tiene un solo proyecto, PRY-200 (Mantenimiento predictivo de camiones), con 5 alertas.** Como el producto no tiene más proyectos, no armé sección aparte. Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no registré nada nuevo. Las cifras salen de `portafolio.py compute` al 2026-10-17, y el informe de avance declarado más reciente es del 2026-10-14.

- **Fecha:** el producto termina el 2026-12-02, que es la fecha de PRY-200. Va 41 días (10,7 %) atrasado frente a la línea base original y 0 días frente a la vigente.
- **Avance:** el proyecto declara 50 % y está en amarillo. El plan sustenta entre 75 y 100 %, una diferencia de 25 puntos. El amarillo declarado no da cuenta de ninguna de las señales que siguen.
- **Hitos sin evidencia:** «Ingeniería básica aprobada» (283 días vencido) e «Ingeniería de detalle aprobada» (187 días) están dados por cumplidos sin evidencia.
- **Compromiso vencido:** Óscar Ramírez debía entregar el punto 12 el 2026-10-10, hace 7 días.
- **Dinero (COP):** las cuatro cifras están completas.

  | Concepto | Monto | Frente a lo aprobado |
  |---|---|---|
  | Aprobado | 9.500.000.000 | — |
  | Comprometido | 3.022.645.496 | 31,8 % |
  | Ejecutado | 5.333.861.988 | 56,1 % |
  | Proyección | 9.416.500.158 | −0,9 % |

  Lo ejecutado supera lo comprometido y el cálculo no explica por qué.
- **Dependencias internas:** ninguna, así que no hay nada que llevar al comité de producto por ese lado.

**Proyectos sin producto declarado:** siete de los 13 no declaran producto: PRY-201, 202, 205, 206, 209, 210 y 211. Su área dueña no viene en el cálculo y no la inventé: queda como «no está en el cálculo».

La corrida quedó registrada como `2026-10-17-product-view-1` y tardó 35 segundos. La salida completa está en `estado/corridas/salida-product-view.md`.
