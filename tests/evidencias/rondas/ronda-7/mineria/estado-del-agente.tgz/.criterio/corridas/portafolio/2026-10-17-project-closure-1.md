# Corrida · 2026-10-17-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T15:59:36 · **Fin:** 2026-10-17T16:00:38 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 46 | 86 | Cierre de PRY-203 no declarable: criterio de éxito sin umbral, 5 hitos cerrados sin evidencia, avance 27% vs 100% del plan, RAID sin doliente. No supe: si está en producción, resultado del ensayo de disponibilidad, componentes del alcance, fecha y gasto finales, qué es el punto 31. |

Por señal (`project-closure`): `milestone_met_without_evidence` 31, `progress_vs_plan` 9, `commitment_overdue` 8, `vendor_deliverable_late` 8, `declared_vs_evidence` 7, `variance_time` 5, `vendor_invoiced_without_delivery` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_accepted_without_evidence` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

**PRY-203 (Despacho automático de flota) no se puede cerrar contra su criterio de éxito con los documentos que hay.**

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo. El cierre sale de la ficha y de cuatro documentos: el acta de constitución, el cronograma v1, el informe de avance del 2026-10-13 y el acta del Comité Ambiental del 2026-10-16.

- **Criterio de éxito:** el acta lo declara: "Despacho automático de flota en producción y medido". No dice qué se mide ni con qué valor mínimo, así que no se puede verificar. Si se cierra, sería por decisión de alguien con nombre y no por cumplimiento.
- **Se cumplió:** no se puede determinar. Ningún documento muestra el sistema en producción ni una medición, y el informe dice que el primer ensayo de disponibilidad "no alcanzó lo pactado y se repite".
- **Hitos:** el cronograma marca los 5 hitos como cerrados, pero ninguno tiene evidencia. El plan equivale a 100 % y el informe declara 27 %, una brecha de 73 puntos.
- **Alcance:** no se puede contrastar entregado contra comprometido. El acta solo dice "Componente 1, 2 y 3" sin describirlos. No hay solicitudes de cambio ni recortes registrados.
- **Fecha:**
  - La fecha de cierre sigue siendo la original, 2026-09-17, sin replanificaciones.
  - La desviación de 0 días compara fechas planeadas, no reales. No hay fecha real de término y ya pasaron 30 días.
- **Presupuesto** (declaración del informe, no evidencia contable):
  - Aprobado: 3.300.000.000 COP.
  - Comprometido: 2.231.152.131 COP (67,6 %).
  - Ejecutado: 1.736.575.747 COP (52,6 %).
  - Proyección al cierre: 3.044.295.228 COP, 7,7 % por debajo de lo aprobado.
  - No hay gasto final ni línea base de costo nueva, pese a que el informe habla de actualizar el presupuesto con compras.
- **RAID:** no está cerrado. Las 2 incidencias y los 2 riesgos abiertos no tienen doliente. El único compromiso con nombre es el de Mauricio Pérez, "Entregar el punto 31", sin fecha y sin explicar qué es el punto 31.
- **Lecciones:** solo entraron 4, todas ancladas a hechos documentados:
  - Hitos marcados cerrados en el cronograma sin evidencia.
  - Criterio de éxito sin umbral.
  - Alcance sin describir.
  - RAID sin doliente.

En "Sin dato" quedó, entre otras cosas, el resultado del ensayo de disponibilidad y el hallazgo concreto de la auditoría de seguridad. Tampoco se sabe quién aprobaría el cierre, porque la autoridad no figura en ningún documento.

No ofrecí mover la carpeta a `archivo/`: con el proyecto sin cerrar no corresponde.

La corrida quedó registrada como `2026-10-17-project-closure-1`. Lo que te mostré está en `estado/corridas/salida-project-closure.md`.
