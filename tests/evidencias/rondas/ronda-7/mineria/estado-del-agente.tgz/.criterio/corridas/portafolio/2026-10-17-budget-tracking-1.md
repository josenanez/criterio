# Corrida · 2026-10-17-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-17T15:52:19 · **Fin:** 2026-10-17T15:53:07 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 32 | 86 | Presupuesto de PRY-202: proyección 28.9% sobre el aprobado, ejecución 24.3% frente a avance declarado 89%; dijo que CC-01 (+230M COP) no tiene autorización registrada y que comprometido, ejecutado y proyección son solo declaraciones sin evidencia. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 31, `progress_vs_plan` 9, `commitment_overdue` 8, `vendor_deliverable_late` 8, `declared_vs_evidence` 7, `variance_time` 5, `vendor_invoiced_without_delivery` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_accepted_without_evidence` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Presupuesto PRY-202 al 2026-10-17

El informe de presupuesto de PRY-202 está listo y la corrida quedó registrada como `2026-10-17-budget-tracking-1`. El problema principal es que la proyección supera el presupuesto aprobado en 28.9 %.

**Cifras (COP, una sola moneda)**

| | Monto | % del aprobado |
|---|---|---|
| Aprobado | 800.000.000 | 100 |
| Comprometido | 300.578.510 | 37.6 |
| Ejecutado | 194.512.198 | 24.3 |
| Proyección al cierre | 1.030.910.468 | 28.9 por encima |

- **Disponible real:** 499.421.490 COP (aprobado menos comprometido).
- **Origen de las cifras:** el aprobado sale del acta de constitución del 2026-02-27. Comprometido, ejecutado y proyección son declaraciones del informe de avance del 2026-10-16. Ningún documento de evidencia las respalda.
- **Cambio CC-01:** declara 230.000.000 COP adicionales y dice «Autorizada por el comité», pero ninguna minuta lo registra. Por eso el aprobado vigente sigue en 800.000.000 COP y el exceso de la proyección no tiene autorización.
- **Ejecución frente a avance:** 24.3 % ejecutado contra 89 % de avance declarado. El plan respalda entre 40 y 60 %, y solo hay 2 de 5 hitos cumplidos, ambos sin evidencia. Con lo que hay no se puede decidir si el 89 % está inflado o si hay trabajo hecho sin causar.
- **Comprometido:** 37.6 % no llega al umbral de 90 %, así que no hay alerta por ese lado.
- **Estado declarado:** el informe lo marca «verde» pese a las señales abiertas de costo, tiempo, avance y compromisos vencidos.
- **Proveedor CT-812:** tiene un entregable atrasado 124 días y facturó 63.399.928 COP. Otro entregable figura como entregado sin evidencia de recibo.

**Ofrecimiento:** como la proyección excede el aprobado, puedo preparar la solicitud de cambio de presupuesto, o completar la de CC-01 con la autorización que falta.

**Trámite**
- Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no se registraron de nuevo.
- Usé las cifras de `compute` tal cual. Solo añadí un resumen de 230.000.000 COP de CC-01, que viene del documento.
- Se cargó la ficha completa; el informe y el archivo de salida están en `estado/corridas/salida-budget-tracking.md`.
