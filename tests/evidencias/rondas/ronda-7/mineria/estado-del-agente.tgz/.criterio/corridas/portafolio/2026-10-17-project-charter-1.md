# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-210 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-17T15:58:44 · **Fin:** 2026-10-17T15:59:31 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 30 | 86 | Revisión del acta de PRY-210 (2026-01-25): faltan autoridad del gerente, supuestos y restricciones, quién mide el éxito; objetivo, alcance y exclusiones son genéricos. No supe si hay decisiones de comité fuera de la carpeta, ni quién mide el éxito, ni si el cronograma y el informe son de este proyecto. |

Por señal (`project-charter`): `milestone_met_without_evidence` 31, `progress_vs_plan` 9, `commitment_overdue` 8, `vendor_deliverable_late` 8, `declared_vs_evidence` 7, `variance_time` 5, `vendor_invoiced_without_delivery` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `variance_cost` 2, `milestone_overdue` 1, `vendor_invoiced_over_accepted` 1, `vendor_accepted_without_evidence` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Acta PRY-210: revisión

**Estado:** el acta existe, del 2026-01-25, y es la única que hay. Los términos ya estaban vigentes (versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo.

### Qué falta y qué consecuencia tiene
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | Ausente | No se sabe qué puede aprobar Laura Vélez sin subir a comité. Cualquier cambio, como los 10 días de montaje perdidos por lluvias, se decide sin respaldo o va al comité. |
| Objetivo de negocio | Repite el nombre del proyecto | No dice qué cambia para el negocio, así que no se puede saber si se logró. |
| Alcance | "Componente 1, 2, 3" | Sin alcance nombrado no se puede detectar ni evaluar un cambio de alcance. |
| Exclusiones | "Lo que otro proyecto cubre" | No nombra ningún proyecto, así que no evita discusiones sobre qué entra. |
| Supuestos y restricciones | Ausentes | El informe ya muestra uno que pesa: la ventana de parada de planta que define operaciones. |
| Dependencias | "Ninguna declarada" | Contradice ese riesgo y el hito de licencias y permisos, que depende de terceros. |
| Criterio de éxito y quién lo mide | No medible; sin dueño | El cierre no se puede evaluar. El éxito lo declararía el mismo gerente que ejecuta. |
| Hitos | Licencias y permisos cae el 2026-12-01, el mismo día del cierre | No hay margen. |
| Comité | Comité de Seguridad para un proyecto del área de Medio Ambiente | Está por confirmar que es el comité correcto. |
| Patrocinador | Felipe Arango | Cumple. |

### Otras inconsistencias que aparecieron
- **Cronograma:** los hitos de ingeniería y los términos "parada de planta" y "montaje" no cuadran con un programa comunitario. Puede que el cronograma o el informe sean de otro proyecto. No pude confirmarlo con lo que hay en la carpeta.
- **Informe del 2026-10-15:** declara Verde y 75 % de avance, pero lo ejecutado es 24,4 % del presupuesto aprobado. Las fechas vigentes del cronograma no cambiaron pese a los 10 días perdidos.
- **Compromiso del comité del 2026-10-09:** "Entregar el punto 8" no dice a qué punto se refiere.

### Qué no sé
No sé si hay decisiones de comité fuera de estos cuatro documentos. Tampoco sé quién mide el éxito ni cuál es el indicador. Lo que no estaba en los documentos quedó marcado como pendiente de definir.

### Después
Dejé sin ejecutar las dos ofertas, porque la sesión no tiene a nadie que responda:
- Llevar la definición de la autoridad del gerente al Comité de Seguridad.
- Pasar al registro RAID los dos supuestos que salieron: la ventana de parada de planta y la obtención de licencias antes del 2026-12-01.

La salida completa está en `/home/claude/banco/ronda-7/mineria/espacio/estado/corridas/salida-project-charter.md`. La corrida quedó registrada como `2026-10-17-project-charter-1`.
