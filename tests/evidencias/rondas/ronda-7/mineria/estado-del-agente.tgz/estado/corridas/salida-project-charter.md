Términos vigentes (versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

## Acta — PRY-210 Programa de relacionamiento comunitario
**Estado:** existe, del 2026-01-25 (`00-gobierno/2026-01-25-acta-constitucion.docx`). Es la única acta; no hay versión posterior.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente** | Nadie puede decir si Laura Vélez puede aprobar un cambio de monto o de alcance por su cuenta. Todo cambio, incluido el de las lluvias (10 días de montaje detenido, informe 2026-10-15), tiene que ir al comité o decidirse sin respaldo. |
| Objetivo de negocio | Descrito como solución | "Entregar programa de relacionamiento comunitario para Medio Ambiente" repite el nombre del proyecto. No dice qué cambia para el negocio ni para las comunidades, así que no se puede saber si se logró. |
| Alcance | Marcadores de posición | "Componente 1, 2, 3" no dicen nada. Sin alcance nombrado no hay forma de detectar un cambio de alcance ni de evaluar uno. |
| Exclusiones | Genéricas | "Lo que otro proyecto cubre" no nombra ningún proyecto. No evita que se discuta qué entra y qué no. |
| Patrocinador | Cumple | Felipe Arango, con nombre. |
| Supuestos y restricciones | **Ausentes** | El acta no los declara. El informe del 2026-10-15 ya muestra uno que pesa: una ventana de parada de planta "definida por operaciones". |
| Dependencias | Declaradas "ninguna" | Contradice el riesgo del informe (ventana de operaciones) y el hito "Licencia y permisos obtenidos" del cronograma, que depende de terceros. Un acta sin dependencias reales oculta de quién depende el cierre. |
| Criterio de éxito | No medible | "En producción y medido" no tiene indicador, meta ni dueño de la medición. El cierre no se puede evaluar contra nada. |
| Quién lo mide | **Ausente** | Sin él, el éxito lo declara el mismo gerente que lo ejecuta. |
| Hitos | Solo inicio y cierre en el acta | El cronograma v1 trae tres hitos. El último, "Licencia y permisos obtenidos" (2026-12-01, en curso), cae el mismo día que el cierre del acta, sin margen. |
| Comité y cadencia | Comité nombrado, sin cadencia | El comité es el de Seguridad, para un proyecto cuya área dueña es Medio Ambiente. Está por confirmar que es el comité correcto. La cadencia no está en el acta (la configuración del portafolio tiene comité semanal). |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar programa de relacionamiento comunitario para Medio Ambiente" (acta, "Objetivo del negocio").
**Alcance:** pendiente de definir. El acta lista "Componente 1", "Componente 2" y "Componente 3" (acta, "Alcance").
**Exclusiones:** pendiente de definir. El acta solo dice "Lo que otro proyecto cubre", sin nombrar ningún proyecto (acta, "Fuera de alcance").
**Patrocinador:** Felipe Arango (acta) · **Gerente:** Laura Vélez (acta)
**Autoridad del gerente:** pendiente de definir. Ningún documento de la carpeta fija monto ni tipo de cambio.
**Comité al que reporta:** Comité de Seguridad (acta; acta de comité 2026-10-09) · **Cadencia:** pendiente de definir en el acta.
**Presupuesto aprobado:** 4.200.000.000 COP, por el Comité de Seguridad el 2026-01-25 (acta, "Presupuesto aprobado").
**Supuestos:** pendiente de definir. Ninguno en el acta.
**Restricciones:** pendiente de definir. Ninguna en el acta.
**Criterio de éxito:** "Programa de relacionamiento comunitario en producción y medido" (acta, "Criterio de éxito"). No es medible. · **Lo mide:** pendiente de definir.
**Hitos principales:** inicio 2026-02-04 y cierre 2026-12-01 (acta). Ingeniería básica aprobada, 2026-05-15, cerrado. Ingeniería de detalle aprobada, 2026-08-23, cerrado. Licencia y permisos obtenidos, 2026-12-01, en curso (`10-plan/2026-01-25-cronograma-v1.xlsx`).

### Otras inconsistencias que salieron en la lectura (fuera del acta)
- **Cronograma:** los hitos de ingeniería básica y de detalle, y los términos "parada de planta" y "montaje", no corresponden a un programa de relacionamiento comunitario. Puede que el cronograma o el informe sean de otro proyecto. No lo puedo confirmar con lo que hay en la carpeta.
- **Informe de avance, 2026-10-15:** declara Verde y 75 % de avance. El ejecutado es 1.024.296.493 COP sobre 4.200.000.000 aprobados, es decir 24,4 %. El comprometido es 81,1 %. Las fechas vigentes del cronograma son iguales a las de línea base aunque el informe cuenta 10 días de montaje detenido por lluvias.
- **Acta de comité, 2026-10-09:** el compromiso "Entregar el punto 8" (Felipe Arango, 2026-11-01) no dice a qué punto se refiere; no hay un punto 8 en ningún documento de la carpeta.

### Pie de rigor
- Lo que revisé: el acta, el cronograma v1, el informe del 2026-10-15 y el acta de comité del 2026-10-09. No hay otros documentos de gobierno de PRY-210 en la carpeta.
- Lo que no sé: si existen decisiones del comité sobre autoridad, supuestos o restricciones fuera de estos documentos; no leí nada que esté fuera de la carpeta. Tampoco sé quién mide el éxito, cuál es el indicador, ni si el Comité de Seguridad es el comité correcto para este proyecto.
- Nada del contenido se completó con lo razonable: lo que no está, queda marcado como pendiente de definir.

### Después
- El acta no declara la autoridad del gerente. Propongo llevar esa definición al Comité de Seguridad como decisión: monto y tipo de cambio que Laura Vélez puede aprobar sin subir. No lo he gestionado.
- De la revisión salen estos supuestos para el registro RAID: disponibilidad de la ventana de parada de planta que define operaciones, y obtención de licencia y permisos antes del 2026-12-01. No los he pasado al registro.
