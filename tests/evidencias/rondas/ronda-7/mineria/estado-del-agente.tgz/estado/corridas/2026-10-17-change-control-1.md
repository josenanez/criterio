# Corrida del 2026-10-17 · change-control

13 proyectos · 38 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Solicitud PRY-201 +30 días (cierre 2027-01-26 a 2027-02-25). Sin autoridad declarada en el acta: va a comité por defecto. Sin impacto declarado en alcance ni costo. impact: 0 proyectos alcanzados, pero el acta declara cero dependencias y hay riesgos externos sin dueño. No se sabe quién pide, el motivo, qué hito se mueve ni cuántos días mueve cada hito (sin holgura por actividad). Licencia vencida desde 2026-10-06 sin evidencia. No se registró línea base nueva.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Ficha de la que sale: `estado/records/PRY-201.json` (Ampliación de la relavera, actualizada 2026-10-17). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-201 Ampliación de la relavera — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días. Lo leo como mover el hito «Pruebas en operación» y el cierre, hoy 2027-01-26, porque el criterio de éxito del acta es «ampliación de la relavera en producción y medido». Es una lectura mía: la solicitud no dice qué hito es.
**Quién lo pide:** no consta. La solicitud no lo dice y ningún documento de la carpeta trae una solicitud de cambio.
**Por qué:** no consta. La causa más cercana en los documentos es una parada del montaje por lluvias de diez días (informe del 2026-10-07), pero nadie la ha vinculado al cambio. No la tomo como motivo.

### Línea base vigente
Una sola: v1, aprobada el 2026-04-11 con el acta, cierre 2027-01-26, presupuesto 4.200.000.000 COP (`10-plan/2026-04-11-cronograma-v1.csv`). Sin replanificaciones anteriores y sin cambios registrados. No hay desviación previa que reconciliar (0 días no autorizados).

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Tres componentes sin detallar («Componente 1, 2, 3») | No declarado | Sin impacto declarado |
| Tiempo | Cierre y «Pruebas en operación»: 2027-01-26 | 2027-02-25 | +30 días (+101 días a hoy, ahora 131) |
| Costo | Aprobado 4.200.000.000 COP · proyección declarada 4.077.850.670 COP | No declarado | Sin impacto declarado |

**Quién absorbe lo que no se declaró.** Treinta días más con el equipo y los contratos corriendo cuestan algo. Si el costo queda en cero, alguien lo absorbe en horas no pagadas o en calidad. Además, el acta no detalla el alcance, y sin eso no se puede decir qué se recorta ni qué se mantiene. La proyección de 4.077.850.670 COP deja 122.149.330 COP de holgura (2,9 % del aprobado); es una declaración del gerente, no una cifra verificada. No sé cuánto cuestan los 30 días y no lo invento.

**Lo que no se sabe:** si el montaje (2026-12-01) también se mueve. El cálculo dice que el cambio pasa por «Montaje e instalación» (a 45 días) y por «Pruebas en operación» (a 101 días), pero no cuántos días mueve cada uno. Eso necesita holgura por actividad, y la ficha no la tiene.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` no encuentra proyectos alcanzados (0 directos, 0 indirectos, 0 sin poder sostener su fecha, 0 dependencias sin confirmar) | — |

**Cuidado con leer esto como «sin efecto».** El acta declara «Ninguna declarada» como dependencia y el RAID no registra ninguna. El resultado es que no hay dependencias declaradas, no que no existan. Hay dos indicios que lo contradicen: el riesgo «Ventana de parada de planta definida por operaciones» y el riesgo «Cambio en la licencia ambiental que puede mover el alcance». Ambos son externos al proyecto y ninguno tiene dueño ni fecha. Si operaciones fijó la ventana de parada, mover la salida 30 días depende de ella y ese acuerdo no está en la carpeta.

### Quién decide
**Autoridad requerida:** no se puede determinar. El acta no declara qué cambios puede aprobar la gerente, el patrocinador o el comité (`identity.authority`: no encontrado). Ese es el hallazgo de fondo.
**Según:** el acta nombra a Javier Hoyos como patrocinador y al Comité Ambiental como comité, y el comité aprobó el presupuesto el 2026-04-11. Eso muestra quién aprobó la línea base original, no quién puede cambiarla. Lo dejo como inferencia.
**Va a comité:** sí, por defecto. Sin umbral declarado, no hay base para decidir que un movimiento de 30 días en el cierre queda dentro de la autoridad de la gerente. Quien aprobó la línea base es quien debería aprobar su cambio. Comité del portafolio: 2026-10-23.

### Si no se aprueba
El proyecto sigue con cierre 2027-01-26 y estado declarado verde al 28 % (informe del 2026-10-07). Contra esa fecha ya hay señales que ese verde no resuelve:
- «Licencia y permisos obtenidos» venció el 2026-10-06 y sigue «en curso» sin evidencia: 11 días de atraso.
- Las lluvias detuvieron el montaje diez días y el informe sigue en verde sin ajustar fechas.
- «Ingeniería de detalle aprobada» (2026-08-11) figura cerrada, pero no hay acta de recibo. Solo hay acta de recibo de la ingeniería básica, con fecha 2026-10-10, casi cuatro meses después de su fecha de línea base (2026-06-16).
- El riesgo de licencia ambiental puede mover el alcance.
Es probable que el cambio sea una consecuencia de estos atrasos y no una decisión independiente. Eso se debe decir en la solicitud y no se dijo.

### Si se aprueba
Línea base 2 — cierre 2027-02-25 · presupuesto: sin cambio declarado (4.200.000.000 COP), pendiente de que se declare el costo de los 30 días · motivo: no consta (se necesita antes de registrarla).
Desviación acumulada contra la línea base original: +30 días · costo sin impacto declarado. La línea base 1 no se toca, y el conteo de replanificaciones pasa de 0 a 1. Desde ahí toda desviación se reporta contra dos referencias.

## Qué falta para poder decidir
1. Quién lo pide y el motivo escrito.
2. Qué hito se mueve: la salida a producción, el cierre o los dos.
3. Costo de los 30 días y si el alcance cambia.
4. Si la ventana de parada de planta de operaciones admite la fecha nueva.
5. Autoridad de aprobación declarada para el proyecto.
6. Evidencia de la licencia y de la ingeniería de detalle.

## Cierre
Esto es un borrador de trabajo que muestra lo que dicen los documentos, no lo que se habló fuera de ellos. La verificación es suya; cada dato sale de `records/PRY-201.json` y de los documentos citados en él. No hay línea base nueva registrada: la solicitud no fue aprobada por nadie. Para registrarla hace falta que quien tenga autoridad la apruebe y deje el documento.

**Siguiente paso que ofrezco:** preparar el paquete para el comité del 2026-10-23 (`/steering-pack`), o registrar la línea base 2 cuando exista la aprobación.
