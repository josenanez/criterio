# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 86 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

puerto 8787, carpeta del informe reportes/, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — Portafolio de minería

**Términos:** vigentes (versión 1.1, aceptada el 2026-10-17 por José Francisco Ñáñez para la familia 0.3.13). No hizo falta pedirlos de nuevo.

**Modo elegido: «para mirarlo un rato».** Respuesta recibida: `rato`. Nadie lo deja corriendo, nadie tiene que hablar con seguridad. Lo que se pierde: el patrocinador no tiene un enlace que funcione mañana.

**Hay informe:** `reportes/` tiene 23 páginas (`index.html`, `decisiones.html`, una por proyecto y una por producto). El servidor no genera el informe, lo sirve.

## Cómo se levanta

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-7/mineria/espacio/reportes --estado /home/claude/banco/ronda-7/mineria/espacio/estado --config /home/claude/banco/ronda-7/mineria/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, **solo en este equipo**. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

## Qué hay y para quién

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores con más de una cosa | La PMO |
| `/decisiones` | Lo que necesita una decisión, como pregunta cerrada y con la consecuencia de no decidirla | El comité y el patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace al producto que lo origina | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

El enlace entre proyecto y producto va en los dos sentidos: quien entra por un producto puede descubrir que lo construyen proyectos que reportan a comités distintos. El portal lleva el nombre «Portafolio de minería».

## Lo que Rostrum no hace

- **No calcula.** Sirve lo que `informe.py` ya escribió; dos personas ven lo mismo.
- **No escribe ninguna ficha.** Lo único que crea es la petición, en `estado/peticiones/`.
- **No autentica.** En este modo no hace falta: solo escucha en este equipo.
- **No manda nada.** Ni correo ni notificación.

## Peticiones

El formulario de la portada deja la petición en `estado/peticiones/`. El servidor no puede correr el agente; `portafolio.py due` las cuenta y una abierta rompe el silencio de `/portfolio-wake`. Se cierran con `portafolio.py answered --id <identificador>`.

## Cierre

Este enlace, `http://127.0.0.1:8787/`, solo sirve en este equipo: no se lo pase a un patrocinador. Para que el patrocinador tenga un enlace que dure, hay que pasar al modo «que quede corriendo» (`--abierto`), que pide un host y un puerto dentro de la red y publicarlo detrás del control de acceso de la organización. El informe es del 2026-10-17 y la portada lo dice; la siguiente cita de comité es el 2026-10-23, así que habrá que regenerarlo antes (`/portfolio-report html`).
