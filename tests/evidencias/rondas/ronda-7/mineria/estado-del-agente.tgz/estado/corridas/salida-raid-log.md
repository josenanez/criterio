**Sale de:** las 13 fichas (`estado/records/PRY-199` a `PRY-211`, con la sección RAID y su cita), las 13 actas de constitución (apartado «Dependencias declaradas»), las minutas de `30-reuniones` de los proyectos que las tienen (17 en total; PRY-208 no tiene) y las notas de reunión de PRY-202 del 2026-10-17. Los riesgos y las incidencias vienen de los informes de avance que las fichas citan; los re-verifiqué directamente en los de PRY-199, PRY-202 y PRY-208, no en los 13. De las seis minutas de PRY-202 leí completa la del 2026-10-10 y la nota del 2026-10-17; las otras cinco solo las barrí por palabras clave (riesgo, depende, supuesto, «podría», «si el…»).

Los Id (`199-R1`, `202-D1`…) los asigna esta corrida: ningún documento trae identificador de RAID. Probabilidad, impacto, doliente, fecha y último movimiento aparecen como «—» porque **ningún documento los dice**; no los rellené.

## RAID — portafolio al 2026-10-17
13 riesgos · 0 supuestos · 15 incidencias · 9 dependencias (37 ítems en 13 proyectos)
37 sin doliente · 13 riesgos sin probabilidad, impacto ni fecha · 37 sin dato de movimiento · 1 no registrado formalmente

(Las fichas traen 22 riesgos, 0 supuestos, 15 incidencias y 0 dependencias. Reclasifiqué 9 riesgos como dependencias; el motivo está más abajo.)

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 202-R1 + 202-D1 | Riesgo + dependencia | El proveedor podría no llegar con el equipo completo para la siguiente fase, y no ha confirmado la fecha de la última entrega | — (sin doliente) | 2026-10-16 (informe) y 2026-10-17 (notas) | Dos documentos distintos hablan del mismo proveedor y ninguno tiene doliente ni fecha. El contrato CT-812 de la ficha tiene «Licenciamiento del software» con vencimiento 2026-06-15 en estado pendiente y sin acta de recibo, y hay una factura del 2026-09-02. Hay una «revisión con el proveedor» comprometida por Óscar Ramírez para el 2026-10-27. **Decisión que se pide:** formalizar el riesgo y nombrar un doliente antes de esa revisión. |

Ningún otro ítem cumple con evidencia un criterio de escalamiento. Eso no significa que no deban subir: «sin movimiento en dos períodos» y «doliente fuera del proyecto que no ha respondido» no se pueden evaluar porque no hay historial de RAID (esta es la primera lectura) ni registro de respuestas.

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (PRY-202) | Riesgo | `PRY-202-planta-de-tratamiento-de-agua/2026-10-17-notas-reunion.txt` | 2026-10-17 |

Es el único. Las otras 16 minutas que leí o barrí solo traen tablas de compromisos, sin riesgos dichos al pasar. La nota no dice quién lo dijo, y la ficha ya lo recogió con la marca «dicho en la reunión; nadie lo anotó como riesgo». Queda a decisión del gerente si lo formaliza.

### Sin doliente o sin fecha
Faltan doliente y fecha en los 37 ítems; no los relleno. Qué falta, por tipo:

| Tipo | Ítems | Qué falta |
|---|---|---|
| Riesgo | 13 | doliente, fecha, probabilidad, impacto |
| Incidencia | 15 | doliente (tienen «desde» salvo 202-I1, que no trae fecha) y fecha de resolución |
| Dependencia | 9 | doliente, fecha de confirmación y el código del proyecto del que dependen (ver abajo) |

Un dato de contexto: el mismo texto se repite palabra por palabra entre proyectos. «Bloqueo de la vía de acceso a la mina» figura en 7 proyectos, «Cambio en la licencia ambiental que puede mover el alcance» en 5, «Ventana de parada de planta definida por operaciones» en 6 y «El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite» en 3, incluidos proyectos de áreas sin relación aparente (luminarias de campamento, taludes, relaciones comunitarias). Puede ser una plantilla de informe y no un análisis de riesgos del proyecto. Lo señalo sin afirmarlo: confirmarlo es cosa de cada gerente.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna con código de proyecto) | — | — | Las 13 actas dicen «Ninguna declarada» y ninguna ficha tiene dependencias entre proyectos. **No hay cruce posible**: no puedo decir que ninguna dependencia entre proyectos esté en riesgo, solo que ninguna fue declarada. |

Las 9 dependencias de abajo son hacia terceros que no son proyectos del portafolio (Operaciones, proveedores). Están **declaradas, no acordadas**: ningún documento muestra confirmación de la contraparte.

**Reclasificadas (por qué).** Por la prueba rápida, si depende de alguien fuera del proyecto es dependencia, y la ficha las traía como riesgos:
- «Ventana de parada de planta definida por operaciones» (201, 202, 205, 206, 208, 210): la fecha la fija Operaciones, no el proyecto.
- «El proveedor no ha confirmado la fecha de la última entrega» (202, 207, 209): la fecha la fija el proveedor.

Es un juicio mío sobre el texto de una línea; si el gerente sabe que en su caso hay un evento incierto distinto, se puede volver a riesgo.

### Registro completo
Prob., Impacto, Doliente, Fecha y Último movimiento: «—» en todos (no están en los documentos). «Desde» = fecha del informe de avance que lo cita.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento | Fuente |
|---|---|---|---|---|---|---|---|---|
| 199-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-15 |
| 199-I1 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | — | desde 2026-10-15 | — | informe 2026-10-15 |
| 199-I2 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | — | desde 2026-10-15 | — | informe 2026-10-15 |
| 199-I3 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | desde 2026-10-15 | — | informe 2026-10-15 |
| 200-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-14 |
| 200-I1 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | — | desde 2026-10-14 | — | informe 2026-10-14 |
| 200-I2 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | desde 2026-10-14 | — | informe 2026-10-14 |
| 201-D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-10-07 |
| 201-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | — | informe 2026-10-07 |
| 201-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | desde 2026-10-07 | — | informe 2026-10-07 |
| 202-D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | informe 2026-10-16 |
| 202-D2 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-10-16 |
| 202-R1 | Riesgo (no registrado formalmente) | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | — | — | — | notas 2026-10-17 |
| 202-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | — | sin fecha de inicio | — | informe 2026-10-16 |
| 203-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-13 |
| 203-R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | — | informe 2026-10-13 |
| 203-I1 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | — | — | — | desde 2026-10-13 | — | informe 2026-10-13 |
| 203-I2 | Incidencia | Hallazgo en la auditoría de seguridad | — | — | — | desde 2026-10-13 | — | informe 2026-10-13 |
| 204-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-13 |
| 204-R2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | — | informe 2026-10-13 |
| 205-D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-10-05 |
| 205-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-05 |
| 206-D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-10-05 |
| 206-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-05 |
| 206-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | desde 2026-10-05 | — | informe 2026-10-05 |
| 207-D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | informe 2026-09-28 |
| 207-I1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | — | — | — | desde 2026-09-28 | — | informe 2026-09-28 |
| 208-D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-09-30 |
| 208-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | — | informe 2026-09-30 |
| 208-I1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento | — | — | — | desde 2026-09-30 | — | informe 2026-09-30 |
| 209-D1 | Dependencia (antes riesgo) | El proveedor no ha confirmado la fecha de la última entrega | — | — | — | — | — | informe 2026-10-10 |
| 209-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | — | — | — | — | — | informe 2026-10-10 |
| 209-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | desde 2026-10-10 | — | informe 2026-10-10 |
| 210-D1 | Dependencia (antes riesgo) | Ventana de parada de planta definida por operaciones | — | — | — | — | — | informe 2026-10-15 |
| 210-I1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | — | — | — | desde 2026-10-15 | — | informe 2026-10-15 |
| 211-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | — | — | — | — | — | informe 2026-10-14 |
| 211-I1 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | — | — | — | desde 2026-10-14 | — | informe 2026-10-14 |

### Supuestos
No hay ninguno registrado ni dicho en reuniones. No los inventé. Nada de lo que leí lo dice, pero conviene preguntar a los gerentes si hay supuestos sin levantar (por ejemplo, que el equipo siga completo en los proyectos con rotación de personal, 202 y 207).

### Datos viejos
Los informes de PRY-207 (2026-09-28) y PRY-208 (2026-09-30) tienen más de 15 días al 2026-10-17 (`silent_days` de la configuración): su RAID puede estar desactualizado.

## Después
- **Subir a comité** (próximo: 2026-10-23): el caso 202-R1 + 202-D1, con la decisión formulada: formalizar el riesgo y nombrar doliente antes de la revisión con el proveedor del 2026-10-27.
- **Doliente**: propongo, no asigno, que cada gerente de proyecto nombre el doliente de sus ítems. En PRY-202 la ficha da a Jorge Medina como gerente y a Laura Vélez como patrocinadora; sería una propuesta para que ellos confirmen, no una asignación.

## Pie de rigor
- Es un borrador de trabajo, no una decisión: la verificación es de quien lo lea, con las citas de la columna «Fuente».
- No sé lo que se habló fuera de los documentos. Si hay riesgos hablados en pasillo o por voz, no están aquí.
- No sé si algún ítem se movió: no hay historial de RAID anterior a hoy.
- No leí completos los 13 informes de avance ni las cinco minutas anteriores de PRY-202; me apoyé en las fichas y en una búsqueda por palabras clave.
- La reclasificación de 9 riesgos a dependencias es mi lectura de una sola línea de texto.
