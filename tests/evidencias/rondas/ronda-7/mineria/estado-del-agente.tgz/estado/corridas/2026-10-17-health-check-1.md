# Corrida del 2026-10-17 · health-check

13 proyectos · 74 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Diagnóstico de PRY-204 desde 6 documentos: 2 sostenidas, 6 sin sustento, 4 contradichas; verde y 31 % contradichos por cronograma 100 % cerrado y cierre vencido hace 85 días; no pudo saber evidencia de hitos, soporte de comprometido/ejecutado, acta de recibo de CT-734 ni autoridad del gerente.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-204 Monitoreo de taludes · 2026-10-17

**Leí:** 6 documentos · 2025-06-12 a 2026-10-15 · formatos: docx (2), xlsx (1), pdf (1), md (2)
**No pude leer:** nada de la carpeta. Del PDF de la factura solo hay texto extraído, no su imagen: no puedo ver firmas ni sellos. Otros proyectos mencionan al proveedor (PRY-199 tiene el contrato CT-199 con la misma firma) pero ninguna minuta ni documento ajeno nombra a PRY-204, a Elena Duarte ni al "punto 34".

Términos: vigentes y aceptados por José Francisco Ñáñez el 2026-10-17 (versión 1.1, familia 0.3.13). No hubo que volver a registrarlos.

### Dictamen
**Sostenido:** 2 afirmaciones · **Sin sustento:** 6 · **Contradicho:** 4 (12 afirmaciones evaluadas)

Desde esta carpeta no se puede afirmar que PRY-204 esté en verde. Tampoco se puede afirmar que esté mal: se puede afirmar que el verde y el 31 % no lo respalda ningún documento y que lo contradicen otros. El informe de avance (2026-10-13) es la única fuente de los números de dinero y de los riesgos, y lo firma quien está siendo evaluado. El cronograma marca los cinco hitos como cerrados, la fecha de cierre (2026-07-24) pasó hace 85 días y el proyecto declara 31 %. Las dos cosas no pueden ser ciertas a la vez. Además, el proveedor facturó el 2026-09-21 un valor igual al de un entregable, y el contrato dice que ambos siguen pendientes o en curso y que se factura contra acta de recibo del gerente, que no existe en la carpeta.

Señales abiertas según `compute`: 5 contra el verde declarado (compromiso vencido, hitos cerrados sin evidencia, avance contra plan, entregables del proveedor tardíos, factura sin entrega).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Rubén Cárdenas | acta de constitución 2025-06-21 |
| Gerente | Paula Céspedes | acta de constitución 2025-06-21; informe 2026-10-13 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente en fechas, dinero o alcance | acta de constitución 2025-06-21 (ausencia) |
| Comité | Comité Ambiental; aprobó el presupuesto el 2025-06-21 y sesionó el 2026-10-15 con Paula Céspedes y Rubén Cárdenas | acta 2025-06-21; minuta 2026-10-15 |

Sin autoridad declarada no hay desviación aprobada: cualquier fecha distinta del 2026-07-24 sería algo que alguien escribió, no algo que alguien aprobó. Además, el acta se aprobó el 2025-06-21 y el contrato CT-734 se firmó antes, el 2025-06-12: el proveedor se contrató nueve días antes de que el proyecto estuviera constituido. El acta no declara dependencias ("Ninguna declarada") y el alcance son "Componente 1, 2 y 3" sin detalle.

### Contra el plan
- **Línea base original (v1, 2025-06-21):** inicio 2025-07-01, cierre 2026-07-24, cinco hitos (2025-09-16, 2025-12-03, 2026-02-18, 2026-05-07, 2026-07-24).
- **Vigente:** la misma. Fecha vigente = fecha de línea base en los cinco hitos. 0 replanificaciones, 0 solicitudes de cambio, desviación de tiempo contra la original y contra la vigente: 0 días, calculada por `compute`.
- Ese cero es engañoso. No es que el proyecto vaya a tiempo: es que nadie movió la línea base. Hoy son 85 días desde el cierre comprometido, sin replanificar y sin aprobación de nadie.
- **Avance contra plan:** el cronograma tiene 5 de 5 hitos "cerrado" (el plan sustenta 100 %); el informe declara 31 %. Brecha: 69 puntos (`compute`).
- El archivo del cronograma lleva fecha 2025-06-21 en su nombre, pero registra como cerrados hitos que en esa fecha estaban en el futuro. No sé cuándo se marcó "cerrado" ni quién lo hizo.

### Hitos vencidos sin evidencia
Los cinco hitos aparecen cerrados en el cronograma y ninguno tiene documento que lo respalde.

| Hito | Fecha | Días desde la fecha | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-09-16 | 396 | Acta o carta de aprobación de la ingeniería básica |
| Ingeniería de detalle aprobada | 2025-12-03 | 318 | Acta o carta de aprobación de la ingeniería de detalle |
| Licencia y permisos obtenidos | 2026-02-18 | 241 | Resolución o licencia de la autoridad ambiental |
| Montaje e instalación | 2026-05-07 | 163 | Acta de entrega del montaje |
| Pruebas en operación | 2026-07-24 | 85 | Protocolo o informe de pruebas firmado |

Los números de días vienen de `compute`. Dos de estos hitos chocan con el contrato: "Montaje e instalación" y "Pruebas en operación" figuran cerrados mientras el licenciamiento del software (vencido el 2025-11-20) sigue pendiente. Además, "Licencia y permisos obtenidos" figura cerrado y el informe mantiene como riesgo abierto un "cambio en la licencia ambiental".

### Dinero
Cifras recalculadas con `compute`. La moneda es COP.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 (acta) | 2.403.599.699 (declarado) | 870.765.374 (declarado) | 3.925.588.988 (declarado) | 1.796.400.301 |

- Ejecutado = 20,7 % de lo aprobado; comprometido = 57,2 %; proyección 6,5 % por debajo de lo aprobado. Frente al 31 % declarado de avance, 20,7 % de ejecución no es una alarma por sí misma: es una cifra que no puedo contrastar con nada.
- De los tres montos declarados no hay un solo documento de soporte. El contrato CT-734 suma 426.367.592 COP (2 × 213.183.796); el resto de lo comprometido, 1.977.232.107 COP, no tiene contrato, orden ni cotización en la carpeta.
- El único dato de dinero con documento es la factura FV-1734 del 2026-09-21: 213.183.796 COP, "radicada en cuentas por pagar". Equivale al monto de un entregable, pero dice "Entregables del contrato CT-734" sin indicar cuál. Con 0 entregables aceptados, el monto aceptado es 0 y lo facturado es 213.183.796.
- La única novedad del periodo en el informe es "se actualizó el presupuesto de la obra con el área de compras". No dice qué cambió y no hay solicitud de cambio. Dice "obra", en un proyecto de monitoreo.

### Lo que se dijo y nadie registró
- **Riesgos:** el informe lista dos ("Bloqueo de la vía de acceso a la mina" y "Cambio en la licencia ambiental que puede mover el alcance"). Ninguno tiene probabilidad, impacto, dueño, fecha ni respuesta. No existe registro de riesgos en la carpeta. El segundo contradice el acta ("Dependencias: ninguna declarada") y el hito de licencia cerrado.
- **Compromiso:** Elena Duarte debía "entregar el punto 34" el 2026-10-05. La minuta lo recoge el 2026-10-15, diez días después del vencimiento, y no dice cuál es el punto 34, ni de qué documento, ni qué pasó. Elena Duarte no asistió ni aparece en ningún otro documento de la carpeta. Vencido hace 12 días (`compute`), sin evidencia ni reprogramación.
- La minuta lista "Avance" y "Compromisos" como temas y no registra qué se dijo del avance, ni si alguien cuestionó el verde. Ninguna decisión, ningún cambio, ningún riesgo.
- **Dependencias:** ninguna registrada.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-10-13: "Verde" | Acta: cierre 2026-07-24, ya pasado hace 85 días sin replanificar. Contrato: ambos entregables del proveedor pendiente / en curso, vencidos hace 331 y 189 días. Minuta 2026-10-15: un compromiso vencido |
| Avance 31 % | Informe 2026-10-13: 31 % | Cronograma v1: 5 de 5 hitos "cerrado" (100 %) |
| Los 5 hitos cerrados | Cronograma v1: todos "cerrado" | Contrato CT-734: licenciamiento "pendiente" desde 2025-11-20 y bolsa de horas "en curso" tras su fecha. Informe: 31 % y riesgo abierto de licencia |
| La factura FV-1734 cobra "entregables del contrato" | Factura 2026-09-21: 213.183.796 COP | Contrato CT-734: ningún entregable entregado; se factura contra acta de recibo firmada por el gerente, que no está |

Una discrepancia menor: la ficha del estado del sistema tiene el estado de la bolsa de horas como "pendiente"; el contrato dice "en curso". Corregir la ficha.

### Sin sustento
Lo que ningún documento respalda ni contradice:
- **Comprometido** 2.403.599.699 COP: sin contratos, órdenes ni cuadro de compras (solo CT-734 por 426.367.592).
- **Ejecutado** 870.765.374 COP: sin ningún reporte contable. La única factura es de 213.183.796 y está radicada, no pagada.
- **Proyección al cierre** 3.925.588.988 COP: sin método ni documento.
- **Riesgo de bloqueo de la vía de acceso:** solo está en el informe.
- **Riesgo de cambio de licencia ambiental:** solo está en el informe.
- **"Se actualizó el presupuesto de la obra con el área de compras":** sin documento, sin cambio aprobado, sin cifra antes/después.

Sostenidas (2): presupuesto aprobado de 4.200.000.000 COP (acta, aprobado por el Comité Ambiental el 2025-06-21) y gerente Paula Céspedes (acta e informe coinciden).

### Lo que esta carpeta no permite saber
- **Si el proyecto está terminado, en curso o detenido.** Ningún hito tiene evidencia; no hay acta de ingeniería, licencia, montaje ni pruebas. Consecuencia: no se puede decir si el 31 % o el 100 % está más cerca de la verdad, ni si la fecha de cierre se cumplió.
- **Quién autorizó mover o no mover la fecha.** Sin autoridad declarada ni cambios, un cierre vencido hace 85 días no tiene aprobación. Consecuencia: el comité no puede considerar "desviación aprobada" nada de lo que pase desde 2026-07-24.
- **Si lo facturado se entregó.** Falta el acta de recibo del gerente. Consecuencia: la factura FV-1734 de 213.183.796 COP está radicada en cuentas por pagar sin la condición de pago que fija el contrato.
- **De dónde salen 2.403.599.699 y 870.765.374 COP.** Consecuencia: el disponible real de 1.796.400.301 COP es un resultado de aritmética sobre una cifra declarada; no sirve para decidir.
- **Qué es el "punto 34"** y si Elena Duarte tiene alguna relación con el proyecto.
- **Qué pasó con el contrato firmado antes del acta.** No hay documento que explique los nueve días de anticipación.
- **Si el cronograma se actualizó después de 2025-06-21.** El archivo conserva v1 y el nombre; no hay versión posterior.

Esto es un resultado: la carpeta de PRY-204 no permite diagnosticar su salud. Puedo preparar el punto de comité con la lista de lo que falta (actas de hitos, licencia, soporte de comprometido y ejecutado, acta de recibo de CT-734, registro de riesgos, autoridad del gerente) y llevar las cuatro contradicciones al gerente como preguntas, una por una. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

---
**Rigor:** cada dato lleva el documento de origen. Lo declarado por el gerente (informe 2026-10-13) está separado de lo probado (acta, contrato, cronograma, factura): el 100 % de las cifras de dinero distintas de lo aprobado son declaraciones. Las cifras derivadas vienen de `portafolio.py compute`; las dos sumas del contrato (426.367.592) y de lo comprometido sin soporte (1.977.232.107) las calculé a mano porque el script no las da. Verifícalas con los documentos.
