# Corrida del 2026-10-17 · product-view

13 proyectos · 35 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Producto con un solo proyecto (PRY-200), 5 alertas; sin dependencias internas. Reportó 7 proyectos sin producto declarado; no dijo su área dueña porque el cálculo no la trae. No explicó por qué lo ejecutado supera lo comprometido.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Vista por producto: **monitoreo de flota**. Sale de las fichas en `estado/` y del cálculo `portafolio.py compute` al 2026-10-17 (13 proyectos, 6 productos). Informe de avance declarado más reciente: 2026-10-14.

## Productos al 2026-10-17

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| monitoreo de flota | 1 (PRY-200) | 1 de 1 (5 alertas) | 2026-12-02 (PRY-200) | COP 9.500.000.000 | COP 3.022.645.496 |

El producto tiene un solo proyecto, así que la vista por producto no aporta más que la ficha de PRY-200 y no armo sección aparte. Lo que sigue es lo que esa ficha deja ver.

**Proyecto:** PRY-200 · Mantenimiento predictivo de camiones. Declarado en amarillo, 50 % de avance, informe del 2026-10-14 (`PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md`).

**Lo que hay que ver (señales de PRY-200):**
- **Atraso contra la línea base original:** 41 días (10,7 %), por encima del umbral de 10 %. Contra la línea base vigente el atraso es 0 días: el cambio aprobado movió la línea 41 días (1 cambio, sin días no autorizados).
- **Avance declarado contra plan:** declara 50 %; el plan sustenta entre 75 y 100 % (3 de 4 hitos cumplidos). Diferencia de 25 puntos, en sentido de atraso.
- **Hitos dados por cumplidos sin evidencia:** «Ingeniería básica aprobada» (vencía 2026-01-07, 283 días) e «Ingeniería de detalle aprobada» (vencía 2026-04-13, 187 días). La ficha no tiene ninguna fuente marcada como evidencia (0 de 29 datos; 5 son declaración y 24 sin marcar).
- **Compromiso vencido:** Óscar Ramírez, «Entregar el punto 12», vencía 2026-10-10 (7 días). Fuente: `PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-11-comite-semanal.md`.
- **El amarillo declarado no da cuenta** de ninguna de estas cuatro señales (variance_time, progress_vs_plan, milestone_met_without_evidence, commitment_overdue).

**Dependencias internas:** ninguna declarada, y no hay otro proyecto del producto con quien cruzarlas.

**Fecha comprometida del producto:** 2026-12-02, sale de PRY-200 (único proyecto).

**Dinero (COP), con las cuatro cifras presentes en el único proyecto:** aprobado 9.500.000.000; comprometido 3.022.645.496 (31,8 %); ejecutado 5.333.861.988 (56,1 %); proyección 9.416.500.158 (−0,9 % frente a lo aprobado). Observación: lo ejecutado supera lo comprometido; el cálculo no explica esa diferencia y no la interpreto.

**Lo que no sé:** `identity.authority` y `identity.phase` no están en la ficha; tres hitos no tienen evidencia citada; los datos de identidad y de dinero aprobado tienen 13 meses (fuente del 2025-09-24), por encima del umbral de 12 meses. Quién aprobó el cambio de 41 días no figura como autoridad en la ficha.

### Proyectos sin producto declarado

Siete de los 13 proyectos no declaran producto (`identity.product` vacío). Nadie puede responder por el conjunto al que sirven. El área dueña no viene en la salida del cálculo; está en la ficha de cada proyecto y no la copio aquí sin leerla.

| Proyecto | Área dueña |
|---|---|
| PRY-201 · Ampliación de la relavera | no está en el cálculo |
| PRY-202 · Planta de tratamiento de agua | no está en el cálculo |
| PRY-205 · Sistema de gestión de seguridad | no está en el cálculo |
| PRY-206 · Red privada LTE en mina | no está en el cálculo |
| PRY-209 · Electrificación de equipos | no está en el cálculo |
| PRY-210 · Programa de relacionamiento comunitario | no está en el cálculo |
| PRY-211 · Control de polvo en vías | no está en el cálculo |

Los otros cinco con producto son PRY-199 (PRD-299), PRY-203 (despacho de flota), PRY-204 (alerta de taludes), PRY-207 (gemelo digital) y PRY-208 (trazabilidad); cada uno también tiene un solo proyecto.

**Ofrecimiento:** no aparecieron dependencias internas, así que no hay decisión de comité de producto que llevar por ese lado.

---
*Pie de rigor:* borrador de trabajo generado por Criterio a partir de las fichas y documentos citados; no es decisión ni asesoría. Cada cifra se copió de `portafolio.py compute`; la verificación contra los documentos fuente es de quien lo lee.
