# Corrida del 2026-10-17 · document-index

13 proyectos · 23 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

95 documentos sin cambio, 0 por releer. PRY-202 reporta 166 citas sin resolver aunque los archivos existen en disco: probable falso positivo de rutas del índice, sin diagnosticar la causa.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 95 · **Sin cambio:** 95 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Solo PRY-202: el índice reporta 166 campos de su ficha (identidad, plan, hitos, dinero, proveedor CT-812 y 26 compromisos) con la cita sin resolver. Se apoyan en 18 documentos:
- `00-gobierno/2026-02-27-acta-constitucion.docx`
- `00-gobierno/2026-02-21-contrato-ct-812.docx`
- `10-plan/2026-02-27-cronograma-v1.csv`
- `10-plan/2026-10-16-cronograma-v2.xlsx`
- `20-seguimiento/2026-09-02-factura-ct-812.pdf`
- `20-seguimiento/2026-10-16-informe-avance.pdf`
- las actas de recibo 3, 7, 15, 17 y 20
- los comités semanales del 5, 12, 19 y 26 de septiembre y del 3 y 10 de octubre
- `2026-10-17-notas-reunion.txt`

**Esto parece falso positivo del índice, no una ruptura real.** Comprobé que esos archivos existen en `documentos/proyectos/PRY-202-planta-de-tratamiento-de-agua/`. Los 95 documentos salen sin cambio, ninguno borrado ni renombrado. En la ficha las rutas llevan el prefijo de la carpeta del proyecto. El índice las reporta sin ese prefijo, y PRY-202 es el único proyecto con subcarpeta propia en `estado/`. No lo diagnostiqué más: no sé por qué difiere. No hay que corregir ninguna ficha, y tampoco confío en que esas citas estén verificadas hasta que se aclare.

### Formatos que no se pudieron leer
Ninguno. Este comando no lee contenido: cuenta y compara huellas.

### Siguiente paso
No hay nada que releer, así que no ofrezco `/portfolio-scan`. Queda pendiente aclarar la resolución de rutas de PRY-202.
