# Corrida del 2026-10-17 · vendor-tracking

13 proyectos · 38 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Proveedor Geotecnia Aplicada (CT-393, CT-663): COP 481.058.790 facturados sin acta de recibo; CT-393 sin ningún entregable aceptado; verde declarado no sostenido. No supe: vigencia y preaviso de los contratos, qué cubre cada factura, ni si la diferencia de CT-663 tiene otro concepto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Sale de:** la ficha `estado/records/PRY-201.json`, el cálculo `portafolio.py compute` (corte 2026-10-17) y estos documentos de `PRY-201-ampliación-de-la-relavera`: `00-gobierno/2026-04-04-contrato-ct-393.md`, `00-gobierno/2026-04-06-contrato-ct-663.md`, `20-seguimiento/2026-08-28-factura-ct-393.md`, `20-seguimiento/2026-09-06-factura-ct-663.pdf`, `20-seguimiento/2026-08-07-acta-recibo-ct-663-licenciamiento-del-software.pdf`, `20-seguimiento/2026-10-07-informe-avance.md` y `30-reuniones/2026-10-05-comite-semanal.md`.

## Proveedores — PRY-201 Ampliación de la relavera al 2026-10-17

Un solo proveedor, **Geotecnia Aplicada S.A.S.**, con dos contratos. El informe de avance del 2026-10-07 declara el proyecto en **verde**. Con lo que hay en la carpeta, los dos contratos no lo sostienen.

### Geotecnia Aplicada S.A.S. — contrato CT-393
**Vigencia:** sin dato (el contrato solo trae firma 2026-04-04 y entregables) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

Condición de pago del contrato: «Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto».

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-07-07 · COP 337.474.541 | `pending` (el contrato dice «en curso»); 102 días tarde | ninguna | |
| Bolsa de horas de ingeniería | 2026-09-22 · COP 337.474.541 | `pending`; 25 días tarde | ninguna | |
| Calibración de sensores | 2026-12-08 · COP 337.474.541 | `pending`; no vence aún | ninguna | |
| **Total del contrato** | | 0 de 3 aceptados | | **COP 337.474.541** (FV-1393, 2026-08-28) |

La factura FV-1393 dice «Entregables del contrato CT-393» sin nombrar cuál. El script levanta `vendor_invoiced_without_delivery`: hay factura y ningún entregable aceptado.

### Geotecnia Aplicada S.A.S. — contrato CT-663
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

Misma condición de pago: factura contra acta de recibo firmada por el gerente.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software | 2026-08-01 · COP 402.930.357 | `accepted` | Acta de recibo 2026-08-07, firmada por Sandra Gil | |
| Bolsa de horas de ingeniería | 2026-11-12 · COP 402.930.357 | `pending`; no vence aún | ninguna | |
| **Total del contrato** | | 1 de 2 aceptados | | **COP 546.514.606** (FV-2663, 2026-09-06) |

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| CT-393: factura sin recibo | Se factura cada entregable contra acta de recibo firmada | Factura de COP 337.474.541 y cero actas de recibo; ningún entregable aceptado | contrato CT-393; factura FV-1393 |
| CT-663: facturado por encima de lo aceptado | Solo el licenciamiento (COP 402.930.357) tiene acta de recibo | Facturado COP 546.514.606; diferencia **COP 143.584.249** sin acta que la sustente | contrato CT-663; acta de recibo 2026-08-07; factura FV-2663 |
| Verde declarado | Informe del 2026-10-07: «Verde», avance 28 % | El script marca 6 señales sobre ese verde: entregables de proveedor tarde, facturado sin entrega, facturado sobre lo aceptado, avance bajo el plan (el plan sustenta 40–60 %, brecha de 12,0 puntos), hito vencido y hito sin evidencia | informe de avance; salida de `compute` |

Total facturado sin acta de recibo que lo sustente: COP 337.474.541 + COP 143.584.249 = COP 481.058.790. Lo que no sé: si la diferencia de CT-663 corresponde a otro concepto, un anticipo o un ajuste. La factura FV-2663 solo dice «Entregables del contrato CT-663» y ningún documento lo explica.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| CT-393 · Licenciamiento del software | `pending` / «en curso» | vencido desde 2026-07-07 (102 días) |
| CT-393 · Bolsa de horas de ingeniería | `pending` / «en curso» | vencido desde 2026-09-22 (25 días) |
| CT-393 · Calibración de sensores | `pending` / «en curso» | vence 2026-12-08 |
| CT-663 · Bolsa de horas de ingeniería | `pending` / «pendiente» | vence 2026-11-12 |

Ningún entregable figura como entregado o aceptado sin documento que lo pruebe (`accepted_without_evidence` vacío en los dos contratos). El problema es el inverso: hay plata facturada y no hay entregable.

El hito del proyecto «Ingeniería de detalle aprobada» (2026-08-11) figura como cumplido sin evidencia (67 días). No es entregable de proveedor, pero está en la misma carpeta.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso de la reunión del 2026-10-05 es de Óscar Ramírez («Entregar el punto 11», para 2026-11-06, abierto). Los documentos no dicen que Óscar Ramírez sea del proveedor ni qué es el «punto 11», así que no lo cuento como compromiso del proveedor. No hay compromisos vencidos ni reprogramados.

### Sin dato
- **Vencimiento de los contratos:** ni CT-393 ni CT-663 traen fecha de terminación, renovación automática ni plazo de preaviso. No puedo decir si hay un preaviso por vencer antes del cierre del proyecto (2027-01-26). Hay que pedir los contratos completos o sus anexos.
- **Qué entregables cubre cada factura:** las dos dicen solo «Entregables del contrato…».
- **Acta de recibo de los entregables de CT-393:** no está en la carpeta. Si existe, no llegó.
- **Por qué dos contratos con el mismo proveedor repiten los mismos entregables** (licenciamiento y bolsa de horas) con fechas y montos distintos: los documentos no lo explican. Puede ser legítimo o un solapamiento; no lo sé.
- **Si la fecha 2026-08-07 del acta de CT-663 corresponde a un documento firmado:** el PDF tiene texto con «Recibido por: Sandra Gil»; no pude verificar la firma.

## Después
- Las dos facturas están radicadas en cuentas por pagar (FV-1393 y FV-2663). Antes de que se paguen, conviene revisar las COP 481.058.790 que no tienen acta de recibo. **Se puede llevar a comité.** El próximo es el 2026-10-23 (Comité Ambiental), y puedo preparar el paquete si me lo piden.
- Preaviso de contrato: no se puede evaluar por falta de dato (ver arriba).

## Rigor
Cifras copiadas de `portafolio.py compute` y de los documentos citados; la suma de COP 481.058.790 la sumé yo a partir de dos cifras del script. Esto es un borrador de trabajo con la cita de cada dato, no una decisión ni asesoría; la verificación contra los originales es de quien lo lea. Lo que no estaba en los documentos queda dicho arriba como «sin dato».
