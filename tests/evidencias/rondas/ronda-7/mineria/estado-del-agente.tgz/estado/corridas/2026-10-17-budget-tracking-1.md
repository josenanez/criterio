# Corrida del 2026-10-17 · budget-tracking

13 proyectos · 32 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Presupuesto de PRY-202: proyección 28.9% sobre el aprobado, ejecución 24.3% frente a avance declarado 89%; dijo que CC-01 (+230M COP) no tiene autorización registrada y que comprometido, ejecutado y proyección son solo declaraciones sin evidencia.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Fuentes: ficha `estado/records/PRY-202.json` (documentos leídos al 2026-10-17) y cifras de `portafolio.py compute` con fecha de corte 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Presupuesto — PRY-202 Planta de tratamiento de agua al 2026-10-17
**Moneda:** COP (única moneda; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | 100 | `00-gobierno/2026-02-27-acta-constitucion.docx` | 2026-02-27 |
| Comprometido | 300.578.510 | 37.6 | `20-seguimiento/2026-10-16-informe-avance.pdf` (declaración) | 2026-10-16 |
| Ejecutado | 194.512.198 | 24.3 | `20-seguimiento/2026-10-16-informe-avance.pdf` (declaración) | 2026-10-16 |
| Proyección al cierre | 1.030.910.468 | 28.9 por encima del aprobado | `20-seguimiento/2026-10-16-informe-avance.pdf` (declaración) | 2026-10-16 |

**Disponible real** (aprobado menos comprometido): 499.421.490 COP

Las tres cifras de movimiento (comprometido, ejecutado, proyección) son declaraciones del informe de avance; ningún documento de evidencia (factura contable, ejecución del ERP) las respalda en la carpeta. La proyección tiene la misma fecha que el comprometido y el ejecutado (2026-10-16) y es posterior al último movimiento de presupuesto (CC-01, 2026-10-10), así que no está vencida frente a él.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 800.000.000 COP | 800.000.000 COP (no hay otro aprobado con evidencia) | 0 declarada |
| Proyección frente al aprobado | | 1.030.910.468 COP | 28.9 % por encima |

Replanificaciones de presupuesto: ninguna registrada como línea base de costo. Existe una solicitud, CC-01 (2026-10-10), que declara **230.000.000 COP adicionales** (`20-seguimiento/2026-10-10-solicitud-cambio-cc-01.md`). La solicitud dice «Autorizada por el comité», pero ninguna minuta ni acta lo registra. Por eso el aprobado vigente sigue en 800.000.000 COP y la diferencia con la proyección es hoy un exceso sin autorizar. (La replanificación de tiempo sí existe: 1, +115 días, con la misma autorización sin soporte.)

### Ejecución frente a avance
Ejecutado 24.3 % · Hitos cumplidos 2 de 5 · Avance declarado 89 % (el plan respalda entre 40 y 60 %; diferencia de 29 puntos). Lectura: la ejecución está muy por debajo del avance declarado. O el 89 % está inflado, o hay trabajo hecho y no causado que aparecerá de golpe; con la evidencia disponible no se puede decidir cuál. Además los dos hitos «cumplidos» (Ingeniería básica, 2026-06-06; Ingeniería de detalle, 2026-09-03) no tienen evidencia de aceptación en ningún documento.

### Alertas
- **Proyección por encima del aprobado:** 1.030.910.468 frente a 800.000.000 COP, 28.9 % de exceso (umbral de costo: 10 %). Hoy no hay presupuesto autorizado que lo cubra.
- **CC-01 sin autorización registrada:** el aumento de 230.000.000 COP depende de una aprobación que no consta en ninguna minuta.
- **Ejecución desalineada del avance:** 24.3 % ejecutado contra 89 % declarado.
- **Estado declarado «verde»** (informe del 2026-10-16) frente a señales abiertas de costo, tiempo, avance, hitos sin evidencia, compromisos vencidos y proveedor atrasado.
- Proveedor Automatización de Procesos Ltda. (CT-812): facturado 63.399.928 COP; «Licenciamiento del software» pendiente con 124 días de atraso (vencía el 2026-06-15); «Bolsa de horas de ingeniería» figura entregada sin evidencia de recibo.
- Comprometido: 37.6 %, por debajo del umbral de 90 %. Sin alerta por ese lado.

### Sin dato
- No hay documento de evidencia (contable o de ejecución) para comprometido, ejecutado ni proyección: solo la declaración del informe de avance.
- No hay línea base de costo vigente aprobada con evidencia que incorpore CC-01.
- Desglose del comprometido por proveedor: no declarado salvo lo facturado a CT-812.
- Notas del 2026-10-17: Laura Vélez se comprometió a «mandar el ajuste del presupuesto» sin fecha («la otra semana»).

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (o completar la de CC-01 con la autorización que falta). El comprometido no está cerca del tope, así que el detalle por proveedor no es urgente.

---
Pie de rigor: cifras derivadas copiadas de `portafolio.py compute`; montos y fechas con la cita de la ficha. Las cifras de movimiento son declaraciones sin evidencia independiente; la verificación es de la persona que decide. Borrador de trabajo, no asesoría.
