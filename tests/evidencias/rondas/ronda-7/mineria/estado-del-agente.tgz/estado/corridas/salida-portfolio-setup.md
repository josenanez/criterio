## Listo — Portafolio de minería

**Miré:** 95 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md (45), .docx (16), .pdf (14), .xlsx (13), .csv (5), .json (1), .txt (1) · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité (semanal; el último fue el 2026-10-16, por eso asumí el próximo el 2026-10-23, que no está confirmado)
**En:** presentación (propuesto por defecto; la configuración la guarda como `html`)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 6d4b67767ea3a1ea…

Nadie podía responder preguntas en esta sesión; tomé la respuesta sugerida en cada una:
- rol PMO, comité semanal con próxima fecha 2026-10-23, informe en presentación;
- estado en `estado/`, informes en `reportes/`, junto a la carpeta de documentos;
- costo por corrida: los valores seguros (lotes de diez, uno tras otro, hasta 400 documentos).

### Probé con tres proyectos

Los de documentación más reciente: PRY-202, PRY-203 y PRY-205. Fichas en `estado/records/`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | 20 (incluye `ficha-pm.json` del gerente y las notas del 17-oct) | Gerente Jorge Medina, patrocinadora Laura Vélez, Comité Ambiental. Declara verde y 89%. Presupuesto aprobado 800.000.000 COP, proyección 1.030.910.468. Cierre 2027-09-20 tras CC-01 (+115 días). 26 compromisos de comité. | Facultad del gerente, fase, acta de recibo de los dos hitos cerrados y de los entregables del proveedor. |
| PRY-203 Despacho automático de flota | 4 | Gerente Sandra Gil, patrocinadora Liliana Torres, Comité Ambiental. Declara amarillo y 27%. Presupuesto aprobado 3.300.000.000 COP, proyección 3.044.295.228. Cierre original 2026-09-17. | Facultad del gerente, fase, acta de recibo de cada uno de los cinco hitos. |
| PRY-205 Sistema de gestión de seguridad | 8 | Gerente Diana Molina, patrocinador Ricardo Salas, Comité de Seguridad. Declara verde y 23%. Presupuesto aprobado 9.500.000.000 COP, proyección 9.819.592.992. Cierre 2027-04-07 (original 2027-01-22). | Facultad del gerente, fase, acta de recibo de Ingeniería básica. |

### Lo que levantó el cálculo

Solo lo que `compute` señaló:

**PRY-202**
- `declared_vs_evidence`: declara verde con señales que el verde no explica (las de abajo).
- `progress_vs_plan`: declara 89% y el cronograma sostiene entre 40% y 60% (2 de 5 hitos cerrados).
- `milestone_met_without_evidence`: Ingeniería básica (vencía 2026-06-06) e Ingeniería de detalle (2026-09-03) figuran cerradas y no hay acta.
- `variance_time`: 115 días de desviación contra la línea base original (25,8%).
- `variance_cost`: la proyección supera lo aprobado en 28,9%.
- `commitment_overdue`: cinco compromisos vencidos (Laura Vélez, anexo 11, 24 días; Andrés Lozano, punto 8, 13 días; Gustavo Neira, matriz 6, 6 días; Rubén Cárdenas, matriz 14, 5 días; Felipe Arango, documento 9, 2 días). Tres de ellos se dijeron entregados en comité sin acta.
- `commitment_rescheduled`: «Enviar el documento 1» (Javier Hoyos) va en 6 reprogramaciones; «Cerrar la prueba 2» (Gustavo Neira) y «Validar el ambiente 4» (Camilo Beltrán) en 5.
- `commitment_undated`: «Aprobar el diseño 21» y «Mandar el ajuste del presupuesto» (ambos de Laura Vélez) no tienen fecha.
- `vendor_deliverable_late`: Licenciamiento del software (CT-812) debía llegar el 2026-06-15; sigue pendiente, 124 días.
- `vendor_accepted_without_evidence`: Bolsa de horas de ingeniería figura como recibida y no hay acta de recibo. Contra eso hay una factura de 63.399.928 COP del 2026-09-02, y el contrato dice que cada entregable se factura contra acta firmada.

**PRY-203**
- `progress_vs_plan`: declara 27% y el cronograma tiene los cinco hitos cerrados (sostiene 100%).
- `milestone_met_without_evidence`: los cinco hitos figuran cerrados sin una sola acta de recibo; el último vencía el 2026-09-17.
- `commitment_undated`: «Entregar el punto 31» (Mauricio Pérez) salió del comité del 16-oct sin fecha.

**PRY-205**
- `declared_vs_evidence`: declara verde con las señales que siguen.
- `progress_vs_plan`: declara 23% y el cronograma tiene 3 de 4 hitos cerrados (sostiene entre 75% y 100%).
- `rebaseline_unauthorized`: el cronograma v2 movió el cierre 75 días y la única solicitud de cambio (CC-01, +75 días) sigue «pendiente de presentación al comité»: 0 días autorizados.
- `variance_time`: 75 días contra la línea base original (14,9%).
- `milestone_met_without_evidence`: Ingeniería básica (vencía 2026-01-10) figura cerrada sin acta.

### El portafolio completo

10 proyectos más y 80 documentos por leer, en 2 lotes (diez proyectos y luego tres), uno tras otro. Estimo entre 30 y 45 minutos; es una estimación a partir de estos tres, no una medición.

### Lo que le falta a tu carpeta

Ninguno de estos es bloqueante:
- Las actas de constitución no dicen hasta dónde puede decidir el gerente, y no dicen la fase: los tres proyectos quedaron con esos dos campos vacíos.
- Alcance con «Componente 1, 2, 3» y «Lo que otro proyecto cubre»: el alcance y las exclusiones no se pueden contrastar contra nada.
- Hay hitos y entregables «cerrados» sin acta de recibo en los tres proyectos; sin ella ninguno se puede probar.
- Las notas de reunión del 17-oct de PRY-202 están sueltas en la carpeta del proyecto, fuera de `30-reuniones/`, y una fecha viene escrita «08/12/2026» (la leí día/mes, 2026-12-08).
- La solicitud CC-01 de PRY-202 dice «Autorizada por el comité», pero la minuta del 10-oct no la menciona.
- No hay ninguna fecha confirmada para el próximo comité; la dejé en 2026-10-23 por inferencia.
