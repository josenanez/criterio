# Corrida del 2026-10-17 · project-history

13 proyectos · 82 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Historia de PRY-202 sobre 19 documentos (2026-02-21 a 2026-10-17): 1 replanificación (+115 días, 25,8 %), CC-01 sin minuta que la autorice, hitos cerrados sin acta, 3 compromisos corridos 5-6 veces. No pude calcular los meses declarando sin sustento (un solo informe de avance), ni saber qué pasó entre marzo y agosto de 2026 (sin documentos), ni qué amplía CC-01.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17, familia 0.3.13); no hizo falta volver a registrarlos.

## Historia · PRY-202 · Planta de tratamiento de agua · 2026-02-21 a 2026-10-17

**Leí:** 19 documentos entre 2026-02-21 y 2026-10-17 (más la `ficha-pm.json`, que es la ficha del propio gerente: la usé para contrastar, no como evidencia).
**Trimestres sin un solo documento:** el segundo de 2026 (abril–junio). De hecho no hay nada entre 2026-02-27 y 2026-09-02, y en esa ventana cae la fecha del primer hito (2026-06-06).

### En una línea
El proyecto se constituyó el 2026-02-27 con cierre al 2027-05-28 y COP 800.000.000, y no deja un solo documento durante seis meses. Reaparece el 2026-09-02 con una factura y, desde el 2026-09-05, con comités semanales cuyos compromisos se corren cada semana. El 2026-10-10 se pide la CC-01 (+115 días, COP 230.000.000), que se declara «autorizada por el comité» sin que ninguna minuta lo registre. El 2026-10-16 el cronograma v2 mueve el cierre al 2027-09-20 y el informe de avance declara **verde, 89%** sin mencionar el cambio.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 115 días (25,8 %) | No calculable: hay un solo informe de avance (2026-10-16) y no existe serie de estados declarados | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-02-21 | `00-gobierno/2026-02-21-contrato-ct-812.docx` | Contrato con Automatización de Procesos Ltda.: 4 entregables de COP 63.399.928 c/u; se factura contra acta de recibo firmada por el gerente. Ya trae estados: licenciamiento «pendiente», bolsa de horas «recibido», calibración «en curso». |
| 2026-02-27 | `00-gobierno/2026-02-27-acta-constitucion.docx` | Línea base 1: inicio 2026-03-09, cierre 2027-05-28, COP 800.000.000 «aprobado por Comité Ambiental». Patrocinadora Laura Vélez, gerente Jorge Medina. Sin dependencias, sin producto asociado. |
| 2026-02-27 | `10-plan/2026-02-27-cronograma-v1.csv` | 5 hitos; los dos primeros (junio y septiembre de 2026, futuros a esa fecha) figuran ya como «cerrado». |
| 2026-03 a 2026-08 | — | **Ningún documento.** |
| 2026-09-02 | `20-seguimiento/2026-09-02-factura-ct-812.pdf` | Factura FV-1812 por COP 63.399.928, «radicada en cuentas por pagar». Es 19 días anterior a la fecha contractual de la bolsa de horas (2026-09-21). No hay acta de recibo del proveedor en la carpeta. |
| 2026-09-05 | `30-reuniones/2026-09-05-comite-semanal.md` | Primera minuta: 5 asistentes, 4 compromisos. |
| 2026-09-12 | `…-09-12-comite-semanal.md` | 8 compromisos; los 4 anteriores se corren (3 con fecha nueva, el anexo 3 se queda en 09-29). |
| 2026-09-19 | `…-09-19-comite-semanal.md` | Aparece Laura Vélez (patrocinadora) por primera vez; 12 compromisos, dos «por definir». |
| 2026-09-26 | `…-09-26-comite-semanal.md` | Andrés Lozano dice que ya entregó «entregar el punto 8»; no hay acta. |
| 2026-10-03 | `…-10-03-comite-semanal.md` + `20-seguimiento/2026-10-03-acta-recibo-15.md` | Primer compromiso cerrado con acta (fecha 15). Laura Vélez dice que ya entregó «revisar el anexo 11»; no hay acta. |
| 2026-10-10 | `…-10-10-comite-semanal.md` + 4 actas de recibo (3, 7, 17, 20) + `solicitud-cambio-cc-01.md` | Cierran 4 compromisos con acta. Gustavo Neira dice que ya entregó «actualizar la matriz 6»; no hay acta. Se emite CC-01: ampliación de alcance, +115 días, COP 230.000.000, «Autorizada por el comité». **La minuta de ese mismo día no menciona la solicitud.** |
| 2026-10-16 | `10-plan/2026-10-16-cronograma-v2.xlsx` | Línea base 2: «Pruebas en operación» pasa de 2027-05-28 a 2027-09-20. Los otros cuatro hitos no se mueven. |
| 2026-10-16 | `20-seguimiento/2026-10-16-informe-avance.pdf` | Declara Verde, 89 %; presupuesto aprobado COP 800.000.000, proyección COP 1.030.910.468. No menciona CC-01 ni la nueva fecha de cierre. |
| 2026-10-17 | `2026-10-17-notas-reunion.txt` | Notas sueltas (fuera de `30-reuniones`): Javier Hoyos se corre por sexta vez; Laura Vélez «queda de mandar el ajuste del presupuesto la otra semana»; se comenta que el proveedor podría no llegar con el equipo completo y «nadie lo anotó como riesgo». |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | Solicitud 2026-10-10; cronograma v2 fechado 2026-10-16 | 2027-09-20 (original: 2027-05-28) | CC-01, ampliación de alcance «sin detalle» (el alcance de la solicitud no dice qué se amplía) | Ninguno verificable: la solicitud dice «Autorizada por el comité», pero no hay minuta ni acta de comité que lo registre. La ficha del gerente pone la aprobación el 2026-10-10; el cronograma v2 está fechado seis días después. |

La solicitud mide el +115 días «sobre la línea base vigente» y, como la vigente era la original, coincide con el atraso contra la original (115 días, 25,8 %).

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | **No hay cambios de patrocinador, gerente ni comité en los documentos.** Patrocinadora Laura Vélez y gerente Jorge Medina desde el acta; comité: Comité Ambiental. | `2026-02-27-acta-constitucion.docx` |
| 2026-02-27 → 2026-09-05 | El Comité Ambiental aprueba el presupuesto el 2026-02-27 y no deja ninguna minuta hasta el 2026-09-05. | acta de constitución; `30-reuniones` |
| 2026-09-19 | La patrocinadora asiste por primera vez a un comité registrado. | `…-09-19-comite-semanal.md` |
| — | No aparece la autoridad (campo vacío en la ficha) ni la fase. | ficha |

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 6 correcciones sobre la fecha original | 2026-09-08 (original) → 09-29 → 10-16 → 10-28 → 11-13 → 11-24 → 12-08 |
| Gustavo Neira | Cerrar la prueba 2 | 5 | 2026-09-12 (original) → 10-01 → 10-16 → 10-24 → 11-09 → 11-30 |
| Camilo Beltrán | Validar el ambiente 4 | 5 | 2026-09-23 (original) → 10-12 → 10-26 → 11-12 → 11-24 → 12-05 |

Vencidos hoy sin evidencia (cálculo del script): Laura Vélez, «revisar el anexo 11» (2026-09-23, 24 días); Andrés Lozano, «entregar el punto 8» (2026-10-04, 13 días); Gustavo Neira, «actualizar la matriz 6» (2026-10-11, 6 días); Rubén Cárdenas, «actualizar la matriz 14» (2026-10-12, 5 días); Felipe Arango, «enviar el documento 9» (2026-10-15, 2 días). Sin fecha: Laura Vélez, «aprobar el diseño 21» y «mandar el ajuste del presupuesto».
Los tres compromisos «ya entregados» (puntos 8, 11 y 6) los dijo de palabra quien los tenía, salieron de las listas siguientes y nunca se presentó acta.
La fecha «08/12/2026» de las notas del 17 la leí como día/mes (2026-12-08); como mes/día no sería una fecha posible para esa serie.

### Desde cuándo lo declarado no se sostiene
**2026-06-06**: es la fecha del hito «Ingeniería básica aprobada», que figura cerrado y no tiene acta ni documento de aceptación (133 días a hoy). Le sigue «Ingeniería de detalle aprobada» (2026-09-03, 44 días), también cerrado sin evidencia. Con esos dos hitos, el plan sustenta entre 40 % y 60 % de avance, y el informe del 2026-10-16 reporta 89 % (29 puntos por encima), en Verde.
Después de esa fecha se siguió reportando, sin sustento: hitos cerrados, Verde, y un 89 % que no cambia con el atraso de 115 días ni con la proyección de costo que supera lo aprobado en 28,9 %. Además, el entregable «bolsa de horas» figura recibido sin acta, y el «licenciamiento del software» lleva 124 días vencido (2026-06-15) en estado pendiente con una factura de COP 63.399.928 ya radicada.
No puedo decir si fue un deslizamiento o un salto: solo hay un informe de avance, así que no existe una serie de estados declarados para recorrer. Lo que sí se ve es que el primer documento después del hito vencido es de septiembre.

### Lecciones ancladas a un hecho
1. **Un cambio de línea base sin rastro de aprobación.** Hecho: CC-01 (2026-10-10) dice «Autorizada por el comité» y la minuta del 2026-10-10 no la menciona; el cronograma v2 (2026-10-16) movió el cierre 115 días. Efecto: hoy no se puede demostrar quién autorizó COP 230.000.000 y 115 días.
2. **Un hito se cierra con acta, no con la palabra.** Hecho: «Ingeniería básica» (2026-06-06) y «Ingeniería de detalle» (2026-09-03) figuran cerrados sin acta; el cronograma v1, fechado 2026-02-27, ya los trae como cerrados. Efecto: el 89 % declarado se apoya en dos hitos sin respaldo.
3. **El comité se reúne y no cierra.** Hecho: «Enviar el documento 1» se corrió seis veces entre 2026-09-05 y 2026-10-17, y otros dos compromisos cinco veces cada uno, sin una causa escrita en ninguna minuta. Efecto: nadie puede decir cuándo termina cada uno.
4. **«Ya lo entregué» sin acta saca el compromiso de la lista.** Hecho: puntos 8 (2026-09-26), 11 (2026-10-03) y 6 (2026-10-10). Efecto: tres compromisos desaparecieron de las listas sin evidencia y siguen vencidos.
5. **Pagar antes de recibir.** Hecho: FV-1812 radicada el 2026-09-02 y no hay acta de recibo del proveedor, aunque el contrato factura contra acta firmada; el entregable licenciamiento sigue pendiente. Efecto: COP 63.399.928 facturados sin la condición de pago a la vista.
6. **Un riesgo dicho en reunión se pierde si no se anota.** Hecho: el 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo registró; el informe del 2026-10-16 lista un riesgo parecido sin responsable. Efecto: ningún riesgo del proyecto tiene dueño.

**Lo que no sé:** si el comité autorizó CC-01 de palabra, si hay actas de los hitos o del proveedor fuera de la carpeta, qué ocurrió entre marzo y agosto de 2026, por qué la ficha del gerente y el cronograma v2 difieren en la fecha de aprobación (10-10 frente a 10-16), y qué amplía exactamente CC-01.

Que el atraso y el cambio de línea base aparezcan sin aprobación en las actas no dice que alguien los ocultara. Esta historia sirve para tener esa conversación con datos; quién la tiene es una persona.

Puedo llevar esta historia al comité del 2026-10-23, donde hay una decisión que sale de ella (ratificar o no CC-01), o al cierre del proyecto.

---
**Pie de rigor:** cifras copiadas de `portafolio.py compute` (corte 2026-10-17); fechas y citas tomadas de los 19 documentos listados. El script cuenta 0 campos con fuente de evidencia y 28 con fuente declarativa; los hitos no tienen ninguna acta, y las únicas actas de recibo son las 5 de compromisos de comité. Es un borrador de trabajo; la verificación de cada dato es de quien lo use.
