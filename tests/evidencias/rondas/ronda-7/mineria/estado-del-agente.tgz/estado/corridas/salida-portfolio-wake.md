## 2026-10-17

**Revisé:** 95 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Nada nuevo. No hubo documentos nuevos, cambiados, renombrados ni borrados, así que no corrí `/portfolio-scan`.

Nota sobre el índice: marca como «source_missing» las citas de `pm_record` de PRY-202 (solo ese proyecto). Los archivos citados sí existen en `documentos/proyectos/PRY-202-planta-de-tratamiento-de-agua/`. Las rutas de `pm_record` van relativas a la carpeta del proyecto y las de las fichas llevan el prefijo del proyecto, así que parece un falso positivo de la comprobación y no citas rotas. No lo corregí; queda como observación.

### Peticiones atendidas
Ninguna.

### Preguntas (confirmación periódica, primera vez: nunca se había corrido)
Nadie responde en esta sesión, así que quedan preguntadas hoy sin respuesta. Cinco campos, elegidos por importancia (hitos de cierre y montaje dados por cumplidos sin acta de recibo):

1. PRY-203, hito «Pruebas en operación» (fecha 2026-09-17, estado «cumplido»): ¿qué documento lo acredita?
2. PRY-204, hito «Pruebas en operación» (fecha 2026-07-24, estado «cumplido»): ¿qué documento lo acredita?
3. PRY-206, hito «Pruebas en operación» (fecha 2026-09-24, estado «cumplido»): ¿qué documento lo acredita?
4. PRY-203, hito «Montaje e instalación» (fecha 2026-06-12, estado «cumplido»): ¿qué documento lo acredita?
5. PRY-204, hito «Montaje e instalación» (fecha 2026-05-07, estado «cumplido»): ¿qué documento lo acredita?

Los estados vienen de los cronogramas de cada proyecto; el campo de evidencia está en «no encontrado» en las fichas. No se escribe nada en las fichas hasta que haya un documento.

**Vuelvo el 2026-10-18.**
