# Portafolio — 2026-10-17
13 proyectos · 12 con hallazgos (86 señales) · 6 productos · último barrido 2026-10-17 (fichas del 2026-10-17, ninguna con más de una semana)

Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`).

## Qué cambió desde 2026-10-17
Sin cambios desde la corrida anterior. La única instantánea previa es de hoy mismo, así que este es el punto de partida y no hay delta real.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes. Sí hay 7 proyectos declarados en verde que la evidencia contradice (ver "Sin sustento").

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-201 Ampliación de la relavera | Licencia y permisos obtenidos | 2026-10-06 | 11 | sin evidencia de cumplimiento |

Hitos dados por cumplidos sin documento que lo respalde: 31 en 11 proyectos. Los más críticos: PRY-203 (5 de 5, el más viejo con 417 días), PRY-204 (5 de 5), PRY-206 (5 de 5), PRY-211 (3), PRY-209 (3).

## Proyectos en silencio
Vacía: el más callado es PRY-208 con 13 días, por debajo del umbral de 15.

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias entre proyectos. Dependencia de proveedor sí: Geotecnia Aplicada S.A.S. aparece en PRY-201, PRY-207 y PRY-208 con licenciamiento de software pendiente (31 a 102 días de atraso) y facturación sin entrega.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-201 | Verde (2026-10-07) | Hito vencido, avance 28% frente a 40–60% que soporta el plan, entregables de proveedor atrasados |
| PRY-202 | Verde (2026-10-16) | Atraso de 115 días (25,8%), sobrecosto proyectado de 28,9%, 5 compromisos vencidos |
| PRY-204 | Verde (2026-10-13) | Declara 31% con los 5 hitos "cumplidos" sin evidencia; facturado sin entrega |
| PRY-205 | Verde (2026-10-05) | Corrimiento de línea base de 75 días sin autorización |
| PRY-207 | Verde (2026-09-28) | Facturado sin entrega por 312,6 M; entregable atrasado 31 días |
| PRY-209 | Verde (2026-10-10) | Atraso de 51 días (17,3%) y compromiso vencido hace 20 días |
| PRY-210 | Verde (2026-10-15) | Dos hitos cumplidos sin evidencia |

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad del proyecto y fase |
| PRY-201, 206, 209, 210, 211 | Producto asociado |
| Casi todos | Evidencia de los hitos cumplidos (ver arriba) |
| PRY-206 | Cambio sin línea base |

Campos viejos (más de 12 meses): identidad y patrocinador en PRY-200, 203, 204, 205, 206, 211.

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | sin declaración contradicha | sin señales | 0 d | 0 d | 0 |
| PRY-200 | — | 2 hitos sin evidencia, 1 compromiso vencido | 41 d (10,7%) | 0 d | 1 |
| PRY-201 | Verde | contradicho | 0 d | 0 d | 0 |
| PRY-202 | Verde | contradicho | 115 d (25,8%) | 0 d | 1 |
| PRY-203 | — | 5 hitos sin evidencia | 0 d | 0 d | 0 |
| PRY-204 | Verde | contradicho | 0 d | 0 d | 0 |
| PRY-205 | Verde | contradicho | 75 d (14,9%) | 0 d | 1 |
| PRY-206 | — | 5 hitos sin evidencia | 47 d (11,5%) | 0 d | 1 |
| PRY-207 | Verde | contradicho | 0 d | 0 d | 0 |
| PRY-208 | — | facturado sin entrega | 0 d | 0 d | 0 |
| PRY-209 | Verde | contradicho | 51 d (17,3%) | 0 d | 1 |
| PRY-210 | Verde | contradicho | 0 d | 0 d | 0 |
| PRY-211 | — | sobrecosto proyectado 20,3% | 0 d | 0 d | 0 |

Costo: PRY-202 proyecta 1.030,9 M contra 800 M aprobados (+28,9%); PRY-211 proyecta 8.178,9 M contra 6.800 M (+20,3%).

## Necesito que confirmes
Pregunta de confirmación mensual; sin interfaz tomo la sugerida y sigo:
1. ¿Quién es la autoridad de cada proyecto? Falta en los 13 (queda como vacío).
2. PRY-206: ¿el patrocinador sigue siendo el del acta de 2025-06?
3. PRY-211: ¿el patrocinador sigue siendo el del acta de 2025-07?
4. PRY-205: ¿el corrimiento de 75 días tiene aprobación fuera de los documentos?
5. PRY-206, 211, 201, 209, 210: ¿a qué producto pertenecen?

---
Informe HTML en `reportes/`: `index.html` (por campo, con cadena de evidencia, para quien actúa) y `decisiones.html` (por decisión, para el patrocinador), más una página por proyecto y por producto (23 páginas). El PDF sale de imprimir el HTML.

Pie: criterio-portfolio 0.3.13 · fichas del 2026-10-17 · campos inciertos: autoridad, fase y evidencia de hitos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
