# Corrida del 2026-10-17 · portfolio-scan

13 proyectos · 95 documentos, 0 releídos y 95 sin cambio · 293 s · 86 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 31 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 8 |
| `vendor_deliverable_late` | 8 |
| `declared_vs_evidence` | 7 |
| `variance_time` | 5 |
| `vendor_invoiced_without_delivery` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `milestone_overdue` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

10 fichas nuevas (PRY-199, 200, 201, 204, 206, 207, 208, 209, 210, 211) escritas y selladas; 63 de 95 documentos leidos, 32 sin cambio (PRY-202, 203, 205 intactos). No hay carpeta entrada/: nada se movio. A mirar: 5 proyectos en verde contradichos por la evidencia, 23 hitos cerrados sin acta, facturas sin acta de recibo en PRY-201/204/207/208, compromisos fechados antes de su minuta en PRY-200/204/209, cita sin resolver en pm_record de PRY-202.

Contra la corrida del 2026-10-17: +56 hallazgos.

## Lo que produjo

## Barrido — 2026-10-17

Encontré una carpeta de **13 proyectos y 95 documentos**, y una configuración con los términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos otra vez). Tres proyectos (PRY-202, PRY-203, PRY-205) ya tenían ficha y no cambiaron; los otros diez no tenían.

**Documentos:** 95 en la carpeta · 63 leídos · 32 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia
**Formatos:** 45 .md, 16 .docx, 14 .pdf, 13 .xlsx, 5 .csv, 1 .txt, 1 .json. Todos se pudieron leer.
**Plan de lectura:** un lote de 10 proyectos, uno tras otro (`workers: 1`); nada quedó diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan (5 hitos), presupuesto, contrato CT-199, 1 compromiso | autoridad, fase, facturado (CT-199), evidencia de 4 hitos y de 3 entregables |
| PRY-200 Mantenimiento predictivo de camiones | 7 | identidad, plan v1 y v2, presupuesto, CC-01, 1 compromiso | autoridad, fase, evidencia de 3 de los 4 hitos (solo «Licencia y permisos» tiene acta) |
| PRY-201 Ampliación de la relavera | 10 | identidad, plan, presupuesto, 2 contratos (CT-393, CT-663), 2 facturas, 2 actas de recibo, 1 compromiso | producto (el acta dice «No aplica»), autoridad, fase, evidencia de 8 hitos y entregables |
| PRY-204 Monitoreo de taludes | 6 | identidad, plan, presupuesto, contrato CT-734, factura, 1 compromiso | autoridad, fase, evidencia de los 5 hitos y de los 2 entregables |
| PRY-206 Red privada LTE en mina | 6 | identidad, plan v1 y v2, presupuesto, CC-01, 1 compromiso | producto («No aplica»), autoridad, fase, evidencia de los 5 hitos |
| PRY-207 Gemelo digital de la planta | 7 | identidad, plan, presupuesto, contrato CT-367, factura, 1 acta de recibo, 1 compromiso sin fecha | autoridad, fase, evidencia de 4 hitos y de los 4 entregables |
| PRY-208 Trazabilidad del mineral | 6 | identidad, plan, presupuesto, contrato CT-929, factura, 1 acta de recibo | autoridad, fase, evidencia de 4 hitos y de los 2 entregables; no hay carpeta de reuniones |
| PRY-209 Electrificación de equipos | 7 | identidad, plan v1 y v2, presupuesto, CC-01, 2 compromisos | producto («No aplica»), autoridad, fase, evidencia de 3 hitos |
| PRY-210 Programa de relacionamiento comunitario | 4 | identidad, plan (3 hitos), presupuesto, 1 compromiso | producto («No aplica»), autoridad, fase, evidencia de los 3 hitos |
| PRY-211 Control de polvo en vías | 4 | identidad, plan, presupuesto, 1 compromiso | producto («No aplica»), autoridad, fase, evidencia de los 4 hitos |

`identity.authority` (hasta dónde decide el gerente sin subir a comité) no aparece en ninguna de las 13 actas.

### Actualizados
Ninguno. PRY-202, PRY-203 y PRY-205 tenían los 32 documentos sin cambio, así que no se abrió ninguno y sus fichas siguen como estaban.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 95 archivos se convirtieron a texto. |

### Movidos desde entrada/
No existe carpeta `entrada/` en este espacio. No se movió nada.

### Pendientes de clasificar
Ninguno. Hay un archivo suelto en la raíz de PRY-202 (`2026-10-17-notas-reunion.txt`); ya está leído y citado en esa ficha, y no lo moví.

---

## Lo que hay que mirar (de las 10 fichas nuevas)

Cifras del cálculo del script sobre las fichas, con fecha de corte 2026-10-17. Son lecturas de documentos, no veredictos.

**El estado declarado no lo sustenta la evidencia.** Con estado verde: PRY-201, PRY-204, PRY-207, PRY-209 y PRY-210. Hay más señales de este tipo en PRY-202 y PRY-205, que no se tocaron.
- **PRY-204** declara verde y 31% de avance, pero su cronograma da los 5 hitos por cerrados (el último, el 2026-07-24), y ninguno tiene acta de recibo.
- **PRY-206** declara rojo y 52% con los 5 hitos cerrados y sin acta. Es la contradicción más grande entre cronograma y avance.
- **PRY-209** declara verde y 36% con los 4 hitos cerrados. Su acta de recibo de «Montaje e instalación» es del 2026-10-06, pero el cronograma v2 mueve ese mismo hito al 2026-11-29 (+51 días, CC-01) y lo deja `cerrado`.

**Hitos cerrados sin acta que lo pruebe:** 23 entre las 10 fichas nuevas (los más pesados: PRY-204 y PRY-206 con 5 cada uno).

**Facturas contra entregables sin acta de recibo:**
- PRY-201 (CT-393): FV-1393 por 337.474.541 COP, sin ningún entregable recibido.
- PRY-201 (CT-663): FV-2663 por 546.514.606 COP, y solo está aceptado «Licenciamiento» por 402.930.357; la diferencia es de 143.584.249 COP.
- PRY-204 (CT-734): 213.183.796 COP facturados, y los dos entregables siguen pendientes, con 331 y 189 días de atraso.
- PRY-207 (CT-367): 312.596.415 COP facturados el 2026-09-05, antes de la fecha del primer entregable y sin acta.
- PRY-208 (CT-929): 319.737.266 COP facturados el 2026-10-01 con ambos entregables pendientes.

**Compromisos vencidos** (3 en estas fichas):
- PRY-200: Óscar Ramírez, punto 12, para el 2026-10-10.
- PRY-204: Elena Duarte, punto 34, para el 2026-10-05.
- PRY-209: Rubén Cárdenas, punto 22, para el 2026-09-27.
- En los tres casos la fecha es anterior a la minuta que lo registró. En PRY-200, PRY-204 y PRY-209 quien responde ni siquiera figura entre los asistentes.
- PRY-207 tiene un compromiso sin fecha («por definir», Ricardo Salas).

**Plazo y costo:**
- Desviación de plazo contra la línea base original de PRY-200 (+41 días), PRY-206 (+47) y PRY-209 (+51), todas por CC-01 (ampliación de alcance «autorizada por el comité», sin nombrar el comité ni citar acta).
- En PRY-206, el cronograma v2 es del 2026-10-05 y la CC-01 del 2026-10-06: la línea base nueva es anterior al cambio que la justifica (`change_without_baseline`).
- PRY-211: la proyección al cierre (8.178.934.417 COP) supera en 20,3% el presupuesto aprobado (6.800.000.000 COP).
- PRY-200: lo ejecutado (5.333.861.988 COP) es mayor que lo comprometido (3.022.645.496 COP) en el informe del gerente; se registró tal cual.

**Gobierno:** en PRY-209 el patrocinador y el gerente son la misma persona (Laura Vélez) y la minuta de comité lista dos veces a esa persona como asistente. Los cambios de patrocinador, de gerente o de comité: ninguno detectado.

**Una cita que no resuelve (PRY-202, no se tocó):** el índice marca como `source_missing` los campos de `pm_record` de PRY-202, porque la ficha del gerente cita rutas sin el nombre de la carpeta del proyecto. Le toca al agente del proyecto; no copié nada a la ficha de la PMO.

**PRY-199** sale limpio: ninguna señal. Los hitos futuros están pendientes, el único hito cerrado tiene su acta y no hay facturas.

---

## Pie

criterio-portfolio 0.3.13 · términos v1.1 (vigentes) · 10 fichas escritas y selladas (PRY-199, 200, 201, 204, 206, 207, 208, 209, 210, 211) · campos en `not_found` por ficha: 10, 5, 11, 9, 8, 10, 8, 6, 6, 7 (80 en total).
Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

**Siguiente paso:** hay más de un proyecto, así que está listo el informe consolidado (`/criterio-portfolio:portfolio-report`). La contradicción entre estado declarado y evidencia, y las facturas sin acta, son lo primero que debería ver el comité del 2026-10-23.
