Fuente: ficha `estado/records/PRY-201.json` (actualizada 2026-10-17) y cálculo de `portafolio.py compute` al 2026-10-17.

## PRY-201 · Ampliación de la relavera — estado al 2026-10-17

**Declara el gerente (Sandra Gil):** verde · 28% · al 2026-10-07 (hace 10 días; la declaración no está vencida)
**Sustento documental:** contradicho. La alerta `declared_vs_evidence` está abierta.
**Lo que el semáforo no explica:**
- hito dado por cumplido sin evidencia (`milestone_met_without_evidence`)
- hito vencido (`milestone_overdue`)
- avance por debajo del plan (`progress_vs_plan`)
- entregable de proveedor atrasado (`vendor_deliverable_late`)
- facturado sin entrega (`vendor_invoiced_without_delivery`)
- facturado por encima de lo aceptado (`vendor_invoiced_over_accepted`)

**Último documento:** 2026-10-10 (hace 7 días; el umbral de silencio es 15) · **Última reunión:** 2026-10-05 (comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-26 | 2027-01-26 | 0 días (0 vs original, 0 vs vigente) |
| Presupuesto (COP) | 4.200.000.000 aprobado | proyección declarada 4.077.850.670 | −2,9% (la proyección queda bajo lo aprobado) |

Replanificaciones: 0. Hay una sola línea base (v1, 2026-04-11). No hay solicitudes de cambio.

Dinero (COP): comprometido 2.607.597.890 (62,1%), ejecutado 1.067.730.191 (25,4%), disponible real 1.592.402.110. Comprometido, ejecutado y proyección son cifras declaradas en el informe del 2026-10-07; no hay otra fuente que las contraste.

Avance: el 28% declarado está 12,0 puntos por debajo de lo que el plan sustenta (entre 40% y 60%, con 2 de 5 hitos cumplidos).

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-06-16 | 2026-06-16 | cumplido | Acta de recibo del 2026-10-10 |
| Ingeniería de detalle aprobada | 2026-08-11 | 2026-08-11 | declarado cumplido | **Ninguna** (67 días desde la fecha) |
| Licencia y permisos obtenidos | 2026-10-06 | 2026-10-06 | pendiente | Ninguna; **vencido hace 11 días** |
| Montaje e instalación | 2026-12-01 | 2026-12-01 | pendiente | Ninguna |
| Pruebas en operación | 2027-01-26 | 2027-01-26 | pendiente | Ninguna |

### Dónde no coincide
- **Verde (informe del 2026-10-07) frente a licencia vencida.** El cronograma v1 (2026-04-11) fecha la licencia el 2026-10-06 y sigue pendiente, sin replanificación registrada. El verde no explica ese vencimiento.
- **Ingeniería de detalle «cumplida» sin acta de recibo.** El cronograma la marca cumplida, pero la ficha no encuentra evidencia. La ingeniería básica sí tiene acta, y es del 2026-10-10, no de junio.
- **Proveedor Geotecnia Aplicada S.A.S., CT-393.** Factura del 2026-08-28 por 337.474.541; 0 de 3 entregables aceptados. «Licenciamiento del software» (vencía 2026-07-07) lleva 102 días de atraso. «Bolsa de horas de ingeniería» (vencía 2026-09-22) lleva 25. Ambos están pendientes.
- **Proveedor Geotecnia Aplicada S.A.S., CT-663.** Factura del 2026-09-06 por 546.514.606 frente a 402.930.357 aceptados (acta de recibo del 2026-08-07): **143.584.249 facturados sin aceptación**. «Bolsa de horas de ingeniería» vence el 2026-11-12 y está pendiente.
- **Observación no calculada por el script:** CT-393 y CT-663 tienen entregables homónimos («Licenciamiento del software», «Bolsa de horas de ingeniería») con el mismo proveedor. Conviene confirmar si hay doble contratación; los documentos no lo aclaran.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: ventana de parada de planta definida por operaciones. Sin responsable, probabilidad, impacto ni fecha.
- Riesgo: cambio en la licencia ambiental que puede mover el alcance. Sin responsable ni valoración. Se conecta con el hito de licencia vencido.
- Incidencia: lluvias detuvieron el montaje diez días (desde 2026-10-07). Sin responsable. Se declara, pero no aparece trasladada al cronograma: el montaje sigue en 2026-12-01.
**Compromisos vencidos:** ninguno. Hay uno abierto: Óscar Ramírez, «Entregar el punto 11», fijado el 2026-10-05 para el 2026-11-06, sin reprogramaciones.
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- Producto, autoridad de aprobación y fase del proyecto: no encontrados.
- Evidencia de cumplimiento de los hitos 2 a 5 y de 4 de los 5 entregables de proveedor.
- Valoración (probabilidad, impacto, responsable, fecha) de los dos riesgos.
- Las cifras de dinero vienen del informe de avance del gerente; ningún documento contable las respalda.
- Los documentos tienen 5 declaraciones y 0 evidencias marcadas como tal; 52 elementos quedan sin marcar.

### Siguiente paso
La alerta `declared_vs_evidence`, el hito de licencia vencido y 143.584.249 facturados sin aceptación justifican llevarlo al comité (próximo: 2026-10-23). Puedo preparar el punto de comité con `/steering-pack`, y revisar el control de pagos al proveedor con `/vendor-tracking`.

---
Criterio Portfolio v0.3.13 · ficha aplicada: PRY-201, actualizada 2026-10-17 · campos inciertos: los listados en «Sin dato» · Términos v1.1 aceptados el 2026-10-17 por José Francisco Ñáñez: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
