**Fuente de este cierre:** ficha `estado/records/PRY-203.json` y los 4 documentos de `documentos/proyectos/PRY-203-despacho-automático-de-flota/`: acta de constitución (2025-05-12, .docx), cronograma v1 (2025-05-12, .csv), informe de avance (corte 2026-10-13) y acta del Comité Ambiental (2026-10-16). Cifras derivadas: salida de `portafolio.py compute` del 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## Cierre — PRY-203 Despacho automático de flota — 2026-10-17

**Veredicto: el proyecto no se puede cerrar contra su criterio de éxito con la documentación disponible.** No hay evidencia de que se cumpliera, y lo poco que hay (informe de avance) apunta en sentido contrario. Si se cierra, se cierra por decisión de alguien con nombre, no por cumplimiento, y esa decisión tiene que quedar escrita.

### Contra lo comprometido
**Criterio de éxito:** "Despacho automático de flota en producción y medido." (acta de constitución, 2025-05-12, sección *Fechas comprometidas*). Está declarado, pero sin umbral: no dice qué se mide, con qué valor ni quién lo mide. Así no se puede verificar cumplimiento, solo existencia.
**Se cumplió:** no se puede determinar.
- Ningún documento muestra el sistema en producción ni una medición.
- El informe de avance (2026-10-13) dice que "el primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite". Con ese ensayo sin superar, "en producción y medido" no está sustentado.
- El avance declarado es 27 %. El cronograma marca los 5 hitos como cerrados, lo que equivale a 100 %. Diferencia: 73 puntos.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| "Componente 1", "Componente 2", "Componente 3" (alcance del acta) | No se puede contrastar: el acta no los describe | Ninguna |
| Ingeniería básica aprobada (2025-08-26) | Declarado cerrado, sin evidencia | Ninguna; solo el estado "cerrado" del cronograma v1 |
| Ingeniería de detalle aprobada (2025-12-01) | Declarado cerrado, sin evidencia | Ninguna |
| Licencia y permisos obtenidos (2026-03-08) | Declarado cerrado, sin evidencia | Ninguna |
| Montaje e instalación (2026-06-12) | Declarado cerrado, sin evidencia | Ninguna |
| Pruebas en operación (2026-09-17) | Declarado cerrado, sin evidencia, y contradicho por el ensayo de disponibilidad no superado | Ninguna |

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| No hay recorte registrado | — | — |

El acta solo dice "Lo que otro proyecto cubre". Hay 0 solicitudes de cambio registradas, así que no hay decisión de alcance que citar. Como los componentes no están descritos, no se puede decir si algo se recortó sin registro.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-09-17 | 2026-09-17 | Sin dato: no hay fecha real de cierre | 0 días (según `compute`) |
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | — | — |

- Replanificaciones: 0. La línea base tiene una sola versión (v1, 2025-05-12).
- **Cuidado con la desviación de 0 días.** Sale de comparar fechas planeadas contra fechas planeadas. No hay fecha real de término. Hoy son 30 días desde el 2026-09-17, y el informe de avance sigue hablando de ensayos pendientes. Eso no equivale a "cumplió a tiempo".
- Presupuesto, tal como lo declara el informe del 2026-10-13 (declaración, no evidencia contable):
  - Aprobado: 3.300.000.000 COP.
  - Comprometido: 2.231.152.131 COP, 67,6 % del aprobado.
  - Ejecutado: 1.736.575.747 COP, 52,6 % del aprobado.
  - Proyección al cierre: 3.044.295.228 COP, 7,7 % por debajo del aprobado.
  - Disponible real: 1.068.847.869 COP.
- No existe un "ejecutado final". Con el 52,6 % ejecutado y una proyección de 3.044.295.228 COP, falta ejecutar dinero que el informe todavía espera gastar. El presupuesto final no se puede cerrar.
- El informe menciona "se actualizó el presupuesto de la obra con el área de compras", pero no hay solicitud de cambio ni línea base de costo nueva (0 cambios registrados).

### RAID al cierre
**Materializados:** ninguno confirmado como riesgo materializado. Hay dos incidencias activas desde el 2026-10-13:
- El primer ensayo de disponibilidad no alcanzó lo pactado y se repite.
- Hallazgo en la auditoría de seguridad (el informe no dice cuál).

**No materializados:** no se puede determinar. Los dos riesgos del informe siguen listados como abiertos:
- Bloqueo de la vía de acceso a la mina.
- Cambio en la licencia ambiental que puede mover el alcance.

**Abiertos, con doliente:**

| Ítem | Doliente | Fecha |
|---|---|---|
| Ensayo de disponibilidad (incidencia) | **Sin doliente** | Sin fecha de resolución |
| Hallazgo de auditoría de seguridad (incidencia) | **Sin doliente** | Sin fecha de resolución |
| Riesgo: bloqueo de la vía de acceso | **Sin doliente** | Sin probabilidad, impacto ni fecha |
| Riesgo: cambio en licencia ambiental | **Sin doliente** | Sin probabilidad, impacto ni fecha |
| Compromiso "Entregar el punto 31" (comité 2026-10-16) | Mauricio Pérez | **Sin fecha** ("por definir"); el documento no explica qué es el "punto 31" |

Lo abierto no tiene doliente con nombre, salvo un compromiso sin fecha. Por la regla del cierre, **esto no está cerrado**.

### Lecciones
Solo entran las que se sustentan en un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1, fechado el día de aprobación del acta, ya trae los 5 hitos como "cerrado", incluidos los que vencen entre 2025-08-26 y 2026-09-17 | 2025-05-12 (archivo) | El plan indica 100 % y el informe del 2026-10-13 declara 27 %; hay 73 puntos de brecha y ningún hito tiene evidencia de cierre | Exigir evidencia de aceptación (acta de aprobación, informe de pruebas) para marcar un hito como cerrado, y no aceptar el estado del cronograma como evidencia |
| El criterio de éxito se pactó sin umbral: "en producción y medido" | 2025-05-12 | Hoy no se puede decir si se cumplió; el único dato de medición (ensayo de disponibilidad) dice que no alcanzó lo pactado, y no se sabe qué se pactó | Fijar en el acta qué se mide, con qué valor mínimo y quién lo certifica |
| El alcance se aprobó como "Componente 1, 2 y 3" sin describirlos | 2025-05-12 | El cierre no puede contrastar entregado contra comprometido | Nombrar cada entregable en el acta, con su criterio de aceptación |
| Riesgos e incidencias reportados sin doliente ni fecha | 2026-10-13 | Ninguno se puede dar por cerrado ni se sabe a quién reclamarlo | Registrar doliente y fecha al abrir cada ítem RAID |

### Sin dato
- Si el sistema está en producción y qué se midió. Ningún documento lo muestra.
- Qué se pactó para el ensayo de disponibilidad, y su resultado numérico.
- Evidencia de cierre de cualquiera de los 5 hitos. La ficha tiene 0 fuentes de evidencia, 5 declaraciones y 25 campos sin marca.
- Cuáles eran los tres componentes del alcance.
- Fecha real de término y gasto final: el informe es de corte 2026-10-13 y declara el proyecto en curso.
- Autoridad que aprobaría el cierre (`identity.authority`) y fase actual (`identity.phase`): ambos campos no encontrados.
- Qué es el "punto 31", y qué hallazgo concreto levantó la auditoría de seguridad.
- Qué cambió en el presupuesto de la obra con compras, y quién lo aprobó.
- Los campos de identidad, fechas, hitos y alcance se leen de documentos de hace 17 meses (2025-05-12), por encima del umbral de 12 meses.

### Pie de rigor
Borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados arriba y la verificación es suya. Las cifras derivadas se copiaron de `portafolio.py compute` del 2026-10-17. El dinero y el avance son declaraciones del informe del 2026-10-13, no evidencia contable.
