<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-14
**Gerente:** Paula Céspedes

## Estado declarado

**Amarillo**

Avance reportado: **50%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.022.645.496 |
| Ejecutado | 5.333.861.988 |
| Proyección al cierre | 9.416.500.158 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
