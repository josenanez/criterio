<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2026-03-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Mantenimiento

Patrocinador: Felipe Arango

Gerente de proyecto: Carlos Peña

Comité: Comité de Operaciones

Producto asociado: trazabilidad

Fecha de aprobación: 2026-03-29

Objetivo del negocio

Entregar trazabilidad del mineral para Mantenimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Operaciones el 2026-03-29.

Fechas comprometidas

Fecha

Inicio

2026-04-08

Cierre

2026-12-15

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
