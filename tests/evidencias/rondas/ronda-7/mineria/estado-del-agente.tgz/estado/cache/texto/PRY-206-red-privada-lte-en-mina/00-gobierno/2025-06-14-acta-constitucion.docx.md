<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2025-06-14-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Mina

Patrocinador: Camilo Beltrán

Gerente de proyecto: Laura Vélez

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2025-06-14

Objetivo del negocio

Entregar red privada lte en mina para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité Ambiental el 2025-06-14.

Fechas comprometidas

Fecha

Inicio

2025-06-24

Cierre

2026-08-08

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
