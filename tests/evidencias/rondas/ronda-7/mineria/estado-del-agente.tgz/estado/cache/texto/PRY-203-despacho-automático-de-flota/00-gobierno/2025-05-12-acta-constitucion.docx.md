<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/2025-05-12-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Despacho automático de flota

Código: PRY-203

Área dueña: Planta de procesamiento

Patrocinador: Liliana Torres

Gerente de proyecto: Sandra Gil

Comité: Comité Ambiental

Producto asociado: despacho de flota

Fecha de aprobación: 2025-05-12

Objetivo del negocio

Entregar despacho automático de flota para Planta de procesamiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité Ambiental el 2025-05-12.

Fechas comprometidas

Fecha

Inicio

2025-05-22

Cierre

2026-09-17

Criterio de éxito

Despacho automático de flota en producción y medido.

Dependencias declaradas

• Ninguna declarada
