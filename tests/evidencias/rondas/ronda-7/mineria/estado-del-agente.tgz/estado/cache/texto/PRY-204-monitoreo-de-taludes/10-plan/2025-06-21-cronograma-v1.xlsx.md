<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2025-06-21-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-09-16 | 2025-09-16 | cerrado
Ingeniería de detalle aprobada | 2025-12-03 | 2025-12-03 | cerrado
Licencia y permisos obtenidos | 2026-02-18 | 2026-02-18 | cerrado
Montaje e instalación | 2026-05-07 | 2026-05-07 | cerrado
Pruebas en operación | 2026-07-24 | 2026-07-24 | cerrado
