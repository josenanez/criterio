<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2026-03-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-28 | 2026-05-28 | cerrado
Ingeniería de detalle aprobada | 2026-07-17 | 2026-07-17 | cerrado
Licencia y permisos obtenidos | 2026-09-06 | 2026-09-06 | cerrado
Montaje e instalación | 2026-10-26 | 2026-10-26 | en curso
Pruebas en operación | 2026-12-15 | 2026-12-15 | en curso
