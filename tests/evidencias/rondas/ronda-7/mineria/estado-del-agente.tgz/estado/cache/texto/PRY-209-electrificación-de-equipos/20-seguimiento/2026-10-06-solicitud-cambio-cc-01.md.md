<!-- origen: PRY-209-electrificación-de-equipos/20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-209 · Electrificación de equipos
**Fecha:** 2026-10-06
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +51 días sobre la línea base vigente |
| Costo | 102.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
