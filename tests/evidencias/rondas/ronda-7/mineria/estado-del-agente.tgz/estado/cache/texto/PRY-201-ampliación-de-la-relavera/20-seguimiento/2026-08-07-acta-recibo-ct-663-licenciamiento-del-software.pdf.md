<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-08-07-acta-recibo-ct-663-licenciamiento-del-software.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento del software
Proyecto: PRY-201 · Ampliación de la relavera
Fecha de recibo: 2026-08-07
Recibido por: Sandra Gil
Se recibe a satisfacción el entregable Licenciamiento del software.
Contrato CT-663 · Geotecnia Aplicada S.A.S..
