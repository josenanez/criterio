<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Gemelo digital de la planta

**Fecha:** 2026-10-15
**Asistentes:** Mauricio Pérez, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 22 | por definir |
