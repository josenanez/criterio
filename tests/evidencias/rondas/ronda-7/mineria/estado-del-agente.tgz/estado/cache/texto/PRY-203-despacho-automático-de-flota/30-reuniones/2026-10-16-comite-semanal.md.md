<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Despacho automático de flota

**Fecha:** 2026-10-16
**Asistentes:** Sandra Gil, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 31 | por definir |
