<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Sistema de gestión de seguridad
Código: PRY-205
Fecha de corte: 2026-10-05
Gerente: Diana Molina

Estado declarado
Verde
Avance reportado: 23%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se reprogramó la parada de planta por la ventana de mantenimiento

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 7.020.019.643
Ejecutado 3.368.186.143
Proyección al cierre 9.819.592.992

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Bloqueo de la vía de acceso a la mina
