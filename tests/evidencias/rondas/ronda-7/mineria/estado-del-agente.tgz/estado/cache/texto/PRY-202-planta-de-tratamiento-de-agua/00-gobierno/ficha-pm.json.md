<!-- origen: PRY-202-planta-de-tratamiento-de-agua/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-202",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "name": {
 "value": "Planta de tratamiento de agua",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "business_area": {
 "value": "Logística",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "not_found",
 "note": "El acta dice «No aplica»."
 },
 "authority": {
 "value": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Laura Vélez",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "manager": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "committee": {
 "value": "Comité Ambiental",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "phase": {
 "value": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 89,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-16",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-03-09",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "end_date": {
 "value": "2027-09-20",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-02-27",
 "start_date": "2026-03-09",
 "end_date": "2027-05-28",
 "reason": "Aprobación inicial del acta de constitución",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx"
 },
 {
 "version": 2,
 "approved_on": "2026-10-10",
 "start_date": "2026-03-09",
 "end_date": "2027-09-20",
 "reason": "CC-01, ampliación de alcance: +115 días sobre la línea base vigente. Fecha del documento; la minuta del 2026-10-10 no menciona la autorización.",
 "source": "20-seguimiento/2026-10-10-solicitud-cambio-cc-01.md"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Ingeniería básica aprobada",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-06-06",
 "source": "10-plan/2026-02-27-cronograma-v1.csv",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "current_date": {
 "value": "2026-06-06",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Ingeniería de detalle aprobada",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-09-03",
 "source": "10-plan/2026-02-27-cronograma-v1.csv",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "current_date": {
 "value": "2026-09-03",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Licencia y permisos obtenidos",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-12-01",
 "source": "10-plan/2026-02-27-cronograma-v1.csv",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "current_date": {
 "value": "2026-12-01",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Montaje e instalación",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-02-28",
 "source": "10-plan/2026-02-27-cronograma-v1.csv",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "current_date": {
 "value": "2027-02-28",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Pruebas en operación",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-05-28",
 "source": "10-plan/2026-02-27-cronograma-v1.csv",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "current_date": {
 "value": "2027-09-20",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-16-cronograma-v2.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3 (más la ampliación de CC-01, sin detalle)",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "approved": {
 "value": 800000000,
 "source": "00-gobierno/2026-02-27-acta-constitucion.docx",
 "source_date": "2026-02-27",
 "state": "found"
 },
 "committed": {
 "value": 300578510,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 194512198,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 1030910468,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Automatización de Procesos Ltda.",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-812",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del software",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-06-15",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "amount": {
 "value": 63399928,
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-21",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "amount": {
 "value": 63399928,
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "state": {
 "value": "accepted",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Calibración de sensores",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-28",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "amount": {
 "value": 63399928,
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Soporte del primer trimestre",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "due_date": {
 "value": "2027-04-05",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "amount": {
 "value": 63399928,
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx",
 "source_date": "2026-02-21",
 "state": "found",
 "source_kind": "declaration"
 },
 "evidence": {
 "value": null,
 "state": "not_found"
 }
 }
 ],
 "invoiced": {
 "value": 63399928,
 "source": "20-seguimiento/2026-09-02-factura-ct-812.pdf",
 "source_date": "2026-09-02",
 "state": "found"
 },
 "source": "00-gobierno/2026-02-21-contrato-ct-812.docx"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "El proveedor no ha confirmado la fecha de la última entrega",
 "owner": null,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16"
 },
 {
 "what": "Ventana de parada de planta definida por operaciones (listada como riesgo abierto en el informe)",
 "owner": null,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión; nadie lo anotó como riesgo)",
 "owner": null,
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un ingeniero clave",
 "since": null,
 "owner": null,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-10",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+115 días sobre la línea base vigente",
 "cost_impact": "230.000.000 COP adicionales",
 "decision": "approved",
 "decided_by": "Comité (según la solicitud; sin minuta ni acta que lo registre)",
 "source": "20-seguimiento/2026-10-10-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "n": 1,
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-08",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-08",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-09-29",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-08",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "note": "Fecha de las notas del 17: «08/12/2026», leída día/mes (2026-12-08); si es mes/día, no es una fecha posible para esta serie."
 },
 {
 "n": 2,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-30",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-12",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-01",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-09",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-30",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 3,
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-10",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-3.md",
 "source": "20-seguimiento/2026-10-10-acta-recibo-3.md",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 {
 "n": 4,
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-05",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "source_date": "2026-09-05",
 "state": "found"
 },
 "stated_on": "2026-09-05",
 "source": {
 "value": "30-reuniones/2026-09-05-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-12-05",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 5,
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-21",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 6,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-15",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "note": "Salió de la lista del 10-10 sin acta; ese día dijo que ya lo entregó y «no se presentó acta»."
 },
 {
 "n": 7,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-7.md",
 "source": "20-seguimiento/2026-10-10-acta-recibo-7.md",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 {
 "n": 8,
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-04",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-04",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "source_date": "2026-09-12",
 "state": "found"
 },
 "stated_on": "2026-09-12",
 "source": {
 "value": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "El 09-26 dijo que ya lo entregó y «no se presentó acta»; desde entonces no figura en las listas."
 },
 {
 "n": 9,
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "n": 10,
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-25",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-25",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 11,
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [],
 "note": "El 10-03 dijo que ya lo entregó y «no se presentó acta»."
 },
 {
 "n": 12,
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "source_date": "2026-09-19",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-05",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-19",
 "source": {
 "value": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 13,
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 14,
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "n": 15,
 "who": {
 "value": "Jorge Medina",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-22",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-03-acta-recibo-15.md",
 "source": "20-seguimiento/2026-10-03-acta-recibo-15.md",
 "source_date": "2026-10-03",
 "state": "found"
 }
 },
 {
 "n": 16,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "source_date": "2026-09-26",
 "state": "found"
 },
 "stated_on": "2026-09-26",
 "source": {
 "value": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 17,
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-17.md",
 "source": "20-seguimiento/2026-10-10-acta-recibo-17.md",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 {
 "n": 18,
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-16",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-26",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-16",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "n": 19,
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 20,
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-07",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-07",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "source_date": "2026-10-03",
 "state": "found"
 },
 "stated_on": "2026-10-03",
 "source": {
 "value": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-10-acta-recibo-20.md",
 "source": "20-seguimiento/2026-10-10-acta-recibo-20.md",
 "source_date": "2026-10-10",
 "state": "found"
 }
 },
 {
 "n": 21,
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 22,
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-05",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-05",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 23,
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 24,
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-01",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-01",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "source_date": "2026-10-10",
 "state": "found"
 },
 "stated_on": "2026-10-10",
 "source": {
 "value": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "n": 25,
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "stated_on": "2026-10-17",
 "source": {
 "value": "2026-10-17-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Notas del 17: «la otra semana», sin fecha."
 },
 {
 "n": 26,
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-27",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "stated_on": "2026-10-17",
 "source": {
 "value": "2026-10-17-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
