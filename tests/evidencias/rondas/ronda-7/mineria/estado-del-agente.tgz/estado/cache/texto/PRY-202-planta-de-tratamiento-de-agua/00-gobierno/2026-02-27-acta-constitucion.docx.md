<!-- origen: PRY-202-planta-de-tratamiento-de-agua/00-gobierno/2026-02-27-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Planta de tratamiento de agua

Código: PRY-202

Área dueña: Logística

Patrocinador: Laura Vélez

Gerente de proyecto: Jorge Medina

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2026-02-27

Objetivo del negocio

Entregar planta de tratamiento de agua para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité Ambiental el 2026-02-27.

Fechas comprometidas

Fecha

Inicio

2026-03-09

Cierre

2027-05-28

Criterio de éxito

Planta de tratamiento de agua en producción y medido.

Dependencias declaradas

• Ninguna declarada
