<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Gemelo digital de la planta
Código: PRY-207
Fecha de corte: 2026-09-28
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 38%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.425.472.768
Ejecutado 1.131.289.671
Proyección al cierre 3.888.195.188

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
