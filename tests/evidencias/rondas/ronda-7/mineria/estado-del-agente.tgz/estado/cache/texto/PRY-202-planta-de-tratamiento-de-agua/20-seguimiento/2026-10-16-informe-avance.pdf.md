<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-16
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 89%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 800.000.000
Comprometido 300.578.510
Ejecutado 194.512.198
Proyección al cierre 1.030.910.468

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Ventana de parada de planta definida por operaciones
