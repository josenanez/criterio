<!-- origen: PRY-202-planta-de-tratamiento-de-agua/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión planta de tratamiento de agua — 2026-10-17
estuvieron: Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Javier Hoyos dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 08/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
