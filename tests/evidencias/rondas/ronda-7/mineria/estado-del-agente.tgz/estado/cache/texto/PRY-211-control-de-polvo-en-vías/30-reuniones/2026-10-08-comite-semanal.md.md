<!-- origen: PRY-211-control-de-polvo-en-vías/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Control de polvo en vías

**Fecha:** 2026-10-08
**Asistentes:** Gustavo Neira, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Camilo Beltrán | Entregar el punto 23 | 2026-11-10 |
