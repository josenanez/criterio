<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2025-06-14-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-09-14,2025-09-14,cerrado
Ingeniería de detalle aprobada,2025-12-05,2025-12-05,cerrado
Licencia y permisos obtenidos,2026-02-25,2026-02-25,cerrado
Montaje e instalación,2026-05-18,2026-05-18,cerrado
Pruebas en operación,2026-08-08,2026-08-08,cerrado
