<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Operaciones · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-11
**Asistentes:** Paula Céspedes, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 12 | 2026-10-10 |
