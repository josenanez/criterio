<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2026-06-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-09-08 | 2026-09-08 | cerrado
Ingeniería de detalle aprobada | 2026-11-29 | 2026-11-29 | en curso
Licencia y permisos obtenidos | 2027-02-18 | 2027-02-18 | en curso
Montaje e instalación | 2027-05-11 | 2027-05-11 | en curso
Pruebas en operación | 2027-08-01 | 2027-08-01 | en curso
