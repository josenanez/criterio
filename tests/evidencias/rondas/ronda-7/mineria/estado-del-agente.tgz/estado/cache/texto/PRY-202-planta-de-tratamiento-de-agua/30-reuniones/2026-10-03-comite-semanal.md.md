<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, María Restrepo, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-11-13 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-11-09 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-10 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-11-24 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 |
| Gustavo Neira | Actualizar la matriz 6 | 2026-10-11 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-19 |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Paula Céspedes | Validar el ambiente 12 | 2026-10-05 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-12 |
| Gustavo Neira | Entregar el punto 16 | 2026-10-20 |
| María Restrepo | Enviar el documento 17 | 2026-10-16 |
| Diana Molina | Cerrar la prueba 18 | 2026-10-26 |
| María Restrepo | Revisar el anexo 19 | por definir |
| Óscar Ramírez | Validar el ambiente 20 | 2026-10-07 |

## Cerrados en esta reunión

- Confirmar la fecha 15 (Jorge Medina): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- Laura Vélez dice que ya entregó «revisar el anexo 11». No se presentó acta.
