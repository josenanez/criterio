<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Gustavo Neira

## Estado declarado

**Amarillo**

Avance reportado: **39%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.955.187.421 |
| Ejecutado | 2.669.596.174 |
| Proyección al cierre | 8.178.934.417 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
