<!-- origen: PRY-206-red-privada-lte-en-mina/30-reuniones/2026-10-07-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Red privada LTE en mina

**Fecha:** 2026-10-07
**Asistentes:** Laura Vélez, Camilo Beltrán

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 31 | 2026-10-24 |
