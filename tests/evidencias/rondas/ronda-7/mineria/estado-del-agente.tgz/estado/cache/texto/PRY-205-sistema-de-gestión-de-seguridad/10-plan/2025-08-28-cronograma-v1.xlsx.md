<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-08-28-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-01-10 | 2026-01-10 | cerrado
Ingeniería de detalle aprobada | 2026-05-16 | 2026-05-16 | cerrado
Licencia y permisos obtenidos | 2026-09-18 | 2026-09-18 | cerrado
Montaje e instalación | 2027-01-22 | 2027-01-22 | en curso
