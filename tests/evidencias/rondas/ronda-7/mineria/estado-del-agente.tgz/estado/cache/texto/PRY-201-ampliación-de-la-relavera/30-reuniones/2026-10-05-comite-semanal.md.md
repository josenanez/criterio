<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Ampliación de la relavera

**Fecha:** 2026-10-05
**Asistentes:** Sandra Gil, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 11 | 2026-11-06 |
