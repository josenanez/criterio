<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-09-05
**Asistentes:** Andrés Lozano, Camilo Beltrán, Gustavo Neira, Javier Hoyos, Jorge Medina

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-09-08 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-09-12 |
| Andrés Lozano | Revisar el anexo 3 | 2026-09-29 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-23 |
