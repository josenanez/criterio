<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2026-02-27-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-06-06,2026-06-06,cerrado
Ingeniería de detalle aprobada,2026-09-03,2026-09-03,cerrado
Licencia y permisos obtenidos,2026-12-01,2026-12-01,en curso
Montaje e instalación,2027-02-28,2027-02-28,en curso
Pruebas en operación,2027-05-28,2027-05-28,en curso
