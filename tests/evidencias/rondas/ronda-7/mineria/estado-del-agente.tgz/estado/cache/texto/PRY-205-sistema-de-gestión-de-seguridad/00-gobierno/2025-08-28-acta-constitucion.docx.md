<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/2025-08-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de seguridad

Código: PRY-205

Área dueña: Planta de procesamiento

Patrocinador: Ricardo Salas

Gerente de proyecto: Diana Molina

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2025-08-28

Objetivo del negocio

Entregar sistema de gestión de seguridad para Planta de procesamiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Seguridad el 2025-08-28.

Fechas comprometidas

Fecha

Inicio

2025-09-07

Cierre

2027-01-22

Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

Dependencias declaradas

• Ninguna declarada
