<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2025-12-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Electrificación de equipos

Código: PRY-209

Área dueña: Logística

Patrocinador: Laura Vélez

Gerente de proyecto: Laura Vélez

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2025-12-08

Objetivo del negocio

Entregar electrificación de equipos para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Operaciones el 2025-12-08.

Fechas comprometidas

Fecha

Inicio

2025-12-18

Cierre

2026-10-09

Criterio de éxito

Electrificación de equipos en producción y medido.

Dependencias declaradas

• Ninguna declarada
