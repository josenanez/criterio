<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-15
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 75%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.405.463.443
Ejecutado 1.024.296.493
Proyección al cierre 4.043.517.569

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
