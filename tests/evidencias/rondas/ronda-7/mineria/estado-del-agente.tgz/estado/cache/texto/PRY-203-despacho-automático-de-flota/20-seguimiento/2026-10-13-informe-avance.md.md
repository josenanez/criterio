<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-13
**Gerente:** Sandra Gil

## Estado declarado

**Amarillo**

Avance reportado: **27%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad
- Se actualizó el presupuesto de la obra con el área de compras
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.231.152.131 |
| Ejecutado | 1.736.575.747 |
| Proyección al cierre | 3.044.295.228 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
- Cambio en la licencia ambiental que puede mover el alcance
