<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-09-12
**Asistentes:** Andrés Lozano, Camilo Beltrán, Gustavo Neira, Javier Hoyos, Jorge Medina, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-09-29 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-10-01 |
| Andrés Lozano | Revisar el anexo 3 | 2026-09-29 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-10-12 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-03 |
| Gustavo Neira | Actualizar la matriz 6 | 2026-09-15 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-06 |
| Andrés Lozano | Entregar el punto 8 | 2026-10-04 |
