<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-09-26-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-10-28 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-10-24 |
| Andrés Lozano | Revisar el anexo 3 | 2026-10-10 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-11-12 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-12 |
| Gustavo Neira | Actualizar la matriz 6 | 2026-10-11 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-19 |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Laura Vélez | Revisar el anexo 11 | 2026-09-23 |
| Paula Céspedes | Validar el ambiente 12 | 2026-10-05 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-03 |
| Jorge Medina | Confirmar la fecha 15 | 2026-10-22 |
| Gustavo Neira | Entregar el punto 16 | 2026-10-20 |

## Lo que se dijo

- Andrés Lozano dice que ya entregó «entregar el punto 8». No se presentó acta.
