<!-- origen: PRY-211-control-de-polvo-en-vías/00-gobierno/2025-07-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Control de polvo en vías

**Código:** PRY-211
**Área dueña:** Mina
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-19

## Objetivo del negocio

Entregar control de polvo en vías para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Tecnología el 2025-07-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-29 |
| Cierre | 2026-11-26 |

## Criterio de éxito

Control de polvo en vías en producción y medido.

## Dependencias declaradas

- Ninguna declarada
