<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2025-07-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-11-27 | 2025-11-27 | cerrado
Ingeniería de detalle aprobada | 2026-03-28 | 2026-03-28 | cerrado
Licencia y permisos obtenidos | 2026-07-28 | 2026-07-28 | cerrado
Montaje e instalación | 2026-11-26 | 2026-11-26 | en curso
