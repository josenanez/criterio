<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-07-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-07
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **28%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.607.597.890 |
| Ejecutado | 1.067.730.191 |
| Proyección al cierre | 4.077.850.670 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
