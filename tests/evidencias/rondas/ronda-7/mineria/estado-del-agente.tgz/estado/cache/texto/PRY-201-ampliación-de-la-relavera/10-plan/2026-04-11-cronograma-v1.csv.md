<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-04-11-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-06-16,2026-06-16,cerrado
Ingeniería de detalle aprobada,2026-08-11,2026-08-11,cerrado
Licencia y permisos obtenidos,2026-10-06,2026-10-06,en curso
Montaje e instalación,2026-12-01,2026-12-01,en curso
Pruebas en operación,2027-01-26,2027-01-26,en curso
