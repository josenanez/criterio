<!-- origen: PRY-202-planta-de-tratamiento-de-agua/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-09-19
**Asistentes:** Andrés Lozano, Camilo Beltrán, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-10-16 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-10-16 |
| Andrés Lozano | Revisar el anexo 3 | 2026-09-29 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-10-26 |
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-03 |
| Gustavo Neira | Actualizar la matriz 6 | 2026-09-15 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-06 |
| Andrés Lozano | Entregar el punto 8 | 2026-10-04 |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 |
| Paula Céspedes | Cerrar la prueba 10 | por definir |
| Laura Vélez | Revisar el anexo 11 | 2026-09-23 |
| Paula Céspedes | Validar el ambiente 12 | por definir |
