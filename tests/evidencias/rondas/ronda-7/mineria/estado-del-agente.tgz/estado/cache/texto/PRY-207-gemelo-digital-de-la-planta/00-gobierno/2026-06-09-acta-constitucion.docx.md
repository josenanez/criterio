<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2026-06-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la planta

Código: PRY-207

Área dueña: Tecnología

Patrocinador: Sandra Gil

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Seguridad

Producto asociado: gemelo digital

Fecha de aprobación: 2026-06-09

Objetivo del negocio

Entregar gemelo digital de la planta para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Seguridad el 2026-06-09.

Fechas comprometidas

Fecha

Inicio

2026-06-19

Cierre

2027-08-01

Criterio de éxito

Gemelo digital de la planta en producción y medido.

Dependencias declaradas

• Ninguna declarada
