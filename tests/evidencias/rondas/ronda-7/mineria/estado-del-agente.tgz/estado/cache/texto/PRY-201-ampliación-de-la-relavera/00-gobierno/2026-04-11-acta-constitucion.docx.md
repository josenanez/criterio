<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2026-04-11-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Ampliación de la relavera

Código: PRY-201

Área dueña: Medio Ambiente

Patrocinador: Javier Hoyos

Gerente de proyecto: Sandra Gil

Comité: Comité Ambiental

Producto asociado: No aplica

Fecha de aprobación: 2026-04-11

Objetivo del negocio

Entregar ampliación de la relavera para Medio Ambiente.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité Ambiental el 2026-04-11.

Fechas comprometidas

Fecha

Inicio

2026-04-21

Cierre

2027-01-26

Criterio de éxito

Ampliación de la relavera en producción y medido.

Dependencias declaradas

• Ninguna declarada
