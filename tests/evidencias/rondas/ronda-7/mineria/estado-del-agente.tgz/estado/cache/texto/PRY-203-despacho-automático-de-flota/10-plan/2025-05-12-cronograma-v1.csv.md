<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2025-05-12-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-08-26,2025-08-26,cerrado
Ingeniería de detalle aprobada,2025-12-01,2025-12-01,cerrado
Licencia y permisos obtenidos,2026-03-08,2026-03-08,cerrado
Montaje e instalación,2026-06-12,2026-06-12,cerrado
Pruebas en operación,2026-09-17,2026-09-17,cerrado
