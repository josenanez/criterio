<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-05
Gerente: Laura Vélez

Estado declarado
Rojo
Avance reportado: 52%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 10.822.301.946
Ejecutado 7.526.934.475
Proyección al cierre 17.887.247.038

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Bloqueo de la vía de acceso a la mina
