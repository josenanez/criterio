<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2026-01-25-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-15 | 2026-05-15 | cerrado
Ingeniería de detalle aprobada | 2026-08-23 | 2026-08-23 | cerrado
Licencia y permisos obtenidos | 2026-12-01 | 2026-12-01 | en curso
