# PRY-202 Planta de tratamiento de agua — semana del 2026-10-10 al 2026-10-17

**Declara el gerente:** *(en blanco: nadie declaró en esta sesión y Samuel no propone estado)*. La ficha trae una declaración previa del informe de avance del 2026-10-16: verde · 89 % (`20-seguimiento/2026-10-16-informe-avance.pdf`). Es del documento, no de esta corrida, y tiene 1 día.
**Sustento documental:** contradicho. Hay 0 campos con fuente de evidencia; 14 son declaración y 203 no tienen marca de fuente.
**Lo que el semáforo no explica:** 7 señales. Sobre el verde del 10-16 quedan sin explicar `variance_time`, `variance_cost`, `progress_vs_plan`, `milestone_met_without_evidence`, `vendor_deliverable_late`, `commitment_overdue` y `commitment_rescheduled`.

Jorge Medina, gerente del proyecto: Samuel no te propone el estado. Con esta evidencia a la vista, declara tú qué estado y qué avance, y la línea se completa.

## Qué cambió esta semana
No hay comparación contra una corrida anterior: este es el primer snapshot de la carpeta (2026-10-17) y `diff` dio 0 cambios. Lo que sigue sale de las fechas de los documentos de la semana, no de un diff.

| Qué | Estaba | Está | |
|---|---|---|---|
| Línea base | v1, cierre 2027-05-28 | v2, cierre 2027-09-20 (CC-01, +115 días, aprobada 2026-10-10) | La minuta del 10-10 no menciona la autorización |
| Presupuesto | 800.000.000 COP | CC-01 pide 230.000.000 COP adicionales; la ficha sigue con 800.000.000 aprobados | Sin acta que registre la decisión |
| Hoyos, «Enviar el documento 1» | 2026-11-24 (reprogramado el 10-10) | 2026-12-08 (reprogramado el 10-17), 6.ª vez | Original 2026-09-08 |
| Neira, «Cerrar la prueba 2» | 2026-11-09 | 2026-11-30 (10-10), 5.ª vez | Original 2026-09-12 |
| Beltrán, «Validar el ambiente 4» | 2026-11-24 | 2026-12-05 (10-10), 5.ª vez | Original 2026-09-23 |
| Cerrados con acta de recibo el 10-10 | abiertos | Lozano, anexo 3; Neira, fecha 7; Restrepo, documento 17; Ramírez, ambiente 20 | Evidencia presente |
| Nuevo el 10-17 | | Vélez, «Mandar el ajuste del presupuesto» (sin fecha); Ramírez, revisión con el proveedor (2026-10-27) | |
| Declaración | | Verde 89 % (informe del 10-16) | Ver arriba |

## Lo que sigue igual y sigue mal
Los días son contra la fecha de vencimiento, porque no hay corrida previa que diga desde cuándo se marcó.

| Qué | Desde | Días así |
|---|---|---|
| Licenciamiento del software (CT-812) pendiente | 2026-06-15 | 124 |
| «Ingeniería básica aprobada» declarada cumplida, sin evidencia | 2026-06-06 | 133 |
| «Ingeniería de detalle aprobada» declarada cumplida, sin evidencia | 2026-09-03 | 44 |
| «Bolsa de horas de ingeniería» aceptada sin documento de aceptación | vencía 2026-09-21 | 26 |
| Vélez, «Revisar el anexo 11» vencido | 2026-09-23 | 24 |
| Lozano, «Entregar el punto 8» vencido | 2026-10-04 | 13 |
| Cárdenas, «Actualizar la matriz 14» vencido | 2026-10-12 | 5 |
| Neira, «Actualizar la matriz 6» vencido | 2026-10-11 | 6 |
| Arango, «Enviar el documento 9» vencido | 2026-10-15 | 2 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-05-28 | 2027-09-20 | +115 días (25,8 %) contra la original; 0 contra la vigente |
| Presupuesto | 800.000.000 COP | 800.000.000 COP en la ficha | Proyección 1.030.910.468 COP: +28,9 % |

Replanificaciones: 1. El 2026-10-10 se pasó a v2 por CC-01, ampliación de alcance (+115 días; fuente: solicitud de cambio del mismo día). La proyección de costo (1.030.910.468) queda a 910.468 COP de la suma 800.000.000 + 230.000.000 de CC-01. Ese sobrecosto depende de una aprobación sin acta.

Avance: el 89 % declarado frente a 2 hitos cumplidos de 5. El plan sostiene entre 40 % y 60 %, así que la declaración va 29 puntos por encima. Los 2 hitos cumplidos no tienen evidencia.

### Hitos de las próximas cuatro semanas (hasta 2026-11-14)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno vence en la ventana | | | |

El siguiente es «Licencia y permisos obtenidos»: base 2026-12-01, vigente 2026-12-01, pendiente, sin evidencia. «Pruebas en operación» pasó de 2027-05-28 a 2027-09-20.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 300.578.510 (37,6 %) | 194.512.198 (24,3 %) | 1.030.910.468 | 499.421.490 (aprobado − comprometido) |

Con ejecutado en 24,3 % y avance declarado en 89 %, las dos cifras no cuentan la misma historia. El disponible real no incluye los 230.000.000 de CC-01.

## Abierto
**Reprogramados:**
- Hoyos, «Enviar el documento 1»: 6 veces, de 2026-09-08 a 2026-12-08.
- Neira, «Cerrar la prueba 2»: 5 veces, de 2026-09-12 a 2026-11-30.
- Beltrán, «Validar el ambiente 4»: 5 veces, de 2026-09-23 a 2026-12-05.

**Vencidos sin evidencia:**
- Vélez, anexo 11: desde 2026-09-23. Dijo el 10-03 que ya lo entregó, «no se presentó acta».
- Lozano, punto 8: desde 2026-10-04. Dijo el 09-26 que ya lo entregó, sin acta.
- Neira, matriz 6: desde 2026-10-11. Dijo el 10-10 que ya lo entregó, sin acta.
- Cárdenas, matriz 14: desde 2026-10-12.
- Arango, documento 9: desde 2026-10-15.

**Sin fecha:** Vélez, «Aprobar el diseño 21» (desde el 10-10) y «Mandar el ajuste del presupuesto» («la otra semana», 10-17).

**RAID sin movimiento:** 3 riesgos y 1 incidencia, todos sin dueño y sin fecha de inicio, así que los días sin movimiento no se pueden calcular.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.
- Riesgo: ventana de parada de planta definida por operaciones.
- Riesgo dicho el 10-17 y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase.
- Incidencia: dos semanas perdidas por la rotación de un ingeniero clave.

**Proveedor (Automatización de Procesos Ltda., CT-812):** 4 entregables, 1 aceptado. Licenciamiento vencido 124 días y pendiente. Bolsa de horas aceptada sin documento. Facturado 63.399.928 COP, que es el monto de un entregable. Calibración de sensores (2026-12-28) y soporte del primer trimestre (2027-04-05) siguen pendientes.

## Lo que necesito de alguien
- **Jorge Medina:** declarar estado y avance (ver arriba).
- **Laura Vélez:** fecha para «Aprobar el diseño 21» y para «Mandar el ajuste del presupuesto»; el anexo 11 sigue vencido.
- **Comité / patrocinio — excede al gerente:** el acta o la minuta que registre la aprobación de CC-01 (+115 días, +230.000.000 COP). Es material de comité, no de este informe.
- **Hoyos, Neira, Beltrán:** fecha firme o decisión sobre sus compromisos reprogramados 5 y 6 veces.
- **Neira, Lozano, Vélez:** el acta de recibo de lo que dicen haber entregado.
- **Proveedor:** fecha de la última entrega, y el documento de aceptación de la bolsa de horas.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto. Evidencia de los 5 hitos y de los 4 entregables del proveedor. Dueño de los 3 riesgos y de la incidencia. Quién autorizó CC-01.
**Silencio:** `days_silent` no se pudo calcular. El último documento fechado es del 2026-10-16 y la última reunión (notas) del 2026-10-17, así que no hay silencio documental. El problema es que casi nada de lo documentado es evidencia.

---
Ficha: `records/PRY-202.json`, al 2026-10-17 · 12 campos sin dato, más 3 de identidad (producto, autoridad, fase) · Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

*Siguiente paso posible:* hay 3 compromisos reprogramados 3 veces o más y una desviación de tiempo del 25,8 % (umbral 10 %), con lo que se puede armar el punto de comité con la decisión formulada. Como la declaración quedó contradicha por la evidencia, también se puede publicar la ficha con `/pm-publish`.
