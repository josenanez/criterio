## Listo — PRY-202 · Planta de tratamiento de agua

**Lo que miré:** 19 documentos · 7 de reuniones (6 minutas del comité semanal, del 2026-09-05 al 2026-10-10, y las notas del 2026-10-17) · la última del 2026-10-17. Leí todas, de la más vieja a la más nueva, y las 5 actas de recibo. Los 19 se pudieron leer.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb…

**Las cuatro preguntas (sin interfaz, con la respuesta sugerida):**
1. Proyecto PRY-202, Planta de tratamiento de agua; gerente Jorge Medina, patrocinadora Laura Vélez (acta de constitución, 2026-02-27).
2. Reunión de seguimiento: semanal, los sábados (así están fechadas las minutas). Las notas del 17 dicen «próxima reunión en dos semanas», o sea el 2026-10-31.
3. El estado queda en `estado/PRY-202-planta-de-tratamiento-de-agua`.
4. Términos: mostrados y aceptados con el nombre indicado.

### Lo que está abierto, y cuántas veces se ha movido

Son 26 compromisos en total: 5 cumplidos con acta, 5 vencidos sin evidencia, 14 abiertos con fecha y 2 sin fecha. Veces movido = veces que se volvió a prometer con fecha nueva.

**Reprogramados 3 veces o más (el bloqueo que nadie ha nombrado):**

| Quién | Qué | Fecha original → vigente | Veces movido |
|---|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-09-08 → 2026-12-08 | 6 |
| Gustavo Neira | Cerrar la prueba 2 | 2026-09-12 → 2026-11-30 | 5 |
| Camilo Beltrán | Validar el ambiente 4 | 2026-09-23 → 2026-12-05 | 5 |

Fechas sucesivas de «Enviar el documento 1»: 09-29, 10-16, 10-28, 11-13, 11-24 y 12-08 (minutas del 09-12, 09-19, 09-26, 10-03, 10-10 y notas del 10-17). Las notas del 17 dicen «08/12/2026»; la leí como día/mes (2026-12-08). Confírmalo.

**Vencidos sin evidencia:**

| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Laura Vélez | Revisar el anexo 11 | 2026-09-23 | 24 | 30-reuniones/2026-09-19-comite-semanal.md |
| Andrés Lozano | Entregar el punto 8 | 2026-10-04 | 13 | 30-reuniones/2026-09-12-comite-semanal.md |
| Gustavo Neira | Actualizar la matriz 6 | 2026-10-11 | 6 | 30-reuniones/2026-09-12-comite-semanal.md |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-12 | 5 | 30-reuniones/2026-09-26-comite-semanal.md |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 | 2 | 30-reuniones/2026-09-19-comite-semanal.md |

Tres de ellos (anexo 11, punto 8, matriz 6) dejaron de aparecer en las listas después de que alguien dijo en la reunión que «ya lo entregó»; la minuta anota «no se presentó acta». Decirlo en la reunión no los cierra.

**Abiertos con fecha, los que no se han movido tres veces:**

| Quién | Qué | Para | Veces movido |
|---|---|---|---|
| Ricardo Salas | Aprobar el diseño 5 | 2026-10-21 (original 10-03) | 2 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-24 | 0 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 | 0 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-25 (estuvo «por definir» tres reuniones) | 0 |
| Paula Céspedes | Validar el ambiente 12 | 2026-10-23 (original 10-05) | 1 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 (notas del 17) | 0 |
| Gustavo Neira | Entregar el punto 16 | 2026-11-02 (original 10-20) | 1 |
| Mauricio Pérez | Entregar el punto 24 | 2026-11-01 | 0 |
| Sandra Gil | Actualizar la matriz 22 | 2026-11-05 | 0 |
| María Restrepo | Revisar el anexo 19 | 2026-10-20 (estuvo «por definir») | 0 |
| Diana Molina | Cerrar la prueba 18 | 2026-11-16 (original 10-26) | 1 |

**Cumplidos con acta de recibo:** Revisar el anexo 3 (Andrés Lozano), Confirmar la fecha 7 (Gustavo Neira), Confirmar la fecha 15 (Jorge Medina), Enviar el documento 17 (María Restrepo), Validar el ambiente 20 (Óscar Ramírez). El anexo 3 se movió una vez antes de cerrarse.

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos:
- Laura Vélez — Aprobar el diseño 21 («por definir», minuta del 2026-10-10).
- Laura Vélez — Mandar el ajuste del presupuesto («la otra semana», notas del 2026-10-17).

### Señales que levantó el cálculo sobre el resto del proyecto
- **El informe dice verde y 89%; los documentos no lo sostienen.** El cronograma v2 tiene 2 de 5 hitos cerrados: el plan sostiene entre 40% y 60%, 29 puntos menos. La diferencia entre lo declarado y lo documentado es el hallazgo.
- **Tiempo:** el cierre pasó de 2027-05-28 a 2027-09-20: 115 días, 25.8% sobre la línea base original (la solicitud CC-01, autorizada por el comité).
- **Costo:** la proyección al cierre es 1.030.910.468 COP contra 800.000.000 aprobados: 28.9% por encima. Comprometido 300.578.510 (37.6%), ejecutado 194.512.198 (24.3%). Todas las cifras del informe son declaradas.
- **Hitos declarados cerrados sin acta que lo pruebe:** Ingeniería básica aprobada (2026-06-06) e Ingeniería de detalle aprobada (2026-09-03).
- **Proveedor (CT-812, Automatización de Procesos Ltda.):** Licenciamiento del software venció el 2026-06-15 y sigue pendiente (124 días). La Bolsa de horas de ingeniería figura como recibida en el contrato, sin acta de recibo. Facturado: 63.399.928 COP (FV-1812).
- **Riesgo dicho y no registrado:** en las notas del 17 se comentó que el proveedor podría no llegar con el equipo completo a la siguiente fase; nadie lo anotó como riesgo. Lo dejé en la ficha con esa cita.

### Qué le falta a tu carpeta
- Minutas anteriores al 2026-09-05: no hay, y los compromisos que ya traían historia no la tienen.
- Actas de recibo de lo que ya se dijo entregado: anexo 11, punto 8 y matriz 6. Sin ellas se ven igual que los incumplidos.
- Acta de recibo de los hitos «cerrados» (ingeniería básica y de detalle) y de la bolsa de horas del proveedor.
- Registro de la autorización de CC-01: la solicitud dice «autorizada por el comité», pero la minuta del 10-10 no la menciona y no hay acta de comité.
- Las notas del 17 son un .txt suelto fuera de `30-reuniones/`, sin lista de compromisos. Una minuta en el formato de las anteriores facilita el seguimiento.
- El acta de constitución no declara dependencias, producto ni qué puede decidir el gerente sin subir a comité.
- Observación sobre las actas: las cinco las recibió Jorge Medina, incluida la de su propio compromiso (confirmar la fecha 15).

La ficha no está sellada: la dejé escrita en `estado/PRY-202-planta-de-tratamiento-de-agua/records/PRY-202.json`. Se sella cuando corras el barrido completo.

**Cuándo vuelvo:** el sábado 2026-10-31, que es la próxima reunión según las notas del 17. Mientras tanto, el seguimiento semanal sigue el ritmo de los sábados.
