## Compromisos — PRY-202 Planta de tratamiento de agua · al 2026-10-17

26 compromisos en la ficha: 21 abiertos, 5 cerrados con documento. De los 21 abiertos: 3 reprogramados 3 veces o más, 5 vencidos sin evidencia, 2 sin fecha. Cifras de `portafolio.py compute`.

### Se viene reprogramando

> **Javier Hoyos** · Enviar el documento 1
> Prometido para el 2026-09-08, y antes para el 09-29, el 10-16, el 10-28, el 11-13, el 11-24, y ahora el 12-08 (dicho en las notas del 17-10).
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.**
> Ojo: las notas del 17 dicen «08/12/2026»; se leyó día/mes (2026-12-08). Si fuera mes/día no sería una fecha posible para esta serie.

> **Gustavo Neira** · Cerrar la prueba 2
> Prometido para el 2026-09-12, y antes para el 10-01, el 10-16, el 10-24, el 11-09, y ahora el 11-30. Cinco reprogramaciones.

> **Camilo Beltrán** · Validar el ambiente 4
> Prometido para el 2026-09-23, y antes para el 10-12, el 10-26, el 11-12, el 11-24, y ahora el 12-05. Cinco reprogramaciones.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Laura Vélez | Revisar el anexo 11 | 2026-09-23 | 24 días |
| Andrés Lozano | Entregar el punto 8 | 2026-10-04 | 13 días |
| Gustavo Neira | Actualizar la matriz 6 | 2026-10-11 (reprogramado una vez) | 6 días |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-12 (reprogramado una vez) | 5 días |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 | 2 días |

Tres de estos —Laura Vélez (anexo 11), Andrés Lozano (punto 8) y Gustavo Neira (matriz 6)— dijeron en comité que ya lo entregaron y «no se presentó acta». Dicen que lo entregaron; no hay nada en el expediente que lo respalde, así que siguen abiertos.

### Vencen esta semana (hasta el 2026-10-24)
| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Revisar el anexo 19 | 2026-10-20 |
| Ricardo Salas | Aprobar el diseño 5 (ya reprogramado dos veces) | 2026-10-21 |
| Paula Céspedes | Validar el ambiente 12 (reprogramado una vez) | 2026-10-23 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-24 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Aprobar el diseño 21 | 2026-10-10 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», sin fecha) | 2026-10-17 |

No pueden estar vencidos, por eso se cuentan aparte. Ambos son de la misma persona, que además tiene vencido el anexo 11.

### Abiertos con fecha posterior (sin novedad)
Paula Céspedes · Cerrar la prueba 10 (10-25); Óscar Ramírez · Revisión con el proveedor (10-27); Gustavo Neira · Entregar el punto 16 (11-02, reprogramado una vez); Mauricio Pérez · Entregar el punto 24 (11-01); Sandra Gil · Actualizar la matriz 22 (11-05); Diana Molina · Cerrar la prueba 18 (11-16, reprogramado una vez).

### Cerrados desde la última revisión
| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Andrés Lozano | Revisar el anexo 3 | 20-seguimiento/2026-10-10-acta-recibo-3.md |
| Gustavo Neira | Confirmar la fecha 7 | 20-seguimiento/2026-10-10-acta-recibo-7.md |
| Jorge Medina | Confirmar la fecha 15 | 20-seguimiento/2026-10-03-acta-recibo-15.md |
| María Restrepo | Enviar el documento 17 | 20-seguimiento/2026-10-10-acta-recibo-17.md |
| Óscar Ramírez | Validar el ambiente 20 | 20-seguimiento/2026-10-10-acta-recibo-20.md |

## Después

**Para el comité:** el compromiso de Javier Hoyos (documento 1, seis fechas) y los dos de Gustavo Neira y Camilo Beltrán exceden el seguimiento. Se puede formular como decisión: qué se pide, qué pasa si no se decide y quién tiene la facultad. No se ha formulado todavía; `/pm-escalate` lo hace.

**Para la PMO:** si estos cambios deben verla, `/pm-publish`.

El informe de avance del 16-10 declara el proyecto en verde; el cálculo trae 5 compromisos vencidos y 3 reprogramados entre las señales que ese informe no explica.
