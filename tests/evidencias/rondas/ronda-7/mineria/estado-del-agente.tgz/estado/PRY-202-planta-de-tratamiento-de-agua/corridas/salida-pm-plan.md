# Plan — PRY-202 Planta de tratamiento de agua · borrador del 2026-10-17
**Desde:** el acta de constitución del 2026-02-27 (`00-gobierno/2026-02-27-acta-constitucion.docx`) · **Criterio de éxito:** «Planta de tratamiento de agua en producción y medido.» (acta). No dice qué se mide, contra qué valor ni quién lo certifica.

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.

**Una observación antes de empezar:** este proyecto no está en arranque. El acta es de febrero, hay dos hitos cerrados (ingeniería básica y de detalle) y el informe del 2026-10-16 declara 89 % de avance. Este borrador reconstruye la estructura desde el acta, no la que el equipo ya está ejecutando; si lo que querías era revisar un plan existente, el comando es `/pm-plan revisar 10-plan/2026-10-16-cronograma-v2.xlsx`.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** Dice «Componente 1, 2, 3» y nada más. Fuera de alcance: «Lo que otro proyecto cubre», sin decir cuál. | No hay entregables que descomponer. La WBS de abajo no puede pasar de los tres componentes sin que alguien invente qué son. Tampoco se sabe qué cubre CC-01 («ampliación de alcance», sin detalle). |
| **Autoridad no declarada.** El acta no dice qué puede decidir el gerente y qué hay que subir. | No sé qué del plan puedes decidir tú y qué va al comité. Todo lo que cruce presupuesto o fecha lo trato como decisión del comité. |
| **Criterio de éxito sin medida.** «En producción y medido» no dice qué métrica ni qué umbral. | La última fase («Pruebas en operación») no tiene criterio de aceptación; nadie puede declararla cerrada con evidencia. |
| **Dependencias: «Ninguna declarada».** Pero existe el contrato CT-812 con el proveedor, hay una licencia/permiso en el hito 3 y una ventana de parada de planta definida por operaciones (informe 2026-10-16). | El plan dice que nada depende de nadie, y no es cierto. |
| **Producto asociado: «No aplica».** | Sin hallazgo adicional; lo anoto porque la planta sirve a Logística y no hay a quién cruzar. |

Patrocinador: Laura Vélez (declarado). Comité: Comité Ambiental (declarado). Esos dos sí están.

## WBS
Con el acta sola, solo hay tres nodos aceptables y ninguno es terminal. Los cuatro entregables del contrato CT-812 sí son terminales (alguien los recibe contra acta de recibo firmada por el gerente). Los hitos salen del cronograma v1/v2, que no es el acta; lo marco.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | Sin definir | del acta (nombre) · contenido **sin definir** | vacía |
| 2 | Componente 2 | Sin definir | del acta (nombre) · contenido **sin definir** | vacía |
| 3 | Componente 3 | Sin definir | del acta (nombre) · contenido **sin definir** | vacía |
| 4 | Ampliación de alcance CC-01 | Sin definir | **sin definir** (solicitud CC-01 no dice qué se amplía) | vacía |
| 5 | Ingeniería básica aprobada | Sin definir | cronograma v1, hito cerrado (no está en el acta) | vacía |
| 6 | Ingeniería de detalle aprobada | Sin definir | cronograma v1, hito cerrado (no está en el acta) | vacía |
| 7 | Licencia y permisos obtenidos | Autoridad emisora (supuesto) | cronograma v1; quién emite: **supuesto** | vacía |
| 8 | Montaje e instalación | Sin definir | cronograma v1 | vacía |
| 9 | Pruebas en operación (planta en producción y medida) | Sin definir | criterio de éxito del acta; medida **sin definir** | vacía |
| 10 | CT-812 · Licenciamiento del software | Jorge Medina (firma el acta de recibo) | contrato CT-812, fecha 2026-06-15 | citable: contrato |
| 11 | CT-812 · Bolsa de horas de ingeniería | Jorge Medina | contrato CT-812, fecha 2026-09-21 | citable: contrato |
| 12 | CT-812 · Calibración de sensores | Jorge Medina | contrato CT-812, fecha 2026-12-28 | citable: contrato |
| 13 | CT-812 · Soporte del primer trimestre | Jorge Medina | contrato CT-812, fecha 2027-04-05 | citable: contrato |

Las fechas de los nodos 10 a 13 son las contractuales del proveedor (compromiso de un tercero), no fechas que yo proponga. No encaje de nodos 1 a 3 con los hitos 5 a 9: el acta no dice cuál componente produce cuál hito. Eso queda sin definir.

Cómo está en el contrato hoy (declarado, no verificado): licenciamiento «pendiente» con fecha vencida (2026-06-15); bolsa de horas «recibido»; calibración «en curso»; soporte «pendiente». No traigo esos estados al plan: son del seguimiento, no de la estructura.

## Orden
Sin fechas; solo qué necesita qué.

- Ingeniería básica → ingeniería de detalle → licencia y permisos → montaje e instalación → pruebas en operación. Es el orden de los hitos del cronograma v1; las dependencias entre ellos **no** están en el acta (supuesto de secuencia lineal).
- Licencia y permisos antes de montaje: **supuesto** (ver abajo).
- Licenciamiento del software antes de calibración de sensores: **supuesto**; el contrato no lo dice.
- Calibración de sensores antes de pruebas en operación, y montaje antes de calibración: **supuesto**.
- Soporte del primer trimestre empieza cuando la planta opera: **supuesto**; el contrato lo fecha al 2027-04-05, que cae antes del cierre vigente del cronograma v2 (2027-09-20) y también antes del hito de pruebas. Con el cierre vigente el soporte cubriría una planta que aún no opera. Es una contradicción a resolver, no a explicar yo.
- Mapeo de los componentes 1 a 3 y de CC-01 al orden: **sin definir**.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| La secuencia de hitos es lineal (básica → detalle → licencia → montaje → pruebas) | Si montaje puede empezar antes de la licencia, el camino crítico cambia y el orden de arriba sobra. |
| La licencia y permisos deben estar antes del montaje | Si no, hay un permiso que puede bloquear la obra ya iniciada. |
| El licenciamiento del software precede a la calibración de sensores | Si no, la calibración se puede hacer sin licencia; si sí, el licenciamiento pendiente y vencido (2026-06-15) está frenando la calibración. |
| Los tres componentes del acta corresponden a los hitos del cronograma | Si no, el cronograma no cubre todo el alcance o lo cubre dos veces. |
| El gerente firma las actas de recibo del proveedor (el contrato lo dice) y es quien acepta esos cuatro entregables | Si otra persona acepta, la condición de pago del contrato no se está cumpliendo. |
| Los hitos del cronograma v1 siguen vigentes como estructura | v2 cambia solo la fecha de «Pruebas en operación»; si el alcance de CC-01 añade entregables, no figuran en v2. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 | Laura Vélez (patrocinadora), con Jorge Medina |
| Qué cubre CC-01 y qué entregables añade | Jorge Medina (solicitante) y el comité |
| Qué proyecto cubre lo «fuera de alcance» | Laura Vélez |
| Quién acepta cada entregable que no es del proveedor | Laura Vélez |
| Qué se mide en «producción y medido», con qué umbral | Laura Vélez / Comité Ambiental |
| Qué puede decidir el gerente sin subir (autoridad) | Laura Vélez |
| Dependencias reales (proveedor, operaciones, permisos) | Jorge Medina |
| Quién emite la licencia y permisos | Jorge Medina |
| Autorización de CC-01: la solicitud dice «Autorizada por el comité» y la minuta del 2026-10-10 no la menciona | Comité Ambiental (acta del comité) |

## Proyectos análogos
La configuración no apunta a ninguna carpeta de fichas de la PMO y la sesión solo tiene este proyecto. **No hay proyectos análogos a la vista.** No traigo ninguna referencia y no estimo por analogía. Dentro del propio proyecto, el único dato citable de desviación es de su cronograma: «Pruebas en operación» pasó de 2027-05-28 (v1) a 2027-09-20 (v2), +115 días, vía CC-01.

## Preguntas para el equipo
Una por cada duración vacía:

1. Componente 1: ¿qué es, qué se entrega y cuánto toma?
2. Componente 2: ¿qué es, qué se entrega y cuánto toma?
3. Componente 3: ¿qué es, qué se entrega y cuánto toma?
4. Ampliación CC-01: ¿qué entregables nuevos trae y cuánto toma cada uno? (+115 días es el total declarado, no por entregable.)
5. Ingeniería básica y de detalle (cerradas): ¿quién las aceptó y dónde está el acta?
6. Licencia y permisos: ¿quién la emite, qué trámites incluye y cuánto tarda?
7. Montaje e instalación: ¿cuánto toma y qué lo habilita (licencia, equipos del proveedor)?
8. Pruebas en operación: ¿cuánto toma, cuántas corridas, y cuál es la medida que las cierra?
9. Licenciamiento del software: ¿por qué sigue pendiente con fecha contractual 2026-06-15 vencida?
10. Soporte del primer trimestre: ¿arranca el 2027-04-05 o cuando la planta entre en operación?

## Para comprometer una fecha falta
- **Disponibilidad real del equipo.** El informe del 2026-10-16 ya registra dos semanas perdidas por la rotación de un ingeniero clave. No hay documento que diga quién queda.
- **La fecha del proveedor.** El informe dice que el proveedor no ha confirmado la fecha de su última entrega, y en la reunión del 17 se dijo que podría no llegar con el equipo completo para la siguiente fase.
- **La ventana de parada de planta** definida por operaciones: listada como riesgo abierto, sin fecha en ningún documento.
- **La aprobación de CC-01** por el comité, con acta.
- **El contenido de los tres componentes**, sin el cual no hay qué fechar.

Ninguna fecha se compromete aquí. La que se compromete es tuya.

## Después
Cuando el plan se apruebe: registrar como línea base original, y pasar los supuestos al RAID con doliente (hoy el registro tiene 0 supuestos). Una nota: el registro de línea base ya tiene dos versiones (v1 del acta, v2 del 2026-10-10 por CC-01); este borrador no crea ni toca ninguna.
