# Acta — Planta de tratamiento de agua (PRY-202) · 2026-10-17
**Asistieron:** Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** las notas no traen agenda, así que no se puede decir. Andrés Lozano, que tiene un compromiso vencido (entregar el punto 8), no figura entre los asistentes.

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta volver a pedirlos.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Javier Hoyos | Enviar el documento 1 | 2026-12-08 | **Reprogramado 6 veces.** Promesa original: 2026-09-08 (acta del 09-05). Fechas sucesivas: 09-29 → 10-16 → 10-28 → 11-13 → 11-24 → 12-08. La nueva fecha queda 91 días después de la promesa original. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Las notas dicen «queda para», sin verbo de compromiso: se registra como compromiso de Óscar con esa fecha. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Las notas dicen «la otra semana»; no se convirtió en fecha. |

Con esta, Laura Vélez tiene dos compromisos sin fecha abiertos (el otro: «Aprobar el diseño 21», desde el 10-10) y uno vencido hace 24 días (revisar el anexo 11, del que dijo el 10-03 que ya lo entregó, sin acta).

## Decisiones
Ninguna. Las notas no registran que alguien haya decidido algo.

## Quedó sin decidir
Las notas no dicen qué quedó pendiente de decisión; no se inventa.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas añaden «nadie lo anotó como riesgo» | Sin atribuir (las notas dicen «se comentó») | Riesgo (proveedor, recursos) | **No.** Está en la ficha ahora, sin dueño, con origen en estas notas. El RAID ya tenía un riesgo cercano pero distinto: «el proveedor no ha confirmado la fecha de la última entrega» (informe del 2026-10-16). |

La ficha no dice cuál es «la siguiente fase» (`identity.phase` no está en ningún documento).

## Cerrado en esta reunión
Nada. Se omite el detalle: ningún compromiso se cerró con documento.

## Lo que esta reunión contradice
Nada. Las notas no cambian patrocinador, fechas de cierre ni comité respecto del expediente.

## Sin resolver de la transcripción
- «Javier Hoyos dice que lo de "enviar el documento 1" no alcanzó, se compromete para el 08/12/2026»: leído día/mes (2026-12-08). Si fuera mes/día (12 de agosto) ya habría pasado, así que no es una fecha posible para esta serie. Además la fecha vigente era el 11-24, que aún no llegaba: no queda claro qué «no alcanzó».
- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: no queda claro si «la otra semana» es la del 10-19 o la del 10-26.
- «próxima reunión en dos semanas»: coincide con el comité del 2026-10-31 de la configuración; se registra como coincidencia, no como acuerdo.

## Lo que mueve en el seguimiento (calculado por el script, `record_issues` vacío)
- Sin fecha: 2 compromisos, ambos de Laura Vélez.
- Reprogramados 3 o más veces: 3 (Javier Hoyos 6, Gustavo Neira 5, Camilo Beltrán 5).
- Vencidos: 5, ninguno cerrado ni movido por esta reunión.
- Informe de avance del 10-16 declara verde; el cálculo lo contradice por 7 señales.
