## Planta de tratamiento de agua (PRY-202) · 2026-10-17

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

**Revisé:** 20 documentos · 0 cambiaron · 0 minutas nuevas

El índice marcó los 20 como «nuevos» porque es el primer barrido de esta carpeta. No los releí: la ficha de hoy ya los cita todos, incluidas las notas del 17-10 (`2026-10-17-notas-reunion.txt`) y las seis minutas del comité semanal, y no hay archivos cambiados, renombrados ni borrados.

### Lo que se venció solo
Nada nuevo desde el cálculo de compromisos de hoy (`pm-commitments`, 2026-10-17). Siguen vencidos sin evidencia 5 compromisos:
- Laura Vélez, anexo 11 (2026-09-23)
- Andrés Lozano, punto 8 (2026-10-04)
- Gustavo Neira, matriz 6 (2026-10-11)
- Rubén Cárdenas, matriz 14 (2026-10-12)
- Felipe Arango, documento 9 (2026-10-15)

Siguen en 3 o más reprogramaciones: Javier Hoyos (documento 1), Gustavo Neira (prueba 2) y Camilo Beltrán (ambiente 4).

### La reunión
El comité es el 2026-10-31, dentro de 14 días. No toca agenda todavía (faltan más de 1 día). El informe sale el 2026-10-30. No hay acta pendiente: las notas del 17-10 ya se procesaron con `pm-minutes`.

### Tu ficha publicada
Está al día: se publicó hoy (2026-10-17) y no ha cambiado desde entonces.

**Vuelvo el 2026-10-18.**
