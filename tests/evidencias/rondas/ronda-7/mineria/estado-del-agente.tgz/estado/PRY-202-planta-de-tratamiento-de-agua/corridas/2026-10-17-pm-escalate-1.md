# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 58 s · 18 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `commitment_rescheduled` | 3 |
| `milestone_met_without_evidence` | 2 |
| `commitment_undated` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `variance_cost` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `declared_vs_evidence` | 1 |

Dos puntos: autoridad no declarada en el acta, y ratificación de CC-01 (opciones A/B/C, recomienda B). impact con 115 días cuenta CC-01 dos veces (mide desde v2); solo usé la lista de hitos. No sé: detalle del alcance de CC-01, holgura por actividad, fecha límite externa, otros proyectos afectados. No escalan: documento 1 (bloqueo sin nombrar) y CT-812 (del gerente).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-202 Planta de tratamiento de agua · 2026-10-17

Sin argumento, tomé lo ya marcado como escalable. De la agenda del 31-10 salen dos puntos que escalan, y están encadenados: el segundo no se puede decidir bien sin el primero. Lo demás que traías (ver el final) no escala.

### Punto previo: el acta no declara quién decide qué

El acta de constitución del 2026-02-27 no tiene ninguna sección de autoridad del gerente: ni umbrales de costo, ni de fecha, ni de alcance. La ficha lo registra como `identity.authority: no encontrado`. Por regla es el primer punto que escala, antes que el que venías a subir.

**Pregunta cerrada:** ¿Se declara por escrito, en el acta o en una adenda, hasta dónde decide el gerente (costo, fecha, alcance) y qué sube al Comité Ambiental?

**Quién decide:** el único dato del acta es que el **Comité Ambiental aprobó el presupuesto** el 2026-02-27, y que Laura Vélez es patrocinadora. Que ellos fijen la autoridad es una inferencia mía; el acta no lo dice. · **Si no se decide hoy:** no hay fecha externa en los documentos. El próximo comité es el **2026-10-31** (en 14 días); si no entra ahí, cada cambio, incluido el siguiente, se vuelve a discutir sin saber a quién le tocaba.

**Recomiendo:** pedirlo el 10-31 junto con el punto siguiente. Con la autoridad escrita, el comité sabe si CC-01 era del gerente, del patrocinador o suyo.

---

### ¿Se ratifica CC-01 (+115 días, +230.000.000 COP, ampliación de alcance) con acta del comité, o se vuelve a la línea base v1?

**Quién decide:** no declarado en el acta. Por lo que hay, el Comité Ambiental (aprobó el presupuesto original; el cambio suma 28,75 % sobre los 800.000.000 COP) con Laura Vélez como patrocinadora. · **Si no se decide hoy:** el cronograma v2 (2026-10-16) y el informe de avance ya se apoyan en CC-01, y la solicitud solo dice «Autorizada por el comité». La minuta del comité del 10-10 no menciona el cambio, y no hay otra acta. Hoy la línea base vigente no tiene documento que la sustente. Fecha dura: ninguna en los documentos; la más cercana que depende de esto es el hito «Licencia y permisos obtenidos», 2026-12-01 (45 días).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| **A. Ratificar CC-01 tal cual** | Ampliado, **sin detalle** (la solicitud dice solo «Ampliación de alcance») | Fin 2027-09-20 (v1: 2027-05-28; +115 días) | 1.030.000.000 COP (+230.000.000). La proyección declarada es 1.030.910.468, **910.468 por encima** |
| **B. Ratificar con el detalle del alcance anexo y la autoridad declarada** | Ampliado y descrito | Igual que A | Igual que A |
| **C. No ratificar; volver a v1** | Componentes 1 a 3, sin la ampliación | Fin 2027-05-28 | 800.000.000 COP (ejecutado a la fecha: 194.512.198). **No sé** qué se pierde ni qué ya se comprometió de la ampliación |

**Recomiendo:** B. El proyecto ya trabaja sobre v2, así que C obliga a deshacer lo hecho sin saber cuánto es. A deja aprobados 230 millones sobre un alcance que ningún documento describe. B cuesta lo mismo que A y deja escrito qué se compró.

### A quién alcanza

La ficha no registra otro proyecto, y el acta declara «Ninguna» dependencia, así que `impact` devuelve **cero proyectos alcanzados**. Eso no prueba que ninguno lo esté: significa que nadie declaró una dependencia. La ejecución de la obra sí toca al proveedor CT-812 (Automatización de Procesos Ltda.), que tiene la calibración de sensores el 2026-12-28 y el soporte el 2027-04-05. El contrato no se ha modificado por CC-01, que yo sepa.

### Mis hitos por los que pasa

Salen de `impact` con 115 días. Ojo: esa herramienta mide desde la fecha vigente, que ya incluye CC-01, así que **sumaría el cambio dos veces** (daría 2028-01-13). Uso solo la lista de hitos y sus distancias; no el «fin nuevo».

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Licencia y permisos obtenidos | 2026-12-01 | 45 |
| Montaje e instalación | 2027-02-28 | 134 |
| Pruebas en operación | 2027-09-20 (v1: 2027-05-28) | 338 |

Una cosa para aclarar antes del comité: en v2 **solo se movió el último hito** (+115 días). Licencia y Montaje siguen con la fecha de v1 aunque el alcance se amplió. Puede ser correcto o puede ser un cronograma a medio actualizar; el cronograma no lo explica.

**Lo que no sé y no inventé:** cuántos días se mueve cada hito intermedio (la ficha no tiene holgura por actividad); en qué consiste la ampliación; si el comité sí lo autorizó de palabra; cuál es la fecha límite externa de la decisión.

### De dónde sale esto

- Falta de autoridad y presupuesto aprobado por el Comité Ambiental: `00-gobierno/2026-02-27-acta-constitucion.docx` (cierre 2027-05-28, 800.000.000 COP, dependencias «Ninguna declarada»).
- CC-01 (+115 días, 230.000.000 COP, «Autorizada por el comité»): `20-seguimiento/2026-10-10-solicitud-cambio-cc-01.md`.
- Sin mención del cambio: `30-reuniones/2026-10-10-comite-semanal.md` (lista de compromisos, cerrados y «lo que se dijo»).
- Fechas de hitos, v1 y v2: `10-plan/2026-02-27-cronograma-v1.csv`, `10-plan/2026-10-16-cronograma-v2.xlsx`.
- Proyección 1.030.910.468 y ejecutado 194.512.198 (declaraciones del gerente): `20-seguimiento/2026-10-16-informe-avance.pdf`.
- Próximo comité 2026-10-31: `.criterio/proyecto/PRY-202/config.json` (`committee_next`).
- Distancias en días: `portafolio.py impact --code PRY-202 --days 115`.

---

### Lo que revisé y no escala

- **Compromiso «enviar el documento 1»** (Javier Hoyos, 6 reprogramaciones, ahora 2026-12-08): el patrón califica, pero nadie ha nombrado qué lo bloquea, así que no hay decisión que formular. Primero hay que preguntarle a Javier Hoyos qué lo frena; si es algo fuera del proyecto, vuelve a este comando.
- **CT-812** (licenciamiento vencido el 2026-06-15, «bolsa de horas» recibida sin acta, factura del 09-02): la condición de pago del contrato exige acta de recibo firmada por el gerente, o sea que corregirlo es de Jorge Medina. No sube.
- **Riesgos sin dueño y «CC-01 sin acta»**: lo segundo está cubierto arriba; los riesgos los asigna el gerente con la sala.

**Qué hacer con esto:** este documento es el paquete; llevarlo al comité del 10-31 es tuyo. Si el comité decide, se registra la decisión con su acta y se cierra el ítem; la línea base v1 no se toca.
