## Reunión de seguimiento — PRY-202 Planta de tratamiento de agua · 2026-10-31
12 puntos · 52 minutos · 9 personas requeridas (Javier Hoyos, Gustavo Neira, Camilo Beltrán, Laura Vélez, Rubén Cárdenas, Felipe Arango, Jorge Medina, Óscar Ramírez, Ricardo Salas)

Fecha tomada de `cycle.committee_next` (sábado 2026-10-31); las notas del 17-10 dicen «próxima reunión en dos semanas», que coincide. No se pidió un tope de minutos: la suma es 52. Si hay que cortar, salen primero los puntos 12, 11 y 10, en ese orden.

Es la primera corrida: no hay agenda anterior contra la cual comparar, así que «lo que cambió» es todo lo abierto en la ficha. Cifras de `portafolio.py` y de la corrida de `/pm-commitments` del 17-10.

El informe de avance del 16-10 declara el proyecto en verde (89 %). Esta agenda parte de lo que los documentos sostienen, que no es lo mismo.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «enviar el documento 1» y dejar una fecha con alguien que la pueda cumplir** · 10 min · **Javier Hoyos**
> Prometido para el 2026-12-08, y antes para el 11-24, y antes para el 11-13, y antes para el 10-28, el 10-16, el 09-29 y el 09-08. Seis reprogramaciones; la fecha actual queda 91 días después de la promesa original.
> Fuente: acta del 2026-09-05 (promesa original) y notas del 2026-10-17. La nota del 17 dice «08/12/2026»; se leyó día/mes. Confirmar la fecha en la sala.
> **Si no se resuelve hoy:** se reprograma por séptima vez. Si el bloqueo no depende de nadie en la sala, es punto de comité y se formula con `/pm-escalate`.

> **[2] Cerrar la prueba 2, o decir qué la frena** · 5 min · **Gustavo Neira**
> Prometido para el 2026-11-30, y antes para el 11-09, el 10-24, el 10-16, el 10-01 y el 09-12. Cinco reprogramaciones.
> Fuente: comités del 2026-10-03 y 2026-10-10.
> **Si no se resuelve hoy:** pasa de diciembre sin fecha confiable.

> **[3] Validar el ambiente 4, o decir qué lo frena** · 6 min · **Camilo Beltrán**
> Prometido para el 2026-12-05, y antes para el 11-24, el 11-12, el 10-26, el 10-12 y el 09-23. Cinco reprogramaciones.
> Fuente: comités del 2026-10-03 y 2026-10-10.
> **Si no se resuelve hoy:** igual que el punto 2.

### Vencido sin evidencia
Más viejo primero.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Laura Vélez | Revisar el anexo 11 | 2026-09-23 (24 días) | En comité del 10-03 dijo que ya lo entregó; no hay acta de recibo. Pasar el documento o la fecha de entrega. | 4 |
| Gustavo Neira | Actualizar la matriz 6 | 2026-10-11 (6 días; reprogramado una vez) | En comité del 10-10 dijo que ya lo entregó; no hay acta de recibo. Pasar el documento o la fecha. | 3 |
| Rubén Cárdenas | Actualizar la matriz 14 | 2026-10-12 (5 días; reprogramado una vez) | Entregar, o nueva fecha dicha en voz alta. | 2 |
| Felipe Arango | Enviar el documento 9 | 2026-10-15 (2 días) | Entregar, o nueva fecha. | 2 |

Fuente: comités del 2026-10-03 y 2026-10-10; cálculo del 17-10. Mientras no haya acta de recibo, «ya lo entregué» no cierra el compromiso.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[8]** Fecha para «aprobar el diseño 21» (sin fecha desde el 10-10) y para «mandar el ajuste del presupuesto» (las notas del 17 dicen «la otra semana»). | Laura Vélez | Siguen sin poder vencerse, y la misma persona ya tiene el anexo 11 vencido. Laura Vélez además figura como patrocinadora en el acta de constitución. | 4 |
| **[9]** Dueño para tres riesgos que hoy no tienen: el proveedor sin fecha confirmada de la última entrega (informe 10-16), la ventana de parada de planta (informe 10-16) y «el proveedor podría no llegar con el equipo completo para la siguiente fase» (notas 10-17, nadie lo anotó). | Jorge Medina con la sala | Los tres siguen sin dueño; el tercero se dijo en voz alta y no quedó en ningún registro más que la ficha. La ficha no dice cuál es «la siguiente fase». | 4 |
| **[10]** Quién autorizó CC-01 (+115 días, +230.000.000 COP). La solicitud del 10-10 dice «aprobado por el Comité»; el comité del 10-10 no lo menciona. La línea base v2 (fin 2027-09-20) se apoya solo en esa solicitud. | Laura Vélez / Jorge Medina | La línea base vigente queda sin acta que la sustente. | 4 |
| **[11]** Entregables de CT-812 (Automatización de Procesos Ltda.): «Licenciamiento del software» venció el 2026-06-15 y sigue pendiente; «Bolsa de horas de ingeniería» venció el 09-21 y figura aceptada sin documento de recibo. Hay una factura del 09-02 por 63.399.928 COP. Las notas no dicen quién responde por el contrato. | Jorge Medina, con Óscar Ramírez (su «revisión con el proveedor» es el 10-27) | Se sigue facturando contra entregables sin evidencia de recibo. | 4 |

Fuente: ficha PRY-202 (`raid`, `changes`, `vendors`), informe del 2026-10-16, notas del 2026-10-17. El punto 11 se arma con lo que dicen la ficha y el contrato; no se sabe si hay actas de recibo fuera de la carpeta.

### Vence antes de la próxima
**[12]** 3 min en total: confirmar en voz alta cada fecha, sin discutirlas.

| Quién | Qué | Para cuándo |
|---|---|---|
| María Restrepo | Revisar el anexo 19 | 2026-10-20 |
| Ricardo Salas | Aprobar el diseño 5 (ya reprogramado dos veces) | 2026-10-21 |
| Paula Céspedes | Validar el ambiente 12 (reprogramado una vez) | 2026-10-23 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-24 |
| Javier Hoyos | Confirmar la fecha 23 | 2026-10-24 |
| Paula Céspedes | Cerrar la prueba 10 | 2026-10-25 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 |

Estos vencen antes del 10-31: si alguno falla, aparecerá en la próxima agenda como vencido, no como preventivo. Solo Ricardo Salas necesita estar; los demás pueden confirmar por mensaje.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Andrés Lozano · Entregar el punto 8 (vencido desde el 10-04, 13 días) | No figura entre los asistentes de las notas del 17-10 ni del comité del 10-10. Si no va a estar, no se puede destrabar en la sala. | Mensaje directo antes de la reunión; si asiste, entra como vencido sin evidencia. |
| Si el punto 1 resulta ser un bloqueo fuera del alcance del gerente | Seis reprogramaciones apuntan a algo que nadie ha nombrado, y la sala puede no tener autoridad para resolverlo. | `/pm-escalate` para formularlo como decisión; no está formulado todavía. |

### Anexo — sin cambios desde el 2026-10-17
No se repasa en la reunión.
- Mauricio Pérez · Entregar el punto 24 (2026-11-01)
- Sandra Gil · Actualizar la matriz 22 (2026-11-05)
- Gustavo Neira · Entregar el punto 16 (2026-11-02, reprogramado una vez)
- Diana Molina · Cerrar la prueba 18 (2026-11-16, reprogramado una vez)
- Vendor CT-812: «Calibración de sensores» (2026-12-28) y «Soporte del primer trimestre» (2027-04-05) pendientes, aún no vencen.
- Cerrados con documento el 10-03 y 10-10: anexo 3, fecha 7, fecha 15, documento 17, ambiente 20.

## Qué no sé
- No hay agenda ni minuta previa de «lo pendiente de decidir»: ni los comités ni las notas del 17 traen una sección de decisiones pendientes. Por eso no hay un punto de «decisiones heredadas»; solo los de la ficha.
- La ficha no tiene `identity.phase`, `identity.authority` ni producto. No sé qué decisiones exceden la autoridad de Jorge Medina más allá de lo que se infiere.
- Los minutos son estimaciones mías, no una regla; Jorge Medina los ajusta.
- Esta agenda no convoca a nadie ni dirige la reunión. Cuando termine, `/pm-minutes` sobre las notas y `/pm-commitments` para los compromisos nuevos.
