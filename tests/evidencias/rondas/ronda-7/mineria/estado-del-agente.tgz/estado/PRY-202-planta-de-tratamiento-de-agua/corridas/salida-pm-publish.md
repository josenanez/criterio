Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

Recalculé antes de publicar (`compute`, corte 2026-10-17). `plan.end_date` es **2027-09-20**, tomada del cronograma v2 del 2026-10-16 (el más nuevo); la del acta, 2027-05-28, queda en `plan.baseline` v1, y la v2 (CC-01, +115 días) como vigente.

Publiqué la ficha en `documentos/proyectos/PRY-202-planta-de-tratamiento-de-agua/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 165 campos con dato · 12 sin decir en ninguna parte · declara **verde** al 2026-10-16

**Lo más viejo que va ahí:** `vendors[0].contract_ref` y los importes y fechas de los entregables del contrato CT-812, del 2026-02-21 — menos de un año, no pasa el umbral de 12 meses.

**Para que lo sepas antes de que la PMO lo lea:** la declaración «verde» va marcada como declarada, y el cálculo la contradice con 7 señales (variación de tiempo del 25,8 % contra la línea base original, proyección de costo 28,9 % sobre lo aprobado, avance declarado de 89 % frente a 40–60 % que sostiene el plan, dos hitos «cumplidos» sin evidencia, compromisos vencidos y reprogramados, y un entregable del proveedor atrasado 124 días). Además, sin evidencia documental los 5 hitos y los 4 entregables del proveedor; sin dato: producto, autoridad y fase.

Escribí solo ese archivo; no avisé a nadie. Vera lo encontrará en su próximo barrido.
