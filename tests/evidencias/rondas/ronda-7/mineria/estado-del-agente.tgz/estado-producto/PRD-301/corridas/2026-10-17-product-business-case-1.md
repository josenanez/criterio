# Corrida del 2026-10-17 · product-business-case

PRD-301 · 17 requerimientos · 28 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada (volumen_mensual 191.637) sin serie medida; costos, retorno, criterio de éxito y propuesta en vacíos; sin otros productos publicados para el cruce.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Alerta de taludes (PRD-301) · borrador del 2026-10-17
**Desde:** la definición del 2026-06-09 y el caso de negocio del 2026-06-09 · **Cifras con fuente:** 1 de 1 (la única cifra es declarada; ninguna es medida)

> Este borrador arma la estructura y la trazabilidad. No contiene proyecciones, retorno ni beneficios: son del negocio. Decidir si se aprueba es de quien tiene la autoridad (Comité de producto).

## Qué problema resuelve, y para quién
«El segmento Comunidad no tiene alerta de taludes.» Segmento: Comunidad. (Definición de producto, `00-definicion/2026-06-09-definicion-producto.docx`, 2026-06-09.)
La propuesta no está escrita: la definición solo trae el encabezado «Propuesta principal», sin texto.

## Qué se construye
Fuente única: acta del comité del 2026-10-09 (`30-decisiones/2026-10-09-comite-producto.docx`). Son 12 aceptados; los 5 propuestos no entran al caso. Todos los títulos son el genérico «Requerimiento REQ-xxxx» y ninguno tiene proyecto que lo ejecute (el acta pone «—»).

| Requerimiento | Estado (desde) | Evidencia de demanda |
|---|---|---|
| REQ-4100 | aceptado (2026-08-03) | «Cliente entrevistado», sin nombre; doliente «sin asignar» |
| REQ-4101 | aceptado (2026-08-25) | «Cliente entrevistado», sin nombre |
| REQ-4104 | aceptado (2026-06-13) | «Cliente entrevistado», sin nombre |
| REQ-4105 | aceptado (2026-03-30) | «Cliente entrevistado», sin nombre |
| REQ-4106 | aceptado (2026-06-21) | «Cliente entrevistado», sin nombre |
| REQ-4107 | aceptado (2026-08-22) | «Cliente entrevistado», sin nombre |
| REQ-4109 | aceptado (2026-07-26) | «Cliente entrevistado», sin nombre |
| REQ-4111 | aceptado (2026-06-07) | «Cliente entrevistado», sin nombre |
| REQ-4113 | aceptado (2026-07-20) | «Cliente entrevistado», sin nombre |
| REQ-4114 | aceptado (2026-06-06) | «Cliente entrevistado», sin nombre |
| REQ-4108 | aceptado (2026-08-11) | **Ninguna**: «Quién lo pidió» es «—» |
| REQ-2030 | aceptado (2026-09-28) | **Ninguna**: «Quién lo pidió» es «—» |

La única evidencia de demanda de la carpeta es la entrevista del 2025-08-30: «Lo necesito y hoy no lo tengo.» (Cliente entrevistado, tema «Necesidad principal»). Tiene 13 meses, supera el umbral de 12, y no nombra ninguno de estos requerimientos.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 191.637 | **Declarada** | `00-definicion/2026-06-09-caso-de-negocio.md`, tabla «Cifras que sostienen el caso» | 2026-06-09 |

La unidad de `volumen_mensual` (¿transacciones, alertas, usuarios, mediciones?) no está escrita en el documento. La fuente que da la tabla es el propio caso de negocio: la cifra se cita a sí misma, sin documento de origen.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 191.637 | **No hay serie medida** | Declarada: caso de negocio, 2026-06-09. Medida: ninguna en la carpeta |

No se puede contrastar; no es una coincidencia, es una ausencia. Umbral de la configuración para señalar brecha: 20 %.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No declarado** | Ningún documento |
| Costo del equipo | **No declarado** | Ningún documento |
| Contratos o cotizaciones | **No declarados** | Ningún documento |

Sin el costo de construir no hay caso de negocio que evaluar: hay una propuesta. Es el primer vacío.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La red de la mina soporta el volumen» (declarado el 2026-08-20, sin verificar; lleva 58 días contra un umbral de 30) | El volumen declarado (191.637) no se puede atender y el producto no opera como se plantea. Es una consecuencia lógica de la redacción del supuesto, no una estimación | Sin responsable nombrado. Se propone la gerente de producto, Natalia Ospina, para asignarlo |
| Supuesta, implícita: que el volumen_mensual declarado es el que Comunidad generará | Toda cifra derivada del volumen cae | Sin responsable: lo produce el negocio |
| Supuesta, implícita: que la demanda de una entrevista de 2025 sigue vigente | Los 12 requerimientos aceptados quedan sin sustento actual | Sin responsable: requiere una ronda nueva de descubrimiento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y del equipo | Sin costo no hay caso, hay propuesta | El negocio / la gerente de producto |
| Retorno esperado: el caso dice «Retorno esperado en 24 meses» sin cifra, base ni método | Es una frase, no una cifra; no se puede sustentar ni refutar | El negocio |
| Criterio de éxito (la definición no lo declara) | Sin él el producto no se puede cerrar meses después | El comité de producto |
| La propuesta («Propuesta principal» está vacía) | No hay qué evaluar | La gerente de producto |
| Unidad y origen de volumen_mensual | La cifra no se puede reconstruir | Quien la declaró (preparó el caso: Natalia Ospina) |
| Serie medida del volumen | No hay contra qué contrastar la cifra declarada | El sistema donde el producto vive |
| Proyecto que ejecute los 12 aceptados | Decidido y nadie lo construye; el más viejo (REQ-4105) lleva 201 días | El comité de producto |
| Quién pidió REQ-4108 y REQ-2030 | Aceptados sin demanda citada | Sus dolientes (Mauricio Pérez, Diana Molina) |
| Doliente de REQ-4100 | «sin asignar» | El comité de producto |
| Decisión sobre REQ-4103, REQ-4102, REQ-4112 (propuestos, 130 a 203 días; umbral 60) | Llevan meses sin decidirse | El comité de producto |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito, y el caso solo dice «Retorno esperado en 24 meses», sin métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después. Lo que sí hay para construirlo: la métrica `volumen_mensual`, que necesitaría una serie medida y una fecha de corte.

## Si hay otros productos publicados
No hay ninguno publicado a la vista (solo PRD-301 en `.criterio/producto/`). No se pudo hacer el cruce de `/product-overlap`; si otro producto afirma el mismo volumen, esta sección queda pendiente.

## Qué sigue
- Pasar los supuestos al seguimiento con **assumption-tracking**: el de la red lleva 58 días sin verificar.
- `/product-charter` solo cuando el caso tenga costo y criterio de éxito y el comité lo apruebe.
