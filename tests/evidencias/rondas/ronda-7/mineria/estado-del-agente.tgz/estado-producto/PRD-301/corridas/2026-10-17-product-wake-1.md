# Corrida del 2026-10-17 · product-wake

PRD-301 · 17 requerimientos · 23 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Primera revisión sin corte previo: línea base de señales abiertas (3 sin decidir, 1 supuesto sin verificar, 14 con evidencia vencida). No confirmé trazas por falta de carpeta de fichas, no releí documentos ni contrasté el volumen declarado: no hay medición.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Alerta de taludes (PRD-301) · 2026-10-17

**Primera revisión: no hay corte anterior** (`last: null`), así que no puedo decir qué cruzó un umbral *desde* el último corte. Lo que sigue es la línea base: lo que ya estaba abierto hoy. A partir del corte que deja esta corrida, solo se reportará lo nuevo.

Registro: 17 requerimientos (12 aceptados, 5 propuestos). 10 con evidencia (83,3 % de los decididos), 0 con traza a proyecto.

### Lo que necesita decisión (comité de producto)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4103 | 203 días (desde 2026-03-28) | Que el comité decida; doliente: Jorge Medina. Umbral: 60 días | Comité de producto |
| Propuesto sin decidir | REQ-4102 | 166 días (desde 2026-05-04) | Ídem; doliente: Javier Hoyos | Comité de producto |
| Propuesto sin decidir | REQ-4112 | 130 días (desde 2026-06-09) | Ídem; doliente: Liliana Torres | Comité de producto |
| Supuesto sin verificar: «La red de la mina soporta el volumen» | definición | 58 días (umbral 30) | Una medición de capacidad de red contra el volumen declarado (191.637 mensual). Ya pasó el punto en que conviene tratarlo como riesgo registrado | Natalia Ospina (responsable del producto) |

### Aceptado sin sustento
- **Sin evidencia de demanda:** REQ-2030, REQ-4108.
- **Sin criterio de aceptación:** REQ-4101, 4104, 4105, 4107, 4109, 4114.
- **Sin doliente:** REQ-4100.
- **Nadie lo construye:** los 12 aceptados están sin proyecto ni traza (0 %). Sin la carpeta de fichas, ninguna traza se da por confirmada.

### Evidencia vencida
14 requerimientos se sostienen en una sola fuente: la entrevista del 2025-08-30 (13 meses; umbral 12). Además, esa entrevista atribuye el pedido a un «Cliente entrevistado» y no nombra ningún requerimiento. Por eso la definición queda sin sustento fechado en la afirmación de demanda del segmento Comunidad.

### Contraste negocio–datos
La cifra declarada de volumen mensual (191.637, caso de negocio del 2026-06-09) no tiene medición que la contraste. No puedo calcular la brecha. Tampoco está definido el criterio de éxito (`success` sin dato).

### Las trazas
No hay carpeta de fichas configurada, así que no confirmé ninguna traza.

### Del descubrimiento
No releí documentos. Hay 4 en la carpeta (definición, caso de negocio, entrevistas 2025-08-30, acta del comité 2026-10-09). No comparé sus huellas con una lectura anterior.

**Vuelvo el 2026-11-16.**
