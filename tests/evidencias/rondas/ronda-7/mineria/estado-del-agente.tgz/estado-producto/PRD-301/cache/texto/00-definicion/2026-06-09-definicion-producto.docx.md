<!-- origen: 00-definicion/2026-06-09-definicion-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Definición de producto · Alerta de taludes

Código: PRD-301

Gerente de producto: Natalia Ospina

Segmento: Comunidad

Fecha de la definición: 2026-06-09

El problema

El segmento Comunidad no tiene alerta de taludes.

La propuesta

• Propuesta principal

Supuestos

• La red de la mina soporta el volumen · declarado el 2026-08-20 · sin verificar

Proyectos que lo construyen

• Ninguno declarado
