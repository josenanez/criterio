# Corrida del 2026-10-17 · product-trace

PRD-301 · 17 requerimientos · 26 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

12 requerimientos decididos y ninguno tiene proyecto; ninguna ficha dice ejecutar PRD-301

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Alerta de taludes (PRD-301) · al 2026-10-17
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

### Decidido y nadie lo está construyendo
Ninguno de los 12 requerimientos aceptados declara proyecto: el acta del comité del 2026-10-09 trae «—» en cada uno (`documentos/productos/PRD-301/30-decisiones/2026-10-09-comite-producto.docx`). Por quién: Comité de producto (autoridad del producto); el acta no nombra a una persona que decidiera cada uno. El dueño es el que dice el registro.

| REQ | Título | Decidido el | Dueño en el registro |
|---|---|---|---|
| REQ-4105 | Requerimiento REQ-4105 | 2026-03-30 | Ricardo Salas |
| REQ-4114 | Requerimiento REQ-4114 | 2026-06-06 | Javier Hoyos |
| REQ-4111 | Requerimiento REQ-4111 | 2026-06-07 | Óscar Ramírez |
| REQ-4104 | Requerimiento REQ-4104 | 2026-06-13 | Beatriz Cuéllar |
| REQ-4106 | Requerimiento REQ-4106 | 2026-06-21 | Felipe Arango |
| REQ-4113 | Requerimiento REQ-4113 | 2026-07-20 | Liliana Torres |
| REQ-4109 | Requerimiento REQ-4109 | 2026-07-26 | Gustavo Neira |
| REQ-4100 | Requerimiento REQ-4100 | 2026-08-03 | sin asignar |
| REQ-4108 | Requerimiento REQ-4108 | 2026-08-11 | Mauricio Pérez |
| REQ-4107 | Requerimiento REQ-4107 | 2026-08-22 | María Restrepo |
| REQ-4101 | Requerimiento REQ-4101 | 2026-08-25 | Rubén Cárdenas |
| REQ-2030 | Requerimiento REQ-2030 | 2026-09-28 | Diana Molina |

El más viejo, REQ-4105, lleva 201 días decidido sin proyecto.

### La traza no se confirma
Vacío: no hay trazas declaradas que confirmar, porque ningún requerimiento nombra proyecto.

### Lo que un proyecto construye y el registro no tiene
Vacío: de las 13 fichas leídas (PRY-199 a PRY-211), ninguna dice que ejecuta PRD-301. Cuidado: esto es ausencia en las fichas; no prueba que ningún proyecto trabaje en taludes (PRY-204, «Monitoreo de taludes», es el candidato obvio por nombre, pero ni su ficha ni el acta los vinculan, y no lo afirmo).

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| 12 aceptados (lista arriba) | aceptado | Comité 2026-10-09 | — | no | — |
| REQ-4102, 4103, 4110, 4112, 4115 | propuesto | sin decisión | — | no | — |

Los 5 propuestos no necesitan traza todavía; 3 llevan más de 60 días sin decidirse (REQ-4103 203 días, REQ-4102 166, REQ-4112 130).

### Sin fichas a la vista
Hay fichas de 13 proyectos, pero la cadena se rompe antes: el eslabón requerimiento → proyecto no existe, así que ninguna ficha se pudo contrastar. Sin proyecto declarado, ninguna traza se da por confirmada.

Después: ofrezco `/criterio-product:product-charter` para el requerimiento que ya esté listo para volverse proyecto; REQ-4105 es el más antiguo.
