# Corrida del 2026-10-17 · product-setup

PRD-301 · 17 requerimientos · 29 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

0 preguntas hechas (4 respondidas con la propuesta por defecto); minutos hasta el primer resultado no medidos (sesión sin interfaz); 4 documentos, 17 requerimientos levantados; sin criterio de éxito, sin serie medida, 0 de 12 aceptados con proyecto, 14 evidencias de 13 meses. Nota: sellar exigió corrida-inicio pese a que el comando dice que no va.

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

> El comando no entregó su resultado (`--salida`): la corrida registra las cifras, pero lo que dijo se quedó en la conversación.
