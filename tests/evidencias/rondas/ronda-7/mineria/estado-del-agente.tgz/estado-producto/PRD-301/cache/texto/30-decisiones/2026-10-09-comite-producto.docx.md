<!-- origen: 30-decisiones/2026-10-09-comite-producto.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de producto · Alerta de taludes

Fecha: 2026-10-09

Asistentes: Natalia Ospina

Requerimientos revisados

ID

Requerimiento

Doliente

Criterio de aceptación

Quién lo pidió

Estado

Desde

Proyecto que lo ejecuta

REQ-4100

Requerimiento REQ-4100

sin asignar

se verifica en producción

Cliente entrevistado

aceptado

2026-08-03

—

REQ-4101

Requerimiento REQ-4101

Rubén Cárdenas

—

Cliente entrevistado

aceptado

2026-08-25

—

REQ-4102

Requerimiento REQ-4102

Javier Hoyos

se verifica en producción

Cliente entrevistado

propuesto

2026-05-04

—

REQ-4103

Requerimiento REQ-4103

Jorge Medina

se verifica en producción

—

propuesto

2026-03-28

—

REQ-4104

Requerimiento REQ-4104

Beatriz Cuéllar

—

Cliente entrevistado

aceptado

2026-06-13

—

REQ-4105

Requerimiento REQ-4105

Ricardo Salas

—

Cliente entrevistado

aceptado

2026-03-30

—

REQ-4106

Requerimiento REQ-4106

Felipe Arango

se verifica en producción

Cliente entrevistado

aceptado

2026-06-21

—

REQ-4107

Requerimiento REQ-4107

María Restrepo

—

Cliente entrevistado

aceptado

2026-08-22

—

REQ-4108

Requerimiento REQ-4108

Mauricio Pérez

se verifica en producción

—

aceptado

2026-08-11

—

REQ-4109

Requerimiento REQ-4109

Gustavo Neira

—

Cliente entrevistado

aceptado

2026-07-26

—

REQ-4110

Requerimiento REQ-4110

Óscar Ramírez

se verifica en producción

Cliente entrevistado

propuesto

2026-08-25

—

REQ-4111

Requerimiento REQ-4111

Óscar Ramírez

se verifica en producción

Cliente entrevistado

aceptado

2026-06-07

—

REQ-4112

Requerimiento REQ-4112

Liliana Torres

se verifica en producción

Cliente entrevistado

propuesto

2026-06-09

—

REQ-4113

Requerimiento REQ-4113

Liliana Torres

se verifica en producción

Cliente entrevistado

aceptado

2026-07-20

—

REQ-4114

Requerimiento REQ-4114

Javier Hoyos

—

Cliente entrevistado

aceptado

2026-06-06

—

REQ-4115

Requerimiento REQ-4115

Diana Molina

—

Cliente entrevistado

propuesto

2026-09-02

—

REQ-2030

Requerimiento REQ-2030

Diana Molina

se verifica en producción

—

aceptado

2026-09-28

—

Decisiones

• Se mantiene el plan
