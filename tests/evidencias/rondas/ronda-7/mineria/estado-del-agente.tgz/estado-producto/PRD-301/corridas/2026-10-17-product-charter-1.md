# Corrida del 2026-10-17 · product-charter

PRD-301 · 17 requerimientos · 41 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

Borrador de acta para REQ-4100 (aceptado). Vacíos marcados, no rellenados: autoridad, patrocinador, doliente, criterio medible, propuesta, evidencia anónima y vencida. No se creó la ficha: el acta no está firmada. Sin barrido normativo.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Acta de constitución — Alerta de taludes (REQ-4100) · borrador del 2026-10-17
**Producto:** PRD-301 · Alerta de taludes · **Requerimientos:** REQ-4100

> Sesión de prueba sin interfaz: términos ya vigentes (v1.1, familia 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17, comprobante en `.criterio/terminos/`); no hubo que registrarlos de nuevo. Donde el comando ofrecía una pregunta se tomó la respuesta sugerida: **seguir sin lo que falta, marcándolo como vacío del acta.**

## Verificación previa (requirement-record)
| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | **Sí** — «aceptado», desde 2026-08-03 | `30-decisiones/2026-10-09-comite-producto.docx` |
| Criterios de aceptación verificables | **Dudoso** — dice «se verifica en producción»; no es un criterio medible, es un lugar | ídem |
| Evidencia de demanda con cita | **Débil** — una cita anónima y genérica, y la entrevista no nombra este requerimiento | `10-descubrimiento/2025-08-30-entrevistas.docx` |
| Autoridad declarada en la definición | **No** — ningún documento dice quién decide | `00-definicion/2026-06-09-definicion-producto.docx` |

Se sigue con el borrador porque el requerimiento está aceptado; las tres condiciones restantes quedan como vacíos, no rellenadas.

## Qué problema resuelve
«El segmento Comunidad no tiene alerta de taludes.» Segmento: Comunidad. (`00-definicion/2026-06-09-definicion-producto.docx`)
La «Propuesta principal» está como encabezado **sin texto**: la definición no dice qué se construye.

## Criterio de éxito
| Criterio | Cómo se verifica |
|---|---|
| «se verifica en producción» (`30-decisiones/2026-10-09-comite-producto.docx`) | **No está dicho.** Sin métrica, umbral ni responsable de verificar. La definición tampoco trae criterio de éxito del producto. |

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 (el título es genérico en el acta) | Cliente entrevistado, 2025-08-30: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). El acta atribuye el pedido a «Cliente entrevistado»; la entrevista no nombra este requerimiento. Tiene 13 meses a hoy (umbral de vigencia: 12). |

Necesidad y prioridad del requerimiento: no están dichas en ningún documento. Doliente: «sin asignar» en el acta.

### No entra
Esta acta cubre solo REQ-4100. Los demás del acta del comité de 2026-10-09 no se incluyen; no es una exclusión que el comité haya decidido, y nadie ha dicho que sea definitiva.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4102, 4103, 4110, 4112, 4115 | Requerimiento REQ-xxxx | Están «propuestos»: sin decisión de aceptarlos no pueden entrar a un acta. |
| REQ-4101, 4104, 4105, 4106, 4107, 4108, 4109, 4111, 4113, 4114, REQ-2030 | Requerimiento REQ-xxxx | Aceptados, pero no se pidieron en esta invocación. Si pertenecen al mismo proyecto, hay que decirlo antes de firmar; si no, quedan para otra acta. |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no hay base para proponer uno del proyecto. Natalia Ospina es la gerente del **producto** (definición, 2026-06-09) y única asistente del comité; no consta que vaya a ser del proyecto.
- **Comité:** «Comité de producto» (`30-decisiones/2026-10-09-comite-producto.docx`).
- **Autoridad del gerente:** no dicha. La ficha del producto trae «Comité de producto» como autoridad **propuesta por defecto**: el acta no menciona su autoridad.
- **Proyecto que lo ejecuta:** «—» en el acta; la definición dice «Ninguno declarado».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La red de la mina soporta el volumen» — declarado el 2026-08-20 (`00-definicion/2026-06-09-definicion-producto.docx`) | **No.** 58 días sin verificar (umbral: 30). La fecha de declaración es posterior a la del documento (2026-06-09): hay que aclararlo. | El gerente del proyecto, cuando lo haya; sin doliente hoy. Se registra como riesgo con raid-taxonomy. |

Está atado a la cifra del caso de negocio: `volumen_mensual` = 191.637, declarada sin fuente distinta de «Caso de negocio, 2026-06-09»; no se contrastó contra datos medidos en esta corrida.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| — | — | — | No se hizo barrido normativo. Los documentos no mencionan datos personales, pagos ni retención, pero una alerta dirigida a la comunidad puede tener obligaciones de seguridad o comunicación que ningún documento cita. **No se sabe.** |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Autoridad declarada | El gerente no sabrá qué puede decidir: escala todo o no escala nada | Comité de producto / quien lo patrocine |
| Patrocinador | Nadie responde por el presupuesto ni desbloquea | Por definir |
| Doliente del requerimiento («sin asignar») | Nadie responde por que el requerimiento se cumpla | Natalia Ospina (gerente del producto) |
| Criterio de aceptación medible | El cierre no se podrá juzgar meses después | Natalia Ospina |
| Propuesta principal sin texto y sin criterio de éxito del producto | No hay qué construir ni contra qué medir | Natalia Ospina |
| Necesidad y prioridad del requerimiento | No se puede ordenar frente a otros trabajos | Natalia Ospina |
| Evidencia de demanda anónima, genérica y vencida | El proyecto arranca sobre una demanda que nadie puede citar por nombre | Quien tenga acceso a los clientes |
| Presupuesto e hitos | El acta no los declara; no se inventan | Patrocinador |
| Proyecto que lo ejecuta | Sin proyecto, no hay traza que confirmar | Gerente del proyecto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre el producto (por definir: la autoridad no está declarada; propuesta por defecto, el Comité de producto). **La ficha del proyecto no se creó:** el acta no está firmada, y el paso 6 va después. No se ha corrido `portafolio.py init`.

**Qué sigue, y para quién:** firmada el acta, el gerente del proyecto —que hay que nombrar— instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
