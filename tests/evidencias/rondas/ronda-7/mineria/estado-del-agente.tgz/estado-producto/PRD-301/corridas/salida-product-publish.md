No publiqué la ficha de PRD-301 (Alerta de taludes). Corte al 2026-10-17.

**Motivo:** la configuración no define una carpeta de productos publicados (`paths` solo trae `documents` y `state`) y `productos/publicados` no existe. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No creé la carpeta ni elegí una por mi cuenta.

**Lo que habría llevado la ficha (calculado, sin escribir):**
- 17 requerimientos (12 aceptados, 5 propuestos) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Comunidad
- Métrica: volumen_mensual = 191637, de `documentos/productos/PRD-301/00-definicion/2026-06-09-caso-de-negocio.md` (2026-06-09). Sin serie medida: no hay contraste posible.

**Tenlo presente antes de publicar:** ningún requerimiento tiene proyecto asignado, así que la ficha no permitiría cruzar por proyecto. Además hay 12 requerimientos sin trazar, 14 con evidencia vencida (13 meses) y 1 supuesto sin verificar (58 días).

**Para avanzar:** indicar la carpeta de publicados acordada con los demás gerentes de producto y volver a correr el comando.
