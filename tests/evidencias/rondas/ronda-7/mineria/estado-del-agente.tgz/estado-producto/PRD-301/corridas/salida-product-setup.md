Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

*Sesión de prueba sin interfaz: las cuatro preguntas se respondieron con la propuesta por defecto. (1) Quién eres: Natalia Ospina, gerente de producto de Alerta de taludes (PRD-301), según la definición. (2) Quién decide: Comité de producto, que es lo único que ningún documento contradice; no lo declara nadie. (3) Estado: `estado-producto/PRD-301`, hermana de la documentación. (4) Términos: sí dado en la instrucción de la sesión por José Francisco Ñáñez, versión 1.1, 2026-10-17.*

## Listo — Alerta de taludes (PRD-301)

**Lo que miré:** 4 documentos · 1 de descubrimiento (una ronda de entrevistas del 2025-08-30) · la definición y el caso de negocio del 2026-06-09 · lo más reciente es el acta del comité de producto del 2026-10-09 · los 4 formatos se pudieron leer.
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.1 (familia 0.3.13) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a…

Levanté la ficha del producto y 17 requerimientos (12 aceptados, 5 propuestos), tal como están escritos en el acta.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Comunidad no tiene alerta de taludes» | Una sola entrevista, de un «cliente entrevistado» sin nombre: «Lo necesito y hoy no lo tengo.» No dice que sea de Comunidad. Evidencia media | 2025-08-30 (13 meses) |
| «La red de la mina soporta el volumen» | Solo un supuesto declarado, sin verificar desde hace 58 días | declarado el 2026-08-20 |
| Volumen mensual de 191.637 | Nada más que el propio caso de negocio. No hay serie medida | 2026-06-09 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben; sin él no hay cómo cerrar el producto.
- **La propuesta.** La definición tiene el encabezado «Propuesta principal» y nada debajo.
- **El retorno.** El caso dice «Retorno esperado en 24 meses» sin una cifra ni cómo se calcula.
- **De dónde sale el volumen de 191.637.** La cifra cita al caso de negocio como su fuente; no hay serie medida, así que nadie está midiendo lo que el negocio afirmó.
- **Quién decide qué se construye.** Ningún documento lo dice. El acta es de un «Comité de producto» a la que asistió solo la gerente; «Comité de producto» es mi propuesta, no una autoridad declarada.
- **Qué pidió cada requerimiento.** Los 17 se titulan «Requerimiento REQ-xxxx»; ninguno dice el problema.
- **Qué entrevista respalda cuál.** 14 requerimientos citan al «cliente entrevistado», y la única entrevista no nombra ninguno de ellos. Todos cuelgan de la misma frase.
- **Qué proyecto los construye.** La definición dice «Ninguno declarado» y el acta tampoco pone proyecto: 12 aceptados, 0 con traza (0,0 %). El acta decide «Se mantiene el plan», y en la carpeta no hay plan.

### Lo que sí se ve en el registro
- **Evidencia vieja:** los 14 requerimientos con evidencia se apoyan en una entrevista de hace 13 meses (umbral: 12).
- **Aceptados sin evidencia:** REQ-4108 y REQ-2030 (este último con numeración distinta a los otros 16).
- **Aceptados sin criterio de aceptación:** 6 (REQ-4101, 4104, 4105, 4107, 4109, 4114). En los demás el criterio es «se verifica en producción», que dice dónde, no qué.
- **Sin doliente:** REQ-4100 («sin asignar»).
- **Propuestos sin decidir:** REQ-4103 (203 días), REQ-4102 (166) y REQ-4112 (130).
- Con evidencia: 10 de 12 decididos (83,3 %).

### Supuestos sobre los que está escrita
Uno declarado: «La red de la mina soporta el volumen» (sin verificar, 58 días). Y está fechado el 2026-08-20 dentro de una definición del 2026-06-09: o se editó después sin cambiar la fecha, o la fecha está mal. Importa porque la cifra de 191.637 depende de él.

### Qué le falta a tu carpeta
- Las transcripciones completas de las entrevistas, y más de una: hoy hay una frase de un cliente.
- La serie medida del volumen mensual con su fuente, para contrastar el 191.637.
- Quién decide, y las decisiones del comité con quién las tomó; sin eso un requerimiento descartado se ve igual que uno que nadie miró.
- Un plan o proyecto al que cuelgue algo.

**Siguiente paso:** `/product-discovery` sobre las entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
