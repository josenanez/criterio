# Corrida del 2026-10-17 · product-publish

PRD-301 · 17 requerimientos · 12 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

No se publicó: no hay carpeta de productos publicados configurada ni existente

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-301 (Alerta de taludes). Corte al 2026-10-17.

**Motivo:** la configuración no define una carpeta de productos publicados (`paths` solo trae `documents` y `state`) y `productos/publicados` no existe. Sin un sitio común acordado, publicar no sirve, y acordarlo es una conversación de la organización, no un comando. No creé la carpeta ni elegí una por mi cuenta.

**Lo que habría llevado la ficha (calculado, sin escribir):**
- 17 requerimientos (12 aceptados, 5 propuestos) · 0 proyectos · 1 métrica afirmada
- Segmento declarado: Comunidad
- Métrica: volumen_mensual = 191637, de `documentos/productos/PRD-301/00-definicion/2026-06-09-caso-de-negocio.md` (2026-06-09). Sin serie medida: no hay contraste posible.

**Tenlo presente antes de publicar:** ningún requerimiento tiene proyecto asignado, así que la ficha no permitiría cruzar por proyecto. Además hay 12 requerimientos sin trazar, 14 con evidencia vencida (13 meses) y 1 supuesto sin verificar (58 días).

**Para avanzar:** indicar la carpeta de publicados acordada con los demás gerentes de producto y volver a correr el comando.
