<!-- origen: 00-definicion/2026-06-09-caso-de-negocio.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-06-09
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 191.637 | Caso de negocio, 2026-06-09 |

## Retorno esperado

Retorno esperado en 24 meses.
