# Corrida del 2026-10-17 · product-requirements

PRD-301 · 17 requerimientos · 31 s · 39 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 14 |
| `requirement_untraced` | 12 |
| `requirement_without_acceptance` | 6 |
| `requirement_undecided` | 3 |
| `requirement_accepted_without_evidence` | 2 |
| `requirement_without_owner` | 1 |
| `assumption_unverified` | 1 |

2 aceptados sin evidencia (REQ-2030, REQ-4108); 12 aceptados sin proyecto; 3 propuestos sin decidir hace más de 60 días (REQ-4103, 4102, 4112); evidencia de una sola entrevista de 2025-08-30 que no nombra ningún requerimiento

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Alerta de taludes (PRD-301) · al 2026-10-17
17 requerimientos · 12 decididos · 83.3% con evidencia · 0% con proyecto que lo ejecuta

Fuente única de los requerimientos: el acta del comité del 2026-10-09 (`documentos/productos/PRD-301/30-decisiones/2026-10-09-comite-producto.docx`). No hay carpeta de fichas de proyecto, así que el 0% con proyecto sale de que el acta declara «—» en los 17; ninguna ficha lo confirma ni lo desmiente. Todos los títulos son el genérico «Requerimiento REQ-xxxx»: el acta no los describe.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado el 2026-09-28 | Diana Molina |
| REQ-4108 | Requerimiento REQ-4108 | aceptado el 2026-08-11 | Mauricio Pérez |

Ninguno de los dos tiene una sola cita de quien lo pidió (el acta pone «—» en «Quién lo pidió»).

### Decidido y nadie lo está construyendo
Los 12 aceptados, sin proyecto declarado en el acta:

| REQ | Decidido el | Doliente |
|---|---|---|
| REQ-4105 | 2026-03-30 | Ricardo Salas |
| REQ-4109 | 2026-07-26 | Gustavo Neira |
| REQ-4113 | 2026-07-20 | Liliana Torres |
| REQ-4111 | 2026-06-07 | Óscar Ramírez |
| REQ-4104 | 2026-06-13 | Beatriz Cuéllar |
| REQ-4114 | 2026-06-06 | Javier Hoyos |
| REQ-4106 | 2026-06-21 | Felipe Arango |
| REQ-4100 | 2026-08-03 | sin asignar |
| REQ-4108 | 2026-08-11 | Mauricio Pérez |
| REQ-4107 | 2026-08-22 | María Restrepo |
| REQ-4101 | 2026-08-25 | Rubén Cárdenas |
| REQ-2030 | 2026-09-28 | Diana Molina |

El más viejo, REQ-4105, lleva 201 días aceptado sin proyecto.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | «sin asignar» (aceptado el 2026-08-03) |

### Sin criterio de aceptación
Solo los decididos:

| REQ | Título | Estado |
|---|---|---|
| REQ-4101 | Requerimiento REQ-4101 | aceptado |
| REQ-4104 | Requerimiento REQ-4104 | aceptado |
| REQ-4105 | Requerimiento REQ-4105 | aceptado |
| REQ-4107 | Requerimiento REQ-4107 | aceptado |
| REQ-4109 | Requerimiento REQ-4109 | aceptado |
| REQ-4114 | Requerimiento REQ-4114 | aceptado |

Los demás traen «se verifica en producción», que no es un criterio medible; el cálculo lo cuenta como presente.

### Decidido sin documento que lo respalde
El cálculo no emite esta señal. Lo que se ve: el acta del 2026-10-09 solo lista el estado de cada requerimiento y una decisión, «Se mantiene el plan». Asiste una persona, Natalia Ospina. No hay documento que diga quién aceptó cada uno de los 12 ni en qué sesión; las fechas «Desde» están, la decisión no. Es una lectura de la forma del acta, no un hallazgo calculado.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4103 | Requerimiento REQ-4103 | 203 días (desde 2026-03-28) | Comité de producto |
| REQ-4102 | Requerimiento REQ-4102 | 166 días (desde 2026-05-04) | Comité de producto |
| REQ-4112 | Requerimiento REQ-4112 | 130 días (desde 2026-06-09) | Comité de producto |

La configuración fija la autoridad en el «Comité de producto», y la gerente del producto es Natalia Ospina. El acta del 2026-10-09 revisó los tres y no decidió ninguno. REQ-4110 (53 días) y REQ-4115 (45 días) siguen bajo el umbral. REQ-4103 no tiene evidencia; no es hallazgo porque está propuesto.

### Evidencia vieja
Umbral: 12 meses. Los 14 requerimientos marcados descansan en la misma fuente, la entrevista del 2025-08-30 (13 meses). Esa entrevista habla de un «Cliente entrevistado» y no nombra ninguno de estos requerimientos.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4100, 4101, 4104, 4105, 4106, 4107, 4109, 4111, 4113, 4114 (aceptados) | entrevista 2025-08-30 | 13 meses |
| REQ-4102, 4110, 4112, 4115 (propuestos) | entrevista 2025-08-30 | 13 meses |

### Fuera de los requerimientos
- Supuesto sin verificar hace 58 días (umbral 30): «La red de la mina soporta el volumen».
- La definición no declara criterio de éxito.
- El volumen mensual declarado (191.637, caso de negocio del 2026-06-09) no tiene medición contra la que contrastarlo.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 12 | 0 | 0 | 0 |

Nada descartado: el registro solo ha crecido.
