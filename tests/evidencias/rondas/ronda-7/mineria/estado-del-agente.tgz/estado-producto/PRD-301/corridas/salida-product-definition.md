## Definición — Alerta de taludes (PRD-301) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-06-09-definicion-producto.docx` y `00-definicion/2026-06-09-caso-de-negocio.md` · **del** 2026-06-09 · 5 afirmaciones

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Esto es un borrador de trabajo: la verificación contra los documentos citados es de quien lo lee.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna métrica tiene serie medida contra la que comparar |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 191.637 | Caso de negocio, 2026-06-09 | No hay serie medida. No es contradicción: nadie está midiendo lo que el caso de negocio afirmó. |

### No está dicho en ninguna parte
- **La propuesta.** La definición trae el encabezado «Propuesta principal» sin texto: no se sabe qué se va a construir.
- **El criterio de éxito.** Ningún documento lo declara.
- **De dónde sale el 191.637.** El caso de negocio da el número y se cita a sí mismo como fuente; no dice qué cuenta ese volumen (¿lecturas, alertas, usuarios?) ni cómo se estimó.
- **El retorno.** «Retorno esperado en 24 meses» no trae monto, base de cálculo ni supuestos.
- **Quién decide.** Ningún documento dice quién tiene autoridad sobre el producto; «Comité de producto» es propuesto por defecto, y el acta del 2026-10-09 no menciona su autoridad.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»: la propuesta no tiene quién la ejecute.
- **Cuánta gente de Comunidad tiene el problema.** «El segmento Comunidad no tiene alerta de taludes» no trae tamaño del segmento ni cuántos la pidieron.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La red de la mina soporta el volumen | 58 (declarado el 2026-08-20; umbral 30) | Una medición de capacidad de la red contra el volumen que el caso de negocio afirma (191.637 al mes), con un responsable y una fecha. Hoy el supuesto depende de un volumen que tampoco está medido. |

Nota: el supuesto figura con fecha 2026-08-20 dentro de un documento fechado 2026-06-09; el documento se editó después de su fecha o la fecha del supuesto está mal. Conviene aclararlo con la autora.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Comunidad necesita una alerta de taludes y hoy no la tiene | Entrevista a «Cliente entrevistado»: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-30-entrevistas.docx`) | 2025-08-30 | Débil: es una declaración de uso futuro de una sola persona, sin nombre, sin pago ni compromiso, y no dice que pertenezca al segmento Comunidad. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Comunidad necesita la alerta | Entrevista del 2025-08-30 | 13 meses (umbral 12) |

Es la única evidencia de demanda de todo el producto: 14 de los 17 requerimientos se apoyan en esa misma entrevista, y la entrevista no nombra ninguno de ellos.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada identificable | — | — | — | No tengo la norma a la vista. Con la propuesta sin texto no hay de qué barrer; un sistema de alerta de taludes puede tocar normas de seguridad minera o de comunicación a comunidades, y el país del producto no está declarado. Esto va a revisión jurídica; no la reemplaza ni dice si hay cumplimiento. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Propuesta:** el encabezado está vacío.
- **Quién decide:** propuesto por defecto, sin confirmar.
- **Problema y para quién:** están escritos, pero sin tamaño ni evidencia vigente.

Después: el supuesto de la red lleva 58 días sin verificar y, con el umbral en 30, ya es candidato a riesgo con doliente. Con la definición sin criterio de éxito ni propuesta, no corresponde ofrecer `/product-charter`.
