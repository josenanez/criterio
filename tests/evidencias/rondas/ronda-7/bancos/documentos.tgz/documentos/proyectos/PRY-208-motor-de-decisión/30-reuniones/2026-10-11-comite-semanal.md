# Comité de Banca Empresas · Motor de decisión

**Fecha:** 2026-10-11
**Asistentes:** Liliana Torres, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 1 | 2026-11-01 |
| Rubén Cárdenas | Entregar el punto 37 | por definir |
