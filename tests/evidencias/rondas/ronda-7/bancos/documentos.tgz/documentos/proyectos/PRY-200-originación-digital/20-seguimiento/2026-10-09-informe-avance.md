# Informe de avance · Originación digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-09
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **44%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.610.506.322 |
| Ejecutado | 554.175.715 |
| Proyección al cierre | 2.218.213.406 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
