# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-10-09
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **30%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 13.830.604.592 |
| Ejecutado | 5.088.404.663 |
| Proyección al cierre | 18.145.395.715 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- El proveedor no ha confirmado la fecha de la última entrega
