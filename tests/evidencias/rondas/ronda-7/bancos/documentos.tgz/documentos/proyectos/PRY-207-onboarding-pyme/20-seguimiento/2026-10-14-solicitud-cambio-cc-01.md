# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-14
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +58 días sobre la línea base vigente |
| Costo | 116.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
