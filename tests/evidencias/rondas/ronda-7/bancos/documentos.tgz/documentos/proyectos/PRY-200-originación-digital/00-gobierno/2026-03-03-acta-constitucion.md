# Acta de constitución · Originación digital

**Código:** PRY-200
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Riesgos
**Producto asociado:** crédito de consumo
**Fecha de aprobación:** 2026-03-03

## Objetivo del negocio

Entregar originación digital para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2026-03-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-13 |
| Cierre | 2026-12-17 |

## Criterio de éxito

Originación digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
