# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 4 | 2026-10-29 |
