# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-10-11
**Asistentes:** Jorge Medina, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 36 | 2026-10-10 |
