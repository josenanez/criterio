# Comité de Medios de Pago · Prevención de lavado de activos

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-11-24 |
| Carlos Peña | Cerrar la prueba 2 | 2026-11-17 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 |
| Natalia Ospina | Confirmar la fecha 7 | 2026-10-31 |
| Liliana Torres | Entregar el punto 8 | 2026-09-28 |
| Ricardo Salas | Cerrar la prueba 10 | 2026-11-15 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-10-24 |
| Liliana Torres | Entregar el punto 16 | 2026-11-02 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-11 |
| María Restrepo | Revisar el anexo 19 | 2026-10-16 |
| Camilo Beltrán | Validar el ambiente 20 | 2026-10-30 |
| Carlos Peña | Aprobar el diseño 21 | 2026-10-20 |
| Paula Céspedes | Actualizar la matriz 22 | 2026-11-02 |
| Natalia Ospina | Confirmar la fecha 23 | 2026-11-01 |
| Elena Duarte | Entregar el punto 24 | 2026-10-19 |

## Lo que se dijo

- Elena Duarte dice que ya entregó «enviar el documento 17». No se presentó acta.
