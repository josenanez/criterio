# Acta de constitución · Nómina electrónica

**Código:** PRY-209
**Área dueña:** Banca Hipotecaria
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Transformación Digital
**Producto asociado:** nómina empresarial
**Fecha de aprobación:** 2026-03-19

## Objetivo del negocio

Entregar nómina electrónica para Banca Hipotecaria.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2026-03-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-29 |
| Cierre | 2027-07-08 |

## Criterio de éxito

Nómina electrónica en producción y medido.

## Dependencias declaradas

- Ninguna declarada
