# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **34%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.943.439.519 |
| Ejecutado | 517.161.109 |
| Proyección al cierre | 2.333.283.260 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
