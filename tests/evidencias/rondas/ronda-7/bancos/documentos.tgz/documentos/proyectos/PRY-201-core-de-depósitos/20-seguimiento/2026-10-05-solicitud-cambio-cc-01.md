# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Core de depósitos
**Fecha:** 2026-10-05
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +107 días sobre la línea base vigente |
| Costo | 214.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
