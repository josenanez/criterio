# Comité de Medios de Pago · Débito contactless

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 4 | 2026-11-09 |
| Camilo Beltrán | Entregar el punto 36 | 2026-11-02 |
