# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Tesorería
**Patrocinador:** Andrés Lozano
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2025-07-31

## Objetivo del negocio

Entregar cobranza digital para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2025-07-31.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-10 |
| Cierre | 2026-05-15 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
