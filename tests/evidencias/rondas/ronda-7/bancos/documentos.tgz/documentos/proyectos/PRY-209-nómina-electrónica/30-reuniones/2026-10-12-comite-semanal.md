# Comité de Transformación Digital · Nómina electrónica

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 19 | por definir |
