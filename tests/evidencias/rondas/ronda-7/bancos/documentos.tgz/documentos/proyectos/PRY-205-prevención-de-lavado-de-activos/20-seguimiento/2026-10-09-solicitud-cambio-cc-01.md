# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-09
**Solicitante:** Natalia Ospina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +38 días sobre la línea base vigente |
| Costo | 76.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
