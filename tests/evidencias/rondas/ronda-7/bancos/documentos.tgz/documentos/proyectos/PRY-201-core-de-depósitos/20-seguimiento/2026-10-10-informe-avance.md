# Informe de avance · Core de depósitos

**Código:** PRY-201
**Fecha de corte:** 2026-10-10
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **66%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 341.241.342 |
| Ejecutado | 281.689.586 |
| Proyección al cierre | 993.865.329 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
