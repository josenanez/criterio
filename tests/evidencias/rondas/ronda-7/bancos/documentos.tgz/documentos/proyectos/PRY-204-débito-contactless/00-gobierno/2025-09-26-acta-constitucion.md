# Acta de constitución · Débito contactless

**Código:** PRY-204
**Área dueña:** Riesgo y Cumplimiento
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Medios de Pago
**Producto asociado:** tarjeta débito
**Fecha de aprobación:** 2025-09-26

## Objetivo del negocio

Entregar débito contactless para Riesgo y Cumplimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-09-26.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-06 |
| Cierre | 2026-08-23 |

## Criterio de éxito

Débito contactless en producción y medido.

## Dependencias declaradas

- Ninguna declarada
