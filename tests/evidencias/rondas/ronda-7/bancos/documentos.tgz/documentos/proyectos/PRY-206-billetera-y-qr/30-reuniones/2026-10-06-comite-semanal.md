# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-06
**Asistentes:** Jorge Medina, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 14 | por definir |
