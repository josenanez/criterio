# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de decisión
**Fecha:** 2026-10-14
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +57 días sobre la línea base vigente |
| Costo | 114.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
