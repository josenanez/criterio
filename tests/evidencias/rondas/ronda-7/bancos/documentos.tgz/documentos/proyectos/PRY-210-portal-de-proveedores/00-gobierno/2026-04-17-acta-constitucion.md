# Acta de constitución · Portal de proveedores

**Código:** PRY-210
**Área dueña:** Banca Hipotecaria
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-17

## Objetivo del negocio

Entregar portal de proveedores para Banca Hipotecaria.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Arquitectura el 2026-04-17.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-27 |
| Cierre | 2027-07-05 |

## Criterio de éxito

Portal de proveedores en producción y medido.

## Dependencias declaradas

- Ninguna declarada
