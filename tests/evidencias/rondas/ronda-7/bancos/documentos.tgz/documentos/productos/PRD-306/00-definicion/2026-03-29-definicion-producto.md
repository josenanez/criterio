# Definición de producto · Microseguros

**Código:** PRD-306
**Gerente de producto:** Javier Hoyos
**Segmento:** Personas
**Fecha de la definición:** 2026-03-29

## El problema

El segmento Personas no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-23 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
