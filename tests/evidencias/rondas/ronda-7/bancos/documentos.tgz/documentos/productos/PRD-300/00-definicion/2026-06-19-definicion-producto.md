# Definición de producto · Pagos QR comercios

**Código:** PRD-300
**Gerente de producto:** María Restrepo
**Segmento:** Microcomercio
**Fecha de la definición:** 2026-06-19

## El problema

El segmento Microcomercio no tiene pagos qr comercios.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-08-13 · verificado con el documento técnico del proveedor del 2026-08-24

## Proyectos que lo construyen

- Ninguno declarado
