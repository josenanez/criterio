# Entrevistas · Crédito hipotecario digital

**Ronda:** Ronda · 2025-09-12
**Realizadas por:** Felipe Arango

### Cliente entrevistado · 2025-09-12

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
