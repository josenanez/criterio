# Entrevistas · Pagos QR comercios

**Ronda:** Ronda · 2025-11-27
**Realizadas por:** María Restrepo

### Cliente entrevistado · 2025-11-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
