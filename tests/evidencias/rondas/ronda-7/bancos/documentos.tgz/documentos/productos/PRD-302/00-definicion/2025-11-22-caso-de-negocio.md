# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-11-22
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 130.646 | Caso de negocio, 2025-11-22 |

## Retorno esperado

Retorno esperado en 24 meses.
