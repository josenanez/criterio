# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2026-01-07
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 60.006 | Caso de negocio, 2026-01-07 |

## Retorno esperado

Retorno esperado en 24 meses.
