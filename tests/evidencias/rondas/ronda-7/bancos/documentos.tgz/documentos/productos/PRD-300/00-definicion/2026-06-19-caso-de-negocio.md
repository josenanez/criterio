# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2026-06-19
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 129.569 | Caso de negocio, 2026-06-19 |

## Retorno esperado

Retorno esperado en 24 meses.
