# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2025-12-29
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 193.711 | Caso de negocio, 2025-12-29 |

## Retorno esperado

Retorno esperado en 24 meses.
