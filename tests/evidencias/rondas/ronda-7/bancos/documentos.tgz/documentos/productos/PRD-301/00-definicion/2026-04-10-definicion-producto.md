# Definición de producto · Nómina empresarial

**Código:** PRD-301
**Gerente de producto:** Óscar Ramírez
**Segmento:** PyME
**Fecha de la definición:** 2026-04-10

## El problema

El segmento PyME no tiene nómina empresarial.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-09-21 · verificado con el concepto jurídico de cumplimiento del 2026-10-02

## Proyectos que lo construyen

- Ninguno declarado
