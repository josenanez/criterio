# Comité de producto · Crédito de libre inversión

**Fecha:** 2026-09-29
**Asistentes:** Andrés Lozano

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Liliana Torres | se verifica en producción | — | aceptado | 2026-08-06 | — |
| REQ-4901 | Requerimiento REQ-4901 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-27 | — |
| REQ-4902 | Requerimiento REQ-4902 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-03 | — |
| REQ-4903 | Requerimiento REQ-4903 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-05 | — |
| REQ-4904 | Requerimiento REQ-4904 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-12 | — |
| REQ-4905 | Requerimiento REQ-4905 | Diana Molina | se verifica en producción | — | aceptado | 2026-07-19 | — |
| REQ-4906 | Requerimiento REQ-4906 | Laura Vélez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4907 | Requerimiento REQ-4907 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-06-16 | — |
| REQ-4908 | Requerimiento REQ-4908 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-06-16 | — |
| REQ-4909 | Requerimiento REQ-4909 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-19 | — |
| REQ-4910 | Requerimiento REQ-4910 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-01 | — |
| REQ-4911 | Requerimiento REQ-4911 | Diana Molina | se verifica en producción | — | propuesto | 2026-06-22 | — |

## Decisiones

- Se mantiene el plan
