# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-05-13
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 252.568 | Caso de negocio, 2026-05-13 |

## Retorno esperado

Retorno esperado en 24 meses.
