# Definición de producto · Remesas familiares

**Código:** PRD-307
**Gerente de producto:** Mauricio Pérez
**Segmento:** Personas
**Fecha de la definición:** 2026-05-13

## El problema

El segmento Personas no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-09-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
