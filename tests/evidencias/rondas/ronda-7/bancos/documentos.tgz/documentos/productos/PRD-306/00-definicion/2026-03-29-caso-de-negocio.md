# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-03-29
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 53.789 | Caso de negocio, 2026-03-29 |

## Retorno esperado

Retorno esperado en 24 meses.
