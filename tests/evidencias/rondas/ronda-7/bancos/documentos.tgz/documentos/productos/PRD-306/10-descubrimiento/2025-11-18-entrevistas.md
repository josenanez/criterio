# Entrevistas · Microseguros

**Ronda:** Ronda · 2025-11-18
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2025-11-18

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
