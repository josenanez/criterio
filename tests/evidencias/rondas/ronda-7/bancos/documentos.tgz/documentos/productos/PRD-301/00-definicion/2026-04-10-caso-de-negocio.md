# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2026-04-10
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 193.264 | Caso de negocio, 2026-04-10 |

## Retorno esperado

Retorno esperado en 24 meses.
