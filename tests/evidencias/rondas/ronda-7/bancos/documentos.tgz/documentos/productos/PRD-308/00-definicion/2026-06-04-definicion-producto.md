# Definición de producto · Cuenta de ahorros joven

**Código:** PRD-308
**Gerente de producto:** Laura Vélez
**Segmento:** PyME
**Fecha de la definición:** 2026-06-04

## El problema

El segmento PyME no tiene cuenta de ahorros joven.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda declarada se sostiene sin campaña** · declarado el 2026-09-28 · verificado con la medición del piloto del 2026-10-02

## Proyectos que lo construyen

- Ninguno declarado
