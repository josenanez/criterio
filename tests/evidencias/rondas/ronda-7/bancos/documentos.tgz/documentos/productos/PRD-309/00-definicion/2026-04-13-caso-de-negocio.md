# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2026-04-13
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 60.381 | Caso de negocio, 2026-04-13 |

## Retorno esperado

Retorno esperado en 24 meses.
