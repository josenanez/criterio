# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2026-06-04
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 229.191 | Caso de negocio, 2026-06-04 |

## Retorno esperado

Retorno esperado en 24 meses.
