# Comité de producto · Cuenta PyME

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-28 | — |
| REQ-4301 | Requerimiento REQ-4301 | Sandra Gil | se verifica en producción | — | propuesto | 2026-03-28 | — |
| REQ-4302 | Requerimiento REQ-4302 | Óscar Ramírez | — | — | propuesto | 2026-08-12 | — |
| REQ-4303 | Requerimiento REQ-4303 | Mauricio Pérez | — | — | aceptado | 2026-08-03 | — |
| REQ-4304 | Requerimiento REQ-4304 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-4305 | Requerimiento REQ-4305 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4306 | Requerimiento REQ-4306 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-04-20 | — |
| REQ-4307 | Requerimiento REQ-4307 | Ricardo Salas | se verifica en producción | — | propuesto | 2026-08-28 | — |
| REQ-4308 | Requerimiento REQ-4308 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-04 | — |
| REQ-4309 | Requerimiento REQ-4309 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-05-07 | — |
| REQ-4310 | Requerimiento REQ-4310 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-05 | — |
| REQ-4311 | Requerimiento REQ-4311 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-08-16 | — |
| REQ-4312 | Requerimiento REQ-4312 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-09-01 | — |
| REQ-4313 | Requerimiento REQ-4313 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-22 | — |

## Decisiones

- Se mantiene el plan
