# Entrevistas · Recaudos y cobros

**Ronda:** Ronda · 2026-07-23
**Realizadas por:** Camilo Beltrán

### Cliente entrevistado · 2026-07-23

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
