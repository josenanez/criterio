# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2025-11-21
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 165.900 | Caso de negocio, 2025-11-21 |

## Retorno esperado

Retorno esperado en 24 meses.
