Vista por producto: «APIs de datos». Sale del cálculo `portafolio.py compute` de hoy (2026-10-17) sobre las fichas del estado. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| APIs de datos | 1 (PRY-203) | 0 | 2027-02-27 (PRY-203) | COP 18.000.000.000 | COP 13.830.604.592 |

**«APIs de datos» tiene un solo proyecto, PRY-203 Open Banking.** La vista por producto no aporta nada sobre un producto de un solo proyecto, así que no armo la sección de producto con dependencias internas ni suma de grupo. Lo que sigue es la ficha del proyecto, tal como la calcula el script.

- **Señales:** ninguna abierta. Sin alertas, sin hitos vencidos, sin hitos cumplidos sin evidencia, sin compromisos vencidos, sin fechar ni reprogramados, sin cambios de alcance ni de línea base.
- **Silencio:** 8 días sin movimiento; el umbral es 15.
- **Fecha comprometida del producto:** 2027-02-27, de PRY-203. Desviación contra la línea base original y contra la vigente: 0 días. Sin replanificaciones.
- **Dinero** (las cuatro cifras vienen completas):
  - Aprobado: COP 18.000.000.000
  - Comprometido: COP 13.830.604.592 (76,8 %; el umbral es 90 %)
  - Ejecutado: COP 5.088.404.663 (28,3 %)
  - Proyección: COP 18.145.395.715 (0,8 % sobre lo aprobado; el umbral es 10 %)
  - Disponible real: COP 4.169.395.408
- **Dependencias internas:** ninguna, porque el producto no tiene otro proyecto. Dependencias declaradas del proyecto: ninguna.
- **Lo que el gerente declara:** estado amarillo, 30 % de avance, al 2026-10-09 (8 días de antigüedad). Está amarillo y el script no encuentra señales que lo contradigan ni que lo expliquen.

### Lo que no sé
- **Sustento documental débil:** de los datos de la ficha, 0 salen de evidencia, 3 de declaración y 10 no están marcados. Que no haya alertas no es que la evidencia lo confirme: casi nada de lo que se lee está sustentado por evidencia.
- **Sin cruce de avance contra plan:** el cálculo no entrega el cruce de avance declarado contra lo que sustenta el plan para este proyecto, y no lo estimo. Falta que el plan tenga hitos suficientes (el mínimo es 3 para que el cruce hable).
- **Sin proveedores:** la ficha no trae proveedores, así que no hay nada que contrastar contra lo facturado.
- **Campos que faltan:** `identity.authority` (quién aprueba) e `identity.phase` (fase). El script reporta que ninguno de los 13 proyectos tiene autoridad declarada.

### Proyectos sin producto declarado
Cuatro de los 13 proyectos del portafolio no tienen producto declarado. Ninguno es parte de «APIs de datos», pero nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | no está en el cálculo |
| PRY-205 Prevención de lavado de activos | no está en el cálculo |
| PRY-208 Motor de decisión | no está en el cálculo |
| PRY-210 Portal de proveedores | no está en el cálculo |

El área dueña no sale de `compute`, así que no la escribo. Hay que leerla de la ficha de cada proyecto.

## Pie de rigor
- **De dónde sale:** `portafolio.py compute` del 2026-10-17. Cada cifra está copiada de esa salida. No leí documentos nuevos en esta corrida.
- **Qué no sustenta:** casi todo en PRY-203 es declaración o dato sin marcar (3 y 10 de 13), no evidencia.
- **Qué hay que verificar:** que el estado amarillo del 2026-10-09 siga vigente, y quién es la autoridad del proyecto.
