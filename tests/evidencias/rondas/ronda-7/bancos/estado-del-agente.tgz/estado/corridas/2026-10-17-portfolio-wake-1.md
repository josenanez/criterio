# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 21 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Barrido: 81 documentos sin cambios, 0 proyectos recalculados. 14 citas de PRY-205 no resuelven (probable desajuste entre el código y el nombre de la carpeta; sin verificar). Confirmación no corrida: no había quien respondiera. Sin peticiones.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 81 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que pedirlos de nuevo.

### Lo que cruzó un umbral
Nada cruzó un umbral. Sí hay una **cita que no resuelve**: las 14 citas de la ficha de PRY-205 apuntan a documentos (acta de constitución, cronograma v3, informe de avance) que el índice no encuentra. Los archivos sí existen en la carpeta `PRY-205-prevención-de-lavado-de-activos`; la causa probable es que la ficha cita el proyecto como `PRY-205` y la carpeta lleva el nombre largo. No lo he verificado ni lo he corregido: la ficha no se toca desde aquí. Queda como hallazgo abierto.

### Peticiones atendidas
Ninguna; no había peticiones en el servidor.

### Preguntas
La confirmación periódica (cinco campos) también toca, pero esta sesión no tiene a nadie que responda, así que **no la corrí** y no la marqué como hecha: vuelve a tocar mañana. Nada preguntado, nada sin respuesta.

**Vuelvo el 2026-10-18.** El informe de comité es el 2026-10-24; se genera el 2026-10-22.
