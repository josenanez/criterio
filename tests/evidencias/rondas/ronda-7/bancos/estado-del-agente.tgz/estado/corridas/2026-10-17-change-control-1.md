# Corrida del 2026-10-17 · change-control

13 proyectos · 33 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Solicitud de mover 30 días la salida a producción de PRY-202. Sin dependencias declaradas ni autoridad en el acta; costo, solicitante y motivo no constan. Va a comité por defecto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-202.json` (corte del informe de avance: 2026-10-14; ficha actualizada 2026-10-17). Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

## Solicitud de cambio — PRY-202 Migración a la nube — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días (del 2027-01-01 al 2027-01-31).
**Quién lo pide:** no consta en ningún documento. Se ejecutó como solicitud recibida en esta sesión, sin solicitante identificado.
**Por qué:** el motivo no viene con la solicitud. Lo más cercano es el informe del 2026-10-14, que dice que *«se reprogramó la salida por ventana de cambio del área de operaciones»* y que el equipo perdió dos semanas por la rotación de un desarrollador clave. Ese informe no trae fecha nueva ni fija un motivo formal. Esto es una coincidencia a confirmar con Sandra Gil, no un motivo establecido.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta, sin más detalle) | Sin cambio declarado | 0 declarado |
| Tiempo | Salida a producción y cierre: 2027-01-01 (línea base 1, 2025-11-17) | 2027-01-31 | +30 días |
| Costo | Aprobado 2.400.000.000 COP; comprometido 1.943.439.519; ejecutado 517.161.109; proyección 2.333.283.260 | No declarado | Sin cifra |

- **Alcance:** nadie declara cambio. Si el alcance no se toca y el tiempo se mueve, el costo de esos 30 días lo absorbe el equipo en horas o el proveedor sin cobrar, o aparece después como sobrecosto. Hoy no se sabe cuál de los tres.
- **Costo:** la solicitud no trae cifra y no la invento. El margen entre el aprobado y la proyección es de 66.716.740 COP (2,8 % del aprobado). Treinta días más de equipo y de proveedor pueden consumirlo; nada en los documentos permite decir cuánto cuestan.
- **Tiempo:** se asume que el cierre se mueve con la salida, porque en el acta ambas fechas son la misma (2027-01-01). Si el cierre tiene que quedar en la fecha original, hay que decirlo.
- **Contexto que agrava:** el hito «Piloto con usuarios internos» tenía fecha 2026-10-13 y sigue pendiente, sin evidencia. Faltan 76 días para la fecha actual de salida y el avance declarado es 34 %. El informe declara el estado en verde mientras reporta dos semanas perdidas, un hito vencido y una reprogramación sin fecha. El verde no está sustentado por esos documentos.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno calculado | El acta declara *«Ninguna declarada»* en dependencias y el cálculo (`impact`) no alcanza a ningún proyecto: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 sin confirmar | — |

Esto no demuestra que no haya efecto. Demuestra que no hay dependencias declaradas. El informe menciona una *«dependencia con el core»* (dos historias quedaron fuera del sprint) y una ventana de cambio del área de operaciones, y ninguna está registrada como dependencia con proyecto ni con dueño. Si el core o operaciones tienen proyectos en el portafolio, ese vínculo hay que declararlo y volver a correr el cálculo. Tampoco sé cuántos días se mueve cada proyecto alcanzado: eso necesita holgura por actividad, y la ficha no la tiene.

El hito «Salida a producción» (2027-01-01) es el único por el que pasa el cambio.

### Quién decide
**Autoridad requerida:** no determinable. La ficha no tiene autoridad declarada (`identity.authority`: no encontrado) y el acta no define umbrales de cambio.
**Según:** acta de constitución 2025-11-17. Sólo dice que el presupuesto fue aprobado por el Comité de Arquitectura y no trae cláusula de cambios. El comité de la ficha es el Comité de Arquitectura y el patrocinador es Diana Molina.
**Va a comité:** sí, por defecto. Sin autoridad declarada no hay base para decir que el gerente o el patrocinador pueden aprobar esto solos, y el comité aprobó la línea base. Lo hago por prudencia y no porque un documento lo ordene. **El hallazgo de fondo es que el acta no dice quién puede aprobar cambios de fecha.**

### Si no se aprueba
El proyecto sigue con salida 2027-01-01 y cierre 2027-01-01. Esa fecha ya está en entredicho: el informe dice que la salida se reprogramó sin fecha nueva en el cronograma, hay un hito vencido y dos semanas perdidas. Una línea base que nadie cree es peor que una replanificada a la vista. Hoy el cronograma v1 es la única línea base y no hay ningún cambio registrado (`changes`: vacío).

### Si se aprueba
Línea base 2 — cierre 2027-01-31 · presupuesto: sin cambio solicitado (2.400.000.000 COP) · motivo: pendiente de confirmar (ventana de cambio de operaciones / rotación del desarrollador clave, según el informe del 2026-10-14). Aprobación pendiente de documento y de quien pueda aprobar.
Desviación acumulada contra la línea base original: **+30 días** en tiempo; en costo, **sin cifra** (la proyección de 2.333.283.260 COP queda 2,8 % bajo el aprobado, pero no incluye los 30 días nuevos).

Reconciliación: la línea base no se ha movido (0 días) y no hay cambios aprobados (0 días autorizados), así que no sobran días sin autorización. La reprogramación de la salida que menciona el informe no dejó línea base nueva ni cambio registrado. La línea base 1 se conserva intacta, y la nueva se registra sólo cuando haya documento de aprobación. Se contaría como la primera replanificación.

### Lo que no sé
- Quién pidió el cambio y con qué motivo documentado.
- El costo de los 30 días.
- Quién tiene autoridad para aprobarlo.
- Si hay proyectos que dependan de este (el core, operaciones).
- Si el cierre se mueve con la salida o no.

Siguiente paso: llevarlo al Comité de Arquitectura (próximo comité según la configuración: 2026-10-24) con estas cinco preguntas respondidas, y registrar la línea base 2 sólo cuando exista el documento que la apruebe.

*Pie de rigor: los datos salen de la ficha y de los cuatro documentos de PRY-202 leídos; el estado «verde» y el 34 % son declaración del gerente, no medición. Es un borrador de trabajo: la verificación es suya.*
