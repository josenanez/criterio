# Corrida del 2026-10-17 · project-closure

13 proyectos · 38 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Cierre de PRY-204 no procede: el criterio de éxito (producción y medido) no tiene evidencia, 3 hitos declarados cumplidos sin evidencia, avance 43% vs 100% del plan, proyección +23,5% sobre presupuesto. Lecciones: ninguna sustentable. No se supo: estado de producción, qué son los componentes, dolientes del riesgo del core, contenido de los puntos 4 y 36.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Sale de:** ficha `estado/records/PRY-204.json` (actualizada 2026-10-17), acta de constitución 2025-09-26, cronograma v1 2025-09-26 (vía ficha), informe de avance 2026-10-12, comité semanal 2026-10-12, y la salida de `compute` del 2026-10-17. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-17).

## Cierre — PRY-204 Débito contactless — 2026-10-17

**Conclusión: este proyecto no se puede cerrar contra su criterio de éxito.** Nadie ha declarado que terminó, y la documentación no muestra que haya terminado. Si se cierra hoy, sería por decisión, no por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Débito contactless en producción y medido" (acta de constitución, 2025-09-26, sección Criterio de éxito).
**Se cumplió:** no se puede determinar. Ningún documento menciona puesta en producción ni medición. El último informe (2026-10-12) reporta avance de 43% y estado Verde, es decir, el propio gerente lo declara sin terminar.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 | Sin dato (el acta no lo describe más) | Ninguna |
| Componente 2 | Sin dato | Ninguna |
| Componente 3 | Sin dato | Ninguna |
| Hito: Diseño funcional aprobado (2026-01-21) | Declarado "cumplido" | Sin evidencia de cumplimiento (señal `milestone_met_without_evidence`, 269 días) |
| Hito: Ambiente de pruebas certificado (2026-05-08) | Declarado "cumplido" | Sin evidencia (162 días) |
| Hito: Integración con el core (2026-08-23) | Declarado "cumplido" | Sin evidencia (55 días) |

Los tres hitos figuran como cumplidos y el avance reportado es 43%. Eso no cuadra: el plan sustenta 100% (brecha de 57,0 puntos, `progress_vs_plan`). Los hitos del plan no alcanzan para decir qué falta, y el acta no descompone los "Componentes" en entregables verificables.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| "Lo que otro proyecto cubre" (acta; sin precisar cuál proyecto) | Acta de constitución | 2025-09-26 |

No hay recortes de alcance posteriores registrados, ni solicitudes de cambio (0 cambios). Tampoco se puede descartar que se hayan recortado sin registro: el alcance del acta es tan genérico que no permite contrastar.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-23 | 2026-08-23 | Sin dato: no ha terminado | 0 días de desviación en la línea base; pero la fecha comprometida venció hace 55 días sin cierre |
| Presupuesto (COP) | 1.200.000.000 | 1.200.000.000 | Proyección al cierre 1.481.747.420 (declarada por el gerente) | +23,5 % sobre lo aprobado |

Replanificaciones: 0. Una sola línea base (v1, aprobada 2025-09-26). La desviación de 0 días contra original y vigente no significa "a tiempo": la línea base nunca se movió, y la fecha ya pasó sin entrega. Es un plan vencido, no un plan replanificado.

Presupuesto aprobado contra ejecutado: aprobado 1.200.000.000; comprometido 757.948.023 (63,2 %); ejecutado 468.384.958 (39,0 %); disponible real 442.051.977. Las cifras de dinero son todas declaración del informe del 2026-10-12; ninguna tiene evidencia contable (0 fuentes de evidencia, 3 de declaración).

### RAID al cierre
**Materializados:** no se puede determinar. El registro no tiene incidencias.
**No materializados:** no se puede determinar.
**Abiertos, con doliente:**
- Riesgo "Dependencia del calendario de liberaciones del core" (informe 2026-10-12): abierto, **sin doliente, sin probabilidad, sin impacto, sin fecha**. Sin doliente no está cerrado.
- Compromisos abiertos del comité 2026-10-12: Andrés Lozano, "Entregar el punto 4", para 2026-11-09; Camilo Beltrán, "Entregar el punto 36", para 2026-11-02. Ninguno está descrito de forma que se sepa qué es "el punto 4" ni "el punto 36".
- El acta declara "Ninguna dependencia", pero el informe reporta la dependencia del core.

### Lecciones
Ninguna entra. No hay un solo hecho documentado con fecha y efecto que sustente una lección, y las genéricas no se escriben. Lo único anclado:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El informe del 2026-10-12 declara Verde con 3 de 3 hitos "cumplidos", 43 % de avance y una proyección 23,5 % sobre el presupuesto | 2026-10-12 | El estado declarado no tiene sustento en los documentos (`declared_vs_evidence`) | Exigir evidencia adjunta para marcar un hito como cumplido. Es un hallazgo sobre el control del proyecto, no una lección sobre el proyecto cerrado. |
| La aprobación regulatoria estuvo "pendiente desde el trimestre anterior" según el informe | Hasta 2026-10-12 | Sin dato de fecha de solicitud ni de efecto en hitos | No se puede decir sin los documentos de origen |

### Sin dato
- Si el producto está en producción y medido (el criterio de éxito).
- Qué son los Componentes 1, 2 y 3 y cuál está entregado.
- Evidencia de aceptación de los tres hitos (actas, certificados).
- Fecha real de terminación y gasto final: el proyecto sigue en ejecución según su propio informe.
- Qué proyecto cubre lo declarado fuera de alcance.
- Autoridad de aprobación y fase del proyecto (campos no encontrados en la ficha).
- Datos de identidad con 13 meses de antigüedad (acta de 2025-09-26): superan el umbral de 12 meses.
- Contenido de los puntos 4 y 36 de los compromisos.

### Lo que sigue
Para cerrar este proyecto hace falta, en este orden: (1) que Ricardo Salas aclare si el proyecto terminó o sigue; (2) evidencia de producción y medición; (3) evidencia de los tres hitos; (4) que Sandra Gil (patrocinadora) decida si la fecha vencida y la proyección de sobrecosto requieren cambio formal; (5) un doliente con nombre para el riesgo del core.

**Archivo:** no se mueve la carpeta a `archivo/`. Respuesta sugerida tomada: el proyecto no está cerrado, y archivarlo lo sacaría del barrido diario con señales abiertas.

---
*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de la cita indicada; la verificación es de quien lo usa. Cifras derivadas copiadas de `portafolio.py compute` (2026-10-17). Lo que no está en los documentos, no se supone.*
