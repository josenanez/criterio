# Corrida del 2026-10-17 · status-report

13 proyectos · 31 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Informe de estado de PRY-202: verde declarado (34%) contradicho por 26.0 puntos de atraso frente al plan, un hito vencido y dos hitos cumplidos sin evidencia. Dijo que no sabe: producto, autoridad, fase, última reunión, sustento contable del presupuesto. Términos ya vigentes, sin nueva aceptación.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-202.json`, actualizada el 2026-10-17. Cifras recalculadas con `portafolio.py compute` el 2026-10-17. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 para esta versión 0.3.13).

## PRY-202 · Migración a la nube — estado al 2026-10-17

**Declara el gerente:** verde · 34 % · al 2026-10-14 (Sandra Gil, informe de avance `20-seguimiento/2026-10-14-informe-avance.md`; antigüedad 3 días, vigente)
**Sustento documental:** contradicho. La alerta `declared_vs_evidence` está activa: el verde no cubre la evidencia que se lista abajo.
**Lo que el semáforo no explica:**
- `progress_vs_plan`: el gerente declara 34 %; los hitos cumplidos (3 de 5) sostienen entre 60 y 80 %. Diferencia de 26.0 puntos, en el sentido de atraso.
- `milestone_overdue`: «Piloto con usuarios internos», vencido el 2026-10-13, 4 días.
- `milestone_met_without_evidence`: «Diseño funcional aprobado» (base 2026-02-15, 244 días) e «Integración con el core» (base 2026-07-25, 84 días). Se declaran cumplidos sin documento de recibo.

**Último documento:** 2026-10-14 (3 días de silencio) · **Última reunión:** sin dato. Entre los 4 documentos leídos no hay acta ni minuta de reunión.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-01-01 | 2027-01-01 | 0 días contra original y contra vigente |
| Presupuesto aprobado | COP 2.400.000.000 | COP 2.400.000.000 | sin cambio aprobado |

Presupuesto, según el informe de avance (es declaración del gerente, no sustento contable):
- Comprometido: COP 1.943.439.519 (81.0 % del aprobado).
- Ejecutado: COP 517.161.109 (21.5 %).
- Proyección: COP 2.333.283.260 (-2.8 % frente al aprobado).
- Disponible real: COP 456.560.481.

Replanificaciones: 0 registradas. Sin embargo, el informe de avance dice que la salida a producción fue reprogramada por una ventana de cambio de operaciones, «sin nueva fecha en el cronograma». Es un movimiento declarado que no está en la línea base. Solicitudes de cambio: 0.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-02-15 | 2026-02-15 | declarado cumplido | **ninguna** |
| Ambiente de pruebas certificado | 2026-05-06 | 2026-05-06 | cumplido | acta de recibo fechada 2026-10-10 (`20-seguimiento/2026-10-10-acta-recibo-ambiente-de-pruebas-certificado.md`), posterior a la fecha base |
| Integración con el core | 2026-07-25 | 2026-07-25 | declarado cumplido | **ninguna** |
| Piloto con usuarios internos | 2026-10-13 | 2026-10-13 | pendiente, vencido 4 días | no aplica |
| Salida a producción | 2027-01-01 | 2027-01-01 | pendiente | no aplica |

### Dónde no coincide
- **El gerente dice verde y 34 %** (informe de avance, 2026-10-14). **El cronograma v1** (2025-11-17) ubica 3 de 5 hitos como cumplidos y por eso sostiene entre 60 y 80 %. Una de las dos cifras no es cierta, o los hitos no están cumplidos como se marcan. Los documentos no permiten decidir cuál.
- **El mismo informe de avance** reporta como incidencias la pérdida de dos semanas por rotación de un desarrollador clave, la salida a producción reprogramada y dos historias fuera del sprint por dependencia con el core, y a la vez reporta verde. El semáforo no refleja lo que el propio informe narra.
- Dos de los tres hitos «cumplidos» no tienen documento que lo respalde. El único con acta de recibo («Ambiente de pruebas certificado») la tiene fechada el 2026-10-10, y el hito estaba previsto para el 2026-05-06.

### Abierto
**Riesgos sin responsable ni valoración** (ambos movidos por última vez el 2026-10-14, sin dueño, probabilidad, impacto ni fecha):
- Concentración del conocimiento en una sola persona.
- El proveedor no ha confirmado la fecha de la última entrega.

**Incidencias abiertas desde el 2026-10-14, todas sin dueño:**
- El equipo perdió dos semanas por rotación de un desarrollador clave.
- Salida a producción reprogramada por ventana de cambio de operaciones, sin nueva fecha en el cronograma.
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core.

**Compromisos vencidos:** ninguno, pero tampoco hay compromisos registrados en la ficha (sin actas de reunión que los respalden).
**Dependencias sin confirmar:** ninguna registrada. Sin embargo, la incidencia de las dos historias habla de una dependencia con el core, que no está registrada como dependencia ni se identifica de qué proyecto.

### Sin dato
- Producto (`identity.product`), autoridad de aprobación (`identity.authority`) y fase (`identity.phase`): no encontrados en los documentos. Sin autoridad definida no se puede decir si los riesgos exceden la del gerente.
- Última reunión: no hay actas ni minutas entre los documentos.
- Proveedores: la ficha no registra ninguno, aunque un riesgo menciona «el proveedor».
- Evidencia contable del presupuesto: las cifras de comprometido, ejecutado y proyección son declaración del gerente en el informe de avance; ningún documento independiente las sustenta (0 documentos de evidencia, 3 de declaración, 9 sin marcar).

### Después
La desviación de avance (26.0 puntos) supera el umbral de 10 puntos y hay un hito vencido. Puedo preparar el punto de comité (próximo comité: 2026-10-24) y la solicitud de cambio para la reprogramación de salida a producción, que hoy no está formalizada. Sin autoridad definida en la ficha, no sé a quién escalar.

---
*criterio-portfolio 0.3.13 · ficha PRY-202 aplicada, actualizada el 2026-10-17 · campos inciertos: producto, autoridad, fase, última reunión, evidencia del presupuesto · Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación contra los documentos es suya · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13*
