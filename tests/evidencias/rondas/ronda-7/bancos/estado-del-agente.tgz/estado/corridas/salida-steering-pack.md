**Fichas cargadas:** 13 fichas de `estado/records` (PRY-199 a PRY-211), corte `compute` al 2026-10-17; solicitudes de cambio de PRY-201, 205, 207 y 208; salidas previas de raid-log, change-control y vendor-tracking del mismo día. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17 (criterio-portfolio 0.3.13).

# Comité de proyectos — 2026-10-24 (datos al 2026-10-17)
7 decisiones · 5 escalamientos sin decisión asociada · 11 de 13 proyectos con hallazgos (67 alertas en total)

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Ninguna encontrada. `estado/` no guarda actas de comité ni decisiones registradas. | — | — | Sin dato |
| PRY-208 CC-01 (+57 días, 114.000.000 COP) figura «Autorizada por el comité» | Sin fecha; el documento es del 2026-10-14 | No cita acta ni dice qué comité. La línea base no se actualizó (`approved_without_new_baseline`: CC-01, 57 días). | Abierto — ver decisión 5 |

No puedo decir qué se decidió la semana pasada: ningún documento lo registra. Este es el primer paquete que se construye sin ciclo anterior.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base, y con qué umbral?
**Proyecto:** todos (13 de 13 sin `identity.authority`) · **Quién decide:** PMO y el patrocinador de cada comité; ningún documento dice quién. · **Si no se decide hoy:** los puntos 2 a 5 no tienen a quién dirigirse con certeza. Hoy hay 3 líneas base movidas sin aprobación (PRY-201: 107 días; PRY-205: 80; PRY-207: 58) y 1 aprobada sin acta (PRY-208: 57).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Cada comité de la ficha aprueba los cambios de sus proyectos (hay 5 comités distintos: Medios de Pago, Arquitectura, Transformación Digital, Riesgos, Banca Empresas) | Sin cambio | Lento: cada comité tiene su calendario | Sin cifra |
| B. Un solo comité de portafolio aprueba todo cambio de línea base | Sin cambio | Una sola cola, semanal | Sin cifra |
| C. Umbral: el gerente/patrocinador aprueba hasta un monto o días, y sobre eso va a comité | Sin cambio | Rápido bajo el umbral | Hay que fijar el umbral; los datos no lo dan |

**Recomendación:** B hasta que se fije un umbral (C). Con 5 comités y ninguna autoridad escrita, hoy cualquier aprobación es discutible. Es una recomendación mía, la decisión es del comité.

### [2] PRY-201 Core de depósitos — ¿se aprueba CC-01 (+107 días, 214.000.000 COP, ampliación de alcance)?
**Proyecto:** PRY-201 (gerente Sandra Gil) · **Quién decide:** Comité de Medios de Pago según la ficha; autoridad no declarada (ver 1) · **Si no se decide hoy:** el cronograma v2 (piloto 2026-10-15 → 2027-01-30) sigue en uso con 107 días de línea base movidos sin autorización, y los proyectos que dependen «del core» planifican sobre una fecha que nadie aprobó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar línea base 2 | Ampliación (el documento no dice cuál) | +107 días; fin 2027-01-30 | +214.000.000 COP; la proyección ya es 993.865.329 contra 800.000.000 aprobados (24,2 %) y no consta si incluye los 214 M |
| B. Rechazar | Sin ampliación | Volver a la línea original, que la ficha ya no sostiene (atraso 41,8 % contra la original) | Proyección 24,2 % sobre el aprobado, sin cambio |
| C. Aplazar hasta recibir: qué alcance se amplía, por qué, y qué proyectos dependen | Pendiente | El atraso de hecho sigue corriendo | Pendiente |

**Recomendación:** C con fecha tope en el siguiente comité, y no aprobar A sin la lista de dependientes: la solicitud no dice qué alcance se amplía ni por qué, y 199, 200, 202, 204 y 208 reportan dependencia «del core» sin que ningún documento confirme que sea PRY-201. Eso hay que confirmarlo antes de decidir.

### [3] PRY-205 Prevención de lavado de activos — ¿se aprueban CC-01 (+38 días, 76.000.000 COP) y CC-02 (+42 días, 84.000.000 COP), o se exige replanificar primero?
**Proyecto:** PRY-205 (gerente Natalia Ospina) · **Quién decide:** Comité de Medios de Pago según la ficha; autoridad no declarada · **Si no se decide hoy:** la línea base lleva 80 días movidos sin autorización (40,2 % sobre la original) y el proyecto sigue con fecha final 2026-06-07 ya vencida.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar las dos | Dos ampliaciones (sin descripción) | +38 y +42 días | +76.000.000 y +84.000.000 COP; proyección 819.904.464 contra 800.000.000 aprobados (2,5 %) |
| B. No aprobar; pedir replanificación completa con evidencia de hitos | Pendiente | Hasta la nueva fecha | Pendiente |
| C. Aprobar solo CC-01 | Una ampliación | +38 días | +76.000.000 COP |

**Recomendación:** B. Declara 27 % con los 5 hitos «cumplidos» y ninguno con evidencia (el más viejo, 372 días); ocho compromisos vencidos y tres reprogramados 6, 5 y 3 veces. Con eso no hay base para medir una ampliación. Las dos solicitudes tampoco dicen qué alcance amplían.

### [4] PRY-207 Onboarding PyME — ¿se aprueba CC-01 (+58 días, 116.000.000 COP)?
**Proyecto:** PRY-207 (gerente Jorge Medina, quien también firma la solicitud) · **Quién decide:** Comité de Arquitectura según la ficha; autoridad no declarada · **Si no se decide hoy:** 58 días de línea base movidos sin autorización (11,6 %); el piloto ya figura en 2027-11-17.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliación (sin descripción) | +58 días | +116.000.000 COP; proyección 3.905.904.944 contra 3.300.000.000 aprobados (18,4 %), sin saber si ya incluye los 116 M |
| B. Rechazar | Sin ampliación | Volver a la línea original | Proyección 18,4 % sobre el aprobado |
| C. Aplazar hasta tener informe de avance nuevo (el último es del 2026-09-24, 23 días) | Pendiente | Atraso de hecho sigue | Pendiente |

**Recomendación:** C. El estado «verde» declarado no está sustentado (atraso, sobrecosto y línea base movida sin autorización) y el informe tiene 23 días. Sin motivo documentado no se puede aprobar ni rechazar con criterio.

### [5] PRY-208 Motor de decisión — ¿se ratifica CC-01 (+57 días, 114.000.000 COP) con acta y se registra la línea base 2?
**Proyecto:** PRY-208 (gerente Liliana Torres) · **Quién decide:** Comité de Banca Empresas según la ficha. El documento dice «Autorizada por el comité» sin nombrar cuál ni citar acta. · **Si no se decide hoy:** hay un cambio «aprobado» que no existe como línea base ni como acta; si alguien lo cuestiona, no hay soporte.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta y registrar línea base 2 | Ampliación (sin descripción) | +57 días; fin 2027-08-01 | +114.000.000 COP; proyección 4.370.533.551 contra 4.200.000.000 aprobados (4,1 %) |
| B. Tratarla como no aprobada hasta que aparezca el acta | Sin ampliación vigente | La línea base no se mueve; el atraso de 57 días queda sin cobertura | Sin cambio |

**Recomendación:** A, si el comité que la autorizó confirma por escrito. Si nadie la recuerda, B. El proyecto declara «rojo» con coherencia, así que el riesgo es documental.

### [6] PRY-209 Nómina electrónica — ¿se retiene el pago de la factura FV-1258 por lo no respaldado con acta de recibo?
**Proyecto:** PRY-209 (gerente Gustavo Neira, proveedor Integra Sistemas Ltda., CT-258) · **Quién decide:** no determinable; toca pagos y el contrato no dice quién autoriza. · **Si no se decide hoy:** la «Bolsa de horas de desarrollo» vence el 2026-10-20 y la factura sigue radicada en cuentas por pagar. Se desconoce si ya se pagó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener el excedente y exigir desglose de la factura | Sin cambio | Posible fricción con el proveedor | Retiene 365.708.982 COP de 1.115.928.705 facturados (aceptado: 750.219.723) |
| B. Pagar la factura completa | Sin cambio | Sin fricción | 365.708.982 COP pagados sin acta |
| C. Pagar lo aceptado y devolver el resto con solicitud de desglose | Sin cambio | Igual a A | 750.219.723 COP ahora |

**Recomendación:** A o C; la condición de pago del contrato exige acta firmada por el gerente y solo hay una. Elegir entre A y C depende de si ya se pagó, y eso no consta. El proyecto está en rojo con proyección 20,6 % sobre el aprobado.

### [7] ¿Quién es el doliente único del equipo de seguridad y en qué orden revisa los cuatro hallazgos abiertos (PRY-203, 208, 209, 211)?
**Proyecto:** 203, 208, 209, 211 (y 199, que registra el mismo riesgo) · **Quién decide:** PMO; no hay doliente en ningún ítem. · **Si no se decide hoy:** cuatro proyectos esperan al mismo equipo sin orden. PRY-211 ya tiene acta de recibo de salida a producción del 2026-10-17 con un hallazgo de seguridad y una prueba de carga bajo el umbral abiertos en el informe del 2026-10-16.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Por fecha de salida | Sin cambio | Favorece a quien sale antes; el orden real hay que sacarlo de los cronogramas | Sin cifra |
| B. Primero los proyectos en rojo (208, 209) | Sin cambio | 211 espera aunque ya recibió | Sin cifra |
| C. Primero PRY-211, por tener acta de recibo con el hallazgo abierto | Sin cambio | Los demás esperan | Sin cifra |

**Recomendación:** C primero, y luego A. Que 211 haya aceptado con un hallazgo abierto es lo que más se parece a un riesgo ya materializado. No sé si se aceptó con ambos abiertos: el gerente debe confirmarlo antes del comité. Los documentos no dan costo de la espera.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-204 Débito contactless | Fecha final vencida; declara verde con 43 % contra 3 de 3 hitos «cumplidos» sin evidencia; sobrecosto proyectado 23,5 %. Sin solicitud de cambio. | 2026-08-23 | Replanificación formal o cierre; el gerente (Ricardo Salas) debe explicar el verde |
| PRY-211 Cobranza digital | Fecha final vencida; declara verde con 84 % contra 5 de 5 hitos; 4 hitos «cumplidos» sin evidencia | 2026-05-15 | Replanificación formal o cierre; confirmar la salida a producción |
| PRY-202 Migración a la nube | Salida «reprogramada» sin fecha y sin solicitud de cambio en la ficha; piloto vencido 4 días; declara verde con 34 % contra 60-80 % que sostiene el plan | 2026-10-13 (piloto) | Que el gerente (Sandra Gil) formalice la solicitud; hoy ni solicitante ni motivo constan |
| PRY-205 compromisos | Ocho compromisos vencidos (hasta 30 días) y tres reprogramados 6, 5 y 3 veces | Original: 2026-09-17 | Gerente de PRY-205 decide si los reasigna o los cierra |
| PRY-202, 203, 207, 210 | «Proveedor sin confirmar fecha de la última entrega», sin nombre ni dueño. En PRY-207 lleva 23 días sin informe | 2026-09-24 a 2026-10-16 | Nombre del proveedor y quién lo gestiona |

## Para conocimiento
- PRY-199 Renovación de cajeros: verde, 20 %, sin alertas. Primer entregable de CT-199 vence el 2026-11-16.
- PRY-200 Originación digital: verde declarado, 44 % contra 75-100 % del plan; compromiso vencido 3 días.
- PRY-203 Open Banking: amarillo, 30 %, sin alertas de cálculo.
- PRY-206 Billetera y QR: rojo, 45 %; un compromiso sin fecha.
- PRY-210 Portal de proveedores: verde, 78 % declarado contra 25-50 % del plan (1 de 4 hitos). Declara más avance que el que el plan sostiene.
- PRY-208 y PRY-209 declaran rojo; el detalle está en las decisiones 5 y 6.
- PRY-201, 205 y 207 declaran verde con la línea base movida: ver decisiones 2, 3 y 4.

## Anexo
**Panorama (compute al 2026-10-17):** 13 proyectos, 11 con alertas, 67 alertas, 8 con verde contradicho por la evidencia, 0 sin línea base, 13 sin autoridad declarada.

**Contradicciones abiertas**
- 8 proyectos declaran verde y sus propios documentos no lo sostienen (`declared_vs_evidence` y señales no explicadas en el informe).
- «El core» aparece como dependencia de 199, 200, 201, 202, 204 y 208 y las actas dicen «Ninguna declarada» en los 13: no se puede cruzar con los documentos.
- Hitos «cumplidos» sin evidencia en 201, 202, 204, 205, 208, 209, 211, 200. Ningún proyecto tiene evidencia de hitos marcada como tal (`sources.evidence`: 0 en los 13).

**Vacíos de información**
- Ninguna solicitud de cambio dice qué alcance se amplía ni por qué.
- Ningún riesgo ni incidencia tiene doliente; 19 riesgos sin probabilidad, impacto ni fecha.
- PRY-209 CT-258: sin fecha de fin, renovación ni preaviso; no se sabe si FV-1258 está pagada.
- Fichas con campos vencidos (más de 12 meses) en PRY-204, 205 y 211.
- PRY-200: gerente y patrocinador son la misma persona (Andrés Lozano), según la ficha.
- Proyectos sin producto asociado en la ficha: PRY-202, 205, 208, 210.

**Pie:** criterio-portfolio 0.3.13 · fichas aplicadas: 13 (corte 2026-10-17) · campos inciertos: autoridad de aprobación (13 de 13), motivo y alcance de cada cambio, pago de FV-1258, identidad de «el core» y de los proveedores sin nombre. Las cifras derivadas salen de `portafolio.py compute`; las recomendaciones son mías y la decisión es del comité. Borrador de trabajo: la verificación contra los documentos citados es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
