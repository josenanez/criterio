## Diagnóstico · PRY-205 Prevención de lavado de activos · 2026-10-17

**Leí:** 17 documentos · del 2025-08-22 al 2026-10-17 · formatos: .md (12), .csv (2), .pdf (1), .txt (1), .json (1)
**No pude leer:** nada quedó sin leer. El PDF del informe de avance lo leí en el original y coincide con su texto convertido. Busqué menciones de PRY-205 o «lavado» en las carpetas de los otros once proyectos y no hay ninguna; lo que otras minutas digan de este proyecto no existe en el portafolio.

Una nota de método: `00-gobierno/ficha-pm.json` es la ficha que escribe el gerente del proyecto. La traté como un documento más, es decir como declaración, y no como verificación. No usé ninguna ficha ni informe previo del portafolio como punto de partida.

### Dictamen
**Sostenido:** 5 afirmaciones · **Sin sustento:** 14 · **Contradicho:** 3 (22 afirmaciones dictaminadas; las listo abajo para que se puedan auditar)

Desde esta carpeta no se puede afirmar que el proyecto esté en verde. Sí se puede afirmar que la fecha de cierre comprometida pasó del 2026-03-19 al 2026-06-07 (80 días, 40.2% sobre la duración original) sin ninguna autorización registrada, y que hoy ya pasaron ambas fechas. Los 5 hitos figuran como cerrados y ninguno tiene un documento de recibo. El informe declara 27% de avance mientras el cronograma vigente marca 5 de 5 hitos cerrados. Hay 8 compromisos vencidos y 3 reprogramados repetidamente. De las cifras de presupuesto, solo la aprobada tiene respaldo documental. Lo demás es declaración del gerente.

Las 22 afirmaciones:
- **Sostenidas (5):** presupuesto aprobado de 800.000.000 COP; cierre comprometido original 2026-03-19 (acta y cronograma v1 coinciden); recibos de «Aprobar el diseño 5», «Validar el ambiente 4» y «Enviar el documento 9» (cada uno con su acta de recibo).
- **Contradichas (3):** estado «Verde»; avance «27%»; fecha vigente de cierre 2026-06-07.
- **Sin sustento (14):** los 5 hitos «cerrados»; «se recibió la aprobación regulatoria»; «se ajustó el plan de pruebas»; presupuesto comprometido, ejecutado y proyección; el riesgo de concentración del conocimiento; y las tres frases «ya lo entregué» dichas en comité sin acta (Rubén Cárdenas, Felipe Arango, Elena Duarte).

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Rubén Cárdenas | `00-gobierno/2025-08-22-acta-constitucion.md` |
| Gerente | Natalia Ospina | `00-gobierno/2025-08-22-acta-constitucion.md` |
| Autoridad declarada | **No está declarada.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o plazo | `00-gobierno/2025-08-22-acta-constitucion.md` |
| Comité | Comité de Medios de Pago; aprobó el presupuesto el 2025-08-22 | `00-gobierno/2025-08-22-acta-constitucion.md` |

El acta tiene el alcance sin definir: «Componente 1, 2 y 3» y, como exclusión, «lo que otro proyecto cubre». También dice «Dependencias: ninguna declarada» y «Producto asociado: no aplica». No hay firmas ni aprobador con nombre. Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. Con un alcance sin definir, las dos solicitudes de «ampliación de alcance» no tienen contra qué medirse.

El patrocinador asistió a los comités del 09-05, 09-12, 09-19 y 09-26. No aparece en las listas del 10-03 ni del 10-10, ni en las notas del 10-17. Son tres reuniones seguidas sin el patrocinador, justo cuando se radicaron las dos solicitudes de cambio.

### Contra el plan
- **Línea base original (v1, acta 2025-08-22):** inicio 2025-09-01, cierre 2026-03-19. Es la única línea base registrada; el cálculo ve 1 replanificación.
- **Vigente (cronograma v3, 2026-10-16):** «Salida a producción» pasa de 2026-03-19 a 2026-06-07. Desviación contra la original: **80 días, 40.2%**. Contra la vigente: 0 días.
- **Motivo de la replanificación:** no hay. No existe un v2 en la carpeta y ningún documento explica el cambio.
- **Autorización:** 0 de los 80 días movidos están autorizados. CC-01 (+38 días, 76.000.000 COP) y CC-02 (+42 días, 84.000.000 COP) están ambas «pendientes de presentación al comité» (2026-10-09 y 2026-10-14). Ninguna aparece en la minuta del 2026-10-10. No calculé si 38 y 42 días explican los 80 movidos. Eso es una pregunta para el gerente.
- **Fecha vigente ya vencida:** la nueva fecha de cierre (2026-06-07) es anterior al propio documento que la registra (2026-10-16). Se registra una fecha que ya había pasado cuando se escribió.
- **Integridad de la v1:** el cronograma v1 está fechado 2025-08-22 pero marca todos los hitos como «cerrado», incluso los que en esa fecha eran futuros. Ese archivo se editó después, así que su nombre y su fecha no prueban que sea la línea base original. Que la fecha de cierre coincida con el acta sí es verificable.

### Hitos vencidos sin evidencia
Los 5 hitos están marcados «cerrado» y no hay ningún acta de recibo ni certificado de ninguno. Los «días» son los transcurridos desde la fecha vigente.

| Hito | Fecha vigente | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2025-10-10 | 372 | Acta de recibo del diseño funcional aprobado |
| Ambiente de pruebas certificado | 2025-11-19 | 332 | Certificado o acta de recibo del ambiente de pruebas |
| Integración con el core | 2025-12-29 | 292 | Acta de recibo de la integración |
| Piloto con usuarios internos | 2026-02-07 | 252 | Acta de cierre del piloto |
| Salida a producción | 2026-06-07 | 132 | Acta de salida a producción |

Las únicas actas de recibo de la carpeta (5, 4 y 9) corresponden a compromisos de comité, no a hitos del cronograma.

### Dinero
Cifras en COP, copiadas del cálculo. Todas, salvo la aprobada, vienen solo del informe de avance (declaración); no hay contrato, factura ni extracto.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 519.954.178 (65.0%) | 408.825.517 (51.1%) | 819.904.464 (+2.5% sobre lo aprobado) | 280.045.822 |

- Ninguna desviación de costo cruza el umbral de 10%, y lo comprometido no llega al umbral de 90%.
- El ejecutado (51.1%) casi duplica el avance declarado (27%). Se gastó mucho más de lo que dice haberse avanzado.
- No se puede saber si la proyección incluye los 76.000.000 y los 84.000.000 COP de CC-01 y CC-02, que están pendientes. El informe no lo dice.
- Hay un «ajuste del presupuesto» comprometido por Laura Vélez, sin fecha.

### Lo que se dijo y nadie registró
- **Riesgo sin registrar (notas 2026-10-17):** «el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo». No hay dueño. El único riesgo del informe es la concentración del conocimiento, también sin dueño.
- **Proveedor sin contrato:** las notas hablan de un proveedor y de una «revisión con el proveedor» (Óscar Ramírez, 2026-10-27), pero no hay contrato ni entregables en la carpeta. El acta declara «dependencias: ninguna».
- **Compromisos sin fecha (2):** Felipe Arango, «Confirmar la fecha 15» (desde 2026-09-26); Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana»).
- **Compromisos vencidos sin evidencia (8):**

| Responsable | Compromiso | Vencía | Días |
|---|---|---|---|
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-18 | 29 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 | 30 |
| Liliana Torres | Entregar el punto 8 | 2026-09-28 | 19 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 | 19 |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 | 15 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 | 9 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-11 | 6 |
| María Restrepo | Revisar el anexo 19 | 2026-10-16 | 1 |

- **Reprogramados varias veces (3):** Sandra Gil, «Enviar el documento 1», 6 veces (de 2026-09-17 a 2026-12-08); Carlos Peña, «Cerrar la prueba 2», 5 veces (de 2026-09-20 a 2026-11-17); Ricardo Salas, «Cerrar la prueba 10», 3 veces (de 2026-10-02 a 2026-11-15). La fecha de Sandra Gil se escribió «08/12/2026» en las notas; la leí como 2026-12-08 porque el 2026-08-12 ya pasó.
- **«Ya lo entregué» sin acta (3):** Rubén Cárdenas (anexo 3, 2026-09-12), Felipe Arango (fecha 15, 2026-10-03) y Elena Duarte (documento 17, 2026-10-10). Los tres compromisos salieron de la tabla de comité sin acta de recibo.
- **Calidad de las actas de comité:** las seis minutas listan compromisos pero ninguna registra decisiones. No hay decisión sobre CC-01, CC-02 ni sobre la replanificación.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado «Verde» | Informe de avance 2026-10-16: «Verde» | El mismo proyecto acumula 80 días de corrimiento sin autorización, 8 compromisos vencidos, 0 evidencias de hitos y 2 solicitudes de cambio sin decidir (cronograma v3, minutas, CC-01 y CC-02) |
| Avance 27% | Informe de avance 2026-10-16: «Avance reportado: 27%» | Cronograma v3 2026-10-16: 5 de 5 hitos «cerrado», es decir 100% del plan |
| Fecha vigente de cierre 2026-06-07 | Cronograma v3: «fecha_vigente» 2026-06-07 | CC-01 y CC-02: ambas «pendiente de presentación al comité»; ninguna autoriza el movimiento |

El script también marca el estado «Verde» como no explicado por 6 señales: compromisos vencidos, compromisos reprogramados, hitos cerrados sin evidencia, avance contra plan, replanificación sin autorizar y desviación de tiempo.

### Sin sustento
- **Los 5 hitos «cerrados».** Nada los respalda; ver la tabla de hitos.
- **«Se recibió la aprobación regulatoria pendiente desde el trimestre anterior».** No hay carta, resolución ni acta. Tampoco se dice cuál aprobación ni de quién.
- **«Se ajustó el plan de pruebas con el área de seguridad».** No hay plan de pruebas ni acta en la carpeta.
- **Presupuesto comprometido, ejecutado y proyección.** Sin contrato, factura ni extracto que los respalden.
- **«Concentración del conocimiento en una sola persona».** Sin dueño, sin plan y sin que se diga quién es esa persona.
- **Los tres «ya lo entregué» de comité.** Ver arriba.

Aquí, sin sustento no significa falso. Significa que nada de lo que hay en la carpeta lo respalda ni lo contradice.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en producción.** Sin acta de salida a producción no se sabe si el hito del 2026-06-07 ocurrió, y el informe de 27% sugiere que no. Consecuencia: no se puede decir si hay 132 días de atraso real o un cronograma marcado «cerrado» por error.
- **Qué autoridad tiene la gerente.** Sin autoridad declarada, ninguna de las fechas movidas se puede dar por aprobada ni por rechazada.
- **Cuál es el alcance.** El acta lo deja en «Componente 1, 2 y 3»; las dos ampliaciones no se pueden medir contra eso. Consecuencia: los cambios pendientes (76.000.000 y 84.000.000 COP) se podrían estar pidiendo sobre un alcance que nunca se definió.
- **Qué línea base original se aprobó.** Solo existe el v1, editado después de su fecha, y no existe un v2.
- **Si la proyección de costo incluye los cambios pendientes.** Consecuencia: el disponible real (280.045.822 COP) puede estar sobrestimado.
- **Qué pasa con el proveedor.** Sin contrato ni entregables no se puede cruzar lo recibido con lo facturado ni medir el riesgo del equipo incompleto.
- **Qué dice el comité.** Las minutas no registran decisiones. Y las minutas de otros proyectos no mencionan este.

---
**Pie de rigor.** 17 documentos leídos, todos de la carpeta del proyecto. Cada dato viene del documento citado. Las cifras derivadas (80 días, 40.2%, 132 días, 51.1%, 65.0%, +2.5%, 280.045.822, días de vencimiento y reprogramaciones) se copian del cálculo del portafolio y no se recalcularon a mano. Los conteos del dictamen (5, 14, 3) son míos y están listados para que se puedan revisar. La fuente de las cifras de dinero es solo declaración del gerente; el portafolio registra 0 evidencias y 6 declaraciones. La lectura de «08/12/2026» como 2026-12-08 es una interpretación. Este diagnóstico no recomienda detener, continuar ni reestructurar el proyecto; esa decisión es de quien tiene la facultad.
