## Historia · PRY-205 Prevención de lavado de activos · 2025-08-22 a 2026-10-17

**Leí:** 16 documentos entre 2025-08-22 y 2026-10-17 (14 meses). No abrí `00-gobierno/ficha-pm.json`: es una ficha derivada que publicó la gerencia, no un documento fuente.
**Trimestres sin un solo documento:** 2025-T4, 2026-T1 y 2026-T2. Tres trimestres seguidos, y en ellos caen cuatro de los cinco hitos y las dos fechas de cierre (la original y la movida).
**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hizo falta una aceptación nueva.

### En una línea
El acta de 2025-08-22 pactó cierre el 2026-03-19. Después no hay ningún documento hasta el comité del 2026-09-05, y la carpeta ya trae el cierre movido al 2026-06-07 (+80 días, 40.2 % sobre el plan original), sin acta que lo apruebe. Las dos solicitudes de cambio que suman esos 80 días (CC-01 del 2026-10-09 y CC-02 del 2026-10-14) siguen "pendientes de presentación al comité", así que la fecha se movió antes de que nadie la autorizara. El informe del 2026-10-16 declara verde con 27 % de avance, mientras el cronograma v3 muestra los cinco hitos cerrados (100 %) y ninguno tiene acta de recibo.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 80 días (40.2 %) | No se puede calcular: solo hay una declaración (2026-10-16) | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-08-22 | Acta de constitución | Pacta alcance genérico (Componentes 1 a 3), 800.000.000 COP, inicio 2025-09-01, cierre 2026-03-19. Patrocinador Rubén Cárdenas, gerente Natalia Ospina. Sin autoridad ni dependencias declaradas. |
| 2025-08-22 | Cronograma v1 | Cinco hitos, el último (salida a producción) el 2026-03-19. El archivo ya trae los cinco en estado "cerrado" aunque está fechado antes de que ocurriera alguno. |
| 2025-09 a 2026-08 | (ninguno) | Sin documentos. Aquí vencen los hitos del 2025-10-10, 2025-11-19, 2025-12-29 y 2026-02-07, y el cierre original del 2026-03-19. |
| 2026-09-05 | Comité semanal | Primer rastro del seguimiento: 4 compromisos abiertos, 4 asistentes. |
| 2026-09-12 | Comité semanal | 7 compromisos. Rubén Cárdenas dice que ya entregó "revisar el anexo 3"; no se presentó acta. |
| 2026-09-19 | Comité semanal | 11 compromisos, 11 asistentes. |
| 2026-09-26 | Comité semanal + acta de recibo 5 | Se cierra "Aprobar el diseño 5" con acta. Primer compromiso cerrado con evidencia. |
| 2026-10-03 | Comité semanal + actas de recibo 4 y 9 | Se cierran "Validar el ambiente 4" y "Enviar el documento 9" con acta. Felipe Arango dice que ya entregó "confirmar la fecha 15"; sin acta. |
| 2026-10-09 | CC-01 | Ampliación de alcance: +38 días, +76.000.000 COP. Pendiente de presentación al comité. |
| 2026-10-10 | Comité semanal | 18 compromisos. Elena Duarte dice que ya entregó "enviar el documento 17"; sin acta. |
| 2026-10-14 | CC-02 | Ampliación de alcance: +42 días, +84.000.000 COP. Pendiente de presentación al comité. |
| 2026-10-16 | Informe de avance | Verde, 27 %. Presupuesto: aprobado 800.000.000, comprometido 519.954.178, ejecutado 408.825.517, proyección 819.904.464 COP. Riesgo declarado: concentración del conocimiento en una persona. |
| 2026-10-16 | Cronograma v3 | La salida a producción pasa de 2026-03-19 a 2026-06-07 (la línea base conserva 2026-03-19). Los cinco hitos "cerrados". |
| 2026-10-17 | Notas de reunión (.txt, en la raíz de la carpeta) | Sandra Gil reprograma por sexta vez; Laura Vélez promete el ajuste del presupuesto sin fecha; se comenta un riesgo del proveedor que nadie anotó. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | Consta en el cronograma v3 del 2026-10-16; la fecha en que se decidió no consta | 2026-06-07 (+80 días contra la original) | Ninguno documentado | Ninguno. CC-01 y CC-02 suman +38 y +42 días, pero ambas están pendientes. |

- La nueva fecha de cierre (2026-06-07) ya había vencido 132 días antes del 2026-10-16, y el hito "Salida a producción" aparece cerrado sin acta.
- El archivo se llama "v3" y no hay v2 en la carpeta. No sé si existió una replanificación intermedia.
- No sé si las CC pretenden regularizar un movimiento ya hecho o sumar plazo sobre uno ya hecho: dicen "sobre la línea base vigente" y la vigente ya era 2026-06-07.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| (ninguno documentado) | Patrocinador y gerente son los mismos en el acta y en todos los documentos posteriores. | Acta 2025-08-22 y siguientes |

Lo que sí consta, sin ser un cambio formal: Rubén Cárdenas, el patrocinador, figura como asistente hasta el 2026-09-26 y no aparece en las listas del 2026-10-03, 2026-10-10 ni 2026-10-17. Los asistentes pasan de 4 (2026-09-05) a 12 (2026-10-10) y 14 (2026-10-17). La autoridad del gerente no está declarada en el acta.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Sandra Gil | Enviar el documento 1 | 6 | Original 2026-09-17; luego 2026-10-05, 2026-10-16, 2026-10-26, 2026-11-06, 2026-11-24 y 2026-12-08 (esta última escrita "08/12/2026" en las notas del 10-17) |
| Carlos Peña | Cerrar la prueba 2 | 5 | Original 2026-09-20; luego 2026-09-30, 2026-10-09, 2026-10-28, 2026-11-08 y 2026-11-17 |
| Ricardo Salas | Cerrar la prueba 10 | 3 | Original 2026-10-02; luego 2026-10-11, 2026-10-31 y 2026-11-15 |

Otros cinco compromisos llevan vencidos sin que su fecha se haya movido: Paula Céspedes, "Actualizar la matriz 6" (2026-09-17, aparece igual en todos los comités desde el 09-12); Liliana Torres, "Entregar el punto 8" (2026-09-28); Andrés Lozano, "Revisar el anexo 11" (2026-09-28); Jorge Medina, "Validar el ambiente 12" (2026-10-02); Carlos Peña, "Aprobar el diseño 13" (2026-10-08). En total el script cuenta 8 vencidos sin evidencia y 2 sin fecha (Felipe Arango, "Confirmar la fecha 15"; Laura Vélez, ajuste del presupuesto).

### Desde cuándo lo declarado no se sostiene
No se puede fechar. La serie de estados declarados tiene un solo punto: el informe del 2026-10-16 (verde, 27 %). No hay informes anteriores en la carpeta, así que no se puede decir si fue un salto o un deslizamiento.

Lo que sí se puede decir:
- El primer hito sin evidencia es "Diseño funcional aprobado", con fecha del 2025-10-10 (372 días). Los cinco hitos están en la misma condición: cerrados en el cronograma, sin acta de recibo. En toda la carpeta solo hay 3 actas de recibo, todas de compromisos de comité y de septiembre-octubre de 2026.
- Lo que se siguió reportando: verde, y "se recibió la aprobación regulatoria pendiente desde el trimestre anterior", sin documento que la respalde.
- El informe y el plan no coinciden entre sí: el plan respalda 100 % de avance y el informe declara 27 % (73 puntos de diferencia). La ejecución presupuestal es 51.1 % y el comprometido 65.0 %. La proyección queda 2.5 % sobre el aprobado.
- Seis señales siguen sin explicar en el informe: compromisos vencidos, compromisos reprogramados, hitos cerrados sin evidencia, avance contra plan, línea base movida sin autorización y atraso contra el original.

### Lecciones ancladas a un hecho
1. **La fecha se movió antes de la autorización.** Hecho: cronograma v3 del 2026-10-16 con cierre 2026-06-07; CC-01 (2026-10-09) y CC-02 (2026-10-14) "pendientes de presentación al comité". Efecto: 80 días de corrimiento con 0 autorizados.
2. **Una fecha que se repite cada semana deja de ser una fecha.** Hecho: Sandra Gil prometió seis veces "Enviar el documento 1", una vez por comité, del 2026-09-05 al 2026-10-17. Efecto: el compromiso original del 2026-09-17 llega a 2026-12-08 sin entregarse.
3. **"Ya entregué" sin acta no cierra nada.** Hecho: tres veces, el 2026-09-12, 2026-10-03 y 2026-10-10, alguien dijo haber entregado y las minutas anotan "no se presentó acta". Efecto: el script mantiene "Revisar el anexo 3" como vencido, y no hay forma de saber si se cumplió.
4. **Un riesgo dicho en voz alta no es un riesgo registrado.** Hecho: las notas del 2026-10-17 recogen que el proveedor podría no llegar con el equipo completo, y nadie lo anotó; el informe del 2026-10-16 solo declara el riesgo del conocimiento concentrado. Efecto: el riesgo con proveedor no existe en ningún registro, y la carpeta no tiene contrato ni proveedor registrado.

### Lo que no sé
- Qué pasó entre 2025-09 y 2026-08: no hay un solo documento.
- Cuándo y quién decidió mover el cierre a 2026-06-07, y por qué.
- Si el proyecto está en producción. El hito está "cerrado", pero no hay acta.
- Si la proyección de 819.904.464 COP incluye CC-01 y CC-02 (160.000.000 COP entre las dos).
- Si existió un cronograma v2.
- Cuál es la autoridad de la gerente, y por qué el acta pone "No aplica" como producto asociado.

---
**Pie de rigor.** Las cifras derivadas (1 replanificación, 80 días, 40.2 %, 2.5 %, 51.1 %, 65.0 %, 8 vencidos, 2 sin fecha) salen de `portafolio.py compute`, a fecha 2026-10-17. Las fechas y los textos salen de los 16 documentos citados. No atribuyo intención: que el corrimiento quedara sin autorizar no dice que alguien lo ocultara. Esa conversación con la gerente y el patrocinador se tiene con estos datos, y la tiene una persona. Verifica cada cita contra su documento antes de llevarla a un comité.

Puedo llevar esta historia al comité del 2026-10-24 como decisión (autorizar o rechazar CC-01 y CC-02 y regularizar la fecha), o al cierre del proyecto.
