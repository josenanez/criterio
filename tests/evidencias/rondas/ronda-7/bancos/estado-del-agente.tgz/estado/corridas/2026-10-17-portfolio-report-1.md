# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 81 documentos, 0 releídos y 81 sin cambio · 41 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

El informe quedó en `/home/claude/banco/ronda-7/bancos/espacio/reportes/index.html`.

8 proyectos declaran verde sin sustento; mirar PRY-205, PRY-201 y PRY-209 (factura sobre lo aceptado)

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17
13 proyectos · 11 con hallazgos (67 señales) · último barrido 2026-10-17

**Fichas cargadas:** 13 fichas de `estado/records/`, instantánea del 2026-10-17. La más vieja tiene 8 días sin documento nuevo (PRY-203); ninguna cruza el umbral de silencio de 15 días. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-17.

**Formato:** html. Informe en `reportes/` (26 páginas). Vista por campo, con la cadena de evidencia, para quien va a actuar: `reportes/index.html`. Vista por decisión, para el patrocinador: `reportes/decisiones.html`. Una página por proyecto (`PRY-199.html` … `PRY-211.html`) y una por producto. El PDF sale de imprimir el HTML.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea previa es la de hoy (2026-10-17), así que esto es el punto de partida y no hay delta que reportar.

## Contradicciones abiertas
Ocho proyectos declaran verde y la evidencia no lo sostiene: PRY-200, 201, 202, 204, 205, 207, 210 y 211. Cada uno tiene su detalle en su página. El cálculo no devolvió campos en conflicto entre dos fuentes (`record_issues` = 0), así que no hay otra contradicción que listar.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-202 Migración a la nube | Piloto con usuarios internos | 2026-10-13 | 4 | Informe de avance 2026-10-14 (declara verde) |

## Proyectos en silencio
Vacía. El mayor silencio es PRY-203 con 8 días, por debajo del umbral de 15.

## Dependencias en riesgo
Vacía. El cálculo no emitió ninguna señal de dependencia rota.

## Sin sustento
Hitos declarados cumplidos sin documento que lo respalde:

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | Ambiente de pruebas certificado (jul-2026) | Nada |
| PRY-201 | 3 hitos cumplidos (abr, jun y ago 2026) | Nada |
| PRY-202 | 2 hitos cumplidos (feb y jul 2026) | Nada |
| PRY-204 | 3 hitos cumplidos (ene, may y ago 2026) | Nada |
| PRY-205 | Los 5 hitos cumplidos (oct-2025 a jun-2026) | Nada |
| PRY-208 | Diseño funcional aprobado (jun-2026) | Nada |
| PRY-209 | Diseño funcional aprobado (jun-2026) | Nada |
| PRY-211 | 4 hitos cumplidos (oct-2025 a mar-2026) | Nada |

Avance declarado frente a lo que sostiene el plan:
- PRY-205: declara 27 % con todos los hitos cumplidos (73 puntos de diferencia).
- PRY-204: declara 43 % con todos los hitos cumplidos (57 puntos).
- PRY-200: declara 44 % y el plan sostiene 75–100 % (31 puntos).
- PRY-202: declara 34 % y el plan sostiene 60–80 % (26 puntos).
- PRY-211: declara 84 % y el plan sostiene 100 % (16 puntos).
- PRY-209: declara 29 % y el plan sostiene 40–60 % (11 puntos).
- PRY-210 va en sentido contrario. Declara 78 % con 1 de 4 hitos cumplidos, y el plan sostiene 25–50 %.

Proveedor: en PRY-209, Integra Sistemas Ltda. facturó COP 1.115.928.705 y lo aceptado suma COP 750.219.723, una diferencia de COP 365.708.982.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Ninguno tiene autoridad aprobadora registrada. |
| PRY-202, 205, 208, 210 | No tienen producto asociado. |
| PRY-205, 206, 208, 209 | Compromisos sin fecha (6 en total). |

Compromisos vencidos: 8 en PRY-205 (el más viejo, 30 días), 1 en PRY-200 y 1 en PRY-207. En PRY-205 tres compromisos se han reprogramado entre 3 y 6 veces: Sandra Gil (6), Carlos Peña (5) y Ricardo Salas (3).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | — | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-200 Originación digital | Verde | No lo sostiene | 0 d | 0 d | 0 |
| PRY-201 Core de depósitos | Verde | No lo sostiene | +107 d (41,8 %); costo +24,2 % | 0 d | 1, sin autorización |
| PRY-202 Migración a la nube | Verde | No lo sostiene | 0 d | 0 d | 0 |
| PRY-203 Open Banking | — | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-204 Débito contactless | Verde | No lo sostiene | 0 d; costo +23,5 % | 0 d | 0 |
| PRY-205 Prevención de lavado de activos | Verde | No lo sostiene | +80 d (40,2 %) | 0 d | 1, sin autorización |
| PRY-206 Billetera y QR | — | 1 compromiso sin fecha | 0 d | 0 d | 0 |
| PRY-207 Onboarding PyME | Verde | No lo sostiene | +58 d (11,6 %); costo +18,4 % | 0 d | 1, sin autorización |
| PRY-208 Motor de decisión | — | Cambio CC-01 sin línea base | +57 d (11,7 %) | 0 d | 1 |
| PRY-209 Nómina electrónica | — | Facturado por encima de lo aceptado | 0 d; costo +20,6 % | 0 d | 0 |
| PRY-210 Portal de proveedores | Verde | No lo sostiene (avance declarado por encima del plan) | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | Verde | No lo sostiene | 0 d | 0 d | 0 |

Las celdas con "—" en Declarado significan que el cálculo no contrastó un semáforo verde contra la evidencia en ese proyecto; no afirmo qué declara.

## Necesito que confirmes
Ninguna pregunta en esta corrida. La confirmación mensual (5 campos) no la selecciona ningún comando de este flujo y no voy a inventar cuáles son los más viejos. Queda pendiente para la próxima corrida.

---
Criterio-portfolio 0.3.13 · fichas aplicadas: 13, con fecha 2026-10-17 · campos inciertos: ninguno marcado como ambiguo; la autoridad aprobadora está sin registrar en los 13 proyectos · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
Criterio produce borradores de trabajo, no decisiones ni asesoría. La verificación de cada dato, con la cita al documento, es suya.
