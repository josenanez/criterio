**Sale de:** `00-gobierno/2026-03-23-contrato-ct-258.docx`, `20-seguimiento/2026-07-21-acta-recibo-ct-258-licenciamiento-del-motor.md`, `20-seguimiento/2026-10-01-factura-ct-258.pdf`, `20-seguimiento/2026-10-15-informe-avance.pdf`, `30-reuniones/2026-10-12-comite-semanal.md` (todos de PRY-209), la ficha `estado/records/PRY-209.json` y la salida de `portafolio.py compute` al 2026-10-17.

## Proveedores — PRY-209 Nómina electrónica al 2026-10-17

### Integra Sistemas Ltda. — contrato CT-258
**Vigencia:** firma 2026-03-23; fecha de fin no declarada en el contrato · **Preaviso de no renovación:** no declarado · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-07-09 · 750.219.723 COP | accepted | Acta de recibo 2026-07-21, firmada por Gustavo Neira (gerente), 12 días después de la fecha comprometida | Sin desglose |
| Bolsa de horas de desarrollo | 2026-10-20 · 750.219.723 COP | pending | Ninguna | Sin desglose |
| Parametrización del tarifario | 2027-01-30 · 750.219.723 COP | pending | Ninguna | Sin desglose |
| Mesa de ayuda del primer trimestre | 2027-05-13 · 750.219.723 COP | pending | Ninguna | Sin desglose |

Cifras del script: 4 entregables, 1 aceptado, 0 atrasados, 0 aceptados sin evidencia, monto aceptado 750.219.723 COP, facturado 1.115.928.705 COP, montos declarados 4 de 4.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado contra aceptado (`vendor_invoiced_over_accepted`) | Cada entregable se factura contra acta de recibo firmada por el gerente | Factura FV-1258 por 1.115.928.705 COP; solo hay un acta de recibo del proveedor, por 750.219.723 COP. Diferencia: **365.708.982 COP** facturados sin acta | Contrato CT-258 (condición de pago); factura FV-1258 (2026-10-01); acta de recibo 2026-07-21 |
| Concepto de la factura | Los entregables se facturan por separado | La factura dice "Entregables del contrato CT-258", sin decir cuáles. Los 1.115.928.705 COP no equivalen a ningún múltiplo de 750.219.723 | Factura FV-1258; contrato CT-258 |
| Estados dentro del contrato | Firmado el 2026-03-23 y ya marca "recibido" en el licenciamiento (recibo del 2026-07-21) y "en curso" en dos entregables | Un contrato firmado en marzo no puede traer un recibo de julio: la tabla se actualizó después de la firma y no hay versión fechada | Contrato CT-258; acta de recibo 2026-07-21 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Ninguno marcado como entregado sin acta. El script no encontró entregables aceptados sin evidencia. | — | — |

El hallazgo de fondo es otro: hay una factura radicada en cuentas por pagar por encima de lo aceptado, y ningún documento dice qué entregable cubre el excedente.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Ninguno del proveedor vencido. Próximo vencimiento: Bolsa de horas de desarrollo, el 2026-10-20 (3 días), sin evidencia aún. | Contrato CT-258 | 2026-10-20 | — |

El comité del 2026-10-12 registra un compromiso de Javier Hoyos ("Entregar el punto 19", para "por definir"). Nada dice que Hoyos sea del proveedor. Queda sin fecha (`commitment_undated`), sin atraso calculable.

### Sin dato
- **Vigencia, terminación, renovación automática y preaviso de CT-258:** el contrato no los trae. No se puede decir si hay un preaviso por vencer; falta el texto completo o las condiciones generales.
- **Desglose de la factura FV-1258:** qué entregables cubre.
- **Si la factura está pagada:** solo dice "radicada en cuentas por pagar".
- **Acta de recibo del ambiente de pruebas certificado (2026-10-16):** es un hito del proyecto, no un entregable de CT-258; no entra en el cruce.
- **Hito "Diseño funcional aprobado" (2026-06-30) marcado como cumplido sin evidencia** (109 días): señal del proyecto, no del proveedor.

## Después
Hay 365.708.982 COP facturados sin acta de recibo que los sustente. Sugiero llevarlo al comité del 2026-10-24: pedir a Integra el desglose de FV-1258 y retener el pago del excedente hasta que haya acta firmada por el gerente.

---
*Rigor: las cifras salen de `portafolio.py compute`. La lectura de los documentos es mía y puede equivocarse; verifique contra las citas. No vi nada fuera de la carpeta: reuniones, correos o pagos que no estén en ella no se reflejan aquí.*
