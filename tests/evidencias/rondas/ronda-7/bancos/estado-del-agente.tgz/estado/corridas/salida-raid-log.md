Sale de: fichas en `estado/records` (PRY-199 a PRY-211), informes de avance, actas de constitución (sección «Dependencias declaradas»), cronogramas, solicitudes de cambio, contratos/factura de PRY-199 y PRY-209, las 15 minutas de comité y las notas de reunión de PRY-205 del 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## RAID — portafolio (13 proyectos) al 2026-10-17
Tras reclasificar: 13 riesgos (12 registrados + 1 no registrado formalmente) · 0 supuestos · 17 incidencias · 7 dependencias
36 ítems registrados + 1 no registrado: 37 sin doliente · 19 riesgos sin fecha, probabilidad ni impacto · 3 sin movimiento (PRY-207) · 1 no registrado formalmente

Escala de probabilidad e impacto: la organización no define una; se usaría alta/media/baja, pero ningún riesgo la trae valorada, así que no se valoró ninguno.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-201 · piloto | Incidencia | El piloto con usuarios internos pasó de 2026-10-15 a 2027-01-30 (cronograma v2, 2026-10-10). CC-01 pide +107 días y 214 M COP y sigue «pendiente de presentación al comité». | Sin doliente (gerente: Sandra Gil) | 2026-10-10 | Afecta a otros proyectos: 199, 200 y 202 reportan historias fuera de sprint «por dependencia con el core», y 201, 204 y 208 registran riesgo por el «calendario de liberaciones del core». Ningún documento dice que «el core» sea PRY-201; hay que confirmarlo. |
| Hallazgos de seguridad abiertos: PRY-203, 208, 209, 211 | Incidencia | Hallazgo de seguridad levantado en la revisión de arquitectura, sin doliente en ninguno. | Sin doliente | 2026-10-08 a 2026-10-16 | Cuatro proyectos esperan al mismo equipo de seguridad. En 199, 203, 209 y 211 el riesgo registrado es la «disponibilidad del equipo de seguridad para la revisión final». Un mismo cuello de botella afecta a varios proyectos. |
| PRY-209 · CT-258 Integra Sistemas | Dependencia | «Bolsa de horas de desarrollo» vence el 2026-10-20 y está «en curso». La factura FV-1258 (2026-10-01) por 1.115.928.705 COP supera en 365.708.982 COP el único entregable recibido (licenciamiento, 750.219.723 COP). | Sin doliente | 2026-10-01 | Excede la autoridad del gerente y toca pagos. El proyecto está en Rojo, con «salida a producción reprogramada» sin nueva fecha. |
| PRY-211 · salida a producción | Incidencia | El acta de recibo de salida a producción es del 2026-10-17. El informe del 2026-10-16 sigue con un hallazgo de seguridad y una prueba de carga bajo el umbral, ambos abiertos, y el riesgo de disponibilidad del equipo de seguridad. | Sin doliente | 2026-10-16 | Una mitigación o resolución queda sin evidencia posterior al recibo. Hay que confirmar si se aceptó con ambos abiertos. |
| PRY-208 / PRY-209 / PRY-210 / PRY-202 · salida reprogramada | Incidencia | «Salida a producción reprogramada por ventana de cambio de operaciones (sin nueva fecha en el cronograma)». Los cronogramas de 208, 209 y 210 no traen el hito, y el de 202 sigue en 2027-01-01. | Sin doliente | 2026-10-08 a 2026-10-15 | Una reprogramación sin fecha es una incidencia sin salida. 208 y 209 están en Rojo. |
| PRY-205 · proveedor | Riesgo (no registrado) | Ver la tabla siguiente. | Sin doliente | 2026-10-17 | Falta doliente y no está en el registro formal. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». No dice qué proveedor ni qué fase. | Riesgo | `PRY-205/2026-10-17-notas-reunion.txt`, línea 7 | 2026-10-17 |

Las otras 15 minutas de comité (una por cada proyecto 199, 200, 201, 204, 206, 207, 208, 209 y 211, y las seis de PRY-205 anteriores a las notas) traen solo compromisos, y en PRY-205 afirmaciones de «ya entregué» sin acta. No mencionan riesgos, supuestos ni dependencias. No inventé ninguno. PRY-202, 203 y 210 no tienen minutas en la carpeta.
La ficha del PM de PRY-205 ya recoge este riesgo (owner «no_identificado»). Falta que el gerente decida si lo formaliza.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 36 ítems registrados | Todos | Ver el registro completo | Doliente en todos. |
| 19 riesgos registrados | Riesgo | Ver el registro completo | Fecha, probabilidad e impacto en todos. |
| 17 incidencias | Incidencia | Ver el registro completo | Fecha de resolución en todas (el registro solo trae «desde»). |
| 0 supuestos | Supuesto | — | Ningún proyecto levantó supuestos. No los inferí. Los habituales (disponibilidad de personas clave, terceros a tiempo, ambientes y licencias, aprobaciones) aparecen como riesgos o incidencias en los informes, por ejemplo la rotación del desarrollador clave en 202, 203 y 206. |

Todo esto se reporta como hallazgo y no lo rellené.

### Dependencias en riesgo
Reclasificaciones: 7 riesgos registrados pasan a dependencia, por la prueba rápida (dependen de alguien fuera del proyecto).

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-202, 203, 207, 210 · «el proveedor no ha confirmado la fecha de la última entrega» | Proveedor sin nombre en el informe. Sin código de proyecto. | No: el propio texto dice que no confirmó. | Declarada y no acordada. En PRY-207 lleva 23 días sin movimiento (último informe 2026-09-24) y el proyecto reprogramó su piloto de 2027-09-20 a 2027-11-17. |
| PRY-201, 204, 208 · «calendario de liberaciones del core» | «El core», sin código. Si es PRY-201, ya movió su piloto +107 días (2026-10-10). | No hay confirmación de la contraparte. | Cruce **no confirmable con los documentos**: ninguna acta declara dependencias («Ninguna declarada» en los 13 proyectos). |
| PRY-199, 200, 202 · «dos historias fuera del sprint por dependencia con el core» | Igual: «el core». | No. | Sale como incidencia, pero no hay dependencia registrada. Propongo registrarla con el código del proyecto una vez se confirme cuál es. |
| PRY-209 · CT-258 Integra Sistemas Ltda. | Proveedor contractual | Contrato firmado, pero 3 de 4 entregables sin recibo. | Bolsa de horas vence el 2026-10-20. |
| PRY-199 · CT-199 Consultora Andina S.A.S. | Proveedor contractual | Contrato firmado, ningún entregable recibido. | Primer entregable (licenciamiento) vence el 2026-11-16. No está en riesgo hoy; se deja registrada porque no figura como dependencia. |

Reclasificaciones para confirmar: los 4 riesgos «disponibilidad del equipo de seguridad» (199, 203, 209, 211) los dejé como riesgo, aunque también podrían ser dependencia del equipo de seguridad, si está fuera del proyecto. No lo sé.

### Registro completo
Tipo ya reclasificado. «Último movimiento» es la fecha del informe de la que sale el ítem, no una fecha de movimiento real; el registro no trae otra. Prob., impacto, doliente y fecha: vacíos en todos.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| 199-R1 | Riesgo | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | 2026-10-15 |
| 199-R2 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-10-15 |
| 199-I1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | n/a | n/a | — | — | 2026-10-15 |
| 200-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-10-09 |
| 200-I1 | Incidencia | Dos historias fuera del sprint por dependencia con el core | n/a | n/a | — | — | 2026-10-09 |
| 201-D1 | Dependencia (antes riesgo) | Calendario de liberaciones del core | — | — | — | — | 2026-10-10 |
| 201-I1 | Incidencia | Prueba de carga bajo el umbral pactado, se repite | n/a | n/a | — | — | 2026-10-10 |
| 202-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-10-14 |
| 202-D1 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de última entrega | — | — | — | — | 2026-10-14 |
| 202-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | n/a | n/a | — | — | 2026-10-14 |
| 202-I2 | Incidencia | Salida reprogramada por ventana de cambio, sin nueva fecha | n/a | n/a | — | — | 2026-10-14 |
| 202-I3 | Incidencia | Dos historias fuera del sprint por dependencia con el core | n/a | n/a | — | — | 2026-10-14 |
| 203-R1 | Riesgo | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | 2026-10-09 |
| 203-D1 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de última entrega | — | — | — | — | 2026-10-09 |
| 203-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | n/a | n/a | — | — | 2026-10-09 |
| 203-I2 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | n/a | n/a | — | — | 2026-10-09 |
| 204-D1 | Dependencia (antes riesgo) | Calendario de liberaciones del core | — | — | — | — | 2026-10-12 |
| 205-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-10-16 |
| 205-R2 | Riesgo (no registrado formalmente) | Proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | — | — | 2026-10-17 |
| 206-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | 2026-10-05 |
| 206-I1 | Incidencia | Dos semanas perdidas por rotación de un desarrollador clave | n/a | n/a | — | — | 2026-10-05 |
| 207-D1 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de última entrega | — | — | — | — | 2026-09-24 |
| 207-R1 | Riesgo | Concentración del conocimiento en una sola persona | — | — | — | — | 2026-09-24 |
| 207-I1 | Incidencia | Prueba de carga bajo el umbral pactado, se repite | n/a | n/a | — | — | 2026-09-24 |
| 208-D1 | Dependencia (antes riesgo) | Calendario de liberaciones del core | — | — | — | — | 2026-10-08 |
| 208-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | n/a | n/a | — | — | 2026-10-08 |
| 208-I2 | Incidencia | Salida reprogramada por ventana de cambio, sin nueva fecha | n/a | n/a | — | — | 2026-10-08 |
| 209-R1 | Riesgo | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | 2026-10-15 |
| 209-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | n/a | n/a | — | — | 2026-10-15 |
| 209-I2 | Incidencia | Salida reprogramada por ventana de cambio, sin nueva fecha | n/a | n/a | — | — | 2026-10-15 |
| 210-R1 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | 2026-10-16 |
| 210-D1 | Dependencia (antes riesgo) | Proveedor sin confirmar fecha de última entrega | — | — | — | — | 2026-10-16 |
| 210-I1 | Incidencia | Salida reprogramada por ventana de cambio, sin nueva fecha | n/a | n/a | — | — | 2026-10-16 |
| 211-R1 | Riesgo | Disponibilidad del equipo de seguridad para la revisión final | — | — | — | — | 2026-10-16 |
| 211-R2 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | — | — | — | — | 2026-10-16 |
| 211-I1 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | n/a | n/a | — | — | 2026-10-16 |
| 211-I2 | Incidencia | Prueba de carga bajo el umbral pactado, se repite | n/a | n/a | — | — | 2026-10-16 |

Aparte del registro: las dependencias contractuales de PRY-209 (CT-258) y PRY-199 (CT-199) no estaban registradas y están en la tabla de dependencias.

## Después
Para subir a comité (llevan la decisión formulada):
1. Confirmar si «el core» es PRY-201 y, de serlo, qué hacen 199, 200, 202, 204 y 208 ante el piloto de PRY-201 en 2027-01-30. **Decisión:** ¿se aprueba CC-01 de PRY-201 y se replanifican los dependientes?
2. Asignar un doliente único para el equipo de seguridad y priorizar los cuatro hallazgos abiertos (203, 208, 209, 211). **Decisión:** ¿en qué orden se revisan?
3. PRY-209: ¿se retiene el pago de FV-1258 hasta tener actas de recibo? (monto sobre lo recibido: 365.708.982 COP).
4. PRY-211: confirmar con qué hallazgos abiertos se aceptó la salida a producción.

Propongo, sin asignar, que cada gerente de proyecto sea el doliente de las incidencias de su proyecto, y que Natalia Ospina evalúe formalizar el riesgo del proveedor de PRY-205. La decisión es de la PMO.

## Pie de rigor
- Lo que no sé: quién es doliente de cualquier ítem (ningún documento lo dice), con qué probabilidad e impacto, a qué proveedor se refiere cada riesgo de proveedor, y si «el core» es PRY-201.
- Lo que no leí a fondo: las actas de constitución en .docx solo por su sección de dependencias; las actas de recibo de 199, 200, 202, 206, 207, 208, 209 (16 oct) y 210; los cronogramas de 200 y 206; los comités 2026-09 de PRY-205 solo para compromisos. Lo leído viene del caché de texto, no de los originales.
- «Sin movimiento» se mide con la fecha del informe y no con una fecha de movimiento real. Solo PRY-207 supera el umbral de 15 días en silencio (23 días).
- La reclasificación riesgo → dependencia es mía; el gerente puede revertirla.
- Esto es un borrador de trabajo. La verificación contra los documentos citados es de la PMO.
