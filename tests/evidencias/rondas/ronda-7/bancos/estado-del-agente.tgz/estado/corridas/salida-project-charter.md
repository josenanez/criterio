Acta previa: **sí existe**, aprobada el 2026-05-06 (`PRY-203-open-banking/00-gobierno/2026-05-06-acta-constitucion.docx`). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se pidió nueva aceptación.

## Acta — PRY-203 Open Banking
**Estado:** existe, del 2026-05-06

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** | Rubén Cárdenas no tiene declarado hasta qué monto ni qué cambio de alcance decide sin comité. Hoy el proyecto proyecta cerrar en 18.145.395.715 COP contra 18.000.000.000 aprobados (+145.395.715, +0,8%), y tiene un hallazgo de seguridad abierto y dos semanas perdidas. Sin autoridad escrita, cualquier ajuste de ese tipo sube al Comité de Medios de Pago por defecto, o se decide sin que nadie pueda decir si era su facultad. |
| Objetivo de negocio | Es la solución, no el negocio: "Entregar open banking para Medios de Pago" | No dice qué resultado de negocio se busca (clientes, volumen, ingreso, cumplimiento). Sin eso el comité no puede decidir si un recorte de alcance sigue sirviendo al objetivo. |
| Alcance | Placeholder: "Componente 1, 2, 3" | Los componentes no están nombrados. No se puede verificar qué se entregó ni detectar un cambio de alcance; el control de cambios no tiene contra qué medir. |
| Exclusiones | Placeholder: "Lo que otro proyecto cubre" | No identifica qué proyecto ni qué cubre. Si hay solapamiento con otro proyecto, nada lo detecta. |
| Supuestos y restricciones | **No hay** | El informe de avance muestra restricciones reales (equipo de seguridad, proveedor) que el acta nunca declaró; no hay base contra la cual decir que un supuesto falló. |
| Dependencias | "Ninguna declarada" | Contradice el informe del 2026-10-09: riesgos abiertos sobre la disponibilidad del equipo de seguridad y sobre la fecha de entrega de un proveedor. La dependencia existe y nadie la tiene registrada ni con dueño. |
| Criterio de éxito | "Open Banking en producción y medido": sin métrica ni umbral | "Medido" no dice qué se mide ni contra qué valor. El cierre del proyecto no se puede juzgar como cumplido o no. |
| Quién mide el éxito | **No está** | Nadie responde por declarar que el criterio se cumplió. |
| Cadencia del comité | **No está** (el comité sí: Comité de Medios de Pago) | No hay frecuencia de reporte pactada; el silencio de un proyecto no tiene umbral propio contra el cual alertar. |
| Hitos principales | **No hay** (`plan.milestones` vacío) | Solo existen inicio (2026-05-16) y cierre (2027-02-27). Con avance declarado de 30% a 5 meses de 9, no hay forma de comprobar si el plan va al ritmo. |
| Patrocinador | Cumple: Carlos Peña | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar open banking para Medios de Pago" (es la solución).
**Alcance:** Componente 1, Componente 2, Componente 3, sin más detalle (acta, 2026-05-06). Pendiente de definir qué es cada uno.
**Exclusiones:** "Lo que otro proyecto cubre" (acta). Pendiente de definir cuál proyecto y qué cubre.
**Patrocinador:** Carlos Peña (acta) · **Gerente:** Rubén Cárdenas (acta e informe 2026-10-09)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento.
**Comité al que reporta:** Comité de Medios de Pago (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Open Banking en producción y medido" (acta); sin métrica. · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo hay inicio 2026-05-16 y cierre 2027-02-27 (acta).
**Presupuesto aprobado:** 18.000.000.000 COP, aprobado por el Comité de Medios de Pago el 2026-05-06 (acta).
**Producto asociado:** APIs de datos (acta).

Fuentes: el acta (2026-05-06) y el informe de avance (2026-10-09). No hay otro documento del proyecto en la carpeta.

### Lo que no sé
- No sé si la autoridad del gerente, la cadencia o los hitos se acordaron fuera de los documentos. Si existen, no están escritos.
- No sé a qué proyecto se refieren las exclusiones.
- El acta es un .docx leído a través de su conversión; no vi formato ni comentarios del original.

## Después
- El acta quedó **sin autoridad declarada**. Te ofrezco llevar esa definición al Comité de Medios de Pago como decisión (monto y tipo de cambio que Rubén Cárdenas decide solo), con el contexto de la proyección de 18.145.395.715 COP. Es una decisión, no un trámite.
- De la revisión salen dos riesgos que el informe cita sin probabilidad, impacto ni dueño, y una dependencia no declarada (equipo de seguridad y proveedor). Te ofrezco pasarlos al registro RAID (`/raid-log`).

*Pie de rigor: borrador de trabajo basado solo en los dos documentos citados; la verificación es de quien lo lea. Todo campo sin cita quedó marcado como pendiente, no se completó con lo razonable.*
