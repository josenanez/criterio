## Barrido — 2026-10-17

**Antes de empezar:** los términos de esta versión (0.3.13, v1.1) ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo. Pregunta que el modo de prueba no puede contestar: ninguna quedó abierta.

**Documentos:** 81 en la carpeta · 51 leídos · 30 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 distinguidos (13 carpetas) · 10 con ficha nueva en esta corrida · 3 sin tocar (PRY-205, PRY-209, PRY-211) · 0 sin carpeta propia

Formatos: 36 .md, 15 .pdf, 12 .docx, 9 .xlsx, 7 .csv, 1 .json, 1 .txt. Plan: 51 de 81 documentos, un solo lote de 10 proyectos, uno tras otro, sin subagentes. Nada quedó diferido. Word, Excel y PDF se leyeron por su texto convertido; las citas van a los originales.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | 13 de 15 | autoridad del gerente, etapa; lo facturado a Consultora Andina (CT-199): ninguna factura en la carpeta |
| PRY-200 Originación digital | 6 | 13 de 15 | autoridad, etapa |
| PRY-201 Core de depósitos | 6 | 13 de 15 | autoridad, etapa |
| PRY-202 Migración a la nube | 4 | 12 de 15 | autoridad, etapa, producto (el acta dice «No aplica») |
| PRY-203 Open Banking | 2 | 13 de 15 | autoridad, etapa; **no hay cronograma**, sin hitos |
| PRY-204 Débito contactless | 4 | 13 de 15 | autoridad, etapa |
| PRY-206 Billetera y QR | 5 | 13 de 15 | autoridad, etapa |
| PRY-207 Onboarding PyME | 7 | 13 de 15 | autoridad, etapa |
| PRY-208 Motor de decisión | 7 | 12 de 15 | autoridad, etapa, producto («No aplica») |
| PRY-210 Portal de proveedores | 4 | 12 de 15 | autoridad, etapa, producto («No aplica») |

Ninguna de las 13 fichas del portafolio declara la autoridad del gerente (cuánto puede decidir sin subir a comité): ese campo falta en las 13.

### Actualizados
Ninguno. Las fichas de PRY-205, PRY-209 y PRY-211 no se releyeron: sus 30 documentos no cambiaron.

### Lo que el barrido ya muestra (el script lo calculó sobre las fichas; el detalle es del informe consolidado)
De las 13 fichas, 11 tienen alertas (67 en total) y **8 proyectos declaran «verde» con señales en contra** (PRY-200, 201, 202, 204, 207, 210, y fuera de este barrido 205 y 211).

- **PRY-201 Core de depósitos** — verde, 66 %. El cronograma v2 (2026-10-10) corrió el piloto de 2026-10-15 a 2027-01-30 (+107 días) y la solicitud de cambio CC-01 sigue «pendiente de presentación al comité»: el plan se movió sin cambio autorizado. Proyección 24,2 % sobre el presupuesto. Tres hitos «cerrado» sin acta de recibo.
- **PRY-207 Onboarding PyME** — verde, 58 %. Misma situación: cronograma v2 (2026-09-24) mueve el piloto +58 días y CC-01 (2026-10-14) está pendiente de comité. Proyección 18,4 % sobre lo aprobado. Compromiso vencido.
- **PRY-208 Motor de decisión** — rojo. CC-01 figura «autorizada por el comité», pero el documento no nombra al comité ni cita acta; el cronograma v2 es del 2026-10-08, seis días antes de la solicitud. El código lo marca como cambio sin línea base.
- **PRY-204 Débito contactless** — verde, 43 %. La fecha de cierre del acta (2026-08-23) ya pasó, el cronograma declara los tres hitos cerrados sin ningún acta de recibo, y el avance reportado no cuadra con un plan terminado. Proyección 23,5 % sobre el presupuesto.
- **PRY-202 Migración a la nube** — verde, 34 %. El piloto (2026-10-13) venció hace 4 días sin cerrarse; la salida a producción se «reprogramó» sin nueva fecha en el cronograma. Dos hitos cerrados sin acta. El informe habla de un proveedor, pero no hay contrato en la carpeta.
- **PRY-200 Originación digital** — verde, 44 %. El mismo nombre (Andrés Lozano) es patrocinador y gerente, y aparece dos veces como asistente del comité del 2026-10-10. Hito «Ambiente de pruebas» cerrado sin acta.
- **PRY-210 Portal de proveedores** — verde, 78 %, pero el plan solo sostiene entre 25 y 50 % (1 de 4 hitos cerrados). Mención de un proveedor sin contrato en la carpeta.
- **PRY-203 Open Banking** — amarillo, 18 000 millones COP, la ficha más grande de este lote: **sin cronograma**, no hay forma de medir atraso. También menciona un proveedor sin contrato.
- **PRY-206 Billetera y QR** — rojo, sin alertas del cálculo salvo un compromiso sin fecha.
- **PRY-199 Renovación de cajeros** — la única sin alertas. Verde, 20 %; hito de diseño con acta de recibo. Contrato CT-199: 3 entregables de 144 millones, todos pendientes, el primero vence el 2026-11-16.

**Compromisos vencidos sin evidencia:** PRY-200 (punto 13, venció 2026-10-14) y PRY-207 (punto 36, venció 2026-10-10; el acta es del día 11, es decir, se registró una fecha ya pasada). **Compromisos sin fecha:** PRY-206 (punto 14) y PRY-208 (punto 37). Se reportan los hechos, no a las personas.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 81 documentos se convirtieron a texto. |

### Citas que dejaron de resolver
`index` marca 14 campos de PRY-205 (`pm_record`) como «fuente ausente». **No es un borrado:** los documentos existen. La ficha que publicó el gerente cita rutas relativas a la carpeta del proyecto (`00-gobierno/...`) y la raíz de documentación pide la carpeta incluida (`PRY-205-.../00-gobierno/...`). No toqué esa ficha: es declaración del gerente, no mía. Conviene que quien la publica unifique la convención de rutas.

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/` en la documentación; no había nada que mover. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. Aviso: `PRY-205-.../2026-10-17-notas-reunion.txt` queda en la raíz del proyecto, fuera de las subcarpetas de la convención; no se leyó (sin cambios). |

### Qué asumí sin poder preguntar
- Los hitos «cerrado» se registraron como `met` y los «en curso» como `pending`; la evidencia solo se llenó donde hay un acta de recibo que nombra ese hito.
- Un `Producto asociado: No aplica` quedó como campo vacío, no como producto.
- El cronograma v2 de PRY-201, 207 y 208 no trae motivo: la línea base 2 dice «no declarado en el documento».
- «Esta semana»/«por definir» no se convirtieron en fechas: quedaron `no_declarada`.

## Después
Hay más de un proyecto: puedo preparar el informe consolidado (`/criterio-portfolio:portfolio-report`). Las contradicciones y los compromisos vencidos de arriba entrarían en él.

---
Criterio Portfolio 0.3.13 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 206, 207, 208, 210) · campos en `not_found`: 2 por proyecto en autoridad y etapa, más producto en 202, 208 y 210, más hitos en 203 · Borradores de trabajo, no asesoría; la verificación es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
