# Corrida del 2026-10-17 · budget-tracking

13 proyectos · 30 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

Presupuesto de PRY-201: proyección 24,2% sobre el aprobado, ejecución 35,2% frente a avance declarado 66%, CC-01 pendiente. No hay respaldo contable de comprometido/ejecutado ni se sabe si la proyección incluye la CC-01.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-201 (estado/records/PRY-201.json), acta de constitución (2026-01-22), informe de avance (corte 2026-10-10), solicitud de cambio CC-01 (2026-10-05), cronogramas v1 y v2. Cifras derivadas copiadas de `portafolio.py compute`, al 2026-10-17.

## Presupuesto — PRY-201 Core de depósitos al 2026-10-17
**Moneda:** COP (única moneda; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 800.000.000 | 100 | Acta de constitución | 2026-01-22 |
| Comprometido | 341.241.342 | 42,7 | Informe de avance (declaración del gerente) | 2026-10-10 |
| Ejecutado | 281.689.586 | 35,2 | Informe de avance (declaración del gerente) | 2026-10-10 |
| Proyección al cierre | 993.865.329 | 24,2 por encima del aprobado | Informe de avance (declaración del gerente) | 2026-10-10 |

**Disponible real** (aprobado menos comprometido): 458.758.658 COP

La proyección es una declaración, no un dato duro. Tiene 7 días de antigüedad y ningún movimiento de presupuesto es posterior. Ninguna de las tres cifras del informe tiene respaldo en un documento de evidencia (contabilidad, facturas); todas salen del mismo informe.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 800.000.000 | 800.000.000 | 0 |
| Proyección frente al aprobado | | 993.865.329 | +24,2 % (umbral 10 %) |

Replanificaciones de presupuesto: 0. La CC-01 pide 214.000.000 COP adicionales y sigue **pendiente de presentación al comité**: no hay aprobación, así que el aprobado vigente sigue siendo 800.000.000.

### Ejecución frente a avance
Ejecutado 35,2 % · Hitos cumplidos 3 de 4 · Avance declarado 66 % (el plan sostiene entre 75 y 100 %).
Lectura: la ejecución está muy por debajo del avance declarado. O hay trabajo hecho y no causado que aparecerá de golpe, o el avance declarado está inflado. Los tres hitos «cumplidos» (Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core) no traen evidencia de cumplimiento, y el propio informe dice que la prueba de carga no alcanzó el umbral. Con los documentos no se puede decidir cuál de las dos lecturas es la correcta.

### Alertas
- **Proyección por encima del aprobado:** 993.865.329 frente a 800.000.000, 24,2 % sobre un umbral de 10 %. La proyección excede el aprobado sin que el cambio de presupuesto esté autorizado.
- **Línea base de tiempo movida sin autorización:** la v2 (2026-10-10) mueve el cierre 107 días (de 2026-10-15 a 2027-01-30) sin cambio aprobado ni motivo declarado.
- **Estado declarado «verde» frente a la evidencia:** el informe no da cuenta de la desviación de costo, la de tiempo, el movimiento de línea base ni los hitos sin evidencia.
- Comprometido: 42,7 % del aprobado, por debajo del umbral de 90 %. No hay alerta de tope.

### Sin dato
- Si la proyección de 993.865.329 incluye los 214.000.000 de la CC-01: ningún documento lo dice.
- Desglose del comprometido y el ejecutado por proveedor o contrato: el proyecto no tiene proveedores en la ficha.
- Fuente contable que respalde comprometido y ejecutado: no hay.
- Motivo de la línea base v2: el cronograma no lo trae.
- Autoridad y fase del proyecto: `not_found`.

## Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`) para llevar la CC-01 al comité, con las cifras de arriba. No lo hago sin que lo pidas.

*Pie de rigor: borrador de trabajo basado solo en los documentos citados; no recoge lo hablado fuera de ellos. Verifica cada cifra contra su fuente antes de usarla.*
