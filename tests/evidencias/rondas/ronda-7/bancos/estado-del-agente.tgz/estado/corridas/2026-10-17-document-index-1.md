# Corrida del 2026-10-17 · document-index

13 proyectos · 27 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 10 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 5 |
| `variance_time` | 4 |
| `variance_cost` | 4 |
| `rebaseline_unauthorized` | 3 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 1 |
| `change_without_baseline` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

81 documentos sin cambio, 0 por releer. 14 citas pm_record de PRY-205 no resuelven aunque los archivos existen; causa probable: citas relativas a la carpeta del proyecto, sin confirmar. No se modificó ninguna ficha.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 81 · **Sin cambio:** 81 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
14 citas, todas del proyecto PRY-205 (campos `pm_record.*`). Ninguna sustenta ya su dato según el índice.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-205 | pm_record.identity.code | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.identity.name | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.identity.business_area | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.identity.sponsor | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.identity.manager | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.identity.committee | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.plan.start_date | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.plan.end_date | 10-plan/2026-10-16-cronograma-v3.csv |
| PRY-205 | pm_record.plan.scope_summary | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.plan.exclusions | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.money.approved | 00-gobierno/2025-08-22-acta-constitucion.md |
| PRY-205 | pm_record.money.committed | 20-seguimiento/2026-10-16-informe-avance.pdf |
| PRY-205 | pm_record.money.executed | 20-seguimiento/2026-10-16-informe-avance.pdf |
| PRY-205 | pm_record.money.projection | 20-seguimiento/2026-10-16-informe-avance.pdf |

Lo que verifiqué: los archivos citados **sí existen** en disco, dentro de `PRY-205-prevención-de-lavado-de-activos/`. Las citas de `pm_record` están escritas relativas a esa carpeta (sin el nombre del proyecto al frente), mientras que las demás citas de la ficha sí lo llevan. Es la causa más probable de que no resuelvan, pero no la he confirmado; no es un documento borrado ni movido.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
No hay documentos por releer, así que no hace falta `/portfolio-scan`. Queda por decidir si se corrige la forma de las citas de `pm_record` de PRY-205 (ficha por ficha, mostrando el cambio); no se ha tocado nada.
