# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 81 documentos, 51 releídos y 30 sin cambio · 133 s · 33 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 10 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 3 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 3 |
| `declared_vs_evidence` | 2 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `variance_cost` | 1 |
| `vendor_invoiced_over_accepted` | 1 |

0 preguntas (sesión sin interfaz, valores sugeridos); unos 10-12 minutos hasta el primer resultado; 3 proyectos (PRY-211, PRY-205, PRY-209), 30 documentos, 33 señales; 2 verdes contradichos

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 81 documentos en 13 proyectos · formatos: .md (36), .pdf (15), .docx (12), .xlsx (9), .csv (7), .json (1), .txt (1) · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesta: hay trece proyectos)
**Te aviso:** dos días antes del comité semanal; propuse el 2026-10-24 como próximo comité porque los documentos muestran comités semanales y no hay fecha dicha (dímela y la corrijo)
**En:** presentación (valor sugerido: no dijiste)
**Términos:** aceptados para la versión 0.3.13 (términos 1.1) por José Francisco Ñáñez, 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 del texto de los términos d31e6b3611041618…

Preguntas hechas: 0 (sesión sin interfaz; en cada una tomé el valor sugerido). Estado en `estado/`, informes en `reportes/`, configuración en `.criterio/portafolio/config.json`.

### Probé con tres proyectos

Los de documentación más reciente: PRY-211, PRY-205 y PRY-209.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-211 Cobranza digital | 5 | Gerente Camilo Beltrán, patrocinador Andrés Lozano, presupuesto 2.400.000.000 COP, cierre comprometido 2026-05-15. Declara **verde, 84 %** (informe 2026-10-16). Cinco hitos cerrados en el cronograma; solo «Salida a producción» tiene acta de recibo (2026-10-17). | Facultad del gerente (`authority`), fase. Alcance: el acta solo dice «Componente 1, 2, 3». |
| PRY-205 Prevención de lavado de activos | 17 | Gerente Natalia Ospina, patrocinador Rubén Cárdenas, presupuesto 800.000.000 COP, cierre 2026-06-07 (cronograma v3; el acta decía 2026-03-19). Declara **verde, 27 %**. Dos solicitudes de cambio pendientes (CC-01 +38 días/76 M; CC-02 +42 días/84 M). 26 compromisos seguidos en seis comités y unas notas del 2026-10-17. El proyecto publicó `ficha-pm.json`; va aparte, en `pm_record`. | Producto («No aplica»), facultad, fase. Cronograma v2 (existe v3 y no hay v2). |
| PRY-209 Nómina electrónica | 8 | Gerente Gustavo Neira, patrocinador Carlos Peña, presupuesto 6.800.000.000 COP, cierre 2027-07-08. Declara **rojo, 29 %**. Contrato CT-258 con Integra Sistemas (4 entregables de 750.219.723 COP; uno con acta de recibo) y factura FV-1258 por 1.115.928.705 COP. | Facultad, fase. |

### Lo que levantó `compute` (33 señales en los tres)

**PRY-205 — verde declarado, y el cálculo no lo sostiene**
- `declared_vs_evidence`: declara verde y cuenta con seis señales abiertas.
- `variance_time`: +80 días (40,2 %) contra la fecha original; `rebaseline_unauthorized`: 80 días movidos y 0 autorizados (hay 2 cambios, ambos pendientes).
- `progress_vs_plan`: declara 27 %, y el cronograma tiene 5 de 5 hitos cerrados; 73 puntos de diferencia.
- `milestone_met_without_evidence`: cinco hitos declarados cerrados sin acta que lo pruebe (el más viejo, 372 días).
- `commitment_overdue`: 8 compromisos vencidos sin evidencia (el más antiguo: Paula Céspedes, «Actualizar la matriz 6», 30 días; Rubén Cárdenas, «Revisar el anexo 3», 29 días).
- `commitment_rescheduled`: Sandra Gil, «Enviar el documento 1», 6 veces (original 2026-09-17, hoy 2026-12-08); Carlos Peña, «Cerrar la prueba 2», 5 veces; Ricardo Salas, «Cerrar la prueba 10», 3 veces.
- `commitment_undated`: 2 (Felipe Arango, «Confirmar la fecha 15»; Laura Vélez, «ajuste del presupuesto»).

**PRY-211 — verde declarado**
- `declared_vs_evidence`: declara verde con dos señales abiertas.
- `progress_vs_plan`: 84 % declarado contra 5 de 5 hitos cerrados (16 puntos).
- `milestone_met_without_evidence`: cuatro hitos cerrados sin acta (el más viejo, 378 días).

**PRY-209 — rojo declarado**
- `variance_cost`: proyección al cierre 8.198.690.139 COP contra 6.800.000.000 aprobados (+20,6 %).
- `vendor_invoiced_over_accepted`: facturado 1.115.928.705 COP contra 750.219.723 aceptados (diferencia 365.708.982 COP).
- `progress_vs_plan`: declara 29 %, el cronograma sostiene entre 40 y 60 %.
- `milestone_met_without_evidence`: «Diseño funcional aprobado» (109 días).
- `commitment_undated`: Javier Hoyos, «Entregar el punto 19».

**Vacíos de la carpeta que `compute` marcó:** ninguno de los tres tiene `authority`; en PRY-205 y PRY-211 varios campos vienen del acta de hace 14–15 meses sin confirmación posterior.

Hay dos hechos que están en los documentos y `compute` no levantó como señal, y los dejo como datos, no como hallazgos: en las notas del 2026-10-17 de PRY-205 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo anotó (lo dejé en `raid.risks` con esa fuente); y tres compromisos de PRY-205 se dieron por entregados en comité sin acta (anexo 3, fecha 15, documento 17).

### El portafolio completo
10 proyectos más y 51 documentos, en dos lotes, uno tras otro. Con lo que tomó este arranque (tres proyectos, 30 documentos, unos 10-12 minutos contando la instalación), calculo entre 30 y 40 minutos. Es una estimación, no una medida.

### Lo que le falta a tu carpeta
- Falta acta de recibo en casi todos los hitos que los cronogramas dan por cerrados (10 de 12 en estos tres proyectos). Es lo que más pesa.
- El cronograma v3 de PRY-205 no tiene v2 al lado, ni aprobación del cambio de fecha.
- Las actas de constitución de los tres no traen la facultad del gerente y dejan el alcance en «Componente 1, 2, 3».
- Un archivo suelto en PRY-205 (`2026-10-17-notas-reunion.txt`) fuera de `30-reuniones/`; se leyó, pero conviene moverla.
- Ninguno es bloqueante.

**Siguiente paso que te ofrezco:** correr el portafolio completo. Como eres PMO y uno de los proyectos ya publica su `ficha-pm.json`, también puedo publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios.
