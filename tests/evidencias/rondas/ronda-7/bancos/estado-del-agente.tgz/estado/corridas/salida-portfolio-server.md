# Rostrum — para mirarlo un rato

**Términos:** vigentes para la versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante en `.criterio/terminos/`). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13

**Modo elegido: «para mirarlo un rato»** (no había quien respondiera; se toma la respuesta sugerida, que es empezar por esta). Se levanta, se mira y se apaga. El patrocinador no tendrá un enlace que funcione mañana; para eso existe «que quede corriendo», que pide un host, un puerto y el control de acceso de la organización.

**Informe:** existe en `reportes/` (13 proyectos, 9 productos, portada, decisiones). Rostrum no lo genera, lo sirve.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El portal lleva el nombre «Portafolio de proyectos» (de `organization.name`).

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos. Las peticiones del formulario esperan a que el agente las vea con `due`; no despiertan al agente por sí solas.

**Cierre:** el enlace local `http://127.0.0.1:8787/` solo lo ve quien esté en este equipo; no se le puede pasar a un patrocinador. El informe es del 2026-10-17 y queda desactualizado en el siguiente barrido o `/portfolio-report` (el comité es el 2026-10-24); la portada muestra su fecha.
