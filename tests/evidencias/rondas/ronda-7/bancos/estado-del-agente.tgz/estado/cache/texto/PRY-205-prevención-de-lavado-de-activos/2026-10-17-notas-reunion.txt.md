<!-- origen: PRY-205-prevención-de-lavado-de-activos/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión prevención de lavado de activos — 2026-10-17
estuvieron: Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

- Sandra Gil dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 08/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
