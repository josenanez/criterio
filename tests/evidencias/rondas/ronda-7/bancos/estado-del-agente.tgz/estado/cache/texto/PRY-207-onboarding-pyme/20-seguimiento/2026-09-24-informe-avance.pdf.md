<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Onboarding PyME
Código: PRY-207
Fecha de corte: 2026-09-24
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 58%

Lo que pasó en el periodo
- La prueba de carga no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.684.726.580
Ejecutado 1.973.666.237
Proyección al cierre 3.905.904.944

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
