<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Prevención de lavado de activos

**Fecha:** 2026-09-05
**Asistentes:** Carlos Peña, Natalia Ospina, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-09-17 |
| Carlos Peña | Cerrar la prueba 2 | 2026-09-20 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-18 |
| Rubén Cárdenas | Validar el ambiente 4 | 2026-09-26 |
