<!-- origen: PRY-209-nómina-electrónica/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Nómina electrónica

**Fecha:** 2026-10-12
**Asistentes:** Gustavo Neira, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Javier Hoyos | Entregar el punto 19 | por definir |
