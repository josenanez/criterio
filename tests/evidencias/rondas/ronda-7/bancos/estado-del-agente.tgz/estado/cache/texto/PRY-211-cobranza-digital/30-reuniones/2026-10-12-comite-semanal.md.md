<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Cobranza digital

**Fecha:** 2026-10-12
**Asistentes:** Camilo Beltrán, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Entregar el punto 4 | 2026-10-29 |
