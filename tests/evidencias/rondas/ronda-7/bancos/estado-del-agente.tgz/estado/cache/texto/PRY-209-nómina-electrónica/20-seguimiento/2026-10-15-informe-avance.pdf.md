<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-10-15
Gerente: Gustavo Neira

Estado declarado
Rojo
Avance reportado: 29%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.357.343.746
Ejecutado 2.310.660.326
Proyección al cierre 8.198.690.139

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
