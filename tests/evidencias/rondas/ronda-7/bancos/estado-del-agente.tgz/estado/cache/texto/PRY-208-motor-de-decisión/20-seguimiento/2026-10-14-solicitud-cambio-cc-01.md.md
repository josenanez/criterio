<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Motor de decisión
**Fecha:** 2026-10-14
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +57 días sobre la línea base vigente |
| Costo | 114.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
