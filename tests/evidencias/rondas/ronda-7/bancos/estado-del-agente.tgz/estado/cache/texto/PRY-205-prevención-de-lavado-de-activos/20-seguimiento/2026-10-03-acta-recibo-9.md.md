<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-03-acta-recibo-9.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Enviar el documento 9

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha de recibo:** 2026-10-03
**Recibido por:** Natalia Ospina

Se recibe a satisfacción: **Enviar el documento 9**, compromiso de Javier Hoyos.
