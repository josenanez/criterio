<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2026-06-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Billetera y QR

Código: PRY-206

Área dueña: Banca PyME

Patrocinador: Carlos Peña

Gerente de proyecto: Jorge Medina

Comité: Comité de Banca Empresas

Producto asociado: pagos QR

Fecha de aprobación: 2026-06-07

Objetivo del negocio

Entregar billetera y qr para Banca PyME.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Banca Empresas el 2026-06-07.

Fechas comprometidas

Fecha

Inicio

2026-06-17

Cierre

2027-05-11

Criterio de éxito

Billetera y QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
