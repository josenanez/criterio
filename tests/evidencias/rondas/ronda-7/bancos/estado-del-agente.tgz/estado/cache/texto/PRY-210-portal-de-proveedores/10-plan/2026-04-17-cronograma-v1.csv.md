<!-- origen: PRY-210-portal-de-proveedores/10-plan/2026-04-17-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-08-13,2026-08-13,cerrado
Ambiente de pruebas certificado,2026-11-30,2026-11-30,en curso
Integración con el core,2027-03-19,2027-03-19,en curso
Piloto con usuarios internos,2027-07-05,2027-07-05,en curso
