<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-10-12
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 43%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 757.948.023
Ejecutado 468.384.958
Proyección al cierre 1.481.747.420

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
