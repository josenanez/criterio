<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-10-acta-recibo-integración-con-el-core.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Integración con el core
Proyecto: PRY-200 · Originación digital
Fecha de recibo: 2026-10-10
Recibido por: Andrés Lozano
Se recibe a satisfacción el entregable Integración con el core.
