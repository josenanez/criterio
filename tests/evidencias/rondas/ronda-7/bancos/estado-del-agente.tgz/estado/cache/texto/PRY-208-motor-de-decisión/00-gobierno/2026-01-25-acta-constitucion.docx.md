<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2026-01-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Tesorería

Patrocinador: Felipe Arango

Gerente de proyecto: Liliana Torres

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2026-01-25

Objetivo del negocio

Entregar motor de decisión para Tesorería.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Banca Empresas el 2026-01-25.

Fechas comprometidas

Fecha

Inicio

2026-02-04

Cierre

2027-06-05

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
