<!-- origen: PRY-209-nómina-electrónica/10-plan/2026-03-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-30 | 2026-06-30 | cerrado
Ambiente de pruebas certificado | 2026-10-01 | 2026-10-01 | cerrado
Integración con el core | 2027-01-02 | 2027-01-02 | en curso
Piloto con usuarios internos | 2027-04-06 | 2027-04-06 | en curso
Salida a producción | 2027-07-08 | 2027-07-08 | en curso
