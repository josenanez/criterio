<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-09
**Solicitante:** Natalia Ospina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +38 días sobre la línea base vigente |
| Costo | 76.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
