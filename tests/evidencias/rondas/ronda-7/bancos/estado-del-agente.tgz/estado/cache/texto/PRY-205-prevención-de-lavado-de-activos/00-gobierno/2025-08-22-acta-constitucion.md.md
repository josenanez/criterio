<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2025-08-22-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Prevención de lavado de activos

**Código:** PRY-205
**Área dueña:** Tesorería
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Medios de Pago
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-08-22

## Objetivo del negocio

Entregar prevención de lavado de activos para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Medios de Pago el 2025-08-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-09-01 |
| Cierre | 2026-03-19 |

## Criterio de éxito

Prevención de lavado de activos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
