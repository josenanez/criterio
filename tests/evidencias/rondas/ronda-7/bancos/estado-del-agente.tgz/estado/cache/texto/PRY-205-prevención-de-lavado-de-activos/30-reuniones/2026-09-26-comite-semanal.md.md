<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-09-26-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Prevención de lavado de activos

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Carlos Peña, Felipe Arango, Javier Hoyos, Jorge Medina, Liliana Torres, Natalia Ospina, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-10-26 |
| Carlos Peña | Cerrar la prueba 2 | 2026-10-28 |
| Rubén Cárdenas | Validar el ambiente 4 | 2026-10-16 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 |
| Natalia Ospina | Confirmar la fecha 7 | 2026-10-19 |
| Liliana Torres | Entregar el punto 8 | 2026-09-28 |
| Javier Hoyos | Enviar el documento 9 | 2026-10-18 |
| Ricardo Salas | Cerrar la prueba 10 | 2026-10-11 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 |
| Javier Hoyos | Actualizar la matriz 14 | 2026-10-16 |
| Felipe Arango | Confirmar la fecha 15 | por definir |
| Liliana Torres | Entregar el punto 16 | 2026-10-17 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Felipe Arango): recibido, acta de recibo del 2026-09-26.
