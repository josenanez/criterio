<!-- origen: PRY-206-billetera-y-qr/10-plan/2026-06-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-09-07 | 2026-09-07 | cerrado
Ambiente de pruebas certificado | 2026-11-28 | 2026-11-28 | en curso
Integración con el core | 2027-02-18 | 2027-02-18 | en curso
Piloto con usuarios internos | 2027-05-11 | 2027-05-11 | en curso
