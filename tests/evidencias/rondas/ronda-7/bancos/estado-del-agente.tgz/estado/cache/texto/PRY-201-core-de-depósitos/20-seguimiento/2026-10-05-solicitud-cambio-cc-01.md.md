<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Core de depósitos
**Fecha:** 2026-10-05
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +107 días sobre la línea base vigente |
| Costo | 214.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
