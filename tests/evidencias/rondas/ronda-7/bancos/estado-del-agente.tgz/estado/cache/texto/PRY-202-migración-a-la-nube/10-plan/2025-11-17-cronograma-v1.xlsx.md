<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-11-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-15 | 2026-02-15 | cerrado
Ambiente de pruebas certificado | 2026-05-06 | 2026-05-06 | cerrado
Integración con el core | 2026-07-25 | 2026-07-25 | cerrado
Piloto con usuarios internos | 2026-10-13 | 2026-10-13 | en curso
Salida a producción | 2027-01-01 | 2027-01-01 | en curso
