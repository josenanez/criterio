<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2026-04-26-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Onboarding PyME

Código: PRY-207

Área dueña: Banca Empresas

Patrocinador: Ricardo Salas

Gerente de proyecto: Jorge Medina

Comité: Comité de Arquitectura

Producto asociado: cuenta PyME

Fecha de aprobación: 2026-04-26

Objetivo del negocio

Entregar onboarding pyme para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Arquitectura el 2026-04-26.

Fechas comprometidas

Fecha

Inicio

2026-05-06

Cierre

2027-09-20

Criterio de éxito

Onboarding PyME en producción y medido.

Dependencias declaradas

• Ninguna declarada
