<!-- origen: PRY-208-motor-de-decisión/10-plan/2026-10-08-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-05 | 2026-06-05 | cerrado
Ambiente de pruebas certificado | 2026-10-05 | 2026-10-05 | cerrado
Integración con el core | 2027-02-03 | 2027-02-03 | en curso
Piloto con usuarios internos | 2027-06-05 | 2027-08-01 | en curso
