<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Billetera y QR

**Fecha:** 2026-10-06
**Asistentes:** Jorge Medina, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 14 | por definir |
