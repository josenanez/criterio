<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Onboarding PyME

**Fecha:** 2026-10-11
**Asistentes:** Jorge Medina, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 36 | 2026-10-10 |
