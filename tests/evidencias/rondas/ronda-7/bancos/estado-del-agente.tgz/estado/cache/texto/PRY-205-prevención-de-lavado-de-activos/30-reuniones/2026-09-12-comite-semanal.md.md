<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Prevención de lavado de activos

**Fecha:** 2026-09-12
**Asistentes:** Carlos Peña, Felipe Arango, Liliana Torres, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-10-05 |
| Carlos Peña | Cerrar la prueba 2 | 2026-09-30 |
| Rubén Cárdenas | Validar el ambiente 4 | 2026-10-05 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-08 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 |
| Natalia Ospina | Confirmar la fecha 7 | 2026-10-05 |
| Liliana Torres | Entregar el punto 8 | 2026-09-17 |

## Lo que se dijo

- Rubén Cárdenas dice que ya entregó «revisar el anexo 3». No se presentó acta.
