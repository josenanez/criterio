<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Riesgos · Originación digital

Fecha: 2026-10-10

Asistentes: Andrés Lozano, Andrés Lozano

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Rubén Cárdenas

Entregar el punto 13

2026-10-14
