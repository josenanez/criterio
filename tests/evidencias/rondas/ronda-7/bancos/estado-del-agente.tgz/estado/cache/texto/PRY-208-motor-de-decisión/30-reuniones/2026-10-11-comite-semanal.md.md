<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Banca Empresas · Motor de decisión

**Fecha:** 2026-10-11
**Asistentes:** Liliana Torres, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 1 | 2026-11-01 |
| Rubén Cárdenas | Entregar el punto 37 | por definir |
