<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Prevención de lavado de activos
Código: PRY-205
Fecha de corte: 2026-10-16
Gerente: Natalia Ospina

Estado declarado
Verde
Avance reportado: 27%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 800.000.000
Comprometido 519.954.178
Ejecutado 408.825.517
Proyección al cierre 819.904.464

Riesgos abiertos
- Concentración del conocimiento en una sola persona
