<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-10-10-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-04-06,2026-04-06,cerrado
Ambiente de pruebas certificado,2026-06-09,2026-06-09,cerrado
Integración con el core,2026-08-12,2026-08-12,cerrado
Piloto con usuarios internos,2026-10-15,2027-01-30,en curso
