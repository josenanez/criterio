<!-- origen: PRY-211-cobranza-digital/10-plan/2025-07-31-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-10-04,2025-10-04,cerrado
Ambiente de pruebas certificado,2025-11-29,2025-11-29,cerrado
Integración con el core,2026-01-23,2026-01-23,cerrado
Piloto con usuarios internos,2026-03-20,2026-03-20,cerrado
Salida a producción,2026-05-15,2026-05-15,cerrado
