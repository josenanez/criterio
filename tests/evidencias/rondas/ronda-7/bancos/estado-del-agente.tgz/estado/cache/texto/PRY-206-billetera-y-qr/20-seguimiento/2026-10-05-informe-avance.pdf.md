<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-05
Gerente: Jorge Medina

Estado declarado
Rojo
Avance reportado: 45%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 6.615.994.177
Ejecutado 1.639.983.493
Proyección al cierre 9.278.874.771

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
