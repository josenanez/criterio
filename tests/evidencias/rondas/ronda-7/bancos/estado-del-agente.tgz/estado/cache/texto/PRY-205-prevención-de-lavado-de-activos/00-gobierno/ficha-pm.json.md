<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-205",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "name": {
 "value": "Prevención de lavado de activos",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Tesorería",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "manager": {
 "value": "Natalia Ospina",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Medios de Pago",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "verde",
 "progress_pct": 27,
 "as_of": "2026-10-16",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-09-01",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "end_date": {
 "value": "2026-06-07",
 "source": "10-plan/2026-10-16-cronograma-v3.csv",
 "source_date": "2026-10-16",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-08-22",
 "start_date": "2025-09-01",
 "end_date": "2026-03-19",
 "reason": "Aprobación del acta de constitución",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2025-10-10",
 "current_date": "2025-10-10",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-16-cronograma-v3.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2025-11-19",
 "current_date": "2025-11-19",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-16-cronograma-v3.csv"
 },
 {
 "name": "Integración con el core",
 "baseline_date": "2025-12-29",
 "current_date": "2025-12-29",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-16-cronograma-v3.csv"
 },
 {
 "name": "Piloto con usuarios internos",
 "baseline_date": "2026-02-07",
 "current_date": "2026-02-07",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-16-cronograma-v3.csv"
 },
 {
 "name": "Salida a producción",
 "baseline_date": "2026-03-19",
 "current_date": "2026-06-07",
 "state": "met",
 "evidence": null,
 "source": "10-plan/2026-10-16-cronograma-v3.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 }
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 800000000,
 "source": "00-gobierno/2025-08-22-acta-constitucion.md",
 "source_date": "2025-08-22",
 "state": "found"
 },
 "committed": {
 "value": 519954178,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 408825517,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 819904464,
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "source_date": "2026-10-16",
 "source_kind": "declaration"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "owner": "no_identificado",
 "source": "2026-10-17-notas-reunion.txt",
 "source_date": "2026-10-17"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-09",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+38 días sobre la línea base vigente",
 "cost_impact": "76.000.000 COP",
 "decision": "pending",
 "decided_by": null,
 "source": "20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md"
 },
 {
 "ref": "CC-02",
 "requested_on": "2026-10-14",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+42 días sobre la línea base vigente",
 "cost_impact": "84.000.000 COP",
 "decision": "pending",
 "decided_by": null,
 "source": "20-seguimiento/2026-10-14-solicitud-cambio-cc-02.md"
 }
 ],
 "commitments": [
 {
 "who": "Sandra Gil",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-08",
 "original_due_date": "2026-09-17",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-08",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "note": "2026-12-08 es la lectura de «08/12/2026» en las notas del 2026-10-17"
 },
 {
 "who": "Carlos Peña",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-17",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-30",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-18",
 "original_due_date": "2026-09-18",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "2026-09-12: dijo en la reunión que ya lo entregó; no se presentó acta; dejó de aparecer en la tabla"
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Validar el ambiente 4",
 "due_date": "2026-10-16",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-4.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-5.md"
 },
 {
 "who": "Paula Céspedes",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-17",
 "original_due_date": "2026-09-17",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-05",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Liliana Torres",
 "what": "Entregar el punto 8",
 "due_date": "2026-09-28",
 "original_due_date": "2026-09-17",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-09-28",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-18",
 "original_due_date": "2026-09-30",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-9.md"
 },
 {
 "who": "Ricardo Salas",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-11-15",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-28",
 "original_due_date": "2026-09-28",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Jorge Medina",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-02",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Felipe Arango",
 "what": "Confirmar la fecha 15",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-03: dijo en la reunión que ya lo entregó; no se presentó acta; dejó de aparecer en la tabla"
 },
 {
 "who": "Liliana Torres",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-02",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "2026-10-10: dijo en la reunión que ya lo entregó; no se presentó acta"
 },
 {
 "who": "Andrés Lozano",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-16",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Camilo Beltrán",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-30",
 "original_due_date": "2026-10-30",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Carlos Peña",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-11-02",
 "original_due_date": "2026-11-02",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Natalia Ospina",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Entregar el punto 24",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana», sin fecha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [
 {
 "path": "2026-10-17-notas-reunion.txt",
 "hash": "345fb80f05644e2a14379ce337c684fe1fcf65acebf0bf8141a0088a95339745",
 "date": "2026-10-17"
 },
 {
 "path": "20-seguimiento/2026-09-26-acta-recibo-5.md",
 "hash": "88baba871652065c615ba0286063ca23721ebf1668d2406fe257e4830272bae0",
 "date": "2026-09-26"
 },
 {
 "path": "20-seguimiento/2026-10-03-acta-recibo-4.md",
 "hash": "d7fd0f6018c44e3c6f671db6c52eef0bd514dc29c847dc3d8f16249a5859ed41",
 "date": "2026-10-03"
 },
 {
 "path": "20-seguimiento/2026-10-03-acta-recibo-9.md",
 "hash": "a65cd60eaea4adbe2b5eccbac24c2d74dc5757107307a8905ab28f1cafa44367",
 "date": "2026-10-03"
 },
 {
 "path": "20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md",
 "hash": "b22f4de9f932333ae49ce0bc1b91d504c33bd6051b5ef0d06546b17b9d21b319",
 "date": "2026-10-09"
 },
 {
 "path": "20-seguimiento/2026-10-14-solicitud-cambio-cc-02.md",
 "hash": "78d7a42c3e1c81a153760e3787a81feb0573a7b115816e89d70c4746f74b37b0",
 "date": "2026-10-14"
 },
 {
 "path": "20-seguimiento/2026-10-16-informe-avance.pdf",
 "hash": "f6d80acb50078711b164934b75fc1a8be2ffd3e154de03f6f7abfb64ac2a7a43",
 "date": "2026-10-16"
 },
 {
 "path": "00-gobierno/2025-08-22-acta-constitucion.md",
 "hash": "23d2566ab0afd818c6993a6bc61160859afcad186aee6e51cf80b5f0e922be6f",
 "date": "2025-08-22"
 },
 {
 "path": "30-reuniones/2026-09-05-comite-semanal.md",
 "hash": "10686b8b1dc38bc74dde9748ae64fe08318320b481b6a0199f07ed2e2d32b4b8",
 "date": "2026-09-05"
 },
 {
 "path": "30-reuniones/2026-09-12-comite-semanal.md",
 "hash": "c69f1a65430f84f49813ce0420c4b867854a316e30b40629a47969b1fe194e24",
 "date": "2026-09-12"
 },
 {
 "path": "30-reuniones/2026-09-19-comite-semanal.md",
 "hash": "9e32047eef5ff92cd2b5ef29c2b0917a79f52d88ac3946aad8b18aad4e0d4399",
 "date": "2026-09-19"
 },
 {
 "path": "30-reuniones/2026-09-26-comite-semanal.md",
 "hash": "39f2d41b963105e3d2d53e93fd262b9986c25eb6b06b506ce5aca360e1b72a0d",
 "date": "2026-09-26"
 },
 {
 "path": "30-reuniones/2026-10-03-comite-semanal.md",
 "hash": "1c7a9175daa06cc531181b6bbdda78c29d4aac4bfa2e5b7638391b5e6f4a9396",
 "date": "2026-10-03"
 },
 {
 "path": "30-reuniones/2026-10-10-comite-semanal.md",
 "hash": "6363aea1e120d1d113eaf10b494cfcf13141512c1a557da47b3cd3e0f6bb0c8a",
 "date": "2026-10-10"
 },
 {
 "path": "10-plan/2025-08-22-cronograma-v1.csv",
 "hash": "9a441d828c6f99963a47dd11c0c2f4fe553f38a6376eb65b67754b176128ebfd",
 "date": "2025-08-22"
 },
 {
 "path": "10-plan/2026-10-16-cronograma-v3.csv",
 "hash": "854341d02f504231e8a627c050b945808caa3c667f64e80c8fafbc420037bfeb",
 "date": "2026-10-16"
 }
 ],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
