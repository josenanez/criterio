<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-16
Gerente: Camilo Beltrán

Estado declarado
Verde
Avance reportado: 84%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- La prueba de carga no alcanzó el umbral pactado y se repite
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 933.765.687
Ejecutado 552.845.850
Proyección al cierre 2.235.478.366

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Cambio regulatorio en discusión que puede mover el alcance
