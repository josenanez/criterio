<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de proveedores
Código: PRY-210
Fecha de corte: 2026-10-16
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 78%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.104.140.921
Ejecutado 1.232.773.531
Proyección al cierre 3.400.504.109

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
