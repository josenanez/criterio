<!-- origen: PRY-203-open-banking/00-gobierno/2026-05-06-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Medios de Pago

Patrocinador: Carlos Peña

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Medios de Pago

Producto asociado: APIs de datos

Fecha de aprobación: 2026-05-06

Objetivo del negocio

Entregar open banking para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Medios de Pago el 2026-05-06.

Fechas comprometidas

Fecha

Inicio

2026-05-16

Cierre

2027-02-27

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
