<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2026-01-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core de depósitos

Código: PRY-201

Área dueña: Banca Hipotecaria

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Medios de Pago

Producto asociado: cuenta de ahorros

Fecha de aprobación: 2026-01-22

Objetivo del negocio

Entregar core de depósitos para Banca Hipotecaria.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Medios de Pago el 2026-01-22.

Fechas comprometidas

Fecha

Inicio

2026-02-01

Cierre

2026-10-15

Criterio de éxito

Core de depósitos en producción y medido.

Dependencias declaradas

• Ninguna declarada
