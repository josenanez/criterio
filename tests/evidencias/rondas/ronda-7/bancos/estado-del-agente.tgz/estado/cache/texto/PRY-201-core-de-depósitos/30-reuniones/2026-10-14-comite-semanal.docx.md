<!-- origen: PRY-201-core-de-depósitos/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Medios de Pago · Core de depósitos

Fecha: 2026-10-14

Asistentes: Sandra Gil, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 32

2026-10-30

Beatriz Cuéllar

Entregar el punto 36

2026-10-31
