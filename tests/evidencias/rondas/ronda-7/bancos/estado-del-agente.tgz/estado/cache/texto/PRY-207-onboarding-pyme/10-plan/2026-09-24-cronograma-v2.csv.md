<!-- origen: PRY-207-onboarding-pyme/10-plan/2026-09-24-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-08,2026-09-08,cerrado
Ambiente de pruebas certificado,2027-01-12,2027-01-12,en curso
Integración con el core,2027-05-17,2027-05-17,en curso
Piloto con usuarios internos,2027-09-20,2027-11-17,en curso
