<!-- origen: PRY-200-originación-digital/10-plan/2026-03-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-21 | 2026-05-21 | cerrado
Ambiente de pruebas certificado | 2026-07-30 | 2026-07-30 | cerrado
Integración con el core | 2026-10-08 | 2026-10-08 | cerrado
Piloto con usuarios internos | 2026-12-17 | 2026-12-17 | en curso
