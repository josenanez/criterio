<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-10-16-cronograma-v3.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-10-10,2025-10-10,cerrado
Ambiente de pruebas certificado,2025-11-19,2025-11-19,cerrado
Integración con el core,2025-12-29,2025-12-29,cerrado
Piloto con usuarios internos,2026-02-07,2026-02-07,cerrado
Salida a producción,2026-03-19,2026-06-07,cerrado
