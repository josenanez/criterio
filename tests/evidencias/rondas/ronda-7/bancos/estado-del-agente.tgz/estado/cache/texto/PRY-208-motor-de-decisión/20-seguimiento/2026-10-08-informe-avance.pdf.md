<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de decisión
Código: PRY-208
Fecha de corte: 2026-10-08
Gerente: Liliana Torres

Estado declarado
Rojo
Avance reportado: 43%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.144.570.703
Ejecutado 978.108.424
Proyección al cierre 4.370.533.551

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
