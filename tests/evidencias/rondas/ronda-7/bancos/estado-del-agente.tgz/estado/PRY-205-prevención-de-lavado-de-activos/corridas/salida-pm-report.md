# PRY-205 Prevención de lavado de activos — semana del 2026-10-10 al 2026-10-17

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrar nada nuevo.

## Antes de leer el informe: la declaración
Se trabaja sin interfaz y nadie respondió, así que **hoy no se pidió ni se recibió declaración del gerente (Natalia Ospina)**. Samuel no declara en su lugar ni sugiere un estado. Lo que sigue usa la declaración que ya consta en un documento del gerente, y se identifica como tal.

**Declaración registrada (no de hoy):** verde · 27 % · al 2026-10-16 · fuente: `20-seguimiento/2026-10-16-informe-avance.pdf` (1 día de antigüedad, vigente)
**Sustento documental:** **contradicho**. Hay 0 fuentes de evidencia en la ficha; las 3 de declaración son del propio gerente.
**Lo que el semáforo no explica:** variance_time, progress_vs_plan, milestone_met_without_evidence (×5), commitment_overdue (×8), commitment_rescheduled (×3).

Un verde con cinco señales que no explica sale con las dos cosas juntas: **verde declarado, 21 alertas abiertas.**

## Qué cambió esta semana
No se puede comparar: este es el primer snapshot del proyecto (2026-10-17) y el diff contra la corrida anterior vuelve vacío (0 cambios). Esto no quiere decir que nada se movió. Lo que **entró a los documentos** esta semana:

| Qué | Estaba | Está |
|---|---|---|
| Cronograma | v1, salida a producción 2026-03-19 | v3 (2026-10-16), salida a producción 2026-06-07 |
| Solicitudes de cambio | ninguna en la ficha | CC-01 (2026-10-09) y CC-02 (2026-10-14), ambas «pendiente de presentación al comité» |
| Informe de avance | n/d | 2026-10-16: verde, 27 % |
| Reunión | n/d | notas del 2026-10-17 |

## Lo que sigue igual y sigue mal
Sin una corrida anterior, «desde» y «días así» salen de las fechas de los propios documentos:

| Qué | Desde | Días así |
|---|---|---|
| «Diseño funcional aprobado» cerrado sin evidencia | 2025-10-10 | 372 |
| «Ambiente de pruebas certificado» cerrado sin evidencia | 2025-11-19 | 332 |
| «Integración con el core» cerrado sin evidencia | 2025-12-29 | 292 |
| «Piloto con usuarios internos» cerrado sin evidencia | 2026-02-07 | 252 |
| «Salida a producción» cerrado sin evidencia | 2026-06-07 | 132 |
| Compromiso vencido: Paula Céspedes, actualizar la matriz 6 | 2026-09-17 | 30 |
| Compromiso vencido: Rubén Cárdenas, revisar el anexo 3 | 2026-09-18 | 29 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre (salida a producción) | 2026-03-19 | 2026-06-07 | **+80 días (40,2 %)**, tanto contra la original como contra la vigente en el cálculo |
| Presupuesto | 800.000.000 COP | 800.000.000 COP | proyección 819.904.464 COP: +2,5 % |

Replanificaciones contadas: **0**. Pero el cronograma v3 (2026-10-16) mueve la fecha de salida 80 días y la carpeta no trae una solicitud de cambio aprobada que lo respalde (CC-01 y CC-02 están pendientes y piden +38 y +42 días *sobre la vigente*). Hay que aclarar con qué autoridad se movió esa fecha. El cálculo no lo marca como cambio no autorizado, porque lo que mide son los cambios registrados.

**Avance:** se declara 27 %, pero el cronograma tiene los 5 hitos en «cerrado» y el plan sostiene 100 %. Brecha: 73 puntos. O el avance está mal declarado o los hitos están mal cerrados; los dos documentos no pueden ser ciertos a la vez.

**Cambios pendientes que no están en las cifras:** CC-01 (+38 días, 76.000.000 COP) y CC-02 (+42 días, 84.000.000 COP): **+160.000.000 COP y +80 días si pasan**. Con eso el aprobado pasaría de 800 a 960 millones y la proyección actual (819,9) quedaría dentro. Cada uno suma sobre la línea base vigente y no sobre la otra; si se aprueban ambos, el efecto sobre la fecha hay que recalcularlo.

### Hitos de las próximas cuatro semanas
Ninguno en el cronograma: los cinco están cerrados, el último con fecha 2026-06-07. Un proyecto al 27 % sin hitos por delante es un hallazgo en sí.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 519.954.178 (65,0 %) | 408.825.517 (51,1 %) | 819.904.464 | **280.045.822** |

Disponible real = aprobado − comprometido. No es aprobado − ejecutado (391.174.483), que es 111 millones más optimista.

## Abierto
**Reprogramados:**
- Sandra Gil, «Enviar el documento 1»: **6 veces**; original 2026-09-17, hoy 2026-12-08 (+82 días)
- Carlos Peña, «Cerrar la prueba 2»: **5 veces**; original 2026-09-20, hoy 2026-11-17
- Ricardo Salas, «Cerrar la prueba 10»: 3 veces; original 2026-10-02, hoy 2026-11-15

**Vencidos sin evidencia (8):** Paula Céspedes, matriz 6 (30 d) · Rubén Cárdenas, anexo 3 (29 d) · Liliana Torres, punto 8 (19 d) · Andrés Lozano, anexo 11 (19 d) · Jorge Medina, ambiente 12 (15 d) · Carlos Peña, diseño 13 (9 d) · Andrés Lozano, prueba 18 (6 d) · María Restrepo, anexo 19 (1 d)

**Sin fecha (2):** Felipe Arango, confirmar la fecha 15 · Laura Vélez, mandar el ajuste del presupuesto («la otra semana»)

**RAID:** 2 riesgos, ambos sin dueño, y ningún supuesto, incidencia ni dependencia. (1) «Concentración del conocimiento en una sola persona», del informe de avance del 2026-10-16. (2) *El proveedor podría no llegar con el equipo completo para la siguiente fase*, dicho en la reunión del 2026-10-17 sin que nadie lo anotara como riesgo. La ficha no trae fechas de revisión, así que no se pueden contar días sin movimiento.

**Proveedor:** la ficha no trae entregables de proveedor (`vendors` vacío); hay una revisión con el proveedor para el 2026-10-27 (Óscar Ramírez).

## Lo que necesito de alguien
- **Natalia Ospina:** hacer la declaración de la semana y explicar el 27 % frente a 5 hitos cerrados.
- **Natalia Ospina / comité (material de comité, excede al gerente):** CC-01 y CC-02 siguen sin presentarse. Tienen fecha de comité el 2026-10-31.
- **Natalia Ospina:** indicar quién autorizó mover la salida a producción del 2026-03-19 al 2026-06-07 en el cronograma v3.
- **Sandra Gil y Carlos Peña:** llevan 6 y 5 reprogramaciones. Pasan del umbral (3) y piden una decisión, no otra fecha.
- **Laura Vélez / Felipe Arango:** fecha.
- **Natalia Ospina:** asignar dueño a los dos riesgos del RAID.

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto. 10 campos de identidad, plan y dinero tienen fuente de 2025-08-22 (14 meses, por encima del límite de 12). No hay ninguna evidencia independiente de los 5 hitos «cerrados».
**Silencio:** último documento hace 0 días (2026-10-17) · última reunión hace 0 días (2026-10-17). El proyecto no está en silencio: lo que falta es sustento, no actividad.

---
Ficha: `records/PRY-205.json` · corte 2026-10-17 · 3 campos sin dato · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.13
