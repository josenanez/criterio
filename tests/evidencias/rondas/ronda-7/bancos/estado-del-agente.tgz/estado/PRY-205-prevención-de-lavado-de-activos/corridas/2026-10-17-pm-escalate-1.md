# Corrida del 2026-10-17 · pm-escalate

1 proyectos · 47 s · 21 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `milestone_met_without_evidence` | 5 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |

Paquete de escalamiento: autoridad no declarada en el acta, CC-01 y CC-02 pendientes sin base de fechas creíble, tres compromisos reprogramados 3+ veces. Impacto: 0 proyectos alcanzados porque el estado solo tiene PRY-205 y no hay dependencias declaradas. No sabe: qué incluye cada ampliación, si CC-01 y CC-02 se acumulan, consecuencia con fecha, dolientes externos.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17, comprobante en `.criterio/terminos/`). No se pidió ni se registró nada nuevo.

No se indicó tema; se trabajó sobre lo que ya está marcado como escalable en la ficha de PRY-205.

## Para decisión — PRY-205 Prevención de lavado de activos · 2026-10-17

### Primer punto: la autoridad del gerente no está declarada

El acta de constitución (2025-08-22) no dice qué puede decidir Natalia Ospina: la ficha tiene `identity.authority` en `not_found`. Sin eso no se puede afirmar que CC-01 y CC-02 excedan su autoridad ni decir quién los aprueba. Por la regla del comando, este es el primer punto que escala, antes que los cambios.

### ¿Se aprueba CC-01 (+38 días, +76 M COP), CC-02 (+42 días, +84 M COP), ambos o ninguno, y con qué línea base de fechas?

**Quién decide:** no se puede decir según el acta (no declara autoridad). El acta nombra al Comité de Medios de Pago como quien aprobó el presupuesto y a Rubén Cárdenas como patrocinador. Ambas solicitudes dicen «Pendiente de presentación al comité». · **Si no se decide hoy:** ningún documento da una fecha de vencimiento ni una consecuencia con fecha; no la invento. Lo que sí consta: el próximo comité es el 2026-10-31 (configuración y nota del 17 de octubre: «en dos semanas»), y hasta entonces las dos solicitudes siguen pendientes (CC-01 lleva 8 días, CC-02 lleva 3). Sin una consecuencia con fecha este punto corre el riesgo de aplazarse; hay que pedirla al patrocinador o al proveedor.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar solo CC-01 | Ampliación de alcance (la solicitud no dice cuál) | +38 días sobre la línea base vigente → cierre 2026-07-15 | +76.000.000 COP |
| B. Aprobar solo CC-02 | Ampliación de alcance (la solicitud no dice cuál) | +42 días → cierre 2026-07-19 | +84.000.000 COP |
| C. Aprobar ambos | Las dos ampliaciones | No calculable: las dos dicen «sobre la línea base vigente» y no consta si se suman | Hasta +160.000.000 COP si son independientes |
| D. No aprobar ninguno | Sin ampliación | Sin cambio sobre 2026-06-07 | Sin cambio sobre lo aprobado, 800.000.000 COP |

Lo que los documentos no dicen y por eso no está en la tabla: qué incluye cada ampliación, si CC-01 y CC-02 se excluyen o se acumulan, y qué pasa con el alcance actual si se rechazan (D).

**Recomiendo:** no decidir A, B ni C todavía y llevar al comité el 2026-10-31 un solo paquete con ambas solicitudes y una línea base de fechas reconstruida. Razón: las dos solicitudes se miden contra una línea base cuyo cierre (2026-06-07) ya pasó hace más de cuatro meses con el proyecto declarado al 27 %, de modo que «+38 días» y «+42 días» no tienen un punto de partida creíble. Esta es mi recomendación; el comité decide.

### Lo que hay que saber antes del comité

- **Presupuesto.** Aprobado 800.000.000 COP. La proyección declarada en el informe del 2026-10-16 ya es 819.904.464 COP, 19.904.464 por encima, antes de cualquier cambio. Con los dos cambios sería hasta 979.904.464 COP, si la proyección no los incluye. No consta si los incluye.
- **Fechas.** Cierre del acta: 2026-03-19. Cierre en el cronograma v3 (2026-10-16): 2026-06-07, 80 días más. La ficha solo tiene la línea base 1; no hay registro de aprobación de ese corrimiento.
- **Contradicción en el cronograma v3.** «Salida a producción» figura como cerrada (2026-06-07) mientras el informe de avance declara 27 % y estado verde. Ninguno de los cinco hitos «cerrados» tiene evidencia de cierre en la carpeta. No lo resuelvo: se dice para que el comité no reciba un verde sin contraste.
- **Compromisos reprogramados tres veces o más** (criterio de escalamiento; los listo porque corresponden, no los pongo como decisión): Sandra Gil, «Enviar el documento 1», 6 reprogramaciones, de 2026-09-17 a 2026-12-08; Carlos Peña, «Cerrar la prueba 2», 4, de 2026-09-20 a 2026-11-17; Ricardo Salas, «Cerrar la prueba 10», 3, de 2026-10-02 a 2026-11-15. No consta si sus dolientes están fuera del proyecto, que es lo que lo convierte en escalamiento y no en una llamada.
- **Riesgo del proveedor sin dueño.** En la reunión del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo. La ficha lo tiene sin responsable, y no hay proveedores ni dependencias registrados (el acta dice «Ninguna declarada»). No escala hoy, pero debe registrarse antes del comité porque afecta cualquier fecha que se apruebe. Óscar Ramírez tiene la revisión con el proveedor el 2026-10-27, antes del comité.

### A quién alcanza

El cálculo de impacto (`impact`, 38 y 42 días) devuelve **cero proyectos alcanzados y cero hitos alcanzados**. No es un «no hay impacto»: el estado solo contiene PRY-205 y el acta no declara dependencias con otros proyectos, así que no hay contra qué cruzar. Si PRY-205 tiene dependencias que no se escribieron, no aparecen. Tampoco se calcula cuántos días se mueve cada proyecto alcanzado: eso necesita holgura por actividad y la ficha no la tiene.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| (ninguno en el estado) | — | — | — |

### Mis hitos por los que pasa

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| (ninguno) | — | El cálculo no devuelve hitos: los cinco del cronograma v3 figuran cerrados; el cierre, 2026-06-07, pasaría a 2026-07-15 (+38) o 2026-07-19 (+42) |

### De dónde sale esto

- Autoridad no declarada: `00-gobierno/2025-08-22-acta-constitucion.md` (sin sección de autoridad; dependencias «Ninguna declarada»); `records/PRY-205.json`, `identity.authority` en `not_found`.
- CC-01: `20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md`. CC-02: `20-seguimiento/2026-10-14-solicitud-cambio-cc-02.md`.
- Presupuesto aprobado: acta. Proyección y avance 27 %: `20-seguimiento/2026-10-16-informe-avance.pdf`.
- Fechas e hitos: `10-plan/2026-10-16-cronograma-v3.csv`; línea base 1 en el acta.
- Compromisos reprogramados: `30-reuniones/2026-09-05` a `2026-10-10-comite-semanal.md` y `2026-10-17-notas-reunion.txt`.
- Riesgo del proveedor: `2026-10-17-notas-reunion.txt`.
- Próximo comité 2026-10-31: `.criterio/proyecto/PRY-205/config.json`.

### Lo que este paquete no hace

No lleva el punto al comité ni le escribe a nadie; eso es de la gerente. Y lo que falta antes de subirlo: la autoridad por escrito (patrocinador), qué incluye cada ampliación, y una consecuencia con fecha.
