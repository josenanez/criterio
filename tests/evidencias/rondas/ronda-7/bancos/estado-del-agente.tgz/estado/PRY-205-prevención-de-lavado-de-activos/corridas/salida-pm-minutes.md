# Acta — PRY-205 Prevención de lavado de activos · 2026-10-17
**Asistieron:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Elena Duarte, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, María Restrepo, Natalia Ospina, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** las notas no traen agenda, así que no se puede decir. Con compromisos abiertos y sin estar presentes: Rubén Cárdenas (patrocinador; «Revisar el anexo 3», vencido hace 29 días) y Felipe Arango («Confirmar la fecha 15», sin fecha).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-12-08 | **Reprogramado 6 veces.** Original 2026-09-17; antes 10-05, 10-16, 10-26, 11-06, 11-24. Son 82 días de corrimiento. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; no dice si es la del 19 o la del 26 de octubre, y no se eligió) |

Con ella son 2 compromisos sin fecha en el expediente; el otro es Felipe Arango, «Confirmar la fecha 15», del 2026-09-26.

## Decisiones
Las notas no recogen ninguna decisión: ni quién decidió ni qué se descartó.

## Quedó sin decidir
Las notas no lo dicen. No se infiere.

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | No atribuido («se comentó») | Riesgo | **No.** El informe del 2026-10-16 solo declara «Concentración del conocimiento en una sola persona». Queda en el RAID sin responsable (`no_identificado`). |

## Cerrado en esta reunión
Nada. (Sección omitida: no hay documento que cierre ningún compromiso.)

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-31) | Comité semanal | Notas, 2026-10-17 · `config.json` (`cycle.committee: weekly`) y las seis actas semanales del 09-05 al 10-10 |

No es un campo de la ficha que cambie solo, pero conviene confirmar si la cadencia cambió o es una excepción. Ningún otro campo (patrocinador, fechas, comité) cambia en estas notas.

## Sin resolver de la transcripción
- «08/12/2026» (Sandra Gil): se leyó 8 de diciembre, porque 12 de agosto ya pasó y las fechas anteriores van en ascenso. Es una lectura, no lo dice la nota.
- «lo de enviar el documento 1 no alcanzó»: la fecha vigente era 2026-11-24, que aún no llega. La nota no dice qué fecha no se alcanzó.
- «Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27»: no dice quién revisa ni a qué proveedor; se registró a Óscar como doliente por la forma de la línea. Confírmalo con él.
- «la otra semana» (Laura Vélez): sin día.

---
**Cifras recalculadas (`compute`, sin `record_issues`):** compromisos abiertos o vencidos con la reunión incluida, 8 vencidos, 2 sin fecha, 3 reprogramados 3 o más veces (Sandra Gil 6, Carlos Peña 5, Ricardo Salas 3). Estado declarado verde el 2026-10-16, contradicho por 5 señales; el acta no lo cambia.

**Siguiente:** `/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por esta acta, salvo que confirmes el cambio de cadencia. El acta es tuya: no se guardó en tu carpeta de reuniones.
