## Listo — PRY-205 · Prevención de lavado de activos

Preguntas de la instalación (sesión sin interfaz, tomé lo sugerido en cada una):
- Quién eres y qué proyecto es: Natalia Ospina, gerente de PRY-205, según el acta de constitución del 2025-08-22.
- Reunión de seguimiento: los sábados (las seis minutas y las notas del 2026-10-17 caen en sábado). Las notas dicen «próxima reunión en dos semanas», así que la siguiente queda para el 2026-10-31.
- Dónde guardo lo que encuentre: `estado/PRY-205-prevención-de-lavado-de-activos`.
- Términos: ver abajo.

**Lo que miré:** 16 documentos · 6 minutas de comité semanal más las notas de reunión del 2026-10-17 · la última minuta es del 2026-10-10 · los 16 se pudieron leer. Leí las 6 minutas de la más vieja a la más nueva, las 3 actas de recibo, el cronograma v1 y el v3, las 2 solicitudes de cambio y el informe de avance del 2026-10-16.
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-17 para la versión 0.3.13 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 b8d0cca7fea66fcb… (md) · 28e9cfed31cb47fb… (pdf)

### Lo que está abierto, y cuántas veces se ha movido
26 compromisos en total: 3 cumplidos con acta, 8 vencidos sin evidencia, 15 abiertos (2 de ellos sin fecha).

**Reprogramados** (primera promesa → fecha vigente):

| Quién | Qué | Primera promesa | Vigente | Veces movido |
|---|---|---|---|---|
| Sandra Gil | Enviar el documento 1 | 2026-09-17 (comité 2026-09-05) | 2026-12-08 (notas 2026-10-17) | 6 |
| Carlos Peña | Cerrar la prueba 2 | 2026-09-20 (comité 2026-09-05) | 2026-11-17 (comité 2026-10-10) | 5 |
| Ricardo Salas | Cerrar la prueba 10 | 2026-10-02 (comité 2026-09-19) | 2026-11-15 (comité 2026-10-10) | 3 |

El documento 1 se prometió seis veces más después de la primera y ninguna se cumplió. La fecha 2026-12-08 sale de «08/12/2026» en las notas, leído como día/mes.

**Vencidos sin evidencia** (la fecha pasó y ningún acta lo prueba):

| Quién | Qué | Venció | Días | Citado en |
|---|---|---|---|---|
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 | 30 | comité 2026-09-12 |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-18 | 29 | comité 2026-09-05 |
| Liliana Torres | Entregar el punto 8 | 2026-09-28 | 19 | comité 2026-09-12 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 | 19 | comité 2026-09-19 |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 | 15 | comité 2026-09-19 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 | 9 | comité 2026-09-26 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-11 | 6 | comité 2026-10-03 |
| María Restrepo | Revisar el anexo 19 | 2026-10-16 | 1 | comité 2026-10-03 |

Siguen figurando en la última tabla del comité (2026-10-10) con la fecha ya vencida.

**Cumplidos con acta:** Aprobar el diseño 5 (Felipe Arango, acta del 2026-09-26) · Validar el ambiente 4 (Rubén Cárdenas, acta del 2026-10-03; se había movido 2 veces) · Enviar el documento 9 (Javier Hoyos, acta del 2026-10-03; se había movido 1 vez).

**Dicho como entregado, sin acta:** tres compromisos se dieron por entregados de palabra y no se cerraron porque no hay acta. «Revisar el anexo 3» (Rubén Cárdenas, comité 2026-09-12) está en la lista de vencidos; «Confirmar la fecha 15» (Felipe Arango, comité 2026-10-03) y «Enviar el documento 17» (Elena Duarte, comité 2026-10-10) siguen abiertos. Los tres dejaron de aparecer en la tabla de la reunión siguiente.

### Sin fecha
No pueden estar vencidos, y por eso mismo son los que desaparecen de los informes:
- Felipe Arango · Confirmar la fecha 15 · «por definir» en el comité del 2026-09-26.
- Laura Vélez · Mandar el ajuste del presupuesto · «la otra semana» en las notas del 2026-10-17.

Camilo Beltrán · Validar el ambiente 20 empezó sin fecha («por definir», 2026-10-03) y recibió la 2026-10-30 en el comité del 2026-10-10: es su primera fecha, no una reprogramación.

### Lo que dicen los documentos frente a lo declarado
El informe del 2026-10-16 declara **verde** con 27 % de avance. Las señales que levantó el cálculo contra esa declaración:
- **Cronograma contra avance:** el cronograma v3 declara los 5 hitos cerrados (el plan sostiene 100 %), contra el 27 % declarado: 73 puntos de diferencia.
- **Hitos cerrados sin acta:** los 5 están declarados cerrados y ningún acta de recibo nombra ninguno. Las tres actas que hay son de compromisos del comité, no de hitos.
- **Atraso:** la salida a producción pasó del 2026-03-19 (acta de constitución) al 2026-06-07 (cronograma v3): 80 días, 40,2 % sobre la línea base original.
- **Compromisos:** los 8 vencidos y los 3 reprogramados de arriba.
- **Presupuesto (según el informe, declaración del gerente):** aprobado 800.000.000 COP · comprometido 519.954.178 (65,0 %) · ejecutado 408.825.517 (51,1 %) · proyección al cierre 819.904.464, 2,5 % sobre lo aprobado.
- **Solicitudes de cambio:** CC-01 (2026-10-09: +38 días, 76.000.000 COP) y CC-02 (2026-10-14: +42 días, 84.000.000 COP), ambas ampliación de alcance y ambas «pendiente de presentación al comité». No aparecen en ninguna minuta.
- **Riesgo que nadie registró:** en las notas del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y no quedó anotado como riesgo. El informe solo lista «concentración del conocimiento en una sola persona».

Samuel no declara el estado: eso lo declaras tú. Esto es contra qué lo estás declarando.

### Qué le falta a tu carpeta
- Actas de recibo de los 5 hitos del cronograma: sin ellas un hito cerrado se ve igual que uno que no lo está.
- Acta de recibo de lo que se dijo entregado en comité (anexo 3, fecha 15, documento 17).
- El acta de constitución no declara la autoridad del gerente, la fase ni un producto asociado («No aplica»), y su alcance es genérico («Componente 1, 2, 3»), con la dependencia «ninguna declarada».
- La reunión del 2026-10-17 solo dejó notas sueltas, no una minuta con tabla de compromisos. Las notas no traen los compromisos que ya estaban abiertos, así que de esa reunión solo sé lo que dicen esas cuatro líneas.
- El acta de constitución es de hace 14 meses y no hay confirmación posterior de patrocinador, presupuesto aprobado ni alcance.

**Cuándo vuelvo:** el 2026-10-31, la próxima reunión según las notas del 2026-10-17 (dos semanas) y los sábados de ahí en adelante.
