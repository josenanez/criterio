## Reunión de seguimiento — PRY-205 Prevención de lavado de activos · 2026-10-31
7 puntos · 48 minutos · 12 personas requeridas

Fecha tomada de `cycle.committee_next`. No se indicó duración: la agenda está armada para 48 minutos. Si la reunión es más corta, se corta por el final de la lista (primero «Vence antes de la próxima», luego el riesgo del proveedor).
No hay corrida anterior contra la que comparar (`diff` es la línea de partida), así que no se puede decir qué cambió desde una agenda previa. Los candidatos salen de la ficha y de los compromisos al 2026-10-17.

### Lo que no se destraba solo

> **[1] Qué bloquea «Enviar el documento 1» y quién lo puede quitar** · 8 min · **Sandra Gil, Natalia Ospina, Rubén Cárdenas**
> Prometido para el 2026-12-08, y antes para el 11-24, el 11-06, el 10-26, el 10-16 y el 10-05; la primera promesa fue el 09-17. Seis reprogramaciones en seis reuniones seguidas, 82 días de corrimiento.
> Fuente: actas del comité 2026-09-05 a 2026-10-10 y `2026-10-17-notas-reunion.txt`. La fecha 12-08 es una lectura de «08/12/2026» (no la confirma la nota).
> **Si no se resuelve hoy:** se reprograma por séptima vez; el entregable suma 82 días de corrimiento sin que nadie haya nombrado la causa.

> **[2] Qué bloquea «Cerrar la prueba 2», y cuándo aprueba Carlos Peña los diseños** · 8 min · **Carlos Peña, Natalia Ospina**
> Prometido para el 2026-11-17, y antes para el 11-08, el 10-28, el 10-09 y el 09-30; la primera promesa fue el 09-20. Cinco reprogramaciones. Además tiene vencido «Aprobar el diseño 13» (2026-10-08) y «Aprobar el diseño 21» vence el 10-20.
> Fuente: actas del comité 2026-09-05 a 2026-10-10; 2026-09-26 (diseño 13); 2026-10-10 (diseño 21).
> **Si no se resuelve hoy:** la prueba 2 pasa del 11-17 sin fecha firme, y con ella lo que dependa de ella.

> **[3] Qué bloquea «Cerrar la prueba 10»** · 4 min · **Ricardo Salas**
> Prometido para el 2026-11-15, y antes para el 10-31 y el 10-11; la primera promesa fue el 10-02. Tres reprogramaciones: cruzó el umbral de bloqueo.
> Fuente: actas del comité 2026-09-19, 09-26, 10-03 y 10-10.
> **Si no se resuelve hoy:** cuarta reprogramación; hoy el corrimiento acumulado es de 44 días.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-18 | Dijo el 09-12 que ya lo entregó; no hay acta ni documento. Que presente el documento o dé fecha. Requiere que él esté. | 3 |
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 | Fecha firme o decir qué lo impide | 1 |
| Liliana Torres | Entregar el punto 8 (ya reprogramado, del 09-17 al 09-28) | 2026-09-28 | Fecha firme | 2 |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 | Fecha firme | 1 |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-11 | Fecha firme; suma dos vencidos | 1 |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 | Fecha firme | 1 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 | Se trata en el punto 2 | — |
| María Restrepo | Revisar el anexo 19 | 2026-10-16 | Fecha firme | 1 |

«Desde» es la fecha prometida; al 10-31 cada atraso suma 14 días más. Fuente: actas de comité 2026-09-05 a 2026-10-10 (cada fila con su fecha de origen en la ficha).

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **CC-01** (2026-10-09): ampliación de alcance, +38 días sobre la línea base vigente, 76.000.000 COP. Estado: «Pendiente de presentación al comité». | El comité; el documento no dice quién autoriza. Confirmar si es Rubén Cárdenas (patrocinador). | Lleva 22 días en el limbo, y el trabajo de la ampliación o se hace sin autorización o no se hace. | 10 (los dos) |
| **CC-02** (2026-10-14): ampliación de alcance, +42 días sobre la línea base vigente, 84.000.000 COP. Estado: «Pendiente de presentación al comité». | Ídem | Ídem. Los dos son solicitudes de la misma persona, de la misma clase y con cinco días de diferencia; hay que decidir si se evalúan juntas o si una reemplaza la otra. | (incluido) |
| **Ajuste del presupuesto** (Laura Vélez, «la otra semana», sin día) | Laura Vélez, con el comité | Las dos solicitudes se deciden sin el ajuste. La proyección declarada (819.904.464 COP) ya supera lo aprobado (800.000.000 COP). | (incluido) |

Fuente: `20-seguimiento/2026-10-09-solicitud-cambio-cc-01.md`, `2026-10-14-solicitud-cambio-cc-02.md`, notas del 2026-10-17; cifras de dinero de la ficha, `2026-10-16-informe-avance.pdf` (declaradas, no auditadas).

### Riesgo del proveedor sin dueño

> **[5] Un dueño para el riesgo del proveedor** · 4 min · **Óscar Ramírez, Natalia Ospina**
> «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase»; nadie lo anotó como riesgo ni lo dijo con nombre. Hoy está en el RAID sin responsable. Qué tiene que quedar resuelto: un dueño, y que la revisión con el proveedor del 10-27 (Óscar Ramírez) lo incluya.
> Fuente: `2026-10-17-notas-reunion.txt`.
> **Si no se resuelve hoy:** el riesgo sigue sin dueño y sin mitigación hasta la fase siguiente.

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Entregar el punto 24 | 2026-10-19 |
| Carlos Peña | Aprobar el diseño 21 | 2026-10-20 (punto 2) |
| Javier Hoyos | Actualizar la matriz 14 (reprogramado una vez) | 2026-10-24 |
| Elena Duarte | Enviar el documento 17 (dijo el 10-10 que ya lo entregó; no hay acta) | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 |
| Camilo Beltrán | Validar el ambiente 20 | 2026-10-30 |
| Natalia Ospina | Confirmar la fecha 7 (reprogramado dos veces) | 2026-10-31 |

Se leen en 4 minutos, al final y sin discusión; solo se habla de los que al 10-31 hayan vencido sin documento. Sus dueños no tienen que estar, salvo Natalia Ospina (el suyo vence ese día).

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| **Felipe Arango** · Confirmar la fecha 15 (sin fecha desde 2026-09-26, 21 días al 10-17) | No estuvo el 10-17 y dijo el 10-03 que ya lo entregó; no hay acta. Sin su doliente no se puede cerrar. | Mensaje directo a Felipe antes del comité: documento o fecha. |
| **Laura Vélez** · Mandar el ajuste del presupuesto, sin día | Entra al punto de los cambios solo si manda la fecha; sin ella no hay nada que discutir | Pedirle el día por mensaje. |
| La causa de fondo de los puntos 1 a 3 (si es una dependencia del patrocinador o de otro equipo) | Si excede la autoridad de la gerente (Natalia Ospina), no se resuelve en una reunión de seguimiento. | `/pm-escalate` para formularla como decisión del comité. No lo he hecho. |

### Anexo — sin cambios desde el 2026-10-10
Una línea cada uno; no se repasan.
- Natalia Ospina · Confirmar la fecha 23 · 2026-11-01
- Paula Céspedes · Actualizar la matriz 22 · 2026-11-02
- Liliana Torres · Entregar el punto 16 · 2026-11-02 (reprogramado una vez)
- Cerrados con documento: Rubén Cárdenas, «Validar el ambiente 4» (acta-recibo-4); Felipe Arango, «Aprobar el diseño 5» (acta-recibo-5); Javier Hoyos, «Enviar el documento 9» (acta-recibo-9).

---
**Lo que no sé y conviene confirmar antes de convocar:**
- La duración real de la reunión: se asumieron 50 minutos.
- La cadencia: las notas del 10-17 dicen «próxima reunión en dos semanas» y la configuración dice comité semanal. Se usó 2026-10-31, que es lo que dice `committee_next`. Si el comité del 10-24 sí se cita, esta agenda se parte.
- Si Rubén Cárdenas (patrocinador, ausente el 10-17) estará en la sala: sin él los puntos 1 y «anexo 3» y la decisión de los cambios no avanzan.
- Los nombres de los compromisos son los que aparecen en las actas («documento 1», «prueba 2»…); los documentos no dicen qué son. Se muestran tal cual.
- Las notas del 10-17 no recogen decisiones ni lo que quedó pendiente de decidir; los únicos pendientes de decisión que hay son los dos cambios CC-01 y CC-02.

**Después:** convocar es tuyo. Cuando termine la reunión, `/pm-minutes` sobre las notas; los compromisos nuevos entran a `/pm-commitments`.
