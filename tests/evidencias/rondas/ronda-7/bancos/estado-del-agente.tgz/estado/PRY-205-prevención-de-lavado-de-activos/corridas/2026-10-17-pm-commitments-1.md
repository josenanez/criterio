# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 29 s · 21 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `milestone_met_without_evidence` | 5 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |

Reprogramados: Sandra Gil (6 veces), Carlos Peña (5), Ricardo Salas (3); 8 vencidos sin evidencia; 2 sin fecha

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-205 Prevención de lavado de activos · al 2026-10-17

26 compromisos en la ficha: 15 abiertos, 8 vencidos sin evidencia, 3 cerrados con documento. Dos de los abiertos no tienen fecha.

### Se viene reprogramando

> **Sandra Gil** · Enviar el documento 1
> Prometido para el 08-12-2026, y antes para el 24-11, el 06-11, el 26-10, el 16-10 y el 05-10; la primera promesa fue el 17-09.
> **Seis reprogramaciones en seis reuniones seguidas. Es un bloqueo que nadie ha nombrado, no un problema de seguimiento.**
> (Fuente: 30-reuniones/2026-09-05 … 2026-10-10 y 2026-10-17-notas-reunion.txt. La última fecha sale de «08/12/2026» en las notas, leída como 8 de diciembre.)

> **Carlos Peña** · Cerrar la prueba 2
> Prometido para el 17-11-2026, y antes para el 08-11, el 28-10, el 09-10 y el 30-09; la primera promesa fue el 20-09.
> **Cinco reprogramaciones: también es un bloqueo, no un retraso suelto.**
> (Fuente: 30-reuniones/2026-09-05 … 2026-10-10.) Además tiene vencido «Aprobar el diseño 13» y abierto «Aprobar el diseño 21».

> **Ricardo Salas** · Cerrar la prueba 10
> Prometido para el 15-11-2026, y antes para el 31-10 y el 11-10; la primera promesa fue el 02-10.
> **Tres reprogramaciones: ya cruzó el umbral de bloqueo.**
> (Fuente: 30-reuniones/2026-09-19 … 2026-10-10.)

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Paula Céspedes | Actualizar la matriz 6 | 2026-09-17 | 30 días |
| Rubén Cárdenas | Revisar el anexo 3 | 2026-09-18 | 29 días |
| Liliana Torres | Entregar el punto 8 (ya reprogramado una vez, del 17-09 al 28-09) | 2026-09-28 | 19 días |
| Andrés Lozano | Revisar el anexo 11 | 2026-09-28 | 19 días |
| Jorge Medina | Validar el ambiente 12 | 2026-10-02 | 15 días |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-08 | 9 días |
| Andrés Lozano | Cerrar la prueba 18 | 2026-10-11 | 6 días |
| María Restrepo | Revisar el anexo 19 | 2026-10-16 | 1 día |

Rubén Cárdenas dijo el 2026-09-12 que ya había entregado el anexo 3; no se presentó acta y no hay nada en el expediente que lo respalde. Sigue abierto.
Andrés Lozano suma dos vencidos.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Entregar el punto 24 | 2026-10-19 |
| Carlos Peña | Aprobar el diseño 21 | 2026-10-20 |
| Javier Hoyos | Actualizar la matriz 14 (reprogramado una vez, del 16-10 al 24-10) | 2026-10-24 |
| Elena Duarte | Enviar el documento 17 | 2026-10-24 |

Elena Duarte dijo el 2026-10-10 que el documento 17 ya estaba entregado; no hay acta. Sigue abierto.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Felipe Arango | Confirmar la fecha 15 | 2026-09-26 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana», sin fecha) | 2026-10-17 |

No pueden estar vencidos, por eso se cuentan aparte. Felipe Arango dijo el 2026-10-03 que ya lo había entregado; no hay acta y la fila dejó de aparecer en la tabla. Lleva 21 días sin fecha.

### Cerrados desde la última revisión
| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Rubén Cárdenas | Validar el ambiente 4 (se reprogramó dos veces) | 20-seguimiento/2026-10-03-acta-recibo-4.md |
| Felipe Arango | Aprobar el diseño 5 | 20-seguimiento/2026-09-26-acta-recibo-5.md |
| Javier Hoyos | Enviar el documento 9 (se reprogramó una vez) | 20-seguimiento/2026-10-03-acta-recibo-9.md |

### Cifras de la corrida
Salen de `portafolio.py compute`: 8 vencidos, 2 sin fecha, 3 reprogramados 3 o más veces (6, 5 y 3). No hay `record_issues`.

### Después
- Los tres compromisos reprogramados tres veces o más se pueden formular como decisión para el comité del 2026-10-31: qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad de la gerente (Natalia Ospina), por eso sube. No lo he formulado.
- Con `/pm-publish` se puede publicar la ficha para que la PMO la vea.
