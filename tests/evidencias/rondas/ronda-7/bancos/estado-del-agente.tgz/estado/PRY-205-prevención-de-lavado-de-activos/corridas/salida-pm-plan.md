Preguntas del comando (sesión sin interfaz, tomé lo sugerido en cada una):
- Términos: ya estaban vigentes (versión 0.3.13, términos 1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hubo que registrarlos de nuevo. Comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.13-2026-10-17.md` y `.pdf`.
- Qué acta usar: la única que hay, `00-gobierno/2025-08-22-acta-constitucion.md`.
- Modo: plan nuevo, no revisión (no hay WBS en la carpeta).

# Plan — PRY-205 · Prevención de lavado de activos · borrador del 2026-10-17
**Desde:** acta de constitución del 2025-08-22 · **Criterio de éxito:** «Prevención de lavado de activos en producción y medido» (acta, sección Criterio de éxito). Está declarado, pero no dice qué se mide, con qué indicador ni con qué umbral.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| El alcance son «Componente 1, 2 y 3», sin nombre ni contenido | No hay entregables que descomponer. La WBS de abajo tiene tres nodos «sin definir» donde debería estar el producto. Cualquier nombre que les ponga sería inventado. |
| «Fuera de alcance: lo que otro proyecto cubre», sin decir cuál proyecto ni qué | No se puede saber si las ampliaciones CC-01 y CC-02 (ambas «Ampliación de alcance») entran o salen del alcance original. |
| El criterio de éxito no tiene indicador, umbral ni fecha de medición | «Medido» no se puede aceptar ni rechazar. El entregable final no tiene criterio de aceptación. |
| No hay autoridad declarada del gerente (qué decide Natalia Ospina al planificar y qué sube al comité) | No sé qué cambios de plan le tocan a ella y cuáles al Comité de Medios de Pago. |
| No dice quién acepta cada entregable. Solo figura el patrocinador, Rubén Cárdenas, que no está declarado como aceptante | La columna «Quién lo acepta» queda «sin definir» en todos los nodos. |
| «Dependencias declaradas: ninguna» | Con un proveedor en juego (las notas del 2026-10-17 lo mencionan) la dependencia existe y no está escrita. Ver supuestos. |
| Presupuesto de 800.000.000 COP sin desglose por componente | No hay de dónde sacar costo por nodo. No lo estimo. |

El acta sí tiene patrocinador (Rubén Cárdenas), comité (Comité de Medios de Pago), presupuesto, y fechas de inicio y cierre. Sigo adelante marcando los huecos y sin rellenarlos.

**Algo que el plan no resuelve y la persona tiene que mirar:** el acta compromete el cierre para 2026-03-19. El cronograma v3 (2026-10-16) mueve la salida a producción a 2026-06-07 y la marca «cerrado»; los otros cuatro hitos también están «cerrado». Sin embargo, el informe de avance del 2026-10-16 reporta 27 % de avance, hay compromisos abiertos hasta noviembre, y CC-01 y CC-02 siguen pendientes de presentarse al comité. En la carpeta no encontré documento que autorice el paso de 2026-03-19 a 2026-06-07. Por eso no sé si este plan es el del proyecto completo o el de lo que falta; lo trato como el del proyecto completo desde el acta, como pide el comando.

## WBS
| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | sin definir | supuesto (hito del cronograma v1, no del acta) | 39 días entre el inicio del acta (2025-09-01) y el hito 2025-10-10, según cronograma v1 |
| 2 | Ambiente de pruebas certificado | sin definir | supuesto (hito del cronograma v1) | 40 días, según cronograma v1 |
| 3 | Integración con el core | sin definir | supuesto (hito del cronograma v1) | 40 días, según cronograma v1 |
| 4 | Piloto con usuarios internos | sin definir | supuesto (hito del cronograma v1) | 40 días, según cronograma v1 |
| 5 | Salida a producción | sin definir | supuesto (hito del cronograma v1) | 40 días según v1; v3 mueve el hito 80 días, de 2026-03-19 a 2026-06-07 |
| 6 | Componente 1 | sin definir | del acta, pero sin contenido: solo el nombre «Componente 1» | vacía: ¿cuánto toma esto? |
| 7 | Componente 2 | sin definir | del acta, pero sin contenido | vacía: ¿cuánto toma esto? |
| 8 | Componente 3 | sin definir | del acta, pero sin contenido | vacía: ¿cuánto toma esto? |
| 9 | Prevención de lavado de activos «en producción y medido» | sin definir | del acta (criterio de éxito) | vacía: ¿cuánto toma la medición y qué se mide? |
| 10 | Ampliación de alcance CC-01 | sin definir (autorización pendiente) | solicitud de cambio CC-01, 2026-10-09; no está en el acta | +38 días sobre la línea base vigente, según CC-01 |
| 11 | Ampliación de alcance CC-02 | sin definir (autorización pendiente) | solicitud de cambio CC-02, 2026-10-14; no está en el acta | +42 días sobre la línea base vigente, según CC-02 |

Los nodos 1 a 5 son hitos, no entregables que alguien reciba, y no los conecto con los componentes porque nada documentado dice cuál componente va en cuál hito. Los nodos 10 y 11 solo cuentan si el comité los aprueba. Las duraciones de 39 y 40 días son la resta de fechas del cronograma v1, no una estimación mía.

Las tres actas de recibo de la carpeta («Aprobar el diseño 5», «Validar el ambiente 4», «Enviar el documento 9») no dicen a cuál nodo corresponden, y no las asigno a ninguno.

## Orden
Sin fechas. Lo que sí está escrito:
- Del cronograma v1, en secuencia: 1 → 2 → 3 → 4 → 5.
- 9 (en producción y medido) depende de 5, porque el criterio de éxito dice «en producción».
- 10 y 11 dependen de que el comité las autorice. No sé si dependen de los nodos 1 a 5 ni de los componentes 6 a 8.
- Qué componente alimenta qué hito: sin definir.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 son los entregables del proyecto, aunque el acta no los nombra | Falta o sobra algún entregable y la WBS no cubre el alcance real. |
| Los componentes 1, 2 y 3 son entregables separados y no partes de un mismo entregable | La WBS cuenta tres cosas donde hay una, o una donde hay tres. |
| CC-01 y CC-02 son trabajo adicional, no corrección de algo que el alcance original ya debía incluir | Si ya estaba en el alcance, no son un cambio; si están solapadas entre sí, se paga dos veces. |
| El plan cubre el proyecto completo desde 2025-09-01 y no solo lo pendiente | Si es solo lo pendiente, los nodos 1 a 5 sobran. |
| El proveedor mencionado en las notas del 2026-10-17 es una dependencia del plan | Si no lo es, ese riesgo se descarta. Si lo es y falta en el acta, el plan no lo cubre. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 | Natalia Ospina con el patrocinador, Rubén Cárdenas (el acta no dice quién; es mi suposición de quién) |
| Indicador y umbral de «medido» | Rubén Cárdenas, como patrocinador |
| Quién acepta cada entregable | Rubén Cárdenas o el Comité de Medios de Pago; el acta no lo dice |
| Qué es exactamente «lo que otro proyecto cubre» y cuál proyecto | Natalia Ospina con la PMO |
| Qué decide la gerente al planificar y qué sube al comité | Rubén Cárdenas o el Comité de Medios de Pago |
| Si hay dependencias externas (proveedor, aprobación regulatoria) | Natalia Ospina |
| Qué autorizó el movimiento del cierre a 2026-06-07 | Comité de Medios de Pago; no hay documento que lo diga |
| Si CC-01 y CC-02 entran al plan | Comité de Medios de Pago |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-205 no apunta a una carpeta de fichas de la PMO, y en el espacio solo hay estado de este proyecto y de un producto (PRD-302), que no es un proyecto análogo. Es la respuesta correcta aquí: sin análogos no hay referencia, y no pongo una cifra de relleno.

## Preguntas para el equipo
1. Componente 1: ¿qué es, quién lo recibe y cuánto toma?
2. Componente 2: ¿qué es, quién lo recibe y cuánto toma?
3. Componente 3: ¿qué es, quién lo recibe y cuánto toma?
4. «En producción y medido»: ¿qué se mide, con qué indicador y umbral, y cuánto toma medirlo?
5. ¿Quién acepta cada entregable: el patrocinador o el comité?
6. ¿Cuál componente entra en cuál hito (diseño, ambiente, integración, piloto, producción)?
7. ¿Cuánto tomaría CC-01 si se aprueba, desglosado por entregable? Hoy solo hay un total (+38 días, 76.000.000 COP).
8. ¿Y CC-02 (+42 días, 84.000.000 COP)? ¿Se solapa con CC-01?
9. ¿Qué proyecto cubre lo que el acta deja «fuera de alcance»?
10. ¿Qué se aprobó para mover la salida a producción de 2026-03-19 a 2026-06-07, y quién lo aprobó?
11. ¿El plan es del proyecto completo o de lo que falta?

## Para comprometer una fecha falta
- La disponibilidad real del equipo: las notas del 2026-10-17 y el comité del 2026-10-10 muestran compromisos vencidos y movidos, y ningún documento dice cuánta capacidad hay.
- La fecha del proveedor y si llega con el equipo completo para la siguiente fase (las notas del 2026-10-17 dicen que podría no llegar; nadie lo anotó como riesgo).
- La ventana de la sala de producción.
- La decisión del comité sobre CC-01 y CC-02.
- El contenido de los componentes 1 a 3, sin el cual no hay qué fechar.

Ninguna fecha queda comprometida en este borrador; eso lo decide Natalia Ospina.

## Después
Cuando el plan se apruebe, puedo registrarlo como línea base original y pasar los supuestos de arriba al registro de riesgos con doliente. El riesgo del proveedor que se dijo el 2026-10-17 y nadie anotó conviene registrarlo ya, sin esperar al plan.
