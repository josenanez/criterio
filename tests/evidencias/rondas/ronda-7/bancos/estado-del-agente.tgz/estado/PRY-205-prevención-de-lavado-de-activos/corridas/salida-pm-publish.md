Términos vigentes (versión 1.1, aceptada el 2026-10-17 por José Francisco Ñáñez). Recalculé antes de publicar; la fecha de cierre vigente (2026-06-07) sale del cronograma v3 del 2026-10-16, y la original (2026-03-19) va en `plan.baseline`. La carpeta de gobierno ya existía.

Publiqué la ficha en `documentos/proyectos/PRY-205-prevención-de-lavado-de-activos/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 14 campos con dato · 3 sin decir en ninguna parte (producto, autoridad, fase) · declara **verde** al 2026-10-16

**Lo más viejo que va ahí:** identidad, patrocinador, gerente, comité, fechas de inicio, alcance y presupuesto aprobado, todos del acta de constitución del 2025-08-22 — 14 meses, pasa de un año.

**Lo primero que la PMO va a mirar:** el verde es tuyo, declarado, y el cálculo lo contradice: avance declarado 27 % frente a 5 de 5 hitos marcados cumplidos sin evidencia, 80 días de atraso contra la línea base original (40,2 %), 8 compromisos vencidos y 3 reprogramados varias veces. Además hay 2 solicitudes de cambio pendientes (CC-01 y CC-02).
