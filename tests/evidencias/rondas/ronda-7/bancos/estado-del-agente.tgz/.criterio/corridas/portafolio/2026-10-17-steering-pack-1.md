# Corrida · 2026-10-17-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:12:10 · **Fin:** 2026-10-17T15:14:27 · **Duración:** 137 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 120 | 67 | Paquete de 7 decisiones y 5 escalamientos sobre 13 fichas. No hay comité anterior registrado en estado/. Dijo que no sabe: quién aprueba cambios (13 de 13 sin autoridad), motivo y alcance de cada solicitud de cambio, si FV-1258 está pagada, si 'el core' es PRY-201. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

El paquete de comité quedó escrito y la corrida quedó registrada (`2026-10-17-steering-pack-1`). Los términos ya estaban vigentes (versión 0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

El paquete es para el comité del 2026-10-24, con datos al 2026-10-17. Cubre 13 fichas, de las cuales 11 tienen alertas (67 en total).

**Decisiones**

1. **Quién aprueba cambios de línea base.** Ninguna de las 13 fichas declara autoridad y hay cinco comités distintos. Por eso es el primer punto. Recomiendo un solo comité de portafolio hasta fijar un umbral.
2. **PRY-201, CC-01 (+107 días, 214 M COP).** Recomiendo aplazar hasta saber qué alcance se amplía y quién depende "del core".
3. **PRY-205, CC-01 y CC-02 (+38 y +42 días).** Recomiendo no aprobar y exigir una replanificación con evidencia.
4. **PRY-207, CC-01 (+58 días, 116 M COP).** Recomiendo aplazar hasta tener un informe de avance nuevo.
5. **PRY-208, CC-01.** El documento dice "autorizada por el comité", pero sin acta y sin línea base nueva. Recomiendo ratificarla con acta.
6. **PRY-209, factura FV-1258.** Hay 365.708.982 COP facturados sin acta de recibo, y la bolsa de horas vence el 2026-10-20. Recomiendo retener ese excedente.
7. **Hallazgos de seguridad abiertos (PRY-203, 208, 209, 211).** Se necesita un responsable único y un orden de revisión. Recomiendo empezar por PRY-211.

Además hay cinco escalamientos sin decisión asociada:
- PRY-204 y PRY-211 tienen la fecha final vencida.
- PRY-202 reprogramó la salida sin fecha y sin solicitud de cambio.
- PRY-205 tiene ocho compromisos vencidos.
- Hay proveedores sin nombre que no han confirmado fecha.

**Lo que no sé**
- **Comité anterior:** no hay actas ni decisiones registradas en `estado/`, así que la sección de decisiones previas dice "sin dato".
- **Solicitudes de cambio:** ninguna dice qué alcance se amplía ni por qué.
- **Pago de FV-1258:** no consta si ya se pagó.
- **"El core":** nada confirma que sea PRY-201.

Revisé a mano dos cifras antes de cerrar y corregí una: PRY-205 tiene ocho compromisos vencidos, no seis.

El pie del documento lleva la versión, las fichas aplicadas, los campos inciertos y el enlace a los términos. Las recomendaciones son mías y la decisión es del comité. Registrar las decisiones en las fichas queda para después de la sesión del comité.

Archivos en `/home/claude/banco/ronda-7/bancos/espacio/estado/corridas/`:
- `salida-steering-pack.md`
