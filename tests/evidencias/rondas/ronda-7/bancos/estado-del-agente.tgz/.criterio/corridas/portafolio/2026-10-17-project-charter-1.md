# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-203 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T15:10:24 · **Fin:** 2026-10-17T15:11:05 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 25 | 67 | Revisión del acta de PRY-203 (2026-05-06): sin autoridad del gerente, objetivo = solución, alcance y exclusiones placeholder, sin hitos, sin cadencia, criterio de éxito sin métrica ni quién mide; dependencias 'ninguna' contradice el informe del 2026-10-09. No supe si hay acuerdos fuera de los documentos ni a qué proyecto se refieren las exclusiones. |

Por señal (`project-charter`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Hay acta previa de PRY-203 Open Banking, aprobada el 2026-05-06, y le faltan campos clave. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no pedí nueva aceptación.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no está declarada. Rubén Cárdenas no tiene escrito hasta qué monto ni qué cambio de alcance decide sin comité. La proyección ya pasa lo aprobado: 18.145.395.715 COP contra 18.000.000.000 (+0,8%). Sin autoridad escrita, ese ajuste sube al Comité de Medios de Pago por defecto.
- **Objetivo de negocio:** "Entregar open banking para Medios de Pago" describe la solución, no el resultado de negocio buscado.
- **Alcance y exclusiones:** son placeholders ("Componente 1, 2, 3" y "Lo que otro proyecto cubre"). No hay contra qué medir un cambio de alcance, y ningún solapamiento con otro proyecto se detectaría.
- **Dependencias:** el acta dice "ninguna declarada", pero el informe del 2026-10-09 abre riesgos sobre el equipo de seguridad y sobre un proveedor sin fecha de entrega.
- **Criterio de éxito:** "en producción y medido" no trae métrica, umbral ni quién lo mide.
- **Supuestos, restricciones, hitos y cadencia del comité:** no hay ninguno. El plan solo tiene inicio (2026-05-16) y cierre (2027-02-27).
- **Patrocinador:** cumple (Carlos Peña).

Los campos sin sustento quedaron marcados como pendientes de definir; no los completé.

**No supe:** si algún acuerdo se pactó fuera de los documentos, ni a qué proyecto se refieren las exclusiones.

**Siguiente paso:** puedo llevar al comité la definición de la autoridad del gerente. También puedo pasar los dos riesgos y la dependencia no declarada al registro RAID.

Guardé la salida completa en `/home/claude/banco/ronda-7/bancos/espacio/estado/corridas/salida-project-charter.md`. La corrida quedó registrada con id `2026-10-17-project-charter-1`, caso PRY-203, 25 segundos medidos.

El resumen de la corrida cuenta 67 hallazgos de los 13 proyectos que tiene el estado. PRY-203 aparece sin señales de portafolio, porque esas señales miden avance y fechas, no el contenido del acta.
