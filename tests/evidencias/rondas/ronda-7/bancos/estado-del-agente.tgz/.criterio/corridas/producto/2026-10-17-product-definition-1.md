# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:38:32 · **Fin:** 2026-10-17T14:39:13 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 14 | — | 25 | 31 | La evidencia sostiene solo la necesidad (una entrevista de hace 13 meses); volumen y retorno sin serie y sin criterio de éxito |

Por señal (`product-definition`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 4, `requirement_without_owner` 3, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Definición — Crédito hipotecario digital (PRD-302) · contrastada al 2026-10-17

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré otra vez. La definición es del 2025-11-22 y tiene 5 afirmaciones. La evidencia solo sostiene una, y débilmente.

- **Lo que la evidencia contradice:** nada. Ninguna fuente dice lo contrario de lo que afirma la definición.
- **Lo que sostiene la evidencia:** una sola entrevista, del 2025-09-12 («Lo necesito y hoy no lo tengo»). Respalda la necesidad, pero no el volumen ni el pago. Ya tiene 13 meses, y el umbral es 12. Diez requerimientos se apoyan solo en ella.
- **Cifras que nadie mide:** `volumen_mensual` = 130.646. El caso de negocio cita como fuente al propio caso de negocio y no hay serie medida, así que no hay con qué comparar. Eso no es una contradicción; es que nadie está midiendo lo que se afirmó.
- **Supuesto sin verificar:** «La demanda declarada se sostiene sin campaña» lleva 113 días sin verificar (el umbral es 30). Para verificarlo hace falta medir la demanda orgánica en un período sin campaña. Eso exige que antes exista la serie del volumen.
- **No está dicho en ninguna parte:**
  - El criterio de éxito.
  - El contenido de la propuesta: el documento solo trae el rótulo «Propuesta principal».
  - El origen del 130.646.
  - La base del «retorno en 24 meses».
  - Cómo se verificó que Personas no tiene la oferta.
  - Quién decide qué se construye.
  - Los proyectos que lo construyen: «Ninguno declarado».
- **Lo normativo:** el producto roza datos personales, consumidor financiero y retención de información. Ningún documento nombra el país, así que no cité ninguna norma. En las tres filas el estado es «no tengo la norma a la vista». Eso no significa que no apliquen, y va a revisión jurídica.
- **Para cerrar la definición:** faltan el criterio de éxito y el contenido de la propuesta. Sin criterio de éxito la definición no se puede cerrar, así que `/product-charter` todavía no aplica. Puedo convertir el supuesto en riesgo con doliente si quieres.

La corrida quedó registrada como `2026-10-17-product-definition-1`, con 31 hallazgos en 25 segundos. La salida completa está en `estado-producto/PRD-302/corridas/salida-product-definition.md`.
