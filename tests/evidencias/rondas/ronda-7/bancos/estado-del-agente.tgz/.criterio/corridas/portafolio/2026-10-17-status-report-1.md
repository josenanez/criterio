# Corrida · 2026-10-17-status-report-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:status-report PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-17T15:00:09 · **Fin:** 2026-10-17T15:00:56 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `status-report` | 13 | — | 31 | 67 | Informe de estado de PRY-202: verde declarado (34%) contradicho por 26.0 puntos de atraso frente al plan, un hito vencido y dos hitos cumplidos sin evidencia. Dijo que no sabe: producto, autoridad, fase, última reunión, sustento contable del presupuesto. Términos ya vigentes, sin nueva aceptación. |

Por señal (`status-report`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

PRY-202 (Migración a la nube) declara verde y 34 % de avance, y los documentos no sostienen ese verde. El informe sale de la ficha actualizada el 2026-10-17 y de cifras recalculadas hoy con `compute`. Quedó registrado en `estado/corridas/2026-10-17-status-report-1.md`.

Los términos ya estaban vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar una aceptación nueva.

**Lo que el semáforo no explica**
- **Atraso de avance:** los 3 hitos cumplidos de 5 sostienen entre 60 y 80 %, y el gerente declara 34 %. La diferencia es de 26.0 puntos.
- **Hito vencido:** el «Piloto con usuarios internos» vencía el 2026-10-13 y lleva 4 días de atraso.
- **Hitos cumplidos sin evidencia:** «Diseño funcional aprobado» (base 2026-02-15) e «Integración con el core» (base 2026-07-25) se declaran cumplidos sin documento de recibo.
- **Contradicción interna:** el mismo informe de avance narra incidencias abiertas y aun así reporta verde. Esas incidencias son dos semanas perdidas por rotación, la salida a producción reprogramada y dos historias fuera del sprint.

**Contra el plan**
- **Fecha de cierre:** 2027-01-01, igual en la línea base original y en la vigente (desviación de 0 días, sin replanificaciones registradas).
- **Salida a producción:** el informe dice que se reprogramó, pero no hay nueva fecha en el cronograma ni cambio formalizado.
- **Presupuesto:** COP 2.400.000.000 aprobado, con 81.0 % comprometido, 21.5 % ejecutado y una proyección de -2.8 % frente al aprobado. Esas tres cifras son declaración del gerente. Ningún documento independiente las sustenta.

**Abierto**
- **Riesgos y incidencias:** hay 2 riesgos y 3 incidencias, ninguno con responsable.
- **Compromisos:** no hay ninguno registrado, porque no hay actas de reunión.

**Sin dato**
- **No encontrados:** producto, autoridad de aprobación y fase.
- **Sin autoridad definida:** no se puede decir a quién escalar, ni si los riesgos exceden la autoridad del gerente.
- **Última reunión:** no hay ninguna entre los documentos leídos.
- **Proveedores:** la ficha no registra ninguno, aunque un riesgo menciona «el proveedor».

La desviación de avance supera el umbral de 10 puntos. Puedo preparar el punto de comité del 2026-10-24 y la solicitud de cambio para la salida a producción reprogramada.

El informe completo, con hitos, el detalle de lo abierto y el pie, está en `estado/corridas/salida-status-report.md`.
