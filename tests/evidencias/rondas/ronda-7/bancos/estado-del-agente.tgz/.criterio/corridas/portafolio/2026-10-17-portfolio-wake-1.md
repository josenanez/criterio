# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T15:16:24 · **Fin:** 2026-10-17T15:16:58 · **Duración:** 34 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 21 | 67 | Barrido: 81 documentos sin cambios, 0 proyectos recalculados. 14 citas de PRY-205 no resuelven (probable desajuste entre el código y el nombre de la carpeta; sin verificar). Confirmación no corrida: no había quien respondiera. Sin peticiones. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Hoy tocaban el barrido y la confirmación. El barrido está hecho; la confirmación no la corrí porque nadie podía responder.

- **Barrido:** revisé 81 documentos y ninguno cambió, así que no recalculé ningún proyecto.
- **Citas rotas en PRY-205:** las 14 citas de su ficha no resuelven. Apuntan al acta de constitución, al cronograma v3 y al informe de avance, y esos archivos sí están en la carpeta `PRY-205-prevención-de-lavado-de-activos`. Probablemente la ficha cita `PRY-205` y la carpeta lleva el nombre largo, pero no lo verifiqué ni toqué la ficha. Queda como hallazgo abierto.
- **Confirmación:** no la corrí, así que no la marqué como hecha y vuelve a tocar mañana.
- **Peticiones:** no había ninguna en el servidor.
- **Términos:** ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17 (v0.3.13), así que no hizo falta registrarlos de nuevo.

La corrida quedó registrada con id `2026-10-17-portfolio-wake-1`. Su registro cuenta 67 hallazgos en 13 proyectos, que vienen de las fichas que ya existían, no de este barrido. La salida de la corrida está en `estado/corridas/salida-portfolio-wake.md`.

**Vuelvo el 2026-10-18.** El comité es el 2026-10-24 y el informe se genera el 2026-10-22.
