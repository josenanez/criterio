# Corrida · 2026-10-17-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:51:03 · **Fin:** 2026-10-17T14:52:06 · **Duración:** 63 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 47 | 21 | Paquete de escalamiento: autoridad no declarada en el acta, CC-01 y CC-02 pendientes sin base de fechas creíble, tres compromisos reprogramados 3+ veces. Impacto: 0 proyectos alcanzados porque el estado solo tiene PRY-205 y no hay dependencias declaradas. No sabe: qué incluye cada ampliación, si CC-01 y CC-02 se acumulan, consecuencia con fecha, dolientes externos. |

Por señal (`pm-escalate`): `commitment_overdue` 8, `milestone_met_without_evidence` 5, `commitment_rescheduled` 3, `commitment_undated` 2, `variance_time` 1, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

Armé el paquete de escalamiento de PRY-205 y registré la corrida (47 segundos). Los términos ya estaban vigentes desde el 2026-10-17, a nombre de José Francisco Ñáñez, así que no registré nada nuevo.

No se indicó tema, así que trabajé sobre lo que la ficha ya marca como escalable.

- **Primer punto que escala:** el acta no declara la autoridad de Natalia Ospina. Sin eso no se puede decir si los cambios CC-01 y CC-02 exceden su facultad ni quién los aprueba.
- **La pregunta cerrada:** si se aprueba CC-01 (+38 días, +76 M COP), CC-02 (+42 días, +84 M COP), ambos o ninguno, y con qué línea base de fechas.
- **Recomendación (mía):** no decidir todavía. Llevar ambos cambios como un solo paquete al comité del 2026-10-31, con las fechas reconstruidas. Las dos solicitudes miden contra un cierre vigente (2026-06-07) que ya pasó con el proyecto declarado al 27 %, así que ese punto de partida no es creíble.
- **Presupuesto:** la proyección declarada (819.904.464 COP) ya supera los 800 M aprobados. Con los dos cambios llegaría hasta 979.904.464 COP, si la proyección no los incluye; no consta si los incluye.
- **Contradicción en el cronograma v3:** "Salida a producción" figura como cerrada, y los cinco hitos "cerrados" no tienen evidencia de cierre. Eso choca con el verde y el 27 % del informe.
- **Compromisos reprogramados tres veces o más:** Sandra Gil (6), Carlos Peña (4) y Ricardo Salas (3). No consta si sus dolientes están fuera del proyecto.
- **Riesgo del proveedor sin dueño:** se comentó el 17 de octubre y nadie lo anotó. Hay que registrarlo antes del comité.
- **Impacto en otros proyectos:** el cálculo da cero proyectos y cero hitos alcanzados. No significa que no haya impacto: el estado solo tiene PRY-205 y el acta no declara dependencias.
- **No sé:**
  - qué incluye cada ampliación;
  - si CC-01 y CC-02 se acumulan;
  - la consecuencia con fecha de no decidir (ningún documento la da, así que no la inventé);
  - cuántos días se movería cada proyecto alcanzado, que necesita holgura por actividad.

Archivos en `estado/PRY-205-prevención-de-lavado-de-activos/corridas/`:
- salida-pm-escalate.md
- 2026-10-17-pm-escalate-1.md
