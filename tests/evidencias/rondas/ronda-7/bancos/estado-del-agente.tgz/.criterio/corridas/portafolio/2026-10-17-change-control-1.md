# Corrida · 2026-10-17-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-202 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-17T15:05:09 · **Fin:** 2026-10-17T15:05:58 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 33 | 67 | Solicitud de mover 30 días la salida a producción de PRY-202. Sin dependencias declaradas ni autoridad en el acta; costo, solicitante y motivo no constan. Va a comité por defecto. |

Por señal (`change-control`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

Dejé la solicitud de cambio de PRY-202 evaluada y la corrida registrada como `2026-10-17-change-control-1`. Lo único que falta es una decisión sobre los 30 días, y esa decisión no se puede tomar con lo que hay en los documentos.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré de nuevo. La solicitud completa está en `/home/claude/banco/ronda-7/bancos/espacio/estado/corridas/salida-change-control.md`.

- **Tiempo:** mover la salida a producción 30 días lleva el cierre del 2027-01-01 al 2027-01-31.
- **Alcance:** nadie declara cambio, así que esos 30 días los absorbe el equipo o el proveedor, o aparecen después como sobrecosto.
- **Costo:** no consta cifra y no la inventé. El margen entre el aprobado y la proyección es de 66.716.740 COP (2,8 %).
- **Portafolio:** el cálculo de impacto no alcanza a ningún otro proyecto, porque el acta dice «Ninguna declarada» en dependencias. Eso no prueba que no haya efecto. El informe menciona una dependencia con el core y una ventana de operaciones que nadie registró. Tampoco sé cuántos días se mueve cada proyecto alcanzado, porque la ficha no tiene holgura por actividad.
- **Quién decide:** el acta no declara autoridad ni cláusula de cambios. Lo dejé para el Comité de Arquitectura por defecto, que se reúne el 2026-10-24, y lo marqué como hallazgo de fondo.
- **Línea base:** no hay cambios registrados ni días sin autorización. La línea base 2 queda solo propuesta, con cierre 2027-01-31, hasta que exista el documento que la apruebe.

El informe del 2026-10-14 declara el proyecto en verde con 34 %, pero reporta dos semanas perdidas, un piloto vencido desde el 2026-10-13 y una reprogramación de la salida sin fecha nueva. Ese verde no está sustentado por los documentos.

Quedan cinco cosas que los documentos no dicen:
- Quién pidió el cambio.
- El motivo documentado.
- El costo de los 30 días.
- Quién puede aprobarlo.
- Si el cierre se mueve junto con la salida.
