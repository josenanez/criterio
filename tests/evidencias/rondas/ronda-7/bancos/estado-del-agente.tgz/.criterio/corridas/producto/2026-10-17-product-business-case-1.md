# Corrida · 2026-10-17-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:39:18 · **Fin:** 2026-10-17T14:40:11 · **Duración:** 53 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 14 | — | 39 | 31 | Caso de negocio armado: 1 cifra declarada que se cita a sí misma, sin serie medida, costos y criterio de éxito sin fuente; no se corrió cruce con otros productos (sin fichas publicadas) |

Por señal (`product-business-case`): `evidence_stale` 10, `requirement_untraced` 9, `requirement_undecided` 4, `requirement_without_owner` 3, `requirement_accepted_without_evidence` 3, `requirement_without_acceptance` 1, `assumption_unverified` 1

## Lo que el agente mostró

Armé el caso de negocio de PRD-302 (Crédito hipotecario digital) y registré la corrida. El resultado es que todavía no hay un caso evaluable, solo una propuesta.

Los términos ya estaban vigentes y aceptados a nombre de José Francisco Ñáñez el 2026-10-17, así que no los registré otra vez.

- **Cifras:** hay una sola, `volumen_mensual` = 130.646, y es declarada. Su fuente es el propio caso de negocio, así que se cita a sí misma. No tiene unidad ni serie medida con la que contrastarla.
- **Retorno:** el caso dice «retorno esperado en 24 meses» sin ningún monto. No lo calculé.
- **Costos:** el costo de construir no está en ningún documento. Es el primer vacío.
- **Requerimientos:** hay 9 aceptados y 5 propuestos.
  - **Evidencia:** 6 de los 9 se apoyan en una sola entrevista de 2025-09-12 que no los nombra, y 3 no tienen evidencia de quién los pidió.
  - **Proyecto:** ninguno tiene proyecto que lo ejecute.
- **Supuesto:** «La demanda declarada se sostiene sin campaña» lleva 113 días sin verificar, contra un umbral de 30. Además está fechado 2026-06-26 dentro de un documento fechado 2025-11-22.
- **Éxito y vacíos:** no hay criterio de éxito declarado. Tampoco están dichos qué pasa si no se hace ni qué alternativas se consideraron.
- **Cruce con otros productos:** no lo corrí porque no hay fichas publicadas de otros productos. Como verificación parcial, 130.646 no aparece en los documentos de ningún otro producto.

No calculé ni proyecté ninguna cifra ni recomendé aprobar o rechazar.

Como siguiente paso propongo pasar los supuestos a assumption-tracking y no abrir `/product-charter` hasta tener el costo de construir y el criterio de éxito.

La salida completa está en `estado-producto/PRD-302/corridas/salida-product-business-case.md`. La corrida quedó registrada como `2026-10-17-product-business-case-1` (39 segundos, 31 hallazgos).
