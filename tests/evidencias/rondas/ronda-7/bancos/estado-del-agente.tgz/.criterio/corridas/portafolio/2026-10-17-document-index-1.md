# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T14:59:25 · **Fin:** 2026-10-17T15:00:03 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 27 | 67 | 81 documentos sin cambio, 0 por releer. 14 citas pm_record de PRY-205 no resuelven aunque los archivos existen; causa probable: citas relativas a la carpeta del proyecto, sin confirmar. No se modificó ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 20, `commitment_overdue` 10, `declared_vs_evidence` 8, `progress_vs_plan` 7, `commitment_undated` 5, `variance_time` 4, `variance_cost` 4, `rebaseline_unauthorized` 3, `commitment_rescheduled` 3, `milestone_overdue` 1, `change_without_baseline` 1, `vendor_invoiced_over_accepted` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

**Documentos:** 81 · **Sin cambio:** 81 · **Hay que releer:** 0

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-17 (versión 1.1, plugin 0.3.13), así que no registré nada nuevo.

- **Contenido, reguardados, renombrados y borrados:** no hubo ninguno.
- **Formatos ilegibles:** el índice no reportó ninguno.
- **Citas que dejaron de resolver:** hay 14, todas de PRY-205, en los campos `pm_record.*`. Son identidad (código, nombre, área, sponsor, gerente, comité), plan (inicio, fin, alcance, exclusiones) y dinero (aprobado, comprometido, ejecutado, proyección). Citan estos documentos:
  - `00-gobierno/2025-08-22-acta-constitucion.md`
  - `10-plan/2026-10-16-cronograma-v3.csv`
  - `20-seguimiento/2026-10-16-informe-avance.pdf`
- **Los archivos citados sí existen:** están en disco dentro de `PRY-205-prevención-de-lavado-de-activos/`. Esas citas están escritas relativas a la carpeta del proyecto, sin el nombre del proyecto al frente. Las demás citas de la ficha sí lo llevan. Es la causa más probable, pero no la confirmé. No es un borrado ni un movimiento.
- **Qué hacer:** no hay nada que releer, así que no hace falta `/portfolio-scan`. Corregir la forma de esas 14 citas queda pendiente de tu decisión. No toqué ninguna ficha.

La corrida quedó registrada como `2026-10-17-document-index-1`, con la salida en `/home/claude/banco/ronda-7/bancos/espacio/estado/corridas/salida-document-index.md`.
