## Crédito hipotecario digital (PRD-302) · 2026-10-17

Términos vigentes (v0.3.13, aceptados por José Francisco Ñáñez el 2026-10-17); no se volvieron a pedir.

**Desde el corte anterior:** no existe corte anterior (primera corrida del reloj, `last: null`). Todo lo que sigue es lo abierto hoy, no una novedad medida contra un corte; desde la próxima corrida solo se reportará lo que cruce un umbral después de este.

**Qué toca:** `review` (mensual). No toca `report`: el comité es mensual y `next_wake` está a 30 días.

### Carpeta de documentos
4 documentos, ninguno nuevo ni cambiado (el más reciente es del 2026-10-11). No se releyó nada. Aparte: el índice marca 8 campos del registro cuya fuente no resuelve con la ruta registrada (`documentos/productos/PRD-302/...`); es la ruta, no un documento borrado: no hay renombrados ni borrados. Conviene corregir la ruta en el registro.

### Cruzó un umbral (60 días sin decidir; 30 sin verificar un supuesto; 12 meses de evidencia)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4212 | 115 días (desde 2026-06-24) | Que el comité decida; sin evidencia de demanda | Jorge Medina (doliente); decide: Comité de producto (propuesto por el acta, ningún documento lo declara) |
| Sin decidir | REQ-4200 | 85 días | Doliente y decisión; sin criterio de aceptación | Sin doliente |
| Sin decidir | REQ-4207 | 83 días | Doliente y decisión; sin criterio de aceptación | Sin doliente |
| Sin decidir | REQ-4201 | 71 días | Doliente y decisión | Sin doliente |
| Supuesto sin verificar | «La demanda declarada se sostiene sin campaña» | 113 días | Una medición de demanda sin campaña que la sostenga o la desmienta; pasó el umbral de 30 días, así que corresponde tratarlo como riesgo registrado | Sin responsable declarado |
| Evidencia vencida | 10 REQ (4200–4205, 4207, 4208, 4209, 4211) | 13 meses | Toda la evidencia es una sola entrevista del 2025-09-12; la afirmación de demanda de la definición se queda sin sustento vigente | — |

### Aceptado sin sustento
- **Sin evidencia de demanda:** REQ-4206, REQ-4210, REQ-4213 (aceptados, con doliente, sin ninguna cita).
- **Sin criterio de aceptación:** REQ-4203.
- **Sin proyecto que los construya:** los 9 aceptados (REQ-4203 a 4206, 4208 a 4211, 4213). La definición dice «Ninguno declarado».

### Las trazas
No se confirmó ninguna: la configuración no trae carpeta de fichas de proyectos y sin ella ninguna traza se da por confirmada. 0 de 9 requerimientos aceptados tienen proyecto.

### Lo que la definición no dice
Criterio de éxito (`success`): no está en ningún documento. Propuesta: el documento solo trae el rótulo «Propuesta principal». La única cifra declarada (volumen mensual 130.646) no tiene medición con la cual contrastarla.

### Del descubrimiento
Sin documentos nuevos desde el registro.

Esta corrida no decide, no verifica supuestos ni le escribe a nadie. Opciones: llevar los cuatro sin decidir al comité; `/product-trace` con la carpeta de fichas; `/product-discovery` para renovar la evidencia de 2025-09.

**Vuelvo el 2026-11-16.**
