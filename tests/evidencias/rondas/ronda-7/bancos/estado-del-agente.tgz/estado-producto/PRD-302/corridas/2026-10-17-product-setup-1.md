# Corrida del 2026-10-17 · product-setup

PRD-302 · 14 requerimientos · 43 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

0 preguntas a la persona (sesión sin interfaz, respuestas sugeridas); minutos hasta el primer resultado sin medir; 4 documentos, 14 requerimientos levantados; hallazgos: 1 sola entrevista de hace 13 meses detrás de 10 requerimientos, 9 de 9 aceptados sin proyecto, sin criterio de éxito, 130.646 mensual sin serie medida

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Qué miré.** 4 documentos en `documentos/productos/PRD-302`, todos legibles (los dos `.docx` se leyeron como texto). 1 es material de descubrimiento (la ronda de entrevistas del 2025-09-12, con una sola cita). Hay caso de negocio y definición escrita, los dos del 2025-11-22, y un acta del comité de producto del 2026-10-11, que es lo más reciente.

**Sesión sin interfaz: no hice preguntas, tomé la respuesta sugerida en cada una.**
1. Producto: Crédito hipotecario digital (PRD-302), gerente Felipe Arango. Lo tomé del caso de negocio y de la definición.
2. Quién decide qué se construye: Comité de producto. Es una propuesta mía a partir del acta del comité. Ningún documento lo declara.
3. Dónde guardo lo que encuentro: `estado-producto/PRD-302`, hermana de la documentación. No usé `estado/`.
4. Términos: José Francisco Ñáñez los aceptó para la versión 1.1 el 2026-10-17. El sí vino en el argumento del comando, no de una conversación.

## Listo — Crédito hipotecario digital

**Lo que miré:** 4 documentos · 1 de descubrimiento · la definición del 2025-11-22
**Términos:** aceptados para la versión 1.1 (familia 0.3.13) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.13-2026-10-17.md` y `.pdf` · SHA-256 d85e8bd2335ac89a…

**Lo que levanté de lo escrito:** la ficha del producto y 14 requerimientos (REQ-4200 a REQ-4213) que el acta del 2026-10-11 nombra: 5 propuestos y 9 aceptados.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Personas no tiene crédito hipotecario digital» | Lo más cercano es una entrevista: «Lo necesito y hoy no lo tengo.», de un cliente sin nombre. No dice qué necesita, ni que sea hipotecario, ni que sea digital, ni de qué segmento es. Se cita como la más cercana, no como sustento | 2025-09-12 (13 meses) |
| «La demanda declarada se sostiene sin campaña» | Solo un supuesto declarado, sin verificar, con 113 días | declarado el 2026-06-26 |
| Volumen mensual de 130.646 | Solo el propio caso de negocio, que se cita a sí mismo como fuente. No hay serie medida | 2025-11-22 |

### Lo que no está dicho en ninguna parte
- **Que el segmento Personas tenga el problema.** Una cita sin nombre, sin conteo y sin segmento no lo dice.
- **De dónde sale el 130.646 mensual.** No hay serie medida con fuente, así que no se puede contrastar. Nadie está midiendo lo que el negocio afirmó.
- **Cuánto es el «retorno esperado en 24 meses».** El caso de negocio no trae una cifra ni la base de cálculo.
- **El criterio de éxito.** No está escrito. Sin él, el producto no se puede cerrar.
- **La propuesta.** La definición trae el rótulo «Propuesta principal» y nada debajo.
- **Qué necesita cada requerimiento.** En el acta los 14 se llaman «Requerimiento REQ-42xx», sin el problema que resuelven. La entrevista no nombra ninguno.
- **Quién decidió cada aceptación.** El acta registra los estados y «Se mantiene el plan», pero no dice quién decidió, y ningún documento trae ese plan.
- **Qué proyecto construye algo.** La definición dice «Ninguno declarado» y ningún requerimiento tiene proyecto.

### Supuestos sobre los que está escrita
Uno declarado: «La demanda declarada se sostiene sin campaña», sin verificar desde hace 113 días. Es el que sostiene el volumen de 130.646, y nada lo verifica. Además, la definición es del 2025-11-22 y el supuesto lleva fecha 2026-06-26. O el documento se editó después sin cambiar su fecha, o la fecha está mal. Tú sabes cuál.

### Qué muestra el registro (cifras del cálculo)
- **Una sola entrevista sostiene todo.** Es de hace 13 meses, pasó el umbral de 12, y está detrás de 10 de los 14 requerimientos. Ninguno nombra la entrevista como origen; el acta solo dice «cliente entrevistado».
- **Aceptados sin proyecto: 9 de 9 (0,0 % con proyecto).** Se aceptó construir y nadie declara que lo construya.
- **Aceptados con evidencia: 6 de 9 (66,7 %).** REQ-4206, REQ-4210 y REQ-4213 se aceptaron sin que nadie conste como quien los pidió.
- **Sin doliente (el acta dice «sin asignar»): 3.** REQ-4200, REQ-4201 y REQ-4207.
- **Propuestos sin decidir hace más de 60 días: 4.** REQ-4212 (115 días), REQ-4200 (85), REQ-4207 (83) y REQ-4201 (71).
- **Aceptado sin criterio de aceptación: 1.** REQ-4203. Los otros 11 que lo tienen dicen lo mismo, «se verifica en producción», que no permite decir si algo quedó hecho.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- Las transcripciones de las entrevistas, con quién habló, cuántos fueron y qué pidieron. Hoy hay una cita.
- La serie medida de `volumen_mensual`, con su fuente.
- Las decisiones del comité con quién decidió cada una. Sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.
- El plan que «se mantiene».

**Sigue:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.

*Nota técnica:* `sellar` exige una corrida abierta aunque este comando dice que aquí no va `corrida-inicio`. Abrí la marca, reescribí la ficha con el mismo contenido y la selló. Una cita a `caso-de-negocio.md` traía texto además de la ruta y la corregí.
