# Corrida del 2026-10-17 · product-definition

PRD-302 · 14 requerimientos · 25 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

La evidencia sostiene solo la necesidad (una entrevista de hace 13 meses); volumen y retorno sin serie y sin criterio de éxito

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Crédito hipotecario digital (PRD-302) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-11-22-definicion-producto.docx` (con `2025-11-22-caso-de-negocio.md`) · **del** 2025-11-22 · 5 afirmaciones

Afirmaciones separadas: (1) el segmento Personas no tiene crédito hipotecario digital; (2) la propuesta principal; (3) la demanda declarada se sostiene sin campaña; (4) volumen mensual de 130.646; (5) retorno esperado en 24 meses.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. (Esto no es que esté sostenida: ver más abajo.)

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa el umbral (20 %) porque no hay nada medido con qué comparar |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 130.646 | `00-definicion/2025-11-22-caso-de-negocio.md`, 2025-11-22 | No hay serie medida: nadie está midiendo lo que el caso de negocio afirmó. No es contradicción; es ausencia de medición. |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo declara (`success` = no encontrado).
- **Qué contiene la propuesta:** el documento solo trae el rótulo «Propuesta principal», sin contenido.
- **De dónde sale el 130.646 mensual:** el caso de negocio cita como fuente a sí mismo («Caso de negocio, 2025-11-22»); no dice a quién cuenta, en qué período ni con qué método.
- **Qué significa «retorno esperado en 24 meses»:** no hay cifra, ni base de cálculo, ni costo contra el cual compararla.
- **Que el segmento Personas no tenga la oferta:** se afirma, pero ningún documento muestra cómo se verificó (competencia, oferta actual, tamaño del segmento).
- **Quién decide qué se construye:** ningún documento lo declara; el acta del comité del 2026-10-11 sugiere «Comité de producto», pero solo asistió Felipe Arango.
- **Proyectos que lo construyen:** «Ninguno declarado».

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (el documento es del 2025-11-22 y declara el supuesto con fecha 2026-06-26) | 113 (umbral: 30) | Medir solicitudes o preaprobaciones orgánicas durante un período sin campaña y compararlas con el volumen declarado. Hoy no hay cifra medida ni declarada de «con campaña» contra la cual contrastar. |

Nota sobre verificabilidad: el supuesto sí se puede desmentir, pero depende de que primero exista la serie del 130.646.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento tiene una necesidad sin cubrir | Una entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-12-entrevistas.md`) | 2025-09-12 | Débil. Es lo que alguien dijo, no lo que alguien hizo ni pagó; es una sola voz, sin cifra. Respalda la necesidad, no el volumen ni el pago. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del segmento (y los 10 requerimientos que se apoyan en ella: REQ-4200, 4201, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4211) | Entrevista del 2025-09-12 | 13 meses (umbral: 12) |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Datos personales de solicitantes de crédito | No declarado en ningún documento | — | — | No tengo la norma a la vista |
| Consumidor financiero / crédito hipotecario | No declarado | — | — | No tengo la norma a la vista |
| Retención de información crediticia | No declarado | — | — | No tengo la norma a la vista |

El producto roza datos personales, consumidor financiero y retención. Como ningún documento nombra el país, no se cita ninguna norma. Que no haya normas aquí no significa que no apliquen. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- **Propuesta:** falta el contenido.
- Problema (declarado), para quién (Personas) y quién decide (propuesto, no declarado) están en el papel, pero el último sin respaldo.

Otras señales que salen del cálculo, fuera del alcance de este comando: 3 requerimientos aceptados sin evidencia (REQ-4206, 4210, 4213), 9 aceptados sin proyecto que los trace, 4 propuestos sin decidir más de 60 días (REQ-4200, 4201, 4207, 4212). Van a `/product-requirements`.

**Después:** el supuesto lleva 113 días sin verificar. Puedo convertirlo en riesgo con doliente (raid-taxonomy). La definición no está cerrada (falta el criterio de éxito), así que `/product-charter` todavía no aplica.
