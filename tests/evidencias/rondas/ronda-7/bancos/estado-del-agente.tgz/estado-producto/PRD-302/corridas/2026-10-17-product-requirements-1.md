# Corrida del 2026-10-17 · product-requirements

PRD-302 · 14 requerimientos · 32 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

REQ-4206, 4210 y 4213 aceptados sin evidencia; 9 aceptados sin proyecto; 4 propuestos sin decidir pasados de 60 días

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Crédito hipotecario digital (PRD-302) · al 2026-10-17
14 requerimientos · 9 decididos · 66.7% con evidencia (6 de 9) · 0% con proyecto que lo ejecuta

Los títulos en el registro son genéricos («Requerimiento REQ-42xx»): el documento de origen no los nombra. Las fichas de proyecto no se pasaron a esta corrida, así que ningún requerimiento tiene traza confirmada.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4206 | Requerimiento REQ-4206 | aceptado (2026-03-30) | Camilo Beltrán |
| REQ-4210 | Requerimiento REQ-4210 | aceptado (2026-03-17) | Ricardo Salas |
| REQ-4213 | Requerimiento REQ-4213 | aceptado (2026-06-03) | Paula Céspedes |

Los tres están aceptados sin una sola cita de quien lo pidió.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el |
|---|---|---|
| REQ-4210 | Requerimiento REQ-4210 | 2026-03-17 |
| REQ-4206 | Requerimiento REQ-4206 | 2026-03-30 |
| REQ-4203 | Requerimiento REQ-4203 | 2026-04-17 |
| REQ-4205 | Requerimiento REQ-4205 | 2026-04-25 |
| REQ-4209 | Requerimiento REQ-4209 | 2026-05-11 |
| REQ-4213 | Requerimiento REQ-4213 | 2026-06-03 |
| REQ-4208 | Requerimiento REQ-4208 | 2026-06-18 |
| REQ-4204 | Requerimiento REQ-4204 | 2026-08-05 |
| REQ-4211 | Requerimiento REQ-4211 | 2026-08-06 |

Los 9 aceptados llevan entre 2 y 7 meses sin proyecto en el registro. Con las fichas de proyecto se confirma si alguno ya lo construye bajo otro nombre; hasta entonces es «sin traza», no «sin proyecto». Siguiente paso: `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4200 | Requerimiento REQ-4200 | sin doliente (propuesto) |
| REQ-4201 | Requerimiento REQ-4201 | sin doliente (propuesto) |
| REQ-4207 | Requerimiento REQ-4207 | sin doliente (propuesto) |

Quién lo cierra: Felipe Arango (gerente de producto) asigna doliente antes del próximo comité.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4203 | Requerimiento REQ-4203 | aceptado (doliente: Liliana Torres) |

Solo los decididos. REQ-4200 y REQ-4207 tampoco lo tienen, pero están propuestos y no se les exige.

### Decidido sin documento que lo respalde
Los 9 decididos citan el acta del Comité de producto del 2026-10-11, así que el documento existe. Lo que falta es otro dato:

| REQ | Quién decidió | Cuándo |
|---|---|---|
| REQ-4203, 4204, 4205, 4206, 4208, 4209, 4210, 4211, 4213 | no consta en el registro | entre 2026-03-17 y 2026-08-06 |

Las fechas de decisión son anteriores al acta que las respalda (2026-10-11): el acta recoge decisiones tomadas meses antes. Conviene confirmar que el comité ratificó cada una.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4212 | Requerimiento REQ-4212 | 115 días (desde 2026-06-24) | Comité de producto |
| REQ-4200 | Requerimiento REQ-4200 | 85 días (desde 2026-07-24) | Comité de producto |
| REQ-4207 | Requerimiento REQ-4207 | 83 días (desde 2026-07-26) | Comité de producto |
| REQ-4201 | Requerimiento REQ-4201 | 71 días (desde 2026-08-07) | Comité de producto |

La facultad sale de la configuración (autoridad: Comité de producto). Se propone que el comité los decida, no que se cierren por viejos. REQ-4212 además no tiene evidencia. REQ-4202 (50 días) todavía no cruza el umbral.

### Evidencia vieja
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4200, 4201, 4202, 4203, 4204, 4205, 4207, 4208, 4209, 4211 | Entrevistas del 2025-09-12 («Lo necesito y hoy no lo tengo.») | 13 meses |

Diez requerimientos descansan en la misma entrevista de hace 13 meses, y el umbral es 12. Es una sola fuente repetida, no diez.

### De la definición (fuera del registro)
- Supuesto sin verificar hace 113 días: «La demanda declarada se sostiene sin campaña».
- El caso de negocio declara un volumen mensual de 130.646 (2025-11-22) y no hay medición contra la que contrastarlo.
- La definición no trae criterio de éxito.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 9 | 0 | 0 | 0 |

Ninguno descartado: si hubo discusiones cerradas, no están registradas.
