# Corrida del 2026-10-17 · product-trace

PRD-302 · 14 requerimientos · 29 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

9 requerimientos decididos y ningún proyecto los construye; ninguna ficha dice ejecutar PRD-302

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Crédito hipotecario digital (PRD-302) · al 2026-10-17
9 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Se pasaron las 13 fichas de la PMO (PRY-199 a PRY-211). Ninguna traza se pudo confirmar, porque ningún requerimiento nombra un proyecto.

### Decidido y nadie lo está construyendo
Los 9 requerimientos aceptados tienen `project: null` y ningún entregable. Todos salen de `documentos/productos/PRD-302/30-decisiones/2026-10-11-comite-producto.docx`. El registro no guarda quién decidió (`who: null`); la autoridad es el Comité de producto.

| REQ | Título | Decidido el | Por quién | Dueño |
|---|---|---|---|---|
| REQ-4210 | Requerimiento REQ-4210 | 2026-03-17 | no registrado (Comité de producto) | Ricardo Salas |
| REQ-4206 | Requerimiento REQ-4206 | 2026-03-30 | no registrado (Comité de producto) | Camilo Beltrán |
| REQ-4203 | Requerimiento REQ-4203 | 2026-04-17 | no registrado (Comité de producto) | Liliana Torres |
| REQ-4205 | Requerimiento REQ-4205 | 2026-04-25 | no registrado (Comité de producto) | Mauricio Pérez |
| REQ-4209 | Requerimiento REQ-4209 | 2026-05-11 | no registrado (Comité de producto) | María Restrepo |
| REQ-4213 | Requerimiento REQ-4213 | 2026-06-03 | no registrado (Comité de producto) | Paula Céspedes |
| REQ-4208 | Requerimiento REQ-4208 | 2026-06-18 | no registrado (Comité de producto) | Javier Hoyos |
| REQ-4204 | Requerimiento REQ-4204 | 2026-08-05 | no registrado (Comité de producto) | Jorge Medina |
| REQ-4211 | Requerimiento REQ-4211 | 2026-08-06 | no registrado (Comité de producto) | Jorge Medina |

El más antiguo lleva 214 días decidido sin proyecto (REQ-4210). Los títulos del registro son genéricos; hay que leer el acta para saber qué se decidió en cada uno.

### La traza no se confirma
Ninguna: ningún requerimiento dice ejecutarse en un proyecto, así que no hay traza que contrastar con una ficha.

### Lo que un proyecto construye y el registro no tiene
Ninguno. De las 13 fichas, ninguna dice que ejecuta PRD-302 ni «Crédito hipotecario digital». Declaran otros productos:

| Proyecto | Su ficha dice que ejecuta | Nota |
|---|---|---|
| PRY-199 | PRD-299 | |
| PRY-200 | crédito de consumo | |
| PRY-201 | cuenta de ahorros | |
| PRY-203 | APIs de datos | |
| PRY-204 | tarjeta débito | |
| PRY-206 | pagos QR | |
| PRY-207 | cuenta PyME | |
| PRY-209 | nómina empresarial | |
| PRY-211 | recaudos | |
| PRY-202, PRY-205, PRY-208, PRY-210 | campo vacío | Hallazgo del otro lado: su ficha no dice qué producto ejecuta. Alguno podría ser el de este producto, pero la ficha no lo dice |

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4210 | aceptado | 2026-03-17 | — | no | — |
| REQ-4206 | aceptado | 2026-03-30 | — | no | — |
| REQ-4203 | aceptado | 2026-04-17 | — | no | — |
| REQ-4205 | aceptado | 2026-04-25 | — | no | — |
| REQ-4209 | aceptado | 2026-05-11 | — | no | — |
| REQ-4213 | aceptado | 2026-06-03 | — | no | — |
| REQ-4208 | aceptado | 2026-06-18 | — | no | — |
| REQ-4204 | aceptado | 2026-08-05 | — | no | — |
| REQ-4211 | aceptado | 2026-08-06 | — | no | — |
| REQ-4200, 4201, 4202, 4207, 4212 | propuesto | sin decidir | — | no aplica | — |

La cadena se rompe en el segundo eslabón: la decisión existe y cita el acta del 2026-10-11, pero no pasa a ningún proyecto.

### Sin fichas a la vista
Todas las fichas de la carpeta se leyeron. Aun así, esto no prueba que no exista un proyecto que construya el producto: puede existir sin ficha publicada, o con una ficha de campo vacío (PRY-202, PRY-205, PRY-208, PRY-210).
