# Corrida del 2026-10-17 · product-publish

PRD-302 · 14 requerimientos · 16 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

No se publicó: no hay carpeta de productos publicados configurada ni existente

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-302 (Crédito hipotecario digital).** Corte al 2026-10-17.

Motivo: la configuración (`.criterio/producto/PRD-302/config.json`) no define una carpeta de productos publicados, y en el espacio no existe ninguna (`productos/publicados/` ni equivalente). Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la creé ni la inventé.

**Lo que habría publicado (ya calculado, listo para cuando haya carpeta):**
- Requerimientos: 14 (9 aceptados, 5 propuestos)
- Proyectos: 0 (ningún requerimiento tiene proyecto enlazado)
- Métricas afirmadas: 1
- Segmento declarado: Personas
- Métrica: `volumen_mensual` = 130646.0, del documento `documentos/productos/PRD-302/00-definicion/2025-11-22-caso-de-negocio.md` (2025-11-22)

Nota: sin proyectos publicados, `/product-overlap` solo podría cruzar este producto por métrica y por segmento, no por proyecto compartido.

**Para destrabar:** que la organización acuerde la carpeta común y se configure; después se vuelve a correr y escribe `PRD-302.json` allí.

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.
