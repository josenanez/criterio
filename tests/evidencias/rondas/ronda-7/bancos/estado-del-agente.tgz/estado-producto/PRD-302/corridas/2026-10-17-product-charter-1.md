# Corrida del 2026-10-17 · product-charter

PRD-302 · 14 requerimientos · 40 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

Borrador de acta para REQ-4203 sin firmar y sin ficha creada. Dijo que no sabe: criterio de aceptación, qué es el requerimiento, patrocinador, gerente y autoridad del proyecto, quién lo aceptó, presupuesto, hitos y obligaciones normativas. Evidencia: una entrevista anónima de hace 13 meses que no lo nombra.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Verificación previa (paso 1): REQ-4203 está **aceptado** (2026-04-17), pero **no tiene criterios de aceptación**, **no tiene declarada la autoridad del gerente del proyecto** y su evidencia de demanda es una entrevista de hace 13 meses que no lo nombra. Es una sesión sin interfaz: tomo la respuesta sugerida —seguir sin eso, marcándolo como vacío del acta, sin rellenarlo— y sigo. Términos: ya vigentes (v1.1, familia 0.3.13), aceptados por José Francisco Ñáñez el 2026-10-17; no se vuelven a pedir.

# Acta de constitución — Proyecto para REQ-4203 (nombre por definir) · borrador del 2026-10-17
**Producto:** PRD-302 · Crédito hipotecario digital · **Requerimientos:** REQ-4203

> El registro titula el requerimiento solo «Requerimiento REQ-4203»: el acta del comité no lo nombra. **No sé qué es lo que se va a construir.** El campo «necesidad» del registro está vacío.

## Qué problema resuelve
Del producto, no de este requerimiento: «El segmento Personas no tiene crédito hipotecario digital.» (`documentos/productos/PRD-302/00-definicion/2025-11-22-definicion-producto.docx`, 2025-11-22).
Cómo REQ-4203 contribuye a resolverlo: **no está dicho en ningún documento** (ver vacíos). La propuesta de la definición trae solo el rótulo «Propuesta principal», sin contenido.

## Criterio de éxito
**Vacío.** El requerimiento no tiene criterio de aceptación: la columna del acta del comité dice «—» (`30-decisiones/2026-10-11-comite-producto.docx`, 2026-10-11). Los otros requerimientos dicen «se verifica en producción», que tampoco es un criterio medible. La definición del producto tampoco declara criterio de éxito. Sin esto el cierre del proyecto no se puede juzgar meses después.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4203 | Requerimiento REQ-4203 (sin título propio) | Una cita: «Lo necesito y hoy no lo tengo.» — cliente entrevistado, tema «Necesidad principal» (`10-descubrimiento/2025-09-12-entrevistas.md`, 2025-09-12). **Es la entrevista más cercana, no una que nombre el requerimiento**; es anónima, tiene 13 meses (el umbral es 12) y es la misma que sostiene a otros 9 requerimientos. El acta del comité dice que lo pidió un «cliente entrevistado». |

### No entra
Esta acta cubre solo REQ-4203. Ninguno de los otros 13 fue excluido por una decisión escrita; **no entran porque no se pidieron en esta acta**, y eso hay que decirlo así, no como exclusión razonada.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4200, 4201, 4202, 4207, 4212 | Requerimiento REQ-42xx | Propuestos, no aceptados: nadie decidió que se construyan (4200, 4201, 4207 y 4212 llevan más de 60 días sin decidirse). |
| REQ-4204, 4205, 4206, 4208, 4209, 4210, 4211, 4213 | Requerimiento REQ-42xx | Aceptados, pero no incluidos en esta acta. Hay que decidir si van en otra acta o en esta; ningún documento lo dice. 4206, 4210 y 4213 además no tienen quién los pidió. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no propongo a nadie. El gerente del *producto* es Felipe Arango (definición, 2025-11-22); el del *proyecto* no consta en ninguna parte y lo nombra quien tenga la autoridad.
- **Doliente del requerimiento:** Liliana Torres (acta del comité, 2026-10-11).
- **Comité:** Comité de producto (acta del 2026-10-11). Solo Felipe Arango figura como asistente. El único acuerdo escrito es «Se mantiene el plan»; no hay plan en los documentos.
- **Autoridad que decide qué se construye:** el registro dice «Comité de producto», pero la nota de la ficha lo marca como propuesto por el acta: ningún documento declara quién decide.
- **Autoridad del gerente del proyecto:** no está dicho. Es el campo que más cuesta después.
- **Quién aceptó REQ-4203:** no consta. La decisión es del 2026-04-17; el acta que la recoge es del 2026-10-11, casi seis meses después.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (definición; declarado el 2026-06-26, en un documento fechado 2025-11-22) | No. 113 días sin verificar; el umbral es 30. | Por asignar: el gerente del proyecto, al ser nombrado. Se registra como riesgo en `/pm-setup`. |
| El volumen mensual de 130.646 del caso de negocio (2025-11-22) | No hay medición contra la que contrastarlo. | Por asignar. Es una cifra del negocio, no del agente. |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito hipotecario a personas, digital (datos personales, consumidor financiero) | No barrido: ningún documento del producto cita obligaciones | No identificada | **Sin resolver.** No opino sobre cumplimiento. Falta el barrido normativo. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de aceptación de REQ-4203 | El proyecto no tiene con qué medirse ni cerrarse | Liliana Torres (doliente) |
| Qué es REQ-4203 (necesidad, título) | Se firma un acta sobre algo que no se puede describir | Liliana Torres |
| Evidencia de demanda propia, no la entrevista general de 2025-09-12 | El proyecto descansa en una cita anónima de hace 13 meses | Felipe Arango |
| Quién aceptó el requerimiento y con qué base | La decisión no se puede rastrear | Comité de producto |
| Patrocinador y gerente del proyecto | No hay a quién entregarle la ficha | Quien tenga la autoridad |
| Autoridad del gerente del proyecto | Escala todo o no escala nada | Comité de producto |
| Criterio de éxito de la definición y contenido de la propuesta | El «problema» no tiene resultado esperado | Felipe Arango |
| Presupuesto y hitos | La ficha nace sin ellos; no hay línea base posible | Comité de producto |
| Prioridad | No se puede ordenar frente a los demás requerimientos | Felipe Arango |
| Barrido normativo | Obligaciones sin descubrir hasta tarde | Quien el comité designe |

**Mi lectura:** el acta se puede firmar con estos vacíos, pero es una decisión de quien firma, no mía.

---
**Esto es un borrador.** Lo firma quien tenga la autoridad de decidir qué se construye (hoy sin declarar; el registro propone al Comité de producto). **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`, sin llenar el estado declarado.

**Qué sigue y para quién:** quien sea nombrado gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
