# Corrida del 2026-10-17 · product-business-case

PRD-302 · 14 requerimientos · 39 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

Caso de negocio armado: 1 cifra declarada que se cita a sí misma, sin serie medida, costos y criterio de éxito sin fuente; no se corrió cruce con otros productos (sin fichas publicadas)

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Crédito hipotecario digital (PRD-302) · borrador del 2026-10-17
**Desde:** definición del 2025-11-22 (`documentos/productos/PRD-302/00-definicion/2025-11-22-definicion-producto.docx`) · **Cifras con fuente:** 0 de 1 con fuente independiente (la única cifra cita como fuente el propio caso de negocio)

Términos: vigentes y aceptados por José Francisco Ñáñez el 2026-10-17 (versión 1.1); no hizo falta volver a registrarlos.

## Qué problema resuelve, y para quién
«El segmento Personas no tiene crédito hipotecario digital.» Segmento: Personas. (Definición, 2025-11-22.)
La propuesta de la definición trae solo el rótulo «Propuesta principal», sin contenido: lo que se construye no está descrito en ningún documento.

## Qué se construye
Entran al caso los 9 requerimientos decididos (aceptados) en el acta del Comité de producto del 2026-10-11. Los 5 propuestos quedan fuera hasta que se decidan: REQ-4200, 4201, 4202, 4207 y 4212.

| Requerimiento | Estado (desde) | Doliente | Evidencia de demanda |
|---|---|---|---|
| REQ-4203 | aceptado (2026-04-17) | Liliana Torres | «Lo necesito y hoy no lo tengo.» — cliente entrevistado, 2025-09-12 (la entrevista no nombra el requerimiento; es la más cercana) |
| REQ-4204 | aceptado (2026-08-05) | Jorge Medina | La misma entrevista, con la misma salvedad |
| REQ-4205 | aceptado (2026-04-25) | Mauricio Pérez | La misma entrevista, con la misma salvedad |
| REQ-4206 | aceptado (2026-03-30) | Camilo Beltrán | **Sin evidencia: el acta no dice quién lo pidió** |
| REQ-4208 | aceptado (2026-06-18) | Javier Hoyos | La misma entrevista, con la misma salvedad |
| REQ-4209 | aceptado (2026-05-11) | María Restrepo | La misma entrevista, con la misma salvedad |
| REQ-4210 | aceptado (2026-03-17) | Ricardo Salas | **Sin evidencia: el acta no dice quién lo pidió** |
| REQ-4211 | aceptado (2026-08-06) | Jorge Medina | La misma entrevista, con la misma salvedad |
| REQ-4213 | aceptado (2026-06-03) | Paula Céspedes | **Sin evidencia: el acta no dice quién lo pidió** |

- 6 de 9 apoyados en una sola entrevista de un cliente, de hace más de 13 meses (2025-09-12), que no nombra ninguno de ellos.
- Ningún requerimiento tiene proyecto que lo ejecute (la definición dice «Ninguno declarado»).
- Los títulos en el registro son genéricos: el acta no los nombra.
- Criterio de aceptación: REQ-4203 no tiene; los otros 8 dicen «se verifica en producción», que no es un criterio verificable.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 130.646 | **Declarada** | `00-definicion/2025-11-22-caso-de-negocio.md`, preparado por Felipe Arango. La columna «Fuente» de ese documento dice «Caso de negocio, 2025-11-22»: la cifra se cita a sí misma. No hay documento de origen. | 2025-11-22 |
| Retorno esperado | «en 24 meses» | **Sin cifra** | El caso lo afirma sin monto, base ni cálculo. No se reconstruye aquí. | 2025-11-22 |

La unidad de `volumen_mensual` (solicitudes, desembolsos, usuarios, monto) no está dicha en ningún documento.

### Donde la cifra declarada y la medida no coinciden
No hay serie medida de PRD-302: no existe carpeta `20-metricas` para este producto. Sin la medida no hay contraste posible, y no se inventa una. Umbral configurado para la brecha: 20 %.

| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 130.646 (2025-11-22) | sin serie | — |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — |
| Contratos, cotizaciones, costo declarado del equipo | No hay | — |

Este es el primer vacío. Sin el costo de construir lo que hay es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» — declarado el 2026-06-26, sin verificar (113 días; el umbral es 30) | El volumen de 130.646 al mes no se alcanza sin gasto de adquisición. Ese gasto no está en el caso (costos vacíos) y el retorno a 24 meses cambia. | No consta. Corresponde a quien produce la serie de volumen; el dueño del supuesto es Felipe Arango como gerente del producto. |
| Implícito: la demanda de 2025-09-12 sigue vigente | Los 6 requerimientos que se apoyan en esa entrevista quedan sin sustento. | Descubrimiento (nueva ronda) |
| Implícito: el volumen de 130.646 se mantiene desde noviembre de 2025 | Toda cifra derivada se mueve. | Sistema donde el producto vive, o el negocio |

Anomalía de fechas: el supuesto lleva fecha 2026-06-26 dentro de un documento fechado 2025-11-22. Hay que aclarar si el documento se editó después sin cambiar su fecha.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir | Sin él no hay caso que evaluar | Quien lleve el presupuesto del producto (no consta) |
| Origen de `volumen_mensual` = 130.646 y su unidad | La cifra se cita a sí misma | Felipe Arango |
| Monto y cálculo del retorno «en 24 meses» | No hay cifra, solo una frase | El negocio |
| Qué pasa si no se hace | No dicho en ningún documento | El negocio |
| Alternativas consideradas | No dichas | El negocio |
| Contenido de la propuesta | Solo el rótulo «Propuesta principal» | Felipe Arango |
| Criterio de éxito | No encontrado en la definición | Felipe Arango / Comité de producto |
| Serie medida de volumen | Impide contrastar lo declarado | El sistema del producto |
| Autor de la aceptación de los 9 requerimientos | El acta no dice quién decidió | Comité de producto |
| Quién decide qué se construye | El acta propone al Comité; ningún documento lo declara | Quien nombró al producto |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito, y el caso solo dice «retorno esperado en 24 meses», sin métrica ni fecha de corte verificable. Sin esto el producto no se puede cerrar meses después. Una propuesta mínima a decidir por el negocio: la métrica (¿`volumen_mensual`?), su valor objetivo, su fuente de medición y la fecha de corte. No se propone el valor.

## Si hay otros productos publicados
No hay fichas publicadas por otros productos a la vista (no se pasó carpeta de fichas), así que no se corrió el cruce de `/product-overlap`. Como verificación parcial: la cifra 130.646 no aparece en ningún documento de los otros productos de la carpeta de documentación; solo en los de PRD-302.

## Lo que este documento no hace
No proyecta ingresos, retorno ni ahorro, no calcula recuperación y no recomienda aprobar o rechazar. Decidir es del Comité de producto.

## Siguiente paso
Pasar los 3 supuestos a seguimiento con **assumption-tracking**, y no abrir `/product-charter` hasta que existan al menos el costo de construir y el criterio de éxito.
