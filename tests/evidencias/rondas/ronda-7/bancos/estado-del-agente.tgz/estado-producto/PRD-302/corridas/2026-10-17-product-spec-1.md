# Corrida del 2026-10-17 · product-spec

PRD-302 · 14 requerimientos · 35 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |
| `assumption_unverified` | 1 |

Borrador de especificación sobre 9 aceptados: no se redactó comportamiento porque ningún REQ tiene título ni necesidad; criterio 'se verifica en producción' no verificable en 8, ninguno en REQ-4203; vacíos con dueño; barrido normativo no hecho; 9 de 9 sin cobertura.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

> **Borrador de especificación, no aprobado.** Lo cierra Felipe Arango (gerente de producto) con la autoridad del Comité de producto; este agente no puede firmarlo.

# Especificación — Crédito hipotecario digital (PRD-302) · borrador del 2026-10-17

## Qué problema resuelve
«El segmento Personas no tiene crédito hipotecario digital.» (`2025-11-22-definicion-producto.docx`). La definición no trae criterio de éxito, y su «propuesta principal» es solo un rótulo sin contenido. Ninguno de los 9 requerimientos aceptados tiene la necesidad escrita, así que **no hay de dónde sacar el comportamiento**.

## Alcance
### Entra
Los 9 requerimientos en estado `aceptado` (acta del Comité de producto, 2026-10-11): REQ-4203, 4204, 4205, 4206, 4208, 4209, 4210, 4211, 4213. Ninguno está `en_construccion`. Entran **solo como registro**: ningún título ni necesidad permite describir qué hacen (ver «Comportamiento»).

### No entra
- REQ-4200, 4201, 4202, 4207, 4212: están `propuesto`; nadie los ha decidido. REQ-4200, 4201 y 4207 además no tienen doliente.
- Arquitectura, estimación, costo y fechas: no son de este documento.
- Cualquier comportamiento no escrito en el registro. Lo que no está en el acta no se infiere de «un crédito hipotecario digital».

## Comportamiento
**No se redacta ninguno.** Los 9 títulos son genéricos («Requerimiento REQ-42xx») y el campo `necesidad` está vacío en todos. Escribir comportamiento sería inventarlo y dejar decidido por el agente lo que nadie decidió. Lo que el registro sí sostiene:

| Requerimiento | Doliente | Decidido el | Criterio registrado |
|---|---|---|---|
| REQ-4203 | Liliana Torres | 2026-04-17 | ninguno |
| REQ-4204 | Jorge Medina | 2026-08-05 | «se verifica en producción» |
| REQ-4205 | Mauricio Pérez | 2026-04-25 | «se verifica en producción» |
| REQ-4206 | Camilo Beltrán | 2026-03-30 | «se verifica en producción» |
| REQ-4208 | Javier Hoyos | 2026-06-18 | «se verifica en producción» |
| REQ-4209 | María Restrepo | 2026-05-11 | «se verifica en producción» |
| REQ-4210 | Ricardo Salas | 2026-03-17 | «se verifica en producción» |
| REQ-4211 | Jorge Medina | 2026-08-06 | «se verifica en producción» |
| REQ-4213 | Paula Céspedes | 2026-06-03 | «se verifica en producción» |

Fuente de todas las filas: `30-decisiones/2026-10-11-comite-producto.docx`. Quién decidió cada una no consta.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | 4204, 4205, 4206, 4208, 4209, 4210, 4211, 4213 | No dice qué se observa, con qué umbral ni quién lo observa. Dos personas mirando lo construido no llegarían a la misma respuesta. | **No es un criterio**: es el lugar donde iría uno. No verificable |
| (ninguno) | 4203 | — | No hay nada que medir |

No propongo umbrales (segundos, percentiles, tasas): serían cifras mías, no del negocio. Cada doliente debe decir qué observaría para dar el requerimiento por bien hecho.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La demanda declarada se sostiene sin campaña» (definición; declarado el 2026-06-26, sin verificar hace ~113 días, umbral 30) | No | Felipe Arango |
| La demanda de 130.646 mensuales del caso de negocio (2025-11-22) existe; no hay medición contra la que contrastarla | No | Felipe Arango |
| «Lo necesito y hoy no lo tengo» (1 cliente, entrevista del 2025-09-12, 13 meses; umbral 12) respalda a los requerimientos que lo citan. La entrevista no nombra ningún REQ | Parcial: es una sola fuente repetida | Felipe Arango (autor de las entrevistas) |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Título y necesidad de cada uno de los 9 aceptados | No se puede escribir comportamiento; la especificación queda vacía | Cada doliente (tabla de arriba) |
| Criterio de aceptación de REQ-4203 | Aceptado sin forma de saber si está hecho | Liliana Torres |
| Criterio verificable en los otros 8 (reemplazar «se verifica en producción») | Cada parte puede declarar el éxito o el fracaso | Sus dolientes; valida Felipe Arango |
| Criterio de éxito del producto | No hay contra qué medir el conjunto | Felipe Arango |
| Quién decidió cada aceptación y si el comité la ratificó (decisiones de 2026-03 a 2026-08, acta de 2026-10-11) | La aceptación no se puede defender ante una auditoría | Comité de producto |
| Casos borde: sin conexión, solicitud duplicada, abandono antes de la confirmación, rechazo del crédito | Quedan a criterio de quien construya | Sin dueño. **Felipe Arango asigna uno**, porque ningún documento dice quién |
| Qué otros equipos deben hacer algo (riesgo, avalúo, notarías, canales): no consta en ningún documento | Dependencias sin acordar | Felipe Arango, con los equipos que identifique |
| Obligaciones normativas: un crédito hipotecario digital roza datos personales, consumidor financiero y retención de información. Ningún documento cita una obligación y este borrador no hizo el barrido | El criterio «cumple la normativa» no se puede escribir | Felipe Arango asigna a quien corresponda; el área no está nombrada en los documentos |
| Proyecto que construya cada requerimiento (0 de 9 con traza) | Aceptado desde hace 2 a 7 meses sin constructor visible | Felipe Arango; siguiente paso `/product-trace` |
| REQ-4206, 4210 y 4213 aceptados sin evidencia de quien lo pidió | Se construye algo que nadie ha pedido | Camilo Beltrán, Ricardo Salas, Paula Céspedes |

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4203 | Requerimiento REQ-4203 | Sin necesidad, sin criterio de aceptación. Solo figura en el registro |
| REQ-4204 | Requerimiento REQ-4204 | Sin necesidad; criterio no verificable |
| REQ-4205 | Requerimiento REQ-4205 | Sin necesidad; criterio no verificable |
| REQ-4206 | Requerimiento REQ-4206 | Sin necesidad ni evidencia; criterio no verificable |
| REQ-4208 | Requerimiento REQ-4208 | Sin necesidad; criterio no verificable |
| REQ-4209 | Requerimiento REQ-4209 | Sin necesidad; criterio no verificable |
| REQ-4210 | Requerimiento REQ-4210 | Sin necesidad ni evidencia; criterio no verificable |
| REQ-4211 | Requerimiento REQ-4211 | Sin necesidad; criterio no verificable |
| REQ-4213 | Requerimiento REQ-4213 | Sin necesidad ni evidencia; criterio no verificable |

**Los 9 aceptados quedan sin cobertura de comportamiento.** No es un descuido del borrador: el registro no trae material para cubrirlos sin inventar.

---
Sale del registro de PRD-302 al 2026-10-17 (14 requerimientos; cubre 9, el resto son propuestos). Fuentes: acta del Comité de producto 2026-10-11, definición y caso de negocio 2025-11-22, entrevistas 2025-09-12. Borrador de trabajo, no asesoría; la verificación es suya. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** `/product-charter` no se ofrece todavía: los vacíos no están cerrados y el producto no tiene criterio de éxito.
