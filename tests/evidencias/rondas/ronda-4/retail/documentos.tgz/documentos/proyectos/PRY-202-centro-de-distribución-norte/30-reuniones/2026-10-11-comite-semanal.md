# Comité de Arquitectura · Centro de distribución norte

**Fecha:** 2026-10-11
**Asistentes:** Felipe Arango, Ricardo Salas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 7 | 2026-10-11 |
| María Restrepo | Entregar el punto 22 | 2026-09-28 |
