# Informe de avance · Iluminación LED en bodegas

**Código:** PRY-199
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- La validación con dos tiendas se extendió una semana por el conteo de inventario
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Disponibilidad de los jefes de tienda para el piloto
