# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-04
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +59 días sobre la línea base vigente |
| Costo | 118.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
