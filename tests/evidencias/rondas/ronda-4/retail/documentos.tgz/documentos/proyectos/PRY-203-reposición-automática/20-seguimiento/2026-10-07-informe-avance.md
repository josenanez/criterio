# Informe de avance · Reposición automática

**Código:** PRY-203
**Fecha de corte:** 2026-10-07
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **47%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.051.411.740 |
| Ejecutado | 3.562.697.966 |
| Proyección al cierre | 6.283.634.402 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
