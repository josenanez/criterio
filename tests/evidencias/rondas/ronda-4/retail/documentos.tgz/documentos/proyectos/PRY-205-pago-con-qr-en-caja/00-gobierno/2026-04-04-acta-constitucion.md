# Acta de constitución · Pago con QR en caja

**Código:** PRY-205
**Área dueña:** Abastecimiento
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Expansión
**Producto asociado:** pago con QR
**Fecha de aprobación:** 2026-04-04

## Objetivo del negocio

Entregar pago con qr en caja para Abastecimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Expansión el 2026-04-04.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-14 |
| Cierre | 2027-11-29 |

## Criterio de éxito

Pago con QR en caja en producción y medido.

## Dependencias declaradas

- Ninguna declarada
