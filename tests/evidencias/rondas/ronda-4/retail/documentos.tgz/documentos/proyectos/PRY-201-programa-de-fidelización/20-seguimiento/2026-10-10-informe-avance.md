# Informe de avance · Programa de fidelización

**Código:** PRY-201
**Fecha de corte:** 2026-10-10
**Gerente:** María Restrepo

## Estado declarado

**Rojo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en los medios de pago
- Se reprogramó el despliegue por el congelamiento de temporada de fin de año

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.342.015.470 |
| Ejecutado | 1.176.506.415 |
| Proyección al cierre | 6.315.003.234 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
- Concentración del conocimiento en una sola persona
