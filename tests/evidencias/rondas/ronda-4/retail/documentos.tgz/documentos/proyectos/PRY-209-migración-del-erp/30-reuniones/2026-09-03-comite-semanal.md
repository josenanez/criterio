# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-09-03
**Asistentes:** Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-09-16 |
| Diana Molina | Cerrar la prueba 2 | 2026-09-10 |
| Elena Duarte | Revisar el anexo 3 | por definir |
| Sandra Gil | Validar el ambiente 4 | 2026-09-29 |
