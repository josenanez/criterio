# Acta de constitución · Tienda en línea

**Código:** PRY-200
**Área dueña:** Servicio al cliente
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Expansión
**Producto asociado:** venta en línea
**Fecha de aprobación:** 2025-07-09

## Objetivo del negocio

Entregar tienda en línea para Servicio al cliente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Expansión el 2025-07-09.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-19 |
| Cierre | 2026-04-11 |

## Criterio de éxito

Tienda en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
