# Acta de constitución · Cajas de autopago

**Código:** PRY-204
**Área dueña:** Abastecimiento
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Gustavo Neira
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** autopago en tienda
**Fecha de aprobación:** 2025-10-01

## Objetivo del negocio

Entregar cajas de autopago para Abastecimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2025-10-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-11 |
| Cierre | 2027-04-19 |

## Criterio de éxito

Cajas de autopago en producción y medido.

## Dependencias declaradas

- Ninguna declarada
