# Informe de avance · Pago con QR en caja

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Laura Vélez

## Estado declarado

**Verde**

Avance reportado: **40%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 13.450.515.565 |
| Ejecutado | 6.852.372.711 |
| Proyección al cierre | 20.834.384.205 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
