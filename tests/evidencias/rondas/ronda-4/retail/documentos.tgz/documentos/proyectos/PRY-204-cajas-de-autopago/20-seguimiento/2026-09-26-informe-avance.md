# Informe de avance · Cajas de autopago

**Código:** PRY-204
**Fecha de corte:** 2026-09-26
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **32%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se levantó un hallazgo de seguridad en los medios de pago
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 894.302.033 |
| Ejecutado | 501.728.889 |
| Proyección al cierre | 1.342.154.042 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
- Congelamiento de cambios en temporada alta
