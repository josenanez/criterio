# Caso de negocio · Compra y recoge

**Código:** PRD-307
**Fecha:** 2026-02-15
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 56.030 | Caso de negocio, 2026-02-15 |

## Retorno esperado

Retorno esperado en 24 meses.
