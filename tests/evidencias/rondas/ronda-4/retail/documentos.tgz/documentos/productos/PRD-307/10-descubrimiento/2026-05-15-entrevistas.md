# Entrevistas · Compra y recoge

**Ronda:** Ronda · 2026-05-15
**Realizadas por:** Paula Céspedes

### Cliente entrevistado · 2026-05-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
