# Definición de producto · Pago con QR

**Código:** PRD-303
**Gerente de producto:** Natalia Ospina
**Segmento:** Jóvenes
**Fecha de la definición:** 2026-04-04

## El problema

El segmento Jóvenes no tiene pago con qr.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación de datos lo permite** · declarado el 2026-04-23 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
