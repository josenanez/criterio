# Comité de producto · Compra y recoge

**Fecha:** 2026-10-12
**Asistentes:** Paula Céspedes

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4701 | Requerimiento REQ-4701 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-19 | — |
| REQ-4702 | Requerimiento REQ-4702 | Óscar Ramírez | se verifica en producción | — | propuesto | 2026-09-01 | — |
| REQ-4703 | Requerimiento REQ-4703 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-20 | — |
| REQ-4704 | Requerimiento REQ-4704 | María Restrepo | — | Cliente entrevistado | aceptado | 2026-07-31 | — |
| REQ-4705 | Requerimiento REQ-4705 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-07 | — |
| REQ-4706 | Requerimiento REQ-4706 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-26 | — |
| REQ-4707 | Requerimiento REQ-4707 | Gustavo Neira | se verifica en producción | — | aceptado | 2026-07-14 | — |
| REQ-4708 | Requerimiento REQ-4708 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-20 | — |
| REQ-4709 | Requerimiento REQ-4709 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-23 | — |
| REQ-4710 | Requerimiento REQ-4710 | Sandra Gil | se verifica en producción | — | aceptado | 2026-07-02 | — |
| REQ-4711 | Requerimiento REQ-4711 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-23 | — |

## Decisiones

- Se mantiene el plan
