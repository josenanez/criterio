# Caso de negocio · Pago con QR

**Código:** PRD-303
**Fecha:** 2026-04-04
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 97.542 | Caso de negocio, 2026-04-04 |

## Retorno esperado

Retorno esperado en 24 meses.
