# Caso de negocio · Venta en línea

**Código:** PRD-300
**Fecha:** 2025-11-26
**Preparado por:** María Restrepo

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 228.369 | Caso de negocio, 2025-11-26 |

## Retorno esperado

Retorno esperado en 24 meses.
