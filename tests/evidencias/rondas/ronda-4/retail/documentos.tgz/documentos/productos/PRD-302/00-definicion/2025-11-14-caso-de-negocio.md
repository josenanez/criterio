# Caso de negocio · Autopago en tienda

**Código:** PRD-302
**Fecha:** 2025-11-14
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 130.371 | Caso de negocio, 2025-11-14 |

## Retorno esperado

Retorno esperado en 24 meses.
