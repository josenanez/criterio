# Tablero de métricas · Puntos de fidelización

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-30

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 137.303 | 2026-09-30 |
