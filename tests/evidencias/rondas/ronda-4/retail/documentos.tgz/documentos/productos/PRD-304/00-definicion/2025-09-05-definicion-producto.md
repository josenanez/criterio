# Definición de producto · Marca propia

**Código:** PRD-304
**Gerente de producto:** Andrés Lozano
**Segmento:** Jóvenes
**Fecha de la definición:** 2025-09-05

## El problema

El segmento Jóvenes no tiene marca propia.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-05-07 · verificado

## Proyectos que lo construyen

- Ninguno declarado
