# Entrevistas · Pago con QR

**Ronda:** Ronda · 2025-11-15
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2025-11-15

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
