# Caso de negocio · Marca propia

**Código:** PRD-304
**Fecha:** 2025-09-05
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 93.257 | Caso de negocio, 2025-09-05 |

## Retorno esperado

Retorno esperado en 24 meses.
