# Caso de negocio · App de clientes

**Código:** PRD-306
**Fecha:** 2026-06-12
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 173.678 | Caso de negocio, 2026-06-12 |

## Retorno esperado

Retorno esperado en 24 meses.
