# Caso de negocio · Puntos de fidelización

**Código:** PRD-301
**Fecha:** 2025-11-06
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 160.063 | Caso de negocio, 2025-11-06 |

## Retorno esperado

Retorno esperado en 24 meses.
