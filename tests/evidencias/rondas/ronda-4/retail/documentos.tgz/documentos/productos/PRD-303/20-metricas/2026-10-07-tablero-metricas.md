# Tablero de métricas · Pago con QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 61.530 | 2026-10-07 |
