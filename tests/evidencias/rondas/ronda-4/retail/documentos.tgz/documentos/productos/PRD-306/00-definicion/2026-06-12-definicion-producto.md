# Definición de producto · App de clientes

**Código:** PRD-306
**Gerente de producto:** Diana Molina
**Segmento:** Clientes frecuentes
**Fecha de la definición:** 2026-06-12

## El problema

El segmento Clientes frecuentes no tiene app de clientes.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-05 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
