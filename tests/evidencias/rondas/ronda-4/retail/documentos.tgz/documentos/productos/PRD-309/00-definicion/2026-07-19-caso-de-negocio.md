# Caso de negocio · Tarjeta de la tienda

**Código:** PRD-309
**Fecha:** 2026-07-19
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 205.884 | Caso de negocio, 2026-07-19 |

## Retorno esperado

Retorno esperado en 24 meses.
