# Definición de producto · Venta en línea

**Código:** PRD-300
**Gerente de producto:** María Restrepo
**Segmento:** Empresas
**Fecha de la definición:** 2025-11-26

## El problema

El segmento Empresas no tiene venta en línea.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-07-21 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
