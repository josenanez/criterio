<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-10-08
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-11-15 |
| Diana Molina | Cerrar la prueba 2 | 2026-11-15 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-31 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-06 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-27 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-28 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-27 |
| Ricardo Salas | Validar el ambiente 12 | 2026-10-20 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-03 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-16 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-18 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| María Restrepo | Validar el ambiente 20 | 2026-10-19 |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-12 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-02 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-24 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Felipe Arango): recibido, acta de recibo del 2026-10-08.
- Revisar el anexo 11 (Óscar Ramírez): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- Laura Vélez dice que ya entregó «confirmar la fecha 15». No se presentó acta.
