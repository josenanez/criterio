<!-- origen: PRY-209-migración-del-erp/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-209",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "name": {
 "value": "Migración del ERP",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Talento humano",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Gustavo Neira",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "manager": {
 "value": "Camilo Beltrán",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Cadena de Abastecimiento",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 75,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": "2026-10-15",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2026-06-07",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "end_date": {
 "value": "2027-03-06",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-05-28",
 "start_date": "2026-06-07",
 "end_date": "2027-03-06",
 "reason": "Aprobación original del acta de constitución",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño de la experiencia aprobado",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-08-06",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "current_date": {
 "value": "2026-08-06",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-06-acta-recibo-diseño-de-la-experiencia-aprobado.md",
 "source": "20-seguimiento/2026-10-06-acta-recibo-diseño-de-la-experiencia-aprobado.md",
 "source_date": "2026-10-06",
 "state": "found"
 },
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-05",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-05",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Integración con el ERP",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-12-05",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "current_date": {
 "value": "2026-12-05",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 },
 {
 "name": {
 "value": "Piloto en tiendas",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-02-03",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "current_date": {
 "value": "2027-02-03",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "approved": {
 "value": 6800000000,
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "committed": {
 "value": 4491302023,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 1935274876,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 6735523046,
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": {
 "value": "Disponibilidad de los jefes de tienda para el piloto",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "what": {
 "value": "Concentración del conocimiento en una sola persona",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "what": {
 "value": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "registered": false,
 "note": "se comentó en la reunión; nadie lo anotó como riesgo y no está en el informe"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": {
 "value": "La prueba de carga de temporada no alcanzó el umbral pactado y se repite",
 "source": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "source_date": "2026-10-15",
 "state": "found",
 "source_kind": "declaration"
 },
 "owner": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "id": 1,
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-29",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-16",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-11-29",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ]
 },
 {
 "id": 2,
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-15",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-19",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 3,
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-31",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 4,
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-29",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-10-acta-recibo-4.md",
 "closed_on": "2026-09-10"
 },
 {
 "id": 5,
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-21",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-5.md",
 "closed_on": "2026-10-08"
 },
 {
 "id": 6,
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-21",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-29",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-06",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ]
 },
 {
 "id": 7,
 "who": {
 "value": "Rubén Cárdenas",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ]
 },
 {
 "id": 8,
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-28",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-28",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta; salió de la lista de abiertos"
 }
 },
 {
 "id": 9,
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-28",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 10,
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ]
 },
 {
 "id": 11,
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-15",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-22",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-15",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-11.md",
 "closed_on": "2026-10-08"
 },
 {
 "id": 12,
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-23",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 13,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "claimed_delivered": {
 "on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta; salió de la lista de abiertos"
 }
 },
 {
 "id": 14,
 "who": {
 "value": "Gustavo Neira",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-13",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 15,
 "who": {
 "value": "Laura Vélez",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "claimed_delivered": {
 "on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "evidence": null,
 "note": "lo dijo en la reunión; no se presentó acta; salió de la lista de abiertos"
 }
 },
 {
 "id": 16,
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-02",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-16.md",
 "closed_on": "2026-10-01"
 },
 {
 "id": 17,
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-16",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 18,
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-18",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 19,
 "who": {
 "value": "Elena Duarte",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-27",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 20,
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 21,
 "who": {
 "value": "Liliana Torres",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-12",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 22,
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 23,
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 24,
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 25,
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "«la otra semana»: nadie dijo fecha"
 },
 {
 "id": 26,
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-25",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-25",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "activity": {
 "last_document_date": {
 "value": "2026-10-15"
 },
 "last_meeting_date": {
 "value": "2026-10-15"
 }
 },
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [
 {
 "path": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "hash": "461ef11f42f3d886591d083cf9c8764a89bf9ac4ea607d8d9a8a36d224be7655",
 "text_hash": null,
 "date": "2026-05-28"
 },
 {
 "path": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "hash": "47c408178e9677e66f56412e0aca07f633dad464e748507e090be32d1e29bbb9",
 "text_hash": null,
 "date": "2026-05-28"
 },
 {
 "path": "20-seguimiento/2026-09-10-acta-recibo-4.md",
 "hash": "ee95ded09d9ef12b17c31c58928a50ebea7c89cc360e0477fb76402aef738316",
 "text_hash": null,
 "date": "2026-09-10"
 },
 {
 "path": "20-seguimiento/2026-10-01-acta-recibo-16.md",
 "hash": "53dab06dbe2451bbcaf9c17da931b4b84873ea48531bec2c7ddfda677f98e4ba",
 "text_hash": null,
 "date": "2026-10-01"
 },
 {
 "path": "20-seguimiento/2026-10-06-acta-recibo-diseño-de-la-experiencia-aprobado.md",
 "hash": "25f5b262ca6ae190e52309f5c9538a33b7215e62792203f114de8eca80a1a1a2",
 "text_hash": null,
 "date": "2026-10-06"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-11.md",
 "hash": "4b900d9d9d1deda01dafa94f7d0c8e4139f8184bad809596f20585c41cf500d3",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-5.md",
 "hash": "50bc4ed6bec9cb24de5ab070ad044cb069798706b704191a0860ddca39362154",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-15-informe-avance.pdf",
 "hash": "3ca1c5c3eca0750802abde147393a4dc0c1d83951d6e2a4345289206d5f4543f",
 "text_hash": null,
 "date": "2026-10-15"
 },
 {
 "path": "2026-10-15-notas-reunion.txt",
 "hash": "41d46139bac06064fc3851dd20ea913e0a3d1d4cd1f5027bbdc4ff88ac92157a",
 "text_hash": null,
 "date": "2026-10-15"
 },
 {
 "path": "30-reuniones/2026-09-03-comite-semanal.md",
 "hash": "98d30835d4bdbe40ad283bb6cb47e72145380338c9129e888c5415fd4134359f",
 "text_hash": null,
 "date": "2026-09-03"
 },
 {
 "path": "30-reuniones/2026-09-10-comite-semanal.md",
 "hash": "9b5da425a72ef23570526fe78dff1dec55a36cbabe1ebda27361fdbdb80969d4",
 "text_hash": null,
 "date": "2026-09-10"
 },
 {
 "path": "30-reuniones/2026-09-17-comite-semanal.md",
 "hash": "bc62eccaa93701e7a4df4b692364ad2afcc8a1c16f01c0d58cf5ab9fad19a4b6",
 "text_hash": null,
 "date": "2026-09-17"
 },
 {
 "path": "30-reuniones/2026-09-24-comite-semanal.md",
 "hash": "67aa1333646a1b1d5e2b49d2712fb112ff2025205ca1d841eed231f8c8083103",
 "text_hash": null,
 "date": "2026-09-24"
 },
 {
 "path": "30-reuniones/2026-10-01-comite-semanal.md",
 "hash": "72271bfc4e550c7d8fdb372d36b484b213d931c0c5c397ce9ca207a4e2137627",
 "text_hash": null,
 "date": "2026-10-01"
 },
 {
 "path": "30-reuniones/2026-10-08-comite-semanal.md",
 "hash": "833cb57ff8090d96d8a177f95393cd3936ef02d53fb1fc394219979f7b2f382a",
 "text_hash": null,
 "date": "2026-10-08"
 }
 ],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase",
 "plan.milestones[].evidence (3 de 4)",
 "vendors",
 "changes"
 ],
 "open_conflicts": [],
 "sealed": false,
 "read_scope": "todas las minutas (6, 2026-09-03 a 2026-10-08), notas del 2026-10-15 y las 5 actas de recibo"
 }
}
