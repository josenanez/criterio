<!-- origen: PRY-209-migración-del-erp/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Migración del ERP
Código: PRY-209
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 75%

Lo que pasó en el periodo
- La prueba de carga de temporada no alcanzó el umbral pactado y se repite

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 4.491.302.023
Ejecutado 1.935.274.876
Proyección al cierre 6.735.523.046

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- Concentración del conocimiento en una sola persona
