<!-- origen: PRY-208-domicilios-en-dos-horas/00-gobierno/2026-03-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Domicilios en dos horas

Código: PRY-208

Área dueña: Talento humano

Patrocinador: Gustavo Neira

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Transformación Digital

Producto asociado: entrega rápida

Fecha de aprobación: 2026-03-29

Objetivo del negocio

Entregar domicilios en dos horas para Talento humano.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Transformación Digital el 2026-03-29.

Fechas comprometidas

Fecha

Inicio

2026-04-08

Cierre

2027-02-02

Criterio de éxito

Domicilios en dos horas en producción y medido.

Dependencias declaradas

• Ninguna declarada
