<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/20-seguimiento/2026-10-08-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Etiquetas electrónicas de precio
Código: PRY-210
Fecha de corte: 2026-10-08
Gerente: Javier Hoyos

Estado declarado
Rojo
Avance reportado: 55%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.542.190.363
Ejecutado 882.848.981
Proyección al cierre 4.160.432.844

Riesgos abiertos
- Concentración del conocimiento en una sola persona
