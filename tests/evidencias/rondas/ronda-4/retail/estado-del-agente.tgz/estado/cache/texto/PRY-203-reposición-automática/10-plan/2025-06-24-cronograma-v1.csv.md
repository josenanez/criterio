<!-- origen: PRY-203-reposición-automática/10-plan/2025-06-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-08-12,2025-08-12,cerrado
Ambiente de pruebas certificado,2025-09-20,2025-09-20,cerrado
Integración con el ERP,2025-10-29,2025-10-29,cerrado
Piloto en tiendas,2025-12-07,2025-12-07,cerrado
Despliegue en la cadena,2026-01-15,2026-01-15,cerrado
