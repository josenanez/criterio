<!-- origen: PRY-211-pronóstico-de-demanda/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cadena de Abastecimiento · Pronóstico de demanda

Fecha: 2026-10-14

Asistentes: Ricardo Salas, Beatriz Cuéllar

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Felipe Arango

Entregar el punto 39

2026-09-25

Gustavo Neira

Entregar el punto 12

2026-10-31
