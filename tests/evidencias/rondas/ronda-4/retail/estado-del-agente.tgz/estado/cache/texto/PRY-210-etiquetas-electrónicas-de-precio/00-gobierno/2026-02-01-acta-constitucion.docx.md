<!-- origen: PRY-210-etiquetas-electrónicas-de-precio/00-gobierno/2026-02-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Etiquetas electrónicas de precio

Código: PRY-210

Área dueña: Comercial

Patrocinador: Liliana Torres

Gerente de proyecto: Javier Hoyos

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2026-02-01

Objetivo del negocio

Entregar etiquetas electrónicas de precio para Comercial.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Transformación Digital el 2026-02-01.

Fechas comprometidas

Fecha

Inicio

2026-02-11

Cierre

2027-04-27

Criterio de éxito

Etiquetas electrónicas de precio en producción y medido.

Dependencias declaradas

• Ninguna declarada
