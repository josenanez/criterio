<!-- origen: PRY-200-tienda-en-línea/10-plan/2025-07-09-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2025-10-03 | 2025-10-03 | cerrado
Ambiente de pruebas certificado | 2025-12-18 | 2025-12-18 | cerrado
Integración con el ERP | 2026-03-04 | 2026-03-04 | cerrado
