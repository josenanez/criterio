<!-- origen: PRY-207-marca-propia-de-alimentos/00-gobierno/2026-02-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Marca propia de alimentos

**Código:** PRY-207
**Área dueña:** Tiendas
**Patrocinador:** Sandra Gil
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** marca propia
**Fecha de aprobación:** 2026-02-12

## Objetivo del negocio

Entregar marca propia de alimentos para Tiendas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-02-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-22 |
| Cierre | 2026-12-20 |

## Criterio de éxito

Marca propia de alimentos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
