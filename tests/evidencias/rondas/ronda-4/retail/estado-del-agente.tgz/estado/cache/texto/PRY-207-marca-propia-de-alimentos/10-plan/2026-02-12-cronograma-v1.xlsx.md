<!-- origen: PRY-207-marca-propia-de-alimentos/10-plan/2026-02-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-04-29 | 2026-04-29 | cerrado
Ambiente de pruebas certificado | 2026-07-05 | 2026-07-05 | cerrado
Integración con el ERP | 2026-09-10 | 2026-09-10 | cerrado
Piloto en tiendas | 2026-11-16 | 2026-11-16 | en curso
