<!-- origen: PRY-211-pronóstico-de-demanda/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Pronóstico de demanda
Código: PRY-211
Fecha de corte: 2026-10-04
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 72%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 639.407.966
Ejecutado 666.917.065
Proyección al cierre 1.364.395.523

Riesgos abiertos
- Concentración del conocimiento en una sola persona
