<!-- origen: PRY-209-migración-del-erp/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión migración del erp — 2026-10-15
estuvieron: Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

- Felipe Arango dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 29/11/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
