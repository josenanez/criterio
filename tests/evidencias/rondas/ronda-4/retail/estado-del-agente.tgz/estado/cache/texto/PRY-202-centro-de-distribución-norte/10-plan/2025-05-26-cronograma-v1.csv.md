<!-- origen: PRY-202-centro-de-distribución-norte/10-plan/2025-05-26-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2025-09-11,2025-09-11,cerrado
Ambiente de pruebas certificado,2025-12-19,2025-12-19,cerrado
Integración con el ERP,2026-03-28,2026-03-28,cerrado
Piloto en tiendas,2026-07-05,2026-07-05,cerrado
