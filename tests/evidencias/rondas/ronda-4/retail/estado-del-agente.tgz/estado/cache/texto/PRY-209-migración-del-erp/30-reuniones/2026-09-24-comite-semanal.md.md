<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-09-24
**Asistentes:** Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-10-20 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-16 |
| Elena Duarte | Revisar el anexo 3 | por definir |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-10 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-06 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-27 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-18 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-27 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-02 |
| Ricardo Salas | Validar el ambiente 12 | 2026-10-08 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-19 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-13 |
| Laura Vélez | Confirmar la fecha 15 | por definir |
| Diana Molina | Entregar el punto 16 | 2026-10-02 |
