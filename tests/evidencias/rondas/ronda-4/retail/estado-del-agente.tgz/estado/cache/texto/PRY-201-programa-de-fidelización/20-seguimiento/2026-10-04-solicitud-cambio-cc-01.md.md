<!-- origen: PRY-201-programa-de-fidelización/20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-201 · Programa de fidelización
**Fecha:** 2026-10-04
**Solicitante:** María Restrepo

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +59 días sobre la línea base vigente |
| Costo | 118.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
