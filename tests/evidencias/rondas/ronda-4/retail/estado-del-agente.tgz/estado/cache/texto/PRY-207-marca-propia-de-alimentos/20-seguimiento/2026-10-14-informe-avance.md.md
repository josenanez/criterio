<!-- origen: PRY-207-marca-propia-de-alimentos/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Marca propia de alimentos

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Felipe Arango

## Estado declarado

**Amarillo**

Avance reportado: **59%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 7.128.099.239 |
| Ejecutado | 5.505.911.981 |
| Proyección al cierre | 17.033.261.108 |

## Riesgos abiertos

- Congelamiento de cambios en temporada alta
