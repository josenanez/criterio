<!-- origen: PRY-208-domicilios-en-dos-horas/10-plan/2026-03-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-02 | 2026-07-02 | cerrado
Ambiente de pruebas certificado | 2026-09-26 | 2026-09-26 | cerrado
Integración con el ERP | 2026-12-21 | 2026-12-21 | en curso
