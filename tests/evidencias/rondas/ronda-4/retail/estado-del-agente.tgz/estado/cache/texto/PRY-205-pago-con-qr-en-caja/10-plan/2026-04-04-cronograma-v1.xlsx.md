<!-- origen: PRY-205-pago-con-qr-en-caja/10-plan/2026-04-04-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-07-31 | 2026-07-31 | cerrado
Ambiente de pruebas certificado | 2026-11-16 | 2026-11-16 | en curso
Integración con el ERP | 2027-03-04 | 2027-03-04 | en curso
Piloto en tiendas | 2027-06-20 | 2027-06-20 | en curso
Despliegue en la cadena | 2027-10-06 | 2027-10-06 | en curso
