<!-- origen: PRY-201-programa-de-fidelización/00-gobierno/2025-07-07-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Programa de fidelización

**Código:** PRY-201
**Área dueña:** Talento humano
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** María Restrepo
**Comité:** Comité de Transformación Digital
**Producto asociado:** puntos de fidelización
**Fecha de aprobación:** 2025-07-07

## Objetivo del negocio

Entregar programa de fidelización para Talento humano.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-07-07.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-17 |
| Cierre | 2026-06-11 |

## Criterio de éxito

Programa de fidelización en producción y medido.

## Dependencias declaradas

- Ninguna declarada
