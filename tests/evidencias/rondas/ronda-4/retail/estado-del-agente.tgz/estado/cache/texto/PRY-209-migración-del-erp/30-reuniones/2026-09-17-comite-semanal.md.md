<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-09-17
**Asistentes:** Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-10-06 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-02 |
| Elena Duarte | Revisar el anexo 3 | por definir |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-10 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-29 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-12 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-08 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-14 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-09-22 |
| Ricardo Salas | Validar el ambiente 12 | 2026-09-23 |

## Lo que se dijo

- Diana Molina dice que ya entregó «entregar el punto 8». No se presentó acta.
