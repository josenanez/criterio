<!-- origen: PRY-202-centro-de-distribución-norte/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Centro de distribución norte

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Felipe Arango

## Estado declarado

**Rojo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 5.211.065.028 |
| Ejecutado | 2.084.725.349 |
| Proyección al cierre | 9.920.939.179 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Cambio en la regulación de datos personales que puede mover el alcance
