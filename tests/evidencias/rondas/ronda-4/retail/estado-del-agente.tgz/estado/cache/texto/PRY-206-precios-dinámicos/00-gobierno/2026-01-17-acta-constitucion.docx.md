<!-- origen: PRY-206-precios-dinámicos/00-gobierno/2026-01-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Precios dinámicos

Código: PRY-206

Área dueña: Comercio electrónico

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Expansión

Producto asociado: No aplica

Fecha de aprobación: 2026-01-17

Objetivo del negocio

Entregar precios dinámicos para Comercio electrónico.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Expansión el 2026-01-17.

Fechas comprometidas

Fecha

Inicio

2026-01-27

Cierre

2027-01-21

Criterio de éxito

Precios dinámicos en producción y medido.

Dependencias declaradas

• Ninguna declarada
