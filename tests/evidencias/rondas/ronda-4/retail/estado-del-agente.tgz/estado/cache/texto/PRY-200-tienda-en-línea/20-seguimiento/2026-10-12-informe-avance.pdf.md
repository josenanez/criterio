<!-- origen: PRY-200-tienda-en-línea/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Tienda en línea
Código: PRY-200
Fecha de corte: 2026-10-12
Gerente: Elena Duarte

Estado declarado
Verde
Avance reportado: 76%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en los medios de pago
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 877.039.354
Ejecutado 548.436.150
Proyección al cierre 1.209.542.313

Riesgos abiertos
- Disponibilidad de los jefes de tienda para el piloto
- El proveedor no ha confirmado la fecha de la última entrega
