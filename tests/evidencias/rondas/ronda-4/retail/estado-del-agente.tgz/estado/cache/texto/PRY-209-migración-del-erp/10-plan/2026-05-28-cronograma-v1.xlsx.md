<!-- origen: PRY-209-migración-del-erp/10-plan/2026-05-28-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-08-06 | 2026-08-06 | cerrado
Ambiente de pruebas certificado | 2026-10-05 | 2026-10-05 | en curso
Integración con el ERP | 2026-12-05 | 2026-12-05 | en curso
Piloto en tiendas | 2027-02-03 | 2027-02-03 | en curso
