<!-- origen: PRY-205-pago-con-qr-en-caja/30-reuniones/2026-10-10-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Expansión · Pago con QR en caja

Fecha: 2026-10-10

Asistentes: Laura Vélez, Laura Vélez

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Laura Vélez

Entregar el punto 9

2026-10-07
