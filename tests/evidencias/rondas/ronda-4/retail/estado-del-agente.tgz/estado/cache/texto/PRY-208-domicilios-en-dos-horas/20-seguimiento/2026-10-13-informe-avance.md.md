<!-- origen: PRY-208-domicilios-en-dos-horas/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Domicilios en dos horas

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Óscar Ramírez

## Estado declarado

**Amarillo**

Avance reportado: **54%**

## Lo que pasó en el periodo

- Se reprogramó el despliegue por el congelamiento de temporada de fin de año
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.733.784.270 |
| Ejecutado | 771.296.555 |
| Proyección al cierre | 3.776.990.948 |

## Riesgos abiertos

- Cambio en la regulación de datos personales que puede mover el alcance
