<!-- origen: PRY-211-pronóstico-de-demanda/00-gobierno/2026-05-01-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pronóstico de demanda

**Código:** PRY-211
**Área dueña:** Tecnología
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Ricardo Salas
**Comité:** Comité de Cadena de Abastecimiento
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-01

## Objetivo del negocio

Entregar pronóstico de demanda para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Cadena de Abastecimiento el 2026-05-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-11 |
| Cierre | 2027-07-04 |

## Criterio de éxito

Pronóstico de demanda en producción y medido.

## Dependencias declaradas

- Ninguna declarada
