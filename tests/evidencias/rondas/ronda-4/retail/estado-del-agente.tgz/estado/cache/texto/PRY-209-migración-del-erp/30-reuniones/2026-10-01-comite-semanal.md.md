<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-10-01
**Asistentes:** Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Laura Vélez, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-10-28 |
| Diana Molina | Cerrar la prueba 2 | 2026-10-27 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-15 |
| Felipe Arango | Aprobar el diseño 5 | 2026-10-27 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-06 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-27 |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-18 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-27 |
| Óscar Ramírez | Revisar el anexo 11 | 2026-10-15 |
| Ricardo Salas | Validar el ambiente 12 | 2026-10-08 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-27 |
| Laura Vélez | Confirmar la fecha 15 | 2026-10-14 |
| Ricardo Salas | Enviar el documento 17 | 2026-10-16 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-18 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| María Restrepo | Validar el ambiente 20 | 2026-10-19 |

## Cerrados en esta reunión

- Entregar el punto 16 (Diana Molina): recibido, acta de recibo del 2026-10-01.

## Lo que se dijo

- Gustavo Neira dice que ya entregó «aprobar el diseño 13». No se presentó acta.
