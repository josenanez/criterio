<!-- origen: PRY-203-reposición-automática/00-gobierno/2025-06-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Reposición automática

Código: PRY-203

Área dueña: Tiendas

Patrocinador: Liliana Torres

Gerente de proyecto: Rubén Cárdenas

Comité: Comité Comercial

Producto asociado: No aplica

Fecha de aprobación: 2025-06-24

Objetivo del negocio

Entregar reposición automática para Tiendas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Comercial el 2025-06-24.

Fechas comprometidas

Fecha

Inicio

2025-07-04

Cierre

2026-02-04

Criterio de éxito

Reposición automática en producción y medido.

Dependencias declaradas

• Ninguna declarada
