<!-- origen: PRY-202-centro-de-distribución-norte/00-gobierno/2025-05-26-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Centro de distribución norte

**Código:** PRY-202
**Área dueña:** Finanzas
**Patrocinador:** Ricardo Salas
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Arquitectura
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-05-26

## Objetivo del negocio

Entregar centro de distribución norte para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Arquitectura el 2025-05-26.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-05 |
| Cierre | 2026-08-24 |

## Criterio de éxito

Centro de distribución norte en producción y medido.

## Dependencias declaradas

- Ninguna declarada
