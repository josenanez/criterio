<!-- origen: PRY-199-iluminación-led-en-bodegas/10-plan/2026-06-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-10-04 | 2026-10-04 | cerrado
Ambiente de pruebas certificado | 2027-01-21 | 2027-01-21 | en curso
Integración con el ERP | 2027-05-10 | 2027-05-10 | en curso
Piloto en tiendas | 2027-08-27 | 2027-08-27 | en curso
Despliegue en la cadena | 2027-12-14 | 2027-12-14 | en curso
