<!-- origen: PRY-204-cajas-de-autopago/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Cadena de Abastecimiento · Cajas de autopago

Fecha: 2026-10-14

Asistentes: Gustavo Neira, Elena Duarte

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Camilo Beltrán

Entregar el punto 15

2026-10-06
