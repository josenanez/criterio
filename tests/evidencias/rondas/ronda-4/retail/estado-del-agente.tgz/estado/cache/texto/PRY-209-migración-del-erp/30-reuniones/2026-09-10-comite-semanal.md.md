<!-- origen: PRY-209-migración-del-erp/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Cadena de Abastecimiento · Migración del ERP

**Fecha:** 2026-09-10
**Asistentes:** Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-09-27 |
| Diana Molina | Cerrar la prueba 2 | 2026-09-19 |
| Elena Duarte | Revisar el anexo 3 | por definir |
| Felipe Arango | Aprobar el diseño 5 | 2026-09-21 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-21 |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-02 |
| Diana Molina | Entregar el punto 8 | 2026-09-28 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Sandra Gil): recibido, acta de recibo del 2026-09-10.
