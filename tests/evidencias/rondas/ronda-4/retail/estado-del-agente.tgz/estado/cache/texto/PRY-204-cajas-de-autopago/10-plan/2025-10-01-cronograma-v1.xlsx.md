<!-- origen: PRY-204-cajas-de-autopago/10-plan/2025-10-01-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño de la experiencia aprobado | 2026-02-11 | 2026-02-11 | cerrado
Ambiente de pruebas certificado | 2026-06-14 | 2026-06-14 | cerrado
Integración con el ERP | 2026-10-16 | 2026-10-16 | en curso
Piloto en tiendas | 2027-02-16 | 2027-02-16 | en curso
