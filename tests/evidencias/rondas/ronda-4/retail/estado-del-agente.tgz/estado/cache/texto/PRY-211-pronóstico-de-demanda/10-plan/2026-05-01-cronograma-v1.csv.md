<!-- origen: PRY-211-pronóstico-de-demanda/10-plan/2026-05-01-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño de la experiencia aprobado,2026-07-26,2026-07-26,cerrado
Ambiente de pruebas certificado,2026-10-10,2026-10-10,cerrado
Integración con el ERP,2026-12-25,2026-12-25,en curso
Piloto en tiendas,2027-03-11,2027-03-11,en curso
Despliegue en la cadena,2027-05-26,2027-05-26,en curso
