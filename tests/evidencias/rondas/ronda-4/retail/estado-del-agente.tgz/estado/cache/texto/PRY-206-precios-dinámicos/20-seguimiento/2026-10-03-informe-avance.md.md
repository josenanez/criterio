<!-- origen: PRY-206-precios-dinámicos/20-seguimiento/2026-10-03-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Precios dinámicos

**Código:** PRY-206
**Fecha de corte:** 2026-10-03
**Gerente:** Sandra Gil

## Estado declarado

**Rojo**

Avance reportado: **59%**

## Lo que pasó en el periodo

- Se recibió el concepto de Jurídica sobre los términos de uso
- La validación con dos tiendas se extendió una semana por el conteo de inventario

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 10.564.665.189 |
| Ejecutado | 6.113.589.042 |
| Proyección al cierre | 17.174.126.272 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
