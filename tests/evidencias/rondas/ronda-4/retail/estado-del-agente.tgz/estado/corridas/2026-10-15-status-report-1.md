# Corrida del 2026-10-15 · status-report

13 proyectos · 25 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

Status report PRY-209: avance declarado 75% contra 25-50% sustentado, hito de pruebas vencido, 4 compromisos vencidos, 2 reprogramados, fecha de cierre en conflicto entre cronograma y acta. No sabe producto, autoridad, fase ni responsables de riesgos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Informe sale de la ficha `estado/records/PRY-209.json` (declaración al 2026-10-15; documentos hasta 2026-10-15). Cifras derivadas copiadas de `portafolio.py compute`, as_of 2026-10-15.

## PRY-209 · Migración del ERP — estado al 2026-10-15

**Declara el gerente (Camilo Beltrán):** amarillo · 75% · al 2026-10-15 (informe de avance, `20-seguimiento/2026-10-15-informe-avance.pdf`)
**Sustento documental:** contradicho en el avance. El plan sustenta entre 25% y 50% (1 de 4 hitos cumplido); lo declarado va 25 puntos por encima.
**Lo que el semáforo no explica:** compromisos vencidos (`commitment_overdue`), compromisos reprogramados (`commitment_rescheduled`), hito vencido (`milestone_overdue`), avance frente al plan (`progress_vs_plan`).
**Último documento:** 2026-10-15 (0 días de silencio) · **Última reunión:** 2026-10-15 (`2026-10-15-notas-reunion.txt`)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-02-03 | 2027-02-03 | 0 días contra original y contra vigente |
| Presupuesto aprobado | COP 6.800.000.000 | COP 6.800.000.000 | Proyección COP 6.735.523.046 = -0,9% (por debajo de lo aprobado) |

Replanificaciones: 0.
Presupuesto: comprometido COP 4.491.302.023 (66,0%), ejecutado COP 1.935.274.876 (28,5%), disponible real COP 2.308.697.977. Estas tres cifras son declaradas en el informe de avance, no verificadas contra otro documento.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-08-06 | 2026-08-06 | cumplido | acta de recibo fechada 2026-10-06 |
| Ambiente de pruebas certificado | 2026-10-05 | 2026-10-05 | **vencido hace 10 días** | ninguna |
| Integración con el ERP | 2026-12-05 | 2026-12-05 | pendiente | ninguna |
| Piloto en tiendas | 2027-02-03 | 2027-02-03 | pendiente | ninguna |

### Dónde no coincide
- **Avance:** el gerente declara 75% (informe 2026-10-15); el cronograma v1 (2026-05-28) con 1 de 4 hitos cumplido sustenta 25–50%.
- **Fecha de cierre:** el cronograma v1 (`10-plan/2026-05-28-cronograma-v1.xlsx`) dice 2027-02-03; el acta de constitución (`00-gobierno/2026-05-28-acta-constitucion.docx`) dice 2027-03-06. Misma fecha de documento, 31 días de diferencia, ninguno es más reciente. La ficha usa 2027-02-03; hay que decidir cuál es la línea base.
- **Hito 1:** la línea base lo pone el 2026-08-06 y el acta de recibo es del 2026-10-06; el cronograma no registra el atraso y la desviación calculada es 0.
- Con un hito de pruebas vencido y un incidente abierto (la prueba de carga de temporada no alcanzó el umbral y se repite), el amarillo no recoge el avance del 75%.

### Abierto
**Riesgos e incidencias sin movimiento:** el script no reporta riesgos sin movimiento; los tres riesgos y la incidencia no tienen responsable (ver «Sin dato»). El riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» se dijo en la reunión del 2026-10-15 y no está en el informe ni registrado.
**Compromisos vencidos (sin evidencia de cumplimiento):**
- Diana Molina, «Entregar el punto 8»: vencido 2026-09-28, 17 días. Dijo haberlo entregado el 2026-09-17; no se presentó acta.
- Óscar Ramírez, «Actualizar la matriz 6»: vencido 2026-10-06, 9 días.
- Liliana Torres, «Aprobar el diseño 21»: vencido 2026-10-12, 3 días.
- Laura Vélez, «Confirmar la fecha 15»: vencido 2026-10-14, 1 día. Dijo haberlo hecho el 2026-10-08; no se presentó acta.

**Compromisos reprogramados repetidamente:**
- Felipe Arango, «Enviar el documento 1»: 6 veces, de 2026-09-16 a 2026-11-29.
- Diana Molina, «Cerrar la prueba 2»: 5 veces, de 2026-09-10 a 2026-11-15.

**Compromiso sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» (notas del 2026-10-15).
**Dependencias sin confirmar:** ninguna registrada en la ficha.

### Sin dato
Producto, autoridad y fase del proyecto; responsable de los tres riesgos y de la incidencia; probabilidad, impacto y fecha de los riesgos; evidencia de los hitos 2, 3 y 4 (los dos últimos aún no vencen). Ningún documento de evidencia independiente: las fuentes de la ficha se clasifican como 10 declaraciones y 150 sin marcar.

---
Criterio Portfolio 0.3.10 · términos 1.1 aceptados por José Francisco Ñáñez el 2026-10-15 · ficha PRY-209 aplicada al 2026-10-15 · campos inciertos: los listados en «Sin dato» · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
