## 2026-10-15

**Revisé:** 66 documentos · 0 cambiaron · 0 proyectos recalculados

Toca barrido y confirmación. No hay peticiones en el servidor.

### Lo que cruzó un umbral
Nada nuevo por documentos cambiados. Sobre la ficha vigente de PRY-209 (Migración del ERP), sin releer nada:
- **Hito vencido sin evidencia:** «Ambiente de pruebas certificado», fecha base y vigente 2026-10-05, sigue `pending` el 2026-10-15 (10 días). Fuente: `10-plan/2026-05-28-cronograma-v1.xlsx`.
- **Avance declarado frente a dinero ejecutado:** el informe declara 75 % de avance y estado amarillo; lo ejecutado es COP 1.935.274.876 de COP 6.800.000.000 aprobados (28 %). Un solo hito de cuatro está cumplido. Fuentes: `20-seguimiento/2026-10-15-informe-avance.pdf`, `00-gobierno/2026-05-28-acta-constitucion.docx`.
- Comprometido 66 % del aprobado (umbral 90 %): no cruza.

### Citas que no resuelven
El índice reporta como «fuente no encontrada» las citas de la ficha de PRY-209 (acta, cronograma, informe de avance, actas de reunión). Los archivos existen en la carpeta del proyecto. Las citas son relativas a esa carpeta y el índice parece buscarlas desde la raíz de documentos, así que es un desajuste de ruta y no una pérdida de documentos. No lo corregí; queda como hallazgo.

### Peticiones atendidas
Ninguna.

### Preguntas (confirmación, 5 campos de PRY-209)
Nadie atiende esta sesión; quedan preguntadas el 2026-10-15, sin respuesta. Se asumió la respuesta sugerida (mantener el valor y no marcarlo como confirmado):
1. Estado declarado: amarillo (informe de avance, 2026-10-15).
2. Avance declarado: 75 % (informe de avance, 2026-10-15). Es el que choca con el 28 % ejecutado.
3. Fecha vigente de «Ambiente de pruebas certificado»: 2026-10-05 (cronograma v1, 2026-05-28).
4. Proyección de costo: COP 6.735.523.046 (informe de avance, 2026-10-15).
5. Fecha de fin planeada: 2027-03-06 (acta de constitución, 2026-05-28).

**Vuelvo el 2026-10-16.**
