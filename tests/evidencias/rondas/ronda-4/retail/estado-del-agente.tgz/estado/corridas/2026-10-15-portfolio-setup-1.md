# Corrida del 2026-10-15 · portfolio-setup

3 proyectos · 66 documentos, 38 releídos y 28 sin cambio · 152 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `progress_vs_plan` | 2 |
| `variance_cost` | 2 |
| `declared_vs_evidence` | 2 |
| `commitment_rescheduled` | 2 |
| `milestone_met_without_evidence` | 1 |
| `vendor_deliverable_late` | 1 |
| `milestone_overdue` | 1 |
| `commitment_undated` | 1 |
| `pm_vs_pmo` | 1 |

0 preguntas (sesión de prueba, respuestas sugeridas); minutos hasta el primer resultado no medidos; 3 fichas escritas y selladas (PRY-209, PRY-204, PRY-205); compute levantó 19 señales, 2 verdes contradichos; pm_vs_pmo de PRY-209 en plan.end_date es en parte efecto de completar la fecha desde el último hito

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Retail

**Miré:** 66 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 36, .docx 11, .pdf 7, .xlsx 7, .csv 3, .json 1, .txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (hay 13 proyectos; fue la propuesta por defecto)
**Te aviso:** dos días antes del comité, cada dos semanas; supuse el próximo comité el 2026-10-29, así que el informe aterriza el 2026-10-27. Si la fecha es otra, dímela y la cambio.
**En:** presentación (propuesta por defecto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.10 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 del comprobante .md: 5a63e87d0ce9d540…
**Dónde queda todo:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

Los de documentación más reciente: PRY-209 (2026-10-15), PRY-204 y PRY-205 (2026-10-14). Quedaron sus tres fichas en `estado/records/`.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-209 Migración del ERP | 16 (15 leídos más la ficha del gerente, guardada aparte) | Patrocinador Gustavo Neira, gerente Camilo Beltrán (acta 2026-05-28). Declara amarillo, 75 %. Presupuesto aprobado 6.800 M COP, comprometido 4.491 M, ejecutado 1.935 M, proyección 6.735 M (informe 2026-10-15). 26 compromisos tomados de 6 minutas y las notas del 15 de octubre. Tiene ficha publicada por su gerente (`ficha-pm.json`), guardada aparte. | Producto, facultad de decisión del gerente, fase, proveedores, solicitudes de cambio; evidencia de 3 de sus 4 hitos. |
| PRY-204 Cajas de autopago | 5 | Patrocinadora Elena Duarte, gerente Gustavo Neira. Declara verde, 32 % (informe 2026-09-26). Aprobado 1.200 M COP, comprometido 894 M, ejecutado 502 M, proyección 1.342 M. | Facultad de decisión, fase, proveedores y contratos; owner de los riesgos y de los dos problemas reportados. |
| PRY-205 Pago con QR en caja | 7 | Patrocinadora y gerente: Laura Vélez. Declara verde, 40 % (informe 2026-10-14). Aprobado 18.000 M COP, comprometido 13.450 M, ejecutado 6.852 M, proyección 20.834 M. Dos contratos: CT-431 (Sistemas Comerciales del Norte) y CT-592 (Tecnología para Tiendas Ltda.). | Facultad de decisión, fase, lo facturado en cualquiera de los dos contratos. |

### Lo que `compute` levantó

19 señales en los tres proyectos; 2 de ellos declaran verde y los documentos no lo sostienen.

**PRY-204 — verde declarado, no sostenido** (`declared_vs_evidence`)
- `progress_vs_plan`: declara 32 % y el plan solo sostiene entre 50 y 75 % (2 de 4 hitos cerrados). Brecha de 18 puntos, por debajo del plan.
- `milestone_met_without_evidence`: «Ambiente de pruebas certificado» figura cerrado con fecha 2026-06-14 y no hay acta de recibo; van 123 días (`20-seguimiento/`, cronograma `10-plan/2025-10-01-cronograma-v1.xlsx`).
- `variance_cost`: la proyección (1.342 M) supera lo aprobado (1.200 M) en 11,8 %.
- `commitment_overdue`: Camilo Beltrán, «Entregar el punto 15», para 2026-10-06, 9 días sin evidencia (comité 2026-10-14).

**PRY-205 — verde declarado, no sostenido** (`declared_vs_evidence`)
- `variance_cost`: proyección 20.834 M contra 18.000 M aprobados, 15,7 % por encima.
- `vendor_deliverable_late`: «Licenciamiento de la plataforma» de CT-592 (Tecnología para Tiendas) tenía fecha 2026-08-10 y sigue pendiente; 66 días.
- `commitment_overdue`: Laura Vélez, «Entregar el punto 9», para 2026-10-07, 8 días (comité 2026-10-10).

**PRY-209 — amarillo declarado**; el cálculo lo deja con cuatro señales que el informe no menciona (`unaccounted_signals`)
- `milestone_overdue`: «Ambiente de pruebas certificado», para 2026-10-05, abierto, 10 días.
- `commitment_overdue`, 4 compromisos: Diana Molina «Entregar el punto 8» (17 días; dijo el 17 de septiembre que ya lo había entregado y no se presentó acta); Óscar Ramírez «Actualizar la matriz 6» (9 días); Liliana Torres «Aprobar el diseño 21» (3 días); Laura Vélez «Confirmar la fecha 15» (1 día; dijo el 8 de octubre que ya lo había entregado, sin acta).
- `commitment_rescheduled`: Felipe Arango, «Enviar el documento 1», prometido para 2026-09-16 y movido 6 veces, hoy 2026-11-29; Diana Molina, «Cerrar la prueba 2», prometido para 2026-09-10 y movido 5 veces, hoy 2026-11-15.
- `commitment_undated`: Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana», nadie dijo fecha).
- `progress_vs_plan`: declara 75 % y el plan sostiene entre 25 y 50 % (1 de 4 hitos cerrado); el desfase va en sentido contrario al de PRY-204, el avance declarado supera al plan.
- `pm_vs_pmo` sobre `plan.end_date`: mi ficha trae 2027-02-03 (completada desde el último hito del cronograma, `10-plan/2026-05-28-cronograma-v1.xlsx`) y la del gerente 2027-03-06 (el cierre del acta). Son dos cosas distintas —último hito contra cierre del acta—, así que esta señal es en parte efecto de cómo se completó la fecha y conviene mirarla antes de citarla. Lo mismo pasó con la fecha de cierre de PRY-204 y PRY-205 (guardada la del último hito); ahí no se levantó señal porque no tienen ficha del gerente.

No es señal calculada, es lo que leí: en las notas del 15 de octubre de PRY-209 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase y nadie lo anotó como riesgo; queda en la ficha marcado como no registrado.

### El portafolio completo
10 proyectos más (PRY-199 a PRY-203, PRY-206 a PRY-208, PRY-210, PRY-211) y 38 documentos por leer; caben en un solo lote, uno tras otro, muy por debajo del tope de 400 documentos por corrida. Con el ritmo de hoy (28 documentos y tres fichas en esta sesión, PRY-209 con 16 de ellos) lo estimo en algo más de lo que tomó esta prueba; es una estimación, no la medí.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- Ninguna de las tres actas dice hasta qué monto o qué cambio de alcance puede decidir el gerente: el control de cambios no podrá saber si algo excede su facultad.
- Las tres actas traen alcance genérico («Componente 1, 2, 3») y exclusiones genéricas («Lo que otro proyecto cubre»); el alcance no se puede contrastar contra nada.
- PRY-205: el patrocinador y el gerente son la misma persona (Laura Vélez), y el comité del 2026-10-10 lista dos veces a Laura Vélez como asistente. El contrato CT-431 está firmado el 2026-03-29, seis días antes del acta de constitución (2026-04-04).
- PRY-205 y su proveedor: no hay facturas ni actas de recibo de ningún entregable en la carpeta, así que no se puede ver qué se facturó contra qué.
- PRY-204: la fecha de cierre del acta es 2027-04-19 y la del último hito del cronograma, 2027-02-16; el acta de recibo del diseño de la experiencia es del 2026-10-14, ocho meses después del 2026-02-11 que marcaba el cronograma como cerrado.
- Cinco de los trece proyectos tienen entre dos y tres documentos (PRY-200, 201, 206, 208 y 210): sin actas de comité ni contratos, el análisis de compromisos y proveedores no tiene de dónde leer.
- Las notas del 2026-10-15 de PRY-209 están sueltas en la carpeta del proyecto, fuera de `30-reuniones/`.

### Qué hice por ti en esta instalación
Cero preguntas: la sesión era de prueba y tomé las respuestas sugeridas (PMO, comité cada dos semanas, presentación, estado junto a la carpeta de documentos).
