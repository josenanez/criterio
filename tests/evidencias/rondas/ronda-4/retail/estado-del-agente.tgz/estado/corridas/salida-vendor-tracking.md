**Sale de:** contrato CT-345 (`00-gobierno/2025-06-18-contrato-ct-345.docx`), factura FV-1345 (`20-seguimiento/2026-08-26-factura-ct-345.md`), informe de avance (`20-seguimiento/2026-10-07-informe-avance.md`), cronograma v1 (`10-plan/2025-06-24-cronograma-v1.csv`), el acta de constitución y el cálculo de `portafolio.py compute` al 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

## Proveedores — PRY-203 Reposición automática al 2026-10-15

### Retail Andino Consultores S.A.S. — contrato CT-345
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2025-06-18) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento de la plataforma (459.463.652 COP) | 2025-08-16 | `pending`, 425 días de atraso | ninguna | ver abajo |
| Bolsa de horas de desarrollo (459.463.652 COP) | 2025-09-28 | `pending`, 382 días de atraso | ninguna | ver abajo |
| Configuración del catálogo (459.463.652 COP) | 2025-11-10 | `pending`, 339 días de atraso | ninguna | ver abajo |
| Soporte del primer trimestre (459.463.652 COP) | 2025-12-23 | `pending`, 296 días de atraso | ninguna | ver abajo |

Resumen del script: 4 entregables, 0 aceptados, 4 atrasados, 0 aceptados sin evidencia. Facturado: 459.463.652 COP (FV-1345, 2026-08-26, "radicada en cuentas por pagar").

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Factura sin entrega | "Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto" | Hay una factura por 459.463.652 COP y ningún acta de recibo en la carpeta; 0 de 4 entregables aceptados. El script levanta `vendor_invoiced_without_delivery`. | contrato CT-345; factura FV-1345 |
| Qué se facturó | Cuatro entregables de 459.463.652 COP cada uno | El valor de la factura es igual al de un entregable, pero su concepto dice "Entregables del contrato CT-345" (plural) y no nombra cuál. No se puede decir a qué entregable corresponde. | contrato CT-345; factura FV-1345 |
| Estado según el contrato | Los 4 figuran "en curso" | Los 4 vencieron entre hace 296 y 425 días | contrato CT-345 |
| Hitos del plan | Cronograma con 5 hitos "cerrado" | Ningún hito tiene acta ni otra evidencia (`milestone_met_without_evidence` ×5, entre 273 y 429 días). El avance declarado es 47 % frente a un plan que sustenta 100 % (brecha de 53,0 puntos). | cronograma v1; informe de avance |
| Estado declarado | Verde (gerente Rubén Cárdenas, corte 2026-10-07) | Cuatro señales abiertas que el informe no menciona: hitos sin evidencia, avance contra plan, entregables atrasados, facturado sin entrega. | informe de avance; `compute` |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Licenciamiento de la plataforma | `pending` (contrato: "en curso") | 2025-08-16 |
| Bolsa de horas de desarrollo | `pending` (contrato: "en curso") | 2025-09-28 |
| Configuración del catálogo | `pending` (contrato: "en curso") | 2025-11-10 |
| Soporte del primer trimestre | `pending` (contrato: "en curso") | 2025-12-23 |

Ninguno está declarado como entregado ni aceptado. Por eso el script no los cuenta como "aceptados sin evidencia", sino como atrasados.

### Compromisos del proveedor vencidos
Ninguno detectado, pero no es una conclusión de que no existan. El proyecto no tiene carpeta de reuniones (`30-reuniones`) y la ficha no registra compromisos. Sin actas de comité no hay dónde leer lo que el proveedor prometió.

### Sin dato
- **Vigencia del contrato, renovación automática y preaviso:** el contrato no los trae en el texto leído. Por eso no se puede decir si algún preaviso vence antes del cierre. El cronograma termina el 2026-01-15 y ya pasó.
- **Acta de recibo de cualquiera de los 4 entregables:** no está en la carpeta.
- **A qué entregable corresponde la factura FV-1345:** no lo dice.
- **Si hay otras facturas:** solo hay una en la carpeta.
- **Fase del proyecto:** sin dato, igual que producto y autoridad.
- **El contrato** está en la carpeta, así que el cruce no es una lista de supuestos. Sí es solo un contrato y una factura, sin actas.

## Después
- Hay una factura radicada sin acta de recibo. Si la factura aún no se ha pagado, hay que frenarla hasta que el gerente aporte el acta o confirme por escrito qué se recibió. Si ya se pagó, es un hallazgo para comité. Los documentos no dicen cuál de los dos casos es.
- Los 4 entregables llevan entre 296 y 425 días de atraso y el informe de avance los reporta en verde. Ofrezco llevar esto a comité (próximo comité: 2026-10-29) con los dos puntos de decisión: pedir al proveedor el acta de recibo o el entregable, y pedir al gerente que corrija el estado declarado.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados; la verificación es de quien lo usa. Las cifras derivadas (días de atraso, brecha de 53,0 puntos, conteos) se copian de `portafolio.py compute`. No se calculó ninguna suma propia.*
