**Sale de:** ficha `estado/records/PRY-200.json`, acta de constitución (2025-07-09), cronograma v1 (2025-07-09), informe de avance (corte 2026-10-12) y la salida de `portafolio.py compute` del 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), sin nuevo registro.

## Cierre — PRY-200 Tienda en línea — 2026-10-15

**Este proyecto no está en condiciones de cerrarse contra lo pactado.** Nadie ha declarado que terminó: el informe más reciente (2026-10-12) lo reporta en verde, con 76 % de avance, un hallazgo de seguridad abierto y dos riesgos abiertos. Lo que sigue es el borrador de cierre con lo que se puede y no se puede sostener. Si el comité lo cierra hoy, sería por decisión, no por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** «Tienda en línea en producción y medido» (acta de constitución, 2025-07-09, sección *Criterio de éxito*).
**Se cumplió:** no se puede determinar. Ningún documento muestra la tienda en producción ni una medición. El informe ni lo menciona.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 (acta) | Sin dato | El acta no lo describe; ningún documento lo vincula a un hito |
| Componente 2 (acta) | Sin dato | Ídem |
| Componente 3 (acta) | Sin dato | Ídem |
| Hito: Diseño de la experiencia aprobado (2025-10-03) | Declarado «cerrado» en el cronograma | Sin acta de recibo ni otra evidencia (377 días desde su fecha) |
| Hito: Ambiente de pruebas certificado (2025-12-18) | Declarado «cerrado» | Sin evidencia (301 días) |
| Hito: Integración con el ERP (2026-03-04) | Declarado «cerrado» | Sin evidencia (225 días) |

Los tres hitos del plan figuran cerrados, es decir, el plan sostiene 100 %, y el informe declara 76 %: una brecha de 24.0 puntos que ningún documento explica. De las fuentes de la ficha, 0 son evidencia y 2 son declaraciones.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Sin dato: ningún documento registra recortes de alcance. El acta solo excluye «lo que otro proyecto cubre», sin decir qué. | — | — |

Cambios de control de cambios registrados: 0.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-03-04 (cronograma v1) | 2026-03-04 | Sin dato: no hay cierre declarado | 0 días (replanificaciones: 0) |
| Presupuesto (COP) | 1.200.000.000 aprobado | 1.200.000.000 | Ejecutado a 2026-10-12: 548.436.150 (45.7 %). Comprometido: 877.039.354 (73.1 %). Proyección al cierre: 1.209.542.313 | Proyección 0.8 % sobre lo aprobado |

Replanificaciones: 0.

**Contradicción entre documentos:** el acta fija el cierre en 2026-04-11 y el cronograma v1 en 2026-03-04. Ningún documento explica la diferencia. Contra cualquiera de las dos fechas, el proyecto ya la pasó sin declarar cierre: el último hito del plan era 2026-03-04, y a 2026-10-12 sigue con trabajo en curso. La desviación en días es 0 porque no hay línea base ni replanificación posteriores: el atraso no está registrado.

La ejecución es el 45.7 % del presupuesto, y el informe declara 76 % de avance. Eso no se concilia con los documentos disponibles.

### RAID al cierre
**Materializados:** incidencia «Hallazgo de seguridad en los medios de pago», desde 2026-10-12 (informe de avance). Sin responsable.
**No materializados:** sin dato. Los dos riesgos siguen reportados como abiertos, así que no se pueden dar por no materializados.
**Abiertos, con doliente:** ninguno. Los tres ítems abiertos no tienen responsable, probabilidad, impacto ni fecha:
- Incidencia: hallazgo de seguridad en los medios de pago.
- Riesgo: disponibilidad de los jefes de tienda para el piloto.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega.

Lo que queda abierto sin doliente con nombre no está cerrado. Que haya un «piloto» pendiente y una «última entrega» por confirmar contradice un proyecto terminado.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Tres hitos figuran «cerrados» en el cronograma sin ningún documento de recibo | Fechas 2025-10-03, 2025-12-18, 2026-03-04; informe del 2026-10-12 | No documentado en ningún archivo; consecuencia observable: el informe declara 76 % frente a 100 % que sostiene el plan | Sin dato: dejar sin lección el «qué haríamos distinto» hasta que alguien documente el efecto. Cualquier propuesta hoy sería opinión mía, no un hecho anclado |

No entra ninguna otra lección: ningún otro aprendizaje se puede anclar a un hecho documentado.

### Sin dato
- Si la tienda está en producción y si se midió (criterio de éxito).
- Qué son los Componentes 1, 2 y 3 y su estado.
- Por qué el acta dice cierre 2026-04-11 y el cronograma 2026-03-04.
- Evidencia de recibo de los tres hitos.
- Quién responde por la incidencia de seguridad y por los dos riesgos.
- Qué cubre «lo que otro proyecto cubre» en las exclusiones.
- Fase del proyecto y autoridad (campos vacíos en la ficha).
- Presupuesto final: solo hay corte parcial al 2026-10-12.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto no ha declarado terminar y sigue en el barrido diario. Se puede hacer cuando alguien declare el cierre o el comité lo decida por escrito.

*Pie de rigor: borrador de trabajo. Cada dato viene del documento citado; la verificación es de quien lo lea. Criterio no sabe lo que se habló fuera de los documentos.*
