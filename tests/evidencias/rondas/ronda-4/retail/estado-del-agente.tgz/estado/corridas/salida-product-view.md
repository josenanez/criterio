# Producto: puntos de fidelización — al 2026-10-15

Sale de las fichas en `estado/records` (cálculo del 2026-10-15). Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.10).

**Puntos de fidelización tiene un solo proyecto: PRY-201 Programa de fidelización.** La vista por producto no aporta nada aquí y no armo sección de producto. Esto es lo que dicen las fichas de ese proyecto:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| puntos de fidelización | 1 (PRY-201) | 0 | 2026-06-11 (PRY-201) | COP 6.800.000.000 | COP 4.342.015.470 |

- **Alertas del cálculo: 0.** Pero no es lo mismo que «sin problema»; dos cosas no se pueden leer como verde:
  - **La fecha de fin comprometida (2026-06-11) ya pasó** y el proyecto declara 78 % de avance con estado **rojo** (informe del 2026-10-10, de hace 5 días). El script no marca atraso porque la ficha **no tiene hitos** (`milestones` vacío) y la línea base coincide con la vigente (desviación 0 días); no hay contra qué medir avance ni atraso de hitos. El cero es ausencia de plan medible, no cumplimiento.
  - **Ningún dato de la ficha tiene evidencia propia:** 0 con evidencia, 2 declaraciones, 15 sin marcar. Los campos de identidad y plan vienen de un documento del 2025-07-07 (15 meses de antigüedad, por encima del umbral de 12).
- **Dinero:** aprobado COP 6.800.000.000; comprometido 4.342.015.470 (63,9 %); ejecutado 1.176.506.415 (17,3 %); proyección 6.315.003.234 (−7,1 % frente a lo aprobado); disponible real 2.457.984.530. Las cuatro cifras vienen completas en este único proyecto.
- **Dependencias internas:** ninguna (un solo proyecto). **Dependencias declaradas en la ficha:** ninguna.
- **Proveedores:** ninguno registrado. **Cambios:** 1 solicitud, sin impacto en tiempo.
- **Campos que faltan:** autoridad (`identity.authority`) y fase (`identity.phase`).
- **Sin cifra que dar:** cuánto atraso real lleva sobre el 2026-06-11 no lo calcula el script sin hitos; no lo escribo.

## Proyectos sin producto declarado
Seis proyectos no declaran producto, así que nadie puede responder por el conjunto al que sirven (no son de este producto, pero es un hallazgo de gobierno):

| Proyecto | Área dueña |
|---|---|
| PRY-202 Centro de distribución norte | no calculada en la salida |
| PRY-203 Reposición automática | no calculada en la salida |
| PRY-206 Precios dinámicos | no calculada en la salida |
| PRY-209 Migración del ERP | no calculada en la salida |
| PRY-210 Etiquetas electrónicas de precio | no calculada en la salida |
| PRY-211 Pronóstico de demanda | no calculada en la salida |

Nota: PRY-199 declara el producto «PRD-299», un código y no un nombre; no se pudo cruzar con ningún otro.

## Pie de rigor
Fichas: PRY-201 (y la lista de los otros 12 solo para detectar proyectos sin producto). Corte: 2026-10-15. Lo que no sé: la causa del rojo, el atraso real contra la fecha, y si algún otro proyecto sin producto sirve a fidelización. La verificación es suya.
