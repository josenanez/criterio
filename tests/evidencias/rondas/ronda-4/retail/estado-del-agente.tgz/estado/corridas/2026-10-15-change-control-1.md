# Corrida del 2026-10-15 · change-control

13 proyectos · 55 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

Solicitud +30 días a la salida a producción de PRY-203. No hay impacto en el portafolio (sin dependencias declaradas). La línea base v1 (2026-01-15) está vencida hace 273 días; acta (2026-02-04) y cronograma no coinciden; avance 47% vs 5 hitos cerrados sin evidencia. Sin autoridad declarada: recomendado a Comité Comercial. No se registró línea base nueva. No sé: quién pide, por qué, fecha real, costo, dependencia con PRY-209.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-203.json` (corte 2026-10-07, actualizada 2026-10-15) y de los documentos de la carpeta PRY-203. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.

## Solicitud de cambio — PRY-203 Reposición automática — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta en ningún documento de la carpeta; llegó como instrucción de la sesión. · **Por qué:** no se dio motivo. El único hecho cercano es el informe del 2026-10-07: «el equipo perdió dos semanas por rotación de un desarrollador clave». Ese texto no pide ni justifica un cambio de fecha.

**Lectura que tomé (suposición mía):** «salida a producción» es el hito «Despliegue en la cadena», que además es el criterio de éxito del acta («Reposición automática en producción y medido»). Los 30 días los conté sobre la fecha de ese hito, no sobre hoy.

### Antes de evaluar: lo que hay que decir primero

1. **La línea base vigente ya venció.** Es la v1, aprobada el 2025-06-24, con despliegue el **2026-01-15**. Hoy es 2026-10-15: van **273 días** de vencida. Sumarle 30 días da 2026-02-14, que también quedó **243 días atrás**. Mover «30 días» sobre esa fecha no describe ninguna salida posible.
2. **Dos documentos no coinciden en la fecha de cierre.** El acta dice cierre **2026-02-04**. El cronograma v1 dice despliegue **2026-01-15**. Son 20 días de diferencia y ningún documento los explica. Con el acta, +30 días da 2026-03-06, también vencida.
3. **El plan dice 100%, el gerente dice 47%.** Los 5 hitos figuran como cerrados en el cronograma, sin evidencia de cierre en ninguno. El informe del 2026-10-07 declara 47% y estado verde. Los dos no pueden ser ciertos: si el despliegue estuviera cerrado, no habría un 47%.
4. **No hay línea base nueva ni cambio registrado.** `changes` está vacío y hay una sola línea base. Replanificaciones: 0. Es decir, el plan nunca se movió en el papel, aunque el proyecto lleva 9 meses de atraso respecto de él.

Por eso, lo que se pide no es un cambio de 30 días. Es **reconocer que la fecha ya no se sostiene y fijar una nueva con fundamento**. Ese fundamento no está en la carpeta.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta). Sin cambio pedido. | Sin dato | Ninguna declarada. |
| Tiempo | Despliegue 2026-01-15 (cronograma) o cierre 2026-02-04 (acta); ambas vencidas | 2026-02-14 (o 2026-03-06 con la fecha del acta) | +30 días sobre una fecha ya vencida. Contra hoy, el atraso real es de 273 días y el cambio no lo cubre. |
| Costo | Aprobado 6.800.000.000 COP; ejecutado 3.562.697.966; comprometido 3.051.411.740; proyección 6.283.634.402 (informe 2026-10-07) | Sin dato | **No hay estimación del costo de 30 días más.** No la invento. |

**Quién absorbe lo que no está declarado.** Ni alcance ni costo traen impacto declarado. Si la fecha se mueve sin tocar presupuesto, lo absorben el equipo (ya perdió dos semanas por una rotación y concentra el conocimiento en una persona, según el propio informe) y la calidad de las pruebas, que el informe dice haber «ajustado» con seguridad.

**Cifras del presupuesto que conviene mirar antes de aprobar nada:**
- Lo ejecutado (3.562.697.966) es **mayor** que lo comprometido (3.051.411.740). En un proyecto sano pasa al revés. No hay documento que lo explique.
- El gasto lleva 52,4% del aprobado y el avance declarado es 47%. Extrapolando linealmente, 3.562.697.966 / 0,47 da unos 7.580 millones, por encima de los 6.800 millones aprobados. Es una cuenta mía, de orden de magnitud, no una cifra de la carpeta; sirve para dudar de la proyección de 6.283.634.402, que está por debajo de esa extrapolación. Ninguna cifra está respaldada por un documento de costo.
- El proveedor Retail Andino Consultores (CT-345) tiene **4 entregables pendientes, todos vencidos** (de 296 a 425 días) y figura **facturado sin entrega**: 459.463.652 COP en la factura del 2026-08-26. Un cambio de fecha no resuelve eso y lo deja más expuesto.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno detectado | `impact --code PRY-203 --days 30` no alcanza a ningún proyecto, ni directa ni indirectamente. `cannot_hold_date` = 0 y dependencias sin confirmar = 0. | — |

**Esto no significa que no haya efecto.** Significa que ninguna ficha declara una dependencia con PRY-203, y el acta de PRY-203 dice «Ninguna declarada». La integración con el ERP era un hito de este proyecto, y existe un PRY-209 Migración del ERP en el portafolio; no hay documento que diga si se tocan. Es una pregunta abierta, no un hallazgo. Tampoco sé cuántos días se movería cada proyecto: eso requiere holgura por actividad, que la ficha no tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo `authority` está en `not_found`: el acta no declara quién aprueba cambios de fecha, de alcance ni de presupuesto. · **Según:** acta 2025-06-24, que solo dice que el **Comité Comercial** aprobó el presupuesto y figura como comité del proyecto; patrocinadora Liliana Torres; gerente Rubén Cárdenas. · **Va a comité:** **sí, recomendado**, al Comité Comercial. No porque se haya excedido una autoridad, sino porque no hay ninguna declarada contra la cual medir, y porque el cambio mueve la fecha comprometida de un proyecto con 9 meses de atraso y presupuesto en cuestión. Ese vacío es el hallazgo de fondo. Próximo comité configurado: 2026-10-29.

### Si no se aprueba
El proyecto sigue con una fecha vencida hace 273 días, declarado en verde y con 47% de avance. Ese verde no lo sostienen los documentos: el cálculo marca la contradicción entre lo declarado y la evidencia (hitos sin evidencia, avance contra plan, entregables del proveedor vencidos, facturación sin entrega). No aprobar el cambio no corrige nada de eso; lo deja igual.

### Si se aprueba
No se puede registrar una línea base 2 todavía. Faltan los tres datos que la solicitud exige: fecha de cierre fundamentada, presupuesto y motivo, más el documento que la apruebe. Con lo que hay, lo único honesto es esto:

Línea base 2 — cierre: **por definir** (la cuenta de +30 días da 2026-02-14, vencida) · presupuesto: **por definir** (sin estimación) · motivo: **no consta** (solo el informe del 2026-10-07 menciona dos semanas perdidas).

**Desviación acumulada contra la línea base original:** hoy, **273 días** contra la fecha del cronograma (2026-01-15), o 253 días contra la del acta (2026-02-04); en costo, aún no se mide porque el presupuesto no ha cambiado (6.800.000.000 aprobado; proyección 6.283.634.402). El script reporta `slip_vs_original_days = 0` porque los 5 hitos figuran como cerrados; ese cero es consecuencia de un dato sin evidencia, no una medición, y no debe citarse como «sin atraso». Reconciliación de cambios: no hay cambios aprobados ni línea base movida, así que `unauthorized_days` no aplica.

### Qué no sé
- Quién pide el cambio y por qué.
- Cuál de las dos fechas (15 de enero o 4 de febrero de 2026) es la comprometida.
- Si los hitos realmente se cerraron: ningún documento lo prueba.
- La nueva fecha real de salida a producción y su costo.
- Si PRY-209 u otro proyecto depende de este.

### Después
Recomiendo llevarlo al comité del 2026-10-29 como decisión de rebaseline, no como «+30 días»: (1) fecha realista de producción con su sustento, (2) costo de ese tiempo, (3) quién tiene autoridad para aprobar cambios en este proyecto, y (4) qué se hace con la factura de CT-345 sin entregables recibidos. No registré ninguna línea base nueva: nadie con autoridad la ha aprobado.

---
**Pie de rigor.** Borrador de trabajo, no decisión ni asesoría. Cada dato sale del documento citado en la ficha; la verificación es de quien lo use. Fuentes: `PRY-203-reposición-automática/00-gobierno/2025-06-24-acta-constitucion.docx`, `…/10-plan/2025-06-24-cronograma-v1.csv`, `…/20-seguimiento/2026-10-07-informe-avance.md`, `…/20-seguimiento/2026-08-26-factura-ct-345.md`. La extrapolación de costo y la lectura de «salida a producción» son mías y están marcadas como tales.
