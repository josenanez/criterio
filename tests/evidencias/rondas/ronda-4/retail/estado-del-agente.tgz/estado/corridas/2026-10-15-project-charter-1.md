# Corrida del 2026-10-15 · project-charter

13 proyectos · 24 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

Revisión del acta de PRY-201 (2025-07-07). Faltan autoridad del gerente, supuestos y restricciones, hitos, cadencia del comité y criterio de éxito medible. Alcance y exclusiones son marcadores. Cierre 2026-06-11 vencido sin replanificación aprobada. No sabe por qué se movió el cierre ni cómo se explica 78% de avance con 17% ejecutado.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Acta previa:** existe, del 2025-07-07 (`PRY-201-programa-de-fidelización/00-gobierno/2025-07-07-acta-constitucion.md`). Modo revisar.

*Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.10).*

## Acta — PRY-201 · Programa de fidelización
**Estado:** existe, del 2025-07-07

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** (la ficha lo marca `not_found`) | No se sabe si María Restrepo podía decidir por sí misma la CC-01 (+118.000.000 COP, +59 días, ampliación de alcance). Queda en "pendiente de presentación al comité" desde el 2026-10-04 y no hay regla para saber si debía subir. |
| Objetivo de negocio | Presente pero es la solución: "Entregar programa de fidelización para Talento humano" | No dice qué cambia en el negocio ni cuánto. Con ese objetivo, cualquier entrega del programa lo cumple. |
| Alcance | Marcador: "Componente 1 / 2 / 3" | Los componentes no están nombrados. La CC-01 "amplía el alcance" sobre un alcance que no se puede leer, así que el tamaño de la ampliación no se puede verificar. |
| Exclusiones | Genérica: "Lo que otro proyecto cubre" | No excluye nada concreto. No sirve para rechazar una ampliación ni para detectar traslape con otros proyectos. |
| Patrocinador con nombre | Cumple: Óscar Ramírez | — |
| Supuestos y restricciones | **No están.** Dependencias: "Ninguna declarada" | El informe del 2026-10-10 ya trae riesgos que nacen de restricciones no declaradas: el congelamiento de fin de año y el conocimiento concentrado en una persona. |
| Criterio de éxito medible y quién lo mide | Parcial: "en producción y medido" | No hay métrica, meta ni plazo de medición. Tampoco se dice quién mide. |
| Hitos principales | **No están** (la ficha tiene `milestones` vacío) | Solo hay inicio y cierre (2025-07-17 a 2026-06-11). El 78 % reportado no se puede contrastar con hitos. |
| Cadencia del comité | **No está** | Se nombra el Comité de Transformación Digital, pero sin periodicidad. No se sabe cuándo se vería la CC-01. |
| Hallazgo extra: línea base | El cierre comprometido (2026-06-11) ya pasó. El informe del 2026-10-10 sigue en curso. Solo existe la línea base v1 y no hay ninguna replanificación aprobada. | La CC-01 dice "+59 días sobre la línea base vigente", pero la única línea base es la original. Hoy el proyecto va unos 4 meses fuera de fecha sin cambio aprobado. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo describe la solución (acta, "Objetivo del negocio").
**Alcance:** pendiente de definir. El acta lista "Componente 1, 2 y 3" sin nombrarlos (acta, "Alcance").
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre", sin detalle (acta, "Fuera de alcance").
**Patrocinador:** Óscar Ramírez (acta) · **Gerente:** María Restrepo (acta; informe 2026-10-10)
**Autoridad del gerente:** pendiente de definir. No figura en ningún documento.
**Comité al que reporta:** Comité de Transformación Digital (acta) · **Cadencia:** pendiente de definir. La configuración da el próximo comité del portafolio el 2026-10-29, pero eso no es un dato del acta.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Presupuesto aprobado** (dato del acta): 6.800.000.000 COP, aprobado el 2025-07-07.
**Criterio de éxito:** "Programa de fidelización en producción y medido" (acta). No es medible tal como está. **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo hay inicio 2025-07-17 y cierre 2026-06-11 (acta).

### Lo que no se puede afirmar
- El informe declara Rojo y 78 % de avance con 1.176.506.415 COP ejecutados, el 17 % del aprobado. Esa relación no se explica en ningún documento y el acta no trae hitos para contrastarla.
- No hay documento que diga por qué el cierre pasó del 2026-06-11.

## Después
- El acta quedó sin autoridad declarada. Te propongo **llevar esa definición al Comité de Transformación Digital** junto con la CC-01. Es una decisión del comité sobre cuánto y qué puede decidir la gerente, no un trámite.
- De la revisión salieron supuestos y restricciones no declaradas (congelamiento de fin de año, conocimiento concentrado). Te propongo pasarlos al registro RAID con `/raid-log`.

---
**Pie de rigor:** Esta salida es un borrador de trabajo que se apoya en 3 documentos: el acta del 2025-07-07, la CC-01 del 2026-10-04 y el informe del 2026-10-10. Lo que se habló fuera de ellos no se sabe. Cada dato lleva su fuente y la verificación es de quien lo usa. No se completó ningún campo con lo razonable.
