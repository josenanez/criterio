Sale de: las 13 fichas del portafolio (`estado/records/PRY-199` a `PRY-211`), los informes de avance, las actas de constitución, las minutas de comité de 2026-10-10 a 2026-10-14, las seis minutas semanales del PRY-209 (septiembre–octubre) y las notas de reunión del PRY-209 del 2026-10-15. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15.

## RAID — Portafolio al 2026-10-15
18 riesgos · 0 supuestos · 6 incidencias · 2 dependencias (reclasificadas desde riesgos)
26 sin doliente · 26 sin fecha · 0 medibles por movimiento · 1 no registrado formalmente (aparte de los 26)

Escala: ningún documento define probabilidad ni impacto. Usé alta/media/baja y no asigné valores, porque ninguna fuente los trae. Los dejo en "—".

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| PRY-200 / 201 / 204 / 211 | Incidencia | Hallazgo de seguridad en los medios de pago (mismo texto en cuatro informes) | Sin doliente | 2026-10-12 / 10-10 / 09-26 / 10-04 (fecha del informe que lo trae) | Cuatro proyectos, ninguno con doliente. Si es el mismo hallazgo, afecta a más de un proyecto. Tres de los cuatro reportan verde (200, 204, 211). Los documentos no dicen si es un solo hallazgo o cuatro, y esa es la primera pregunta. |
| PRY-204 / 209 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | Sin doliente | 2026-09-26 (204) / 2026-10-15 (209) | Mismo texto en dos proyectos, sin doliente. PRY-204 lo lleva abierto casi tres semanas en el informe más reciente que tiene. |
| PRY-209 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | Sin doliente | Dicho el 2026-10-15 | Nadie lo anotó y no está en el informe del mismo día. Está junto a una revisión con el proveedor pendiente para el 2026-10-25 (Óscar Ramírez). |

Esto no es una decisión del comité todavía: cumple el criterio de escalamiento porque no tiene doliente (primera fila), toca a más de un proyecto (primeras dos filas) o no está registrado (tercera).

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-209, notas de reunión (`2026-10-15-notas-reunion.txt`) | 2026-10-15 |

Es el único. Las otras minutas de octubre (PRY-199, 202, 204, 205, 207, 211) solo traen la tabla de compromisos, y las seis minutas semanales del PRY-209 no mencionan riesgos ni dependencias. No inventé ninguno más.

### Sin doliente o sin fecha
Los 26 ítems registrados faltan en las dos cosas: ninguno tiene doliente, fecha ni probabilidad e impacto. Lo reporto como hallazgo y no relleno nada.

| Proyecto | Ítems | Qué falta |
|---|---|---|
| PRY-199 | 2 riesgos | Doliente, fecha, valoración |
| PRY-200 | 1 riesgo, 1 dependencia, 1 incidencia | Doliente, fecha |
| PRY-201 | 2 riesgos, 1 incidencia | Doliente, fecha |
| PRY-202 | 2 riesgos | Doliente, fecha |
| PRY-203 | 1 riesgo | Doliente, fecha |
| PRY-204 | 2 riesgos, 2 incidencias | Doliente, fecha |
| PRY-205 | 2 riesgos | Doliente, fecha |
| PRY-206 | 1 dependencia | Doliente, fecha |
| PRY-207 | 1 riesgo | Doliente, fecha |
| PRY-208 | 1 riesgo | Doliente, fecha |
| PRY-209 | 2 riesgos, 1 incidencia (+1 no registrado) | Doliente, fecha |
| PRY-210 | 1 riesgo | Doliente, fecha |
| PRY-211 | 1 riesgo, 1 incidencia | Doliente, fecha |

Sin movimiento en dos períodos: no lo puedo medir. Ningún ítem lleva fecha de último movimiento, y los informes listan los riesgos sin historial. No digo "sin movimiento" de algo que no sé.

Reclasificaciones:
- **PRY-200 y PRY-206, «El proveedor no ha confirmado la fecha de la última entrega»**: estaba como riesgo. Pasa a dependencia, porque la entrega es de un tercero que el proyecto no controla. Y una confirmación pendiente es, por definición, una dependencia declarada pero no acordada.
- Dejé como riesgo, pero lo señalo como dudoso: «Disponibilidad de los jefes de tienda para el piloto» (PRY-199, 200, 209) podría ser un supuesto, porque nadie dice que se haya verificado. Los documentos no me permiten decidirlo. Lo decide el gerente.
- «Congelamiento de cambios en temporada alta» (PRY-201, 204, 207) lo mantengo como riesgo, aunque es una restricción de calendario casi segura.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-200 | Proveedor (sin nombre en el informe) | No | Entrega final sin fecha confirmada. El informe es del 2026-10-12. |
| PRY-206 | Proveedor (sin nombre en el informe) | No | Entrega final sin fecha confirmada. El informe es del 2026-10-03. |

Ninguna de las dos lleva código de proyecto, porque la contraparte es un proveedor y no otro proyecto del portafolio.

Cruce entre proyectos: no se puede hacer. Las 13 actas de constitución dicen «Ninguna declarada» en dependencias, así que no existe ninguna dependencia entre proyectos que haya podido moverse.

Una pregunta, no un hallazgo: los hitos de «Integración con el ERP» aparecen en 9 proyectos (199, 200, 202, 203, 204, 205, 207, 208, 211), y existe un proyecto de migración del ERP (PRY-209). Ese proyecto tiene «Ambiente de pruebas certificado» con fecha 2026-10-05 todavía pendiente y sin evidencia a 2026-10-15, e «Integración con el ERP» el 2026-12-05. Ningún documento dice que esos 9 dependan del PRY-209. Si dependen, hoy es una dependencia que nadie declaró. Lo dejo para que el gerente de PMO lo confirme.

### Registro completo
Prob./Impacto: «—» = no declarados. Doliente y Fecha: «sin» = ningún documento los trae. Último mov.: «no consta» en todos. «Visto en» es el informe en que aparece, no la fecha en que empezó.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último mov. |
|---|---|---|---|---|---|---|---|
| PRY-199 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-13) |
| PRY-199 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | sin | sin | no consta (visto 2026-10-13) |
| PRY-200 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | sin | sin | no consta (visto 2026-10-12) |
| PRY-200 | Dependencia | Proveedor no ha confirmado la fecha de la última entrega (reclasificado) | — | — | sin | sin | no consta (visto 2026-10-12) |
| PRY-200 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin | sin | no consta (visto 2026-10-12) |
| PRY-201 | Riesgo | Congelamiento de cambios en temporada alta | — | — | sin | sin | no consta (visto 2026-10-10) |
| PRY-201 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-10) |
| PRY-201 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin | sin | no consta (visto 2026-10-10) |
| PRY-202 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-13) |
| PRY-202 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin | sin | no consta (visto 2026-10-13) |
| PRY-203 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-07) |
| PRY-204 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin | sin | no consta (visto 2026-09-26) |
| PRY-204 | Riesgo | Congelamiento de cambios en temporada alta | — | — | sin | sin | no consta (visto 2026-09-26) |
| PRY-204 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin | sin | no consta (visto 2026-09-26) |
| PRY-204 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | sin | sin | no consta (visto 2026-09-26) |
| PRY-205 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-14) |
| PRY-205 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin | sin | no consta (visto 2026-10-14) |
| PRY-206 | Dependencia | Proveedor no ha confirmado la fecha de la última entrega (reclasificado) | — | — | sin | sin | no consta (visto 2026-10-03) |
| PRY-207 | Riesgo | Congelamiento de cambios en temporada alta | — | — | sin | sin | no consta (visto 2026-10-14) |
| PRY-208 | Riesgo | Cambio en la regulación de datos personales que puede mover el alcance | — | — | sin | sin | no consta (visto 2026-10-13) |
| PRY-209 | Riesgo | Disponibilidad de los jefes de tienda para el piloto | — | — | sin | sin | no consta (visto 2026-10-15) |
| PRY-209 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-15) |
| PRY-209 | Incidencia | La prueba de carga de temporada no alcanzó el umbral pactado y se repite | — | — | sin | sin | no consta (visto 2026-10-15) |
| PRY-210 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-08) |
| PRY-211 | Riesgo | Concentración del conocimiento en una sola persona | — | — | sin | sin | no consta (visto 2026-10-04) |
| PRY-211 | Incidencia | Hallazgo de seguridad en los medios de pago | — | — | sin | sin | no consta (visto 2026-10-04) |
| PRY-209 | Riesgo — **no registrado formalmente** | El proveedor podría no llegar con el equipo completo para la siguiente fase | — | — | sin | sin | dicho 2026-10-15 |

## Después
- Subir a comité (próximo: 2026-10-29) los tres puntos de «Necesitan decisión ahora». Cada uno llevaría la pregunta cerrada: ¿quién es el doliente y con qué fecha?, y en el hallazgo de pagos, ¿es uno solo o son cuatro?
- Proponer doliente, no asignarlo: la persona natural es el gerente de cada proyecto, salvo en el hallazgo de pagos y la prueba de carga, que cruzan proyectos y piden que el comité nombre a una sola persona.
- Pedir a Óscar Ramírez (revisión con el proveedor, 2026-10-25) que diga si el riesgo del equipo incompleto se formaliza.

## Pie de rigor
- Qué leí: las fichas de los 13 proyectos y, en el texto extraído de los documentos, las secciones de riesgos de los informes, las dependencias de las actas y todas las minutas de octubre. Búsqueda por palabras clave más lectura de las secciones.
- Qué no leí: los PDF sin texto extraído (acta de recibo del PRY-199 y actas de recibo en PDF del PRY-211). Si traen riesgos, no aparecen aquí.
- Qué no sé: cuándo empezó cada incidencia, si los cuatro hallazgos de pagos son uno solo, si los ítems del informe siguen abiertos hoy y qué valoración les daría su gerente.
- Los documentos son la única base. Lo que se habló fuera de ellos no está.
- Es un borrador de trabajo. La verificación contra los documentos citados es suya.
