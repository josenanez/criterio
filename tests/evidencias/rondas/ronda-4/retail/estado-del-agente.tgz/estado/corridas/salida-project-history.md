## Historia · PRY-201 Programa de fidelización · 2025-07-07 a 2026-10-10

**Leí:** 3 documentos entre 2025-07-07 y 2026-10-10
**Trimestres sin un solo documento:** 2025-T4, 2026-T1, 2026-T2, 2026-T3 (el proyecto tiene documentos solo en 2025-T3 y 2026-T4)

*Términos: vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15; no hubo que registrarlos de nuevo.*

### En una línea
El acta de 2025-07-07 comprometió el cierre para 2026-06-11. Después no hay un solo documento durante unos 15 meses de calendario hasta el 2026-10-04, cuando aparece una solicitud de cambio (CC-01) y, seis días después, un informe en rojo con 78% de avance. La fecha de cierre comprometida ya pasó, el proyecto sigue abierto y ningún documento registra una replanificación ni una línea base nueva.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 0 documentadas | 0 días según `compute` (no hay línea base nueva que lo mida; ver nota) | No calculable: la ficha no tiene hitos | 0 documentados |

*Nota:* el 0 de atraso mide el movimiento de la línea base, no el calendario. El cierre original (2026-06-11) es anterior a la fecha de corte (2026-10-15) y el proyecto no ha cerrado. `compute` no entrega los días transcurridos desde esa fecha; no los escribo. Que la línea base no se haya movido es lo que hay que preguntar.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-07-07 | `00-gobierno/2025-07-07-acta-constitucion.md` | Se aprueba el proyecto: 6.800.000.000 COP, inicio 2025-07-17, cierre 2026-06-11. Patrocinador Óscar Ramírez, gerente María Restrepo, Comité de Transformación Digital. Alcance genérico («Componente 1, 2, 3»). |
| 2026-10-04 | `20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md` | Se solicita ampliar el alcance: +59 días sobre la línea base vigente y 118.000.000 COP adicionales. Autorización: pendiente de presentación al comité. |
| 2026-10-10 | `20-seguimiento/2026-10-10-informe-avance.md` | Estado declarado rojo, 78% de avance. Hallazgo de seguridad en medios de pago; despliegue reprogramado por el congelamiento de fin de año. Comprometido 4.342.015.470, ejecutado 1.176.506.415, proyección 6.315.003.234 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| — | — | — | — | — |

Ninguna aprobada. Dos hechos cercanos a una replanificación, ninguno aprobado:
- CC-01 (2026-10-04) pide +59 días, con decisión pendiente y sin comité que la haya decidido. `compute` registra 0 días de tiempo aprobado y 0 de línea base movida.
- El informe del 2026-10-10 dice que se «reprogramó el despliegue», pero no da fecha nueva, motivo más allá del congelamiento ni documento de aprobación. Es una reprogramación sin motivo documentado en forma de línea base.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios de gobierno documentados. | — |

Patrocinador y comité vienen solo del acta de 2025-07-07, que tiene 15 meses; no hay un documento posterior que los confirme. El gerente figura también en el informe del 2026-10-10. El campo `authority` no aparece en ningún documento.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | — | — | — |

No hay actas ni minutas en la carpeta, así que no hay compromisos extraíbles. No es lo mismo que decir que no hubo: solo que no están escritos.

### Desde cuándo lo declarado no se sostiene
No se puede fechar con rigor. La ficha no tiene hitos, así que no hay un primer hito sin evidencia que señalar, y ningún dato de avance tiene evidencia (`compute`: 0 fuentes de evidencia, 2 declaraciones). Lo que sí se ve:
- El único estado declarado (rojo, 78%, 2026-10-10) llega después de la fecha de cierre comprometida (2026-06-11). No hay estado declarado anterior contra el cual comparar.
- No hay un deslizamiento reconstruible: entre el acta y octubre de 2026 no hay documentos.
- La proyección al cierre (6.315.003.234 COP, 7,1% por debajo de lo aprobado según `compute`) no es consistente a simple vista con un proyecto en rojo con ampliación pendiente. No puedo decir cuál de las dos cifras falla.

### Lecciones ancladas a un hecho
Ninguna se puede anclar todavía. Lo único que los documentos sustentan:
- **Hecho:** CC-01 pide 59 días y 118.000.000 COP, y a 2026-10-04 estaba sin presentar al comité. **Efecto:** el cierre vigente sigue siendo 2026-06-11, que ya pasó. Hasta que el comité decida, el calendario oficial y el real no coinciden.

### Qué no sé
- Qué pasó entre 2025-07-07 y 2026-10-04: no hay ningún documento.
- Si hubo comités, replanificaciones o cambios de patrocinador fuera de la carpeta.
- Cuántos días van desde el cierre comprometido: `compute` no lo da.

No atribuyo intención. Que no haya documentos en cuatro trimestres no dice por qué; esa conversación es de una persona, con estos datos delante.

**Siguiente paso posible:** llevar CC-01 y la fecha de cierre vencida al comité del 2026-10-29, que es una decisión con base en esta historia.

*Pie de rigor: borrador de trabajo basado solo en los tres documentos citados; verifique cada dato contra su fuente. Criterio puede equivocarse.*
