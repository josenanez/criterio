# Corrida del 2026-10-15 · document-index

13 proyectos · 17 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

66 documentos sin cambio, 0 por releer. 146 citas de PRY-209 sin resolver aunque los 7 archivos existen; hipótesis (no verificada): normalización de la tilde en la ruta.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 66 · **Sin cambio:** 66 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ningún documento.

### Citas que dejaron de resolver
El índice marca **146 citas de PRY-209** (migración del ERP) como fuente no encontrada. Son campos de la ficha (identidad, plan, hitos, dinero, RAID y 26 compromisos) que citan estos 7 documentos:

- 00-gobierno/2026-05-28-acta-constitucion.docx
- 10-plan/2026-05-28-cronograma-v1.xlsx
- 20-seguimiento/2026-10-15-informe-avance.pdf
- 20-seguimiento/2026-10-06-acta-recibo-diseño-de-la-experiencia-aprobado.md
- 30-reuniones/2026-09-03, 09-10, 09-17, 09-24, 10-01 y 10-08-comite-semanal.md
- 2026-10-15-notas-reunion.txt

Los 7 archivos **sí existen** en la carpeta del proyecto y no figuran como borrados ni renombrados. Por eso no es un documento perdido. Lo más probable es que las citas de la ficha no se estén resolviendo contra la ruta real (por ejemplo, la tilde de «migración» en el nombre de la carpeta). Es una hipótesis: no la verifiqué.

Mientras tanto, esos datos de PRY-209 se muestran como sustentados y el índice no puede confirmarlo.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
No hay documentos por releer, así que no corresponde un `/portfolio-scan`. Sí conviene revisar por qué las citas de PRY-209 no resuelven antes de confiar en esa ficha. No corregí ninguna.
