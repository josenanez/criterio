# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 27 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

Presupuesto de PRY-204: cuatro cifras de un solo informe declarado (2026-09-26), proyección excede el aprobado 11.8%, comprometido 74.5% bajo umbral. Dijo que no sabe: aprobado original del acta, evidencia contable, proveedores, autoridad.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

*Fuentes: ficha `estado/records/PRY-204.json`, construida de 5 documentos de `PRY-204-cajas-de-autopago/` (el último, el comité del 2026-10-14); cifras recalculadas con `portafolio.py compute` al 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).*

## Presupuesto — PRY-204 Cajas de autopago al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda, no se convirtió nada)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 1200000000 | — | `20-seguimiento/2026-09-26-informe-avance.md` | 2026-09-26 |
| Comprometido | 894302033 | 74.5 | ídem | 2026-09-26 |
| Ejecutado | 501728889 | 41.8 | ídem | 2026-09-26 |
| Proyección al cierre | 1342154042 | excede el aprobado en 11.8 | ídem | 2026-09-26 |

**Disponible real** (aprobado menos comprometido): 305697967 COP

Las cuatro cifras salen de un solo documento, el informe de avance del gerente: son una declaración, no un dato contable. Ningún documento de evidencia (factura, extracto, ejecución presupuestal) las respalda; la ficha cuenta 0 fuentes de evidencia y 2 de declaración. La proyección es de la misma fecha que las otras tres (19 días de antigüedad, bajo el umbral de 30), así que no es más vieja que el último movimiento de presupuesto que consta.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 1200000000 | 1200000000 | 0 |
| Fecha de cierre (tiempo) | 2027-02-16 | 2027-02-16 | 0 días |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. La línea base de tiempo es la v1 (2025-10-01) y no tiene motivo registrado porque no ha cambiado. No existe un documento de línea base de costo aparte: el "original" del aprobado es el mismo monto del informe de avance, no uno del acta de constitución.

### Ejecución frente a avance
Ejecutado 41.8% · Hitos cumplidos 2 de 4 (declarados), de los cuales solo 1 tiene evidencia · Avance declarado 32%; el plan sostiene entre 50% y 75%.
Lectura: el gasto ejecutado no está muy por encima del avance de hitos; lo que no cuadra es el avance, que va 18.0 puntos por detrás de lo que el plan sostiene. El 32% declarado está por debajo del 41.8% ejecutado.

### Alertas
- **Proyección por encima del aprobado:** 1342154042 contra 1200000000, un exceso de 11.8%, sobre el umbral de 10%. Es la alerta `variance_cost`.
- **Comprometido:** 74.5%, bajo el umbral de 90%. No hay alerta de tope.
- **El informe declara "verde" (2026-09-26)** y ese mismo informe trae la proyección que excede el aprobado. El script marca 4 señales que el estado verde no explica: costo, avance 18.0 puntos atrás, el hito "Ambiente de pruebas certificado" (vencía 2026-06-14) marcado cumplido sin evidencia, y el compromiso de Camilo Beltrán ("Entregar el punto 15", vencido el 2026-10-06, 9 días).
- Dos incidencias abiertas desde 2026-09-26, sin dueño, que pueden tocar el costo: hallazgo de seguridad en los medios de pago, y prueba de carga de temporada que no alcanzó el umbral y se repite. Ninguna trae estimación de costo.

### Sin dato
- Presupuesto aprobado original según el acta de constitución: no figura (el aprobado viene del informe de avance).
- Evidencia contable de comprometido y ejecutado: no hay.
- Detalle por proveedor: no hay proveedores ni contratos registrados en la ficha.
- Autoridad que aprobó el presupuesto (`identity.authority`) y fase (`identity.phase`): `not_found`.
- Los campos de identidad y plan vienen del 2025-10-01, 12 meses; están en el límite de antigüedad.

### Después
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). No ofrezco el detalle por proveedor porque no hay proveedores en la ficha.

---
*Pie de rigor: borrador de trabajo hecho solo con los documentos de la carpeta; no incluye lo hablado fuera de ellos. Las cifras vienen de un informe declarado, no de contabilidad. La verificación contra las citas es de quien lo lee.*
