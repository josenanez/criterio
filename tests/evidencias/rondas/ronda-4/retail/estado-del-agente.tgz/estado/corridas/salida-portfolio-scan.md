## Barrido — 2026-10-15

**Términos:** vigentes (v0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante ya registrado). No se volvió a pedir aceptación.

**Documentos:** 66 en la carpeta · 38 leídos · 28 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 3 sin cambio (PRY-204, PRY-205, PRY-209) · 0 sin carpeta propia

Formatos: 36 .md, 11 .docx, 7 .pdf, 7 .xlsx, 3 .csv, 1 .json, 1 .txt. Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro, sin subagentes. Nada diferido.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Iluminación LED en bodegas | 6 | identidad, plan, 5 hitos, dinero, 2 riesgos, 1 compromiso, contrato CT-199 con 3 entregables | autoridad, fase, motivo de la línea base |
| PRY-200 Tienda en línea | 3 | identidad, plan, 3 hitos, dinero, 2 riesgos, 1 incidencia | autoridad, fase, motivo de la línea base |
| PRY-201 Programa de fidelización | 3 | identidad, plan, dinero, 2 riesgos, 1 incidencia, solicitud CC-01 | autoridad, fase, cronograma e hitos (no hay), motivo de la línea base |
| PRY-202 Centro de distribución norte | 4 | identidad, plan, 4 hitos, dinero, 2 riesgos, 2 compromisos | autoridad, fase, producto (el acta dice «No aplica»), motivo de la línea base |
| PRY-203 Reposición automática | 5 | identidad, plan, 5 hitos, dinero, 1 riesgo, contrato CT-345 con 4 entregables y 1 factura | autoridad, fase, producto («No aplica»), motivo de la línea base |
| PRY-206 Precios dinámicos | 2 | identidad, plan, dinero, 1 riesgo | autoridad, fase, producto («No aplica»), cronograma e hitos (no hay), motivo de la línea base |
| PRY-207 Marca propia de alimentos | 4 | identidad, plan, 4 hitos, dinero, 1 riesgo, 2 compromisos | autoridad, fase, motivo de la línea base; fecha del compromiso del punto 37 («por definir») |
| PRY-208 Domicilios en dos horas | 3 | identidad, plan, 3 hitos, dinero, 1 riesgo | autoridad, fase, motivo de la línea base |
| PRY-210 Etiquetas electrónicas de precio | 2 | identidad, plan, dinero, 1 riesgo | autoridad, fase, producto («No aplica»), cronograma e hitos (no hay), motivo de la línea base |
| PRY-211 Pronóstico de demanda | 6 | identidad, plan, 5 hitos, dinero, 1 riesgo, 1 incidencia, 2 compromisos | autoridad, fase, producto («No aplica»), motivo de la línea base |

### Actualizados
Ninguno. PRY-204, PRY-205 y PRY-209 no tenían documentos nuevos ni cambiados; se conservan sus fichas.

### No pude leer
Ninguno. Los 66 archivos se convirtieron a texto.

### Movidos desde entrada/
Ninguno. No existe carpeta `entrada/` en esta documentación.

### Pendientes de clasificar
Ninguno.

### Qué hay que mirar (lo que muestran los documentos; el cálculo de señales lo hace el código)
- **Hitos declarados cerrados sin acta de recibo:** PRY-200 (3 de 3), PRY-202 (4 de 4), PRY-203 (5 de 5), PRY-207 (3 de 4 cerrados), PRY-208 (2 de 3). Quedan como `met` con `evidence` vacía. Con acta: PRY-199 (diseño de la experiencia) y PRY-211 (diseño y ambiente de pruebas).
- **Factura sin acta de recibo:** PRY-203 tiene la factura FV-1345 por 459.463.652 COP contra CT-345, y ninguno de los 4 entregables del contrato (todos con fecha en 2025) aparece con acta de recibo; el contrato los marca «en curso».
- **Fechas de cierre ya pasadas con avance incompleto:** PRY-200 (cierre 2026-04-11, avance 76%), PRY-201 (2026-06-11, 78%), PRY-202 (2026-08-24, 54%), PRY-203 (2026-02-04, 47%, con los 5 hitos declarados cerrados).
- **Ejecutado mayor que comprometido, tal como lo reportan los informes:** PRY-203 y PRY-211.
- **Estado verde con las cifras anteriores:** PRY-200, PRY-203 y PRY-211 declaran verde.
- **Cambio de alcance sin decidir:** PRY-201 CC-01 (ampliación de alcance, +59 días, +118.000.000 COP) está «pendiente de presentación al comité»; el proyecto ya reporta rojo.
- **Compromisos con fecha ya pasada y sin evidencia en la documentación:** PRY-202 (puntos 7 y 22) y PRY-211 (punto 39). Compromiso sin fecha: PRY-207, punto 37.
- **Autoridad del gerente:** ninguna de las 10 actas la declara.
- **Índice de PRY-209:** el plan de lectura listó como «fuente faltante» las citas de la ficha del gerente de PRY-209 (ficha-pm.json); esos documentos sí están en disco, y no se tocó esa ficha. Conviene revisarlo con `document-index`.

---
criterio-portfolio 0.3.10 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 206, 207, 208, 210, 211) · campos en `not_found`: autoridad y fase en las 10, motivo de línea base en las 10, producto en 5, cronograma/hitos en 3 · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
