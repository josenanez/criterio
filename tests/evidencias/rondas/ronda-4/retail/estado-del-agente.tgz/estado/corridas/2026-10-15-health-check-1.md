# Corrida del 2026-10-15 · health-check

13 proyectos · 65 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

Diagnóstico de PRY-203 sobre 5 documentos: verde y 47% declarados contra 5 hitos cerrados sin evidencia, 4 entregables del proveedor sin acta y una factura radicada. Dijo que no puede saber si entregó algo, qué fecha de cierre rige, ni el gasto real.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos: ya vigentes (v1.1, familia 0.3.10), aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`. No hubo que pedirlos de nuevo.

## Diagnóstico · PRY-203 Reposición automática · 2026-10-15

**Leí:** 5 documentos · 2025-06-18 a 2026-10-07 · formatos: docx (2), csv (1), md (2)
**No pude leer:** nada de la carpeta del proyecto quedó sin leer. Busqué menciones de PRY-203, "Reposición automática" y CT-345 en el texto convertido de las demás carpetas de proyecto (minutas, informes, actas) y no aparece en ninguna. Los docx de `documentos/productos` no tienen conversión en el caché y no los busqué.

### Dictamen
**Sostenido:** 6 afirmaciones · **Sin sustento:** 7 · **Contradicho:** 6
(Conteo mío al leer, agrupando las afirmaciones parecidas. El script no cuenta afirmaciones; sí calcula las señales que cito abajo.)

Desde esta carpeta se puede afirmar quién es el patrocinador, el gerente y el comité, cuánto se aprobó y qué se contrató y se facturó. No se puede afirmar que el proyecto esté en verde, que esté al 47% ni que haya entregado algo. El informe del 2026-10-07 declara verde y 47% por la mitad de un proyecto cuyo cierre comprometido ya pasó, y los cinco hitos del cronograma figuran "cerrado" sin un solo acta ni evidencia. Del lado del proveedor hay una factura radicada por 459.463.652 COP y ningún entregable con acta de recibo. El script cruza el "verde" declarado contra cuatro señales sin explicar: hitos cumplidos sin evidencia, avance contra plan, entregables del proveedor vencidos y facturación sin entrega.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Liliana Torres | Acta de constitución, 2025-06-24 |
| Gerente | Rubén Cárdenas | Acta de constitución, 2025-06-24; informe de avance, 2026-10-07 |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente en fechas, dinero o alcance. | Acta de constitución, 2025-06-24 |
| Comité | Comité Comercial (aprobó el presupuesto el 2025-06-24). No hay ninguna minuta suya en la carpeta. | Acta de constitución, 2025-06-24 |

Además, el acta tiene el alcance sin llenar ("Componente 1, 2, 3"), una exclusión genérica ("Lo que otro proyecto cubre") y "Ninguna declarada" en dependencias. Producto asociado: "No aplica". Fase: no figura. Sin autoridad declarada no hay desviación aprobada: las fechas del cronograma son fechas que alguien escribió.

### Contra el plan
Hay una sola línea base, v1, del 2025-06-24 (cronograma-v1.csv). Ninguna replanificación, ningún control de cambios y ningún motivo de cambio en la carpeta. Fecha vigente igual a fecha de línea base en los cinco hitos: desviación contra la original 0 días y contra la vigente 0 días (script).

Las dos fuentes no coinciden en el cierre: el acta fija **2026-02-04** y el cronograma termina el **2026-01-15**. Nada explica la diferencia. Con cualquiera de las dos, el cierre ya pasó a la fecha de corte.

### Hitos vencidos sin evidencia
Los cinco hitos están declarados "cerrado" en el cronograma, con fecha vigente igual a la de línea base. En la carpeta no hay ninguna evidencia de ninguno (script: `milestone_met_without_evidence`).

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2025-08-12 | 429 | Acta de aprobación del diseño |
| Ambiente de pruebas certificado | 2025-09-20 | 390 | Certificado o acta del ambiente de pruebas |
| Integración con el ERP | 2025-10-29 | 351 | Acta o prueba de integración |
| Piloto en tiendas | 2025-12-07 | 312 | Informe o acta de cierre del piloto |
| Despliegue en la cadena | 2026-01-15 | 273 | Acta de despliegue y medición de producción |

Los cuatro entregables del proveedor Retail Andino Consultores S.A.S. (CT-345) también están vencidos y sin acta de recibo (script: `vendor_deliverable_late`):

| Entregable | Vence | Días | Estado |
|---|---|---|---|
| Licenciamiento de la plataforma | 2025-08-16 | 425 | pendiente |
| Bolsa de horas de desarrollo | 2025-09-28 | 382 | pendiente |
| Configuración del catálogo | 2025-11-10 | 339 | pendiente |
| Soporte del primer trimestre | 2025-12-23 | 296 | pendiente |

### Dinero
Cifras del informe de avance del 2026-10-07; porcentajes del script. Ninguna tiene soporte contable en la carpeta.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 COP | 3.051.411.740 COP (44,9%) | 3.562.697.966 COP (52,4%) | 6.283.634.402 COP (7,6% por debajo de lo aprobado) | 3.748.588.260 COP |

Lo ejecutado es mayor que lo comprometido, lo que no cabe: no se puede ejecutar lo que no se comprometió. Alguna de las dos cifras está mal o mide otra cosa. El aprobado (6.800.000.000 COP) sí coincide entre el acta y el informe.

Facturación: la factura FV-1345 (2026-08-26) por 459.463.652 COP, "Entregables del contrato CT-345", radicada en cuentas por pagar. Ese valor es el de un entregable, y la factura no dice cuál. El contrato condiciona el pago a "acta de recibo firmada por el gerente del proyecto", y no hay ninguna (script: `vendor_invoiced_without_delivery`).

### Lo que se dijo y nadie registró
No hay minutas en la carpeta, así que no hay compromisos que rastrear: lista de compromisos vacía.

En el informe de avance sí hay dos cosas fuera de todo registro:
- **Incidencia no registrada:** "El equipo perdió dos semanas por rotación de un desarrollador clave". No figura como incidencia y no hay cambio de plan que la absorba.
- **Riesgo sin ficha completa:** "Concentración del conocimiento en una sola persona" es el único riesgo, sin probabilidad, impacto, dueño ni fecha. Es el riesgo que la incidencia anterior ya materializó en parte.

Dependencias: el acta dice "Ninguna declarada", pero hay un hito "Integración con el ERP". No hay documento que diga con quién se coordinó esa integración.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 47% | Informe 2026-10-07: 47% | Cronograma v1: 5 de 5 hitos "cerrado" (el plan sostiene 100%; diferencia de 53 puntos) |
| Estado verde | Informe 2026-10-07: verde | Cierre comprometido 2026-02-04 (acta) o 2026-01-15 (cronograma) ya pasado; cuatro señales sin explicar (arriba) |
| Fecha de cierre | Acta: 2026-02-04 | Cronograma v1: 2026-01-15 |
| "Perdió dos semanas" | Informe 2026-10-07 | Cronograma: ningún hito movido, desviación 0 días |
| Factura procedente | Factura FV-1345, 2026-08-26, radicada | Contrato CT-345: se factura contra acta de recibo firmada; los 4 entregables siguen sin acta |
| Ejecutado vs comprometido | Informe: ejecutado 3.562.697.966 | Informe: comprometido 3.051.411.740 |

### Sin sustento
- Los cinco hitos "cerrado": nada los respalda (ni acta, ni certificado, ni informe de piloto).
- El estado de los cuatro entregables del contrato: la única fuente es el contrato mismo, de 2025-06-18, que los dejó "en curso".
- Las tres cifras de dinero del informe (comprometido, ejecutado, proyección): sin extracto, orden de compra ni reporte financiero.
- "Se ajustó el plan de pruebas con el área de seguridad": ningún documento lo recoge.
- El riesgo de concentración de conocimiento: sin dueño ni valoración, y sin mitigación.

Fuente de las cifras del script: 0 campos con fuente de evidencia, 2 de declaración (estado y avance) y 14 sin marcar. Todo lo que hay en la ficha viene de documentos escritos por el propio proyecto o por el contrato.

### Lo que esta carpeta no permite saber
- **Si el proyecto entregó algo.** Sin actas de recibo no se puede decir si el sistema está en producción ni si se midió; es el criterio de éxito del acta y no hay documento que lo toque.
- **Si la factura de 459.463.652 COP procede.** Falta el acta de recibo del entregable que cubre. Mientras no aparezca, no hay base para pagar ni para decir que no.
- **Cuál fecha de cierre rige** (2026-02-04 o 2026-01-15) y si alguien aprobó un cambio. Sin autoridad declarada ni control de cambios, no se sabe quién podía mover fechas.
- **Cuánto se ha gastado de verdad.** Ejecutado y comprometido no pueden ser ciertos a la vez; sin reporte financiero no se sabe cuál es la cifra.
- **Qué hizo el Comité Comercial desde 2025-06-24.** No hay minutas, y por lo tanto no se sabe si conoce el estado del proyecto.
- **Si el proyecto está en silencio o solo quien reporta.** El último documento es de hace 8 días (umbral 15), pero entre el 2026-01-15 y el 2026-08-26 no hay nada en la carpeta, y de 2026-08-26 a 2026-10-07 solo una factura y un informe.

### Cómo seguir
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. La carpeta no permite diagnosticar la salud real del proyecto; ese es el resultado, no una disculpa. Puedo preparar el punto de comité con la lista de lo que falta (actas de los cinco hitos, actas de recibo del contrato, reporte financiero, minutas del comité, aclaración de la fecha de cierre) y llevar las seis contradicciones a Rubén Cárdenas como preguntas, una por una.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada dato sale de los cinco documentos citados; la verificación es de quien lo use. Cifras derivadas copiadas de `portafolio.py compute` (2026-10-15). El conteo de afirmaciones es mío. Lo que no está en la carpeta no se puede afirmar, aunque haya ocurrido.
