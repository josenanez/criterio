Fichas cargadas: las 13 de `estado/records/` (PRY-199 a PRY-211), con corte de lectura 2026-10-15. Cifras de `portafolio.py compute` al 2026-10-15. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo. Comité configurado: 2026-10-29 (quincenal).

# Comité de proyectos — 2026-10-29 (material preparado el 2026-10-15)
7 decisiones · 9 escalamientos sin decisión asociada · 9 proyectos con hallazgos (de 13; 56 alertas en total)

## Decisiones del comité anterior
No puedo cerrar el ciclo. No hay acta de un comité de proyectos anterior en `estado/` ni en `documentos/proyectos/`; las únicas minutas son los comités semanales de cada proyecto, que no registran decisiones de portafolio. Hay actas de comité de **producto** (`documentos/productos/*/30-decisiones/`), que no leí: son de otro foro. Si existió un comité anterior, pasa su acta y se llena esta tabla.

| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin registro | — | — | No consta |

## Decisiones de hoy

### [1] ¿Adopta el comité una regla escrita de autoridad (qué decide cada gerente y hasta qué tope de días y de monto, y qué sube al comité) para los 13 proyectos?
**Proyecto:** todos (13 de 13 sin autoridad declarada) · **Quién decide:** el comité mismo; la autoridad que enmienda las actas de cada proyecto no está escrita, y que sea el patrocinador de cada una es inferencia mía · **Si no se decide hoy:** los puntos 2 a 7 no pueden clasificarse como decisión del gerente o del comité, y cada desvío vuelve a este foro caso por caso.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Regla única con topes, adenda a las 13 actas | Sin cambio | Una sesión para fijar topes; luego decisiones sin escalar | Sin costo directo; los topes los fija el comité |
| B. Sin regla; todo cambio de fecha, bloqueo o gasto sube al comité | Sin cambio | Cada decisión espera a la sesión quincenal | Sin cifra: ningún documento la trae |

**Recomendación:** A, porque con B este mismo paquete es el modelo de lo que llega cada quincena. Los valores de los topes son del comité; no los propongo.

### [2] ¿Se retiene el pago de la factura FV-1345 (459.463.652 COP, Retail Andino, contrato CT-345) hasta que haya acta de recibo firmada?
**Proyecto:** PRY-203 Reposición automática · **Quién decide:** no determinable (autoridad no declarada); el contrato exige acta firmada por el gerente del proyecto para facturar · **Si no se decide hoy:** la factura sigue radicada en cuentas por pagar sin que ningún documento diga si está pagada.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener y exigir acta de recibo o entregable | Sin cambio | Hasta que el proveedor entregue | Ninguno directo |
| B. Pagar contra la declaración del gerente | Sin cambio | Inmediato | 459.463.652 COP sin entregable recibido (0 de 4 aceptados) |
| C. Si ya se pagó: abrir reclamación | Sin cambio | Sin dato | Sin dato |

**Recomendación:** A (o C si ya se pagó). Primero hay que saber en cuál de los dos casos estamos; los documentos no lo dicen. Los 4 entregables están vencidos entre 296 y 425 días.

### [3] ¿Se reconoce que la fecha de PRY-203 no se sostiene y se pide un rebaseline fundamentado (fecha, costo, autoridad), en lugar de aprobar «+30 días»?
**Proyecto:** PRY-203 · **Quién decide:** no determinable; el acta solo nombra al Comité Comercial como aprobador del presupuesto · **Si no se decide hoy:** sigue declarado en verde con 47% de avance, una fecha de despliegue (2026-01-15) vencida hace 273 días y sin ninguna línea base nueva.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar +30 días | Sin dato | Da una fecha ya vencida | Sin estimación |
| B. Pedir rebaseline con fecha sustentada, costo y motivo | Sin dato hasta recibirlo | Vuelve al comité con el plan | Sin dato; se calcula con el plan nuevo |

**Recomendación:** B. A no describe ninguna salida posible. Además, el solicitante del cambio no consta en ningún documento, y el acta (cierre 2026-02-04) y el cronograma (2026-01-15) no coinciden.

### [4] ¿Se aprueba la solicitud de cambio CC-01 de PRY-201 (ampliación de alcance, +59 días, +118.000.000 COP)?
**Proyecto:** PRY-201 Programa de fidelización (gerente María Restrepo, declarado rojo, 78%) · **Quién decide:** Comité de Transformación Digital, que aprobó el presupuesto de 6.800.000.000 COP; la solicitud dice «pendiente de presentación al comité» · **Si no se decide hoy:** la solicitud lleva desde el 2026-10-04 sin respuesta y el informe del 2026-10-10 ya dice que el despliegue se reprogramó, sin cambio registrado (cambios aprobados: 0 días; replanificaciones: 0).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliado (contenido no detallado en la solicitud) | +59 días sobre una fecha vigente (2026-06-11) que ya pasó | +118.000.000 COP |
| B. Rechazar | Sin cambio | Sin cambio; fecha vigente ya vencida | Ninguno |
| C. Devolver para que traiga el plan con fecha real | Sin dato | Sin dato | Sin dato |

**Recomendación:** C. La solicitud no dice qué se amplía ni por qué, y los +59 días se miden sobre una fecha que ya pasó. Al aprobarse con fecha y alcance, se registra una línea base nueva sin borrar la original.

### [5] ¿Nombra el comité a una sola persona responsable del hallazgo de seguridad en los medios de pago, que hoy aparece en cuatro informes sin doliente?
**Proyecto:** PRY-200, 201, 204 y 211 (informes del 2026-10-12, 10-10, 09-26 y 10-04). Tres de los cuatro reportan verde. · **Quién decide:** el comité (cruza proyectos y ningún gerente puede resolverlo solo) · **Si no se decide hoy:** nadie responde por un hallazgo que, si es el mismo, afecta a cuatro proyectos; el más antiguo lleva casi tres semanas en el informe.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un responsable único y primero confirmar si es un hallazgo o cuatro | Sin cambio | Una verificación antes del cierre del mes | Sin dato |
| B. Cada gerente responde por el suyo | Sin cambio | Sin coordinación entre los cuatro | Sin dato |

**Recomendación:** A. Los documentos no dicen si es un hallazgo o cuatro, y esa respuesta determina la solución.

### [6] ¿Qué se hace con los proyectos cuya proyección de costo supera el umbral de 10%: PRY-205 (15,7%), PRY-208 (14,5%), PRY-211 (13,7%) y PRY-204 (11,8%)?
**Proyecto:** los cuatro. PRY-205 y PRY-204 y PRY-211 se declaran en verde; PRY-208 en amarillo. · **Quién decide:** no determinable (autoridad no declarada en ninguno) · **Si no se decide hoy:** los cuatro siguen proyectando sobre el presupuesto aprobado sin que nadie haya aprobado ese exceso.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pedir a cada gerente un plan de recorte o una solicitud de cambio formal antes del próximo comité | Puede recortarse | Una quincena | Sin dato hasta recibir los planes |
| B. Aceptar la proyección como nuevo presupuesto | Sin cambio | Sin cambio | Proyección: PRY-205 20.834.384.205 contra 18.000.000.000; PRY-208 3.776.990.948 contra 3.300.000.000; PRY-211 1.364.395.523 contra 1.200.000.000; PRY-204 1.342.154.042 contra 1.200.000.000 |

**Recomendación:** A. Con B se aprueba un exceso que ningún gerente ha sustentado. Además PRY-204 y PRY-205 tienen avance contra plan y compromisos vencidos abiertos.

### [7] ¿Cuál es la fecha vigente de cierre de PRY-209 Migración del ERP: 2027-02-03 (cronograma) o 2027-03-06 (acta de constitución)?
**Proyecto:** PRY-209 (gerente Camilo Beltrán, patrocinador Gustavo Neira, declarado amarillo, 75%) · **Quién decide:** el patrocinador, por inferencia mía; el acta no lo dice · **Si no se decide hoy:** los dos documentos son del mismo día (2026-05-28) y ninguno es más reciente; el hito «Ambiente de pruebas certificado» (2026-10-05) lleva 10 días vencido y no hay forma de saber contra qué fecha medir.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Vale el cronograma (2027-02-03) | Sin cambio | Más corto | Sin dato |
| B. Vale el acta (2027-03-06) | Sin cambio | Más largo | Sin dato |

**Recomendación:** no recomiendo una; la elección depende de qué se prometió al negocio, que no consta. Pido al patrocinador que lo confirme antes de la sesión.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| Portafolio (199, 200, 202, 203, 204, 205, 207, 208, 211) | «Integración con el ERP» es hito en 9 proyectos y existe PRY-209; las 13 actas dicen «Ninguna declarada» en dependencias | Sin fecha | Que PRY-209 confirme si hay dependencia y de quién |
| PRY-204 y PRY-209 | La prueba de carga de temporada no alcanzó el umbral y se repite; sin doliente | 2026-09-26 (204) / 2026-10-15 (209) | Un doliente |
| PRY-209 | Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo | 2026-10-15 | Registrarlo y revisarlo con el proveedor (2026-10-25, Óscar Ramírez) |
| PRY-209 | Compromisos reprogramados: «Enviar el documento 1» (Felipe Arango) 6 veces, «Cerrar la prueba 2» (Diana Molina) 5 veces | Original 2026-09-16 y 2026-09-10 | Desbloquear o reasignar |
| PRY-205 | Entregable del proveedor Tecnología para Tiendas Ltda. (CT-592) vencido 66 días: licenciamiento de la plataforma | 2026-08-10 | Acta o nueva fecha |
| PRY-211 y PRY-202 | Compromisos vencidos de 20 días (Felipe Arango, punto 39) y de 17 días (María Restrepo, punto 22) | 2026-09-25 / 2026-09-28 | Cumplir o reprogramar con fecha |
| PRY-200, 202, 203, 204, 207, 208 | Hitos «cumplidos» sin acta ni evidencia (3, 4, 5, 1, 3 y 2 respectivamente) | Entre 19 y 429 días | Acta de recibo o corregir el estado |
| PRY-200, 203, 204, 205, 211 | Estado declarado verde contradicho por la evidencia (5 proyectos) | Corte de cada informe | Que el gerente corrija el estado declarado |
| PRY-209 | Hito «Ambiente de pruebas certificado» vencido 10 días, sin replanificación | 2026-10-05 | Nueva fecha por control de cambios |

## Para conocimiento
- PRY-199 Iluminación LED en bodegas: verde, 20%, sin alertas.
- PRY-200 Tienda en línea: verde declarado, 76% contra 100% del plan, fecha de cierre 2026-03-04 ya pasada.
- PRY-201 Programa de fidelización: rojo, 78%, CC-01 pendiente (punto 4).
- PRY-202 Centro de distribución norte: rojo, 54% contra 100% del plan, cierre 2026-07-05 ya pasado.
- PRY-203 Reposición automática: verde declarado, 47% contra 100% del plan (puntos 2 y 3).
- PRY-204 Cajas de autopago: verde declarado, 32%, costo +11,8%.
- PRY-205 Pago con QR en caja: verde declarado, 40%, costo +15,7%; mayor presupuesto del portafolio junto con PRY-206 y PRY-207 (18.000.000.000 COP cada uno).
- PRY-206 Precios dinámicos: rojo, 59%, 12 días sin informe (umbral 15). Sin alertas calculadas.
- PRY-207 Marca propia de alimentos: amarillo, 59% contra 75–100% del plan; un compromiso sin fecha (Diana Molina, punto 37).
- PRY-208 Domicilios en dos horas: amarillo, 54%, costo +14,5%.
- PRY-209 Migración del ERP: amarillo, 75% contra 25–50% del plan (adelantado, lo que no cuadra con un hito vencido).
- PRY-210 Etiquetas electrónicas de precio: rojo, 55%, 7 días sin informe. Sin alertas calculadas.
- PRY-211 Pronóstico de demanda: verde declarado, 72% contra 40–60% del plan, costo +13,7%.

## Anexo
**Estado por proyecto.** Detalle en las fichas `estado/records/PRY-199.json` a `PRY-211.json` y en `estado/snapshots/2026-10-15.json`. Resumen del cálculo: 13 proyectos, 9 con alertas, 56 alertas, 5 en verde contradichos, 0 sin línea base, 7 productos, 13 sin autoridad declarada.

**Contradicciones abiertas.**
- PRY-209: fecha de cierre, 2027-02-03 (cronograma `10-plan/2026-05-28-cronograma-v1.xlsx`) contra 2027-03-06 (acta `00-gobierno/2026-05-28-acta-constitucion.docx`).
- PRY-203: cierre 2026-02-04 (acta) contra despliegue 2026-01-15 (cronograma); plan 100% contra gerente 47%; ejecutado 3.562.697.966 mayor que comprometido 3.051.411.740 COP.
- PRY-201: el informe dice «se reprogramó el despliegue» y la ficha no tiene ninguna replanificación.
- PRY-209: avance declarado 75% contra 1 de 4 hitos cumplidos.

**Vacíos de información.**
- Autoridad: sin declarar en los 13 proyectos. Fase: sin dato en los 13.
- Producto: sin dato en PRY-202, 203, 206, 209, 210 y 211.
- Datos de identidad y plan con más de 12 meses de antigüedad en PRY-200, 201, 202, 203 y 204.
- RAID: 26 ítems registrados, ninguno con doliente ni fecha.
- Ninguna cifra de costo o de días de opciones fue inventada; donde dice «sin dato», ningún documento la trae.
- No leí los PDF sin texto extraído (acta de recibo de PRY-199 y actas de recibo en PDF de PRY-211).
- Sin comité anterior registrado: el ciclo no se pudo cerrar.
- Sin proyecto en silencio: el máximo es PRY-206 con 12 días (umbral 15).

## Después
Cuando el comité sesione, ofrezco registrar sus decisiones en las fichas; ahí se cierra el ciclo y el material del siguiente empieza a construirse solo.

---
**Pie de rigor.** Versión de la familia 0.3.10 · fichas aplicadas: las 13 de `estado/records/` · campos inciertos: autoridad, fase y producto (ver vacíos), solicitante del cambio de PRY-203, pago de FV-1345, fecha vigente de PRY-209, quién aprueba cada decisión · Borrador de trabajo, no decisión ni asesoría; la verificación contra los documentos citados es suya · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
