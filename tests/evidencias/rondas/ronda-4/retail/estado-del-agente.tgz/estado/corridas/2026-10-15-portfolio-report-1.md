# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 66 documentos, 0 releídos y 66 sin cambio · 46 s · 56 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

El informe quedó en `/home/claude/banco/ronda-4/retail/espacio/reportes`.

Primera corrida del informe: sin delta. Mirar los 5 verdes contradichos (PRY-200, 203, 204, 205, 211) y la fecha de fin en conflicto de PRY-209.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 9 con hallazgos · último barrido 2026-10-15 (13 fichas, todas de hoy; ninguna con más de una semana)

Términos vigentes (versión 0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15). Formato: html.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (2026-10-15): este es el punto de partida, no hay delta.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-209 Migración del ERP | plan.end_date | 2027-02-03 | 10-plan/2026-05-28-cronograma-v1.xlsx | 2027-03-06 | 00-gobierno/2026-05-28-acta-constitucion.docx |

Misma fecha en ambas fuentes (2026-05-28): no hay forma de saber cuál es la vigente.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-209 | Ambiente de pruebas certificado | 2026-10-05 | 10 |

Además, 6 proyectos declaran hitos cumplidos sin evidencia que lo respalde: PRY-200 (3), PRY-202 (4), PRY-203 (5), PRY-204 (1), PRY-207 (3), PRY-208 (2).

## Proyectos en silencio
Vacía: ninguno supera el umbral de 15 días (el más callado es PRY-206, 12 días).

## Dependencias en riesgo
Sin dependencias en riesgo detectadas por el cálculo. Sin cambios de fecha por replanificación (0 replanificaciones en el portafolio).

## Sin sustento
Cinco proyectos declaran verde y las señales lo contradicen:
| Proyecto | Declara | Qué lo contradice |
|---|---|---|
| PRY-200 Tienda en línea | verde (2026-10-12) | declara 76% con el plan apoyando 100%; 3 hitos cumplidos sin evidencia |
| PRY-203 Reposición automática | verde (2026-10-07) | 47% declarado; 5 hitos sin evidencia; 4 entregables del proveedor atrasados y 459.463.652 facturados sin entrega |
| PRY-204 Cajas de autopago | verde (2026-09-26) | sobrecosto proyectado 11,8%; avance 18 puntos por debajo; compromiso vencido 9 días |
| PRY-205 Pago con QR | verde (2026-10-14) | sobrecosto proyectado 15,7%; entregable del proveedor atrasado 66 días; compromiso vencido |
| PRY-211 Pronóstico de demanda | verde (2026-10-04) | sobrecosto proyectado 13,7%; compromiso vencido 20 días |

Compromisos vencidos: PRY-202 (2), PRY-204, PRY-205, PRY-209 (4), PRY-211. Reprogramados varias veces en PRY-209: Felipe Arango (6 veces), Diana Molina (5).
Sin fecha: PRY-207 (Diana Molina), PRY-209 (Laura Vélez).

## Vacíos de información
- Ninguno de los 13 proyectos tiene autoridad (patrocinador/decisor) identificada.
- 6 proyectos no están asociados a un producto: PRY-202, 203, 206, 209, 210, 211.

## Estado general
| Proyecto | Desviación vs original | vs vigente | Replanificaciones | Señales |
|---|---|---|---|---|
| PRY-199 | 0 d | 0 d | 0 | sin alertas |
| PRY-200 | 0 d | 0 d | 0 | avance, hitos sin evidencia |
| PRY-201 | 0 d | 0 d | 0 | sin alertas |
| PRY-202 | 0 d | 0 d | 0 | avance (−46 pts), 4 hitos sin evidencia, 2 compromisos vencidos |
| PRY-203 | 0 d | 0 d | 0 | avance (−53 pts), 5 hitos sin evidencia, proveedor |
| PRY-204 | 0 d | 0 d | 0 | costo +11,8%, avance |
| PRY-205 | 0 d | 0 d | 0 | costo +15,7%, proveedor |
| PRY-206 | 0 d | 0 d | 0 | sin alertas (12 días sin documentos) |
| PRY-207 | 0 d | 0 d | 0 | avance (−16 pts), 3 hitos sin evidencia |
| PRY-208 | 0 d | 0 d | 0 | costo +14,5%, avance |
| PRY-209 | 0 d | 0 d | 0 | avance declarado por encima del plan (+25 pts), hito vencido, 4 compromisos vencidos, contradicción de fecha |
| PRY-210 | 0 d | 0 d | 0 | sin alertas |
| PRY-211 | 0 d | 0 d | 0 | costo +13,7%, avance declarado por encima del plan (+12 pts) |

Totales del cálculo: 56 alertas en 9 proyectos; 5 verdes contradichos; 7 productos.

## Necesito que confirmes
No toca confirmación este mes: no hay corridas previas de confirmación registradas y la sesión no tiene interfaz. Queda para la próxima corrida.

## Informe HTML
Archivos en `reportes/` (24 páginas):
- `reportes/index.html`: vista por campo, con la cadena de evidencia. Para quien va a actuar (gerente de PMO y gerentes de proyecto).
- `reportes/decisiones.html`: vista por decisión, solo lo que excede la facultad del gerente. Para el patrocinador y el comité (próximo: 2026-10-29).
- Una página por proyecto (`PRY-199.html` … `PRY-211.html`) y por producto, más `proyectos.html` y `productos.html`.
Para PDF, imprimir el HTML desde el navegador.

Pie: criterio-portfolio 0.3.10 · fichas aplicadas del 2026-10-15 · campos inciertos: plan.end_date de PRY-209 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
