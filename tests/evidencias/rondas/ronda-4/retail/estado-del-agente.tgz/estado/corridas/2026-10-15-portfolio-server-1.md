# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 56 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 18 |
| `commitment_overdue` | 9 |
| `progress_vs_plan` | 8 |
| `declared_vs_evidence` | 5 |
| `vendor_deliverable_late` | 5 |
| `variance_cost` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `vendor_invoiced_without_delivery` | 1 |
| `milestone_overdue` | 1 |
| `pm_vs_pmo` | 1 |

puerto 8787, informe en reportes, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

**Términos:** ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). No se registró una aceptación nueva.

**Forma elegida:** «Para mirarlo un rato» (argumento `rato`). Se levanta, se mira y se apaga. Nadie tiene un enlace que funcione mañana. Si después se quiere dejar corriendo, la conversación con seguridad es otra: un host y un puerto dentro de la red, publicado detrás del control de acceso que la organización ya usa.

**Informe:** `reportes/` (13 proyectos PRY-199 a PRY-211, 7 productos, decisiones, listado de proyectos y de productos). Estado: `estado/`.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes que la evidencia no sostiene, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a sus proyectos | Quien responde por un producto |
| `/estado.json` | De cuándo es el informe y cuántas peticiones hay abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica y no manda correos. Las peticiones del formulario esperan hasta que el agente despierte; `due` las cuenta y rompen el silencio de `/portfolio-wake`.

**Cierre:** el enlace `http://127.0.0.1:8787/` solo sirve en este equipo, para quien esté sentado aquí. No se le pasa a ningún patrocinador. El informe es el de la última corrida; la portada dice de cuándo es, y hay que mirarlo antes de reenviar nada. Para que un patrocinador tenga enlace, hay que pasar a «que quede corriendo».
