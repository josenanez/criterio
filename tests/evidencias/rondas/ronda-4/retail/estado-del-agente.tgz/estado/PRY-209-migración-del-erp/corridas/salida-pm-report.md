# Migración del ERP (PRY-209) — semana al 2026-10-15

**Declara el gerente:** SIN DECLARAR esta semana. La sesión no tuvo a nadie que respondiera, y este informe no propone un estado. Línea en blanco a propósito.
*(Contexto, no es la declaración de hoy: la ficha trae del informe de avance `20-seguimiento/2026-10-15-informe-avance.pdf` amarillo · 75 % · al 2026-10-15. Es un documento, no la respuesta del gerente a esta pregunta.)*
**Sustento documental:** sin sustento para el 75 % (ver «Contra el plan»). Evidencia independiente de los documentos: 0 fuentes; 8 son declaraciones y 136 no están marcadas.
**Lo que el semáforo no explica** (señales que el amarillo del informe no cubre): compromisos vencidos, compromisos reprogramados, hito vencido y avance contra el plan.

## Qué cambió esta semana
Esta es la primera captura del proyecto (`snapshots/2026-10-15.json`) y no hay corrida anterior contra la cual comparar. El diff sale vacío por eso, no porque no haya cambiado nada. La comparación empieza la próxima semana.

## Lo que sigue igual y sigue mal
Sin captura anterior no se puede decir desde cuándo. Fechas que sí constan en la ficha:
| Qué | Desde | Días así |
|---|---|---|
| Hito «Ambiente de pruebas certificado» vencido, sin evidencia | 2026-10-05 | 10 |
| Compromiso Diana Molina, «Entregar el punto 8» | 2026-09-28 | 17 |
| Compromiso Óscar Ramírez, «Actualizar la matriz 6» | 2026-10-06 | 9 |
| Compromiso Liliana Torres, «Aprobar el diseño 21» | 2026-10-12 | 3 |
| Compromiso Laura Vélez, «Confirmar la fecha 15» | 2026-10-14 | 1 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-03-06 | 2027-03-06 | 0 días |
| Presupuesto | COP 6.800.000.000 | COP 6.800.000.000 | proyección COP 6.735.523.046 (−0,9 %) |

Replanificaciones: 0. La desviación de cierre en cero es lo que dice la fecha de cierre. Un hito ya lleva 10 días vencido y esa fecha no se ha movido.

**Avance:** el informe declara 75 %. El plan sostiene entre 25 % y 50 %: 1 de 4 hitos cumplidos, con 25 puntos de diferencia a favor de lo declarado. Dato del cálculo, no juicio mío.

### Hitos
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Diseño de la experiencia aprobado | 2026-08-06 | 2026-08-06 | cumplido; acta de recibo del 2026-10-06 |
| Ambiente de pruebas certificado | 2026-10-05 | 2026-10-05 | VENCIDO 10 días, sin evidencia |
| Integración con el ERP | 2026-12-05 | 2026-12-05 | pendiente, sin evidencia |
| Piloto en tiendas | 2027-02-03 | 2027-02-03 | pendiente, sin evidencia |

Próximas cuatro semanas (hasta el 2026-11-12): ningún hito vigente cae en la ventana. El de pruebas ya está vencido.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 4.491.302.023 (66,0 %) | 1.935.274.876 (28,5 %) | 6.735.523.046 | 2.308.697.977 |

El disponible real es aprobado menos comprometido, no menos ejecutado. Las tres cifras no-aprobadas salen del informe de avance, o sea que son declaradas y no están contrastadas con un documento contable.

## Abierto
**Reprogramados:**
- Felipe Arango, «Enviar el documento 1»: 6 veces. Original 2026-09-16 → 09-27 → 10-06 → 10-20 → 10-28 → 11-15 → 11-29.
- Diana Molina, «Cerrar la prueba 2»: 5 veces. Original 2026-09-10 → 09-19 → 10-02 → 10-16 → 10-27 → 11-15.

Ambos pasan el umbral de 3 reprogramaciones.

**Vencidos sin evidencia:** Diana Molina, punto 8 (17 días); Óscar Ramírez, matriz 6 (9 días); Liliana Torres, diseño 21 (3 días); Laura Vélez, fecha 15 (1 día).
**Sin fecha:** Laura Vélez, «Mandar el ajuste del presupuesto» (notas de la reunión del 2026-10-15).
**RAID sin dueño:** 3 riesgos y 1 incidencia, ninguno con responsable.
- Disponibilidad de los jefes de tienda para el piloto.
- Concentración del conocimiento en una sola persona.
- El proveedor podría no llegar con el equipo completo para la siguiente fase. Se dijo en la reunión del 2026-10-15 y no está registrado.
- Incidencia: la prueba de carga de temporada no alcanzó el umbral y se repite.

**Proveedor:** la ficha no registra ninguno, aunque los riesgos mencionan a uno.

## Lo que necesito de alguien
- **Camilo Beltrán:** declarar el estado y el avance de esta semana. Es la línea que falta.
- **Camilo Beltrán:** asignar dueño a los 3 riesgos y la incidencia.
- **Felipe Arango y Diana Molina:** una fecha que se vaya a cumplir, o decir que no se va a cumplir. Si Felipe Arango vuelve a mover su fecha, serían 7 reprogramaciones.
- **Laura Vélez:** fecha para el ajuste del presupuesto.

Ninguno de estos puntos excede la autoridad del gerente según lo que muestra la ficha. Si las reprogramaciones siguen, hay material para un punto de comité (próximo, 2026-10-29).

## Lo que no se sabe
**Sin dato:** producto, autoridad y fase del proyecto; evidencia de los hitos 2, 3 y 4; dueño de 3 riesgos y 1 incidencia. Son 10 campos en total.
**Silencio:** último documento hace 0 días (2026-10-15) · última reunión hace 0 días (2026-10-15).

---
*Fuente: ficha `records/PRY-209.json`, corte 2026-10-15. 10 campos sin dato. Términos aceptados (v1.1, José Francisco Ñáñez, 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10*
