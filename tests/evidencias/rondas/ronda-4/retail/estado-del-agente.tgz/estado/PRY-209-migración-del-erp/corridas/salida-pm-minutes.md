# Acta — Migración del ERP (PRY-209) · 2026-10-15
**Asistieron (14):** Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` (notas, líneas 1–8) · **Ausentes con tema en agenda:** no se puede saber; las notas no traen agenda.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Felipe Arango | Enviar el documento 1 (compromiso #1) | 2026-11-29 | **Reprogramado por 6.ª vez.** Promesa original 2026-09-16; fechas intermedias 09-27, 10-06, 10-20, 10-28, 11-15. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 29/11/2026» (línea 4). La fecha anterior (11-15) todavía no había llegado. El 29-nov-2026 es domingo. |
| Óscar Ramírez | Revisión con el proveedor (#26) | 2026-10-25 | Cita: «revisión con el proveedor, queda para el 2026-10-25» (línea 6). El 25-oct es domingo. Ver *Sin resolver*: puede ser una fecha de reunión y no un entregable. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto (#25). Cita: «queda de mandar el ajuste del presupuesto la otra semana» (línea 5). «La otra semana» no es una fecha y no se convirtió en una; queda `due_date: no_declarada`. No puede vencer y por eso se cuenta aparte. |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
Nada se presenta como pendiente de decisión en las notas.

## Intenciones sin doliente
Ninguna.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (línea 7) | No atribuido: las notas dicen «se comentó» | Riesgo (de proveedor / recursos) | **No.** No estaba en el informe de avance del 2026-10-15 ni en ningún documento anterior. Quedó en la ficha como riesgo con `registered: false`, sin dueño. No se le puso doliente. |

## Cerrado en esta reunión
Nada. Ninguna frase de las notas trae un documento que cierre algo.

## Lo que esta reunión contradice
Nada. No cambió patrocinador, fecha de cierre ni comité.

## Sin resolver de la transcripción
- **Fecha de Laura Vélez:** «la otra semana» sin día, y las notas no dicen de qué fecha se cuenta.
- **Qué es la «revisión con el proveedor» de Óscar Ramírez:** «queda para el 2026-10-25» no aclara si él entrega algo o si esa es la fecha de una reunión. Se registró como compromiso suyo; confírmalo con él.
- **Quién habló del riesgo del proveedor:** las notas no lo atribuyen. Hay que preguntarle a quien tomó las notas.
- **Cadencia:** «próxima reunión en dos semanas» (línea 8; calza con el 2026-10-29 de la configuración), pero el comité venía semanal (09-03 a 10-08, un acta por semana). No queda claro si la cadencia cambió o fue un comentario aislado.

## Cifras recalculadas (`portafolio.py compute`, no contadas a mano)
- 26 compromisos en la ficha. Esta reunión tocó 3: uno reprogramado (#1), uno sin fecha (#25) y uno con fecha (#26).
- Reprogramados: Felipe Arango, 6 veces; Diana Molina («Cerrar la prueba 2»), 5 veces. No hablaron en esta reunión, pero conviene verlos junto al de Felipe.
- Vencidos sin evidencia: 4 (Óscar Ramírez #6, Diana Molina #8, Laura Vélez #15, Liliana Torres #21). Ninguno se cerró hoy.
- Un riesgo dicho al pasar sin registrar, y sin dueño.

## Después
`/pm-commitments` para el seguimiento completo. `/pm-publish` no hace falta por contradicciones, porque no hubo. Si quieres que el riesgo del proveedor quede en el RAID oficial, necesita un dueño.
