## PRY-209 Migración del ERP · 2026-10-15

**Revisé:** 16 documentos · 1 nuevo (`00-gobierno/ficha-pm.json`, la ficha publicada; no es una minuta) · 0 cambiaron · 0 minutas nuevas. No hubo extracción de compromisos. Los términos de esta versión (0.3.10) están vigentes, aceptados el 2026-10-15 por José Francisco Ñáñez.

### Lo que está vencido hoy
Es el primer barrido registrado (`last: null`), así que esto es el estado a hoy y no lo que cruzó desde una corrida anterior. Todo sale de `estado/records/PRY-209.json`.

- **#6 Óscar Ramírez, «Actualizar la matriz 6»**: vencía el 2026-10-06, reprogramada 2 veces, sin evidencia (`30-reuniones/2026-10-08-comite-semanal.md`).
- **#21 Liliana Torres, «Aprobar el diseño 21»**: vencía el 2026-10-12, sin evidencia (`30-reuniones/2026-10-08-comite-semanal.md`).
- **#8 Diana Molina, «Entregar el punto 8»**: vencía el 2026-09-28. Dijo el 09-17 que ya la había entregado, pero no hay acta de recibo (`30-reuniones/2026-09-17-comite-semanal.md`).
- **#15 Laura Vélez, «Confirmar la fecha 15»**: vencía el 2026-10-14. Dijo el 10-08 que ya la había entregado, pero no hay acta de recibo (`30-reuniones/2026-10-08-comite-semanal.md`).
- **#13 Gustavo Neira, «Aprobar el diseño 13»**: vence el 2026-10-19. Dijo el 10-01 que ya la había entregado, pero no hay acta de recibo (`30-reuniones/2026-10-01-comite-semanal.md`).
- **Hito «Ambiente de pruebas certificado»**: fecha base 2026-10-05, sigue pendiente y sin evidencia (`10-plan/2026-05-28-cronograma-v1.xlsx`).

**Reprogramados que se repiten:**
- **#1 Felipe Arango**, «Enviar el documento 1»: 6 reprogramaciones. Fecha original 2026-09-16, hoy 2026-11-29 (`2026-10-15-notas-reunion.txt`).
- **#2 Diana Molina**, «Cerrar la prueba 2»: 5 reprogramaciones. Fecha original 2026-09-10, hoy 2026-11-15 (`30-reuniones/2026-10-08-comite-semanal.md`).

### La reunión
El comité semanal es el 2026-10-29, en 14 días. Todavía no toca ofrecer la agenda. El informe toca el 2026-10-28. La reunión del 10-15 ya tiene notas y acta procesada, así que no falta ninguna acta.

### Tu ficha publicada
Al día. La ficha se publicó hoy y el registro se actualizó hoy.

**Vuelvo el 2026-10-16.**
