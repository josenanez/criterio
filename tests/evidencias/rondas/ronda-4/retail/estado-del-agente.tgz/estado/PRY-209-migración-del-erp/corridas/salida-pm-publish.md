Publiqué la ficha en `/home/claude/banco/ronda-4/retail/espacio/documentos/proyectos/PRY-209-migración-del-erp/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 38 campos con dato · 10 sin decir en ninguna parte · declara **amarillo** al 2026-10-15

**Lo más viejo que va ahí:** identidad, plan y presupuesto aprobado, del 2026-05-28 (acta de constitución y cronograma v1) — no pasa de un año.

**Lo que la PMO va a mirar primero:** el estado declarado es amarillo con 75 % de avance, y el plan solo sustenta entre 25 % y 50 % (1 de 4 hitos cumplidos). El hito «Ambiente de pruebas certificado» está vencido desde el 2026-10-05 (10 días). La ficha lo marca como declarado por el gerente, no como verificado.

**Sin decir en ninguna parte:** producto, autoridad, fase, evidencia de 3 hitos y dueño de 3 riesgos y 1 incidencia.

**Notas de la corrida:**
- Los términos ya estaban vigentes (versión 1.1, aceptados el 2026-10-15 por José Francisco Ñáñez); no hubo que registrarlos de nuevo.
- La carpeta de gobierno ya existía; no se creó nada.
- No se tocó ningún otro archivo de la documentación.
- Nadie fue avisado: Vera la encontrará en su próximo barrido.
