## Reunión de seguimiento — Migración del ERP (PRY-209) · 2026-10-29
8 puntos · 45 minutos · 6 personas requeridas (Camilo Beltrán, Felipe Arango, Diana Molina, Óscar Ramírez, Liliana Torres, Laura Vélez)

Supuestos que digo en voz alta: la fecha es la del próximo comité en la configuración (2026-10-29; las notas del 10-15 dicen «próxima reunión en dos semanas», que calza) y la duración es 45 minutos porque no pasaste un tope. Si es otra, el corte por el final de la lista cambia. No hay una foto anterior para comparar («diff» devolvió punto de partida), así que «lo que cambió» es todo lo registrado el 2026-10-15 por `/pm-setup`, `/pm-minutes` y `/pm-commitments`. Las fechas de abajo están contadas al 2026-10-15; hasta el 10-29 habrá más vencidos y hay que recalcular ese día.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y salir con una fecha que no sea domingo ni una más movida** · 10 min · **Felipe Arango** (y Camilo Beltrán, para quitar el bloqueo)
> Prometido para el 2026-11-29, y antes para el 11-15, el 10-28, el 10-20, el 10-06, el 09-27 y, al principio, el 09-16. Seis reprogramaciones en cinco semanas; la última se dijo con la fecha anterior (11-15) todavía sin llegar. El 29-nov es domingo.
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md` (promesa original) y `2026-10-15-notas-reunion.txt`, línea 4 (fecha vigente).
> **Si no se resuelve hoy:** la fecha vigente queda lejos y el compromiso no aparecerá como vencido hasta diciembre, aunque lleva semanas sin cumplirse. Nadie sabe hoy qué entrega depende de ese documento: las notas no lo dicen.

> **[2] Diana Molina: qué impide cerrar la prueba 2, y si el punto 8 está o no entregado** · 12 min · **Diana Molina**
> «Cerrar la prueba 2»: prometido para el 2026-11-15, y antes para el 10-27, el 10-16, el 10-02, el 09-19 y, al principio, el 09-10. Cinco reprogramaciones. «Entregar el punto 8»: prometido para el 2026-09-28, vencido hace 17 días; el 2026-09-17 se dijo que estaba entregado y no hay acta ni documento que lo respalde.
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md`, `2026-10-08-comite-semanal.md` y `2026-09-10-comite-semanal.md`.
> **Si no se resuelve hoy:** son dos compromisos de la misma persona, uno sin evidencia y otro que se corre sin explicación. Con tres reprogramaciones ya es un bloqueo que nadie ha nombrado; aquí son cinco.

> **[3] Decidir qué se hace con el hito «Ambiente de pruebas certificado», vencido el 2026-10-05, y si se pide cambio de fecha** · 5 min · **Camilo Beltrán**
> Línea base y fecha vigente: 2026-10-05, sin replanificación registrada y sin acta de cumplimiento. Lleva 10 días vencido. Las notas no relacionan este hito con la prueba 2 ni con las validaciones de ambiente de Ricardo Salas y María Restrepo; no lo afirmo, solo hay que preguntarlo.
> Fuente: `10-plan/2026-05-28-cronograma-v1.xlsx`.
> **Si no se resuelve hoy:** el informe seguirá declarando 75% con 1 de 4 hitos cerrados, y el plan que sustenta el informe ya no es el vigente.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Óscar Ramírez | Actualizar la matriz 6 (ya movida dos veces) | 2026-10-06 (9 días) | Fecha de entrega con acta, o decir que no se hará | 3 |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-12 (3 días) | Aprobar en la sala, o decir qué falta para aprobar | 3 |
| Laura Vélez | Confirmar la fecha 15 (se dijo el 10-08 que estaba confirmada; no hay acta) | 2026-10-14 (1 día) | El documento que la confirma, o dejarla abierta | 3 |

Fuentes: `30-reuniones/2026-09-10-comite-semanal.md` (6), `2026-10-08-comite-semanal.md` (21), `2026-09-24-comite-semanal.md` (15). Diana Molina (punto 8) está en el punto [2].

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Quién es el dueño del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase» (dicho al pasar el 10-15, nadie lo anotó, no atribuido) y si entra al RAID oficial | Camilo Beltrán, con Óscar Ramírez (que tiene la revisión con el proveedor) | Sigue como riesgo sin dueño y sin registrar; la revisión del 10-25 pasa sin que nadie la lleve | 5 |
| Fecha para «Mandar el ajuste del presupuesto» (Laura Vélez dijo «la otra semana», sin día) y qué es la «revisión con el proveedor» del 10-25 (¿entregable o reunión? es domingo) | Laura Vélez y Óscar Ramírez | Un compromiso sin fecha no puede vencer, y uno ambiguo tampoco puede cumplirse | 4 |

Fuente: `2026-10-15-notas-reunion.txt`, líneas 5 a 7.

### Vence antes de la próxima
Los puntos de aquí no se discuten: se avisa a cada doliente por su lado. Ya vencerán el 10-29 o antes.

| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Enviar el documento 17 | 2026-10-16 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-18 |
| Gustavo Neira | Aprobar el diseño 13 (dijo el 10-01 que estaba aprobado; no hay acta) | 2026-10-19 |
| María Restrepo | Validar el ambiente 20 | 2026-10-19 |
| Ricardo Salas | Validar el ambiente 12 (movido dos veces) | 2026-10-20 |
| Mauricio Pérez | Confirmar la fecha 23 | 2026-10-24 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor (ver punto de decisión) | 2026-10-25 |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-27 |
| Rubén Cárdenas | Confirmar la fecha 7 (movida dos veces) | 2026-10-27 |
| Elena Duarte | Revisar el anexo 19 | 2026-10-27 |
| Mauricio Pérez | Enviar el documento 9 (movido dos veces) | 2026-10-28 |

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| El informe declara 75% de avance con 1 de 4 hitos cerrados (el plan sustenta entre 25% y 50%) | Es una declaración del gerente, no un tema de la sala; la corrige Camilo antes del próximo informe | `/pm-report` |
| Si Felipe Arango o Diana Molina siguen sin fecha creíble después de los puntos [1] y [2] | Quitar el bloqueo puede exceder la autoridad del gerente; no sé quién tiene esa facultad | `/pm-escalate` para el comité, con la pregunta cerrada |
| Cadencia: venía semanal y las notas dicen «en dos semanas» | Es una decisión del gerente, no necesita sala | Confirmar y ajustar `cycle.committee` en la configuración |

### Anexo — sin cambios desde el 2026-10-15
Sin comparación con una foto anterior; son abiertos con fecha posterior al 10-29 y sin vencer.
- Elena Duarte · Revisar el anexo 3 · 2026-10-31 (movida dos veces)
- Javier Hoyos · Actualizar la matriz 22 · 2026-11-02
- Gustavo Neira · Actualizar la matriz 14 · 2026-11-03 (movida dos veces)

Cerrados con acta, no se repasan: 4, 5, 11 y 16 (Sandra Gil, Felipe Arango, Óscar Ramírez y Diana Molina).

**Quedaron fuera por tiempo:** nada. La suma de los ocho puntos es de 45 minutos, justo el tope supuesto, sin margen para apertura.
Esta agenda sale de la ficha y de las salidas de `/pm-minutes` y `/pm-commitments` del 2026-10-15; no volví a leer las minutas originales.

Cuando termine la reunión, `/pm-minutes` sobre las notas o la transcripción: lo que salga de ahí entra a `/pm-commitments` con su cita.
