## Para decisión — Migración del ERP (PRY-209) · 2026-10-15

Sin tema en el argumento, tomé «lo que ya está marcado como escalable». Hay un solo punto que escala hoy, y es el primero que la regla manda subir: **el acta no declara la autoridad del gerente.**

### ¿Se declara por escrito qué puede decidir Camilo Beltrán en PRY-209 (mover fechas de hitos, quitar bloqueos a compromisos de terceros, comprometer gasto) y hasta dónde, o se acuerda que toda decisión de esas tres clases pasa por el comité?

**Quién decide:** el acta no lo dice. Lo que sí dice: el patrocinador es Gustavo Neira y el presupuesto lo aprobó el Comité de Cadena de Abastecimiento el 2026-05-28. Es razonable que quien aprobó el acta sea quien la enmiende, pero **eso es inferencia mía, no está escrito**: confírmalo antes de llevarlo. · **Si no se decide hoy:** el comité siguiente es el 2026-10-29 (configuración); mientras no haya autoridad escrita, el hito «Ambiente de pruebas certificado» (vencido desde 2026-10-05, sin replanificación) no se puede clasificar como decisión del gerente o del comité, y lo mismo vale para el bloqueo de «Enviar el documento 1» (seis reprogramaciones) si el 10-29 no se resuelve en la sala.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta con la autoridad del gerente y sus topes (días de corrimiento de un hito, monto, quién reasigna) | Sin cambio | Una sesión de comité para aprobar los topes; después, decisiones sin escalar | Sin costo directo; los topes los fija el comité, no yo |
| B. Sin adenda: toda decisión de fechas, bloqueos o gasto se escala caso a caso | Sin cambio | Cada decisión espera al comité (semanal según la configuración; las notas del 10-15 dicen «en dos semanas») | Sin costo directo declarado; el costo es la espera acumulada en un proyecto que ya tiene un hito vencido |

No tengo cifras de costo ni de días para ninguna opción: ningún documento las trae, y no las invento.

**Recomiendo:** A — el patrocinador y el comité fijan los topes, porque con B el comité recibiría cada compromiso movido como un punto aparte, y ya hay 26 compromisos en la ficha. Los números de los topes son suyos, no los propongo.

### A quién alcanza
Ninguno identificado. El acta dice «Dependencias declaradas: Ninguna declarada»; eso es ausencia de declaración, no prueba de que no haya dependencias. No se propuso ningún cambio de fecha, así que **no calculé el efecto de un corrimiento**. (Corrí `impact` con 14 días solo para ver la mecánica; es un número inventado y no sustenta nada en este paquete.)

### Mis hitos por los que pasaría un corrimiento
Si el comité mueve algo, el cálculo se rehace con los días reales. Hitos pendientes en la ficha:

| Hito | Fecha vigente | En cuántos días (al 2026-10-15) |
|---|---|---|
| Integración con el ERP | 2026-12-05 | 51 |
| Piloto en tiendas | 2027-02-03 | 111 |

El cierre comprometido es el 2027-03-06. «Ambiente de pruebas certificado» (2026-10-05) ya venció sin acta de cumplimiento.

### Lo que no escala todavía
- **Quitar el bloqueo a Felipe Arango y Diana Molina:** depende de lo que salga de los puntos [1] y [2] de la agenda del 10-29, que no se han discutido. Si siguen sin fecha creíble, vuelve aquí; y con la autoridad escrita se sabría si lo decide Camilo.
- **Fecha del hito «Ambiente de pruebas certificado»:** mover una fecha de la línea base es control de cambios, no escalamiento; se registra aparte y la línea base original no se toca.
- **Riesgo del proveedor sin dueño** y compromisos sin fecha (presupuesto, Laura Vélez): son del gerente.

### De dónde sale esto
- Autoridad no declarada, patrocinador, comité y presupuesto: `00-gobierno/2026-05-28-acta-constitucion.docx` (leí el texto completo; no hay sección de autoridad ni de facultades). La ficha lo confirma: `identity.authority`, no encontrado.
- Hitos y fechas: `10-plan/2026-05-28-cronograma-v1.xlsx`, vía la ficha.
- Seis reprogramaciones de «Enviar el documento 1»: `30-reuniones/2026-09-03-comite-semanal.md` a `2026-10-15-notas-reunion.txt`, vía la ficha.
- Fecha del comité y cadencia: `.criterio/proyecto/PRY-209/config.json`.

**Lo que no sé:** quién tiene la facultad hoy, cuántos días se mueve cada proyecto alcanzado (la ficha no tiene holgura por actividad), y si existe algún documento de autoridad fuera de la carpeta.
