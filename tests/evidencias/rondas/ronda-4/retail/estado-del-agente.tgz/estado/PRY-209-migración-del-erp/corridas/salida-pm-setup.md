Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

*Sesión sin interfaz: las tres primeras preguntas (quién eres y qué proyecto es, cuándo es tu reunión, dónde guardo el estado) las respondí con la propuesta por defecto: Camilo Beltrán, PRY-209 Migración del ERP, según el acta de constitución; comité semanal de los jueves, con la próxima el 2026-10-29 porque las notas del 15 dicen «en dos semanas»; y estado en `estado/PRY-209-migración-del-erp`.*

## Listo — PRY-209 · Migración del ERP

**Lo que miré:** 15 documentos · 6 minutas del comité (2026-09-03 a 2026-10-08) más las notas del 2026-10-15 · la más reciente es del 2026-10-15. Leí las 6 minutas completas, de la más vieja a la más nueva, y las 5 actas de recibo. Todos los formatos (docx, xlsx, pdf, md, txt) se pudieron leer.
**Términos:** aceptados para la versión 1.1 (familia 0.3.10) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 5c505a87302a3766…

Texto mostrado: «Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal»

### Lo que está abierto, y cuántas veces se ha movido
En total hay 26 compromisos en el historial: 4 cerrados con acta de recibo y 22 abiertos.

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Felipe Arango | Enviar el documento 1 | 2026-11-29 (prometido primero el 2026-09-16) | **Movido 6 veces:** 09-27 → 10-06 → 10-20 → 10-28 → 11-15 → 11-29. Fuente: minutas del 09-03 al 10-08 y notas del 10-15 |
| Diana Molina | Cerrar la prueba 2 | 2026-11-15 (primero el 2026-09-10) | **Movido 5 veces:** 09-19 → 10-02 → 10-16 → 10-27 → 11-15. Fuente: minutas del 09-03 al 10-08 |
| Elena Duarte | Revisar el anexo 3 | 2026-10-31 | Empezó «por definir»; luego 10-15 y 10-31 (2 veces) |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-06 | **Vencido hace 9 días, sin evidencia.** Movido 2 veces (09-29, 10-06); la minuta del 10-08 lo sigue listando con la fecha ya pasada |
| Diana Molina | Entregar el punto 8 | 2026-09-28 | **Vencido hace 17 días, sin evidencia.** En la minuta del 09-17 dijo que ya lo entregó; no se presentó acta y salió de la lista |
| Laura Vélez | Confirmar la fecha 15 | 2026-10-14 | **Vencido hace 1 día, sin evidencia.** En la minuta del 10-08 dijo que ya lo entregó; no se presentó acta y salió de la lista |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-12 | **Vencido hace 3 días, sin evidencia** (minuta del 10-08) |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-19 | Aún no vence, pero en la minuta del 10-01 dijo que ya lo entregó; no hay acta y salió de la lista |
| Rubén Cárdenas | Confirmar la fecha 7 | 2026-10-27 | Movido 2 veces |
| Mauricio Pérez | Enviar el documento 9 | 2026-10-28 | Movido 2 veces |
| Ricardo Salas | Validar el ambiente 12 | 2026-10-20 | Movido 2 veces |
| Gustavo Neira | Actualizar la matriz 14 | 2026-11-03 | Movido 2 veces |
| Óscar Ramírez | Cerrar la prueba 10 | 2026-10-27 | Movido 1 vez |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo, notas del 10-15 |

Sin movimiento y vigentes: Ricardo Salas (documento 17, 10-16), Beatriz Cuéllar (prueba 18, 10-18), Elena Duarte (anexo 19, 10-27), María Restrepo (ambiente 20, 10-19), Javier Hoyos (matriz 22, 11-02), Mauricio Pérez (fecha 23 y punto 24, 10-24).

**Cerrados con acta:** Validar el ambiente 4 (Sandra Gil, acta 2026-09-10), Entregar el punto 16 (Diana Molina, 2026-10-01), Aprobar el diseño 5 (Felipe Arango, 2026-10-08; se había movido 2 veces), Revisar el anexo 11 (Óscar Ramírez, 2026-10-08; se había movido 2 veces).

**Otras señales que levantó el cálculo:**
- Hito «Ambiente de pruebas certificado»: línea base 2026-10-05, 10 días vencido, sin acta que lo pruebe.
- El informe del 2026-10-15 declara amarillo y 75% de avance; el cronograma tiene 1 de 4 hitos cerrados (el plan sostiene entre 25% y 50%), y el 75% queda 25 puntos por encima. El informe no menciona ningún compromiso vencido ni reprogramado, ni el hito vencido.
- Presupuesto (informe): aprobado COP 6.800.000.000; comprometido 4.491.302.023 (66,0%); ejecutado 1.935.274.876 (28,5%); proyección al cierre 6.735.523.046 (−0,9% frente al aprobado). Sin alerta de costo.
- Riesgo que se dijo y nadie anotó (notas del 10-15): el proveedor podría no llegar con el equipo completo para la siguiente fase. No está en los riesgos del informe.

### Sin fecha
- **Laura Vélez — «Mandar el ajuste del presupuesto»:** dijo «la otra semana» (notas del 2026-10-15); nadie fijó fecha. No puede estar vencido, y por eso es el que desaparece de los informes.

### Qué le falta a tu carpeta
- Actas de recibo de lo que se dijo entregado: «Entregar el punto 8» (Diana Molina), «Aprobar el diseño 13» (Gustavo Neira) y «Confirmar la fecha 15» (Laura Vélez). Sin ellas se ven igual que los incumplidos.
- Acta o evidencia del hito «Ambiente de pruebas certificado», vencido desde el 10-05, y de los hitos de integración y piloto cuando cierren.
- Un cronograma más reciente que la v1 del 2026-05-28; el vigente y la línea base original son la misma fecha en los cuatro hitos.
- Del acta de constitución faltan producto asociado, facultad del gerente (hasta qué monto y cambio puede decidir sin comité) y fase; y no hay dependencias ni proveedores registrados.
- Las minutas de antes del 2026-09-03: el compromiso del documento 1 ya tenía fecha original 09-16 en la primera que leí, y puede venir de antes.
- Dueño de los dos riesgos del informe y del riesgo del proveedor: ninguno lo nombra.

La ficha quedó en `estado/PRY-209-migración-del-erp/records/PRY-209.json`. **No la sellé:** leí las reuniones y las actas, no el proyecto entero.

**Cuándo vuelvo:** el 2026-10-29, la próxima reunión según las notas del 15 («en dos semanas»). Si prefieres que siga el jueves semanal de las minutas, dímelo y lo cambio.
