# Corrida del 2026-10-15 · pm-commitments

1 proyectos · 32 s · 9 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 4 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `milestone_overdue` | 1 |
| `commitment_undated` | 1 |

Felipe Arango (documento 1) reprogramado 6 veces y Diana Molina (prueba 2) 5; 4 compromisos vencidos sin evidencia (2 dichos entregados sin acta); 1 sin fecha (Laura Vélez); sin cierres nuevos desde pm-setup

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Compromisos — Migración del ERP (PRY-209) · al 2026-10-15

26 compromisos registrados: 22 abiertos y 4 cerrados con acta de recibo. De los abiertos, 4 están vencidos sin evidencia, 2 se vienen reprogramando 5 o más veces y 1 no tiene fecha.

### Se viene reprogramando

> **Felipe Arango** · Enviar el documento 1
> Prometido para el 2026-11-29, y antes para el 11-15, el 10-28, el 10-20, el 10-06, el 09-27 y, al principio, el 09-16 (dicho el 2026-09-03). **Seis reprogramaciones en cinco semanas.**
> Fuentes: `30-reuniones/2026-09-03-comite-semanal.md` (primera promesa) y `2026-10-15-notas-reunion.txt` (fecha vigente).

> **Diana Molina** · Cerrar la prueba 2
> Prometido para el 2026-11-15, y antes para el 10-27, el 10-16, el 10-02, el 09-19 y, al principio, el 09-10 (dicho el 2026-09-03). **Cinco reprogramaciones.**
> Fuentes: `30-reuniones/2026-09-03-comite-semanal.md` y `30-reuniones/2026-10-08-comite-semanal.md`.

**Tres veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** Aquí son seis y cinco. Con la fecha vigente tan lejos, ninguno de los dos aparece como vencido, aunque llevan semanas sin cumplirse.

Con dos reprogramaciones, sin llegar al umbral de tres, están Óscar Ramírez (Actualizar la matriz 6, ya vencido), Elena Duarte (Revisar el anexo 3), Rubén Cárdenas (Confirmar la fecha 7), Mauricio Pérez (Enviar el documento 9), Ricardo Salas (Validar el ambiente 12) y Gustavo Neira (Actualizar la matriz 14).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Diana Molina | Entregar el punto 8 | 2026-09-28 | 17 días |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-06 | 9 días |
| Liliana Torres | Aprobar el diseño 21 | 2026-10-12 | 3 días |
| Laura Vélez | Confirmar la fecha 15 | 2026-10-14 | 1 día |

Diana Molina dijo el 2026-09-17 que el punto 8 estaba entregado, y Laura Vélez dijo el 2026-10-08 que la fecha 15 estaba confirmada. En ninguno de los dos casos se presentó acta ni hay nada en el expediente que lo respalde, así que siguen abiertos.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Enviar el documento 17 | 2026-10-16 |
| Beatriz Cuéllar | Cerrar la prueba 18 | 2026-10-18 |
| Gustavo Neira | Aprobar el diseño 13 | 2026-10-19 |
| María Restrepo | Validar el ambiente 20 | 2026-10-19 |
| Ricardo Salas | Validar el ambiente 12 | 2026-10-20 (ya reprogramado dos veces) |

Gustavo Neira dijo el 2026-10-01 que el diseño 13 estaba aprobado; no hay acta. Sigue abierto.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-15 |

Las notas dicen «la otra semana»; nadie dijo fecha. No puede estar vencido, y por eso se cuenta aparte.

### Ver también
La reunión del 2026-10-15 también dejó a Óscar Ramírez con la revisión con el proveedor para el 2026-10-25, y un riesgo del proveedor («podría no llegar con el equipo completo para la siguiente fase») dicho al pasar y sin registrar.

## Qué sigue

Ofrezco dos cosas, que no hago sin que las pidas:
1. Formular lo de Felipe Arango y Diana Molina como decisión para el comité del 2026-10-29: qué se pide, qué pasa si no se decide y quién tiene la facultad.
2. `/pm-publish`, porque lo reprogramado cambia lo que la ficha dice para la PMO.
