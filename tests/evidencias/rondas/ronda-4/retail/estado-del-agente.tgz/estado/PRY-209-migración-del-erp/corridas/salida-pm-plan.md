# Plan — Migración del ERP (PRY-209) · borrador del 2026-10-15
**Desde:** acta de constitución del 2026-05-28 (`00-gobierno/2026-05-28-acta-constitucion.docx`) · **Criterio de éxito:** «Migración del ERP en producción y medido.» (acta). No dice con qué se mide.

> **Antes de leerlo:** esto no es un primer borrador. El proyecto ya tiene línea base v1 aprobada el 2026-05-28 (`10-plan/2026-05-28-cronograma-v1.xlsx`, 4 hitos) y va a 4,5 meses de ejecución con 75 % declarado. Lo traté como una **revisión del plan sobre un acta que quedó a medio llenar**. No toqué la línea base ni comprometo ninguna fecha. Las fechas que aparecen abajo son las de la línea base v1, citadas, no nuevas.
> Sin interfaz para preguntar: ante cada duda seguí adelante y dejé el vacío a la vista.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance con contenido.** Dice «Componente 1, Componente 2, Componente 3» y «Fuera de alcance: Lo que otro proyecto cubre». Son marcadores de plantilla. | No hay de dónde descomponer. La WBS solo puede apoyarse en los hitos del cronograma, que el acta no menciona. Cualquier cosa «fuera de alcance» queda sin frontera. |
| **Criterio de éxito medible.** «En producción y medido»: no dice qué métrica, qué umbral ni quién mide. | No se puede saber cuándo el último entregable está aceptado. «Medido» queda como un nodo sin cierre. |
| **Autoridad declarada.** No hay (la ficha lo registra como no encontrado). | No sé qué puede decidir el gerente al planificar y qué hay que subir. Todo ajuste de plan queda con dueño incierto. |
| **Dependencias.** «Ninguna declarada». Pero las notas del 2026-10-15 hablan de un proveedor y de una «revisión con el proveedor», y no hay contrato en la carpeta. | El proveedor, que parece estar en la ruta del trabajo, no figura en ninguna dependencia. Su riesgo («podría no llegar con el equipo completo») no está registrado en ninguna parte. |
| **Coherencia de dueños.** Área dueña: Talento humano; comité: Cadena de Abastecimiento; el cronograma habla de «Piloto en tiendas». | No es claro quién recibe el producto ni quién acepta los entregables. |
| **Objetivo del negocio genérico** («Entregar migración del erp para Talento humano»). | No aporta nada para decidir qué entra y qué no. |

Patrocinador sí está: Gustavo Neira. Esa es la persona a quien llevar las excepciones.

## WBS
Terminales que alguien recibe y acepta. Ninguno de los cuatro primeros está en el acta; vienen del cronograma v1.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño de la experiencia aprobado | Acta de recibo del 2026-10-06: «Recibido por Camilo Beltrán» | **Supuesto** (hito del cronograma v1; no está en el acta). Cerrado con evidencia. | — (ya cerrado) |
| 2 | Ambiente de pruebas certificado | **Sin definir** | **Supuesto** (hito del cronograma v1). Sin evidencia de cierre. | vacía |
| 3 | Integración con el ERP | **Sin definir** | **Supuesto** (hito del cronograma v1) | vacía |
| 4 | Piloto en tiendas | **Sin definir** (¿jefes de tienda?, no está dicho) | **Supuesto** (hito del cronograma v1) | vacía |
| 5 | Migración del ERP en producción y medido | **Sin definir** | **Del acta** (criterio de éxito) | vacía |
| 6 | Componente 1 | **Sin definir** | **Sin definir** (marcador de plantilla en el acta) | vacía |
| 7 | Componente 2 | **Sin definir** | **Sin definir** | vacía |
| 8 | Componente 3 | **Sin definir** | **Sin definir** | vacía |

Referencia, no duración: las ventanas entre hitos en la línea base v1 son 60 días (inicio 2026-06-07 → diseño 2026-08-06), 60 (→ ambiente 2026-10-05), 61 (→ integración 2026-12-05), 60 (→ piloto 2027-02-03) y 31 (→ cierre 2027-03-06). Son lo que se aprobó, no lo que el trabajo toma.

No agregué nodos de migración de datos, capacitación, corte ni medición posterior: nada en los documentos los menciona y completarlos con lo razonable es lo que este plan no hace. Están en «Sin definir».

## Orden
Sin fechas. Orden del cronograma v1, **tomado como supuesto de dependencia** porque ningún documento dice que unos necesiten a otros:

1 Diseño → 2 Ambiente de pruebas certificado → 3 Integración con el ERP → 4 Piloto en tiendas → 5 Producción y medición.

- Nodos 6–8 (componentes): no se pueden ordenar, no se sabe qué son.
- Conviene verificar que 3 realmente espera al 2. El informe del 2026-10-15 dice que la prueba de carga de temporada no alcanzó el umbral y se repite; eso toca el nodo 2 y por tanto, si el supuesto es cierto, todo lo que sigue.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los 4 hitos del cronograma v1 son los entregables del proyecto | La WBS está incompleta o tiene nodos que el negocio no pidió. |
| El orden de los hitos del cronograma es orden de dependencia | El camino crítico es otro y las fechas de la línea base se apoyan en una secuencia que no existe. |
| «Recibido por Camilo Beltrán» es aceptación válida del diseño | El nodo 1 está cerrado solo por el gerente; si el negocio debía aceptarlo, no hay aceptación. |
| La prueba de carga de temporada pertenece al «Ambiente de pruebas certificado» | Hay un entregable sin nodo o el nodo 2 tiene un cierre distinto del que se cree. |
| El proveedor participa en la ruta del trabajo (por las notas del 2026-10-15) | Si no, la «revisión con el proveedor» del 2026-10-25 no es parte del plan. Si sí, falta una dependencia y probablemente un contrato en la carpeta. |

Estos pasan a riesgos del proyecto cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define (propuesto; el acta no lo dice) |
|---|---|
| Qué son los Componentes 1, 2 y 3 y qué queda fuera | Patrocinador (Gustavo Neira), con el gerente |
| Métrica, umbral y responsable de «medido» | Patrocinador |
| Quién acepta cada entregable (2 a 8) | Patrocinador |
| Autoridad del gerente al planificar | Patrocinador |
| Si el proveedor es dependencia, y bajo qué contrato | Gerente (Camilo Beltrán) a confirmar con el patrocinador |
| Dueño del producto: Talento humano o Cadena de Abastecimiento | Patrocinador / comité |
| Efecto del «ajuste del presupuesto» que Laura Vélez prometió «la otra semana» (sin fecha) sobre el plan | Laura Vélez, luego el comité |

## Proyectos análogos
Ninguno a la vista. La configuración de este proyecto no apunta a una carpeta de fichas de la PMO, así que no hay con qué comparar. No se ofrece estimación por analogía.

Lo único «análogo» disponible es del propio proyecto, y es un dato, no una proyección:
- El hito «Diseño de la experiencia aprobado» tenía fecha de línea base 2026-08-06 y su acta de recibo es del 2026-10-06 (61 días después). El cronograma sigue mostrando 2026-08-06 como fecha vigente, sin replanificación registrada. Fuente: cronograma v1 y acta de recibo del 2026-10-06.
- «Ambiente de pruebas certificado»: línea base 2026-10-05, sin evidencia de cierre al 2026-10-15 (10 días). Fuente: cronograma v1.

## Preguntas para el equipo
Una por cada duración vacía:
1. Ambiente de pruebas certificado: ¿cuánto falta, repetida la prueba de carga de temporada, y quién certifica?
2. Integración con el ERP: ¿cuánto toma y qué necesita del proveedor y de qué entregable previo?
3. Piloto en tiendas: ¿cuánto dura, cuántas tiendas, y en qué ventana pueden participar los jefes de tienda?
4. Producción y medición: ¿cuánto toma el corte, y cuánto tiempo después se mide, con qué métrica?
5. Componente 1: ¿qué es y cuánto toma?
6. Componente 2: ¿qué es y cuánto toma?
7. Componente 3: ¿qué es y cuánto toma?

## Para comprometer una fecha falta
- La disponibilidad real del equipo. El informe del 2026-10-15 declara «concentración del conocimiento en una sola persona», sin dueño.
- La fecha del proveedor y si llega con el equipo completo para la siguiente fase (comentado el 2026-10-15; nadie lo registró).
- La ventana de las tiendas para el piloto. El informe declara «disponibilidad de los jefes de tienda para el piloto» como riesgo abierto, sin dueño.
- El resultado de la repetición de la prueba de carga.
- El ajuste del presupuesto pendiente (Laura Vélez, sin fecha).
- Que el patrocinador diga qué es el alcance. Sin eso, ninguna fecha cierra nada.

Ninguna de estas está hoy en un documento.

## Después
La línea base original ya existe (v1, 2026-05-28) y no la toco. Si este plan se aprueba como revisión, el cambio entra por control de cambios y como línea base nueva, sin borrar la v1; los supuestos de arriba pasan al RAID con doliente.
