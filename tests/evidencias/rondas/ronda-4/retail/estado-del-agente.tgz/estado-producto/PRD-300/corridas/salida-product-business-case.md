# Caso de negocio — Venta en línea (PRD-300) · borrador del 2026-10-15
**Desde:** `00-definicion/2025-11-26-definicion-producto.md` y `00-definicion/2025-11-26-caso-de-negocio.md`, ambos del 2025-11-26 · **Cifras con fuente:** 1 de 1 declarada, pero ninguna con origen anterior al propio caso (0 medidas, 0 con documento de respaldo)

**Términos:** ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

## Qué problema resuelve, y para quién
«El segmento Empresas no tiene venta en línea.» Para el segmento Empresas. (`00-definicion/2025-11-26-definicion-producto.md`, 2025-11-26.)
No se sabe cuántas empresas lo tienen ni cuánto pagarían: ningún documento lo dimensiona.

## Qué se construye
La propuesta en la definición dice solo «Propuesta principal»: es un marcador, no una propuesta. Lo decidido es lo que está en el registro: **13 requerimientos aceptados** y 3 propuestos (REQ-4002, 4003, 4005, que **no entran** al caso). Los títulos son genéricos («Requerimiento REQ-xxxx»); ningún documento dice qué es cada uno.

| Requerimiento | Estado | Doliente | Criterio de aceptación | Evidencia de demanda |
|---|---|---|---|---|
| REQ-2028 | aceptado | Rubén Cárdenas | no | Entrevista 2025-11-24 |
| REQ-2036 | aceptado | Rubén Cárdenas | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4000 | aceptado | Mauricio Pérez | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4001 | aceptado | Sandra Gil | no | Entrevista 2025-11-24 |
| REQ-4004 | aceptado | **sin doliente** | no | Entrevista 2025-11-24 |
| REQ-4006 | aceptado | Ricardo Salas | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4007 | aceptado | Mauricio Pérez | no | Entrevista 2025-11-24 |
| REQ-4008 | aceptado | Camilo Beltrán | «se verifica en producción» | **ninguna** |
| REQ-4009 | aceptado | **sin doliente** | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4010 | aceptado | Andrés Lozano | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4011 | aceptado | Sandra Gil | «se verifica en producción» | **ninguna** |
| REQ-4012 | aceptado | Gustavo Neira | «se verifica en producción» | Entrevista 2025-11-24 |
| REQ-4013 | aceptado | Mauricio Pérez | «se verifica en producción» | Entrevista 2025-11-24 |

Estado y doliente salen de `30-decisiones/2026-10-09-comite-producto.docx` (2026-10-09). La «evidencia» es siempre la misma frase de un solo cliente entrevistado el 2025-11-24 («Lo necesito y hoy no lo tengo»): la entrevista no nombra ningún requerimiento y no dice que sea del segmento Empresas; el acta se la atribuye a «Cliente entrevistado». Nadie la pidió con nombre propio para estos requerimientos. «Se verifica en producción» no es un criterio verificable. Ningún requerimiento tiene necesidad escrita.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| `volumen_mensual` | 228.369 | **Declarada** (no medida; sin unidad ni qué cuenta) | `00-definicion/2025-11-26-caso-de-negocio.md`, que se cita a sí mismo como fuente | 2025-11-26 |
| Retorno esperado | sin cifra, solo «24 meses» | **Supuesta**: nadie afirmó un monto ni una base | mismo caso | 2025-11-26 |
| «El proveedor cumple el tiempo pactado» | sin proveedor ni plazo | **Supuesta** (ver supuestos) | definición, declarado el 2026-07-21 | 2026-07-21 |

Una observación que el comité va a hacer: la definición dice que Empresas **no tiene** venta en línea hoy; el documento no explica de dónde sale un volumen mensual de algo que no existe. Como ninguna serie lo mide, no puedo decir si es una proyección, una estimación de otro canal o un valor de plantilla. Tampoco encontré 228.369 en ningún otro producto.

### Donde la cifra declarada y la medida no coinciden
Ninguna diferencia calculable: `volumen_mensual` no tiene serie medida (`measured: null`), así que no hay contra qué comparar. Eso no la sostiene; la deja sin contrastar. El umbral de brecha es 20 %.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no está** | Ningún documento: ni contrato, ni cotización, ni costo declarado del equipo |
| Costo de operar | **no está** | — |

**Este es el primer vacío**: sin costo de construir no hay caso de negocio que evaluar, hay una propuesta. No calculo retorno, ni recuperación, ni ahorro, y no relleno con valores de referencia del sector.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-07-21, **86 días sin verificar**; umbral 30) | Sin proveedor que cumpla no hay venta en línea; el plazo de 24 meses del retorno no se sostiene | Sin confirmar: haría falta un documento que nombre al proveedor y el tiempo pactado, y un registro de avance contra esa fecha |
| El `volumen_mensual` de 228.369 se alcanzará (implícito) | Todo el retorno depende de él | Nadie lo ha afirmado como supuesto; lo produce el negocio |
| Hay demanda en Empresas (implícito; una sola entrevista, 325 días, cruza 12 meses el 2026-11-24) | El caso se queda sin mercado | Quien lleve descubrimiento; sin confirmar |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin costo no hay caso | El negocio / quien tenga el contrato o la cotización (sin confirmar) |
| Origen y unidad del `volumen_mensual` | Es la única cifra del caso y no tiene dónde apoyarse | María Restrepo (autora del caso) |
| Base del retorno esperado (monto, cómo se mide) | Hoy es solo un plazo | El negocio |
| Criterio de éxito | No se puede cerrar el producto meses después | María Restrepo / comité (autoridad sin confirmar) |
| Qué se hace si no se construye | No está dicho | El negocio |
| Alternativas consideradas | No está dicho | El negocio |
| Cuántas empresas y a qué precio | No hay dimensión del mercado | Descubrimiento / negocio |
| Qué proveedor y qué plazo | Soporta el supuesto principal | Quien contrató; sin confirmar |
| Proyecto que lo construye | «Ninguno declarado»; los requerimientos no tienen traza | Sin confirmar |
| País | Sin él no se sitúa lo normativo (pagos y datos personales de los compradores: **no tengo la norma a la vista**; va a revisión jurídica) | Quien configure el producto |
| Dolientes de REQ-4004 y REQ-4009; criterio de aceptación en 4 de 13 aceptados; evidencia en REQ-4008 y REQ-4011 | Aceptados sin que nadie los pidió o los verifique | Comité de producto |

## Cómo se sabrá si funcionó
**No está declarado.** Ningún documento trae criterio de éxito, métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después, y «retorno en 24 meses» no es verificable porque no trae cifra.

## Si hay otros productos publicados
No hay ninguno publicado a la vista (la carpeta `estado/` está vacía), así que el cruce de `/product-overlap` no se pudo hacer con fichas. Los casos de negocio de otros productos (PRD-299 a PRD-309) sí traen `volumen_mensual`, pero ninguno repite 228.369. Hasta que se publiquen, esto no descarta que se cuenten las mismas transacciones.

## Después
Ofrezco pasar los tres supuestos al seguimiento (`assumption-tracking`), empezando por el del proveedor, que lleva 86 días. `/product-charter` queda para cuando haya costo, criterio de éxito y autoridad confirmada.
