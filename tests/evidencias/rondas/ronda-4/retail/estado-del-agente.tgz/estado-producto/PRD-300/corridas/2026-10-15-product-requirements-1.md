# Corrida del 2026-10-15 · product-requirements

PRD-300 · 16 requerimientos · 25 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_accepted_without_evidence` | 2 |
| `assumption_unverified` | 1 |

REQ-4008 y REQ-4011 aceptados sin evidencia; REQ-4003, 4005 y 4002 sin decidir; REQ-4004 y 4009 sin doliente; 13 sin proyecto confirmado (carpeta de fichas vacía)

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Registro — Venta en línea (PRD-300) · al 2026-10-15
16 requerimientos · 13 decididos · 84.6% con evidencia · 0% con proyecto que lo ejecuta

> Nota: la carpeta de fichas de proyecto (`estado/`) está vacía, así que ningún requerimiento se pudo confirmar contra un proyecto. El 0% es "sin ficha que lo confirme", no prueba de que nadie construya nada.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4008 | Requerimiento REQ-4008 | aceptado (decidido el 2026-05-09) | Camilo Beltrán |
| REQ-4011 | Requerimiento REQ-4011 | aceptado (decidido el 2026-06-23) | Sandra Gil |

Ninguno tiene una sola cita de quien lo pidió. Cierra el vacío cada doliente: aportar la evidencia o llevarlo de nuevo al Comité de producto.

### Decidido y nadie lo está construyendo
Los 13 aceptados quedan sin proyecto que los ejecute (sin ficha que lo confirme):

| REQ | Decidido el |
|---|---|
| REQ-4009 | 2026-04-10 |
| REQ-4010 | 2026-05-05 |
| REQ-4008 | 2026-05-09 |
| REQ-4000 | 2026-05-16 |
| REQ-4001 | 2026-05-28 |
| REQ-4004 | 2026-06-02 |
| REQ-4011 | 2026-06-23 |
| REQ-4012 | 2026-06-26 |
| REQ-4007 | 2026-07-30 |
| REQ-4006 | 2026-08-09 |
| REQ-4013 | 2026-08-11 |
| REQ-2028 | 2026-09-24 |
| REQ-2036 | 2026-10-10 |

### Sin doliente
| REQ | Título | Dice |
|---|---|---|
| REQ-4004 | Requerimiento REQ-4004 | sin doliente (aceptado el 2026-06-02) |
| REQ-4009 | Requerimiento REQ-4009 | sin doliente (aceptado el 2026-04-10) |

Quién lo cierra: María Restrepo (gerente de producto) nombra una persona, no un área.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-2028 | Requerimiento REQ-2028 | aceptado |
| REQ-4001 | Requerimiento REQ-4001 | aceptado |
| REQ-4004 | Requerimiento REQ-4004 | aceptado |
| REQ-4007 | Requerimiento REQ-4007 | aceptado |

Cierra cada doliente (Rubén Cárdenas, Sandra Gil, sin doliente, Mauricio Pérez). Los propuestos no se cuentan: no se les exige criterio.

### Decidido sin documento que lo respalde
No se calculó: el cálculo no cruza cada decisión contra el acta del comité. Existe `30-decisiones/2026-10-09-comite-producto.docx`, que no se ha leído en esta corrida. Queda por verificar, sin afirmar nada.

### Lleva meses y nadie lo decide (umbral: 60 días)
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4003 | Requerimiento REQ-4003 | 205 días (2026-03-24) | Comité de producto |
| REQ-4005 | Requerimiento REQ-4005 | 160 días (2026-05-08) | Comité de producto |
| REQ-4002 | Requerimiento REQ-4002 | 96 días (2026-07-11) | Comité de producto |

Se propone llevarlos al próximo comité mensual para decidir (aceptar o descartar), no cerrarlos por viejos. REQ-4005 tampoco tiene evidencia, y como está propuesto no se le exige.

### Evidencia vieja
Sin hallazgos. Lo más nuevo que sostiene los requerimientos es del 2025-11-24, bajo el umbral de 12 meses, aunque se cumple a fines de noviembre de 2026.

### Fuera del registro, pero en la definición
- El supuesto "El proveedor cumple el tiempo pactado" lleva 86 días sin verificar (umbral 30).
- El volumen mensual declarado, 228,369, no tiene medición contra la cual contrastarlo.
- La definición no trae criterio de éxito.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

Después: hay 13 requerimientos decididos que nadie confirma que se construyan, así que corresponde `/product-trace`.
