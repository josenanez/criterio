# Corrida del 2026-10-15 · product-charter

PRD-300 · 16 requerimientos · 35 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_accepted_without_evidence` | 2 |
| `assumption_unverified` | 1 |

Borrador de acta para REQ-4000; 10 vacíos declarados (decisor de la aceptación, criterio medible, necesidad, autoridad, patrocinador/gerente, normativa, presupuesto/hitos). No se firmó ni se creó ficha.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Configuración: `.criterio/producto/PRD-300/config.json` (único producto configurado; el argumento REQ-4000 es un requerimiento, no un código de producto). Términos v1.1 ya vigentes, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo.

## Verificación previa (requirement-record)

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | **Sí en el estado, no en la decisión.** El acta del comité del 2026-10-09 lo lista como «aceptado, desde 2026-05-16», pero no dice quién lo aceptó. Único asistente: María Restrepo. |
| Criterios de aceptación verificables | **Débil.** Solo «se verifica en producción»: es un lugar, no un criterio medible. |
| Evidencia de demanda con cita | **Parcial.** Una cita («Lo necesito y hoy no lo tengo.», entrevista del 2025-11-24, ~11 meses, bajo el umbral de 12) que **no nombra este requerimiento**: el acta del comité lo atribuye a «Cliente entrevistado». |
| Autoridad declarada en la definición | **Falta.** La definición no la declara. El acta del comité nombra «Comité de producto» pero no dice quién decide en él. |

Respuesta sugerida tomada (sesión sin interfaz): **seguir, marcando cada falta como vacío del acta; nada se rellena.**

---

# Acta de constitución — Venta en línea (REQ-4000) · borrador del 2026-10-15
**Producto:** PRD-300 Venta en línea · **Requerimientos:** REQ-4000

## Qué problema resuelve
«El segmento Empresas no tiene venta en línea.» (`00-definicion/2025-11-26-definicion-producto.md`, 2025-11-26). Ese es el problema del **producto**. Lo que REQ-4000 aporta a él **no está dicho**: el título es genérico («Requerimiento REQ-4000») y el campo «necesidad» no aparece en ningún documento.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No está dicho.** Falta qué se mide, con qué umbral y quién lo da por cumplido. | `30-decisiones/2026-10-09-comite-producto.docx` |

El éxito del producto en la definición: no encontrado. Con este criterio el cierre no se podrá juzgar meses después.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 (sin título propio) | Cita del cliente entrevistado, 2025-11-24, que no nombra el requerimiento (`10-descubrimiento/2025-11-24-entrevistas.docx`). Doliente: Mauricio Pérez (acta del comité). |

### No entra
Los demás requerimientos del registro no están en esta acta porque no se pidieron en esta invocación. No es un juicio sobre ellos; tres, además, no podrían entrar: siguen **propuestos**. Estado según el acta del 2026-10-09:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4002, REQ-4003, REQ-4005 | sin título propio | Propuestos, no aceptados. |
| REQ-4001, 4004, 4006, 4007, 4008, 4009, 4010, 4011, 4012, 4013, 2028, 2036 | sin título propio | Aceptados, pero no se pidieron para esta acta. Quién decide si van en esta o en otra acta: el gerente de producto. |

## Gobierno
- **Patrocinador:** no dicho en ningún documento.
- **Gerente propuesto:** no dicho. El gerente del **producto** es María Restrepo (definición, 2025-11-26); eso no la hace gerente del proyecto. Este comando no nombra a nadie.
- **Comité:** «Comité de producto», mensual (acta del 2026-10-09; configuración). Quién decide en él: no dicho; asistente único, María Restrepo. Sin confirmar.
- **Autoridad del gerente del proyecto:** no dicha.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-07-21) | No. Lleva ~86 días sin verificar; el umbral es 30. | Riesgo del proyecto, **sin doliente**: lo asigna quien firma. Hay que registrarlo con raid-taxonomy desde el primer día. |

Inconsistencia a aclarar: el supuesto lleva fecha 2026-07-21 dentro de una definición fechada 2025-11-26. Además, ningún documento nombra al proveedor ni el tiempo pactado.

## Restricciones normativas sin resolver
No se hizo barrido normativo. La definición no menciona datos personales, pagos ni otras obligaciones, pero una venta en línea suele tocarlas. **No se sabe si aplica ninguna; no se afirma que no.**

| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Sin determinar | Sin determinar | Sin determinar | Pendiente de barrido (`regulatory-sweep`) |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién aceptó REQ-4000 (el acta no registra decisor) | El proyecto arranca sobre una decisión que nadie firmó. | Gerente de producto / Comité de producto |
| Criterio de aceptación medible | Cierre imposible de juzgar; cada parte lo interpretará distinto. | Doliente (Mauricio Pérez) con el gerente de producto |
| Necesidad de REQ-4000 y título propio | No se sabe qué se construye ni para quién dentro del producto. | Doliente del requerimiento |
| Evidencia que nombre el requerimiento | La demanda es una cita general de un solo cliente, atribuida por el acta. | Gerente de producto |
| Autoridad declarada | Un gerente que no sabe qué decide escala todo o nada. | Quien firma el acta |
| Patrocinador y gerente del proyecto | Sin doliente del proyecto desde el día uno. | Quien tiene la autoridad para asignarlos |
| Éxito del producto en la definición | No hay contra qué medir el producto. | Gerente de producto |
| Doliente del supuesto del proveedor | El riesgo nace sin dueño. | Quien firma |
| Barrido normativo | Obligaciones sin descubrir hasta el proyecto. | Gerente de producto / área legal |
| Presupuesto e hitos | No declarados en ningún documento; la ficha nace sin ellos. | Quien firma |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (no está dicho quién). La ficha del proyecto se crea después de la firma. **No se creó ninguna ficha ni se corrió `portafolio.py init`.**

## Después
El gerente del proyecto, una vez asignado, instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella. Mientras tanto, el acta del comité del 2026-10-09 dice «Se mantiene el plan» y no hay ningún proyecto que ejecute REQ-4000.
