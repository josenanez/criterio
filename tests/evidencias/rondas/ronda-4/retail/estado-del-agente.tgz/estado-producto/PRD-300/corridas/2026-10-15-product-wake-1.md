# Corrida del 2026-10-15 · product-wake

PRD-300 · 16 requerimientos · 33 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_accepted_without_evidence` | 2 |
| `assumption_unverified` | 1 |

Primera corrida, sin corte previo: reporté el estado completo (3 propuestos sin decidir, 1 supuesto sin verificar, 13 aceptados sin traza). Con fichas en estado/records la traza sigue en 0 confirmadas. No leí el acta del comité del 2026-10-09 ni abrí las fichas una por una.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Venta en línea (PRD-300) · 2026-10-15

**Primera corrida del reloj: no hay corte anterior, así que no puedo separar lo nuevo de lo viejo.** Lo que sigue es el estado completo al hoy; desde la próxima corrida solo se reportará lo que cruce un umbral después de este corte.

Toca `review` (cada 30 días; nunca se había corrido). Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no registré nada nuevo.

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 d) | REQ-4003 | 205 días | Llevarlo al próximo comité para aceptar o descartar | Comité de producto (decide); Natalia Ospina (doliente) |
| Propuesto sin decidir | REQ-4005 | 160 días | Ídem; además no tiene evidencia de demanda | Comité de producto; Gustavo Neira |
| Propuesto sin decidir | REQ-4002 | 96 días | Ídem | Comité de producto; Mauricio Pérez |
| Supuesto sin verificar (umbral 30 d) | "El proveedor cumple el tiempo pactado" | 86 días | Un dato de cumplimiento del proveedor contra el plazo pactado; ya pasó el punto en que conviene tratarlo como riesgo registrado | María Restrepo |

### Las trazas
Hay 13 requerimientos aceptados y ninguno confirmado con proyecto. Recalculé con las fichas de `estado/records` (13 proyectos) y el resultado no cambió: 0 trazas confirmadas. No abrí las fichas una por una; me baso en el cálculo. Esto no prueba que nadie construya: dice que ninguna ficha lo confirma.

### Del descubrimiento
Ningún documento nuevo ni cambiado (4 de 4 sin cambios). No hay nada que releer. La evidencia de demanda más reciente es del 2025-11-24 y cumple 12 meses a fines de noviembre de 2026.

### Para el comité
- Aceptados sin evidencia de quien los pidió: REQ-4008, REQ-4011.
- Aceptados sin doliente: REQ-4004, REQ-4009.
- Aceptados sin criterio de aceptación: REQ-2028, REQ-4001, REQ-4004, REQ-4007.
- La definición no tiene criterio de éxito y el volumen mensual declarado (228.369) no tiene medición contra la que contrastarlo.

No leí el acta del comité del 2026-10-09; queda por verificar.

**Vuelvo el 2026-11-14.**
