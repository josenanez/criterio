# Corrida del 2026-10-15 · product-trace

PRD-300 · 16 requerimientos · 28 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_accepted_without_evidence` | 2 |
| `assumption_unverified` | 1 |

13 decididos y ninguno con proyecto; PRY-200 dice ejecutar 'venta en línea' y ningún REQ lo nombra

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Venta en línea (PRD-300) · al 2026-10-15
13 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Se pasó la carpeta de fichas (`estado/records`, 13 fichas). Ningún requerimiento nombra un proyecto, así que ninguna traza se puede confirmar: la cadena se rompe en el eslabón decisión → proyecto, en los 13.

### Decidido y nadie lo está construyendo
Ningún REQ aceptado tiene proyecto en `traces.project`. El campo «Por quién» (`decision.who`) está vacío en los 13: el acta no atribuye la decisión a una persona.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4009 | Requerimiento REQ-4009 | 2026-04-10 | no consta |
| REQ-4010 | Requerimiento REQ-4010 | 2026-05-05 | no consta |
| REQ-4008 | Requerimiento REQ-4008 | 2026-05-09 | no consta |
| REQ-4000 | Requerimiento REQ-4000 | 2026-05-16 | no consta |
| REQ-4001 | Requerimiento REQ-4001 | 2026-05-28 | no consta |
| REQ-4004 | Requerimiento REQ-4004 | 2026-06-02 | no consta |
| REQ-4011 | Requerimiento REQ-4011 | 2026-06-23 | no consta |
| REQ-4012 | Requerimiento REQ-4012 | 2026-06-26 | no consta |
| REQ-4007 | Requerimiento REQ-4007 | 2026-07-30 | no consta |
| REQ-4006 | Requerimiento REQ-4006 | 2026-08-09 | no consta |
| REQ-4013 | Requerimiento REQ-4013 | 2026-08-11 | no consta |
| REQ-2028 | Requerimiento REQ-2028 | 2026-09-24 | no consta |
| REQ-2036 | Requerimiento REQ-2036 | 2026-10-10 | no consta |

Fuente de las decisiones: `documentos/productos/PRD-300/30-decisiones/2026-10-09-comite-producto.docx` (p. ej. REQ-4000). El más antiguo lleva 188 días decidido (REQ-4009) sin proyecto.

Además, 3 requerimientos siguen propuestos sin decisión (REQ-4002 a 96 días, REQ-4005 a 160, REQ-4003 a 205); no entran en la traza porque aún no se decidieron.

### La traza no se confirma
Ninguna fila: no hay trazas declaradas que confirmar (`trace_not_confirmed` no aplica cuando el REQ no nombra proyecto).

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-200 Tienda en línea | `identity.product` = «venta en línea» (acta de constitución, 2025-07-09) | Sí: ningún REQ de PRD-300 nombra PRY-200 |

Cautela: la ficha de PRY-200 dice «venta en línea» por nombre, no con el código PRD-300, y su autoridad figura como no encontrada. Es muy probable que sea este producto, pero conviene confirmarlo con su gerente de proyecto antes de ligarlo. Si lo es, es probablemente el proyecto que debería cargar varios de los 13 decididos, y hoy el registro no lo sabe. Las demás fichas dicen otros productos (PRD-299, puntos de fidelización, pago con QR, autopago, entrega rápida, marca propia) o dejan el campo vacío (PRY-202, 203, 206, 209, 210, 211: hallazgo de esos proyectos, no de este producto).

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2028 | aceptado | 2026-09-24 | — | no | — |
| REQ-2036 | aceptado | 2026-10-10 | — | no | — |
| REQ-4000 | aceptado | 2026-05-16 | — | no | — |
| REQ-4001 | aceptado | 2026-05-28 | — | no | — |
| REQ-4004 | aceptado | 2026-06-02 | — | no | — |
| REQ-4006 | aceptado | 2026-08-09 | — | no | — |
| REQ-4007 | aceptado | 2026-07-30 | — | no | — |
| REQ-4008 | aceptado | 2026-05-09 | — | no | — |
| REQ-4009 | aceptado | 2026-04-10 | — | no | — |
| REQ-4010 | aceptado | 2026-05-05 | — | no | — |
| REQ-4011 | aceptado | 2026-06-23 | — | no | — |
| REQ-4012 | aceptado | 2026-06-26 | — | no | — |
| REQ-4013 | aceptado | 2026-08-11 | — | no | — |

Eslabón roto en todos: decisión → proyecto (sin cita de proyecto). Entregados: ninguno.

### Sin fichas a la vista
Se vieron las 13 fichas (PRY-199 a PRY-211). Ninguna ficha falta, pero como ningún REQ nombra un proyecto no hay traza que contrastar.

### Después
Hay 13 decididos sin proyecto: `/criterio-product:product-charter` para el que ya esté listo para serlo. Para PRY-200, la salida es una conversación con su gerente de proyecto.
