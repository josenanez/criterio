## Definición — Venta en línea (PRD-300) · contrastada al 2026-10-15
**Documento:** `00-definicion/2025-11-26-definicion-producto.md` (con `00-definicion/2025-11-26-caso-de-negocio.md`) · **del** 2025-11-26 · 5 afirmaciones sobre el mundo y 1 campo vacío (la propuesta)

**Términos:** ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Eso no significa que esté sostenida: ver más abajo.

### El negocio y los datos
Ninguna cifra pasa del umbral (20 %), porque ninguna tiene serie medida con la cual compararse. `claim_vs_metric` no produjo diferencias.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 228.369 | `00-definicion/2025-11-26-caso-de-negocio.md`, 2025-11-26 | `measured: null`. Nadie mide esta métrica. La fuente que cita la cifra es el propio caso de negocio, así que no tiene origen anterior. |
| «Retorno esperado en 24 meses» | `00-definicion/2025-11-26-caso-de-negocio.md`, 2025-11-26 | No trae cifra, solo un plazo; no hay nada que medir ni contra qué comparar. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara (`success: not_found`).
- **La propuesta.** La definición dice «Propuesta principal» y nada más. Es un marcador de posición, no una propuesta.
- **Qué cuenta el `volumen_mensual` de 228.369.** No dice unidad, ni de qué se mide. Además, la definición afirma que Empresas *no tiene* venta en línea; el documento no explica de dónde sale un volumen mensual para algo que hoy no existe.
- **De dónde sale el retorno esperado y con qué base.** Solo aparece el plazo de 24 meses.
- **Cuántas empresas tienen el problema.** La definición nombra el segmento, pero ningún documento lo dimensiona.
- **Cuánto pagarían o qué precio.** No aparece en ningún documento.
- **Qué proveedor y qué tiempo pactado.** El supuesto los da por sabidos; ningún documento los nombra.
- **Quién decide en el comité.** El acta del 2026-10-09 tiene un solo asistente (María Restrepo) y no dice quién decide. La autoridad «Comité de producto» queda sin confirmar.
- **A qué plan se refiere «Se mantiene el plan».** Ningún documento del producto contiene un plan.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado»; los 16 requerimientos están sin traza a proyecto.
- **El país.** No está en la configuración ni en los documentos; sin él no se puede situar lo normativo.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado el 2026-07-21) | **86** (umbral: 30) | Un documento que nombre al proveedor y el tiempo pactado (contrato, orden o cronograma firmado) y un registro de avance o de recibo contra esa fecha. Hoy ni el proveedor ni el tiempo están escritos, así que tal como está redactado todavía no se puede contrastar con nada. |

Dos observaciones sobre este supuesto: la definición está fechada el 2025-11-26, pero el supuesto dice declarado el 2026-07-21, de modo que el documento se editó después de su fecha y esa edición no queda versionada. Y por su peso en el producto (sin proveedor que cumpla no hay venta en línea) lleva casi tres meses sin verificar: es candidato a pasar a riesgo con doliente.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Hay una necesidad de venta en línea («Lo necesito y hoy no lo tengo») | `10-descubrimiento/2025-11-24-entrevistas.docx`, un cliente entrevistado | 2025-11-24 | **Débil.** Es lo que alguien dijo, no algo que haya pagado ni hecho; es una sola persona; y la entrevista no dice que sea del segmento Empresas. |

La afirmación «el segmento Empresas no tiene venta en línea» queda con esta única pieza. No hay evidencia de que otros la compartan.

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad de venta en línea | Entrevista del 2025-11-24 | 325 días (~10,7 meses). Aún no pasa el umbral de 12 meses; lo cruza el **2026-11-24** si no entra evidencia nueva. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Una venta en línea probablemente toca pagos y datos personales de los compradores | no declarado | — | — | **No tengo la norma a la vista.** Esto no es un cumplimiento ni un incumplimiento: sin país y sin norma citada no se puede decir nada más. Va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no está. **Sin él la definición no se puede cerrar**, porque el cierre se juzga contra él meses después.
- **Quién decide:** sin confirmar (el acta no lo dice).
- **Problema** y **para quién:** están declarados (venta en línea para el segmento Empresas), con la evidencia débil de arriba.

### Aviso de la ficha
Siete campos de `producto.json` (identidad, problema, quién, el supuesto y la autoridad) citan fuentes con la ruta `documentos/productos/PRD-300/...`, mientras que el índice de documentos las registra como `00-definicion/...` y `30-decisiones/...`. Los documentos existen, pero las citas no resuelven. Habría que corregir las rutas en la ficha; este comando no lo hace.

### Después
Ofrezco convertir el supuesto del proveedor (86 días) en un riesgo con doliente (`raid-taxonomy`). `/product-charter` queda para cuando la definición tenga criterio de éxito y autoridad confirmada.
