## Listo — Venta en línea (PRD-300)

Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

**Lo lei:** 4 documentos · 1 de descubrimiento (una entrevista del 2025-11-24, un solo cliente, una sola frase) · definición y caso de negocio del 2025-11-26 · lo más reciente: acta del comité de producto del 2026-10-09. Formatos que no pude leer: ninguno (.docx leídos como texto).
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.10 (términos 1.1), 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 fdf0177cc54e5055… (md).
**Preguntas:** 4, ninguna respondida (sesión sin interfaz); tomé lo sugerido: gerente María Restrepo (definición); quién decide = «Comité de producto» (del acta; el acta no dice quién decide dentro de él, sin confirmar); estado en `estado-producto/PRD-300` (hermana de `documentos/`, no `estado/`).

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Empresas no tiene venta en línea» | Solo la propia definición. La entrevista dice «Lo necesito y hoy no lo tengo», sin nombrar segmento ni Empresas | 2025-11-26 / 2025-11-24 |
| Volumen mensual 228.369 | Solo el caso de negocio; ninguna serie medida a la vista | 2025-11-26 |
| «Retorno esperado en 24 meses» | Sin cifra, sin cálculo, sin fuente | 2025-11-26 |
| «Propuesta principal» | Es un marcador: la propuesta no está escrita | 2025-11-26 |
| El proveedor cumple el tiempo pactado | Supuesto declarado, sin verificar (86 días) | 2026-07-21 |

### Lo que no está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo dice.
- **De dónde sale 228.369 al mes** y qué mide: nadie está midiendo la cifra que el negocio afirmó (no hay serie).
- **Cuánto es el retorno** y contra qué inversión; solo se dice «24 meses».
- **Qué se propone construir.**
- **Quién decide** dentro del comité: el acta tiene un solo asistente (María Restrepo) y no nombra decisor.
- **Qué proyecto construye esto:** la definición dice «Ninguno declarado» y los 16 requerimientos tienen «—» como proyecto.
- **Qué proveedor** es el del supuesto, y qué tiempo se pactó.

### Supuestos sobre los que está escrita
Uno: «El proveedor cumple el tiempo pactado», declarado el 2026-07-21, sin verificar, 86 días.

### Requerimientos levantados del acta del 2026-10-09 (16)
13 aceptados · 3 propuestos · con evidencia 11 (84,6 %) · con proyecto 0 (0,0 %).
- 13 aceptados sin proyecto que los ejecute.
- 4 aceptados sin criterio de aceptación: REQ-2028, REQ-4001, REQ-4004, REQ-4007.
- 2 aceptados sin evidencia (el acta no dice quién los pidió): REQ-4008, REQ-4011.
- 2 aceptados sin doliente («sin asignar»): REQ-4004, REQ-4009.
- 3 propuestos sin decidir: REQ-4003 (205 días), REQ-4005 (160), REQ-4002 (96).
- La evidencia de los 11 es la misma frase de la misma entrevista; el acta la atribuye a «Cliente entrevistado», pero la entrevista no nombra ningún requerimiento. La registré así, con esa salvedad.
- Los títulos son «Requerimiento REQ-xxxx» y no hay texto de la necesidad: quedó `not_found`.
- REQ-2028 y REQ-2036 tienen otra numeración (20xx) y REQ-2036 figura «desde» 2026-10-10, un día después del acta del 2026-10-09. No lo resolví; lo anoto.
- El acta no registra quién decidió ni cuándo se aceptó (usé «Desde» como fecha) y su única decisión es «Se mantiene el plan», sin decir qué plan.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: las transcripciones completas de las entrevistas (hay una sola, de una frase); la serie medida del volumen mensual con su fuente; el texto de cada requerimiento; y las decisiones del comité con quién decide, para distinguir un requerimiento descartado de uno que nadie miró.

### Después
Cuando tengas más entrevistas, `/product-discovery` convierte los temas en requerimientos con la cita de quién lo pidió.
