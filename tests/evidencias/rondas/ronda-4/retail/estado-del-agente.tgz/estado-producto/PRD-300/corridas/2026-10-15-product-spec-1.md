# Corrida del 2026-10-15 · product-spec

PRD-300 · 16 requerimientos · 39 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_without_acceptance` | 4 |
| `requirement_undecided` | 3 |
| `requirement_without_owner` | 2 |
| `requirement_accepted_without_evidence` | 2 |
| `assumption_unverified` | 1 |

Borrador de especificación: 13 aceptados en alcance, 0 con comportamiento especificado porque ningún registro dice su necesidad; 9 criterios 'se verifica en producción' no verificables, 4 sin criterio; sin norma ni país a la vista (no tengo la norma a la vista).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

> **Borrador.** Lo escribe el agente; lo cierra María Restrepo (gerente de producto), con la firma que este agente no puede dar.

# Especificación — Venta en línea (PRD-300) · borrador del 2026-10-15

**Qué problema resuelve.** La definición (`00-definicion/2025-11-26-definicion-producto.md`) dice solo: «El segmento Empresas no tiene venta en línea». La propuesta es «Propuesta principal», sin más. No dice quién compra, qué se vende, cómo se paga ni qué es éxito (no trae criterio de éxito).

**Resultado central:** ningún requerimiento aceptado dice qué necesita (`need` = no está dicho en ninguna parte en los 16 registros; todos los títulos son «Requerimiento REQ-xxxx»). Escribir comportamiento sería inventarlo, así que **la sección Comportamiento queda vacía a propósito.** Lo que sí sale del registro está abajo.

## Alcance
### Entra
Los 13 requerimientos en estado `aceptado` según el acta del comité del 2026-10-09 (`30-decisiones/2026-10-09-comite-producto.docx`): REQ-4000, 4001, 4004, 4006, 4007, 4008, 4009, 4010, 4011, 4012, 4013, 2028, 2036. Ninguno está `en_construccion`.
Se entra solo por el nombre: de ninguno se puede decir qué entrega.

### No entra
- REQ-4002, REQ-4003, REQ-4005: `propuesto`; nadie los ha decidido (96, 205 y 160 días). No se especifica lo que nadie decidió.
- Todo lo que la definición no menciona: medios de pago, país, catálogo, logística, integraciones. No está dicho en ninguna parte; no se supone.
- Diseño, estimación, costo y fechas: no son de este documento.

## Comportamiento
Sin contenido. Los 13 aceptados tienen `need` sin valor; el acta tampoco lo trae (solo columnas ID, doliente, criterio, quién lo pidió, estado, desde). Cerrar: cada doliente escribe el problema en sus palabras.

## Criterios de aceptación
Nueve aceptados traen el mismo texto, «se verifica en producción» (acta 2026-10-09). **No pasa la prueba:** dos personas mirando lo construido no pueden llegar a una respuesta, porque no dice qué se verifica ni contra qué umbral. No se reescribió como un número, porque cualquier número sería del agente.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4000, 4006, 4008, 4009, 4010, 4011, 4012, 4013, 2036 | No definido: falta qué se observa y con qué umbral | No: no es verificable todavía (hallazgo) |
| — (sin criterio) | REQ-4001, 4004, 4007, 2028 | — | — |

Además: no hay evidencia de que la organización mida algo hoy sobre venta en línea; el volumen declarado (228.369 mensual, caso de negocio 2025-11-26) no tiene medición con la que contrastarlo.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (definición; declarado 2026-07-21) | No; 86 días sin verificar (umbral 30). Ya es un riesgo sin registrar. Además, la definición no dice qué proveedor ni qué tiempo | María Restrepo (valorar y registrar como riesgo); quién verifica: no está dicho |
| Volumen mensual 228.369 (caso de negocio) | Sin medición | María Restrepo |
| Los requerimientos individuales no declaran supuestos | — | Cada doliente |

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada uno de los 13 aceptados (`need`) | No hay nada que especificar; la especificación sería inventada | Cada doliente (ver abajo) |
| Criterio de aceptación verificable en los 9 con «se verifica en producción» | Nadie podrá decir si se construyó bien | Los dolientes: Mauricio Pérez (4000, 4013), Ricardo Salas (4006), Camilo Beltrán (4008), Andrés Lozano (4010), Sandra Gil (4011), Gustavo Neira (4012), Rubén Cárdenas (2036); REQ-4009 sin doliente |
| Criterio ausente en REQ-4001 (Sandra Gil), 4004 (sin doliente), 4007 (Mauricio Pérez), 2028 (Rubén Cárdenas) | Aceptados sin criterio | Cada doliente; 4004 lo asigna María Restrepo |
| Doliente de REQ-4004 y REQ-4009 («sin asignar») | Nadie responde por ellos | María Restrepo, nombrando una persona |
| Quién pidió REQ-4008, REQ-4011 (y 4005, propuesto) | Se construirían sin una sola cita de quien lo pidió | Camilo Beltrán, Sandra Gil: aportar evidencia o volver al Comité de producto |
| La evidencia de los demás es una sola entrevista (2025-11-24, «Lo necesito y hoy no lo tengo.») que no nombra ningún requerimiento; el acta la atribuye a «Cliente entrevistado» | La demanda no está sostenida requerimiento por requerimiento; cumple 12 meses el 2026-11-24 | María Restrepo / dolientes |
| Quién decidió cada aceptación: el acta registra «Desde» pero no quién decidió ni documento propio; asistente único: María Restrepo; decisión del acta: «Se mantiene el plan» | Decisiones sin respaldo individual | Comité de producto |
| REQ-2036 figura «desde» 2026-10-10, posterior al acta (2026-10-09); REQ-2028 y REQ-2036 tienen otra numeración (20xx) y no se verificó que sean de este producto | Posible requerimiento ajeno o fecha errada | María Restrepo / Rubén Cárdenas |
| Proyecto que ejecuta cada requerimiento: la columna del acta está en «—» y no hay fichas de proyecto | 13 decididos sin quién los construya (o sin confirmar) | María Restrepo; seguir con `/product-trace` |
| Casos borde (sin conexión, pago duplicado, abandono antes de confirmar, etc.) | No definidos; la definición no habla de pagos | Dolientes, una vez exista el `need` |
| **Otros equipos:** la definición declara «Ninguno» como proyectos que lo construyen y menciona un proveedor sin nombre. Lo que otros equipos o el proveedor deban hacer no está acordado en ningún documento | Dependencias ocultas | María Restrepo |
| **Obligaciones normativas:** la definición no dice país ni qué datos o pagos maneja. Una venta en línea para Empresas probablemente toca datos personales, medios de pago, protección al consumidor y retención/trazabilidad, pero **no tengo la norma a la vista** ni el país; no se cita ninguna | Posible incumplimiento descubierto con el producto construido | María Restrepo con revisión jurídica; estado: `no tengo la norma a la vista` |

## Requerimientos aceptados que esta especificación no cubre
Todos, en cuanto a comportamiento; por la misma razón: `need` no está dicho en ninguna parte.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4000, 4006, 4009, 4010, 4012, 4013 | Requerimiento REQ-xxxx | Sin necesidad escrita; criterio no verificable |
| REQ-4001, 4007, 2028 | Ídem | Sin necesidad escrita; sin criterio |
| REQ-4004 | Ídem | Sin necesidad, sin criterio, sin doliente |
| REQ-4008, 4011 | Ídem | Sin necesidad, criterio no verificable, sin evidencia de quién lo pidió |
| REQ-2036 | Ídem | Sin necesidad; criterio no verificable; fecha posterior al acta; numeración ajena |

---
Registro: `estado-producto/PRD-300/requirements/` · acta del 2026-10-09 · registro de requerimientos al 2026-10-15 · cubre 0 de los 13 aceptados en comportamiento (13 en alcance, 3 propuestos fuera). Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal (aceptados por José Francisco Ñáñez, versión 0.3.10, 2026-10-15).

**Después:** no corresponde `/product-charter` todavía: los vacíos no están cerrados y el producto no tiene criterio de éxito. Antes, `/product-trace` por los 13 decididos sin proyecto.
