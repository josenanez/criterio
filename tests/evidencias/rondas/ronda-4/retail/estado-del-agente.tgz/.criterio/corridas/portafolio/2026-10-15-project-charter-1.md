# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-201 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-15T20:25:35 · **Fin:** 2026-10-15T20:26:16 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 24 | 56 | Revisión del acta de PRY-201 (2025-07-07). Faltan autoridad del gerente, supuestos y restricciones, hitos, cadencia del comité y criterio de éxito medible. Alcance y exclusiones son marcadores. Cierre 2026-06-11 vencido sin replanificación aprobada. No sabe por qué se movió el cierre ni cómo se explica 78% de avance con 17% ejecutado. |

Por señal (`project-charter`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**Revisión del acta de PRY-201 · Programa de fidelización** (acta del 2025-07-07, modo revisar)

Los términos estaban vigentes. José Francisco Ñáñez los aceptó el 2026-10-15 para la versión 0.3.10, así que no hubo que registrar nada nuevo.

**Qué falta y qué consecuencia tiene**
- **Autoridad de la gerente:** no está en ningún documento. Por eso no se sabe si María Restrepo podía decidir la CC-01 (+118.000.000 COP, +59 días, ampliación de alcance) o si debía subirla. Lleva pendiente de presentar al comité desde el 2026-10-04.
- **Línea base:** el cierre comprometido (2026-06-11) ya pasó y el informe del 2026-10-10 sigue en curso. La CC-01 habla de "+59 días sobre la línea base vigente", pero la única línea base registrada es la original. No hay ninguna replanificación aprobada.
- **Objetivo:** describe la solución ("Entregar programa de fidelización"), no un resultado de negocio medible.
- **Alcance y exclusiones:** son marcadores ("Componente 1, 2 y 3"; "Lo que otro proyecto cubre"). No sirven para medir ni para rechazar una ampliación.
- **Supuestos, restricciones, hitos y cadencia del comité:** no están. Los dos riesgos del informe, el congelamiento de fin de año y el conocimiento concentrado en una persona, nacen de restricciones que el acta no declara.
- **Criterio de éxito:** "en producción y medido" no tiene métrica ni dice quién mide.
- **Patrocinador:** cumple (Óscar Ramírez).

**Lo que no se puede afirmar:** el informe declara Rojo y 78 % de avance con solo el 17 % del presupuesto ejecutado. Ningún documento explica esa relación. Tampoco hay documento que diga por qué se movió el cierre.

**Siguiente paso que propongo:** llevar la definición de la autoridad del gerente al Comité de Transformación Digital junto con la CC-01, y pasar los supuestos y restricciones no declarados al registro RAID con `/raid-log`.

La salida completa quedó en `/home/claude/banco/ronda-4/retail/espacio/estado/corridas/salida-project-charter.md`. La corrida quedó registrada como `2026-10-15-project-charter-1`, con 24 segundos medidos.

El registro de la corrida muestra cifras de las 13 carpetas del portafolio, no solo de PRY-201. Las señales de PRY-201 salen vacías en esa tabla.
