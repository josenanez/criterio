# Corrida · 2026-10-15-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T20:31:03 · **Fin:** 2026-10-15T20:31:53 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 35 | 56 | Barrido: 66 docs sin cambios, nada que releer. Citas de PRY-209 reportadas como no resueltas por desajuste de ruta (archivos existen). Confirmación: 5 campos preguntados sin respuesta (sesión sin interfaz). No pude saber qué se habló fuera de los documentos. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Hoy tocaban el barrido y la confirmación. En el barrido, ninguno de los 66 documentos cambió, así que no recalculé ningún proyecto. En la confirmación no pude hacer las preguntas a nadie (sesión sin interfaz).

- **Términos:** ya estaban vigentes (v1.1, aceptados el 2026-10-15 por José Francisco Ñáñez), así que no los registré de nuevo.
- **Peticiones:** no había ninguna en el servidor.
- **Hallazgos en PRY-209 (Migración del ERP), con lo que ya tenía la ficha:**
  - **Hito vencido:** «Ambiente de pruebas certificado» tenía fecha 2026-10-05 y sigue pendiente, 10 días después.
  - **Avance contra dinero:** el informe declara 75 % de avance, pero lo ejecutado es el 28 % del presupuesto aprobado (COP 1.935.274.876 de 6.800.000.000), y solo uno de los cuatro hitos está cumplido.
  - **Compromisos vencidos:** hay hallazgos de compromisos vencidos y reprogramados en PRY-209, que no revisé.
- **Citas rotas:** el índice marca como no encontradas las citas de PRY-209, aunque los archivos existen en la carpeta del proyecto. Parece un desajuste de ruta: las citas son relativas a la carpeta del proyecto y el índice las busca desde la raíz de documentos. Lo dejé como hallazgo y no lo corregí.
- **Confirmación:** elegí cinco campos de PRY-209 (estado, avance, fecha del hito vencido, proyección de costo y fecha de fin) y los dejé como «preguntados el 2026-10-15, sin respuesta». Tomé la respuesta sugerida, mantener el valor sin marcarlo como confirmado.
- **Registro:** dejé constancia del barrido y de la confirmación, y la corrida quedó registrada con la salida completa en `estado/corridas/salida-portfolio-wake.md`.

Vuelvo el 2026-10-16.
