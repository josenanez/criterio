# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T20:16:05 · **Fin:** 2026-10-15T20:16:36 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 17 | 56 | 66 documentos sin cambio, 0 por releer. 146 citas de PRY-209 sin resolver aunque los 7 archivos existen; hipótesis (no verificada): normalización de la tilde en la ruta. |

Por señal (`document-index`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

**Documentos:** 66 · **Sin cambio:** 66 · **Hay que releer:** 0

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

- **Contenido, reguardados, renombrados y borrados:** ninguno en ninguna de las cuatro categorías.
- **Citas que no resuelven:** el índice marca 146 citas de PRY-209 (migración del ERP) como fuente no encontrada. Cubren identidad, plan, hitos, dinero, RAID y 26 compromisos.
  - **Qué documentos citan:** son 7 documentos: el acta de constitución, el cronograma v1, el informe de avance del 15-oct, el acta de recibo del diseño de la experiencia, los comités semanales del 3-sep al 8-oct y las notas del 15-oct.
  - **Qué pasa con esos archivos:** los 7 existen en la carpeta del proyecto y no figuran como borrados ni renombrados, así que no se perdió ningún documento.
  - **Causa probable:** las citas no se están resolviendo contra la ruta real, quizá por la tilde de «migración» en el nombre de la carpeta. Es una hipótesis y no la verifiqué.
  - **Efecto:** mientras no se resuelva, esos datos de PRY-209 aparecen como sustentados y el índice no puede confirmarlo.
- **Formatos ilegibles:** ninguno reportado.
- **Siguiente paso:** no hay documentos por releer, así que no ofrezco `/portfolio-scan`. Conviene revisar por qué las citas de PRY-209 no resuelven antes de confiar en esa ficha. No corregí ninguna.

La corrida quedó registrada como `2026-10-15-document-index-1`, con la salida guardada en `estado/corridas/salida-document-index.md`.
