# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view puntos de fidelización

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T20:29:07 · **Fin:** 2026-10-15T20:29:46 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 23 | 56 | Producto de un solo proyecto (PRY-201): sin sección de producto. 0 alertas pero fecha 2026-06-11 vencida, rojo declarado 78 %, sin hitos ni evidencia; atraso real no calculable. 6 proyectos sin producto reportados. |

Por señal (`product-view`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Producto: puntos de fidelización, al 2026-10-15

Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.10), así que no los registré de nuevo. Las cifras salen del cálculo de hoy sobre las fichas.

**Este producto tiene un solo proyecto, PRY-201 Programa de fidelización.** La vista por producto no aporta nada con un solo proyecto, así que no armé una sección de producto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| puntos de fidelización | 1 (PRY-201) | 0 | 2026-06-11 | COP 6.800.000.000 | COP 4.342.015.470 |

**El cero de alertas no significa que esté bien.**
- **Fecha vencida:** la fecha de fin ya pasó. El proyecto declara 78 % de avance y estado rojo, en un informe del 2026-10-10.
- **Sin hitos:** la ficha no tiene hitos, y la línea base coincide con la vigente. Por eso el script no puede medir atraso, y no escribo cuánto lleva. El cero es falta de plan medible.
- **Sin evidencia:** ningún dato de la ficha tiene evidencia propia (0 con evidencia, 2 declaraciones, 15 sin marcar). Los datos de identidad y plan vienen de un documento del 2025-07-07, con 15 meses de antigüedad.

**Dinero** (las cuatro cifras vienen completas):
- Ejecutado: COP 1.176.506.415 (17,3 %).
- Comprometido: 63,9 %.
- Proyección: COP 6.315.003.234, que es 7,1 % por debajo de lo aprobado.
- Disponible real: COP 2.457.984.530.

**Otros datos de la ficha:**
- Sin dependencias, sin proveedores y una solicitud de cambio, sin impacto en tiempo.
- Faltan la autoridad y la fase.

**Seis proyectos no declaran producto:** PRY-202, 203, 206, 209, 210 y 211. Nadie responde por el conjunto al que sirven. No sé si alguno sirve a fidelización. Además, PRY-199 declara «PRD-299», que es un código y no un nombre, y no se pudo cruzar con ningún otro producto.

**No sé** la causa del rojo ni el atraso real frente a la fecha. La verificación es suya.

Dejé la salida en `estado/corridas/salida-product-view.md` y registré la corrida como `2026-10-15-product-view-1`.
