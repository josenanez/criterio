# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-15T20:19:48 · **Fin:** 2026-10-15T20:20:31 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 27 | 56 | Presupuesto de PRY-204: cuatro cifras de un solo informe declarado (2026-09-26), proyección excede el aprobado 11.8%, comprometido 74.5% bajo umbral. Dijo que no sabe: aprobado original del acta, evidencia contable, proveedores, autoridad. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Presupuesto — PRY-204 Cajas de autopago al 2026-10-15

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los volví a registrar. Las cifras salen de `compute` y de la ficha de PRY-204. Todo es en COP; no hay otra moneda ni conversión.

| | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 1200000000 | — |
| Comprometido | 894302033 | 74.5 |
| Ejecutado | 501728889 | 41.8 |
| Proyección al cierre | 1342154042 | excede el aprobado en 11.8 |

- **Fuente de las cuatro cifras:** el informe de avance del 2026-09-26, que es una declaración del gerente. Ningún documento contable las respalda.
- **Disponible real** (aprobado menos comprometido): 305697967.
- **Contra la línea base:** el aprobado y la fecha de cierre (2027-02-16) no se han movido. Hay 0 replanificaciones y 0 solicitudes de cambio.
- **Ejecución frente a avance:**
  - Ejecutado 41.8%; hitos cumplidos 2 de 4, y solo 1 tiene evidencia.
  - El avance declarado es 32%, y el plan sostiene entre 50% y 75%.
  - El gasto no está muy por encima del avance de hitos; lo que no cuadra es que el avance va 18 puntos atrás.
- **Alertas:**
  - La proyección excede el aprobado en 11.8%, sobre el umbral de 10%.
  - El comprometido (74.5%) está bajo el umbral de 90%.
  - El informe declara "verde", pero ese mismo informe trae la proyección sobre el aprobado.
  - Hay dos incidencias abiertas sin dueño: un hallazgo de seguridad en los medios de pago y una prueba de carga que se repite. Ninguna trae estimación de costo.
- **Sin dato:**
  - El aprobado original del acta de constitución.
  - Evidencia contable.
  - Proveedores, porque la ficha no registra ninguno.
  - La autoridad que aprobó el presupuesto.

Como la proyección excede el aprobado, puedo preparar la solicitud de cambio con `change-control`. No ofrezco el detalle por proveedor porque no hay proveedores.

La salida completa quedó en `estado/corridas/salida-budget-tracking.md`. La corrida quedó registrada como `2026-10-15-budget-tracking-1`.
