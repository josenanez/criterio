# Corrida · 2026-10-15-vendor-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:vendor-tracking PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-15T20:20:37 · **Fin:** 2026-10-15T20:21:31 · **Duración:** 54 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `vendor-tracking` | 13 | — | 38 | 56 | Cruce contrato CT-345 / factura FV-1345 / entregables de PRY-203. 4 entregables atrasados sin acta de recibo, factura radicada sin entrega, estado declarado verde. No supo: vigencia, renovación y preaviso del contrato, a qué entregable corresponde la factura, compromisos del proveedor (no hay actas de reunión). |

Por señal (`vendor-tracking`): `milestone_met_without_evidence` 18, `commitment_overdue` 9, `progress_vs_plan` 8, `declared_vs_evidence` 5, `vendor_deliverable_late` 5, `variance_cost` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `vendor_invoiced_without_delivery` 1, `milestone_overdue` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

**PRY-203: los 4 entregables de Retail Andino Consultores (contrato CT-345) siguen sin acta de recibo, y aun así hay una factura radicada y el informe de avance declara el proyecto en verde.**

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los volví a registrar. Las cifras salen de `portafolio.py compute` y de los documentos del proyecto, que son el contrato, la factura, el informe de avance y el cronograma.

- **Entregables:** los cuatro (licenciamiento, bolsa de horas, configuración del catálogo y soporte del primer trimestre) siguen pendientes. Llevan entre 296 y 425 días de atraso y ninguno tiene evidencia de recibo ni está aceptado. El contrato los muestra "en curso".
- **Factura sin entrega:** la factura FV-1345 es del 2026-08-26, por 459.463.652 COP, y está radicada en cuentas por pagar. El contrato exige un acta de recibo firmada por el gerente del proyecto, y no hay ninguna en la carpeta. La factura vale lo mismo que un solo entregable, pero su concepto es "Entregables del contrato CT-345" y no dice cuál cubre.
- **Estado declarado:** el informe del 2026-10-07 dice verde y 47 % de avance. El cronograma marca los 5 hitos como cerrados, ninguno con evidencia, y respalda 100 %, una brecha de 53,0 puntos.

No pude determinar la vigencia del contrato, la renovación ni el preaviso, porque el contrato solo trae la fecha de firma. Tampoco hay carpeta de reuniones en el proyecto, así que no puedo decir si el proveedor tiene compromisos vencidos. Dejé ambos vacíos declarados en el informe.

Si la factura aún no se ha pagado, conviene frenarla hasta que haya acta de recibo. Si ya se pagó, es un hallazgo para comité. Los documentos no dicen cuál de los dos casos es. Puedo llevarlo al comité del 2026-10-29.

La corrida quedó registrada como `2026-10-15-vendor-tracking-1` y duró 38 segundos.

Archivos en `/home/claude/banco/ronda-4/retail/espacio/estado/corridas/`:
- `salida-vendor-tracking.md`
