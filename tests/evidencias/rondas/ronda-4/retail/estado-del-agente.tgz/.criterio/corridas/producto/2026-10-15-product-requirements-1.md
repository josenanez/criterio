# Corrida · 2026-10-15-product-requirements-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-requirements (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:54:16 · **Fin:** 2026-10-15T19:54:59 · **Duración:** 42 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-requirements` | 16 | — | 25 | 25 | REQ-4008 y REQ-4011 aceptados sin evidencia; REQ-4003, 4005 y 4002 sin decidir; REQ-4004 y 4009 sin doliente; 13 sin proyecto confirmado (carpeta de fichas vacía) |

Por señal (`product-requirements`): `requirement_untraced` 13, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_without_owner` 2, `requirement_accepted_without_evidence` 2, `assumption_unverified` 1

## Lo que el agente mostró

## Registro — Venta en línea (PRD-300) · al 2026-10-15
Hay 16 requerimientos, 13 decididos, 84.6% con evidencia y 0% con proyecto que los ejecute.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no registré nada nuevo. La carpeta de fichas de proyecto (`estado/`) está vacía. Por eso el 0% significa que ninguna ficha lo confirma, no que nadie esté construyendo.

**Se va a construir y nadie lo pidió.** REQ-4008 (Camilo Beltrán) y REQ-4011 (Sandra Gil) están aceptados sin ninguna evidencia de quien los pidió.

**Decidido y nadie lo está construyendo.** Los 13 aceptados quedan sin proyecto confirmado, de REQ-4009 (2026-04-10) a REQ-2036 (2026-10-10).

**Sin doliente.** REQ-4004 y REQ-4009. María Restrepo, la gerente de producto, nombra una persona para cada uno.

**Sin criterio de aceptación.** REQ-2028, REQ-4001, REQ-4004 y REQ-4007, todos decididos.

**Decidido sin documento que lo respalde.** No lo calculé, porque el script no cruza cada decisión contra un acta. El acta del comité `2026-10-09-comite-producto.docx` existe y no la leí en esta corrida, así que queda por verificar.

**Lleva meses y nadie lo decide.** El umbral son 60 días y la facultad de decidir es del Comité de producto, que se reúne cada mes. Se propone llevar los tres al próximo comité para aceptarlos o descartarlos:
- REQ-4003, 205 días.
- REQ-4005, 160 días. Tampoco tiene evidencia, pero como está propuesto no se le exige.
- REQ-4002, 96 días.

**Evidencia vieja.** Sin hallazgos. Lo más reciente es del 2025-11-24, dentro del umbral de 12 meses, que se cumple a fines de noviembre de 2026.

**De la definición, fuera del registro:**
- El supuesto "El proveedor cumple el tiempo pactado" lleva 86 días sin verificar.
- El volumen mensual declarado (228,369) no tiene medición con la que contrastarlo.
- No hay criterio de éxito.

| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

Siguiente paso sugerido: `/product-trace`, por los 13 decididos sin proyecto confirmado.

La corrida quedó registrada como `2026-10-15-product-requirements-1` (25 hallazgos, 25 segundos). La salida completa está en `estado-producto/PRD-300/corridas/salida-product-requirements.md`.
