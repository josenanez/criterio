# Entrevistas · Crédito hipotecario digital

**Ronda:** Ronda · 2026-01-06
**Realizadas por:** Gustavo Neira

### Cliente entrevistado · 2026-01-06

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
