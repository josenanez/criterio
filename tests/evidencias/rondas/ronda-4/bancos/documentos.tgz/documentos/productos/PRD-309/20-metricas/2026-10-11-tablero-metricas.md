# Tablero de métricas · Crédito de libre inversión

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 85.140 | 2026-10-11 |
