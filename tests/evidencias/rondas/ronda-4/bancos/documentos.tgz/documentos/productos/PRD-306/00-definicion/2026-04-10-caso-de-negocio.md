# Caso de negocio · Microseguros

**Código:** PRD-306
**Fecha:** 2026-04-10
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 91.728 | Caso de negocio, 2026-04-10 |

## Retorno esperado

Retorno esperado en 24 meses.
