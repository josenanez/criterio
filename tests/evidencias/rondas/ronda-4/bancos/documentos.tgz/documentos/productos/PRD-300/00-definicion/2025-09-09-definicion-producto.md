# Definición de producto · Pagos QR comercios

**Código:** PRD-300
**Gerente de producto:** Paula Céspedes
**Segmento:** Empresas
**Fecha de la definición:** 2025-09-09

## El problema

El segmento Empresas no tiene pagos qr comercios.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-09-11 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
