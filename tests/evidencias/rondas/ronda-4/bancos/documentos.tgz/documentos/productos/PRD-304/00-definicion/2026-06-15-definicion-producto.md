# Definición de producto · Tarjeta de crédito digital

**Código:** PRD-304
**Gerente de producto:** Jorge Medina
**Segmento:** Personas
**Fecha de la definición:** 2026-06-15

## El problema

El segmento Personas no tiene tarjeta de crédito digital.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-09-11 · verificado

## Proyectos que lo construyen

- Ninguno declarado
