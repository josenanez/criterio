# Caso de negocio · Recaudos y cobros

**Código:** PRD-305
**Fecha:** 2025-12-27
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 133.614 | Caso de negocio, 2025-12-27 |

## Retorno esperado

Retorno esperado en 24 meses.
