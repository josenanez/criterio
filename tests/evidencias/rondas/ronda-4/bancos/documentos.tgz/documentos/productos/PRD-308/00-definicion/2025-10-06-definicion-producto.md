# Definición de producto · Cuenta de ahorros joven

**Código:** PRD-308
**Gerente de producto:** Elena Duarte
**Segmento:** Empresas
**Fecha de la definición:** 2025-10-06

## El problema

El segmento Empresas no tiene cuenta de ahorros joven.

## La propuesta

- Propuesta principal

## Supuestos

- **La regulación vigente lo permite** · declarado el 2026-07-31 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
