# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-05

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 117.055 | 2026-10-05 |
