# Entrevistas · Cuenta de ahorros joven

**Ronda:** Ronda · 2026-06-24
**Realizadas por:** Elena Duarte

### Cliente entrevistado · 2026-06-24

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
