# Entrevistas · Tarjeta de crédito digital

**Ronda:** Ronda · 2026-01-26
**Realizadas por:** Jorge Medina

### Cliente entrevistado · 2026-01-26

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
