# Caso de negocio · Crédito hipotecario digital

**Código:** PRD-302
**Fecha:** 2025-10-31
**Preparado por:** Gustavo Neira

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 88.223 | Caso de negocio, 2025-10-31 |

## Retorno esperado

Retorno esperado en 24 meses.
