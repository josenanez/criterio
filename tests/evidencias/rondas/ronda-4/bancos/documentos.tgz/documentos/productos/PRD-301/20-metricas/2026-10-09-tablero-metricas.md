# Tablero de métricas · Nómina empresarial

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 239.237 | 2026-10-09 |
