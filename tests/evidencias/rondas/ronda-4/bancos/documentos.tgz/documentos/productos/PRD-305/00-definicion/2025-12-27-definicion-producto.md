# Definición de producto · Recaudos y cobros

**Código:** PRD-305
**Gerente de producto:** Felipe Arango
**Segmento:** PyME
**Fecha de la definición:** 2025-12-27

## El problema

El segmento PyME no tiene recaudos y cobros.

## La propuesta

- Propuesta principal

## Supuestos

- **El segmento paga por esto** · declarado el 2026-05-27 · verificado

## Proyectos que lo construyen

- Ninguno declarado
