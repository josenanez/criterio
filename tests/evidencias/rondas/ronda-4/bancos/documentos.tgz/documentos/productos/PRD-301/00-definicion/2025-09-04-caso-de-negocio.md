# Caso de negocio · Nómina empresarial

**Código:** PRD-301
**Fecha:** 2025-09-04
**Preparado por:** Laura Vélez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 232.538 | Caso de negocio, 2025-09-04 |

## Retorno esperado

Retorno esperado en 24 meses.
