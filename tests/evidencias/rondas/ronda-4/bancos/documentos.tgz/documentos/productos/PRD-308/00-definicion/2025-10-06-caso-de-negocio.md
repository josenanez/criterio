# Caso de negocio · Cuenta de ahorros joven

**Código:** PRD-308
**Fecha:** 2025-10-06
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 138.077 | Caso de negocio, 2025-10-06 |

## Retorno esperado

Retorno esperado en 24 meses.
