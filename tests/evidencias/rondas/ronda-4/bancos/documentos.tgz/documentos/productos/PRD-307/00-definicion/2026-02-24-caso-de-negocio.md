# Caso de negocio · Remesas familiares

**Código:** PRD-307
**Fecha:** 2026-02-24
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 111.527 | Caso de negocio, 2026-02-24 |

## Retorno esperado

Retorno esperado en 24 meses.
