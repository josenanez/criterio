# Definición de producto · Microseguros

**Código:** PRD-306
**Gerente de producto:** Diana Molina
**Segmento:** PyME
**Fecha de la definición:** 2026-04-10

## El problema

El segmento PyME no tiene microseguros.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-06-20 · verificado

## Proyectos que lo construyen

- Ninguno declarado
