# Caso de negocio · Pagos QR comercios

**Código:** PRD-300
**Fecha:** 2025-09-09
**Preparado por:** Paula Céspedes

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 61.684 | Caso de negocio, 2025-09-09 |

## Retorno esperado

Retorno esperado en 24 meses.
