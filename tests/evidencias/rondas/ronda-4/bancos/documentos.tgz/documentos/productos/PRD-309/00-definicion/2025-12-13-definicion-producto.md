# Definición de producto · Crédito de libre inversión

**Código:** PRD-309
**Gerente de producto:** Mauricio Pérez
**Segmento:** Microcomercio
**Fecha de la definición:** 2025-12-13

## El problema

El segmento Microcomercio no tiene crédito de libre inversión.

## La propuesta

- Propuesta principal

## Supuestos

- **El canal actual soporta el volumen** · declarado el 2026-05-11 · verificado

## Proyectos que lo construyen

- Ninguno declarado
