# Entrevistas · Nómina empresarial

**Ronda:** Ronda · 2026-04-11
**Realizadas por:** Laura Vélez

### Cliente entrevistado · 2026-04-11

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
