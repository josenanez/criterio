# Caso de negocio · Tarjeta de crédito digital

**Código:** PRD-304
**Fecha:** 2026-06-15
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 156.053 | Caso de negocio, 2026-06-15 |

## Retorno esperado

Retorno esperado en 24 meses.
