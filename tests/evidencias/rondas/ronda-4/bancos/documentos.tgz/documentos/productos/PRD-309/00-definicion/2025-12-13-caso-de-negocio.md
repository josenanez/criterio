# Caso de negocio · Crédito de libre inversión

**Código:** PRD-309
**Fecha:** 2025-12-13
**Preparado por:** Mauricio Pérez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 117.145 | Caso de negocio, 2025-12-13 |

## Retorno esperado

Retorno esperado en 24 meses.
