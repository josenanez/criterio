# Comité de producto · Recaudos y cobros

**Fecha:** 2026-10-12
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Felipe Arango | — | — | propuesto | 2026-07-07 | — |
| REQ-4501 | Requerimiento REQ-4501 | Liliana Torres | se verifica en producción | — | aceptado | 2026-07-26 | — |
| REQ-4502 | Requerimiento REQ-4502 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-08-25 | — |
| REQ-4503 | Requerimiento REQ-4503 | Ricardo Salas | se verifica en producción | — | aceptado | 2026-06-25 | — |
| REQ-4504 | Requerimiento REQ-4504 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-04 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | — | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4506 | Requerimiento REQ-4506 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-17 | — |
| REQ-4507 | Requerimiento REQ-4507 | Jorge Medina | se verifica en producción | — | aceptado | 2026-05-23 | — |
| REQ-4508 | Requerimiento REQ-4508 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-06 | — |
| REQ-4509 | Requerimiento REQ-4509 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-04 | — |
| REQ-4510 | Requerimiento REQ-4510 | Camilo Beltrán | se verifica en producción | — | propuesto | 2026-08-09 | — |
| REQ-4511 | Requerimiento REQ-4511 | Diana Molina | se verifica en producción | — | aceptado | 2026-04-15 | — |
| REQ-4512 | Requerimiento REQ-4512 | Ricardo Salas | — | Cliente entrevistado | aceptado | 2026-08-03 | — |
| REQ-4513 | Requerimiento REQ-4513 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-18 | — |
| REQ-2028 | Requerimiento REQ-2028 | Jorge Medina | — | Cliente entrevistado | aceptado | 2026-09-18 | — |

## Decisiones

- Se mantiene el plan
