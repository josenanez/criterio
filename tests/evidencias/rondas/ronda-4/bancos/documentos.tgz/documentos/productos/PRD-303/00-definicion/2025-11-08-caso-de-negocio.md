# Caso de negocio · Cuenta PyME

**Código:** PRD-303
**Fecha:** 2025-11-08
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 117.928 | Caso de negocio, 2025-11-08 |

## Retorno esperado

Retorno esperado en 24 meses.
