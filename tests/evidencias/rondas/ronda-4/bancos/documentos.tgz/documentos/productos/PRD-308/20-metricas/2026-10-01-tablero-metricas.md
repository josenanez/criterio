# Tablero de métricas · Cuenta de ahorros joven

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-01

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 87.640 | 2026-10-01 |
