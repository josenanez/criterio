# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-02
**Asistentes:** Carlos Peña, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 9 | 2026-11-05 |
