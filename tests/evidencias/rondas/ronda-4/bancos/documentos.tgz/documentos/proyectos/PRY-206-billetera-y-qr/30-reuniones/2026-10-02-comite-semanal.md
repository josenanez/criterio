# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-10-02
**Asistentes:** María Restrepo, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 10 | 2026-11-05 |
