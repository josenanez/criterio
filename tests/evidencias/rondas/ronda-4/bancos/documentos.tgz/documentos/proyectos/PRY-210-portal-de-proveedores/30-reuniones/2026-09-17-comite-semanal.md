# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-09-17
**Asistentes:** Camilo Beltrán, Diana Molina, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-10-09 |
| Liliana Torres | Cerrar la prueba 2 | 2026-10-12 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-28 |
| Rubén Cárdenas | Aprobar el diseño 5 | 2026-09-22 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-26 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-18 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-19 |
| Mauricio Pérez | Enviar el documento 9 | 2026-09-29 |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-06 |
| Diana Molina | Revisar el anexo 11 | 2026-09-22 |
| Camilo Beltrán | Validar el ambiente 12 | 2026-10-09 |

## Lo que se dijo

- Paula Céspedes dice que ya entregó «validar el ambiente 4». No se presentó acta.
