# Comité de Transformación Digital · Onboarding PyME

**Fecha:** 2026-10-07
**Asistentes:** Camilo Beltrán, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |
