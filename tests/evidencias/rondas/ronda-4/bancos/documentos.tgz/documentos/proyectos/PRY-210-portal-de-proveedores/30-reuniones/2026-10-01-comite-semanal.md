# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-10-01
**Asistentes:** Camilo Beltrán, Carlos Peña, Diana Molina, Javier Hoyos, Jorge Medina, Liliana Torres, María Restrepo, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-11-10 |
| Liliana Torres | Cerrar la prueba 2 | 2026-11-02 |
| Natalia Ospina | Revisar el anexo 3 | 2026-11-05 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-11-19 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-19 |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-06 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-12 |
| Carlos Peña | Actualizar la matriz 14 | por definir |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-20 |
| Óscar Ramírez | Entregar el punto 16 | 2026-10-18 |
| Sandra Gil | Enviar el documento 17 | 2026-10-16 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-09 |
| María Restrepo | Revisar el anexo 19 | por definir |
| Camilo Beltrán | Validar el ambiente 20 | 2026-10-07 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Rubén Cárdenas): recibido, acta de recibo del 2026-10-01.
- Actualizar la matriz 6 (Laura Vélez): recibido, acta de recibo del 2026-10-01.
- Enviar el documento 9 (Mauricio Pérez): recibido, acta de recibo del 2026-10-01.

## Lo que se dijo

- Diana Molina dice que ya entregó «revisar el anexo 11». No se presentó acta.
