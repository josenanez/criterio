# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-03
**Asistentes:** Laura Vélez, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 6 | 2026-10-24 |
