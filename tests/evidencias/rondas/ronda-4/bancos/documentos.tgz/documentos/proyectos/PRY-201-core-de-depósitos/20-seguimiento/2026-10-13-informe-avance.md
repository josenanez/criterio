# Informe de avance · Core de depósitos

**Código:** PRY-201
**Fecha de corte:** 2026-10-13
**Gerente:** Carlos Peña

## Estado declarado

**Amarillo**

Avance reportado: **48%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.172.515.462 |
| Ejecutado | 2.566.684.043 |
| Proyección al cierre | 7.022.864.553 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
