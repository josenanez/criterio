# Comité de Medios de Pago · Originación digital

**Fecha:** 2026-10-05
**Asistentes:** Diana Molina, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 28 | 2026-10-17 |
