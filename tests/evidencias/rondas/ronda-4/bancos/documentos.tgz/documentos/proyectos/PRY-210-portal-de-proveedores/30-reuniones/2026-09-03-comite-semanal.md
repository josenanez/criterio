# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-09-03
**Asistentes:** Jorge Medina, Liliana Torres, Natalia Ospina, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-09-17 |
| Liliana Torres | Cerrar la prueba 2 | 2026-09-15 |
| Natalia Ospina | Revisar el anexo 3 | 2026-09-27 |
| Paula Céspedes | Validar el ambiente 4 | 2026-09-25 |
