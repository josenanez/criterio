# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-11-24 |
| Liliana Torres | Cerrar la prueba 2 | 2026-11-11 |
| Natalia Ospina | Revisar el anexo 3 | 2026-11-05 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-11-27 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-19 |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-06 |
| Carlos Peña | Actualizar la matriz 14 | 2026-10-19 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-27 |
| Óscar Ramírez | Entregar el punto 16 | 2026-11-03 |
| Sandra Gil | Enviar el documento 17 | 2026-10-24 |
| Javier Hoyos | Cerrar la prueba 18 | 2026-10-23 |
| Camilo Beltrán | Validar el ambiente 20 | 2026-10-23 |
| Ricardo Salas | Aprobar el diseño 21 | 2026-10-27 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-14 |
| Laura Vélez | Confirmar la fecha 23 | 2026-10-11 |
| Mauricio Pérez | Entregar el punto 24 | 2026-11-01 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Diana Molina): recibido, acta de recibo del 2026-10-08.

## Lo que se dijo

- María Restrepo dice que ya entregó «revisar el anexo 19». No se presentó acta.
