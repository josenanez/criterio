# Comité de Riesgos · Motor de decisión

**Fecha:** 2026-10-06
**Asistentes:** Sandra Gil, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 17 | 2026-11-09 |
