# Acta de constitución · Core de depósitos

**Código:** PRY-201
**Área dueña:** Operaciones
**Patrocinador:** Óscar Ramírez
**Gerente de proyecto:** Carlos Peña
**Comité:** Comité de Arquitectura
**Producto asociado:** cuenta de ahorros
**Fecha de aprobación:** 2026-04-12

## Objetivo del negocio

Entregar core de depósitos para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Arquitectura el 2026-04-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-22 |
| Cierre | 2027-05-11 |

## Criterio de éxito

Core de depósitos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
