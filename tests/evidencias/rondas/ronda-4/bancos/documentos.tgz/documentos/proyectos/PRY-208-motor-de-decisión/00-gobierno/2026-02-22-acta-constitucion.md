# Acta de constitución · Motor de decisión

**Código:** PRY-208
**Área dueña:** Tesorería
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-22

## Objetivo del negocio

Entregar motor de decisión para Tesorería.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Riesgos el 2026-02-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-04 |
| Cierre | 2027-01-02 |

## Criterio de éxito

Motor de decisión en producción y medido.

## Dependencias declaradas

- Ninguna declarada
