# Comité de Riesgos · Débito contactless

**Fecha:** 2026-10-07
**Asistentes:** Jorge Medina, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 31 | 2026-09-26 |
