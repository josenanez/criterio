# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-09-24
**Asistentes:** Camilo Beltrán, Carlos Peña, Diana Molina, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-10-30 |
| Liliana Torres | Cerrar la prueba 2 | 2026-10-26 |
| Natalia Ospina | Revisar el anexo 3 | 2026-11-05 |
| Rubén Cárdenas | Aprobar el diseño 5 | 2026-09-22 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-26 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-11-04 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-19 |
| Mauricio Pérez | Enviar el documento 9 | 2026-09-29 |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-06 |
| Diana Molina | Revisar el anexo 11 | 2026-09-22 |
| Diana Molina | Aprobar el diseño 13 | 2026-10-12 |
| Carlos Peña | Actualizar la matriz 14 | por definir |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-20 |
| Óscar Ramírez | Entregar el punto 16 | por definir |

## Cerrados en esta reunión

- Validar el ambiente 12 (Camilo Beltrán): recibido, acta de recibo del 2026-09-24.
