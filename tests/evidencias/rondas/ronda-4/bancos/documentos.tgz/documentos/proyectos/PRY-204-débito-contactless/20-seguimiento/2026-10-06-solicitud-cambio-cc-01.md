# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Débito contactless
**Fecha:** 2026-10-06
**Solicitante:** Jorge Medina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +83 días sobre la línea base vigente |
| Costo | 166.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
