# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Onboarding PyME
**Fecha:** 2026-10-02
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +32 días sobre la línea base vigente |
| Costo | 64.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
