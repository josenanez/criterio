# Corrida del 2026-10-15 · product-business-case

PRD-309 · 15 requerimientos · 39 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `claim_vs_metric` | 1 |

Caso de negocio armado: 2 cifras con fuente (declarada 117.145 vs medida 85.140, brecha 27,3 %). Sin costos, sin monto de retorno y sin criterio de éxito: quedan como vacíos. Sin productos publicados para el cruce de overlap.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Crédito de libre inversión (PRD-309) · borrador del 2026-10-15
**Desde:** la definición de producto (2025-12-13) y el caso de negocio declarado (2025-12-13) · **Cifras con fuente:** 2 de 2 (1 declarada, 1 medida). El retorno y los costos no traen cifra: van a Vacíos.

## Qué problema resuelve, y para quién
«El segmento Microcomercio no tiene crédito de libre inversión.» Para el segmento Microcomercio. (Definición de producto, `00-definicion/2025-12-13-definicion-producto.md`, 2025-12-13.) La propuesta de la definición dice solo «Propuesta principal», sin contenido.

## Qué se construye
15 requerimientos en el registro: 11 decididos (aceptados) y 4 propuestos. Entran al caso los 11 decididos. En los 11 la evidencia de demanda es la misma frase del acta del comité del 2026-10-09: «Cliente entrevistado», sin cita de qué dijo. Ninguno dice quién decidió. Ninguno tiene proyecto que lo ejecute.

| Requerimiento | Estado | Doliente | Criterio de aceptación | Evidencia de demanda |
|---|---|---|---|---|
| REQ-4909 | aceptado (2026-08-11) | Liliana Torres | «se verifica en producción» | «Cliente entrevistado» (sin cita) |
| REQ-4912 | aceptado (2026-07-28) | Gustavo Neira | «se verifica en producción» | «Cliente entrevistado» (sin cita) |
| REQ-2035 | aceptado (2026-09-27) | Felipe Arango | sin criterio | «Cliente entrevistado» (sin cita) |
| REQ-4907 | aceptado (2026-07-25) | Natalia Ospina | sin criterio | nadie lo pidió, según el registro |
| REQ-4902 | aceptado (2026-05-14) | Carlos Peña | tiene criterio | nadie lo pidió, según el registro |
| REQ-4900, 4905 | aceptados (2026-08-15, 2026-08-24) | sin doliente | sin criterio | nadie lo pidió |
| REQ-4904, 4906, 4910, 4911 | aceptados | no revisados en esta corrida | sin criterio | no revisada en esta corrida |

Fuente de las filas sin detalle: `estado-producto/PRD-309/corridas/salida-product-requirements.md` (2026-10-15). Solo REQ-4909 y REQ-4912 tienen doliente, criterio y evidencia. Esas filas conviene releerlas contra cada ficha antes de llevarlas a un comité.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (esperado) | 117.145 | Declarada | Caso de negocio, Mauricio Pérez | 2025-12-13 |
| volumen_mensual (observado) | 85.140 | Medida | Tablero de métricas, bodega de datos | corte 2026-10-11 |
| Retorno esperado | «en 24 meses», sin monto | — (no es una cifra) | Caso de negocio | 2025-12-13 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 117.145 | 85.140 | Caso de negocio (2025-12-13) vs. tablero de métricas (corte 2026-10-11). Brecha 27,3 %, declarada por encima. Umbral configurado: 20 %. |

La serie medida tiene un solo punto (2026-10-11), así que no muestra tendencia. Que el volumen esté por debajo de lo declarado no dice si el producto aún está en rampa. Eso lo sabe el negocio. El documento no dice cuál es la cifra objetivo ni desde cuándo se mide.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no hay** | Ningún documento |
| Costo operativo / de fondeo / de riesgo de crédito | **no hay** | Ningún documento |

**El primer vacío es el costo de construir.** Sin él lo que hay es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El canal actual soporta el volumen» (declarado 2026-05-11, marcado «verificado») | Habría que invertir en canal, y el costo no está en el caso | No hay documento de verificación; lo diría quien administra el canal. Hoy es un supuesto con apariencia de declarado. |
| El volumen de 117.145 es alcanzable | El retorno se mueve sin que nadie lo haya calculado. El tablero ya mide 27,3 % menos | El dueño del caso (Mauricio Pérez): ¿de dónde salió 117.145? |
| Microcomercio demanda este crédito | Los 11 requerimientos decididos descansan en «Cliente entrevistado», sin cita | Descubrimiento: las entrevistas están en `10-descubrimiento/2025-09-06-entrevistas.docx` y esta corrida no las releyó (ya las procesó `/product-discovery`) |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin costo no hay caso | Finanzas / dueño del producto |
| Monto del retorno esperado (el caso solo dice «en 24 meses») | «Retorno» sin monto ni método no se puede verificar ni cerrar | Dueño del caso de negocio |
| De dónde sale 117.145 | Es la única cifra del caso y no tiene derivación | Mauricio Pérez |
| Criterio de éxito (definición: `not_found`) | Sin él no se puede decir meses después si funcionó | Mauricio Pérez / Comité de producto |
| Qué pasa si no se hace; alternativas consideradas | El caso no las dice | Dueño del producto |
| Cuándo se sabrá si funcionó (fecha de corte) | Convierte el criterio en algo verificable | Comité de producto |
| Quién decidió cada requerimiento (11 decididos sin decisor) y quién tiene autoridad (`authority: not_found`) | Una decisión sin decisor no sostiene el alcance | Comité de producto, en el acta |
| Proyecto que construya lo decidido (definición: «Ninguno declarado»; carpeta de fichas vacía) | Sin proyecto no hay costo ni fecha que citar | PMO / `/product-trace` |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito. Lo único cercano es el volumen mensual de 117.145 del caso, sin fecha de corte ni umbral de «funcionó». Sin esto el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ningún producto publicado a la vista, así que no se pudo hacer el cruce de `/product-overlap`. No hay evidencia de que otro producto cuente las mismas transacciones, y tampoco de que no las cuente.

## Después
Pasar los 3 supuestos de arriba a `assumption-tracking`. Y, si el caso se aprueba, `/product-charter` con REQ-4909 y REQ-4912 como candidatos. Este documento no recomienda aprobar ni rechazar. Eso es del Comité de producto.
