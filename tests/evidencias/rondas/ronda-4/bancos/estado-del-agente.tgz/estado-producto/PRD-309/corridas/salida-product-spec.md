> **Borrador** de especificación, escrito por el agente. Lo cierra Mauricio Pérez (gerente de producto) con el Comité de producto; el agente no aprueba. No es dictamen jurídico: la revisión jurídica sigue pendiente.

# Especificación — Crédito de libre inversión (PRD-309) · borrador del 2026-10-15

**Resultado en una línea:** el registro tiene 11 requerimientos aceptados, pero **ninguno dice qué necesidad cubre** (`need` vacío en los 11), así que no hay comportamiento que especificar sin inventarlo. Este borrador deja el marco, los criterios que existen, y los vacíos con dueño. No rellena nada.

## Qué problema resuelve
«El segmento Microcomercio no tiene crédito de libre inversión.» (definición de producto, 2025-12-13). La propuesta del documento es «Propuesta principal», un texto sin contenido. El criterio de éxito del producto **no está dicho en ningún documento**.

## Alcance
### Entra
Los 11 requerimientos en estado `aceptado` (ninguno `en_construccion`), solo como lista; ninguno tiene sección de comportamiento (ver abajo):
REQ-2035, REQ-4900, REQ-4902, REQ-4904, REQ-4905, REQ-4906, REQ-4907, REQ-4909, REQ-4910, REQ-4911, REQ-4912.

### No entra
- Los 4 requerimientos `propuesto`, que nadie ha decidido: REQ-4901 (137 días), REQ-4903 (168), REQ-4908 (143), REQ-4913 (155). Todos pasan el umbral de 60 días sin decisión.
- Cualquier segmento distinto de Microcomercio: la definición no menciona otro.
- Diseño técnico, estimación de esfuerzo, costo y fechas: no son de este documento.
- Cualquier comportamiento que ningún requerimiento describa. El agente no lo agrega.

## Comportamiento
**Sin secciones.** Los 11 aceptados tienen títulos que son solo su código («Requerimiento REQ-49xx») y `need` vacío; el acta del comité (2026-10-09) los lista como decididos pero no dice qué piden. Escribir comportamiento aquí sería inventarlo.

## Criterios de aceptación
Solo 3 de los 11 aceptados traen algún criterio, y es el mismo texto. **No pasa la prueba de las dos personas:** dice dónde se verifica, no qué se verifica ni con qué resultado.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4902 (Carlos Peña) | No definido: falta qué y qué umbral | No: no es un criterio todavía |
| «se verifica en producción» | REQ-4909 (Liliana Torres) | No definido | No |
| «se verifica en producción» | REQ-4912 (Gustavo Neira) | No definido | No |

Sin criterio alguno (8): REQ-2035, 4900, 4904, 4905, 4906, 4907, 4910, 4911. No propongo cifras: sin la necesidad de cada requerimiento, cualquier umbral sería mío y no del negocio.

Única métrica medida hoy en el producto: `volumen_mensual` = 85.140 (tablero, 2026-10-11). Ningún criterio la usa.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El canal actual soporta el volumen» | **El documento dice «verificado»; no hay documento de verificación.** Además figura declarado el 2026-05-11 dentro de una definición fechada 2025-12-13. | Mauricio Pérez (aporta la verificación o lo baja a no verificado) |
| El volumen mensual es 117.145 (caso de negocio, 2025-12-13) | **No se sostiene:** el tablero mide 85.140, 27,3 % por debajo; el umbral es 20 %. | Mauricio Pérez, con el dato de la bodega |
| Quien decide es el Comité de producto | Ningún documento lo dice (`authority: not_found`); lo propone la configuración | Comité de producto, dejándolo en el acta |

Nota: el supuesto del canal se apoya en un volumen que ya no es el medido; verificarlo contra 117.145 o contra 85.140 da respuestas distintas.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesidad cubre cada uno de los 11 aceptados (`need` vacío) | No hay especificación posible; se construiría lo que cada quien entienda | Mauricio Pérez, con cada doliente |
| Criterio de aceptación en 8 requerimientos, y uno verificable en los otros 3 | Cada quien declara «terminado» a su manera | Mauricio Pérez; dolientes: Felipe Arango (2035), Carlos Peña (4904), Elena Duarte (4906), Natalia Ospina (4907), Javier Hoyos (4910), Beatriz Cuéllar (4911); 4900 y 4905 sin doliente |
| Doliente de REQ-4900 y REQ-4905 (aceptados, sin doliente; 4900 y 4905 también sin evidencia) | Aceptados sin nadie que responda; nadie los pidió que conste | Mauricio Pérez |
| Quién decidió cada aceptación (`decision.who` vacío en los 11; el acta es del 2026-10-09, posterior a todas las decisiones) | Decisiones sin autoría verificable | Comité de producto |
| Evidencia de demanda: 4900, 4902, 4905, 4907 sin ninguna; el resto cita «Cliente entrevistado» sin lo que dijo | Se construye sin sustento de que alguien lo pidió | Mauricio Pérez (volver a las entrevistas del 2025-09-06) |
| Criterio de éxito del producto | No hay contra qué medir si el producto funcionó | Mauricio Pérez / Comité de producto |
| Casos borde: nada definido (p. ej. qué pasa con una solicitud abandonada a medias, un desembolso duplicado o una solicitud rechazada) | Cada equipo resuelve distinto, o no resuelve | Mauricio Pérez con los dolientes |
| Lo que otro equipo debe hacer: la definición dice «Proyectos que lo construyen: Ninguno declarado» y no nombra equipos ni dependencias; el supuesto del canal implica uno | Nadie está comprometido a construir; ningún equipo ha acordado nada | Mauricio Pérez |
| Obligaciones normativas (ver abajo) | Se descubren con el producto construido | Revisión jurídica de la organización (sin nombre en los documentos) |

## Obligaciones normativas: primer barrido
Es un barrido, no un dictamen. **Ningún documento dice el país**, y sin país no cito norma: no tengo la norma a la vista.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Otorga crédito de libre inversión (producto financiero al consumidor) | no dicho | Información previa, reclamos y cobros al consumidor financiero | — | no tengo la norma a la vista |
| Evaluará y registrará datos de un cliente de crédito | no dicho | Autorización y finalidad en tratamiento de datos personales; conservación | — | no tengo la norma a la vista |
| Dónde corre y se guarda el dato | no dicho | Posible transferencia internacional | — | no tengo la norma a la vista |

Que esté así no significa que se cumpla ni que no. Lo que quede sin resolver debe entrar al registro como restricción del requerimiento o como riesgo con doliente.

## Requerimientos aceptados que esta especificación no cubre
Con sección de comportamiento, **ninguna cubre ninguno** (0 de 11).

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2035 | Requerimiento REQ-2035 | Sin necesidad, sin criterio; doliente Felipe Arango |
| REQ-4900 | Requerimiento REQ-4900 | Sin necesidad, criterio, doliente ni evidencia |
| REQ-4902 | Requerimiento REQ-4902 | Sin necesidad ni evidencia; criterio no verificable |
| REQ-4904 | Requerimiento REQ-4904 | Sin necesidad ni criterio |
| REQ-4905 | Requerimiento REQ-4905 | Sin necesidad, criterio, doliente ni evidencia |
| REQ-4906 | Requerimiento REQ-4906 | Sin necesidad ni criterio |
| REQ-4907 | Requerimiento REQ-4907 | Sin necesidad, criterio ni evidencia |
| REQ-4909 | Requerimiento REQ-4909 | Sin necesidad; criterio no verificable. Cerca de estar listo: tiene doliente y evidencia (citada sin contenido) |
| REQ-4910 | Requerimiento REQ-4910 | Sin necesidad ni criterio |
| REQ-4911 | Requerimiento REQ-4911 | Sin necesidad ni criterio; el más antiguo (decidido 2026-03-17) |
| REQ-4912 | Requerimiento REQ-4912 | Sin necesidad; criterio no verificable. Cerca de estar listo, como REQ-4909 |

## Después
`/product-charter` todavía no: ningún requerimiento tiene criterio verificable ni el producto criterio de éxito. Primero cerrar los vacíos de arriba, empezando por la necesidad y el criterio de REQ-4909 y REQ-4912.

---
**Pie.** Sale del registro `estado-producto/PRD-309/requirements/` (15 requerimientos: 11 aceptados, 4 propuestos), al 2026-10-15; cubre 0 de 11 con comportamiento. Documentos fuente: definición y caso de negocio (2025-12-13), tablero (2026-10-11), acta del comité (2026-10-09). Términos aceptados por José Francisco Ñáñez, versión 0.3.10, 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal
