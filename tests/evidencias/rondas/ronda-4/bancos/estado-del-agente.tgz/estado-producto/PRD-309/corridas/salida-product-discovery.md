## Descubrimiento — Crédito de libre inversión (PRD-309) · 1 pieza de entrevistas, 5 piezas leídas al 2026-10-15

Material: 5 documentos en 4 carpetas, ninguno visto antes. De descubrimiento hay **una sola pieza**: `10-descubrimiento/2025-09-06-entrevistas.docx` (una ronda, un cliente entrevistado, hecha por Mauricio Pérez). Las otras cuatro son definición, caso de negocio, tablero de métricas y acta de comité, y no son voz del cliente. No hubo nada ilegible.

### Temas
> **Necesidad principal** — 1 de 1 piezas (1 entrevistado)
> — *«Lo necesito y hoy no lo tengo.»* · Cliente entrevistado (sin nombre ni segmento en el documento), 2025-09-06
> **En el registro:** **ninguno** que se pueda atar con seguridad. Los 15 requerimientos (REQ-2035, REQ-4900 a REQ-4913) no tienen la necesidad escrita (`need` vacío en todos), así que ninguno dice a qué problema responde. Sólo se sabe que el acta de comité del 2026-10-09 atribuye 11 de ellos a «Cliente entrevistado», sin cita de qué dijo. No asigno la cita a ninguno: sería inventar el vínculo.

Contradicciones dentro del tema: ninguna en el material. Una sola voz no permite contradicción ni consenso.

### Dicho y nunca convertido en nada
| Tema | Veces | Desde | Ningún requerimiento lo recoge |
|---|---|---|---|
| Necesidad principal | 1 | 2025-09-06 (13 meses) | No se puede afirmar ni negar: ningún requerimiento tiene la necesidad escrita |

Con una sola mención no hay patrón de «dicho muchas veces». Se deja registrado, sin promover.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| «Lo necesito y hoy no lo tengo.» (no dice qué necesita: ni monto, ni plazo, ni uso) | Cliente entrevistado | 2025-09-06 |

No se promueve y no se descarta. Esa pieza es de hace 13 meses, por encima del umbral de 12 meses de la configuración. No basta para sustentar un requerimiento.

### Afirmaciones numéricas de los entrevistados
Ninguna. La entrevista no contiene cifras.

### De fuentes públicas
No entró ninguna.

### Evidencia nueva que contradice el registro
Ninguna. La entrevista no contradice ningún requerimiento, porque el registro no dice qué necesidad recoge cada uno.

### Lo que no sé
- Quién es el cliente entrevistado, de qué segmento y si es de Microcomercio, que es el segmento de la definición.
- Qué dijo cada uno de los clientes que el acta cita como origen de 11 requerimientos. Esas entrevistas no están en la carpeta: sólo hay una ronda, y es de una voz.
- No se crea ningún requerimiento: no hay tema con doliente que lo asuma.

### Recálculo (`compute`, no cuento yo)
15 requerimientos (11 aceptados, 4 propuestos). Con evidencia: 7 de 11 decididos (63,6 %). Con proyecto: 0 (0,0 %). Señales: sin criterio de aceptación 8, sin proyecto 11, sin doliente 3, aceptado sin evidencia 4, sin decidir más de 60 días 4, y 1 diferencia de afirmación contra métrica. Ésa es `volumen_mensual`: el caso de negocio declara 117.145 y el tablero mide 85.140 (27,3 % por encima, corte 2026-10-11). Es un hallazgo de `/product-definition`, no de descubrimiento.

### Sellado
`sellar` se negó: dijo que la ficha `producto.json` no se escribió en esta corrida y que sellar daría los documentos por leídos sin haberlos leído. Este comando no escribe esa ficha, así que **no sellé nada** y no lo forcé. La próxima corrida volverá a ver estos 5 documentos como nuevos.

### Después
Ningún tema nuevo quedó como requerimiento, así que no ofrezco `/product-requirements` por esto. Lo que haría falta es otra cosa: más entrevistas, o las transcripciones que respaldan el «Cliente entrevistado» del acta.
