# Corrida del 2026-10-15 · product-charter

PRD-309 · 15 requerimientos · 31 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `claim_vs_metric` | 1 |

Borrador de acta para REQ-4900 con vacíos: sin criterios de aceptación, evidencia, doliente ni autoridad. No se creó ficha (sin firma). Brecha de volumen 27,3% señalada.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Términos: ya vigentes (v1.1, familia 0.3.10, aceptados el 2026-10-15 por José Francisco Ñáñez); no se registraron de nuevo.

**Verificación previa (paso 1) — REQ-4900 no está completo.** Falta: criterios de aceptación (el acta del comité de 2026-10-09 los marca «—»), evidencia de demanda con cita («Quién lo pidió»: «—»), y la autoridad (ningún documento dice quién decide; la configuración solo propone «Comité de producto»). Tampoco tiene doliente («sin asignar»). Sí está aceptado (desde 2026-08-15, según el acta del comité de 2026-10-09), pero sin registro de quién lo decidió. Respuesta sugerida tomada (nadie contesta en esta sesión): seguir sin esos datos, marcándolos como vacíos del acta y sin rellenarlos.

# Acta de constitución — Crédito de libre inversión · borrador del 2026-10-15
**Producto:** PRD-309 · Crédito de libre inversión · **Requerimientos:** REQ-4900

## Qué problema resuelve
Del producto: «El segmento Microcomercio no tiene crédito de libre inversión.» (documentos/productos/PRD-309/00-definicion/2025-12-13-definicion-producto.md, 2025-12-13).
Del requerimiento REQ-4900: **no está dicho.** El registro no tiene necesidad, solo el título genérico «Requerimiento REQ-4900» (documentos/productos/PRD-309/30-decisiones/2026-10-09-comite-producto.docx). No se infiere cuál es.

## Criterio de éxito
**Vacío.** REQ-4900 no tiene criterios de aceptación (acta del comité, 2026-10-09: «—»). La definición del producto tampoco declara éxito. Sin esto el cierre no se podrá juzgar.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 (sin descripción) | **Ninguna.** «Quién lo pidió»: «—» (comité, 2026-10-09) |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4901 … REQ-4913, REQ-2035 | Sin título descriptivo en el registro | No se pidieron en este acta. Su estado en el comité del 2026-10-09 es mezcla de «propuesto» y «aceptado»; ninguno tiene proyecto que lo ejecute. Quedan fuera por no haberse incluido en el argumento, no por una razón de fondo; esa razón la tiene que dar quien decide el alcance. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Mauricio Pérez es gerente de *producto* (definición, 2025-12-13); no consta que sea gerente del proyecto y este comando no nombra a nadie.
- **Comité:** Comité de producto (solo en la configuración; el acta del 2026-10-09 registra como asistente únicamente a Mauricio Pérez).
- **Autoridad del gerente:** no está dicho. Ningún documento declara qué puede decidir.
- **Quién decidió aceptar REQ-4900:** no consta (`decision.who` vacío).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El canal actual soporta el volumen» (declarado 2026-05-11) | La definición dice «verificado», pero no existe documento de verificación: se trata como **no verificado** | Por asignar: el gerente del proyecto, al registrarlo con RAID. Sin doliente propuesto. |

Además, la cifra del caso de negocio (volumen_mensual 117.145, 2025-12-13) frente a la medida del tablero (85.140, corte 2026-10-11) difiere en 27,3 % por debajo, sobre el umbral de 20 % de la configuración. No es un supuesto, pero afecta el supuesto de volumen anterior y debe llegar al comité.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Crédito a persona/negocio (datos personales, consumidor financiero) | No barrido: el requerimiento no describe su necesidad | — | Sin resolver; no se cita norma que no esté en los documentos |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Necesidad de REQ-4900 | El proyecto arranca sin saber qué construye | Quien pidió el requerimiento (nadie consta) / gerente de producto |
| Criterios de aceptación | No hay criterio de éxito; el cierre no se puede juzgar | Gerente de producto |
| Evidencia de demanda con cita | Se construye sin sustento de que alguien lo pidió | Gerente de producto |
| Doliente del requerimiento | Nadie responde por él | Comité de producto |
| Autoridad del gerente | El proyecto escala todo o no escala nada | Comité de producto |
| Patrocinador y gerente del proyecto | No hay a quién entregarle la ficha | Quien tenga autoridad para asignarlos |
| Quién y cuándo decidió aceptar REQ-4900 | Aceptación sin traza (60 días con estado «aceptado» y sin proyecto) | Comité de producto |
| Éxito del producto | La definición no declara qué es éxito | Gerente de producto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad sobre el producto (por definir). La ficha del proyecto se crea después de la firma; **no se creó ficha en esta corrida** y no se escribió ningún estado declarado.

## Después
El gerente del proyecto (aún sin nombrar) instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella. Antes de eso, conviene cerrar los vacíos de arriba: con tres de cuatro condiciones de REQ-4900 sin cumplir, no recomiendo firmar tal cual.
