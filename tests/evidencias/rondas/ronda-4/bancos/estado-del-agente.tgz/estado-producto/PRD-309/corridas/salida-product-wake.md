## Crédito de libre inversión (PRD-309) · 2026-10-15

**Primera revisión: no había corte anterior** (`snapshots/` estaba vacío y `review` nunca se había corrido), así que no puedo decir qué cruzó un umbral *desde* un corte. Lo que sigue es la línea de base: lo que ya estaba abierto hoy. Desde la próxima corrida solo se reportará lo nuevo.

Términos: vigentes (aceptados por José Francisco Ñáñez el 2026-10-15, versión 0.3.10).

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir (umbral 60 días) | REQ-4903 | 168 días | Quién tiene la facultad de decidirlo | Doliente: Carlos Peña. Autoridad: no consta en ningún documento (la configuración propone Comité de producto) |
| ídem | REQ-4913 | 155 días | Además no tiene doliente | sin doliente |
| ídem | REQ-4908 | 143 días | Llevarlo al comité | Doliente: Mauricio Pérez |
| ídem | REQ-4901 | 137 días | Llevarlo al comité | Doliente: Mauricio Pérez |

### Aceptado y nadie lo construye
Los 11 requerimientos aceptados no tienen proyecto asignado (`requirement_untraced`: 11). El más antiguo, REQ-4911, lleva 212 días decidido. Cuatro están aceptados sin evidencia de quién los pidió (REQ-4900, REQ-4902, REQ-4905, REQ-4907); dos de ellos (REQ-4900, REQ-4905) tampoco tienen doliente. Ocho no tienen criterio de aceptación.

### Lo que el negocio declara contra lo que miden los datos
`volumen_mensual`: el caso de negocio (2025-12-13) declara 117.145; el tablero del 2026-10-11 mide 85.140. Está 27,3 % por debajo, sobre el umbral de 20 %.

### Supuesto sin sustento documental
«El canal actual soporta el volumen» figura como verificado, pero no hay documento de verificación. Dado el punto anterior, vale revisarlo.

### Las trazas
Ninguna se confirma. Solo hay una ficha a la vista (PRY-210, Portal de proveedores) y no dice ejecutar PRD-309. Las fichas de los otros 12 proyectos no están publicadas en la carpeta, así que no sé si alguno construye este producto.

### Del descubrimiento
Los 5 documentos de la carpeta se leen por primera vez (nada cambió respecto a un corte porque no existía). Nota técnica: `plan-lectura` marca como `source_missing` las fuentes de 7 campos de `producto.json`, aunque los archivos existen; parece un problema de rutas relativas, no de documentos faltantes.

**Vuelvo el 2026-11-14.**
