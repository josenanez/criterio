## Trazabilidad — Crédito de libre inversión (PRD-309) · al 2026-10-15

11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

*Ninguno de los 11 requerimientos decididos tiene proyecto asignado en el registro (`traces.project` vacío en todos). La cadena se corta en el segundo eslabón: hay decisión, no hay proyecto ni entregable.*

### Decidido y nadie lo está construyendo

Fuente de la decisión en todos: `documentos/productos/PRD-309/30-decisiones/2026-10-09-comite-producto.docx` (acta del comité de producto del 2026-10-09). El acta no dice quién decidió cada uno, así que «Por quién» queda como no consta.

| REQ | Título | Decidido el | Por quién | Doliente |
|---|---|---|---|---|
| REQ-4911 | Requerimiento REQ-4911 | 2026-03-17 | no consta | Beatriz Cuéllar |
| REQ-4906 | Requerimiento REQ-4906 | 2026-04-06 | no consta | Elena Duarte |
| REQ-4904 | Requerimiento REQ-4904 | 2026-05-13 | no consta | Carlos Peña |
| REQ-4902 | Requerimiento REQ-4902 | 2026-05-14 | no consta | Carlos Peña |
| REQ-4910 | Requerimiento REQ-4910 | 2026-06-24 | no consta | Javier Hoyos |
| REQ-4907 | Requerimiento REQ-4907 | 2026-07-25 | no consta | Natalia Ospina |
| REQ-4912 | Requerimiento REQ-4912 | 2026-07-28 | no consta | Gustavo Neira |
| REQ-4909 | Requerimiento REQ-4909 | 2026-08-11 | no consta | Liliana Torres |
| REQ-4900 | Requerimiento REQ-4900 | 2026-08-15 | no consta | sin doliente |
| REQ-4905 | Requerimiento REQ-4905 | 2026-08-24 | no consta | sin doliente |
| REQ-2035 | Requerimiento REQ-2035 | 2026-09-27 | no consta | Felipe Arango |

El más antiguo lleva 212 días decidido (REQ-4911) sin proyecto. Cuatro de estos once (REQ-4900, REQ-4902, REQ-4905, REQ-4907) además están aceptados sin evidencia de quién los pidió, y dos (REQ-4900, REQ-4905) no tienen doliente: son los que más difícilmente van a encontrar un proyecto solos.

### La traza no se confirma

Ninguna. Ningún requerimiento declara un proyecto que ejecute el producto, así que no hay traza que confirmar ni desacuerdo que reportar (`trace_not_confirmed`: 0).

### Lo que un proyecto construye y el registro no tiene

Con lo que hay a la vista, ninguno: la única ficha disponible (PRY-210, Portal de proveedores) deja `identity.product` en `not_found` — el acta de constitución dice «No aplica» — y por tanto no dice que ejecute PRD-309. Eso es un hallazgo del lado de la ficha (el campo está vacío), no una brecha del registro. La respuesta completa a esta pregunta depende de las fichas que faltan (abajo).

### La cadena completa

| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2035 | aceptado | 2026-09-27 | — | no | — |
| REQ-4900 | aceptado | 2026-08-15 | — | no | — |
| REQ-4902 | aceptado | 2026-05-14 | — | no | — |
| REQ-4904 | aceptado | 2026-05-13 | — | no | — |
| REQ-4905 | aceptado | 2026-08-24 | — | no | — |
| REQ-4906 | aceptado | 2026-04-06 | — | no | — |
| REQ-4907 | aceptado | 2026-07-25 | — | no | — |
| REQ-4909 | aceptado | 2026-08-11 | — | no | — |
| REQ-4910 | aceptado | 2026-06-24 | — | no | — |
| REQ-4911 | aceptado | 2026-03-17 | — | no | — |
| REQ-4912 | aceptado | 2026-07-28 | — | no | — |
| REQ-4901 | propuesto | — (sin decidir, 137 días) | — | — | — |
| REQ-4903 | propuesto | — (sin decidir, 168 días) | — | — | — |
| REQ-4908 | propuesto | — (sin decidir, 143 días) | — | — | — |
| REQ-4913 | propuesto | — (sin decidir, 155 días) | — | — | — |

Los cuatro propuestos no son hallazgo de esta traza: todavía no hay decisión que trazar. Aparecen en `/product-requirements`.

### Sin fichas a la vista

Se pasó la carpeta `documentos/proyectos/PRY-210-portal-de-proveedores/00-gobierno`, la única con una ficha publicada (`ficha-pm.json`). Los otros 12 proyectos del portafolio (PRY-199 a PRY-209 y PRY-211) **no tienen ficha en esa carpeta**, así que no se pudo ver si alguno dice ejecutar PRD-309. Pueden existir y no estar publicadas. Mientras tanto, ninguna traza se da por confirmada y la brecha «un proyecto construye lo que el registro no tiene» queda sin verificar para esos 12.

### Después

Hay once decididos sin proyecto: `/product-charter` para el primero que esté listo para serlo. Los candidatos con más sustento son los que tienen doliente, criterio de aceptación y evidencia: REQ-4909 y REQ-4912.
