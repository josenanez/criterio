# Corrida del 2026-10-15 · product-definition

PRD-309 · 15 requerimientos · 33 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `claim_vs_metric` | 1 |

La evidencia sostiene poco: una entrevista de 13 meses y un volumen medido 27,3 % por debajo del declarado; sin criterio de éxito ni autoridad

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Definición — Crédito de libre inversión (PRD-309) · contrastada al 2026-10-15
**Documento:** `00-definicion/2025-12-13-definicion-producto.md` y `00-definicion/2025-12-13-caso-de-negocio.md` · **del** 2025-12-13 · 5 afirmaciones

Afirmaciones leídas: (1) el segmento Microcomercio no tiene crédito de libre inversión; (2) la propuesta principal (sin contenido); (3) el canal actual soporta el volumen (supuesto, «verificado»); (4) volumen mensual de 117.145; (5) retorno esperado en 24 meses.

### Lo que la evidencia contradice
Ninguna afirmación está contradicha por una fuente que diga lo contrario. La única diferencia es de cifra y va en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 117.145 | 85.140 | declarado 27,3 % por encima (umbral 20 %) | Caso de negocio, 2025-12-13 · Tablero de métricas (bodega de datos), corte 2026-10-11 |

La serie medida tiene un solo punto (2026-10-11). No hay tendencia que mostrar: la cifra declarada de hace diez meses se compara con una sola medición.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses (sin cifra) | Caso de negocio, 2025-12-13 | No hay serie, ni siquiera una cifra declarada que medir. Nadie está midiendo el retorno. |

### No está dicho en ninguna parte
- **Criterio de éxito:** ningún documento lo dice.
- **Quién decide:** ningún documento lo dice. La configuración propone «Comité de producto», pero eso no sale de la definición.
- **Cuál es la propuesta:** la definición dice «Propuesta principal» y nada más. No hay propuesta escrita (monto, plazo, tasa, uso, canal).
- **Qué es el retorno esperado:** el caso de negocio dice «Retorno esperado en 24 meses» sin monto, sin supuestos de cálculo, sin costo.
- **Qué es «el volumen»** del supuesto del canal: no dice cuál cifra, ni la de 117.145 ni otra, ni qué capacidad tiene el canal.
- **Quién es el cliente del segmento:** la definición dice «Microcomercio» sin delimitarlo (tamaño, sector, país).
- **Que Microcomercio no tiene el producto hoy:** la afirmación del problema no cita ninguna fuente.
- **Proyectos que lo construyen:** «Ninguno declarado».

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El canal actual soporta el volumen | No aplica el conteo: el documento lo marca «verificado» (declarado 2026-05-11, 157 días antes de hoy) | No hay documento de verificación. Haría falta la prueba de capacidad del canal o la nota de quien lo verificó, con fecha y la cifra de volumen contra la que se hizo. Además, la fecha del supuesto (2026-05-11) es posterior a la de la definición (2025-12-13) y la definición no dice quién lo verificó. |

Es una afirmación de verificación sin sustento a la vista, no un supuesto abierto. No se puede decir que sea falsa; tampoco que esté verificada.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Existe una necesidad en un cliente | Entrevista: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-06-entrevistas.docx`) | 2025-09-06 | Débil: una sola voz, sin nombre ni segmento, sin monto, plazo ni uso. Es lo que alguien dijo, no algo que alguien pagó o pidió formalmente. No se puede atar a Microcomercio. |
| Volumen actual de 85.140 al mes | Tablero de métricas | 2026-10-11 | Medición. Sostiene que hay volumen, no que sea el declarado. |

El acta de comité del 2026-10-09 atribuye 11 requerimientos a «Cliente entrevistado», pero no hay más entrevistas en la carpeta que esa ronda de una voz.

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del cliente / problema del segmento | Entrevista del 2025-09-06 | 13 meses (umbral: 12) |
| Cifra de volumen del caso de negocio (117.145) | Caso de negocio del 2025-12-13 | 10 meses, dentro del umbral, pero ya contradicha por la medición |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Crédito de consumo/comercial a clientes (consumidor financiero) | No declarado en la configuración ni en los documentos | Información al cliente, condiciones del crédito, protección del consumidor financiero | — | No tengo la norma a la vista |
| Datos personales de los solicitantes | No declarado | Autorización y tratamiento de datos personales | — | No tengo la norma a la vista |
| Evaluación de riesgo crediticio y reporte a centrales | No declarado | Consulta y reporte de información crediticia | — | No tengo la norma a la vista |
| Retención de información | No declarado | Conservación de registros del crédito | — | No tengo la norma a la vista |

Se nombra lo que el producto roza; no se cita norma porque el país no está dicho y no tengo el texto a la vista. No se dice si cumple. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito:** no declarado. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide:** no declarado en ningún documento.
- **El problema** y **para quién** sí están dichos, pero en una frase cada uno, sin fuente. Siguen siendo insuficientes para cerrar: el problema no cuantifica, el segmento no se delimita.
- La **propuesta** está vacía.

Nota del cálculo: `compute` trae `unknown` vacío en esta corrida aunque `success` y `authority` figuran `not_found` en la ficha. Cito la ficha, no el campo `unknown`.

### Después
- El supuesto del canal no está abierto, pero su «verificado» no tiene soporte: si nadie aporta la verificación, conviene registrarlo como riesgo con doliente (raid-taxonomy). No lo hago sin que alguien lo pida.
- La definición **no** está cerrada (sin criterio de éxito ni autoridad), así que no ofrezco `/product-charter`.
