# Corrida del 2026-10-15 · product-setup

PRD-309 · 15 requerimientos · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 11 |
| `requirement_without_acceptance` | 8 |
| `requirement_accepted_without_evidence` | 4 |
| `requirement_undecided` | 4 |
| `requirement_without_owner` | 3 |
| `claim_vs_metric` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

4 preguntas (todas por defecto), primer resultado en una sesión sin interfaz; 15 requerimientos, 8 aceptados sin criterio, 4 sin evidencia, 11 sin proyecto, brecha de volumen_mensual 27,3 %; sellar falló (sin corrida abierta)

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Crédito de libre inversión (PRD-309)

**Lo que miré:** 5 documentos · 2 de descubrimiento y decisión (una ronda de entrevistas del 2025-09-06 con una sola cita, y el acta del comité del 2026-10-09) · la definición del 2025-12-13 · un tablero de métricas del 2026-10-11. Los cinco se leyeron; no hubo formatos ilegibles.
**Términos:** aceptados para la versión 0.3.10 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 fdf0177cc54e5055…
**Preguntas:** 4, todas con la respuesta sugerida (sesión sin interfaz). Producto y gerente: Mauricio Pérez, del caso de negocio. Quién decide: Comité de producto (ningún documento lo dice; es una propuesta, no un dato). Estado en `estado-producto/PRD-309`. Términos: sí, por instrucción de la prueba.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Microcomercio no tiene crédito de libre inversión | Una entrevista: «Lo necesito y hoy no lo tengo» (no dice de qué segmento es el cliente) | 2025-09-06 |
| volumen_mensual = 117.145 | Solo el caso de negocio. El tablero mide 85.140 al 2026-10-11, **27,3 % por debajo**: declarado por encima de lo medido | 2025-12-13 / 2026-10-11 |
| El canal actual soporta el volumen | Un supuesto que el documento marca «verificado»; no hay ningún documento de la verificación. Está fechado 2026-05-11 dentro de una definición del 2025-12-13 | 2026-05-11 |
| Retorno esperado en 24 meses | Nada. Sin cifra, sin base | — |

### Lo que no está dicho en ninguna parte
- El criterio de éxito del producto.
- Quién decide qué se construye (ningún documento lo dice).
- De dónde sale el 117.145: la fuente es el propio caso de negocio.
- Cuánto es el retorno esperado y con qué se calculó.
- La propuesta de valor: la definición dice solo «Propuesta principal».
- Qué dijo cada cliente por requerimiento: el acta dice «Cliente entrevistado», sin cita ni nombre.
- El problema de cada uno de los 15 requerimientos: todos se llaman «Requerimiento REQ-xxxx».
- Qué proyecto construye algo: «Ninguno declarado» en la definición y «—» en las 15 filas del acta.
- El acta decide «Se mantiene el plan» y no dice cuál.

### Supuestos sobre los que está escrita
Uno declarado: «El canal actual soporta el volumen», marcado verificado sin documento que lo muestre. No hay ninguno más, y eso también es un hallazgo.

### El registro de requerimientos (15, tal como los dice el acta)
- 11 aceptados y 4 propuestos.
- **8 aceptados sin criterio de aceptación** (REQ-4900, 4904, 4905, 4906, 4907, 4910, 4911 y 2035).
- **4 aceptados sin evidencia de demanda** (REQ-4900, 4902, 4905 y 4907). REQ-4900 y 4905 además no tienen doliente.
- **11 aceptados sin proyecto que los ejecute**: ninguno está trazado, 0,0 %.
- **3 sin doliente**: REQ-4900, 4905 y 4913.
- **4 propuestos sin decidir hace más de 60 días**: REQ-4901 (137 días), 4903 (168), 4908 (143) y 4913 (155).
- El conteo de «con evidencia» (7 de 11 aceptados, 63,6 %) cuenta «Cliente entrevistado» tal como lo dice el acta. Es una categoría y no una cita, así que es un máximo. La única entrevista que hay es del 2025-09-06, de hace más de 12 meses.
- REQ-2035 no sigue la numeración de los demás (4900–4913). Lo dejo señalado, no corregido.
- «Quién decidió» no está en el acta de ninguna aceptación. Solo hay fecha.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas: hay una sola cita y ninguna enlaza con un requerimiento.
- La serie de volumen_mensual: hay un solo punto (2026-10-11), así que no se ve tendencia, solo la brecha.
- Las decisiones del comité con su motivo: sin ellas un requerimiento descartado se ve igual que uno que nadie miró.
- Nadie ha medido el retorno esperado.
- No se pudo hacer: el sellado de la lectura (`sellar`) falló porque pide una corrida abierta y este comando no abre ninguna. La lectura de los 5 documentos quedó sin sellar.

### Después
Con más material de entrevistas, `/product-discovery` convierte los temas en requerimientos con la cita de quién lo pidió. Con lo que hay hoy solo daría un tema.
