No publiqué la ficha de PRD-309 (Crédito de libre inversión): no hay carpeta de productos publicados configurada (la configuración solo define `paths.documents` y `paths.state`) ni existe ninguna en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No la inventé ni la creé.

**Lo que habría llevado (corte 2026-10-15):** 15 requerimientos (11 aceptados, 4 propuestos) · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Microcomercio
**Métricas:** volumen_mensual, declarado 117145.0 en documentos/productos/PRD-309/00-definicion/2025-12-13-caso-de-negocio.md (medido 85140.0 el 2026-10-11, brecha 27.3 %; la medición no se publica).

Cuando la organización fije la carpeta, se vuelve a correr y se escribe `<código>.json` ahí.
