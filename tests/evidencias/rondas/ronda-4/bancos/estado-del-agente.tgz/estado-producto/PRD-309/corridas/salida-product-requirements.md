## Registro — Crédito de libre inversión (PRD-309) · al 2026-10-15
15 requerimientos · 11 decididos · 63,6 % con evidencia · 0 % con proyecto que lo ejecuta

Nota de alcance: la carpeta de fichas de proyectos (`estado/`) está vacía, así que "0 % con proyecto" significa que no hay ficha que confirme ninguna traza. No prueba que nadie esté construyendo.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | aceptado (2026-08-15) | sin doliente |
| REQ-4905 | Requerimiento REQ-4905 | aceptado (2026-08-24) | sin doliente |
| REQ-4907 | Requerimiento REQ-4907 | aceptado (2026-07-25) | Natalia Ospina |
| REQ-4902 | Requerimiento REQ-4902 | aceptado (2026-05-14) | Carlos Peña |

### Decidido y nadie lo está construyendo
Los 11 aceptados (REQ-2035, 4900, 4902, 4904, 4905, 4906, 4907, 4909, 4910, 4911, 4912) no tienen proyecto que los ejecute. Los más antiguos: REQ-4911 (decidido 2026-03-17), REQ-4906 (2026-04-06), REQ-4904 (2026-05-13), REQ-4902 (2026-05-14).

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | no dice doliente |
| REQ-4905 | Requerimiento REQ-4905 | no dice doliente |
| REQ-4913 | Requerimiento REQ-4913 (propuesto) | no dice doliente |

Quién lo cerraría: Mauricio Pérez (gerente de producto) asigna el doliente.

### Sin criterio de aceptación
Solo decididos: REQ-2035, 4900, 4904, 4905, 4906, 4907, 4910, 4911 (8 de 11).

### Decidido sin documento que lo respalde
Los 11 decididos citan el acta del comité de producto del 2026-10-09 como fuente, así que el documento existe. Pero ninguno dice **quién decidió**.
Atención: el acta es posterior a todas las decisiones (la más reciente, REQ-2035, es del 2026-09-27). Sirve de respaldo, pero no es el documento del momento de la decisión.

### Lleva meses y nadie lo decide
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4903 | Requerimiento REQ-4903 | 168 días | Comité de producto |
| REQ-4913 | Requerimiento REQ-4913 | 155 días | Comité de producto |
| REQ-4908 | Requerimiento REQ-4908 | 143 días | Comité de producto |
| REQ-4901 | Requerimiento REQ-4901 | 137 días | Comité de producto |

Umbral configurado: 60 días. El comité de producto es la autoridad según la configuración; el cálculo no la encontró en los documentos (`authority: not_found`), así que conviene que el acta lo diga de forma expresa.

### Evidencia vieja
Ninguno. Lo más nuevo que sostiene cada requerimiento con evidencia es del 2026-10-09.

### Fuera del registro, pero que cruza el umbral
El caso de negocio (2025-12-13) declara un volumen mensual de 117.145; el tablero del 2026-10-11 mide 85.140. Es una brecha de 27,3 %, declarada por encima, con umbral en 20 %.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 4 | 11 | 0 | 0 | 0 |

## Después
Hay 11 requerimientos decididos que nadie construye: `/product-trace`. Solo REQ-4909 y REQ-4912 tienen doliente, criterio y evidencia; son los candidatos a `/product-charter`.
