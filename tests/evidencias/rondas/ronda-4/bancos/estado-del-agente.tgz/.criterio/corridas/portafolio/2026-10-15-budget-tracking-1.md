# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking portafolio

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T18:49:00 · **Fin:** 2026-10-15T18:50:30 · **Duración:** 90 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 74 | 60 | Presupuesto de 13 proyectos (COP) desde informes de avance, todo declaración sin soporte contable. Alertas: ejecutado mayor que comprometido en PRY-210 y PRY-211; proyección sobre aprobado en 6 proyectos; comprometido cerca del tope en PRY-207 y PRY-208; proyección de PRY-204 y PRY-205 anterior a su cambio de costo. Dijo que no sabe: presupuesto original vs vigente (no hay línea base de costo), soporte contable y totales del portafolio. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 4, `variance_time` 3, `milestone_overdue` 2, `change_without_baseline` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

El informe de presupuesto del portafolio (13 proyectos, todos en COP) está hecho y la corrida quedó registrada como `2026-10-15-budget-tracking-1`. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez, así que no hizo falta registrarlos de nuevo.

Las cifras de los 13 proyectos salen del informe de avance de cada uno. Es una declaración del gerente y no hay ningún soporte contable en la carpeta. Calculé todo con `portafolio.py compute` y no sumé nada a mano, así que el informe no trae totales del portafolio.

- **Ejecutado mayor que comprometido:** PRY-210 (59,5% contra 36,1%) y PRY-211 (39,2% contra 33,2%). Eso no cuadra, y su «disponible real» no es confiable hasta aclararlo.
- **Proyección sobre el aprobado:** seis proyectos, PRY-201, 203, 206, 207, 209 y 210, entre +0,3% y +4,2%. Ninguno llega al umbral de 10%.
- **Comprometido cerca del tope:** PRY-207 (89,2%) y PRY-208 (86,9%), sin cruzar el umbral de 90%. En PRY-207 el ejecutado es solo 32,3%, pero el disponible real es 735.237.184 de 6.800.000.000.
- **Proyección desactualizada:** la de PRY-204 y la de PRY-205 son anteriores a su solicitud de cambio, con costo adicional declarado de 166.000.000 y 156.000.000.
- **Cambios sin acta:** cinco cambios aprobados con costo (PRY-201, 202, 204, 205, 207) dicen «autorizada por el comité», pero no hay acta que lo respalde. Ninguno movió el presupuesto aprobado de la ficha.
- **Ejecución contra avance:** PRY-200 tiene el gasto por delante del avance (53,1% ejecutado, 34% de avance declarado). PRY-206 va al revés (31,3% ejecutado, 89% de avance declarado).
- **Sin dato:** no hay línea base de costo (presupuesto original y vigente) en ninguna ficha, solo de cronograma. La desviación del presupuesto contra la línea base es `not_found`.

Ofrecí preparar la solicitud de cambio de presupuesto para los seis proyectos con proyección sobre el aprobado, empezando por PRY-203. También ofrecí el detalle por proveedor para PRY-207 y PRY-208, cuyos proveedores aún no revisé.

El informe completo está en `estado/corridas/salida-budget-tracking.md`.
