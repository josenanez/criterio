# Corrida · 2026-10-15-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view nómina empresarial

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:00:43 · **Fin:** 2026-10-15T19:01:18 · **Duración:** 35 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 20 | 60 | Producto de un solo proyecto (PRY-209), sin sección de producto. Verde declarado contradicho: avance 24,0 % vs 75-100 % del plan y 2 hitos cumplidos sin evidencia. 4 proyectos sin producto. No supe el área dueña de esos 4 ni dependencias de PRY-209. |

Por señal (`product-view`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 4, `variance_time` 3, `milestone_overdue` 2, `change_without_baseline` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Productos al 2026-10-15

Esta vista sale del cálculo del estado (`compute`) sobre 13 proyectos. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

**Nómina empresarial tiene un solo proyecto: PRY-209 Nómina electrónica.** La vista por producto no aporta nada con un solo proyecto, así que no armé sección de producto. Esto es lo que dice la ficha de ese proyecto:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209) | 4 señales | 2026-12-05 (PRY-209) | COP 9.500.000.000 | COP 6.750.954.901 |

**Lo que hay que ver en PRY-209**
- **Verde sin sustento.** El informe del 2026-09-28 declara verde con 24,0 % de avance. Con 3 de 4 hitos cumplidos, el plan sostiene entre 75 % y 100 %, una brecha de 51,0 puntos.
- **Dos hitos "cumplidos" sin evidencia.**
  - «Diseño funcional aprobado» vencía el 2026-03-22 (207 días).
  - «Ambiente de pruebas certificado» vencía el 2026-06-16 (121 días).
- **Dinero (traen las cuatro cifras).** Lo ejecutado es COP 3.509.937.301 (36,9 %) y lo comprometido es 71,1 %. La proyección es COP 9.666.666.238, 1,8 % sobre lo aprobado. Queda disponible COP 2.749.045.099.
- **Fechas.** Tiene línea base, sin replanificaciones y con 0 días de desviación. No hay proveedores registrados ni compromisos vencidos.
- **Faltan en la ficha** la autoridad (`identity.authority`) y la fase (`identity.phase`).

**Dependencias internas:** ninguna. El cálculo tampoco registra dependencias declaradas de PRY-209.

### Proyectos sin producto declarado
- PRY-202 Migración a la nube
- PRY-205 Prevención de lavado de activos
- PRY-208 Motor de decisión
- PRY-210 Portal de proveedores

Mientras no declaren producto, nadie puede responder por el conjunto al que sirven. No pude decir el área dueña de ninguno, porque el cálculo no la entrega y no la inventé.

La corrida quedó registrada como `2026-10-15-product-view-1`, con la salida completa en `estado/corridas/salida-product-view.md`. Las cifras salen del cálculo y las alertas contrastan lo declarado con la evidencia de la ficha. No sé qué se habló fuera de los documentos, y la verificación es de quien lea.
