# Corrida · 2026-10-15-pm-escalate-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-escalate (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T18:35:58 · **Fin:** 2026-10-15T18:37:12 · **Duración:** 74 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-escalate` | 1 | — | 58 | 15 | Dos paquetes: autoridad no declarada en el acta (primer punto) y CC-01 (+41 días, +82M COP) con la v2 ya trayendo los 41 días sin aprobación. Documento 1 (6 reprogramaciones) cumple el criterio pero no se armó: no hay evidencia de qué depende de él. No sabe: alcance de CC-01, si 2027-03-01 es alcanzable, cadencia real del comité, dependencias de otros proyectos (ninguna cargada). |

Por señal (`pm-escalate`): `commitment_overdue` 5, `commitment_rescheduled` 4, `milestone_met_without_evidence` 2, `commitment_undated` 2, `progress_vs_plan` 1, `declared_vs_evidence` 1

## Lo que el agente mostró

La corrida de `/pm-escalate` para PRY-210 quedó registrada con el paquete completo. El archivo está en `estado/PRY-210-portal-de-proveedores/corridas/salida-pm-escalate.md`. Los términos ya estaban vigentes, aceptados por José Francisco Ñáñez el 2026-10-15, así que no registré nada nuevo.

No indicaste tema, así que tomé lo que ya estaba marcado como escalable. Salen dos paquetes:

1. **Autoridad no declarada.** El acta de constitución nombra patrocinador, gerente y comité, pero no dice quién aprueba qué. Por eso va primero. La pregunta cerrada es si se hace una adenda al acta con la matriz de autoridad. Recomiendo la adenda en vez de dejarlo solo en la minuta del comité.
2. **CC-01** (+41 días, +82.000.000 COP). Las opciones son aprobar o revertir el cronograma a 2027-03-01. Recomiendo aprobar, pero antes la gerente tiene que completar el alcance de CC-01, porque el documento no dice qué se agrega.
   - **Plan sin respaldo:** el cronograma v2 ya trae «Salida a producción» en 2027-04-11, exactamente 41 días después de 2027-03-01, sin ningún cambio aprobado.
   - **Impacto:** el cálculo de impacto devolvió 0 proyectos alcanzados, pero eso solo significa que no hay dependencias cargadas. Los hitos propios que pasan por el cambio son el piloto del 2026-11-14 y la salida a producción.
   - **Doble conteo:** sumar 41 días otra vez al cierre del acta daría 2027-06-04, lo que cuenta doble.
   - **Consecuencia con fecha:** no encontré ninguna fecha en los documentos que haga costosa la falta de decisión, y lo dije en el paquete en vez de inventarla.

El «Enviar el documento 1» de Jorge Medina lleva seis reprogramaciones y cumple el criterio, pero no armé su paquete. Ningún documento dice qué depende de ese entregable, así que las opciones no tendrían costo.

No sé qué alcance agrega CC-01, si el 2027-03-01 es alcanzable ni cada cuánto sesiona el comité. La configuración dice semanal y las notas de hoy dicen «dos semanas». Tampoco abrí el .xlsx del cronograma: tomé sus fechas de la ficha del proyecto.
