# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T18:45:18 · **Fin:** 2026-10-15T18:45:58 · **Duración:** 40 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 23 | 60 | 89 documentos sin cambio, 0 por releer. 39 citas de PRY-210 no resuelven en el índice aunque los archivos existen en la carpeta del proyecto; causa probable de ruta relativa, no confirmada. No se modificó ninguna ficha. |

Por señal (`document-index`): `milestone_met_without_evidence` 20, `commitment_overdue` 8, `progress_vs_plan` 7, `vendor_deliverable_late` 4, `declared_vs_evidence` 4, `commitment_rescheduled` 4, `variance_time` 3, `milestone_overdue` 2, `change_without_baseline` 2, `commitment_undated` 2, `vendor_accepted_without_evidence` 1, `vendor_invoiced_without_delivery` 1, `rebaseline_unauthorized` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

No hay documentos cambiados, reguardados, renombrados, movidos ni borrados. Por eso no ofrezco `/portfolio-scan`.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

### Citas que dejaron de resolver
Hay 39 citas rotas, todas del proyecto PRY-210:

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-210 | identity (6), plan.start_date, plan.end_date, plan.scope_summary, plan.exclusions (12 campos en total) | `00-gobierno/2025-09-01-acta-constitucion.docx` |
| PRY-210 | declared (3) y money (5) (8 campos) | `20-seguimiento/2026-10-13-informe-avance.md` |
| PRY-210 | milestones[0..4]: name, baseline_date, current_date, state (20 campos) | `10-plan/2026-10-13-cronograma-v2.xlsx` |
| PRY-210 | milestones[0].evidence (1 campo) | `20-seguimiento/2026-10-11-acta-recibo-diseño-funcional-aprobado.pdf` |

Los cuatro archivos existen dentro de `documentos/proyectos/PRY-210-portal-de-proveedores/`, y el índice los cuenta como sin cambio. Lo más probable es una diferencia de ruta, pero no lo confirmé. La cita está escrita relativa a la carpeta del proyecto, y el índice la compara con la ruta completa desde la raíz de documentos.

No toqué ninguna ficha. Mientras no se corrija, el informe sigue mostrando esos 39 datos como sustentados aunque la cita no resuelva. Queda a decisión de una persona corregir las 39 citas una por una, o revisar cómo se escribe la ruta en la ficha de PRY-210.

### Formatos que no se pudieron leer
El índice no reportó ninguno. Este comando no lee contenido, así que no puedo decir más.

### Corrida registrada
La corrida quedó registrada como `2026-10-15-document-index-1` y duró 23 segundos. Contó 13 proyectos y no midió documentos. Ese número viene de las fichas, no del índice.

La corrida también guardó 60 hallazgos de otros comandos y proyectos. No los revisé aquí.

La salida completa está en `estado/corridas/salida-document-index.md`.
