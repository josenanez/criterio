# Plan — Portal de proveedores (PRY-210) · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-09-01 (`00-gobierno/2025-09-01-acta-constitucion.docx`) · **Criterio de éxito:** «Portal de proveedores en producción y medido.» (acta). No dice qué se mide, con qué cifra ni quién lo acepta.

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrar de nuevo.

**Antes de leer el borrador:** el proyecto no está en fase de arranque. El acta es de hace 13 meses y ya existen un cronograma v1 (2025-09-01) y uno v2 (2026-10-13), con 3 de 5 hitos cerrados. Este borrador no es la línea base: es una WBS reconstruida desde el acta para ver qué sostiene el acta hoy. No toca ni reemplaza el v1 ni el v2.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido.** Dice «Componente 1, Componente 2, Componente 3»; el fuera de alcance dice «Lo que otro proyecto cubre». Parecen plantillas sin llenar. | No hay entregables que descomponer. La WBS de abajo solo tiene nodos del cronograma, no del acta. La solicitud de cambio CC-01 («ampliación de alcance», +41 días, +82.000.000 COP) amplía un alcance que nadie escribió. |
| **Criterio de éxito sin medida.** «En producción y medido». | Sin cifra ni fecha de medición no se sabe cuándo está terminado ni qué entra en el alcance. Es el vacío más caro. |
| **Autoridad del gerente no declarada.** El acta no dice qué puede decidir Liliana Torres y qué sube al comité. | No se sabe qué puede decidir quien planifica y qué debe subir. |
| **Dependencias: «Ninguna declarada».** | Hay un proveedor en juego (las notas del 2026-10-15 dicen que podría no llegar con el equipo completo) y no hay contrato en la carpeta. Planificar sin dependencias esconde justo esa. |
| **Producto asociado: «No aplica».** | Para un portal con proveedores como usuarios, no hay producto cuya definición diga qué debe hacer. Nadie lo ha dicho; no lo supongo. |
| **Aceptante de los entregables.** El acta no nombra quién acepta qué. | No puedo llenar la columna «Quién lo acepta». |

Hay patrocinador (Andrés Lozano) y comité (Comité de Arquitectura), así que ese hallazgo no aplica. Sigo adelante marcando los huecos; no los relleno.

## WBS
Solo hay entregables citables en el cronograma; los componentes del acta no tienen nombre. La columna Duración queda vacía en todos: ninguna duración sale de un documento citable. Las fechas del v1 son compromisos ya hechos, no una duración propuesta.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Diseño funcional aprobado | Sin definir | Cronograma v1/v2 (hito, «cerrado»); acta de recibo 2026-10-11 firmada por Liliana Torres | — |
| 2 | Ambiente de pruebas certificado | Sin definir | Cronograma v1/v2 (hito, «cerrado»). No hay acta de recibo en la carpeta | — |
| 3 | Integración con el core | Sin definir | Cronograma v1/v2 (hito, «cerrado»). No hay acta de recibo en la carpeta | — |
| 4 | Piloto con usuarios internos | Sin definir | Cronograma v1/v2 (hito, «en curso») | — |
| 5 | Salida a producción | Sin definir | Cronograma v1/v2 (hito, «en curso»); acta: cierre 2027-04-24 | — |
| 6 | Medición del portal (la parte «medido» del criterio de éxito) | Sin definir | Acta, criterio de éxito. No existe como hito en ningún cronograma | — |
| 7 | Componentes 1, 2 y 3 del alcance | Sin definir | Acta, sin contenido | — |
| 8 | Ampliación de alcance CC-01 | Sin definir | Solicitud CC-01 (2026-10-04), «pendiente de presentación al comité» | — |

Los nodos 1 a 5 son hitos y no entregables recibibles por alguien con nombre; cada uno necesita que se diga qué documento o resultado se firma. Los nodos 6 a 8 no se pueden descomponer más sin que alguien defina el alcance.

Hay una contradicción: el hito «Diseño funcional aprobado» figura «cerrado» con fecha 2025-12-27, pero su acta de recibo es del 2026-10-11, unos 9 meses después. Alguien debe decir cuál fecha vale.

## Orden
Sin fechas. Lo que necesita qué:
- Diseño funcional aprobado → Ambiente de pruebas certificado → Integración con el core → Piloto con usuarios internos → Salida a producción → Medición.
  El orden de los hitos 1 a 5 es el que traen los cronogramas; la dependencia entre ellos no está escrita en ningún sitio, es la secuencia de la tabla.
- La Ampliación CC-01 depende de que el comité la apruebe; qué toca del orden anterior no se sabe, porque no dice qué amplía.
- La Medición depende de la Salida a producción y de que alguien defina «medido».

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los hitos del cronograma v2 son todo el alcance entregable. | Hay trabajo sin nodo, y las fechas de cierre no cubren el alcance real. |
| El orden de los hitos es una cadena estricta. | Si hay paralelismo, el camino crítico es otro y la ruta se acorta; si hay dependencias cruzadas no vistas, se alarga. |
| «Medido» significa medido después de producción, con una fecha posterior a la salida. | Si es antes, el nodo 6 se reordena; si no existe medición, el criterio de éxito no se puede cumplir. |
| El proveedor del que hablan las notas es una dependencia del piloto y la salida. | Si es de otra fase, el riesgo apunta a otro nodo. |

Estos pasan a riesgos del proyecto en cuanto el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los Componentes 1, 2 y 3 y qué queda fuera | Patrocinador (Andrés Lozano) con la gerente |
| Cifra y método de «medido» | Patrocinador |
| Quién acepta cada entregable | Patrocinador / Comité de Arquitectura |
| Autoridad de la gerente al planificar | Patrocinador / Comité |
| Qué amplía CC-01 y qué hace con el orden | Liliana Torres (solicitante) y el comité |
| Cuál es la fecha válida del diseño funcional (2025-12-27 u 2026-10-11) | Liliana Torres |
| Qué dice el contrato con el proveedor | No hay contrato en la carpeta; lo sabe quien lo tenga |

## Proyectos análogos
Ninguno a la vista: la configuración no apunta a una carpeta de fichas de la PMO, así que no busqué análogos. No es que no existan, es que no los miré. Sin ellos no hay ninguna referencia de plazos y no pongo ninguna.

## Preguntas para el equipo
Una por duración vacía:
1. ¿Cuánto toma terminar el Piloto con usuarios internos desde hoy, y qué lo cierra?
2. ¿Cuánto toma la Salida a producción desde el cierre del piloto?
3. ¿Cuánto toma medir el portal y cuándo se declara «medido»?
4. ¿Cuánto toma el trabajo de CC-01 y qué entregable nuevo produce?
5. ¿Cuánto toma cada uno de los Componentes 1, 2 y 3? Antes: ¿cuáles son?
6. Para los hitos «cerrados» (1 a 3): ¿dónde está la evidencia de recibo de cada uno? Solo el diseño funcional tiene acta.
7. ¿Quién acepta cada entregable?

## Para comprometer una fecha falta
- La disponibilidad real del equipo y del equipo de seguridad (el informe del 2026-10-13 lo marca como riesgo y no dice quiénes ni cuándo).
- La fecha del proveedor y si viene con el equipo completo (las notas del 2026-10-15 dicen que podría no llegar y nadie lo registró como riesgo).
- La ventana de producción para la salida.
- La decisión del comité sobre CC-01 (+41 días, +82.000.000 COP), que hoy no está presentada.

Nada de esto está en un documento.

## Lo que no hice
No comprometí fechas. No estimé por analogía. No asigné personas. No creé línea base: el v1 y el v2 existentes quedan como están.

## Después
Si el plan se aprueba, ofrezco registrar la línea base y pasar los supuestos al RAID con doliente. Hoy no hay nada que registrar: el acta no alcanza para aprobar un plan.
