# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 58 s · 15 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `commitment_rescheduled` | 4 |
| `milestone_met_without_evidence` | 2 |
| `commitment_undated` | 2 |
| `progress_vs_plan` | 1 |
| `declared_vs_evidence` | 1 |

Dos paquetes: autoridad no declarada en el acta (primer punto) y CC-01 (+41 días, +82M COP) con la v2 ya trayendo los 41 días sin aprobación. Documento 1 (6 reprogramaciones) cumple el criterio pero no se armó: no hay evidencia de qué depende de él. No sabe: alcance de CC-01, si 2027-03-01 es alcanzable, cadencia real del comité, dependencias de otros proyectos (ninguna cargada).

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — Portal de proveedores (PRY-210) · 2026-10-15

Preparado para Liliana Torres. No se indicó tema, así que tomé lo que ya estaba marcado como escalable en la ficha, la agenda y el acta. Salen **dos paquetes, en este orden**, y un tercer punto que cumple el criterio pero no armé.

---

## Paquete 1 — Primero: ¿quién puede decidir qué?

### ¿Se declara por escrito, en una adenda al acta de constitución, quién aprueba los cambios de alcance, fecha y presupuesto de PRY-210, y hasta qué monto y días decide la gerente por su cuenta?

**Quién decide:** Andrés Lozano (patrocinador) con el Comité de Arquitectura, que aprobó el presupuesto el 2025-09-01. Esto lo deduzco de quién aprobó el presupuesto; el acta no dice que ese comité apruebe cambios. · **Si no se decide hoy:** ningún documento da una fecha límite para este punto. Lo que sí cuesta: el Paquete 2 no tiene a quién ir. Si el comité del 2026-10-29 decide CC-01 sin esta declaración, la decisión puede devolverse con un «eso no lo decide este comité», como advierte el criterio.

El acta del 2025-09-01 nombra patrocinador, gerente y comité, pero no tiene sección de autoridad: no dice qué decide la gerente, qué decide el patrocinador ni qué decide el comité. Tampoco declara dependencias («Ninguna declarada»).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Adenda al acta con la matriz de autoridad (umbrales de días y de COP) | Ninguno | El tiempo de firmar una página. No tengo evidencia de cuánto tarda | Ninguno en COP |
| B. Declararlo en el comité del 2026-10-29 y dejarlo en la minuta | Ninguno | Inmediato | Ninguno en COP. La minuta vale menos que un acta firmada y se pierde entre seis más |

**Recomiendo:** A. Los umbrales los fija quien firma el acta, no yo. Con la matriz escrita, CC-01 se rutea sin discusión previa.

---

## Paquete 2 — CC-01: ¿se aprueba o se revierte el plan?

### ¿Se aprueba CC-01 (ampliación de alcance, +41 días, +82.000.000 COP) y se registra una línea base v2 con «Salida a producción» el 2027-04-11, o se rechaza y el cronograma vuelve al 2027-03-01?

**Quién decide:** el acta no lo declara (ver Paquete 1). Lo más probable: el Comité de Arquitectura, que aprobó el presupuesto, con Andrés Lozano como patrocinador. · **Si no se decide hoy:** «Salida a producción» sigue en 2027-04-11 en el cronograma v2 del 2026-10-13, contra 2027-03-01 de la línea base, sin ningún cambio aprobado. El plan vigente no tiene respaldo. CC-01 lleva 11 días «pendiente de presentación al comité» desde el 2026-10-04. No encontré en ningún documento una fecha de vencimiento ligada a esta decisión; el próximo hito fechado es el piloto del 2026-11-14, a 30 días.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Se amplía. **El documento no dice qué se agrega** | +41 días. La línea base v2 queda en 2027-04-11; la v1 (2027-03-01) no se borra | +82.000.000 COP. Sobre la proyección declarada (2.406.453.124) serían unos 2.488.453.124 COP, si se suman sin solapamiento (supuesto mío). Sobre lo aprobado (2.400.000.000) son +3,4 % de CC-01, y la proyección ya lo excede en 6.453.124 |
| B. Rechazar CC-01 y volver a 2027-03-01 | Sin ampliación | Hay que corregir la v2. **No hay evidencia de que 2027-03-01 sea alcanzable.** Nadie la ha contrastado | 0 COP adicionales por el cambio. La proyección ya está sobre lo aprobado |

**Recomiendo:** A, pero no con las cifras tal como están. La v2 ya trae los 41 días, así que decidir B obliga a rehacer un plan que ya se movió; y CC-01 no dice qué alcance compra. Pediría que la gerente complete el alcance de CC-01 antes del 2026-10-29. Es una recomendación con información incompleta, y lo digo.

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno | n/a | n/a | n/a |

`impact` devolvió 0 proyectos alcanzados. **Esto significa que no hay dependencias cargadas, no que nadie se afecte:** el acta declara «Ninguna declarada» y el estado de esta carpeta solo contiene PRY-210. El cálculo no estima cuántos días se mueve ningún otro proyecto.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Piloto con usuarios internos | 2026-11-14 | 30 |
| Salida a producción | 2027-04-11 | 178 |

Una advertencia sobre `impact` con `--days 41`: da un nuevo cierre de 2027-06-04 (2027-04-24 más 41). Pero la fecha vigente de «Salida a producción» (2027-04-11) ya es exactamente 41 días después de 2027-03-01, así que **la v2 parece traer CC-01 incorporado**. Si se vuelve a sumar, se cuenta doble. La fecha de cierre real depende de lo que diga la v2 sobre el cierre; la ficha no tiene hito de cierre.

---

## Tercer punto: lo que cumple el criterio y no armé

**«Enviar el documento 1» (Jorge Medina):** seis reprogramaciones, de 2026-09-17 a 2026-12-08 (82 días). Cumple «reprogramado tres veces». No armo el paquete porque ningún documento dice qué depende de ese entregable ni quién fuera del proyecto lo espera, y sin eso las opciones no tienen costo. Primero hay que nombrar el bloqueo (punto 1 de la agenda del 10-29). Con eso formulo la decisión.

**Lo que dejo fuera por no escalar:** «Cerrar la prueba 2» (Liliana Torres, 5 reprogramaciones) es compromiso de la gerente; lo decide ella y el patrocinador lo mira. Los vencidos de actas de recibo faltantes se resuelven con una llamada. El riesgo del proveedor sin registrar es de la gerente: asignar dueño no excede su autoridad.

---

### De dónde sale esto
- Autoridad no declarada, patrocinador, comité, presupuesto aprobado, «Ninguna declarada»: `00-gobierno/2025-09-01-acta-constitucion.docx` (leído completo).
- CC-01 (+41 días, +82.000.000 COP, «Pendiente de presentación al comité»): `20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md`.
- Salida a producción 2027-03-01 → 2027-04-11, sin cambio aprobado: `10-plan/2026-10-13-cronograma-v2.xlsx`, tal como lo transcribe la ficha `estado/…/records/PRY-210.json`. No abrí el .xlsx directamente.
- Presupuesto comprometido, ejecutado y proyección: `20-seguimiento/2026-10-13-informe-avance.md` (cifras declaradas por la gerente).
- Reprogramaciones del documento 1: minutas del comité `30-reuniones/2026-09-03` a `2026-10-08` y `2026-10-15-notas-reunion.txt`.
- Hitos y días: `portafolio.py impact --code PRY-210 --days 41`.

**Lo que no sé:** qué alcance agrega CC-01; si 2027-03-01 es alcanzable; si el comité aprobó o no el cronograma v2; si el comité sesiona cada semana o cada dos (la configuración dice semanal y las notas de hoy, «dos semanas»); y de otros proyectos que dependan de este, nada.

Este paquete no escala solo ni decide. Llevarlo al comité es tuyo. Si el comité decide, ofrezco registrar la decisión con su fecha en la ficha. El cambio de línea base se registra como control de cambios y la v1 no se toca.
