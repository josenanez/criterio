## Listo — PRY-210 · Portal de proveedores

Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

**Lo que miré:** 18 documentos · 7 de reunión (6 minutas del comité, de 2026-09-03 a 2026-10-08, y las notas del 2026-10-15) · la última del 2026-10-15. Las leí todas, de la más vieja a la más nueva, junto con las 6 actas de recibo. Todos los formatos se pudieron leer (.docx, .xlsx, .pdf, .md, .txt).
**Términos:** aceptados para la versión 0.3.10 (textos 1.1) por José Francisco Ñáñez el 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 5c505a87302a3766… (md) y cdc4d640b2648d1b… (pdf)

**Preguntas:** ninguna se contestó en vivo; tomé la sugerida en cada una.
- Quién eres: Liliana Torres, gerente de PRY-210 Portal de proveedores (patrocinador Andrés Lozano, Comité de Arquitectura), según el acta de constitución.
- Reunión de seguimiento: jueves, cada semana (las 7 reuniones caen en jueves). Ojo: las notas del 2026-10-15 dicen «próxima reunión en dos semanas»; dejé semanal y la próxima en 2026-10-29. Corrígelo si cambió la cadencia.
- Estado: `estado/PRY-210-portal-de-proveedores`, junto a la carpeta de documentos y fuera de ella.

### Lo que está abierto, y cuántas veces se ha movido
26 compromisos en total: 5 cumplidos con acta de recibo, 14 abiertos con fecha, 5 vencidos sin evidencia, 2 sin fecha.

Reprogramados (tres o más veces):
| Quién | Qué | Fecha original → vigente | Veces | Cita |
|---|---|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-09-17 → 2026-12-08 | 6 | `30-reuniones/2026-09-03-comite-semanal.md`; última fecha en `2026-10-15-notas-reunion.txt` («no alcanzó, se compromete para el 08/12/2026») |
| Liliana Torres | Cerrar la prueba 2 | 2026-09-15 → 2026-11-11 | 5 | `30-reuniones/2026-09-03-comite-semanal.md` … `2026-10-08-comite-semanal.md` |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-02 → 2026-11-27 | 4 | `30-reuniones/2026-09-10-comite-semanal.md` … `2026-10-08-comite-semanal.md` |
| Natalia Ospina | Revisar el anexo 3 | 2026-09-27 → 2026-11-05 | 3 | `30-reuniones/2026-09-03-comite-semanal.md` … `2026-10-08-comite-semanal.md` |

Vencidos sin evidencia al 2026-10-15:
| Quién | Qué | Venció | Días | Cita |
|---|---|---|---|---|
| Diana Molina | Revisar el anexo 11 | 2026-09-22 | 23 | `30-reuniones/2026-09-17-comite-semanal.md`. El 10-01 dijo que ya lo entregó; no se presentó acta |
| Paula Céspedes | Validar el ambiente 4 | 2026-09-25 | 20 | `30-reuniones/2026-09-03-comite-semanal.md`. El 09-17 dijo que ya lo entregó; no se presentó acta |
| Camilo Beltrán | Cerrar la prueba 10 | 2026-10-06 | 9 | `30-reuniones/2026-09-17-comite-semanal.md` |
| Laura Vélez | Confirmar la fecha 23 | 2026-10-11 | 4 | `30-reuniones/2026-10-08-comite-semanal.md` |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-14 | 1 | `30-reuniones/2026-10-08-comite-semanal.md` |

Otros abiertos con fecha (10): Rubén Cárdenas, punto 8 (2026-10-19, movido una vez); Carlos Peña, matriz 14 (2026-10-19, primera fecha); Sandra Gil, documento 17 (2026-10-24, una vez); Javier Hoyos, prueba 18 (2026-10-23, una vez); Camilo Beltrán, ambiente 20 (2026-10-23, una vez); Óscar Ramírez, punto 16 (2026-11-03, una vez); Mauricio Pérez, fecha 15 (2026-10-27, una vez) y punto 24 (2026-11-01); Ricardo Salas, diseño 21 (2026-10-27); Óscar Ramírez, revisión con el proveedor (2026-10-25, dicho el 10-15; puede ser el mismo punto 16, las notas no lo aclaran).

### Sin fecha
- María Restrepo — Revisar el anexo 19: «por definir» el 2026-10-01; el 10-08 dijo que ya lo entregó, sin acta. `30-reuniones/2026-10-01-comite-semanal.md`
- Laura Vélez — Mandar el ajuste del presupuesto: «la otra semana», sin día. `2026-10-15-notas-reunion.txt`

Estos no pueden estar vencidos, y por eso son los que desaparecen de los informes.

### Otras señales que levantó el cálculo
- **Estado declarado «verde» (informe del 2026-10-13) contra lo que sustentan los documentos:** el cálculo lo marca como contradicho por los vencidos, los reprogramados, el avance y los hitos sin acta de abajo.
- **Avance declarado 34%** frente a 3 de 5 hitos marcados cerrados en el cronograma, que sostienen entre 60% y 80%: 26 puntos por debajo.
- **Hitos declarados cerrados sin acta:** «Ambiente de pruebas certificado» (fecha 2026-04-13, 185 días) e «Integración con el core» (fecha 2026-07-29, 78 días). Solo «Diseño funcional aprobado» tiene acta (recibo del 2026-10-11).
- Cambio **CC-01** (ampliación de alcance, +41 días, 82.000.000 COP): pendiente de presentación al comité, sin decisión.
- Riesgo dicho en la reunión del 10-15 («el proveedor podría no llegar con el equipo completo para la siguiente fase») que, según las notas, nadie anotó como riesgo; lo dejé en la ficha sin dueño.

El estado lo declaras tú; esto es contra qué se ve.

### Qué le falta a tu carpeta
- Actas de recibo del «Ambiente de pruebas certificado» y de la «Integración con el core»: sin ellas un hito cerrado se ve igual que uno que no lo está.
- Actas de recibo de los compromisos que ya se dicen entregados (anexo 11, ambiente 4, anexo 19).
- El acta de constitución no declara facultad de decisión del gerente ni fase del proyecto; el producto asociado es «No aplica».
- Las notas del 2026-10-15 están sueltas en la raíz del proyecto, no en `30-reuniones/`, y no traen fechas escritas para varios acuerdos.

**Cuándo vuelvo:** el jueves 2026-10-29, la próxima reunión según las notas (cadencia semanal, jueves).

Ficha escrita en `estado/PRY-210-portal-de-proveedores/records/PRY-210.json`, sin sellar: leí las minutas, no el proyecto entero. Si quieres, la sello cuando confirmes que no falta nada por leer.
