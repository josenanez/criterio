# Portal de proveedores (PRY-210) — semana del 2026-10-09 al 2026-10-15

**Declara el gerente (esta semana):** SIN DECLARACIÓN. La sesión no tuvo interfaz y nadie respondió; el estado de esta semana queda en blanco y no lo propongo ni lo completo yo.
**Última declaración en los documentos** (no es la de esta semana): verde · 34 % · al 2026-10-13, con 2 días de antigüedad, vigente (`20-seguimiento/2026-10-13-informe-avance.md`). Es contra esa que se contrastó.
**Sustento documental:** contradicho. Hay 0 fuentes de evidencia, 4 de declaración y 35 sin marcar.
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos «cumplidos» sin evidencia y avance declarado por debajo de lo que el plan sostiene.

## Qué cambió esta semana
No hay comparación posible contra una corrida anterior: la de hoy es la primera foto guardada (`diff` devolvió 0 cambios, contra sí misma). No afirmo que no haya cambiado nada; afirmo que no hay con qué comparar. Desde la próxima corrida este cuadro tendrá contenido.

Lo que sí es nuevo en los documentos de esta semana:
| Qué | Estaba | Está |
|---|---|---|
| Informe de avance del 2026-10-13 | — | verde, 34 % |
| Notas de reunión del 2026-10-15 | — | «Enviar el documento 1» pasa al 2026-12-08 (6.ª vez); se abre «Mandar el ajuste del presupuesto» sin fecha; se menciona un riesgo del proveedor que nadie registró |
| Solicitud de cambio CC-01 (2026-10-04) | — | pendiente, sin decidir |

## Lo que sigue igual y sigue mal
Sin corrida anterior no puedo decir desde cuándo lo está el conjunto. Con la fecha de cada fuente:
| Qué | Desde | Días así |
|---|---|---|
| Diana Molina — Revisar el anexo 11 | 2026-09-22 | 23 |
| Paula Céspedes — Validar el ambiente 4 | 2026-09-25 | 20 |
| Camilo Beltrán — Cerrar la prueba 10 | 2026-10-06 | 9 |
| Laura Vélez — Confirmar la fecha 23 | 2026-10-11 | 4 |
| Andrés Lozano — Actualizar la matriz 22 | 2026-10-14 | 1 |
| Hito «Ambiente de pruebas certificado» marcado cumplido sin evidencia | 2026-04-13 | 185 |
| Hito «Integración con el core» marcado cumplido sin evidencia | 2026-07-29 | 78 |
| Fecha vigente de «Salida a producción» movida sin cambio aprobado | CC-01 pendiente desde 2026-10-04 | 11 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre del proyecto | 2027-04-24 | 2027-04-24 | 0 días |
| Hito «Salida a producción» | 2027-03-01 | 2027-04-11 | +41 días (+41 sobre la original) |
| Presupuesto | 2.400.000.000 COP | 2.400.000.000 COP | proyección +0,3 % (2.406.453.124) |

Replanificaciones de la línea base: 0. Solo existe la versión 1 (2025-09-01). El corrimiento del hito de salida (+41 días) coincide con el de CC-01 (+41 días y +82.000.000 COP), que está pendiente de presentación al comité. Es un movimiento de fecha sin cambio aprobado. La fecha de cierre del proyecto no se movió en el cálculo.
Avance: declarado 34 %; el plan sostiene entre 60 % y 80 % (3 de 5 hitos marcados cumplidos). Brecha de 26 puntos, **por debajo** del plan. Solo 1 de los 3 hitos «cumplidos» tiene evidencia.

### Hitos de las próximas cuatro semanas (hasta 2026-11-12)
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno cae en la ventana | | | |

El más cercano es «Piloto con usuarios internos»: base y vigente 2026-11-14, 30 días, sin evidencia. Hay 12 compromisos abiertos con fecha entre el 2026-10-19 y el 2026-11-11.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 865.619.680 (36,1 %) | 1.427.858.191 (59,5 %) | 2.406.453.124 | 1.534.380.320 |

Disponible real = aprobado − comprometido. Ojo: **lo ejecutado supera lo comprometido** (1.427,9 M contra 865,6 M), cosa que normalmente no ocurre; o falta registrar compromisos, o la cifra de ejecutado no sale de la misma base. No lo resuelvo yo: queda como pregunta. Fuente: informe de avance del 2026-10-13. La proyección es una declaración, no una medición. CC-01 sumaría 82.000.000 COP si se aprueba.

## Abierto
**Reprogramados** (umbral: 3 veces):
- Jorge Medina — Enviar el documento 1: **6 veces**, de 2026-09-17 a 2026-12-08.
- Liliana Torres — Cerrar la prueba 2: **5 veces**, de 2026-09-15 a 2026-11-11. La gerente es quien lo reprograma.
- Javier Hoyos — Confirmar la fecha 7: **4 veces**, de 2026-10-02 a 2026-11-27.
- Natalia Ospina — Revisar el anexo 3: **3 veces**, de 2026-09-27 a 2026-11-05.

**Vencidos sin evidencia:** Diana Molina (anexo 11, 23 días), Paula Céspedes (ambiente 4, 20 días), Camilo Beltrán (prueba 10, 9 días), Laura Vélez (fecha 23, 4 días), Andrés Lozano (matriz 22, 1 día; es también el patrocinador).
**Sin fecha:** María Restrepo — Revisar el anexo 19; Laura Vélez — Mandar el ajuste del presupuesto.
**RAID sin movimiento:** 2 riesgos y ningún dato de dueño, probabilidad, impacto ni último movimiento. «Disponibilidad del equipo de seguridad» está registrado; «El proveedor podría no llegar con el equipo completo» se comentó en la reunión del 2026-10-15 y **no está registrado**. No hay supuestos, incidencias ni dependencias registrados.
**Proveedor:** no hay proveedores en la ficha, aunque se habla de una «Revisión con el proveedor» (Óscar Ramírez, 2026-10-25) y del riesgo del equipo del proveedor. Sin contrato ni entregables no hay con qué contrastar lo facturado.

## Lo que necesito de alguien
- **Liliana Torres:** declarar el estado y el avance de esta semana, a la vista de las señales de arriba.
- **Liliana Torres:** poner evidencia de recibo en los hitos «Ambiente de pruebas certificado» y «Integración con el core», o corregir su estado.
- **Comité de Arquitectura (excede la autoridad del gerente):** decidir CC-01 (+41 días, +82.000.000 COP) y la fecha vigente de «Salida a producción» (2027-04-11), que ya se movió sin decisión. Es material de comité, no de este informe.
- **Jorge Medina, Liliana Torres, Javier Hoyos:** una fecha realista o una decisión de recortar o cancelar el compromiso; llevan 6, 5 y 4 reprogramaciones.
- **Andrés Lozano:** su compromiso (matriz 22) venció ayer.
- **Liliana Torres:** registrar el riesgo del proveedor con dueño y aclarar por qué lo ejecutado supera lo comprometido.

## Lo que no se sabe
**Sin dato:** producto (el acta dice «No aplica»), autoridad, fase, proveedores, y dueño de ambos riesgos. Además 10 campos de identidad y plan vienen del acta del 2025-09-01, con 13 meses de antigüedad (umbral 12).
**Silencio:** el último documento es del 2026-10-15 (0 días) y la última reunión con acta es del 2026-10-08 (7 días; el día 15 solo hay notas sueltas). El silencio no es el problema aquí: es que lo que se escribe no trae evidencia. 35 de 39 fuentes son «sin marcar».

---
**Origen:** ficha `records/PRY-210.json` (actualizada el 2026-10-15, no sellada), corte al 2026-10-15; 3 campos sin dato (producto, autoridad, fase) más proveedores y dueño de los riesgos. 15 señales abiertas. Términos aceptados (v1.1, José Francisco Ñáñez, 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal

**Qué sigue:** hay un compromiso reprogramado 6 veces y un verde contradicho por la evidencia. Si lo quieres, armo el punto de comité con la decisión formulada (`/pm-escalate`) y publico la ficha para la PMO (`/pm-publish`).
