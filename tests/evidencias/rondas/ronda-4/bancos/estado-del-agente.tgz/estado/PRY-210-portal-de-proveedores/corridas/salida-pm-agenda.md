## Reunión de seguimiento — Portal de proveedores (PRY-210) · 2026-10-29
9 puntos · 44 minutos · 7 personas requeridas (Jorge Medina, Liliana Torres, Andrés Lozano, Javier Hoyos, Natalia Ospina, Camilo Beltrán, Laura Vélez)

Supuestos de esta agenda: no se indicó duración, así que armé 45 minutos. La fecha es el `committee_next` de la configuración (2026-10-29); coincide con las notas de hoy, que dicen «próxima reunión en dos semanas». El dato es del 2026-10-15. Vuelve a correr `/pm-agenda` la mañana del 10-29, porque ocho compromisos vencen antes y habrá que mirar cuáles quedaron sin evidencia.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y quién lo destraba, o sacarlo a comité** · 10 min · **Jorge Medina** (con Andrés Lozano)
> Prometido para el 2026-12-08, y antes para el 11-24, 11-10, 10-30, 10-09 y 09-29. Original: 2026-09-17. Seis reprogramaciones, 82 días sobre la promesa original.
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md` y cada minuta posterior; última fecha en `2026-10-15-notas-reunion.txt` («no alcanzó, se compromete para el 08/12/2026», leída día/mes/año).
> **Si no se resuelve hoy:** hay una séptima fecha. En seis reuniones el tiempo solo ha empeorado.

> **[2] Cerrar la prueba 2: causa y fecha que el patrocinador avale, o reasignar** · 5 min · **Liliana Torres** (decide Andrés Lozano)
> Prometido para el 2026-11-11, y antes para el 11-02, 10-26, 10-12 y 09-24. Original: 2026-09-15. Cinco reprogramaciones. El doliente es la gerente: la decisión es del patrocinador.
> Fuente: `30-reuniones/2026-10-08-comite-semanal.md` y minutas anteriores.
> **Si no se resuelve hoy:** sigue corriendo sin que nadie distinto de la gerente la mire.

> **[3] Confirmar la fecha 7: qué falta para que sea una fecha real** · 5 min · **Javier Hoyos**
> Prometido para el 2026-11-27, y antes para el 11-19, 11-04 y 10-18. Original: 2026-10-02. Cuatro reprogramaciones.
> Fuente: `30-reuniones/2026-10-08-comite-semanal.md`.
> **Si no se resuelve hoy:** pasa a quinta reprogramación.

> **[4] Revisar el anexo 3: fecha firme o por qué no** · 5 min · **Natalia Ospina**
> Prometido para el 2026-11-05, y antes para el 10-28 y el 10-12. Original: 2026-09-27. Tres reprogramaciones, el umbral configurado (`reschedules_to_flag: 3`).
> Fuente: `30-reuniones/2026-09-24-comite-semanal.md`.
> **Si no se resuelve hoy:** cruza el umbral y entra al material de comité como patrón.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Camilo Beltrán | Cerrar la prueba 10 (#10) | 2026-10-06 | Acta de recibo, o fecha nueva dicha en voz alta. Figura con la misma fecha en las minutas del 09-24, 10-01 y 10-08; no consta reprogramación. | 2 |
| Laura Vélez | Confirmar la fecha 23 (#23) y poner día al ajuste del presupuesto (#25) | 2026-10-11 | Asistió el 10-15 y las notas no mencionan el #23. El #25 se dijo «la otra semana» sin día: que salga con fecha. | 3 |
| Andrés Lozano | Actualizar la matriz 22 (#22) | 2026-10-14 | Es el patrocinador: acta de recibo o fecha. Venció un día antes de las notas de hoy. | 2 |

Fuente: `30-reuniones/2026-10-08-comite-semanal.md` (los tres); #25 en `2026-10-15-notas-reunion.txt`.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **CC-01**, ampliación de alcance: +41 días y +82.000.000 COP. Lleva desde el 2026-10-04 «pendiente de presentación al comité». Fuente: `20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md`. | Comité (Andrés Lozano como patrocinador) | «Salida a producción» ya figura en 2027-04-11 en el cronograma v2, contra 2027-03-01 de la línea base, sin un cambio aprobado (`10-plan/2026-10-13-cronograma-v2.xlsx`). Sin decisión, el plan vigente no tiene respaldo. | 8 |
| **Riesgo del proveedor**: «podría no llegar con el equipo completo para la siguiente fase». Dicho el 10-15, nadie lo registró. Fuente: `2026-10-15-notas-reunion.txt`. | Liliana Torres asigna dueño; la sala valora | Sigue sin dueño, probabilidad ni impacto. La ficha no tiene ningún proveedor cargado, así que tampoco hay contrato al que atarlo. | 4 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 8 (#8) | 2026-10-19 (una reprogramación; antes 10-04) |
| Carlos Peña | Actualizar la matriz 14 (#14) | 2026-10-19 (primera fecha) |
| Javier Hoyos | Cerrar la prueba 18 (#18) | 2026-10-23 (una reprogramación; antes 10-09) |
| Camilo Beltrán | Validar el ambiente 20 (#20) | 2026-10-23 (una reprogramación; antes 10-07) |
| Sandra Gil | Enviar el documento 17 (#17) | 2026-10-24 (una reprogramación; antes 10-16) |
| Óscar Ramírez | Revisión con el proveedor (#26) | 2026-10-25, domingo. Puede ser el #16 reformulado; las notas no lo dicen. |
| Mauricio Pérez | Confirmar la fecha 15 (#15) | 2026-10-27 (una reprogramación; antes 10-20) |
| Ricardo Salas | Aprobar el diseño 21 (#21) | 2026-10-27 |

Fuente: minutas del 09-24, 10-01 y 10-08, y `2026-10-15-notas-reunion.txt`. No llevan minutos: se piden avisos antes de la fecha, no se discuten en la sala.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Paula Céspedes, Validar el ambiente 4 (#4), vencido desde 2026-09-25 | Dijo el 09-17 que ya lo entregó; no hay acta. Último comité al que asistió: 2026-09-10. | La gerente pide el acta directo. Si no aparece, pasa a agenda con la persona citada. |
| Diana Molina, Revisar el anexo 11 (#11), vencido desde 2026-09-22 | Dijo el 10-01 que ya lo entregó; no hay acta. No asistió el 10-08 ni el 10-15. | Igual: acta directa, o citarla. |
| María Restrepo, Revisar el anexo 19 (#19), sin fecha | Dijo el 10-08 que ya lo entregó; no hay acta. No asistió el 10-15. | Igual. Además hay que ponerle fecha o cerrarlo con acta. |
| Informe de avance en «verde» y 34 % | El informe del 10-13 lo contradicen cuatro señales del cálculo. Es del gerente y del informe, no de la sala. | `/pm-report` |
| Cadencia del comité | La configuración dice semanal y las seis minutas previas lo son; las notas de hoy dicen «dos semanas». | Liliana Torres confirma cuál rige y se corrige la configuración con `/pm-setup`. |

### Anexo — sin cambios desde el 2026-10-15
- Mauricio Pérez · Entregar el punto 24 (#24) · 2026-11-01
- Óscar Ramírez · Entregar el punto 16 (#16) · 2026-11-03 (una reprogramación)

### Lo que quedó fuera por tiempo
Nada: los 9 puntos suman 44 de 45 minutos. Si la reunión dura menos de 45, corta por el final de la lista, que son el riesgo del proveedor y luego CC-01, y dilo en la reunión.

### Después
Cuando termine la reunión, `/pm-minutes` sobre las notas. Cierra el ciclo: los compromisos que salgan entran a `/pm-commitments` con su cita. Para el punto 1 puedo formular la decisión con `/pm-escalate`. Esta agenda no convoca a nadie; eso es de la gerente.
