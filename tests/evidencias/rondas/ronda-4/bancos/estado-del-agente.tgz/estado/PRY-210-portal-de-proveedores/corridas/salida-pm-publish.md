Términos: ya vigentes (versión 0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

Recalculé antes de publicar (corte 2026-10-15). Antes de escribir: la ficha lleva 39 campos con dato y 3 sin decir en ninguna parte (producto, autoridad, fase); el más viejo es del 2025-09-01; y el estado declarado es **verde** al 2026-10-13, tuyo, marcado como declarado.

Publiqué la ficha en `documentos/proyectos/PRY-210-portal-de-proveedores/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 39 campos con dato · 3 sin decir en ninguna parte · declara **verde** al 2026-10-13

**Lo más viejo que va ahí:** acta de constitución, del 2025-09-01 (10 campos de identidad y plan, incluidos patrocinador, gerente, comité y fecha de fin) — pasa de un año: 13 meses.

Dos cosas que conviene saber antes de que la PMO la lea:
- El estado declarado es verde y el recálculo lo contradice con cuatro señales: avance declarado 34 % contra 60–80 % que sostiene el plan, dos hitos «cumplidos» sin acta de recibo, compromisos vencidos y compromisos reprogramados varias veces.
- De los ocho campos que Vera contrasta, `identity.product` no está en ninguna parte (el acta dice «No aplica»); los otros siete llevan dato.
