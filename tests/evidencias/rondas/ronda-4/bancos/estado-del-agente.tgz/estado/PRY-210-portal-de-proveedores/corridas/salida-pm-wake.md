## Portal de proveedores (PRY-210) · 2026-10-15

**Revisé:** 19 documentos · 19 nuevos para el índice (primera vez que se indexa la carpeta; no hay corrida anterior con qué comparar) · 7 minutas/notas ya extraídas en la ficha (6 comités, 09-03 a 10-08, y las notas de hoy). Nada nuevo que extraer: la ficha ya las traía.

### Lo que se venció solo
Sin corrida anterior no puedo decir qué cruzó *desde* ayer; esto es lo que está cruzado hoy según `compute`:

- **Compromisos vencidos sin evidencia (5):** Diana Molina, «Revisar el anexo 11» (2026-09-22, 23 días); Paula Céspedes, «Validar el ambiente 4» (09-25, 20 días); Camilo Beltrán, «Cerrar la prueba 10» (10-06, 9 días); Laura Vélez, «Confirmar la fecha 23» (10-11, 4 días); Andrés Lozano, «Actualizar la matriz 22» (10-14, 1 día; el único que venció ayer).
- **Reprogramados al umbral de 3 (4):** Jorge Medina «Enviar el documento 1» ×6; Liliana Torres «Cerrar la prueba 2» ×5; Javier Hoyos «Confirmar la fecha 7» ×4; Natalia Ospina «Revisar el anexo 3» ×3.
- **Sin fecha (2):** María Restrepo, «Revisar el anexo 19»; Laura Vélez, «Mandar el ajuste del presupuesto».
- **Hitos dados por cumplidos sin evidencia (2):** «Ambiente de pruebas certificado» (2026-04-13) e «Integración con el core» (2026-07-29).
- **Avance declarado vs plan:** el informe del 10-13 declara verde y 34 %; el plan sostiene entre 60 % y 80 % (3 de 5 hitos). Cuatro señales contradicen el verde. Este comando no declara el estado.

### La reunión
Falta 14 días (2026-10-29): no toca agenda todavía. El acta de hoy ya se redactó con `/pm-minutes`, así que no falta acta. El informe toca el 2026-10-28 (un día antes).
Las notas de hoy dicen «próxima reunión en dos semanas», pero la configuración dice comité semanal; conviene aclarar cuál vale.

### Tu ficha publicada
Se publicó hoy y ningún campo cambió desde entonces; no está vieja.

**Vuelvo el 2026-10-16.**
