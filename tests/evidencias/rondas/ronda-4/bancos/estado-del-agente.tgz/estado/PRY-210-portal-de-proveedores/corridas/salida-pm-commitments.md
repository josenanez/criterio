## Compromisos — Portal de proveedores (PRY-210) · al 2026-10-15

26 compromisos en la ficha: 21 abiertos y 5 cerrados con documento. De los 21 abiertos: 4 reprogramados 3 veces o más, 5 vencidos sin evidencia, 2 sin fecha. Cifras de `portafolio.py compute`.

### Se viene reprogramando

> **Jorge Medina** · Enviar el documento 1 (#1)
> Prometido para el 2026-12-08, y antes para el 11-24, 11-10, 10-30, 10-09 y 09-29. La promesa original era el 2026-09-17.
> **Seis reprogramaciones, 82 días corridos sobre la promesa original. Las notas de hoy dicen «no alcanzó». Esto no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuente: `30-reuniones/2026-09-03-comite-semanal.md` y cada minuta posterior; la última fecha sale de `2026-10-15-notas-reunion.txt`, escrita «08/12/2026» y leída día/mes/año.

> **Liliana Torres** · Cerrar la prueba 2 (#2)
> Prometido para el 2026-11-11, y antes para el 11-02, 10-26, 10-12 y 09-24. Original: 2026-09-15. **Cinco veces.** Es la gerente del proyecto.

> **Javier Hoyos** · Confirmar la fecha 7 (#7)
> Prometido para el 2026-11-27, y antes para el 11-19, 11-04 y 10-18. Original: 2026-10-02. **Cuatro veces.**

> **Natalia Ospina** · Revisar el anexo 3 (#3)
> Prometido para el 2026-11-05, y antes para el 10-28 y el 10-12. Original: 2026-09-27. **Tres veces**, que es el umbral de la configuración (`reschedules_to_flag: 3`).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Diana Molina | Revisar el anexo 11 (#11) | 2026-09-22 | 23 días |
| Paula Céspedes | Validar el ambiente 4 (#4) | 2026-09-25 | 20 días |
| Camilo Beltrán | Cerrar la prueba 10 (#10) | 2026-10-06 | 9 días |
| Laura Vélez | Confirmar la fecha 23 (#23) | 2026-10-11 | 4 días |
| Andrés Lozano | Actualizar la matriz 22 (#22) | 2026-10-14 | 1 día |

- **Paula Céspedes (#4):** dijo el 2026-09-17 que ya lo entregó; no hay acta de recibo ni otro documento en el expediente que lo respalde. Desde esa reunión sale de la lista sin cerrarse.
- **Diana Molina (#11):** dijo el 2026-10-01 que ya lo entregó; no hay acta de recibo.
- **Camilo Beltrán (#10):** figura con la misma fecha en las minutas del 09-24, 10-01 y 10-08, y no hay acta de recibo. No consta que se haya reprogramado: la fecha simplemente quedó pasada.
- **Laura Vélez (#23)** asistió a la reunión de hoy y las notas no mencionan el compromiso. Diana Molina y Paula Céspedes no asistieron.
- **Andrés Lozano (#22)** es el patrocinador del proyecto; venció ayer.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Rubén Cárdenas | Entregar el punto 8 (#8) | 2026-10-19 (prometido antes para el 10-04; una reprogramación) |
| Carlos Peña | Actualizar la matriz 14 (#14) | 2026-10-19 (primera fecha; estaba «por definir» hasta el 10-08) |

Lo siguiente cae el 2026-10-23: Javier Hoyos (#18, una reprogramación) y Camilo Beltrán (#20, una reprogramación).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| María Restrepo | Revisar el anexo 19 (#19) | 2026-10-01 |
| Laura Vélez | Mandar el ajuste del presupuesto (#25) | 2026-10-15 |

No pueden estar vencidos y por eso se cuentan aparte. María Restrepo dijo el 2026-10-08 que ya lo entregó; no hay acta de recibo. En el de Laura Vélez se dijo «la otra semana» y nadie dijo día: no se convirtió en fecha.

### Cerrados desde la última revisión
Cinco compromisos están cumplidos contra un acta de recibo:

| Quién | Qué | Documento que lo cierra |
|---|---|---|
| Rubén Cárdenas | Aprobar el diseño 5 (#5) | `20-seguimiento/2026-10-01-acta-recibo-5.md` |
| Laura Vélez | Actualizar la matriz 6 (#6) | `20-seguimiento/2026-10-01-acta-recibo-6.md` |
| Mauricio Pérez | Enviar el documento 9 (#9) | `20-seguimiento/2026-10-01-acta-recibo-9.md` |
| Camilo Beltrán | Validar el ambiente 12 (#12) | `20-seguimiento/2026-09-24-acta-recibo-12.md` |
| Diana Molina | Aprobar el diseño 13 (#13) | `20-seguimiento/2026-10-08-acta-recibo-13.md` |

### A tener en cuenta
- **#26 Óscar Ramírez, «Revisión con el proveedor», 2026-10-25:** las notas de hoy lo presentan como compromiso nuevo. Puede ser el mismo que «Entregar el punto 16» (#16, 2026-11-03, ya reprogramado una vez); las notas no lo dicen y no se fusionó. El 25 cae domingo.
- El informe de avance del 2026-10-13 declara «verde»; el cálculo lo contrasta con cuatro señales, entre ellas los compromisos vencidos y reprogramados.

### Después
Hay cuatro compromisos reprogramados tres veces o más. Puedo formular el de Jorge Medina (#1) como decisión para el comité con `/pm-escalate`: qué se pide, qué pasa si no se decide y quién tiene la facultad. Eso excede la autoridad del gerente y por eso sube. El #2 es de la propia gerente; la decisión le corresponde al patrocinador o al comité. No hace falta `/pm-publish`: esta corrida no cambió nada de la ficha.

### Lo que no hace este informe
No le escribe a nadie ni juzga por qué no se cumplió cada compromiso; eso es del gerente.
