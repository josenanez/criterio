<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-06-acta-recibo-piloto-con-usuarios-internos.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Piloto con usuarios internos
Proyecto: PRY-211 · Cobranza digital
Fecha de recibo: 2026-10-06
Recibido por: Laura Vélez
Se recibe a satisfacción el entregable Piloto con usuarios internos.
