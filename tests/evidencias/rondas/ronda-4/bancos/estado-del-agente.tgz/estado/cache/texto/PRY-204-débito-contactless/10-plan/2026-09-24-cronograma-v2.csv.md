<!-- origen: PRY-204-débito-contactless/10-plan/2026-09-24-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-01-22,2026-01-22,cerrado
Ambiente de pruebas certificado,2026-04-11,2026-04-11,cerrado
Integración con el core,2026-06-29,2026-06-29,cerrado
Piloto con usuarios internos,2026-09-17,2026-09-17,cerrado
Salida a producción,2026-12-05,2027-02-26,en curso
