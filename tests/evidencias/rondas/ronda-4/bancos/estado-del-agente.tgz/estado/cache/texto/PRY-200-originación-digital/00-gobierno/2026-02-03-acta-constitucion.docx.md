<!-- origen: PRY-200-originación-digital/00-gobierno/2026-02-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Banca de Personas

Patrocinador: Paula Céspedes

Gerente de proyecto: Diana Molina

Comité: Comité de Medios de Pago

Producto asociado: crédito de consumo

Fecha de aprobación: 2026-02-03

Objetivo del negocio

Entregar originación digital para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Medios de Pago el 2026-02-03.

Fechas comprometidas

Fecha

Inicio

2026-02-13

Cierre

2027-09-02

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
