<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-09-01-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-12-27 | 2025-12-27 | cerrado
Ambiente de pruebas certificado | 2026-04-13 | 2026-04-13 | cerrado
Integración con el core | 2026-07-29 | 2026-07-29 | cerrado
Piloto con usuarios internos | 2026-11-14 | 2026-11-14 | en curso
Salida a producción | 2027-03-01 | 2027-03-01 | en curso
