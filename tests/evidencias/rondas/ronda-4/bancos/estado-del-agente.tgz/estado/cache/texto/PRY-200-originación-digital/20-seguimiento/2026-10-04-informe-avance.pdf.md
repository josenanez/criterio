<!-- origen: PRY-200-originación-digital/20-seguimiento/2026-10-04-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Originación digital
Código: PRY-200
Fecha de corte: 2026-10-04
Gerente: Diana Molina

Estado declarado
Rojo
Avance reportado: 34%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.426.973.144
Ejecutado 1.752.697.435
Proyección al cierre 3.273.985.487

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- El proveedor no ha confirmado la fecha de la última entrega
