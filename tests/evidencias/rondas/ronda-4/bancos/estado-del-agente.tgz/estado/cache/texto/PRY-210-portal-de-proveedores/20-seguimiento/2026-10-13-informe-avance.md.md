<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Portal de proveedores

**Código:** PRY-210
**Fecha de corte:** 2026-10-13
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **34%**

## Lo que pasó en el periodo

- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 865.619.680 |
| Ejecutado | 1.427.858.191 |
| Proyección al cierre | 2.406.453.124 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
