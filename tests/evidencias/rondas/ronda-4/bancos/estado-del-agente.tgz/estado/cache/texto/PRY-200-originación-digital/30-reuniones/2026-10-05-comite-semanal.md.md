<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Originación digital

**Fecha:** 2026-10-05
**Asistentes:** Diana Molina, Paula Céspedes

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 28 | 2026-10-17 |
