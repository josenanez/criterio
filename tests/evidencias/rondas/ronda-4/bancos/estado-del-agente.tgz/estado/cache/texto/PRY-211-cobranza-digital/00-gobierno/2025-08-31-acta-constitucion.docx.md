<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-08-31-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Banca de Personas

Patrocinador: Liliana Torres

Gerente de proyecto: Laura Vélez

Comité: Comité de Riesgos

Producto asociado: recaudos

Fecha de aprobación: 2025-08-31

Objetivo del negocio

Entregar cobranza digital para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Riesgos el 2025-08-31.

Fechas comprometidas

Fecha

Inicio

2025-09-10

Cierre

2026-06-26

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
