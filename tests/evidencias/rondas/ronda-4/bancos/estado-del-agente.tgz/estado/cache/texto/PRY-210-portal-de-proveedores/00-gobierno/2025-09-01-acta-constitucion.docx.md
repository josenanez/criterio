<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-09-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Banca de Personas

Patrocinador: Andrés Lozano

Gerente de proyecto: Liliana Torres

Comité: Comité de Arquitectura

Producto asociado: No aplica

Fecha de aprobación: 2025-09-01

Objetivo del negocio

Entregar portal de proveedores para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Arquitectura el 2025-09-01.

Fechas comprometidas

Fecha

Inicio

2025-09-11

Cierre

2027-04-24

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
