<!-- origen: PRY-207-onboarding-pyme/30-reuniones/2026-10-07-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Onboarding PyME

**Fecha:** 2026-10-07
**Asistentes:** Camilo Beltrán, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |
