<!-- origen: PRY-207-onboarding-pyme/10-plan/2025-06-05-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-10-14,2025-10-14,cerrado
Ambiente de pruebas certificado,2026-02-13,2026-02-13,cerrado
Integración con el core,2026-06-15,2026-06-15,cerrado
