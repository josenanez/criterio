<!-- origen: PRY-208-motor-de-decisión/10-plan/2026-02-22-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | cerrado
Ambiente de pruebas certificado | 2026-06-22 | 2026-06-22 | cerrado
Integración con el core | 2026-08-16 | 2026-08-16 | cerrado
Piloto con usuarios internos | 2026-10-11 | 2026-10-11 | en curso
Salida a producción | 2026-12-05 | 2026-12-05 | en curso
