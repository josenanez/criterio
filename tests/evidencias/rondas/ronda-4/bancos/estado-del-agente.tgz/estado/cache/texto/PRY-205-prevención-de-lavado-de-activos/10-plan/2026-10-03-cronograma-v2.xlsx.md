<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-10-03-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | cerrado
Ambiente de pruebas certificado | 2026-07-07 | 2026-07-07 | cerrado
Integración con el core | 2026-09-15 | 2026-12-02 | cerrado
