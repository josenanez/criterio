<!-- origen: PRY-208-motor-de-decisión/30-reuniones/2026-10-06-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Motor de decisión

**Fecha:** 2026-10-06
**Asistentes:** Sandra Gil, Beatriz Cuéllar

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 17 | 2026-11-09 |
