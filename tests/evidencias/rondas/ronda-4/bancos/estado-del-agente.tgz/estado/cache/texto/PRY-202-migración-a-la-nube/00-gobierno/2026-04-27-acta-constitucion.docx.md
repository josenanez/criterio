<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2026-04-27-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Operaciones

Patrocinador: Andrés Lozano

Gerente de proyecto: Laura Vélez

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2026-04-27

Objetivo del negocio

Entregar migración a la nube para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Transformación Digital el 2026-04-27.

Fechas comprometidas

Fecha

Inicio

2026-05-07

Cierre

2027-01-29

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
