<!-- origen: PRY-211-cobranza-digital/10-plan/2025-08-31-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-11-13,2025-11-13,cerrado
Ambiente de pruebas certificado,2026-01-16,2026-01-16,cerrado
Integración con el core,2026-03-21,2026-03-21,cerrado
Piloto con usuarios internos,2026-05-24,2026-05-24,cerrado
