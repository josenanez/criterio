<!-- origen: PRY-203-open-banking/00-gobierno/2026-06-12-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Operaciones

Patrocinador: Mauricio Pérez

Gerente de proyecto: María Restrepo

Comité: Comité de Medios de Pago

Producto asociado: APIs de datos

Fecha de aprobación: 2026-06-12

Objetivo del negocio

Entregar open banking para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Medios de Pago el 2026-06-12.

Fechas comprometidas

Fecha

Inicio

2026-06-22

Cierre

2027-08-27

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
