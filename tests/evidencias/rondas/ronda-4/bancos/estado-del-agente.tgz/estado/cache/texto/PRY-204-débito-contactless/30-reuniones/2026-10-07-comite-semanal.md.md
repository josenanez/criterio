<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-07-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Débito contactless

**Fecha:** 2026-10-07
**Asistentes:** Jorge Medina, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 31 | 2026-09-26 |
