<!-- origen: PRY-203-open-banking/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Open Banking

**Código:** PRY-203
**Fecha de corte:** 2026-10-11
**Gerente:** María Restrepo

## Estado declarado

**Rojo**

Avance reportado: **88%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 626.908.903 |
| Ejecutado | 520.498.073 |
| Proyección al cierre | 1.250.542.318 |

## Riesgos abiertos

- Cambio regulatorio en discusión que puede mover el alcance
- Concentración del conocimiento en una sola persona
