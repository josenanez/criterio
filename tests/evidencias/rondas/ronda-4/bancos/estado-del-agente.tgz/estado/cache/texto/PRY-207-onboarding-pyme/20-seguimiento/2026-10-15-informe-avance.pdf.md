<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Onboarding PyME
Código: PRY-207
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Amarillo
Avance reportado: 40%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 6.064.762.816
Ejecutado 2.194.353.672
Proyección al cierre 6.886.375.731

Riesgos abiertos
- Concentración del conocimiento en una sola persona
