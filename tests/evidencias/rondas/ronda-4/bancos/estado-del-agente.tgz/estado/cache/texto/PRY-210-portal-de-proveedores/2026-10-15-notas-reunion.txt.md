<!-- origen: PRY-210-portal-de-proveedores/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión portal de proveedores — 2026-10-15
estuvieron: Andrés Lozano, Camilo Beltrán, Carlos Peña, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Mauricio Pérez, Natalia Ospina, Ricardo Salas, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Jorge Medina dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 08/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
