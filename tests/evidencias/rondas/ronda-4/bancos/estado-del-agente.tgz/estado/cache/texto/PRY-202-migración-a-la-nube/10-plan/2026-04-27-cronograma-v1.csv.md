<!-- origen: PRY-202-migración-a-la-nube/10-plan/2026-04-27-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-07-22,2026-07-22,cerrado
Ambiente de pruebas certificado,2026-10-06,2026-10-06,en curso
Integración con el core,2026-12-21,2026-12-21,en curso
