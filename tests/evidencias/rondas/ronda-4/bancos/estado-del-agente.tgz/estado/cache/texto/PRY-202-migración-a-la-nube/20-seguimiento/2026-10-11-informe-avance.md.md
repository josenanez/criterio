<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-11
**Gerente:** Laura Vélez

## Estado declarado

**Amarillo**

Avance reportado: **50%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.770.463.432 |
| Ejecutado | 2.449.444.833 |
| Proyección al cierre | 6.421.718.591 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
