<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Billetera y QR
Código: PRY-206
Fecha de corte: 2026-10-12
Gerente: María Restrepo

Estado declarado
Verde
Avance reportado: 89%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.410.902.312
Ejecutado 1.032.384.656
Proyección al cierre 3.341.040.792

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
