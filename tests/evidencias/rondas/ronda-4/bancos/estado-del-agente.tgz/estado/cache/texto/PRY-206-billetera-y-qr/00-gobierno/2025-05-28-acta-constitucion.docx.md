<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2025-05-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Billetera y QR

Código: PRY-206

Área dueña: Canales Digitales

Patrocinador: Javier Hoyos

Gerente de proyecto: María Restrepo

Comité: Comité de Medios de Pago

Producto asociado: pagos QR

Fecha de aprobación: 2025-05-28

Objetivo del negocio

Entregar billetera y qr para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Comité de Medios de Pago el 2025-05-28.

Fechas comprometidas

Fecha

Inicio

2025-06-07

Cierre

2026-03-25

Criterio de éxito

Billetera y QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
