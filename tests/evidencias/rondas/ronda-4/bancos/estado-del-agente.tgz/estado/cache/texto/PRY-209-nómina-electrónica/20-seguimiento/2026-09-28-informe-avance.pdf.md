<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Nómina electrónica
Código: PRY-209
Fecha de corte: 2026-09-28
Gerente: Óscar Ramírez

Estado declarado
Verde
Avance reportado: 24%

Lo que pasó en el periodo
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 6.750.954.901
Ejecutado 3.509.937.301
Proyección al cierre 9.666.666.238

Riesgos abiertos
- Concentración del conocimiento en una sola persona
