<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-09-24-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Débito contactless
Código: PRY-204
Fecha de corte: 2026-09-24
Gerente: Jorge Medina

Estado declarado
Amarillo
Avance reportado: 27%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 3.940.228.462
Ejecutado 2.069.194.046
Proyección al cierre 6.330.588.007

Riesgos abiertos
- Cambio regulatorio en discusión que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
