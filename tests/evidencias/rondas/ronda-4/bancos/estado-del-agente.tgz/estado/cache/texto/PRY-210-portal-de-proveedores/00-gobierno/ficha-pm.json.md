<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-210",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "name": {
 "value": "Portal de proveedores",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Banca de Personas",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Andrés Lozano",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "manager": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Arquitectura",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "verde",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 34,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-09-11",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "end_date": {
 "value": "2027-04-24",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-09-01",
 "start_date": "2025-09-11",
 "end_date": "2027-04-24",
 "reason": "Aprobación inicial del acta de constitución",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-12-27",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "current_date": {
 "value": "2025-12-27",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-11-acta-recibo-diseño-funcional-aprobado.pdf",
 "source": "20-seguimiento/2026-10-11-acta-recibo-diseño-funcional-aprobado.pdf",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-04-13",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "current_date": {
 "value": "2026-04-13",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Integración con el core",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-07-29",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "current_date": {
 "value": "2026-07-29",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Piloto con usuarios internos",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-11-14",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "current_date": {
 "value": "2026-11-14",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Salida a producción",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-03-01",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "current_date": {
 "value": "2027-04-11",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": null,
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "note": "La fecha vigente se movió respecto de la v1 (2027-03-01) sin una solicitud de cambio aprobada; CC-01 sigue pendiente."
 }
 ],
 "scope_summary": {
 "value": "Componente 1; Componente 2; Componente 3",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-09-01-acta-constitucion.docx",
 "source_date": "2025-09-01",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "approved": {
 "value": 2400000000,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "committed": {
 "value": 865619680,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 1427858191,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 2406453124,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Disponibilidad del equipo de seguridad para la revisión final",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "registered": true
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "probability": null,
 "impact": null,
 "owner": null,
 "due_date": null,
 "last_moved": null,
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "registered": false,
 "note": "Se comentó en la reunión; las notas dicen que nadie lo anotó como riesgo."
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-04",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+41 días sobre la línea base vigente",
 "cost_impact": "82.000.000 COP adicionales",
 "decision": "pending",
 "decided_by": null,
 "note": "Solicitante Liliana Torres. «Pendiente de presentación al comité».",
 "source": "20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-04"
 }
 ],
 "commitments": [
 {
 "id": 1,
 "who": "Jorge Medina",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-08",
 "original_due_date": "2026-09-17",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-29",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-30",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-24",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-08",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ],
 "note": "Notas del 2026-10-15: «no alcanzó, se compromete para el 08/12/2026»; leído día/mes/año."
 },
 {
 "id": 2,
 "who": "Liliana Torres",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-11",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-09-24",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 3,
 "who": "Natalia Ospina",
 "what": "Revisar el anexo 3",
 "due_date": "2026-11-05",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-05",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ]
 },
 {
 "id": 4,
 "who": "Paula Céspedes",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "El 2026-09-17 dijo que ya lo entregó; no se presentó acta y desde esa reunión sale de la lista sin cerrarse."
 },
 {
 "id": 5,
 "who": "Rubén Cárdenas",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-22",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-5.md"
 },
 {
 "id": 6,
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-26",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-6.md"
 },
 {
 "id": 7,
 "who": "Javier Hoyos",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-11-27",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-18",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 8,
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 }
 ]
 },
 {
 "id": 9,
 "who": "Mauricio Pérez",
 "what": "Enviar el documento 9",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-01-acta-recibo-9.md"
 },
 {
 "id": 10,
 "who": "Camilo Beltrán",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "Figura con la misma fecha en las minutas del 09-24, 10-01 y 10-08; ninguna acta de recibo."
 },
 {
 "id": 11,
 "who": "Diana Molina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-22",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "overdue",
 "reschedules": [],
 "note": "El 2026-10-01 dijo que ya lo entregó; no se presentó acta."
 },
 {
 "id": 12,
 "who": "Camilo Beltrán",
 "what": "Validar el ambiente 12",
 "due_date": "2026-10-09",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-24-acta-recibo-12.md"
 },
 {
 "id": 13,
 "who": "Diana Molina",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-12",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-10-08-acta-recibo-13.md"
 },
 {
 "id": 14,
 "who": "Carlos Peña",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-19",
 "original_due_date": "2026-10-19",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "«Por definir» hasta el 2026-10-08, cuando recibió su primera fecha; no cuenta como reprogramación."
 },
 {
 "id": 15,
 "who": "Mauricio Pérez",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 16,
 "who": "Óscar Ramírez",
 "what": "Entregar el punto 16",
 "due_date": "2026-11-03",
 "original_due_date": "2026-10-18",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "«Por definir» hasta el 2026-10-01, primera fecha; luego una reprogramación."
 },
 {
 "id": 17,
 "who": "Sandra Gil",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-16",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 18,
 "who": "Javier Hoyos",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-09",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 19,
 "who": "María Restrepo",
 "what": "Revisar el anexo 19",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "Nadie le puso fecha. El 2026-10-08 dijo que ya lo entregó; no se presentó acta."
 },
 {
 "id": 20,
 "who": "Camilo Beltrán",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "id": 21,
 "who": "Ricardo Salas",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 22,
 "who": "Andrés Lozano",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "id": 23,
 "who": "Laura Vélez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "id": 24,
 "who": "Mauricio Pérez",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "id": 25,
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Dicho como «la otra semana»; nadie dijo día. Se copia sin convertir en fecha."
 },
 {
 "id": 26,
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "Compromiso nuevo según el texto; puede ser lo mismo que «Entregar el punto 16» (#16), las notas no lo dicen."
 }
 ],
 "activity": {},
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product (el acta dice «No aplica»)",
 "identity.authority",
 "identity.phase",
 "vendors",
 "raid.owner de ambos riesgos"
 ],
 "open_conflicts": [],
 "reading": "pm-setup: las 6 minutas del comité (2026-09-03 a 2026-10-08), las notas del 2026-10-15 y las 6 actas de recibo; no sellada."
 }
}
