<!-- origen: PRY-208-motor-de-decisión/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de decisión
Código: PRY-208
Fecha de corte: 2026-09-25
Gerente: Sandra Gil

Estado declarado
Amarillo
Avance reportado: 74%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 1.042.279.479
Ejecutado 673.930.886
Proyección al cierre 1.162.609.510

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
- Disponibilidad del equipo de seguridad para la revisión final
