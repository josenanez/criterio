<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-02-08-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Banca de Personas

Patrocinador: María Restrepo

Gerente de proyecto: Diana Molina

Comité: Comité de Riesgos

Producto asociado: No aplica

Fecha de aprobación: 2026-02-08

Objetivo del negocio

Entregar prevención de lavado de activos para Banca de Personas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Riesgos el 2026-02-08.

Fechas comprometidas

Fecha

Inicio

2026-02-18

Cierre

2026-10-20

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
