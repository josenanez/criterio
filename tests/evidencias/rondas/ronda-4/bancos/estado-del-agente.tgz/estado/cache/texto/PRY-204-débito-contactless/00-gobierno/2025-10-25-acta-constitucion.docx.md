<!-- origen: PRY-204-débito-contactless/00-gobierno/2025-10-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Débito contactless

Código: PRY-204

Área dueña: Banca PyME

Patrocinador: María Restrepo

Gerente de proyecto: Jorge Medina

Comité: Comité de Riesgos

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-10-25

Objetivo del negocio

Entregar débito contactless para Banca PyME.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Riesgos el 2025-10-25.

Fechas comprometidas

Fecha

Inicio

2025-11-04

Cierre

2027-01-14

Criterio de éxito

Débito contactless en producción y medido.

Dependencias declaradas

• Ninguna declarada
