<!-- origen: PRY-201-core-de-depósitos/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-30 | 2026-06-30 | cerrado
Ambiente de pruebas certificado | 2026-09-08 | 2026-09-08 | cerrado
Integración con el core | 2026-11-17 | 2026-11-17 | en curso
Piloto con usuarios internos | 2027-01-26 | 2027-01-26 | en curso
Salida a producción | 2027-04-06 | 2027-04-26 | en curso
