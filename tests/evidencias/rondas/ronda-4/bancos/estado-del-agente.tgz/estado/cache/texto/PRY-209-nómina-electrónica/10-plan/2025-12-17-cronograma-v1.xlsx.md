<!-- origen: PRY-209-nómina-electrónica/10-plan/2025-12-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-22 | 2026-03-22 | cerrado
Ambiente de pruebas certificado | 2026-06-16 | 2026-06-16 | cerrado
Integración con el core | 2026-09-10 | 2026-09-10 | cerrado
Piloto con usuarios internos | 2026-12-05 | 2026-12-05 | en curso
