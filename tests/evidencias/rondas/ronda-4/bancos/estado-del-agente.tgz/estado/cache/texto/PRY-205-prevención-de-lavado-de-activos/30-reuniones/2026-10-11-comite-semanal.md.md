<!-- origen: PRY-205-prevención-de-lavado-de-activos/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Riesgos · Prevención de lavado de activos

**Fecha:** 2026-10-11
**Asistentes:** Diana Molina, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Entregar el punto 40 | 2026-09-30 |
| Diana Molina | Entregar el punto 30 | 2026-09-26 |
