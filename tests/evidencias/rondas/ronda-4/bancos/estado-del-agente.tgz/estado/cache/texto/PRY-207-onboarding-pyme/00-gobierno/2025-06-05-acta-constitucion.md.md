<!-- origen: PRY-207-onboarding-pyme/00-gobierno/2025-06-05-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Onboarding PyME

**Código:** PRY-207
**Área dueña:** Canales Digitales
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Transformación Digital
**Producto asociado:** cuenta PyME
**Fecha de aprobación:** 2025-06-05

## Objetivo del negocio

Entregar onboarding pyme para Canales Digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Transformación Digital el 2025-06-05.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-15 |
| Cierre | 2026-08-15 |

## Criterio de éxito

Onboarding PyME en producción y medido.

## Dependencias declaradas

- Ninguna declarada
