<!-- origen: PRY-205-prevención-de-lavado-de-activos/20-seguimiento/2026-10-03-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-03
**Gerente:** Diana Molina

## Estado declarado

**Rojo**

Avance reportado: **43%**

## Lo que pasó en el periodo

- Se reprogramó la salida por ventana de cambio del área de operaciones

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.196.050.514 |
| Ejecutado | 1.022.306.302 |
| Proyección al cierre | 3.988.589.390 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
