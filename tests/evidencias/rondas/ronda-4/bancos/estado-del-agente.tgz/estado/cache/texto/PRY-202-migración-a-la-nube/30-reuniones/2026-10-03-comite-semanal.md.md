<!-- origen: PRY-202-migración-a-la-nube/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Migración a la nube

**Fecha:** 2026-10-03
**Asistentes:** Laura Vélez, Andrés Lozano

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 6 | 2026-10-24 |
