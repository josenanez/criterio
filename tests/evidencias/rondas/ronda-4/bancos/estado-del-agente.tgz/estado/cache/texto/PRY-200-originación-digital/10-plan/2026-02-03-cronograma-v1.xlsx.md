<!-- origen: PRY-200-originación-digital/10-plan/2026-02-03-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-07-24 | 2026-07-24 | cerrado
Ambiente de pruebas certificado | 2027-01-02 | 2027-01-02 | en curso
Integración con el core | 2027-06-13 | 2027-06-13 | en curso
