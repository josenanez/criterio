<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-12-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Nómina electrónica

Código: PRY-209

Área dueña: Riesgo y Cumplimiento

Patrocinador: María Restrepo

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Medios de Pago

Producto asociado: nómina empresarial

Fecha de aprobación: 2025-12-17

Objetivo del negocio

Entregar nómina electrónica para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Medios de Pago el 2025-12-17.

Fechas comprometidas

Fecha

Inicio

2025-12-27

Cierre

2027-01-17

Criterio de éxito

Nómina electrónica en producción y medido.

Dependencias declaradas

• Ninguna declarada
