<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-09-25-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-09-25
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 34%

Lo que pasó en el periodo
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 1.394.605.504
Ejecutado 1.645.776.121
Proyección al cierre 3.915.287.113

Riesgos abiertos
- Concentración del conocimiento en una sola persona
- Cambio regulatorio en discusión que puede mover el alcance
