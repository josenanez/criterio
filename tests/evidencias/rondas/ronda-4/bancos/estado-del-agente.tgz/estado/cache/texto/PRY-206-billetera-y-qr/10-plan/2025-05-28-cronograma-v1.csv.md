<!-- origen: PRY-206-billetera-y-qr/10-plan/2025-05-28-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-08-29,2025-08-29,cerrado
Ambiente de pruebas certificado,2025-11-20,2025-11-20,cerrado
Integración con el core,2026-02-11,2026-02-11,cerrado
