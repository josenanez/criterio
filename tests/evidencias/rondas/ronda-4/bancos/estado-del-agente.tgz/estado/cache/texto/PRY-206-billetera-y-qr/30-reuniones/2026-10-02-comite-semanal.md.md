<!-- origen: PRY-206-billetera-y-qr/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Billetera y QR

**Fecha:** 2026-10-02
**Asistentes:** María Restrepo, Javier Hoyos

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 10 | 2026-11-05 |
