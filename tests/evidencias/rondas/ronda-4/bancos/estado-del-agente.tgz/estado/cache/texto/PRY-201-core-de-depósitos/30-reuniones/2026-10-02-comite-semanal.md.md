<!-- origen: PRY-201-core-de-depósitos/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Core de depósitos

**Fecha:** 2026-10-02
**Asistentes:** Carlos Peña, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 9 | 2026-11-05 |
