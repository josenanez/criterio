<!-- origen: PRY-199-renovación-de-cajeros-automáticos/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Renovación de cajeros automáticos

**Fecha:** 2026-10-11
**Asistentes:** Andrés Lozano, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Presentar el cierre de la fase | 2026-11-04 |
