<!-- origen: PRY-210-portal-de-proveedores/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Portal de proveedores

**Fecha:** 2026-09-10
**Asistentes:** Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Natalia Ospina, Paula Céspedes, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Enviar el documento 1 | 2026-09-29 |
| Liliana Torres | Cerrar la prueba 2 | 2026-09-24 |
| Natalia Ospina | Revisar el anexo 3 | 2026-10-12 |
| Paula Céspedes | Validar el ambiente 4 | 2026-09-25 |
| Rubén Cárdenas | Aprobar el diseño 5 | 2026-09-22 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-26 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-02 |
| Rubén Cárdenas | Entregar el punto 8 | 2026-10-04 |
