# Portafolio — 2026-10-15

Fichas cargadas: 13 (`estado/records/`), con fecha de barrido 2026-10-15; ninguna supera una semana. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15 para esta prueba).

13 proyectos · 10 con hallazgos (60 señales) · último barrido 2026-10-15

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (el diff contra la instantánea 2026-10-15 devolvió 0 cambios).

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-210 Portal de proveedores | plan.end_date | 2027-04-11 (PMO, 2026-10-13, más reciente) | 10-plan/2026-10-13-cronograma-v2.xlsx | 2027-04-24 (PM) | 00-gobierno/2025-09-01-acta-constitucion.docx |

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-202 | Ambiente de pruebas certificado | 2026-10-06 | 9 | — |
| PRY-208 | Piloto con usuarios internos | 2026-10-11 | 4 | — |

Además, 10 proyectos declaran hitos como cumplidos sin evidencia (PRY-200, 202, 204, 205, 206, 207, 208, 209, 210, 211).

## Proyectos en silencio
Vacío: ningún proyecto supera 15 días sin documentos (máximo: PRY-200, 10 días).

## Dependencias en riesgo
Las señales calculadas no incluyen dependencias entre proyectos rotas. Sí hay proveedor común: Datacore Colombia atrasa entregables en PRY-204 (licenciamiento, 236 días) y PRY-208 (licenciamiento 165 días, bolsa de horas 104, tarifario 43), y en PRY-208 hay 105.076.622 facturados sin entrega.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-206 Billetera y QR | verde (2026-10-12) | hitos cumplidos sin evidencia; avance 89 % vs 100 % que sostiene el plan |
| PRY-209 Nómina electrónica | verde (2026-09-28) | hitos sin evidencia; avance declarado 24 % vs 75–100 % |
| PRY-211 Cobranza digital | verde (2026-09-25) | hitos sin evidencia; avance 34 % vs 100 % |
| PRY-210 Portal de proveedores | verde (2026-10-13) | compromisos vencidos y reprogramados, hitos sin evidencia, replanificación de 41 días sin autorización |

## Vacíos de información
- 13 de 13 proyectos sin autoridad registrada.
- PRY-203 sin línea base.
- PRY-202, 205, 208 y 210 sin producto asociado.
- PRY-204 y PRY-205: cambio CC-01 sin línea base (83 y 78 días).

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | — | sin alertas | 0 d | 0 d | 0 |
| PRY-200 | — | 1 hito sin evidencia | 0 d | 0 d | 0 |
| PRY-201 | — | sin alertas | 20 d | 0 d | 1 |
| PRY-202 | — | 3 alertas | 120 d (52,6 %) | 0 d | 1 |
| PRY-203 | — | sin alertas | sin línea base | — | 0 |
| PRY-204 | — | 9 alertas | 83 d (21,0 %) | 0 d | 1 |
| PRY-205 | — | 6 alertas | 78 d (37,3 %) | 0 d | 1 |
| PRY-206 | verde | contradicho | 0 d | 0 d | 0 |
| PRY-207 | — | 4 alertas | 32 d | 0 d | 1 |
| PRY-208 | — | 6 alertas | 0 d | 0 d | 0 |
| PRY-209 | verde | contradicho | 0 d | 0 d | 0 |
| PRY-210 | verde | contradicho (18 alertas) | 41 d | 0 d | 1 |
| PRY-211 | verde | contradicho | 0 d | 0 d | 0 |

## Necesito que confirmes
No toca confirmación este mes (no hay confirmación previa registrada que vencer en esta corrida de prueba; se omiten las cinco preguntas).

## Informe
Generado en `reportes/` (26 páginas):
- `reportes/index.html` — por campo, con la cadena de evidencia: para quien va a actuar.
- `reportes/decisiones.html` — por decisión: para el patrocinador en el comité del 2026-10-22.
- Una página por proyecto (`reportes/PRY-###.html`). El PDF sale de imprimir el HTML.

---
Criterio-portfolio 0.3.10 · fichas aplicadas: 13, del 2026-10-15 · campos inciertos: contradicción PRY-210 plan.end_date; PRY-203 sin línea base · Criterio produce borradores de trabajo, no decisiones ni asesoría; la verificación es suya. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
