## Diagnóstico · PRY-204 Débito contactless · 2026-10-15

**Leí:** 10 documentos · del 2025-10-25 al 2026-10-07 · formatos: .docx (1), .md (4), .csv (2), .pdf (3). Busqué además el código, el nombre y «CT-152» en los demás documentos del portafolio: ninguna otra minuta ni documento menciona este proyecto.
**No pude leer:** nada. Los tres PDF tienen texto extraíble.

Las cifras derivadas (días, porcentajes, disponible) salen de `portafolio.py compute`. Los datos que lo alimentan los contrasté a mano con los 10 documentos y coinciden.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 12 · **Contradicho:** 5

Desde esta carpeta se puede afirmar quién es el patrocinador, quién el gerente, cuál el comité, cuál el presupuesto aprobado y que dos entregables tienen acta de recibo: la bolsa de horas y el diseño funcional. No se puede afirmar el estado amarillo, el 27 %, el comprometido, el ejecutado, la proyección, que tres de los cinco hitos estén cerrados, ni que el comité autorizara el cambio CC-01. En esta carpeta la evidencia llega a 0 de las 39 marcas de fuente con que `compute` clasifica los datos del proyecto: 4 son declaraciones del gerente y 35 no están marcadas. Los cinco puntos que el informe del 2026-09-24 no explica son: desviación de tiempo, avance contra plan, hitos sin evidencia, compromiso vencido y entregable del proveedor atrasado.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | María Restrepo | `00-gobierno/2025-10-25-acta-constitucion.docx` |
| Gerente | Jorge Medina | `00-gobierno/2025-10-25-acta-constitucion.docx` |
| Autoridad declarada | **No está.** El acta no dice qué puede aprobar el gerente sin pasar por el comité | `00-gobierno/2025-10-25-acta-constitucion.docx` |
| Comité | Comité de Riesgos. Presupuesto aprobado por él el 2025-10-25. Único acta/minuta existente: 2026-10-07, asistentes Jorge Medina y María Restrepo; temas «Avance» y «Compromisos»; no menciona CC-01 ni registra ninguna decisión | `30-reuniones/2026-10-07-comite-semanal.md` |

Sin autoridad declarada para el gerente, las fechas del cronograma v2 son fechas que alguien escribió, no una desviación aprobada.

### Contra el plan
- **Línea base original (v1, 2025-10-25):** salida a producción 2026-12-05. Cierre del acta de constitución: 2027-01-14.
- **Vigente (v2, 2026-09-24):** salida 2027-02-26. Motivo de la replanificación: **no consta en ningún documento**. El informe del 2026-09-24 dice solo que «se reprogramó la salida por ventana de cambio del área de operaciones»; nada lo respalda.
- **Desviación:** 83 días contra la original, 21,0 %; 0 días contra la vigente (la vigente ya incluye los 83). Supera el umbral de 10 %.
- **Replanificaciones:** 1.
- **Cambio CC-01 (2026-10-06):** pide +83 días «sobre la línea base vigente» y 166.000.000 COP adicionales, y dice «Autorizada por el comité». No hay acta de comité que lo respalde, ni fecha, ni nombre. Es posterior al v2 que ya mueve esos 83 días. La línea base no se movió por una aprobación: el cronograma se movió primero y la solicitud llegó después. `compute` lo marca como cambio aprobado sin línea base nueva.
- **La nueva salida (2027-02-26) queda después del cierre del acta (2027-01-14).** Ningún documento modifica el acta.
- **La integridad de la línea base original es dudosa:** el v1 está fechado 2025-10-25 y ya trae cuatro hitos «cerrado» cuyas fechas son de 2026. Ese archivo se editó después de su fecha; no es una foto de lo aprobado ese día.

### Hitos vencidos sin evidencia
Los hitos del cronograma están marcados cerrados (4 de 5). Solo uno tiene acta.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ambiente de pruebas certificado | 2026-04-11 | 187 | Acta de recibo / certificado del ambiente |
| Integración con el core | 2026-06-29 | 108 | Acta de recibo de la integración |
| Piloto con usuarios internos | 2026-09-17 | 28 | Acta o informe de cierre del piloto |

Diseño funcional aprobado: sí tiene acta de recibo, pero fechada 2026-10-05, para un hito de 2026-01-22; y el cronograma v2 de 2026-09-24 ya lo mostraba cerrado, once días antes de que existiera el acta. Salida a producción no está vencido.

### Dinero (COP)
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 6.800.000.000 | 3.940.228.462 (57,9 %) | 2.069.194.046 (30,4 %) | 6.330.588.007 (−6,9 % frente al aprobado) | 2.859.771.538 |

- Solo el aprobado tiene respaldo (acta de constitución). Comprometido, ejecutado y proyección vienen únicamente del informe del 2026-09-24, declarados, sin contrato ni libro que los sostenga. La proyección no trae método.
- Los 166.000.000 COP de CC-01 no figuran en ningún presupuesto aprobado. Si la proyección los incluye, ningún documento lo dice.
- **Proveedor Datacore Colombia · CT-152.** Condición de pago: «Cada entregable se factura contra acta de recibo firmada por el gerente».

| Entregable | Fecha | Monto | Contrato dice | Acta de recibo |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-02-21 | 675.572.032 | en curso | no hay; atraso de 236 días |
| Bolsa de horas de desarrollo | 2026-06-10 | 675.572.032 | recibido | sí, 2026-06-22 |
| Parametrización del tarifario | 2026-09-27 | 675.572.032 | recibido | **no hay** |

  Factura FV-1152 (2026-08-30): 1.351.144.064 COP, concepto «Entregables del contrato CT-152», sin detallarlos. Equivale a dos entregables. Solo uno tiene acta, y la parametrización tenía fecha comprometida un mes después de la factura. Radicada en cuentas por pagar; no hay documento de pago.

### Lo que se dijo y nadie registró
- **Compromiso:** Carlos Peña · «Entregar el punto 31» · para 2026-09-26. Está en la minuta del 2026-10-07, es decir, la fecha ya había pasado cuando se anotó. Vencido hace 19 días, sin evidencia de entrega. Carlos Peña no figura como asistente ni en ningún otro documento. «Punto 31» no se define en ninguna parte.
- **Riesgos y problemas** solo existen como viñetas del informe de avance: cambio regulatorio que puede mover el alcance, proveedor sin fecha de la última entrega, hallazgo de seguridad en la revisión de arquitectura. Ninguno tiene responsable, probabilidad, impacto ni fecha. No hay registro RAID en la carpeta. El acta de constitución declara «Ninguna dependencia».
- La minuta del 2026-10-07 no dice nada de riesgos, de CC-01, de la factura ni del hallazgo de seguridad.
- No hay ningún documento que relacione el cambio regulatorio con la ampliación de alcance de CC-01; no lo afirmo.

### Silencio
El proyecto no está en silencio: el último documento es del 2026-10-07 (8 días). El que se calló es el informe: el último es del 2026-09-24 (21 días, umbral de 15) y no explica ninguna de las desviaciones anteriores.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 27 % | Informe 2026-09-24: 27 % | Cronograma v2: 4 de 5 hitos cerrados; el plan sostendría entre 80 y 100 %. Brecha de 53 puntos. O los hitos no están cerrados o el 27 % no es el avance |
| Dos entregables de CT-152 recibidos y facturados | Factura FV-1152 (2026-08-30): 1.351.144.064 COP; contrato: parametrización «recibido» | Solo hay acta de la bolsa de horas; la parametrización vencía el 2026-09-27; el contrato exige acta para facturar |
| Salida 2027-02-26 | Cronograma v2 (2026-09-24) | Acta de constitución: cierre 2027-01-14 |
| La salida se movió con aprobación | Cronograma v2 (2026-09-24) ya con +83 días | CC-01 (2026-10-06) pide esos mismos +83 días; «autorizada por el comité» sin acta |
| v1 es la línea base del 2025-10-25 | Nombre y fecha de `cronograma-v1.csv` | Contenido: cuatro hitos «cerrado» con fechas de 2026 |

### Sin sustento
- Estado amarillo.
- Comprometido 3.940.228.462, ejecutado 2.069.194.046 y proyección 6.330.588.007.
- Ambiente de pruebas certificado, integración con el core y piloto con usuarios internos «cerrados».
- «Autorizada por el comité» en CC-01.
- Licenciamiento del motor «en curso».
- «Se recibió la aprobación regulatoria pendiente desde el trimestre anterior».
- El hallazgo de seguridad en la revisión de arquitectura.
- El motivo de la reprogramación de la salida («ventana de cambio de operaciones»).

### Sostenido
- Presupuesto aprobado de 6.800.000.000 COP (acta de constitución).
- Patrocinador, gerente y comité (acta de constitución).
- Diseño funcional aprobado, con acta de recibo del 2026-10-05.
- Bolsa de horas de desarrollo recibida, con acta del 2026-06-22.

### Lo que esta carpeta no permite saber
- **Si el proyecto está cerrado en 4 de 5 hitos o en 27 %.** Sin actas de tres hitos, no se sabe cuál de las dos cifras está mal.
- **Quién autorizó CC-01.** Sin acta ni nombre no se sabe si el cambio de 83 días y 166.000.000 COP es una decisión del comité.
- **Si lo facturado a Datacore se debía.** Sin acta de la parametrización no se sabe si 675.572.032 COP se pagaron o se pagarán sin entregable recibido.
- **Cuánto dinero hay realmente.** Sin respaldo del comprometido y el ejecutado, el disponible de 2.859.771.538 COP es el del informe, no el de los libros.
- **Qué puede decidir el gerente.** Sin autoridad declarada, no se sabe qué cambios requerían al comité.
- **Quién es Carlos Peña y qué es el punto 31.**
- **Si la línea base original fue la que se aprobó.** El v1 fue editado después de su fecha.

Cobertura: 10 documentos de un proyecto; el estado de los sistemas financieros, de contratación y de tickets no está en esta carpeta. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

Puedo preparar el punto de comité con esta lista de faltantes, o llevar las contradicciones al gerente como preguntas, una por una.
