## 2026-10-15

**Revisé:** 89 documentos · 0 cambiaron · 0 proyectos recalculados

### Lo que cruzó un umbral
Nada. No hay documentos nuevos, cambiados, renombrados ni borrados, así que no se recalculó ningún proyecto.

**Hallazgo del índice:** 38 citas de PRY-210 (portal de proveedores) figuran como «fuente no resuelta»: acta de constitución, informe de avance del 13-oct, cronograma v2 y acta de recibo del diseño funcional. Los archivos sí existen en `PRY-210-portal-de-proveedores/`. Las citas de la ficha llevan ese prefijo de carpeta, así que lo más probable es un desajuste de rutas al comprobarlas y no documentos perdidos. No lo verifiqué ni lo corregí. Queda abierto hasta que alguien lo confirme.

### Peticiones atendidas
No se consultaron: `requests` no estaba entre lo que tocaba hoy.

### Preguntas
Es la primera confirmación (sin corrida previa). Nadie responde en esta sesión, así que quedan **preguntadas el 2026-10-15, sin respuesta**. Todas son de PRY-210:

1. **Motivo de la línea base v2** (`plan.baseline[1].reason`): `not_found`. El fin pasó de 2027-03-01 a 2027-04-11 (+41 días) el 2026-10-13 sin motivo escrito. Fuente: cronograma v2, 2026-10-13.
2. **Autoridad de aprobación** (`identity.authority`): `not_found`. La solicitud de cambio CC-01 del 2026-10-04 no dice quién aprobó.
3. **Fase actual** (`identity.phase`): `not_found`. El informe del 13-oct declara verde y 34 %, sin fase.
4. **Producto al que pertenece** (`identity.product`): `not_found`.
5. **Fecha de inicio** (`plan.start_date`): la ficha dice 2025-09-11, tomada del acta del 2025-09-01. Pido confirmar que fue el inicio real.

**Vuelvo el 2026-10-16.**
