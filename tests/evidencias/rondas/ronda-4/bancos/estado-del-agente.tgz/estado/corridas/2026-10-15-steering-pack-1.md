# Corrida del 2026-10-15 · steering-pack

13 proyectos · 128 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Paquete de comité 2026-10-22: 5 decisiones, 5 escalamientos. Dijo que no sabe: quién decide (autoridad no declarada en los 13), el alcance de cada CC-01, el estado de pago de FV-1152, vigencia de CT-152/CT-932 y qué es «el core». Sin acta de comité anterior, no cerró ciclo.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** las 13 de `estado/records` (PRY-199 a PRY-211), con cifras recalculadas por `portafolio.py compute` al 2026-10-15. También usé las salidas de hoy de change-control, raid-log y vendor-tracking, y el paquete de PRY-210 (`pm-escalate`). No reabrí ningún `.docx`, `.pdf` ni `.xlsx`: de ellos solo uso lo que ya trae la ficha. Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 (no se registraron de nuevo). No se pasó fecha, así que tomé la del próximo comité de la configuración, 2026-10-22.

# Comité de proyectos — 2026-10-22
5 decisiones · 5 escalamientos · 10 de 13 proyectos con hallazgos (60 señales abiertas)

## Decisiones del comité anterior
| Decisión | Fecha | Qué pasó | Estado |
|---|---|---|---|
| Sin dato | — | No hay acta ni minuta de un comité de portafolio anterior en la carpeta. | **No puedo cerrar el ciclo.** |

Cinco proyectos (PRY-201, 202, 204, 205, 207) traen un CC-01 que dice «Autorizada por el comité» sin nombre del comité ni acta. Por eso no hay un «comité anterior» al que atribuir esas decisiones; es el punto 2.

## Decisiones de hoy

### [1] ¿Se declara por escrito quién aprueba los cambios de alcance, fecha y presupuesto, y hasta qué monto y días decide cada gerente por su cuenta?
**Proyecto:** los 13 (`identity.authority`: no encontrada en ninguno) · **Quién decide:** sin determinar. Cada ficha nombra un comité de proyecto distinto: Arquitectura (PRY-201, 210), Transformación Digital (PRY-199, 202, 207), Medios de Pago (PRY-200, 203, 206, 209) y Riesgos (PRY-204, 205, 208, 211). Este comité tiene que decir primero si tiene la facultad. · **Si no se decide hoy:** los puntos 2, 3 y 4 pueden devolverse con un «eso no lo decide este comité». Y cualquier cambio futuro vuelve a subir aquí por defecto.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Una matriz única de autoridad para el portafolio (umbrales en días y en COP), firmada por quien preside este comité | Ninguno | Una sola decisión. No hay en los documentos una estimación de cuánto tarda firmarla | Ninguno en COP |
| B. Una adenda al acta de constitución de cada proyecto | Ninguno | 13 firmas, con patrocinadores y comités distintos | Ninguno en COP |
| C. No declararla; todo cambio sube a este comité | Ninguno | Cada cambio espera sesión | Ninguno en COP |

**Recomendación:** A, y que cada gerente la cite en una adenda a su acta (B) cuando corresponda. Con C este comité acaba aprobando cualquier cambio de un día. Los umbrales los fija quien firma; no los propongo, porque ningún documento trae una base para hacerlo.

### [2] ¿Se ratifica con acta cada CC-01 «autorizado por el comité» que no tiene acta, o se tratan como no autorizados hasta que la haya?
**Proyecto:** PRY-201, 202, 204, 205, 207 · **Quién decide:** este comité, una vez resuelto el punto 1. · **Si no se decide hoy:** cinco desviaciones de fecha y cinco aumentos de costo siguen vigentes sin documento que los respalde. En PRY-202 es la mayor desviación contra la línea base original del portafolio.

| Proyecto | Pedido el | Tiempo | Costo adicional | Desviación vs. línea base original | ¿Línea base nueva? |
|---|---|---|---|---|---|
| PRY-201 | 2026-10-06 | +20 días | 40.000.000 COP | 20 días (5,7 %) | Cuadra |
| PRY-202 | 2026-10-06 | +120 días | 240.000.000 COP | 120 días (52,6 %), sobre el umbral de 10 % | Cuadra |
| PRY-204 | 2026-10-06 | +83 días | 166.000.000 COP | 83 días (21,0 %), sobre el umbral | **Falta** |
| PRY-205 | 2026-10-08 | +78 días | 156.000.000 COP | 78 días (37,3 %), sobre el umbral | **Falta** |
| PRY-207 | 2026-10-02 | +32 días | 64.000.000 COP | 32 días (8,8 %) | La ficha dice que no hay. `compute` no lo marca, y no sé cuál de los dos tiene razón |

Los cinco se piden como «ampliación de alcance» sin decir qué se agrega.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar en acta, con quién decidió, fecha y motivo, y registrar línea base nueva donde falte (204 y 205 como mínimo) | Se confirma una ampliación que ningún documento describe | Las fechas vigentes quedan respaldadas | Se confirman los montos de la tabla |
| B. No tratarlos como autorizados hasta que haya acta; los gerentes presentan la solicitud completa | Sin ampliación mientras tanto | Las fechas vigentes pierden respaldo; no hay estudio de qué fecha es alcanzable | Los montos no se comprometen |
| C. Dejarlos como están | Ampliación sin detalle | Desviaciones sin respaldo | Montos sin respaldo |

**Recomendación:** A para los que este comité pueda confirmar que sí autorizó, y B para los que no. Hoy la evidencia no distingue entre uno y otro, y esa distinción solo la tienen quienes estuvieron en la sala. Pedir el alcance de cada CC-01 es condición de A en ambos casos.

### [3] PRY-210: ¿se aprueba CC-01 (+41 días, +82.000.000 COP) y se registra la línea base 2 con «Salida a producción» el 2027-04-11, o se rechaza y el cronograma vuelve al 2027-03-01?
**Proyecto:** PRY-210 Portal de proveedores · **Quién decide:** sin determinar (punto 1). Su comité de proyecto es el de Arquitectura, que aprobó el presupuesto; el acta no dice que apruebe cambios. · **Si no se decide hoy:** el cronograma v2 del 2026-10-13 ya trae 2027-04-11, contra 2027-03-01 en la línea base original. Son 41 días movidos sin cambio aprobado (señal `rebaseline_unauthorized`). El plan vigente no tiene respaldo y la gerente reporta verde sobre él. CC-01 está «pendiente de presentación al comité» desde 2026-10-04.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y registrar línea base 2 | Se amplía; el documento no dice qué se agrega | +41 días. La línea base original (2027-03-01) no se borra | +82.000.000 COP. Aprobado 2.400.000.000, proyección 2.406.453.124 (+0,3 %). No sumo ambas cifras porque no sé si se solapan |
| B. Rechazar y volver a 2027-03-01 | Sin ampliación | Hay que rehacer un cronograma que ya se movió. Nadie ha contrastado que 2027-03-01 sea alcanzable | 0 COP por el cambio |

**Recomendación:** A, condicionada a que la gerente entregue el alcance de CC-01 antes de que se firme. B obliga a rehacer un plan ya en marcha, y no hay evidencia de que 2027-03-01 se pueda sostener. Es una recomendación con información incompleta, y lo digo.

### [4] ¿Se retienen los pagos a Datacore Colombia hasta que haya acta de recibo de lo facturado, en CT-152 (PRY-204) y CT-932 (PRY-208)?
**Proyecto:** PRY-204 y PRY-208 (el mismo proveedor en dos proyectos con patrocinadores distintos: María Restrepo y Beatriz Cuéllar) · **Quién decide:** sin determinar (punto 1). Afecta a dos proyectos, así que no lo resuelve un gerente solo. · **Si no se decide hoy:** si FV-1152 no se ha pagado, puede pagarse sin acta de la parametrización. Si ya se pagó, queda como hallazgo sin recuperar. El documento solo dice «Radicada en cuentas por pagar»; no sé el estado de pago.

Lo que muestran los documentos:
- **PRY-204, CT-152:** `compute` da 1.351.144.064 COP facturados. El licenciamiento del motor lleva 236 días tarde, sin acta ni avance. La parametrización del tarifario figura como aceptada sin acta de recibo. Según la corrida de vendor-tracking de hoy, esa parametrización vale 675.572.032 COP y se facturó (2026-08-30) antes de su fecha comprometida (2026-09-27).
- **PRY-208, CT-932:** 4 entregables, 0 aceptados, 3 tarde (licenciamiento 165 días, bolsa de horas 104, parametrización 43) y 105.076.622 COP facturados (señal `vendor_invoiced_without_delivery`).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener todo pago pendiente en ambos contratos hasta tener acta de recibo y desglose de factura, y pedir a Datacore la cláusula de vigencia y renovación | Ninguno | Puede tensar la relación y la entrega. No hay evidencia de cuánto | Sin COP nuevos. Lo retenido es lo facturado sin acta |
| B. Pagar lo que tiene acta, retener solo lo que no la tiene | Ninguno | Menor fricción con el proveedor | Igual que A, pero exige separar la factura por entregable, y FV-1152 no tiene desglose |
| C. No actuar | Ninguno | Los atrasos de 236 y 165 días siguen sin consecuencia | El contrato exige acta para facturar; seguir pagando sin ella es incumplirlo |

**Recomendación:** B si Datacore entrega el desglose de FV-1152 a tiempo, y A si no. Es lo que el propio contrato exige, y el licenciamiento atrasado ya es la señal de que no hay avance que verificar. No sé la vigencia del contrato, y eso cambia el apremio.

### [5] ¿Se adopta como regla que un hito solo cuenta como cumplido con acta de recibo?
**Proyecto:** PRY-200, 202, 204, 205, 206, 207, 208, 209, 210, 211 (todos con hitos declarados «cumplidos» sin acta) · **Quién decide:** este comité, como política de portafolio. · **Si no se decide hoy:** el avance y el estado de esos proyectos siguen apoyados en hitos sin evidencia. Cuatro proyectos reportan verde contra su evidencia (PRY-206, 209, 210, 211) y es la regla más barata para corregirlo.

Tres de ellos tienen el plan al 100 % de hitos cumplidos y un avance declarado muy por debajo: PRY-211 (34 % declarado, fecha de cierre 2026-05-24), PRY-207 (40 %, cierre 2026-07-17) y PRY-206 (89 %, cierre 2026-02-11). La fecha de cierre de los tres ya pasó y ninguno la replanificó. O los hitos se marcaron cumplidos sin estarlo, o el avance está mal declarado; los documentos no permiten decir cuál.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Un hito sin acta pasa a «pendiente de evidencia» hasta presentarla | Ninguno | Los gerentes reúnen actas; no hay estimación en los documentos | Ninguno en COP |
| B. Igual que A, con plazo de gracia hasta el siguiente comité para presentar las actas antes de reclasificar | Ninguno | Da tiempo, pero deja los estados verdes un ciclo más | Ninguno en COP |
| C. Sin cambio | Ninguno | Sin cambio | Ninguno en COP |

**Recomendación:** B. Reclasificar de golpe diez proyectos sin darles la oportunidad de mostrar las actas castiga el archivo y no la entrega. Lo que no recomiendo es C: quedaría un estado verde que ningún documento sostiene.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200, 201, 202, 204, 205 | Dependencia: «el proveedor no ha confirmado la fecha de la última entrega». Sin nombre, doliente ni fecha. Es declarada, no acordada | Informes del 2026-09-24 al 2026-10-13 | Qué proveedor es y quién lo confirma, con fecha |
| PRY-202, 208, 209 | Dependencia de «el core», sin código de proyecto. PRY-208 la declara en el informe, mientras su acta dice «Ninguna declarada» | Sin fecha | Que cada gerente diga qué proyecto es «el core» |
| PRY-210 | Riesgo dicho en reunión y no registrado: el proveedor podría no llegar con el equipo completo para la siguiente fase | 2026-10-15 | Doliente y fecha |
| PRY-210 | Compromisos reprogramados: «Enviar el documento 1» (Jorge Medina) 6 veces, de 2026-09-17 a 2026-12-08; «Cerrar la prueba 2» (Liliana Torres) 5; «Confirmar la fecha 7» (Javier Hoyos) 4; «Revisar el anexo 3» (Natalia Ospina) 3 | Desde 2026-09-15 la más antigua | Nombrar qué bloquea o quién espera cada entregable. Sin eso no hay opciones con costo |
| PRY-203 | Estado declarado rojo (88 % de avance, 2026-10-11) sin línea base: sin cronograma no se puede calcular ninguna desviación | 2026-10-11 | Cronograma con línea base y la causa del rojo |

## Para conocimiento
- **PRY-199** Renovación de cajeros: verde declarado, 20 %, sin señales.
- **PRY-200** Originación digital: rojo declarado, 34 %; 1 señal (hito sin acta, punto 5).
- **PRY-201** Core de depósitos: amarillo, 48 %; sin señales; 20 días de desviación (5,7 %). Ver punto 2.
- **PRY-202** Migración a la nube: amarillo, 50 %; 3 señales: 120 días de desviación (52,6 %), hito «Ambiente de pruebas certificado» vencido sin cumplir (2026-10-06) y un hito sin acta.
- **PRY-203** Open Banking: ver escalamientos.
- **PRY-204** Débito contactless: amarillo, 27 % frente a 80-100 % que sostiene el plan; 9 señales. Ver puntos 2, 4 y 5.
- **PRY-205** Prevención de lavado de activos: rojo, 43 % frente a 100 % que sostiene el plan; 7 señales; dos compromisos vencidos (Diana Molina, Elena Duarte).
- **PRY-206** Billetera y QR: verde declarado, 89 %; 5 señales. Ver punto 5.
- **PRY-207** Onboarding PyME: amarillo, 40 %; 4 señales; comprometido 89,2 % del aprobado, justo bajo el umbral de 90 %.
- **PRY-208** Motor de decisión: amarillo, 74 %; 6 señales; hito «Piloto con usuarios internos» vencido (2026-10-11). Ver punto 4.
- **PRY-209** Nómina electrónica: verde declarado, 24 % frente a 75-100 % que sostiene el plan; 4 señales. Ver punto 5.
- **PRY-210** Portal de proveedores: verde declarado, 34 % frente a 60-80 %; 17 señales. Ver punto 3 y escalamientos.
- **PRY-211** Cobranza digital: verde declarado, 34 %; 4 señales. Ver punto 5.

Ningún proyecto lleva más de 15 días en silencio (el máximo es PRY-200, con 10).

## Anexo

### Contradicciones abiertas
| Dónde | Qué | Fuentes |
|---|---|---|
| PRY-210 | Fin del proyecto: 2027-04-11 en el cronograma v2 (2026-10-13) y 2027-04-24 en el acta (2025-09-01). La ficha toma la más reciente. | `10-plan/2026-10-13-cronograma-v2.xlsx`; `00-gobierno/2025-09-01-acta-constitucion.docx` |
| PRY-201 | Cierre 2027-05-11 en el acta y 2027-04-06 en el cronograma v1; la fecha vigente es 2027-04-26. | acta 2026-04-12; cronograma v1 |
| PRY-207 | La ficha dice que CC-01 no tiene línea base nueva y `compute` no lo marca. | ficha PRY-207; `compute` |
| PRY-210 y PRY-211 | Ejecutado mayor que comprometido: PRY-210 1.427.858.191 contra 865.619.680 (59,5 % y 36,1 % del aprobado); PRY-211 1.645.776.121 contra 1.394.605.504 (39,2 % y 33,2 %). Lo ejecutado debería estar comprometido. | informes de avance |
| PRY-208 | Declara depender del core, y su acta dice «Ninguna declarada». | acta; informe de avance |

### Vacíos de información
- **Autoridad y fase:** `identity.authority` e `identity.phase` faltan en los 13. Producto falta en PRY-202, 205, 208 y 210.
- **Campos viejos (12 meses o más):** PRY-204 (12), PRY-206 (17), PRY-207 (16), PRY-210 (13), PRY-211 (14), todos de su acta de constitución.
- **RAID:** ninguno de los 35 ítems tiene doliente, fecha, probabilidad ni impacto. Las mismas ocho frases se repiten en los 13 proyectos; puede ser una plantilla. Cada gerente debe confirmar los suyos.
- **Edad de la declaración:** la más vieja es la de PRY-204 (2026-09-24, 21 días), dentro del umbral de 30.
- **Solicitud no registrada:** la corrida de change-control de hoy evaluó un cambio de +30 días en PRY-201 que no está en la ficha, sin solicitante ni motivo. No lo traje como decisión.
- **Contratos:** vigencia, renovación y preaviso de CT-152 sin dato. CT-932 no lo leí, y sus cifras salen de `compute`.
- **No leí `.docx`, `.pdf` ni `.xlsx`.** Lo que no esté en las fichas no está aquí.

### Pie
Criterio portfolio v0.3.10 · fichas PRY-199 a PRY-211 al 2026-10-15 · términos v1.1, aceptados el 2026-10-15 por José Francisco Ñáñez. Campos inciertos: quién decide en los 13 proyectos, el alcance de cada CC-01, el estado de pago de FV-1152, la vigencia de CT-152 y CT-932, y la identidad de «el core» y del proveedor sin nombre. Este es un borrador de trabajo, no una decisión ni una asesoría; cada dato lleva la cita de su documento y la verificación es de quien lo use. Nota legal y términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10

## Después
Cuando el comité sesione, puedo registrar cada decisión con su fecha en la ficha del proyecto. Así se cierra el ciclo y el material del siguiente empieza a armarse con ella.
