**Fuentes:** las 13 fichas de `estado/records` (PRY-199 a PRY-211, RAID y su cita), las 9 minutas de comité de PRY-199 a PRY-209, las 6 minutas y las notas de reunión del 2026-10-15 de PRY-210, el informe de avance de PRY-210 y la sección «Dependencias declaradas» de las tres actas legibles como texto (PRY-201, 207, 208). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15. Las actas `.docx`, los `.pdf` y los `.xlsx` no los reabrí: de ellos solo uso lo que ya trae la ficha.

## RAID — Portafolio (13 proyectos) al 2026-10-15
15 riesgos · 0 supuestos · 14 incidencias · 6 dependencias (6 de los 21 «riesgos» registrados se reclasifican como dependencias, ver abajo) · más 1 riesgo no registrado
35 sin doliente · 0 medibles como «sin movimiento» (ningún ítem tiene fecha de último movimiento) · 1 no registrado formalmente

Lectura corta: el registro existe solo como las listas de «riesgos abiertos» de los informes de avance. **Ningún ítem, de los 35, tiene doliente, fecha, probabilidad ni impacto.** No los rellené: es el hallazgo. Probabilidad e impacto no están en ningún documento, así que no hay escala que aplicar.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| (nuevo) PRY-210 | Riesgo | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-15 | Depende de un tercero y nadie lo anotó. Decisión pedida: ¿se formaliza, con doliente y fecha? |
| PRY-200, 201, 202, 204, 205 | Dependencia (hoy registrada como riesgo) | El proveedor no ha confirmado la fecha de la última entrega | sin doliente | informes del 2026-09-24 al 2026-10-13 | Es una dependencia declarada y sin confirmar, sin doliente y sin fecha. Decisión pedida: ¿quién la confirma con el proveedor y para cuándo? |

Del resto no puedo decir que cumpla un criterio de escalamiento: no hay doliente, fecha ni movimiento contra los cuales medir si «excede autoridad», «lleva dos períodos» o «venció la mitigación».

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo (también dependencia del proveedor) | `PRY-210-portal-de-proveedores/2026-10-15-notas-reunion.txt`, línea 7 | 2026-10-15 |

Es el único. Las minutas de PRY-199 a PRY-209 solo traen la tabla de compromisos; las de PRY-210 traen compromisos y dos frases sobre actas no presentadas. No encontré otro riesgo dicho al pasar y no inventé ninguno. Las notas no nombran al proveedor.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| PRY-199, 201, 203, 205, 207, 209, 211 | Riesgo | Concentración del conocimiento en una sola persona | Doliente, fecha, probabilidad, impacto |
| PRY-199, 200, 206, 208, 210 | Riesgo | Disponibilidad del equipo de seguridad para la revisión final | Doliente, fecha, probabilidad, impacto |
| PRY-203, 204, 211 | Riesgo | Cambio regulatorio en discusión que puede mover el alcance | Doliente, fecha, probabilidad, impacto |
| PRY-199, 204, 205, 209 | Incidencia | Se reprogramó la salida por ventana de cambio de operaciones | Doliente, desde cuándo |
| PRY-199, 201, 202, 207 | Incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | Doliente, desde cuándo |
| PRY-200, 203, 204 | Incidencia | Se levantó un hallazgo de seguridad en la revisión de arquitectura | Doliente, desde cuándo |
| PRY-202, 208, 209 | Incidencia | Dos historias quedaron fuera del sprint por dependencia con el core | Doliente, desde cuándo |

### Reclasificaciones
| Id | Estaba como | Pasa a | Por qué |
|---|---|---|---|
| PRY-200, 201, 202, 204, 205 | Riesgo | Dependencia | «El proveedor no ha confirmado la fecha»: depende de alguien fuera del proyecto. Sigue siendo declarada, no acordada. |
| PRY-208 | Riesgo | Dependencia | «Dependencia del calendario de liberaciones del core»: lo dice su propio texto. |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| PRY-208 | «el core», sin código de proyecto | No | No puedo cruzarla: ningún documento dice qué proyecto es «el core». |
| PRY-202, 208, 209 | «el core», sin código | No | Mismo vacío; la incidencia de las dos historias ya ocurrió. |
| PRY-200, 201, 202, 204, 205 | Proveedor sin nombre | No | Fecha de última entrega sin confirmar. |

PRY-201 se llama «Core de depósitos» y tiene la solicitud de cambio CC-01 y un cronograma v2, pero eso es una coincidencia de nombre, no una dependencia citada. No afirmo que sea «el core». Las actas de PRY-201, 207 y 208 dicen «Ninguna declarada» en dependencias, aunque PRY-208 dice después depender del core: contradicción para el gerente.

### Registro completo
| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último movimiento |
|---|---|---|---|---|---|---|---|
| PRY-199 | Riesgo | Concentración del conocimiento en una sola persona | n/d | n/d | n/d | n/d | n/d |
| PRY-199 | Riesgo | Disponibilidad del equipo de seguridad | n/d | n/d | n/d | n/d | n/d |
| PRY-199 | Incidencia | Salida reprogramada por ventana de cambio | – | – | n/d | n/d | n/d |
| PRY-199 | Incidencia | Rotación de un desarrollador clave | – | – | n/d | n/d | n/d |
| PRY-200 | Riesgo | Disponibilidad del equipo de seguridad | n/d | n/d | n/d | n/d | n/d |
| PRY-200 | Dependencia (reclasificada) | Proveedor sin confirmar fecha | – | – | n/d | n/d | n/d |
| PRY-200 | Incidencia | Hallazgo de seguridad en revisión de arquitectura | – | – | n/d | n/d | n/d |
| PRY-201 | Dependencia (reclasificada) | Proveedor sin confirmar fecha | – | – | n/d | n/d | n/d |
| PRY-201 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-201 | Incidencia | Rotación de un desarrollador clave | – | – | n/d | n/d | n/d |
| PRY-202 | Dependencia (reclasificada) | Proveedor sin confirmar fecha | – | – | n/d | n/d | n/d |
| PRY-202 | Incidencia | Dos historias fuera del sprint por dependencia con el core | – | – | n/d | n/d | n/d |
| PRY-202 | Incidencia | Rotación de un desarrollador clave | – | – | n/d | n/d | n/d |
| PRY-203 | Riesgo | Cambio regulatorio que puede mover el alcance | n/d | n/d | n/d | n/d | n/d |
| PRY-203 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-203 | Incidencia | Hallazgo de seguridad en revisión de arquitectura | – | – | n/d | n/d | n/d |
| PRY-204 | Riesgo | Cambio regulatorio que puede mover el alcance | n/d | n/d | n/d | n/d | n/d |
| PRY-204 | Dependencia (reclasificada) | Proveedor sin confirmar fecha | – | – | n/d | n/d | n/d |
| PRY-204 | Incidencia | Hallazgo de seguridad en revisión de arquitectura | – | – | n/d | n/d | n/d |
| PRY-204 | Incidencia | Salida reprogramada por ventana de cambio | – | – | n/d | n/d | n/d |
| PRY-205 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-205 | Dependencia (reclasificada) | Proveedor sin confirmar fecha | – | – | n/d | n/d | n/d |
| PRY-205 | Incidencia | Salida reprogramada por ventana de cambio | – | – | n/d | n/d | n/d |
| PRY-206 | Riesgo | Disponibilidad del equipo de seguridad | n/d | n/d | n/d | n/d | n/d |
| PRY-207 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-207 | Incidencia | Rotación de un desarrollador clave | – | – | n/d | n/d | n/d |
| PRY-208 | Dependencia (reclasificada) | Calendario de liberaciones del core | – | – | n/d | n/d | n/d |
| PRY-208 | Riesgo | Disponibilidad del equipo de seguridad | n/d | n/d | n/d | n/d | n/d |
| PRY-208 | Incidencia | Dos historias fuera del sprint por dependencia con el core | – | – | n/d | n/d | n/d |
| PRY-209 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-209 | Incidencia | Dos historias fuera del sprint por dependencia con el core | – | – | n/d | n/d | n/d |
| PRY-209 | Incidencia | Salida reprogramada por ventana de cambio | – | – | n/d | n/d | n/d |
| PRY-210 | Riesgo | Disponibilidad del equipo de seguridad | n/d | n/d | n/d | n/d | n/d |
| PRY-210 | Riesgo, no registrado | Proveedor podría no llegar con el equipo completo | n/d | n/d | n/d | n/d | 2026-10-15 (dicho) |
| PRY-211 | Riesgo | Concentración del conocimiento | n/d | n/d | n/d | n/d | n/d |
| PRY-211 | Riesgo | Cambio regulatorio que puede mover el alcance | n/d | n/d | n/d | n/d | n/d |

`n/d` = no está en ningún documento. Cada fila cita el informe de avance de su proyecto (fecha 2026-09-24 a 2026-10-15), tal como está en la ficha.

### Dos cosas que vale mirar
- **Texto idéntico entre proyectos.** Las mismas ocho frases se repiten en 13 proyectos distintos, con áreas y comités distintos. Puede ser una plantilla de informe; no puedo decir si cada riesgo es real en cada proyecto. Conviene que cada gerente confirme los suyos.
- **PRY-210, compromisos que se corren (no son RAID, pero alimentan uno).** «Enviar el documento 1» (Jorge Medina) pasó de 2026-09-17 a 2026-12-08 en 7 apariciones; «Confirmar la fecha 7» (Javier Hoyos), de 2026-10-02 a 2026-11-27. Eso lo cubre `/commitments`; aquí solo señalo que, si bloquean algo, el riesgo no está registrado.

## Después
- **Subir a comité** (próximo, 2026-10-22): el riesgo no registrado de PRY-210 y la dependencia del proveedor sin confirmar (5 proyectos). Lo que subiría es la pregunta cerrada «¿quién confirma y para cuándo?», no el problema solo.
- **Proponer doliente:** no tengo base en los documentos para proponer uno por ítem. Los gerentes figuran en las fichas (por ejemplo Liliana Torres en PRY-210), pero asignar es decisión de ellos y de la PMO; no asigné ninguno.

## Lo que no sé
- Qué proyecto es «el core» y si alguno de los demás lo espera.
- Si hay riesgos hablados en reuniones que no quedaron en minuta; solo leí lo escrito.
- El contenido de los `.docx`, `.pdf` y `.xlsx` más allá de lo que ya extrajo la ficha.
- Probabilidad, impacto, doliente y fechas de los 35 ítems: no existen en los documentos.
