# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 89 documentos, 0 releídos y 89 sin cambio · 223 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

10 fichas nuevas (PRY-199 a 209, salvo 207) sobre 59 documentos; 30 sin cambio (207, 210, 211). Nada que mover: no existe entrada/. 35 señales nuevas, 2 verdes contradichos nuevos (206, 209). Mirar: facturas de PRY-208 y PRY-204 sin acta de recibo; CC-01 sin acta de comité en 201, 202, 204, 205; ficha-pm de PRY-210 con citas que no resuelven.

Contra la corrida del 2026-10-15: +35 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Encontré 89 documentos en 13 carpetas de proyecto, ningún archivo ilegible. Formatos: 43 md, 15 pdf, 11 docx, 10 xlsx, 8 csv, 1 json, 1 txt. El plan de lectura mandó leer 59 y dejar 30 sin abrir (no cambiaron desde la corrida anterior, que fue portfolio-setup). Los 59 son los de 10 proyectos que aún no tenían ficha.

**Documentos:** 89 en la carpeta · 59 leídos · 30 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Los documentos de PRY-207, PRY-210 y PRY-211 no se releyeron: sus fichas quedan como estaban.

### Nuevos
| Proyecto | Documentos | Campos sin dato |
|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | autoridad, fase; factura CT-199 |
| PRY-200 Originación digital | 4 | autoridad, fase, contrato; acta de recibo de 1 hito cerrado |
| PRY-201 Core de depósitos | 8 | autoridad, fase, contrato; los 2 hitos cerrados tienen acta |
| PRY-202 Migración a la nube | 6 | autoridad, fase, producto («No aplica»), contrato; acta de 1 hito cerrado |
| PRY-203 Open Banking | 2 | autoridad, fase, cronograma e hitos, línea base, minutas |
| PRY-204 Débito contactless | 10 | autoridad, fase; acta de 3 hitos cerrados; acta de 1 entregable recibido |
| PRY-205 Prevención de lavado de activos | 6 | autoridad, fase, producto («No aplica»), contrato; acta de los 3 hitos cerrados |
| PRY-206 Billetera y QR | 4 | autoridad, fase, contrato; acta de los 3 hitos cerrados |
| PRY-208 Motor de decisión | 8 | autoridad, fase, producto («No aplica»); acta de 1 hito cerrado; acta de los 4 entregables del contrato |
| PRY-209 Nómina electrónica | 5 | autoridad, fase, contrato; acta de 2 hitos cerrados |

La autoridad del gerente y la fase no aparecen en ningún acta del portafolio (13 de 13).

### Actualizados
Ninguna ficha previa se actualizó: PRY-207, PRY-210 y PRY-211 no tuvieron documentos nuevos.

### Lo que muestran los documentos (35 señales nuevas; 60 en el portafolio)

**Verde contradicho por los documentos**
- PRY-206 declara verde con 89%. El cierre del acta era 2026-03-25 y el informe es de 2026-10-12, sin cronograma nuevo ni solicitud de cambio. Sus tres hitos están cerrados sin acta de recibo.
- PRY-209 declara verde con 24%. Tiene tres de cuatro hitos cerrados; solo Integración con el core tiene acta (2026-10-14). El informe dice que se reprogramó la salida, pero hay una sola versión del cronograma.
- Con los verdes de PRY-210 y PRY-211 de la corrida anterior, son 4 verdes contradichos.

**Proveedores**
- PRY-208, CT-932 (Datacore): la factura FV-1932 por 105.076.622 COP (2026-09-27) está radicada y ningún entregable del contrato figura recibido ni tiene acta de recibo. Tres entregables ya pasaron su fecha (165, 104 y 43 días).
- PRY-204, CT-152 (Datacore): la factura FV-1152 por 1.351.144.064 COP equivale a dos entregables; solo la bolsa de horas tiene acta. La parametrización consta como recibida en el contrato, sin acta. El licenciamiento lleva 236 días vencido.
- PRY-199, CT-199: tres entregables pendientes, ninguno vencido, sin factura.

**Cambios y líneas base**
- PRY-204 y PRY-205: el cronograma v2 (2026-09-24 y 2026-10-03) mueve la salida o la integración antes de que se pida el cambio CC-01 (2026-10-06 y 2026-10-08). CC-01 solo dice «Autorizada por el comité», sin acta.
- PRY-201 y PRY-202: v2 posterior a CC-01, con los mismos días que pide el cambio (+20 y +120). Tampoco hay acta del comité.
- PRY-202, PRY-204 y PRY-205: la fecha nueva queda después del cierre del acta; las dos fechas se conservaron como ambiguas (variación de 52,6%, 21,0% y 37,3% contra la línea base original).

**Avance declarado contra el plan**
- PRY-204 (27%, cuatro de cinco hitos cerrados), PRY-205 (43%, los tres cerrados), PRY-206 (89%) y PRY-209 (24%): el avance no cabe en lo que el cronograma sostiene.
- PRY-203 declara rojo con 88%, pero solo hay acta e informe: no hay cronograma que lo sostenga.

**Hitos**
- 13 hitos cerrados sin acta de recibo en los 10 proyectos nuevos. Vencidos y abiertos: Ambiente de pruebas de PRY-202 (9 días) y Piloto de PRY-208 (4 días).

**Compromisos vencidos** (3): Carlos Peña (PRY-204, vencido 19 días; la fecha ya había pasado cuando se registró en la minuta del 2026-10-07), Elena Duarte (PRY-205, 15 días) y Diana Molina (PRY-205, 19 días).

### No pude leer
Nada: los 89 archivos se convirtieron a texto sin error.

Una observación sobre PRY-210: el índice reporta 38 campos de su ficha-pm cuya cita no resuelve, porque las rutas no incluyen la carpeta del proyecto (`00-gobierno/…` en lugar de `PRY-210-portal-de-proveedores/00-gobierno/…`). No toqué esa ficha: es del gerente.

### Movidos desde entrada/
La carpeta `entrada/` no existe; no había nada que mover.

### Pendientes de clasificar
Ninguno. No hay archivos sueltos y ningún proyecto apareció solo dentro de las minutas de otro.

### Supuestos míos que conviene revisar
- Tomé como fecha de fin la del último hito del cronograma, y guardé el cierre del acta aparte. Es la convención de las fichas de la corrida anterior.
- «Recibido» en un contrato lo registré como `accepted`, y la evidencia solo cuando hay un acta que nombra ese entregable.
- Las menciones a «el core» en los informes de PRY-202, PRY-208 y PRY-209 no las convertí en dependencia de PRY-201, porque ningún documento lo dice.

---
criterio-portfolio 0.3.10 · términos 1.1 (aceptados por José Francisco Ñáñez el 2026-10-15) · fichas tocadas: 10 (PRY-199, 200, 201, 202, 203, 204, 205, 206, 208, 209) · campos en `not_found`: ver cada ficha (`meta.fields_not_found`) · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
