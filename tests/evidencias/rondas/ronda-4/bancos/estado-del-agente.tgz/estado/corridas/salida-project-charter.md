Hay acta previa: `PRY-201-core-de-depósitos/00-gobierno/2026-04-12-acta-constitucion.md`, aprobada el 2026-04-12. Es la única; no hay versiones posteriores ni una revisión anterior de esta acta en el estado.

## Acta — PRY-201 · Core de depósitos
**Estado:** existe, del 2026-04-12 (modo revisar; no se modificó)

El acta tiene los campos, pero casi todos están en forma de plantilla sin llenar. Solo el patrocinador, el gerente, el presupuesto y las fechas tienen contenido real. Lo demás no se puede usar para decidir nada.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** | **No existe.** El acta no dice hasta qué monto ni qué cambio de alcance decide Carlos Peña sin subir a comité. | Todo cambio sube al comité por defecto. La solicitud CC-01 (ampliación de alcance, +20 días, 40.000.000 COP, el 0,6 % del presupuesto aprobado) quedó "autorizada por el comité" (`2026-10-06-solicitud-cambio-cc-01.md`). No se puede saber si el comité tenía que decidirla o si el gerente podía resolverla. |
| Objetivo de negocio | Describe la solución, no el resultado: "Entregar core de depósitos para Operaciones" (acta, "Objetivo del negocio"). | No dice qué mejora para el negocio ni cuánto. Un cambio de alcance no se puede juzgar contra el objetivo, porque el objetivo no discrimina nada. |
| Alcance | Marcadores sin llenar: "Componente 1 / 2 / 3". | CC-01 pide una "ampliación de alcance" y no hay alcance contra el cual medirla. Tampoco se puede verificar qué ampliaría ni si ya estaba incluido. |
| Exclusiones | "Lo que otro proyecto cubre", sin nombrar el proyecto. | Un traslape con otro proyecto del portafolio no se puede detectar ni discutir, porque no se dice cuál. |
| Supuestos y restricciones | **No existen.** | Los supuestos de los que depende el plazo (cierre 2027-05-11) no están declarados, así que ninguno se puede vigilar ni salir como riesgo cuando falle. |
| Dependencias | "Ninguna declarada". | El informe de avance del 2026-10-13 lista como riesgo abierto que "el proveedor no ha confirmado la fecha de la última entrega". Hay una dependencia externa que el acta dice que no existe. |
| Criterio de éxito | "Core de depósitos en producción y medido". No dice qué métrica, qué umbral ni quién la mide. | No se puede decidir si el proyecto cumplió. El cierre quedaría a juicio de quien lo declare. |
| Hitos principales | No hay. Solo fecha de inicio (2026-04-22) y de cierre (2027-05-11). | No hay puntos intermedios contra los cuales medir el atraso. Esa referencia queda solo en los cronogramas (no se usaron en esta revisión). |
| Comité y cadencia | Se nombra el Comité de Arquitectura. La cadencia no se declara. | Se sabe a quién se reporta, pero no cada cuánto ni qué decide ese comité. |
| Patrocinador / gerente | Óscar Ramírez / Carlos Peña. Con nombre de persona. | Sin hallazgo. |
| Presupuesto y fechas | Presupuesto aprobado 6.800.000.000 COP, aprobado por el Comité de Arquitectura el 2026-04-12. | Sin hallazgo en el acta. Sin autoridad declarada ni tolerancia, la proyección al cierre del informe (7.022.864.553 COP, 222.864.553 COP o 3,3 % sobre lo aprobado) no tiene umbral contra el cual juzgarse. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta solo dice "Entregar core de depósitos para Operaciones", que es la solución. Falta qué resultado se busca y en cuánto.
**Alcance:** pendiente de definir. El acta tiene "Componente 1, 2, 3" sin contenido.
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre" sin nombrar el proyecto.
**Patrocinador:** Óscar Ramírez · **Gerente:** Carlos Peña (acta, cabecera)
**Autoridad del gerente:** hasta [pendiente de definir: monto] y [pendiente de definir: qué cambios] sin comité. No está en ningún documento de la carpeta.
**Comité al que reporta:** Comité de Arquitectura (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Core de depósitos en producción y medido" (acta). Falta la métrica y el umbral · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir en el acta. Fechas del acta: inicio 2026-04-22, cierre 2027-05-11.
**Presupuesto aprobado:** 6.800.000.000 COP, 2026-04-12 (acta).

### Después
- **Autoridad del gerente:** es una decisión del comité, no un trámite. Propongo llevarle la definición (monto y tipo de cambio que Carlos Peña puede decidir solo) en la próxima sesión, la del 2026-10-22. Con esa decisión CC-01 y los siguientes cambios dejan de subir por defecto.
- **Supuestos:** de esta revisión salen tres para el registro RAID, y los dejo como candidatos, no registrados: (1) que el proveedor entrega a tiempo, sin fecha confirmada hoy; (2) que no hay otras dependencias, aunque el acta dice "ninguna" y el informe contradice eso; (3) que el alcance de los tres componentes es el que se aprobó, aunque el acta no lo describe. Puedo pasarlos al registro cuando lo indique.

### Pie de rigor
- **Leído:** el acta del 2026-04-12, la solicitud de cambio CC-01 (2026-10-06), el comité del 2026-10-02 y el informe de avance del 2026-10-13, todos de PRY-201.
- **No leído:** los cronogramas v1 y v2, las dos actas de recibo y el resto de la carpeta de gobierno, que no tiene contrato de proveedor. Si el cronograma tiene hitos, el hallazgo de "hitos" cambia de "no hay" a "no están en el acta".
- **No sé:** lo que se haya hablado fuera de estos documentos. Puede haber una autoridad acordada de palabra o un alcance definido en otro lado, y esta revisión no lo ve.
- **Verificación:** las citas son del documento de origen; la verificación es de usted. Esto es un borrador de trabajo, no una decisión.
