# Corrida del 2026-10-15 · document-index

13 proyectos · 23 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

89 documentos sin cambio, 0 por releer. 39 citas de PRY-210 no resuelven en el índice aunque los archivos existen en la carpeta del proyecto; causa probable de ruta relativa, no confirmada. No se modificó ninguna ficha.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 89 · **Sin cambio:** 89 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
Todas son del proyecto PRY-210 (39 citas, 5 documentos citados):

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-210 | identity (code, name, business_area, sponsor, manager, committee), plan.start_date, plan.end_date, plan.scope_summary, plan.exclusions (12 campos) | 00-gobierno/2025-09-01-acta-constitucion.docx |
| PRY-210 | declared (status, progress_pct, as_of), money (currency, approved, committed, executed, projection) (8 campos) | 20-seguimiento/2026-10-13-informe-avance.md |
| PRY-210 | plan.milestones[0..4] (name, baseline_date, current_date, state; 20 campos) | 10-plan/2026-10-13-cronograma-v2.xlsx |
| PRY-210 | plan.milestones[0].evidence (1 campo) | 20-seguimiento/2026-10-11-acta-recibo-diseño-funcional-aprobado.pdf |

Lo que sé y lo que no: los cuatro archivos existen dentro de la carpeta del proyecto (documentos/proyectos/PRY-210-portal-de-proveedores/…) y el índice los reporta sin cambio. La cita está escrita relativa a esa carpeta y el índice compara contra la ruta completa desde la raíz de documentos, así que lo más probable es una diferencia de ruta y no un documento perdido. No lo he confirmado ni he tocado ninguna ficha. Mientras no se corrija, el informe muestra esos 39 datos como sustentados sin que la cita resuelva.

### Formatos que no se pudieron leer
Ninguno reportado por el índice (este comando no lee contenido).

### Siguiente paso
No hay documentos por releer, así que no corresponde un /portfolio-scan. Pendiente de decisión humana: corregir las 39 citas de PRY-210 (una por una, mostrando el cambio) o revisar cómo se escribe la ruta en su ficha.
