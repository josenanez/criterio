## Listo — Portafolio de proyectos

**Miré:** 89 documentos en 13 proyectos · formatos: .md 43, .pdf 15, .docx 11, .xlsx 10, .csv 8, .json 1, .txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (propuesto: hay 13 proyectos)
**Te aviso:** dos días antes del comité; sin fecha de comité conocida, propuse cada dos semanas con el próximo el 2026-10-22 (valor sugerido, por confirmar)
**En:** página (HTML; ajustable a presentación o PDF si lo pides)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.10 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 del comprobante: 5a63e87d0ce9d54086e0d0f78525bdf47a12e2bc8d81d92c99f996c4b51ca6e6 (primeros 16: 5a63e87d0ce9d540)…

Dónde queda todo: configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

Los tres con documentación más reciente (todos con documentos del 2026-10-15): PRY-207, PRY-210 y PRY-211.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-207 Onboarding PyME | 6 | Gerente Camilo Beltrán, patrocinadora María Restrepo. Declara amarillo y 40 % (2026-10-15). Presupuesto 6.800 M COP, comprometido 89,2 %. CC-01 (+32 días, +64 M) "autorizada por el comité". | Autoridad del gerente, fase, actas de recibo de los tres hitos, acta del comité que autorizó CC-01. |
| PRY-210 Portal de proveedores | 19 leídos por el sello (26 en carpeta) | Gerente Liliana Torres, patrocinador Andrés Lozano. Declara verde y 34 % (2026-10-13). Presupuesto 2.400 M COP, ejecutado 59,5 %. 26 compromisos seguidos en seis comités. Su ficha de gerente (`ficha-pm.json`) quedó guardada aparte, sin fusionar. | Producto (el acta dice "No aplica"), autoridad, fase, proveedor, dueño de los dos riesgos. |
| PRY-211 Cobranza digital | 5 | Gerente Laura Vélez, patrocinadora Liliana Torres. Declara verde y 34 % (2026-09-25). Presupuesto 4.200 M COP. Dos actas de recibo (piloto 2026-10-06, integración con el core 2026-10-15). | Autoridad, fase, minutas de comité, cualquier solicitud de cambio. |

**Señales que levantó el cálculo** (25 en total, 3 proyectos con señales):

- **PRY-207**
  - `progress_vs_plan`: declara 40 % y los tres hitos del plan están cerrados (brecha de 60 puntos).
  - `milestone_met_without_evidence` ×3: Diseño funcional, Ambiente de pruebas e Integración con el core figuran cerrados sin acta de recibo.
- **PRY-210**
  - `declared_vs_evidence`: declara verde, y el cálculo levanta cinco señales en contra: compromisos vencidos, compromisos reprogramados, hitos sin evidencia, avance contra plan y línea base movida sin autorización.
  - `progress_vs_plan`: declara 34 % y el plan sostiene entre 60 % y 80 %.
  - `milestone_met_without_evidence` ×2: Ambiente de pruebas e Integración con el core.
  - `commitment_overdue` ×5: Paula Céspedes (20 días), Diana Molina (23), Camilo Beltrán (9), Laura Vélez (4) y Andrés Lozano (1).
  - `commitment_undated` ×2: María Restrepo (anexo 19) y Laura Vélez (ajuste del presupuesto).
  - `commitment_rescheduled` ×4: Jorge Medina 6 veces, Liliana Torres 5, Javier Hoyos 4, Natalia Ospina 3.
  - `rebaseline_unauthorized`: la salida a producción pasó del 2027-03-01 al 2027-04-11 (41 días) con CC-01 aún pendiente.
  - `pm_vs_pmo`: fecha de cierre; la ficha del gerente dice 2027-04-24 (acta) y el cronograma v2 dice 2027-04-11.
- **PRY-211**
  - `declared_vs_evidence`: declara verde con dos señales en contra.
  - `progress_vs_plan`: declara 34 % y los cuatro hitos del plan están cerrados (brecha de 66 puntos).
  - `milestone_met_without_evidence` ×2: Diseño funcional y Ambiente de pruebas.

Dos riesgos que aparecen en los documentos de PRY-210 y que nadie ha registrado como tal: el proveedor podría no llegar con el equipo completo para la siguiente fase (notas del 2026-10-15), y los dos riesgos que sí están registrados no tienen dueño.

### El portafolio completo
10 proyectos más y 49 documentos (un solo lote de diez proyectos, uno tras otro). Estimado propio, no medido: unas tres veces lo que tomó esta prueba.

### Lo que le falta a tu carpeta
Ninguno es bloqueante.
- PRY-203 tiene solo dos documentos (acta e informe): sin cronograma ni minutas.
- PRY-211 no tiene minutas de comité, y su cronograma v1 fecha los hitos de integración y piloto en marzo y mayo de 2026, mientras las actas de recibo son de octubre.
- Los tres proyectos probados declaran hitos cerrados sin acta de recibo.
- Ninguna acta de constitución dice hasta qué monto puede decidir el gerente sin subir a comité.
- Las actas de constitución tienen entre 13 y 16 meses; patrocinador, gerente y alcance no se han reconfirmado después.
- En las actas el alcance es genérico ("Componente 1, 2, 3").

Una nota sobre la prueba: no hubo nadie para responder; tomé las respuestas sugeridas (rol PMO, comité cada dos semanas, página, estado en `estado/`) y las dije arriba.
