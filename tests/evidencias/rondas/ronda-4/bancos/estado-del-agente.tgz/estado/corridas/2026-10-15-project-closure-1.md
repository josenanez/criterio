# Corrida del 2026-10-15 · project-closure

13 proyectos · 40 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Cierre por decisión, no por cumplimiento: proyecto en rojo (43%), criterio de éxito no verificable, 3 hitos cerrados sin acta de recibo, CC-01 sin acta de comité. Declaré sin dato: producción y medición, contenido de los componentes, motivo de la v2, dolientes de los RAID, proveedor.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fichas y documentos de los que sale:** ficha `estado/records/PRY-205.json` y cifras de `portafolio.py compute` (corte 2026-10-15). Documentos leídos: acta de constitución (2026-02-08), cronogramas v1 (2026-02-08) y v2 (2026-10-03), informe de avance (2026-10-03), solicitud CC-01 (2026-10-08) y minuta del comité (2026-10-11). Términos vigentes (v0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15).

## Cierre — PRY-205 Prevención de lavado de activos — 2026-10-15

**Aviso previo: este proyecto no está terminado.** El informe de avance más reciente (2026-10-03) lo declara en **rojo, 43 %**, y el cronograma vigente tiene su último hito con fecha 2026-12-02, futura. Lo que sigue es un cierre *por decisión* (si alguien lo quiere cerrar hoy), no un cierre por cumplimiento. No hay ninguna declaración de que el proyecto terminó.

### Contra lo comprometido
**Criterio de éxito:** «Prevención de lavado de activos en producción y medido.» (acta de constitución, 2026-02-08, `00-gobierno/2026-02-08-acta-constitucion.docx`)
**Se cumplió:** **no se puede determinar; la evidencia disponible apunta a que no.** Ningún documento muestra puesta en producción ni medición. El informe de avance declara 43 % y rojo.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 / 2 / 3 (alcance del acta) | Sin dato: el acta no los describe ni los liga a hitos | Acta: solo los nombra |
| Hito «Diseño funcional aprobado» (2026-04-28) | Marcado «cerrado» en el cronograma | **Sin acta de recibo** |
| Hito «Ambiente de pruebas certificado» (2026-07-07) | Marcado «cerrado» | **Sin acta de recibo** |
| Hito «Integración con el core» (línea base 2026-09-15, vigente 2026-12-02) | Marcado «cerrado» con fecha futura | **Sin acta de recibo**; contradice el 43 % declarado |

Los tres hitos figuran cerrados, pero el avance declarado es 43 %: el plan sostiene 100 % y la declaración 43 %, una brecha de 57 puntos que nadie explica.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Acta: «Lo que otro proyecto cubre» (sin nombrar cuál) | Acta de constitución | 2026-02-08 |
| CC-01 *amplió* el alcance (no lo recortó); no dice qué se agrega | «Autorizada por el comité» (sin nombre, sin acta de comité) | Solicitud 2026-10-08 |

No hay alcance recortado documentado. Hallazgo: la ampliación CC-01 no tiene decisión verificable.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha | 2026-09-15 (línea base v1) | 2026-12-02 (v2) | Sin dato: el proyecto no ha terminado | **78 días (37,3 %)** |
| Presupuesto (COP) | 4.200.000.000 aprobado | 4.200.000.000 (CC-01 pide 156.000.000 adicionales, sin respaldo; no están incorporados) | Ejecutado a la fecha del informe: 1.022.306.302 (24,3 %); comprometido 2.196.050.514 (52,3 %); proyección declarada 3.988.589.390 (−5,0 % vs. aprobado) | Sin cierre: no es un final |

Desviación contra la vigente: 0 días (la vigente ya absorbió los 78). Replanificaciones: **1** (v1 → v2, 2026-10-03). La v2 no registra motivo, y la CC-01 que pide esos 78 días es posterior (2026-10-08) a la línea base que ya los contenía. Además, el acta fija el cierre en **2026-10-20**, que no coincide con la línea base original del cronograma (2026-09-15); queda sin conciliar.

La proyección de 3.988.589.390 es una declaración del gerente, no una medición, y con el 24,3 % ejecutado no tiene sustento visible.

### RAID al cierre
**Materializados:** incidencia «Se reprogramó la salida por ventana de cambio del área de operaciones» (informe 2026-10-03), sin fecha de inicio ni responsable. No se puede decir que se haya materializado ninguno de los dos riesgos.
**No materializados:** ninguno confirmado como tal.
**Abiertos, con doliente:** ninguno tiene doliente con nombre, así que **no están cerrados**:
- Riesgo: concentración del conocimiento en una sola persona (sin responsable, probabilidad ni impacto).
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (sin responsable; no hay contrato de proveedor en la carpeta).
- Incidencia: reprogramación de la salida (sin responsable).
- Compromisos vencidos: Elena Duarte, «Entregar el punto 40», para 2026-09-30 (15 días); Diana Molina, «Entregar el punto 30», para 2026-09-26 (19 días). Ambos consignados en la minuta del 2026-10-11, o sea registrados *después* de vencer, y sin evidencia de entrega.

### Lecciones
Solo entran las ancladas a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Cronograma v2 movió «Integración con el core» de 2026-09-15 a 2026-12-02 | 2026-10-03 | +78 días (37,3 %) sobre la línea base original | Registrar el motivo de la replanificación en la línea base misma |
| La CC-01 (+78 días, +156.000.000 COP) se emitió cinco días *después* de que la v2 ya contenía el atraso, y dice solo «Autorizada por el comité» | 2026-10-08 | Cambio sin decisión verificable ni línea base propia | Aprobar el cambio antes de mover la línea base, con acta y nombre |
| Tres hitos «cerrados» sin acta de recibo, mientras el avance declarado es 43 % | corte 2026-10-03 | El plan y la declaración no se pueden conciliar | Exigir acta de recibo para marcar un hito como cerrado |
| Compromisos de la minuta del 2026-10-11 con fechas ya vencidas (2026-09-26 y 2026-09-30) | 2026-10-11 | Dos entregas sin evidencia, 15 y 19 días de vencidas | Registrar compromisos en el momento en que se asumen, con fecha futura |

Sin ancla documental, **no** se sustenta ninguna lección sobre el proveedor, ni sobre el riesgo de concentración de conocimiento (solo está listado, sin hechos).

### Sin dato
- Si hubo puesta en producción y medición (criterio de éxito).
- Qué son los Componentes 1, 2 y 3, y cuáles se entregaron.
- Quién decidió la CC-01 y qué alcance agrega.
- El motivo de la línea base v2 y de la discrepancia entre el cierre del acta (2026-10-20) y la línea base original (2026-09-15).
- Autoridad, fase y producto asociado (el acta dice «No aplica»).
- Contrato o entregables del proveedor mencionado en el informe.
- Fecha real de terminación y gasto final.
- Responsable de los riesgos y la incidencia abiertos.

### Después
Mover la carpeta a `archivo/` y congelar la ficha **no es lo que recomiendo todavía**: sería sacar del barrido diario un proyecto en rojo, con dos compromisos vencidos, una CC-01 sin respaldo y riesgos sin doliente. Si el comité decide cerrarlo igual, esa decisión (con nombre y fecha) debe constar, y los puntos abiertos deben tener doliente antes. Por ahora no moví ni congelé nada: queda como oferta para quien tenga autoridad.

---
*Pie de rigor: borrador de trabajo; cada dato sale de los documentos citados y la verificación es suya. Las cifras derivadas se copiaron de `portafolio.py compute`; lo que no está en la documentación se declara «sin dato». Criterio no sabe lo que se habló fuera de los documentos.*
