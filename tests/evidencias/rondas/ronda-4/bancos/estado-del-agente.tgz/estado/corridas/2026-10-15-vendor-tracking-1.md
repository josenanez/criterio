# Corrida del 2026-10-15 · vendor-tracking

13 proyectos · 38 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Proveedores PRY-204 (Datacore, CT-152): 1 entregable tarde (licenciamiento, 236 días), 1 aceptado sin evidencia (parametrización, facturada sin acta), FV-1152 sin desglose. Dije que no sé: vigencia/preaviso del contrato, desglose de la factura, estado de pago, quién es Carlos Peña.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Sale de:** contrato CT-152 (`00-gobierno/2025-10-28-contrato-ct-152.md`), acta de recibo de la bolsa de horas (`20-seguimiento/2026-06-22-acta-recibo-ct-152-bolsa-de-horas-de-desarrollo.md`), factura FV-1152 (`20-seguimiento/2026-08-30-factura-ct-152.pdf`), informe de avance del 2026-09-24, solicitud de cambio CC-01, comité del 2026-10-07 y la ficha PRY-204; cifras de `portafolio.py compute` al 2026-10-15. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15.

## Proveedores — PRY-204 Débito contactless al 2026-10-15

### Datacore Colombia — contrato CT-152
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo trae fecha de firma, 2025-10-28, entregables y condición de pago)

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor (675.572.032 COP) | 2026-02-21 | pendiente, 236 días tarde («en curso» en el contrato) | ninguna | no, según FV-1152 por 1.351.144.064 = dos entregables |
| Bolsa de horas de desarrollo (675.572.032 COP) | 2026-06-10 | aceptado | acta de recibo 2026-06-22, firmada por Jorge Medina | sí, dentro de FV-1152 (sin desglose) |
| Parametrización del tarifario (675.572.032 COP) | 2026-09-27 | «recibido» solo en el contrato → **sin evidencia** | ninguna | sí, dentro de FV-1152 (sin desglose) |

Resumen del script: 3 entregables, 2 aceptados, 1 tarde, 1 aceptado sin evidencia, 1.351.144.064 COP facturados, 1.351.144.064 COP contados como aceptados.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Pago de la parametrización | Se factura contra acta de recibo firmada por el gerente | No hay acta. La factura FV-1152 (2026-08-30) es anterior a la fecha comprometida del entregable (2026-09-27) | contrato CT-152; FV-1152 |
| Detalle de la factura | Tres entregables con monto propio de 675.572.032 COP | FV-1152 dice solo «Entregables del contrato CT-152»; 1.351.144.064 equivale a dos entregables, pero no dice cuáles | contrato CT-152; FV-1152 |
| Licenciamiento | Comprometido el 2026-02-21, estado «en curso» | Sin acta ni avance posterior; el informe del 2026-09-24 lista como riesgo que el proveedor no ha confirmado la fecha de la última entrega | contrato CT-152; informe de avance 2026-09-24 |

El cálculo «facturado = aceptado» del script se sostiene solo si la factura cubre bolsa de horas y parametrización. Eso es una inferencia por el monto, no un dato de la factura. Sin acta de la parametrización, 675.572.032 COP de lo facturado carecen del soporte que exige el contrato.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Parametrización del tarifario | recibido (contrato CT-152) / aceptado (ficha) | la fecha del documento que lo marca no consta; la fecha comprometida es 2026-09-27 |

Hay un caso paralelo en el plan, aunque no es del proveedor: tres hitos figuran como cerrados sin acta de recibo (Ambiente de pruebas certificado, Integración con el core, Piloto con usuarios internos). No se puede decir si alguno corresponde a trabajo de Datacore.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Licenciamiento del motor (compromiso contractual) | CT-152 | 2026-02-21 | 236 |
| Entregar el punto 31 (Carlos Peña) | comité 2026-10-07 | 2026-09-26 | 19 |

Los documentos no dicen si Carlos Peña es de Datacore ni qué es el «punto 31». Lo cito porque es el único compromiso vencido del proyecto. La minuta que lo registra es posterior a su fecha de vencimiento.

### Contexto del cambio CC-01
CC-01 (ampliación de alcance, +83 días y 166.000.000 COP adicionales) figura como «Autorizada por el comité» sin acta que lo respalde. El script lo marca como cambio sin línea base nueva sustentada (`change_without_baseline`). No dice si afecta el alcance de CT-152, y el contrato no tiene adenda en la carpeta.

### Sin dato
- Vigencia, renovación automática y preaviso del contrato CT-152: el documento no los trae. No puedo decir si hay un preaviso por vencer antes del cierre (acta de constitución: 2027-01-14; salida vigente: 2027-02-26).
- Desglose de FV-1152 por entregable.
- Estado de pago de FV-1152: solo dice «Radicada en cuentas por pagar».
- Acta de recibo de la parametrización del tarifario.
- Afiliación de Carlos Peña y contenido del «punto 31».

## Después
Hay 675.572.032 COP facturados sin acta de recibo y un licenciamiento con 236 días de atraso sin evidencia de avance. Conviene llevar ambos al próximo comité (2026-10-22) y pedir a Jorge Medina el acta de la parametrización, o la suspensión del pago hasta que exista. Pedir también a Datacore el desglose de FV-1152 y la copia de la cláusula de vigencia y renovación.

---
*Rigor:* leí los documentos de PRY-204 en `documentos/proyectos`; no leí el acta de constitución `.docx`. Las cifras derivadas salen de `portafolio.py compute`. Todo lo que no figura en un documento está marcado «sin dato». Esto es un borrador de trabajo: la verificación contra los documentos citados es de quien lo use.
