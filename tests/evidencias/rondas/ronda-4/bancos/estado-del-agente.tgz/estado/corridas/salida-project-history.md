## Historia · PRY-201 Core de depósitos · 2026-04-12 a 2026-10-13

**Leí:** 8 documentos entre 2026-04-12 y 2026-10-13 (los 8 de la carpeta del proyecto; el PDF se leyó con pdftotext y los dos cronogramas con openpyxl).
**Trimestres sin un solo documento:** 2026-T3 (julio–septiembre). Entre el acta de constitución y cronograma v1 (2026-04-12) y el siguiente documento (2026-10-02) hay 173 días sin nada escrito.

Términos: vigentes (versión 0.3.10), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo.

### En una línea
El proyecto se aprobó el 2026-04-12 con cierre el 2027-04-06 según el cronograma v1; no hay nada escrito durante cinco meses y medio, y en octubre de 2026 aparecen en una semana los dos recibos de los hitos que el plan fechaba en junio y septiembre, la solicitud de cambio CC-01 (+20 días, 2026-10-06) y un cronograma v2 (2026-10-13) que mueve el cierre al 2027-04-26 sin decir por qué.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 20 días (5.7 %) | No calculable: hay un solo informe declarado (2026-10-13) | 0 |

Las cifras vienen de `portafolio.py compute` (replans 1, slip_vs_original_days 20, slip_vs_original_pct 5.7, governance_changes vacío).

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-04-12 | `00-gobierno/2026-04-12-acta-constitucion.md` | Aprobación: presupuesto 6.800.000.000 COP, inicio 2026-04-22, cierre 2027-05-11. Patrocinador Óscar Ramírez, gerente Carlos Peña, Comité de Arquitectura. |
| 2026-04-12 | `10-plan/2026-04-12-cronograma-v1.xlsx` | Línea base v1: salida a producción 2027-04-06. |
| 2026-04-12 → 2026-10-02 | (ninguno) | 173 días sin documentos. |
| 2026-10-02 | `20-seguimiento/2026-10-02-acta-recibo-diseño-funcional-aprobado.pdf` | Recibo de «Diseño funcional aprobado», hito con fecha de línea base 2026-06-30 (94 días antes del recibo). |
| 2026-10-02 | `30-reuniones/2026-10-02-comite-semanal.md` | Comité: Carlos Peña y Óscar Ramírez. Compromiso de Ricardo Salas: «Entregar el punto 9» para 2026-11-05. |
| 2026-10-06 | `20-seguimiento/2026-10-06-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +20 días y +40.000.000 COP; «Autorizada por el comité». |
| 2026-10-09 | `20-seguimiento/2026-10-09-acta-recibo-ambiente-de-pruebas-certificado.md` | Recibo de «Ambiente de pruebas certificado», hito con fecha de línea base 2026-09-08 (31 días antes del recibo). |
| 2026-10-13 | `10-plan/2026-10-13-cronograma-v2.xlsx` | Salida a producción pasa de 2027-04-06 a 2027-04-26. |
| 2026-10-13 | `20-seguimiento/2026-10-13-informe-avance.md` | Estado declarado amarillo, 48 %; perdieron dos semanas por rotación de un desarrollador clave; proyección al cierre 7.022.864.553 COP. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-13 | 2027-04-26 (+20 días sobre 2027-04-06) | No documentado en el cronograma v2. | Ninguno nombrado. |

Lo que sí se puede decir: los 20 días coinciden con los de CC-01 (2026-10-06) y el informe del 2026-10-13 menciona dos semanas perdidas por rotación. Ningún documento enlaza el cronograma v2 con CC-01 ni con esa causa; es una coincidencia, no una trazabilidad. CC-01 dice «Autorizada por el comité» sin nombre ni acta, y el único acta de comité de la carpeta (2026-10-02) es anterior a la solicitud y no la menciona. Además, la solicitud pide ampliar alcance y el cronograma solo mueve el último hito; los otros hitos pendientes conservan sus fechas.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos. | — |

Sin nada que contrastar en correos ni minutas más allá del comité del 2026-10-02, que no es evidencia suficiente de estabilidad.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ninguno repetido | — | — | — |

Hay un solo compromiso abierto: Ricardo Salas, «Entregar el punto 9», 2026-11-05 (dicho el 2026-10-02, aún no vence). No dice a qué se refiere «punto 9», y Ricardo Salas no figura entre los asistentes de esa reunión.

### Desde cuándo lo declarado no se sostiene
Con una sola declaración no se puede ubicar un punto de separación: no hay serie contra la cual medir un deslizamiento. Lo que sí hay:
- El 48 % declarado el 2026-10-13 cae dentro de lo que el plan sostiene (entre 40 % y 60 %, 2 de 5 hitos con evidencia de recibo). Brecha: 0 puntos.
- Los dos hitos «cerrados» tienen recibo, pero con fecha de recibo posterior a su fecha de línea base (94 y 31 días), y los cronogramas muestran como fecha vigente la de la línea base original, sin atraso registrado. Que el recibo sea posterior no prueba que el hito se terminara tarde: puede haberse terminado antes y firmado después. Es la distancia entre lo ocurrido y lo escrito, y quien pueda decir cuál fue se lo debe preguntar a Carlos Peña.
- Una inconsistencia de archivo: el cronograma v1 está fechado 2026-04-12 pero ya marca como «cerrado» dos hitos con fechas de junio y septiembre. No puede reflejar el estado real de abril; el archivo se tocó después o el nombre no corresponde a su contenido.
- El acta de constitución dice cierre 2027-05-11; el cronograma v1 dice 2027-04-06. Una diferencia de 35 días entre dos documentos del mismo día, sin explicación. El cálculo de atraso (20 días) usa el cronograma v1; contra el acta serían menos.

### Lecciones ancladas a un hecho
1. **Hecho:** entre 2026-04-12 y 2026-10-02 no hay un solo documento en la carpeta (173 días), y en ese lapso vencieron las fechas de línea base de dos hitos (2026-06-30 y 2026-09-08). **Efecto:** el atraso o cumplimiento de esos hitos no se puede reconstruir desde los documentos; solo los recibos de octubre.
2. **Hecho:** CC-01 (2026-10-06) dice «Autorizada por el comité» y el cronograma v2 (2026-10-13) mueve el cierre sin motivo escrito. **Efecto:** la replanificación no tiene un aprobador con nombre ni un acta; quien la audite depende de la memoria de los asistentes.
3. **Hecho:** el acta (cierre 2027-05-11) y el cronograma v1 (2027-04-06) difieren, ambos del 2026-04-12. **Efecto:** «línea base original» tiene dos lecturas y el atraso de 20 días depende de cuál se elija.

No se atribuye intención a nadie: lo que muestran los documentos es silencio y trazabilidad incompleta, y la conversación sobre por qué la tiene que tener una persona con estos datos.

### Qué no sé
- Qué pasó entre abril y octubre; no hay documentos.
- Por qué se movió el cierre ni quién lo aprobó.
- Si el presupuesto aprobado incluye los 40.000.000 COP de CC-01: el informe del 2026-10-13 sigue mostrando 6.800.000.000 COP aprobado, y la proyección de 7.022.864.553 COP lo supera en 3.3 %.
- A qué se refiere «el punto 9».

### Pie de rigor
Todo dato sale de los 8 documentos citados arriba; las cifras derivadas, de `portafolio.py compute` del 2026-10-15; los días entre fechas, de cálculo directo sobre las fechas de los documentos. Es un borrador de trabajo: la verificación contra las fuentes es de quien lo use.

Siguiente paso posible: llevar esta historia al comité del 2026-10-22 si hay que decidir sobre la replanificación, o al cierre del proyecto.
