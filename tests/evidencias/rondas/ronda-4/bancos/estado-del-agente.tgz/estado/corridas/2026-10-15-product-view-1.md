# Corrida del 2026-10-15 · product-view

13 proyectos · 20 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Producto de un solo proyecto (PRY-209), sin sección de producto. Verde declarado contradicho: avance 24,0 % vs 75-100 % del plan y 2 hitos cumplidos sin evidencia. 4 proyectos sin producto. No supe el área dueña de esos 4 ni dependencias de PRY-209.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Productos al 2026-10-15

Sale del cálculo del estado (`portafolio.py compute`), 13 proyectos, a 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

**Nómina empresarial tiene un solo proyecto: PRY-209 Nómina electrónica.** La vista por producto no aporta nada sobre un producto de un solo proyecto, así que no armo sección de producto; lo que sigue es la lectura de ese proyecto.

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209) | 4 señales | 2026-12-05 (PRY-209) | COP 9.500.000.000 | COP 6.750.954.901 |

**Lo que hay que ver en PRY-209**
- Declara verde (informe del 2026-09-28, 17 días) con 24,0 % de avance; el plan de 3 de 4 hitos cumplidos sostiene entre 75 % y 100 %: brecha de 51,0 puntos. Verde contradicho por las señales.
- Dos hitos declarados cumplidos sin evidencia: «Diseño funcional aprobado» (vencía 2026-03-22, 207 días) y «Ambiente de pruebas certificado» (vencía 2026-06-16, 121 días).
- Dinero (las cuatro cifras vienen): ejecutado COP 3.509.937.301 (36,9 %), comprometido 71,1 %, proyección COP 9.666.666.238, 1,8 % sobre lo aprobado; disponible real COP 2.749.045.099.
- Línea base: existe; 0 replanificaciones, desviación 0 días contra original y vigente. Sin cambios de control, sin compromisos vencidos, sin proveedores registrados. Última actividad: hace 1 día.
- Faltan en la ficha: autoridad (`identity.authority`) y fase (`identity.phase`).

**Dependencias internas:** ninguna, por tener un solo proyecto. El cálculo tampoco registra dependencias declaradas de PRY-209.

**Fecha comprometida del producto:** 2026-12-05, sale de PRY-209.

### Proyectos sin producto declarado
| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | no calculada |
| PRY-205 Prevención de lavado de activos | no calculada |
| PRY-208 Motor de decisión | no calculada |
| PRY-210 Portal de proveedores | no calculada |

Consecuencia: nadie puede responder por el conjunto al que sirven. El área dueña no sale del cálculo; no la inventé.

---
Pie de rigor: cifras copiadas de la salida de `compute`; las alertas son declaradas contra evidencia de la ficha, no un juicio sobre el gerente. No sé qué se habló fuera de los documentos. La verificación es de quien lea.
