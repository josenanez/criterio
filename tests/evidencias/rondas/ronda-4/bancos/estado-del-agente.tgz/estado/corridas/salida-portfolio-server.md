# Rostrum — para mirarlo un rato

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10

Modo elegido: **para mirarlo un rato** (respuesta tomada del argumento `rato`). Es el que se levanta en diez segundos y se apaga con Ctrl-C; no hay nada que pedirle a seguridad.

Informe encontrado en `reportes/` (index, proyectos, decisiones, productos, un HTML por proyecto y por producto).

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-4/bancos/espacio/reportes --estado /home/claude/banco/ronda-4/bancos/espacio/estado --config /home/claude/banco/ronda-4/bancos/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Si el puerto está ocupado, `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que Rostrum no hace: no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda nada.

Cierre: en este modo el enlace `http://127.0.0.1:8787` solo sirve en este equipo y mientras el proceso corra; no se lo pases a un patrocinador. Para darle un enlace estable hay que pasar a «que quede corriendo» (`--abierto`, detrás del control de acceso de la organización). El informe es del 2026-10-15; la portada muestra su fecha, y queda desactualizado en cuanto cambie un documento o corra otro barrido.
