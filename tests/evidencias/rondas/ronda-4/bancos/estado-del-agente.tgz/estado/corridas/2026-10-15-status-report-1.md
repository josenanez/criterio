# Corrida del 2026-10-15 · status-report

13 proyectos · 29 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Informe de estado de PRY-208 desde su ficha. Amarillo 74% declarado el 2026-09-25; cuatro señales que el semáforo no explica (hito de diseño sin acta, piloto vencido, tres entregables de proveedor vencidos, factura sin entrega). Dijo que no sabe: producto, autoridad, fase, evidencia del diseño funcional, dueños de los RAID y línea base de costo previa.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Informe sacado de la ficha `estado/records/PRY-208.json` (actualizada el 2026-10-15), con las cifras recalculadas por `compute` al 2026-10-15.

## PRY-208 · Motor de decisión — estado al 2026-10-15

**Declara el gerente (Sandra Gil):** amarillo · 74% · al 2026-09-25 (hace 20 días; la declaración no está vencida, el umbral es 30). Fuente: `20-seguimiento/2026-09-25-informe-avance.pdf`.
**Sustento documental:** parcial. El 74% cae dentro de lo que el plan sustenta (60–80%, 3 de 5 hitos cerrados), pero el amarillo no explica cuatro señales abiertas. Ninguna fuente de la ficha está marcada como evidencia (0 evidencia, 4 declaración, 34 sin marcar).
**Lo que el semáforo no explica:**
- `milestone_met_without_evidence`: «Diseño funcional aprobado» figura cumplido (base 2026-04-28) y no tiene acta de recibo; van 170 días.
- `milestone_overdue`: «Piloto con usuarios internos» vencía el 2026-10-11 y sigue pendiente; van 4 días.
- `vendor_deliverable_late`: tres entregables de Datacore Colombia (CT-932) vencidos y sin recibo.
- `vendor_invoiced_without_delivery`: Datacore facturó 105.076.622 COP (FV-1932, 2026-09-27) sin ningún entregable aceptado.

**Último documento:** 2026-10-12 (hace 3 días) · **Última reunión:** 2026-10-06 (comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-12-05 | 2026-12-05 | 0 días |
| Presupuesto aprobado | 1.200.000.000 COP | 1.200.000.000 COP | sin cambio |

Presupuesto: comprometido 1.042.279.479 (86,9%), ejecutado 673.930.886 (56,2%), proyección 1.162.609.510 (−3,1% frente al aprobado), disponible real 157.720.521. La proyección es declarada por el gerente (informe del 2026-09-25), no calculada de los documentos.

Replanificaciones: 0. Solicitudes de cambio: 0.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-04-28 | 2026-04-28 | cumplido (declarado) | **ninguna** |
| Ambiente de pruebas certificado | 2026-06-22 | 2026-06-22 | cumplido | acta de recibo 2026-10-02 |
| Integración con el core | 2026-08-16 | 2026-08-16 | cumplido | acta de recibo 2026-10-12 |
| Piloto con usuarios internos | 2026-10-11 | 2026-10-11 | pendiente, vencido 4 días | — |
| Salida a producción | 2026-12-05 | 2026-12-05 | pendiente | — |

### Dónde no coincide
- **Contrato CT-932:** ningún entregable figura recibido y no hay actas de recibo de ellos (las dos actas de la carpeta son de hitos del proyecto, no de entregables). Aun así, la factura FV-1932 por 105.076.622 está radicada en cuentas por pagar (`20-seguimiento/2026-09-27-factura-ct-932.pdf`). Contrato: `00-gobierno/2026-02-22-contrato-ct-932.docx`.
- **Hito de diseño:** el cronograma v1 (2026-02-22) lo marca «met», sin acta que lo sustente.
- **Piloto:** el cronograma lo tiene pendiente con fecha ya pasada; el informe del 2026-09-25 no lo menciona como en riesgo.
- **Dependencia del core:** el informe la cita como riesgo; el acta de constitución no la declara.

### Abierto
**Riesgos e incidencias sin movimiento:** tres registrados en el informe del 2026-09-25 (dependencia del calendario de liberaciones del core; disponibilidad del equipo de seguridad para la revisión final; dos historias fuera del alcance del sprint por dependencia con el core). Ninguno tiene dueño, fecha ni última fecha de movimiento, así que no se pueden contar los días sin movimiento.
**Compromisos vencidos:** ninguno. Hay uno abierto: María Restrepo, «Entregar el punto 17», para el 2026-11-09 (dicho el 2026-10-06).
**Dependencias sin confirmar:** ninguna registrada como dependencia; la del core aparece solo como riesgo.

Entregables de CT-932 aún por vencer: «Mesa de ayuda del primer trimestre» (2026-11-02), pendiente.

### Sin dato
- Producto: el acta dice «No aplica»; queda vacío.
- Autoridad de aprobación y fase: no figuran en ningún documento.
- Probabilidad, impacto y dueño de los riesgos; dueño y fecha de inicio de la incidencia.
- Acta de recibo del hito «Diseño funcional aprobado».
- Presupuesto: solo hay una cifra aprobada; no hay línea base de costo anterior con la que comparar.

**Siguiente paso posible:** si quiere, preparo el punto de comité (próximo: 2026-10-22) con la factura sin entregable y el piloto vencido.

---
Criterio Portfolio v0.3.10 · ficha PRY-208 aplicada, con fecha 2026-10-15 · campos inciertos: producto, autoridad, fase y evidencia del diseño funcional (arriba) · Términos aceptados por José Francisco Ñáñez el 2026-10-15 (v1.1) · Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal
