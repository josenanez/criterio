# Corrida del 2026-10-15 · change-control

13 proyectos · 53 s · 60 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 20 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 7 |
| `vendor_deliverable_late` | 4 |
| `declared_vs_evidence` | 4 |
| `commitment_rescheduled` | 4 |
| `variance_time` | 3 |
| `milestone_overdue` | 2 |
| `change_without_baseline` | 2 |
| `commitment_undated` | 2 |
| `vendor_accepted_without_evidence` | 1 |
| `vendor_invoiced_without_delivery` | 1 |
| `rebaseline_unauthorized` | 1 |
| `pm_vs_pmo` | 1 |

Solicitud +30 días a la salida a producción de PRY-201. Impacto en portafolio 0 por dependencias declaradas (no hay ninguna). No se sabe: holgura por hito, costo, alcance, motivo, solicitante, autoridad (no declarada). Conflicto sin resolver: acta cierre 2027-05-11 vs cronograma v1 2027-04-06.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

> Sale de la ficha `estado/records/PRY-201.json` (actualizada 2026-10-15) y de los documentos de `PRY-201-core-de-depósitos`. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no se registró de nuevo).

## Solicitud de cambio — PRY-201 Core de depósitos — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días (de 2027-04-26 a 2027-05-26, contando desde la fecha vigente) · **Quién lo pide:** no consta en lo recibido · **Por qué:** no consta; no hay motivo escrito.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3, más la ampliación de CC-01 (sin detallar en el documento) | Sin declarar | Sin impacto declarado |
| Tiempo | Salida a producción 2027-04-26 (línea base 2 vigente; original 2027-04-06) | 2027-05-26 | +30 días. Contra la línea base original: +50 días (20 ya movidos + 30), 14,3 % de la duración original (349 días), sobre el umbral de 10 % |
| Costo | Aprobado 6.800.000.000 COP; proyección 7.022.864.553 (+3,3 %); CC-01 pide 40.000.000 más | Sin declarar | Sin impacto declarado |

**Quién absorbe lo no declarado:** la solicitud no dice nada de alcance ni de costo. Un mes más de equipo sobre un proyecto que ya proyecta 222.864.553 COP por encima de lo aprobado no sale gratis; si nadie lo presupuesta, se absorbe en horas no pagadas o en calidad. Tampoco se sabe si el costo extra se paga con los 40.000.000 de CC-01 (que no figuran en el aprobado de la ficha). Hay que pedirle el número a quien solicita.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno por dependencias | El cálculo (`impact`, 30 días) devuelve 0 alcanzados, 0 que no puedan sostener su fecha y 0 dependencias sin confirmar. | Carlos Peña (gerente de PRY-201) |

Lo anterior solo vale para lo declarado: el acta dice «Ninguna declarada» y ninguna otra ficha apunta a PRY-201. Que no haya dependencias escritas no prueba que no existan. Sí atraviesa tres hitos propios: Integración con el core (2026-11-17), Piloto con usuarios internos (2027-01-26) y Salida a producción. **Cuántos días se mueve cada hito intermedio no se puede decir:** eso necesita holgura por actividad y la ficha no la tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. La autoridad del proyecto no está declarada en ningún documento (`identity.authority`: no encontrada). Ese es el hallazgo de fondo. · **Según:** acta de constitución 2026-04-12, que nombra al Comité de Arquitectura como comité y no fija umbrales · **Va a comité:** sí, por defecto, mientras no haya autoridad escrita que diga lo contrario.

Antecedente: CC-01 (2026-10-06, +20 días y 40.000.000 COP) dice solo «Autorizada por el comité». No hay acta de comité que lo respalde, y la reunión del 2026-10-02 no trata el cambio. La reconciliación de días cuadra (línea base movida 20, autorizados 20, sin autorizar 0), pero la autorización misma no tiene documento.

### Si no se aprueba
El proyecto sigue con salida a producción el 2027-04-26 (línea base 2, +20 días sobre la original). Estado declarado amarillo, 48 % de avance (el plan sostiene entre 40 y 60 %). Riesgos abiertos: el proveedor no ha confirmado la fecha de la última entrega y el conocimiento está concentrado en una persona; ya se perdieron dos semanas por rotación. No hay contrato de proveedor en la carpeta. El propio informe sugiere presión sobre la fecha vigente, pero eso no está medido.

### Si se aprueba
Línea base 3 — salida a producción 2027-05-26 · presupuesto: sin monto declarado (hoy 6.800.000.000 COP aprobados) · motivo: no consta, hay que escribirlo.
Desviación acumulada contra la línea base original: **+50 días (14,3 %)** · costo: +222.864.553 COP de proyección sobre lo aprobado (3,3 %), sin sumar este cambio ni los 40.000.000 de CC-01.
La línea base 2 y la 1 no se tocan; el conteo de replanificaciones pasa de 1 a 2.

### Lo que no sé
- Cuántos días se mueven el piloto y la integración.
- El costo, el alcance y el motivo del cambio.
- Cuál es la fecha de cierre correcta de origen: el acta dice cierre **2027-05-11** y el cronograma v1 (línea base 1) dice **2027-04-06**. La ficha toma el cronograma. La fecha nueva, 2027-05-26, pasa de ambas.
- Quién pide el cambio.

## Después
Si la autoridad no está declarada, no hay a quién pedirle la aprobación. Primero se necesita escribirla. Puedo llevar el paquete al comité del 2026-10-22 o registrar la línea base 3 si me indica el documento que la apruebe y quién la aprobó.
