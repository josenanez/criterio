## Presupuesto — portafolio (13 proyectos) al 2026-10-15
**Moneda:** COP (los 13 proyectos; no hay otra moneda, no se convirtió nada)

**De dónde sale:** las fichas de `estado/records/` (PRY-199 a PRY-211) y el recálculo de `portafolio.py compute` del 2026-10-15. Las cuatro cifras de cada proyecto salen de **un solo documento**: su informe de avance, y ese informe es una declaración del gerente, no un soporte contable. No hay en la carpeta un presupuesto aprobado, un registro de compromisos ni un extracto de ejecución que las respalde (`sources.evidence = 0` en todos los proyectos). Los totales del portafolio no los calcula el script, así que no los escribo.

### Las cuatro cifras por proyecto (COP)

| Proyecto | Aprobado | Comprometido (% aprob.) | Ejecutado (% aprob.) | Proyección (sobre aprobado) | Disponible real | Fuente y fecha |
|---|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | 2.400.000.000 | 1.080.000.000 (45,0%) | 720.000.000 (30,0%) | 2.400.000.000 (0,0%) | 1.320.000.000 | informe de avance, 2026-10-13 |
| PRY-200 Originación digital | 3.300.000.000 | 2.426.973.144 (73,5%) | 1.752.697.435 (53,1%) | 3.273.985.487 (-0,8%) | 873.026.856 | informe de avance, 2026-10-04 |
| PRY-201 Core de depósitos | 6.800.000.000 | 4.172.515.462 (61,4%) | 2.566.684.043 (37,7%) | 7.022.864.553 (+3,3%) | 2.627.484.538 | informe de avance, 2026-10-13 |
| PRY-202 Migración a la nube | 6.800.000.000 | 3.770.463.432 (55,4%) | 2.449.444.833 (36,0%) | 6.421.718.591 (-5,6%) | 3.029.536.568 | informe de avance, 2026-10-11 |
| PRY-203 Open Banking | 1.200.000.000 | 626.908.903 (52,2%) | 520.498.073 (43,4%) | 1.250.542.318 (+4,2%) | 573.091.097 | informe de avance, 2026-10-11 |
| PRY-204 Débito contactless | 6.800.000.000 | 3.940.228.462 (57,9%) | 2.069.194.046 (30,4%) | 6.330.588.007 (-6,9%) | 2.859.771.538 | informe de avance, 2026-09-24 |
| PRY-205 Prevención de lavado | 4.200.000.000 | 2.196.050.514 (52,3%) | 1.022.306.302 (24,3%) | 3.988.589.390 (-5,0%) | 2.003.949.486 | informe de avance, 2026-10-03 |
| PRY-206 Billetera y QR | 3.300.000.000 | 1.410.902.312 (42,8%) | 1.032.384.656 (31,3%) | 3.341.040.792 (+1,2%) | 1.889.097.688 | informe de avance, 2026-10-12 |
| PRY-207 Onboarding PyME | 6.800.000.000 | 6.064.762.816 (89,2%) | 2.194.353.672 (32,3%) | 6.886.375.731 (+1,3%) | 735.237.184 | informe de avance, 2026-10-15 |
| PRY-208 Motor de decisión | 1.200.000.000 | 1.042.279.479 (86,9%) | 673.930.886 (56,2%) | 1.162.609.510 (-3,1%) | 157.720.521 | informe de avance, 2026-09-25 |
| PRY-209 Nómina electrónica | 9.500.000.000 | 6.750.954.901 (71,1%) | 3.509.937.301 (36,9%) | 9.666.666.238 (+1,8%) | 2.749.045.099 | informe de avance, 2026-09-28 |
| PRY-210 Portal de proveedores | 2.400.000.000 | 865.619.680 (36,1%) | 1.427.858.191 (59,5%) | 2.406.453.124 (+0,3%) | 1.534.380.320 | informe de avance, 2026-10-13 |
| PRY-211 Cobranza digital | 4.200.000.000 | 1.394.605.504 (33,2%) | 1.645.776.121 (39,2%) | 3.915.287.113 (-6,8%) | 2.805.394.496 | informe de avance, 2026-09-25 |

**Disponible real** = aprobado menos comprometido, por proyecto, en la última columna de monto. Es la cifra que manda, no la del ejecutado.

### Contra la línea base
El presupuesto **no tiene línea base propia** en ninguna ficha: solo se versionan los cronogramas. Hay un único «aprobado» por proyecto, sin original ni vigente, así que la desviación del presupuesto contra la línea base original y la vigente es `not_found`: no la calculo.

Lo que sí hay son solicitudes de cambio con impacto en costo declarado, y **ninguna movió el aprobado** de la ficha:

| Proyecto | Cambio | Costo adicional declarado | Estado | Observación |
|---|---|---|---|---|
| PRY-201 | CC-01 (2026-10-06) | 40.000.000 | aprobado | «Autorizada por el comité», sin acta de comité |
| PRY-202 | CC-01 (2026-10-06) | 240.000.000 | aprobado | ídem |
| PRY-204 | CC-01 (2026-10-06) | 166.000.000 | aprobado | ídem |
| PRY-205 | CC-01 (2026-10-08) | 156.000.000 | aprobado | ídem |
| PRY-207 | CC-01 (2026-10-02) | 64.000.000 | aprobado | ídem, y sin nueva línea base |
| PRY-210 | CC-01 (2026-10-04) | 82.000.000 | pendiente | «Pendiente de presentación al comité» |

Replanificaciones de presupuesto: 0 registradas. Cambios con costo aprobado: 5. Cambios con costo pendiente: 1.

### Ejecución frente a avance
Lectura de lo que el script entrega, sin cifras nuevas:
- **PRY-207:** comprometido 89,2% (a 0,8 puntos del umbral de 90%) con ejecutado 32,3% y avance declarado 40%. Es el caso del error clásico: parece que sobra presupuesto por lo ejecutado, pero solo queda disponible real de 735.237.184 de 6.800.000.000.
- **PRY-208:** comprometido 86,9%, disponible real de 157.720.521 sobre 1.200.000.000, con avance declarado 74% y 3 de 5 hitos.
- **PRY-200:** ejecutado 53,1% con avance declarado 34% y 1 de 3 hitos; el hito cumplido, «Diseño funcional aprobado», no tiene evidencia. Es la señal de gasto por delante del avance.
- **PRY-206:** ejecutado 31,3% con avance declarado 89% y 3 de 3 hitos. Ejecución muy por debajo del avance: trabajo hecho y no facturado, o avance sobrestimado. Hay que preguntar cuál.
- **PRY-203:** ejecutado 43,4% con avance declarado 88%; no tiene línea base ni hitos, no puedo cruzarlo con el plan.
- **PRY-204:** ejecutado 30,4% con avance declarado 27%, pero el script marca 53,0 puntos de atraso frente al plan (4 de 5 hitos, tres sin evidencia). El presupuesto se ve tranquilo porque el avance real no es el de los hitos.
- **PRY-205 y PRY-202:** ejecutado 24,3% y 36,0% frente a avance declarado de 43% y 50%; ejecución por debajo del avance.

### Alertas
1. **Ejecutado por encima de lo comprometido, en PRY-210 (59,5% contra 36,1%) y PRY-211 (39,2% contra 33,2%).** No es posible si el comprometido está completo: o falta registrar compromisos, o el informe mezcla bases. Esas dos cifras de «disponible real» (1.534.380.320 y 2.805.394.496) no son confiables hasta aclararlo.
2. **Proyección por encima del aprobado en 6 proyectos:** PRY-201 (+3,3%), PRY-203 (+4,2%), PRY-206 (+1,2%), PRY-207 (+1,3%), PRY-209 (+1,8%), PRY-210 (+0,3%). Ninguna llega al umbral de 10%, pero todas dicen que se va a gastar más de lo aprobado y ninguna trae solicitud de cambio de presupuesto que lo cubra (salvo las CC de 201, 207 y 210, cuyo costo adicional no está en el aprobado).
3. **Comprometido cerca del tope:** PRY-207 (89,2%) y PRY-208 (86,9%). Ninguno cruza el umbral de 90%.
4. **Proyección más vieja que el último movimiento de presupuesto:** PRY-204 (informe del 2026-09-24, CC-01 con +166.000.000 del 2026-10-06) y PRY-205 (informe del 2026-10-03, CC-01 con +156.000.000 del 2026-10-08). Su proyección no incluye el cambio, o no se sabe si lo incluye.
5. **Cinco cambios con costo aprobados sin acta de comité** (PRY-201, 202, 204, 205, 207), por un total declarado que el script no suma y por tanto no escribo.
6. **Todas las proyecciones son declaraciones del gerente**, con fuente y fecha, y ninguna tiene soporte contable en la carpeta.

### Sin dato
- Presupuesto original y vigente separados (no hay línea base de costo) en los 13 proyectos.
- Soporte de comprometido y ejecutado distinto del informe de avance, en los 13.
- Totales del portafolio: el script no los entrega.
- Tasa de cambio: no aplica, todo está en COP.
- Autoridad que aprobó el presupuesto: `identity.authority` falta en los 13.

### Después
- La proyección excede el aprobado en 6 proyectos. Puedo preparar la solicitud de cambio de presupuesto de PRY-201, PRY-203, PRY-206, PRY-207, PRY-209 y PRY-210, empezando por PRY-203 que es la desviación mayor.
- El comprometido está cerca del tope en PRY-207 y PRY-208. Puedo abrir el detalle por proveedor si me lo pides (no revisé aún qué proveedores tienen registrados esos dos proyectos).

---
*Pie de rigor:* borrador de trabajo, no decisión ni asesoría. Todas las cifras vienen de declaraciones en informes de avance (ninguna de evidencia contable) y de `portafolio.py compute` del 2026-10-15; la verificación contra el documento citado es de quien lo use. Lo que no estaba en ningún documento figura como `not_found`.
