# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-03
**Gerente:** Liliana Torres

## Estado declarado

**Verde**

Avance reportado: **38%**

## Lo que pasó en el periodo

- Se recibió el concepto pendiente del ente supervisor
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 386.935.777 |
| Ejecutado | 334.067.490 |
| Proyección al cierre | 762.685.964 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
