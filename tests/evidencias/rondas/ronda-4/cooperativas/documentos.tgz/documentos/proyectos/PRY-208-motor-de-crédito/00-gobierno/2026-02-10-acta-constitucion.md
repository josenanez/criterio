# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Canales digitales
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-10

## Objetivo del negocio

Entregar motor de crédito para Canales digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-10.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-20 |
| Cierre | 2026-12-29 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
