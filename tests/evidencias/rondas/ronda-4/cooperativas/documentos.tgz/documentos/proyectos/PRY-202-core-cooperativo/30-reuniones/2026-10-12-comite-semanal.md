# Consejo de Administración · Core cooperativo

**Fecha:** 2026-10-12
**Asistentes:** Ricardo Salas, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 4 | 2026-10-23 |
