# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-03
**Gerente:** Elena Duarte

## Estado declarado

**Rojo**

Avance reportado: **70%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 2.044.466.248 |
| Ejecutado | 2.463.577.669 |
| Proyección al cierre | 4.389.905.182 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Concentración del conocimiento en una sola persona
