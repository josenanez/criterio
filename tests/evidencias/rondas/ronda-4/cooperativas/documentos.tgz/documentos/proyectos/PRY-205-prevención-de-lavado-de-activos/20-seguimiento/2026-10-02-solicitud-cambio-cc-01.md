# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Prevención de lavado de activos
**Fecha:** 2026-10-02
**Solicitante:** Rubén Cárdenas

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +63 días sobre la línea base vigente |
| Costo | 126.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
