# Comité de Tecnología · Corresponsales rurales

**Fecha:** 2026-10-02
**Asistentes:** Liliana Torres, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 1 | 2026-10-30 |
