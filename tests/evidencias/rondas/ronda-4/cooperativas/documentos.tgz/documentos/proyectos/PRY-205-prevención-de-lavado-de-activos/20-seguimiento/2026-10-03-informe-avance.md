# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-03
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **47%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 4.143.034.840 |
| Ejecutado | 3.056.546.748 |
| Proyección al cierre | 8.762.266.701 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
- Concentración del conocimiento en una sola persona
