# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-09-23
**Gerente:** Elena Duarte

## Estado declarado

**Verde**

Avance reportado: **64%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.708.940.032 |
| Ejecutado | 534.840.876 |
| Proyección al cierre | 2.216.045.578 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
