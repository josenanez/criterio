# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-09-17
**Asistentes:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-28 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-14 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-25 |
| Mauricio Pérez | Aprobar el diseño 5 | por definir |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-20 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-08 |
| Elena Duarte | Entregar el punto 8 | 2026-10-14 |
| Carlos Peña | Enviar el documento 9 | 2026-09-24 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-10 |
| Liliana Torres | Revisar el anexo 11 | por definir |
| Felipe Arango | Validar el ambiente 12 | 2026-09-29 |

## Cerrados en esta reunión

- Revisar el anexo 3 (Diana Molina): recibido, acta de recibo del 2026-09-17.
