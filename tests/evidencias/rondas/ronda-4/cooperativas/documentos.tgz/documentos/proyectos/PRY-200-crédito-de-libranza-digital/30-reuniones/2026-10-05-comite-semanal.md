# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-05
**Asistentes:** Gustavo Neira, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 31 | por definir |
