# Informe de avance · Microcrédito rural

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Laura Vélez

## Estado declarado

**Amarillo**

Avance reportado: **74%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se ajustó el plan de pruebas con el área de seguridad
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.303.328.999 |
| Ejecutado | 2.205.358.674 |
| Proyección al cierre | 4.231.019.061 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
