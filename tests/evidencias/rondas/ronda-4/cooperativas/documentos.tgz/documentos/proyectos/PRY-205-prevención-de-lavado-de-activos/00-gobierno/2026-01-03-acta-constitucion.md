# Acta de constitución · Prevención de lavado de activos

**Código:** PRY-205
**Área dueña:** Canales digitales
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Riesgos
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-01-03

## Objetivo del negocio

Entregar prevención de lavado de activos para Canales digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Riesgos el 2026-01-03.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-01-13 |
| Cierre | 2027-04-14 |

## Criterio de éxito

Prevención de lavado de activos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
