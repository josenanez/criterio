# Informe de avance · Motor de crédito

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Mauricio Pérez

## Estado declarado

**Amarillo**

Avance reportado: **25%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 800.000.000 |
| Comprometido | 379.727.650 |
| Ejecutado | 276.500.259 |
| Proyección al cierre | 829.965.215 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
