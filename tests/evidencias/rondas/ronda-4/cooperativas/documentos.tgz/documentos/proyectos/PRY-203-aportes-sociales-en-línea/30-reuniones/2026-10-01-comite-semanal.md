# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-10-01
**Asistentes:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-20 |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-07 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-20 |
| Elena Duarte | Entregar el punto 8 | 2026-10-14 |
| Carlos Peña | Enviar el documento 9 | 2026-10-09 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-24 |
| Liliana Torres | Revisar el anexo 11 | 2026-10-21 |
| Felipe Arango | Validar el ambiente 12 | 2026-10-08 |
| Mauricio Pérez | Aprobar el diseño 13 | 2026-10-31 |
| María Restrepo | Actualizar la matriz 14 | 2026-09-27 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-08 |
| Andrés Lozano | Enviar el documento 17 | 2026-10-24 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-21 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-05 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Andrés Lozano): recibido, acta de recibo del 2026-10-01.
- Confirmar la fecha 7 (Javier Hoyos): recibido, acta de recibo del 2026-10-01.
