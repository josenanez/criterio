# Comité de Crédito · Microcrédito rural

**Fecha:** 2026-10-15
**Asistentes:** Laura Vélez, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 4 | 2026-10-14 |
