# Definición de producto · Ahorro a la vista

**Código:** PRD-301
**Gerente de producto:** Beatriz Cuéllar
**Segmento:** Asociados rurales
**Fecha de la definición:** 2026-01-30

## El problema

El segmento Asociados rurales no tiene ahorro a la vista.

## La propuesta

- Propuesta principal

## Supuestos

- **La demanda se sostiene sin campaña** · declarado el 2026-05-19 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
