# Tablero de métricas · Pagos QR

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 276.593 | 2026-10-02 |
