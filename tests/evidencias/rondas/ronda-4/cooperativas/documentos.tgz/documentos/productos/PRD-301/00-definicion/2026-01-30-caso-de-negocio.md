# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-01-30
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 160.456 | Caso de negocio, 2026-01-30 |

## Retorno esperado

Retorno esperado en 24 meses.
