# Tablero de métricas · Recaudos

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 142.860 | 2026-10-15 |
