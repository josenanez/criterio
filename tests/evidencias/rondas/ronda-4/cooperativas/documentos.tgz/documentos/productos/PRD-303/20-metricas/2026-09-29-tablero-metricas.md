# Tablero de métricas · Tarjeta débito

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-09-29

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 202.628 | 2026-09-29 |
