# Tablero de métricas · Auxilios de solidaridad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-11

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 169.641 | 2026-10-11 |
