# Definición de producto · Tarjeta débito

**Código:** PRD-303
**Gerente de producto:** Natalia Ospina
**Segmento:** Microempresarios
**Fecha de la definición:** 2025-12-27

## El problema

El segmento Microempresarios no tiene tarjeta débito.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-09-02 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
