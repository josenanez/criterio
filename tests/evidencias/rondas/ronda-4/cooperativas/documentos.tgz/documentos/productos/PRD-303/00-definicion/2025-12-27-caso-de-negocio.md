# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2025-12-27
**Preparado por:** Natalia Ospina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 248.461 | Caso de negocio, 2025-12-27 |

## Retorno esperado

Retorno esperado en 24 meses.
