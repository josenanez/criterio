# Comité de producto · Tarjeta débito

**Fecha:** 2026-10-12
**Asistentes:** Natalia Ospina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-26 | — |
| REQ-4301 | Requerimiento REQ-4301 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-05-17 | — |
| REQ-4302 | Requerimiento REQ-4302 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4303 | Requerimiento REQ-4303 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-16 | — |
| REQ-4304 | Requerimiento REQ-4304 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-05 | — |
| REQ-4305 | Requerimiento REQ-4305 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4306 | Requerimiento REQ-4306 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-19 | — |
| REQ-4307 | Requerimiento REQ-4307 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-12 | — |
| REQ-4308 | Requerimiento REQ-4308 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-20 | — |
| REQ-4309 | Requerimiento REQ-4309 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-15 | — |
| REQ-4310 | Requerimiento REQ-4310 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-14 | — |
| REQ-4311 | Requerimiento REQ-4311 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-11 | — |
| REQ-4312 | Requerimiento REQ-4312 | Sandra Gil | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-23 | — |
| REQ-4313 | Requerimiento REQ-4313 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-10 | — |
| REQ-4314 | Requerimiento REQ-4314 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4315 | Requerimiento REQ-4315 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-09 | — |
| REQ-2030 | Requerimiento REQ-2030 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-10-02 | — |
| REQ-2038 | Requerimiento REQ-2038 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-30 | — |

## Decisiones

- Se mantiene el plan
