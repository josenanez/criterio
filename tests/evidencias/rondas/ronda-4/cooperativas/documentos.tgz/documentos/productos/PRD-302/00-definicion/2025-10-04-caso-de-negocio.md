# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2025-10-04
**Preparado por:** Javier Hoyos

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 161.739 | Caso de negocio, 2025-10-04 |

## Retorno esperado

Retorno esperado en 24 meses.
