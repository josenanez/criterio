# Entrevistas · Tarjeta débito

**Ronda:** Ronda · 2025-09-19
**Realizadas por:** Natalia Ospina

### Cliente entrevistado · 2025-09-19

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
