# Caso de negocio · Microseguros

**Código:** PRD-309
**Fecha:** 2025-09-27
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 280.222 | Caso de negocio, 2025-09-27 |

## Retorno esperado

Retorno esperado en 24 meses.
