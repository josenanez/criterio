# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2026-03-03
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 155.425 | Caso de negocio, 2026-03-03 |

## Retorno esperado

Retorno esperado en 24 meses.
