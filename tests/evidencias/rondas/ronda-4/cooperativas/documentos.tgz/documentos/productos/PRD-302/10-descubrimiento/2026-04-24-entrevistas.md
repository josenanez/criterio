# Entrevistas · Aportes sociales

**Ronda:** Ronda · 2026-04-24
**Realizadas por:** Javier Hoyos

### Cliente entrevistado · 2026-04-24

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
