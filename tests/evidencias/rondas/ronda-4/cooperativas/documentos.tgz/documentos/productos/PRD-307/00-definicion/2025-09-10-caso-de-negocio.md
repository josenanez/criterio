# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2025-09-10
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 250.125 | Caso de negocio, 2025-09-10 |

## Retorno esperado

Retorno esperado en 24 meses.
