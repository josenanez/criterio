# Comité de producto · Crédito de libranza

**Fecha:** 2026-10-12
**Asistentes:** María Restrepo

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-21 | — |
| REQ-4001 | Requerimiento REQ-4001 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-03-26 | — |
| REQ-4002 | Requerimiento REQ-4002 | Gustavo Neira | se verifica en producción | — | propuesto | 2026-06-27 | — |
| REQ-4003 | Requerimiento REQ-4003 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-04-16 | — |
| REQ-4004 | Requerimiento REQ-4004 | Felipe Arango | — | Cliente entrevistado | aceptado | 2026-03-15 | — |
| REQ-4005 | Requerimiento REQ-4005 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-16 | — |
| REQ-4006 | Requerimiento REQ-4006 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-17 | — |
| REQ-4007 | Requerimiento REQ-4007 | Rubén Cárdenas | — | — | aceptado | 2026-04-26 | — |
| REQ-4008 | Requerimiento REQ-4008 | Mauricio Pérez | — | — | aceptado | 2026-08-09 | — |
| REQ-4009 | Requerimiento REQ-4009 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-28 | — |
| REQ-4010 | Requerimiento REQ-4010 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-27 | — |
| REQ-4011 | Requerimiento REQ-4011 | Jorge Medina | se verifica en producción | — | aceptado | 2026-05-26 | — |
| REQ-4012 | Requerimiento REQ-4012 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-10 | — |
| REQ-4013 | Requerimiento REQ-4013 | Javier Hoyos | — | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4014 | Requerimiento REQ-4014 | Diana Molina | — | Cliente entrevistado | propuesto | 2026-06-10 | — |
| REQ-4015 | Requerimiento REQ-4015 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-01 | — |

## Decisiones

- Se mantiene el plan
