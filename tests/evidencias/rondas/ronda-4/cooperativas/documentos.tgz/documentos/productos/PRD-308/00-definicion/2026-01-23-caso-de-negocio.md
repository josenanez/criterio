# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-01-23
**Preparado por:** Andrés Lozano

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 223.275 | Caso de negocio, 2026-01-23 |

## Retorno esperado

Retorno esperado en 24 meses.
