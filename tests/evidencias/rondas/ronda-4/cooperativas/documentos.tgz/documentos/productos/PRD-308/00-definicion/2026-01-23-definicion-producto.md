# Definición de producto · Remesas familiares

**Código:** PRD-308
**Gerente de producto:** Andrés Lozano
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-01-23

## El problema

El segmento Asociados urbanos no tiene remesas familiares.

## La propuesta

- Propuesta principal

## Supuestos

- **El proveedor cumple el tiempo pactado** · declarado el 2026-04-19 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
