## Listo — Tarjeta débito (PRD-303)

**Lo que miré:** 6 documentos (todos .md, todos legibles) · 1 de descubrimiento (una ronda de entrevistas, 2025-09-19, una sola cita) · la definición y el caso de negocio del 2025-12-27 · lo más reciente: el acta del comité del 2026-10-12.
**Términos:** aceptados para la versión 0.3.10 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 fdf0177cc54e5055… (md) y dcaa4cbfec5be44312… (pdf)
**Quién decide:** Comité de producto (tomado del acta; ningún documento lo dice, confírmalo). Gerente: Natalia Ospina. Estado en `estado-producto/PRD-303`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Microempresarios no tiene tarjeta débito | Una entrevista, un cliente: «Lo necesito y hoy no lo tengo.» No dice que sea microempresario ni un segmento | 2025-09-19 |
| Volumen mensual de 248.461 | Solo el caso de negocio. El tablero mide 202.628 al 2026-09-29: 18,4 % por debajo de lo declarado (bajo el umbral de 20 %, es imprecisión de la cifra, no contradicción, pero va en la dirección que el caso no previó) | 2025-12-27 / 2026-09-29 |
| Retorno esperado en 24 meses | Nada: sin monto, tasa ni cálculo | 2025-12-27 |
| El reglamento vigente lo permite | Supuesto declarado, sin verificar, hace 43 días | 2026-09-02 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito de la definición.** No existe.
- **Cuánto es el retorno y de dónde sale.** «Retorno esperado en 24 meses» no es una cifra.
- **Por qué la propuesta es la propuesta.** La definición dice «Propuesta principal» y nada más.
- **Cuál entrevista sostiene cuál requerimiento.** El acta atribuye 16 de 18 requerimientos a «Cliente entrevistado»; hay una cita en toda la carpeta y no dice cuál.
- **Quién decidió qué.** La única decisión escrita es «Se mantiene el plan»; no dice quién ni sobre qué.
- **Qué proyecto ejecuta cada requerimiento.** Ninguno declarado: los 12 aceptados están sin proyecto.
- **El problema en las palabras de quien lo tiene** (campo `need`) en los 18 requerimientos, y los títulos: todos dicen «Requerimiento REQ-xxxx».

### Supuestos sobre los que está escrita
Uno: «El reglamento vigente lo permite», declarado el 2026-09-02, sin verificar. Es el que, si falla, tumba el producto entero.

### Qué le falta a tu carpeta
- Las transcripciones de las entrevistas, con quién habló y de qué requerimiento: hoy toda la evidencia tiene 12 meses (2025-09-19) y 17 de 18 requerimientos salen con evidencia vencida.
- La serie de la métrica principal: hay un solo punto (2026-09-29), no una serie.
- Las decisiones del comité con su motivo: sin ellas no se distingue un requerimiento descartado de uno que nadie miró.

### Lo que levanté del acta del comité (18 requerimientos: 12 aceptados, 6 propuestos)
- **Sin proyecto que los ejecute:** 12 aceptados (todos).
- **Sin criterio de aceptación:** 2 (REQ-2030, REQ-4302).
- **Aceptado sin nadie que lo pidiera:** 1 (REQ-4301).
- **Sin doliente (sin asignar):** 3 (REQ-4305, REQ-4306, REQ-4314), los tres aceptados.
- **Propuestos sin decidir hace más de 60 días:** 6 (REQ-4303, 4309, 4310, 4311, 4312, 4313).
- **Evidencia vencida (12 meses):** 17.
- Dos requerimientos (REQ-2030 y REQ-2038) tienen numeración distinta del resto; no lo interpreto, lo dejo anotado.

### Pendientes de esta sesión
- `sellar` no corrió: pide una corrida abierta (`corrida-inicio`) y este comando indica no usarla. Queda sin sellar la lectura.
- No encontré fichas de proyectos (`estado/records`), así que ninguna traza se pudo confirmar.

Siguiente paso: `/product-discovery` sobre el material de entrevistas.
