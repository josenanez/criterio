# Acta de constitución — Tarjeta débito (REQ-4300) · borrador del 2026-10-15
**Producto:** PRD-303 Tarjeta débito · **Requerimientos:** REQ-4300

> **Esto es un borrador de trabajo, no una decisión ni asesoría.** No está firmado, no da nada por firmado y no se ha creado la ficha del proyecto. La verificación de cada dato es de quien firma.

## Verificación previa: hay con qué, a medias
| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | Cumple en el papel: el acta del comité lo lista «aceptado» desde 2026-05-26. **Pero ninguna decisión escrita lo acepta** (la única es «Se mantiene el plan») y no consta quién decidió. | `30-decisiones/2026-10-12-comite-producto.md` |
| Criterios de aceptación verificables | **No cumple.** Dice «se verifica en producción», que es dónde se mira, no qué debe verse. | ídem |
| Evidencia de demanda con cita | **Débil.** El acta dice «Cliente entrevistado», sin entrevista ni cita. La única entrevista (2025-09-19, «Lo necesito y hoy no lo tengo.») no nombra este requerimiento: vínculo no confirmado. | ídem; `10-descubrimiento/2025-09-19-entrevistas.md` |
| Autoridad declarada en la definición | **No cumple.** La definición no dice quién decide. | `00-definicion/2025-12-27-definicion-producto.md` |

Se sigue con los faltantes marcados como vacíos del acta (respuesta sugerida, sin interlocutor en esta prueba). No se rellenó ninguno.

## Qué problema resuelve
«El segmento Microempresarios no tiene tarjeta débito.» (`00-definicion/2025-12-27-definicion-producto.md`). El requerimiento no registra su propia necesidad (`need`: no encontrada). La propuesta de la definición es solo «Propuesta principal», sin contenido.

## Criterio de éxito
- De REQ-4300: «se verifica en producción». **Sin cómo se verifica**: no hay métrica, umbral ni fecha.
- La definición no declara criterio de éxito del producto (no encontrado).
- El caso de negocio declara `volumen_mensual` = 248.461 (sin unidad ni periodo de medición) y «Retorno esperado en 24 meses» sin monto ni tasa (`00-definicion/2025-12-27-caso-de-negocio.md`). Son cifras del negocio; no se usan como criterio.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 (doliente: Felipe Arango) | «Cliente entrevistado» según el acta; sin vínculo confirmado a la entrevista del 2025-09-19 |

### No entra
Razón común: la invocación pidió solo REQ-4300 y no existe decisión escrita de alcance. Fuente: acta del comité del 2026-10-12.
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4303, 4309, 4310, 4311, 4312, 4313 | Requerimiento REQ-xxxx | Propuestos, no aceptados: sin decisión del gerente de producto no entran a un acta |
| REQ-4301 | Requerimiento REQ-4301 | Aceptado; no se pidió en esta acta. Sin «quién lo pidió» |
| REQ-4302 | Requerimiento REQ-4302 | Aceptado; no se pidió. Sin criterio de aceptación |
| REQ-2030 | Requerimiento REQ-2030 | Aceptado; no se pidió. Sin criterio de aceptación |
| REQ-4304, 4307, 4308, 4315, 2038 | Requerimiento REQ-xxxx | Aceptados; no se pidieron en esta acta |
| REQ-4305, 4306, 4314 | Requerimiento REQ-xxxx | Aceptados; no se pidieron. Sin doliente asignado |

Cualquiera puede sumarse con otra acta o un cambio de alcance firmado.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Natalia Ospina es gerente de **producto** (definición), no gerente de proyecto; no se la propone ni se nombra a nadie.
- **Comité:** «Comité de producto» según la configuración; el acta del 2026-10-12 solo registra a Natalia Ospina como asistente.
- **Autoridad del gerente:** no está dicho. Ningún documento dice qué puede decidir el gerente del proyecto ni cuándo escala.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El reglamento vigente lo permite» (declarado 2026-09-02, en un documento fechado 2025-12-27) | No. Lleva 43 días sin verificar, sobre el umbral de 30 | Sin doliente: debe asignarlo quien firme. Se registra como riesgo con raid-taxonomy en el proyecto |

Dato a aclarar: la fecha del supuesto es posterior a la de la definición que lo contiene.

## Restricciones normativas sin resolver
Barrido de nombrado y cita, no dictamen de cumplimiento. **El país no está declarado** en la definición, y la obligación cambia con él. No se cita ninguna norma: no hay norma a la vista.
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Un medio de pago (tarjeta débito) para microempresarios | Reglas de emisión y de medios de pago | — | no tengo la norma a la vista |
| Producto financiero para consumidor | Información previa, reclamos y cobros | — | no tengo la norma a la vista |
| Datos del titular (identificación, transacciones) | Autorización, finalidad, retención | — | no tengo la norma a la vista |
| Supuesto «el reglamento vigente lo permite» | Hay que saber a qué reglamento se refiere | — | sin resolver |
| Proveedor o nube en otro país, si existe | Transferencia internacional | — | no tengo la norma a la vista |

Todo esto va a revisión jurídica como insumo.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Decisión escrita de aceptación y quién la tomó | El proyecto arranca sobre un «aceptado» que nadie puede sustentar | Gerente de producto / comité |
| Criterio de aceptación verificable | El cierre no se podrá juzgar meses después | Felipe Arango (doliente) con el gerente de producto |
| Criterio de éxito del producto | Sin contra qué medir | Gerente de producto |
| Evidencia de demanda vinculada a REQ-4300 | La demanda queda en una afirmación del acta | Gerente de producto |
| Patrocinador | Nadie responde por el presupuesto ni por escalar | Quien tenga autoridad en la organización |
| Autoridad del gerente del proyecto | Escalar todo o no escalar nada | Comité de producto |
| Gerente del proyecto | No hay a quién entregarle la ficha | Quien asigne personas |
| País y norma aplicable | El supuesto del reglamento no se puede verificar | Jurídica |
| Presupuesto, hitos | Ningún documento los declara; no se inventan | Gerente de producto |
| Proyecto que lo construye | La definición dice «Ninguno declarado» | Quien firme |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para constituir el proyecto (hoy no identificada en los documentos). **La ficha del proyecto no se creó** y se crea solo después de la firma; el estado declarado nunca lo escribe este comando.

**Sigue:** el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
