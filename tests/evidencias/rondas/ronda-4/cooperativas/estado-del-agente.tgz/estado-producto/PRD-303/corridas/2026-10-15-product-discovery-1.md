# Corrida del 2026-10-15 · product-discovery

PRD-303 · 18 requerimientos · 22 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

Una entrevista, una cita, una voz: ningún tema. Cita registrada como dicha una vez; sin cruce posible con REQ (títulos vacíos). Sellado rechazado: no hay ficha producto.json escrita en la corrida.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Descubrimiento — Tarjeta débito (PRD-303) · 1 pieza de descubrimiento al 2026-10-15

Se leyeron las 5 piezas del producto (1 de descubrimiento, 2 de definición, 1 de métricas, 1 acta de comité). Material de entrevistas: una sola entrevista, 2025-09-19, de Natalia Ospina a un cliente.

### Temas
Ninguno. Un tema necesita más de una voz, y hay una.

### Dicho y nunca convertido en nada
No se puede establecer: con una sola voz no hay tema repetido. Tampoco se puede cruzar la cita con un requerimiento: el acta del 2026-10-12 lista REQ-4300 a REQ-4315, REQ-2030 y REQ-2038 solo con su número como título y "Cliente entrevistado" como quien lo pidió; ninguno dice qué problema recoge. No asigno la cita a ninguno.

### Dicho una sola vez
| Qué | Quién | Cuándo |
|---|---|---|
| *«Lo necesito y hoy no lo tengo.»* (rotulado «Necesidad principal») | Cliente entrevistado, sin nombre ni segmento | 2025-09-19 |

No se promueve ni se descarta. Tiene 13 meses; el umbral de evidencia vieja es 12. El entrevistado no dice qué necesita: la cita no sustenta por sí sola ninguna funcionalidad concreta.

### Afirmaciones numéricas de los entrevistados
Ninguna.

### Evidencia nueva que contradice el registro
Ninguna. La entrevista no contradice nada del registro.

### Lo que el cálculo dejó ver (no es descubrimiento, solo se nombra)
- El caso de negocio declara volumen_mensual 248.461 (2025-12-27); el tablero mide 202.628 (2026-09-29): 18,4 % de brecha, bajo el umbral de 20 %.
- El supuesto «El reglamento vigente lo permite» lleva 43 días sin verificar (umbral 30).
- 16 de 18 requerimientos del acta dicen «Cliente entrevistado» como quien los pidió, pero solo existe una entrevista de una cita. Eso lo decide la gerencia, pero la evidencia que consta en el descubrimiento no alcanza para sustentarlos.

### Lo que no pude hacer
- No pude sellar la lectura: `sellar` se negó porque la ficha `producto.json` no se escribió en esta corrida. La próxima corrida volverá a leer las 5 piezas.
