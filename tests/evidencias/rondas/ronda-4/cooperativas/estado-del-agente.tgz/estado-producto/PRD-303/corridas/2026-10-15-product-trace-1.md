# Corrida del 2026-10-15 · product-trace

PRD-303 · 18 requerimientos · 42 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

12 requerimientos decididos y ninguno tiene proyecto; PRY-204 dice ejecutar tarjeta débito y ningún REQ lo nombra

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Tarjeta débito (PRD-303) · al 2026-10-15
12 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-15). Fichas leídas: 13 en `estado/records` (PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Los 12 requerimientos aceptados tienen `traces.project = null`. Ninguno nombra un proyecto. Orden: el más antiguo primero.

| REQ | Título | Decidido el | Por quién | Dueño del REQ |
|---|---|---|---|---|
| REQ-4315 | Requerimiento REQ-4315 | 2026-04-09 | no consta (el acta no dice quién) | Sandra Gil |
| REQ-4308 | Requerimiento REQ-4308 | 2026-04-20 | no consta | Sandra Gil |
| REQ-4307 | Requerimiento REQ-4307 | 2026-05-12 | no consta | Gustavo Neira |
| REQ-4301 | Requerimiento REQ-4301 | 2026-05-17 | no consta | Óscar Ramírez |
| REQ-4300 | Requerimiento REQ-4300 | 2026-05-26 | no consta | Felipe Arango |
| REQ-4304 | Requerimiento REQ-4304 | 2026-07-05 | no consta | Elena Duarte |
| REQ-4314 | Requerimiento REQ-4314 | 2026-07-12 | no consta | sin dueño |
| REQ-4306 | Requerimiento REQ-4306 | 2026-07-19 | no consta | sin dueño |
| REQ-4305 | Requerimiento REQ-4305 | 2026-07-23 | no consta | sin dueño |
| REQ-4302 | Requerimiento REQ-4302 | 2026-08-20 | no consta | Beatriz Cuéllar |
| REQ-2038 | Requerimiento REQ-2038 | 2026-09-30 | no consta | Óscar Ramírez |
| REQ-2030 | Requerimiento REQ-2030 | 2026-10-02 | no consta | Paula Céspedes |

Cita de la decisión (verificada en REQ-4300): `documentos/productos/PRD-303/30-decisiones/2026-10-12-comite-producto.md`, que lista el requerimiento como aceptado y cuya única decisión escrita es «Se mantiene el plan». Los títulos del registro son genéricos porque el acta no los nombra. Cuatro de los doce llevan más de 140 días decididos sin proyecto (REQ-4315, 4308, 4307, 4301). No se abrió el registro de los otros once para confirmar que citan la misma acta.

### La traza no se confirma
Ninguna: no hay trazas declaradas que confirmar. El cálculo da `traced = 0` y ninguno de los doce nombra un proyecto, así que no hay nada que cotejar contra una ficha.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-204 «Tarjeta débito para asociados» (gerente: Elena Duarte) | Campo `product` = «tarjeta débito», cita `PRY-204-tarjeta-débito-para-asociados/00-gobierno/2025-11-15-acta-constitucion.docx` (2025-11-15) | Cierto: los 18 REQ tienen `project = null` |

Es el hallazgo principal de la corrida: PRY-204 dice construir la tarjeta débito y el registro de PRD-303 no lo conoce. No se afirma que PRY-204 ejecute alguno de los doce: eso no consta en ningún documento. Un dato para quien lo revise: Elena Duarte es dueña de REQ-4304 en el registro y gerente de PRY-204 en la ficha. Es un indicio, no un vínculo. El nombre del campo en la ficha es texto libre («tarjeta débito»), no el código PRD-303.

Las otras fichas declaran otros productos (PRD-299, ahorro a la vista, crédito de libranza, aportes sociales, microcrédito, pagos QR, recaudos). Cinco fichas (PRY-202, 205, 208, 209, 210) tienen el campo producto vacío: es un hallazgo del lado de esas fichas y no se puede descartar que alguna ejecute este producto.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-2030 | aceptado | 2026-10-02 | — | no | — |
| REQ-2038 | aceptado | 2026-09-30 | — | no | — |
| REQ-4300 | aceptado | 2026-05-26 | — | no | — |
| REQ-4301 | aceptado | 2026-05-17 | — | no | — |
| REQ-4302 | aceptado | 2026-08-20 | — | no | — |
| REQ-4304 | aceptado | 2026-07-05 | — | no | — |
| REQ-4305 | aceptado | 2026-07-23 | — | no | — |
| REQ-4306 | aceptado | 2026-07-19 | — | no | — |
| REQ-4307 | aceptado | 2026-05-12 | — | no | — |
| REQ-4308 | aceptado | 2026-04-20 | — | no | — |
| REQ-4314 | aceptado | 2026-07-12 | — | no | — |
| REQ-4315 | aceptado | 2026-04-09 | — | no | — |
| REQ-4303, 4309, 4310, 4311, 4312, 4313 | propuesto | sin decidir (65 a 214 días) | — | — | — |

La cadena se rompe en el segundo eslabón en los doce: hay decisión citada y no hay proyecto. No se pudo armar ningún tramo hasta un entregable.

### Sin fichas a la vista
Hay fichas de 13 proyectos y ninguna se pudo cruzar con un REQ, porque el registro no nombra proyecto. Quien tenga que crear o corregir esa traza es el dueño del producto: este comando no toca el registro ni las fichas.

### Pendiente que condiciona esta lectura
Los doce decididos comparten evidencia de demanda de 2025-09-19, de 12 meses, sin vínculo confirmado a cada requerimiento. Dos aceptados no tienen criterio de aceptación (REQ-2030, REQ-4302) y uno no tiene evidencia (REQ-4301). Eso no cambia la traza, pero afecta qué tan listo está cada uno para `/product-charter`.

Siguiente paso: `/product-charter` para el que ya esté listo. Sobre PRY-204 conviene hablar con Elena Duarte.
