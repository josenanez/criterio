## Definición — Tarjeta débito (PRD-303) · contrastada al 2026-10-15
**Documento:** `00-definicion/2025-12-27-definicion-producto.md` (con `2025-12-27-caso-de-negocio.md`) · **del** 2025-12-27 · 5 afirmaciones

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (versión 0.3.10); no hubo que registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ningún documento de la carpeta dice lo contrario de lo que afirma la definición.

### El negocio y los datos
Ninguna cifra pasa el umbral (20 %). Una queda cerca, y es imprecisión, no contradicción:

| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual (bajo el umbral) | 248.461 | 202.628 | −18,4 % | Caso de negocio, 2025-12-27 · Tablero de métricas (bodega de datos), 2026-09-29 |

La medición es un solo punto, no una serie. Con un solo corte no se puede decir si la brecha crece o se cierra.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| Retorno esperado en 24 meses (sin monto ni tasa) | Caso de negocio, 2025-12-27 | No hay cifra declarada ni medida. No se puede contrastar. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento lo declara, así que el producto no se puede cerrar contra nada.
- **La propuesta.** El documento dice solo «Propuesta principal», sin contenido.
- **Cuántos microempresarios son, ni cuántos no tienen tarjeta débito.** El problema se afirma sin tamaño.
- **Cuánto pagarían o qué harían.** No hay precio, comisión, ni compromiso de nadie.
- **El país.** Ningún documento lo dice, y de él depende lo normativo.
- **Quién decide.** Ningún documento lo dice. «Comité de producto» se tomó del acta del 2026-10-12 y está por confirmar con la persona.
- **Qué proyecto lo construye.** La definición dice «Ninguno declarado».
- **A qué requerimiento corresponde la entrevista.** El acta del comité atribuye 15 de 18 requerimientos a «Cliente entrevistado». No dice a cuál entrevista ni cita lo dicho.
- **Por qué el supuesto está fechado el 2026-09-02** si la definición es del 2025-12-27. No se sabe si la definición se tocó después sin cambiar su fecha.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El reglamento vigente lo permite (declarado 2026-09-02) | 43 (umbral: 30) | Que jurídico o cumplimiento nombre el reglamento y el artículo, y deje un concepto escrito. Hoy no se sabe cuál reglamento ni de qué país. Como está escrito, «el reglamento» sin norma, no se puede desmentir. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Microempresarios no tiene tarjeta débito | Entrevista a un cliente: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-09-19-entrevistas.md`) | 2025-09-19 | Débil. Es una persona que dijo, no que pagó. El registro no dice que sea microempresario. Es la única entrevista de la carpeta. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento Microempresarios no tiene tarjeta débito | Entrevista del 2025-09-19 | 13 meses (umbral: 12). El cálculo del arnés la marca como envejecida en 17 señales sobre los requerimientos que la citan. |

### Lo normativo que toca
Esto es un primer barrido. No dice si el producto cumple y va a revisión jurídica, no la reemplaza. No hay país declarado, así que todas las filas quedan sin norma citada.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Emite un medio de pago (tarjeta débito) y mueve dinero de cuentas | No declarado | Quién puede emitirlo, con qué autorización y qué reportes debe | — | no tengo la norma a la vista |
| Consumidor financiero: información previa, cobros y reclamos de la tarjeta | No declarado | Obligaciones de quien atiende consumidor financiero | — | no tengo la norma a la vista |
| Datos personales de los microempresarios (identificación, transacciones) | No declarado | Autorización previa, finalidad declarada y encargados del tratamiento | — | no tengo la norma a la vista |
| Retención y trazabilidad de las transacciones | No declarado | Cuánto se conserva y quién puede pedirlo | — | no tengo la norma a la vista |
| El supuesto «el reglamento vigente lo permite» | No declarado | Es la pregunta jurídica central y está sin verificar | — | sin resolver |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar.
- **Quién decide:** sin confirmar (se tomó el comité del acta).
- **Problema y para quién:** están, pero el problema sin tamaño y el segmento sin entrevistas que lo nombren.
- **Nota:** el cálculo del arnés trae `unknown` vacío. Aun así el criterio de éxito aparece como `not_found` en la definición, y es lo que manda aquí.

### Después
- El supuesto lleva 43 días sin verificar. Se ofrece registrarlo como riesgo con doliente (raid-taxonomy).
- La definición no está cerrada, así que no se ofrece `/product-charter`.
