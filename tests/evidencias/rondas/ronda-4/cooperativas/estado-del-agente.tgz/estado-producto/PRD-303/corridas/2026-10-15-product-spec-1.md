# Corrida del 2026-10-15 · product-spec

PRD-303 · 18 requerimientos · 40 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

Borrador sin comportamiento: 12 aceptados sin necesidad; único criterio 'se verifica en producción' no verificable; 0 cubiertos. Dije que no tengo la norma a la vista y que el país no está en los documentos.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Borrador, no una especificación cerrada. Lo cierra Natalia Ospina (gerente de producto, Comité de producto como autoridad); este agente no aprueba.**

# Especificación — Tarjeta débito (PRD-303) · borrador del 2026-10-15

Resultado en una línea: **del registro no sale comportamiento que especificar.** Los 12 requerimientos aceptados no tienen enunciada la necesidad (`need: not_found`), así que ninguna sección de «Comportamiento» se puede escribir sin inventarla. Lo que sigue deja a la vista qué falta, en vez de rellenarlo.

## Qué problema resuelve
La definición (`00-definicion/2025-12-27-definicion-producto.md`) dice solo: «El segmento Microempresarios no tiene tarjeta débito». La propuesta es un marcador vacío («Propuesta principal»). No dice qué debe hacer la tarjeta, ni por qué hoy no existe.

## Alcance
### Entra (solo por estar aceptados en el acta del 2026-10-12; sin contenido)
REQ-2030, REQ-2038, REQ-4300, REQ-4301, REQ-4302, REQ-4304, REQ-4305, REQ-4306, REQ-4307, REQ-4308, REQ-4314, REQ-4315. Todos tienen como título «Requerimiento REQ-xxxx»: el acta no dice qué piden.

### No entra
- Los 6 en `propuesto`: REQ-4303, 4309, 4310, 4311, 4312, 4313. Nadie decidió hacerlos.
- Todo lo que la definición no menciona: canales, límites, emisión, costos, otros segmentos. No está dicho en ninguna parte; no lo agrego.

## Comportamiento
Sin secciones. Ningún requerimiento tiene `need`, y el título es genérico. Escribir comportamiento aquí sería diseñar desde la imaginación del agente.

## Criterios de aceptación
El único criterio que existe en todo el registro es «se verifica en producción». Dos personas distintas no llegan a la misma respuesta con eso: **no pasa la prueba de verificabilidad.**

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (no verificable) | REQ-2038, 4300, 4301, 4304, 4305, 4306, 4307, 4308, 4314, 4315 | No está dicho: no nombra qué se observa ni qué umbral | No: no hay nada que medir |
| **Sin criterio** | REQ-2030, REQ-4302 | — | — |

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El reglamento vigente lo permite» (declarado el 2026-09-02, definición) | No. Lleva 43 días sin verificar, sobre el umbral de 30 (`assumption_unverified`). Además no es falsable tal como está: no dice qué reglamento ni de qué país | Natalia Ospina como dueña de la definición; la revisión jurídica de la organización sería quien lo confirme (no figura ningún jurídico nombrado en los documentos) |

Los registros de los 18 requerimientos no traen supuestos propios.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Necesidad de cada requerimiento aceptado (12 sin `need`) | No hay qué construir ni qué verificar | Cada doliente (ver abajo); Natalia Ospina para REQ-4305, 4306, 4314 |
| Criterio de aceptación verificable, para los 12 | La discusión de «¿quedó bien?» ocurre después de construir | Cada doliente con Natalia Ospina |
| Criterio de aceptación inexistente en REQ-2030 (Paula Céspedes) y REQ-4302 (Beatriz Cuéllar) | Aceptados sin poder saber cuándo están hechos | Paula Céspedes; Beatriz Cuéllar |
| Doliente: REQ-4305, 4306, 4314 figuran «sin asignar» y están aceptados | Nadie responde por ellos | Natalia Ospina |
| Evidencia de demanda: toda es «Cliente entrevistado», una sola entrevista del 2025-09-19 («Lo necesito y hoy no lo tengo»), sin vínculo confirmado a ningún requerimiento y con 12,9 meses (sobre el umbral de 12) → `evidence_stale`. REQ-4301 no tiene ninguna | Se acepta sin demanda sustentada | Natalia Ospina (realizó la ronda) |
| Decisión sin autor: el acta solo dice «Se mantiene el plan», sin quién decidió cada aceptación; las fechas «desde» del registro son las del propio acta, no una decisión documentada | La aceptación no se puede rastrear a una decisión | Comité de producto / Natalia Ospina |
| Proyecto que ejecuta cada requerimiento: ninguno (acta: «—»; definición: «Ninguno declarado») | Aceptado y sin quien lo construya | Comité de producto |
| Casos borde (sin conexión, operación duplicada, cancelación a medio camino, tarjeta perdida, fraude, etc.) | Comportamiento no definido en ningún documento | Gerente de producto con quien construya, una vez exista la necesidad |
| Otros equipos: la definición no nombra ningún equipo ni proveedor; no hay acuerdos | Dependencias desconocidas, no inexistentes | Natalia Ospina |
| Obligaciones normativas (barrido abajo) | Revisión jurídica tardía | Natalia Ospina debe designar a quién; no hay jurídico nombrado |

### Barrido normativo (nombra y cita; no dice si cumple)
| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Emisión y uso de una tarjeta débito (medio de pago) | No dicho en los documentos | Autorización para emitir/operar medios de pago | — | no tengo la norma a la vista |
| Microempresarios como consumidores financieros | No dicho | Información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Datos personales de titulares (inferido: toda tarjeta los recoge; la definición no lo dice) | No dicho | Autorización y finalidad | — | no tengo la norma a la vista |
| «El reglamento vigente lo permite» | No dicho | La propia definición lo da por supuesto | — | sin resolver |

Esto es insumo para la revisión jurídica, no sustituto.

## Requerimientos aceptados que esta especificación no cubre
Ningún requerimiento queda cubierto con comportamiento. Los 12 se listan, sin excepción:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | Sin necesidad, sin criterio de aceptación, sin proyecto |
| REQ-2038 | Requerimiento REQ-2038 | Sin necesidad; criterio no verificable |
| REQ-4300 | Requerimiento REQ-4300 | Sin necesidad; criterio no verificable |
| REQ-4301 | Requerimiento REQ-4301 | Sin necesidad; criterio no verificable; sin evidencia |
| REQ-4302 | Requerimiento REQ-4302 | Sin necesidad ni criterio |
| REQ-4304 | Requerimiento REQ-4304 | Sin necesidad; criterio no verificable |
| REQ-4305 | Requerimiento REQ-4305 | Sin necesidad; sin doliente |
| REQ-4306 | Requerimiento REQ-4306 | Sin necesidad; sin doliente |
| REQ-4307 | Requerimiento REQ-4307 | Sin necesidad; criterio no verificable |
| REQ-4308 | Requerimiento REQ-4308 | Sin necesidad; criterio no verificable |
| REQ-4314 | Requerimiento REQ-4314 | Sin necesidad; sin doliente |
| REQ-4315 | Requerimiento REQ-4315 | Sin necesidad; criterio no verificable |

## Pie
Sale del registro `estado-producto/PRD-303/requirements/` (18 requerimientos: 12 aceptados, 6 propuestos), fechado el 2026-10-15 sobre el acta del comité del 2026-10-12. Cubre 0 de 12 aceptados con comportamiento; 12 listados en alcance. Términos aceptados por José Francisco Ñáñez (2026-10-15, v1.1): https://www.josenanez.com/es/agents/criterio-pmo/legal

**No ofrezco `/product-charter`:** los vacíos no están cerrados y ningún requerimiento tiene criterio de éxito verificable.
