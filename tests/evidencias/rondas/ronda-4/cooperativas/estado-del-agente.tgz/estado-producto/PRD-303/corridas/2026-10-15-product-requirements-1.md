# Corrida del 2026-10-15 · product-requirements

PRD-303 · 18 requerimientos · 29 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

REQ-4301 aceptado sin quien lo pidiera; 12 aceptados sin proyecto ni documento de decisión; 6 propuestos entre 65 y 214 días sin decidir; 3 sin doliente; 2 sin criterio de aceptación

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Registro — Tarjeta débito (PRD-303) · al 2026-10-15
18 requerimientos · 12 decididos · 91.7% con evidencia · 0% con proyecto que lo ejecuta

Todas las cifras salen de `producto.py compute`. No hay fichas de proyecto en `estado/records` (la carpeta no existe), así que ningún requerimiento tiene proyecto confirmado: el acta del comité de 2026-10-12 también pone «—» en la columna de proyecto de los 18.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4301 | Requerimiento REQ-4301 | aceptado desde 2026-05-17 | Óscar Ramírez |

Sin una sola cita de quien lo pidió: el acta tiene «—» en «Quién lo pidió» y el registro no tiene evidencia. Quien lo cierra: Óscar Ramírez trae quién y qué dijo, o el Comité de producto lo devuelve a `propuesto`.

### Decidido y nadie lo está construyendo
Los 12 aceptados, sin proyecto que los ejecute: REQ-2030, REQ-2038, REQ-4300, REQ-4301, REQ-4302, REQ-4304, REQ-4305, REQ-4306, REQ-4307, REQ-4308, REQ-4314, REQ-4315.

| REQ | Decidido el | Doliente |
|---|---|---|
| REQ-4315 | 2026-04-09 | Sandra Gil |
| REQ-4308 | 2026-04-20 | Sandra Gil |
| REQ-4307 | 2026-05-12 | Gustavo Neira |
| REQ-4301 | 2026-05-17 | Óscar Ramírez |
| REQ-4300 | 2026-05-26 | Felipe Arango |
| REQ-4304 | 2026-07-05 | Elena Duarte |
| REQ-4314 | 2026-07-12 | sin asignar |
| REQ-4306 | 2026-07-19 | sin asignar |
| REQ-4305 | 2026-07-23 | sin asignar |
| REQ-4302 | 2026-08-20 | Beatriz Cuéllar |
| REQ-2038 | 2026-09-30 | Óscar Ramírez |
| REQ-2030 | 2026-10-02 | Paula Céspedes |

La fecha es la columna «Desde» del acta. Hay 5 meses de aceptado sin proyecto en REQ-4315. Quien lo cierra: Natalia Ospina, con `/product-trace` y `/product-charter` sobre los que tengan evidencia y criterio.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4305 | Requerimiento REQ-4305 | «sin asignar» |
| REQ-4306 | Requerimiento REQ-4306 | «sin asignar» |
| REQ-4314 | Requerimiento REQ-4314 | «sin asignar» |

Los tres están aceptados. Quien lo cierra: Natalia Ospina, que asigna una persona.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-2030 | Requerimiento REQ-2030 | aceptado |
| REQ-4302 | Requerimiento REQ-4302 | aceptado |

Solo decididos. Los demás tienen un criterio, «se verifica en producción», que no dice qué medir ni contra qué umbral; eso es una mejora de forma, no un vacío. Quien lo cierra: Paula Céspedes (REQ-2030) y Beatriz Cuéllar (REQ-4302).

### Decidido sin documento que lo respalde
| REQ | Quién decidió | Cuándo |
|---|---|---|
| Los 12 aceptados | No está dicho. El acta del 2026-10-12 solo lista el estado y su única decisión escrita es «Se mantiene el plan». | La fecha «Desde» del acta, sin acta de la decisión misma |

No hay un documento por requerimiento que diga quién aceptó y cuándo. Quien lo cierra: el Comité de producto deja constancia de cada aceptación.

### Lleva meses y nadie lo decide
Umbral de 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4309 | Requerimiento REQ-4309 | 214 días (2026-03-15) | Comité de producto |
| REQ-4303 | Requerimiento REQ-4303 | 182 días (2026-04-16) | Comité de producto |
| REQ-4313 | Requerimiento REQ-4313 | 158 días (2026-05-10) | Comité de producto |
| REQ-4310 | Requerimiento REQ-4310 | 123 días (2026-06-14) | Comité de producto |
| REQ-4312 | Requerimiento REQ-4312 | 84 días (2026-07-23) | Comité de producto |
| REQ-4311 | Requerimiento REQ-4311 | 65 días (2026-08-11) | Comité de producto |

La facultad es del Comité de producto, que es la autoridad de la configuración; Natalia Ospina es la gerente y la única asistente del acta. Se propone decidirlos —aceptar o descartar—, no cerrarlos por viejos. El comité del 2026-10-12 los revisó y su única decisión fue «Se mantiene el plan».

### Evidencia vieja
17 de los 18 se sostienen en lo mismo: «Cliente entrevistado», sin entrevista ni cita en el acta. Lo más nuevo que existe es el único registro de entrevista, del 2025-09-19, hace 12 meses y sin vínculo confirmado a ninguno de los requerimientos («Lo necesito y hoy no lo tengo.»).

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| Los 17 salvo REQ-4301 | Entrevista del 2025-09-19 | 12 meses |

En los 6 propuestos esto no cuenta como hallazgo: todavía no se les exige evidencia. Cuenta en los 11 aceptados con evidencia. Quien lo cierra: Natalia Ospina vincula cada requerimiento a su entrevista, o se hacen entrevistas nuevas.

### Aparte, de la definición
- Supuesto sin verificar hace 43 días: «El reglamento vigente lo permite» (umbral 30).
- `volumen_mensual`: declarado 248.461 en el caso de negocio (2025-12-27), medido 202.628 el 2026-09-29, brecha 18.4% (umbral 20%, no cruza). `retorno_esperado` no tiene cifra declarada.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 6 | 12 | 0 | 0 | 0 |

Ningún descartado en el registro. Si hubo discusiones cerradas, no están guardadas.

Siguiente paso: `/product-trace` para los 12 aceptados sin proyecto.
