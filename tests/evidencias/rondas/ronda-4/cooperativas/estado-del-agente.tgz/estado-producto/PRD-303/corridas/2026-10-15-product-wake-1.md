# Corrida del 2026-10-15 · product-wake

PRD-303 · 18 requerimientos · 26 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

Primera corrida, sin corte anterior: reporté el estado completo, no un delta. No pude confirmar trazas porque ninguna ficha nombra PRD-303; no verifiqué el supuesto del reglamento ni escribí a nadie.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Tarjeta débito (PRD-303) · 2026-10-15

**Primera corrida de product-wake: no hay corte anterior**, así que no puedo separar lo nuevo de lo que ya estaba. Lo que sigue es el estado completo, no un delta. Desde el corte de hoy, lo que repita no se volverá a reportar.

18 requerimientos (12 aceptados, 6 propuestos). 11 con evidencia (91,7 %). 0 con traza a un proyecto.

### Cruzó un umbral sin que nadie hiciera nada
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4309 | 214 días (desde 2026-03-15) | Que el Comité de producto lo decida o lo descarte | Sandra Gil (doliente) |
| Sin decidir | REQ-4303 | 182 días (desde 2026-04-16) | Ídem | Rubén Cárdenas |
| Sin decidir | REQ-4313 | 158 días (desde 2026-05-10) | Ídem | Liliana Torres |
| Sin decidir | REQ-4310 | 123 días (desde 2026-06-14) | Ídem | Mauricio Pérez |
| Sin decidir | REQ-4312 | 84 días (desde 2026-07-23) | Ídem | Sandra Gil |
| Sin decidir | REQ-4311 | 65 días (desde 2026-08-11) | Ídem | Ricardo Salas |
| Supuesto sin verificar (umbral 30 días) | «El reglamento vigente lo permite» | 43 días | Una verificación normativa citada de quien tenga la facultad; hoy pesa sobre toda la definición | Natalia Ospina |
| Evidencia vencida (umbral 12 meses) | 17 requerimientos | 12 meses | Su única sustentación es una entrevista del 2025-09-19 que el acta no vincula a ningún requerimiento; las afirmaciones de demanda quedan sin sustento actual | Natalia Ospina |

La facultad de decidir es del Comité de producto. Ofrezco llevar estos seis al próximo comité.

### Las trazas
Ninguna ficha de `estado/records` nombra PRD-303, y los 12 requerimientos aceptados figuran sin traza (`requirement_untraced`). Ninguna traza se da por confirmada: aceptado y sin proyecto que lo construya.

### Del registro
- Sin doliente: 3 requerimientos (p. ej. REQ-4305).
- Aceptado sin criterio de aceptación: REQ-2030, REQ-4302.
- Aceptado sin evidencia: REQ-4301.

### Contradicción entre negocio y datos
`volumen_mensual`: el caso de negocio (2025-12-27) declara 248.461; el tablero de 2026-09-29 mide 202.628, una brecha de 18,4 %, bajo el umbral de 20 %, pero cerca. `retorno_esperado` no tiene cifra declarada. El criterio de éxito de la definición no aparece en ningún documento.

### Del descubrimiento
Sin documentos nuevos que releer: hay una sola entrevista (2025-09-19).

**Vuelvo el 2026-11-14.**
