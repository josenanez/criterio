No publiqué la ficha de PRD-303 (Tarjeta débito): no hay carpeta de productos publicados configurada ni existe en el espacio (`productos/publicados/` no está). Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé nada; escribir en una carpeta nueva exige tu permiso y esta sesión no tiene a quién preguntar.

**Lo que habría publicado (corte al 2026-10-15):**
- 18 requerimientos (12 aceptados, 6 propuestos) · 0 proyectos que los ejecuten · 2 métricas afirmadas
- Segmento declarado: Microempresarios
- Métricas: volumen_mensual = 248461 (caso de negocio, 2025-12-27, documentos/productos/PRD-303/00-definicion/2025-12-27-caso-de-negocio.md); retorno_esperado = sin valor en el documento.

Para publicar: acordar la carpeta común, dejarla en la configuración y volver a correr el comando.
