# Corrida del 2026-10-15 · product-business-case

PRD-303 · 18 requerimientos · 31 s · 42 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 17 |
| `requirement_untraced` | 12 |
| `requirement_undecided` | 6 |
| `requirement_without_owner` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_accepted_without_evidence` | 1 |
| `assumption_unverified` | 1 |

Caso de negocio PRD-303 armado: 2 cifras con fuente (volumen declarado 248.461 vs medido 202.628, brecha 18,4% bajo el umbral de 20%); retorno sin valor; costos sin ningún dato; supuesto normativo sin verificar hace 43 días; sin criterio de éxito ni fecha de corte; sin otros productos publicados para cruzar.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Tarjeta débito (PRD-303) · borrador del 2026-10-15
**Desde:** la definición del 2025-12-27 y el caso de negocio del 2025-12-27 · **Cifras con fuente:** 2 de 3 (la tercera, el retorno, no tiene valor)

> Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15. Este documento es un borrador de estructura y trazabilidad. No proyecta ingresos, no calcula retorno y no recomienda aprobar ni rechazar.

## Qué problema resuelve, y para quién
"El segmento Microempresarios no tiene tarjeta débito." Segmento: Microempresarios. (`00-definicion/2025-12-27-definicion-producto.md`, 2025-12-27)

La propuesta de la definición dice solo "Propuesta principal". No describe qué se construye.

## Qué se construye
El registro tiene 18 requerimientos: 12 aceptados y 6 propuestos. Los 18 salen del acta del comité del 2026-10-12. El alcance del caso son los 12 aceptados. Ninguno tiene proyecto que lo ejecute.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4300 | aceptado | "Cliente entrevistado" según el acta. La única entrevista de la carpeta es la del 2025-09-19: «Lo necesito y hoy no lo tengo.» El acta no la vincula a este requerimiento. |
| REQ-4302 | aceptado | Igual que REQ-4300. **Sin criterio de aceptación.** |
| REQ-4304, 4305, 4306, 4307, 4308, 4314, 4315, 2038 | aceptado | Igual que REQ-4300. REQ-4305, 4306 y 4314 están **sin doliente**. |
| REQ-2030 | aceptado | Igual que REQ-4300. **Sin criterio de aceptación.** |
| REQ-4301 | aceptado | **Nadie lo pidió** según el acta (el campo está vacío). |

Los 6 propuestos (REQ-4303, 4309, 4310, 4311, 4312 y 4313) quedan fuera del alcance hasta que se decidan.

La única entrevista de la carpeta es genérica. No nombra ninguna funcionalidad, así que no sostiene ningún requerimiento en concreto.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (esperado) | 248.461 | Declarada | Caso de negocio, Natalia Ospina | 2025-12-27 |
| volumen_mensual (actual) | 202.628 | Medida | Tablero de métricas, bodega de datos | 2026-09-29 |
| Retorno esperado | "en 24 meses", sin monto ni tasa | Declarada, sin valor | Caso de negocio | 2025-12-27 |
| Que el reglamento vigente permita el producto | — | Supuesta | Definición, "declarado el 2026-09-02 · sin verificar" | 2026-09-02 |

El retorno no tiene número. Solo hay un plazo y no se puede evaluar. No se completó con ninguna cifra.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 248.461 (caso de negocio, 2025-12-27) | 202.628 (tablero, 2026-09-29) | Diferencia de 45.833, el 18,4 % de lo declarado. Está por debajo del umbral configurado de 20 %, así que no es señal abierta. Se deja a la vista porque es la primera pregunta que haría un comité. |

El caso no dice si 248.461 es una meta o una cifra ya observada. La serie medida tiene un solo punto, así que no hay tendencia que mostrar.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **Sin dato** | Ningún documento |
| Costo del equipo | **Sin dato** | Ningún documento |
| Contratos o cotizaciones | **Sin dato** | Ningún documento |

Este es el primer vacío. Sin costo de construir no hay caso de negocio que evaluar. Hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El reglamento vigente permite el producto (declarado el 2026-09-02, sin verificar) | El producto no se puede ofrecer al segmento. Todo el caso cae. | Nadie asignado. El umbral de 30 días sin verificar está superado (43 días al 2026-10-15). Falta una persona o área responsable. |
| El volumen de 248.461 es alcanzable | El caso se apoya en un número que la serie no ha alcanzado (202.628) | El negocio, con la serie del tablero |
| Los 12 requerimientos aceptados responden a demanda real | Se construye sin sustento. La evidencia es una sola entrevista genérica. | Natalia Ospina |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y de operar | Sin él no hay caso que evaluar | El negocio (Natalia Ospina, o quien tenga el presupuesto) |
| Monto y tasa del retorno esperado | "Retorno en 24 meses" sin cifra no se puede verificar | El negocio |
| Qué se construye (la propuesta dice "Propuesta principal") | No se puede acotar el costo ni el alcance | Natalia Ospina |
| Criterio de éxito | La definición no lo trae (`not_found`) | Natalia Ospina |
| Fecha de corte para medir el éxito | Sin ella no se puede cerrar el producto meses después | Comité de producto |
| Verificación del supuesto normativo | De él depende todo el caso | Área de cumplimiento, a confirmar |
| Alternativas consideradas y qué pasa si no se hace | El caso no las menciona | Natalia Ospina |
| Proyecto que construye el producto ("Ninguno declarado") | Nada de lo aceptado tiene quién lo ejecute | Comité de producto |
| Demanda por requerimiento | Una entrevista genérica no sostiene ninguno | Descubrimiento |
| Doliente en REQ-4305, 4306 y 4314; criterio de aceptación en REQ-4302 y 2030; quién pidió REQ-4301 | Están aceptados con huecos | Natalia Ospina |

## Cómo se sabrá si funcionó
Sin declarar. La definición no trae criterio de éxito. La única métrica candidata es volumen_mensual, con el valor declarado de 248.461. Ningún documento fija una fecha de corte ni dice si ese valor es la meta. Sin esto, el producto no se puede cerrar meses después.

## Si hay otros productos publicados
No hay ninguno publicado a la vista (la carpeta de fichas `estado/records` no existe o está vacía). No se hizo el cruce de métricas. Hay que repetirlo cuando otros productos publiquen, para descartar que cuenten las mismas transacciones.

## Observación sobre los documentos
La definición está fechada el 2025-12-27, pero registra un supuesto "declarado el 2026-09-02". Es posterior a la fecha del documento y conviene confirmar si el documento se editó después sin cambiar su fecha.

## Siguiente paso
Pasar los supuestos a seguimiento con assumption-tracking. Un supuesto que se queda dentro del caso de negocio es el que nadie vuelve a mirar. `/product-charter` queda para cuando el caso se apruebe, y hoy no hay base para eso.
