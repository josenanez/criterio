<!-- origen: PRY-208-motor-de-crédito/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Motor de crédito

Fecha: 2026-10-14

Asistentes: Mauricio Pérez, Gustavo Neira

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Felipe Arango

Entregar el punto 9

2026-11-09
