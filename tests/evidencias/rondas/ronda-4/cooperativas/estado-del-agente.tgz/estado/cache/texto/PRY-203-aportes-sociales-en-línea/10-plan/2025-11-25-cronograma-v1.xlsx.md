<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2025-11-25-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-08 | 2026-05-08 | cerrado
Ambiente de pruebas certificado | 2026-10-10 | 2026-10-10 | en curso
Integración con el core cooperativo | 2027-03-13 | 2027-03-13 | en curso
