<!-- origen: PRY-203-aportes-sociales-en-línea/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión aportes sociales en línea — 2026-10-15
estuvieron: Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

- María Restrepo dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 11/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
