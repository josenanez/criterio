<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 31%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- Se ajustó el plan de pruebas con el área de seguridad

Presupuesto
COP
Aprobado 800.000.000
Comprometido 585.968.484
Ejecutado 243.883.065
Proyección al cierre 808.267.389

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
- El proveedor no ha confirmado la fecha de la última entrega
