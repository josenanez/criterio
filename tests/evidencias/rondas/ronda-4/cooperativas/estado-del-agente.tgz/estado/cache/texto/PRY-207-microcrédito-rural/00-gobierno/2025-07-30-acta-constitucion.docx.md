<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2025-07-30-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Microcrédito rural

Código: PRY-207

Área dueña: Tecnología

Patrocinador: Óscar Ramírez

Gerente de proyecto: Laura Vélez

Comité: Comité de Crédito

Producto asociado: microcrédito

Fecha de aprobación: 2025-07-30

Objetivo del negocio

Entregar microcrédito rural para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Crédito el 2025-07-30.

Fechas comprometidas

Fecha

Inicio

2025-08-09

Cierre

2026-05-25

Criterio de éxito

Microcrédito rural en producción y medido.

Dependencias declaradas

• Ninguna declarada
