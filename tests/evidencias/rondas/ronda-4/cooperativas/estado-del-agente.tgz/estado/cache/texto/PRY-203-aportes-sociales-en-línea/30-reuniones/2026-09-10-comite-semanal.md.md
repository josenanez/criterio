<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-09-10
**Asistentes:** Andrés Lozano, Diana Molina, Elena Duarte, Javier Hoyos, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-20 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-07 |
| Diana Molina | Revisar el anexo 3 | 2026-09-30 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-18 |
| Mauricio Pérez | Aprobar el diseño 5 | por definir |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-20 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-08 |
| Elena Duarte | Entregar el punto 8 | 2026-09-28 |
