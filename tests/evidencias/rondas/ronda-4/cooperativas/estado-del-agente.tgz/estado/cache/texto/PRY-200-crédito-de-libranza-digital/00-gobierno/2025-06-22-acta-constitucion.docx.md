<!-- origen: PRY-200-crédito-de-libranza-digital/00-gobierno/2025-06-22-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Crédito de libranza digital

Código: PRY-200

Área dueña: Tecnología

Patrocinador: Elena Duarte

Gerente de proyecto: Gustavo Neira

Comité: Consejo de Administración

Producto asociado: crédito de libranza

Fecha de aprobación: 2025-06-22

Objetivo del negocio

Entregar crédito de libranza digital para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

3.300.000.000 COP, aprobado por Consejo de Administración el 2025-06-22.

Fechas comprometidas

Fecha

Inicio

2025-07-02

Cierre

2026-07-27

Criterio de éxito

Crédito de libranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
