<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-27 |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-28 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-28 |
| Elena Duarte | Entregar el punto 8 | 2026-11-03 |
| Carlos Peña | Enviar el documento 9 | 2026-10-09 |
| Liliana Torres | Revisar el anexo 11 | 2026-10-21 |
| Mauricio Pérez | Aprobar el diseño 13 | 2026-10-31 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-21 |
| Andrés Lozano | Enviar el documento 17 | 2026-11-12 |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-11-10 |
| Felipe Arango | Validar el ambiente 20 | 2026-10-05 |
| Carlos Peña | Aprobar el diseño 21 | 2026-11-05 |
| María Restrepo | Actualizar la matriz 22 | 2026-10-27 |
| Elena Duarte | Confirmar la fecha 23 | 2026-10-30 |
| Óscar Ramírez | Entregar el punto 24 | por definir |

## Cerrados en esta reunión

- Cerrar la prueba 10 (Gustavo Neira): recibido, acta de recibo del 2026-10-08.
- Validar el ambiente 12 (Felipe Arango): recibido, acta de recibo del 2026-10-08.
- Actualizar la matriz 14 (María Restrepo): recibido, acta de recibo del 2026-10-08.
