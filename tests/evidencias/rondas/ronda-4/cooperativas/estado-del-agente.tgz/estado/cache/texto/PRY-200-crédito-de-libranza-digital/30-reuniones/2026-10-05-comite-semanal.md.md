<!-- origen: PRY-200-crédito-de-libranza-digital/30-reuniones/2026-10-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Crédito de libranza digital

**Fecha:** 2026-10-05
**Asistentes:** Gustavo Neira, Elena Duarte

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 31 | por definir |
