<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-09-23-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-09-23
**Gerente:** Gustavo Neira

## Estado declarado

**Amarillo**

Avance reportado: **44%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se recibió el concepto pendiente del ente supervisor
- Se ajustó el plan de pruebas con el área de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.615.968.219 |
| Ejecutado | 1.362.657.814 |
| Proyección al cierre | 3.286.443.742 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
