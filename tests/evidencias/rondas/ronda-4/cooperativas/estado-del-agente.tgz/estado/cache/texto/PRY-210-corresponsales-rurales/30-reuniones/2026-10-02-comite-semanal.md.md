<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-02-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Corresponsales rurales

**Fecha:** 2026-10-02
**Asistentes:** Liliana Torres, Liliana Torres

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Laura Vélez | Entregar el punto 1 | 2026-10-30 |
