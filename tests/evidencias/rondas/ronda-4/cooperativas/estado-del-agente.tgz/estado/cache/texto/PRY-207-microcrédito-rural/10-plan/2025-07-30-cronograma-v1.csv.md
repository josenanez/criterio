<!-- origen: PRY-207-microcrédito-rural/10-plan/2025-07-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-09-30,2025-09-30,cerrado
Ambiente de pruebas certificado,2025-11-22,2025-11-22,cerrado
Integración con el core cooperativo,2026-01-13,2026-01-13,cerrado
Piloto con asociados,2026-03-07,2026-03-07,cerrado
Salida a producción,2026-04-28,2026-04-28,cerrado
