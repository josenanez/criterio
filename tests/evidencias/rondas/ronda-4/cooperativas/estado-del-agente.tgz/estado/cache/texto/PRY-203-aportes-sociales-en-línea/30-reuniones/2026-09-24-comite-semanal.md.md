<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-09-24
**Asistentes:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-11-08 |
| Sandra Gil | Cerrar la prueba 2 | 2026-10-26 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-25 |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-09-20 |
| Javier Hoyos | Confirmar la fecha 7 | 2026-10-22 |
| Elena Duarte | Entregar el punto 8 | 2026-10-14 |
| Carlos Peña | Enviar el documento 9 | 2026-09-24 |
| Gustavo Neira | Cerrar la prueba 10 | 2026-10-10 |
| Liliana Torres | Revisar el anexo 11 | 2026-10-03 |
| Felipe Arango | Validar el ambiente 12 | 2026-09-29 |
| Mauricio Pérez | Aprobar el diseño 13 | 2026-10-18 |
| María Restrepo | Actualizar la matriz 14 | 2026-09-27 |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-08 |

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «aprobar el diseño 5». No se presentó acta.
