<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-10-04-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Cobranza digital

Código: PRY-211

Área dueña: Ahorro y aportes

Patrocinador: Camilo Beltrán

Gerente de proyecto: Beatriz Cuéllar

Comité: Comité de Tecnología

Producto asociado: recaudos

Fecha de aprobación: 2025-10-04

Objetivo del negocio

Entregar cobranza digital para Ahorro y aportes.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Tecnología el 2025-10-04.

Fechas comprometidas

Fecha

Inicio

2025-10-14

Cierre

2027-06-03

Criterio de éxito

Cobranza digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
