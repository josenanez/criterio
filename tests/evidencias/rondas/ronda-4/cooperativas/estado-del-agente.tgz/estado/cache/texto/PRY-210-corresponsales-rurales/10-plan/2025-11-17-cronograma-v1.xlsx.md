<!-- origen: PRY-210-corresponsales-rurales/10-plan/2025-11-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-20 | 2026-02-20 | cerrado
Ambiente de pruebas certificado | 2026-05-17 | 2026-05-17 | cerrado
Integración con el core cooperativo | 2026-08-11 | 2026-08-11 | cerrado
Piloto con asociados | 2026-11-05 | 2026-11-05 | en curso
Salida a producción | 2027-01-30 | 2027-01-30 | en curso
