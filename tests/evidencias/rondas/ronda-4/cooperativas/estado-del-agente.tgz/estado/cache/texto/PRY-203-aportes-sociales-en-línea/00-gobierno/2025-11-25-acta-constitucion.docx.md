<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-11-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Aportes sociales en línea

Código: PRY-203

Área dueña: Bienestar social

Patrocinador: Elena Duarte

Gerente de proyecto: Ricardo Salas

Comité: Comité de Tecnología

Producto asociado: aportes sociales

Fecha de aprobación: 2025-11-25

Objetivo del negocio

Entregar aportes sociales en línea para Bienestar social.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Tecnología el 2025-11-25.

Fechas comprometidas

Fecha

Inicio

2025-12-05

Cierre

2027-05-30

Criterio de éxito

Aportes sociales en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
