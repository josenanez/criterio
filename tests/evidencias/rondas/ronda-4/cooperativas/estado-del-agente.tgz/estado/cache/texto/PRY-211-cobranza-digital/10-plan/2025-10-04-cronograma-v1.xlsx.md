<!-- origen: PRY-211-cobranza-digital/10-plan/2025-10-04-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-01-30 | 2026-01-30 | cerrado
Ambiente de pruebas certificado | 2026-05-19 | 2026-05-19 | cerrado
Integración con el core cooperativo | 2026-09-04 | 2026-09-04 | cerrado
Piloto con asociados | 2026-12-22 | 2026-12-22 | en curso
Salida a producción | 2027-04-09 | 2027-04-09 | en curso
