<!-- origen: PRY-200-crédito-de-libranza-digital/20-seguimiento/2026-03-07-acta-recibo-ct-451-parametrización-de-líneas-de-crédito.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Parametrización de líneas de crédito
Proyecto: PRY-200 · Crédito de libranza digital
Fecha de recibo: 2026-03-07
Recibido por: Gustavo Neira
Se recibe a satisfacción el entregable Parametrización de líneas de crédito.
Contrato CT-451 · Red Rural de Pagos S.A.S..
