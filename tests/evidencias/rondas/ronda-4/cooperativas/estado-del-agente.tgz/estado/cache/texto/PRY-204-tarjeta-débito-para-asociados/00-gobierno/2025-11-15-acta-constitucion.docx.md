<!-- origen: PRY-204-tarjeta-débito-para-asociados/00-gobierno/2025-11-15-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Tarjeta débito para asociados

Código: PRY-204

Área dueña: Operaciones

Patrocinador: Natalia Ospina

Gerente de proyecto: Elena Duarte

Comité: Comité de Crédito

Producto asociado: tarjeta débito

Fecha de aprobación: 2025-11-15

Objetivo del negocio

Entregar tarjeta débito para asociados para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Crédito el 2025-11-15.

Fechas comprometidas

Fecha

Inicio

2025-11-25

Cierre

2027-02-16

Criterio de éxito

Tarjeta débito para asociados en producción y medido.

Dependencias declaradas

• Ninguna declarada
