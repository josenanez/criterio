<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2026-06-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Apertura de ahorro en línea

Código: PRY-201

Área dueña: Operaciones

Patrocinador: Jorge Medina

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Educación

Producto asociado: ahorro a la vista

Fecha de aprobación: 2026-06-07

Objetivo del negocio

Entregar apertura de ahorro en línea para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Educación el 2026-06-07.

Fechas comprometidas

Fecha

Inicio

2026-06-17

Cierre

2027-05-03

Criterio de éxito

Apertura de ahorro en línea en producción y medido.

Dependencias declaradas

• Ninguna declarada
