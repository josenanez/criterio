<!-- origen: PRY-200-crédito-de-libranza-digital/10-plan/2025-06-22-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-09-10,2025-09-10,cerrado
Ambiente de pruebas certificado,2025-11-20,2025-11-20,cerrado
Integración con el core cooperativo,2026-01-30,2026-01-30,cerrado
Piloto con asociados,2026-04-11,2026-04-11,cerrado
Salida a producción,2026-06-21,2026-06-21,cerrado
