<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/2025-06-20-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Convenios de libranza con empresas

**Código:** PRY-209
**Área dueña:** Cartera y cobranza
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-06-20

## Objetivo del negocio

Entregar convenios de libranza con empresas para Cartera y cobranza.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Tecnología el 2025-06-20.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-30 |
| Cierre | 2026-07-03 |

## Criterio de éxito

Convenios de libranza con empresas en producción y medido.

## Dependencias declaradas

- Ninguna declarada
