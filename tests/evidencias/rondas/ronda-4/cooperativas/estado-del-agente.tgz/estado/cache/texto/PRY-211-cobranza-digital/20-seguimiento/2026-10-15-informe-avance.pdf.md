<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-15
Gerente: Beatriz Cuéllar

Estado declarado
Rojo
Avance reportado: 44%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 4.607.236.341
Ejecutado 3.697.963.264
Proyección al cierre 11.146.984.265

Riesgos abiertos
- Concentración del conocimiento en una sola persona
