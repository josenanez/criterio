<!-- origen: PRY-203-aportes-sociales-en-línea/30-reuniones/2026-09-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Aportes sociales en línea

**Fecha:** 2026-09-03
**Asistentes:** Andrés Lozano, Diana Molina, María Restrepo, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-10-01 |
| Sandra Gil | Cerrar la prueba 2 | 2026-09-18 |
| Diana Molina | Revisar el anexo 3 | 2026-09-30 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-18 |
