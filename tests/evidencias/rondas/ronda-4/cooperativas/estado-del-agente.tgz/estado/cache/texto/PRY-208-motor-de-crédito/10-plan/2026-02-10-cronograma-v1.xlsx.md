<!-- origen: PRY-208-motor-de-crédito/10-plan/2026-02-10-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-04-30 | 2026-04-30 | cerrado
Ambiente de pruebas certificado | 2026-07-08 | 2026-07-08 | cerrado
Integración con el core cooperativo | 2026-09-16 | 2026-09-16 | cerrado
Piloto con asociados | 2026-11-24 | 2026-11-24 | en curso
