<!-- origen: PRY-206-pagos-con-qr/00-gobierno/2025-10-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Pagos con QR

**Código:** PRY-206
**Área dueña:** Servicio al asociado
**Patrocinador:** Diana Molina
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Tecnología
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2025-10-30

## Objetivo del negocio

Entregar pagos con qr para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Tecnología el 2025-10-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-09 |
| Cierre | 2027-02-11 |

## Criterio de éxito

Pagos con QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
