<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/2025-11-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Corresponsales rurales

Código: PRY-210

Área dueña: Operaciones

Patrocinador: Liliana Torres

Gerente de proyecto: Liliana Torres

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2025-11-17

Objetivo del negocio

Entregar corresponsales rurales para Operaciones.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Tecnología el 2025-11-17.

Fechas comprometidas

Fecha

Inicio

2025-11-27

Cierre

2027-03-14

Criterio de éxito

Corresponsales rurales en producción y medido.

Dependencias declaradas

• Ninguna declarada
