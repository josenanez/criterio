<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Cobranza digital

Fecha: 2026-10-14

Asistentes: Beatriz Cuéllar, Camilo Beltrán

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Mauricio Pérez

Entregar el punto 9

2026-10-16
