<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2026-10-12-cronograma-v2.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-05-08,2026-05-08,cerrado
Ambiente de pruebas certificado,2026-10-10,2026-10-10,en curso
Integración con el core cooperativo,2027-03-13,2027-07-06,en curso
