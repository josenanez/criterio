<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-203",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "name": {
 "value": "Aportes sociales en línea",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Bienestar social",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "product": {
 "value": "aportes sociales",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Elena Duarte",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "manager": {
 "value": "Ricardo Salas",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Tecnología",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 44,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-12",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 "plan": {
 "start_date": {
 "value": "2025-12-05",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "end_date": {
 "value": "2027-05-30",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-11-25",
 "start_date": "2025-12-05",
 "end_date": "2027-05-30",
 "reason": "Acta de constitución",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Diseño funcional aprobado",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-05-08",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-05-08",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-10-12-cronograma-v2.csv"
 },
 {
 "name": {
 "value": "Ambiente de pruebas certificado",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-10-10",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "current_date": {
 "value": "2026-10-10",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-10-12-cronograma-v2.csv"
 },
 {
 "name": {
 "value": "Integración con el core cooperativo",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "baseline_date": {
 "value": "2027-03-13",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "current_date": {
 "value": "2027-07-06",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "10-plan/2026-10-12-cronograma-v2.csv",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "evidence": {
 "value": null
 },
 "source": "10-plan/2026-10-12-cronograma-v2.csv"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "source_date": "2025-11-25",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "approved": {
 "value": 2400000000,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "committed": {
 "value": 732174098,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "executed": {
 "value": 473118382,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 },
 "projection": {
 "value": 2833558895,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_date": "2026-10-12",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Dependencia del proveedor del core cooperativo",
 "owner": null,
 "registered": true,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "source_kind": "declaration"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase",
 "owner": null,
 "registered": false,
 "source": "2026-10-15-notas-reunion.txt",
 "note": "Comentado en la reunión; nadie lo anotó como riesgo"
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "Hallazgo de seguridad en la revisión de arquitectura",
 "since": "no_declarada",
 "owner": null,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 },
 {
 "what": "Rotación de un desarrollador clave: el equipo perdió dos semanas",
 "since": "no_declarada",
 "owner": null,
 "source": "20-seguimiento/2026-10-12-informe-avance.pdf"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": {
 "value": "CC-01"
 },
 "requested_on": {
 "value": "2026-10-04"
 },
 "scope_impact": {
 "value": "Ampliación de alcance"
 },
 "time_impact": {
 "value": "+115 días sobre la línea base vigente"
 },
 "cost_impact": {
 "value": "230.000.000 COP adicionales"
 },
 "decision": {
 "value": "pending"
 },
 "decided_by": {
 "value": null
 },
 "source": "20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Enviar el documento 1"
 },
 "due_date": {
 "value": "2026-12-11"
 },
 "original_due_date": {
 "value": "2026-10-01"
 },
 "stated_on": {
 "value": "2026-09-03"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-11",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ],
 "note": "Última fecha: las notas del 2026-10-15 dicen «11/12/2026»; se leyó día/mes/año (11 de diciembre). Si fuera 12 de noviembre sería una fecha anterior a la de la semana pasada."
 },
 {
 "who": {
 "value": "Sandra Gil"
 },
 "what": {
 "value": "Cerrar la prueba 2"
 },
 "due_date": {
 "value": "2026-11-28"
 },
 "original_due_date": {
 "value": "2026-09-18"
 },
 "stated_on": {
 "value": "2026-09-03"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-07",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-28",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina"
 },
 "what": {
 "value": "Revisar el anexo 3"
 },
 "due_date": {
 "value": "2026-09-30"
 },
 "original_due_date": {
 "value": "2026-09-30"
 },
 "stated_on": {
 "value": "2026-09-03"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-17-acta-recibo-3.md"
 }
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Validar el ambiente 4"
 },
 "due_date": {
 "value": "2026-09-25"
 },
 "original_due_date": {
 "value": "2026-09-18"
 },
 "stated_on": {
 "value": "2026-09-03"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-09-25",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-01-acta-recibo-4.md"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Aprobar el diseño 5"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-09-10"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«Por definir» el 2026-09-10 y 2026-09-17; el 2026-09-24 salió de la tabla y Mauricio dijo que ya lo entregó, sin acta de recibo: no se da por cumplido."
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Actualizar la matriz 6"
 },
 "due_date": {
 "value": "2026-10-28"
 },
 "original_due_date": {
 "value": "2026-09-20"
 },
 "stated_on": {
 "value": "2026-09-10"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "La fecha 2026-09-20 siguió en la tabla del 24-sep y del 01-oct sin cambio, ya vencida; el 08-oct se volvió a prometer."
 },
 {
 "who": {
 "value": "Javier Hoyos"
 },
 "what": {
 "value": "Confirmar la fecha 7"
 },
 "due_date": {
 "value": "2026-10-22"
 },
 "original_due_date": {
 "value": "2026-10-08"
 },
 "stated_on": {
 "value": "2026-09-10"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-01-acta-recibo-7.md"
 }
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Entregar el punto 8"
 },
 "due_date": {
 "value": "2026-11-03"
 },
 "original_due_date": {
 "value": "2026-09-28"
 },
 "stated_on": {
 "value": "2026-09-10"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Enviar el documento 9"
 },
 "due_date": {
 "value": "2026-10-09"
 },
 "original_due_date": {
 "value": "2026-09-24"
 },
 "stated_on": {
 "value": "2026-09-17"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Gustavo Neira"
 },
 "what": {
 "value": "Cerrar la prueba 10"
 },
 "due_date": {
 "value": "2026-10-24"
 },
 "original_due_date": {
 "value": "2026-10-10"
 },
 "stated_on": {
 "value": "2026-09-17"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-10.md"
 }
 },
 {
 "who": {
 "value": "Liliana Torres"
 },
 "what": {
 "value": "Revisar el anexo 11"
 },
 "due_date": {
 "value": "2026-10-21"
 },
 "original_due_date": {
 "value": "2026-10-03"
 },
 "stated_on": {
 "value": "2026-09-17"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "note": "«Por definir» el 2026-09-17; la primera fecha (2026-10-03) llegó el 2026-09-24 y no cuenta como reprogramación."
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Validar el ambiente 12"
 },
 "due_date": {
 "value": "2026-10-08"
 },
 "original_due_date": {
 "value": "2026-09-29"
 },
 "stated_on": {
 "value": "2026-09-17"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-12.md"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Aprobar el diseño 13"
 },
 "due_date": {
 "value": "2026-10-31"
 },
 "original_due_date": {
 "value": "2026-10-18"
 },
 "stated_on": {
 "value": "2026-09-24"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Actualizar la matriz 14"
 },
 "due_date": {
 "value": "2026-09-27"
 },
 "original_due_date": {
 "value": "2026-09-27"
 },
 "stated_on": {
 "value": "2026-09-24"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 "state": {
 "value": "met"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-14.md"
 }
 },
 {
 "who": {
 "value": "Mauricio Pérez"
 },
 "what": {
 "value": "Confirmar la fecha 15"
 },
 "due_date": {
 "value": "2026-10-22"
 },
 "original_due_date": {
 "value": "2026-10-22"
 },
 "stated_on": {
 "value": "2026-09-24"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Entregar el punto 16"
 },
 "due_date": {
 "value": "2026-10-21"
 },
 "original_due_date": {
 "value": "2026-10-08"
 },
 "stated_on": {
 "value": "2026-09-24"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Andrés Lozano"
 },
 "what": {
 "value": "Enviar el documento 17"
 },
 "due_date": {
 "value": "2026-11-12"
 },
 "original_due_date": {
 "value": "2026-10-24"
 },
 "stated_on": {
 "value": "2026-10-01"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-12",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Cerrar la prueba 18"
 },
 "due_date": {
 "value": "2026-10-19"
 },
 "original_due_date": {
 "value": "2026-10-19"
 },
 "stated_on": {
 "value": "2026-10-01"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisar el anexo 19"
 },
 "due_date": {
 "value": "2026-11-10"
 },
 "original_due_date": {
 "value": "2026-10-21"
 },
 "stated_on": {
 "value": "2026-10-01"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango"
 },
 "what": {
 "value": "Validar el ambiente 20"
 },
 "due_date": {
 "value": "2026-10-05"
 },
 "original_due_date": {
 "value": "2026-10-05"
 },
 "stated_on": {
 "value": "2026-10-01"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 "state": {
 "value": "overdue"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña"
 },
 "what": {
 "value": "Aprobar el diseño 21"
 },
 "due_date": {
 "value": "2026-11-05"
 },
 "original_due_date": {
 "value": "2026-11-05"
 },
 "stated_on": {
 "value": "2026-10-08"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "María Restrepo"
 },
 "what": {
 "value": "Actualizar la matriz 22"
 },
 "due_date": {
 "value": "2026-10-27"
 },
 "original_due_date": {
 "value": "2026-10-27"
 },
 "stated_on": {
 "value": "2026-10-08"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Elena Duarte"
 },
 "what": {
 "value": "Confirmar la fecha 23"
 },
 "due_date": {
 "value": "2026-10-30"
 },
 "original_due_date": {
 "value": "2026-10-30"
 },
 "stated_on": {
 "value": "2026-10-08"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Entregar el punto 24"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-10-08"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "«Por definir» en la minuta del 2026-10-08."
 },
 {
 "who": {
 "value": "Laura Vélez"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto"
 },
 "due_date": {
 "value": "no_declarada"
 },
 "original_due_date": {
 "value": "no_declarada"
 },
 "stated_on": {
 "value": "2026-10-15"
 },
 "source": {
 "value": "2026-10-15-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Dicho como «la otra semana»; no es una fecha y no se calculó."
 },
 {
 "who": {
 "value": "Óscar Ramírez"
 },
 "what": {
 "value": "Revisión con el proveedor"
 },
 "due_date": {
 "value": "2026-10-25"
 },
 "original_due_date": {
 "value": "2026-10-25"
 },
 "stated_on": {
 "value": "2026-10-15"
 },
 "source": {
 "value": "2026-10-15-notas-reunion.txt"
 },
 "state": {
 "value": "open"
 },
 "reschedules": [],
 "note": "Sin número en las notas; no se asimiló a los compromisos 6, 19 ni 24."
 }
 ],
 "activity": {
 "last_document_date": {
 "value": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "last_meeting_date": {
 "value": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 }
 },
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [
 {
 "path": "00-gobierno/2025-11-25-acta-constitucion.docx",
 "hash": "0fdfc29fe3603635535a19922809afdc2912c37c20fcd783c451e3d982378b11",
 "text_hash": null,
 "date": "2025-11-25"
 },
 {
 "path": "10-plan/2025-11-25-cronograma-v1.xlsx",
 "hash": "9c0ed6f929dd3e34c4ad368ef5753d31227d66990e1bbc608c5c20c6de4fdd25",
 "text_hash": null,
 "date": "2025-11-25"
 },
 {
 "path": "10-plan/2026-10-12-cronograma-v2.csv",
 "hash": "d5eea45b02046176284544aeb5424455f90d95198d85060996073d5a214199cb",
 "text_hash": null,
 "date": "2026-10-12"
 },
 {
 "path": "20-seguimiento/2026-09-17-acta-recibo-3.md",
 "hash": "c0423b2e03fe41de5a60c1be8f0f706e796aaf51150c43e6ddc3e8e0065037f2",
 "text_hash": null,
 "date": "2026-09-17"
 },
 {
 "path": "20-seguimiento/2026-10-01-acta-recibo-4.md",
 "hash": "93e0463c190ad3a523ae9c9bb62e7970a2418598a11cbec4099a9617984675f6",
 "text_hash": null,
 "date": "2026-10-01"
 },
 {
 "path": "20-seguimiento/2026-10-01-acta-recibo-7.md",
 "hash": "2fc9d6cca0e5b9d9112a389bbb2c459fce7760cfb271286021b312b68b443638",
 "text_hash": null,
 "date": "2026-10-01"
 },
 {
 "path": "20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md",
 "hash": "009f901ea2eb0cef9ce8e8cc571dbd3f25f82bef2ee31c3124c8c9a608052082",
 "text_hash": null,
 "date": "2026-10-04"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-10.md",
 "hash": "ce3a2dec4c8c2829a024d7cefe7e6dd00980bce7652011d0e002c3e5e32b22cf",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-12.md",
 "hash": "eb81785aa6dba941d1c54ccd0c76f2bb47423613ebe031cad98025ff9e2385a0",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-08-acta-recibo-14.md",
 "hash": "090748aedde6b3798cd21d8491df72a37c44dc8eb11beceee1d638851fab28ac",
 "text_hash": null,
 "date": "2026-10-08"
 },
 {
 "path": "20-seguimiento/2026-10-12-informe-avance.pdf",
 "hash": "1aa952a007877cd37393cb9ed786481b577346096cc0fb3338b07c02710080b5",
 "text_hash": null,
 "date": "2026-10-12"
 },
 {
 "path": "2026-10-15-notas-reunion.txt",
 "hash": "06edb59d2ec8b95f867b83e4cb609817bc6031a13339ff01c9e7a373a4ccd18b",
 "text_hash": null,
 "date": "2026-10-15"
 },
 {
 "path": "30-reuniones/2026-09-03-comite-semanal.md",
 "hash": "fd899f73f5e8cf2c586e62fc6b47382c92f06e5b8430e7bbb42ef2c762892d8e",
 "text_hash": null,
 "date": "2026-09-03"
 },
 {
 "path": "30-reuniones/2026-09-10-comite-semanal.md",
 "hash": "017832c47bab2b7776c0e717713ef01ba9196dcd2ab52381ccd1f43a4ffe8719",
 "text_hash": null,
 "date": "2026-09-10"
 },
 {
 "path": "30-reuniones/2026-09-17-comite-semanal.md",
 "hash": "9b9741d2c2b9b51510d568683f005b17c5a3368f1d4430ba08c6b37ab73dd7ec",
 "text_hash": null,
 "date": "2026-09-17"
 },
 {
 "path": "30-reuniones/2026-09-24-comite-semanal.md",
 "hash": "7fd7e4b08c9ccf63411517575f6dd242b54b63e8f79755568c7ce76d4c740388",
 "text_hash": null,
 "date": "2026-09-24"
 },
 {
 "path": "30-reuniones/2026-10-01-comite-semanal.md",
 "hash": "eea5fcc17c8fb4b6a69bc5d5637bc49fce517896eb74b0b29f5ec42d398657c1",
 "text_hash": null,
 "date": "2026-10-01"
 },
 {
 "path": "30-reuniones/2026-10-08-comite-semanal.md",
 "hash": "93ceed961eafba96f35d5fc4144d8496c36dd830d9efe60cd704ffeab9e2bb89",
 "text_hash": null,
 "date": "2026-10-08"
 }
 ],
 "fields_not_found": [
 "identity.authority",
 "identity.phase",
 "vendors"
 ],
 "open_conflicts": [],
 "coverage": "Leídas 7 reuniones (6 minutas 2026-09-03 a 2026-10-08 y las notas del 2026-10-15), 6 actas de recibo, acta de constitución, cronogramas v1 y v2, informe de avance y CC-01. No sellada: se leyeron reuniones, no el proyecto entero."
 }
}
