<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-01-19-acta-recibo-ct-315-bolsa-de-horas-de-desarrollo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Bolsa de horas de desarrollo
Proyecto: PRY-207 · Microcrédito rural
Fecha de recibo: 2026-01-19
Recibido por: Laura Vélez
Se recibe a satisfacción el entregable Bolsa de horas de desarrollo.
Contrato CT-315 · Red Rural de Pagos S.A.S..
