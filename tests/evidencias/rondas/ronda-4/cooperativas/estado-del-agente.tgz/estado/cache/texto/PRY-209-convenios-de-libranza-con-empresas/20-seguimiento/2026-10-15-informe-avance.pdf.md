<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Convenios de libranza con empresas
Código: PRY-209
Fecha de corte: 2026-10-15
Gerente: Camilo Beltrán

Estado declarado
Verde
Avance reportado: 86%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.356.863.587
Ejecutado 1.236.476.942
Proyección al cierre 3.462.920.072

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
