<!-- origen: PRY-203-aportes-sociales-en-línea/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Aportes sociales en línea
Código: PRY-203
Fecha de corte: 2026-10-12
Gerente: Ricardo Salas

Estado declarado
Amarillo
Avance reportado: 44%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 732.174.098
Ejecutado 473.118.382
Proyección al cierre 2.833.558.895

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
