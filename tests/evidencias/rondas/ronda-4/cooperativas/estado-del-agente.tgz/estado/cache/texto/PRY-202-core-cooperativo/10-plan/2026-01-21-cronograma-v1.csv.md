<!-- origen: PRY-202-core-cooperativo/10-plan/2026-01-21-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-04-25,2026-04-25,cerrado
Ambiente de pruebas certificado,2026-07-19,2026-07-19,cerrado
Integración con el core cooperativo,2026-10-12,2026-10-12,en curso
Piloto con asociados,2027-01-04,2027-01-04,en curso
