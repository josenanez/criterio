<!-- origen: PRY-207-microcrédito-rural/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Crédito · Microcrédito rural

**Fecha:** 2026-10-15
**Asistentes:** Laura Vélez, Óscar Ramírez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Gustavo Neira | Entregar el punto 4 | 2026-10-14 |
