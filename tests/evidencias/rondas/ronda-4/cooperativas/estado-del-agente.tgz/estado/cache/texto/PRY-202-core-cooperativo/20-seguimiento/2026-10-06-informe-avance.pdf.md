<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core cooperativo
Código: PRY-202
Fecha de corte: 2026-10-06
Gerente: Ricardo Salas

Estado declarado
Verde
Avance reportado: 36%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 5.158.209.584
Ejecutado 7.936.946.387
Proyección al cierre 16.634.260.450

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
- El proveedor no ha confirmado la fecha de la última entrega
