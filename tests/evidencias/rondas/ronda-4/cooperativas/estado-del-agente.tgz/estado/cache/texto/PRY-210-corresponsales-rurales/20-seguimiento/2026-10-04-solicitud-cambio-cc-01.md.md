<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Corresponsales rurales
**Fecha:** 2026-10-04
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +84 días sobre la línea base vigente |
| Costo | 168.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
