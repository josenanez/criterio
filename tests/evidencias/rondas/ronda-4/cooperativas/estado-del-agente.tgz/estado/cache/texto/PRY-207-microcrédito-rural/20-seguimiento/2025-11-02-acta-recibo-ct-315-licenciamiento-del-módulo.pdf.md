<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2025-11-02-acta-recibo-ct-315-licenciamiento-del-módulo.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de recibo · Licenciamiento del módulo
Proyecto: PRY-207 · Microcrédito rural
Fecha de recibo: 2025-11-02
Recibido por: Laura Vélez
Se recibe a satisfacción el entregable Licenciamiento del módulo.
Contrato CT-315 · Red Rural de Pagos S.A.S..
