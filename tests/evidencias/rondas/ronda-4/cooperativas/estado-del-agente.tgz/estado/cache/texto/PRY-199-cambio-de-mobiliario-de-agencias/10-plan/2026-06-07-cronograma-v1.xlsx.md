<!-- origen: PRY-199-cambio-de-mobiliario-de-agencias/10-plan/2026-06-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-10-04 | 2026-10-04 | cerrado
Ambiente de pruebas certificado | 2027-01-21 | 2027-01-21 | en curso
Integración con el core cooperativo | 2027-05-10 | 2027-05-10 | en curso
Piloto con asociados | 2027-08-27 | 2027-08-27 | en curso
Salida a producción | 2027-12-14 | 2027-12-14 | en curso
