## Reunión de seguimiento — PRY-203 Aportes sociales en línea · 2026-10-22 (jueves)
8 puntos · 55 minutos · 11 personas requeridas

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir.
Notas de partida: no indicaste un límite de minutos; la suma es 55 y no se cortó nada. Es la primera corrida (no hay foto previa para comparar), así que «lo que cambió» sale de las actas y del cálculo del 2026-10-15. Ojo: las notas del 10-15 dicen «próxima reunión en dos semanas» (≈ 10-29), y la configuración dice semanal, jueves 10-22. Esta agenda asume el 10-22; ver punto 7.

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1» y fijar una fecha que se sostenga** · 10 min · **María Restrepo, con Elena Duarte (patrocinadora)**
> Prometido para el 2026-12-11, y antes 11-27, 11-20, 11-08, 10-28, 10-20, y originalmente 10-01. Seis reprogramaciones, ~71 días corridos desde la primera promesa.
> Antes de la sala: confirmar con María si «11/12/2026» es 11 de diciembre (se leyó día/mes/año); si fuera 12 de noviembre, sería anterior a la fecha de la semana pasada.
> Fuente: 30-reuniones/2026-09-03-comite-semanal.md (promesa) … 30-reuniones/2026-10-08-comite-semanal.md y 2026-10-15-notas-reunion.txt (última fecha)
> **Si no se resuelve hoy:** el documento seguirá corriéndose cada semana; el expediente no dice qué depende de él ni qué bloquea.

> **[2] Qué impide «Cerrar la prueba 2» y cómo se destraba** · 10 min · **Sandra Gil, Felipe Arango**
> Prometido para el 2026-11-28, y antes 11-07, 10-26, 10-14 (pasó sin cierre), 10-07, y originalmente 09-18. Cinco reprogramaciones. El hito «Ambiente de pruebas certificado» (plan 2026-10-10) sigue sin evidencia, vencido hace 12 días a la fecha de la reunión. No se afirma que estén conectados; ningún documento los une, y eso es parte de lo que hay que preguntar.
> Fuente: 30-reuniones/2026-09-03-comite-semanal.md … 2026-10-08-comite-semanal.md; 10-plan/2026-10-12-cronograma-v2.csv
> **Si no se resuelve hoy:** el hito sigue vencido y la fecha de integración con el core (ya en 2027-07-06 vs 2027-03-13 de línea base) no tiene base para sostenerse.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Felipe Arango | Validar el ambiente 20 | 2026-10-05 (17 días al 10-22) | Acta de recibo o nueva fecha dicha con su motivo | 5 |
| Carlos Peña | Enviar el documento 9 | 2026-10-09, antes 09-24 (13 días) | Entrega o fecha; ya se movió una vez | 5 |

Fuente: 30-reuniones/2026-10-08-comite-semanal.md; no hay acta de recibo en 20-seguimiento/ para ninguno.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **Presentación de CC-01** (ampliación de alcance, +115 días, +230.000.000 COP), «pendiente de presentación al comité» desde el 2026-10-04 | Por confirmar: la ficha no tiene `authority`; Elena Duarte es la patrocinadora | Sigue sin decisión mientras el costo proyectado ya va 18,1 % sobre lo aprobado y el plan no tiene línea base nueva | 10 |
| **Fecha y cadencia del próximo comité** (¿10-22 o ~10-29?) | Ricardo Salas | Las fechas del 10-21 y 10-22 (Liliana Torres, Andrés Lozano, Mauricio Pérez) se quedan sin revisión | 3 |
| **Fecha para los tres compromisos sin fecha**: Laura Vélez (ajuste del presupuesto, «la otra semana»), Mauricio Pérez (Aprobar el diseño 5, desde 2026-09-10; dijo «ya lo entregó», sin acta de recibo), Óscar Ramírez (Entregar el punto 24, desde 2026-10-08) | Cada doliente, en la sala | No pueden vencer, y por eso nadie los verá fallar | 5 |
| **Dueño para lo que no lo tiene**: hallazgo de seguridad de la revisión de arquitectura; rotación del desarrollador clave; riesgo «el proveedor podría no llegar con el equipo completo» (comentado el 10-15, nadie lo anotó) | Ricardo Salas | Tres puntos abiertos sin responsable, y el tercero ni siquiera está registrado | 4 |

Fuente: 20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md; 20-seguimiento/2026-10-12-informe-avance.pdf; 2026-10-15-notas-reunion.txt; 30-reuniones/2026-10-08-comite-semanal.md.

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 (ya pasó en la fecha de la reunión; confirmar cierre) |
| Liliana Torres | Revisar el anexo 11 | 2026-10-21 (antes 10-03) |
| Andrés Lozano | Entregar el punto 16 | 2026-10-21 (antes 10-08) |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 (domingo; vence antes de la próxima si la cadencia es de dos semanas) |

Tiempo: 3 min, solo para confirmar que llegan; si alguno no llega, pasa a «Vencido» en la siguiente.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Quién tiene la facultad de aprobar CC-01 y la base nueva del plan | La ficha no trae `authority`; no se puede afirmar que la sala lo decida | Confirmar con Ricardo Salas; si excede su autoridad, `/pm-escalate` y material de comité |
| Hito «Diseño funcional aprobado» declarado cumplido sin evidencia | Es de verificación documental, no de la sala | Pedir el documento de aprobación; se verá en `/pm-report` |
| Estado «amarillo» del informe del 10-12 | Con dos reprogramados sobre el umbral, dos vencidos, un hito vencido y 18,1 % de costo, el informe no recoge compromisos entre sus señales | La declaración la hace el gerente; `/pm-report` |

### Anexo — sin cambios desde el 2026-10-15
Sin foto previa, el anexo es lo abierto con fecha futura y sin movimientos; no se repasa:
- Óscar Ramírez: matriz 6 al 10-28 (prometida originalmente 09-20), anexo 19 al 11-10
- Elena Duarte: confirmar la fecha 23 al 10-30; punto 8 al 11-03 (2 reprogramaciones)
- María Restrepo: matriz 22 al 10-27
- Mauricio Pérez: diseño 13 al 10-31
- Carlos Peña: diseño 21 al 11-05
- Andrés Lozano: documento 17 al 11-12

### Después
Convocar es tuyo. Tras la reunión, `/pm-minutes` sobre las notas o la transcripción, y los compromisos nuevos entran a `/pm-commitments` con su cita.
