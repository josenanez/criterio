# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 55 s · 10 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_undated` | 3 |
| `commitment_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `milestone_met_without_evidence` | 1 |
| `variance_cost` | 1 |

Paquete de decisión sobre CC-01; el acta no declara la autoridad del gerente (primer punto). El impacto dio 0 proyectos alcanzados porque el estado tiene un solo proyecto, no porque nadie dependa. No se supo si la proyección incluye CC-01, ni si el cronograma v2 ya incorpora los +115 días.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-203 Aportes sociales en línea · 2026-10-15

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir. No indicaste qué escalar: tomé lo ya marcado como escalable en la ficha (CC-01 «pendiente de presentación al comité» desde el 2026-10-04).

### Primer punto, antes del que venías a subir: el acta no declara la autoridad del gerente

El acta de constitución (2025-11-25) nombra patrocinadora (Elena Duarte), gerente (Ricardo Salas) y comité (Comité de Tecnología), y dice que ese comité aprobó el presupuesto de 2.400.000.000 COP. **No dice qué puede decidir el gerente ni quién aprueba cambios de alcance, tiempo o costo.** Sin eso no puedo afirmar que CC-01 exceda tu autoridad, ni a quién va dirigido sin que se devuelva.

### ¿Se aprueba CC-01 (ampliación de alcance, +115 días, +230.000.000 COP) en el Comité de Tecnología del 2026-10-22, o se rechaza y se conserva la línea base (cierre 2027-05-30, 2.400.000.000 COP)?

**Quién decide:** no está declarado en el acta. Lo que el acta sí muestra: el Comité de Tecnología aprobó el presupuesto original; por eso lo razonable es llevarlo allí, con la patrocinadora Elena Duarte. Es una inferencia, no una cita: que el comité confirme en la misma sesión que tiene la facultad. · **Si no se decide hoy:** ningún documento fija una fecha límite (no hay oferta de proveedor ni vencimiento citado), y no la invento. Lo que sí tiene fecha: la próxima ocasión es el comité del 2026-10-22 según la configuración (las notas del 10-15 dicen «próxima reunión en dos semanas», ≈10-29: confirmar cuál); el hito «Ambiente de pruebas certificado» venció el 2026-10-10 sin evidencia; y mientras CC-01 siga pendiente, el plan v2 ya opera con una fecha que la línea base no tiene (ver abajo).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliado; la solicitud no dice qué se agrega | Cierre 2027-05-30 → 2027-09-22 (+115 días) | 2.630.000.000 COP (+230.000.000). La proyección del informe (2.833.558.895) queda 203.558.895 por encima de eso, salvo que ya incluya CC-01: no lo dice |
| B. Rechazar CC-01 | El original (3 componentes) | Cierre 2027-05-30, pero el plan v2 ya pone «Integración con el core» en 2027-07-06, después de ese cierre | 2.400.000.000 COP; la proyección ya va 433.558.895 (18,1 %) sobre lo aprobado, y eso queda sin decidir |
| C. Devolver CC-01 para completarla y decidir el 2026-10-22 o 10-29 | Se define qué se agrega | Sin cambio hasta decidir | Se separa qué parte de la proyección es CC-01 y cuál es sobrecosto previo |

**Recomiendo:** C — CC-01 no describe qué alcance agrega ni dice si los 230.000.000 están dentro de la proyección de 2.833.558.895; sin eso el comité aprobaría o rechazaría a ciegas. Se pide completar antes del 10-22 y llevar en esa sesión también la pregunta de quién tiene la facultad.

### A quién alcanza
| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno aparece | — | — | — |

El cálculo (`impact`, +115 días) no encontró otros proyectos alcanzados, pero eso solo significa que **este estado tiene un proyecto y el acta declara «Ninguna declarada» en dependencias**. No prueba que nadie dependa de este: el informe cita «dependencia del proveedor del core cooperativo» y el acta excluye «lo que otro proyecto cubre» sin nombrarlo. Esa dependencia nunca se confirmó con el otro lado. Tampoco se calculan días que se mueve cada proyecto alcanzado: necesita holgura por actividad y la ficha no la tiene.

### Mis hitos por los que pasa
| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Integración con el core cooperativo | 2027-07-06 (línea base 2027-03-13) | 264 días desde hoy |

Ojo: la fecha vigente ya está 115 días después de la línea base (2027-03-13 → 2027-07-06), exactamente lo que pide CC-01, y CC-01 no está aprobada ni la línea base tiene versión 2. Ningún documento dice que el cronograma v2 incorpore CC-01; si lo hace, el plan ya se movió sin la decisión. Si no, hay un segundo atraso de 115 días aparte. Hay que preguntarlo a Ricardo Salas antes del comité. Y si CC-01 se aprueba con esta fecha como punto de partida, el cambio se contaría dos veces.

### Lo que sube pero no se puede formular todavía
- «Enviar el documento 1» (María Restrepo): 6 reprogramaciones, última al 2026-12-11. «Cerrar la prueba 2» (Sandra Gil): 5, última al 2026-11-28. Pasan el umbral de 3, pero sin saber qué las bloquea no se puede armar una pregunta cerrada. Primero la llamada; si el doliente está fuera del proyecto, entonces escala.
- No escalan, son del gerente: dueño para el hallazgo de seguridad, la rotación del desarrollador clave y el riesgo no registrado del equipo del proveedor (comentado el 10-15, nadie lo anotó).

### De dónde sale esto
- Autoridad no declarada, comité, patrocinadora, presupuesto, cierre 2027-05-30, «Ninguna declarada» en dependencias: `00-gobierno/2025-11-25-acta-constitucion.docx`.
- CC-01 (alcance ampliado, +115 días, 230.000.000 COP, pendiente de presentación al comité): `20-seguimiento/2026-10-04-solicitud-cambio-cc-01.md`.
- Aprobado, comprometido, ejecutado y proyección; riesgo de dependencia del proveedor: `20-seguimiento/2026-10-12-informe-avance.pdf`.
- Hitos y fechas de línea base/vigente: `10-plan/2026-10-12-cronograma-v2.csv`.
- Comité semanal los jueves, próximo 2026-10-22: `.criterio/proyecto/PRY-203/config.json`; «próxima reunión en dos semanas» y riesgo del proveedor: `2026-10-15-notas-reunion.txt`.
- Reprogramaciones: `30-reuniones/` (2026-09-03 a 2026-10-08) y `2026-10-15-notas-reunion.txt`.
- Cálculo de impacto: `portafolio.py impact --days 115` (cierre 2027-09-22; un hito alcanzado; 0 proyectos).

Esto es un paquete: no lo lleva nadie al comité ni le escribe a nadie; eso es tuyo.
