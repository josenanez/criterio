# Plan — PRY-203 Aportes sociales en línea · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-11-25 (`00-gobierno/2025-11-25-acta-constitucion.docx`) · **Criterio de éxito:** «Aportes sociales en línea en producción y medido» (acta). No trae métrica ni umbral: ver abajo.

> Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-15 (versión 1.1, familia 0.3.10); no hizo falta registrarlos de nuevo.
> Respuestas sugeridas tomadas sin preguntar (sesión sin interfaz): se pidió el borrador completo desde el acta, sin argumento de archivo.

**Una cosa antes del plan:** esto se pide como «primer borrador», pero el acta tiene 10 meses y el proyecto ya está en ejecución (inicio comprometido 2025-12-05; avance declarado 44 % el 2026-10-12). Ya existen un cronograma v1 (2025-11-25) y un v2 (2026-10-12). Este borrador se construye desde el acta, como pide el comando, y usa los cronogramas solo como referencia citada. No los reemplaza.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido**: la sección dice «Componente 1, Componente 2, Componente 3», sin nombres ni descripción | No se puede descomponer por entregable: tres nodos de la WBS quedan sin definir. Cualquier cambio de alcance (CC-01 pide una «ampliación») se mide contra nada. |
| **Fuera de alcance vacío en la práctica**: «Lo que otro proyecto cubre», sin decir cuál proyecto ni qué | No se sabe dónde termina este proyecto; el solapamiento con el otro proyecto es invisible. |
| **Objetivo tautológico**: «Entregar aportes sociales en línea para Bienestar social» | No agrega nada al nombre del proyecto; no dice qué cambia para el negocio. |
| **Criterio de éxito sin métrica**: «en producción y medido» no dice qué se mide, con qué meta ni quién lo mide | «Medido» no se puede aceptar ni rechazar. Es el entregable final y nadie sabría cerrarlo. |
| **Sin autoridad declarada** (también en la ficha: `identity.authority`, no encontrado) | No se sabe qué puede decidir el gerente al planificar y qué debe subir al comité. |
| **Dependencias: «Ninguna declarada»**, pero el informe del 2026-10-12 lista como riesgo abierto la «Dependencia del proveedor del core cooperativo», y el cronograma tiene un hito «Integración con el core cooperativo» | El acta y el informe se contradicen. Un plan que herede «sin dependencias» esconde la más grande. |
| **Sin proveedor ni contrato citado** (la ficha tiene `vendors` vacío) | No hay duración contractual citable para ningún nodo que dependa del proveedor. |
| Patrocinador: **sí está** (Elena Duarte); comité: **sí está** (Comité de Tecnología); presupuesto: **sí está** (2.400.000.000 COP) | — |

## WBS
Los tres estados son: *del acta* (escrito, con cita), *supuesto* (lo asumo yo) y *sin definir* (nadie lo ha dicho; no lo completo).

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | **sin definir** — el acta lo nombra y no lo describe | — |
| 2 | Componente 2 | sin definir | **sin definir** — ídem | — |
| 3 | Componente 3 | sin definir | **sin definir** — ídem | — |
| 4 | Diseño funcional aprobado | sin definir | **supuesto** — hito del cronograma v1/v2 (cerrado, 2026-05-08); no está en el acta. No vi acta de recibo que lo respalde. | — |
| 5 | Ambiente de pruebas certificado | sin definir | **supuesto** — hito del cronograma v1/v2 (2026-10-10, «en curso»; ya pasó la fecha); no está en el acta | — |
| 6 | Integración con el core cooperativo | sin definir | **supuesto** — hito del cronograma v1/v2; no está en el acta | — |
| 7 | Aportes sociales en línea en producción | sin definir (el acta nombra al patrocinador, no dice que acepte) | **del acta** — criterio de éxito, «en producción» | — |
| 8 | Medición de aportes sociales en línea | sin definir | **del acta** — criterio de éxito, «y medido»; la métrica es **sin definir** | — |

Los nodos 1–3 pueden ser los mismos que 4–6 o distintos. El acta no lo dice y no lo resuelvo.

## Orden
Sin fechas. Qué necesita qué:

- 7 necesita 1, 2 y 3 (todo el alcance), y la integración con el core (6) si el producto toca el core. **Supuesto**: el acta no dice qué es cada componente.
- 6 necesita al proveedor del core cooperativo. **Supuesto**, contradice el «ninguna declarada» del acta; el informe del 2026-10-12 respalda la dependencia.
- 5 (ambiente de pruebas) antes de las pruebas de 6 y 7. **Supuesto** de orden técnico.
- 4 (diseño funcional) antes de construir 1–3. **Supuesto**; el cronograma lo muestra cerrado.
- 8 necesita 7 en producción y una métrica definida. Sin la métrica no hay forma de cerrarlo.

El orden de los hitos en el cronograma v1/v2 es de calendario (2026-05-08, 2026-10-10, 2027-03-13/2027-07-06), no de dependencia; no lo copio como si fuera lo segundo.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres hitos del cronograma v1/v2 son entregables del proyecto, y no solo marcas de calendario | La WBS cambia por completo y los nodos 4–6 se reemplazan por los componentes reales. |
| «Componente 1, 2 y 3» corresponden a entregables aceptables por separado | Si son uno solo, o más de tres, el desglose y el orden no sirven. |
| La integración con el core (6) es camino crítico del producto | Si no lo es, el corrimiento del hito no afecta el cierre. Si lo es, ya lo afecta (ver análogos). |
| El diseño funcional (4) quedó realmente cerrado el 2026-05-08 | Se reabriría trabajo que el plan da por hecho. El cronograma lo dice, pero no hay acta de recibo que lo sustente. |
| El proveedor del core es una sola organización y es la misma de «la revisión con el proveedor» del 2026-10-25 | Las dependencias y los riesgos se reparten distinto. |
| El alcance de CC-01 (ampliación, aún sin decidir) no está incluido en esta WBS | Si se aprueba, se agregan nodos y la línea base cambia. |

Cuando el plan se apruebe, estos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Sin definir quién; el acta lo firman el patrocinador (Elena Duarte) y el comité (Comité de Tecnología) |
| Qué proyecto cubre lo que queda fuera de alcance | Sin definir quién |
| Qué se mide, con qué meta y quién la mide («medido») | Sin definir quién; el patrocinador acepta el criterio de éxito |
| Quién acepta cada entregable | Sin definir quién; el acta no lo declara |
| Qué puede decidir el gerente por su cuenta (autoridad) | Sin definir quién; normalmente el patrocinador o el comité |
| Cuál es el proveedor del core y cuál su contrato | Sin definir; no hay contrato en la carpeta |
| Si el cronograma v2 es la línea base vigente: la ficha solo tiene la versión 1 (del acta) | Sin definir quién; lo decide quien aprueba el cambio de línea base |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-203 apunta a su carpeta y no a una carpeta de fichas de la PMO, y no hay otras fichas en el espacio de este proyecto. Es la respuesta correcta y evita una falsa precisión: no estimo duraciones por analogía.

Lo que sí hay son datos **de este mismo proyecto**, como referencia y no como estimación:
- El hito «Integración con el core cooperativo» pasó de 2027-03-13 (línea base) a 2027-07-06 (vigente) en el cronograma v2: 115 días. La fecha vigente, 2027-07-06, queda 37 días **después** del cierre comprometido en el acta (2027-05-30). (`10-plan/2026-10-12-cronograma-v2.csv`; acta)
- La proyección al cierre del informe del 2026-10-12 es 2.833.558.895 COP contra 2.400.000.000 aprobados (433.558.895 COP por encima), antes de CC-01 (230.000.000 COP adicionales, sin decisión). (`20-seguimiento/2026-10-12-informe-avance.pdf`; `2026-10-04-solicitud-cambio-cc-01.md`)
- Entre el 2026-09-03 y el 2026-10-15, un mismo compromiso (María Restrepo, «enviar el documento 1») se reprogramó 6 veces. (ficha, `commitments`)

## Preguntas para el equipo
Una por cada duración vacía:

1. **Componente 1**: ¿qué es, quién lo recibe y cuánto toma?
2. **Componente 2**: ¿qué es, quién lo recibe y cuánto toma?
3. **Componente 3**: ¿qué es, quién lo recibe y cuánto toma?
4. **Diseño funcional**: ¿qué documento lo respalda como aprobado y quién lo firmó? (Es duración ya consumida; no necesita estimación.)
5. **Ambiente de pruebas certificado**: la fecha 2026-10-10 ya pasó. ¿Cuánto falta y qué certificación falta?
6. **Integración con el core**: ¿cuánto toma, con qué equipo del proveedor y desde cuándo está disponible ese equipo?
7. **En producción**: ¿cuánto toma el paso a producción desde que 1–3 y 6 están listos, y cuándo es la ventana de la sala de producción?
8. **Medición**: ¿qué se mide, desde cuándo, durante cuánto tiempo y quién da por buena la medición?

## Para comprometer una fecha falta
Nada de esto está en un documento:
- **Disponibilidad real del equipo**: el informe dice que se perdieron dos semanas por la rotación de un desarrollador clave; no hay plan de reemplazo.
- **Fecha y capacidad del proveedor del core**: en la reunión del 2026-10-15 se dijo que el proveedor podría no llegar con el equipo completo a la siguiente fase, y nadie lo registró como riesgo.
- **Ventana de la sala de producción** y el cierre contable de fin de mes (el informe reprogramó la salida por ese cierre).
- **Decisión de CC-01** (+115 días y +230.000.000 COP): sin ella no se sabe si el plan tiene que cubrir esa ampliación.
- **Hallazgo de seguridad de la revisión de arquitectura**: sin doliente ni fecha; no se sabe cuánto trabajo agrega.
- **El ajuste del presupuesto** que Laura Vélez prometió «la otra semana».

Este borrador no compromete ninguna fecha, no asigna personas ni crea línea base. Quien aprueba el plan decide si el cronograma v2 pasa a ser la vigente; antes de eso, los supuestos de arriba pasan al RAID con doliente.
