# Aportes sociales en línea (PRY-203) — semana del 2026-10-08 al 2026-10-15

**Declara el gerente (Ricardo Salas):** *sin declaración esta semana* — nadie respondió a la pregunta de la declaración en esta sesión, y el informe sale con la línea en blanco. Lo que consta en documento, para que se vea y no como sustituto: informe de avance del 2026-10-12 (hace 3 días): amarillo · 44 % (`20-seguimiento/2026-10-12-informe-avance.pdf`).
**Sustento documental:** sin sustento. Evidencia documental marcada: 0 fuentes; declaración: 3; sin marcar: 224.
**Lo que el semáforo no explica:** hitos vencidos, hito «cumplido» sin evidencia, desviación de costo proyectada, compromisos vencidos y compromisos reprogramados (las 5 señales quedan fuera de lo que cubre el amarillo documentado).

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: esta es la primera instantánea (2026-10-15), y el diff sale vacío. No se puede decir qué cambió; se dice lo que hay.

## Lo que sigue igual y sigue mal (con los días que lleva)
| Qué | Desde | Días así |
|---|---|---|
| Hito «Ambiente de pruebas certificado», pendiente | vencía 2026-10-10 | 5 |
| Hito «Diseño funcional aprobado», marcado cumplido sin evidencia | vencía 2026-05-08 | 160 |
| Carlos Peña — Enviar el documento 9 | 2026-10-09 | 6 |
| Felipe Arango — Validar el ambiente 20 | 2026-10-05 | 10 |
| Proyección de costo sobre lo aprobado: +18,1 % (umbral 10 %) | informe del 2026-10-12 | — |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-05-30 | 2027-05-30 | 0 días |
| Presupuesto | 2.400.000.000 COP | 2.400.000.000 COP | proyección 2.833.558.895 COP: +433.558.895 (+18,1 %) |

Replanificaciones: 0 (línea base única, versión 1, acta del 2025-11-25).

Atención: el hito «Integración con el core cooperativo» ya figura con fecha vigente 2027-07-06 contra 2027-03-13 de la base (+115 días), mientras la fecha de cierre del proyecto no se movió. Coincide con los +115 días de la solicitud de cambio CC-01 (2026-10-04, +230.000.000 COP, ampliación de alcance), que sigue **pendiente de decisión**, sin decisor registrado. El cálculo no marca días sin autorización (0), pero la fecha del hito y el cierre del proyecto no pueden ser ciertas a la vez.

Avance: el 44 % documentado frente a lo que sostiene el plan por hitos (33–67 %, 1 de 3 hitos cumplido, y ese sin evidencia): no hay brecha por encima del umbral, pero el único hito cumplido no tiene sustento.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ninguno cae entre el 2026-10-15 y el 2026-11-12 | | | |

(El hito vencido «Ambiente de pruebas certificado», base y vigente 2026-10-10, sigue pendiente y sin evidencia.)

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 732.174.098 (30,5 %) | 473.118.382 (19,7 %) | 2.833.558.895 | 1.667.825.902 |

Disponible real = aprobado − comprometido. Con CC-01 aprobado, el costo adicional sería de 230.000.000 más.

## Abierto
**Reprogramados:**
- María Restrepo — Enviar el documento 1: 6 veces; original 2026-10-01, hoy 2026-12-11 (la nota del 2026-10-15 dice «11/12/2026»; se leyó día/mes/año).
- Sandra Gil — Cerrar la prueba 2: 5 veces; original 2026-09-18, hoy 2026-11-28.
- También con una reprogramación: Elena Duarte (punto 8, 2026-11-03, dos cambios) y Óscar Ramírez (matriz 6, 2026-10-28).

**Vencidos sin evidencia:** Carlos Peña (documento 9, desde 2026-10-09); Felipe Arango (ambiente 20, desde 2026-10-05).
**Sin fecha:** Mauricio Pérez — Aprobar el diseño 5 (desde 2026-09-10; dijo que ya lo entregó, sin acta de recibo: no se da por cumplido); Óscar Ramírez — Entregar el punto 24 (2026-10-08); Laura Vélez — Mandar el ajuste del presupuesto (2026-10-15).
**RAID sin movimiento:** dos incidencias sin dueño ni fecha de inicio (hallazgo de seguridad en la revisión de arquitectura; rotación de un desarrollador clave, dos semanas perdidas); riesgo «Dependencia del proveedor del core cooperativo» registrado sin dueño; riesgo «el proveedor podría no llegar con el equipo completo» comentado el 2026-10-15 y no registrado.
**Proveedor:** no hay proveedores en la ficha.

## Lo que necesito de alguien
- **Ricardo Salas:** declarar estado y avance de esta semana. Sin esa línea el informe queda incompleto a propósito.
- **Quien decida CC-01** (decisor no registrado; excede al gerente, es material de comité, comité del 2026-10-22): decisión pendiente desde el 2026-10-04.
- **María Restrepo y Sandra Gil:** fecha firme o decisión de qué hacer con un compromiso movido 6 y 5 veces.
- **Carlos Peña y Felipe Arango:** evidencia o nueva fecha.
- **Mauricio Pérez, Óscar Ramírez, Laura Vélez:** fecha para cada compromiso.
- **Dueño para los riesgos e incidencias** sin dueño, y registrar el riesgo del equipo del proveedor.

## Lo que no se sabe
**Sin dato:** autoridad que aprueba (`identity.authority`) y fase (`identity.phase`).
**Silencio:** último documento hace 0 días · última reunión hace 0 días (notas del 2026-10-15). No hay silencio; lo que falta es evidencia: ninguna fuente está marcada como evidencia.

---
Origen: ficha PRY-203 (`records/PRY-203.json`), con corte al 2026-10-15; informe de avance del 2026-10-12. 2 campos sin dato. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10 — borrador de trabajo, no asesoría; la verificación es del gerente.

**Siguiente paso posible:** hay dos compromisos reprogramados más de 3 veces y una desviación de costo sobre el umbral: se puede armar el punto de comité con la decisión formulada (incluida CC-01). No se ofrece `/pm-publish` por contradicción de declaración, porque esta semana no hay declaración que contrastar.
