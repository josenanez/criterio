## Compromisos — PRY-203 Aportes sociales en línea · al 2026-10-15

26 compromisos registrados: 20 abiertos (2 vencidos, 3 sin fecha, 2 reprogramados 3 veces o más), 6 cerrados con evidencia. Las cifras salen de `portafolio.py compute`.

### Se viene reprogramando

> **María Restrepo** · Enviar el documento 1
> Prometido para el 2026-10-01, y antes para el 10-20, 10-28, 11-08, 11-20, 11-27 y ahora el **2026-12-11**. **Seis reprogramaciones**, cada una dicha en un comité distinto (09-10 a 10-15). La fecha se corrió ~71 días desde la primera promesa.
> Nota: las notas del 10-15 dicen «11/12/2026»; se leyó día/mes/año. Si fuera 12 de noviembre, sería una fecha anterior a la de la semana pasada: conviene confirmarlo con ella.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.** (Fuente: 30-reuniones/2026-09-03-comite-semanal.md y reprogramaciones en los comités siguientes y 2026-10-15-notas-reunion.txt)

> **Sandra Gil** · Cerrar la prueba 2
> Prometido para el 2026-09-18, y antes para el 10-07, 10-14, 10-26, 11-07 y ahora el **2026-11-28**. **Cinco reprogramaciones**; la del 10-14 ya pasó sin cierre y se movió de nuevo. Vigente: 11-28. (Fuente: 30-reuniones/2026-09-03-comite-semanal.md … 2026-10-08-comite-semanal.md)
> **Es un bloqueo que nadie ha nombrado**, y toca la prueba que sostiene el hito «Ambiente de pruebas certificado», vencido hace 5 días (2026-10-10). No se afirma causalidad: solo que ambos temas coinciden y no hay documento que los conecte.

Con 2 reprogramaciones, sin llegar al umbral de 3, también se mueve **Elena Duarte** (patrocinadora) en «Entregar el punto 8»: 09-28 → 10-14 → 11-03.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Felipe Arango | Validar el ambiente 20 | 2026-10-05 | 10 días |
| Carlos Peña | Enviar el documento 9 | 2026-10-09 (antes 09-24) | 6 días |

No hay acta de recibo ni entregable en el expediente para ninguno.

### Vencen en los próximos 7 días (hasta el 22-oct; nada vence antes del domingo 18)
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Liliana Torres | Revisar el anexo 11 | 2026-10-21 (antes 10-03) |
| Andrés Lozano | Entregar el punto 16 | 2026-10-21 (antes 10-08) |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 |

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Mauricio Pérez | Aprobar el diseño 5 | 2026-09-10 |
| Óscar Ramírez | Entregar el punto 24 | 2026-10-08 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-15 |

Son 3 y no pueden estar vencidos. Detalles: lo de Mauricio salió de la tabla el 09-24 porque él dijo que «ya lo entregó»; **no hay acta de recibo, así que sigue abierto** y no se da por cumplido. Lo de Laura se dijo como «la otra semana», que no es una fecha y no se calculó. Mauricio tiene además otros dos compromisos abiertos (diseño 13 al 10-31, fecha 15 al 10-22).

### Resto de abiertos con fecha (9)
Óscar Ramírez: matriz 6 al 10-28 (prometida originalmente para el 09-20, siguió vencida en las tablas del 09-24 y del 10-01 hasta que se volvió a prometer el 10-08), anexo 19 al 11-10, revisión con el proveedor al 10-25 · Elena Duarte: punto 8 al 11-03, confirmar la fecha 23 al 10-30 · María Restrepo: matriz 22 al 10-27 · Mauricio Pérez: diseño 13 al 10-31 · Carlos Peña: diseño 21 al 11-05 · Andrés Lozano: documento 17 al 11-12.

### Cerrados desde la última revisión
No hay una revisión previa de este comando; se listan todos los cerrados con su documento.
- Diana Molina · Revisar el anexo 3 → 20-seguimiento/2026-09-17-acta-recibo-3.md
- Andrés Lozano · Validar el ambiente 4 → 20-seguimiento/2026-10-01-acta-recibo-4.md
- Javier Hoyos · Confirmar la fecha 7 → 20-seguimiento/2026-10-01-acta-recibo-7.md
- Gustavo Neira · Cerrar la prueba 10 → 20-seguimiento/2026-10-08-acta-recibo-10.md
- Felipe Arango · Validar el ambiente 12 → 20-seguimiento/2026-10-08-acta-recibo-12.md
- María Restrepo · Actualizar la matriz 14 → 20-seguimiento/2026-10-08-acta-recibo-14.md

### Después
- **Ofrezco formular como decisión para el comité** (jueves 2026-10-22) los dos bloqueos: el documento 1 de María Restrepo y la prueba 2 de Sandra Gil: qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente. Nota: la ficha no tiene `authority` ni `phase`, así que quién decide queda por confirmar.
- **El informe de avance del 10-12 declara amarillo** y no recoge compromisos vencidos ni reprogramados entre sus señales; si el estado cambia por esto, ofrezco `/pm-publish`.
