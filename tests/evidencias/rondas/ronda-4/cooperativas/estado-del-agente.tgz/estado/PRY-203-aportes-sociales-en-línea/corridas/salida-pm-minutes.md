# Acta — Aportes sociales en línea (PRY-203) · 2026-10-15

**Asistieron:** Andrés Lozano, Carlos Peña, Elena Duarte, Felipe Arango, Laura Vélez, Liliana Torres, María Restrepo, Mauricio Pérez, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-15-notas-reunion.txt` (notas de 9 líneas, sin agenda) · **Ausentes con tema en agenda:** no se puede decir; las notas no traen agenda. Gustavo Neira estuvo el 2026-10-01 y no está en esta lista. Laura Vélez no aparecía en ninguna de las seis minutas anteriores.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a pedir.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| María Restrepo | Enviar el documento 1 («lo de enviar el documento 1 no alcanzó») | 2026-12-11 | **Reprogramado por 6.ª vez.** Promesa original 2026-10-01; fechas: 10-20 → 10-28 → 11-08 → 11-20 → 11-27 → 12-11. Pasa el umbral de 3. |
| Óscar Ramírez | Revisión con el proveedor («queda para el 2026-10-25») | 2026-10-25 | Nuevo. La fecha cae en domingo. Las notas no dicen qué se revisa; no se asimiló a sus compromisos «matriz 6», «anexo 19» ni «punto 24». |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. Dijo «la otra semana», que no es una fecha: `due_date: no_declarada`, no se calculó. |

Ya había otros dos sin fecha abiertos: Mauricio Pérez (Aprobar el diseño 5, desde 2026-09-10) y Óscar Ramírez (Entregar el punto 24, desde 2026-10-08). Con el de hoy son tres.

## Decisiones
Ninguna. Las notas no registran que nadie decidiera algo.

## Quedó sin decidir
Las notas no dicen qué se discutió sin decidir; no se infiere.

## Intenciones sin doliente
Ninguna en las notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase»; las notas añaden que nadie lo anotó como riesgo | No atribuido: las notas dicen «se comentó» | Riesgo | **No.** Lo más cercano es «Dependencia del proveedor del core cooperativo» (informe de avance 2026-10-12, sin dueño). Es otra causa, y esta no lo cubre. Queda con `registered: false` y sin dueño. |

## Cerrado en esta reunión
Nada. Ninguna de las notas trae documento de recibo, así que no se cierra nada.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-29) | Comité semanal, jueves; próximo 2026-10-22 | Notas 2026-10-15 · `config.json` (`cycle.committee_next`, configuración de esta sesión) |

Si la cadencia cambió de verdad, se corrige la configuración. Si no, hay que preguntarle a Ricardo Salas. Con una reunión cada dos semanas, las fechas del 10-22 (Elena Duarte, Mauricio Pérez, Javier Hoyos, Andrés Lozano, Liliana Torres) se quedan sin comité que las revise.

## Sin resolver de la transcripción
- «11/12/2026» (María Restrepo): se leyó día/mes/año = 11 de diciembre. Si fuera mes/día sería 12 de noviembre, anterior al 2026-11-27 prometido la semana pasada. Conviene confirmarlo con María.
- «La otra semana» (Laura Vélez): sin fecha.
- «Revisión con el proveedor»: no se sabe qué revisión es, y 2026-10-25 es domingo.
- «Se comentó que el proveedor podría no llegar…»: no se sabe quién lo dijo ni a qué proveedor se refiere. La ficha no tiene proveedores cargados.

## Recálculo (`portafolio.py compute`, 2026-10-15)
- Vencidos sin evidencia: Carlos Peña, «Enviar el documento 9» (6 días); Felipe Arango, «Validar el ambiente 20» (10 días). Ninguno se mencionó en las notas de hoy.
- Reprogramados sobre el umbral: María Restrepo (6 veces) y Sandra Gil (5 veces, «Cerrar la prueba 2», hoy en 2026-11-28; las notas de hoy no la mencionan).
- Sin fecha: 3.
- Fuera de lo que cubre el acta, el cálculo también marca: costo proyectado 18,1 % sobre lo aprobado, hito «Ambiente de pruebas certificado» vencido hace 5 días e hito «Diseño funcional aprobado» declarado cumplido sin evidencia.

## Después
Puedes correr `/pm-commitments` para ver el seguimiento completo. `/pm-publish` solo hace falta si cambias algo de la ficha; hoy el acta contradice la configuración (cadencia), no un campo de la ficha. El acta sale aquí y la guardas tú: no se escribió en tu carpeta de reuniones.
