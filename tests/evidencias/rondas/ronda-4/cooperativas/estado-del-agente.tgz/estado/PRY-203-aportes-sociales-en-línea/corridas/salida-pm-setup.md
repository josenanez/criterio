Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

**Lo que vi:** 18 documentos, 7 de reuniones (6 minutas del comité del 2026-09-03 al 2026-10-08 y las notas del 2026-10-15), la más reciente del 2026-10-15. Formatos que no puedo leer: ninguno.

**Respuestas tomadas (sesión sin interfaz, la sugerida en cada una):**
1. Eres Ricardo Salas, gerente de PRY-203 «Aportes sociales en línea» (acta de constitución del 2025-11-25).
2. Reunión de seguimiento: jueves, semanal (los seis comités caen en jueves). Ojo: las notas del 2026-10-15 dicen «próxima reunión en dos semanas»; dejé la próxima el jueves 2026-10-22 y habría que confirmarla.
3. Estado guardado en `estado/PRY-203-aportes-sociales-en-línea`, junto a `documentos/`, fuera de la carpeta de documentación y de `.criterio/`.
4. Términos: versión 1.1 (plugin 0.3.10), mostrados tal cual; aceptados por José Francisco Ñáñez, 2026-10-15, según el encargo de esta prueba.

## Listo — Aportes sociales en línea (PRY-203)

**Lo que miré:** 18 documentos · 7 reuniones (todas leídas, de la más vieja a la más nueva) · la última del 2026-10-15
**Términos:** aceptados para la versión 0.3.10 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 5c505a87302a3766…

### Lo que está abierto, y cuántas veces se ha movido
Leí 26 compromisos: 6 cumplidos con acta de recibo, 2 vencidos, 3 sin fecha y 15 vigentes.

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| María Restrepo | Enviar el documento 1 | 2026-12-11 | **Movido 6 veces**: 2026-10-01 → 10-20 → 10-28 → 11-08 → 11-20 → 11-27 → 12-11. Cita: notas 2026-10-15 («lo de "enviar el documento 1" no alcanzó, se compromete para el 11/12/2026»). Leí día/mes/año; si fuera 12 de noviembre sería una fecha anterior a la de la semana pasada, confírmalo. |
| Sandra Gil | Cerrar la prueba 2 | 2026-11-28 | **Movido 5 veces**: 2026-09-18 → 10-07 → 10-14 → 10-26 → 11-07 → 11-28. Cita: minuta 2026-10-08. |
| Carlos Peña | Enviar el documento 9 | 2026-10-09 | **Vencido hace 6 días sin acta.** Movido 1 vez (antes 2026-09-24). Minuta 2026-10-08. |
| Felipe Arango | Validar el ambiente 20 | 2026-10-05 | **Vencido hace 10 días sin acta.** Minuta 2026-10-08. |
| Óscar Ramírez | Actualizar la matriz 6 | 2026-10-28 | Estuvo en la tabla con 2026-09-20 tres reuniones (ya vencida) hasta que el 10-08 se volvió a prometer. Movido 1 vez. |
| Elena Duarte | Entregar el punto 8 | 2026-11-03 | Movido 2 veces (09-28 → 10-14 → 11-03). |
| Liliana Torres | Revisar el anexo 11 | 2026-10-21 | Movido 1 vez (primera fecha 10-03). |
| Mauricio Pérez | Aprobar el diseño 13 | 2026-10-31 | Movido 1 vez (antes 10-18). |
| Andrés Lozano | Entregar el punto 16 / Enviar el documento 17 | 2026-10-21 / 2026-11-12 | Cada uno movido 1 vez. |
| Óscar Ramírez | Revisar el anexo 19 | 2026-11-10 | Movido 1 vez (antes 10-21). |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo, notas 2026-10-15. |
| Mauricio Pérez | Confirmar la fecha 15 | 2026-10-22 | Sin movimientos. |
| Elena Duarte | Cerrar la prueba 18 · Confirmar la fecha 23 | 2026-10-19 · 2026-10-30 | Sin movimientos. |
| Carlos Peña | Aprobar el diseño 21 | 2026-11-05 | Sin movimientos. |
| María Restrepo | Actualizar la matriz 22 | 2026-10-27 | Sin movimientos. |

Cumplidos con acta de recibo: anexo 3 (Diana Molina), ambiente 4 (Andrés Lozano), confirmar la fecha 7 (Javier Hoyos), prueba 10 (Gustavo Neira), ambiente 12 (Felipe Arango), matriz 14 (María Restrepo; vencía el 2026-09-27, se recibió el 2026-10-08).

### Sin fecha
Nadie los fechó, así que no pueden estar vencidos:
- Mauricio Pérez — Aprobar el diseño 5. Estaba «por definir» el 09-10 y 09-17; el 09-24 salió de la tabla y Mauricio dijo que ya lo entregó. **No se presentó acta, así que no lo di por cumplido.**
- Óscar Ramírez — Entregar el punto 24 («por definir», minuta 2026-10-08).
- Laura Vélez — Mandar el ajuste del presupuesto («la otra semana», notas 2026-10-15). No calculé una fecha.

### Otras señales que levantó el cálculo
- Hito «Ambiente de pruebas certificado»: fecha 2026-10-10, 5 días sin cerrarse (cronograma v2).
- Hito «Diseño funcional aprobado»: el cronograma lo declara cerrado, 160 días desde su fecha, sin acta que lo pruebe.
- Presupuesto: aprobado 2.400.000.000 COP; proyección al cierre 2.833.558.895 COP, 18.1 % por encima. Comprometido 30.5 %, ejecutado 19.7 %.
- Tu declaración (amarillo, 44 %, informe del 2026-10-12) no explica por sí sola estas señales: compromisos vencidos, compromisos reprogramados, hito cerrado sin acta, hito vencido y sobrecosto proyectado. Es tu declaración y la tuya queda como está; esto es contra qué se contrasta.

### Para mirar (el cálculo no lo levantó como señal)
- El cronograma v2 (2026-10-12) mueve «Integración con el core cooperativo» de 2027-03-13 a 2027-07-06, mientras la solicitud de cambio CC-01 (2026-10-04, ampliación de alcance, +115 días, 230.000.000 COP) sigue «pendiente de presentación al comité». No hay línea base nueva aprobada.
- Las notas del 2026-10-15 recogen que el proveedor podría no llegar con el equipo completo para la siguiente fase y que nadie lo anotó como riesgo. Tu informe solo lista «dependencia del proveedor del core cooperativo», y el acta de constitución declara «ninguna» dependencia.

### Qué le falta a tu carpeta
- Actas de recibo para casi todo lo prometido: solo hay 6 de 26 compromisos; sin ellas lo entregado se ve igual que lo incumplido.
- Acta del hito «Diseño funcional aprobado» y del hito del ambiente de pruebas.
- Autoridad del gerente (hasta qué monto y qué cambio decide sin comité) y fase declarada: no están en el acta de constitución.
- Un acta de la decisión sobre CC-01 o la línea base v2.
- Las minutas de comité traen solo tabla de compromisos; las del 10-15 son notas sueltas, sin tabla.

Dejé la ficha sin sellar: leí reuniones, no el proyecto entero. Ficha en `estado/PRY-203-aportes-sociales-en-línea/records/PRY-203.json`.

**Cuándo vuelvo:** el jueves 2026-10-22, por la cadencia semanal (confirma si la reunión es en dos semanas, como dicen las notas).
