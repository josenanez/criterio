Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15): no hizo falta registrarlos de nuevo.

Recalculé antes de publicar (corte 2026-10-15). Carpeta de gobierno existente, no hubo que crearla.

Publiqué la ficha en `documentos/proyectos/PRY-203-aportes-sociales-en-línea/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 33 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · declara **amarillo** al 2026-10-12 (44 % de avance, informe de avance del 12-oct, declarado por el gerente)

**Lo más viejo que va ahí:** identidad, patrocinio, comité y fechas del plan, del 2025-11-25 (acta de constitución), 324 días: no pasa de un año.

**Para tener presente antes de que la PMO la lea:**
- La ficha no está sellada: se leyeron reuniones, no el proyecto entero (dice «No sellada» en su cobertura).
- `compute` marca 10 señales abiertas que la declaración amarilla no recoge: costo proyectado +18,1 % sobre lo aprobado, hito «Ambiente de pruebas certificado» vencido hace 5 días, hito «Diseño funcional aprobado» dado por cumplido sin evidencia, 2 compromisos vencidos y 2 reprogramados 5 y 6 veces, 3 sin fecha.
- La declaración sigue siendo tuya; la ficha la marca como declarada.
