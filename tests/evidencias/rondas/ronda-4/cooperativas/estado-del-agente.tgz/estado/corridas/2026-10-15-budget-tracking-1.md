# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 32 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Presupuesto PRY-211: proyección 17.3% sobre aprobado, facturado 513.489.020 sin entregables aceptados, hitos sin evidencia. Dijo no saber: línea base de costo original, desglose del comprometido, fecha de aprobación del vigente.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha `estado/records/PRY-211.json` (actualizada 2026-10-15), construida desde `PRY-211-cobranza-digital/`: informe de avance 2026-10-15, cronograma v1 2025-10-04, contrato CT-884 2025-10-10, factura CT-884 2026-09-26, acta de recibo 2026-10-13. Cifras derivadas copiadas de `portafolio.py compute` con fecha de corte 2026-10-15. Términos vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-15.

## Presupuesto — PRY-211 Cobranza digital al 2026-10-15
**Moneda:** COP (única; no hay contratos en otra moneda ni conversión)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 9.500.000.000 | — | informe de avance (declaración) | 2026-10-15 |
| Comprometido | 4.607.236.341 | 48.5 | informe de avance (declaración) | 2026-10-15 |
| Ejecutado | 3.697.963.264 | 38.9 | informe de avance (declaración) | 2026-10-15 |
| Proyección al cierre | 11.146.984.265 | 17.3 por encima del aprobado | informe de avance (declaración) | 2026-10-15 |

**Disponible real** (aprobado menos comprometido): 4.892.763.659 COP

Las cuatro cifras salen del mismo informe de avance del gerente, una declaración. Ninguna tiene respaldo en un documento contable o contractual distinto del contrato CT-884 (ver alertas).

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | not_found como línea base original (el acta del 2025-10-04 no trae la cifra en la ficha) | 9.500.000.000 (informe 2026-10-15) | no calculable contra el original |
| Proyección vs. aprobado | — | 9.500.000.000 | +17.3 % (umbral 10 %) |

Replanificaciones de presupuesto: 0. No hay solicitudes de cambio registradas (`changes`: 0). La línea base de cronograma tiene una sola versión (v1, 2025-10-04), sin desvío de fecha: fin 2027-04-09.

### Ejecución frente a avance
Ejecutado 38.9 % · Hitos cumplidos 3 de 5 (declarados) · Avance declarado 44 %, el plan sustenta entre 60 y 80 %, brecha 16.0 puntos y va atrasado. De los 3 hitos «cumplidos», solo «Ambiente de pruebas certificado» tiene acta de recibo (2026-10-13). «Diseño funcional aprobado» (vencía 2026-01-30) e «Integración con el core cooperativo» (vencía 2026-09-04) están dados por cumplidos sin evidencia. Con evidencia, el cumplimiento es 1 de 5.
Lectura: se ha gastado cerca del avance declarado, pero ese avance no tiene respaldo y el plan pedía más. No se puede descartar que parte de lo ejecutado no corresponda a trabajo entregado (ver proveedor).

### Alertas
- **Proyección excede el aprobado:** 11.146.984.265 contra 9.500.000.000, 17.3 % por encima. Supera el umbral de 10 %. El proyecto no ha abierto solicitud de cambio.
- **Facturado sin entrega:** Red Rural de Pagos S.A.S. (CT-884) facturó 513.489.020 COP (factura 2026-09-26) y no tiene ningún entregable aceptado (0 de 4). Tres entregables están vencidos y pendientes: Licenciamiento del módulo (247 días), Bolsa de horas de desarrollo (128 días), Parametrización de líneas de crédito (8 días).
- **Hitos cumplidos sin evidencia:** los dos citados arriba.
- **Avance declarado por debajo del plan:** 16.0 puntos.
- **Comprometido:** 48.5 %, por debajo del umbral de 90 %. No hay alerta de tope. Sí hay que decir que el comprometido es la declaración del gerente y no está desglosado: del contrato CT-884 se ve el monto facturado, no el total comprometido.
- El estado declarado es rojo; el informe no explica 5 de las señales que aquí aparecen (hitos sin evidencia, avance vs. plan, desviación de costo, entregables vencidos, facturado sin entrega).

### Sin dato
- Presupuesto aprobado original (línea base de costo de la constitución): no declarado en ningún documento leído.
- Desglose del comprometido y del ejecutado por proveedor o rubro: no declarado.
- Fecha de aprobación del presupuesto vigente: no declarada, así que no se puede decir si la proyección es más vieja que el último movimiento de presupuesto.
- Campos de identidad `autoridad` y `fase`: not_found.
- Campos con más de 12 meses (código, nombre, patrocinador, gerente, fechas del plan, alcance): vienen del acta del 2025-10-04.

### Siguiente paso posible
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). Y el detalle por proveedor de CT-884, dado el facturado sin entrega (`/criterio-portfolio:vendor-tracking`).

---
**Pie de rigor:** Criterio produce un borrador de trabajo, no una decisión ni asesoría. Cada cifra sale de los documentos listados y debe verificarse contra ellos; lo hablado fuera de los documentos no está aquí. No se asumió ninguna cifra ausente.
