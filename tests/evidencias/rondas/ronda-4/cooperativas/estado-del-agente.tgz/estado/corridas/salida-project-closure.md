Sale de: ficha `estado/records/PRY-200.json` (actualizada 2026-10-15), `compute` del 2026-10-15 y los documentos de `PRY-200-crédito-de-libranza-digital/`: acta de constitución (2025-06-22), contrato CT-451 (2025-06-24), cronograma v1 (2025-06-22), dos actas de recibo (2026-03-07 y 2026-05-23), factura CT-451 (2026-09-16), informe de avance (2026-09-23) y comité semanal (2026-10-05).

Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

## Cierre — PRY-200 Crédito de libranza digital — 2026-10-15

**Lo primero: este proyecto no está en condiciones de cerrarse por cumplimiento.** Los documentos no muestran que haya terminado. El único avance declarado es del 23 de septiembre: 44 %, estado amarillo, con un hallazgo de seguridad abierto. Ningún documento de evidencia dice que esté en producción. Si se cierra hoy, sería por decisión del Consejo de Administración, no porque se cumplió lo pactado, y esa decisión no está registrada en ningún documento.

### Contra lo comprometido
**Criterio de éxito:** "Crédito de libranza digital en producción y medido" (acta de constitución, 2025-06-22).
**Se cumplió:** no se puede determinar. Ningún documento muestra el producto en producción ni su medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (2025-09-10) | Declarado cumplido / cerrado | Ninguna (400 días sin evidencia) |
| Ambiente de pruebas certificado (2025-11-20) | Declarado cumplido / cerrado | Ninguna (329 días) |
| Integración con el core cooperativo (2026-01-30) | Declarado cumplido / cerrado | Ninguna (258 días) |
| Piloto con asociados (2026-04-11) | Declarado cumplido / cerrado | Ninguna (187 días) |
| Salida a producción (2026-06-21) | Declarado cumplido / cerrado | Ninguna (116 días) |

Los cinco hitos aparecen como "cerrado" en el cronograma v1 (`10-plan/2025-06-22-cronograma-v1.csv`), que es un plan de 2025 sin actualizar. Ningún hito tiene acta, aprobación ni certificado. Además, el informe del 2026-09-23 declara 44 % de avance, y el plan dice que los cinco hitos están cumplidos (100 %). La diferencia es de 56.0 puntos. Hay dos lecturas posibles y los documentos no permiten elegir: el cronograma está desactualizado o el avance está mal declarado. Tampoco hay una cuarta posibilidad que descartar: que sí esté en producción y nadie lo haya documentado.

Proveedor Red Rural de Pagos S.A.S. (CT-451), 4 entregables:
- Licenciamiento del módulo: vencía el 2025-09-18, sigue pendiente, 392 días de atraso.
- Bolsa de horas de desarrollo: figura "entregado", sin acta de recibo.
- Parametrización de líneas de crédito: aceptado, con acta del 2026-03-07.
- Mesa de ayuda del primer trimestre: aceptado, con acta del 2026-05-23.

Facturado: 930.019.665 COP (factura del 2026-09-16). Solo hay dos actas de recibo; los otros dos entregables no tienen aceptación documentada. Lo facturado frente a lo aceptado con evidencia es un punto para revisar antes de cualquier cierre.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| No se puede determinar. El acta solo dice "Lo que otro proyecto cubre". | — | — |

El alcance del acta son "Componente 1, Componente 2, Componente 3", sin detalle. No hay forma de contrastar qué se entregó contra qué se comprometió. No hay solicitudes de cambio registradas (0).

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-06-21 (cronograma v1) | 2026-06-21 | No hay fecha real de cierre documentada | 0 días contra la línea base; no refleja la realidad (ver abajo) |
| Presupuesto aprobado | 3.300.000.000 COP | 3.300.000.000 COP | Ejecutado 1.362.657.814 COP (41.3 %) | Proyección al cierre 3.286.443.742 COP (−0.4 % sobre lo aprobado) |

Comprometido: 1.615.968.219 COP (49.0 %). Disponible real: 1.684.031.781 COP.
Replanificaciones: 0.

Los 0 días de desviación no son un hallazgo de buen desempeño. La línea base nunca se movió, y la fecha comprometida ya pasó hace 116 días sin evidencia de salida a producción. El hecho es que la línea base no se actualizó y no hay replanificación registrada.

**Conflicto entre documentos, sin resolver:** el acta fija el cierre en **2026-07-27**; el cronograma v1 (misma fecha, 2025-06-22) lo fija en **2026-06-21**. Ninguna fecha se declaró vigente por decisión. Esta tabla usa la del cronograma porque es la que la ficha tiene como línea base.

Presupuesto: las cifras salen del informe del 2026-09-23 (declaración del gerente) y no de un registro contable. No hay evidencia independiente de lo ejecutado.

### RAID al cierre
**Materializados:** no se puede determinar. El hallazgo de seguridad de la revisión de arquitectura (incidencia) figura en el informe del 2026-09-23; no dice desde cuándo, ni si se resolvió.
**No materializados:** ninguno documentado.
**Abiertos, con doliente:**
- Riesgo "concentración del conocimiento en una sola persona": registrado en el informe, **sin doliente**.
- Hallazgo de seguridad: **sin doliente** ni fecha de inicio.
- Compromiso de Natalia Ospina "Entregar el punto 31" (comité 2026-10-05): **sin fecha** ("por definir"); Natalia Ospina no figura entre los asistentes y el "punto 31" no se define en ningún documento.
- Licenciamiento del módulo (proveedor): pendiente hace 392 días, sin doliente.

Lo que queda abierto sin doliente con nombre no está cerrado.

### Lecciones
No hay ninguna que se pueda sustentar hoy con la documentación disponible: sería armarlas con hechos inventados. Lo que sí queda establecido como hecho documentado, y que la próxima vez se debe corregir:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marca los 5 hitos como cerrados sin acta ni aprobación; el informe de avance dice 44 % | Cronograma 2025-06-22; informe 2026-09-23 | Diferencia de 56.0 puntos entre plan y avance declarado; no se puede saber el estado real | Exigir un documento de evidencia por hito antes de marcarlo cerrado |
| El acta y el cronograma dan dos fechas de cierre distintas (2026-07-27 y 2026-06-21) el mismo día | 2025-06-22 | La desviación contra la línea base no tiene una referencia única | Que el acta y el cronograma salgan de una sola fuente |
| El licenciamiento del módulo con vencimiento 2025-09-18 sigue pendiente | 2025-09-18 a hoy (392 días) | Entregable contractual vencido sin gestión visible | Revisión de vencimientos del contrato en cada comité |
| Compromiso de comité sin fecha ni responsable presente | 2026-10-05 | No es verificable | No aceptar compromisos sin fecha en el acta del comité |

### Sin dato
- Si el producto está en producción y medido (el criterio de éxito).
- Fecha real de salida a producción, o de qué hito se cerró y cuándo.
- Evidencia de los cinco hitos y del entregable "Bolsa de horas de desarrollo".
- Fecha de cierre vigente: acta (2026-07-27) o cronograma (2026-06-21).
- Qué incluyen los "Componentes 1, 2 y 3", y qué quedó fuera por decisión.
- Autoridad del proyecto y fase (campos sin encontrar en la ficha).
- Fecha de inicio y estado del hallazgo de seguridad; doliente de ese hallazgo y del riesgo de concentración de conocimiento.
- Qué es el "punto 31".
- Una decisión del Consejo de Administración de cerrar el proyecto.
- Fuentes de los números: el único documento es el informe del gerente. La ficha tiene 0 fuentes de evidencia, 3 de declaración y 16 sin marcar.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha: el proyecto no está demostrado como terminado y su ficha tiene alertas abiertas. Cuando el Consejo decida el cierre —y lo registre—, se puede archivar con la última instantánea. Antes, lo mínimo es obtener la evidencia de salida a producción, asignar doliente a lo abierto, y resolver la fecha de cierre.

Rigor: cifras copiadas de la salida de `compute` del 2026-10-15; todo lo demás, de los documentos citados arriba. Lo que no estaba, está en "Sin dato".
