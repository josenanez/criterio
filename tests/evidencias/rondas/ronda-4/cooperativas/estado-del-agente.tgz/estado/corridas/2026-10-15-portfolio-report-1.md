# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 82 documentos, 0 releídos y 82 sin cambio · 41 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

El informe quedó en `/home/claude/banco/ronda-4/cooperativas/espacio/reportes`.

4 verdes contradichos (PRY-202, 206, 209, 210); rebaselines sin autorización en PRY-203 y PRY-210; sin instantánea previa, no hay delta

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 9 con hallazgos · 64 señales · fichas en `estado/records/` (13), última instantánea 2026-10-15

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato trae su cita y la verificación es suya.

Formato: html. Informe en `reportes/`: `index.html` (por campo, con cadena de evidencia; para quien va a actuar) y `decisiones.html` (por decisión; para el patrocinador). Además una página por proyecto (13), por producto (8), `productos.html` y `proyectos.html`. El PDF sale de imprimir el HTML.

## Qué cambió desde la corrida anterior
Sin cambios desde la instantánea 2026-10-15 (la única que existe; el diff dio 0 cambios). Este es en la práctica el punto de partida: no hay delta fiable.

## Contradicciones abiertas
4 proyectos declaran verde y la evidencia lo contradice:
| Proyecto | Declara | Fecha | Señales en contra |
|---|---|---|---|
| PRY-202 Core cooperativo | verde | 2026-10-06 | hito vencido, hito cumplido sin evidencia, avance 36% vs 50–75% del plan |
| PRY-206 Pagos con QR | verde | 2026-09-23 | silencio de 22 días |
| PRY-209 Convenios de libranza | verde | 2026-10-15 | 3 hitos cumplidos sin evidencia, avance 86% vs 100% |
| PRY-210 Corresponsales rurales | verde | 2026-10-03 | +84 días vs original sin autorización, proveedor facturado sobre lo aceptado, entregables vencidos |

PRY-203: fin del plan según PMO 2027-07-06 (cronograma v2, 2026-10-12) vs 2027-05-30 según el acta (2025-11-25); la más reciente es la de la PMO.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días |
|---|---|---|---|
| PRY-202 | Integración con el core cooperativo | 2026-10-12 | 3 |
| PRY-203 | Ambiente de pruebas certificado | 2026-10-10 | 5 |

Hitos declarados cumplidos sin evidencia (los más viejos): PRY-200 Diseño funcional (400 d) y los otros 4 de ese proyecto; PRY-209 Diseño funcional (367 d); PRY-207 Ambiente de pruebas (327 d); PRY-210 Diseño funcional (237 d); PRY-211 Diseño funcional (258 d); PRY-208 Diseño funcional (168 d); PRY-203 Diseño funcional (160 d); PRY-202 Ambiente de pruebas (88 d). Total por proyecto: PRY-200 5, PRY-207 4, PRY-208 3, PRY-209 3, PRY-210 2, PRY-211 2, PRY-202 1, PRY-203 1.

## Proyectos en silencio
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-206 Pagos con QR | 22 (umbral 15) | 2026-09-23, informe de avance |

## Dependencias en riesgo
No hubo señal de dependencias rotas en el cálculo de esta corrida. No hice un cruce adicional a mano.

## Sin sustento
Avance declarado por encima de lo que sostiene el plan o la evidencia: PRY-200 (44% con 5/5 hitos "cumplidos" sin evidencia), PRY-208 (25% vs 75–100%), PRY-210 (38% vs 60–80%), PRY-207 (74% vs 100%), PRY-211 (44% vs 60–80%), PRY-202 (36% vs 50–75%), PRY-209 (86% vs 100%). La dirección que marca el script en todos es "behind".

Proveedores: entregable aceptado sin evidencia en PRY-200 y PRY-210 (Bolsa de horas); facturado sin entrega en PRY-211 (Red Rural de Pagos, COP 513.489.020); facturado sobre lo aceptado en PRY-210 (Datos para Cooperativas, COP 96.239.531 vs 69.732.354, diferencia 26.507.177). Entregables vencidos: PRY-200, 207, 210, 211.

## Vacíos de información
- Ningún proyecto tiene autoridad registrada (13 de 13).
- 5 proyectos sin producto asociado: PRY-202, 205, 208, 209, 210.
- Compromisos sin fecha: PRY-200 (1), PRY-203 (3).

## Estado general
| Proyecto | Desviación tiempo vs original | vs vigente | Replanificaciones | Otras señales |
|---|---|---|---|---|
| PRY-203 Aportes sociales | +115 d (24,8%) | 0 | 1 (115 d sin autorización) | costo +18,1% (proy. 2.833.558.895 vs 2.400.000.000); 2 compromisos vencidos; 2 reprogramados 5–6 veces |
| PRY-210 Corresponsales rurales | +84 d (19,6%) | 0 | 1 (84 d sin autorización) | ver contradicciones |
| PRY-211 Cobranza digital | 0 | 0 | 0 | costo +17,3% (proy. 11.146.984.265 vs 9.500.000.000) |
| PRY-199, 201, 204, 205 | 0 | 0 | 0 | sin señales |
| Resto | 0 | 0 | 0 | ver secciones anteriores |

Sin señales: PRY-199, 201, 204, 205. Sobre umbral de costo (10%): PRY-203 y PRY-211. Sobre umbral de tiempo: PRY-203 y PRY-210.

## Necesito que confirmes
No hay confirmación periódica este mes en esta corrida (sin respuestas posibles en sesión de prueba; no la ejecuté).

---
Pie: criterio-portfolio 0.3.10 · fichas aplicadas a 2026-10-15 · campos inciertos: autoridad vacía en los 13 proyectos; dependencias, cambios de gobierno y recursos repetidos no cruzados a mano · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
