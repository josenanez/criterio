## Carpeta al 2026-10-15

**Documentos:** 82 · **Sin cambio:** 82 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
33 citas, todas de PRY-203, en 4 documentos citados:

| Proyecto | Campos | Documento citado |
|---|---|---|
| PRY-203 | 13: identity.code, name, business_area, product, sponsor, manager, committee; plan.start_date, end_date, scope_summary, exclusions | 00-gobierno/2025-11-25-acta-constitucion.docx |
| PRY-203 | 8: declared.status, progress_pct, as_of; money.currency, approved, committed, executed, projection | 20-seguimiento/2026-10-12-informe-avance.pdf |
| PRY-203 | 12: plan.milestones[0..2].name, baseline_date, current_date, state | 10-plan/2026-10-12-cronograma-v2.csv |
| PRY-203 | 2: activity.last_document_date, last_meeting_date | 2026-10-15-notas-reunion.txt |

Los cuatro archivos SÍ existen en la carpeta de PRY-203 y el índice los cuenta como sin cambio. Lo que falla es la ruta de la cita: la ficha de PRY-203 cita sin el prefijo de carpeta de proyecto (`00-gobierno/...`), mientras que las fichas de los demás proyectos citan `PRY-2xx-nombre/00-gobierno/...`. Es una causa probable, no verificada contra el código del índice. Mientras no se corrija, el informe muestra esos 33 datos como sustentados y la verificación automática no los resuelve.

### Formatos que no se pudieron leer
Ninguno reportado por el índice.

### Siguiente paso
No hace falta barrido: no hay nada que releer. Se ofrece corregir las 33 citas de PRY-203 anteponiendo `PRY-203-aportes-sociales-en-línea/`, mostrando el cambio campo por campo. No se ha tocado ninguna ficha.
