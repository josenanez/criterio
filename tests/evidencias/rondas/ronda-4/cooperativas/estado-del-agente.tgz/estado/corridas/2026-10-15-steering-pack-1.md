# Corrida del 2026-10-15 · steering-pack

13 proyectos · 83 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Paquete de comité 2026-10-22: 8 decisiones, 5 escalamientos. Dije que no sé: decisiones del comité anterior (sin registro), autoridad de cambios (13/13 sin declarar), quién es el core y qué reglamento, si FV-1451 está pagada.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** las 13 de `estado/records/` (PRY-199 a PRY-211), cortes entre 2026-09-23 y 2026-10-15, y el cálculo `portafolio.py compute` con corte 2026-10-15. Apoyo: las salidas de esta misma fecha de change-control (PRY-200), raid-log y vendor-tracking (PRY-200). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo). Comité siguiente según la configuración: 2026-10-22.

# Comité de proyectos — 2026-10-22 (material preparado el 2026-10-15)
8 decisiones · 5 escalamientos sin decisión asociada · 9 de 13 proyectos con hallazgos (64 señales abiertas)

**Antes de leer:** en las 13 fichas la autoridad de cambios (`identity.authority`) no está declarada. Por eso el punto 1 es quién decide. Los "quién decide" de abajo salen del comité nombrado en cada acta, no de una autoridad documentada; si el punto 1 se resuelve distinto, se corrigen.

## Decisiones del comité anterior
Sin dato. Ninguna ficha trae decisiones de comité registradas (`decisions`: vacío en las que revisé) y no hay acta de un comité de portafolio en la carpeta. No puedo decir qué se decidió, qué se hizo ni qué sigue abierto. Los comités semanales de proyecto (p. ej. PRY-200, 2026-10-05) solo dejan compromisos, no decisiones. Las 5 solicitudes de cambio abiertas llevan `decision: pending`, sin decisor.

## Decisiones de hoy

### [1] ¿Quién tiene facultad para aprobar cambios de alcance, tiempo y costo, y hasta qué umbral?
**Proyecto:** todos (13 de 13 sin autoridad declarada) · **Quién decide:** Consejo de Administración (único órgano con autoridad documentada, en PRY-199, 200 y 202; el resto nombra otro comité) · **Si no se decide hoy:** los puntos 2 a 5 se quedan sin un decisor claro; hoy dos proyectos ya movieron su fecha sin aprobación.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Umbral único del portafolio: el gerente decide hasta un monto y de días; lo que pase sube a su comité | Sin cambio | Decisiones locales rápidas | Tope fijado por el Consejo; el monto lo fija el Consejo, no lo propongo |
| B. Todo cambio que toque alcance sube al comité del proyecto | Cada ampliación pasa por comité | Una semana más por cambio | Sin tope; más carga de comité |
| C. Dejarlo por proyecto, en cada acta | Sin cambio | Sin cambio | Sin cambio; el vacío sigue |
**Recomendación:** A. Con 5 solicitudes pendientes y ningún decisor, B satura el comité y C perpetúa el vacío. El umbral es del Consejo; yo no lo invento.

### [2] ¿Se aprueba el CC-01 de PRY-203 (ampliación de alcance, +115 días, +230.000.000 COP) y se registra su línea base?
**Proyecto:** PRY-203 Aportes sociales en línea · **Quién decide:** Comité de Tecnología (por el acta; autoridad no declarada) · **Si no se decide hoy:** el cronograma v2 (fin 2027-07-06) ya aplica el cambio sin aprobación y el acta dice 2027-05-30; el proyecto sigue con +115 días (24,8 %) contra la original sin respaldo.
Datos: proyección 2.833.558.895 COP frente a 2.400.000.000 aprobados (+18,1 %); hito «Ambiente de pruebas certificado» vencido 5 días; informe declara amarillo con 7 señales sin explicar.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar y crear línea base 2 | Entra la ampliación | Fin 2027-07-06 (+115 d contra la original) | +230.000.000 COP pedidos; la proyección ya supera el aprobado en 18,1 % |
| B. Rechazar y volver al alcance original | Sin ampliación | Revertir cronograma v2; fecha del acta 2027-05-30 | Sin costo adicional; la proyección sigue por encima |
| C. Aprobar en parte, diferir la ampliación a otro proyecto | Parcial | Intermedio, no calculable con lo disponible | No calculable |
**Recomendación:** A solo si el sponsor confirma por escrito el motivo y quién absorbe el costo; sin motivo, B. Es la única opción que cierra la brecha entre acta, cronograma y solicitud. Nota: la solicitud dice «+115 días sobre la línea base vigente», pero el cálculo mide +115 días contra la original y 0 contra la vigente: el cronograma v2 ya lo incorporó.

### [3] ¿Se aprueba el CC-01 de PRY-210 (+84 días, +168.000.000 COP) cuando patrocinador y gerente son la misma persona?
**Proyecto:** PRY-210 Corresponsales rurales · **Quién decide:** Comité de Tecnología; el gerente no puede decidir sobre sí mismo (Liliana Torres es patrocinadora y gerente) · **Si no se decide hoy:** la línea base ya se movió 84 días (19,6 %) sin autorización y el informe sigue en verde con 6 señales sin explicar.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar con un patrocinador distinto designado | Entra la ampliación | Fin 2027-04-24 (+84 d) | +168.000.000 COP; proyección actual 762.685.964 sobre 800.000.000 aprobados (−4,7 %) |
| B. Rechazar | Sin ampliación | Volver a la fecha original | Sin costo adicional |
| C. Diferir hasta separar los roles | Sin cambio | Sigue +84 d sin respaldo | Sin cambio |
**Recomendación:** C con plazo: designar patrocinador distinto y decidir en el siguiente comité. Aprobar un cambio con un solo firmante repite el hallazgo. Si el comité no puede separar los roles, B.

### [4] ¿Se deciden los CC-01 (+63 días, +126.000.000 COP) y CC-02 (+104 días, +208.000.000 COP) de PRY-205, o se unifican?
**Proyecto:** PRY-205 Prevención de lavado de activos · **Quién decide:** Comité de Riesgos (por el acta) · **Si no se decide hoy:** dos solicitudes de ampliación pendientes (2026-10-02 y 2026-10-14) sin decisor; fin vigente 2027-04-14.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar ambas | Dos ampliaciones | +63 y +104 días; si se acumulan no está dicho | +126.000.000 y +208.000.000 COP; margen: proyección 8.762.266.701 sobre 9.500.000.000 aprobados (−7,8 %) |
| B. Aprobar una y rechazar la otra | Una ampliación | Solo una | Solo una |
| C. Pedir una solicitud unificada | A definir | A definir | A definir |
**Recomendación:** C. Las dos son del mismo proyecto con 12 días entre sí y no dicen si se suman; hay que saberlo antes de decidir. No sumé los días ni los montos: las fichas no dicen si son acumulativos.

### [5] ¿Qué se hace con la solicitud de mover 30 días la salida a producción de PRY-200?
**Proyecto:** PRY-200 Crédito de libranza digital · **Quién decide:** Consejo de Administración (por el acta; autoridad de cambios no declarada) · **Si no se decide hoy:** la línea base v1 queda vencida desde 2026-06-21 (116 días), con los 5 hitos marcados como cumplidos sin evidencia y 44 % declarado contra el 100 % que sostiene el plan.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Rechazar la solicitud tal como llegó y exigir replanificación real | Sin cambio declarado | Nueva fecha y línea base 2 con motivo | No consta; la proyección deja 13.556.258 COP de margen (0,4 %) |
| B. Aprobar +30 días desde hoy (2026-11-14) | Sin cambio | +146 días contra la original | No declarado |
| C. Aprobar +30 días sobre la base (2026-07-21) | Sin cambio | Fecha ya pasada | Sin sentido como base |
**Recomendación:** A. No consta quién pide ni por qué, y 2026-07-21 ya pasó. Antes de elegir B hay que fijar qué fecha rige (cronograma 2026-06-21 o acta 2026-07-27) y confirmar si hubo salida a producción.

### [6] ¿Se retiene el pago de la factura FV-1451 (930.019.665 COP) del contrato CT-451 hasta tener el acta de la Bolsa de horas?
**Proyecto:** PRY-200 · **Quién decide:** no determinable. El contrato exige acta firmada por el gerente (Gustavo Neira, firmante de las dos actas existentes) y las fichas no dicen quién aprueba pagos. Se sube al comité para que lo nombre. · **Si no se decide hoy:** la factura sigue radicada en cuentas por pagar; cubre 3 entregables y hay actas de 2. Licenciamiento lleva 392 días vencido.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener hasta tener el acta o un desglose sin la Bolsa de horas | Sin cambio | Puede demorar la relación con el proveedor | Se difiere 310.006.555 COP (un entregable) |
| B. Pagar completa | Sin cambio | Sin demora | 930.019.665 COP sin soporte de un tercio |
| C. Pagar dos tercios y retener la Bolsa de horas | Sin cambio | Sin demora | 620.013.110 COP ahora |
**Recomendación:** A o C, según lo que diga contabilidad. No sé si la factura está pagada: solo dice «radicada». Si ya se pagó, el punto pasa a recuperación, no a retención.

### [7] ¿Quién es el doliente de la dependencia «proveedor del core cooperativo» y con qué fecha se compromete la integración?
**Proyecto:** PRY-201, 203, 204 y 209 (dependen); PRY-202 Core cooperativo es el candidato, sin confirmar en ninguna ficha · **Quién decide:** Consejo de Administración (comité de PRY-202); lo que ninguno de los gerentes puede resolver solo · **Si no se decide hoy:** el hito «Integración con el core cooperativo» de PRY-202 (vencía 2026-10-12) sigue pendiente; PRY-202 está en verde con 4 alertas y el avance declarado, 36 %, frente a 50–75 % que sostiene el plan.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Nombrar a PRY-202 como doliente y pedirle fecha firme a los cuatro | Sin cambio | Fecha formal de entrega | Sin costo declarado; PRY-202 tiene 18.000.000.000 aprobados y proyección de −7,6 % |
| B. Cada proyecto negocia con el proveedor | Sin cambio | Sin coordinación | Posible duplicación |
| C. Congelar los cuatro hasta que se entregue | Se pausan 4 proyectos | Atraso sin medir | Sin medir |
**Recomendación:** A. Es una dependencia compartida y B es lo que hay hoy. Es una inferencia mía que el «core» sea PRY-202; confírmenla antes de decidir.

### [8] ¿Cuándo se pronuncia el Consejo sobre el reglamento ajustado?
**Proyecto:** PRY-199, 202, 204, 205, 206, 207, 208, 210 (9 ítems sobre el mismo texto, si es un solo reglamento; las fichas no lo confirman) · **Quién decide:** Consejo de Administración · **Si no se decide hoy:** los pilotos de PRY-210 (2026-11-05) y PRY-208 (2026-11-24) dependen de esa respuesta.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Pronunciarse en este comité con fecha y condiciones | Sin cambio | Destraba los ítems | Sin costo declarado |
| B. Pronunciarse en el siguiente | Sin cambio | Una semana más | PRY-210 queda a 14 días del piloto |
| C. Devolver con ajustes y una nueva fecha | Puede cambiar el reglamento | Depende de los ajustes | No calculable |
**Recomendación:** A. Una sola respuesta mueve nueve ítems y el doliente es el propio Consejo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-211 | Rojo: CT-884 con 4 entregables `pending` (3 vencidos: 247, 128 y 8 días), 513.489.020 COP facturados sin entrega aceptada y proyección 17,3 % sobre lo aprobado (11.146.984.265 contra 9.500.000.000) | Informe 2026-10-15 | Que el comité diga si lo trata como el punto 6 (retención de pago) y pida plan de recuperación |
| PRY-200, 207, 210 | Entregables de proveedor vencidos: CT-451 Licenciamiento 392 días; CT-315 Parametrización 216 días; CT-220 228 y 39 días; CT-252 204 días | 2025-09-18 a 2026-09-06 | Doliente por contrato y fecha nueva del proveedor |
| PRY-203 | Compromisos replanteados 6 veces (María Restrepo, original 2026-10-01) y 5 veces (Sandra Gil, original 2026-09-18); 2 vencidos y 3 sin fecha | Septiembre–octubre 2026 | Fecha fija o descartar el compromiso |
| PRY-206 | En silencio 22 días con informe en verde del 2026-09-23 (umbral: 15) | 2026-09-23 | Informe nuevo; hasta entonces el verde no se sostiene |
| Varios (200, 203, 204, 205, 209) | «Hallazgo de seguridad en la revisión de arquitectura» con la misma redacción en cinco proyectos, sin doliente ni fecha | Sin fecha | Aclarar si es uno o cinco, y asignar doliente |

## Para conocimiento
- PRY-199 Cambio de mobiliario: verde, 20 %, sin señales.
- PRY-200 Crédito de libranza digital: amarillo, 44 %, 9 señales (puntos 5 y 6).
- PRY-201 Apertura de ahorro en línea: verde, 31 %, sin señales; depende del core (punto 7).
- PRY-202 Core cooperativo: verde declarado contradicho por 4 señales (punto 7).
- PRY-203 Aportes sociales en línea: amarillo, 44 %, 13 señales (punto 2).
- PRY-204 Tarjeta débito: rojo declarado, 70 %, sin señales calculadas; proyección +4,5 % sobre lo aprobado (por debajo del umbral de 10 %).
- PRY-205 Prevención de lavado: amarillo, 47 %, 2 cambios pendientes (punto 4).
- PRY-206 Pagos con QR: verde, 22 días en silencio.
- PRY-207 Microcrédito rural: amarillo, 74 %, fecha de fin 2026-04-28 ya pasada, 7 señales.
- PRY-208 Motor de crédito: amarillo, 25 % declarado frente a 75–100 % que sostiene el plan.
- PRY-209 Convenios de libranza: verde declarado, 86 %, fecha de fin 2026-05-11 ya pasada; 3 hitos cumplidos sin evidencia.
- PRY-210 Corresponsales rurales: verde declarado contradicho por 6 señales (punto 3).
- PRY-211 Cobranza digital: rojo, 44 % (escalamiento arriba).

## Anexo
**Verde contradicho por la evidencia (4 de 13):** PRY-202, 206, 209 y 210. **Hitos cumplidos sin evidencia:** PRY-200 (5 de 5), 207 (4), 209 (3), 208 (3), 210 (2), 211 (2), 202 (1), 203 (1).

**Contradicciones abiertas:**
- PRY-203: fin 2027-05-30 (acta, 2025-11-25) contra 2027-07-06 (cronograma v2, 2026-10-12); la más reciente es la del cronograma.
- PRY-200: cierre 2026-07-27 (acta) contra salida 2026-06-21 (cronograma); 36 días entre dos documentos del mismo día.
- PRY-202 y PRY-199: «se reprogramó la salida por el cierre contable» y el cronograma v1 no lo refleja.

**Vacíos de información:**
- 13 de 13 sin autoridad de cambios ni fase.
- Sin ningún supuesto registrado.
- 38 de 38 ítems de RAID sin doliente y sin fecha.
- Campos con más de 12 meses de antigüedad en PRY-200, 206, 207, 209 y 211.
- No se pudo medir «sin movimiento en dos períodos»: hay un solo corte.
- Vigencia de CT-451 sin dato.
- Cifras de costo de las extensiones: solo las que traen las solicitudes; no estimé ninguna.
- No leí los `.docx` ni `.pdf` originales: uso lo que las fichas ya extrajeron.

---
**Pie:** criterio-portfolio 0.3.10 · fichas aplicadas: PRY-199 a PRY-211 (corte 2026-10-15) · cifras derivadas copiadas del `compute`; las diferencias que calculé yo (620.013.110 COP = 2 × 310.006.555) están marcadas como aritmética propia y son de verificar · campos inciertos: autoridad de cambios (13/13), quién es «el core» y «el reglamento», si FV-1451 está pagada, vigencia de CT-451 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10 · borrador de trabajo, la verificación contra los originales es de quien decide.
