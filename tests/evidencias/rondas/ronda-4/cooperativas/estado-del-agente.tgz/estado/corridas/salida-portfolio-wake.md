## 2026-10-15

**Revisé:** 82 documentos · 0 cambiaron · 0 proyectos recalculados (no hubo `/portfolio-scan`: `projects_to_recompute` vacío). Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Nada nuevo por documentos. Una observación del índice: reporta 32 citas de PRY-203 como «source_missing» (acta de constitución, informe de avance, cronograma v2, notas del 15-oct). Los archivos existen en la carpeta del proyecto; las rutas del bloque `pm_record` de la ficha van relativas a la carpeta del proyecto y no a la raíz de documentos, así que parece un desajuste de rutas y no documentos perdidos. No lo corregí; conviene confirmarlo.

### Preguntas
Primera confirmación (nunca se había hecho). Nadie respondió en esta corrida de prueba: quedan preguntadas el 2026-10-15, sin respuesta, y no se repiten.

1. **PRY-203, línea base v2** — el fin pasó de 2027-03-13 a 2027-07-06 (+115 días) y el motivo figura «not_found» (cronograma-v2.csv, 2026-10-12). ¿Quién aprobó la v2 y por qué?
2. **PRY-203, CC-01** — ampliación de alcance, +115 días y 230.000.000 COP, decisión «pending» sin quién decide (solicitud-cambio-cc-01.md, 2026-10-04). ¿Quién decide y cuándo?
3. **PRY-203, hito «Ambiente de pruebas certificado»** — fecha 2026-10-10, sigue «pending» sin evidencia (cronograma-v2.csv, 2026-10-12). ¿Se cumplió? ¿Hay acta?
4. **PRY-203, hallazgo de seguridad** — incidencia sin fecha de origen ni responsable (informe-avance.pdf, 2026-10-12). ¿Quién lo tiene y desde cuándo?
5. **PRY-203, riesgo del proveedor del core** — sin responsable; y el riesgo de que no llegue con el equipo completo se dijo en la reunión del 15-oct y nadie lo registró. ¿Quién lo asume?

**Vuelvo el 2026-10-16.**
