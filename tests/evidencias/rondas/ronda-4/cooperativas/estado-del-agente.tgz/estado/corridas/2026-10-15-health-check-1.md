# Corrida del 2026-10-15 · health-check

13 proyectos · 75 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Diagnóstico de PRY-210 sobre 11 documentos: dictamen 4 sostenido / 11 sin sustento / 5 contradicho. Verde declarado contradicho por seis señales; línea base v2 sin motivo ni autorización; dos hitos cerrados sin acta; factura CT-252 por encima del contrato. Dijo que no sabe quién autorizó la v2, el avance real, la ejecución contable ni si lo facturado se recibió.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-210 Corresponsales rurales · 2026-10-15

**Leí:** 11 documentos · del 2025-11-07 al 2026-10-08 · formatos: docx (3), xlsx (2), md (4), pdf (2). Además busqué PRY-210, "corresponsales", CT-220 y CT-252 en los demás documentos del portafolio (minutas y seguimientos de otros proyectos): ninguno lo menciona.
**No pude leer:** nada quedó sin leer. Las dos facturas (pdf) se leyeron como texto, sin imagen de firmas o sellos; no puedo decir si están firmadas.
**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

### Dictamen
**Sostenido:** 4 afirmaciones · **Sin sustento:** 11 · **Contradicho:** 5 (20 revisadas)

Desde esta carpeta se puede afirmar que el proyecto tiene un acta con presupuesto de 800.000.000 COP, que la integración con el core cooperativo tiene acta de recibo (2026-10-08), que hay una solicitud de cambio CC-01 sin autorizar y que se facturaron 77.586.508 COP (CT-220) y 96.239.531 COP (CT-252). No se puede afirmar que esté en verde: el informe del 2026-10-03 lo declara verde con 38 % de avance, y seis señales independientes lo contradicen (hito cerrado sin evidencia, avance contra plan, línea base movida sin autorización, desviación de tiempo, entregables de proveedor vencidos, factura por encima de lo aceptado). Los documentos de evidencia suman 0; las cifras de dinero son todas declaradas por la misma persona que patrocina y gerencia el proyecto.

Afirmaciones revisadas:
- **Sostenido (4):** presupuesto aprobado 800.000.000 COP (acta); Integración con el core cooperativo recibida (acta 2026-10-08); CC-01 pendiente de comité (la propia solicitud); patrocinador y gerente = Liliana Torres (acta).
- **Contradicho (5):** estado verde; avance 38 %; fecha vigente de salida a producción 2027-04-24; factura FV-1252; "Dependencias: ninguna declarada".
- **Sin sustento (11):** comprometido, ejecutado y proyección declarados; Diseño funcional aprobado cerrado; Ambiente de pruebas certificado cerrado; Bolsa de horas CT-220 recibida; Bolsa de horas CT-252 recibida; factura FV-2220; aprobación del presupuesto por el Comité de Tecnología el 2025-11-17; "se recibió el concepto del ente supervisor"; "dos semanas perdidas por rotación".

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Liliana Torres | 00-gobierno/2025-11-17-acta-constitucion.docx |
| Gerente | Liliana Torres (la misma persona) | 00-gobierno/2025-11-17-acta-constitucion.docx |
| Autoridad declarada | No está. El acta no dice qué puede aprobar el gerente ni hasta dónde | 00-gobierno/2025-11-17-acta-constitucion.docx |
| Comité | Comité de Tecnología; la única minuta (2026-10-02) lista como asistentes a "Liliana Torres, Liliana Torres" | 30-reuniones/2026-10-02-comite-semanal.md |

Sin autoridad declarada no hay desviación aprobada: hay fechas que alguien escribió. Además no existe ningún acta del Comité de Tecnología que apruebe el presupuesto ni la línea base. Producto asociado: "No aplica"; fase: no declarada. El alcance del acta es "Componente 1, 2, 3" y la exclusión es "Lo que otro proyecto cubre": no permiten saber qué se construye ni qué no.

### Contra el plan
- **Línea base original (v1):** acta y cronograma del 2025-11-17; salida a producción 2027-01-30.
- **Vigente (v2, 2026-10-03):** salida a producción 2027-04-24. Motivo de la replanificación: **no consta** en ningún documento. Desviación contra la original: **84 días (19,6 %)**; contra la vigente: 0 días. Supera el umbral de 10 %.
- **Sin autorización:** la v2 es del 2026-10-03; CC-01 (que pide +84 días "sobre la línea base vigente" y 168.000.000 COP adicionales por ampliación de alcance) es del 2026-10-04 y dice "pendiente de presentación al comité". Cambios autorizados: 0 días; movidos: 84 días. Es decir, la línea base se movió antes de que el cambio que la justifica se presentara, y aún no está decidido.
- **Dos fechas que no cuadran:** el acta fija cierre 2027-03-14; la salida a producción vigente (2027-04-24) queda después de esa fecha de cierre.
- **Avance:** declarado 38 %; el cronograma marca 3 de 5 hitos cerrados, lo que sostiene entre 60 % y 80 %. Diferencia: 22 puntos. Aquí la declaración está por debajo del cronograma, y el propio cronograma tiene dos de esos tres hitos sin evidencia; no sé cuál de las dos cifras es la verdadera.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado (marcado cerrado) | 2026-02-20 | 237 | Acta de recibo / aprobación del diseño funcional |
| Ambiente de pruebas certificado (marcado cerrado) | 2026-05-17 | 151 | Certificación o acta de recibo del ambiente de pruebas |

Integración con el core cooperativo (2026-08-11) sí tiene acta de recibo, pero está fechada 2026-10-08, y el cronograma sigue mostrando 2026-08-11 como fecha vigente y el hito como cerrado sin registrar el atraso. Recibió Liliana Torres, que es también patrocinadora y gerente. Piloto con asociados (2026-11-05) aún no vence.

Entregables de proveedor vencidos (contratos):
| Contrato | Entregable | Fecha | Días | Documento esperado |
|---|---|---|---|---|
| CT-220 Soluciones Solidarias | Licenciamiento del módulo | 2026-03-01 | 228 | Acta de recibo firmada por el gerente |
| CT-220 Soluciones Solidarias | Parametrización de líneas de crédito | 2026-09-06 | 39 | Acta de recibo firmada por el gerente |
| CT-252 Datos para Cooperativas | Licenciamiento del módulo | 2026-03-25 | 204 | Acta de recibo firmada por el gerente |

Los contratos marcan "Bolsa de horas de desarrollo" como recibida (CT-220, fecha 2026-06-03; CT-252, fecha 2026-07-21), pero no hay acta de recibo en la carpeta.

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 800.000.000 | 386.935.777 | 334.067.490 | 762.685.964 | 413.064.223 |

Ejecutado 41,8 % del aprobado; comprometido 48,4 %; proyección 4,7 % por debajo de lo aprobado. Las cuatro cifras salen solo del informe del 2026-10-03; no hay ningún documento contable que las respalde. Si CC-01 (168.000.000 COP adicionales) se aprobara, no consta si la proyección ya lo incluye.

Facturación contra aceptación:
- **CT-220:** facturado 77.586.508 COP (FV-2220, 2026-09-03). Equivale al monto de un entregable; el contrato exige acta de recibo firmada y no hay ninguna.
- **CT-252:** facturado 96.239.531 COP (FV-1252, 2026-09-23); el contrato fija 69.732.354 COP por entregable. Facturado por encima de lo aceptado: **26.507.177 COP**. Ambas facturas dicen "Entregables del contrato", sin decir cuáles.
- No calculé la suma de los contratos contra el "comprometido" declarado (el script no la entrega); los montos por entregable están arriba para quien quiera cotejarla. Los dos contratos listan entregables con el mismo nombre (licenciamiento, bolsa de horas, parametrización de líneas de crédito) a dos proveedores distintos: el documento no explica la división.

### Lo que se dijo y nadie registró
- **Riesgo:** "Aprobación del reglamento por el Consejo de Administración": está en el informe, sin responsable ni fecha, y contradice "Dependencias: ninguna declarada" del acta. Es una dependencia externa no registrada como tal.
- **Incidencia:** pérdida de dos semanas por rotación de un desarrollador clave: sin desde cuándo, sin responsable, y sin reflejo en el cronograma.
- **Dependencia / hecho no soportado:** "se recibió el concepto pendiente del ente supervisor": no hay documento del concepto ni del trámite.
- **Compromiso:** Laura Vélez, "Entregar el punto 1", para 2026-10-30 (minuta del 2026-10-02). No vence aún. Pero Laura Vélez no figura entre los asistentes y "el punto 1" no dice cuál es. No hay registro RAID del proyecto en la carpeta.
- **Dependencia con otro proyecto:** el hito "Integración con el core cooperativo" coincide con el nombre del proyecto PRY-202 Core cooperativo; ningún documento de PRY-210 declara esa relación. Es una pregunta, no un hallazgo.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe 2026-10-03: "Verde" | Cronograma v2 + CC-01 + contratos + facturas: seis señales (ver Dictamen) |
| Avance 38 % | Informe 2026-10-03 | Cronograma v2: 3 de 5 hitos cerrados (60–80 %) |
| Salida a producción 2027-04-24 vigente | Cronograma v2 (2026-10-03) | CC-01 (2026-10-04): cambio pendiente de comité; acta: cierre 2027-03-14 |
| Dependencias: ninguna | Acta de constitución | Informe 2026-10-03: riesgo del Consejo de Administración y concepto del ente supervisor |
| Factura FV-1252 por 96.239.531 COP | Factura | Contrato CT-252: 69.732.354 COP por entregable |

### Sin sustento
- Comprometido, ejecutado y proyección (solo en el informe, sin soporte contable).
- Hitos "Diseño funcional aprobado" y "Ambiente de pruebas certificado" como cerrados.
- Bolsa de horas recibida en CT-220 y en CT-252, y la factura FV-2220 (sin acta de recibo, que es la condición de pago).
- Aprobación del presupuesto por el Comité de Tecnología el 2025-11-17: la afirma el acta, pero no hay acta de comité.
- Recibo del concepto del ente supervisor; las dos semanas perdidas por rotación.

### Lo que esta carpeta no permite saber
- **Quién autorizó la línea base v2 ni por qué:** sin motivo ni autorización, los 84 días no se pueden tratar como desviación aprobada.
- **Qué se está construyendo:** el alcance es "Componente 1, 2, 3", así que no se puede juzgar si CC-01 (ampliación) es de verdad una ampliación.
- **Si el avance real es 38 % o 60–80 %:** depende de si los dos hitos sin acta se cumplieron.
- **Cuánto se ha ejecutado realmente:** no hay libro contable ni ejecución presupuestal; sin eso, el disponible real de 413.064.223 COP es una resta de cifras declaradas.
- **Si lo facturado se entregó:** sin actas de recibo, no se puede decir si lo facturado (77.586.508 COP y 96.239.531 COP) corresponde a trabajo recibido; no sumo las dos facturas porque el script no entrega esa cifra.
- **Si hay supervisión independiente:** patrocinador, gerente y quien recibe entregables son la misma persona; la única minuta de comité tiene un solo asistente repetido. Ninguna decisión del proyecto tiene una segunda firma.

### Pie de rigor
Cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-15). El conteo 4 / 11 / 5 es mi clasificación de 20 afirmaciones, listadas arriba para que se pueda revisar. Todos los datos citan el documento original; las fechas de los documentos del caché coinciden con las del registro. Esto es un borrador de trabajo: la verificación es de quien lo lee. No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad.

**Siguiente paso posible:** (a) preparar el punto de comité con la lista de lo que falta, o (b) llevarle las cinco contradicciones a la gerente como preguntas, una por una. Como gerente y patrocinadora son la misma persona, conviene decidir antes quién más las recibe.
