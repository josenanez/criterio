**Sale de:** contrato CT-451 (`00-gobierno/2025-06-24-contrato-ct-451.docx`), dos actas de recibo (`20-seguimiento/2026-03-07-acta-recibo-ct-451-parametrización-de-líneas-de-crédito.pdf` y `20-seguimiento/2026-05-23-acta-recibo-ct-451-mesa-de-ayuda-del-primer-trimestre.pdf`), factura FV-1451 (`20-seguimiento/2026-09-16-factura-ct-451.pdf`), informe de avance del 2026-09-23 y comité del 2026-10-05. Las cifras derivadas salen de `portafolio.py compute` (corte 2026-10-15). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## Proveedores — PRY-200 Crédito de libranza digital al 2026-10-15

### Red Rural de Pagos S.A.S. — contrato CT-451
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato (el contrato solo declara fecha de firma, 2025-06-24, entregables y condición de pago)

**Condición de pago (contrato):** cada entregable se factura contra acta de recibo firmada por el gerente del proyecto.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo | 2025-09-18 | `pending` (contrato: "en curso") | Ninguna | Sin desglose |
| Bolsa de horas de desarrollo | 2025-12-05 | `delivered` declarado (contrato: "recibido") | **Ninguna** | Sin desglose |
| Parametrización de líneas de crédito | 2026-02-21 | `accepted` | Acta de recibo 2026-03-07, firmada por Gustavo Neira | Sin desglose |
| Mesa de ayuda del primer trimestre | 2026-05-10 | `accepted` | Acta de recibo 2026-05-23, firmada por Gustavo Neira | Sin desglose |

Cada entregable vale 310.006.555 COP. Lo facturado por el proveedor es 930.019.665 COP (FV-1451, 2026-09-16, "Entregables del contrato CT-451", radicada en cuentas por pagar). La factura no dice a qué entregables corresponde.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Lo facturado frente a lo aceptado | Se factura contra acta firmada | Hay actas de dos entregables. El monto facturado (930.019.665 COP) equivale al de tres entregables; el script cuenta como aceptados 3 de 4 y 930.019.665 COP aceptados, porque incluye la Bolsa de horas, que no tiene acta. | Contrato CT-451; FV-1451; las dos actas |
| Bolsa de horas de desarrollo | Estado "recibido" | No hay acta, correo ni mención en minuta | Contrato CT-451; carpeta `20-seguimiento` |
| Licenciamiento del módulo | Comprometido para 2025-09-18, "en curso" | Sin entrega ni acta; 392 días de atraso | Contrato CT-451 |
| Salida a producción | — | La ficha da el hito "Salida a producción" (2026-06-21) como cumplido, sin evidencia, y con el licenciamiento del módulo sin entregar. No puedo decir si el módulo es requisito de la salida. | Cronograma v1; contrato CT-451 |

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Bolsa de horas de desarrollo | `delivered` (el contrato dice "recibido") | Fecha comprometida 2025-12-05; no hay fecha de recibo |

### Compromisos del proveedor vencidos
Ninguno. Ninguna reunión de la carpeta registra una promesa de Red Rural de Pagos. El único compromiso abierto del comité del 2026-10-05 es de Natalia Ospina ("Entregar el punto 31"), con fecha "por definir", y ella no figura entre los asistentes; no hay nada en la carpeta que diga que sea del proveedor. Sin fecha no puede vencer, pero tampoco se puede seguir.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso del CT-451: el documento no los trae. No se puede decir si hay un preaviso por vencer.
- A qué entregables corresponde la factura FV-1451 y si está pagada: solo dice "radicada en cuentas por pagar".
- Facturas anteriores, si las hubo: no hay otras en la carpeta.
- Acta de recibo o correo de aceptación de la Bolsa de horas de desarrollo.

## Lo que sigue
- Hallazgo principal: una factura de 930.019.665 COP radicada contra un contrato que exige acta firmada, con actas para dos entregables y no para tres. Antes de aprobar el pago, pedir a Gustavo Neira el acta de la Bolsa de horas o desglose de la factura sin ese entregable. Si quieres, lo llevo a comité como punto.
- Licenciamiento sin entregar con 392 días de atraso: se necesita una fecha nueva del proveedor y la decisión de si el atraso afecta la salida a producción.
- Fuera del proveedor pero relacionado: los 5 hitos del cronograma figuran como cumplidos sin evidencia, y el avance declarado es 44% frente a un 100% que sostendría el plan.

*Rigor: las cifras de atraso, el conteo de aceptados y los montos aceptados vienen del script; los montos por entregable y el valor de la factura, de los documentos citados. No leí los PDF originales, sino su texto en la caché. Que no haya acta en la carpeta no prueba que no exista: puede estar en otro sitio.*
