## Historia · PRY-205 Prevención de lavado de activos · 2026-01-03 a 2026-10-14

**Leí:** 4 documentos entre 2026-01-03 y 2026-10-14 (1 acta de constitución, 2 solicitudes de cambio, 1 informe de avance)
**Trimestres sin un solo documento:** 2026-T2 (abr–jun) y 2026-T3 (jul–sep). Entre el acta del 2026-01-03 y la CC-01 del 2026-10-02 hay nueve meses sin ningún documento.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hubo que registrarlos de nuevo.

### En una línea
Del proyecto hay un acta (2026-01-03) y, nueve meses después, tres documentos en trece días: CC-01 (2026-10-02), el informe de avance (2026-10-03) y CC-02 (2026-10-14). No hay ninguna replanificación aprobada: la línea base sigue siendo la del acta (cierre 2027-04-14), pero las dos solicitudes de cambio, ambas pendientes, suman +167 días y 334.000.000 COP si se aprobaran. Lo que se declara (amarillo, 47%) no tiene hitos contra los cuales contrastarse.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 0 | 0 días (`slip_vs_original_days`) | No se puede calcular: la ficha no tiene hitos ni evidencia | 0 documentados |

- Las 2 solicitudes de cambio (CC-01 +63 días, CC-02 +104 días, ambas sobre «la línea base vigente») están pendientes; no se cuentan como atraso ni como replanificación porque nadie las aprobó.
- Los +167 días y los 334.000.000 COP son la suma simple de las dos solicitudes. No salen de `compute`; se dan solo como aritmética de lo escrito en los documentos. La CC-02 calcula su impacto sobre la línea base vigente, que no incluye la CC-01, así que si ambas se aprueban hay que confirmar si los +104 ya cuentan los +63.

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2026-01-03 | 00-gobierno/2026-01-03-acta-constitucion.md | Se aprueba el proyecto: 9.500.000.000 COP (Comité de Riesgos), inicio 2026-01-13, cierre 2027-04-14. Patrocinador Gustavo Neira, gerente Rubén Cárdenas. Alcance: «Componente 1, 2, 3». |
| 2026-10-02 | 20-seguimiento/2026-10-02-solicitud-cambio-cc-01.md | Rubén Cárdenas solicita ampliación de alcance: +63 días, +126.000.000 COP. Pendiente de presentación al comité. |
| 2026-10-03 | 20-seguimiento/2026-10-03-informe-avance.md | Estado declarado amarillo, 47%. Prueba de carga bajo el umbral y se repite; el Consejo pidió ajustar el reglamento antes del piloto; hallazgo de seguridad en la revisión de arquitectura. Comprometido 4.143.034.840, ejecutado 3.056.546.748, proyección 8.762.266.701. |
| 2026-10-14 | 20-seguimiento/2026-10-14-solicitud-cambio-cc-02.md | Segunda ampliación de alcance, once días después de la primera: +104 días, +208.000.000 COP. Pendiente de presentación al comité. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| — | — | — | Ninguna: la línea base tiene una sola versión (acta, 2026-01-03; cierre 2027-04-14) | — |

Hay dos solicitudes que, de aprobarse, moverían el cierre; ninguna tiene decisión (`decision: pending`, sin quien decida). Ninguna dice por qué amplía el alcance: solo «Ampliación de alcance».

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Sin cambios documentados. Patrocinador (Gustavo Neira), gerente (Rubén Cárdenas) y comité (Comité de Riesgos) son los del acta. | — |

Con cuatro documentos no se puede descartar un cambio de gobierno ocurrido en los trimestres sin documentos; solo se puede decir que ninguno quedó escrito.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno: no hay minutas ni transcripciones en la carpeta, y la ficha no tiene compromisos | — | — |

### Desde cuándo lo declarado no se sostiene
No se puede fijar la fecha. La ficha no tiene hitos (`milestones: []`), así que no hay un «primer hito sin evidencia» ni contra qué comparar el 47% declarado el 2026-10-03. De las fuentes de la ficha, 0 son evidencia, 3 son declaración y 15 no están marcadas.

Lo que sí se ve:
- El único informe de avance es de 2026-10-03; antes no hay ninguno, por lo que no hay serie de estados declarados que recorrer.
- El informe dice amarillo, pero reporta tres hechos que lo tensionan (prueba de carga fallida, reglamento por ajustar, hallazgo de seguridad) sin fecha de inicio (`since: no_declarada`) y sin responsable.
- El avance de 47% se reporta con 32,2% del presupuesto ejecutado y 43,6% comprometido, y con la proyección 7,8% por debajo del aprobado. Esa relación no se puede evaluar sin plan por hitos.

### Lecciones ancladas a un hecho
Ninguna sustentable todavía. Cada lección necesita hecho, fecha y efecto, y el efecto (atraso, sobrecosto, impacto) no está medido: no hay replanificación aprobada ni hitos. Se dejan dos preguntas abiertas, que no son lecciones:
- ¿Qué pasó entre 2026-01-03 y 2026-10-02? No hay documentos de esos nueve meses, y el hecho de que no existan ya es un hallazgo de la historia.
- ¿Por qué dos ampliaciones de alcance en once días, justo después de una prueba de carga fallida y un hallazgo de seguridad? Los documentos no lo dicen.

### Lo que no sé
- Hitos y fechas intermedias (el acta no los trae; el alcance es «Componente 1, 2, 3»).
- Quién decidirá CC-01 y CC-02, y cuándo se presentan al comité (próximo comité configurado: 2026-10-22).
- Fase, producto y autoridad del proyecto (campos no encontrados).
- Si hubo reuniones, cambios de gobierno o compromisos en los trimestres sin documentos.

### Pie de rigor
Cifras copiadas de `portafolio.py compute` (as_of 2026-10-15), salvo las sumas de +167 días y 334.000.000 COP, que son aritmética propia sobre las dos solicitudes. Todo dato sale de los cuatro documentos citados en la línea de tiempo; la verificación es de quien lee. No se atribuye intención a nadie: que las solicitudes lleguen juntas y tarde dice cuándo quedaron escritas, no por qué.

Siguiente paso posible: llevar las dos solicitudes pendientes al comité del 2026-10-22 como una sola decisión, o conseguir los documentos de abril a septiembre para poder reconstruir esos meses.
