**Acta previa:** sí existe. Acta de constitución de PRY-201, aprobada el 2026-06-07 (`PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2026-06-07-acta-constitucion.docx`). Es el único documento de gobierno de la carpeta; el otro es el informe de avance del 2026-10-12. Términos vigentes (versión 0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15).

## Acta — PRY-201 Apertura de ahorro en línea
**Estado:** existe, del 2026-06-07

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **Ausente.** No hay monto ni tipo de cambio que Mauricio Pérez pueda decidir sin comité. | Toda desviación, por pequeña que sea, no tiene dueño de decisión claro y termina en el Comité de Educación. Hoy la proyección al cierre (808.267.389 COP) supera lo aprobado (800.000.000 COP) en 8.267.389 COP (1,03 %): el acta no dice si eso lo resuelve el gerente o hay que subirlo. |
| Objetivo de negocio | **Débil.** "Entregar apertura de ahorro en línea para Operaciones" describe la solución, no el resultado de negocio. | Sin un resultado esperado (cuentas abiertas, costo por apertura, canal sustituido) no hay forma de saber si el proyecto sirvió, solo si se entregó. |
| Alcance | **Con marcadores sin completar.** "Componente 1, 2, 3". | No se puede decidir qué es un cambio de alcance porque el alcance no dice qué contiene. Cualquier solicitud de cambio se discute sin referencia. |
| Exclusiones | **Con marcador sin completar.** "Lo que otro proyecto cubre". | No nombra qué proyecto ni qué cubre. Si hay traslape con otro proyecto del portafolio, el acta no lo permite detectar. |
| Criterio de éxito | **Parcial.** "En producción y medido". | No dice qué se mide, con qué umbral ni quién lo mide. "Medido" no es un criterio: el cierre no podrá declararse cumplido ni fallido. |
| Supuestos y restricciones | **Ausentes.** El acta no tiene sección. | El informe del 2026-10-12 ya reporta como riesgo la dependencia del proveedor del core cooperativo; nada de eso quedó pactado desde el inicio como supuesto. |
| Dependencias | **Declara "Ninguna declarada".** | Contradice el informe de avance, que lista "Dependencia del proveedor del core cooperativo" y que el proveedor no ha confirmado la fecha de la última entrega. Una dependencia real sin registrar en el acta no tiene dueño ni fecha de control. |
| Hitos principales | **Ausentes.** Solo hay inicio (2026-06-17) y cierre (2027-05-03). | Con 31 % reportado no hay contra qué comparar el avance. El "verde" declarado no se puede contrastar con un plan por hitos. |
| Comité y cadencia | **Comité nombrado, cadencia ausente.** | No se sabe cada cuánto debe reportar ni cuándo un silencio es anormal. |
| Patrocinador / gerente | Presentes con nombre de persona: Jorge Medina y Mauricio Pérez. | — |
| Presupuesto aprobado | Presente: 800.000.000 COP, Comité de Educación, 2026-06-07. | — |

### Contenido
**Objetivo de negocio:** pendiente de definir. Lo que dice el acta es "Entregar apertura de ahorro en línea para Operaciones", que es la solución, no un objetivo medible.
**Alcance:** pendiente de definir. El acta lista "Componente 1, Componente 2, Componente 3" sin contenido.
**Exclusiones:** pendiente de definir. El acta dice "Lo que otro proyecto cubre", sin nombrar el proyecto.
**Patrocinador:** Jorge Medina · **Gerente:** Mauricio Pérez
**Autoridad del gerente:** pendiente de definir. El acta no la declara; no se completa con un valor razonable.
**Comité al que reporta:** Comité de Educación · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Apertura de ahorro en línea en producción y medido" (sin métrica ni umbral) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo inicio 2026-06-17 y cierre 2027-05-03.

Fuentes: acta de constitución 2026-06-07 para todo lo anterior; informe de avance 2026-10-12 para la contradicción de dependencias y las cifras de presupuesto (aprobado 800.000.000, comprometido 585.968.484, ejecutado 243.883.065, proyección 808.267.389 COP).

### Para que lo verifique una persona
- El acta asigna el proyecto de Operaciones y producto "ahorro a la vista" al **Comité de Educación**. No sé si es el comité correcto; no hay en la carpeta un documento que lo confirme ni lo contradiga.
- No leí documentos fuera de los dos de la carpeta de PRY-201. Si la autoridad del gerente o los hitos están pactados en otro lado (un correo, una reunión), no consta en lo que tengo.

## Después
- **Autoridad sin declarar:** ofrezco llevar esa definición al comité como decisión (monto y tipo de cambio que puede resolver el gerente sin subir). Es una decisión, no un trámite. Respuesta tomada en esta prueba: sí, queda ofrecido; no lo preparo hasta que me lo pidan.
- **Supuestos que salieron de la revisión:** la dependencia del proveedor del core y la fecha de última entrega sin confirmar. Ofrezco pasarlos al registro RAID (`/raid-log`). Respuesta tomada: sí, queda ofrecido; no lo ejecuto aquí.

**Pie de rigor:** esto es un borrador de trabajo, no una decisión ni asesoría. Se basa solo en dos documentos de la carpeta de PRY-201; cada dato lleva su fuente y la verificación es de quien lo use. No sé lo que se habló fuera de esos documentos.
