# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 82 documentos, 0 releídos y 82 sin cambio · 164 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

47 de 82 documentos leídos, 10 fichas nuevas (PRY-199..210 sin 203 ni 207), 35 sin cambio; no existe entrada/, nada movido ni omitido. Mirar: PRY-210 (cierre ambiguo, v2 aplicado antes de aprobar CC-01, facturas sin acta), PRY-200 y PRY-209 con cierre vencido, hitos cerrados sin acta, 3 solicitudes de cambio pendientes.

Contra la corrida del 2026-10-15: +36 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`). No hubo que volver a pedirlos. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10

**Qué encontré:** una carpeta con 82 documentos en 13 proyectos (PRY-199 a PRY-211). Formatos: 35 .md, 18 .pdf, 16 .docx, 7 .xlsx, 4 .csv, 1 .txt y 1 .json. Los 13 proyectos tienen carpeta propia. No existe carpeta `entrada/`.

**Documentos:** 82 en la carpeta · 47 leídos · 35 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos · 0 sin carpeta propia

Plan ejecutado tal cual: 1 lote de 10 proyectos, uno tras otro en esta conversación, sin subagentes. Nada quedó diferido. PRY-203, PRY-207 y PRY-211 no cambiaron y no se abrieron.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de mobiliario de agencias | 6 | identidad, plan, presupuesto, 5 hitos, 1 contrato (CT-199), RAID, 1 compromiso | autoridad del gerente, fase |
| PRY-200 Crédito de libranza digital | 8 | ídem, 5 hitos, 1 contrato (CT-451) con factura, 1 compromiso | autoridad, fase |
| PRY-201 Apertura de ahorro en línea | 2 | identidad, plan (solo acta), presupuesto, RAID | autoridad, fase; sin cronograma ni contrato |
| PRY-202 Core cooperativo | 5 | identidad, plan, 4 hitos, presupuesto, RAID, 1 compromiso | producto ("No aplica"), autoridad, fase |
| PRY-204 Tarjeta débito para asociados | 2 | identidad, plan (solo acta), presupuesto, RAID | autoridad, fase; sin cronograma |
| PRY-205 Prevención de lavado de activos | 4 | identidad, plan (solo acta), presupuesto, RAID, 2 solicitudes de cambio | producto ("No aplica"), autoridad, fase; sin cronograma |
| PRY-206 Pagos con QR | 2 | identidad, plan (solo acta), presupuesto, RAID | autoridad, fase; sin cronograma |
| PRY-208 Motor de crédito | 4 | identidad, plan, 4 hitos, presupuesto, RAID, 1 compromiso | producto ("No aplica"), autoridad, fase |
| PRY-209 Convenios de libranza con empresas | 3 | identidad, plan, 3 hitos, presupuesto, RAID | producto ("No aplica"), autoridad, fase |
| PRY-210 Corresponsales rurales | 11 | identidad, 2 líneas base, 5 hitos, 2 contratos con facturas, 1 solicitud de cambio, RAID, 1 compromiso | producto ("No aplica"), autoridad, fase; fecha de cierre `ambiguous` |

### Actualizados
Ninguno. Los tres proyectos con ficha previa (PRY-203, PRY-207, PRY-211) no tuvieron documentos nuevos ni cambiados y se conservan tal cual.

### Qué hay que mirar (leído en los documentos; los cálculos y las señales los hace el script)
- **Contradicción sin umbral, PRY-210:** el acta fija el cierre el 2027-03-14; el cronograma v2 (2026-10-03) mueve "Salida a producción" al 2027-04-24, después del cierre. Ese corrimiento (+84 días) coincide con la solicitud CC-01, que está "pendiente de presentación al comité" y es del 2026-10-04, un día después del v2. El informe de avance sigue en verde (38 %). La ficha deja la fecha de cierre `ambiguous` con las dos fuentes.
- **Hitos declarados cerrados sin acta de recibo que los pruebe:** PRY-200 (5 de 5), PRY-208 (3), PRY-209 (3), PRY-210 (2), PRY-202 (1). Con acta del hito que nombran: PRY-199, PRY-202 y PRY-210, uno cada uno. Se registró la declaración y el vacío de prueba; no se cambió el estado.
- **PRY-200:** el cierre comprometido (2026-07-27) ya pasó y el cronograma v1 da por cerrada la salida a producción (2026-06-21), pero el informe del 2026-09-23 reporta amarillo y 44 %. La factura FV-1451 (930.019.665 COP) cubre el contrato CT-451, y solo hay acta de recibo de 2 de sus 4 entregables.
- **PRY-209:** cierre comprometido 2026-07-03 ya pasado; el informe del 2026-10-15 reporta verde y 86 %.
- **Facturas sin acta de recibo, PRY-210:** FV-2220 (77.586.508) y FV-1252 (96.239.531) no tienen ninguna acta de recibo de sus contratos. El valor de FV-1252 no coincide con el de un entregable de CT-252 (69.732.354 cada uno). Además la condición de pago de ambos contratos exige acta firmada.
- **Cambios pendientes:** PRY-205 tiene CC-01 (+63 días, 126.000.000 COP) y CC-02 (+104 días, 208.000.000 COP), ambas pendientes de comité. PRY-210 tiene CC-01 (+84 días, 168.000.000 COP). Ninguna tiene decisión.
- **Gobierno, PRY-210:** el patrocinador y el gerente son la misma persona (Liliana Torres) y la minuta del comité del 2026-10-02 la lista dos veces como asistente.
- **Informes que dicen que se reprogramó, sin plan nuevo:** PRY-199 y PRY-202 mencionan "se reprogramó la salida", pero solo existe el cronograma v1.
- **Presupuesto:** en PRY-202 y PRY-204 el ejecutado declarado es mayor que el comprometido declarado. PRY-204 se reporta en rojo (70 %).
- **Compromisos:** 5 nuevos (PRY-199, 200, 202, 208, 210). Los 5 los asumen personas que no figuran como asistentes de la minuta donde quedaron anotados. El de PRY-200 (Natalia Ospina) dice "por definir" y se registró como `no_declarada`, que es un hallazgo y no un vencido.
- **Sin cronograma ni contrato, así que sin hitos ni entregables que medir:** PRY-201, PRY-204, PRY-205, PRY-206.

### No pude leer
| Archivo | Por qué |
|---|---|
| — | Ninguno: los 82 se convirtieron a texto sin errores. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| — | — | No existe carpeta `entrada/`; no se movió nada. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| — | Ninguno. |

---
criterio-portfolio 0.3.10 · fichas tocadas: 10 (PRY-199, 200, 201, 202, 204, 205, 206, 208, 209, 210) · campos en `not_found`: 25 en total (autoridad y fase en los 10; producto en 5, donde el acta dice "No aplica") · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
