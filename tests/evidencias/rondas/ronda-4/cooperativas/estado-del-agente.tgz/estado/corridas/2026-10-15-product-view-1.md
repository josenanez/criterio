# Corrida del 2026-10-15 · product-view

13 proyectos · 28 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Producto de un solo proyecto (PRY-204): sin sección de producto. Declarado rojo sin alertas calculadas ni evidencia; ejecutado mayor que comprometido sin explicar; 5 proyectos sin producto reportados.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Fichas de `estado/records` (13 proyectos), cálculo `portafolio.py compute` con corte al 2026-10-15. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-15.

## Producto «tarjeta débito» al 2026-10-15

«Tarjeta débito» tiene un solo proyecto, PRY-204 *Tarjeta débito para asociados*. La vista por producto no aporta nada con un solo proyecto, así que no armo sección de producto. Estos son los datos de ese proyecto:

- **Alertas calculadas:** 0. Eso no equivale a estar sano. El gerente declara estado **rojo** y 70 % de avance (informe del 2026-10-03, 12 días de antigüedad). Las 3 fuentes que respaldan los datos son declaraciones y ninguna es evidencia. Ni el cálculo ni los documentos muestran qué hay detrás del rojo.
- **Fecha comprometida del producto:** 2027-02-16 (la única, de PRY-204). Sin atraso contra la línea base original ni contra la vigente (0 días, 0 replanificaciones).
- **Dinero (COP, las cuatro cifras presentes):** aprobado 4.200.000.000; comprometido 2.044.466.248; ejecutado 2.463.577.669; proyección 4.389.905.182 (4,5 % sobre lo aprobado, bajo el umbral de 10 %). Ejecutado 58,7 %; comprometido 48,7 %.
  - **Hay que revisarlo:** el ejecutado es mayor que el comprometido. No lo corrijo ni lo explico, porque los documentos no lo aclaran.
- **Dependencias internas:** ninguna, porque el producto tiene un solo proyecto. La ficha registra como riesgo, sin dueño, la «dependencia del proveedor del core cooperativo». Es una declaración del informe de avance, no una dependencia confirmada con PRY-202 *Core cooperativo*, y PRY-202 no tiene producto declarado. Tampoco hay dueño para el riesgo «concentración del conocimiento en una sola persona».
- **Vacíos de la ficha:** falta la autoridad (`identity.authority`) y la fase (`identity.phase`). Proveedores: ninguno registrado.

## Proyectos sin producto declarado

Los reporto aquí, aunque no los pidió la vista, porque la consulta era por un producto. Nadie puede responder por el conjunto al que sirven.

| Proyecto | Área dueña |
|---|---|
| PRY-202 Core cooperativo | Ahorro y aportes |
| PRY-205 Prevención de lavado de activos | Canales digitales |
| PRY-208 Motor de crédito | Canales digitales |
| PRY-209 Convenios de libranza con empresas | Cartera y cobranza |
| PRY-210 Corresponsales rurales | Operaciones |

Las dependencias internas sin confirmar no pasan de una sola decisión de comité: no hay dos proyectos del mismo producto que dependan entre sí. Lo único que queda para el comité es decidir a qué producto pertenece PRY-202, para poder confirmar o descartar la dependencia de PRY-204.

Fuentes: `estado/records/PRY-204.json` y la salida de `compute`.
