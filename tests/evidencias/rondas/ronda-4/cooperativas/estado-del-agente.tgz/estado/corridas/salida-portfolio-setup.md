## Listo — Cooperativa

**Miré:** 82 documentos en 13 proyectos · formatos: .md (35), .pdf (18), .docx (16), .xlsx (7), .csv (4), .json (1), .txt (1) · más reciente: 2026-10-15
**Eres:** PMO del portafolio (hay varios proyectos; tomé la respuesta sugerida)
**Te aviso:** dos días antes del comité del 2026-10-22 (los comités se llaman «semanales»; tomé esa cadencia)
**En:** presentación (respuesta sugerida)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.3.10 (términos 1.1), fecha 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 5a63e87d0ce9d540…

Preguntas hechas a la persona: ninguna (sesión de prueba sin interfaz; cada respuesta se tomó del valor sugerido y se dijo en una línea).

Configuración en `.criterio/portafolio/config.json`. Documentos en `documentos/proyectos`; lo que Vera va encontrando en `estado`; informes en `reportes`.

### Probé con tres proyectos

Cuatro proyectos empataban con documentos del 2026-10-15 (PRY-203, 207, 209, 211). Tomé PRY-203, PRY-207 y PRY-211, que tienen más documentos. Las fichas quedaron en `estado/records/` y selladas.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-207 Microcrédito rural | 9 | Gerente Laura Vélez, patrocinador Óscar Ramírez, presupuesto 4.200 M COP, cierre comprometido 2026-05-25. Declara amarillo y 74 % (corte 2026-10-14). Contrato CT-315 con 3 entregables, 2 recibidos con acta, 1 facturación de 684.568.088 COP. | Facultad del gerente, etapa. |
| PRY-211 Cobranza digital | 7 | Gerente Beatriz Cuéllar, patrocinador Camilo Beltrán, presupuesto 9.500 M COP, cierre 2027-06-03. Declara rojo y 44 % (corte 2026-10-15). Contrato CT-884 con 4 entregables de 513.489.020 COP cada uno. | Facultad del gerente, etapa. |
| PRY-203 Aportes sociales en línea | 19 | Gerente Ricardo Salas, patrocinadora Elena Duarte, presupuesto 2.400 M COP, cierre 2027-05-30. Declara amarillo y 44 % (corte 2026-10-12). Solicitud de cambio CC-01 pendiente. Trae `ficha-pm.json` del gerente, guardada aparte en `pm_record`. 26 compromisos tomados de 6 comités y las notas del 2026-10-15. | Facultad del gerente, etapa, proveedores. |

### Hallazgos (28 señales; todas salen del cálculo)

**PRY-211 Cobranza digital**
- Facturado sin entrega: se facturaron 513.489.020 COP (factura del 2026-09-26) contra el contrato CT-884, y ninguno de sus 4 entregables tiene acta de recibo. El único acta del proyecto es la del ambiente de pruebas, que es un hito, no un entregable del contrato.
- Entregables del proveedor atrasados: licenciamiento (247 días, vencía 2026-02-10), bolsa de horas (128 días) y parametrización (8 días).
- Sobrecosto proyectado: 11.146.984.265 COP contra 9.500.000.000 aprobados (+17,3 %).
- Avance declarado de 44 % frente a 60–80 % que sustenta el plan (3 de 5 hitos cerrados): 16 puntos de diferencia.
- Dos hitos declarados cerrados sin acta que lo pruebe: Diseño funcional aprobado y Integración con el core cooperativo.

**PRY-207 Microcrédito rural**
- Cuatro hitos declarados cerrados sin acta: Ambiente de pruebas, Integración con el core, Piloto con asociados y Salida a producción (de 170 a 327 días desde su fecha). Solo Diseño funcional tiene acta, firmada el 2026-10-15.
- Avance declarado de 74 % frente a 100 % que sustenta el plan (los 5 hitos figuran cerrados): 26 puntos de diferencia.
- Entregable del proveedor atrasado: Parametrización de líneas de crédito, 216 días (vencía 2026-03-13).
- Un compromiso vencido: Gustavo Neira, «Entregar el punto 4», para el 2026-10-14.

**PRY-203 Aportes sociales en línea**
- Línea base movida sin autorización: +115 días (la integración con el core pasa de 2027-03-13 a 2027-07-06), y CC-01 sigue pendiente de comité con autorizado en cero.
- Contradicción entre fuentes: la ficha del gerente dice cierre 2027-05-30 y el cronograma v2 pone la última entrega el 2027-07-06.
- Sobrecosto proyectado: 2.833.558.895 COP contra 2.400.000.000 (+18,1 %).
- Hito vencido: Ambiente de pruebas certificado, 5 días (2026-10-10). Diseño funcional declarado cerrado sin acta.
- Compromisos reprogramados: «Enviar el documento 1» (María Restrepo) seis veces, de 2026-10-01 a 2026-12-11; «Cerrar la prueba 2» (Sandra Gil) cinco veces, de 2026-09-18 a 2026-11-28.
- Compromisos vencidos: Carlos Peña (documento 9, 6 días) y Felipe Arango (ambiente 20, 10 días).
- Compromisos sin fecha: Mauricio Pérez (diseño 5), Óscar Ramírez (punto 24), Laura Vélez (ajuste del presupuesto).

### El portafolio completo
10 proyectos más (PRY-199, 200, 201, 202, 204, 205, 206, 208, 209, 210) y 47 documentos, en 2 lotes uno tras otro. Con lo que costó esta prueba, calculo entre 20 y 30 minutos de conversación. No lo medí con reloj.

### Lo que le falta a tu carpeta
Ninguno de estos es bloqueante.
- Las tres actas de constitución leídas no dicen hasta qué monto puede decidir el gerente sin subir a comité. Sin eso, el control de cambios no puede saber si un cambio excede su facultad.
- Cuatro hitos de PRY-207 y dos de PRY-211 están «cerrados» en el cronograma sin acta de recibo. Si las actas existen, no están en la carpeta.
- Los cronogramas de PRY-207 y PRY-211 son la versión 1 sin cambios, aunque el cierre de PRY-207 ya pasó hace casi cinco meses.
- Las notas del 2026-10-15 de PRY-203 están sueltas en la raíz del proyecto, no en `30-reuniones`, y traen una fecha ambigua («11/12/2026») y otra relativa («la otra semana»).
- Los compromisos «por definir» y los que se reprograman cada semana no dicen quién decide ni por qué se mueven.
- Ninguno de los tres proyectos tiene una etapa declarada.

Sigue: correr el portafolio completo. Como PMO con equipo, también puedes publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios.
