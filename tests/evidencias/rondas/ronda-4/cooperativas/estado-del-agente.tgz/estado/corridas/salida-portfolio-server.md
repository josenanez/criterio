# /portfolio-server — Rostrum (modo: para mirarlo un rato)

**Términos:** ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`). No hizo falta pedirlos de nuevo. Resumen: Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita de su documento y la verificación es de la persona. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Forma elegida:** «para mirarlo un rato» (es el argumento `rato`). Se levanta, se mira y se apaga con Ctrl-C. No hay enlace estable para el patrocinador mañana.

**Informe encontrado:** `reportes/` (13 proyectos PRY-199 a PRY-211, 7 productos, `index.html`, `proyectos.html`, `productos.html`, `decisiones.html`). No hay `pmo.html` en esa carpeta: la sección `/pmo` puede no responder hasta que `/portfolio-report html` la genere.

**Comando:**

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-4/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-4/cooperativas/espacio/estado --config /home/claude/banco/ronda-4/cooperativas/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo (`--puerto 8788` si está ocupado).

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada y formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por atención requerida | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos`, `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo la petición, en `estado/peticiones/`), no autentica, no manda nada. El servidor no puede correr el agente: las peticiones esperan hasta que `due` las cuente.

**Enlace y vigencia:** para mirarlo un rato no hay enlace que pasar al patrocinador. El informe es del 2026-10-15; la portada muestra su fecha. Para dejarlo corriendo hay que pedir un host y puerto internos y publicarlo detrás del control de acceso de la organización; con `--abierto`, sin autenticación propia.
