# Corrida del 2026-10-15 · change-control

13 proyectos · 45 s · 64 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `vendor_deliverable_late` | 8 |
| `progress_vs_plan` | 7 |
| `commitment_undated` | 4 |
| `declared_vs_evidence` | 4 |
| `vendor_accepted_without_evidence` | 3 |
| `commitment_overdue` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `variance_cost` | 2 |
| `commitment_rescheduled` | 2 |
| `rebaseline_unauthorized` | 2 |
| `pm_vs_pmo` | 1 |
| `silent` | 1 |
| `vendor_invoiced_over_accepted` | 1 |
| `vendor_invoiced_without_delivery` | 1 |

Solicitud de mover la salida a producción de PRY-200 30 días. La salida evalúa el cambio como no aplicable tal cual: el hito base (2026-06-21) venció hace 116 días y +30 da una fecha ya pasada. Sin dependencias declaradas (impact: 0 alcanzados), sin autoridad de cambios declarada, sin motivo ni solicitante. No sé: costo de la extensión, vencimiento de CT-451, qué fecha rige (acta 07-27 vs cronograma 06-21), ni si el hito marcado como cerrado lo está.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Sale de la ficha `estado/records/PRY-200.json` (corte del informe: 2026-09-23) y del cálculo `portafolio.py impact` con 30 días.

## Solicitud de cambio — PRY-200 Crédito de libranza digital — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días. · **Quién lo pide:** no consta en la solicitud. · **Por qué:** no consta; ningún documento de la carpeta trae el motivo.

**Antes de evaluar: la solicitud no se puede aplicar tal como está escrita.** Tomé la respuesta sugerida (calcular desde la línea base vigente) y lo dejo dicho:

- La línea base única (v1, 2025-06-22) fija «Salida a producción» el **2026-06-21**. Sumarle 30 días da **2026-07-21**, que ya pasó hace 86 días. El hito base ya venció hace **116 días**.
- El cronograma v1 marca ese hito como «cerrado», sin evidencia de salida a producción. Eso contradice el informe del 2026-09-23: estado amarillo, **44 %** de avance, y un hallazgo de seguridad abierto sin responsable ni fecha. Un proyecto al 44 % no está en producción. El criterio de éxito del acta es «en producción y medido».
- El acta de constitución dice cierre **2026-07-27**; el cronograma dice 2026-06-21. Son 36 días de diferencia entre dos documentos del mismo día, y ningún documento los reconcilia.
- Si lo que se quiere es «30 días desde hoy», la fecha sería 2026-11-14. Eso es otra solicitud, no la que llegó.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Componentes 1, 2 y 3 (acta) | Sin cambio declarado | Ninguna declarada |
| Tiempo | Salida 2026-06-21 (cronograma) / cierre 2026-07-27 (acta) | 2026-07-21 (calculado) o 2026-11-14 (si se cuenta desde hoy) | +30 días pedidos; el atraso real contra la línea base ya es de 116 días y sigue sin reconocerse |
| Costo | Aprobado 3.300.000.000 COP · ejecutado 1.362.657.814 · proyección 3.286.443.742 | No declarado | No consta. No lo estimo: no hay costo diario ni de mantener al proveedor. La proyección deja 13.556.258 COP (0,4 %) de margen, así que cualquier extensión probablemente lo excede |

**Quién absorbe:** el alcance no cambia y el costo no se declara, así que 30 días más los absorbe el equipo en horas no pagadas o la calidad. El riesgo registrado, «concentración del conocimiento en una sola persona», lo agrava, y no tiene responsable.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El cálculo no encuentra proyectos alcanzados: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha | — |

Esto no significa que no haya efecto. El acta declara «Dependencias: ninguna declarada», y la ficha tiene la lista de dependencias vacía. El cálculo solo recorre lo declarado. El producto «crédito de libranza» y el contrato con el proveedor sí dependen de la fecha (ver más abajo). Cuántos días se mueve cada actividad no se puede calcular, porque no hay holgura por actividad.

**Proveedor (CT-451, Red Rural de Pagos):** el vencimiento del contrato está en un `.docx` que no leí en esta corrida, así que no sé si 30 días más lo exceden. Además hay facturados 930.019.665 COP (tres entregables) y solo dos tienen acta de recibo. «Licenciamiento del módulo» figura pendiente desde 2025-09-18 y «Bolsa de horas» como entregado sin acta. Eso debe aclararse antes de ampliar un plazo que el proveedor también cobra.

### Quién decide
**Autoridad requerida:** no determinable. La autoridad de cambios no está declarada (`identity.authority`: no encontrada). · **Según:** el acta nombra al Consejo de Administración como comité y como aprobador del presupuesto; no dice qué umbral de cambio le toca a quién. · **Va a comité:** **sí**, por defecto. El Consejo es el único órgano con autoridad documentada, y un cambio de fecha con atraso de 116 días y presupuesto sin margen no debe decidirlo solo el gerente. Próximo comité: 2026-10-22.

Hallazgo de fondo: no hay autoridad de cambios declarada.

### Si no se aprueba
El proyecto sigue con una línea base vencida desde 2026-06-21 y un hito marcado como cerrado que no lo está. No hay solicitud de cambio previa registrada (`changes`: vacío) ni línea base nueva. Desde la perspectiva de los documentos, ya son 116 días de atraso sin ningún documento que lo autorice, y eso hay que llevarlo al comité aunque el cambio no se apruebe.

### Si se aprueba
Línea base 2 — salida: **2026-07-21 si se aplica literalmente (ya vencida; no tiene sentido como línea base)**, o 2026-11-14 si se cuenta desde hoy · presupuesto: sin cambio declarado (3.300.000.000 COP) · motivo: **no consta**; hay que obtenerlo antes de registrar.
Desviación acumulada contra la línea base original: **tiempo, +116 días** a hoy (+146 con 30 más, 2026-11-14 contra 2026-06-21; +110 contra la fecha del acta, 2026-07-27, si esa fuera la vigente) · **costo, sin cambio declarado**; la proyección está dentro del aprobado por 13.556.258 COP.
El conteo de replanificaciones pasaría de 0 a 1. La línea base v1 no se toca.

## Lo que no sé
- Quién pide el cambio, el motivo y la fecha de referencia de los 30 días.
- Si el hito de producción realmente se cerró. La evidencia dice que no, pero el informe no lo afirma.
- Costo de la extensión, vencimiento del contrato CT-451 y si hay dependencias reales no declaradas.
- Qué fecha rige: la del acta (2026-07-27) o la del cronograma (2026-06-21).

## Siguiente paso
Llevarlo al comité del 2026-10-22 con estas cuatro preguntas resueltas. No registro línea base nueva: nadie con autoridad documentada la ha aprobado.

---
**Pie de rigor:** salen de la ficha PRY-200 (acta 2025-06-22, cronograma v1, informe de avance 2026-09-23, acta del comité 2026-10-05) y del cálculo `impact`. Los días y márgenes son aritmética de esas fechas y montos; ninguna cifra de costo del cambio fue estimada. Es un borrador de trabajo: la verificación contra los originales es de quien decide.
