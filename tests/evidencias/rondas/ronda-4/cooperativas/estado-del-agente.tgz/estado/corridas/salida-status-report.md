Informe generado desde la ficha `estado/records/PRY-206.json` (actualizada 2026-10-15) y el cálculo de `portafolio.py compute` con corte 2026-10-15.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 para la versión 0.3.10); no hizo falta registrarlos de nuevo.

## PRY-206 Pagos con QR — estado al 2026-10-15

**Declara el gerente (Elena Duarte):** verde · 64% · al 2026-09-23 (hace 22 días)
**Sustento documental:** sin sustento. Los dos documentos del proyecto son el acta de constitución y el propio informe de avance; este último es una declaración. No hay ninguna fuente de evidencia (sources: evidencia 0, declaración 3).
**Lo que el semáforo no explica:** `silent` — el proyecto lleva 22 días sin documentos nuevos (umbral: 15 días).
**Último documento:** 2026-09-23 · **Última reunión:** sin dato (ningún documento registra una reunión)

Alertas del script: `silent` y `declared_vs_evidence` (el gerente reporta verde y hay una señal que ese verde no cubre). Aunque la declaración tiene menos de 30 días de edad, ya no es reciente respecto al silencio posterior.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-02-11 | 2027-02-11 | 0 días (original y vigente) |
| Presupuesto aprobado | COP 2.400.000.000 | COP 2.400.000.000 | — |

Replanificaciones: 0. Una sola línea base (v1, 2025-10-30, acta de constitución).

Presupuesto (declarado por el gerente el 2026-09-23, no contrastado con otra fuente):
- Comprometido: COP 1.708.940.032 (71.2% del aprobado)
- Ejecutado: COP 534.840.876 (22.3%)
- Proyección al cierre: COP 2.216.045.578 (-7.7% frente a lo aprobado)
- Disponible real: COP 691.059.968

El avance declarado es 64% mientras lo ejecutado es 22.3%; el informe no explica esa diferencia y el plan no tiene hitos con los que contrastarla.

### Hitos
Sin dato: la ficha no tiene ningún hito (`plan.milestones` vacío). No se puede decir si el 64% tiene respaldo en el plan.

### Dónde no coincide
- **Declarado:** verde, 64% (informe de avance, 2026-09-23).
- **Documentos:** el mismo informe menciona que el equipo perdió dos semanas por la rotación de un desarrollador clave, pero la fecha de cierre no se movió y no hay solicitud de cambio ni replanificación. Un atraso de dos semanas reconocido sin reflejo en el plan es lo que el verde no explica. Además, desde esa fecha no hay un solo documento nuevo.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: aprobación del reglamento por el Consejo de Administración — sin responsable, sin fecha de registro (informe 2026-09-23).
- Incidencia: pérdida de dos semanas por rotación de un desarrollador clave — sin responsable, fecha de inicio «no declarada» (informe 2026-09-23).
Ambos tienen como única fuente el informe del 2026-09-23, hace 22 días.

**Compromisos vencidos:** ninguno registrado (la ficha no tiene compromisos; no hay minutas que los sustenten).
**Dependencias sin confirmar:** ninguna registrada.

### Sin dato
- `identity.authority` (quién aprueba) y `identity.phase` (fase del proyecto): no encontrados.
- Hitos: ninguno.
- Reuniones y compromisos: ninguno.
- Campos con 12 meses de antigüedad (acta del 2025-10-30): código, nombre, área, producto, patrocinador, gerente, comité, fechas de inicio y cierre, alcance y exclusiones. No es que estén mal; llevan 12 meses sin reconfirmarse.

### Después
No hay desviación en fechas por encima del umbral, pero sí un verde con silencio de 22 días y una incidencia de dos semanas que no llegó al plan. Puedo preparar el punto de comité (próximo comité: 2026-10-22) o una solicitud de cambio si el atraso es real y no está formalizado.

---
*Criterio · criterio-portfolio 0.3.10 · Ficha de PRY-206 actualizada el 2026-10-15; declaración del gerente al 2026-09-23 · Campos inciertos: authority, phase, hitos, reuniones · Esto es un borrador de trabajo: la verificación es suya. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal*
