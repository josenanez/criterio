# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-211

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-211

**Inicio:** 2026-10-15T19:34:38 · **Fin:** 2026-10-15T19:35:25 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 32 | 64 | Presupuesto PRY-211: proyección 17.3% sobre aprobado, facturado 513.489.020 sin entregables aceptados, hitos sin evidencia. Dijo no saber: línea base de costo original, desglose del comprometido, fecha de aprobación del vigente. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 21, `vendor_deliverable_late` 8, `progress_vs_plan` 7, `commitment_undated` 4, `declared_vs_evidence` 4, `vendor_accepted_without_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `variance_time` 2, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## Presupuesto — PRY-211 Cobranza digital, al 2026-10-15

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo. Todas las cifras salen de la ficha del proyecto (actualizada el 2026-10-15) y del cálculo del script. La moneda es COP, sin otras monedas ni conversiones.

| | Monto (COP) | % del aprobado |
|---|---|---|
| Aprobado | 9.500.000.000 | — |
| Comprometido | 4.607.236.341 | 48.5 |
| Ejecutado | 3.697.963.264 | 38.9 |
| Proyección al cierre | 11.146.984.265 | 17.3 por encima del aprobado |

- **Fuente de las cuatro cifras:** el informe de avance del 2026-10-15, que es una declaración del gerente.
- **Disponible real:** 4.892.763.659 COP (aprobado menos comprometido).
- **Replanificaciones de presupuesto:** 0, y no hay solicitudes de cambio registradas.

### Ejecución frente a avance
- **Avance declarado:** 44 %. El plan sustenta entre 60 y 80 %, así que el proyecto va 16.0 puntos por detrás.
- **Hitos:** 3 de 5 figuran como cumplidos, pero solo uno tiene acta de recibo (ambiente de pruebas certificado, 2026-10-13). «Diseño funcional aprobado» e «Integración con el core cooperativo» están dados por cumplidos sin evidencia. Con evidencia, el cumplimiento es 1 de 5.

### Alertas
- **Proyección sobre el aprobado:** supera en 17.3 % el aprobado, con un umbral de 10 %.
- **Facturado sin entrega:** Red Rural de Pagos S.A.S. (contrato CT-884) facturó 513.489.020 COP el 2026-09-26 y no tiene ningún entregable aceptado (0 de 4). Tres están vencidos y pendientes, con 247, 128 y 8 días de atraso.
- **Comprometido:** 48.5 %, por debajo del umbral de 90 %, así que no hay alerta de tope.

### Sin dato
- **Línea base de costo original:** no aparece en ningún documento, así que no puedo medir la desviación contra el original.
- **Desglose del comprometido y del ejecutado:** por proveedor o rubro, no está declarado.
- **Fecha de aprobación del presupuesto vigente:** no está declarada, así que no puedo decir si la proyección es más vieja que el último movimiento de presupuesto.

Como la proyección excede el aprobado, puedo preparar la solicitud de cambio con `/criterio-portfolio:change-control`. También puedo detallar el contrato CT-884 con `/criterio-portfolio:vendor-tracking`.

La corrida quedó registrada como `2026-10-15-budget-tracking-1`. El informe completo está en `estado/corridas/salida-budget-tracking.md`.
