# Corrida · 2026-10-15-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-15T19:42:54 · **Fin:** 2026-10-15T19:43:53 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 42 | 64 | Cierre de PRY-200: no se puede determinar el cumplimiento del criterio de éxito; sin evidencia de ningún hito ni de producción, avance declarado 44% contra 5/5 hitos del plan, dos fechas de cierre en conflicto (acta 2026-07-27, cronograma 2026-06-21), RAID abierto sin doliente. Sin lecciones sustentables; no se archivó. |

Por señal (`project-closure`): `milestone_met_without_evidence` 21, `vendor_deliverable_late` 8, `progress_vs_plan` 7, `commitment_undated` 4, `declared_vs_evidence` 4, `vendor_accepted_without_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `variance_time` 2, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

**Cierre de PRY-200 (Crédito de libranza digital), 2026-10-15.** Lo preparé a partir de la ficha, del cálculo de cifras del día y de los siete documentos de la carpeta del proyecto. El proyecto no se puede cerrar por cumplimiento, y no lo archivé. Los términos ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo.

- **Criterio de éxito:** el acta pide "Crédito de libranza digital en producción y medido". Ningún documento muestra que esté en producción ni medido, así que no se puede determinar si se cumplió.
- **Hitos:** los cinco aparecen como "cerrado" en el cronograma de 2025 (que nunca se actualizó), pero ninguno tiene acta ni aprobación. El informe del 2026-09-23 declara 44 % de avance y estado amarillo. La diferencia con el plan es de 56.0 puntos.
- **Dinero:** de 3.300.000.000 COP aprobados, hay 1.362.657.814 ejecutados (41.3 %). La proyección al cierre es 3.286.443.742. Estas cifras salen solo del informe del gerente, sin registro contable. Hay 0 replanificaciones, pero la fecha comprometida ya pasó hace 116 días sin evidencia de salida a producción.
- **Fecha de cierre en conflicto:** el acta dice 2026-07-27 y el cronograma dice 2026-06-21. Usé la del cronograma porque es la línea base de la ficha.
- **Proveedor Red Rural de Pagos (CT-451):**
  - **Licenciamiento:** sigue pendiente, con 392 días de atraso.
  - **Bolsa de horas:** figura como entregada, sin acta de recibo.
  - **Facturado:** 930.019.665 COP, pero solo hay dos actas de recibo; ese monto hay que revisarlo.
- **Abierto sin doliente:** el riesgo de concentración del conocimiento, el hallazgo de seguridad y el licenciamiento pendiente. El compromiso de Natalia Ospina ("Entregar el punto 31") no tiene fecha, y ella no estaba entre los asistentes del comité.
- **Lecciones:** solo dejé las que se anclan a hechos documentados (cuatro). Una lección sobre lo que pasó en el proyecto no se puede sustentar con estos documentos.

La salida completa quedó en `estado/corridas/salida-project-closure.md`. La corrida está registrada como `2026-10-15-project-closure-1`, caso PRY-200, con 42 segundos medidos.

Para poder cerrarlo hace falta evidencia de la salida a producción, un doliente con nombre para cada punto abierto, la fecha de cierre vigente y una decisión registrada del Consejo de Administración. Con eso se puede archivar la carpeta y congelar la ficha.
