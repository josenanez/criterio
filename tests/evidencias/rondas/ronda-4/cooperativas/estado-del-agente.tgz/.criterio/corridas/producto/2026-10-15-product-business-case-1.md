# Corrida · 2026-10-15-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:10:31 · **Fin:** 2026-10-15T19:11:19 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 18 | — | 31 | 42 | Caso de negocio PRD-303 armado: 2 cifras con fuente (volumen declarado 248.461 vs medido 202.628, brecha 18,4% bajo el umbral de 20%); retorno sin valor; costos sin ningún dato; supuesto normativo sin verificar hace 43 días; sin criterio de éxito ni fecha de corte; sin otros productos publicados para cruzar. |

Por señal (`product-business-case`): `evidence_stale` 17, `requirement_untraced` 12, `requirement_undecided` 6, `requirement_without_owner` 3, `requirement_without_acceptance` 2, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1

## Lo que el agente mostró

Armé el borrador del caso de negocio de Tarjeta débito (PRD-303) y registré la corrida. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez.

**Lo que dice el caso**
- **Qué se construye:** el registro tiene 12 requerimientos aceptados y 6 propuestos, todos del acta del 2026-10-12. Ninguno tiene proyecto que lo ejecute. La propuesta de la definición dice solo "Propuesta principal".
- **Volumen mensual:** el caso declara 248.461 (2025-12-27) y el tablero mide 202.628 (2026-09-29). La brecha es del 18,4 %, por debajo del umbral de 20 %. La dejé dentro del caso con las dos cifras y las dos fechas, porque es la primera pregunta de un comité.
- **Retorno:** dice "en 24 meses", sin monto ni tasa. No lo completé con ninguna cifra.
- **Supuesto normativo:** "El reglamento vigente lo permite" sigue sin verificar, 43 días después de declarado.

**Lo que falta**
- Los costos están vacíos. Ningún documento trae el costo de construir ni el del equipo, y ese es el primer vacío.
- No hay criterio de éxito ni fecha de corte. La definición no los trae, así que el producto no se podría cerrar meses después.
- La demanda tiene una sola entrevista genérica, que ningún requerimiento cita de forma concreta.
- REQ-4305, 4306 y 4314 no tienen doliente. REQ-4302 y 2030 no tienen criterio de aceptación. REQ-4301 no tiene quién lo pidió.
- No hay productos publicados con los que cruzar métricas, así que no hice ese cruce.
- La definición está fechada el 2025-12-27, pero registra un supuesto "declarado el 2026-09-02". Lo anoté como algo a confirmar.

La corrida quedó como `2026-10-15-product-business-case-1`, con 42 hallazgos entre 18 requerimientos y 31 segundos de duración. El texto completo está en `estado-producto/PRD-303/corridas/salida-product-business-case.md`.

El siguiente paso que propone el comando es pasar los supuestos a seguimiento con assumption-tracking. `/product-charter` no tiene base todavía, porque el caso no está aprobado.
