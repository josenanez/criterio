# Corrida · 2026-10-15-product-wake-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:51:10 · **Fin:** 2026-10-15T19:51:52 · **Duración:** 43 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-wake` | 18 | — | 26 | 42 | Primera corrida, sin corte anterior: reporté el estado completo, no un delta. No pude confirmar trazas porque ninguna ficha nombra PRD-303; no verifiqué el supuesto del reglamento ni escribí a nadie. |

Por señal (`product-wake`): `evidence_stale` 17, `requirement_untraced` 12, `requirement_undecided` 6, `requirement_without_owner` 3, `requirement_without_acceptance` 2, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1

## Lo que el agente mostró

## Tarjeta débito (PRD-303) · 2026-10-15

Esta es la primera corrida de product-wake y no había corte anterior. Por eso no pude separar lo nuevo de lo que ya estaba, y esto es el estado completo, no un delta. Ya guardé el corte de hoy, así que lo que se repita no volverá a salir como novedad.

El registro tiene 18 requerimientos: 12 aceptados y 6 propuestos. 11 tienen evidencia y ninguno tiene traza a un proyecto.

**Cruzó un umbral sin que nadie hiciera nada**

| Qué | REQ | Cuánto lleva | Quién |
|---|---|---|---|
| Sin decidir (umbral 60 días) | REQ-4309 | 214 días | Sandra Gil |
| Sin decidir | REQ-4303 | 182 días | Rubén Cárdenas |
| Sin decidir | REQ-4313 | 158 días | Liliana Torres |
| Sin decidir | REQ-4310 | 123 días | Mauricio Pérez |
| Sin decidir | REQ-4312 | 84 días | Sandra Gil |
| Sin decidir | REQ-4311 | 65 días | Ricardo Salas |
| Supuesto sin verificar (umbral 30 días): «El reglamento vigente lo permite» | definición | 43 días | Natalia Ospina |
| Evidencia vencida (umbral 12 meses) | 17 requerimientos | 12 meses | Natalia Ospina |

- **Decisión:** la facultad de decidir los seis requerimientos es del Comité de producto. Puedo llevarlos al próximo comité.
- **Supuesto del reglamento:** necesita una verificación normativa citada. Hoy pesa sobre toda la definición.
- **Evidencia vencida:** la única sustentación es una entrevista del 2025-09-19 que el acta no vincula a ningún requerimiento. Las afirmaciones de demanda quedan sin sustento actual.

**Las trazas:** ninguna ficha de `estado/records` nombra PRD-303. Los 12 requerimientos aceptados no tienen proyecto que los construya, y ninguna traza se da por confirmada.

**Del registro**
- Sin doliente: 3 requerimientos, por ejemplo REQ-4305.
- Aceptados sin criterio de aceptación: REQ-2030 y REQ-4302.
- Aceptado sin evidencia: REQ-4301.

**Negocio contra datos**
- **Volumen mensual:** el caso de negocio declara 248.461 y el tablero del 2026-09-29 mide 202.628. La brecha es de 18,4 %, bajo el umbral de 20 %, pero cerca.
- **Retorno esperado:** no tiene cifra declarada.
- **Criterio de éxito:** no aparece en ningún documento.

**Del descubrimiento:** no hay documentos nuevos. La única entrevista es la del 2025-09-19.

**Vuelvo el 2026-11-14.**

**Términos:** ya estaban vigentes (v1.1, aceptados el 2026-10-15 a nombre de José Francisco Ñáñez), así que no pedí aceptación nueva.

**Registro de la corrida:** `2026-10-15-product-wake-1`. Tardó 26 segundos y dejó 42 hallazgos. El informe quedó en `estado-producto/PRD-303/corridas/salida-product-wake.md`.
