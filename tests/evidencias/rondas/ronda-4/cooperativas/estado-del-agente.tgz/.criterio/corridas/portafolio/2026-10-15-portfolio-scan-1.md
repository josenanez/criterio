# Corrida · 2026-10-15-portfolio-scan-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-scan (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:28:10 · **Fin:** 2026-10-15T19:31:14 · **Duración:** 184 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-scan` | 13 | 82 | 164 | 64 | 47 de 82 documentos leídos, 10 fichas nuevas (PRY-199..210 sin 203 ni 207), 35 sin cambio; no existe entrada/, nada movido ni omitido. Mirar: PRY-210 (cierre ambiguo, v2 aplicado antes de aprobar CC-01, facturas sin acta), PRY-200 y PRY-209 con cierre vencido, hitos cerrados sin acta, 3 solicitudes de cambio pendientes. |

Por señal (`portfolio-scan`): `milestone_met_without_evidence` 21, `vendor_deliverable_late` 8, `progress_vs_plan` 7, `commitment_undated` 4, `declared_vs_evidence` 4, `vendor_accepted_without_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `variance_time` 2, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Barrido hecho. Leí 47 de los 82 documentos y creé 10 fichas nuevas, una por cada proyecto de PRY-199 a PRY-210 salvo PRY-203 y PRY-207. Esas dos y PRY-211 no cambiaron y no las abrí. Cada ficha quedó sellada apenas la escribí, y la corrida y la instantánea están registradas (`2026-10-15-portfolio-scan-1`, 164 segundos).

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo nada que registrar. Los 82 documentos se leyeron sin errores, no existe la carpeta `entrada/` y no moví nada.

El script calculó 64 hallazgos sobre los 13 proyectos. Los más importantes:
- **PRY-210:** el cronograma v2 mueve la salida a producción 84 días, hasta el 2027-04-24, que queda después del cierre del acta (2027-03-14). Ese corrimiento coincide con la solicitud de cambio CC-01, que sigue pendiente de comité y es de un día después del v2. Dejé la fecha de cierre como `ambiguous` con las dos fuentes. También hay dos facturas sin acta de recibo, y el patrocinador y el gerente son la misma persona.
- **PRY-200 y PRY-209:** el cierre comprometido ya pasó (2026-07-27 y 2026-07-03). En PRY-200 el cronograma da los 5 hitos por cerrados mientras el informe reporta amarillo y 44 %. En PRY-209 el informe reporta verde y 86 %.
- **Hitos cerrados sin acta de recibo:** 21 en el portafolio. Registré lo que declaran los documentos y dejé la prueba vacía.
- **Solicitudes de cambio pendientes:** PRY-205 tiene dos (CC-01 y CC-02) y PRY-210 una; ninguna tiene decisión.
- **Compromisos:** quedaron 5 nuevos, todos de personas que no figuran como asistentes de la minuta donde se anotaron. El de PRY-200 dice "por definir" y lo registré como sin fecha.

En todas las fichas la autoridad del gerente y la fase quedaron en `not_found`. El producto también, en las cinco donde el acta dice "No aplica".

Un fallo mío: para leer los textos convertidos usé `cat` en lugar de la herramienta de lectura. No pidió aprobación y no cambió nada del resultado.

`salida-portfolio-scan.md` recoge lo que leí en los documentos. No incluye las 64 señales del script, que están en el JSON de la corrida.

¿Genero ahora el informe consolidado del portafolio (`/criterio-portfolio:portfolio-report`)? Hay más de un proyecto y aparecieron contradicciones y compromisos sin fecha, así que conviene.

Archivos en `/home/claude/banco/ronda-4/cooperativas/espacio/estado/`:
- `records/` (las fichas)
- `corridas/salida-portfolio-scan.md`
- `snapshots/2026-10-15.json`

Pie: criterio-portfolio 0.3.10 · fichas tocadas: 10 · campos en `not_found`: 25 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
