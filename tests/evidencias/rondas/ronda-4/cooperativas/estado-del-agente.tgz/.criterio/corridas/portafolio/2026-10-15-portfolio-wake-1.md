# Corrida · 2026-10-15-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:47:42 · **Fin:** 2026-10-15T19:48:29 · **Duración:** 47 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 32 | 64 | Barrido: 82 documentos sin cambios, nada que recalcular; 32 citas de PRY-203 reportadas como source_missing aunque los archivos existen (probable desajuste de rutas relativas en pm_record). Primera confirmación: 5 preguntas sobre PRY-203, sin respuesta (corrida sin interfaz). No pude saber si las rutas son un falso positivo del índice. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 21, `vendor_deliverable_late` 8, `progress_vs_plan` 7, `commitment_undated` 4, `declared_vs_evidence` 4, `vendor_accepted_without_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `variance_time` 2, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

## 2026-10-15

**Revisé:** 82 documentos, 0 cambiaron y 0 proyectos se recalcularon. No hubo peticiones en el servidor.

**Términos:** ya estaban vigentes para la versión 0.3.10. Constan a nombre de José Francisco Ñáñez, con fecha 2026-10-15.

**Barrido:** no hay nada que releer, así que no corrí `/portfolio-scan`. El índice marca 32 citas de PRY-203 como «source_missing» (acta de constitución, informe de avance, cronograma v2 y notas del 15-oct). Los archivos sí están en la carpeta del proyecto. Las rutas del bloque `pm_record` de la ficha van relativas a la carpeta del proyecto y no a la raíz de documentos. Parece un desajuste de rutas del índice y no documentos perdidos, pero no pude confirmarlo ni lo corregí.

**Confirmación:** es la primera y salió con cinco preguntas, todas sobre PRY-203, sin respuesta en esta corrida sin interfaz. Quedan registradas como «preguntadas el 2026-10-15, sin respuesta» y no se repiten:
1. La línea base v2 movió el fin de 2027-03-13 a 2027-07-06 (+115 días) y no consta el motivo.
2. El cambio CC-01 (+115 días y 230.000.000 COP) sigue pendiente, sin quién decide.
3. El hito «Ambiente de pruebas certificado» tenía fecha 2026-10-10 y sigue pendiente, sin evidencia.
4. El hallazgo de seguridad no tiene responsable ni fecha de origen.
5. El riesgo del proveedor del core no tiene responsable, y el riesgo de que no llegue con el equipo completo se dijo en la reunión y nadie lo registró.

**Registro:** quedó marcado el barrido y la confirmación, y la corrida (32 segundos, 13 proyectos) quedó guardada. El texto completo está en `estado/corridas/salida-portfolio-wake.md`. El conteo de documentos de la corrida quedó sin medir.

**Vuelvo el 2026-10-16.** El comité es el 22 de octubre y el informe toca el 20.
