# Corrida · 2026-10-15-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4300

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4300

**Inicio:** 2026-10-15T19:12:35 · **Fin:** 2026-10-15T19:13:27 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 18 | — | 36 | 42 | Borrador de acta para REQ-4300 sin firmar ni ficha. Vacíos: aceptación sin decisión escrita, criterio no verificable, demanda sin vínculo, sin patrocinador/autoridad/gerente/país; sin normas citadas. |

Por señal (`product-charter`): `evidence_stale` 17, `requirement_untraced` 12, `requirement_undecided` 6, `requirement_without_owner` 3, `requirement_without_acceptance` 2, `requirement_accepted_without_evidence` 1, `assumption_unverified` 1

## Lo que el agente mostró

Escribí el borrador del acta de REQ-4300 (Tarjeta débito, PRD-303), pero no está firmado y no creé la ficha del proyecto. La ficha se crea solo después de la firma.

Los términos ya estaban aceptados por José Francisco Ñáñez el 2026-10-15 y siguen vigentes (versión 0.3.10), así que no los registré de nuevo.

**Cómo salió la verificación previa.** Seguí adelante marcando los faltantes como vacíos del acta, sin rellenarlos. Esa fue mi respuesta por defecto a la oferta de seguir sin el dato, porque en esta prueba nadie contesta.
- **Aceptación:** el acta del comité lo lista como «aceptado», pero ninguna decisión escrita lo acepta y no consta quién decidió. La única decisión escrita es «Se mantiene el plan».
- **Criterio de aceptación:** «se verifica en producción» dice dónde mirar, no qué debe verse. No es verificable.
- **Demanda:** el acta dice «Cliente entrevistado», sin cita. La única entrevista (2025-09-19) no nombra este requerimiento, así que el vínculo no está confirmado.
- **Autoridad:** la definición no dice quién decide.

**Lo que no está dicho en ningún documento:** patrocinador, gerente del proyecto, autoridad del gerente, criterio de éxito, presupuesto, hitos y país. Natalia Ospina es gerente de producto, no de proyecto, y no la propuse para el cargo.

**Supuesto que pasa al proyecto como riesgo, sin doliente:** «El reglamento vigente lo permite». Lleva 43 días sin verificar, por encima del umbral de 30. Su fecha (2026-09-02) es posterior a la del documento que lo contiene (2025-12-27), y eso hay que aclararlo.

**Normas:** la tabla de restricciones normativas queda en «no tengo la norma a la vista» (cinco filas). No cité ninguna norma porque el país no está declarado.

**Lo que no entra:** los otros 18 requerimientos del acta del comité, cada uno con su razón: seis propuestos, no aceptados, y doce aceptados que esta acta no pidió.

**Qué sigue:** el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

La corrida quedó registrada como `2026-10-15-product-charter-1`, con la salida guardada en `estado-producto/PRD-303/corridas/salida-product-charter.md`. El registro marca 42 hallazgos del producto, casi todos de evidencia vencida y requerimientos sin proyecto.
