# Corrida · 2026-10-15-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T19:17:45 · **Fin:** 2026-10-15T19:18:41 · **Duración:** 57 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 37 | 10 | Reprogramados: María Restrepo (documento 1, 6 veces, vigente 2026-12-11) y Sandra Gil (prueba 2, 5 veces, vigente 2026-11-28); vencidos: Carlos Peña y Felipe Arango; 3 sin fecha (Mauricio Pérez, Óscar Ramírez, Laura Vélez) |

Por señal (`pm-commitments`): `commitment_undated` 3, `commitment_overdue` 2, `commitment_rescheduled` 2, `milestone_overdue` 1, `milestone_met_without_evidence` 1, `variance_cost` 1

## Lo que el agente mostró

## Compromisos — PRY-203 Aportes sociales en línea · al 2026-10-15

Hay 26 compromisos registrados: 20 abiertos y 6 cerrados con evidencia. De los abiertos, 2 están vencidos, 3 no tienen fecha y 2 se han reprogramado más de tres veces. Las cifras vienen del cálculo del script; no las conté yo.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no volví a registrarlos.

### Se viene reprogramando
- **María Restrepo, «Enviar el documento 1»:** se prometió para el 10-01 y se ha movido seis veces: 10-20, 10-28, 11-08, 11-20, 11-27 y ahora el **12-11**. Son unos 71 días de corrimiento. Las notas de hoy dicen «11/12/2026» y lo leí como día/mes/año. Si fuera 12 de noviembre, sería una fecha anterior a la de la semana pasada, así que conviene confirmarlo con ella.
- **Sandra Gil, «Cerrar la prueba 2»:** se prometió para el 09-18 y se ha movido cinco veces: 10-07, 10-14, 10-26, 11-07 y ahora el **11-28**. Coincide con el hito «Ambiente de pruebas certificado», vencido desde el 10-10, pero ningún documento conecta los dos.

Seis y cinco reprogramaciones no son un problema de seguimiento. Son bloqueos que nadie ha nombrado.

Elena Duarte, la patrocinadora, lleva dos reprogramaciones en «Entregar el punto 8» (09-28 → 10-14 → 11-03). Todavía no llega al umbral de tres.

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Felipe Arango | Validar el ambiente 20 | 10-05 | 10 días |
| Carlos Peña | Enviar el documento 9 | 10-09 | 6 días |

Ninguno de los dos tiene acta de recibo ni entregable en el expediente.

### Vencen en los próximos 7 días
Nada vence antes del domingo 18. Hasta el jueves 22:

| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Cerrar la prueba 18 | 10-19 |
| Liliana Torres | Revisar el anexo 11 | 10-21 |
| Andrés Lozano | Entregar el punto 16 | 10-21 |
| Mauricio Pérez | Confirmar la fecha 15 | 10-22 |

### Sin fecha (no pueden estar vencidos)
| Quién | Qué | Dicho el |
|---|---|---|
| Mauricio Pérez | Aprobar el diseño 5 | 09-10 |
| Óscar Ramírez | Entregar el punto 24 | 10-08 |
| Laura Vélez | Mandar el ajuste del presupuesto | 10-15 |

- **Mauricio Pérez:** dijo que ya entregó el diseño 5, pero no hay acta de recibo, así que sigue abierto.
- **Laura Vélez:** dijo «la otra semana», que no es una fecha, y no la calculé.

### Cerrados con documento
Estos son todos los cerrados, porque no había una revisión previa de este comando para comparar.

| Quién | Qué | Documento |
|---|---|---|
| Diana Molina | Anexo 3 | acta-recibo-3 |
| Andrés Lozano | Ambiente 4 | acta-recibo-4 |
| Javier Hoyos | Fecha 7 | acta-recibo-7 |
| Gustavo Neira | Prueba 10 | acta-recibo-10 |
| Felipe Arango | Ambiente 12 | acta-recibo-12 |
| María Restrepo | Matriz 14 | acta-recibo-14 |

La lista completa, con los otros 9 abiertos con fecha, está en el archivo de salida.

### Después
- Puedo formular los dos bloqueos, el de María Restrepo y el de Sandra Gil, como decisión para el comité del 2026-10-22. Excede la autoridad del gerente. La ficha no tiene `authority`, así que habría que confirmar quién decide.
- El informe de avance del 10-12 declara amarillo y no recoge los compromisos vencidos ni reprogramados. Si el estado cambia por esto, puedo preparar `/pm-publish`.

La corrida quedó registrada como `2026-10-15-pm-commitments-1`, con 10 hallazgos y 37 segundos. El texto completo está en `estado/PRY-203-aportes-sociales-en-línea/corridas/salida-pm-commitments.md`.
