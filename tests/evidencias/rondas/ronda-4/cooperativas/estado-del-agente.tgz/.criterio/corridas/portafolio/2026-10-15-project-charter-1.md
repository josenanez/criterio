# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-201 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-15T19:42:02 · **Fin:** 2026-10-15T19:42:48 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 31 | 64 | Revisión del acta de PRY-201 (2026-06-07): falta autoridad del gerente, objetivo medible, alcance y exclusiones con marcadores sin completar, supuestos, hitos y cadencia; contradicción entre 'Ninguna dependencia declarada' y el informe del 2026-10-12. No se pudo confirmar si el Comité de Educación es el comité correcto ni si hay definiciones fuera de los dos documentos leídos. |

Por señal (`project-charter`): `milestone_met_without_evidence` 21, `vendor_deliverable_late` 8, `progress_vs_plan` 7, `commitment_undated` 4, `declared_vs_evidence` 4, `vendor_accepted_without_evidence` 3, `commitment_overdue` 3, `milestone_overdue` 2, `variance_time` 2, `variance_cost` 2, `commitment_rescheduled` 2, `rebaseline_unauthorized` 2, `pm_vs_pmo` 1, `silent` 1, `vendor_invoiced_over_accepted` 1, `vendor_invoiced_without_delivery` 1

## Lo que el agente mostró

Revisé el acta de PRY-201 (Apertura de ahorro en línea), aprobada el 2026-06-07. Le faltan casi todos los campos de gobierno que se buscan.

Los términos ya estaban vigentes (versión 0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo. Solo leí dos documentos de PRY-201: el acta y el informe de avance del 2026-10-12.

**Qué falta y qué consecuencia tiene**
- **Autoridad del gerente:** no está declarada. Mauricio Pérez no tiene un monto ni un tipo de cambio que pueda decidir sin comité, así que cualquier desviación termina en el Comité de Educación. Hoy la proyección al cierre es 808.267.389 COP contra 800.000.000 aprobados (+1,03 %), y el acta no dice quién resuelve ese exceso.
- **Objetivo de negocio:** describe la solución ("Entregar apertura de ahorro en línea para Operaciones"), no un resultado medible.
- **Alcance y exclusiones:** son marcadores sin completar ("Componente 1, 2, 3" y "Lo que otro proyecto cubre"). Sin eso no hay referencia para decidir qué es un cambio de alcance.
- **Criterio de éxito:** dice "en producción y medido", sin qué se mide, con qué umbral ni quién lo mide.
- **Supuestos, restricciones, hitos y cadencia:** no existen. Solo hay fecha de inicio (2026-06-17) y de cierre (2027-05-03), así que el 31 % y el "verde" declarados no se pueden contrastar con un plan por hitos.
- **Dependencias:** el acta dice "Ninguna declarada", pero el informe del 2026-10-12 reporta la dependencia del proveedor del core cooperativo y que ese proveedor no ha confirmado la fecha de la última entrega.
- **Lo que sí está:** patrocinador (Jorge Medina), gerente (Mauricio Pérez), comité y presupuesto aprobado, con nombre y fuente.

**No pude confirmar:** si el Comité de Educación es el comité correcto para un proyecto de Operaciones, ni si algo de lo que falta está pactado fuera de esos dos documentos.

**Después:** dejé ofrecidas dos cosas, sin ejecutarlas. Una es llevar la definición de la autoridad del gerente al comité. La otra es pasar al registro de riesgos (`/raid-log`) la dependencia del proveedor del core y la fecha de entrega sin confirmar.

La corrida quedó registrada como `2026-10-15-project-charter-1`. La salida completa está en `estado/corridas/salida-project-charter.md`.

El registro de la corrida cuenta 64 hallazgos sobre 13 proyectos, pero eso es el estado de todo el portafolio. Para PRY-201 no hay ninguno.
