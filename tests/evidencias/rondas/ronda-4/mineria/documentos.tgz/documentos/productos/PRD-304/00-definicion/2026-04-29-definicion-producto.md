# Definición de producto · Trazabilidad

**Código:** PRD-304
**Gerente de producto:** Jorge Medina
**Segmento:** Operadores
**Fecha de la definición:** 2026-04-29

## El problema

El segmento Operadores no tiene trazabilidad.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-06-21 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
