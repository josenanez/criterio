# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Paula Céspedes
**Segmento:** Gerencia
**Fecha de la definición:** 2026-05-09

## El problema

El segmento Gerencia no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-08-27 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
