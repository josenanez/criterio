# Definición de producto · Reporte ambiental

**Código:** PRD-307
**Gerente de producto:** Elena Duarte
**Segmento:** Gerencia
**Fecha de la definición:** 2026-03-05

## El problema

El segmento Gerencia no tiene reporte ambiental.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-05-10 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
