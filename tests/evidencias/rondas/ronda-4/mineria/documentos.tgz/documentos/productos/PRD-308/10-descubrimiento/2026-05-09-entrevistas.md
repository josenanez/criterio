# Entrevistas · Permisos de trabajo digitales

**Ronda:** Ronda · 2026-05-09
**Realizadas por:** Elena Duarte

### Cliente entrevistado · 2026-05-09

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
