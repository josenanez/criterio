# Tablero de métricas · Inspección con drones

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-02

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 98.199 | 2026-10-02 |
