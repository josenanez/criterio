# Entrevistas · Despacho de flota

**Ronda:** Ronda · 2026-05-29
**Realizadas por:** Mauricio Pérez

### Cliente entrevistado · 2026-05-29

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
