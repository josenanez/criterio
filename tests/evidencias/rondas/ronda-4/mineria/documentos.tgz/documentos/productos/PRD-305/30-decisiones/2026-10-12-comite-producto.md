# Comité de producto · Alerta de fatiga

**Fecha:** 2026-10-12
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-21 | — |
| REQ-4501 | Requerimiento REQ-4501 | Liliana Torres | — | Cliente entrevistado | propuesto | 2026-08-11 | — |
| REQ-4502 | Requerimiento REQ-4502 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-26 | — |
| REQ-4503 | Requerimiento REQ-4503 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-30 | — |
| REQ-4504 | Requerimiento REQ-4504 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-09 | — |
| REQ-4505 | Requerimiento REQ-4505 | sin asignar | — | Cliente entrevistado | aceptado | 2026-07-12 | — |
| REQ-4506 | Requerimiento REQ-4506 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-20 | — |
| REQ-4507 | Requerimiento REQ-4507 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-25 | — |
| REQ-4508 | Requerimiento REQ-4508 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4509 | Requerimiento REQ-4509 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-22 | — |
| REQ-4510 | Requerimiento REQ-4510 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4511 | Requerimiento REQ-4511 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-16 | — |
| REQ-4512 | Requerimiento REQ-4512 | sin asignar | se verifica en producción | — | aceptado | 2026-05-19 | — |
| REQ-4513 | Requerimiento REQ-4513 | Liliana Torres | se verifica en producción | — | aceptado | 2026-04-16 | — |

## Decisiones

- Se mantiene el plan
