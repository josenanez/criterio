# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2025-12-10
**Preparado por:** Elena Duarte

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 150.232 | Caso de negocio, 2025-12-10 |

## Retorno esperado

Retorno esperado en 24 meses.
