# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2025-11-27
**Realizadas por:** Beatriz Cuéllar

### Cliente entrevistado · 2025-11-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
