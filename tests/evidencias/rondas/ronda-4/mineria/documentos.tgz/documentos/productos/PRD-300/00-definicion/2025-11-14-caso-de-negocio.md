# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2025-11-14
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 210.767 | Caso de negocio, 2025-11-14 |

## Retorno esperado

Retorno esperado en 24 meses.
