# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2026-07-01
**Preparado por:** Beatriz Cuéllar

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 98.347 | Caso de negocio, 2026-07-01 |

## Retorno esperado

Retorno esperado en 24 meses.
