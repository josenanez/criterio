# Definición de producto · Alerta de taludes

**Código:** PRD-301
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Gerencia
**Fecha de la definición:** 2025-12-23

## El problema

El segmento Gerencia no tiene alerta de taludes.

## La propuesta

- Propuesta principal

## Supuestos

- **Operaciones adopta la herramienta** · declarado el 2026-05-02 · verificado

## Proyectos que lo construyen

- Ninguno declarado
