# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2026-03-23
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 127.392 | Caso de negocio, 2026-03-23 |

## Retorno esperado

Retorno esperado en 24 meses.
