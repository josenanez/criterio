# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-10-12
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Elena Duarte | se verifica en producción | — | aceptado | 2026-06-26 | — |
| REQ-4801 | Requerimiento REQ-4801 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-08-21 | — |
| REQ-4802 | Requerimiento REQ-4802 | Gustavo Neira | — | — | aceptado | 2026-04-10 | — |
| REQ-4803 | Requerimiento REQ-4803 | Rubén Cárdenas | se verifica en producción | — | aceptado | 2026-06-02 | — |
| REQ-4804 | Requerimiento REQ-4804 | Diana Molina | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-14 | — |
| REQ-4805 | Requerimiento REQ-4805 | Liliana Torres | — | Cliente entrevistado | propuesto | 2026-03-30 | — |
| REQ-4806 | Requerimiento REQ-4806 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-23 | — |
| REQ-4807 | Requerimiento REQ-4807 | Diana Molina | — | Cliente entrevistado | aceptado | 2026-04-12 | — |
| REQ-4808 | Requerimiento REQ-4808 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-24 | — |
| REQ-4809 | Requerimiento REQ-4809 | Sandra Gil | — | Cliente entrevistado | aceptado | 2026-07-23 | — |
| REQ-4810 | Requerimiento REQ-4810 | Ricardo Salas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-07 | — |
| REQ-4811 | Requerimiento REQ-4811 | Natalia Ospina | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-31 | — |
| REQ-4812 | Requerimiento REQ-4812 | Elena Duarte | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-20 | — |
| REQ-4813 | Requerimiento REQ-4813 | Javier Hoyos | se verifica en producción | — | aceptado | 2026-07-13 | — |
| REQ-2028 | Requerimiento REQ-2028 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-22 | — |

## Decisiones

- Se mantiene el plan
