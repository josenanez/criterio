# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2025-12-23
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 266.498 | Caso de negocio, 2025-12-23 |

## Retorno esperado

Retorno esperado en 24 meses.
