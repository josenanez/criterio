# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Mauricio Pérez
**Segmento:** Comunidad
**Fecha de la definición:** 2026-06-16

## El problema

El segmento Comunidad no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-08-07 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
