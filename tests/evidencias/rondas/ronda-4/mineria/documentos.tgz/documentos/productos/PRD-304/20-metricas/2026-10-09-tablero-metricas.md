# Tablero de métricas · Trazabilidad

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-09

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 211.981 | 2026-10-09 |
