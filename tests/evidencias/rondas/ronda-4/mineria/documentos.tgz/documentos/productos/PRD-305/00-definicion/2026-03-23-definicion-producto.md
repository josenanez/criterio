# Definición de producto · Alerta de fatiga

**Código:** PRD-305
**Gerente de producto:** Felipe Arango
**Segmento:** Comunidad
**Fecha de la definición:** 2026-03-23

## El problema

El segmento Comunidad no tiene alerta de fatiga.

## La propuesta

- Propuesta principal

## Supuestos

- **La licencia ambiental lo permite** · declarado el 2026-05-04 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
