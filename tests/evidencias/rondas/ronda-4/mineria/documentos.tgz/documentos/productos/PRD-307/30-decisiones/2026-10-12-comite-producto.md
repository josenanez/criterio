# Comité de producto · Reporte ambiental

**Fecha:** 2026-10-12
**Asistentes:** Elena Duarte

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | Sandra Gil | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-28 | — |
| REQ-4701 | Requerimiento REQ-4701 | Sandra Gil | se verifica en producción | — | aceptado | 2026-06-21 | — |
| REQ-4702 | Requerimiento REQ-4702 | Gustavo Neira | — | — | aceptado | 2026-04-16 | — |
| REQ-4703 | Requerimiento REQ-4703 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-27 | — |
| REQ-4704 | Requerimiento REQ-4704 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-08 | — |
| REQ-4705 | Requerimiento REQ-4705 | Paula Céspedes | — | Cliente entrevistado | aceptado | 2026-08-04 | — |
| REQ-4706 | Requerimiento REQ-4706 | Jorge Medina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-15 | — |
| REQ-4707 | Requerimiento REQ-4707 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-05-06 | — |
| REQ-4708 | Requerimiento REQ-4708 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4709 | Requerimiento REQ-4709 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-02 | — |
| REQ-4710 | Requerimiento REQ-4710 | Jorge Medina | se verifica en producción | — | propuesto | 2026-07-12 | — |
| REQ-4711 | Requerimiento REQ-4711 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-30 | — |
| REQ-4712 | Requerimiento REQ-4712 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-22 | — |
| REQ-4713 | Requerimiento REQ-4713 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-02 | — |

## Decisiones

- Se mantiene el plan
