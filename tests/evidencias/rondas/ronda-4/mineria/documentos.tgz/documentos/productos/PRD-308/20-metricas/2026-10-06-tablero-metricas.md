# Tablero de métricas · Permisos de trabajo digitales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-06

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 137.557 | 2026-10-06 |
