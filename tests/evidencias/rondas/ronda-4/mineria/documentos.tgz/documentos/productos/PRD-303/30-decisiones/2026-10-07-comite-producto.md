# Comité de producto · Gemelo digital

**Fecha:** 2026-10-07
**Asistentes:** Paula Céspedes

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4300 | Requerimiento REQ-4300 | Andrés Lozano | se verifica en producción | — | propuesto | 2026-06-06 | — |
| REQ-4301 | Requerimiento REQ-4301 | Liliana Torres | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4302 | Requerimiento REQ-4302 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |
| REQ-4303 | Requerimiento REQ-4303 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-03-15 | — |
| REQ-4304 | Requerimiento REQ-4304 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-20 | — |
| REQ-4305 | Requerimiento REQ-4305 | Laura Vélez | — | — | propuesto | 2026-03-27 | — |
| REQ-4306 | Requerimiento REQ-4306 | Felipe Arango | — | — | propuesto | 2026-05-12 | — |
| REQ-4307 | Requerimiento REQ-4307 | Liliana Torres | se verifica en producción | — | aceptado | 2026-05-22 | — |
| REQ-4308 | Requerimiento REQ-4308 | sin asignar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-10 | — |
| REQ-4309 | Requerimiento REQ-4309 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-25 | — |
| REQ-4310 | Requerimiento REQ-4310 | Diana Molina | — | — | aceptado | 2026-05-03 | — |
| REQ-4311 | Requerimiento REQ-4311 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-06 | — |
| REQ-4312 | Requerimiento REQ-4312 | Beatriz Cuéllar | — | Cliente entrevistado | propuesto | 2026-08-21 | — |
| REQ-4313 | Requerimiento REQ-4313 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-14 | — |
| REQ-2028 | Requerimiento REQ-2028 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-29 | — |

## Decisiones

- Se mantiene el plan
