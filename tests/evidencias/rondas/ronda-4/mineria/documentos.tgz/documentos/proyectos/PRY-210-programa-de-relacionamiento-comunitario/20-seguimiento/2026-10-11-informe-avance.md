# Informe de avance · Programa de relacionamiento comunitario

**Código:** PRY-210
**Fecha de corte:** 2026-10-11
**Gerente:** Camilo Beltrán

## Estado declarado

**Verde**

Avance reportado: **69%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.463.214.708 |
| Ejecutado | 1.868.733.943 |
| Proyección al cierre | 7.049.863.850 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
- Ventana de parada de planta definida por operaciones
