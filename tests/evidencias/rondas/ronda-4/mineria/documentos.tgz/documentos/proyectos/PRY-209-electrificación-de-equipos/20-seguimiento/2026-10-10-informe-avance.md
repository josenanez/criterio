# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-10
**Gerente:** Carlos Peña

## Estado declarado

**Amarillo**

Avance reportado: **28%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 11.642.655.377 |
| Ejecutado | 5.574.302.085 |
| Proyección al cierre | 18.320.495.221 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- Bloqueo de la vía de acceso a la mina
