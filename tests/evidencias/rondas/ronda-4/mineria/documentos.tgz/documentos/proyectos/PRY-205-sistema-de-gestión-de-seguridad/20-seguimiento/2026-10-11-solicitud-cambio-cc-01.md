# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-11
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +112 días sobre la línea base vigente |
| Costo | 224.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
