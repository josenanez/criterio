# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-03
**Asistentes:** Andrés Lozano, Camilo Beltrán, Mauricio Pérez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-25 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-22 |
| Mauricio Pérez | Revisar el anexo 3 | 2026-09-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-13 |
