# Acta de constitución · Ampliación de la relavera

**Código:** PRY-201
**Área dueña:** Mina
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Sandra Gil
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-12

## Objetivo del negocio

Entregar ampliación de la relavera para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Inversiones el 2026-05-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-05-22 |
| Cierre | 2026-12-21 |

## Criterio de éxito

Ampliación de la relavera en producción y medido.

## Dependencias declaradas

- Ninguna declarada
