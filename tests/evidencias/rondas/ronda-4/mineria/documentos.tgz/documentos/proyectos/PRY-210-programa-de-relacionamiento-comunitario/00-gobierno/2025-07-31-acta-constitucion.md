# Acta de constitución · Programa de relacionamiento comunitario

**Código:** PRY-210
**Área dueña:** Tecnología
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-31

## Objetivo del negocio

Entregar programa de relacionamiento comunitario para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Tecnología el 2025-07-31.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-08-10 |
| Cierre | 2026-10-31 |

## Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

## Dependencias declaradas

- Ninguna declarada
