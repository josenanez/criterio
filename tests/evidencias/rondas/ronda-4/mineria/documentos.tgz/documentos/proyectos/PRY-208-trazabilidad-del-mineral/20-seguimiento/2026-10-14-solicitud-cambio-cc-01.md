# Solicitud de cambio CC-01

**Proyecto:** PRY-208 · Trazabilidad del mineral
**Fecha:** 2026-10-14
**Solicitante:** Andrés Lozano

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +54 días sobre la línea base vigente |
| Costo | 108.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
