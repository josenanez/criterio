# Informe de avance · Gemelo digital de la planta

**Código:** PRY-207
**Fecha de corte:** 2026-10-14
**Gerente:** Elena Duarte

## Estado declarado

**Rojo**

Avance reportado: **75%**

## Lo que pasó en el periodo

- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Las lluvias detuvieron el montaje durante diez días
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 755.551.273 |
| Ejecutado | 424.090.796 |
| Proyección al cierre | 2.373.957.787 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
