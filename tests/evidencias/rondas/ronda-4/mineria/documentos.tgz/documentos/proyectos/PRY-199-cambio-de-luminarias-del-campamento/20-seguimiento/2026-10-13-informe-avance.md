# Informe de avance · Cambio de luminarias del campamento

**Código:** PRY-199
**Fecha de corte:** 2026-10-13
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **20%**

## Lo que pasó en el periodo

- Se reprogramó la parada de planta por la ventana de mantenimiento
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se levantó un hallazgo en la auditoría de seguridad

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.080.000.000 |
| Ejecutado | 720.000.000 |
| Proyección al cierre | 2.400.000.000 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
