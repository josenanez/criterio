# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-200 · Mantenimiento predictivo de camiones
**Fecha de recibo:** 2026-02-15
**Recibido por:** Camilo Beltrán

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-235 · Servicios Ambientales del Norte.
