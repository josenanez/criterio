# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-10-15
**Asistentes:** Gustavo Neira, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 34 | por definir |
