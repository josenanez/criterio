# Comité de Inversiones · Electrificación de equipos

**Fecha:** 2026-10-15
**Asistentes:** Carlos Peña, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 20 | 2026-10-26 |
