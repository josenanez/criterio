# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-10
**Gerente:** Gustavo Neira

## Estado declarado

**Verde**

Avance reportado: **41%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 731.337.940 |
| Ejecutado | 468.897.081 |
| Proyección al cierre | 1.166.182.042 |

## Riesgos abiertos

- Ventana de parada de planta definida por operaciones
- Cambio en la licencia ambiental que puede mover el alcance
