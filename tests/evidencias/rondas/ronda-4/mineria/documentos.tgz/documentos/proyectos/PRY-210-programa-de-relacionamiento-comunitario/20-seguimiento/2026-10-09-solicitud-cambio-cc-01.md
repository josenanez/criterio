# Solicitud de cambio CC-01

**Proyecto:** PRY-210 · Programa de relacionamiento comunitario
**Fecha:** 2026-10-09
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +31 días sobre la línea base vigente |
| Costo | 62.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
