# Acta de constitución · Red privada LTE en mina

**Código:** PRY-206
**Área dueña:** Logística
**Patrocinador:** Elena Duarte
**Gerente de proyecto:** Óscar Ramírez
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-10-12

## Objetivo del negocio

Entregar red privada lte en mina para Logística.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Inversiones el 2025-10-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-22 |
| Cierre | 2026-06-22 |

## Criterio de éxito

Red privada LTE en mina en producción y medido.

## Dependencias declaradas

- Ninguna declarada
