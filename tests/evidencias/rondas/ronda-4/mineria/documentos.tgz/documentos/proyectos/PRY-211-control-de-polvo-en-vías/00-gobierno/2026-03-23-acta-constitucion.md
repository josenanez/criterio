# Acta de constitución · Control de polvo en vías

**Código:** PRY-211
**Área dueña:** Geología
**Patrocinador:** Rubén Cárdenas
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-03-23

## Objetivo del negocio

Entregar control de polvo en vías para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Inversiones el 2026-03-23.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-02 |
| Cierre | 2027-09-03 |

## Criterio de éxito

Control de polvo en vías en producción y medido.

## Dependencias declaradas

- Ninguna declarada
