# Informe de avance · Mantenimiento predictivo de camiones

**Código:** PRY-200
**Fecha de corte:** 2026-10-13
**Gerente:** Camilo Beltrán

## Estado declarado

**Amarillo**

Avance reportado: **61%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- El equipo perdió dos semanas por rotación de un ingeniero clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.481.500.375 |
| Ejecutado | 993.723.690 |
| Proyección al cierre | 2.474.762.505 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
