# Comité de Inversiones · Ampliación de la relavera

**Fecha:** 2026-10-09
**Asistentes:** Sandra Gil, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 6 | 2026-10-18 |
