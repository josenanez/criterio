**Sale de:** contrato CT-235 (`00-gobierno/2025-10-01-contrato-ct-235.md`), ficha PM (`00-gobierno/ficha-pm.json`), factura FV-1235 (`20-seguimiento/2026-09-27-factura-ct-235.md`), acta de recibo de la bolsa de horas (`20-seguimiento/2026-02-15-acta-recibo-ct-235-bolsa-de-horas-de-ingeniería.md`), informe de avance del 2026-10-13, las seis minutas de comité (2026-09-03 a 2026-10-08) y las notas del 2026-10-15. Cifras derivadas: salida de `portafolio.py compute`. Términos vigentes (0.3.10), aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo.

## Proveedores — PRY-200 Mantenimiento predictivo de camiones al 2026-10-15

### Servicios Ambientales del Norte — contrato CT-235
**Vigencia:** sin dato · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato. El contrato solo trae fecha de firma (2025-10-01), tres entregables y la condición de pago; no dice vigencia, renovación automática ni preaviso.

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (204.854.837 COP) | 2025-12-08 | `pending`; 311 días de retraso | Ninguna | No identificable (ver abajo) |
| Bolsa de horas de ingeniería (204.854.837 COP) | 2026-01-29 | `accepted` | Acta de recibo del 2026-02-15, firmada por Camilo Beltrán | No identificable (ver abajo) |
| Calibración de sensores (204.854.837 COP) | 2026-03-22 | Declarado `accepted`; **sin evidencia** | Ninguna: no hay acta, correo ni minuta | No identificable (ver abajo) |

La factura FV-1235 (2026-09-27) suma **409.709.674 COP** y dice solo «Entregables del contrato CT-235». No nombra cuáles. Ese valor es igual al de los dos entregables declarados aceptados (`amount_accepted` = 409.709.674). Que cubra la bolsa de horas y la calibración es una **inferencia por monto**, no un dato de la factura.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Calibración de sensores facturada sin acta | La columna «Estado» marca «recibido», pero la condición de pago exige acta de recibo firmada por el gerente del proyecto | No existe acta de esa calibración en la carpeta. La columna «Estado» del contrato es una declaración, no una prueba. | Contrato CT-235; factura FV-1235; ficha PM |
| Factura sin detalle | Cada entregable se factura contra su acta | FV-1235 junta dos montos y no cita ningún acta | Contrato CT-235; FV-1235 |
| Licenciamiento sin recibir y sin explicación | Comprometido para 2025-12-08 | Sigue `pending`; ningún comité lo menciona ni hay solicitud de cambio que mueva la fecha | Contrato CT-235; las seis minutas |

Una cosa que no hay que confundir: el PDF `2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf` recibe el hito del cronograma «Licencia y permisos obtenidos», no el entregable «Licenciamiento del software». No menciona CT-235 ni al proveedor, así que **no cuenta como evidencia** del licenciamiento.

El script no levanta `vendor_invoiced_without_delivery`, porque hay dos entregables declarados aceptados. Pero uno de esos dos no tiene acta (siguiente sección), así que el monto sustentado con acta es el de la bolsa de horas: 204.854.837 COP, y no los 409.709.674 COP facturados. El otro entregable facturado, la calibración, no tiene documento que lo pruebe.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Calibración de sensores | `accepted` (columna «Estado» del contrato) | Sin fecha de aceptación; la entrega estaba comprometida para 2026-03-22 |

### Entregables vencidos sin entrega
| Entregable | Comprometido | Días | Estado |
|---|---|---|---|
| Licenciamiento del software | 2025-12-08 | 311 | `pending`, sin evidencia |

### Compromisos del proveedor vencidos
Ninguno atribuible al proveedor. Ningún documento asigna un compromiso al proveedor; los 7 compromisos vencidos del proyecto son de personas del equipo, y no consta a qué organización pertenece cada una. Solo hay uno que lo toca: «revisión con el proveedor», a cargo de Óscar Ramírez, para el 2026-10-25 (notas del 2026-10-15). No está vencido.

En esas mismas notas se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y **nadie lo anotó como riesgo**. El informe de avance del 2026-10-13 tampoco lo trae entre los riesgos abiertos. Además, ese informe dice que «el proveedor entregó los equipos en el campamento, pendientes de aceptación», pero ningún entregable de CT-235 es «equipos»: no se puede decir a qué contrato ni a qué proveedor se refiere.

### Sin dato
- Vigencia, fecha de terminación, renovación automática y preaviso de CT-235. **No se puede evaluar si algún preaviso vence antes del cierre del proyecto.**
- Qué entregables cubre FV-1235 y si ya se pagó. La factura dice «Radicada en cuentas por pagar», sin fecha de pago.
- Quién firma por el proveedor, y si «equipos entregados» es parte de CT-235 o de otro contrato que no está en la carpeta.
- Contrato, entregables y facturas de cualquier otro proveedor: la ficha solo registra uno.

### Qué sigue
- Hay un entregable facturado sin acta (calibración de sensores). Conviene llevarlo a comité antes de que la factura se pague, o pedir el acta o un correo de aceptación al gerente (Camilo Beltrán). Si lo quieres, preparo ese punto para comité.
- Pedir el contrato completo con vigencia y preaviso, o confirmar que no los tiene.
- Registrar como riesgo el comentario del 2026-10-15 sobre el equipo incompleto del proveedor.

*Pie de rigor: todas las fechas, montos y conteos salen de los documentos citados o de `portafolio.py compute`. Las inferencias van marcadas. No se verificó nada fuera de la carpeta, y no sé lo que se habló fuera de los documentos.*
