**Fuente:** fichas de `estado/records` (13 proyectos), cálculo de `portafolio.py compute` con corte al 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## Productos al 2026-10-15 — consulta: despacho de flota

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| despacho de flota | 1 (PRY-203) | 3 señales | 2027-03-20 (PRY-203) | COP 1.200.000.000 | COP 731.337.940 (60,9 %) |

**Despacho de flota tiene un solo proyecto (PRY-203, Despacho automático de flota).** La vista por producto no aporta nada distinto de la vista del proyecto, así que no armo sección por producto. Dejo lo que el cálculo da para PRY-203:

- **Señales abiertas (3):**
  1. Hito «Ingeniería básica aprobada» declarado cumplido (vencía 2026-03-13, hace 216 días) sin evidencia de cumplimiento.
  2. Compromiso sin fecha: Óscar Ramírez, «Entregar el punto 34» (`PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-15-comite-semanal.md`).
  3. El gerente declara **verde** (informe del 2026-10-10, `20-seguimiento/2026-10-10-informe-avance.md`) y la señal 1 no está reconocida en esa declaración.
- **Avance:** declarado 41 %; el plan sustenta entre 50 % y 75 % (2 de 4 hitos cumplidos). Brecha de 9,0 puntos, por debajo del umbral de 10: no es alerta.
- **Dinero (COP):** aprobado 1.200.000.000; comprometido 731.337.940; ejecutado 468.897.081 (39,1 %); proyección 1.166.182.042 (−2,8 % frente a lo aprobado); disponible real 468.662.060. Es un solo proyecto, así que la suma es completa por construcción.
- **Fecha comprometida del producto:** 2027-03-20, sale de PRY-203. Sin atraso frente a la línea base original ni a la vigente (0 días), sin replanificaciones.
- **Dependencias internas:** ninguna, solo hay un proyecto. Dependencias declaradas por PRY-203: ninguna registrada.
- **Evidencia:** 0 fuentes marcadas como evidencia, 2 como declaración, 17 sin marcar. «Sin evidencia» aquí quiere decir que la ficha no trae evidencia marcada, no que no exista fuera de los documentos leídos.
- **Datos que faltan:** autoridad y fase del proyecto. Diez campos de identidad y plan (incluido `money.approved`) se apoyan en un documento del 2025-10-30, con 12 meses de antigüedad en el umbral de caducidad; conviene confirmarlos.

## Proyectos sin producto declarado

Siete proyectos no declaran producto. Nadie puede responder por el conjunto al que sirven; es un hallazgo de gobierno.

| Proyecto | Área dueña (según ficha) |
|---|---|
| PRY-201 Ampliación de la relavera | Mina |
| PRY-202 Planta de tratamiento de agua | Mina |
| PRY-205 Sistema de gestión de seguridad | no declarada en la ficha |
| PRY-206 Red privada LTE en mina | Logística |
| PRY-209 Electrificación de equipos | Seguridad y Salud |
| PRY-210 Programa de relacionamiento comunitario | Tecnología |
| PRY-211 Control de polvo en vías | Geología |

**Otras lecturas que conviene tener a la vista (no son parte del producto consultado):** «monitoreo de flota» (PRY-200) y «despacho de flota» (PRY-203) son productos distintos en la ficha; por nombre podrían solaparse, pero ninguna ficha declara dependencia entre ellos y no lo afirmo.

**Pie de rigor:** cifras copiadas de la salida de `compute`; nada promediado. No leí documentos fuera de las fichas. Lo que se habló fuera de los documentos no lo sé.
