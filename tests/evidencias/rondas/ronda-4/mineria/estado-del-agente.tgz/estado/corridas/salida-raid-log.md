Sale de: las 13 fichas de `estado/records/` (PRY-199 a PRY-211) y del texto de los documentos en `estado/cache/texto/` (informes de avance, minutas de comité y las notas de reunión de PRY-200 del 2026-10-15). No releí los originales; leí el caché. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).

## RAID — portafolio (13 proyectos) al 2026-10-15

Como está registrado: 20 riesgos · 0 supuestos · 24 incidencias · 0 dependencias
44 de 44 ítems sin doliente · 20 de 20 riesgos sin fecha · 1 no registrado formalmente · "sin movimiento": no se puede medir (ver abajo)

Con la clasificación que propongo: 13 riesgos · 0 supuestos · 24 incidencias (6 dudosas) · 7 dependencias.

Tres límites de este registro:
- **Sin escala propia**, uso alta/media/baja. Ningún riesgo trae probabilidad ni impacto en los documentos; no los relleno.
- **Sin movimiento no es evaluable.** Cada proyecto tiene un solo informe de avance en la carpeta y `last_moved` está vacío en todos los riesgos. El "Desde" de las incidencias es la fecha del informe, no la fecha en que ocurrieron.
- **Los ítems no traen Id en los documentos.** Las etiquetas (R-199-1…) son de esta corrida, solo para citarlos.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| R-200-2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | sin doliente | 2026-10-15 (dicho en reunión) | Nadie lo anotó; el mismo día se acordó "revisión con el proveedor" el 2026-10-25 (Óscar Ramírez). Falta decidir si se formaliza y quién lo lleva. |
| D-OPS | Dependencia (propuesta) | Ventana de parada de planta definida por Operaciones. Aparece como riesgo en PRY-201, 202, 203, 205 y 210; y en PRY-199 y PRY-207 el informe dice que "se reprogramó la parada de planta por la ventana de mantenimiento" | sin doliente (ni de Operaciones ni del proyecto) | informes 2026-10-06 a 2026-10-15 | Afecta a 7 proyectos a la vez y el doliente está fuera de los proyectos. Un solo interlocutor con Operaciones, no siete registros separados. |
| R-200-1 / R-205-2 | Riesgo ya materializado | "Concentración del conocimiento en una sola persona" sigue como riesgo abierto, y el mismo informe cuenta que el equipo perdió dos semanas por la rotación de un ingeniero clave | sin doliente | 2026-10-13 (PRY-200), 2026-10-12 (PRY-205) | Lo que era riesgo ya produjo una incidencia. Hay que decidir qué se hace con la persona clave que queda, no seguir "mitigando". |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Riesgo | PRY-200, `2026-10-15-notas-reunion.txt` | 2026-10-15 |

Es el único. Barrí con palabras clave las minutas de comité de los 13 proyectos (si, falta, atraso, bloqueo, aprobación, proveedor, presupuesto) y no encontré otro. No leí cada minuta de PRY-200 línea a línea, solo las notas del 10-15; el barrido por palabras puede dejar pasar algo dicho con otras palabras.

Aparte, en esas mismas notas: Laura Vélez quedó de mandar "el ajuste del presupuesto la otra semana" sin fecha. No es un riesgo, es un compromiso; no lo registro aquí.

### Sin doliente o sin fecha
Todos. Ninguno de los 44 ítems tiene doliente y ninguno de los 20 riesgos tiene fecha. No los relleno. Lo que falta:
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| R-199-1 a R-211-1 (20) | Riesgo | todos los de la tabla de abajo | doliente, fecha, probabilidad, impacto |
| I-199-1 a I-211-2 (24) | Incidencia | todas las de la tabla de abajo | doliente, fecha objetivo de resolución |

### Reclasificaciones que propongo (no toqué las fichas)
| Ítem | Hoy | Propuesta | Por qué |
|---|---|---|---|
| Ventana de parada de planta definida por operaciones (PRY-201, 202, 203, 205, 210) | Riesgo | Dependencia | La define alguien fuera del proyecto. No hay código de proyecto: es Operaciones, no otro proyecto. |
| El proveedor no ha confirmado la fecha de la última entrega (PRY-204, 206) | Riesgo | Dependencia | Depende de un tercero y no está confirmada: es declarada, no acordada. |
| Rotación de ingeniero clave (PRY-202, 205, 200) | Incidencia | Se queda | Ya ocurrió. En PRY-202 no hay riesgo asociado abierto; en PRY-200 y PRY-205 sí (ver arriba). |
| Ítems que "ya pasaron" pero el informe no dice qué daño causan: equipos entregados pendientes de aceptación (PRY-200, 201, 204, 209), presupuesto actualizado con compras (PRY-211), parada de planta reprogramada (PRY-199, 207) | Incidencia | Dudosos | Son hechos del periodo, no problemas declarados. Los dejo como están y se lo pregunto a cada gerente. |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna con código de proyecto) | — | — | Ningún documento declara una dependencia de otro PRY: busqué códigos PRY-2xx ajenos en todo el caché y no hay ninguno. El cruce de portafolio no tiene qué cruzar; eso no prueba que no existan, solo que nadie las escribió. |
| D-OPS (propuesta) | Operaciones (externo) | No | Ventana de parada movida según PRY-199 y PRY-207; sin confirmación de Operaciones en ningún documento. |
| PRY-204, PRY-206 (propuesta) | Proveedor (fecha de última entrega) | No | "No ha confirmado" en ambos informes; sin respuesta del proveedor en los documentos. |

### Registro completo
Prob./Impacto: sin dato en los 20 riesgos. Doliente: sin dato en los 44. Fecha: sin dato en los 20 riesgos. Último movimiento: sin dato; entre paréntesis, la fecha del informe donde aparece.

| Id | Tipo | Qué | Informe |
|---|---|---|---|
| R-199-1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-13 |
| I-199-1 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento (dudosa) | 2026-10-13 |
| I-199-2 | Incidencia | El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite | 2026-10-13 |
| I-199-3 | Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-13 |
| R-200-1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-13 |
| R-200-2 | Riesgo (no registrado) | El proveedor podría no llegar con el equipo completo para la siguiente fase | notas 2026-10-15 |
| I-200-1 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación (dudosa) | 2026-10-13 |
| I-200-2 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-10-13 |
| R-201-1 | Riesgo → Dependencia | Ventana de parada de planta definida por operaciones | 2026-10-15 |
| I-201-1 | Incidencia | Equipos entregados por el proveedor en el campamento, pendientes de aceptación (dudosa) | 2026-10-15 |
| R-202-1 | Riesgo → Dependencia | Ventana de parada de planta definida por operaciones | 2026-10-06 |
| I-202-1 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-10-06 |
| R-203-1 | Riesgo → Dependencia | Ventana de parada de planta definida por operaciones | 2026-10-10 |
| R-203-2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-10 |
| I-203-1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-10 |
| I-203-2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-10 |
| R-204-1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-15 |
| R-204-2 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-15 |
| I-204-1 | Incidencia | Equipos entregados por el proveedor en el campamento, pendientes de aceptación (dudosa) | 2026-10-15 |
| R-205-1 | Riesgo → Dependencia | Ventana de parada de planta definida por operaciones | 2026-10-12 |
| R-205-2 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-12 |
| I-205-1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-12 |
| I-205-2 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-12 |
| I-205-3 | Incidencia | El equipo perdió dos semanas por rotación de un ingeniero clave | 2026-10-12 |
| R-206-1 | Riesgo → Dependencia | El proveedor no ha confirmado la fecha de la última entrega | 2026-10-11 |
| R-206-2 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-11 |
| I-206-1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-11 |
| I-206-2 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-11 |
| R-207-1 | Riesgo | Bloqueo de la vía de acceso a la mina | 2026-10-14 |
| I-207-1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-14 |
| I-207-2 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-14 |
| I-207-3 | Incidencia | Se reprogramó la parada de planta por la ventana de mantenimiento (dudosa) | 2026-10-14 |
| R-208-1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-12 |
| R-209-1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-10 |
| R-209-2 | Riesgo | Bloqueo de la vía de acceso a la mina | 2026-10-10 |
| I-209-1 | Incidencia | Las lluvias detuvieron el montaje durante diez días | 2026-10-10 |
| I-209-2 | Incidencia | El proveedor entregó los equipos en el campamento, pendientes de aceptación (dudosa) | 2026-10-10 |
| I-209-3 | Incidencia | Hallazgo levantado en la auditoría de seguridad | 2026-10-10 |
| R-210-1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | 2026-10-11 |
| R-210-2 | Riesgo → Dependencia | Ventana de parada de planta definida por operaciones | 2026-10-11 |
| I-210-1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-11 |
| R-211-1 | Riesgo | Concentración del conocimiento en una sola persona | 2026-10-03 |
| I-211-1 | Incidencia | Se actualizó el presupuesto de la obra con el área de compras (dudosa) | 2026-10-03 |
| I-211-2 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | 2026-10-03 |

Dos observaciones sobre el conjunto, sin conclusión de mi parte:
- La misma frase aparece en varios informes: "El primer ensayo de disponibilidad…" en 7 (PRY-199, 203, 205, 206, 207, 210, 211), "Las lluvias detuvieron el montaje durante diez días" en 5 (PRY-203, 205, 206, 207, 209), "Cambio en la licencia ambiental…" en 5 (PRY-199, 203, 204, 208, 210). No sé si es un mismo hecho que toca a varios proyectos o texto repetido de plantilla. Eso lo confirma cada gerente.
- Solicitudes de cambio abiertas que hoy no están en el RAID como incidencia: PRY-200 (CC-01, +49 días) ya tiene el cronograma v2 con la fecha movida sin acta de aprobación según su ficha. Es tema de control de cambios; lo menciono porque mueve la fecha base de varios ítems de arriba.

## Después
Puedo subir a comité tres cosas: la dependencia compartida con Operaciones (7 proyectos), el riesgo de concentración ya materializado en PRY-200 y PRY-205, y el riesgo de proveedor no registrado de PRY-200. Si quiere, redacto para cada una la decisión formulada (pregunta cerrada, opciones y qué pasa si nadie decide).

Doliente: propongo, no asigno. Para R-200-2 hay un candidato razonable, Óscar Ramírez (quedó con la revisión del proveedor el 2026-10-25), pero ninguna acta lo dice como responsable del riesgo. Para el resto no hay en los documentos a quién proponer con sustento; los gerentes de cada proyecto figuran en las actas de constitución, pero ser gerente no equivale a ser doliente de un riesgo.

## Pie de rigor
Sale de las fichas y del caché de texto al 2026-10-15; el caché no sustituye a los originales (los PDF de PRY-202, 204, 208 vienen sin hash de texto). No sé qué se habló fuera de los documentos. No medí movimiento ni envejecimiento de ítems por falta de histórico. Verifique cada cita contra el documento original antes de llevarlo a comité.
