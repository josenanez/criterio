# Corrida del 2026-10-15 · status-report

13 proyectos · 26 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Estado PRY-206: verde declarado (33%) contradicho; hitos cerrados sin evidencia salvo licencia (PDF sin texto legible); cierre vencido hace 142 días sin replanificar. Sin dato: producto, autoridad, fase.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Informe de la ficha PRY-206, actualizada el 2026-10-15 (cálculos de `portafolio.py compute`, corte 2026-10-15).

## PRY-206 · Red privada LTE en mina — estado al 2026-10-15

**Declara el gerente (Óscar Ramírez):** verde · 33% · al 2026-10-11 (4 días; vigente)
**Sustento documental:** contradicho (alerta `declared_vs_evidence`)
**Lo que el semáforo no explica:** `milestone_met_without_evidence` y `progress_vs_plan`
**Último documento:** 2026-10-14 (1 día de silencio) · **Última reunión:** 2026-10-14 (comité semanal)

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-05-26 | 2026-05-26 | 0 días (sin replanificación); la fecha pasó hace 142 días y el proyecto sigue en ejecución |
| Presupuesto (COP) | 2.400.000.000 aprobado | proyección 2.430.168.207 | +1,3% (umbral 10%) |

Ejecutado 873.934.388 (36,4%) · Comprometido 1.212.307.205 (50,5%) · Disponible real 1.187.692.795.
Replanificaciones: 0. Solicitudes de cambio: 0.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2025-12-15 | 2025-12-15 | cerrado (según cronograma) | ninguna (304 días) |
| Ingeniería de detalle aprobada | 2026-02-07 | 2026-02-07 | cerrado (según cronograma) | ninguna (250 días) |
| Licencia y permisos obtenidos | 2026-04-02 | 2026-04-02 | cerrado | acta de recibo, PDF, 2026-10-04 (sin texto extraíble: no pude leerla, solo consta que existe) |
| Montaje e instalación | 2026-05-26 | 2026-05-26 | cerrado (según cronograma) | ninguna (142 días) |

### Dónde no coincide
- **Avance:** el gerente declara 33% (informe 2026-10-11). El cronograma v1 (2025-10-12) marca los 4 hitos como cerrados, lo que sustenta 100%: brecha de 67 puntos. Ninguna de las dos cifras está respaldada por evidencia de recibo, salvo la licencia.
- **Montaje:** el cronograma lo da por cerrado desde 2026-05-26, pero el informe del 2026-10-11 dice que «las lluvias detuvieron el montaje durante diez días» y que el primer ensayo de disponibilidad no alcanzó lo pactado y se repite. Un montaje en curso en octubre no es un hito cerrado en mayo.
- **Verde:** con un ensayo fallido, una incidencia de montaje y la fecha de cierre vencida hace 142 días sin replanificar, el verde no queda explicado por los documentos.
- El cronograma no se ha actualizado desde 2025-10-12 (v1 única); sospecho que el estado «cerrado» es de plan y no de ejecución, pero los documentos no lo dicen.

### Abierto
**Riesgos e incidencias sin movimiento:** sin fecha de último movimiento ni dueño en ninguno.
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (sin dueño, sin probabilidad ni impacto).
- Riesgo: concentración del conocimiento en una sola persona (sin dueño).
- Incidencia: lluvias detuvieron el montaje diez días (desde 2026-10-11, sin dueño).
- Incidencia: primer ensayo de disponibilidad no alcanzó lo pactado y se repite (desde 2026-10-11, sin dueño).

**Compromisos vencidos:** ninguno. Abierto: Liliana Torres, «Entregar el punto 1», para 2026-11-06 (dicho el 2026-10-14, comité semanal).
**Dependencias sin confirmar:** ninguna registrada; el riesgo de la entrega del proveedor sugiere una, pero el proyecto no tiene proveedor en la ficha (vendors vacío).

### Sin dato
Producto, autoridad (quién aprueba cambios) y fase: no encontrados. Los datos de identidad, plan y presupuesto aprobado vienen del acta del 2025-10-12 y llegan a 12 meses (umbral de antigüedad).

### Siguiente paso
Por la contradicción de avance y la fecha de cierre vencida sin replanificar, puedo preparar el punto de comité y, si el atraso viene de un cambio no formalizado, la solicitud de cambio. Y conviene pedir al gerente evidencia de recibo de ingeniería básica, de detalle y de montaje.

---
Criterio Portfolio v0.3.10 · ficha PRY-206 actualizada el 2026-10-15 · campos inciertos: producto, autoridad, fase, y la lectura del acta PDF de licencia · Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-15: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
