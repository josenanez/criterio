# Corrida del 2026-10-15 · portfolio-report

13 proyectos · 73 documentos, 23 releídos y 50 sin cambio · 38 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

El informe quedó en `/home/claude/banco/ronda-4/mineria/espacio/reportes/index.html`.

4 verdes contradichos; PRY-205 replanificado sin autorización; PRY-200 con 18 señales; 13 de 13 sin autoridad registrada

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-15
13 proyectos · 10 con hallazgos · 51 señales · fichas cargadas de `estado/records/` (PRY-199 a PRY-211), todas con barrido del 2026-10-15 (0 días; ninguna supera la semana).

**Términos:** vigentes (versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-15; comprobante en `.criterio/terminos/`). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato lleva la cita del documento de donde salió y la verificación es de usted. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10

Nota de ruta: las fichas están en `estado/records/`, no en `estado/fichas/` como dice el comando; se leyeron de ahí.

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior (la instantánea 2026-10-15 es de hoy; diff = 0 cambios). Esto es prácticamente el punto de partida.

## Señales por proyecto (salida de `compute`, sin recalcular)
| Proyecto | Señales |
|---|---|
| PRY-200 Mantenimiento predictivo de camiones | 18: avance vs plan, 4 hitos cumplidos sin evidencia, 7 compromisos vencidos, 2 sin fecha, 2 reprogramados, entregable de proveedor atrasado, entregable aceptado sin evidencia |
| PRY-205 Sistema de gestión de seguridad | 8: desviación en tiempo (112 días vs original), avance vs plan, 4 hitos sin evidencia, compromiso vencido, **replanificación sin autorización** |
| PRY-206 Red privada LTE en mina | 5: avance vs plan, 3 hitos sin evidencia, declarado vs evidencia |
| PRY-201 Ampliación de la relavera | 4: avance vs plan, 2 hitos sin evidencia, declarado vs evidencia |
| PRY-207 Gemelo digital de la planta | 4: avance vs plan, 3 hitos sin evidencia |
| PRY-209 Electrificación de equipos | 5: avance vs plan, 4 hitos sin evidencia |
| PRY-203 Despacho automático de flota | 3: hito sin evidencia, compromiso sin fecha, declarado vs evidencia |
| PRY-202 Planta de tratamiento de agua | 2: desviación de costo, declarado vs evidencia |
| PRY-204 Monitoreo de taludes | 1: desviación de costo |
| PRY-208 Trazabilidad del mineral | 1: cambio sin línea base |
| PRY-199, PRY-210, PRY-211 | Sin señales |

## Contradicciones abiertas
Cuatro proyectos declarados en verde están contradichos por la evidencia (PRY-201, PRY-202, PRY-203, PRY-206). El detalle con las dos fuentes y fechas está en `reportes/index.html`.

## Hitos vencidos sin evidencia
El script no reporta hitos vencidos; reporta **hitos cumplidos sin evidencia** (PRY-200, 201, 203, 205, 206, 207, 209). Detalle por hito en `reportes/index.html`.

## Proyectos en silencio
Vacía: el mayor silencio es 9 días (PRY-202), bajo el umbral de 15. (PRY-200 no tiene fecha de último documento calculable.)

## Dependencias en riesgo
Sin dependencias señaladas por el script en esta corrida.

## Sin sustento
Ver "hitos cumplidos sin evidencia" y "declarado vs evidencia" arriba; 4 verdes contradichos.

## Vacíos de información
- Ningún proyecto (13 de 13) tiene autoridad/patrocinador registrado.
- 7 proyectos sin producto asociado: PRY-201, 202, 205, 206, 209, 210, 211.
- PRY-208 tiene un cambio sin línea base.

## Estado general
Producto con más carga: monitoreo de flota (PRY-200, 18 señales). Detalle de desviación contra original y vigente, y replanificaciones: PRY-205 desvió 112 días contra la original (1 replanificación, no autorizada); PRY-200 tiene 1 replanificación. El resto: 0 días.

## Necesito que confirmes
Sin sesión interactiva; no se hicieron preguntas de confirmación. Pendiente para la siguiente corrida con interlocutor: cinco campos de confirmación mensual.

## Informe HTML
- `reportes/index.html` — por campo, con cadena de evidencia completa: para quien va a actuar.
- `reportes/decisiones.html` — por decisión: para el patrocinador, solo lo que excede la facultad del gerente.
- Además: una página por proyecto (13), por producto (6), `productos.html` y `proyectos.html`. 23 páginas. Para PDF, imprimir el HTML.

---
Pie: criterio-portfolio 0.3.10 · fichas del 2026-10-15 · campos inciertos: ver `index.html` · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
