## Listo — Minería

**Miré:** 73 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 42, .pdf 10, .docx 9, .csv 5, .xlsx 5, .json 1, .txt 1 · más reciente: 2026-10-15
**Eres:** PMO del portafolio (sugerido: hay 13 proyectos)
**Te aviso:** dos días antes de cada comité; los comités son semanales y no hay fecha del próximo, así que el informe sale cada semana (sugerido)
**En:** presentación (sugerido)
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-15 para la versión 0.3.10 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 del Markdown 5a63e87d0ce9d540…
**Dónde queda:** configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; informes en `reportes/`.

### Probé con tres proyectos

Cinco proyectos empatan con documentos del 2026-10-15 (PRY-200, 201, 203, 204 y 209). Tomé PRY-201, PRY-203 y PRY-204.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-201 Ampliación de la relavera | 5 | Gerente Sandra Gil, patrocinadora María Restrepo, presupuesto 2.400 M COP, cierre comprometido 2026-12-21. Declara verde y 50% (informe 2026-10-15). Ejecutado 50,5%, comprometido 64,5%. | Producto (el acta dice «No aplica»), facultad del gerente, etapa. |
| PRY-203 Despacho automático de flota | 5 | Gerente Gustavo Neira, patrocinador Felipe Arango, presupuesto 1.200 M COP, cierre 2027-05-21. Declara verde y 41% (informe 2026-10-10). Ejecutado 39,1%. | Facultad del gerente, etapa. |
| PRY-204 Monitoreo de taludes | 2 | Gerente Javier Hoyos, patrocinador Gustavo Neira, presupuesto 800 M COP, cierre comprometido 2026-01-16. Declara amarillo y 98% (informe 2026-10-15). | Cronograma e hitos, facultad del gerente, etapa. |

### Hallazgos (los que levantó el cálculo)

- **PRY-201: verde contradicho por la evidencia.** Dos hitos están declarados cerrados sin un acta que lo pruebe: «Ingeniería básica aprobada» (plan 2026-06-29, hace 108 días) e «Ingeniería de detalle aprobada» (plan 2026-08-07, hace 69 días). Además el 50% declarado queda 10 puntos por debajo de lo que sostiene el plan (entre 60% y 80%). El acta de recibo de licencias es del 2026-10-04, 19 días después de la fecha de línea base (2026-09-15).
- **PRY-203: verde contradicho por la evidencia.** «Ingeniería básica aprobada» figura cerrada (plan 2026-03-13, hace 216 días) sin acta de recibo. El comité del 2026-10-15 deja un compromiso sin fecha: Óscar Ramírez, «Entregar el punto 34».
- **PRY-204: sobrecosto proyectado de 13,9%.** La proyección al cierre es 910,8 M COP contra 800 M aprobados, y el estado declarado es amarillo.
- **Los tres:** la facultad del gerente no está en ningún acta, y en PRY-203 y PRY-204 los datos de identidad y presupuesto vienen de un acta de hace 12 y 17 meses sin confirmación posterior.

Resultado del cálculo: 3 proyectos con señales, 8 señales, 2 verdes contradichos.

### El portafolio completo
10 proyectos más (PRY-199, 200, 202, 205 a 211), 66 documentos, en un lote de 10 proyectos y otro de 1, uno tras otro. PRY-200 es el más grande (24 documentos, con contrato, facturas, solicitud de cambio y una ficha del gerente). Mi estimación es de 30 a 40 minutos; es una estimación, no una medición.

### Lo que le falta a tu carpeta
- Actas de recibo para los hitos que el cronograma da por cerrados (PRY-201 y PRY-203).
- PRY-202, PRY-204 y PRY-208 solo tienen acta e informe de avance, sin cronograma; PRY-204 tiene el cierre comprometido en 2026-01-16 y declara 98%.
- Fecha para los compromisos tomados en comité («por definir»).
- Facultad del gerente en las actas; ninguna de las tres la trae.
- Las actas de constitución de PRY-201, PRY-203 y PRY-204 tienen alcance genérico («Componente 1, 2, 3») y «Ninguna declarada» en dependencias.
- Una ruta suelta: `PRY-200.../2026-10-15-notas-reunion.txt` está fuera de las subcarpetas de seguimiento o reuniones.

Ninguno es bloqueante.
