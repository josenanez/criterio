# Corrida del 2026-10-15 · project-history

13 proyectos · 77 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Historia de PRY-200 sobre 23 archivos (2025-10-01 a 2026-10-15). 1 replanificación sin motivo ni aprobación documentados; 4 hitos cumplidos sin evidencia; una sola declaración de estado, así que el deslizamiento no se pudo fechar. No sé quién aprobó el cambio de fecha ni qué pasó entre 2026-02-15 y 2026-09-03.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Historia · PRY-200 Mantenimiento predictivo de camiones · 2025-10-01 a 2026-10-15

**Leí:** 23 archivos de la carpeta del proyecto (22 documentos más la ficha-pm.json, que es un registro derivado) entre 2025-10-01 y 2026-10-15. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15).
**Trimestres sin un solo documento:** 2026 T2 (abril–junio). Entre el acta de recibo del 2026-02-15 y el primer comité del 2026-09-03 no hay ningún documento.

### En una línea
El proyecto nació el 2025-10-07 con cierre al 2026-05-13 y un cronograma que ya traía los cinco hitos marcados "cerrado". El único cambio de fecha que consta es "Pruebas en operación", de 2026-04-24 a 2026-06-12, y solo aparece en el cronograma v2 del 2026-10-13, sin motivo ni aprobación. Hasta septiembre de 2026 casi no hay rastro documental. El informe del 2026-10-13 declara amarillo y 61%, mientras el plan marcado como cumplido sustenta 100%. Cuatro de esos hitos "cumplidos" no tienen evidencia, y el mismo informe dice que los equipos llegaron al campamento "pendientes de aceptación".

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 0 días en la fecha de cierre del proyecto (compute: `slip_vs_original_days` = 0; el acta sigue en 2026-05-13). El hito "Pruebas en operación" se movió de 2026-04-24 a 2026-06-12; el script no entrega ese atraso como cifra, así que no la escribo. | No calculable: el script no lo entrega y hay una sola declaración de estado (2026-10-13). | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-10-01 | 00-gobierno/2025-10-01-contrato-ct-235.md | Contrato CT-235 con Servicios Ambientales del Norte: 3 entregables de 204.854.837 COP cada uno; pago contra acta de recibo firmada por el gerente. Licenciamiento comprometido al 2025-12-08, ya "pendiente" en este texto. |
| 2025-10-07 | 00-gobierno/2025-10-07-acta-constitucion.docx | Aprobación por Comité de Seguridad: 2.400.000.000 COP, inicio 2025-10-17, cierre 2026-05-13. Dependencias: "Ninguna declarada". |
| 2025-10-07 | 10-plan/2025-10-07-cronograma-v1.csv | 5 hitos con fecha de línea base; los cinco con estado "cerrado" aunque sus fechas eran futuras. |
| 2026-02-15 | 20-seguimiento/2026-02-15-acta-recibo-…bolsa-de-horas… | Acta de recibo de la bolsa de horas, comprometida al 2026-01-29. Es la única pieza de evidencia entre octubre de 2025 y septiembre de 2026. |
| 2026-09-03 a 2026-10-08 | 30-reuniones (6 comités semanales) | Aparece el seguimiento de compromisos; arranca con 4 abiertos y llega a 14 el 2026-10-08. |
| 2026-09-17 a 2026-10-08 | 20-seguimiento (actas de recibo 3, 8, 12, 14, 17, 19) | Actas de recibo de compromisos de reunión (anexo 3, punto 8, ambiente 12, matriz 14, documento 17, anexo 19). |
| 2026-09-27 | 20-seguimiento/2026-09-27-factura-ct-235.md | Factura FV-1235 por 409.709.674 COP (equivale a dos entregables), radicada en cuentas por pagar. Solo hay acta de recibo de la bolsa de horas. |
| 2026-10-04 | 20-seguimiento/2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf | Acta de recibo de "Licencia y permisos obtenidos", hito con línea base 2026-02-07. |
| 2026-10-11 | 20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md | CC-01: ampliación de alcance, +49 días sobre la línea base vigente y 98.000.000 COP. Autorización: "pendiente de presentación al comité". |
| 2026-10-13 | 10-plan/2026-10-13-cronograma-v2.xlsx | "Pruebas en operación" pasa de 2026-04-24 a 2026-06-12; los demás hitos no cambian; los cinco siguen "cerrado". |
| 2026-10-13 | 20-seguimiento/2026-10-13-informe-avance.md | Amarillo, 61%. Dice que el proveedor entregó los equipos en el campamento, pendientes de aceptación, y que se perdieron dos semanas por rotación de un ingeniero clave. |
| 2026-10-15 | 2026-10-15-notas-reunion.txt | Paula Céspedes mueve por sexta vez su compromiso; Laura Vélez promete el ajuste de presupuesto "la otra semana"; se comenta un riesgo del proveedor que nadie anotó. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | Sin fecha de decisión; consta en el cronograma v2 del 2026-10-13 | Hito "Pruebas en operación": 2026-06-12 (antes 2026-04-24). La fecha de cierre del proyecto en el acta sigue en 2026-05-13. | No hay motivo documentado | Ninguno. CC-01 no es esta aprobación: es una ampliación de alcance pendiente de comité. |

El cronograma v2 es de 2026-10-13, después de la fecha que fija. La ficha del proyecto tiene una sola versión de línea base (la del acta).

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos (compute: `governance_changes` vacío). Siguen Rubén Cárdenas, Camilo Beltrán y Comité de Seguridad. | Acta de constitución |

Que no haya cambios no prueba que no los hubo: el informe del 2026-10-13 menciona la rotación de un ingeniero clave, que no es un cambio de gobierno pero sí un dato que no consta en otro documento. El campo "autoridad" no se encuentra en ningún documento.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 6 | original 2026-09-25 → 2026-10-12, 2026-10-28, 2026-11-14, 2026-11-23, 2026-12-09, 2026-12-23 |
| Mauricio Pérez | Cerrar la prueba 2 | 5 | original 2026-09-22 → 2026-10-05, 2026-10-20, 2026-10-27, 2026-11-17, 2026-12-02 |

Además, compute marca 7 compromisos vencidos sin evidencia: Andrés Lozano (ambiente 4, 18 días), María Restrepo (fecha 7, 25), Beatriz Cuéllar (documento 9, 25), Javier Hoyos (prueba 10, 7), Sandra Gil (anexo 11, 14), Ricardo Salas (prueba 18, 9) y Diana Molina (diseño 21, 4). Hay dos sin fecha: Beatriz Cuéllar (matriz 6) y Laura Vélez (ajuste del presupuesto). En el comité del 2026-09-24 tres personas dicen que ya entregaron (diseño 5, matriz 6, anexo 11) y no hay acta de ninguno; el 2026-09-17, María Restrepo dice lo mismo de la fecha 7.

### Desde cuándo lo declarado no se sostiene
No se puede fechar el deslizamiento con una serie, porque en la carpeta hay una sola declaración de estado: el informe del 2026-10-13. Lo que sí se puede fechar es el primer hito sin evidencia: "Ingeniería básica aprobada", con fecha 2025-11-23. Siguen "Ingeniería de detalle aprobada" (2025-12-31), "Montaje e instalación" (2026-03-17) y "Pruebas en operación" (2026-06-12). Todos figuran como cumplidos sin acta ni documento que lo respalde. "Licencia y permisos obtenidos" sí tiene acta, pero del 2026-10-04, 8 meses después de su fecha de línea base (2026-02-07); esa diferencia la calculo yo y no la entrega el script.

Lo que se sigue reportando: 61% y amarillo, cuando el plan con los cinco hitos cumplidos sustenta 100% (compute: brecha de 39 puntos). Hay además dos contradicciones en el propio informe y el contrato: el licenciamiento del software sigue "pendiente" desde 2025-12-08 (311 días) mientras "Pruebas en operación" figura cerrado, y el informe dice que los equipos están "pendientes de aceptación" mientras "Montaje e instalación" figura cumplido desde 2026-03-17.

### Lecciones ancladas a un hecho
1. **Un cronograma que nace con los hitos "cerrados" no sirve de línea base.** Hecho: el cronograma v1 del 2025-10-07 marca cerrados los cinco hitos con fechas futuras. Efecto: el "cumplido" no tiene fecha de cierre y no se puede contrastar con nada.
2. **Facturar contra un acta que no existe rompe la condición de pago del contrato.** Hecho: FV-1235 (2026-09-27) por 409.709.674 COP cubre dos entregables y solo existe acta de recibo de la bolsa de horas (2026-02-15). Efecto: "Calibración de sensores" consta como aceptado sin evidencia.
3. **Mover una fecha sin documento hace invisible el atraso.** Hecho: "Pruebas en operación" pasó a 2026-06-12 en el cronograma del 2026-10-13, sin motivo ni aprobación, y el acta mantiene el cierre en 2026-05-13. Efecto: contra la línea base del proyecto el atraso sale en 0 días.
4. **Un compromiso movido seis veces no es una fecha.** Hecho: "Enviar el documento 1" pasó de 2026-09-25 a 2026-12-23 en seis cambios en cinco semanas. Efecto: la fecha vigente ya es 89 días posterior a la original según las propias fechas escritas; el entregable sigue sin acta.

No se ancla ninguna lección sobre el riesgo del proveedor (nota del 2026-10-15): lo dijo alguien en la reunión y nadie lo registró. Eso es un hallazgo, no una lección.

### Lo que no sé
- Quién aprobó el cambio de fecha de "Pruebas en operación", cuándo y por qué.
- Qué pasó entre 2026-02-15 y 2026-09-03: puede haber documentos que no están en la carpeta.
- Si hay evidencia de los hitos de ingeniería y montaje fuera de la carpeta.
- Si los comités de septiembre-octubre son los primeros o los primeros que se guardaron.

Esta historia no atribuye intención: que el atraso no aparezca en el acta no dice que alguien lo ocultara. Sirve para tener esa conversación con datos en vez de con memorias. ¿Quieres llevarla al comité? Hay una decisión pendiente (CC-01, +49 días y 98.000.000 COP) que se apoya en una línea base que hoy no es clara.

*Rigor: las cifras salen de `portafolio.py compute` (as_of 2026-10-15), salvo la brecha de 8 meses y los 89 días, que calculé yo de fechas escritas en los documentos y están marcados. Todo dato lleva el documento del que sale; la verificación es tuya.*
