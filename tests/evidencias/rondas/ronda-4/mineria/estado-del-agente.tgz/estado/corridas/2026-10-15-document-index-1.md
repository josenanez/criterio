# Corrida del 2026-10-15 · document-index

13 proyectos · 30 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

73 documentos, 23 nuevos (todos PRY-200), 0 cambiados. 250 citas marcadas sin resolver por el índice, probable falso positivo de rutas relativas; no verificado a fondo. No se reportan formatos ilegibles.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-15

**Documentos:** 73 · **Sin cambio:** 50 · **Hay que releer:** 23

### Cambió el contenido
Ninguno. Ningún documento ya indexado cambió de hash.

### Documentos nuevos para el índice (23, todos de PRY-200)
Contrato CT-235, acta de constitución (.docx), ficha-pm.json, cronogramas v1 (.csv) y v2 (.xlsx), 9 actas de recibo/factura/solicitud de cambio/informe de avance en 20-seguimiento (incluye un .pdf), 6 comités semanales (30-reuniones) y las notas de reunión del 2026-10-15. Los otros 12 proyectos (PRY-199, 201 a 211) no tienen nada nuevo.
Nota: la ficha de PRY-200 ya cita estos documentos, pero el índice no los tenía registrados; por eso salen como nuevos y no como cambiados.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
El índice marca 250 citas de PRY-200 (campos pm_record.* de la ficha del gerente, ficha-pm.json) como "fuente no encontrada". No las doy por rotas: las 14 fuentes distintas existen dentro de la carpeta de PRY-200. Son rutas relativas a la carpeta del proyecto (p. ej. `00-gobierno/2025-10-07-acta-constitucion.docx`), y el chequeo parece resolverlas contra la raíz de documentos. Es un falso positivo probable, no verificado. Dos rutas (`...acta-recibo-licencia-y-permisos-obtenidos.pdf`, `...informe-avance.md`, `...solicitud-cambio-cc-01.md`) comparten nombre con archivos de otros proyectos, así que conviene confirmar que apunten al de PRY-200.

### Formatos que no se pudieron leer
El índice no reporta ninguno. No lee contenido: solo cuenta y compara hashes. Hay 1 .docx, 1 .xlsx y 1 .pdf entre los nuevos; su lectura la decide el barrido.

### Siguiente paso
`/portfolio-scan` limitado a PRY-200 (23 documentos). `projects_to_recompute` viene vacío.
