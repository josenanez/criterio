Acta previa: sí, **PRY-210 tiene acta de constitución, del 2025-07-31** (`PRY-210-programa-de-relacionamiento-comunitario/00-gobierno/2025-07-31-acta-constitucion.md`). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

## Acta — PRY-210 · Programa de relacionamiento comunitario
**Estado:** existe, del 2025-07-31 (una sola versión; sin enmiendas en la carpeta)

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** (monto y cambios sin comité) | **No existe** | CC-01 (+62.000.000 COP, +31 días, ampliación de alcance) está "pendiente de presentación al comité". Como el acta no dice qué puede decidir Camilo Beltrán solo, no hay forma de saber si CC-01 era suyo o debía subir; hoy sube todo por defecto. |
| **Objetivo de negocio** | Es la descripción de la solución, no un objetivo: "Entregar programa de relacionamiento comunitario para Tecnología" | No dice qué cambia para el negocio ni cuánto. Nadie puede juzgar si la ampliación de CC-01 aporta o desvía. |
| **Alcance** | "Componente 1, 2, 3", sin contenido | Una ampliación de alcance (CC-01) no se puede medir contra un alcance que no dice qué incluye. |
| **Exclusiones** | "Lo que otro proyecto cubre", sin nombrar el proyecto ni el límite | No protege de nada: la ampliación de CC-01 podría estar invadiendo lo que cubre otro proyecto y el acta no permite verlo. |
| **Criterio de éxito** | "En producción y medido": sin métrica, umbral ni fecha | "Medido" no dice con qué número se da por logrado. El cierre sería una opinión. |
| **Quién mide el éxito** | No existe | Quien reporta el avance (el gerente) sería también quien declara el éxito. |
| **Supuestos y restricciones** | No existen | Los dos riesgos del informe (licencia ambiental, ventana de parada de planta) son en realidad supuestos y restricciones nunca declarados; hoy no hay base contra la cual decir que dejaron de cumplirse. |
| **Dependencias** | "Ninguna declarada" | Contradice el informe de avance del 2026-10-11, que depende de una ventana de parada que define operaciones. |
| **Hitos principales** | No existen | Sin hitos, el 69 % de avance declarado no se puede contrastar con nada. |
| **Cadencia del comité** | No existe (solo se nombra el Comité de Tecnología) | No se sabe cada cuánto debe ver el proyecto. |
| **Autorización de la línea base** | Presente: aprobada por el Comité de Tecnología el 2025-07-31 | Sin hallazgo. |
| **Patrocinador / Gerente** | Presentes con nombre de persona: Laura Vélez / Camilo Beltrán | Sin hallazgo. |
| **Presupuesto y fechas** | Presentes: 6.800.000.000 COP; 2025-08-10 a 2026-10-31 | Sin hallazgo en el acta. Ver contraste abajo. |

### Contenido
**Objetivo de negocio:** pendiente de definir. El acta dice "Entregar programa de relacionamiento comunitario para Tecnología", que es la solución y no un resultado medible (acta, sección Objetivo del negocio).
**Alcance:** Componente 1, Componente 2, Componente 3, sin descripción (acta, sección Alcance). Contenido de cada componente: pendiente de definir.
**Exclusiones:** "Lo que otro proyecto cubre" (acta). Qué proyecto y qué parte: pendiente de definir.
**Patrocinador:** Laura Vélez · **Gerente:** Camilo Beltrán (acta). Área dueña: Tecnología. Producto asociado: "No aplica".
**Autoridad del gerente:** pendiente de definir. No hay monto ni tipo de cambio en ningún documento de la carpeta.
**Comité al que reporta:** Comité de Tecnología (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir. **Restricciones:** pendiente de definir.
**Criterio de éxito:** "Programa de relacionamiento comunitario en producción y medido" (acta); métrica y umbral: pendiente de definir · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo hay inicio 2025-08-10 y cierre 2026-10-31 (acta).

### Contraste del acta con lo que pasó después (para dimensionar las consecuencias)
- **Presupuesto:** la proyección al cierre es 7.049.863.850 COP frente a 6.800.000.000 aprobados, es decir 249.863.850 COP por encima (3,7 %), sin contar los 62.000.000 de CC-01 (informe del 2026-10-11 y CC-01). Está por debajo del umbral de 10 % de la configuración, pero **excede lo aprobado y el acta no dice quién puede autorizar ese exceso**. Es el caso concreto donde falta la autoridad del gerente.
- **Plazo:** CC-01 suma 31 días sobre la línea base vigente, que sería del 2026-10-31 al 2026-12-01 si se aprueba. Faltan 16 días para el cierre comprometido y no hay decisión (CC-01 está pendiente de presentación al comité, sin fecha de comité).
- **Estado:** el informe declara Verde y 69 % de avance; el mismo informe dice que el primer ensayo de disponibilidad no alcanzó lo pactado y se repite. El acta no define el criterio de disponibilidad "pactado" ni quién lo pactó. Este contraste es del informe; el estado de salud se juzga con `/health-check`, no aquí.

### Qué no sé
- Si existe una enmienda, un acta del comité o un contrato de autoridad fuera de la carpeta del proyecto: no lo vi y no lo supongo.
- Qué proyecto cubre lo excluido y qué contienen los tres componentes.
- Qué se pactó como disponibilidad de los equipos.

## Después
- **Autoridad del gerente sin declarar:** conviene llevar esa definición al Comité de Tecnología. Es una decisión (monto y tipo de cambio que Camilo Beltrán decide solo), no un trámite, y debería resolverse junto con CC-01 para que el comité no decida a ciegas. Se puede preparar con `/steering-pack`.
- **Supuestos que salieron de la revisión** (licencia ambiental estable, ventana de parada de planta definida por operaciones, ausencia de dependencias): se pueden pasar al registro RAID con `/raid-log`.

*Pie de rigor: borrador de trabajo hecho solo con los tres documentos de la carpeta de PRY-210 (acta, solicitud CC-01 e informe de avance). Cada dato lleva su documento; lo que no estaba quedó como pendiente de definir. La verificación es de quien lo lea.*
