## Diagnóstico · PRY-200 Mantenimiento predictivo de camiones · 2026-10-15

**Leí:** 23 documentos · del 2025-10-01 al 2026-10-15 · formatos: .md (17), .docx (1), .xlsx (1), .csv (1), .pdf (1), .txt (1), .json (1).
De los 23, uno es `00-gobierno/ficha-pm.json`, la ficha del propio gerente: la traté como declaración, no como evidencia, y solo la usé para comparar. Búsqueda en las otras 12 carpetas de proyecto por texto (PRY-200, CT-235, «predictivo»): ninguna lo menciona. Esa búsqueda cubre los archivos de texto; los .docx y .xlsx de las otras carpetas no se pudieron buscar así.
**No pude leer:** nada quedó ilegible. Los .docx y .xlsx se leyeron desde su XML y el PDF con extracción de texto; el PDF es de una sola página de texto, sin firmas ni anexos visibles.

### Dictamen
**Sostenido:** 12 afirmaciones · **Sin sustento:** 16 · **Contradicho:** 4 (32 afirmaciones dictaminadas: las del informe de avance del 2026-10-13, las de la ficha del gerente, las del contrato y las dichas en comité).

Desde esta carpeta se puede afirmar: quién patrocina y quién gerencia, cuánto se aprobó (2.400.000.000 COP), que hay una solicitud de cambio sin decidir, que 6 compromisos de comité se cerraron con acta de recibo y que 2 de los 3 entregables del proveedor figuran como recibidos, uno solo con acta. No se puede afirmar el estado real del proyecto. El informe dice «Amarillo» y 61% de avance. El cronograma vigente dice que los 5 hitos están cerrados (el plan sostiene 100%, una diferencia de 39.0 puntos), y de los 5 hitos solo uno tiene un documento de recibo. Hoy es 2026-10-15 y la fecha de cierre del acta, 2026-05-13, nunca se movió en ningún documento. Ese informe omite las 5 señales que el cálculo encuentra abiertas: avance contra plan, hitos cumplidos sin evidencia, compromisos vencidos, compromisos reprogramados y entregable de proveedor vencido.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Rubén Cárdenas | `00-gobierno/2025-10-07-acta-constitucion.docx` |
| Gerente | Camilo Beltrán | ídem |
| Autoridad declarada | **No está dicha en ningún documento.** El acta no fija qué puede aprobar el gerente en fechas, dinero o alcance | ídem (ausencia; el cálculo la marca en `identity.authority`) |
| Comité | Comité de Seguridad; aprobó el presupuesto el 2025-10-07. Sus minutas existen solo del 2026-09-03 al 2026-10-08 (6) | acta; `30-reuniones/` |

Consecuencia: sin autoridad declarada no hay desviación aprobada, hay fechas que alguien escribió. Además:
- El contrato CT-235 está firmado el 2025-10-01, antes de la aprobación del acta (2025-10-07) y del inicio (2025-10-17).
- El acta dice «Dependencias declaradas: ninguna», pero el proyecto depende de un proveedor con contrato.
- El alcance son «Componente 1, 2, 3» y la exclusión es «lo que otro proyecto cubre»: el acta no permite saber qué entra ni qué no.

### Contra el plan
- **Línea base original:** acta del 2025-10-07: inicio 2025-10-17, cierre 2026-05-13, 2.400.000.000 COP; hitos en `2025-10-07-cronograma-v1.csv` (último: Pruebas en operación, 2026-04-24).
- **Vigente:** `2026-10-13-cronograma-v2.xlsx`. Un solo cambio: Pruebas en operación pasó de 2026-04-24 a 2026-06-12. No hay motivo escrito, ni acta de cambio aprobada, ni línea base nueva aprobada. El cálculo da 1 replanificación, 0 cambios aprobados.
- **El cierre:** la fecha de cierre del acta sigue siendo 2026-05-13 (el cálculo da `slip_vs_original_days` = 0), pero el último hito vigente es 2026-06-12, posterior. Los dos no pueden ser verdad a la vez.
- **CC-01** (2026-10-11): ampliación de alcance, +49 días y 98.000.000 COP, «pendiente de presentación al comité». El cálculo no puede dar días no autorizados (`unauthorized_days` nulo). Una observación mía, no del cálculo: el corrimiento de Pruebas en operación (2026-04-24 a 2026-06-12) parece coincidir con esos +49 días. Si es el mismo cambio, ya está aplicado en el plan sin autorización. La carpeta no lo dice.
- **Estados imposibles por fecha:** el cronograma v1 está fechado 2025-10-07 y ya marca los 5 hitos «cerrado». La tabla del contrato, fechado 2025-10-01, ya marca «recibido» entregables de 2026. Los dos documentos se editaron después de su fecha y no dejan versión.

### Hitos vencidos sin evidencia
Los 5 hitos figuran «cerrado» (declarado). Documento de recibo en la carpeta: solo para uno.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-11-23 | 326 | Acta de aprobación de ingeniería básica |
| Ingeniería de detalle aprobada | 2025-12-31 | 288 | Acta de aprobación de ingeniería de detalle |
| Montaje e instalación | 2026-03-17 | 212 | Acta de recibo de montaje |
| Pruebas en operación | 2026-06-12 (vigente) | 125 | Acta o informe de pruebas |

Licencia y permisos obtenidos sí tiene acta de recibo, pero está fechada 2026-10-04 y el hito figura en 2026-02-07 con estado «cerrado» desde antes. La evidencia llegó meses después de la fecha. El cálculo no lo marca porque hay documento.

### Dinero
Todas las cifras vienen del informe de avance del gerente (declaración). Ningún documento de la carpeta las respalda: no hay estado de ejecución ni ledger.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.481.500.375 | 993.723.690 | 2.474.762.505 | 918.499.625 |

COP. Cálculo: ejecutado 41.4% del aprobado, comprometido 61.7%, proyección 3.1% sobre el aprobado (bajo el umbral de 10%). Solo el aprobado tiene respaldo (acta). El informe no dice si la proyección incluye los 98.000.000 COP de CC-01.

**Proveedor Servicios Ambientales del Norte (CT-235):**

| Entregable | Fecha | Monto COP | Estado | Evidencia |
|---|---|---|---|---|
| Licenciamiento del software | 2025-12-08 | 204.854.837 | pendiente | Vencido 311 días |
| Bolsa de horas de ingeniería | 2026-01-29 | 204.854.837 | recibido | Acta 2026-02-15 |
| Calibración de sensores | 2026-03-22 | 204.854.837 | recibido | **Sin acta** |

La factura FV-1235 del 2026-09-27 cobra 409.709.674 COP por «entregables del contrato CT-235» (el cálculo lo tiene como lo aceptado). El contrato exige factura contra acta de recibo firmada por entregable, y la carpeta tiene un acta para dos entregables cobrados. La factura figura «radicada», no pagada.

### Lo que se dijo y nadie registró
- **Riesgo:** en las notas del 2026-10-15 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y nadie lo anotó. La carpeta no tiene registro RAID. El informe lista un solo riesgo (concentración del conocimiento en una persona), sin dueño. El plan no tiene ninguna «siguiente fase».
- **Incidencia:** pérdida de dos semanas por rotación de un ingeniero clave. Solo está en el informe, sin fecha ni documento.
- **Compromisos vencidos sin evidencia (7):**
  - Andrés Lozano, validar el ambiente 4 (2026-09-27, 18 días)
  - María Restrepo, confirmar la fecha 7 (2026-09-20, 25 días)
  - Beatriz Cuéllar, enviar el documento 9 (2026-09-20, 25 días)
  - Javier Hoyos, cerrar la prueba 10 (2026-10-08, 7 días)
  - Sandra Gil, revisar el anexo 11 (2026-10-01, 14 días)
  - Ricardo Salas, cerrar la prueba 18 (2026-10-06, 9 días)
  - Diana Molina, aprobar el diseño 21 (2026-10-11, 4 días)
- **Reprogramados:** Paula Céspedes, «enviar el documento 1» (original 2026-09-25, ahora 2026-12-23): 6 veces. Mauricio Pérez, «cerrar la prueba 2» (original 2026-09-22, ahora 2026-12-02): 5 veces.
- **Sin fecha:** Beatriz Cuéllar, actualizar la matriz 6. Laura Vélez, mandar el ajuste del presupuesto «la otra semana».
- **Dichos como entregados, sin acta (4):** María Restrepo («confirmar la fecha 7», 09-17), Carlos Peña («aprobar el diseño 5», 09-24), Beatriz Cuéllar («actualizar la matriz 6», 09-24) y Sandra Gil («revisar el anexo 11», 09-24).
- **Cadencia:** las notas del 2026-10-15 fijan la próxima reunión «en dos semanas»; el comité figuraba semanal.
- **Autoaceptación:** el acta de recibo de «Entregar el punto 8» recibe un compromiso del propio Camilo Beltrán, firmado por Camilo Beltrán.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Avance 61% | Informe 2026-10-13: 61% | Cronograma v2: 5 de 5 hitos «cerrado»; el plan sostiene 100% (diferencia de 39.0 puntos) |
| «Se actualizó el presupuesto de la obra con el área de compras» | Informe 2026-10-13 | Notas 2026-10-15: Laura Vélez «queda de mandar el ajuste del presupuesto la otra semana» (las notas no dicen si es el mismo presupuesto) |
| Cierre del proyecto 2026-05-13 | Acta de constitución; no hay otra fecha de cierre en ningún documento | Cronograma v2: Pruebas en operación 2026-06-12; además hoy es 2026-10-15 y el informe sigue reportando avance |
| «Dependencias: ninguna declarada» | Acta de constitución | Contrato CT-235 y notas 2026-10-15 (proveedor y equipo completo) |

### Sin sustento
Lo que ningún documento contradice ni respalda (16):
- **Estado «Amarillo»**: ningún documento define su criterio, y el informe no menciona las 5 señales abiertas.
- **Cifras**: comprometido, ejecutado y proyección.
- **Hitos «cerrado» sin acta** (4): Ingeniería básica, Ingeniería de detalle, Montaje e instalación, Pruebas en operación.
- **Calibración de sensores «recibido»**: sin acta. La factura la cobra.
- **Informe**:
  - «El proveedor entregó los equipos en el campamento, pendientes de aceptación»: el contrato no tiene equipos como entregable.
  - «Perdió dos semanas por rotación de un ingeniero clave».
  - El riesgo de concentración del conocimiento se reporta como abierto, sin dueño ni registro.
- **Los 4 «ya entregué» de comité**, sin acta.

### Lo que esta carpeta no permite saber
- **Si el proyecto está en Amarillo o en otro color:** sin evidencia de 4 de 5 hitos ni línea base vigente aprobada, no se puede medir atraso. Si el cierre es 2026-05-13 o 2026-06-12, nadie lo aprobó.
- **Cuánto lleva realmente de avance:** hay dos cifras incompatibles (61% y 100% del plan) y ninguna es medición independiente.
- **Cuánto se gastó y cuánto se debe:** sin estado financiero, el comprometido, el ejecutado y la proyección son la palabra del gerente. Para saber si FV-1235 está bien radicada falta el acta de Calibración de sensores.
- **Quién puede aprobar CC-01 y si ya se aplicó:** el acta no declara autoridad y el comité no tiene CC-01 en minuta.
- **Qué pasó entre 2025-10 y 2026-08:** no hay una sola minuta ni acta de seguimiento anterior al 2026-09-03, salvo la de Bolsa de horas (2026-02-15). El silencio es del proyecto entero, no solo de quien reporta.
- **Qué es la «siguiente fase»:** ningún plan la contiene.

Qué se puede hacer con esto: preparar el punto de comité con la lista de lo que falta (actas de los 4 hitos y de Calibración de sensores, estado financiero, declaración de autoridad, decisión sobre CC-01 y registro RAID), o llevarle al gerente las 4 contradicciones como preguntas, una por una. Esa decisión es suya; este diagnóstico no recomienda detener, continuar ni reestructurar.

---
**Pie de rigor:** documentos leídos completos, 23 de 23. Las cifras derivadas (porcentajes, días, disponible, conteos de señales) salen de `portafolio.py compute` con corte 2026-10-15; las que aparecen en las fechas de los documentos son las que ellos escriben. Las observaciones marcadas como mías (coincidencia de 49 días, autoaceptación, fechas imposibles) son lectura de los textos, no cálculo. La verificación contra los originales es de quien lea. Términos vigentes: versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15.
