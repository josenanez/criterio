# Corrida del 2026-10-15 · portfolio-scan

13 proyectos · 73 documentos, 23 releídos y 50 sin cambio · 289 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Se leyeron 61 de 73 documentos (10 proyectos nuevos; PRY-201, 203 y 204 sin cambio). Nada movido: no hay entrada/. PRY-200 escrita pero sin sellar: ficha-pm.json trae un source con dos rutas; se releerá hasta que el gerente la corrija. Mirar: 4 verdes contradichos, PRY-205 línea base movida +112 días sin autorizar, 7 compromisos vencidos en PRY-200.

Contra la corrida del 2026-10-15: +43 hallazgos.

## Lo que produjo

## Barrido — 2026-10-15

Encontré 73 documentos en 13 carpetas de proyecto (PRY-199 a PRY-211). Formatos: .md 42, .pdf 10, .docx 9, .csv 5, .xlsx 5, .json 1, .txt 1. Todos se pudieron leer.

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 para la versión 0.3.10). No hubo que registrar nada nuevo.

**Plan de lectura:** 61 de 73 documentos, en un lote de 10 proyectos, uno tras otro en esta conversación. Los otros 12 son PRY-201, PRY-203 y PRY-204, que `portfolio-setup` ya leyó y no cambiaron. No quedó nada diferido.

**Documentos:** 73 en la carpeta · 61 leídos · 12 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos en esta corrida · 0 sin carpeta propia

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, producto PRD-299, presupuesto, 5 hitos, 3 entregables del contrato CT-199, 1 compromiso | facultad del gerente, etapa, facturado |
| PRY-200 Mantenimiento predictivo de camiones | 24 + ficha del gerente | identidad, 2 líneas base, 5 hitos, contrato CT-235 con factura, CC-01, 26 compromisos (6 cerrados con acta) | facultad del gerente, etapa |
| PRY-202 Planta de tratamiento de agua | 2 | identidad, presupuesto, proyección | producto («No aplica»), facultad, etapa, cronograma e hitos |
| PRY-205 Sistema de gestión de seguridad | 7 | identidad, 2 versiones de cronograma, 5 hitos, CC-01, 1 compromiso | producto («No aplica»), facultad, etapa |
| PRY-206 Red privada LTE en mina | 5 | identidad, 4 hitos, presupuesto, 1 compromiso | producto («No aplica»), facultad, etapa |
| PRY-207 Gemelo digital de la planta | 5 | identidad, producto, 4 hitos, 2 compromisos | facultad, etapa |
| PRY-208 Trazabilidad del mineral | 3 | identidad, producto, presupuesto, CC-01 | facultad, etapa, cronograma e hitos |
| PRY-209 Electrificación de equipos | 4 | identidad, 4 hitos, presupuesto, 1 compromiso | producto («No aplica»), facultad, etapa |
| PRY-210 Programa de relacionamiento comunitario | 3 | identidad, presupuesto, CC-01 | producto («No aplica»), facultad, etapa, cronograma e hitos |
| PRY-211 Control de polvo en vías | 3 | identidad, presupuesto, CC-01 | producto («No aplica»), facultad, etapa, cronograma e hitos |

### Actualizados
Ninguno. PRY-201, PRY-203 y PRY-204 no cambiaron y se conservan tal cual.

### Hallazgos (los que levantó el cálculo)
El cálculo dio 51 señales en 10 de los 13 proyectos, con 4 verdes contradichos por la evidencia.

- **Verde contradicho** (PRY-201 y PRY-203, ya reportados en el setup, y dos nuevos):
  - PRY-202, verde con avance de 25%: la proyección al cierre es 11.432.506.949 COP contra 9.500.000.000 aprobados (+20,3%).
  - PRY-206, verde con avance de 33%: los cuatro hitos del cronograma figuran cerrados y solo uno tiene acta de recibo (Licencia y permisos, 2026-10-04). El plan sostiene 100%.
- **Hitos declarados cerrados sin acta que lo pruebe:** PRY-200 (4 de 5), PRY-205 (4 de 5), PRY-209 (4 de 4, sin ninguna acta), PRY-206 (3 de 4) y PRY-207 (3 de 4). En todos el avance declarado queda lejos de lo que sostiene el cronograma: PRY-209 28% contra 100%, PRY-206 33%, PRY-200 61%, PRY-205 72%, PRY-207 75%.
- **Línea base movida sin autorización:** PRY-205. El cronograma v2 (2026-10-12) mueve «Pruebas en operación» de 2026-03-23 a 2026-07-13, +112 días (47,1% contra la original). La solicitud CC-01 con ese mismo impacto sigue «pendiente de presentación al comité». En PRY-200 el cronograma v2 mueve el mismo hito +49 días y CC-01 también está pendiente (ver «No pude sellar»).
- **Cambio sin línea base:** PRY-208. CC-01 (+54 días, 108.000.000 COP) figura «autorizada por el comité», pero no hay cronograma ni acta de comité en la carpeta.
- **Solicitudes de cambio pendientes de comité:** PRY-200 (+49 días, 98 M COP), PRY-205 (+112 días, 224 M COP), PRY-210 (+31 días, 62 M COP) y PRY-211 (+103 días, 206 M COP).
- **PRY-200, compromisos:** 7 vencidos sin evidencia, 2 sin fecha y 2 reprogramados varias veces. «Enviar el documento 1» (Paula Céspedes) se prometió para 2026-09-25 y va en 2026-12-23, seis reprogramaciones. «Cerrar la prueba 2» (Mauricio Pérez) pasó de 2026-09-22 a 2026-12-02, cinco. Además, cuatro personas dijeron en comité que ya habían entregado y no se presentó acta (María Restrepo el 2026-09-17; Carlos Peña, Beatriz Cuéllar y Sandra Gil el 2026-09-24).
- **PRY-200, proveedor (CT-235):** «Licenciamiento del software» vencía el 2025-12-08 y sigue pendiente. «Calibración de sensores» figura recibida en el contrato sin acta de recibo. Hay una factura FV-1235 por 409.709.674 COP radicada el 2026-09-27 y solo existe acta para la bolsa de horas.
- **PRY-200, riesgo que nadie registró:** en las notas del 2026-10-15 se dijo que el proveedor podría no llegar con el equipo completo para la siguiente fase. Lo levanté como riesgo.
- **PRY-205:** 1 compromiso vencido (Sandra Gil, «Entregar el punto 8», 2026-10-07). La minuta que lo recoge es del 2026-10-13 y lista a Javier Hoyos dos veces como asistente.
- **Facultad del gerente:** no aparece en ninguna acta, en los 13 proyectos.
- **Contradicciones entre documentos:** ninguna. Tampoco cambios de gobierno.

### No pude leer
Ninguno. Los 73 documentos se convirtieron a texto sin fallas.

### No pude sellar
| Proyecto | Por qué |
|---|---|
| PRY-200 | El sellado rechazó la ficha porque `00-gobierno/ficha-pm.json` (la del gerente) trae un `source` con dos rutas: «00-gobierno/2025-10-01-contrato-ct-235.md; factura: 20-seguimiento/2026-09-27-factura-ct-235.md». No la corregí: es su declaración y la ficha de la PMO la guarda entera en `pm_record`. La ficha de PRY-200 está escrita, pero sin sellar: la próxima corrida releerá sus 24 documentos hasta que el gerente deje una sola ruta en esa cita. En los otros proyectos el sellado completó las líneas base desde los cronogramas; en PRY-200 no ocurrió, y el cálculo no marcó el cambio de línea base sin autorizar que sí se ve a simple vista (+49 días, CC-01 pendiente). |

### Movidos desde entrada/
No hay carpeta `entrada/`. No se movió nada.

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-200…/2026-10-15-notas-reunion.txt` | No es ambiguo: nombra el proyecto y quedó asignado a PRY-200. Solo está fuera de `30-reuniones/`; no lo moví porque ya está en su carpeta. |

## Después
Hay más de un proyecto: puedo preparar el informe consolidado con `/portfolio-report`. Hay contradicciones de avance, compromisos vencidos y una línea base movida sin autorización (PRY-205), así que conviene mirarlos antes del comité.

---
Criterio portfolio 0.3.10 · fichas tocadas: 10 (PRY-199, 200, 202, 205, 206, 207, 208, 209, 210, 211) · campos en `not_found`: facultad del gerente y etapa en los 10; producto en 6 (el acta dice «No aplica»); cronograma e hitos en 4 (PRY-202, 208, 210, 211) · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal
