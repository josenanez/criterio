# Corrida del 2026-10-15 · budget-tracking

13 proyectos · 26 s · 51 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

Presupuesto PRY-202: proyección 20,3% sobre el aprobado con estado declarado verde; comprometido 38,0%, ejecutado 17,2%. Dijo que no sabía: hitos, proveedores, causa del sobrecosto, producto/autoridad/fase.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

Fuentes: ficha PRY-202 (acta de constitución 2026-02-22 e informe de avance 2026-10-06, PDF) y cálculo del script `compute` al 2026-10-15.

## Presupuesto — PRY-202 Planta de tratamiento de agua al 2026-10-15
**Moneda:** COP (única; no hay otras monedas ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 9.500.000.000 | 100 | 00-gobierno/2026-02-22-acta-constitucion.md | 2026-02-22 |
| Comprometido | 3.612.108.532 | 38,0 | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |
| Ejecutado | 1.634.387.317 | 17,2 | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |
| Proyección al cierre | 11.432.506.949 | — | 20-seguimiento/2026-10-06-informe-avance.pdf | 2026-10-06 |

**Disponible real** (aprobado menos comprometido): 5.887.891.468 COP

La proyección es una declaración del informe de avance, no un dato duro. Es posterior al aprobado (2026-02-22) y no hay ningún movimiento de presupuesto registrado después, así que no está desactualizada frente a la línea base.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 9.500.000.000 | 9.500.000.000 | 0 |
| Proyección frente al aprobado | | 11.432.506.949 | +20,3 % sobre el aprobado (umbral: 10 %) |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. La ficha solo guarda la línea base de fechas (versión 1, 2026-02-22). No hay una línea base de presupuesto separada; el aprobado es el del acta.

### Ejecución frente a avance
Ejecutado 17,2 % · Avance declarado 25 % · Hitos cumplidos: sin dato (la ficha no tiene hitos) · No se puede cruzar contra hitos. Contra el avance declarado, la ejecución va por debajo; puede ser trabajo hecho y no facturado, pero ningún documento lo confirma.

### Alertas
- **Proyección por encima del aprobado: 20,3 %**, más del doble del umbral de 10 %. Es la señal de `variance_cost` del script.
- **Declarado contra evidencia:** el informe de avance del 2026-10-06 declara estado **verde** y esa cifra de proyección no la explica. Ese estado lo sostiene solo una declaración; la ficha tiene 0 fuentes de evidencia y 2 de declaración.
- Comprometido 38,0 %, bajo el umbral de 90 %: no hay alerta de agotamiento.
- Incidencia abierta (misma fuente, sin responsable): el equipo perdió dos semanas por rotación de un ingeniero clave. El informe no dice si entra en la proyección.

### Sin dato
- Hitos del plan: no hay ninguno registrado, por eso no se mide el avance por hitos.
- Detalle por proveedor: la ficha no tiene proveedores ni contratos.
- Producto, autoridad y fase del proyecto: `not_found`.
- La causa del sobrecosto proyectado: ningún documento la explica.

**Siguiente paso posible:** como la proyección excede el aprobado, puedo preparar la solicitud de cambio (`/change-control`). No la he iniciado.

*Pie de rigor: borrador de trabajo basado solo en los 2 documentos de la ficha. Lo que se habló fuera de ellos no está. Verifica cada cifra contra su fuente citada.*
