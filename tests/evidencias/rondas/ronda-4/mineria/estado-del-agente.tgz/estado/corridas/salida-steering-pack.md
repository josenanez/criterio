# Comité de proyectos — 2026-10-15
6 decisiones · 7 escalamientos · 10 de 13 proyectos con hallazgos

**Base:** fichas PRY-199 a PRY-211 (13), cálculo `portafolio.py compute` con fecha 2026-10-15. Los informes de avance son de entre 2026-10-03 y 2026-10-15. Términos vigentes: versión 0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15.

## Decisiones del comité anterior
No hay registro de un comité anterior en el estado (ni material de comité ni decisiones en las fichas). No se puede cerrar el ciclo; se dice en vez de inventarlo. Cuando este comité sesione, registrar sus decisiones en las fichas deja el ciclo cerrado para el próximo.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de alcance, tiempo y costo, y hasta qué monto?
**Proyecto:** los 13 · **Quién decide:** patrocinador ejecutivo / PMO · **Si no se decide hoy:** las cinco solicitudes de cambio abiertas (puntos 2 a 6) quedan sin un decisor legítimo.
Hechos: el cálculo marca `no_authority` en los 13 proyectos (ninguna ficha dice quién aprueba). Las cinco solicitudes dependen de cuatro comités distintos: Seguridad (PRY-200), Operaciones (PRY-205 y PRY-208), Tecnología (PRY-210) e Inversiones (PRY-211). En PRY-202 y PRY-205 la misma persona figura como patrocinador y como gerente.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Este comité define una tabla de facultades por monto y por días de desplazamiento y la anexa a las actas | Sin efecto directo | Desbloquea los puntos 2 a 6 hoy | Sin efecto directo |
| B. Cada solicitud va a su comité de origen | Sin efecto directo | Cada decisión espera la agenda de su comité; fechas no documentadas | Sin efecto directo |
**Recomendación:** A. Sin una facultad escrita, los puntos 2 a 6 se decidirían sin saber si quien decide puede hacerlo. Es la condición para el resto.

### [2] PRY-205 · ¿Se aprueba CC-01 (ampliación de alcance, +112 días, +224.000.000 COP) o se rechaza?
**Proyecto:** PRY-205 Sistema de gestión de seguridad · **Quién decide:** Comité de Operaciones; facultad no documentada (punto 1) · **Si no se decide hoy:** la línea base ya está desplazada 112 días sin autorización y esa situación sigue vigente.
Hechos: la solicitud (2026-10-11) dice «Pendiente de presentación al comité», pero la línea base ya se movió 112 días (autorizados: 0). Desviación en tiempo contra la original: 112 días, 47.1 %. El informe (2026-10-12) declara amarillo y 72.0 % de avance; el plan sostiene 100 % (5 de 5 hitos cumplidos), con 28.0 puntos de brecha, y 4 hitos cumplidos no tienen evidencia. Fecha fin vigente: 2026-07-13.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 y registrar la nueva línea base con acta | Ampliación | +112 días sobre la vigente | +224.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | El desplazamiento queda como atraso, no como cambio | Sin los 224.000.000 COP |
| C. Diferir hasta que el gerente aporte evidencia de los 4 hitos | Sin cambio | Una semana más con la línea base sin autorización | Sin cambio |
**Recomendación:** C. Aprobar hoy ratificaría un desplazamiento hecho antes de la decisión sobre un avance que los documentos no sostienen. Entre tanto, la línea base vigente consta como no autorizada.

### [3] PRY-208 · ¿Se ratifica CC-01 (ampliación de alcance, +54 días, +108.000.000 COP), marcada como aprobada por «el comité»?
**Proyecto:** PRY-208 Trazabilidad del mineral · **Quién decide:** Comité de Operaciones; facultad no documentada · **Si no se decide hoy:** hay un cambio dado por aprobado sin acta y sin línea base nueva.
Hechos: la solicitud (2026-10-14) dice «Autorizada por el comité», sin nombrar cuál ni citar acta. La línea base no se movió: 54 días aprobados sin línea base nueva.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con acta y registrar la línea base nueva | Ampliación | +54 días | +108.000.000 COP |
| B. Tratarla como no aprobada hasta que aparezca el acta | Sin ampliación | Sin cambio | Sin cambio |
**Recomendación:** A solo si el comité confirma hoy su propia autorización y la deja en acta; si nadie puede confirmarla, B. Una aprobación sin acta no se puede auditar.

### [4] PRY-200 · ¿Se decide CC-01 (ampliación de alcance, +49 días, +98.000.000 COP) antes de aclarar el estado del proyecto?
**Proyecto:** PRY-200 Mantenimiento predictivo de camiones · **Quién decide:** Comité de Seguridad; facultad no documentada · **Si no se decide hoy:** el proyecto, con fecha fin 2026-05-13 ya pasada, sigue sin fecha creíble.
Hechos: el informe (2026-10-13) declara amarillo y 61.0 % contra un plan que sostiene 100 % (5 de 5 hitos); 4 hitos cumplidos sin evidencia. 7 compromisos vencidos, 2 reprogramados 6 y 5 veces, 2 sin fecha. Entregable del proveedor «Licenciamiento del software» pendiente, 311 días tarde; «Calibración de sensores» aceptado sin evidencia; facturado 409709674.0 COP.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliación | +49 días | +98.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | Sin cambio | Sin cambio |
| C. Diferir hasta que el gerente presente un plan de recuperación con evidencia | Sin cambio | Sin cambio | Sin cambio |
**Recomendación:** C. Ampliar alcance sobre un proyecto cuya fecha fin ya pasó y cuyo avance no se sostiene agrega compromiso sin base.

### [5] PRY-211 · ¿Se aprueba CC-01 (ampliación de alcance, +103 días, +206.000.000 COP)?
**Proyecto:** PRY-211 Control de polvo en vías · **Quién decide:** Comité de Inversiones; facultad no documentada · **Si no se decide hoy:** la solicitud (2026-10-14) sigue pendiente; el proyecto no tiene otras señales abiertas.
Hechos: verde, 75.0 % (informe 2026-10-03); proyección 3434195358.0 COP contra 3300000000.0 aprobados (+4.1 %). Fecha fin 2027-09-03. El solicitante, Laura Vélez, es también la gerente.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliación | +103 días | +206.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | Sin cambio | Sin cambio |
**Recomendación:** A, sujeta al punto 1, con la nueva línea base registrada. El proyecto no muestra contradicciones; la solicitud no explica el motivo de la ampliación, así que el comité debería pedirlo antes de votar.

### [6] PRY-210 · ¿Se aprueba CC-01 (ampliación de alcance, +31 días, +62.000.000 COP)?
**Proyecto:** PRY-210 Programa de relacionamiento comunitario · **Quién decide:** Comité de Tecnología; facultad no documentada · **Si no se decide hoy:** la solicitud (2026-10-09) queda pendiente y la fecha fin vigente es 2026-10-31.
Hechos: verde, 69.0 % (informe 2026-10-11); proyección 7049863850.0 COP contra 6800000000.0 (+3.7 %). Sin señales abiertas.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliación | +31 días | +62.000.000 COP |
| B. Rechazar CC-01 | Sin ampliación | Sin cambio | Sin cambio |
**Recomendación:** A, sujeta al punto 1. Es la más cercana a su fecha fin y no hay contradicciones; la solicitud tampoco explica el motivo.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-202 Planta de tratamiento de agua | Proyección 11432506949.0 COP contra 9500000000.0 aprobados: +20.3 %, sobre el umbral de 10 %; el informe dice verde | Informe 2026-10-06 | Que el gerente presente la causa y una propuesta (no hay solicitud de cambio) |
| PRY-204 Monitoreo de taludes | Proyección 910844209.0 COP contra 800000000.0: +13.9 %. Fecha fin 2026-01-16; declara 98.0 % y amarillo | Informe 2026-10-15 | Causa del sobrecosto y fecha real de cierre |
| PRY-200 Mantenimiento predictivo | 7 compromisos vencidos y 2 reprogramados 6 y 5 veces (detalle en el anexo) | Desde 2026-09-20 el más antiguo | Un doliente que destrabe o cancele |
| PRY-209 Electrificación de equipos | Declara 28.0 % y amarillo; el plan sostiene 100 % (4 de 4 hitos, ninguno con evidencia). Fecha fin 2026-01-20 | Informe 2026-10-10 | Evidencia de los 4 hitos o corrección del plan |
| PRY-206 Red privada LTE | Declara 33.0 % y verde; el plan sostiene 100 % (4 de 4 hitos, 3 sin evidencia). Fecha fin 2026-05-26 | Informe 2026-10-11 | Igual que PRY-209 |
| PRY-207 Gemelo digital | Declara rojo y 75.0 %; el plan sostiene 100 % (4 de 4 hitos, 3 sin evidencia). Fecha fin 2026-06-30 | Informe 2026-10-14 | Plan de recuperación; nadie ha dicho qué lo puso en rojo |
| PRY-201 y PRY-203 | Verde con 50.0 % y 41.0 %; el plan sostiene 60-80 % y 50-75 % respectivamente; hitos cumplidos sin evidencia (2 y 1) | Informes 2026-10-15 y 2026-10-10 | Evidencia de los hitos; PRY-203 además tiene un compromiso sin fecha |

## Para conocimiento
- PRY-199: sin señales; verde, 20.0 %, informe 2026-10-13.
- PRY-210 y PRY-211: sin señales fuera de su solicitud de cambio (puntos 6 y 5).
- PRY-208: sin otras señales; verde, 33.0 %.
- Cuatro proyectos declaran verde y los documentos lo contradicen: PRY-201, PRY-202, PRY-203, PRY-206.

## Anexo
**Estado por proyecto** (declarado → cálculo)
| Proyecto | Declarado | Avance declarado | Señales |
|---|---|---|---|
| PRY-199 | verde | 20.0 % | ninguna |
| PRY-200 | amarillo | 61.0 % | 18 alertas: avance, hitos sin evidencia, compromisos, proveedor |
| PRY-201 | verde | 50.0 % | avance, hitos sin evidencia, verde contradicho |
| PRY-202 | verde | 25.0 % | sobrecosto 20.3 %, verde contradicho |
| PRY-203 | verde | 41.0 % | hito sin evidencia, compromiso sin fecha, verde contradicho |
| PRY-204 | amarillo | 98.0 % | sobrecosto 13.9 % |
| PRY-205 | amarillo | 72.0 % | atraso 47.1 %, línea base no autorizada, avance, hitos, compromiso vencido |
| PRY-206 | verde | 33.0 % | avance, hitos sin evidencia, verde contradicho |
| PRY-207 | rojo | 75.0 % | avance, hitos sin evidencia |
| PRY-208 | verde | 33.0 % | cambio aprobado sin línea base |
| PRY-209 | amarillo | 28.0 % | avance, hitos sin evidencia |
| PRY-210 | verde | 69.0 % | ninguna (solicitud pendiente) |
| PRY-211 | verde | 75.0 % | ninguna (solicitud pendiente) |
Totales del cálculo: 13 proyectos, 10 con alertas, 51 alertas.

**PRY-200, compromisos vencidos** (días de vencido): Andrés Lozano, validar el ambiente 4 (18); María Restrepo, confirmar la fecha 7 (25); Beatriz Cuéllar, enviar el documento 9 (25); Javier Hoyos, cerrar la prueba 10 (7); Sandra Gil, revisar el anexo 11 (14); Ricardo Salas, cerrar la prueba 18 (9); Diana Molina, aprobar el diseño 21 (4). Reprogramados: Paula Céspedes, enviar el documento 1 (6 veces; original 2026-09-25, hoy 2026-12-23); Mauricio Pérez, cerrar la prueba 2 (5 veces; original 2026-09-22, hoy 2026-12-02). Sin fecha: Beatriz Cuéllar, actualizar la matriz 6; Laura Vélez, mandar el ajuste del presupuesto «la otra semana».
**PRY-205:** compromiso vencido, Sandra Gil, entregar el punto 8 (8 días).
**PRY-203:** compromiso sin fecha, Óscar Ramírez, entregar el punto 34.

**Vacíos de información**
- `identity.authority` falta en las 13 fichas y `identity.phase` en las que se revisaron (PRY-199, 200, 201).
- En PRY-200 los datos de identidad vienen del acta de 2025-10-07 y superan el umbral de 12 meses de antigüedad.
- PRY-208: no hay acta de comité que sostenga la aprobación de CC-01.
- Ningún proyecto tiene, en este cálculo, un comité anterior contra el cual cerrar decisiones.
- Los riesgos e incidencias de las fichas no tienen doliente ni fecha de movimiento; no se pudo aplicar «dos períodos sin movimiento» ni «doliente fuera del proyecto sin responder».

---
**Pie:** criterio-portfolio 0.3.10 · términos versión 1.1 · fichas PRY-199 a PRY-211, cálculo del 2026-10-15 · campos inciertos: autoridad de aprobación (13 de 13), fase, evidencia de hitos, acta de CC-01 de PRY-208 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10

Después del comité: puedo registrar las decisiones en las fichas, que es lo que cierra el ciclo y arma el material del próximo.
