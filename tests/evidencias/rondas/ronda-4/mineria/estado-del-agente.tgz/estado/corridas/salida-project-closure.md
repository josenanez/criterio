Sale de la ficha `estado/records/PRY-200.json` (instantánea 2026-10-15) y de estos documentos: acta de constitución (2025-10-07), contrato CT-235 (2025-10-01), cronogramas v1 (2025-10-07) y v2 (2026-10-13), actas de recibo, factura FV-1235, solicitud de cambio CC-01, informe de avance (corte 2026-10-13), seis comités semanales (2026-09-03 a 2026-10-08) y las notas del 2026-10-15. Las cifras salen de `portafolio.py compute` (as_of 2026-10-15).

## Cierre — PRY-200 Mantenimiento predictivo de camiones — 2026-10-15

**Lo primero:** este proyecto no ha declarado que terminó. El último informe (2026-10-13) lo reporta en **amarillo, 61%**, tiene una solicitud de cambio de alcance pendiente (CC-01) y compromisos abiertos para noviembre y diciembre. Lo que sigue es el cierre **como se vería hoy**. No es un acta de cierre firmable; si se cerrara ahora, sería por decisión y no por cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** «Mantenimiento predictivo de camiones en producción y medido.» (acta de constitución, 2025-10-07, sección Criterio de éxito.)
**Se cumplió:** **no se puede determinar**. Ningún documento muestra el sistema en producción ni una medición. El informe del 2026-10-13 dice que «el proveedor entregó los equipos en el campamento, pendientes de aceptación», lo que contradice un cronograma con *Montaje e instalación* y *Pruebas en operación* en «cerrado».

El acta tampoco permite contrastar el alcance. Su alcance es «Componente 1, 2, 3» y su fuera de alcance es «Lo que otro proyecto cubre»: son marcadores sin contenido. Dependencias declaradas: «Ninguna».

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Hito: Ingeniería básica aprobada (línea base 2025-11-23) | declarado cerrado | Sin acta ni documento (el script lo marca «cumplido sin evidencia», 326 días) |
| Hito: Ingeniería de detalle aprobada (2025-12-31) | declarado cerrado | Sin evidencia (288 días) |
| Hito: Licencia y permisos obtenidos (2026-02-07) | cerrado | Acta de recibo del 2026-10-04 (`20-seguimiento/2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf`), cerca de ocho meses después de la fecha de línea base |
| Hito: Montaje e instalación (2026-03-17) | declarado cerrado | Sin evidencia (212 días); el informe dice que los equipos están sin aceptar |
| Hito: Pruebas en operación (línea base 2026-04-24, vigente 2026-06-12) | declarado cerrado | Sin evidencia (125 días) |
| CT-235 · Licenciamiento del software (2025-12-08, 204.854.837 COP) | pendiente | Sin acta; 311 días de atraso |
| CT-235 · Bolsa de horas de ingeniería (2026-01-29, 204.854.837 COP) | recibido | Acta 2026-02-15 |
| CT-235 · Calibración de sensores (2026-03-22, 204.854.837 COP) | «aceptado» | **Sin acta de recibo**, aunque el contrato exige acta firmada para facturar |

Facturación: la factura FV-1235 (2026-09-27) es por 409.709.674 COP, radicada en cuentas por pagar. Cubre dos entregables, pero solo uno tiene acta.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| No se puede determinar | — | — |

Hay una ampliación de alcance **pedida y no decidida**: CC-01 (2026-10-11, solicitante Camilo Beltrán), con «+49 días sobre la línea base vigente» y «98.000.000 COP adicionales». Su autorización dice «Pendiente de presentación al comité». Ningún comité de septiembre ni octubre la trata.
Hallazgo: el cronograma v2 (2026-10-13) movió *Pruebas en operación* de 2026-04-24 a 2026-06-12, y no hay solicitud de cambio aprobada que respalde ese movimiento. El script reporta 0 días de cambios aprobados.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-05-13 (acta) | 2026-05-13 | **No hay cierre real**; hoy son 2026-10-15 | El script da 0 días contra el original, y esa cifra solo compara la fecha de fin del acta con la vigente. No refleja que el proyecto sigue abierto cinco meses después |
| Presupuesto (COP) | 2.400.000.000 | 2.400.000.000 | Ejecutado 993.723.690 (41,4 %); comprometido 1.481.500.375 (61,7 %); proyección al cierre 2.474.762.505 | Proyección +3,1 % sobre el aprobado |

Disponible real: 918.499.625 COP. La proyección de 2.474.762.505 viene del informe del gerente y no está sustentada con documentos. Si se aprobara CC-01 (+98.000.000), el script no recalcula una proyección con ese adicional.
Replanificaciones: **1** (cronograma v2). La desviación en días contra la línea base vigente no se calcula porque el script no la entrega (`slip_vs_current_days` es nulo).

### RAID al cierre
**Materializados:**
- Rotación de un ingeniero clave: el equipo perdió dos semanas (informe 2026-10-13). El riesgo de «concentración del conocimiento en una sola persona» sigue abierto en el mismo informe.
- Atraso del hito *Licencia y permisos*: línea base 2026-02-07, acta 2026-10-04.

**No materializados:** no se puede determinar. No hay registro RAID del proyecto.

**Abiertos, con doliente:**
- Siete compromisos vencidos sin evidencia: Andrés Lozano (Validar el ambiente 4, 18 días), María Restrepo (Confirmar la fecha 7, 25 días), Beatriz Cuéllar (Enviar el documento 9, 25 días), Javier Hoyos (Cerrar la prueba 10, 7 días), Sandra Gil (Revisar el anexo 11, 14 días), Ricardo Salas (Cerrar la prueba 18, 9 días), Diana Molina (Aprobar el diseño 21, 4 días).
- Replanificados una y otra vez: Paula Céspedes, «Enviar el documento 1» (original 2026-09-25, seis fechas, la última 2026-12-23); Mauricio Pérez, «Cerrar la prueba 2» (original 2026-09-22, cinco fechas, la última 2026-12-02).
- Sin fecha: Beatriz Cuéllar, «Actualizar la matriz 6»; Laura Vélez, «mandar el ajuste del presupuesto la otra semana» (notas 2026-10-15).
- Óscar Ramírez: revisión con el proveedor, para el 2026-10-25 (notas 2026-10-15).
- Entregables del proveedor: *Licenciamiento* sin recibir y *Calibración* sin acta. **Doliente: no figura.** El contrato nombra al proveedor, y el recibo, al gerente, Camilo Beltrán.
- **Sin doliente:** «el proveedor podría no llegar con el equipo completo para la siguiente fase» se dijo el 2026-10-15 y, según las notas, nadie lo anotó como riesgo. No está cerrado.
- Declaraciones de entrega sin acta: María Restrepo («confirmar la fecha 7», comité 2026-09-17), Carlos Peña («aprobar el diseño 5») y Beatriz Cuéllar («actualizar la matriz 6»), ambos en el comité del 2026-09-24, y Sandra Gil («revisar el anexo 11», 2026-09-24). Ninguna tiene acta.
- CC-01: sin decidir, sin comité que la reciba.

### Lecciones
Solo entran las que se anclan a un hecho documentado.

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El hito *Licencia y permisos* tenía línea base 2026-02-07 y su acta de recibo es del 2026-10-04 | 2026-02-07 a 2026-10-04 | Cerca de ocho meses sin evidencia de recibo, y *Montaje* y *Pruebas* quedaron declarados cerrados sin acta | No dar un hito por cerrado sin acta de recibo, y exigir que el cronograma se actualice con la fecha real |
| *Pruebas en operación* pasó de 2026-04-24 a 2026-06-12 en un cronograma v2 fechado 2026-10-13, sin solicitud de cambio aprobada | Cronograma v2, 2026-10-13 | La línea base vigente se mueve sin decisión de comité, y el atraso queda invisible ante el avance declarado | Que todo movimiento de línea base pase por control de cambios antes de reflejarse en el cronograma |
| El contrato CT-235 condiciona el pago a un acta firmada; la factura FV-1235 (409.709.674 COP) cubre dos entregables y solo uno tiene acta | 2026-09-27 | Pago en trámite sobre un entregable sin soporte | Validar el acta contra la factura antes de radicarla |
| «Enviar el documento 1» se reprogramó seis veces y «Cerrar la prueba 2», cinco, entre el 2026-09-03 y el 2026-10-15 | Comités de septiembre y octubre | Compromisos que se corren cada semana sin un cambio de plan explícito | Escalar al segundo reagendamiento |
| Cuatro personas dijeron «ya entregué» sin presentar acta (comités 2026-09-17 y 2026-09-24) | Septiembre 2026 | Compromisos que el comité no puede cerrar | No cerrar compromisos de palabra |

### Sin dato
- Si el sistema está en producción y medido (criterio de éxito): no hay ningún documento.
- Cualquier evidencia de los cuatro hitos declarados cerrados sin acta.
- Alcance real contratado y excluido: el acta tiene marcadores sin contenido.
- Quién autorizó la replanificación de *Pruebas en operación*, y por qué.
- Desviación en días contra la línea base vigente, ya que el script no la entrega.
- Presupuesto final: no hay cierre financiero; la proyección es del gerente.
- Lecciones sobre la rotación del ingeniero clave: el informe no da fechas ni efecto.
- Doliente de los riesgos y de los entregables del proveedor pendientes.

**Siguiente paso:** no muevo la carpeta a `archivo/` ni congelo la ficha, porque el proyecto no ha declarado terminado y tiene trabajo y un cambio abiertos. Eso lo decide el patrocinador, Rubén Cárdenas, o el comité. Cuando lo haga, en el siguiente cierre habría que resolver primero CC-01 y las actas faltantes.

*Rigor: esto es un borrador de trabajo hecho solo con los documentos de la carpeta. No sabe lo que se habló fuera de ellos. Cada dato lleva su fuente y la verificación es de quien lo lea.*
