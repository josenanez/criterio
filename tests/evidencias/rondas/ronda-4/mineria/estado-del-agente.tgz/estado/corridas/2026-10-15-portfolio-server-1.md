# Corrida del 2026-10-15 · portfolio-server

13 proyectos · 51 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 21 |
| `commitment_overdue` | 8 |
| `progress_vs_plan` | 6 |
| `declared_vs_evidence` | 4 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `variance_cost` | 2 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `variance_time` | 1 |
| `rebaseline_unauthorized` | 1 |
| `change_without_baseline` | 1 |

puerto 8787, informe en reportes/, modo rato

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato (Minería)

**Términos:** vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Comprobante en `.criterio/terminos/`.

**Modo:** «para mirarlo un rato» (respuesta sugerida, sin interfaz para preguntar). Se levanta, se mira, se apaga con Ctrl-C. No hay enlace estable para mañana.

**Qué se sirve:** el informe ya generado en `reportes/` (index, decisiones, proyectos PRY-199 a PRY-211, productos). Estado en `estado/`. Escucha solo en `127.0.0.1:8787`, solo en este equipo.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio | La PMO |
| `/decisiones` | Lo que necesita una decisión | Comité y patrocinador |
| `/proyectos` | Listado por atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlaza a su producto | Quien gerencia |
| `/productos` y `/producto/<nombre>` | Productos y los proyectos que los construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

**Lo que no hace:** no calcula (sirve lo que `informe.py` escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica, no manda correos.

**Cierre:** en este modo el enlace `http://127.0.0.1:8787/` sirve solo a quien está en esta máquina. Para el patrocinador hace falta el modo «que quede corriendo» (`--abierto`, host y puerto dentro de la red, detrás del control de acceso de la organización). El informe vale hasta su fecha de generación, que la portada muestra.
