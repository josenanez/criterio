## 2026-10-15

**Revisé:** 73 documentos · 23 figuran como nuevos (todos de PRY-200) · 0 proyectos recalculados

Tocaban dos cosas: el barrido diario y la confirmación mensual (primera corrida, sin registro previo).

### Barrido
- Los 23 documentos «nuevos» de PRY-200 no son nuevos. La ficha `records/PRY-200.json` ya se escribió hoy a las 20:58 con esos documentos, y ninguno es posterior a ella. Quedó con `meta.documents_seen` vacío, así que el índice los trata como no vistos y marca 250 citas como «source_missing».
- `projects_to_recompute` vino en cero. Corrí `portfolio-scan` sobre PRY-200 y `sellar` rechazó el sello: la ficha no se escribió en esta corrida, y sellarla la daría por leída sin haberla leído. No releí los 23 documentos ni reescribí una ficha de 84 KB para obtener el sello, porque no cambió nada.
- **Queda pendiente:** la próxima vez que se reescriba la ficha de PRY-200 hay que sellarla. Mientras tanto, cada barrido va a repetir este mismo aviso.
- Ningún umbral cruzado: no recalculé nada.

### Preguntas (confirmación, 5 campos, elegidos por antigüedad del patrocinador, la más vieja de las fichas)
Sin interfaz no hay a quién preguntar. Quedan preguntadas hoy, sin respuesta; no se repiten hasta que alguien conteste.
1. PRY-204 — ¿Gustavo Neira sigue siendo patrocinador? (acta de 2025-05-14, más de 17 meses)
2. PRY-209 — ¿Mauricio Pérez sigue siendo patrocinador? (2025-06-24)
3. PRY-205 — ¿Javier Hoyos sigue siendo patrocinador (y gerente)? (2025-07-18)
4. PRY-210 — ¿Laura Vélez sigue siendo patrocinadora? (2025-07-31)
5. PRY-200 — ¿Rubén Cárdenas sigue siendo patrocinador? (acta de constitución, 2025-10-07)

Los cinco superan el umbral de 12 meses (`stale_field_months`). Los demás campos de importancia (presupuesto aprobado, fecha de cierre) no los revisé en esta corrida.

**Vuelvo el 2026-10-16.**
