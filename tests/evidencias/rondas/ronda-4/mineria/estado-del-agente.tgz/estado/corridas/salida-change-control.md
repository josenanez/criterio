Parto de la ficha `estado/records/PRY-201.json` (Ampliación de la relavera, gerente Sandra Gil, corte 2026-10-15). Términos vigentes: v1.1, aceptados por José Francisco Ñáñez el 2026-10-15 (comprobante ya registrado).

## Solicitud de cambio — PRY-201 Ampliación de la relavera — 2026-10-15

**Qué se pide:** mover la salida a producción 30 días. Lo leo como mover el hito «Pruebas en operación» (2026-12-01), que en el cronograma coincide con el cierre. Si «salida a producción» es otra cosa, hay que decirlo.
**Quién lo pide:** no consta en ningún documento de la carpeta.
**Por qué:** no consta. Lo único cercano es el informe de avance del 2026-10-15: equipos entregados en el campamento «pendientes de aceptación» y riesgo abierto «ventana de parada de planta definida por operaciones». Nadie lo vincula con este cambio, así que es una pista y no un motivo.

### Línea base vigente
- Hay una sola línea base: v1, aprobada el 2026-05-12 por el Comité de Inversiones, cierre 2026-12-01 (`10-plan/2026-05-12-cronograma-v1.xlsx`). Replanificaciones: 0. Cambios registrados: ninguno.
- **Conflicto sin resolver:** el acta de constitución dice cierre **2026-12-21**. El cronograma v1, aprobado el mismo día, dice **2026-12-01**. La ficha tomó el 12-01 y no registró el conflicto. La diferencia es de 20 días y la decide quien tenga el documento original. Con 12-21 como base, el cierre nuevo sería 2027-01-20 y no 2026-12-31.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta) | No declarado | Sin cambio declarado |
| Tiempo | Pruebas en operación / cierre 2026-12-01 (cronograma) | 2026-12-31 | +30 días (+20 días sobre el 12-01 si la base es el acta) |
| Costo | Aprobado 2.400.000.000 COP; comprometido 1.547.913.183 (64,5 %); ejecutado 1.211.173.631 (50,5 %); proyección 2.291.759.454 | No declarado | Sin estimar |

**Quién absorbe lo que no se declaró.** Nadie dijo que el alcance quede igual ni que el costo no suba, y 30 días más de obra no son gratis: gerencia, supervisión y alquiler de equipos corren más tiempo. La holgura contra el aprobado es de 108.240.546 COP (4,5 %). Si el costo extra no cabe ahí, lo absorbe el presupuesto aprobado o la calidad. Esta ficha no tiene el costo mensual de mantener el proyecto, así que **no estimo el costo del cambio**. Lo tiene que aportar Sandra Gil.

**Estado declarado y evidencia.** El informe dice «Verde» y 50 % de avance. Un proyecto en verde que pide 30 días no es coherente, y la ficha no tiene la fecha en que se supo. El hito «Montaje e instalación» (2026-10-23) vence en 8 días con los equipos aún sin aceptar. El cambio puede ser un atraso ya existente que se está regularizando.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno alcanzado por dependencias declaradas | `impact`: 0 alcanzados (directos 0, indirectos 0), 0 que no sostienen su fecha, 0 dependencias sin confirmar | — |

Pasa por los hitos «Montaje e instalación» (2026-10-23, a 8 días) y «Pruebas en operación» (2026-12-01, a 47 días).

**Lo que este resultado no dice.** El acta declara «Ninguna declarada» como dependencia, y ninguna otra ficha apunta a PRY-201. Eso significa que **no hay dependencias registradas**. No prueba que no existan. Una relavera suele depender de operaciones (la ventana de parada es un riesgo abierto) y de compras. Cuántos días se mueve cada hito intermedio necesita holgura por actividad, y la ficha no la tiene.

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo `authority` de la ficha está sin encontrar: el acta no declara umbrales de autoridad para cambios de tiempo.
**Según:** acta 2026-05-12, sin cláusula de autoridad. El presupuesto y la línea base los aprobó el Comité de Inversiones.
**Va a comité:** sí, por defecto. La línea base original la aprobó el Comité de Inversiones y ningún documento da a la gerente ni al patrocinador (María Restrepo) facultad para moverla. Que no haya autoridad declarada es el hallazgo de fondo.

### Si no se aprueba
Sigue vigente la línea base v1, con cierre 2026-12-01 (o 2026-12-21 según el acta). El proyecto reporta verde con 50 % de avance, equipos sin aceptar y un montaje que vence el 2026-10-23. Si el atraso es real, saldrá como desviación contra la línea base sin cambio aprobado. Eso es peor que un cambio aprobado a tiempo.

### Si se aprueba
Línea base 2 — cierre 2026-12-31 (2027-01-20 si la base es el acta) · presupuesto: sin cambio declarado (2.400.000.000 COP vigente; proyección 2.291.759.454) · motivo: **sin documentar**. Hace falta el motivo escrito, el documento que lo aprueba y la fecha.
Desviación acumulada contra la línea base original: **+30 días** en tiempo, y en costo la proyección actual está 4,5 % bajo el aprobado, sin el efecto del cambio. Replanificaciones: 0 → 1.
La línea base v1 no se toca.

### Faltan antes de decidir
1. Resolver 2026-12-01 vs 2026-12-21 en el cierre.
2. Quién pide el cambio y por qué, por escrito.
3. Costo del cambio, a cargo de la gerente.
4. Qué depende de esta relavera y no está registrado, empezando por operaciones.
5. Qué autoridad tiene cada nivel para mover fechas.

## Después
El cambio excede lo que se puede decidir con lo que hay. Puedo llevarlo a comité con `/steering-pack`. No registro línea base nueva: nadie con autoridad la ha aprobado.
