Soy Samuel. Leo lo que pasa en tu proyecto y me acuerdo de lo que se prometió en cada reunión.

*(Sesión de prueba sin interfaz: las cuatro preguntas se contestaron con la propuesta por defecto, dicha en una línea cada una.)*

1. **Quién eres y qué proyecto es:** Camilo Beltrán, gerente de PRY-200 · Mantenimiento predictivo de camiones, patrocinador Rubén Cárdenas, Comité de Seguridad (acta de constitución del 2025-10-07).
2. **Reunión de seguimiento:** los jueves, semanal (las seis minutas son de jueves). Las notas del 2026-10-15 dicen «próxima reunión en dos semanas»; dejé la cadencia semanal con próxima fecha 2026-10-29.
3. **Dónde guardo lo que encuentro:** `estado/PRY-200-mantenimiento-predictivo-de-camiones`, junto a la carpeta de documentos y fuera de ella.
4. **Términos:** texto mostrado tal cual:

> Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256. Términos completos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Aceptación dada en el argumento de la prueba por José Francisco Ñáñez, fecha 2026-10-15; la registré con ese nombre.

## Listo — PRY-200 · Mantenimiento predictivo de camiones

**Lo que miré:** 22 documentos · 6 minutas de comité (2026-09-03 al 2026-10-08, las leí todas, de la más vieja a la más nueva) más las notas de reunión del 2026-10-15 · la última, del 2026-10-15. Formatos: .md, .csv, .xlsx, .docx, .pdf y .txt; no quedó ninguno sin leer.
**Términos:** aceptados para la versión 0.3.10 · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 del comprobante .md: 5c505a87302a3766…

Leí 26 compromisos distintos en total; 9 siguen con fecha futura sin problema aparente, 6 se cerraron con acta de recibo, y el resto está en las listas de abajo.

### Lo que está abierto, y cuántas veces se ha movido

Vencidos sin evidencia (el script los marcó `commitment_overdue`, con los días contados al 2026-10-15):

| Quién | Qué | Para cuándo | Días | Cita |
|---|---|---|---|---|
| María Restrepo | Confirmar la fecha 7 | 2026-09-20 | 25 | minuta 2026-09-10; el 09-17 dijo que ya lo entregó, no se presentó acta |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 | 25 | minuta 2026-09-17; sigue igual en las listas del 09-24, 10-01 y 10-08 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 | 18 | minuta 2026-09-03 (original 2026-09-13, movido una vez el 09-10) |
| Sandra Gil | Revisar el anexo 11 | 2026-10-01 | 14 | minuta 2026-09-17; el 09-24 dijo que ya lo entregó, no se presentó acta |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-06 | 9 | minuta 2026-10-01 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-08 | 7 | minuta 2026-09-17 (original 2026-09-21, movido el 10-01) |
| Diana Molina | Aprobar el diseño 21 | 2026-10-11 | 4 | minuta 2026-10-08 |

**Los que se reprogramaron**, el hallazgo que ninguna minuta sola da:

| Quién | Qué | Original | Veces | Fecha vigente |
|---|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-09-25 | **6** | 2026-12-23 (10-12 → 10-28 → 11-14 → 11-23 → 12-09 → 12-23) |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-09-22 | **5** | 2026-12-02 (10-05 → 10-20 → 10-27 → 11-17 → 12-02) |

Son dos compromisos con historial, no once vencidos: cada semana se movió la fecha y cada vez unas dos o tres semanas hacia adelante. Mauricio Pérez además no apareció en las notas del 10-15, así que su fecha del 2026-12-02 no se reconfirmó.

**Cerrados con acta de recibo (6):** Entregar el punto 8 (Camilo Beltrán, acta 2026-09-17), Revisar el anexo 3 (Mauricio Pérez, 2026-10-01), Validar el ambiente 12 (Carlos Peña, 2026-10-01), Actualizar la matriz 14 (Mauricio Pérez, 2026-10-01), Enviar el documento 17 (Diana Molina, 2026-10-08) y Revisar el anexo 19 (Óscar Ramírez, 2026-10-08).

**Dichos como entregados, sin acta, y no dados por cumplidos:** «Aprobar el diseño 5» (Carlos Peña, dicho el 09-24), «Actualizar la matriz 6» (Beatriz Cuéllar, 09-24), «Confirmar la fecha 7» y «Revisar el anexo 11» (arriba). Desaparecieron de las listas, pero ningún acta los prueba.

**Con fecha futura y sin problema aparente:** Aprobar el diseño 5 (2026-10-23), Aprobar el diseño 13 (Carlos Peña, 2026-11-03; empezó sin fecha y se fechó dos veces), Confirmar la fecha 15 (Felipe Arango, 2026-11-07, movido una vez), Entregar el punto 16 (Felipe Arango, 2026-11-04, movido una vez desde 2026-10-14), Validar el ambiente 20 (Ricardo Salas, 2026-10-19), Actualizar la matriz 22 (Javier Hoyos, 2026-11-03), Confirmar la fecha 23 (Natalia Ospina, 2026-11-04), Entregar el punto 24 (Carlos Peña, 2026-10-20) y Revisión con el proveedor (Óscar Ramírez, 2026-10-25, notas 10-15).

### Sin fecha
Nadie los fechó; no pueden estar vencidos, y por eso son los que desaparecen de los informes:
- **Beatriz Cuéllar — Actualizar la matriz 6:** «por definir» el 09-10 y el 09-17; después dijo que ya lo entregó, sin acta.
- **Laura Vélez — Mandar el ajuste del presupuesto:** «la otra semana» (notas 2026-10-15). No puse una fecha calculada.

### Otras señales que levantó el cálculo
- **Declarado contra plan:** el informe del 2026-10-13 declara **amarillo y 61%**; el cronograma v2 (2026-10-13) declara los 5 hitos cerrados. La diferencia es de 39.0 puntos (`progress_vs_plan`). Las dos cosas no pueden ser ciertas a la vez, y esa diferencia es tuya de explicar.
- **Hitos declarados cerrados sin acta:** 4 de 5 (`milestone_met_without_evidence`): Ingeniería básica aprobada (2025-11-23), Ingeniería de detalle aprobada (2025-12-31), Montaje e instalación (2026-03-17) y Pruebas en operación (vigente 2026-06-12; línea base 2026-04-24). Solo «Licencia y permisos obtenidos» tiene acta (PDF del 2026-10-04).
- **Proveedor CT-235 (Servicios Ambientales del Norte):** «Licenciamiento del software» sigue pendiente, 311 días después de su fecha (2025-12-08); «Calibración de sensores» figura recibido en el contrato pero sin acta de recibo (`vendor_accepted_without_evidence`). Solo la Bolsa de horas tiene acta (2026-02-15). La factura FV-1235 (2026-09-27) es por 409.709.674 COP, igual a lo que el contrato da por aceptado (dos entregables); el script no levantó facturación por encima de lo aceptado.
- **Presupuesto (informe 2026-10-13):** aprobado 2.400.000.000 COP, comprometido 1.481.500.375 (61.7%), ejecutado 993.723.690 (41.4%), proyección al cierre 2.474.762.505, es decir 3.1% sobre lo aprobado.
- **Fecha de cierre:** el acta de constitución fijó 2026-05-13 y no hay otra fecha de cierre en ningún documento; ya pasó. Hay 0 replanificaciones registradas de la línea base.
- **Solicitud de cambio CC-01** (2026-10-11): ampliación de alcance, +49 días y 98.000.000 COP, «pendiente de presentación al comité». No hay decisión.
- **Un riesgo que nadie anotó:** las notas del 2026-10-15 dicen que el proveedor podría no llegar con el equipo completo para la siguiente fase. El informe solo registra «concentración del conocimiento en una sola persona».

### Qué le falta a tu carpeta
- Actas de recibo de los 4 hitos cerrados (ingeniería básica, ingeniería de detalle, montaje, pruebas en operación) y de «Calibración de sensores»: sin ellas lo cumplido se ve igual que lo incumplido.
- Actas de recibo, o la fecha, de los 7 compromisos vencidos.
- Un cronograma que mueva la fecha de cierre, o el acta que la ratifique: el cierre sigue en 2026-05-13.
- La facultad del gerente (hasta qué monto y qué cambio de alcance decide sin comité) no aparece en el acta de constitución; sin ella CC-01 no se puede medir contra la autoridad.
- Minutas anteriores al 2026-09-03: la primera que tengo es de esa fecha, y Paula y Mauricio ya llevaban compromisos abiertos desde antes de lo que muestro.
- La fase del proyecto no aparece en ningún documento.

**Cuándo vuelvo:** semanal, los jueves. Las notas del 10-15 dicen «en dos semanas»; la próxima fecha quedó en 2026-10-29, y el informe se prepara dos días antes.

*Lo que dejé escrito:* configuración en `.criterio/proyecto/PRY-200/config.json` y ficha en `estado/PRY-200-mantenimiento-predictivo-de-camiones/records/PRY-200.json`. No la sellé: leí las minutas, no el proyecto entero.
