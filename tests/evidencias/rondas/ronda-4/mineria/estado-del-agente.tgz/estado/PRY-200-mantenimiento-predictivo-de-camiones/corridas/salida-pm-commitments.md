## Compromisos — Mantenimiento predictivo de camiones (PRY-200) · al 2026-10-15

Cifras de `portafolio.py compute`: 7 vencidos sin evidencia, 2 sin fecha, 2 reprogramados 3 veces o más.

### Se viene reprogramando

> **Paula Céspedes** · Enviar el documento 1
> Prometido para el 2026-09-25, y antes para el 10-12, el 10-28, el 11-14, el 11-23, el 12-09 y ahora el 12-23.
> **Seis reprogramaciones en seis semanas seguidas. Cada comité le puso una fecha nueva. Eso no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**
> Fuentes: 30-reuniones/2026-09-03 (origen), 09-10, 09-17, 09-24, 10-01, 10-08 y 2026-10-15-notas-reunion.txt (última).

> **Mauricio Pérez** · Cerrar la prueba 2
> Prometido para el 2026-09-22, y antes para el 10-05, el 10-20, el 10-27, el 11-17 y ahora el 12-02.
> **Cinco reprogramaciones; la fecha vigente se corrió dos semanas más el 10-08.** No se mencionó en las notas del 2026-10-15: nadie lo trató ayer.
> Fuentes: 30-reuniones/2026-09-03 (origen), 09-10, 09-17, 09-24, 10-01 y 10-08 (última).

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| María Restrepo | Confirmar la fecha 7 | 2026-09-20 | 25 días |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 | 25 días |
| Andrés Lozano | Validar el ambiente 4 (antes 09-13; reprogramado una vez) | 2026-09-27 | 18 días |
| Sandra Gil | Revisar el anexo 11 | 2026-10-01 | 14 días |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-06 | 9 días |
| Javier Hoyos | Cerrar la prueba 10 (antes 09-21; reprogramado una vez) | 2026-10-08 | 7 días |
| Diana Molina | Aprobar el diseño 21 (no se mencionó en las notas del 10-15) | 2026-10-11 | 4 días |

Dicen que ya entregaron, y no hay nada en el expediente que lo respalde (ningún acta de recibo): María Restrepo (lo dijo el 09-17), Sandra Gil (el 09-24) y, fuera de esta tabla, Beatriz Cuéllar con la matriz 6 (el 09-24) y Carlos Peña con el diseño 5 (el 09-24; su fecha vigente es el 10-23, así que aún no vence). Siguen abiertos.

### Vencen esta semana (hasta el 2026-10-22)
| Quién | Qué | Para cuándo |
|---|---|---|
| Ricardo Salas | Validar el ambiente 20 (empezó sin fecha; se le puso el 10-08) | 2026-10-19 |
| Carlos Peña | Entregar el punto 24 | 2026-10-20 |

Justo después: Carlos Peña · Aprobar el diseño 5, el 2026-10-23 (ya reprogramado una vez, desde el 10-03).

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Beatriz Cuéllar | Actualizar la matriz 6 | 2026-09-10 |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»; nadie dijo una fecha) | 2026-10-15 |

No pueden estar vencidos y por eso se cuentan aparte. El de Beatriz lleva 35 días sin fecha y ella misma dice que ya lo entregó.

### Cerrados con documento
- Mauricio Pérez · Revisar el anexo 3 — acta de recibo 3 (2026-10-01). Estuvo abierto con 09-22 en las minutas del 09-10, 09-17 y 09-24.
- Camilo Beltrán · Entregar el punto 8 — acta de recibo 8 (2026-09-17).
- Carlos Peña · Validar el ambiente 12 — acta de recibo 12 (2026-10-01).
- Mauricio Pérez · Actualizar la matriz 14 — acta de recibo 14 (2026-10-01).
- Diana Molina · Enviar el documento 17 — acta de recibo 17 (2026-10-08).
- Óscar Ramírez · Revisar el anexo 19 — acta de recibo 19 (2026-10-08).

### Nota aparte
Un compromiso nuevo de Óscar Ramírez, «Revisión con el proveedor» (2026-10-25), es distinto del anexo 19 ya cerrado; está abierto y no vence aún.

### Lo que sigue
- Paula Céspedes (6 veces) y Mauricio Pérez (5) pasan el umbral de 3 reprogramaciones. Puedo formularlos como decisión para el comité (próximo: 2026-10-29): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad del gerente y por eso sube.
- Si quieres que la PMO vea esto en la ficha, `/pm-publish`.
