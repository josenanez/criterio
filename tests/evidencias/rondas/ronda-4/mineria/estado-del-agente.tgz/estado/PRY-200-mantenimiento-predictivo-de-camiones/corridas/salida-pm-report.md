# Mantenimiento predictivo de camiones (PRY-200) — semana del 2026-10-09 al 2026-10-15

**Declara el gerente:** *[en blanco: la sesión no tuvo a nadie que declarara esta semana]*
**Última declaración en documento (no es la de esta semana):** amarillo · 61 % · al 2026-10-13, de `20-seguimiento/2026-10-13-informe-avance.md` (2 días de antigüedad, vigente para el umbral de 30 días).
**Sustento documental:** sin sustento. Hay 0 fuentes de evidencia, 3 de declaración y 247 sin marcar.
**Lo que el semáforo no explica:** el amarillo del 13-oct no explica cinco señales: avance contra plan, hitos cumplidos sin evidencia, compromisos vencidos, compromisos reprogramados y entregable de proveedor vencido.

> Una declaración vacía es incómoda a propósito. Camilo Beltrán, gerente, declara estado y avance. Este informe no lo propone.

## Qué cambió esta semana
No hay corrida anterior con la que comparar: la de hoy es la primera foto del estado (`snapshots/2026-10-15.json`), así que el diff da 0 cambios. **Eso no significa que nada cambió.** Significa que no hay semana pasada contra la cual medirlo. Desde la próxima corrida este apartado se llena.

Lo nuevo en los documentos de los últimos días:
| Qué | Estaba | Está |
|---|---|---|
| Solicitud de cambio CC-01 (2026-10-11): ampliación de alcance, +49 días sobre la línea base vigente, +98.000.000 COP | no existía | **pendiente de decisión**, sin decisor registrado |
| Cronograma v2 (2026-10-13) | v1 | los 5 hitos figuran «cumplidos» |
| Notas de reunión de hoy | n/a | Laura Vélez, «mandar el ajuste del presupuesto», sin fecha. Riesgo dicho en reunión y sin registrar: el proveedor podría no llegar con el equipo completo para la siguiente fase |

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Licenciamiento del software (Servicios Ambientales del Norte, CT-235) pendiente | 2025-12-08 | 311 |
| Hito «Ingeniería básica aprobada» cumplido sin evidencia | 2025-11-23 | 326 |
| Hito «Ingeniería de detalle aprobada» cumplido sin evidencia | 2025-12-31 | 288 |
| Hito «Montaje e instalación» cumplido sin evidencia | 2026-03-17 | 212 |
| Hito «Pruebas en operación» cumplido sin evidencia | 2026-06-12 | 125 |
| Cierre planificado del proyecto (2026-05-13) pasado, con avance declarado de 61 % | 2026-05-13 | 155 |
| Compromiso de María Restrepo, «Confirmar la fecha 7» | 2026-09-20 | 25 |
| Compromiso de Beatriz Cuéllar, «Enviar el documento 9» | 2026-09-20 | 25 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-05-13 | 2026-05-13 | 0 días contra ambas |
| Hito «Pruebas en operación» | 2026-04-24 | 2026-06-12 | **+49 días** |
| Presupuesto (aprobado) | 2.400.000.000 COP | 2.400.000.000 COP | 0 %. Proyección 2.474.762.505 COP, **+3,1 %** (74.762.505 COP) |

Replanificaciones registradas: **0**. Hay una sola versión de línea base (v1, acta de constitución, 2025-10-07).

**Incoherencia que el informe no resuelve:** el cronograma v2 mueve «Pruebas en operación» 49 días, hasta 2026-06-12. Ese hito queda después de la fecha de cierre del proyecto (2026-05-13), y no hay línea base nueva ni cambio aprobado que lo respalde. La desviación de cierre «0 días» es la de una línea base que ya no cuadra con el cronograma. Además el avance declarado es 61 % con 5 de 5 hitos «cumplidos», y el plan sostiene 100 %: **brecha de 39 puntos**.

### Hitos de las próximas cuatro semanas
No hay ninguno. Los 5 hitos figuran como cumplidos, 4 de ellos sin evidencia. «Licencia y permisos obtenidos» sí tiene evidencia (`2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf`).

## Las cifras (COP, al 2026-10-13)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 2.400.000.000 | 1.481.500.375 (61,7 %) | 993.723.690 (41,4 %) | 2.474.762.505 | **918.499.625** (aprobado menos comprometido) |

El CC-01 pide 98.000.000 COP adicionales. Si se aprobara, la proyección pasaría a unos 2.572.762.505 COP, **7,2 %** por encima de lo aprobado y por debajo del umbral de 10 %, pero fuera de lo aprobado.

## Abierto
**Reprogramados (primero):**
- Paula Céspedes, «Enviar el documento 1»: **6 veces**. Original 2026-09-25, hoy 2026-12-23.
- Mauricio Pérez, «Cerrar la prueba 2»: **5 veces**. Original 2026-09-22, hoy 2026-12-02.

**Vencidos sin evidencia:**
- María Restrepo, «Confirmar la fecha 7»: venció 2026-09-20 (25 días).
- Beatriz Cuéllar, «Enviar el documento 9»: venció 2026-09-20 (25 días).
- Andrés Lozano, «Validar el ambiente 4»: venció 2026-09-27 (18 días).
- Sandra Gil, «Revisar el anexo 11»: venció 2026-10-01 (14 días).
- Ricardo Salas, «Cerrar la prueba 18»: venció 2026-10-06 (9 días).
- Javier Hoyos, «Cerrar la prueba 10»: venció 2026-10-08 (7 días).
- Diana Molina, «Aprobar el diseño 21»: venció 2026-10-11 (4 días).

**Sin fecha:** Beatriz Cuéllar, «Actualizar la matriz 6»; Laura Vélez, «Mandar el ajuste del presupuesto».

**RAID sin movimiento:** el riesgo registrado «Concentración del conocimiento en una sola persona» no tiene dueño. El riesgo del proveedor está dicho en reunión y sin registrar. La incidencia «el equipo perdió dos semanas por rotación de un ingeniero clave» no tiene fecha de cierre. El script no calculó días sin movimiento para el RAID.

**Proveedor (Servicios Ambientales del Norte, CT-235):** 3 entregables, 2 aceptados.
- Vencido: «Licenciamiento del software», pendiente desde 2025-12-08 (311 días).
- Aceptado sin documento: «Calibración de sensores».
- Facturado 409.709.674 COP, igual al monto de los aceptados. Hay un entregable aceptado sin evidencia de recibo, así que parte de esa factura no tiene respaldo.

## Lo que necesito de alguien
- **Camilo Beltrán:** declarar estado y avance de esta semana. El del 13-oct no cubre cinco señales.
- **Camilo Beltrán / Comité de Seguridad (Rubén Cárdenas, patrocinador):** decidir el CC-01 (+49 días, +98 M COP, ampliación de alcance) y quién lo decide. **Excede la autoridad del gerente: es material de comité**, siguiente el 2026-10-29.
- **Camilo Beltrán:** aclarar la línea base. Hito de pruebas en 2026-06-12, cierre en 2026-05-13, cero replanificaciones.
- **Paula Céspedes y Mauricio Pérez:** dar una fecha que se sostenga, o decir que no la tienen.
- **Beatriz Cuéllar, María Restrepo:** documento 9 y fecha 7, vencidos hace 25 días.
- **Laura Vélez:** fecha para el ajuste del presupuesto.
- **Quien administre el contrato CT-235:** acta de recibo de la «Calibración de sensores» y fecha del licenciamiento.
- **Quien tenga las actas de recibo:** evidencia de los hitos de ingeniería básica, ingeniería de detalle, montaje y pruebas.

## Lo que no se sabe
**Sin dato:** autoridad y fase del proyecto; evidencia de 4 de los 5 hitos y de 2 de los 3 entregables del proveedor; quién decidió el CC-01. El script no calculó dueño ni antigüedad del RAID.
**Antigüedad:** 30 campos de la ficha vienen del acta de constitución (2025-10-07) o del contrato (2025-10-01), con 12 meses de antigüedad. No se han releído contra una fuente más reciente.
**Silencio:** último documento hace 0 días (notas de reunión del 2026-10-15) · última reunión de comité hace 7 días (2026-10-08). `days_silent` salió sin valor en el cálculo; las fechas salen de los archivos de la carpeta.

---
*Ficha: `estado/PRY-200-mantenimiento-predictivo-de-camiones/records/PRY-200.json`, con corte al 2026-10-15 y datos de documentos hasta el 2026-10-13. 9 campos sin dato. Es un borrador de trabajo; cada dato tiene su cita en la ficha y la verificación es del gerente. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10*
