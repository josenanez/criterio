## Reunión de seguimiento — Mantenimiento predictivo de camiones (PRY-200) · 2026-10-29
14 puntos · 36 minutos · 11 personas requeridas (Camilo Beltrán, Paula Céspedes, Mauricio Pérez, Beatriz Cuéllar, Andrés Lozano, Ricardo Salas, Javier Hoyos, Diana Molina, Carlos Peña, Óscar Ramírez, Laura Vélez)

**Antes de leerla, tres cosas que no sé.**
- **La fecha.** Uso el 2026-10-29: es `committee_next` en la configuración y es lo que dicen las notas del 10-15 («próxima reunión en dos semanas»). Pero la configuración dice comité **semanal** y hoy es jueves 10-15, así que el jueves 10-22 también caería. Si en realidad hay reunión el 10-22, los puntos de «Vence antes de la próxima» ya no son preventivos para esa fecha (Ricardo y Carlos vencen el 10-19 y el 10-20).
- **El tiempo.** La configuración no trae duración y no pediste un tope. Los 36 minutos son la suma de lo que cada punto necesita, no un límite. Si la reunión es más corta, se corta por el final: con 20 minutos quedan los puntos 1 a 4 y el resto se pide por escrito.
- **Quién va.** Asumo la asistencia del 10-15 (13 personas). No hay convocatoria en el expediente.

### Lo que no se destraba solo

> **[1] Que Paula diga qué le falta para enviar el documento 1 y quién lo tiene** · 8 min · **Paula Céspedes** (con Camilo Beltrán)
> Prometido para el 2026-09-25, y antes para el 10-12, el 10-28, el 11-14, el 11-23, el 12-09 y ahora el 12-23. Seis reprogramaciones en seis reuniones seguidas; la fecha vigente quedó a 69 días.
> Fuente: 30-reuniones/2026-09-03 (origen), 09-10, 09-17, 09-24, 10-01, 10-08 y 2026-10-15-notas-reunion.txt (última).
> **Si no se resuelve hoy:** se anota una séptima fecha. En el expediente no consta qué es el «documento 1» ni qué depende de él, así que no puedo decir qué se atrasa; eso lo tiene que decir ella.
> **Qué tiene que quedar resuelto:** la causa nombrada, o la decisión de subirlo (`/pm-escalate`) si lo que falta excede lo que alguien en la sala puede mover.

> **[2] Que Mauricio diga si el 12-02 es real o qué se lo impide** · 6 min · **Mauricio Pérez**
> Cerrar la prueba 2: prometido para el 2026-09-22, y antes para el 10-05, el 10-20, el 10-27, el 11-17 y ahora el 12-02. Cinco reprogramaciones; la última se corrió dos semanas el 10-08. **No se mencionó en las notas del 10-15: nadie lo trató.**
> Fuente: 30-reuniones/2026-09-03 (origen), 09-10, 09-17, 09-24, 10-01 y 10-08 (última).
> **Si no se resuelve hoy:** se repite el patrón de las últimas cinco reuniones. Ojo: sí cierra cuando hay papel (anexo 3 y matriz 14, con acta de recibo el 10-01), así que la pregunta es qué tiene esta prueba de distinto.

### Vencido sin evidencia
Más viejo primero. En los cinco, la persona va a estar. Lo que se pide es lo mismo: el acta de recibo, o una fecha nueva con su causa.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Beatriz Cuéllar | Enviar el documento 9 (2026-09-20) | 25 días | Acta de recibo o fecha. Además: dijo el 09-24 que ya entregó la matriz 6, sin acta, y esa no tiene fecha desde el 09-10 (35 días): que la fecha quede dicha hoy | 3 |
| Andrés Lozano | Validar el ambiente 4 (2026-09-27; antes 09-13) | 18 días | Acta de recibo o fecha | 2 |
| Ricardo Salas | Cerrar la prueba 18 (2026-10-06) | 9 días | Acta de recibo o fecha | 2 |
| Javier Hoyos | Cerrar la prueba 10 (2026-10-08; antes 09-21) | 7 días | Acta de recibo o fecha | 2 |
| Diana Molina | Aprobar el diseño 21 (2026-10-11) | 4 días | Acta de recibo o fecha; tampoco se mencionó el 10-15 | 2 |

Fuente: 30-reuniones/2026-09-17 (Beatriz, Javier), 09-03 y 09-10 (Andrés), 10-01 (Ricardo), 10-08 (Diana; estado de Javier y Ricardo); cálculo `portafolio.py compute` del 2026-10-15.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Dueño del riesgo «el proveedor podría no llegar con el equipo completo para la siguiente fase». Se comentó el 10-15 y «nadie lo anotó como riesgo»; no está en el RAID ni tiene dueño | Camilo Beltrán (registrarlo y nombrar dueño) | Sigue sin registro y sin dueño. Además, «la siguiente fase» no está definida en ningún documento: alguien tiene que decir cuál es | 3 |
| Fecha del ajuste de presupuesto: «la otra semana», sin fecha | Laura Vélez | Queda sin fecha, y un compromiso sin fecha no puede vencer | 2 |
| Cadencia: las notas dicen «dos semanas» y la configuración dice semanal | Camilo Beltrán | Si es de dos semanas, lo que vence el 10-19 y el 10-20 no se revisa hasta el 10-29 | 1 |

Fuente: 2026-10-15-notas-reunion.txt; estado/…/corridas/salida-pm-minutes.md (propuesta al RAID y contradicción de cadencia).

### Vence antes de la próxima
| Quién | Qué | Para cuándo | Min |
|---|---|---|---|
| Ricardo Salas | Validar el ambiente 20 (empezó sin fecha; se le puso el 10-19 el 10-08) | 2026-10-19 | 1 |
| Carlos Peña | Entregar el punto 24 | 2026-10-20 | 1 |
| Carlos Peña | Aprobar el diseño 5 (antes 10-03). El 09-24 dijo que ya lo entregó; no hay acta | 2026-10-23 | 1 |
| Óscar Ramírez | Revisión con el proveedor. **El 25 de octubre es domingo**: confirmar el día real. Que lleve a esa revisión el acta de la calibración de sensores (figura aceptada sin documento) y la fecha del licenciamiento (pendiente desde 2025-12-08) | 2026-10-25 | 2 |

Fuente: 30-reuniones/2026-10-08 (Ricardo, Carlos), 09-10 y 09-17 (diseño 5), 2026-10-15-notas-reunion.txt (Óscar); 00-gobierno/2025-10-01-contrato-ct-235.md (entregables).

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| María Restrepo · Confirmar la fecha 7 (2026-09-20, 25 días) | Dijo el 09-17 que ya entregó, sin acta. No aparece en la asistencia del 10-08 ni del 10-15, así que su doliente no va a estar | Camilo le pide el acta directamente antes del 10-29; si no la hay, entra a la reunión como vencido |
| Sandra Gil · Revisar el anexo 11 (2026-10-01, 14 días) | Dijo el 09-24 que ya entregó, sin acta. Última vez en la asistencia: 09-17; tampoco estuvo el 10-08 ni el 10-15 | Igual que el anterior |
| CC-01: ampliación de alcance, +49 días sobre la línea base vigente y 98.000.000 COP adicionales, sin decisión desde el 2026-10-11 | Excede la autoridad del gerente. En el expediente no figura quién decide (autoridad y `decided_by` sin encontrar), así que no puedo decir ante quién | `/pm-escalate` para formularlo como decisión |
| El informe del 10-13 declara amarillo y 61 %, mientras el cronograma v2 marca los 5 hitos como cumplidos y cuatro de ellos no tienen acta | Es una discrepancia del informe, no de la reunión | `/pm-report`: el estado lo declara Camilo, mostrando contra qué |
| Entregables de CT-235: licenciamiento pendiente 311 días; calibración aceptada sin acta; facturado 409.709.674 COP, igual a dos entregables aceptados | Es del contrato, no de la sala | Lo que traiga Óscar de la revisión con el proveedor, y `/pm-escalate` si la factura se quiere frenar |

### Anexo — sin cambios desde el 2026-10-15
No se repasa en la reunión; ninguno vence antes del 10-29.
- Carlos Peña · Aprobar el diseño 13 — 2026-11-03 (se le puso fecha dos veces: 10-22 y 11-03).
- Javier Hoyos · Actualizar la matriz 22 — 2026-11-03.
- Felipe Arango · Entregar el punto 16 — 2026-11-04 (antes 10-14).
- Natalia Ospina · Confirmar la fecha 23 — 2026-11-04.
- Felipe Arango · Confirmar la fecha 15 — 2026-11-07 (antes 10-20).
- Cerrados con documento, no se repasan: anexo 3, punto 8, ambiente 12, matriz 14, documento 17, anexo 19.
- Riesgo «concentración del conocimiento en una sola persona»: registrado, sin dueño.

---
Es la primera corrida de este proyecto: no había foto anterior, así que «qué cambió» se midió contra la reunión del 10-15 y no contra una corrida previa.
No convoco a nadie y no dirijo la reunión. Cuando termine, `/pm-minutes` sobre las notas, y lo que salga entra a `/pm-commitments`.
