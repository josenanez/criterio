# Corrida del 2026-10-15 · pm-escalate

1 proyectos · 57 s · 18 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 7 |
| `milestone_met_without_evidence` | 4 |
| `commitment_undated` | 2 |
| `commitment_rescheduled` | 2 |
| `progress_vs_plan` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Paquete de decisión: autoridad no declarada en el acta (punto 0) y CC-01 (+49 días, +98 M COP; recomienda devolver porque la base ya venció). Impact: 0 proyectos alcanzados. No sabe: si la proyección incluye CC-01, qué alcance agrega, quién tiene la facultad, consecuencia con fecha de no decidir.

Contra la corrida del 2026-10-15: +0 hallazgos.

## Lo que produjo

## Para decisión — PRY-200 · Mantenimiento predictivo de camiones · 2026-10-15

Sin tema en la invocación: se tomó lo que ya está marcado como escalable. Escalan dos cosas y una tercera queda como aviso. Las dos primeras van juntas porque la segunda no se puede cerrar sin la primera.

### Punto 0 (el primero que escala): ¿qué puede decidir el gerente?

**El acta de constitución (2025-10-07) no declara la autoridad del gerente.** Ficha: `identity.authority = not_found`. El acta nombra patrocinador (Rubén Cárdenas), gerente (Camilo Beltrán) y comité (Comité de Seguridad, que aprobó el presupuesto de 2.400.000.000 COP), pero no dice qué cambios de alcance, fecha o costo puede aprobar el gerente y cuáles pasan al comité o al patrocinador. Tampoco declara dependencias («Ninguna declarada»).

**Pregunta cerrada:** ¿Se acepta que el Comité de Seguridad (o el patrocinador) emita por escrito, en una adenda al acta, los umbrales de alcance, fecha y costo que el gerente decide solo y los que suben?
Respuesta posible: *sí, con umbrales X* / *no, todo cambio sube al comité*.

**Quién decide:** el patrocinador, Rubén Cárdenas, y el Comité de Seguridad, por ser quien aprobó el acta. Es una inferencia mía; el acta no lo dice.
**Si no se decide hoy:** el documento no da una fecha límite. La fecha más cercana que ofrece el calendario es el comité del 2026-10-29 (`cycle.committee_next`; las notas del 10-15 dicen «próxima reunión en dos semanas»). Sin la adenda, el punto siguiente (CC-01) llega a esa sesión sin que se sepa si quien lo decide tiene la facultad. Puede que se decida y no valga.

**Recomiendo:** sí, pedir la adenda en la sesión del 10-29, con umbrales explícitos. Es corta y evita que cada cambio abra la misma discusión.

---

### Punto 1: Solicitud de cambio CC-01

**Pregunta cerrada:** ¿Se aprueba CC-01 tal como está (ampliación de alcance, +49 días, +98.000.000 COP), se rechaza, o se devuelve para reemitirla con la fecha de cierre real?

**Quién decide:** no se puede decir contra el acta, porque no declara autoridad (punto 0). CC-01 dice «Pendiente de presentación al comité»; el comité que aprobó el presupuesto es el Comité de Seguridad.
**Si no se decide hoy:** no hay en los documentos una consecuencia con fecha. No la invento. Lo que sí hay: la decisión no puede tomarse antes del comité del 2026-10-29, y el 2026-10-25 está comprometida la revisión con el proveedor (Óscar Ramírez), que cae antes de esa sesión.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 tal cual | Se amplía (sin detalle de qué se agrega; CC-01 solo dice «Ampliación de alcance») | +49 días sobre la línea base vigente → cierre 2026-07-01, que **ya pasó** | +98.000.000 COP. La proyección declarada al cierre es 2.474.762.505 (74.762.505 sobre lo aprobado). Si la proyección no incluye CC-01, quedaría en 2.572.762.505, o sea 172.762.505 (7,2 %) sobre lo aprobado. No sé si la incluye |
| B. Rechazar | Se mantiene el alcance aprobado | Cierre vigente 2026-05-13, ya vencido: el proyecto va al 61 % declarado | 0 adicional por el cambio. La proyección declarada ya excede lo aprobado en 74.762.505, sin autorización registrada |
| C. Devolver y reemitir con fecha real | A definir al reemitir | A definir: +49 días sobre 2026-05-13 no es una fecha de cierre posible hoy | A definir |

**Recomiendo:** C, devolver. La solicitud calcula los +49 días sobre una línea base que terminó hace cinco meses, así que aprobarla tal cual deja una línea base nueva con una fecha ya vencida. Además no dice qué alcance se agrega, y la ficha tiene una sola línea base (v1, 2025-10-07). Tengo que pedir lo que falta antes de que el comité elija entre A y B.

Dos cosas de los documentos que debe aclarar quien reemita:
- El cronograma v2 (2026-10-13) ya mueve «Pruebas en operación» de 2026-04-24 a 2026-06-12, que son exactamente 49 días, y no hay una línea base v2 aprobada. No sé si ese desplazamiento es el mismo de CC-01 (se contaría dos veces) o una coincidencia.
- Los cinco hitos del cronograma figuran «met», pero solo «Licencia y permisos obtenidos» tiene acta de recibo; los otros cuatro no tienen evidencia.

### A quién alcanza

`portafolio.py impact` (49 días, PRY-200): **0 proyectos alcanzados, 0 dependencias sin confirmar.** Es lo que dice la ficha, que es un solo proyecto, sin dependencias declaradas en el acta. No prueba que nadie más dependa de este cierre. Si otra área depende de él, nadie lo ha escrito.
Cuántos días se mueve cada proyecto alcanzado no se calcula: necesita holgura por actividad y la ficha no la tiene.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| (ninguno según la ficha) | — | — | — |

### Mis hitos por los que pasa

El cálculo devolvió **ningún hito** por el que pase el cambio: nuevo cierre calculado 2026-07-01 y todos los hitos de la ficha tienen fecha vigente anterior o igual a 2026-06-12. Eso es consecuencia de que la fecha ya venció; no significa que el cambio no afecte nada.

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| (ninguno) | — | — |

### Aviso, sin armar paquete: compromiso reprogramado seis veces

Paula Céspedes, «Enviar el documento 1»: original 2026-09-25, reprogramado seis veces (10-12, 10-28, 11-14, 11-23, 12-09 y, en las notas de hoy, 2026-12-23). Cumple el criterio de tres reprogramaciones. No armo el paquete porque la ficha no dice si quien espera el documento está fuera del proyecto. Díganme quién lo espera y lo formulo.

### De dónde sale esto

- Autoridad no declarada, presupuesto, comité, fechas del acta, «Ninguna declarada»: `00-gobierno/2025-10-07-acta-constitucion.docx` (leído de nuevo hoy).
- CC-01 (alcance, +49 días, +98.000.000 COP, «Pendiente de presentación al comité»): `20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md`.
- Proyección, comprometido, ejecutado, 61 %, estado amarillo: `20-seguimiento/2026-10-13-informe-avance.md`.
- Hitos, fecha 2026-06-12, estado «met»: `10-plan/2026-10-13-cronograma-v2.xlsx` y `10-plan/2025-10-07-cronograma-v1.csv`; acta de recibo: `20-seguimiento/2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf`.
- Reprogramaciones del compromiso de Paula Céspedes: `30-reuniones/2026-09-10…2026-10-08-comite-semanal.md` y `2026-10-15-notas-reunion.txt`.
- Próximo comité 2026-10-29: `.criterio/proyecto/PRY-200/config.json` y `2026-10-15-notas-reunion.txt`.
- Efecto en otros proyectos: `portafolio.py impact --code PRY-200 --days 49`.

**Lo que no sé:** si la proyección incluye CC-01; qué alcance agrega; quién tiene la facultad (el acta no la declara); si otro proyecto depende de este cierre; la consecuencia con fecha de no decidir.

*Las preguntas del flujo se contestaron con la respuesta sugerida, sin interlocutor (sesión de prueba). Este paquete lo lleva usted al comité; no le escribí a nadie.*
