# Acta — Mantenimiento predictivo de camiones (PRY-200) · 2026-10-15

**Asistieron (13):** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Javier Hoyos, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Óscar Ramírez
**Fuente:** `2026-10-15-notas-reunion.txt` · **Ausentes con tema en agenda:** no se puede saber; las notas no traen agenda. Los nombres coinciden con los del comité del 2026-10-08, y Laura Vélez y Óscar Ramírez reaparecen en esta lista.

## Compromisos

| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-12-23 | **Reprogramado 6 veces.** Original 2026-09-25; luego 10-12, 10-28, 11-14, 11-23, 12-09 y ahora 12-23. Cita: «lo de "enviar el documento 1" no alcanzó, se compromete para el 23/12/2026». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-25 | Nuevo. No es «Revisar el anexo 19», que se cerró el 10-08 con acta de recibo. El 2026-10-25 cae en domingo. |

### Sin fecha

| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto. `due_date: no_declarada`. Cita: «la otra semana». Nadie dijo una fecha. |

## Decisiones

Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir

| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Fecha del ajuste de presupuesto | Se dijo «la otra semana» sin fecha | Las notas no lo dicen |

## Intenciones sin doliente

Ninguna en esta reunión.

## Dicho al pasar y no registrado

| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «el proveedor podría no llegar con el equipo completo para la siguiente fase» | No atribuido en las notas; dice «se comentó» | Riesgo. Proveedor CT-235, Servicios Ambientales del Norte | No. Las notas dicen «nadie lo anotó como riesgo». Queda propuesto para el RAID, sin dueño asignado. |

## Cerrado en esta reunión

Nada. Ningún compromiso se cerró contra un documento.

## Lo que esta reunión contradice

| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «próxima reunión en dos semanas» (2026-10-29) | Comité semanal (`cycle.committee: weekly`); actas semanales del 09-03 al 10-08 | Notas 2026-10-15; configuración y actas de comité |

La fecha 2026-10-29 coincide con `committee_next`. Lo que choca es «dos semanas» contra el ciclo semanal. Puede ser un cambio de cadencia o un salto puntual, y las notas no lo aclaran.

## Sin resolver de la transcripción

- «Laura Vélez queda de mandar el ajuste del presupuesto la otra semana»: no hay fecha. Se mantiene sin fecha y no se interpreta.
- «se comentó que el proveedor podría no llegar…»: no se sabe quién lo dijo ni a qué fase se refiere. No hay documento que defina «la siguiente fase».
- No queda claro a qué se refiere el «documento 1» de Paula Céspedes. Las notas lo nombran igual que las actas anteriores.

## Cifras recalculadas (`portafolio.py compute`, no a mano)

- 7 compromisos vencidos sin evidencia.
- 2 sin fecha: Beatriz Cuéllar (matriz 6) y Laura Vélez.
- 2 reprogramados 3 o más veces: Paula Céspedes (6) y Mauricio Pérez (5, no mencionado hoy).

**Siguiente paso:** `/pm-commitments` para el seguimiento completo, y `/pm-publish` si quieres llevar el cambio a la ficha. Esta acta no se guardó en tu carpeta de reuniones: la guardas tú.
