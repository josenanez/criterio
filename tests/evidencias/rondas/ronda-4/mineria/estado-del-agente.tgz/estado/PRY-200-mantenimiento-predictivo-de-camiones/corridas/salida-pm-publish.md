Publiqué la ficha en `/home/claude/banco/ronda-4/mineria/espacio/documentos/proyectos/PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/ficha-pm.json`, con corte al 2026-10-15.

**Lleva:** 250 campos con dato · 9 sin decir en ninguna parte · declara **amarillo** al 2026-10-13 (61 % de avance, declarado por la gerencia; la ficha lo marca como declaración)

**Lo más viejo que va ahí:** `vendors[0].contract_ref` (y los demás datos del contrato CT-235), del 2025-10-01 — pasa de un año. Los datos de identidad y plan vienen del acta de constitución del 2025-10-07, también con 12 meses.

**Antes de publicar, lo que la PMO va a ver (recalculado hoy):**
- 18 alertas. El avance declarado (61 %) contra un plan con 5 de 5 hitos cumplidos: 39 puntos de diferencia.
- 4 hitos declarados cumplidos sin evidencia.
- 7 compromisos vencidos, 2 sin fecha y 2 reprogramados 5 y 6 veces.
- Proveedor Servicios Ambientales del Norte: licenciamiento 311 días tarde, y calibración aceptada sin evidencia.
- Dinero: aprobado 2.400 M COP, ejecutado 41,4 %, proyección 3,1 % sobre lo aprobado.
- El estado amarillo declarado no da cuenta de varias de estas señales (compromisos, hitos sin evidencia, avance contra plan, proveedor tarde).
- Sin dato: `identity.authority`, `identity.phase`, evidencias de hitos y entregables, y quién decidió el cambio.
