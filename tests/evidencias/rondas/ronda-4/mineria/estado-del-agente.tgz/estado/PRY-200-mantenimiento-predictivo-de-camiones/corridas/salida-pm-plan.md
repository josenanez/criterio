Términos: vigentes (v0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15). Sin preguntas pendientes; en esta sesión sin interfaz no hubo nada que decidir.

# Plan — PRY-200 · Mantenimiento predictivo de camiones · borrador del 2026-10-15
**Desde:** acta de constitución del 2025-10-07 (`00-gobierno/2025-10-07-acta-constitucion.docx`) y contrato CT-235 (`00-gobierno/2025-10-01-contrato-ct-235.md`) · **Criterio de éxito:** «Mantenimiento predictivo de camiones en producción y medido» (acta, sección Criterio de éxito). Está declarado, pero no dice qué se mide ni con qué umbral.

> Aviso de contexto: este proyecto ya tiene cronograma v1 (2025-10-07) y v2 (2026-10-13), y el cierre comprometido del acta (2026-05-13) ya pasó. Lo que sigue es el borrador desde el acta, como pide el comando por defecto. Si lo que necesitas es revisar el plan vigente, el modo es `/pm-plan revisar 10-plan/2026-10-13-cronograma-v2.xlsx`.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance sin contenido:** dice «Componente 1 / 2 / 3» y nada más | No hay entregables de alcance que descomponer. Cualquier nombre que yo les ponga sería inventado, así que van como «sin definir». |
| **Fuera de alcance sin contenido:** «Lo que otro proyecto cubre», sin decir qué proyecto ni qué cubre | No se puede saber dónde termina este proyecto. Si otro proyecto (por ejemplo, el que construye «monitoreo de flota») cubre parte del trabajo, el plan puede duplicarlo o dejarlo huérfano. |
| **Criterio de éxito sin métrica:** «en producción y medido» | No se sabe cuándo un entregable cuenta como aceptado, ni qué es «medido». El nodo de aceptación final queda sin definir. |
| **Sin autoridad declarada:** el acta no dice qué puede decidir el gerente (Camilo Beltrán) sin subir al patrocinador (Rubén Cárdenas) ni al Comité de Seguridad | No sé qué del plan puedes decidir tú y qué hay que escalar. Cada excepción de plan tiene que subir por defecto. |
| **Dependencias:** «Ninguna declarada» | Un proyecto con proveedor, sensores y camiones en operación casi seguro tiene dependencias. El orden de abajo sale de ahí, y es supuesto. |
| **Sin quién acepta entregables** | El acta no nombra al aceptante de nada. Solo el contrato dice que el gerente firma el acta de recibo para facturar. |

Patrocinador: sí está (Rubén Cárdenas). No falta.

## WBS
Descompuesta por entregable. Los nodos 1 a 3 salen del contrato CT-235, no del acta; el contrato dice «Proyecto: PRY-200», pero el acta no lo menciona. Por eso van como supuesto, con su fuente.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Licenciamiento del software | El gerente firma el acta de recibo (contrato, «Condición de pago»). Quién acepta técnicamente: sin definir | Supuesto: contrato CT-235, fecha comprometida del proveedor 2025-12-08 | vacía |
| 2 | Bolsa de horas de ingeniería | Ídem | Supuesto: contrato CT-235, fecha comprometida 2026-01-29 | vacía |
| 3 | Calibración de sensores | Ídem | Supuesto: contrato CT-235, fecha comprometida 2026-03-22 | vacía |
| 4 | Componente 1 | Sin definir | Sin definir (el acta no lo nombra) | vacía |
| 5 | Componente 2 | Sin definir | Sin definir | vacía |
| 6 | Componente 3 | Sin definir | Sin definir | vacía |
| 7 | Mantenimiento predictivo en producción | Sin definir (¿Mina, área dueña según el acta?) | Del acta: criterio de éxito | vacía |
| 8 | Medición del mantenimiento predictivo (el «y medido») | Sin definir | Del acta: criterio de éxito. Qué se mide: sin definir | vacía |

Los hitos del cronograma v1 (ingeniería básica, ingeniería de detalle, licencia y permisos, montaje e instalación, pruebas en operación) no los puse como nodos. Son fases del trabajo, no entregables que alguien reciba en el acta. Siguen como referencia en «Orden» y quedan por cruzar con los componentes cuando se definan.

## Orden
Sin fechas. Sale del cronograma v1 y del sentido del trabajo; el acta dice «Ninguna declarada», así que todo esto es **supuesto**.
- Los componentes (4, 5, 6) se definen antes de poder planificarse. Sin ellos no hay nodos terminales.
- El licenciamiento (1) necesita estar antes de lo que se instala o se pone en producción con el software. Supuesto.
- La calibración de sensores (3) necesita sensores instalados, y el acta no dice quién los instala. Supuesto.
- La bolsa de horas (2) es de apoyo transversal y no tiene predecesor claro. Supuesto.
- Producción (7) necesita todo lo anterior. La medición (8) necesita producción y la definición de la métrica.
- Secuencia de hitos del v1 como referencia: ingeniería básica → detalle → licencia y permisos → montaje → pruebas en operación.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres entregables del contrato CT-235 son todo el trabajo del proveedor para PRY-200 | Si hay trabajo del proveedor fuera del contrato, la WBS queda corta y el presupuesto también. Los tres entregables suman 614.564.511 COP (3 × 204.854.837) frente a 2.400.000.000 COP aprobados. Qué cubre el resto, el acta no lo dice. |
| Los entregables del contrato corresponden a los «Componentes 1, 2 y 3» del acta | Si no corresponden, hay seis o más entregables en vez de tres, y el mapeo del alcance cambia. |
| El gerente del proyecto es quien acepta | El contrato solo dice que firma el acta de recibo. Si Mina o el patrocinador aceptan técnicamente, el cierre de cada nodo tiene otro dueño. |
| Las dependencias son las del orden de arriba | El acta no declara ninguna. Una dependencia real no declarada es un riesgo que hoy nadie está mirando. |
| «Medido» significa medición del resultado en operación, no medición del avance del proyecto | Si es lo segundo, el nodo 8 es otra cosa. |

Cuando el plan se apruebe, estos supuestos pasan al RAID con doliente.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son los Componentes 1, 2 y 3 | Patrocinador (Rubén Cárdenas) con el área dueña (Mina). El acta no dice quién. |
| Qué queda fuera de alcance y qué proyecto lo cubre | Patrocinador |
| Métrica y umbral de «en producción y medido» | Patrocinador y área dueña |
| Quién acepta cada entregable técnicamente | Patrocinador |
| Qué puede decidir el gerente sin escalar | Patrocinador / Comité de Seguridad |
| Dependencias del proyecto (otro proyecto, sala de producción, flota disponible) | Gerente, con Mina |
| En qué se gasta el resto del presupuesto (2.400.000.000 − 614.564.511 = 1.785.435.489 COP no asignados a los entregables del contrato) | Gerente / patrocinador |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-200 no apunta a una carpeta de fichas de la PMO, y no busqué proyectos análogos por mi cuenta en otras carpetas. Así que no hay referencia de cuánto se corrieron proyectos parecidos, y no la invento.

## Preguntas para el equipo
Una por cada duración vacía:
1. ¿Cuánto toma el licenciamiento del software, desde la orden hasta el recibo? (El contrato da una fecha del proveedor, 2025-12-08, no una duración.)
2. ¿Cuántas horas de la bolsa de ingeniería se prevén y en qué ventana? ¿Cuánto trabajo cabe en la bolsa?
3. ¿Cuánto toma la calibración de sensores por camión o por lote de camiones?
4. ¿Qué es el Componente 1 y cuánto toma?
5. ¿Qué es el Componente 2 y cuánto toma?
6. ¿Qué es el Componente 3 y cuánto toma?
7. ¿Cuánto toma pasar a producción una vez entregado lo anterior?
8. ¿Qué se mide, durante cuánto tiempo y con qué umbral se da por medido?

## Para comprometer una fecha falta
- La disponibilidad real del equipo del proyecto y de Mina. No está en ningún documento.
- La fecha confirmada del proveedor. El contrato trae fechas de 2025 y 2026; no hay documento que diga que siguen siendo válidas.
- La ventana de la sala de producción y de los camiones. No aparece en ningún documento.
- La aprobación del patrocinador sobre alcance y aceptantes. Sin ella, cualquier fecha comprometería algo que nadie definió.

## Nota aparte (no es parte del plan)
El cronograma v2 mueve «Pruebas en operación» de 2026-04-24 a 2026-06-12, 49 días, y la nueva fecha queda 30 días después del cierre comprometido en el acta (2026-05-13). El contrato marca «Licenciamiento del software» como pendiente, con fecha comprometida 2025-12-08, mientras el cronograma marca todos los hitos como cerrados. Es una discrepancia entre documentos que no resolví aquí: pertenece a `/pm-report` o a `/pm-commitments`.
