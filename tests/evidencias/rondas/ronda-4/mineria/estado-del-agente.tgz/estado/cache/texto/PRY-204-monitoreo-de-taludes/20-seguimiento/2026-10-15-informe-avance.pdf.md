<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Monitoreo de taludes
Código: PRY-204
Fecha de corte: 2026-10-15
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 98%

Lo que pasó en el periodo
- El proveedor entregó los equipos en el campamento, pendientes de aceptación

Presupuesto
COP
Aprobado 800.000.000
Comprometido 231.976.147
Ejecutado 160.911.675
Proyección al cierre 910.844.209

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
- Cambio en la licencia ambiental que puede mover el alcance
