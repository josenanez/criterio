<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-06
Gerente: Laura Vélez

Estado declarado
Verde
Avance reportado: 25%

Lo que pasó en el periodo
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.612.108.532
Ejecutado 1.634.387.317
Proyección al cierre 11.432.506.949

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
