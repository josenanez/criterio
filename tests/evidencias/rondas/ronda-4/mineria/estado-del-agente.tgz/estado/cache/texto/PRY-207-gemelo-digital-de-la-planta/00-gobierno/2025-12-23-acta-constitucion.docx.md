<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2025-12-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la planta

Código: PRY-207

Área dueña: Tecnología

Patrocinador: Carlos Peña

Gerente de proyecto: Elena Duarte

Comité: Comité de Tecnología

Producto asociado: gemelo digital

Fecha de aprobación: 2025-12-23

Objetivo del negocio

Entregar gemelo digital de la planta para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Tecnología el 2025-12-23.

Fechas comprometidas

Fecha

Inicio

2026-01-02

Cierre

2026-07-23

Criterio de éxito

Gemelo digital de la planta en producción y medido.

Dependencias declaradas

• Ninguna declarada
