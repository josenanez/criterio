<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/10-plan/2026-10-13-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-11-23 | 2025-11-23 | cerrado
Ingeniería de detalle aprobada | 2025-12-31 | 2025-12-31 | cerrado
Licencia y permisos obtenidos | 2026-02-07 | 2026-02-07 | cerrado
Montaje e instalación | 2026-03-17 | 2026-03-17 | cerrado
Pruebas en operación | 2026-04-24 | 2026-06-12 | cerrado
