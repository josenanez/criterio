<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-24-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-24
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Felipe Arango, Javier Hoyos, Mauricio Pérez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-14 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-27 |
| Mauricio Pérez | Revisar el anexo 3 | 2026-09-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-21 |
| Carlos Peña | Validar el ambiente 12 | 2026-09-26 |
| Carlos Peña | Aprobar el diseño 13 | por definir |
| Mauricio Pérez | Actualizar la matriz 14 | 2026-10-03 |
| Felipe Arango | Confirmar la fecha 15 | 2026-10-20 |
| Felipe Arango | Entregar el punto 16 | 2026-10-14 |

## Lo que se dijo

- Carlos Peña dice que ya entregó «aprobar el diseño 5». No se presentó acta.
- Beatriz Cuéllar dice que ya entregó «actualizar la matriz 6». No se presentó acta.
- Sandra Gil dice que ya entregó «revisar el anexo 11». No se presentó acta.
