<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/10-plan/2026-06-07-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-10-04 | 2026-10-04 | cerrado
Ingeniería de detalle aprobada | 2027-01-21 | 2027-01-21 | en curso
Licencia y permisos obtenidos | 2027-05-10 | 2027-05-10 | en curso
Montaje e instalación | 2027-08-27 | 2027-08-27 | en curso
Pruebas en operación | 2027-12-14 | 2027-12-14 | en curso
