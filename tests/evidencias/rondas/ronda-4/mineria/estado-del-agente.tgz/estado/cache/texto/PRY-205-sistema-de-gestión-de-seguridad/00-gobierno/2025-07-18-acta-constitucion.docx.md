<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/00-gobierno/2025-07-18-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Sistema de gestión de seguridad

Código: PRY-205

Área dueña: Geología

Patrocinador: Javier Hoyos

Gerente de proyecto: Javier Hoyos

Comité: Comité de Operaciones

Producto asociado: No aplica

Fecha de aprobación: 2025-07-18

Objetivo del negocio

Entregar sistema de gestión de seguridad para Geología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Operaciones el 2025-07-18.

Fechas comprometidas

Fecha

Inicio

2025-07-28

Cierre

2026-04-16

Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

Dependencias declaradas

• Ninguna declarada
