<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "name": {
 "value": "Mantenimiento predictivo de camiones",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Mina",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "product": {
 "value": "monitoreo de flota",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Rubén Cárdenas",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "manager": {
 "value": "Camilo Beltrán",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Seguridad",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "progress_pct": {
 "value": 61,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "as_of": {
 "value": "2026-10-13",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found",
 "source_kind": "declaration"
 },
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 },
 "plan": {
 "start_date": {
 "value": "2025-10-17",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "end_date": {
 "value": "2026-05-13",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-10-07",
 "start_date": "2025-10-17",
 "end_date": "2026-05-13",
 "reason": "Acta de constitución",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": {
 "value": "Ingeniería básica aprobada",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-11-23",
 "source": "10-plan/2025-10-07-cronograma-v1.csv",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "current_date": {
 "value": "2025-11-23",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Ingeniería de detalle aprobada",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2025-12-31",
 "source": "10-plan/2025-10-07-cronograma-v1.csv",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "current_date": {
 "value": "2025-12-31",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Licencia y permisos obtenidos",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-02-07",
 "source": "10-plan/2025-10-07-cronograma-v1.csv",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "current_date": {
 "value": "2026-02-07",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf",
 "source": "20-seguimiento/2026-10-04-acta-recibo-licencia-y-permisos-obtenidos.pdf",
 "source_date": "2026-10-04",
 "state": "found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Montaje e instalación",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-03-17",
 "source": "10-plan/2025-10-07-cronograma-v1.csv",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "current_date": {
 "value": "2026-03-17",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 },
 {
 "name": {
 "value": "Pruebas en operación",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "baseline_date": {
 "value": "2026-04-24",
 "source": "10-plan/2025-10-07-cronograma-v1.csv",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "current_date": {
 "value": "2026-06-12",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "10-plan/2026-10-13-cronograma-v2.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-10-07-acta-constitucion.docx",
 "source_date": "2025-10-07",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "approved": {
 "value": 2400000000,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "committed": {
 "value": 1481500375,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "executed": {
 "value": 993723690,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 },
 "projection": {
 "value": 2474762505,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "source_date": "2026-10-13",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": {
 "value": "Servicios Ambientales del Norte",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "contract_ref": {
 "value": "CT-235",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "deliverables": [
 {
 "name": {
 "value": "Licenciamiento del software",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2025-12-08",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "amount": {
 "value": 204854837,
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "state": {
 "value": "pending",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 {
 "name": {
 "value": "Bolsa de horas de ingeniería",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-01-29",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "amount": {
 "value": 204854837,
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "state": {
 "value": "accepted",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "evidence": {
 "value": "20-seguimiento/2026-02-15-acta-recibo-ct-235-bolsa-de-horas-de-ingeniería.md",
 "source": "20-seguimiento/2026-02-15-acta-recibo-ct-235-bolsa-de-horas-de-ingeniería.md",
 "source_date": "2026-02-15",
 "state": "found"
 }
 },
 {
 "name": {
 "value": "Calibración de sensores",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-03-22",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "amount": {
 "value": 204854837,
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "state": {
 "value": "accepted",
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md",
 "source_date": "2025-10-01",
 "state": "found"
 },
 "evidence": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 }
 ],
 "invoiced": {
 "value": 409709674,
 "source": "20-seguimiento/2026-09-27-factura-ct-235.md",
 "source_date": "2026-09-27",
 "state": "found"
 },
 "source": "00-gobierno/2025-10-01-contrato-ct-235.md; factura: 20-seguimiento/2026-09-27-factura-ct-235.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": null,
 "source": "20-seguimiento/2026-10-13-informe-avance.md",
 "registered": true
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase; nadie lo anotó como riesgo",
 "owner": null,
 "source": "2026-10-15-notas-reunion.txt",
 "registered": false
 }
 ],
 "assumptions": [],
 "issues": [
 {
 "what": "El equipo perdió dos semanas por rotación de un ingeniero clave",
 "source": "20-seguimiento/2026-10-13-informe-avance.md"
 }
 ],
 "dependencies": []
 },
 "changes": [
 {
 "ref": {
 "value": "CC-01",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "requested_on": {
 "value": "2026-10-11",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "scope_impact": {
 "value": "Ampliación de alcance",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "time_impact": {
 "value": "+49 días sobre la línea base vigente",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "cost_impact": {
 "value": "98.000.000 COP adicionales",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "decision": {
 "value": "pending",
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md",
 "source_date": "2026-10-11",
 "state": "found"
 },
 "decided_by": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "source": "20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": {
 "value": "Paula Céspedes",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 1",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-23",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-25",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-23",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-12-09",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 },
 {
 "due_date": "2026-12-23",
 "stated_on": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt"
 }
 ]
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 2",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-12-02",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-22",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-05",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 },
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-12-02",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "No se mencionó en las notas del 2026-10-15."
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 3",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-22",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-22",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-01-acta-recibo-3.md",
 "source": "20-seguimiento/2026-10-01-acta-recibo-3.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "note": "Siguió abierto con 2026-09-22 en las minutas del 09-10, 09-17 y 09-24; cerrado el 2026-10-01."
 },
 {
 "who": {
 "value": "Andrés Lozano",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 4",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-27",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-13",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-03",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-03-comite-semanal.md",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-03-comite-semanal.md",
 "source_date": "2026-09-03",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md"
 }
 ],
 "note": "Sigue en las listas del 10-01 y 10-08 con 2026-09-27; sin acta de recibo."
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 5",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-23",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md"
 }
 ],
 "note": "El 2026-09-24 Carlos Peña dijo que ya lo entregó; no se presentó acta y desapareció de las listas. No se da por cumplido."
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 6",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [],
 "note": "Por definir el 09-10 y 09-17. El 2026-09-24 dijo que ya lo entregó; no se presentó acta y desapareció de las listas."
 },
 {
 "who": {
 "value": "María Restrepo",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 7",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-20",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-20",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [],
 "note": "El 2026-09-17 dijo que ya lo entregó; no se presentó acta y desapareció de las listas."
 },
 {
 "who": {
 "value": "Camilo Beltrán",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 8",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-14",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-14",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-10",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-10-comite-semanal.md",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-09-10-comite-semanal.md",
 "source_date": "2026-09-10",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-09-17-acta-recibo-8.md",
 "source": "20-seguimiento/2026-09-17-acta-recibo-8.md",
 "source_date": "2026-09-17",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Beatriz Cuéllar",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 9",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-20",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-20",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [],
 "note": "Sigue con 2026-09-20 en las listas del 09-24, 10-01 y 10-08; sin acta de recibo."
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 10",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-21",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-08",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ],
 "note": "Sigue con 2026-10-08 el 10-08; sin acta de recibo."
 },
 {
 "who": {
 "value": "Sandra Gil",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 11",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [],
 "note": "El 2026-09-24 dijo que ya lo entregó; no se presentó acta y desapareció de las listas."
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 12",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "due_date": {
 "value": "2026-09-26",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-09-26",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-17",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-17-comite-semanal.md",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-09-17-comite-semanal.md",
 "source_date": "2026-09-17",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-01-acta-recibo-12.md",
 "source": "20-seguimiento/2026-10-01-acta-recibo-12.md",
 "source_date": "2026-10-01",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 13",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "Empezó sin fecha («por definir»); las dos entradas son las veces que se le puso fecha."
 },
 {
 "who": {
 "value": "Mauricio Pérez",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 14",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-03",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-01-acta-recibo-14.md",
 "source": "20-seguimiento/2026-10-01-acta-recibo-14.md",
 "source_date": "2026-10-01",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 15",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-07",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-07",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Felipe Arango",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 16",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-14",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-09-24",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-09-24-comite-semanal.md",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-09-24-comite-semanal.md",
 "source_date": "2026-09-24",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-11-04",
 "stated_on": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md"
 }
 ]
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Enviar el documento 17",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-28",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-28",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-17.md",
 "source": "20-seguimiento/2026-10-08-acta-recibo-17.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Cerrar la prueba 18",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-06",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [],
 "note": "Sigue con 2026-10-06 el 10-08; sin acta de recibo."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Revisar el anexo 19",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "met",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [],
 "evidence": {
 "value": "20-seguimiento/2026-10-08-acta-recibo-19.md",
 "source": "20-seguimiento/2026-10-08-acta-recibo-19.md",
 "source_date": "2026-10-08",
 "state": "found"
 }
 },
 {
 "who": {
 "value": "Ricardo Salas",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "what": {
 "value": "Validar el ambiente 20",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-19",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-01",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-01-comite-semanal.md",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-01-comite-semanal.md",
 "source_date": "2026-10-01",
 "state": "found"
 },
 "reschedules": [
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md"
 }
 ],
 "note": "Empezó sin fecha; la entrada es la vez que se le puso fecha."
 },
 {
 "who": {
 "value": "Diana Molina",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Aprobar el diseño 21",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-11",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": [],
 "note": "No se mencionó en las notas del 2026-10-15; sin acta de recibo."
 },
 {
 "who": {
 "value": "Javier Hoyos",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Actualizar la matriz 22",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-03",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Natalia Ospina",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Confirmar la fecha 23",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-11-04",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Carlos Peña",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "what": {
 "value": "Entregar el punto 24",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-20",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-08",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "source": {
 "value": "30-reuniones/2026-10-08-comite-semanal.md",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "30-reuniones/2026-10-08-comite-semanal.md",
 "source_date": "2026-10-08",
 "state": "found"
 },
 "reschedules": []
 },
 {
 "who": {
 "value": "Laura Vélez",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Mandar el ajuste del presupuesto",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "no_declarada",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "no_declarada",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "source": {
 "value": "2026-10-15-notas-reunion.txt",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": [],
 "note": "Nota: «la otra semana». Nadie dijo una fecha."
 },
 {
 "who": {
 "value": "Óscar Ramírez",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "what": {
 "value": "Revisión con el proveedor",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "due_date": {
 "value": "2026-10-25",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "original_due_date": {
 "value": "2026-10-25",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "stated_on": {
 "value": "2026-10-15",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "source": {
 "value": "2026-10-15-notas-reunion.txt",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "state": {
 "value": "open",
 "source": "2026-10-15-notas-reunion.txt",
 "source_date": "2026-10-15",
 "state": "found"
 },
 "reschedules": [],
 "note": "Distinto de «Revisar el anexo 19», que se cerró el 2026-10-08."
 }
 ],
 "meta": {
 "record_updated": "2026-10-15",
 "documents_seen": [],
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
