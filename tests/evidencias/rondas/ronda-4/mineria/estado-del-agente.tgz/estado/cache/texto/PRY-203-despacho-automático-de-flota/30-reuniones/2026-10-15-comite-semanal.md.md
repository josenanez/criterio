<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Despacho automático de flota

**Fecha:** 2026-10-15
**Asistentes:** Gustavo Neira, Felipe Arango

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Óscar Ramírez | Entregar el punto 34 | por definir |
