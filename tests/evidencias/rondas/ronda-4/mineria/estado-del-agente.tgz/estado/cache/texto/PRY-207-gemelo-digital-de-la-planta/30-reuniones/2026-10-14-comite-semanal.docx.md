<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Gemelo digital de la planta

Fecha: 2026-10-14

Asistentes: Elena Duarte, Carlos Peña

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Javier Hoyos

Entregar el punto 22

2026-11-07

Mauricio Pérez

Entregar el punto 23

2026-11-09
