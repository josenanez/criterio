<!-- origen: PRY-204-monitoreo-de-taludes/00-gobierno/2025-05-14-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Monitoreo de taludes

**Código:** PRY-204
**Área dueña:** Relacionamiento comunitario
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Javier Hoyos
**Comité:** Comité de Inversiones
**Producto asociado:** alerta de taludes
**Fecha de aprobación:** 2025-05-14

## Objetivo del negocio

Entregar monitoreo de taludes para Relacionamiento comunitario.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**800.000.000 COP**, aprobado por Comité de Inversiones el 2025-05-14.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-05-24 |
| Cierre | 2026-01-16 |

## Criterio de éxito

Monitoreo de taludes en producción y medido.

## Dependencias declaradas

- Ninguna declarada
