<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2025-06-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-08-23,2025-08-23,cerrado
Ingeniería de detalle aprobada,2025-10-12,2025-10-12,cerrado
Licencia y permisos obtenidos,2025-12-01,2025-12-01,cerrado
Montaje e instalación,2026-01-20,2026-01-20,cerrado
