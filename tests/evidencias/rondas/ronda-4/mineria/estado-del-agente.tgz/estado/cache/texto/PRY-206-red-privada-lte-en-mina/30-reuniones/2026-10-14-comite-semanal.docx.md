<!-- origen: PRY-206-red-privada-lte-en-mina/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Inversiones · Red privada LTE en mina

Fecha: 2026-10-14

Asistentes: Óscar Ramírez, Elena Duarte

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Liliana Torres

Entregar el punto 1

2026-11-06
