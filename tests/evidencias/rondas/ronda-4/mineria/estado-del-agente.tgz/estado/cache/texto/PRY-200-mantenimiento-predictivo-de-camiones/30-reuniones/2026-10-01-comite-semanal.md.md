<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-01-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-01
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Javier Hoyos, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-11-23 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-11-17 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-08 |
| Carlos Peña | Aprobar el diseño 13 | 2026-10-22 |
| Felipe Arango | Confirmar la fecha 15 | 2026-10-20 |
| Felipe Arango | Entregar el punto 16 | 2026-11-04 |
| Diana Molina | Enviar el documento 17 | 2026-10-28 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-06 |
| Óscar Ramírez | Revisar el anexo 19 | 2026-10-19 |
| Ricardo Salas | Validar el ambiente 20 | por definir |

## Cerrados en esta reunión

- Revisar el anexo 3 (Mauricio Pérez): recibido, acta de recibo del 2026-10-01.
- Validar el ambiente 12 (Carlos Peña): recibido, acta de recibo del 2026-10-01.
- Actualizar la matriz 14 (Mauricio Pérez): recibido, acta de recibo del 2026-10-01.
