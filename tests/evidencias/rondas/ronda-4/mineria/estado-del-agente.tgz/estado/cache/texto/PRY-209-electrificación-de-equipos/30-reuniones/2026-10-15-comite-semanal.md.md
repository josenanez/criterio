<!-- origen: PRY-209-electrificación-de-equipos/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Electrificación de equipos

**Fecha:** 2026-10-15
**Asistentes:** Carlos Peña, Mauricio Pérez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 20 | 2026-10-26 |
