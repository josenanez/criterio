<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2025-12-23-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-02-15 | 2026-02-15 | cerrado
Ingeniería de detalle aprobada | 2026-04-01 | 2026-04-01 | cerrado
Licencia y permisos obtenidos | 2026-05-16 | 2026-05-16 | cerrado
Montaje e instalación | 2026-06-30 | 2026-06-30 | cerrado
