<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-10-08-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-08
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Javier Hoyos, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-12-09 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-12-02 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-10-08 |
| Carlos Peña | Aprobar el diseño 13 | 2026-11-03 |
| Felipe Arango | Confirmar la fecha 15 | 2026-11-07 |
| Felipe Arango | Entregar el punto 16 | 2026-11-04 |
| Ricardo Salas | Cerrar la prueba 18 | 2026-10-06 |
| Ricardo Salas | Validar el ambiente 20 | 2026-10-19 |
| Diana Molina | Aprobar el diseño 21 | 2026-10-11 |
| Javier Hoyos | Actualizar la matriz 22 | 2026-11-03 |
| Natalia Ospina | Confirmar la fecha 23 | 2026-11-04 |
| Carlos Peña | Entregar el punto 24 | 2026-10-20 |

## Cerrados en esta reunión

- Enviar el documento 17 (Diana Molina): recibido, acta de recibo del 2026-10-08.
- Revisar el anexo 19 (Óscar Ramírez): recibido, acta de recibo del 2026-10-08.
