<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2025-10-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-03-13,2026-03-13,cerrado
Ingeniería de detalle aprobada,2026-07-15,2026-07-15,cerrado
Licencia y permisos obtenidos,2026-11-16,2026-11-16,en curso
Montaje e instalación,2027-03-20,2027-03-20,en curso
