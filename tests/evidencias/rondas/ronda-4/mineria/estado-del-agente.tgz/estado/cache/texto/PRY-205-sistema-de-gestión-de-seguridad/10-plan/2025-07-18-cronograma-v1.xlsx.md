<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2025-07-18-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-09-13 | 2025-09-13 | cerrado
Ingeniería de detalle aprobada | 2025-10-31 | 2025-10-31 | cerrado
Licencia y permisos obtenidos | 2025-12-17 | 2025-12-17 | cerrado
Montaje e instalación | 2026-02-03 | 2026-02-03 | cerrado
Pruebas en operación | 2026-03-23 | 2026-03-23 | cerrado
