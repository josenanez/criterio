<!-- origen: PRY-208-trazabilidad-del-mineral/00-gobierno/2026-02-21-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Trazabilidad del mineral

Código: PRY-208

Área dueña: Seguridad y Salud

Patrocinador: Beatriz Cuéllar

Gerente de proyecto: Andrés Lozano

Comité: Comité de Operaciones

Producto asociado: trazabilidad

Fecha de aprobación: 2026-02-21

Objetivo del negocio

Entregar trazabilidad del mineral para Seguridad y Salud.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Operaciones el 2026-02-21.

Fechas comprometidas

Fecha

Inicio

2026-03-03

Cierre

2027-03-01

Criterio de éxito

Trazabilidad del mineral en producción y medido.

Dependencias declaradas

• Ninguna declarada
