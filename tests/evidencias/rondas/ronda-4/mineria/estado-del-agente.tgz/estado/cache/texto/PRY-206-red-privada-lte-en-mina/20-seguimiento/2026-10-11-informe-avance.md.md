<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-11-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Red privada LTE en mina

**Código:** PRY-206
**Fecha de corte:** 2026-10-11
**Gerente:** Óscar Ramírez

## Estado declarado

**Verde**

Avance reportado: **33%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 2.400.000.000 |
| Comprometido | 1.212.307.205 |
| Ejecutado | 873.934.388 |
| Proyección al cierre | 2.430.168.207 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
