<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-11-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-205 · Sistema de gestión de seguridad
**Fecha:** 2026-10-11
**Solicitante:** Javier Hoyos

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +112 días sobre la línea base vigente |
| Costo | 224.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
