<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2026-05-12-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-06-29 | 2026-06-29 | cerrado
Ingeniería de detalle aprobada | 2026-08-07 | 2026-08-07 | cerrado
Licencia y permisos obtenidos | 2026-09-15 | 2026-09-15 | cerrado
Montaje e instalación | 2026-10-23 | 2026-10-23 | en curso
Pruebas en operación | 2026-12-01 | 2026-12-01 | en curso
