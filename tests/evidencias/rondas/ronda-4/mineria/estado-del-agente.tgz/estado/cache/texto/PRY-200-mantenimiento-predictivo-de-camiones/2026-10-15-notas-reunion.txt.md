<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/2026-10-15-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión mantenimiento predictivo de camiones — 2026-10-15
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Diana Molina, Felipe Arango, Javier Hoyos, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Ricardo Salas, Óscar Ramírez

- Paula Céspedes dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 23/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-25
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
