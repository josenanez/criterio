<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-10
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, María Restrepo, Mauricio Pérez, Paula Céspedes

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-12 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-05 |
| Mauricio Pérez | Revisar el anexo 3 | 2026-09-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 |
| Carlos Peña | Aprobar el diseño 5 | 2026-10-03 |
| Beatriz Cuéllar | Actualizar la matriz 6 | por definir |
| María Restrepo | Confirmar la fecha 7 | 2026-09-20 |
| Camilo Beltrán | Entregar el punto 8 | 2026-09-14 |
