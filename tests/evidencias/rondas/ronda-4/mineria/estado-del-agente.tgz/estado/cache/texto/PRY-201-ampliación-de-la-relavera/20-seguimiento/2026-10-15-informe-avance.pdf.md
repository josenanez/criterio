<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Ampliación de la relavera
Código: PRY-201
Fecha de corte: 2026-10-15
Gerente: Sandra Gil

Estado declarado
Verde
Avance reportado: 50%

Lo que pasó en el periodo
- El proveedor entregó los equipos en el campamento, pendientes de aceptación
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.547.913.183
Ejecutado 1.211.173.631
Proyección al cierre 2.291.759.454

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
