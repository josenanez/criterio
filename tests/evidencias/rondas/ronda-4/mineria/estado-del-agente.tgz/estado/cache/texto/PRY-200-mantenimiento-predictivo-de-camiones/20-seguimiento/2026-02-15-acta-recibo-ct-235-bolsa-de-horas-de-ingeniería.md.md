<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-02-15-acta-recibo-ct-235-bolsa-de-horas-de-ingeniería.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de recibo · Bolsa de horas de ingeniería

**Proyecto:** PRY-200 · Mantenimiento predictivo de camiones
**Fecha de recibo:** 2026-02-15
**Recibido por:** Camilo Beltrán

Se recibe a satisfacción el entregable **Bolsa de horas de ingeniería**.

Contrato CT-235 · Servicios Ambientales del Norte.
