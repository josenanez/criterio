<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Operaciones · Sistema de gestión de seguridad

Fecha: 2026-10-13

Asistentes: Javier Hoyos, Javier Hoyos

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Sandra Gil

Entregar el punto 8

2026-10-07
