<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Trazabilidad del mineral
Código: PRY-208
Fecha de corte: 2026-10-12
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 33%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.678.557.326
Ejecutado 852.971.693
Proyección al cierre 4.084.868.175

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
