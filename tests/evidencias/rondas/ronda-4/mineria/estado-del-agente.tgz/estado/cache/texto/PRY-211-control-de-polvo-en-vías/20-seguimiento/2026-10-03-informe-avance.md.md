<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-03-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-03
**Gerente:** Laura Vélez

## Estado declarado

**Verde**

Avance reportado: **75%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 1.902.979.584 |
| Ejecutado | 1.560.026.773 |
| Proyección al cierre | 3.434.195.358 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
