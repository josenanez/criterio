<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-09-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Inversiones · Ampliación de la relavera

**Fecha:** 2026-10-09
**Asistentes:** Sandra Gil, María Restrepo

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 6 | 2026-10-18 |
