<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Sistema de gestión de seguridad
Código: PRY-205
Fecha de corte: 2026-10-12
Gerente: Javier Hoyos

Estado declarado
Amarillo
Avance reportado: 72%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 5.369.418.427
Ejecutado 4.385.650.788
Proyección al cierre 8.884.769.854

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Concentración del conocimiento en una sola persona
