<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2025-10-07-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de camiones

Código: PRY-200

Área dueña: Mina

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Seguridad

Producto asociado: monitoreo de flota

Fecha de aprobación: 2025-10-07

Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Seguridad el 2025-10-07.

Fechas comprometidas

Fecha

Inicio

2025-10-17

Cierre

2026-05-13

Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

Dependencias declaradas

• Ninguna declarada
