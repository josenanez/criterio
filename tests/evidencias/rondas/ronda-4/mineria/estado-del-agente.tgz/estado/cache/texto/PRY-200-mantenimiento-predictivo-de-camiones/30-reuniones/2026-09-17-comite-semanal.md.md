<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/30-reuniones/2026-09-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-09-17
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Carlos Peña, Javier Hoyos, Mauricio Pérez, Paula Céspedes, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Enviar el documento 1 | 2026-10-28 |
| Mauricio Pérez | Cerrar la prueba 2 | 2026-10-20 |
| Mauricio Pérez | Revisar el anexo 3 | 2026-09-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-27 |
| Carlos Peña | Aprobar el diseño 5 | 2026-10-23 |
| Beatriz Cuéllar | Actualizar la matriz 6 | por definir |
| Beatriz Cuéllar | Enviar el documento 9 | 2026-09-20 |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-21 |
| Sandra Gil | Revisar el anexo 11 | 2026-10-01 |
| Carlos Peña | Validar el ambiente 12 | 2026-09-26 |

## Cerrados en esta reunión

- Entregar el punto 8 (Camilo Beltrán): recibido, acta de recibo del 2026-09-17.

## Lo que se dijo

- María Restrepo dice que ya entregó «confirmar la fecha 7». No se presentó acta.
