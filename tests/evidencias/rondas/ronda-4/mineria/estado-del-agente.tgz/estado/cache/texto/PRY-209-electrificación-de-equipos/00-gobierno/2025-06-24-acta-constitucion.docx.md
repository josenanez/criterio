<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2025-06-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Electrificación de equipos

Código: PRY-209

Área dueña: Seguridad y Salud

Patrocinador: Mauricio Pérez

Gerente de proyecto: Carlos Peña

Comité: Comité de Inversiones

Producto asociado: No aplica

Fecha de aprobación: 2025-06-24

Objetivo del negocio

Entregar electrificación de equipos para Seguridad y Salud.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Inversiones el 2025-06-24.

Fechas comprometidas

Fecha

Inicio

2025-07-04

Cierre

2026-02-14

Criterio de éxito

Electrificación de equipos en producción y medido.

Dependencias declaradas

• Ninguna declarada
