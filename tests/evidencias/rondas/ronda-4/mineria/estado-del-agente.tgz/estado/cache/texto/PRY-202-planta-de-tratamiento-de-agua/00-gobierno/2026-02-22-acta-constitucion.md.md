<!-- origen: PRY-202-planta-de-tratamiento-de-agua/00-gobierno/2026-02-22-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Mina
**Patrocinador:** Laura Vélez
**Gerente de proyecto:** Laura Vélez
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-02-22

## Objetivo del negocio

Entregar planta de tratamiento de agua para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Tecnología el 2026-02-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-03-04 |
| Cierre | 2027-06-25 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
