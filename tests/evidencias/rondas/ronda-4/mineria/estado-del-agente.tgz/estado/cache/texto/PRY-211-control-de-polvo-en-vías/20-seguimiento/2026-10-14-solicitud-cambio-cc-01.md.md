<!-- origen: PRY-211-control-de-polvo-en-vías/20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Control de polvo en vías
**Fecha:** 2026-10-14
**Solicitante:** Laura Vélez

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +103 días sobre la línea base vigente |
| Costo | 206.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
