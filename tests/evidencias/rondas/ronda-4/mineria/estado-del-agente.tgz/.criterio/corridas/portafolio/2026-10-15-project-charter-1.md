# Corrida · 2026-10-15-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-210 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-15T21:12:22 · **Fin:** 2026-10-15T21:13:07 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 30 | 51 | Revisión del acta PRY-210 (2025-07-31): falta autoridad del gerente, supuestos/restricciones, hitos, medidor del éxito y cadencia; objetivo, alcance, exclusiones y criterio de éxito son genéricos. No sé si hay enmiendas o actas de comité fuera de la carpeta, qué proyecto cubre lo excluido ni qué se pactó como disponibilidad. |

Por señal (`project-charter`): `milestone_met_without_evidence` 21, `commitment_overdue` 8, `progress_vs_plan` 6, `declared_vs_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

Revisé el acta de PRY-210 y dejé la corrida registrada. El informe completo está en `estado/corridas/salida-project-charter.md`.

El acta existe y es del 2025-07-31. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

**Qué falta, con su consecuencia:**
- **Autoridad del gerente:** no existe. CC-01 pide 62.000.000 COP más y 31 días más, y está sin presentar al comité. Sin esa autoridad declarada no se sabe si Camilo Beltrán podía decidirla solo.
- **Objetivo de negocio:** es la solución ("Entregar programa…"), no un resultado medible.
- **Alcance:** solo dice "Componente 1, 2, 3", sin contenido. Una ampliación de alcance no se puede medir contra eso.
- **Exclusiones:** dice "Lo que otro proyecto cubre", sin nombrar el proyecto.
- **Criterio de éxito:** dice "en producción y medido", sin métrica ni umbral, y no dice quién lo mide.
- **Supuestos, restricciones, hitos y cadencia del comité:** no existen. Las dependencias dicen "ninguna", pero el informe de avance depende de una ventana de parada que define operaciones.

**Contraste con lo posterior:**
- **Presupuesto:** la proyección al cierre es 249.863.850 COP (3,7 %) sobre lo aprobado, sin contar CC-01. Está bajo el umbral de 10 %, pero el acta no dice quién autoriza ese exceso.
- **Plazo:** si CC-01 se aprueba, el cierre pasa del 2026-10-31 al 2026-12-01.
- **Estado:** el informe declara Verde con 69 % de avance, aunque su primer ensayo de disponibilidad no alcanzó lo pactado. Eso corresponde a `/health-check`, no a esta revisión.

**Qué no sé:** si hay enmiendas o actas de comité fuera de la carpeta, qué proyecto cubre lo excluido y qué se pactó como disponibilidad.

**Siguiente paso:** llevar la definición de la autoridad del gerente al Comité de Tecnología junto con CC-01 (`/steering-pack`). Los supuestos que salieron de la revisión se pueden pasar al registro RAID (`/raid-log`). Ninguno de los dos pasos está hecho.

**Dato raro del registro:** la corrida mostró 51 hallazgos de portafolio y ninguno asignado a PRY-210. Esas cifras corresponden a las corridas anteriores del portafolio, no a esta revisión.
