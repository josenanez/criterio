# Corrida · 2026-10-15-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-15T21:07:49 · **Fin:** 2026-10-15T21:08:38 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 34 | 51 | Solicitud de cambio PRY-201 +30 días: impacto en portafolio 0 (sin dependencias declaradas, lo que no prueba que no existan). Dijo que no sabe: quién pide, el motivo, el costo del cambio y la autoridad. Conflicto de cierre acta 2026-12-21 vs cronograma 2026-12-01. No se registró línea base nueva. |

Por señal (`change-control`): `milestone_met_without_evidence` 21, `commitment_overdue` 8, `progress_vs_plan` 6, `declared_vs_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

La solicitud de cambio de PRY-201 (Ampliación de la relavera, gerente Sandra Gil) quedó evaluada, pero no se puede aprobar con lo que hay en la carpeta. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo.

- **Qué se mueve:** leí «salida a producción» como el hito «Pruebas en operación», que en el cronograma coincide con el cierre. Pasa del 2026-12-01 al 2026-12-31.
- **Conflicto de fechas:** el acta de constitución dice cierre 2026-12-21 y el cronograma aprobado el mismo día dice 2026-12-01. Si vale el acta, el cierre nuevo sería 2027-01-20. Hay que resolver cuál rige.
- **Falta de datos:** ningún documento dice quién pide el cambio ni por qué. El costo del cambio no está estimado, porque la ficha no trae el costo mensual del proyecto. La holgura contra el presupuesto aprobado es de 108.240.546 COP (4,5 %).
- **Efecto en el portafolio:** el cálculo dio cero proyectos alcanzados. Eso solo significa que no hay dependencias declaradas: el acta dice «Ninguna» y ninguna otra ficha apunta a PRY-201. No prueba que no existan, y la ventana de parada de planta es un riesgo abierto.
- **Quién decide:** no se puede determinar, porque el acta no declara autoridad. Lo dejé como «va a comité» por defecto, ya que la línea base la aprobó el Comité de Inversiones. Esa ausencia es el hallazgo de fondo.
- **Línea base nueva:** no la registré, porque nadie con autoridad aprobó el cambio. La v1 sigue intacta.
- **Señales que no puse en la solicitud:** el registro de la corrida marcó cuatro señales sobre PRY-201: «declared_vs_evidence», «progress_vs_plan» y dos hitos cumplidos sin evidencia. No las desarrollé en la salida. Concuerdan con que el proyecto reporte «Verde» mientras pide 30 días y tiene el montaje vencido el 2026-10-23.

La salida completa quedó en `/home/claude/banco/ronda-4/mineria/espacio/estado/corridas/salida-change-control.md`. La corrida quedó registrada con id `2026-10-15-change-control-1` (34 segundos, 13 proyectos). Si quiere llevarlo a comité, puedo preparar el paquete con `/steering-pack`.
