# Corrida · 2026-10-15-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-307

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-307

**Inicio:** 2026-10-15T21:22:00 · **Fin:** 2026-10-15T21:22:09 · **Duración:** 9 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

No hay configuración para PRD-307. Con el código que me diste, `.criterio/producto/PRD-307/config.json` no existe en esta carpeta. Solo hay un producto configurado, `PRD-300`.

Me detengo aquí, como dice el comando. No uso la configuración de PRD-300 en su lugar, no busco la de PRD-307 en otro sitio y no la invento. Tampoco corrí términos, `corrida-inicio` ni el cruce, porque todo eso depende de esa configuración.

Para seguir, dime una de estas dos:
- **Si el producto es PRD-300:** vuelve a lanzar `/criterio-product:product-overlap PRD-300`.
- **Si de verdad es PRD-307:** hay que crearlo antes con `/criterio-product:product-setup`.
