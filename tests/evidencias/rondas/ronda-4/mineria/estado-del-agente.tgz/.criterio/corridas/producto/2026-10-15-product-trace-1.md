# Corrida · 2026-10-15-product-trace-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-trace (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T21:21:06 · **Fin:** 2026-10-15T21:21:54 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-trace` | 14 | — | 33 | 37 | 11 decididos sin proyecto; PRY-200 dice ejecutar monitoreo de flota y ningún REQ lo nombra |

Por señal (`product-trace`): `evidence_stale` 12, `requirement_untraced` 11, `requirement_without_owner` 4, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `assumption_unverified` 1

## Lo que el agente mostró

## Trazabilidad — Monitoreo de flota (PRD-300) · al 2026-10-15

11 requerimientos decididos, 0 con proyecto, 0 confirmados contra la ficha y 0 entregados. Los términos ya estaban vigentes (José Francisco Ñáñez, 2026-10-15), así que no los registré de nuevo. Usé las 13 fichas de `estado/records` (PRY-199 a PRY-211).

**Decidido y nadie lo está construyendo.** Los 11 requerimientos aceptados no tienen proyecto: REQ-4000 a REQ-4007, REQ-4009, REQ-4010 y REQ-4011.
- El más antiguo es REQ-4006, decidido el 2026-04-12, hace 186 días.
- En ninguno de los 11 consta quién decidió.
- Los tres propuestos (REQ-4008, REQ-4012, REQ-4013) no están decididos y no entran en la cadena.

**La traza no se confirma.** No hay ninguna traza declarada, así que no hay desacuerdo entre el registro y las fichas. La cadena se rompe justo después de la decisión.

**Lo que un proyecto construye y el registro no tiene.** La ficha de PRY-200 (Mantenimiento predictivo de camiones) dice que ejecuta «monitoreo de flota», según su acta de constitución del 2025-10-07. Ninguno de los 14 requerimientos nombra a PRY-200.

**Fichas.** Las otras cuatro que declaran producto dicen uno distinto: PRY-203, PRY-204, PRY-207 y PRY-208. Varias fichas, entre ellas PRY-201, no dicen qué producto ejecutan; eso es un hallazgo de ese lado y no lo toqué.

**Lo que sigue.** `/product-charter` aplica al requerimiento que ya esté listo para ser proyecto. Con PRY-200 conviene una conversación con su gerente para ver si lo que ejecuta corresponde a alguno de los 11. Ese cruce lo hace el alcance de PRY-200, y desde aquí no se puede inferir.

La corrida quedó registrada como `2026-10-15-product-trace-1`: 37 hallazgos en total. Está en `estado-producto/PRD-300/corridas/`, con la salida completa en `salida-product-trace.md`.
