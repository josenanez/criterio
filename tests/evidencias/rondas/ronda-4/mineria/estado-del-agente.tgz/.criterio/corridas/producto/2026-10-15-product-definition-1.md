# Corrida · 2026-10-15-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T20:38:04 · **Fin:** 2026-10-15T20:38:50 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 14 | — | 30 | 37 | La evidencia no contradice nada, pero sostiene poco: una entrevista de hace 13 meses, un supuesto de 113 días y una cifra que nadie mide; falta el criterio de éxito |

Por señal (`product-definition`): `evidence_stale` 12, `requirement_untraced` 11, `requirement_without_owner` 4, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `assumption_unverified` 1

## Lo que el agente mostró

La evidencia no contradice la definición de Monitoreo de flota (PRD-300). Tampoco la sostiene bien: tiene una entrevista de hace 13 meses, un supuesto sin verificar y una cifra que nadie mide. Falta además el criterio de éxito, así que el producto no se puede cerrar.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que registrarlos de nuevo. La definición y el caso de negocio son del 2025-11-14 y suman 6 afirmaciones.

- **Contradicciones:** ninguna. Ninguna fuente dice lo contrario de lo que afirma la definición.
- **Cifras:** `volumen_mensual` = 210.767 no tiene ninguna serie medida con qué comparar. No es una contradicción: nadie mide lo que el negocio afirmó.
- **Sostenida por evidencia:** el problema («Operadores sin monitoreo de flota») descansa en una sola frase de un «Cliente entrevistado» sin nombre, del 2025-08-18. Es una evidencia débil y ya superó el umbral de 12 meses, con 13 meses según el cálculo.
- **Supuesto:** «El ahorro se sostiene sin inversión adicional» lleva 113 días sin verificar (el umbral es 30). Escrito así no se puede desmentir. Haría falta declarar el ahorro como cifra, con su línea base y las inversiones excluidas.
- **No está dicho en ninguna parte:**
  - el criterio de éxito;
  - el contenido de la «Propuesta principal»;
  - el monto y la base del retorno a 24 meses;
  - el origen del ahorro;
  - el tamaño del segmento;
  - cuánto pagaría el cliente;
  - quién aprueba el cierre.
- **Normativa:** marcado como «no tengo la norma a la vista». La definición no menciona datos personales y no hay país en la configuración, así que no hay norma que citar. Esto no es un cumplimiento; lo revisa jurídico.
- **Proyectos:** ninguno declarado. Los 11 requerimientos aceptados no tienen proyecto que los ejecute.
- **Requerimientos:** hay 14 (11 aceptados y 3 propuestos). Hay 4 sin doliente, 4 sin criterio de aceptación y 3 propuestos sin decidir desde hace entre 80 y 175 días.

Tomé la respuesta sugerida en cada punto abierto: no registré los términos de nuevo y solo ofrezco convertir el supuesto en riesgo con doliente, sin registrarlo. No ofrezco `/product-charter` porque la definición no está cerrada.

La corrida quedó registrada como `2026-10-15-product-definition-1`, con 37 hallazgos. La salida completa está en `estado-producto/PRD-300/corridas/salida-product-definition.md`.
