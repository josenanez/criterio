# Corrida · 2026-10-15-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-202

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-202

**Inicio:** 2026-10-15T21:05:50 · **Fin:** 2026-10-15T21:06:32 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 26 | 51 | Presupuesto PRY-202: proyección 20,3% sobre el aprobado con estado declarado verde; comprometido 38,0%, ejecutado 17,2%. Dijo que no sabía: hitos, proveedores, causa del sobrecosto, producto/autoridad/fase. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 21, `commitment_overdue` 8, `progress_vs_plan` 6, `declared_vs_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

**PRY-202, planta de tratamiento de agua: la proyección al cierre pasa del presupuesto aprobado en 20,3 %, el doble del umbral de 10 %. Aun así el informe de avance del 2026-10-06 la declara en verde.**

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo que volver a registrarlos.

El informe sale de dos documentos: el acta de constitución (2026-02-22) y el informe de avance (2026-10-06). Los cálculos son del script al 2026-10-15.

| Cifra (COP) | Monto | % del aprobado |
|---|---|---|
| Aprobado | 9.500.000.000 | 100 |
| Comprometido | 3.612.108.532 | 38,0 |
| Ejecutado | 1.634.387.317 | 17,2 |
| Proyección al cierre | 11.432.506.949 | 20,3 sobre el aprobado |
| Disponible real (aprobado menos comprometido) | 5.887.891.468 | |

- **Estado verde sin respaldo:** esa declaración no explica el sobrecosto. La ficha no tiene ninguna fuente de evidencia, solo dos declaraciones.
- **Comprometido:** va en 38,0 %, muy por debajo del umbral de 90 %, así que no hay alerta de agotamiento.
- **Línea base de presupuesto:** no hay replanificaciones ni solicitudes de cambio. El presupuesto original y el vigente son el mismo.
- **Ejecución frente a avance:** va 17,2 % ejecutado contra 25 % de avance declarado. Puede ser trabajo hecho y no facturado, pero ningún documento lo confirma.
- **Incidencia abierta:** el equipo perdió dos semanas por la rotación de un ingeniero clave. El informe no dice si eso entra en la proyección.

**Sin dato:**
- Hitos del plan: no hay ninguno registrado, así que no se pudo medir el avance por hitos.
- Proveedores y contratos.
- La causa del sobrecosto proyectado.
- Producto, autoridad y fase del proyecto.

Dejé escrita la salida completa y la corrida registrada como `2026-10-15-budget-tracking-1`. Como la proyección excede el aprobado, puedo preparar la solicitud de cambio con `/change-control`, pero no la inicié.

Archivos en `/home/claude/banco/ronda-4/mineria/espacio/estado/corridas/`:
- `salida-budget-tracking.md`
