# Corrida · 2026-10-15-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T21:01:16 · **Fin:** 2026-10-15T21:02:00 · **Duración:** 44 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 30 | 51 | 73 documentos, 23 nuevos (todos PRY-200), 0 cambiados. 250 citas marcadas sin resolver por el índice, probable falso positivo de rutas relativas; no verificado a fondo. No se reportan formatos ilegibles. |

Por señal (`document-index`): `milestone_met_without_evidence` 21, `commitment_overdue` 8, `progress_vs_plan` 6, `declared_vs_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

## Carpeta al 2026-10-15

Los términos ya estaban vigentes (v0.3.10, aceptados por José Francisco Ñáñez el 2026-10-15), así que no hubo nada que registrar.

**Documentos:** 73 · **Sin cambio:** 50 · **Hay que releer:** 23

- **Cambió el contenido:** ninguno.
- **Solo se reguardó, renombrado o movido, ya no está:** ninguno.
- **Nuevos para el índice (23):** todos son de PRY-200. Son el contrato CT-235, el acta de constitución, los cronogramas v1 y v2, las actas de recibo, la factura, la solicitud de cambio, el informe de avance, 6 comités semanales y las notas del 15 de oct. Los otros 12 proyectos no tienen nada nuevo.
  - La ficha de PRY-200 ya cita estos documentos, pero el índice no los tenía registrados. Por eso salen como nuevos y no como cambiados.
- **Citas que dejaron de resolver:** el índice marca 250 de PRY-200, pero probablemente es un falso positivo y no lo verifiqué a fondo.
  - Las 14 fuentes distintas existen dentro de la carpeta de PRY-200. Son rutas relativas al proyecto, y el chequeo parece resolverlas contra la raíz de documentos.
  - Tres de esas rutas comparten nombre con archivos de otros proyectos. Conviene confirmar que apunten al de PRY-200: el PDF de licencias y permisos, el informe de avance y la solicitud de cambio CC-01.
- **Formatos que no se pudieron leer:** el índice no reporta ninguno. Solo compara hashes. Entre los nuevos hay un .docx, un .xlsx y un .pdf, y su lectura le toca al barrido.

**Siguiente paso:** correr `/portfolio-scan` limitado a PRY-200 (23 documentos). `projects_to_recompute` vino vacío, así que no hay otros proyectos por recomputar.

La corrida quedó registrada como `2026-10-15-document-index-1` y la salida está en `estado/corridas/salida-document-index.md`. La corrida midió el tiempo (30 s) pero no la cantidad de documentos.
