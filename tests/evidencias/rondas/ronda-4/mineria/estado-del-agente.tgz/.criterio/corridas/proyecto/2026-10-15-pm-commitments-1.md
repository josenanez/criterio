# Corrida · 2026-10-15-pm-commitments-1

**Agente:** Samuel (proyecto) · **Comando:** `/criterio-project:pm-commitments (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-15T20:46:26 · **Fin:** 2026-10-15T20:47:15 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `pm-commitments` | 1 | — | 32 | 18 | Reprogramados: Paula Céspedes (6 veces, documento 1) y Mauricio Pérez (5, prueba 2); 7 vencidos sin evidencia y 2 sin fecha; cuatro personas dicen haber entregado sin acta. |

Por señal (`pm-commitments`): `commitment_overdue` 7, `milestone_met_without_evidence` 4, `commitment_undated` 2, `commitment_rescheduled` 2, `progress_vs_plan` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

## Compromisos — Mantenimiento predictivo de camiones (PRY-200) · al 2026-10-15

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15), así que no los registré de nuevo. La ficha ya traía los compromisos extraídos de las minutas, y `compute` calculó las cifras.

**Se viene reprogramando**
- **Paula Céspedes · Enviar el documento 1.** Lo prometió para el 09-25 y lo movió seis veces: 10-12, 10-28, 11-14, 11-23, 12-09 y ahora 12-23. Cada comité le puso una fecha nueva. Es un bloqueo que nadie ha nombrado.
- **Mauricio Pérez · Cerrar la prueba 2.** Lo prometió para el 09-22 y lo movió cinco veces: 10-05, 10-20, 10-27, 11-17 y ahora 12-02. No se mencionó en las notas del 10-15.

**Vencidos sin evidencia (7)**

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| María Restrepo | Confirmar la fecha 7 | 09-20 | 25 días |
| Beatriz Cuéllar | Enviar el documento 9 | 09-20 | 25 días |
| Andrés Lozano | Validar el ambiente 4 | 09-27 | 18 días |
| Sandra Gil | Revisar el anexo 11 | 10-01 | 14 días |
| Ricardo Salas | Cerrar la prueba 18 | 10-06 | 9 días |
| Javier Hoyos | Cerrar la prueba 10 | 10-08 | 7 días |
| Diana Molina | Aprobar el diseño 21 | 10-11 | 4 días |

Cuatro personas dicen que ya entregaron, pero no hay ningún acta de recibo. Siguen abiertos.
- María Restrepo (confirmar la fecha 7, 09-17)
- Sandra Gil (anexo 11, 09-24)
- Beatriz Cuéllar (matriz 6, 09-24)
- Carlos Peña (diseño 5, 09-24)

Carlos Peña tiene como fecha vigente el 10-23, así que su compromiso aún no vence.

**Vencen esta semana**
- Ricardo Salas · Validar el ambiente 20, el 10-19.
- Carlos Peña · Entregar el punto 24, el 10-20.

**Sin fecha (2)**
- Beatriz Cuéllar · Actualizar la matriz 6, dicho el 09-10.
- Laura Vélez · Mandar el ajuste del presupuesto, dicho el 10-15. Dijo «la otra semana» y nadie puso fecha.

**Cerrados con documento (6):** anexo 3, punto 8, ambiente 12, matriz 14, documento 17 y anexo 19. Cada uno cita su acta de recibo.

**Siguiente paso:** puedo formular los dos reprogramados (Paula y Mauricio) como decisión para el comité del 2026-10-29. Dime si lo hago. Si quieres que la PMO vea esto en la ficha, corre `/pm-publish`.

La salida completa y la corrida quedaron registradas como `2026-10-15-pm-commitments-1`, en `estado/PRY-200-mantenimiento-predictivo-de-camiones/corridas/`. La corrida duró 32 segundos y encontró 18 señales.
