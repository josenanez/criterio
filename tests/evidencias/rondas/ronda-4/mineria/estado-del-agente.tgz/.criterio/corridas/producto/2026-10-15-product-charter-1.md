# Corrida · 2026-10-15-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4000

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4000

**Inicio:** 2026-10-15T20:41:17 · **Fin:** 2026-10-15T20:42:07 · **Duración:** 50 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 14 | — | 34 | 37 | Borrador de acta para REQ-4000. Sin criterios de aceptación, doliente, patrocinador, gerente ni autoridad: marcados como vacíos, no rellenados. Evidencia de demanda débil y de 14 meses. Ficha no creada: falta la firma. |

Por señal (`product-charter`): `evidence_stale` 12, `requirement_untraced` 11, `requirement_without_owner` 4, `requirement_without_acceptance` 4, `requirement_undecided` 3, `requirement_accepted_without_evidence` 2, `assumption_unverified` 1

## Lo que el agente mostró

Dejé el borrador del acta de REQ-4000, pero no creé la ficha del proyecto porque nadie ha firmado el acta. El acta tiene muchos vacíos y los marqué como vacíos, sin rellenarlos.

Los términos ya estaban vigentes (los aceptó José Francisco Ñáñez el 2026-10-15), así que no los registré otra vez. REQ-4000 es un requerimiento de PRD-300, el único producto configurado.

**Lo que falta en REQ-4000:**
- **Aceptación:** el comité de producto del 2026-10-14 lo tiene como aceptado.
- **Criterios de aceptación:** no tiene. Por eso el acta no puede decir cómo se juzgará el éxito.
- **Demanda:** solo hay una entrevista del 2025-08-18, con 14 meses de antigüedad (el umbral es 12). Dice «Lo necesito y hoy no lo tengo» y no nombra este requerimiento.
- **Autoridad:** la definición del producto no declara la autoridad del gerente del proyecto.
- **Responsables:** el requerimiento no tiene doliente, y el acta no nombra patrocinador, gerente propuesto, hitos ni presupuesto. Ni siquiera dice quién decidió aceptarlo: el comité solo escribió «Se mantiene el plan».
- **Supuesto:** «el ahorro se sostiene sin inversión adicional» sigue sin verificar desde el 2026-06-24. Pasa al proyecto como riesgo, a cargo de quien sea su gerente.
- **Normativa:** los documentos no citan ninguna restricción normativa, pero no hice un barrido, así que no puedo decir que no haya.

**Siguiente paso:** cuando el patrocinador (aún sin nombrar) firme, se crea la ficha. El gerente del proyecto que se asigne instala `criterio-project` y corre `/pm-setup`. Antes de firmar conviene cerrar los criterios de aceptación y el doliente.

Dejé la corrida registrada. Lo que te mostré está en `/home/claude/banco/ronda-4/mineria/espacio/estado-producto/PRD-300/corridas/salida-product-charter.md`.
