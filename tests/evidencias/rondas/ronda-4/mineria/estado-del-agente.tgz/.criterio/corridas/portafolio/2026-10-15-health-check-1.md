# Corrida · 2026-10-15-health-check-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:health-check PRY-200

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-15; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-15T21:02:58 · **Fin:** 2026-10-15T21:05:46 · **Duración:** 168 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `health-check` | 13 | — | 151 | 51 | Diagnóstico de PRY-200 sobre 23 documentos: 12 sostenidas, 16 sin sustento, 4 contradichas. Dijo que no sabe el estado real, el gasto real ni quién autoriza CC-01; no hay línea base vigente aprobada ni evidencia de 4 de 5 hitos. |

Por señal (`health-check`): `milestone_met_without_evidence` 21, `commitment_overdue` 8, `progress_vs_plan` 6, `declared_vs_evidence` 4, `commitment_undated` 3, `commitment_rescheduled` 2, `variance_cost` 2, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1, `variance_time` 1, `rebaseline_unauthorized` 1, `change_without_baseline` 1

## Lo que el agente mostró

El diagnóstico de PRY-200 está hecho y la corrida quedó registrada. No se puede decir cuál es el estado real del proyecto desde su carpeta.

Leí 23 documentos, del 2025-10-01 al 2026-10-15. Uno de ellos es la ficha del propio gerente, que traté como declaración y no como evidencia. Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (versión 1.1, 2026-10-15), así que no los registré de nuevo.

**Dictamen:** de 32 afirmaciones, 12 están sostenidas, 16 sin sustento y 4 contradichas.

- **Avance:** el informe dice «Amarillo» y 61%, pero el cronograma vigente marca los 5 hitos como cerrados, lo que equivale a 100% del plan. La diferencia es de 39.0 puntos.
- **Hitos:** solo uno de los 5 tiene documento de recibo. Los otros 4 llevan entre 125 y 326 días vencidos sin evidencia.
- **Fechas:** el cierre de 2026-05-13 nunca se movió en ningún documento, pero el último hito vigente es 2026-06-12. Hoy es 2026-10-15.
- **Línea base y autoridad:** el único cambio de fechas (Pruebas en operación, de 2026-04-24 a 2026-06-12) no tiene motivo ni aprobación. El acta tampoco declara la autoridad del gerente. La solicitud de cambio CC-01 (+49 días, 98.000.000 COP) está sin decidir. Ese corrimiento parece coincidir con los +49 días de CC-01, pero esa coincidencia es mi lectura de los textos; el script no la calculó.
- **Proveedor:**
  - Licenciamiento del software lleva 311 días vencido.
  - Calibración de sensores figura como recibida, pero no hay acta.
  - La factura FV-1235 (409.709.674 COP) cobra dos entregables y la carpeta tiene un acta.
- **Dinero:** las cifras vienen del informe de avance. Ningún documento respalda comprometido, ejecutado ni proyección. El aprobado sí lo respalda el acta.
- **Compromisos:** hay 7 vencidos sin evidencia, 2 reprogramados 6 y 5 veces, y 2 sin fecha.
- **Lo dicho y no registrado:** un riesgo del proveedor dicho en la reunión de hoy que nadie anotó, y 4 compromisos que dijeron haber entregado sin acta.

No recomendé detener, continuar ni reestructurar. Dejé ofrecidas dos salidas: preparar el punto de comité con la lista de lo que falta, o llevarle al gerente las 4 contradicciones como preguntas, una por una.

Los archivos están en `/home/claude/banco/ronda-4/mineria/espacio/estado/corridas/`:
- `salida-health-check.md`
- `2026-10-15-health-check-1.md`
