## Trazabilidad — Monitoreo de flota (PRD-300) · al 2026-10-15
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211). Los 3 requerimientos en estado «propuesto» (REQ-4008, REQ-4012, REQ-4013) no están decididos y no entran en la cadena.

### Decidido y nadie lo está construyendo
Los 11 requerimientos aceptados tienen `traces.project = null`: ninguno nombra un proyecto. El acta de decisión es `documentos/productos/PRD-300/30-decisiones/2026-10-14-comite-producto.docx` (2026-10-14); en ningún registro consta quién decidió (`decision.who` = no encontrado en los 11).

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4006 | Requerimiento REQ-4006 | 2026-04-12 | no consta |
| REQ-4004 | Requerimiento REQ-4004 | 2026-04-17 | no consta |
| REQ-4002 | Requerimiento REQ-4002 | 2026-04-20 | no consta |
| REQ-4007 | Requerimiento REQ-4007 | 2026-05-17 | no consta |
| REQ-4001 | Requerimiento REQ-4001 | 2026-05-20 | no consta |
| REQ-4009 | Requerimiento REQ-4009 | 2026-06-21 | no consta |
| REQ-4000 | Requerimiento REQ-4000 | 2026-06-24 | no consta |
| REQ-4003 | Requerimiento REQ-4003 | 2026-07-12 | no consta |
| REQ-4005 | Requerimiento REQ-4005 | 2026-07-26 | no consta |
| REQ-4011 | Requerimiento REQ-4011 | 2026-08-16 | no consta |
| REQ-4010 | Requerimiento REQ-4010 | 2026-08-27 | no consta |

El más antiguo lleva 186 días decidido sin proyecto (REQ-4006). Los títulos son genéricos porque el acta no los nombra.

### La traza no se confirma
Ninguna traza declarada existe todavía en el registro, así que no hay nada que confirmar ni desacuerdo entre registro y ficha. La cadena se rompe en el primer eslabón después de la decisión.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-200 · Mantenimiento predictivo de camiones | Sí: «monitoreo de flota», según `00-gobierno/2025-10-07-acta-constitucion.docx` (2025-10-07) | Cierto: ninguno de los 14 REQ nombra a PRY-200 |

Alguien está construyendo, según su propia acta de constitución, este producto, y el registro no lo sabe. Queda por ver si alguno de los 11 REQ decididos es lo que PRY-200 ejecuta; eso lo dice el alcance de PRY-200 y no se infiere desde aquí.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4000 | aceptado | comité 2026-10-14 (decidido 2026-06-24) | — | no | — |
| REQ-4001 | aceptado | comité 2026-10-14 (decidido 2026-05-20) | — | no | — |
| REQ-4002 | aceptado | comité 2026-10-14 (decidido 2026-04-20) | — | no | — |
| REQ-4003 | aceptado | comité 2026-10-14 (decidido 2026-07-12) | — | no | — |
| REQ-4004 | aceptado | comité 2026-10-14 (decidido 2026-04-17) | — | no | — |
| REQ-4005 | aceptado | comité 2026-10-14 (decidido 2026-07-26) | — | no | — |
| REQ-4006 | aceptado | comité 2026-10-14 (decidido 2026-04-12) | — | no | — |
| REQ-4007 | aceptado | comité 2026-10-14 (decidido 2026-05-17) | — | no | — |
| REQ-4009 | aceptado | comité 2026-10-14 (decidido 2026-06-21) | — | no | — |
| REQ-4010 | aceptado | comité 2026-10-14 (decidido 2026-08-27) | — | no | — |
| REQ-4011 | aceptado | comité 2026-10-14 (decidido 2026-08-16) | — | no | — |

### Sin fichas a la vista
Las 13 fichas están a la vista; no falta ninguna. Lo que dicen sobre el producto que ejecutan:
- Dice «monitoreo de flota»: PRY-200.
- Dice otro producto (no es desacuerdo con este): PRY-203 «despacho de flota», PRY-204 «alerta de taludes», PRY-207 «gemelo digital», PRY-208 «trazabilidad».
- No dice qué producto ejecuta (campo vacío en la ficha, hallazgo del lado del proyecto): PRY-201 y otras fichas con el producto «no encontrado». Si alguna de ellas ejecuta PRD-300, hoy no se ve.

### Después
Hay 11 decididos sin proyecto: `/product-charter` aplica al que ya esté listo para serlo. Con PRY-200 conviene una conversación con su gerente para ver si lo que ejecuta corresponde a alguno de los REQ decididos; no se le pide nada desde aquí y su ficha no se toca.
