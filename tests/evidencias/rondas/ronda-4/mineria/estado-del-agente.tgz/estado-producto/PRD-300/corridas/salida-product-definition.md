## Definición — Monitoreo de flota (PRD-300) · contrastada al 2026-10-15
**Documento:** `00-definicion/2025-11-14-definicion-producto.docx` y `00-definicion/2025-11-14-caso-de-negocio.md` · **del** 2025-11-14 · 6 afirmaciones

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición. Eso no significa que esté sostenida: ver más abajo.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| — | — | — | — | Ninguna pasa del umbral (20 %), porque no hay serie medida con la que comparar. |

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 210.767 | Caso de negocio, 2025-11-14 | No hay ninguna serie medida de `volumen_mensual` (`measured` = null en el cálculo). Nadie está midiendo lo que el negocio afirmó; no es una contradicción. |

### No está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo traen (`success`: no encontrado).
- **Qué es la propuesta.** La definición dice «Propuesta principal» y nada más: no hay contenido.
- **El retorno esperado.** El caso de negocio dice «Retorno esperado en 24 meses» sin monto, sin base de cálculo y sin medida con la que verificarlo.
- **De dónde sale el ahorro.** El supuesto habla de «ahorro» y ningún documento declara cuánto, contra qué ni cómo se mide.
- **Cuántos Operadores hay ni cuántos tienen el problema.** El tamaño del segmento no aparece. Tampoco hay de dónde sale 210.767 ni qué cuenta como «volumen».
- **Cuánto pagaría el cliente.** Ninguna afirmación ni evidencia sobre precio o disposición a pagar.
- **Quién decide que el producto se cierra.** El acta de comité (2026-10-14) nombra al «Comité de producto» como autoridad, pero la definición no dice quién aprueba el cierre ni con qué criterio.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El ahorro se sostiene sin inversión adicional (declarado el 2026-06-24 en la definición) | 113 (umbral: 30) | Declarar el ahorro como cifra y su línea base, y listar qué inversiones se excluyeron. Se verifica con el costo real de operación del primer periodo contra esa línea base. Escrito así, «sin inversión adicional» no se puede desmentir. Nota: la fecha del supuesto (2026-06-24) es posterior a la fecha de la definición (2025-11-14); la definición se editó después y conserva la fecha vieja. |

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Operadores no tiene monitoreo de flota | `10-descubrimiento/2025-08-18-entrevistas.md`: un «Cliente entrevistado» dice «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | 2025-08-18 | Débil. Es una sola frase de una sola persona sin nombre, sin segmento declarado y sin compromiso de compra. En la jerarquía de demanda es «alguien dijo que lo usaría», no «alguien pagó». |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El segmento Operadores no tiene monitoreo de flota | Entrevista del 2025-08-18 | 13 meses según el cálculo (umbral: 12) |

Las 12 señales de evidencia envejecida del registro de requerimientos remiten a esta misma entrevista: el acta de comité del 2026-10-14 pone a «Cliente entrevistado» como quien pidió cada requerimiento, pero la entrevista no nombra ninguno.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Monitoreo de flota puede implicar ubicación de vehículos y, por tanto, de conductores | No declarado en la configuración ni en los documentos | — | — | No tengo la norma a la vista. La definición no menciona datos personales, pagos ni retención, y no hay país, así que no hay obligación que nombrar o citar. Esto no es un cumplimiento: se revisa con jurídico. |

### Lo que falta para cerrar la definición
- **Criterio de éxito: falta.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él meses después.
- Problema: está (Operadores sin monitoreo de flota). Para quién: está (Operadores). Quién decide: está en el acta (Comité de producto).
- Proyectos que lo construyen: «Ninguno declarado». Los 11 requerimientos aceptados no tienen proyecto que los ejecute.

### Lo que se ve en el registro de requerimientos (contexto)
14 requerimientos (11 aceptados, 3 propuestos): 4 sin doliente, 4 sin criterio de aceptación, 2 aceptados sin evidencia (REQ-4002, REQ-4006), 11 sin proyecto, 3 propuestos sin decidir desde hace 80 a 175 días (REQ-4008, REQ-4012, REQ-4013).

### Después
- El supuesto del ahorro lleva 113 días sin verificarse: puede convertirse en riesgo con doliente (raid-taxonomy). Lo ofrezco, no lo registro.
- La definición no está cerrada (falta el criterio de éxito), así que no corresponde ofrecer `/product-charter`.
