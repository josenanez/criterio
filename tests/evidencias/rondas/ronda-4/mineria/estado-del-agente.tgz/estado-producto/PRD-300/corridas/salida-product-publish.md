No publiqué la ficha de PRD-300 (Monitoreo de flota): la configuración no tiene una carpeta de productos publicados. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No inventé una ruta.

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no se volvieron a registrar.

**Lo que habría llevado la ficha (corte al 2026-10-15):** 14 requerimientos · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Operadores
**Métricas:** volumen_mensual = 210767, del caso de negocio `documentos/productos/PRD-300/00-definicion/2025-11-14-caso-de-negocio.md` (2025-11-14); sin medición contra la que contrastarla.

Aviso para quien la lea: ninguno de los 14 requerimientos está ligado a un proyecto, así que el cruce por proyecto compartido no tendría nada que comparar.

Para publicar: acordar la carpeta común (por ejemplo `productos/publicados/`) y darme su ruta; entonces escribo `PRD-300.json` ahí.
