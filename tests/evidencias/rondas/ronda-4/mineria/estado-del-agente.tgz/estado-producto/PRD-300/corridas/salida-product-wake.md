## Monitoreo de flota (PRD-300) · 2026-10-15

**Desde el corte anterior:** no hay corte anterior. Esta es la primera revisión (`last: null`), así que no se puede decir qué cruzó un umbral desde entonces; lo que sigue es el estado de hoy, no una novedad. Los cortes de la próxima corrida sí permitirán distinguir lo nuevo.

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15). Documentos: 4, ninguno nuevo ni cambiado; solo se recalculó.

### Lo que necesita decisión
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Propuesto sin decidir | REQ-4013 | 175 días (desde 2026-04-23) | Una decisión de aceptar o rechazar | Comité de producto (doliente: Elena Duarte) |
| Propuesto sin decidir | REQ-4008 | 120 días (desde 2026-06-17) | Ídem | Comité de producto (doliente: Javier Hoyos) |
| Propuesto sin decidir | REQ-4012 | 80 días (desde 2026-07-27) | Ídem, y primero un doliente: no tiene | Comité de producto; doliente sin nombrar |
| Supuesto sin verificar: «El ahorro se sostiene sin inversión adicional» | definición | 113 días (umbral 30) | Quién y con qué dato lo verifica; ya pasó el punto en que conviene tratarlo como riesgo registrado | Beatriz Cuéllar (gerente del producto) |

Ofrezco llevar estos cuatro al comité. Quién tiene la facultad de decidir está en la configuración (Comité de producto); no consta en ningún documento que alguno se haya puesto en agenda.

### Aceptado y sin sustento
- **Sin ninguna evidencia de demanda:** REQ-4002 y REQ-4006, aceptados hace 178 y 186 días (decididos en abril de 2026).
- **Evidencia vencida (umbral 12 meses):** 12 requerimientos se apoyan solo en la entrevista del 2025-08-18, con 13 meses de antigüedad. Esa única entrevista dice «Lo necesito y hoy no lo tengo» (Necesidad principal) **sin nombrar ninguno de estos requerimientos**. La afirmación de la definición que se queda sin sustento es que existe demanda específica para cada uno.
- **Sin doliente:** REQ-4000, REQ-4003, REQ-4011, REQ-4012.
- **Aceptados sin criterio de aceptación:** REQ-4000, REQ-4002, REQ-4006, REQ-4011.

### Las trazas
Los 11 requerimientos aceptados figuran **sin proyecto** (`traced: 0 de 11`). Se revisó contra las 13 fichas de `estado/records` (PRY-199 a PRY-211); ninguna menciona PRD-300. No doy ninguna traza por confirmada: o nadie está construyendo lo aceptado, o la ficha del proyecto no lo dice.

### Del descubrimiento
Sin documentos nuevos. La única entrevista (2025-08-18) es la que envejece.

### Contradicción negocio vs. datos
El caso de negocio declara `volumen_mensual = 210.767` (2025-11-14), y **no hay medición** contra la cual contrastarlo. No se puede decir si coincide o no. Tampoco está declarado el criterio de éxito del producto (`success` = desconocido).

### Lo que no sé
- Qué se habló fuera de los documentos (por ejemplo, si el comité del 2026-10-14 trató alguno de estos puntos más allá de lo que quedó escrito).
- Si `estado/records` es toda la carpeta de fichas que corresponde; la configuración del producto no la indica y la tomé como tal.

Este comando no decidió nada, no verificó supuestos y no escribió a nadie.

**Vuelvo el 2026-11-14.**
