## Registro — Monitoreo de flota (PRD-300) · al 2026-10-15
14 requerimientos · 11 decididos · 81,8 % con evidencia · 0 % con proyecto que lo ejecute

Gerente de producto: Beatriz Cuéllar. Quien decide: Comité de producto.
Los títulos de las 14 fichas son el código repetido («Requerimiento REQ-40xx»): ninguna ficha dice todavía de qué trata su requerimiento.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4002 | Requerimiento REQ-4002 | aceptado el 2026-04-20 | Camilo Beltrán |
| REQ-4006 | Requerimiento REQ-4006 | aceptado el 2026-04-12 | Óscar Ramírez |

Aceptados sin una sola cita de quien los pidió. Los dos tienen además cero criterios de aceptación.

### Decidido y nadie lo está construyendo
Los 11 aceptados, sin proyecto asociado (0 % trazado):

| REQ | Decidido el | | REQ | Decidido el |
|---|---|---|---|---|
| REQ-4006 | 2026-04-12 | | REQ-4003 | 2026-07-12 |
| REQ-4004 | 2026-04-17 | | REQ-4005 | 2026-07-26 |
| REQ-4002 | 2026-04-20 | | REQ-4011 | 2026-08-16 |
| REQ-4007 | 2026-05-17 | | REQ-4010 | 2026-08-27 |
| REQ-4001 | 2026-05-20 | | REQ-4009 | 2026-06-21 |
| REQ-4000 | 2026-06-24 | | | |

El más antiguo lleva 186 días aceptado sin proyecto.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Estado | Dice |
|---|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | aceptado | doliente no encontrado |
| REQ-4003 | Requerimiento REQ-4003 | aceptado | doliente no encontrado |
| REQ-4011 | Requerimiento REQ-4011 | aceptado | doliente no encontrado |
| REQ-4012 | Requerimiento REQ-4012 | propuesto | doliente no encontrado |

Quién lo cierra: Beatriz Cuéllar nombra al doliente; si es un tema de cliente, lo confirma el Comité de producto. Ningún doliente aparece como área: los otros 10 son personas.

### Sin criterio de aceptación
Solo decididos:

| REQ | Título | Estado |
|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | aceptado |
| REQ-4002 | Requerimiento REQ-4002 | aceptado |
| REQ-4006 | Requerimiento REQ-4006 | aceptado |
| REQ-4011 | Requerimiento REQ-4011 | aceptado |

Quién lo cierra: el doliente de cada uno (REQ-4002 Camilo Beltrán, REQ-4006 Óscar Ramírez); REQ-4000 y REQ-4011 primero necesitan doliente. A los 3 propuestos no se les exige.

### Decidido sin documento que lo respalde
Ninguno sin documento: los 11 aceptados citan el acta `30-decisiones/2026-10-14-comite-producto.docx`. Dos cosas que conviene mirar de ese respaldo:
- Las fichas no registran **quién** decidió cada uno (el campo está vacío en las que se revisaron); solo consta el Comité de producto como instancia.
- El acta es del 2026-10-14, pero las fechas de decisión van del 2026-04-12 al 2026-08-27. No hay acta anterior en la carpeta que respalde esas fechas.

### Lleva meses y nadie lo decide
Umbral configurado: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4013 | Requerimiento REQ-4013 | 175 días (desde 2026-04-23) | Comité de producto |
| REQ-4008 | Requerimiento REQ-4008 | 120 días (desde 2026-06-17) | Comité de producto |
| REQ-4012 | Requerimiento REQ-4012 | 80 días (desde 2026-07-27) | Comité de producto |

Tienen dolientes (Elena Duarte, Javier Hoyos) salvo REQ-4012. Proponer una decisión —aceptar o descartar— en el próximo comité mensual; no se cierran por viejos.

### Evidencia vieja
Umbral configurado: 12 meses. 12 de los 14 requerimientos (los 9 aceptados con evidencia y los 3 propuestos) se sostienen en lo mismo: la entrevista del 2025-08-18, de hace 13 meses, que dice «Lo necesito y hoy no lo tengo.» y **no nombra ninguno de los requerimientos**. Es una sola evidencia genérica contada doce veces, no doce evidencias.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4000, 4001, 4003, 4004, 4005, 4007, 4008, 4009, 4010, 4011, 4012, 4013 | Entrevista 2025-08-18 | 13 meses |

### Además, en la definición del producto
- Criterio de éxito: no encontrado en ningún documento.
- Supuesto «El ahorro se sostiene sin inversión adicional»: sin verificar desde hace 113 días (umbral 30).
- Cifra declarada `volumen_mensual` = 210.767 (caso de negocio, 2025-11-14): sin medición que la contraste.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 11 | 0 | 0 | 0 |

Nada descartado: el registro solo ha crecido hacia «aceptado».

**Después:** hay 11 requerimientos decididos que nadie construye → `/product-trace`. Ninguno cumple hoy lo necesario para `/product-charter` (aceptado, con evidencia propia y con criterio); los candidatos más cercanos, con criterio y evidencia aunque genérica, son REQ-4001, 4003, 4004, 4005, 4007, 4009 y 4010 (REQ-4003 sin doliente).
