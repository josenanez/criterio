Términos vigentes (versión 1.1, familia 0.3.10), ya aceptados por José Francisco Ñáñez el 2026-10-15; no hizo falta registrarlos de nuevo. Configuración usada: `.criterio/producto/PRD-300/config.json` (único producto configurado; REQ-4000 es el requerimiento pedido).

## Verificación previa (requirement-record)

| Condición | Estado | Dónde se ve |
|---|---|---|
| Aceptado, no propuesto | **Cumple** | `comite-producto.docx` (2026-10-14): REQ-4000 · estado «aceptado» · desde 2026-06-24 |
| Criterios de aceptación verificables | **Falta** | El comité lista «—» en criterio de aceptación; el registro tiene `acceptance: []` |
| Evidencia de demanda con cita | **Débil** | Única entrevista (2025-08-18, `entrevistas.md`): «Lo necesito y hoy no lo tengo.» No nombra este requerimiento; tiene 14 meses (umbral de la configuración: 12) |
| Autoridad declarada en la definición | **Falta** para el proyecto | La definición (2025-11-14) no la declara; solo figura «Comité de producto» como autoridad del producto, tomada del acta del comité |

Respuesta sugerida tomada (nadie contesta en esta sesión): **seguir sin esos datos marcándolos como vacíos del acta, sin rellenarlos.**

---

# Acta de constitución — Monitoreo de flota, REQ-4000 · borrador del 2026-10-15
**Producto:** PRD-300 Monitoreo de flota · **Requerimientos:** REQ-4000

## Qué problema resuelve
«El segmento Operadores no tiene monitoreo de flota.» (`00-definicion/2025-11-14-definicion-producto.docx`). El requerimiento REQ-4000 en sí no tiene necesidad escrita: su título es solo «Requerimiento REQ-4000» y el campo necesidad está vacío. No se dice qué parte del problema resuelve.

## Criterio de éxito
**No está dicho.** REQ-4000 no tiene criterios de aceptación (`comite-producto.docx`, 2026-10-14: «—») y la definición del producto tampoco declara criterio de éxito. Sin esto el cierre no se podrá juzgar. Se registra como vacío; no se propone uno.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 | Quién lo pidió: «Cliente entrevistado» (acta del comité 2026-10-14). Entrevista del 2025-08-18: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal). No menciona este requerimiento y supera el umbral de antigüedad |

### No entra
Solo se incluyó REQ-4000; el resto no se evaluó para esta acta y no se decide su exclusión aquí. Del mismo comité, para que quien firme lo tenga a la vista:

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4001 a REQ-4013 | «Requerimiento REQ-40xx» | No se pidieron en esta acta. REQ-4008, 4012 y 4013 están «propuestos», no aceptados. El resto está aceptado y sin proyecto que lo ejecute. Esa exclusión, requerimiento por requerimiento y con razón, **la tiene que escribir quien firma**: los documentos no la dan |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Beatriz Cuéllar es gerente de **producto** (definición, 2025-11-14) y única asistente del comité del 2026-10-14. No se propone como gerente del proyecto: esa asignación no es de este comando.
- **Comité:** Comité de producto (`comite-producto.docx`, 2026-10-14).
- **Autoridad del gerente del proyecto:** no está dicha (monto, cambio de alcance).
- **Doliente del requerimiento:** «sin asignar» (comité 2026-10-14).
- **Quién decidió la aceptación:** no consta. La decisión del comité dice solo «Se mantiene el plan» y no nombra REQ-4000. La fecha de decisión que usa el registro (2026-06-24) no tiene fuente propia.
- **Proyecto que lo ejecuta:** «—» en el comité; la definición dice «Ninguno declarado».

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El ahorro se sostiene sin inversión adicional (declarado el 2026-06-24, definición 2025-11-14) | No (hace 113 días; umbral: 30) | Quien sea el gerente del proyecto, **sin doliente hoy**. Se registra como riesgo bajo raid-taxonomy cuando exista gerente |

Cifra del caso de negocio, solo como referencia: volumen_mensual declarado 210.767 (`caso-de-negocio.md`, 2025-11-14), sin contraste contra una medición. El caso cita «retorno esperado en 24 meses» sin cifra.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Ninguna identificada | — | — | Los documentos no mencionan datos personales, pagos ni retención, y no se hizo barrido normativo. «Sin restricciones citadas» no equivale a «sin restricciones» |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4000 | Sin criterio de éxito el cierre no se puede juzgar meses después | Doliente del requerimiento (hoy sin asignar) y gerente de producto |
| Doliente del requerimiento | Nadie responde por el criterio ni por el supuesto no verificado | Gerente de producto / Comité de producto |
| Necesidad del requerimiento (qué pide) | El proyecto arranca sin saber qué construir | Gerente de producto |
| Evidencia de demanda propia y vigente | La entrevista no nombra REQ-4000 y tiene 14 meses; el pedido descansa en una frase genérica | Gerente de producto (nueva ronda de entrevistas) |
| Quién decidió la aceptación | La decisión del comité no nombra el requerimiento | Comité de producto |
| Patrocinador con nombre | Sin persona a quien escalar | Comité de producto |
| Gerente propuesto y su autoridad | Todo se escala o nada se escala | Quien tenga la facultad de asignarlo |
| Criterio de éxito del producto | Ver arriba | Gerente de producto |
| Alcance excluido, requerimiento por requerimiento | La discusión del tercer mes | Quien firma |
| Presupuesto e hitos | Ninguno declarado en los documentos; no se inventan | Patrocinador |

---
**Esto es un borrador.** Lo firma el patrocinador, que **aún no está nombrado**. La ficha del proyecto se crea después de la firma.

## Lo que no se hizo
- **No se creó la ficha** (`portafolio.py init`): sin firma no corresponde.
- No se escribió el estado declarado ni se nombró gerente.
- No hay cronograma ni plan en el acta.

## Después
El gerente que se asigne al proyecto instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella y Alba sabrá si REQ-4000 se está construyendo. Antes de firmar conviene cerrar los vacíos de arriba, sobre todo criterios de aceptación y doliente.
