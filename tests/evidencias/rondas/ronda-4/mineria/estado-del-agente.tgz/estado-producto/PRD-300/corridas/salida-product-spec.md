# Especificación — Monitoreo de flota (PRD-300) · borrador del 2026-10-15

> **Esto es un borrador.** Lo cierra Beatriz Cuéllar (gerente de producto) con el Comité de producto como autoridad; este agente no aprueba ni firma.
> **Resultado en una línea: la especificación no se pudo redactar.** Los 11 requerimientos aceptados llegan al registro sin decir qué se necesita (todos se titulan «Requerimiento REQ-40xx» y ninguno tiene `need`). Escribir comportamiento sobre eso sería inventarlo, así que esta sección queda vacía a propósito y todo lo demás es la lista de lo que falta.

## Qué problema resuelve

«El segmento Operadores no tiene monitoreo de flota.» (`documentos/productos/PRD-300/00-definicion/2025-11-14-definicion-producto.docx`, 2025-11-14).

Eso es todo lo que la definición dice. La sección «La propuesta» solo trae «Propuesta principal», sin contenido. El criterio de éxito del producto **no está dicho en ninguna parte** (`definition.success`: not_found). Proyectos que lo construyen: «Ninguno declarado».

## Alcance

### Entra
Candidatos que salen del registro, **sin descripción posible** porque el registro no la tiene. Los 11 aceptados por el comité del 2026-10-14 (`30-decisiones/2026-10-14-comite-producto.docx`):

REQ-4000, REQ-4001, REQ-4002, REQ-4003, REQ-4004, REQ-4005, REQ-4006, REQ-4007, REQ-4009, REQ-4010, REQ-4011.

### No entra
- **REQ-4008, REQ-4012, REQ-4013**: siguen en `propuesto`. Nadie ha decidido nada sobre ellos, y especificarlos sería escribir el documento dos veces. REQ-4013 lleva 175 días propuesto (desde 2026-04-23), REQ-4008 lleva 120 y REQ-4012 lleva 80; los tres pasan el umbral de 60 días sin decisión (`undecided_days`). Eso es del comité, no de esta especificación.
- Todo lo que la definición no menciona. «Propuesta principal» no describe ninguna funcionalidad, así que no hay nada más que dejar dentro ni fuera.

## Comportamiento

**Sin secciones.** Ningún requerimiento dice el problema concreto que resuelve, y el acta del comité solo lista ID, doliente y estado. No se redacta comportamiento, ni casos borde (sin conexión, dato duplicado, etc.), porque no hay base en el registro para ninguno. Los casos borde quedan listados como vacío.

## Criterios de aceptación

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4001, 4003, 4004, 4005, 4007, 4009, 4010 | No dice qué se mide, con qué umbral ni quién lo mira: dos personas no llegarían a la misma respuesta. **No pasa la prueba de verificabilidad.** | No. No se sabe qué habría que medir. |
| *(sin criterio)* | REQ-4000, 4002, 4006, 4011 | — | — |

Los 11 aceptados tienen un criterio que no verifica nada o no tienen ninguno. Esto es un hallazgo, no un detalle: según el registro, un requerimiento aceptado exige criterio de aceptación.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El ahorro se sostiene sin inversión adicional» (definición; declarado el 2026-06-24, hace 113 días; el umbral es 30) | No | Beatriz Cuéllar. No hay ahorro cuantificado en el caso de negocio, y la frase no se puede desmentir como está escrita. |
| Que la frase de la entrevista («Lo necesito y hoy no lo tengo.», 2025-08-18) respalda cada uno de los 9 requerimientos que la citan como evidencia | No: la entrevista no nombra ninguno | Beatriz Cuéllar (realizó la entrevista) |

Nota de fecha: el supuesto figura «declarado el 2026-06-24» dentro de una definición fechada 2025-11-14. No se puede saber cuál de las dos fechas es la correcta.

Por superar `assumption_unverified_days`, el primero ya es un riesgo sin registrar: pasa a **raid-taxonomy** con doliente.

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué necesita cada requerimiento aceptado (los 11 sin `need`, con título genérico) | No hay qué especificar, construir ni aceptar | Beatriz Cuéllar, con el doliente de cada REQ donde lo hay |
| Doliente de REQ-4000, REQ-4003 y REQ-4011 («sin asignar» en el acta) | Nadie responde por la necesidad ni por el criterio | Beatriz Cuéllar asigna; el Comité de producto confirma |
| Criterio de aceptación de REQ-4000, 4002, 4006, 4011, y reescritura del de los otros 7 | Aceptado sin forma de saber si se cumplió | Doliente de cada REQ (Camilo Beltrán en 4002, Óscar Ramírez en 4006); Beatriz Cuéllar en 4000 y 4011 hasta que haya doliente |
| Evidencia de demanda de REQ-4002 y REQ-4006 (no tienen ninguna) | Aceptados sin que nadie haya demostrado que alguien los pidió | Camilo Beltrán (4002), Óscar Ramírez (4006) |
| La evidencia de los otros 9 es una sola entrevista de 2025-08-18, hace unos 14 meses (umbral: 12), de «Cliente entrevistado» sin nombre, y no nombra ningún requerimiento | La misma cita sostiene 9 requerimientos distintos; está vencida | Beatriz Cuéllar |
| Proyecto que ejecuta cada requerimiento: ninguno tiene traza; la definición dice «Ninguno declarado» | Aceptado sin nadie que lo construya, y no puede avanzar a acta de constitución | Comité de producto |
| Quién decidió la aceptación: el acta del 2026-10-14 no nombra quién decidió (`decision.who` vacío en los 11). Los «Desde» (2026-04-12 a 2026-08-27) son anteriores al acta y no hay documento que los respalde | La decisión no se puede rastrear a una persona | Comité de producto |
| Criterio de éxito del producto (no está dicho en ninguna parte) | Sin definir qué es éxito, ningún requerimiento puede sustentarse | Beatriz Cuéllar |
| Casos borde: ninguno definido porque no hay comportamiento descrito | Quedan decididos por quien construya | Beatriz Cuéllar, una vez haya necesidades escritas |
| Lo que otro equipo tiene que hacer: **no está dicho en ninguna parte.** No hay proyecto ni acuerdo documentado con otro equipo | Si hay dependencias, no se sabrán hasta que bloqueen | Beatriz Cuéllar |
| Cifra del caso de negocio: `volumen_mensual` = 210.767 sin unidad ni fuente distinta del propio caso; retorno «en 24 meses» sin monto | La especificación no puede dimensionar nada con eso | Beatriz Cuéllar (autora del caso); las cifras son del negocio |
| Obligaciones normativas: ver abajo | — | Revisión jurídica de la organización |

### Barrido normativo (solo nombrar, sin opinar sobre cumplimiento)

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| La definición no dice qué datos recoge el monitoreo (ubicación, conductores, telemetría) ni de quién | No dicho | Si incluye datos de personas (p. ej. operadores o conductores), tratamiento de datos personales | — | no tengo la norma a la vista |
| La definición no dice dónde se guardan los datos ni si salen del país | No dicho | Posible transferencia internacional si hay nube en otro país | — | no tengo la norma a la vista |
| Retención y trazabilidad de lo monitoreado | No dicho | Sin información en los documentos | — | no tengo la norma a la vista |

No se cita ninguna norma: ni el país ni los datos están en los documentos, y inventar una cita sería peor que dejar el vacío. Va a revisión jurídica como insumo; debe entrar al registro como restricción del requerimiento correspondiente cuando se sepa cuál.

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4000 | «Requerimiento REQ-4000» | Sin necesidad, sin doliente, sin criterio |
| REQ-4001 | «Requerimiento REQ-4001» | Sin necesidad; criterio no verificable |
| REQ-4002 | «Requerimiento REQ-4002» | Sin necesidad, sin criterio, sin evidencia |
| REQ-4003 | «Requerimiento REQ-4003» | Sin necesidad, sin doliente; criterio no verificable |
| REQ-4004 | «Requerimiento REQ-4004» | Sin necesidad; criterio no verificable |
| REQ-4005 | «Requerimiento REQ-4005» | Sin necesidad; criterio no verificable |
| REQ-4006 | «Requerimiento REQ-4006» | Sin necesidad, sin criterio, sin evidencia |
| REQ-4007 | «Requerimiento REQ-4007» | Sin necesidad; criterio no verificable |
| REQ-4009 | «Requerimiento REQ-4009» | Sin necesidad; criterio no verificable |
| REQ-4010 | «Requerimiento REQ-4010» | Sin necesidad; criterio no verificable |
| REQ-4011 | «Requerimiento REQ-4011» | Sin necesidad, sin doliente, sin criterio |

Cobertura: **0 de 11** aceptados.

## Lo que sigue

No se ofrece `/product-charter`: los vacíos no están cerrados, no hay criterio de éxito del producto ni proyecto que ejecute nada. El primer paso es que el gerente de producto escriba la necesidad de cada requerimiento aceptado y vuelva a correr esta especificación.

---
**Pie.** Sale del registro `estado-producto/PRD-300/requirements/` (14 requerimientos; 11 aceptados, 3 propuestos), actualizado el 2026-10-15; último documento leído: acta del comité del 2026-10-14. Cubre 0 de 11 requerimientos aceptados. Es un borrador para revisión del gerente de producto, no un dictamen jurídico. Términos (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-15): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.3.10
