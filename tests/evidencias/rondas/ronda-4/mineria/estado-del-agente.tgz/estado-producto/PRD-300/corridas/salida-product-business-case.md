# Caso de negocio — Monitoreo de flota (PRD-300) · borrador del 2026-10-15
**Desde:** la definición del 2025-11-14 y el caso de negocio del 2025-11-14 · **Cifras con fuente:** 1 de 1 (la única cifra tiene fuente, pero es declarada y sin medición)

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-15); no hizo falta registrarlos de nuevo.

> Con lo que hay escrito, esto no es todavía un caso de negocio: es una propuesta. Falta el costo de construir (el primer vacío), no hay criterio de éxito y la única cifra no tiene serie que la mida. No recomiendo aprobar ni rechazar; eso es del Comité de producto.

## Qué problema resuelve, y para quién
- **Problema:** «El segmento Operadores no tiene monitoreo de flota.» (`00-definicion/2025-11-14-definicion-producto.docx`, 2025-11-14)
- **Para quién:** Operadores (misma fuente). No hay cifra de cuántos son ni de cuántos tienen el problema.
- **Lo que lo sostiene:** una sola frase de «Cliente entrevistado», sin nombre ni segmento declarado: «Lo necesito y hoy no lo tengo.» (`10-descubrimiento/2025-08-18-entrevistas.md`, 2025-08-18). Evidencia débil y de hace 13 meses (umbral: 12).
- **La propuesta:** la definición dice «Propuesta principal» y nada más. No hay contenido.

## Qué se construye
Alcance: los 11 requerimientos decididos (aceptados), según el acta `30-decisiones/2026-10-14-comite-producto.docx`. Los 3 propuestos (REQ-4008, 4012, 4013) quedan fuera.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4000 | aceptado 2026-06-24 | «Cliente entrevistado» (genérico). Sin doliente, sin criterio de aceptación |
| REQ-4001 | aceptado 2026-05-20 | «Cliente entrevistado» (genérico). Doliente: Gustavo Neira |
| REQ-4002 | aceptado 2026-04-20 | **Ninguna.** Nadie lo pidió según el acta. Sin criterio. Doliente: Camilo Beltrán |
| REQ-4003 | aceptado 2026-07-12 | «Cliente entrevistado» (genérico). Sin doliente |
| REQ-4004 | aceptado 2026-04-17 | «Cliente entrevistado» (genérico). Doliente: Mauricio Pérez |
| REQ-4005 | aceptado 2026-07-26 | «Cliente entrevistado» (genérico). Doliente: Paula Céspedes |
| REQ-4006 | aceptado 2026-04-12 | **Ninguna.** Nadie lo pidió según el acta. Sin criterio. Doliente: Óscar Ramírez |
| REQ-4007 | aceptado 2026-05-17 | «Cliente entrevistado» (genérico). Doliente: Ricardo Salas |
| REQ-4009 | aceptado 2026-06-21 | «Cliente entrevistado» (genérico). Doliente: Felipe Arango |
| REQ-4010 | aceptado 2026-08-27 | «Cliente entrevistado» (genérico). Doliente: Paula Céspedes |
| REQ-4011 | aceptado 2026-08-16 | «Cliente entrevistado» (genérico). Sin doliente, sin criterio |

- Las fichas de los 14 requerimientos llevan por título el código repetido: ninguna dice de qué trata. Un caso de negocio no puede decir «qué se construye» con títulos así.
- La «evidencia» de los 9 que tienen quien lo pidió es una sola entrevista que no nombra ninguno: una evidencia genérica contada nueve veces, no nueve evidencias.
- Ninguno tiene proyecto que lo ejecute (0 % trazado). Las fechas de decisión (2026-04-12 a 2026-08-27) son anteriores al único acta (2026-10-14).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| `volumen_mensual` | 210.767 | **Declarada** | `00-definicion/2025-11-14-caso-de-negocio.md`, tabla «Cifras que sostienen el caso» (la fuente que cita es el mismo documento) | 2025-11-14 |
| Retorno esperado | «en 24 meses» | **Sin cifra.** Es una frase, no un valor | Mismo documento | 2025-11-14 |
| Ahorro | sin valor | **Supuesta.** Nadie la declara como cifra; solo existe en el supuesto de abajo | `00-definicion/2025-11-14-definicion-producto.docx` | supuesto fechado 2026-06-24 |

Qué no dice el documento sobre `volumen_mensual`: de dónde sale 210.767, qué se cuenta como «volumen» (¿transacciones, vehículos, eventos?) ni a qué mes se refiere. Entra como declarada, nunca como medida.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| — | — | — | No hay serie medida de `volumen_mensual`, así que no hay contraste ni diferencia que comparar con el umbral (20 %). No es una coincidencia: es que nadie está midiendo lo que el caso afirma. |

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No está en ningún documento** | — (vacío 1) |
| Contratos o cotizaciones | Ninguno a la vista | — |
| Costo del equipo | No declarado | — |

No hay proyecto que construya el producto («Ninguno declarado»), así que tampoco hay presupuesto de proyecto del que traerlo. Sin este costo no hay caso de negocio que evaluar: hay una propuesta.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| «El ahorro se sostiene sin inversión adicional» (declarado el 2026-06-24, sin verificar desde hace 113 días; umbral 30) | El único beneficio que el caso insinúa no existe, o exige una inversión que el caso no recoge en los costos. Escrito así no se puede desmentir: no dice cuánto ahorro, contra qué línea base ni qué inversiones se excluyen | Beatriz Cuéllar (gerente de producto) declara la cifra y la línea base; se contrasta con el costo real de operación del primer periodo |
| `volumen_mensual` = 210.767 se mantendrá como base del producto | Todo lo que dependa de volumen (ingresos, ahorro, dimensionamiento) queda sin base | Quien opera el sistema donde se mediría; hoy no se sabe quién es |
| La necesidad de «Cliente entrevistado» representa al segmento Operadores | La demanda de los 11 requerimientos no tiene respaldo | Beatriz Cuéllar, con entrevistas nuevas o con compromisos de compra |

Nota: la fecha del supuesto (2026-06-24) es posterior a la de la definición (2025-11-14); la definición se editó después y conserva la fecha vieja.

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| **Costo de construir** | Sin él no hay caso que evaluar | Quien vaya a construir; hoy no hay proyecto ni dueño |
| **Criterio de éxito, con métrica y fecha de corte** | Sin él el producto no se puede cerrar meses después | Beatriz Cuéllar; lo aprueba el Comité de producto |
| Origen y definición de `volumen_mensual` = 210.767 | Es la única cifra y no se puede reconstruir | Beatriz Cuéllar |
| Retorno esperado: monto y base de cálculo | «24 meses» sin monto no se puede verificar | El negocio (Beatriz Cuéllar) |
| Ahorro: cuánto, contra qué, cómo se mide | Es la razón de ser del supuesto | El negocio |
| Tamaño del segmento Operadores | No se sabe cuántos tienen el problema | El negocio |
| Cuánto pagaría el cliente | Sin precio ni disposición a pagar no hay ingreso que sustentar | El negocio / ventas |
| La propuesta (qué es el producto) | La definición no tiene contenido | Beatriz Cuéllar |
| Qué pasa si no se hace | No está dicho | El negocio |
| Alternativas consideradas | No están dichas | El negocio |
| País y datos personales (ubicación de vehículos y conductores) | Puede traer obligaciones normativas; no tengo la norma a la vista y esto no es un juicio de cumplimiento | Jurídico |
| Serie medida de `volumen_mensual` | Permitiría contrastar lo declarado | El sistema donde el producto viva; hoy no existe |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso de negocio traen criterio de éxito (`success`: no encontrado). Sin esto el producto no se puede cerrar: no habrá contra qué juzgarlo meses después. Falta la métrica, el valor objetivo y la fecha de corte.

## Si hay otros productos publicados
No hay ninguno publicado: PRD-300 es el único configurado en este espacio. Aun así leí la carpeta de documentos de PRD-299 a PRD-309 (sin ficha publicada, así que no es el cruce formal de `/product-overlap`) y ninguno afirma 210.767 ni cita `volumen_mensual` con ese valor. No encontré doble conteo de esta cifra. Cuando los demás publiquen, vale correr `/product-overlap`.

## Después
- Ofrezco pasar los 3 supuestos al seguimiento (assumption-tracking). El del ahorro lleva 113 días sin verificarse. Lo ofrezco, no lo registro.
- `/product-charter` no corresponde todavía: falta el criterio de éxito y el costo de construir, y ningún requerimiento cumple lo necesario (aceptado, con evidencia propia y con criterio).
