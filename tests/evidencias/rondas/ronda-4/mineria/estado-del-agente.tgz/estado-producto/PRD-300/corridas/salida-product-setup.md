Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

*(Sesión sin interfaz: tomé las respuestas sugeridas. Producto PRD-300 · Monitoreo de flota · gerente Beatriz Cuéllar · decide el Comité de producto · estado en `estado-producto/PRD-300`.)*

## Listo — Monitoreo de flota (PRD-300)

**Lo que miré:** 4 documentos · 1 de descubrimiento (una ronda de entrevistas, 2025-08-18, con un solo cliente citado) · la definición y el caso de negocio del 2025-11-14 · el acta del comité del 2026-10-14. No hay series de métricas ni transcripciones. Los dos .docx los leí.
**Términos:** aceptados para la versión 0.3.10 (términos 1.1) por José Francisco Ñáñez, 2026-10-15 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.3.10-2026-10-15.md` y `.pdf` · SHA-256 fdf0177cc54e5055… (md)
**Ficha levantada:** `producto.json` y 14 requerimientos (REQ-4000 a REQ-4013), tal como los dice el acta: 11 aceptados, 3 propuestos.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Operadores no tiene monitoreo de flota» | Una cita: «Lo necesito y hoy no lo tengo» (entrevistas, tema Necesidad principal). Un solo cliente sin nombre; la cita no dice que sea Operador ni que hable de flota | 2025-08-18 (13 meses) |
| «El ahorro se sostiene sin inversión adicional» | Solo un supuesto, declarado y sin verificar hace 113 días | 2026-06-24 |
| volumen_mensual = 210.767 | Solo el propio caso de negocio. Ninguna serie medida | 2025-11-14 |
| «Retorno esperado en 24 meses» | Nada: sin cifra, sin método, sin fuente | — |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo escribe.
- **La propuesta.** Dice «Propuesta principal» y nada más.
- **De dónde sale 210.767** ni qué mide: no hay serie. Nadie está midiendo lo que el negocio afirmó, y por eso no se puede contrastar.
- **Cuánto es el retorno ni cuánto el ahorro.** Ninguno tiene cifra.
- **Qué proyecto construye cualquiera de los 14 requerimientos.** Definición y acta dicen «ninguno declarado»: 0 de 14 con proyecto.
- **El criterio de aceptación** de REQ-4000, REQ-4002, REQ-4006 y REQ-4011, todos aceptados.
- **Una sola cita de quien lo pidió** en REQ-4002 y REQ-4006 (aceptados). Los otros 12 solo dicen «Cliente entrevistado».
- **Doliente** de REQ-4000, REQ-4003, REQ-4011 y REQ-4012 («sin asignar»).
- **Quién decidió** cada aceptación: el acta da la fecha del estado, no quién lo decidió.
- Las dos únicas decisiones del acta: «Se mantiene el plan», sin decir cuál.

### Supuestos sobre los que está escrita
Uno declarado: «El ahorro se sostiene sin inversión adicional» (2026-06-24, sin verificar, 113 días). Ojo: esa fecha es posterior a la de la definición (2025-11-14); el documento se tocó después de su fecha y no dice qué más cambió.

### Lo que el cálculo marca
- 12 de 14 requerimientos tienen la evidencia más nueva en 2025-08-18 (13 meses): todos se apoyan en la misma entrevista, que no nombra ningún requerimiento.
- 11 de 11 aceptados sin proyecto que los ejecute (0,0 % con traza).
- 3 propuestos sin decidir: REQ-4013 (175 días), REQ-4008 (120) y REQ-4012 (80).
- 2 aceptados sin evidencia (REQ-4002, REQ-4006): 81,8 % de los aceptados con evidencia, y esa evidencia es la misma cita.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: las transcripciones completas de las entrevistas (hay una cita); la serie medida de volumen_mensual con su fuente; el desglose del retorno y del ahorro; y las decisiones del comité con quién y por qué. Sin ellas, un requerimiento descartado se ve igual que uno que nadie miró.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para convertir los temas en requerimientos con la cita de quién los pidió.
