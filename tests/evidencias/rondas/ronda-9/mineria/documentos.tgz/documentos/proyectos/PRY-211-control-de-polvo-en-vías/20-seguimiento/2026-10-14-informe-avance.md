# Informe de avance · Control de polvo en vías

**Código:** PRY-211
**Fecha de corte:** 2026-10-14
**Gerente:** Liliana Torres

## Estado declarado

**Amarillo**

Avance reportado: **82%**

## Lo que pasó en el periodo

- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.310.630.831 |
| Ejecutado | 1.465.714.221 |
| Proyección al cierre | 4.009.341.481 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
