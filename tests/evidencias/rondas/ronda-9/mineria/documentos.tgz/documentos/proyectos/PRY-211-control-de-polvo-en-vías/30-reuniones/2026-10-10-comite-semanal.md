# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-19 |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-11-15 |
| Laura Vélez | Revisar el anexo 3 | 2026-11-03 |
| Andrés Lozano | Validar el ambiente 4 | 2026-11-14 |
| Diana Molina | Enviar el documento 9 | por definir |
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-10 |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |
| Paula Céspedes | Enviar el documento 17 | 2026-10-26 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-31 |
| Andrés Lozano | Validar el ambiente 20 | 2026-10-21 |
| Diana Molina | Aprobar el diseño 21 | 2026-10-25 |
| Camilo Beltrán | Actualizar la matriz 22 | 2026-10-28 |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-28 |
| Gustavo Neira | Entregar el punto 24 | 2026-11-01 |

## Cerrados en esta reunión

- Aprobar el diseño 13 (Rubén Cárdenas): recibido, acta de recibo del 2026-10-10.

## Lo que se dijo

- Felipe Arango dice que ya entregó «cerrar la prueba 18». No se presentó acta.
