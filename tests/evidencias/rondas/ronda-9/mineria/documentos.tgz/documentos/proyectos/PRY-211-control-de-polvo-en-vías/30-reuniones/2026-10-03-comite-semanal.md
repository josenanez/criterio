# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Felipe Arango, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-11-06 |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-11-02 |
| Laura Vélez | Revisar el anexo 3 | 2026-10-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-11-14 |
| Diana Molina | Enviar el documento 9 | por definir |
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 |
| Rubén Cárdenas | Aprobar el diseño 13 | 2026-11-01 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-10 |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |
| Paula Céspedes | Enviar el documento 17 | 2026-10-26 |
| Felipe Arango | Cerrar la prueba 18 | 2026-10-23 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-31 |
| Andrés Lozano | Validar el ambiente 20 | por definir |

## Cerrados en esta reunión

- Actualizar la matriz 6 (Ricardo Salas): recibido, acta de recibo del 2026-10-03.
- Confirmar la fecha 7 (Paula Céspedes): recibido, acta de recibo del 2026-10-03.
