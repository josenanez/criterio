# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Control de polvo en vías
**Fecha:** 2026-10-07
**Solicitante:** Liliana Torres

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +103 días sobre la línea base vigente |
| Costo | 206.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
