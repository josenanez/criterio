# Informe de avance · Electrificación de equipos

**Código:** PRY-209
**Fecha de corte:** 2026-10-09
**Gerente:** Andrés Lozano

## Estado declarado

**Verde**

Avance reportado: **82%**

## Lo que pasó en el periodo

- Se acordó con operaciones el plan de arranque de los equipos
- Se reprogramó la parada de planta por la ventana de mantenimiento

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 444.670.162 |
| Ejecutado | 268.110.385 |
| Proyección al cierre | 1.168.386.598 |

## Riesgos abiertos

- Bloqueo de la vía de acceso a la mina
