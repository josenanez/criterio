# Acta de constitución · Sistema de gestión de seguridad

**Código:** PRY-205
**Área dueña:** Seguridad y Salud
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** Rubén Cárdenas
**Comité:** Comité de Tecnología
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-05-27

## Objetivo del negocio

Entregar sistema de gestión de seguridad para Seguridad y Salud.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Tecnología el 2026-05-27.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-06 |
| Cierre | 2027-05-14 |

## Criterio de éxito

Sistema de gestión de seguridad en producción y medido.

## Dependencias declaradas

- Ninguna declarada
