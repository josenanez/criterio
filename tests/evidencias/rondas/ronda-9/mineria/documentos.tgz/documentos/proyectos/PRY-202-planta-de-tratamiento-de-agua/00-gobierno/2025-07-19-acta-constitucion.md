# Acta de constitución · Planta de tratamiento de agua

**Código:** PRY-202
**Área dueña:** Finanzas
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité Ambiental
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-07-19

## Objetivo del negocio

Entregar planta de tratamiento de agua para Finanzas.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Comité Ambiental el 2025-07-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-29 |
| Cierre | 2026-09-10 |

## Criterio de éxito

Planta de tratamiento de agua en producción y medido.

## Dependencias declaradas

- Ninguna declarada
