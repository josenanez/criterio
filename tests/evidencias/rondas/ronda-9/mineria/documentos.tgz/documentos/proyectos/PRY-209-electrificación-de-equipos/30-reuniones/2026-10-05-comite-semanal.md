# Comité de Seguridad · Electrificación de equipos

**Fecha:** 2026-10-05
**Asistentes:** Andrés Lozano, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Liliana Torres | Entregar el punto 4 | 2026-09-22 |
