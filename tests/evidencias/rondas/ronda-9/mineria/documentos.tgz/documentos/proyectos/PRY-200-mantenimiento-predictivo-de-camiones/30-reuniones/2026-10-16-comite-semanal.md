# Comité de Seguridad · Mantenimiento predictivo de camiones

**Fecha:** 2026-10-16
**Asistentes:** Gustavo Neira, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Beatriz Cuéllar | Entregar el punto 2 | 2026-11-04 |
| Paula Céspedes | Entregar el punto 29 | 2026-10-22 |
