# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Diana Molina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-28 |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-10-21 |
| Laura Vélez | Revisar el anexo 3 | 2026-10-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-10-28 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-11-10 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-27 |
| Diana Molina | Enviar el documento 9 | por definir |
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 |
| Rubén Cárdenas | Aprobar el diseño 13 | 2026-10-12 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-03 |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 |

## Cerrados en esta reunión

- Aprobar el diseño 5 (Jorge Medina): recibido, acta de recibo del 2026-09-26.
- Entregar el punto 8 (Jorge Medina): recibido, acta de recibo del 2026-09-26.
- Revisar el anexo 11 (Diana Molina): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- Javier Hoyos dice que ya entregó «cerrar la prueba 10». No se presentó acta.
