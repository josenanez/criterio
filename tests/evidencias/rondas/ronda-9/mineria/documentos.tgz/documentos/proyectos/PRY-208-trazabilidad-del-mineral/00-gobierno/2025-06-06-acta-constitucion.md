# Acta de constitución · Trazabilidad del mineral

**Código:** PRY-208
**Área dueña:** Mantenimiento
**Patrocinador:** Natalia Ospina
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Seguridad
**Producto asociado:** trazabilidad
**Fecha de aprobación:** 2025-06-06

## Objetivo del negocio

Entregar trazabilidad del mineral para Mantenimiento.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Seguridad el 2025-06-06.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-06-16 |
| Cierre | 2026-01-04 |

## Criterio de éxito

Trazabilidad del mineral en producción y medido.

## Dependencias declaradas

- Ninguna declarada
