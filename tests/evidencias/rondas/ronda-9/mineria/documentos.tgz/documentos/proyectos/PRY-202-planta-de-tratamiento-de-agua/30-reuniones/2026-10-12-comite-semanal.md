# Comité Ambiental · Planta de tratamiento de agua

**Fecha:** 2026-10-12
**Asistentes:** Andrés Lozano, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Mauricio Pérez | Entregar el punto 17 | 2026-11-07 |
| Liliana Torres | Entregar el punto 1 | por definir |
