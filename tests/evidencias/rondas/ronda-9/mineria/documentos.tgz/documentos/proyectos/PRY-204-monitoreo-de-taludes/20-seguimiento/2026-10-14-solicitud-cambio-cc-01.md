# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Monitoreo de taludes
**Fecha:** 2026-10-14
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +73 días sobre la línea base vigente |
| Costo | 146.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
