# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-09-19
**Asistentes:** Andrés Lozano, Diana Molina, Javier Hoyos, Jorge Medina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-20 |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-10-09 |
| Laura Vélez | Revisar el anexo 3 | 2026-10-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-10-28 |
| Jorge Medina | Aprobar el diseño 5 | 2026-09-15 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-24 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-27 |
| Jorge Medina | Entregar el punto 8 | 2026-09-26 |
| Diana Molina | Enviar el documento 9 | por definir |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-27 |
| Diana Molina | Revisar el anexo 11 | 2026-09-27 |
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 |
