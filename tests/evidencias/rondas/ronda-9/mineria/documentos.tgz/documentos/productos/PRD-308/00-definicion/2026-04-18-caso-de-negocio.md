# Caso de negocio · Permisos de trabajo digitales

**Código:** PRD-308
**Fecha:** 2026-04-18
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 236.678 | Caso de negocio, 2026-04-18 |

## Retorno esperado

Retorno esperado en 24 meses.
