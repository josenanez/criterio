# Comité de producto · Alerta de fatiga

**Fecha:** 2026-09-29
**Asistentes:** Óscar Ramírez

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4500 | Requerimiento REQ-4500 | Beatriz Cuéllar | se verifica en producción | — | aceptado | 2026-07-14 | — |
| REQ-4501 | Requerimiento REQ-4501 | Óscar Ramírez | — | Cliente entrevistado | propuesto | 2026-08-30 | — |
| REQ-4502 | Requerimiento REQ-4502 | Laura Vélez | se verifica en producción | — | aceptado | 2026-04-13 | — |
| REQ-4503 | Requerimiento REQ-4503 | sin asignar | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-02 | — |
| REQ-4504 | Requerimiento REQ-4504 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-03 | — |
| REQ-4505 | Requerimiento REQ-4505 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | propuesto | 2026-04-25 | — |
| REQ-4506 | Requerimiento REQ-4506 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-15 | — |
| REQ-4507 | Requerimiento REQ-4507 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-05-27 | — |
| REQ-4508 | Requerimiento REQ-4508 | Diana Molina | se verifica en producción | — | aceptado | 2026-08-24 | — |
| REQ-4509 | Requerimiento REQ-4509 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-11 | — |
| REQ-4510 | Requerimiento REQ-4510 | Diana Molina | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-11 | — |
| REQ-4511 | Requerimiento REQ-4511 | Rubén Cárdenas | — | Cliente entrevistado | aceptado | 2026-05-21 | — |
| REQ-4512 | Requerimiento REQ-4512 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-05-29 | — |
| REQ-4513 | Requerimiento REQ-4513 | Natalia Ospina | se verifica en producción | — | aceptado | 2026-06-05 | — |

## Decisiones

- Se mantiene el plan
