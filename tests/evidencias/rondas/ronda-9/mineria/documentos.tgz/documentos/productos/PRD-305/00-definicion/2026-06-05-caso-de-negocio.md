# Caso de negocio · Alerta de fatiga

**Código:** PRD-305
**Fecha:** 2026-06-05
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 297.533 | Caso de negocio, 2026-06-05 |

## Retorno esperado

Retorno esperado en 24 meses.
