# Caso de negocio · Despacho de flota

**Código:** PRD-302
**Fecha:** 2026-01-31
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 139.157 | Caso de negocio, 2026-01-31 |

## Retorno esperado

Retorno esperado en 24 meses.
