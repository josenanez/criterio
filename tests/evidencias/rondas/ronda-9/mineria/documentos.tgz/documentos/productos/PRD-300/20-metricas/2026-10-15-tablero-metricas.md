# Tablero de métricas · Monitoreo de flota

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-15

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 201.743 | 2026-10-15 |
