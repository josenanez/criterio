# Caso de negocio · Inspección con drones

**Código:** PRD-309
**Fecha:** 2025-11-05
**Preparado por:** Carlos Peña

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 83.626 | Caso de negocio, 2025-11-05 |

## Retorno esperado

Retorno esperado en 24 meses.
