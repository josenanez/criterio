# Entrevistas · Permisos de trabajo digitales

**Ronda:** Ronda · 2025-12-27
**Realizadas por:** Liliana Torres

### Cliente entrevistado · 2025-12-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
