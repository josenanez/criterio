# Tablero de métricas · Alerta de taludes

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-07

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 112.887 | 2026-10-07 |
