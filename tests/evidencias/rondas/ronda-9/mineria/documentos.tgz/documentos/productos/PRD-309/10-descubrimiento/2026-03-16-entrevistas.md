# Entrevistas · Inspección con drones

**Ronda:** Ronda · 2026-03-16
**Realizadas por:** Carlos Peña

### Cliente entrevistado · 2026-03-16

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
