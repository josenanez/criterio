# Caso de negocio · Alerta de taludes

**Código:** PRD-301
**Fecha:** 2026-07-15
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 149.227 | Caso de negocio, 2026-07-15 |

## Retorno esperado

Retorno esperado en 24 meses.
