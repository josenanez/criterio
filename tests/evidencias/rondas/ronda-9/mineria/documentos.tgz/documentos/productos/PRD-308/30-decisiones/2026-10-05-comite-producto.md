# Comité de producto · Permisos de trabajo digitales

**Fecha:** 2026-10-05
**Asistentes:** Liliana Torres

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Gustavo Neira | — | — | aceptado | 2026-05-05 | — |
| REQ-4801 | Requerimiento REQ-4801 | sin asignar | se verifica en producción | — | propuesto | 2026-06-27 | — |
| REQ-4802 | Requerimiento REQ-4802 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-28 | — |
| REQ-4803 | Requerimiento REQ-4803 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-4804 | Requerimiento REQ-4804 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-01 | — |
| REQ-4805 | Requerimiento REQ-4805 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-04 | — |
| REQ-4806 | Requerimiento REQ-4806 | sin asignar | se verifica en producción | — | aceptado | 2026-08-16 | — |
| REQ-4807 | Requerimiento REQ-4807 | Mauricio Pérez | — | Cliente entrevistado | aceptado | 2026-06-02 | — |
| REQ-4808 | Requerimiento REQ-4808 | Mauricio Pérez | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-17 | — |
| REQ-4809 | Requerimiento REQ-4809 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-04-16 | — |
| REQ-4810 | Requerimiento REQ-4810 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4811 | Requerimiento REQ-4811 | María Restrepo | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-03 | — |
| REQ-4812 | Requerimiento REQ-4812 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-06-11 | — |
| REQ-4813 | Requerimiento REQ-4813 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-30 | — |

## Decisiones

- Se mantiene el plan
