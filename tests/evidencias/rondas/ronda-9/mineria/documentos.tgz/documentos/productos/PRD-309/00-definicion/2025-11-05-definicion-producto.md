# Definición de producto · Inspección con drones

**Código:** PRD-309
**Gerente de producto:** Carlos Peña
**Segmento:** Operadores
**Fecha de la definición:** 2025-11-05

## El problema

El segmento Operadores no tiene inspección con drones.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-05-21 · verificado con la entrevista con doce clientes del segmento del 2026-06-22 (anexo «Verificación del supuesto» del 2026-06-22)

## Proyectos que lo construyen

- Ninguno declarado
