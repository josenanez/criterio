# Definición de producto · Gemelo digital

**Código:** PRD-303
**Gerente de producto:** Gustavo Neira
**Segmento:** Comunidad
**Fecha de la definición:** 2026-01-12

## El problema

El segmento Comunidad no tiene gemelo digital.

## La propuesta

- Propuesta principal

## Supuestos

- **El ahorro se sostiene sin inversión adicional** · declarado el 2026-05-07 · sin verificar

## Proyectos que lo construyen

- Ninguno declarado
