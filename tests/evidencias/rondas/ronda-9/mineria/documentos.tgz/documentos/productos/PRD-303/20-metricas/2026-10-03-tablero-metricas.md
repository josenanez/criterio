# Tablero de métricas · Gemelo digital

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-03

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 132.904 | 2026-10-03 |
