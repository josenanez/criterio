# Tablero de métricas · Permisos de trabajo digitales

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-03

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 225.065 | 2026-10-03 |
