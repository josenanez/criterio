# Caso de negocio · Monitoreo de flota

**Código:** PRD-300
**Fecha:** 2025-12-15
**Preparado por:** Camilo Beltrán

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 236.725 | Caso de negocio, 2025-12-15 |

## Retorno esperado

Retorno esperado en 24 meses.
