# Definición de producto · Despacho de flota

**Código:** PRD-302
**Gerente de producto:** Sandra Gil
**Segmento:** Mantenimiento
**Fecha de la definición:** 2026-01-31

## El problema

El segmento Mantenimiento no tiene despacho de flota.

## La propuesta

- Propuesta principal

## Supuestos

- **La red de la mina soporta el volumen** · declarado el 2026-08-27 · verificado con la entrevista con doce clientes del segmento del 2026-09-01 (anexo «Verificación del supuesto» del 2026-09-01)

## Proyectos que lo construyen

- Ninguno declarado
