# Caso de negocio · Trazabilidad

**Código:** PRD-304
**Fecha:** 2025-11-09
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 229.649 | Caso de negocio, 2025-11-09 |

## Retorno esperado

Retorno esperado en 24 meses.
