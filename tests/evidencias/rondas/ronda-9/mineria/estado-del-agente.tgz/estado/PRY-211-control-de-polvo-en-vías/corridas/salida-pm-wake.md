## Control de polvo en vías (PRY-211) · 2026-10-17

**Revisé:** 21 documentos · 0 cambiaron respecto de la ficha · 0 minutas nuevas (la única sin acta propia, `2026-10-17-notas-reunion.txt`, ya está extraída en la ficha: 26 compromisos).

El índice trae los 21 como «nuevos» porque es el primer barrido de este proyecto (`sweep.last` era nulo); todos ya estaban citados en la ficha, así que no releí ninguno.

### Lo que se venció solo
Nada nuevo desde las corridas de hoy. Siguen vencidos sin evidencia 5 compromisos (los de Liliana Torres, Javier Hoyos, Beatriz Cuéllar ×2 y Rubén Cárdenas, ya reportados en `/pm-commitments`). Los siguientes en vencer son el ambiente 20 de Andrés Lozano (2026-10-21) y la prueba 18 de Felipe Arango (2026-10-23).

### La reunión
Comité el 2026-10-31, a 14 días: aún no toca agenda. El informe toca el 2026-10-30. La reunión del 2026-10-17 ya tiene notas y sus compromisos están en la ficha.

### Tu ficha publicada
Al día: se publicó hoy (corte 2026-10-17) y no ha cambiado desde entonces.

**Vuelvo el 2026-10-18.**
