Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

*Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta.*
1. *Quién eres y qué proyecto es:* Liliana Torres, gerente de PRY-211 · Control de polvo en vías, según el acta de constitución.
2. *Reunión de seguimiento:* los sábados, cada semana (todas las minutas caen en sábado). Las notas del 2026-10-17 dicen «próxima reunión en dos semanas», así que anoté el 2026-10-31 como la próxima.
3. *Dónde guardo lo que encuentro:* `estado/PRY-211-control-de-polvo-en-vías`.
4. *Términos:* los mostré tal cual y quedaron aceptados a nombre de José Francisco Ñáñez, con el sí de la instrucción de la prueba.

## Listo — PRY-211 · Control de polvo en vías

**Lo que miré:** 20 documentos · 6 minutas del Comité Ambiental (2026-09-05 a 2026-10-10) más las notas de la reunión del 2026-10-17 · la más reciente es del 2026-10-17. Leí las 6 minutas completas, de la más vieja a la más nueva, y las 7 actas de recibo. Todos los formatos se pudieron leer.
**Términos:** aceptados para la versión 1.1 (familia 0.4.0) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 99704ec1070b8386…
**Cuántas preguntas hice:** 0 (sesión sin interfaz).

### Lo que está abierto, y cuántas veces se ha movido

26 compromisos en total: 6 cumplidos con acta de recibo y 20 sin cerrar. De esos 20: 5 vencidos, 2 sin fecha y 13 con fecha por delante.

**Los que se vienen moviendo (tres o más veces):**

| Quién | Qué | Fecha original → vigente | Veces movido | Cita |
|---|---|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-09-17 → 2026-12-03 | 6 (10-02, 10-20, 10-28, 11-06, 11-19, 12-03) | minuta 2026-09-05; la última fecha, de las notas 2026-10-17 («03/12/2026», leído día/mes) |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-10-02 → 2026-11-15 | 4 (10-09, 10-21, 11-02, 11-15) | minuta 2026-09-05 (entonces «por definir»); primera fecha en la del 2026-09-12 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-25 → 2026-11-14 | 3 (10-14, 10-28, 11-14) | minuta 2026-09-05 |

El documento 1 se prometió el 5 de septiembre para el 17 y va en el sexto cambio de fecha: más que un seguimiento flojo, parece un bloqueo que nadie ha nombrado.

**Vencidos sin evidencia (a 2026-10-17):**

| Quién | Qué | Debía | Días | Cita |
|---|---|---|---|---|
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 | 24 | minuta 2026-09-19; la fecha no se movió en las 3 minutas siguientes |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-27 | 20 | minuta 2026-09-19; el 09-26 dijo que ya lo entregó y no se presentó acta; después desaparece de la lista |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 | 11 | minuta 2026-09-26 |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-10 | 7 | minuta 2026-09-26 (movido una vez, del 10-03 al 10-10) |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 | 6 | minuta 2026-09-26 |

**Abiertos con fecha por delante (13; los 3 de arriba más estos 10):** Laura Vélez, Revisar el anexo 3 (2026-11-03, movido 2 veces) · Felipe Arango, Cerrar la prueba 18 (2026-10-23; dijo el 10-10 que ya lo entregó, sin acta) · Andrés Lozano, Validar el ambiente 20 (2026-10-21) · Paula Céspedes, Enviar el documento 17 (2026-10-26) · Laura Vélez, Revisar el anexo 19 (2026-10-31) · Diana Molina, Aprobar el diseño 21 (2026-10-25) · Camilo Beltrán, Actualizar la matriz 22 (2026-10-28) · Ricardo Salas, Confirmar la fecha 23 (2026-10-28) · Gustavo Neira, Entregar el punto 24 (2026-11-01) · Óscar Ramírez, Revisión con el proveedor (2026-10-27, notas 2026-10-17).

**Cumplidos con acta de recibo (6):** Aprobar el diseño 5 y Entregar el punto 8 (Jorge Medina), Revisar el anexo 11 (Diana Molina) y Aprobar el diseño 13 (Rubén Cárdenas), con acta del 2026-09-26 y del 2026-10-10; y Actualizar la matriz 6 (Ricardo Salas) y Confirmar la fecha 7 (Paula Céspedes), con acta del 2026-10-03. Cuando Javier Hoyos y Felipe Arango dicen que entregaron, no cuenta hasta que haya acta.

### Sin fecha
- Diana Molina — Enviar el documento 9. «Por definir» desde la minuta del 2026-09-19, cuatro minutas seguidas.
- Laura Vélez — Mandar el ajuste del presupuesto. Dijo «la otra semana» en la reunión del 2026-10-17; no lo convertí en fecha.

### Otras señales que levantó el cálculo
- **Tiempo:** el cierre pasó del 2026-08-17 (acta) al 2026-11-28 (cronograma v2): 103 días, 23,0 % sobre la línea base original. La CC-01 autorizó +103 días, así que ese corrimiento tiene un documento que lo autoriza.
- **Avance contra el plan:** el informe del 2026-10-14 declara 82 % y amarillo; el cronograma v2 marca los 5 hitos como cerrados. Son 18 puntos de diferencia.
- **Hitos cerrados sin acta:** 4 (Ingeniería básica, Ingeniería de detalle, Licencia y permisos, Montaje e instalación), entre 151 y 420 días de vencidos sin un documento que los pruebe.
- **Proveedor (CT-110, Servicios Ambientales del Norte):** Licenciamiento del software (debía 2025-09-26, 386 días) y Bolsa de horas de ingeniería (debía 2026-01-27, 263 días) siguen sin entregar. Calibración de sensores figura recibida en el contrato y no hay acta de recibo. El contrato dice que se factura contra esa acta, y la factura FV-1110 por 392.117.057 COP ya está radicada.
- **Presupuesto:** aprobado 4.200.000.000 COP; ejecutado 1.465.714.221 (34,9 %); comprometido 1.310.630.831 (31,2 %); proyección al cierre 4.009.341.481 (−4,5 % contra lo aprobado). Son las cifras del informe de avance; no las verifiqué contra otro documento.
- **Riesgo que nadie registró:** en las notas del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. El informe solo lista «concentración del conocimiento en una sola persona». Los dos quedaron en la ficha.

### Qué le falta a tu carpeta
- Minutas anteriores al 2026-09-05: la primera que hay ya trae 4 compromisos abiertos, así que hay reuniones previas que no están. Ahí puede estar el origen del documento 1.
- Actas de recibo de los 4 hitos cerrados y de la Calibración de sensores. Sin ellas, lo cumplido se ve igual que lo incumplido.
- Un acta de recibo (o su ausencia confirmada) para «Cerrar la prueba 10» y «Cerrar la prueba 18».
- El acta del comité que autorizó la CC-01: la solicitud dice «Autorizada por el comité» sin decir cuál ni en qué fecha.
- En el acta de constitución: hasta qué monto puedes decidir sin subir a comité (facultad) y en qué fase está el proyecto. Ninguno aparece en los documentos.
- Un riesgo registrado para lo que se dijo el 2026-10-17.

**Cuándo vuelvo:** el sábado 2026-10-31, la próxima reunión según las notas del 2026-10-17 (ahí hay que leer sus minutas).

*No sellé la ficha: leí las minutas y las actas del proyecto, pero no lo di por leído entero.*
