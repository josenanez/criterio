Sesión sin interfaz: nadie eligió qué escalar. Tomé la opción por defecto («lo que ya está marcado como escalable») y apliqué el criterio de la tabla. Las opciones y las recomendaciones son borrador mío para que Liliana Torres las confirme o las cambie; no las revisó nadie.

## Para decisión — PRY-211 Control de polvo en vías · 2026-10-17

Salieron cuatro puntos. El primero va antes que los otros, porque sin él no se sabe a quién van dirigidos.

### 1. ¿Quién tiene la facultad de decidir cambios de alcance, tiempo y costo en PRY-211? ¿El Comité Ambiental, la patrocinadora Paula Céspedes, o el gerente hasta qué monto y cuántos días?

**Quién decide:** Paula Céspedes como patrocinadora, o el Comité Ambiental. El acta no lo dice (`identity.authority`: no encontrada), así que esto es una inferencia mía. · **Si no se decide hoy:** el comité del **2026-10-31** (siguiente fecha de `config.json`) vuelve a decidir sin saber si le toca. Los puntos 2 y 3 se devuelven con un «eso no lo decide usted» o se deciden sin validez. Los documentos no traen otra fecha límite.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. La patrocinadora firma un anexo al acta con la autoridad del gerente (límites en días y COP) | Solo gobierno; no toca el alcance del proyecto | Sin dato; es un documento, no una obra | Sin cifra en los documentos |
| B. El Comité Ambiental declara la autoridad en su acta del 2026-10-31 | Igual que A | Hasta el 2026-10-31 | Sin cifra en los documentos |
| C. No se declara, y todo cambio sube al comité | Cada cambio pasa por comité | Cada cambio espera la sesión semanal | Sin cifra en los documentos |

**Recomiendo:** A. Es la más corta y deja la autoridad escrita antes de que el comité del 31 decida los puntos 2 y 3. B también sirve, pero obliga a que ese comité decida su propia facultad mientras decide lo demás.

### 2. CC-01 (+103 días, +206.000.000 COP): ¿el comité ratifica por escrito la aprobación, con comité y fecha, o se trata como no autorizada?

La solicitud dice «Autorizada por el comité» (2026-10-07). No dice cuál comité, ni la fecha, ni quién firmó. La línea base v2 (cierre 2026-11-28) se aprobó el 2026-10-14 sobre esa frase.

**Quién decide:** según el acta, no se puede afirmar; ver punto 1. · **Si no se decide hoy:** hay una línea base vigente (2026-11-28) apoyada en una autorización sin comprobante. Sigue así hasta el **2026-10-31**, y desde el 2026-08-17 la fecha original ya está vencida.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar CC-01 con acta del comité (nombre, fecha, firma) | Ampliación de alcance, sin cambio | Cierre 2026-11-28 (+103 días sobre 2026-08-17) | +206.000.000 COP; proyección 4.009.341.481 vs. aprobado 4.200.000.000 (el informe de avance no dice si ya incluye CC-01) |
| B. No ratificar; la línea base v2 queda sin respaldo y se vuelve a la v1 | Se pierde la ampliación | Cierre vuelve a 2026-08-17, ya vencido | Sin cifra en los documentos |

**Recomiendo:** A, si el comité efectivamente lo autorizó. La línea base anterior no se toca: la v1 sigue en el historial. Si nadie encuentra el acta, entonces el punto es de control de cambios, no de escalamiento.

### 3. Servicios Ambientales del Norte (CT-110): ¿se exige fecha firme para licenciamiento y bolsa de horas, o se inicia reclamación contractual?

El licenciamiento está pendiente desde 2025-09-26 (**386 días**). La bolsa de horas, desde 2026-01-27 (**263 días**). Valen 392.117.057 COP cada uno. Solo se ha facturado lo de la calibración (392.117.057). La calibración figura aceptada, pero sin acta de aceptación en la carpeta. En la reunión de hoy se comentó que el proveedor podría no llegar con el equipo completo a la siguiente fase, y nadie lo registró como riesgo. El doliente está fuera del proyecto.

**Quién decide:** el contrato condiciona el pago al acta de recibo del gerente. Quién puede exigir o reclamar al proveedor no está en el acta ni en el contrato que leí. · **Si no se decide hoy:** la revisión con el proveedor (Óscar Ramírez) es el **2026-10-27**, antes del comité. Sin posición acordada, se va con las manos vacías. Los documentos no dan fecha de vencimiento del contrato ni de ninguna oferta.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir en la revisión del 2026-10-27 fecha firme y por escrito para los dos entregables | Sin cambio | La fecha que el proveedor ofrezca; el cierre vigente es 2026-11-28 | Sin sobrecosto en los documentos |
| B. Iniciar reclamación contractual | Sin cambio | Sin dato | Sin dato; hasta 784.234.114 COP en entregables pendientes (2 × 392.117.057) |
| C. Esperar al comité del 31 | Sin cambio | Después de la revisión del 27 | Sin dato |

**Recomiendo:** A. Es lo que ya está agendado para el 27, y además registra el riesgo del equipo incompleto. B queda como respaldo para el comité si no hay fecha por escrito.

### 4. Reprogramados tres veces o más: ¿qué se hace con «Enviar el documento 1» (Ricardo Salas, 6 veces) y «Cerrar la prueba 2» (Rubén Cárdenas, 4 veces)?

El documento 1 pasó de 2026-09-17 a **2026-12-03**, que es **después del cierre vigente (2026-11-28)**. La prueba 2 pasó de 2026-10-02 a 2026-11-15. Para esta última no sé si hay doliente fuera del proyecto. Me falta saber de qué se tratan los dos.

**Quién decide:** el gerente, si ambos están dentro del proyecto. Este punto puede no escalar: si una llamada lo destraba, no sube. · **Si no se decide hoy:** el documento 1 ya se promete para después del cierre.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar una fecha tope antes del 2026-11-28 y cerrar la sesión de reprogramación | Sin cambio | Máximo 2026-11-28 | Sin dato |
| B. Aceptar el 2026-12-03 y mover el cierre | Sin cambio | Cierre pasa del 2026-11-28 al 2026-12-03 o más (nuevo cambio) | Sin dato |

**Recomiendo:** A. B es otro control de cambios, no un escalamiento.

### A quién alcanza
Hoy no sale ningún proyecto alcanzado. La ficha no declara dependencias («Ninguna declarada» en el acta) y el estado contiene solo PRY-211. `impact` se corrió con 103 días como comprobación y devolvió 0 alcanzados; ese cálculo suma los días al cierre actual (2027-03-11), así que no describe CC-01, que ya está en el cierre vigente. No hay un cambio nuevo propuesto, así que no hay efecto nuevo que calcular.

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno | — | — | — |

No sé cuántos días se mueve cada proyecto alcanzado: la ficha no trae holgura por actividad. Que el estado solo tenga este proyecto no prueba que no haya dependencias con otros; solo que no están declaradas.

### Mis hitos por los que pasa
Ninguno: los 5 hitos están marcados como cumplidos y la ficha no trae hitos pendientes. Ojo: los 5 cumplidos no tienen evidencia, y el último («Pruebas en operación», línea base 2026-08-17) figura cumplido con fecha vigente 2026-11-28, que aún no llega.

### De dónde sale esto
- Autoridad no declarada: `00-gobierno/2025-05-16-acta-constitucion.md` (no hay sección de autoridad ni de límites del gerente).
- CC-01 y su autorización: `20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md`; línea base v2: `10-plan/2026-10-14-cronograma-v2.xlsx`.
- Entregables, montos y condición de pago: `00-gobierno/2025-05-18-contrato-ct-110.md`; factura: `20-seguimiento/2026-08-30-factura-ct-110.pdf`.
- Riesgo del equipo del proveedor y la revisión del 2026-10-27: `2026-10-17-notas-reunion.txt`.
- Reprogramaciones: `30-reuniones/2026-09-05-comite-semanal.md` en adelante, más la nota del 2026-10-17.
- Próximo comité: `.criterio/proyecto/PRY-211/config.json` (2026-10-31).

---
Esto es un borrador. Llevarlo al comité es de Liliana Torres, y la llamada a quien corresponda también. Términos v1.1, aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
