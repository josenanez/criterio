Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

Recalculé antes de publicar (corte 2026-10-17). `plan.end_date` = 2026-11-28, tomada del cronograma v2 (2026-10-14), que es el más nuevo; la fecha original del acta (2026-08-17) queda en `plan.baseline` v1.

**Qué voy a publicar:** 19 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`). El estado que declara el proyecto es **amarillo** al 2026-10-14 (82 % de avance, declarado por la gerencia, no por la PMO). Esa declaración no recoge 6 señales que sí calculó Samuel: desviación de tiempo (+103 días, 23 %), avance contra plan, hitos cumplidos sin evidencia, compromisos vencidos, compromisos reprogramados y entregables de proveedor atrasados.

Publiqué la ficha en `documentos/proyectos/PRY-211-control-de-polvo-en-vías/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 19 campos con dato · 2 sin decir en ninguna parte · declara **amarillo** al 2026-10-14

**Lo más viejo que va ahí:** `identity.code` y otros 12 campos de identidad, plan y dinero, del 2025-05-16 (acta de constitución) — pasa de un año: 17 meses.

**Lo que conviene mirar antes de que lo lea la PMO:**
- El hito «Pruebas en operación» figura como cumplido (`met`) con fecha vigente 2026-11-28, que es futura. Los 5 hitos salen cumplidos, lo que da un plan que sostiene 100 % contra el 82 % declarado. Hay que corregir el estado de ese hito en el cronograma.
- 4 hitos cumplidos no tienen evidencia citada.
- CC-01 figura aprobado por «el comité», sin decir cuál ni en qué fecha.
