# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 38 s · 19 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 5 |
| `milestone_met_without_evidence` | 4 |
| `commitment_rescheduled` | 3 |
| `commitment_undated` | 2 |
| `vendor_deliverable_late` | 2 |
| `variance_time` | 1 |
| `progress_vs_plan` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Reprogramados: Ricardo Salas (6 veces, documento 1), Rubén Cárdenas (4, prueba 2), Andrés Lozano (3, ambiente 4); 5 vencidos sin evidencia; 2 sin fecha

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Compromisos — Control de polvo en vías (PRY-211) · al 2026-10-17

26 compromisos en la ficha: 20 abiertos o sin confirmar, 6 cerrados con documento. De los abiertos: 3 reprogramados, 5 vencidos sin evidencia, 2 sin fecha. Cifras de `portafolio.py compute`.

### Se viene reprogramando

> **Ricardo Salas** · Enviar el documento 1
> Prometido para el 2026-09-17, y antes para el 10-02, el 10-20, el 10-28, el 11-06, el 11-19 y ahora el **2026-12-03** (nota del 2026-10-17). **Seis reprogramaciones.**
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Rubén Cárdenas** · Cerrar la prueba 2
> Prometido para el 2026-10-02; luego 10-09, 10-21, 11-02 y ahora el **2026-11-15**. **Cuatro reprogramaciones.**
> Rubén también tiene vencido «Entregar el punto 16» (ver abajo).

> **Andrés Lozano** · Validar el ambiente 4
> Prometido para el 2026-09-25; luego 10-14, 10-28 y ahora el **2026-11-14**. **Tres reprogramaciones.** Alcanza el umbral de 3.

(Fuentes: `30-reuniones/2026-09-05` a `2026-10-10-comite-semanal.md` y `2026-10-17-notas-reunion.txt`.)

### Vencidos sin evidencia
| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 | 24 días |
| Javier Hoyos | Cerrar la prueba 10 | 2026-09-27 | 20 días |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 | 11 días |
| Beatriz Cuéllar | Actualizar la matriz 14 (ya reprogramado una vez, del 10-03 al 10-10) | 2026-10-10 | 7 días |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 | 6 días |

- **Javier Hoyos** dijo el 2026-09-26 que ya había entregado «cerrar la prueba 10»; no se presentó acta, y el compromiso desapareció de la tabla del comité del 10-10 sin cierre. Sigue abierto: no hay nada en el expediente que respalde la entrega.
- **Liliana Torres** es la gerente del proyecto; su compromiso vencido es de quien hace el seguimiento.

### Vencen esta semana (17 al 24 de octubre)
| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Validar el ambiente 20 | 2026-10-21 |
| Felipe Arango | Cerrar la prueba 18 | 2026-10-23 |

- **Felipe Arango** dijo el 2026-10-10 que ya entregó «cerrar la prueba 18»; no hay acta. Sigue abierto hasta que haya documento.
- Andrés Lozano llega a esta fecha con el ambiente 4 ya reprogramado tres veces.

### Sin fecha
| Quién | Qué | Dicho el |
|---|---|---|
| Diana Molina | Enviar el documento 9 | 2026-09-19 (en el comité del 10-10 sigue «por definir») |
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana») | 2026-10-17 |

No pueden estar vencidos; se cuentan aparte para que no desaparezcan. El de Diana lleva 4 semanas sin fecha.

### Cerrados desde la última revisión
Esta es la primera revisión de compromisos; se listan los cerrados con acta de recibo en el expediente.

| Quién | Qué | Documento |
|---|---|---|
| Jorge Medina | Aprobar el diseño 5 | `20-seguimiento/2026-09-26-acta-recibo-5.md` |
| Jorge Medina | Entregar el punto 8 | `20-seguimiento/2026-09-26-acta-recibo-8.md` |
| Diana Molina | Revisar el anexo 11 | `20-seguimiento/2026-09-26-acta-recibo-11.md` |
| Ricardo Salas | Actualizar la matriz 6 (reprogramado dos veces) | `20-seguimiento/2026-10-03-acta-recibo-6.md` |
| Paula Céspedes | Confirmar la fecha 7 (reprogramado una vez) | `20-seguimiento/2026-10-03-acta-recibo-7.md` |
| Rubén Cárdenas | Aprobar el diseño 13 (reprogramado una vez) | `20-seguimiento/2026-10-10-acta-recibo-13.md` |

### Contexto
El resto (Paula Céspedes doc. 17, 10-26; Diana Molina diseño 21, 10-25; Camilo Beltrán matriz 22, 10-28; Ricardo Salas fecha 23, 10-28; Óscar Ramírez revisión con el proveedor, 10-27; Laura Vélez anexo 3, 11-03 con 2 reprogramaciones; Laura Vélez anexo 19, 10-31; Gustavo Neira punto 24, 11-01) está abierto y a tiempo.

El informe de avance del 2026-10-14 declara amarillo y 82 %; no da cuenta de los vencidos ni de las reprogramaciones.

## Después

Ofrezco dos cosas, sin hacerlas:
1. **Formular como decisión para el comité** lo de Ricardo Salas (documento 1, seis reprogramaciones): qué se pide, qué pasa si no se decide y quién tiene la facultad. Excede la autoridad de la gerente y por eso sube. Los casos de Rubén Cárdenas y Andrés Lozano pueden ir en el mismo paquete.
2. **/pm-publish** para que la PMO vea los compromisos vencidos y reprogramados.
