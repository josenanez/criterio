# Plan — PRY-211 Control de polvo en vías · borrador del 2026-10-17
**Desde:** acta de constitución del 2025-05-16 (`00-gobierno/2025-05-16-acta-constitucion.md`) · **Criterio de éxito:** «Control de polvo en vías en producción y medido» (acta, sección Criterio de éxito) — declarado, pero sin ninguna métrica.

> Términos vigentes aceptados por José Francisco Ñáñez el 2026-10-17 (comprobante ya registrado, versión 0.4.0); no se registró de nuevo.
> Contexto: este proyecto ya está en ejecución y ya existen cronograma v1 (2025-05-16) y v2 (2026-10-14). Este borrador se construye desde el acta, como pide el comando, y no sustituye ni crea línea base. No se comprometió ninguna fecha.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío:** lista «Componente 1, Componente 2, Componente 3» (acta, Alcance) | No se puede descomponer por entregable: los tres nombres no dicen qué se recibe. La WBS de abajo no puede partir del alcance del acta y queda reconstruida desde el cronograma v1 y el contrato, que son supuestos. |
| **Fuera de alcance vacío:** «Lo que otro proyecto cubre» (acta) | No dice qué otro proyecto ni qué cubre; cualquier ampliación (como CC-01) no tiene contra qué compararse. |
| **Criterio de éxito sin medida:** «en producción y medido» | No hay qué medir, con qué umbral ni quién lo da por cumplido; el nodo final de pruebas queda sin criterio de aceptación. |
| **Autoridad del gerente no declarada** (la ficha la registra como no encontrada) | No se sabe qué puede decidir quien planifica y qué debe subir al comité o al patrocinador. |
| **Dependencias: «Ninguna declarada»** | Hay un contrato con proveedor (CT-110) y permisos ambientales (informe de avance 2026-10-14), así que «ninguna» es dudoso; se deja sin rellenar. |
| Sí está: patrocinador (Paula Céspedes), gerente (Liliana Torres), comité (Comité Ambiental), presupuesto (4.200.000.000 COP) y fechas de inicio y cierre. | — |

Se sigue marcándolo, como se pidió; nada de lo anterior se rellenó.

## WBS
Duración vacía en todos los nodos: ningún documento cita una duración. Las fechas del contrato y del cronograma v1 son fechas comprometidas por otros, no duraciones, y se citan solo como referencia.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Ingeniería básica aprobada | Sin definir | Supuesto: hito del cronograma v1 (`10-plan/2025-05-16-cronograma-v1.csv`, base 2025-08-23); no está en el acta | vacía |
| 2 | Ingeniería de detalle aprobada | Sin definir | Supuesto: hito del cronograma v1 (base 2025-11-21) | vacía |
| 3 | Licencia y permisos obtenidos | Sin definir | Supuesto: hito del cronograma v1 (base 2026-02-18); el informe de avance 2026-10-14 habla de un «permiso ambiental pendiente desde el trimestre anterior» sin decir cuál | vacía |
| 4 | Licenciamiento del software (CT-110) | Liliana Torres, firma el acta de recibo (contrato, Condición de pago) | Supuesto: contrato CT-110 (`00-gobierno/2025-05-18-contrato-ct-110.md`), comprometido 2025-09-26, 392.117.057 COP; no está en el acta | vacía |
| 5 | Bolsa de horas de ingeniería (CT-110) | Liliana Torres, ídem | Supuesto: CT-110, comprometido 2026-01-27, 392.117.057 COP | vacía |
| 6 | Calibración de sensores (CT-110) | Liliana Torres, ídem | Supuesto: CT-110, comprometido 2026-05-30, 392.117.057 COP | vacía |
| 7 | Montaje e instalación | Sin definir | Supuesto: hito del cronograma v1 (base 2026-05-19) | vacía |
| 8 | Pruebas en operación | Sin definir | Supuesto: hito del cronograma v1 (base 2026-08-17, igual al cierre del acta) | vacía |
| 9 | Control de polvo «en producción y medido» | Sin definir | **Del acta** (Criterio de éxito), pero sin métrica; no se vincula a los nodos 1–8 porque ningún documento lo hace | vacía |
| 10 | Contenido de la ampliación de alcance CC-01 | Sin definir | Sin definir: CC-01 (`20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md`) dice solo «Ampliación de alcance», +103 días, +206.000.000 COP | vacía |

Los nodos 1–8 son entregables solo en la medida en que alguien los reciba y acepte; el único aceptante citable hoy es el gerente en los tres del proveedor.

## Orden
Sin fechas. Lo que sí se desprende de los documentos:
- 1 → 2 → 3 → 7 → 8 es el orden en que aparecen en el cronograma v1; **que cada uno necesite al anterior es un supuesto**, el cronograma v1 no declara dependencias.
- 4, 5 y 6 (CT-110) no tienen dependencia declarada contra los otros nodos; en el contrato aparecen en orden de fecha comprometida (4 → 5 → 6).
- 9 depende de 8, supuesto.
- 10 no se puede ordenar: no se sabe qué agrega.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los cinco hitos del cronograma v1 son los entregables del proyecto | Faltan entregables no listados, y el cierre se mide contra una lista incompleta. |
| Los tres entregables de CT-110 son todos los del proveedor | Habría trabajo del proveedor sin contrato ni acta de recibo. |
| El orden 1 → 2 → 3 → 7 → 8 es de dependencia y no solo de calendario | Se serializa trabajo que podía ir en paralelo, o se paraleliza lo que no puede. |
| «Componente 1, 2, 3» del acta equivalen a los hitos o a los entregables de CT-110 | Si no, el alcance real y el escrito difieren, y no hay cómo detectar la diferencia. |
| El gerente puede aceptar los entregables del proveedor sin escalarlos (el contrato lo dice, el acta no declara autoridad) | Aceptaciones con efecto de pago hechas sin autoridad declarada. |

Estos pasan al RAID con doliente cuando el plan se apruebe (hoy el RAID de la ficha no tiene ningún supuesto registrado).

## Sin definir
| Qué | Quién lo define |
|---|---|
| Qué son Componente 1, 2 y 3 | Patrocinador (Paula Céspedes) con el gerente |
| Qué excluye «lo que otro proyecto cubre» y qué proyecto es | Patrocinador |
| Métrica y umbral de «medido» | Patrocinador / Comité Ambiental |
| Quién acepta los hitos de ingeniería, permisos, montaje y pruebas | Patrocinador |
| Autoridad del gerente al planificar | Patrocinador / Comité Ambiental |
| Dependencias del proyecto (proveedor, permisos, otros proyectos) | Gerente, con el patrocinador |
| Contenido, entregables y aceptante de la ampliación CC-01 | Comité (la solicitud dice «autorizada por el comité» sin decir cuál ni cuándo) |
| Cómo se reconcilia el cierre del acta (2026-08-17) con el cronograma v2 (2026-11-28) | Gerente y comité |

## Proyectos análogos
Ninguno a la vista: la configuración no apunta a una carpeta de fichas de la PMO y en el espacio de este proyecto no hay fichas de otros proyectos. Es la respuesta correcta y evita una falsa precisión; no se estima por analogía.

## Preguntas para el equipo
Una por cada duración vacía.
1. ¿Cuánto toma la ingeniería básica hasta su aprobación, y quién la aprueba?
2. ¿Cuánto toma la ingeniería de detalle, y quién la aprueba?
3. ¿Cuánto toma obtener la licencia y los permisos, y cuál es el «permiso ambiental pendiente» del informe del 2026-10-14?
4. ¿Cuánto toma el licenciamiento del software, y por qué consta como pendiente si su fecha comprometida era 2025-09-26?
5. ¿Cuánto toma la bolsa de horas de ingeniería y cuándo se considera consumida?
6. ¿Cuánto toma la calibración de sensores? (CT-110 la marca «recibido», pero en la carpeta no hay acta de recibo que lo sustente.)
7. ¿Cuánto toma el montaje e instalación con las lluvias que ya lo detuvieron diez días?
8. ¿Cuánto toman las pruebas en operación, y quién las acepta?
9. ¿Cuánto toma medir el control de polvo en producción, y con qué indicador?
10. ¿Cuánto toma la ampliación CC-01 y qué entrega exactamente?

## Para comprometer una fecha falta
- La disponibilidad real del equipo: ninguna fuente la da.
- La fecha del proveedor: CT-110 trae fechas de 2025–2026, y el 2026-10-17 se dijo en reunión que el proveedor podría no llegar con el equipo completo (notas de reunión); nadie las ha confirmado como vigentes.
- La ventana de operación donde se hacen pruebas y se mide: no está en ningún documento.
- El contenido de CC-01: sin él, +103 días no se puede ubicar en ningún nodo.
