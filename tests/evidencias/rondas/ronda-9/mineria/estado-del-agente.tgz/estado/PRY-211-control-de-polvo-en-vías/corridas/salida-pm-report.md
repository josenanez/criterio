Sesión sin interfaz: nadie respondió la pregunta del paso 2 (qué estado declara el gerente). No propuse ningún estado. La línea de declaración de abajo es la que Liliana Torres ya dejó en su informe de avance del 2026-10-14; no se reconfirmó en esta sesión.

# PRY-211 Control de polvo en vías — corte al 2026-10-17

**Declara el gerente:** amarillo · 82 % · al 2026-10-14 (hace 3 días; fuente: 20-seguimiento/2026-10-14-informe-avance.md). No se reconfirmó hoy.
**Sustento documental:** sin sustento pleno. Ningún dato de la ficha está marcado como evidencia (0 de 20 con evidencia, 0 declaración, 20 sin marcar). No hay contradicción de un verde, porque no se declara verde.
**Lo que el semáforo no explica:** compromisos vencidos, compromisos reprogramados, hitos cumplidos sin evidencia, avance contra plan, desviación de tiempo y entregables de proveedor vencidos.

## Qué cambió esta semana
No hay corrida anterior con la que comparar: el snapshot de hoy es el primero (`diff`: 0 cambios). Todo lo de abajo es línea base de la primera corrida, no novedad.

## Lo que sigue igual y sigue mal
| Qué | Desde | Días así |
|---|---|---|
| Licenciamiento del software (Servicios Ambientales del Norte), pendiente | 2025-09-26 | 386 |
| Bolsa de horas de ingeniería (mismo proveedor), pendiente | 2026-01-27 | 263 |
| Hito «Ingeniería básica aprobada» cumplido sin evidencia | 2025-08-23 | 420 |
| Hito «Ingeniería de detalle aprobada» cumplido sin evidencia | 2025-11-21 | 330 |
| Hito «Licencia y permisos obtenidos» cumplido sin evidencia | 2026-02-18 | 241 |
| Hito «Montaje e instalación» cumplido sin evidencia | 2026-05-19 | 151 |

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-08-17 (derivada: vigente menos 103 días) | 2026-11-28 | +103 días (23 %) contra la original; 0 contra la vigente |
| Presupuesto | sin línea base original de costo en el cálculo | 4.200.000.000 COP aprobado | proyección 4.009.341.481 COP (−4,5 %) |

Replanificaciones: 1. Una solicitud de cambio aprobada movió la línea base 103 días; sin días no autorizados. No leí las fechas ni los motivos declarados en el cálculo; hay que verificarlos en el control de cambios.

Avance declarado 82 % contra un plan que da 100 % (5 de 5 hitos cumplidos): brecha de 18 puntos, y el proyecto aún no cierra. Los hitos no explican el 82 %.

### Hitos de las próximas cuatro semanas
Sin dato: los 5 hitos figuran cumplidos y el cálculo no trae ningún hito pendiente. El cierre vigente es el 2026-11-28, dentro de 6 semanas.

## Las cifras
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 | 1.310.630.831 (31,2 %) | 1.465.714.221 (34,9 %) | 4.009.341.481 | 2.889.369.169 |

Disponible real = aprobado menos comprometido. Ojo: lo ejecutado supera lo comprometido en 155 millones; hay que explicarlo (gasto sin compromiso registrado). Proveedor: facturado 392.117.057 = aceptado 392.117.057.

## Abierto
**Reprogramados:**
- Ricardo Salas, «Enviar el documento 1»: 6 veces (original 2026-09-17, hoy 2026-12-03).
- Rubén Cárdenas, «Cerrar la prueba 2»: 4 veces (original 2026-10-02, hoy 2026-11-15).
- Andrés Lozano, «Validar el ambiente 4»: 3 veces (original 2026-09-25, hoy 2026-11-14).

**Vencidos sin evidencia:**
- Liliana Torres, «Validar el ambiente 12»: vencido 2026-09-23 (24 días).
- Javier Hoyos, «Cerrar la prueba 10»: 2026-09-27 (20 días).
- Beatriz Cuéllar, «Confirmar la fecha 15»: 2026-10-06 (11 días).
- Beatriz Cuéllar, «Actualizar la matriz 14»: 2026-10-10 (7 días).
- Rubén Cárdenas, «Entregar el punto 16»: 2026-10-11 (6 días).

**Sin fecha:** Diana Molina, «Enviar el documento 9»; Laura Vélez, «Mandar el ajuste del presupuesto» («la otra semana»).
**RAID sin movimiento:** sin dato en el cálculo.
**Proveedor (Servicios Ambientales del Norte, CT-110):** 2 entregables vencidos (licenciamiento 386 días, bolsa de horas 263 días); «Calibración de sensores» aceptado sin documento de aceptación; 1 de 3 aceptado.

## Lo que necesito de alguien
- Liliana Torres: declarar estado y avance hoy; la declaración del 14 de octubre no explica 6 señales.
- Ricardo Salas: el documento 1, reprogramado 6 veces. Cumple el umbral de 3, así que es material de comité.
- Rubén Cárdenas: la prueba 2, reprogramada 4 veces. También material de comité.
- Diana Molina y Laura Vélez: fecha para sus compromisos.
- Servicios Ambientales del Norte: el acta de aceptación de la calibración y fechas para los 2 entregables vencidos.
- Quien corresponda: evidencia de los 4 hitos cumplidos sin soporte; explicación de lo ejecutado por encima de lo comprometido.

## Lo que no se sabe
**Sin dato:** autoridad (identity.authority) y fase (identity.phase); fechas de las replanificaciones y sus motivos. Otros 13 campos tienen fuente de hace 17 meses (2025-05-16): identidad, inicio, alcance, exclusiones, moneda y presupuesto aprobado.
**Silencio:** días desde el último documento y desde la última reunión: el cálculo devuelve null. Hay una nota de reunión fechada 2026-10-17 y un informe de avance del 2026-10-14.

---
Fuente: ficha PRY-211, corte 2026-10-17; 2 campos sin dato, 13 con fuente antigua. Términos v1.1, aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
