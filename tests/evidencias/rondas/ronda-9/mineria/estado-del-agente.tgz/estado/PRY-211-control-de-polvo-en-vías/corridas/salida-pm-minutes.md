# Acta — Control de polvo en vías (PRY-211) · 2026-10-17
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en el expediente, así que no se puede decir. Con compromisos abiertos y sin estar presentes: Felipe Arango, Javier Hoyos.

Nota: Óscar Ramírez asiste por primera vez en lo que el expediente registra (no estaba el 2026-10-10).

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-12-03 | **Reprogramado 6 veces.** Original 2026-09-17; la fecha anterior era 2026-11-19. Nota: «no alcanzó». |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Primera fecha. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto («la otra semana»). Sin día; no se le inventa fecha. |
| Diana Molina | Enviar el documento 9 (de 2026-09-19, sigue sin fecha; no se habló hoy) |

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace con el documento 1 tras la sexta reprogramación | Las notas solo recogen la nueva fecha, sin motivo ni decisión | No consta en las notas |

## Intenciones sin doliente
Ninguna en estas notas.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase | No consta: las notas dicen «se comentó» | Riesgo | No («nadie lo anotó como riesgo»). Entra al RAID con dueño `no_identificado`. |

Con el proveedor Servicios Ambientales del Norte (CT-110) ya hay dos entregables pendientes vencidos (386 y 263 días), así que este comentario no cae en terreno limpio.

## Cerrado en esta reunión
Nada. Sin documento no se cierra nada. No se presentó ningún documento nuevo.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-31) | Comité semanal | Notas 2026-10-17 · `config.json` (cycle.committee = weekly). Coincide con `committee_next` 2026-10-31, pero no con «semanal». Confirma cuál rige. |
| Fin del proyecto | Ricardo se compromete para 2026-12-03 | Línea base v2 termina 2026-11-28 | Notas 2026-10-17 · cronograma v2, 2026-10-14. El compromiso cae **5 días después del cierre**. |

No cambió patrocinador, comité ni fecha de cierre; no hay campo de la ficha por corregir.

## Sin resolver de la transcripción
- «03/12/2026» (Ricardo Salas): se lee 3 de diciembre (día/mes), porque el resto de fechas va en ISO y 12 de marzo ya habría pasado. Confirma con Ricardo.
- «la otra semana» (Laura Vélez): no se sabe si es la semana del 19 o la del 26 de octubre.
- «se comentó que el proveedor podría no llegar…»: no se sabe quién lo dijo ni de qué proveedor/fase habla (se asume CT-110, sin confirmar).
- Óscar Ramírez: «revisión con el proveedor, queda para el 2026-10-27»: la nota no dice si él hace la revisión o la recibe. Se registra como suya.

## Seguimiento tras esta reunión (calculado)
- Vencidos sin evidencia (5): Javier Hoyos (prueba 10, 20 días), Liliana Torres (ambiente 12, 24 días), Beatriz Cuéllar (matriz 14, 7 días; fecha 15, 11 días), Rubén Cárdenas (punto 16, 6 días).
- Sin fecha (2): Diana Molina, Laura Vélez.
- Reprogramados: Ricardo Salas (6), Rubén Cárdenas (4: prueba 2), Andrés Lozano (3: ambiente 4).

Siguiente: `/pm-commitments` para el seguimiento completo. No hace falta `/pm-publish` por esta acta: ningún campo de la ficha cambia, aunque conviene correrlo para que la PMO vea el riesgo nuevo.

*El acta sale aquí y la guardas tú: Samuel no la escribe en tu carpeta de reuniones.*
