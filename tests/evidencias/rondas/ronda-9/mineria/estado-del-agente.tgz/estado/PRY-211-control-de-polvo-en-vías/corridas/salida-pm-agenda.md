## Reunión de seguimiento — Control de polvo en vías (PRY-211) · 2026-10-31
8 puntos · 42 minutos (de 45 supuestos) · 8 personas requeridas

Supuestos que no están en la configuración ni en el argumento: la fecha es la del próximo comité (`committee_next` 2026-10-31) y la duración es de 45 minutos. Si cambia alguna, se reordena. Esta es la primera corrida: no hay foto anterior (`diff` → baseline), así que «lo que cambió» se tomó de las minutas del 2026-09-05 al 2026-10-17 y de la ficha.

### Lo que no se destraba solo

> **[1] Qué se hace con el documento 1: quién lo destraba y si la fecha cabe en el proyecto** · 10 min · **Ricardo Salas, Liliana Torres, Paula Céspedes (patrocinadora)**
> Prometido para el 2026-12-03, y antes para el 11-19, el 11-06, el 10-28, el 10-20 y el 10-02, y originalmente el 2026-09-17. **Seis reprogramaciones.**
> Fuente: `2026-10-17-notas-reunion.txt` (nota «no alcanzó»); historial en `30-reuniones/2026-09-05` a `2026-10-10-comite-semanal.md`
> **Que quede resuelto:** el motivo concreto del bloqueo, nombrado; quién lo puede quitar; y una fecha que cabe antes del 2026-11-28 (fin de la línea base v2, `10-plan/2026-10-14-cronograma-v2.xlsx`) o la decisión de subirlo a comité. La fecha del 12-03 cae cinco días después del cierre. Las notas del 10-17 no registran motivo ni decisión.
> **Si no se resuelve hoy:** sale una séptima fecha, y el proyecto cierra con un entregable comprometido después de su propio fin. Si el bloqueo excede la autoridad de la gerente, `/pm-escalate`.
> Aviso: la fecha «03/12/2026» se leyó como 3 de diciembre; confírmala con Ricardo antes de la reunión.

> **[2] Prueba 2 y punto 16 de Rubén Cárdenas** · 5 min · **Rubén Cárdenas**
> Prueba 2: prometida para el 2026-11-15; antes el 11-02, el 10-21, el 10-09 y el 10-02. **Cuatro reprogramaciones.** Punto 16: vencido desde el 2026-10-11, sin evidencia.
> Fuente: comités del 09-05 al 10-10; `30-reuniones/2026-10-10-comite-semanal.md`
> **Que quede resuelto:** si la prueba 2 tiene fecha firme y qué la ha movido cuatro veces; y el acta o la nueva fecha del punto 16.
> **Si no se resuelve hoy:** la prueba 2 llega a cinco reprogramaciones y entra en la ventana del 11-28.

> **[3] Ambiente 4 de Andrés Lozano** · 3 min · **Andrés Lozano**
> Prometido para el 2026-09-25; antes el 10-14 y el 10-28; hoy el 2026-11-14. **Tres reprogramaciones.** Además, el ambiente 20 vencía el 10-21.
> Fuente: comités del 09-05 al 10-10
> **Que quede resuelto:** qué lo bloquea y si el 11-14 se sostiene. El ambiente 20 se confirma con el acta, ver [7].
> **Si no se resuelve hoy:** pasa a cuatro reprogramaciones.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Liliana Torres | Validar el ambiente 12 | 2026-09-23 (24 días al 10-17) | Documento de validación o fecha nueva. Es de la gerente: no se deja para el final | 4 |
| Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 (11 días) | Fecha confirmada por escrito | (en el mismo bloque) |
| Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-10 (7 días; ya reprogramada una vez, del 10-03) | Matriz actualizada o fecha nueva | (en el mismo bloque) |

Fuente: `30-reuniones/2026-10-10-comite-semanal.md`. El punto 16 de Rubén Cárdenas va en [2].

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| **[4]** Cadencia: las notas del 10-17 dicen «próxima reunión en dos semanas» y la configuración dice comité semanal. Y la fecha de cierre frente al compromiso del 12-03 | Liliana Torres | Se sigue sin saber si el siguiente seguimiento es el 11-07 o el 11-14, y los vencimientos de noviembre se revisan tarde | 4 |
| **[5]** Contrato CT-110 y riesgo del proveedor. Servicios Ambientales del Norte tiene dos entregables pendientes y vencidos: licenciamiento del software (2025-09-26, 386 días al 10-17) y bolsa de horas de ingeniería (2026-01-27, 263 días). La calibración de sensores figura como aceptada y no hay documento de aceptación en el expediente; el expediente muestra facturado 392.117.057 COP, el monto de un entregable (`20-seguimiento/2026-08-30-factura-ct-110.pdf`). Se comentó el 10-17 que el proveedor podría no llegar con el equipo completo para la siguiente fase, sin dueño | Paula Céspedes y Óscar Ramírez (revisión con el proveedor del 2026-10-27). Quién es dueño del contrato no consta en la ficha | El riesgo sigue con dueño `no_identificado` y los dos entregables siguen vencidos sin que nadie los reclame | 8 |
| **[6]** Sin fecha: Diana Molina, documento 9 (dicho el 2026-09-19, «por definir» el 10-10, cuatro semanas) y Laura Vélez, ajuste del presupuesto («la otra semana», 10-17) | Cada doliente, ahí mismo | Siguen sin poder vencer, es decir, sin poder incumplirse | 3 |

Para [5]: asignar dueño al riesgo y decidir quién reclama los dos entregables. Para [6]: sale un día concreto por cada uno.

### Vence antes de la próxima
Con el comité el 2026-10-31, estos ya habrán vencido ese día: se confirman con documento, en 5 minutos como un solo punto **[7]**, sin repasarlos uno por uno. Lo que no tenga acta pasa a «vencido sin evidencia».

| Quién | Qué | Para cuándo |
|---|---|---|
| Andrés Lozano | Validar el ambiente 20 | 2026-10-21 |
| Felipe Arango | Cerrar la prueba 18 (dijo el 10-10 que ya la entregó, sin acta) | 2026-10-23 |
| Diana Molina | Aprobar el diseño 21 | 2026-10-25 |
| Paula Céspedes | Enviar el documento 17 | 2026-10-26 |
| Óscar Ramírez | Revisión con el proveedor (primera fecha) | 2026-10-27 |
| Camilo Beltrán | Actualizar la matriz 22 | 2026-10-28 |
| Ricardo Salas | Confirmar la fecha 23 | 2026-10-28 |
| Laura Vélez | Revisar el anexo 19 | 2026-10-31 |

Y entre esta reunión y la siguiente: Gustavo Neira, entregar el punto 24 (2026-11-01), y Laura Vélez, revisar el anexo 3 (2026-11-03; ya con dos reprogramaciones, una más lo lleva al umbral de tres). Se preguntan en [7] si hay avance; no se discuten.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Javier Hoyos, cerrar la prueba 10 (vencido desde el 2026-09-27, 20 días al 10-17) | Dijo el 09-26 que ya había entregado; no hay acta y no aparece en las asistencias del 10-10 ni del 10-17 | La gerente le pide el acta o su presencia antes del 10-31. Si no viene, el punto queda en el seguimiento por escrito |
| Felipe Arango, prueba 18 | Los dos últimos listados de asistentes (10-10 y 10-17) no lo incluyen, aunque el comité del 10-10 recoge lo que dijo | Se resuelve en [7] solo si está presente o manda el acta |
| Seis reprogramaciones del documento 1 como patrón | Si el bloqueo excede la autoridad de la gerente, no se resuelve en este comité de seguimiento | `/pm-escalate` o el material del comité |

### Anexo — sin cambios desde el 2026-10-10 (último comité con tabla completa)
- Cerrados con acta de recibo: diseño 5 y punto 8 (Jorge Medina), anexo 11 (Diana Molina), matriz 6 (Ricardo Salas), fecha 7 (Paula Céspedes), diseño 13 (Rubén Cárdenas). No se repasan.
- Informe de avance del 2026-10-14 (amarillo, 82 %): no entra a la agenda; no da cuenta de los vencidos ni de las reprogramaciones, y eso se dice en el informe, no en la reunión.

## Lo que no sé
- Duración real de la reunión y si la fecha del 2026-10-31 sigue en pie (las notas dicen «dos semanas»).
- Quién es el dueño del contrato CT-110 y quién tiene facultad para exigir los dos entregables.
- Qué ha bloqueado el documento 1, la prueba 2 y el ambiente 4: ninguna minuta lo dice.
- Si Óscar Ramírez hace la revisión con el proveedor o la recibe.
- No hay agenda anterior en el expediente, así que no se puede decir qué quedó pendiente de decidir en una reunión anterior distinto de lo que dicen las notas del 10-17.

No convoca a nadie: citar a Ricardo Salas, Rubén Cárdenas, Andrés Lozano, Paula Céspedes, Óscar Ramírez, Beatriz Cuéllar, Diana Molina y Laura Vélez es de la gerente. Después de la reunión, `/pm-minutes` sobre la transcripción o las notas.
