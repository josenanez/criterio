# Corrida del 2026-10-17 · health-check

13 proyectos · 173 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Diagnóstico de PRY-211 desde cero sobre 21 documentos: 11 sostenidas, 11 sin sustento, 7 contradichas. Dijo que no se sabe si algún hito se cerró (0 actas de hito), cuánto se ejecutó (sin soporte contable), quién autorizó CC-01 ni con qué facultad, ni a qué siguiente fase se refiere la nota del 2026-10-17.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Diagnóstico · PRY-211 · Control de polvo en vías · 2026-10-17

**Leí:** 21 documentos · del 2025-05-16 al 2026-10-17 (fechas del nombre de archivo) · formatos: 16 .md, 1 .txt, 1 .json, 1 .csv, 1 .xlsx, 1 .pdf
**Otras carpetas:** busqué PRY-211, «polvo», «Servicios Ambientales del Norte» y «CT-110» en los documentos de los otros 12 proyectos y en el caché de texto. No aparece en ninguno.
**No pude leer:** nada quedó sin leer. El .xlsx y el .pdf los leí en su conversión a texto (caché), no abriendo el original. El `ficha-pm.json` de `00-gobierno` es el registro que escribió el gerente: lo leí como declaración suya, no como evidencia.
**Entrada de la prueba:** términos vigentes y aceptados el 2026-10-17 por José Francisco Ñáñez (versión 0.4.0); no hubo que registrarlos de nuevo. No hubo preguntas que contestar con la respuesta sugerida.

### Dictamen
**Sostenido:** 11 afirmaciones · **Sin sustento:** 11 · **Contradicho:** 7

(Son 29 afirmaciones tomadas de los documentos del proyecto. Cuando dos documentos se contradicen, cuento las dos afirmaciones. El detalle está en la última sección, para poder revisar el conteo.)

Desde esta carpeta se puede afirmar el gobierno de origen (patrocinador, gerente, comité, presupuesto y fechas aprobados en 2025), seis compromisos cerrados con acta, la existencia de una factura y que el cambio CC-01 mueve el cierre 103 días. No se puede afirmar que el proyecto esté en amarillo, que haya avanzado el 82 % que declara, que alguno de sus cinco hitos esté cerrado, ni cuánto lleva ejecutado. Sobre esos hitos hay 0 actas, el informe de avance contradice al cronograma en dos de ellos, y las tres cifras de dinero salen de un solo documento, el informe, que escribe quien está siendo evaluado. El cambio que movió la línea base dice estar «autorizado por el comité», pero ninguna minuta del comité lo menciona.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Paula Céspedes | `00-gobierno/2025-05-16-acta-constitucion.md` |
| Gerente | Liliana Torres | `00-gobierno/2025-05-16-acta-constitucion.md` |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente ni hasta qué monto o días. | `00-gobierno/2025-05-16-acta-constitucion.md` |
| Comité | Comité Ambiental. Aprobó el presupuesto el 2025-05-16. Las seis minutas (2026-09-05 a 2026-10-10) llevan ese nombre. | `00-gobierno/2025-05-16-acta-constitucion.md`, `30-reuniones/` |

Lo que el acta deja vacío:
- **Alcance:** «Componente 1, 2, 3». **Fuera de alcance:** «Lo que otro proyecto cubre». Ninguno de los dos se puede contrastar contra nada.
- **Dependencias:** «Ninguna declarada». El contrato CT-110 con un proveedor y la nota del 2026-10-17 sobre el equipo del proveedor para «la siguiente fase» son dependencias que nadie registró.
- **Autoridad del gerente:** sin ella no hay desviación aprobada. Lo que hay es un cambio (CC-01) que el propio gerente solicitó y que dice estar autorizado «por el comité», sin decir cuál comité, en qué fecha ni con qué acta.
- **Quién firma qué:** Liliana Torres firma todas las actas de recibo, es la autora del informe de avance y es la solicitante de CC-01. También es dueña del compromiso «Validar el ambiente 12», vencido y sin acta.

### Contra el plan
- **Línea base original (v1):** inicio 2025-05-26, cierre 2026-08-17. Salen del acta de constitución y del cronograma v1.
- **Línea base vigente (v2):** cierre 2026-11-28, según `10-plan/2026-10-14-cronograma-v2.xlsx`. Es una replanificación. Su motivo es CC-01 («ampliación de alcance», +103 días sobre la línea base vigente), que no dice qué se amplía.
- **Desviación del cierre contra la original:** 103 días, 23.0 %. Está sobre el umbral de 10 %. Contra la vigente: 0 días.
- **Avance contra el plan:** el informe declara 82 %. El cronograma v2 trae los 5 hitos como «cerrado», y eso sostendría 100 %. La brecha es de 18.0 puntos y el informe no la explica.
- **El cronograma v1 ya trae todos los hitos como «cerrado».** Es un archivo fechado 2025-05-16 que registra como cerrados hitos de 2026. O se editó después sin dejar rastro, o la columna «estado» no mide nada.
- **«Pruebas en operación»** figura «cerrado» con fecha vigente 2026-11-28, posterior a hoy (2026-10-17). Una fecha futura no puede estar cerrada.

### Hitos vencidos sin evidencia
Los cinco hitos del cronograma están marcados «cerrado». En la carpeta no hay ningún acta, resolución ni aprobación que lo pruebe. En otros proyectos de este portafolio el hito cerrado sí trae su acta de recibo en `20-seguimiento`. Aquí las seis actas de recibo son de compromisos de reunión, no de hitos.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Ingeniería básica aprobada | 2025-08-23 | 420 | Acta de recibo o aprobación de la ingeniería básica |
| Ingeniería de detalle aprobada | 2025-11-21 | 330 | Acta de recibo o aprobación de la ingeniería de detalle |
| Licencia y permisos obtenidos | 2026-02-18 | 241 | Resolución o licencia de la autoridad ambiental, con acta de recibo |
| Montaje e instalación | 2026-05-19 | 151 | Acta de recibo del montaje |
| Pruebas en operación | 2026-11-28 (aún no vence) | — | Un cierre con fecha futura no tiene documento posible. Cuando llegue la fecha se espera el acta de pruebas. |

### Dinero
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 4.200.000.000 COP | 1.310.630.831 COP | 1.465.714.221 COP | 4.009.341.481 COP | 2.889.369.169 COP |

- **Ejecutado y comprometido:** ejecutado es 34.9 % del aprobado y comprometido 31.2 %. La proyección queda 4.5 % por debajo del aprobado.
- **Las cuatro cifras vienen de un solo documento**, el informe del 2026-10-14. No hay libro mayor, extracto ni orden de compra. Solo el aprobado tiene un segundo documento (el acta de constitución).
- **Ejecutado mayor que comprometido:** el informe no define si «comprometido» incluye lo ya ejecutado. Si lo incluye, las cifras no cuadran.
- **Presupuesto tras CC-01:** CC-01 pide 206.000.000 COP adicionales. Ningún documento actualiza el aprobado ni dice si la proyección incluye esa suma. El 2026-10-17 Laura Vélez quedó de mandar «el ajuste del presupuesto», que tampoco está registrado.

**Proveedor CT-110 · Servicios Ambientales del Norte** (tres entregables de 392.117.057 COP cada uno):
- **Licenciamiento del software:** comprometido 2025-09-26, «pendiente», 386 días de atraso.
- **Bolsa de horas de ingeniería:** comprometido 2026-01-27, «en curso», 263 días de atraso.
- **Calibración de sensores:** comprometido 2026-05-30, figura «recibido». No hay acta de recibo en la carpeta, y el contrato exige que cada entregable se facture contra acta firmada por el gerente.
- **Factura FV-1110** (2026-08-30): 392.117.057 COP, radicada en cuentas por pagar. Su concepto dice «Entregables del contrato CT-110», en plural. El valor equivale a un solo entregable, y el único «recibido» no tiene acta.

### Lo que se dijo y nadie registró
- **Riesgo:** el 2026-10-17 «se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo». El informe lista un único riesgo («concentración del conocimiento en una sola persona»), sin dueño ni mitigación. Además, con 5 de 5 hitos cerrados el cronograma no tiene «siguiente fase». Falta saber a qué fase se refiere la nota.
- **Compromisos con la fecha corrida varias veces:**
  - Ricardo Salas, «Enviar el documento 1»: fecha original 2026-09-17, corrida 6 veces, hoy 2026-12-03. La nota dice «03/12/2026», que leo como 3 de diciembre porque la lectura contraria cae en el pasado.
  - Rubén Cárdenas, «Cerrar la prueba 2»: original 2026-10-02, corrida 4 veces, hoy 2026-11-15.
  - Andrés Lozano, «Validar el ambiente 4»: original 2026-09-25, corrida 3 veces, hoy 2026-11-14.
- **Compromisos vencidos sin evidencia:**

  | Quién | Compromiso | Vencía | Días |
  |---|---|---|---|
  | Liliana Torres | Validar el ambiente 12 | 2026-09-23 | 24 |
  | Javier Hoyos | Cerrar la prueba 10 | 2026-09-27 | 20 |
  | Beatriz Cuéllar | Confirmar la fecha 15 | 2026-10-06 | 11 |
  | Beatriz Cuéllar | Actualizar la matriz 14 | 2026-10-10 | 7 |
  | Rubén Cárdenas | Entregar el punto 16 | 2026-10-11 | 6 |
- **Compromisos sin fecha:**
  - Diana Molina, «Enviar el documento 9», «por definir» desde 2026-09-19 y presente en 4 minutas.
  - Laura Vélez, «ajuste del presupuesto» («la otra semana»), 2026-10-17.
- **Compromiso nuevo sin antecedente:** Óscar Ramírez, «revisión con el proveedor», 2026-10-27. Es la primera vez que aparece en la carpeta.
- **«Ya entregué» sin acta:** Javier Hoyos dijo el 2026-09-26 que entregó la prueba 10, y Felipe Arango el 2026-10-10 que entregó la prueba 18. Ninguno presentó acta. Ninguno de los dos compromisos aparece en la lista de la minuta donde se dijo, y ninguno quedó cerrado.
- **Cadencia:** las seis minutas anteriores son semanales. La nota del 2026-10-17 dice «próxima reunión en dos semanas». Esa reunión además quedó como `.txt` suelto en la raíz de la carpeta y no en `30-reuniones`.
- **Cambio de presupuesto:** el «ajuste del presupuesto» anunciado el 2026-10-17 no tiene solicitud de cambio, y CC-01 es la única que existe.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Se recibió el permiso ambiental en el periodo / «Licencia y permisos obtenidos» cerrado | Informe 2026-10-14: «se recibió el permiso ambiental pendiente desde el trimestre anterior» | Cronograma v2: hito cerrado desde 2026-02-18 |
| Las lluvias detuvieron el montaje diez días / «Montaje e instalación» cerrado | Informe 2026-10-14: «las lluvias detuvieron el montaje durante diez días» | Cronograma v2: hito cerrado desde 2026-05-19 (si el informe habla de otro montaje, no lo dice) |
| Avance de 82 % | Informe 2026-10-14: 82 % | Cronograma v2: 5 de 5 hitos «cerrado», que sostiene 100 % (brecha de 18.0 puntos) |
| «Pruebas en operación» cerrado | Cronograma v2: estado «cerrado» | Cronograma v2: fecha vigente 2026-11-28, posterior a 2026-10-17 |
| Bolsa de horas de ingeniería «pendiente» | `ficha-pm.json` (la del gerente): pendiente | Contrato CT-110: «en curso» |

### Sin sustento
Es el bloque más largo (11 de las 29 afirmaciones). Nada lo contradice y nada lo respalda:
- **«Estado amarillo».** Ningún documento define qué es amarillo para este proyecto. Hay 6 señales sobre umbral que el informe no menciona: desviación de cierre, brecha de avance, hitos sin evidencia, compromisos vencidos, compromisos corridos y entregables del proveedor atrasados.
- **Las tres cifras de ejecución del informe:** comprometido, ejecutado y proyección (3 afirmaciones). Un solo documento, el del evaluado, y sin soporte contable.
- **El único riesgo declarado** («concentración del conocimiento en una sola persona»). Sin dueño, sin valoración, sin nada que lo sustente.
- **«CC-01 autorizada por el comité».** No dice cuál comité ni cuándo. La solicitud es del 2026-10-07 y la minuta del 2026-10-10 no la menciona. Tampoco hay acta de comité de ninguna otra fecha.
- **Hitos «Ingeniería básica aprobada» e «Ingeniería de detalle aprobada» cerrados.** Sin acta (420 y 330 días desde su fecha).
- **«Calibración de sensores» recibido o aceptado.** Sin acta de recibo. Además el contrato está firmado el 2025-05-18 y ya lista ese entregable como «recibido», cuando vencía el 2026-05-30. Esa columna de estado no se puede tomar como registro.
- **«Cerrar la prueba 10» entregada** (dicho por Javier Hoyos, sin acta).
- **«Cerrar la prueba 18» entregada** (dicho por Felipe Arango, sin acta).

**Sostenido (11):**
1. Patrocinador, gerente y comité (acta).
2. Presupuesto aprobado original de 4.200.000.000 COP (acta).
3. Fechas originales: inicio 2025-05-26, cierre 2026-08-17 (acta y cronograma v1).
4. +103 días de CC-01: coinciden entre CC-01 y el cronograma v2. Lo sostenido es la coincidencia entre los dos documentos, no la autorización.
5. «Aprobar el diseño 5» (acta 2026-09-26).
6. «Actualizar la matriz 6» (acta 2026-10-03).
7. «Confirmar la fecha 7» (acta 2026-10-03).
8. «Entregar el punto 8» (acta 2026-09-26).
9. «Revisar el anexo 11» (acta 2026-09-26).
10. «Aprobar el diseño 13» (acta 2026-10-10).
11. Factura FV-1110 por 392.117.057 COP radicada (el PDF existe y el valor coincide con el de un entregable). Que esté bien pagada es otra cuestión, que aparece arriba.

### Lo que esta carpeta no permite saber
- **Si algún hito se cerró de verdad.** No hay ni una sola acta de hito. Cualquier cifra de avance, incluido el 82 %, queda sin base hasta que las haya. Hoy no se puede decir si el proyecto está en el 82 % declarado o muy por debajo.
- **Cuánto se gastó.** No hay soporte contable. Sin él no se puede saber si la proyección de 4.009.341.481 COP es creíble. Tampoco si incluye los 206.000.000 COP de CC-01.
- **Quién autorizó CC-01 y con qué facultad.** Sin acta de comité y sin autoridad del gerente declarada, la línea base v2 no tiene aprobación demostrable. Los 103 días son por ahora una fecha que alguien escribió.
- **Qué se amplió.** CC-01 dice «ampliación de alcance» y el alcance del acta es «Componente 1, 2, 3». No se puede saber qué entra ni qué cuesta.
- **Si lo pagado al proveedor se entregó.** Falta el acta de «Calibración de sensores» que el contrato exige para facturar. De los tres entregables, uno figura recibido (sin acta) y dos están atrasados 386 y 263 días.
- **A qué «siguiente fase» se refiere la nota del 2026-10-17**, si los cinco hitos figuran cerrados.
- **Quién es Óscar Ramírez** y qué papel tiene en el proyecto: no figura en el acta ni en ninguna minuta anterior.
- **Si se cumplió la prueba 10 y la prueba 18.**
- **El criterio de éxito** («control de polvo en vías en producción y medido»). No hay ninguna medición de polvo en la carpeta.

### Qué sigue
No recomiendo detener, continuar ni reestructurar el proyecto: eso lo decide quien tiene la facultad.

Ofrezco dos cosas:
1. **Llevar las 5 contradicciones y los vacíos de CC-01 al gerente como preguntas, una por una.** Empezaría por la contradicción entre el permiso «recibido en el periodo» y el hito cerrado en febrero.
2. **Preparar el punto de comité con la lista de lo que falta:** actas de los cinco hitos, el acta de comité de CC-01, la autoridad del gerente, el soporte contable del ejecutado, el acta de «Calibración de sensores» y el registro del riesgo y las dependencias (CT-110 y el equipo del proveedor) que se dijeron y no se anotaron.

**Pie de rigor:** las cifras derivadas (103 días, 23.0 %, 18.0 puntos, 34.9 %, 31.2 %, 4.5 %, disponible real y todos los conteos de días) salen de `portafolio.py compute` del 2026-10-17. Los conteos de afirmaciones y de minutas son míos, hechos leyendo cada documento. Los documentos del gerente (informe y `ficha-pm.json`) los traté como declaración, no como evidencia. No hay en la carpeta ningún documento que sea evidencia independiente de avance o de gasto.
