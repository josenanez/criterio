Sale de la ficha PRY-211 (`estado/records/PRY-211.json`, informe de avance del 2026-10-14), el acta de constitución del 2025-05-16 y la solicitud CC-01 del 2026-10-07. Términos v1.1 vigentes (aceptados por José Francisco Ñáñez, 2026-10-17).

## Solicitud de cambio — PRY-211 Control de polvo en vías — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días. Leo «salida a producción» como el hito «Pruebas en operación», que hoy coincide con el cierre (2026-11-28); el criterio de éxito del acta es «control de polvo en vías en producción y medido». Si se refiere a otro hito, el cálculo cambia.
**Quién lo pide:** no consta en ningún documento. La instrucción llegó por la sesión; no hay solicitud escrita con solicitante, motivo ni fecha.
**Por qué:** no declarado. Sin motivo, el comité no tiene qué evaluar.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
|---|---|---|---|
| Alcance | Componentes 1, 2 y 3 (acta) más la ampliación de CC-01, que no dice qué agrega | Sin cambio declarado | 0 declarado |
| Tiempo | Cierre y «Pruebas en operación»: 2026-11-28 (línea base 2) | 2026-12-28 | +30 días |
| Costo | Aprobado 4.200.000.000 COP; proyección 4.009.341.481 COP; CC-01 sumó 206.000.000 COP que la ficha no refleja en lo aprobado | No declarado | No se sabe |

**Quién absorbe lo que no se declaró.** Alcance y costo no tienen impacto declarado. Con 30 días más y el mismo alcance, quien lo absorbe es el equipo (horas no pagadas) o la calidad de las pruebas. El costo de 30 días extra de gerencia y del proveedor no está calculado, y no lo invento: la ficha no tiene costo por periodo ni holgura por actividad.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
|---|---|---|
| Ninguno | `impact` con 30 días: 0 alcanzados, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar | — |

**Lo que este resultado no dice.** El acta declara «Ninguna declarada» en dependencias. Que el cálculo dé cero significa que nadie declaró dependencias, no que no existan: un proyecto de logística y de salida a producción de la mina casi seguro toca a otros. Hay que preguntárselo al gerente antes de dar el cero por bueno. Tampoco puedo decir cuántos días se mueve nadie más, porque no hay holgura por actividad.

### Quién decide
**Autoridad requerida:** no determinable. El acta no declara autoridad para cambios (`identity.authority`: no encontrada, sin umbrales de tiempo ni de costo). Eso es el hallazgo de fondo.
**Según:** acta de constitución 2025-05-16; solo nombra al Comité Ambiental, que aprobó el presupuesto.
**Va a comité:** sí, por defecto, al Comité Ambiental (próxima sesión semanal 2026-10-23). Sin autoridad declarada no hay quién pueda aprobarlo solo, y el precedente es malo:

- CC-01 figura aprobado por «el comité», sin decir cuál ni en qué fecha.
- La solicitud CC-01 es del 2026-10-07 y la línea base 2 se aprobó el 2026-10-14.
- Ese cambio no deja documento de aprobación en la carpeta.

### Si no se aprueba
El proyecto sigue con cierre el 2026-11-28, 103 días (23 %) contra la línea base original (2026-08-17), con 0 contra la vigente.

Lo que lo hace frágil:
- Avance declarado 82 % contra 5 de 5 hitos «cumplidos» en la ficha, una diferencia de 18 puntos.
- 4 de esos hitos sin evidencia de cumplimiento.
- «Pruebas en operación» figura cumplido con fecha 2026-11-28, que es futura: no puede estar cumplido.
- 5 compromisos vencidos, 2 sin fecha y 3 reprogramados repetidamente. «Enviar el documento 1» (Ricardo Salas) lleva 6 reprogramaciones y ya está en 2026-12-03, cinco días después del cierre vigente.
- Proveedor CT-110: dos entregables pendientes con 386 y 263 días de atraso, y uno aceptado sin evidencia.

Que la fecha vigente se sostenga hoy es dudoso, y la solicitud puede estar reconociendo un atraso que ya existe.

### Si se aprueba
**Línea base 3** — cierre 2026-12-28 · presupuesto: sin cambio declarado (4.200.000.000 COP; el cobro de 206.000.000 COP de CC-01 está sin reflejar) · motivo: sin motivo escrito; hay que redactarlo antes de comité.
La línea base 2 queda intacta. Replanificaciones: de 1 a 2.
**Desviación acumulada contra la línea base original:** tiempo +133 días (23 % → ~30 %) · costo: no calculable, porque el 30-día extra no tiene costo declarado y la ficha no recoge los 206.000.000 COP de CC-01 en el presupuesto aprobado.
Contra la vigente (línea base 2): +30 días.
Reconciliación: 103 días de movimiento de línea base, 103 autorizados por CC-01, 0 sin autorización. Con este cambio, los 30 días quedarían autorizados solo si el comité aprueba y lo deja escrito.

### Qué hace falta antes de comité
1. Solicitud escrita: solicitante, motivo y causa del movimiento de 30 días.
2. Confirmar qué hito se mueve (¿«Pruebas en operación» o la entrada a producción propiamente dicha?).
3. Costo de los 30 días extra.
4. Confirmar con Liliana Torres (gerente) dependencias con otros proyectos.
5. Declarar la autoridad de cambios del acta.
6. Aclarar el hito «Pruebas en operación» marcado cumplido con fecha futura.

## Después
Ofrezco armar el paquete para el Comité Ambiental de 2026-10-23. La línea base 3 no se registra: nadie con autoridad la ha aprobado.

---
**Pie de rigor.** Cifras sacadas de `portafolio.py` (`impact` y `compute`) y de la ficha. No afirmo: cuántos días se mueve cada dependiente (sin holgura por actividad), el costo de los 30 días, ni quién tiene autoridad (el acta no la declara). Supuestos míos: que «salida a producción» es el hito «Pruebas en operación», y que no existe solicitud escrita. La verificación contra los documentos es de quien lea esto.
