**Fuentes de este registro:** las 13 fichas de `estado/records/` (PRY-199 a PRY-211, sección RAID, que citan el informe de avance de cada proyecto), las 13 actas de constitución (sección "Dependencias declaradas") y las minutas y notas de reunión disponibles (PRY-199, 200, 201, 202, 203, 205, 207, 208, 209 y las siete de PRY-211, incluidas las notas del 2026-10-17). Términos vigentes: aceptados por José Francisco Ñáñez, 2026-10-17 (versión 1.1).

## RAID — Portafolio al 2026-10-17
15 riesgos · 0 supuestos · 14 incidencias · 7 dependencias
36 de 36 sin doliente · 36 de 36 sin movimiento verificable · 1 no registrado formalmente

Cifras después de reclasificar 7 ítems (ver más abajo; 211-D1 es la dependencia no registrada formalmente). Como las fichas lo traían: 22 riesgos, 14 incidencias, 0 supuestos, 0 dependencias.

Dos aclaraciones sobre cómo leer los conteos:
- **Prob. e Impacto:** ningún ítem las trae, así que no las inventé. No se aplicó escala alta/media/baja a nada.
- **Sin movimiento:** las fichas guardan cada ítem una sola vez, sin historial. No puedo afirmar "sin movimiento en dos períodos" ni lo contrario; lo declaro como no verificable, no como cero.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 199-R1, 201-R1, 204-R1, 207-R1, 210-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | sin doliente | 2026-09-28 a 2026-10-16 (fecha del informe que lo cita) | Aparece en 5 proyectos con la misma redacción. Si es un solo evento, afecta a otros proyectos del portafolio. Nadie lo tiene a su cargo. |
| 202-R1, 204-R2, 206-R2, 209-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | sin doliente | 2026-09-28 a 2026-10-15 | Mismo patrón: 4 proyectos, un solo acceso, ningún doliente. |
| 200-I1, 208-I1, 210-I2 | Incidencia | Se levantó un hallazgo en la auditoría de seguridad | sin doliente | 2026-10-13 a 2026-10-16 | Ya ocurrió, y una incidencia sin doliente ni fecha de resolución no se resuelve. |
| 206-I1, 207-I2, 208-I2, 210-I1 | Incidencia | El primer ensayo de disponibilidad no alcanzó lo pactado y se repite | sin doliente | 2026-09-29 a 2026-10-16 | Incumple lo pactado en 4 proyectos y no hay doliente ni fecha del nuevo ensayo. |
| 200-R2 + 200-I2 | Riesgo + incidencia | Concentración del conocimiento en una persona, y pérdida de dos semanas por rotación de un ingeniero clave | sin doliente | 2026-10-15 | En PRY-200 el riesgo y la incidencia se citan en el mismo informe. Parece que el riesgo ya ocurrió; hay que confirmarlo con el gerente. |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| El proveedor podría no llegar con el equipo completo para la siguiente fase («nadie lo anotó como riesgo») | Dependencia del proveedor (la ficha de PRY-211 ya lo trae como riesgo, marcado como no formal) | PRY-211, `2026-10-17-notas-reunion.txt` | 2026-10-17 |

Las demás minutas (PRY-199, 200, 201, 202, 203, 205, 207, 208, 209 y las siete de PRY-211) solo traen compromisos, y no encontré en ellas riesgos dichos al pasar. No agregué ninguno.

### Sin doliente o sin fecha
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 36 ítems (listados abajo) | todos | todos | Doliente: en todos figura `no_identificado`. Fecha objetivo o de resolución: en ninguno. Prob./Impacto: en ninguno. Mitigación: ninguna registrada, así que no se puede decir que alguna esté vencida. |

No relleno ninguno de estos datos. La fecha "desde" de las incidencias es la del informe que las menciona, no necesariamente la del hecho.

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna) | — | — | Las 13 actas dicen "Ninguna declarada" en dependencias y las fichas traen 0. **No pude hacer el cruce entre proyectos**: ninguna dependencia lleva el código de otro proyecto, así que no se puede saber si un proyecto movió su fecha y arrastró a otro. Eso no demuestra que no haya dependencias entre proyectos. Demuestra que nadie las declaró. |

Las 7 dependencias son hacia terceros (proveedor u Operaciones), no hacia proyectos. Todas están como **declaradas, no acordadas**: ninguna contraparte las confirmó.

### Reclasificaciones
| Ítem | Antes | Ahora | Por qué |
|---|---|---|---|
| 211-D1: el proveedor podría no llegar con el equipo completo | Riesgo | Dependencia (proveedor) | Mismo criterio que los de abajo. |
| 203-R2, 205-R1, 208-R2: "El proveedor no ha confirmado la fecha de la última entrega" | Riesgo | Dependencia (proveedor, sin código de proyecto) | Depende de alguien fuera del proyecto y su confirmación está pendiente. Se coordina y se confirma. No se mitiga. |
| 200-R1, 202-R2, 206-R1: "Ventana de parada de planta definida por operaciones" | Riesgo | Dependencia (Operaciones, sin código de proyecto) | La fecha la fija otra área. El proyecto no la controla. |

Propongo estas reclasificaciones, **no modifiqué las fichas**. El gerente de cada proyecto las confirma.

### Registro completo
Ids: `<proyecto>-R` riesgo, `-D` dependencia, `-I` incidencia. Prob., Impacto, Doliente y Fecha son "—" o "sin doliente" en todos. Último movimiento: "sin historial" en todos.

| Id | Tipo | Qué | Fuente |
|---|---|---|---|
| 199-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | informe 2026-10-15 |
| 200-R1 | Dependencia (Operaciones) | Ventana de parada de planta definida por operaciones | informe 2026-10-15 |
| 200-R2 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-15 |
| 200-I1 | Incidencia | Hallazgo en la auditoría de seguridad | informe 2026-10-15 |
| 200-I2 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | informe 2026-10-15 |
| 201-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | informe 2026-10-14 |
| 202-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | informe 2026-10-12 |
| 202-R2 | Dependencia (Operaciones) | Ventana de parada de planta definida por operaciones | informe 2026-10-12 |
| 203-R1 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-14 |
| 203-R2 | Dependencia (proveedor) | El proveedor no ha confirmado la fecha de la última entrega | informe 2026-10-14 |
| 203-I1 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | informe 2026-10-14 |
| 203-I2 | Incidencia | Las lluvias detuvieron el montaje diez días | informe 2026-10-14 |
| 204-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | informe 2026-09-28 |
| 204-R2 | Riesgo | Bloqueo de la vía de acceso a la mina | informe 2026-09-28 |
| 205-R1 | Dependencia (proveedor) | El proveedor no ha confirmado la fecha de la última entrega | informe 2026-10-14 |
| 205-R2 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-14 |
| 205-I1 | Incidencia | Las lluvias detuvieron el montaje diez días | informe 2026-10-14 |
| 206-R1 | Dependencia (Operaciones) | Ventana de parada de planta definida por operaciones | informe 2026-10-15 |
| 206-R2 | Riesgo | Bloqueo de la vía de acceso a la mina | informe 2026-10-15 |
| 206-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | informe 2026-10-15 |
| 207-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | informe 2026-09-29 |
| 207-I1 | Incidencia | Las lluvias detuvieron el montaje diez días | informe 2026-09-29 |
| 207-I2 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | informe 2026-09-29 |
| 207-I3 | Incidencia | Dos semanas perdidas por rotación de un ingeniero clave | informe 2026-09-29 |
| 208-R1 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-13 |
| 208-R2 | Dependencia (proveedor) | El proveedor no ha confirmado la fecha de la última entrega | informe 2026-10-13 |
| 208-I1 | Incidencia | Hallazgo en la auditoría de seguridad | informe 2026-10-13 |
| 208-I2 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | informe 2026-10-13 |
| 209-R1 | Riesgo | Bloqueo de la vía de acceso a la mina | informe 2026-10-09 |
| 210-R1 | Riesgo | Cambio en la licencia ambiental que puede mover el alcance | informe 2026-10-16 |
| 210-R2 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-16 |
| 210-I1 | Incidencia | Primer ensayo de disponibilidad no alcanzó lo pactado y se repite | informe 2026-10-16 |
| 210-I2 | Incidencia | Hallazgo en la auditoría de seguridad | informe 2026-10-16 |
| 211-R1 | Riesgo | Concentración del conocimiento en una persona | informe 2026-10-14 |
| 211-D1 | Dependencia (proveedor), no registrada formalmente | El proveedor podría no llegar con el equipo completo para la siguiente fase | notas 2026-10-17 |
| 211-I1 | Incidencia | Las lluvias detuvieron el montaje diez días | informe 2026-10-14 |

(36 filas: 15 riesgos, 7 dependencias, 14 incidencias.)

### Cosas que conviene saber antes de actuar
- **Texto idéntico en proyectos distintos.** Los mismos riesgos e incidencias aparecen con las mismas palabras en 3 a 5 proyectos (licencia ambiental, vía de acceso, rotación, lluvias en el montaje). Pueden ser el mismo evento o texto copiado de una plantilla. Los documentos no me permiten distinguirlo. Antes de elevarlos como un solo asunto de portafolio, que lo confirme cada gerente.
- **Informes viejos.** El último informe de PRY-204 es del 2026-09-28 y el de PRY-207 del 2026-09-29: pasaron 19 y 18 días, y el umbral configurado es 15. Su RAID puede estar desactualizado.
- **No se evaluó:** si hay mitigaciones vencidas (no hay mitigaciones registradas) ni si hay doliente fuera del proyecto sin respuesta (no hay doliente de ningún tipo).

### Después
- **Subir a comité** (próximo: 2026-10-23): licencia ambiental (5 proyectos), vía de acceso (4), hallazgos de auditoría de seguridad (3), ensayos de disponibilidad fallidos (4) y 200-R2/200-I2. Todos cumplen el criterio de "afecta a otro proyecto" o "incidencia sin resolver". La decisión a formular en cada uno es **quién es el doliente** y para qué fecha.
- **Doliente:** puedo proponer uno por cada ítem, pero los documentos que leí no dicen quién debería ser, y proponer sin ese dato sería adivinar. Se propone, no se asigna. Dime si quieres que lo proponga a partir de los responsables de las minutas.
