# Corrida del 2026-10-17 · vendor-tracking

13 proyectos · 40 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Proveedores de PRY-211 (CT-110): 2 entregables vencidos sin evidencia (386 y 263 días), Calibración de sensores aceptada sin acta de recibo y facturada (392.117.057 COP, FV-1110). No se pudo decir: vigencia, renovación y preaviso del contrato; qué entregable cubre la factura.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Fuentes:** ficha PRY-211 (`estado/records/PRY-211.json`), contrato CT-110 (`00-gobierno/2025-05-18-contrato-ct-110.md`), factura FV-1110 (`20-seguimiento/2026-08-30-factura-ct-110.pdf`), actas de recibo de `20-seguimiento`, informe de avance del 2026-10-14, minutas de comité 2026-09-05 a 2026-10-10 y notas del 2026-10-17. Cifras derivadas: salida de `portafolio.py compute` al 2026-10-17.

## Proveedores — PRY-211 Control de polvo en vías al 2026-10-17

### Servicios Ambientales del Norte — contrato CT-110
**Vigencia:** no declarada (el contrato solo trae fecha de firma, 2025-05-18) · **Preaviso de no renovación:** no declarado · **Vence el:** no declarado

El contrato está en la carpeta, así que la lista de entregables sale de él. Condición de pago, según el contrato: *"Cada entregable se factura contra acta de recibo firmada por el gerente del proyecto."*

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del software (392.117.057 COP) | 2025-09-26 | `late`: 386 días vencido | Ninguna | Sin dato por entregable |
| Bolsa de horas de ingeniería (392.117.057 COP) | 2026-01-27 | `late`: 263 días vencido | Ninguna | Sin dato por entregable |
| Calibración de sensores (392.117.057 COP) | 2026-05-30 | Declarado `accepted` | **Ninguna en la carpeta** | Sin dato por entregable |

Resumen del cruce (calculado): 3 entregables, los 3 con monto declarado; 1 aceptado; monto aceptado 392.117.057 COP; facturado 392.117.057 COP, en una sola factura (FV-1110, 2026-08-30).

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Aceptación de Calibración de sensores | La tabla del contrato la marca "recibido" y exige acta de recibo firmada por el gerente (Liliana Torres) para facturar | No hay acta de recibo de ese entregable. Las actas de la carpeta (recibo 5, 6, 7, 8, 11 y 13) recibieron compromisos de comité, no entregables del proveedor | Contrato CT-110; `20-seguimiento/` |
| Qué cubre la factura | Cada entregable se factura contra su acta | FV-1110 dice "Entregables del contrato CT-110" y no nombra cuál. Su valor, 392.117.057 COP, coincide con un entregable y no con la suma de los tres | `2026-08-30-factura-ct-110.pdf` |
| Estado de los dos entregables vencidos | La tabla del contrato los marca "pendiente" y "en curso" | El informe de avance reporta 82 % y la ficha los deja en `pending`. Ningún documento dice que se hayan entregado | Contrato CT-110; informe 2026-10-14 |

Lo facturado coincide con lo aceptado en monto, así que el script **no levanta** `vendor_invoiced_over_accepted` ni `vendor_invoiced_without_delivery`. Pero esa coincidencia solo se sostiene si la aceptación de Calibración de sensores es cierta, y ningún documento la prueba. El contrato la marca "recibido", y esa es una declaración, no un acta. Puede haber un acta firmada y no archivada, o una factura que corresponda a otro hito. Eso lo saben Compras y Finanzas, no esta carpeta.

### Sin evidencia de recibo
| Entregable | Marcado como | Desde |
|---|---|---|
| Calibración de sensores | `accepted` (señal `vendor_accepted_without_evidence`) | Fecha comprometida 2026-05-30; la fecha de la declaración no consta en los documentos |

### Compromisos del proveedor vencidos
Ninguno identificado como del proveedor. Los 5 compromisos vencidos de la ficha son de personas del proyecto, no del proveedor: Javier Hoyos (20 días), Liliana Torres (24), Beatriz Cuéllar (7 y 11) y Rubén Cárdenas (6). Ningún compromiso de comité figura a nombre del proveedor.

Dos puntos relacionados con él, ambos sin vencer:
- Óscar Ramírez: "revisión con el proveedor", para el 2026-10-27 (`2026-10-17-notas-reunion.txt`).
- En la reunión del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase. Nadie lo anotó como riesgo; la ficha lo recoge sin dueño (`2026-10-17-notas-reunion.txt`).

### Sin dato
- **Vigencia, renovación automática y preaviso de CT-110:** el contrato no los trae. No se puede decir si hay un preaviso por vencer antes del cierre del proyecto (2026-11-28 según el cronograma v2). Hay que pedir el contrato completo o sus anexos a Compras.
- **Fecha de la aceptación de Calibración de sensores y quién la firmó.**
- **Qué entregable cubre la factura FV-1110.** Tampoco hay otras facturas de CT-110 ni estado de pago más allá de "radicada en cuentas por pagar".
- **Si los dos entregables vencidos fueron reprogramados por acuerdo con el proveedor.** No hay otrosí ni acta en la carpeta; el contrato conserva las fechas originales.

## Después
- El preaviso no se puede evaluar sin la fecha de terminación del contrato; ese dato va primero.
- La factura FV-1110 está radicada contra un entregable aceptado sin acta. Si va a pago, conviene pedir el acta de Calibración de sensores antes. Ofrezco llevar el punto a comité: *entregable aceptado sin acta de recibo, facturado y radicado*, más los dos entregables vencidos (386 y 263 días) y el riesgo del equipo del proveedor.

---
**Pie de rigor:** este es un borrador de trabajo que dice lo que muestran los documentos de la carpeta; no sabe lo que se habló fuera de ellos y puede equivocarse. Cada dato lleva su cita, y la verificación es suya. Cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-17). No se leyó el contenido de los demás proyectos.
