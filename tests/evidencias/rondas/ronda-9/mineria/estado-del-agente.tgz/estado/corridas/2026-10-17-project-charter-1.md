# Corrida del 2026-10-17 · project-charter

13 proyectos · 30 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Revisión del acta de PRY-206 (2026-02-25): faltan autoridad del gerente, supuestos, restricciones, cadencia del comité y quién mide el éxito; alcance, exclusiones y criterio de éxito son de plantilla. No sé qué se acordó fuera de los documentos.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos vigentes (versión 1.1, aceptados el 2026-10-17 por José Francisco Ñáñez): no hubo que pedirlos de nuevo.

## Acta — PRY-206 Red privada LTE en mina
**Estado:** existe, del 2026-02-25 (acta de constitución, aprobada por el Comité de Seguridad). Esta es una revisión; no se redactó nada nuevo.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| Autoridad del gerente | **No está** | No hay monto ni tipo de cambio que Óscar Ramírez pueda decidir solo. Cualquier ajuste, por pequeño que sea, tiene que subir al Comité de Seguridad. Con 1.200.000.000 COP aprobados y 487.051.150 ya comprometidos, eso pasa en la práctica a diario, y nadie puede decir si una decisión del gerente fue legítima o un exceso. |
| Objetivo de negocio | Presente pero es la descripción de la solución: «Entregar red privada LTE en mina para Logística» | No dice qué mejora para Logística ni en cuánto. Sin eso no se puede juzgar si la red, aunque se entregue, sirvió. |
| Alcance | Presente pero vacío: «Componente 1, 2, 3» | No se puede saber qué entra. Cualquier cambio de alcance es indiscutible en un sentido o en el otro, y el control de cambios no tiene contra qué comparar. |
| Exclusiones | Presente pero vacío: «Lo que otro proyecto cubre» | No nombra el proyecto ni lo excluido. Una exclusión que no dice cuál es no protege de nada. Es el texto de plantilla. |
| Criterio de éxito | Presente pero no medible: «en producción y medido» | No dice qué se mide, con qué umbral ni quién lo mide. El informe de avance reporta que el primer ensayo de disponibilidad «no alcanzó lo pactado», pero el acta no recoge qué se pactó, así que no se puede verificar el incumplimiento ni su tamaño. |
| Quién mide el éxito | **No está** | El cierre quedaría en manos de quien reporta. |
| Patrocinador | Natalia Ospina (persona) | Cubierto. |
| Gerente | Óscar Ramírez (persona) | Cubierto. |
| Comité y cadencia | Comité de Seguridad; **cadencia no declarada** | Un proyecto de red lo gobierna el comité de seguridad; el acta no dice si es el comité adecuado ni cada cuánto se reúne. No se sabe cuándo se decide. |
| Supuestos | **No están** | Los dos riesgos abiertos del informe (ventana de parada de planta definida por operaciones, bloqueo de la vía de acceso) parecen supuestos o dependencias no declarados. |
| Restricciones | **No están** | Sin restricciones escritas, nadie puede decir qué margen tuvo el proyecto. |
| Dependencias | «Ninguna declarada» | Contradice el informe: la ventana de parada depende de operaciones, y el acta no lo sabe. |
| Hitos | Tres, en el cronograma v1, no en el acta | El acta da inicio (2026-03-07) y cierre (2027-05-05); los hitos solo están en el cronograma. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta dice «Entregar red privada LTE en mina para Logística», que describe la solución, no un objetivo medible). Fuente: 00-gobierno/2026-02-25-acta-constitucion.docx.
**Alcance:** Componente 1, Componente 2, Componente 3 (sin descripción). Fuente: ídem. Pendiente de definir qué es cada componente.
**Exclusiones:** «Lo que otro proyecto cubre» (sin nombrar). Pendiente de definir.
**Patrocinador:** Natalia Ospina · **Gerente:** Óscar Ramírez (ídem).
**Autoridad del gerente:** pendiente de definir (no está en ningún documento). No se propone un monto: lo decide el comité.
**Comité al que reporta:** Comité de Seguridad · **Cadencia:** pendiente de definir.
**Presupuesto aprobado:** 1.200.000.000 COP, aprobado el 2026-02-25 por el Comité de Seguridad (acta).
**Supuestos:** pendiente de definir. · **Restricciones:** pendiente de definir.
**Criterio de éxito:** «Red privada LTE en mina en producción y medido» (acta); no medible tal como está. · **Lo mide:** pendiente de definir.
**Hitos principales** (cronograma v1, 2026-02-25): Ingeniería básica aprobada, 2026-07-26 (cerrado); Ingeniería de detalle aprobada, 2026-12-14 (en curso); Licencia y permisos obtenidos, 2027-05-05 (en curso).

### Otras cosas que vi al revisar (no son del acta, pero sí del acta)
- El informe de avance (2026-10-15) declara **verde** con 34 % de avance, y reporta a la vez un ensayo de disponibilidad no alcanzado y dos riesgos sin responsable. El acta no permite decidir si ese verde se sostiene, porque no tiene un criterio de éxito medible. Esta revisión no dictamina la salud del proyecto (para eso: `/health-check`).
- El hito «Ingeniería básica aprobada» figura cerrado en el cronograma, pero no hay en la carpeta el documento de aprobación. No lo puedo confirmar.
- El informe dice que se recibió el permiso ambiental, mientras el hito «Licencia y permisos obtenidos» sigue en curso para 2027-05-05. No sé si son el mismo permiso; no lo asumo.

### Después
- El acta quedó **sin autoridad declarada**: ofrezco llevar esa definición al Comité de Seguridad como decisión, con `/steering-pack`. No es un trámite: es quien decide hasta dónde puede decidir el gerente.
- De esta revisión salen supuestos (ventana de parada de planta, acceso a la mina) y una dependencia con operaciones: ofrezco pasarlos al registro RAID con `/raid-log`.

### Pie de rigor
Leí tres documentos: el acta (2026-02-25), el cronograma v1 (2026-02-25) y el informe de avance (2026-10-15), en su versión de texto del caché, y la ficha del proyecto. No leí actas de comité, contratos ni correos, porque la carpeta no los tiene; si el Comité de Seguridad definió algo de palabra (autoridad, cadencia, umbral de disponibilidad), no consta y no lo sé. Lo que marqué como pendiente no lo completé. Se verifica contra los originales citados.
