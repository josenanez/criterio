## Listo — Portafolio de proyectos

**Miré:** 76 documentos en 13 carpetas (12 proyectos más la carpeta de PRY-211, que ya traía su propio agente) · formatos: .md 37, .docx 11, .pdf 11, .xlsx 9, .csv 6, .json 1, .txt 1 · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesto: hay varios proyectos)
**Te aviso:** dos días antes del comité semanal; el primero que supuse es el 2026-10-23 (los comités que vi son semanales; dime la fecha real y la cambio)
**En:** presentación (valor por defecto; la configuración la guarda como `html`)
**Términos:** aceptados por José Francisco Ñáñez el 2026-10-17 para la versión 0.4.0 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 96015115a67f6c94…

Dónde queda: configuración en `.criterio/portafolio/config.json`; lo que voy encontrando en `estado/`; los informes irán a `reportes/`.

### Probé con tres proyectos

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Mantenimiento predictivo de camiones | 5 | Patrocinador y gerente: Gustavo Neira (la misma persona). Presupuesto 2.400 M COP, ejecutado 789,9 M, proyección 2.647,9 M. Declara verde, 66 %. Fin vigente 2027-04-12. (acta 2026-06-09; informe 2026-10-15) | Facultad del gerente (`authority`), etapa |
| PRY-210 Programa de relacionamiento comunitario | 3 | Patrocinadora Diana Molina, gerente Felipe Arango. Presupuesto 1.200 M COP, ejecutado 605,0 M, proyección 1.214,3 M. Declara verde, 45 %. Fin 2026-12-19. (acta 2026-05-23; informe 2026-10-16) | Producto (el acta dice «No aplica»), facultad, etapa; sin actas de recibo de hitos |
| PRY-211 Control de polvo en vías | 28 (21 citados en la ficha) | Gerente Liliana Torres, patrocinadora Paula Céspedes. Presupuesto 4.200 M COP. Declara amarillo, 82 %. Fin 2026-11-28 tras CC-01 (+103 días). Trae `ficha-pm.json`, guardada aparte como `pm_record`. | Producto, facultad, etapa |

### Hallazgos (todos levantados por `compute`)

**PRY-200**
- `declared_vs_evidence`: declara verde con 66 %, pero el cronograma solo sustenta entre 25 % y 50 % (1 hito de 4) y la proyección supera lo aprobado en 10,3 %.
- `progress_vs_plan` y `variance_cost` (10,3 %).

**PRY-210**
- `declared_vs_evidence`: declara verde con un hito vencido y otro cerrado sin prueba.
- `milestone_overdue`: Ingeniería de detalle aprobada, venció el 2026-10-13 (4 días).
- `milestone_met_without_evidence`: Ingeniería básica aprobada se declara cerrada (plan 2026-08-07) y no hay acta.

**PRY-211**
- `variance_time`: +103 días, 23 % sobre la línea base original (CC-01, ya con línea base v2).
- `progress_vs_plan`: declara 82 % con 5 de 5 hitos cerrados.
- `milestone_met_without_evidence`: 4 hitos cerrados sin acta (hasta 420 días).
- `commitment_overdue`: 5 vencidos; `commitment_undated`: 2; `commitment_rescheduled`: «Enviar el documento 1» (Ricardo Salas) 6 veces, «Cerrar la prueba 2» 4, «Validar el ambiente 4» 3.
- `vendor_deliverable_late`: 2 entregables de CT-110 (386 y 263 días); `vendor_accepted_without_evidence`: Calibración de sensores, aceptada sin acta.
- `pm_vs_pmo`: la ficha del gerente pone producto «No aplica»; mi lectura lo deja vacío (el acta dice que no sirve a uno). Es la única diferencia entre las dos fichas.

Totales: 3 proyectos, los 3 con alertas (26), 2 verdes contradichos, 0 problemas de ficha.

### El portafolio completo
10 proyectos más, 48 documentos en un lote y 3 proyectos en otro (según `plan-lectura`; 73 documentos sin leer), uno tras otro. Con lo visto, del orden de media hora de lectura en esta conversación (estimación mía, no medida).

### Lo que le falta a tu carpeta
- Ninguna acta de constitución dice la facultad del gerente: sin eso no se sabe si un cambio exige comité.
- Hitos cerrados sin acta de recibo en PRY-210 y PRY-211: la declaración queda sin prueba.
- En PRY-200 el gerente y el patrocinador son la misma persona, y los asistentes del comité son dos veces el mismo nombre; los compromisos son de Beatriz Cuéllar y Paula Céspedes, que no figuran como asistentes.
- Cada proyecto debería tener un riesgo con doliente: todos los riesgos leídos quedaron sin responsable.
- `estado/` ya tenía la carpeta de PRY-211 del agente de proyecto; el portafolio escribe en `estado/records/` y no la toca.

Preguntas hechas: 0 (en esta prueba todas se tomaron con el valor sugerido). Sigue: ofrezco correr el portafolio completo; publicar un estándar para gerentes de proyecto no aplica todavía (no hay carpeta compartida).
