**Fichas cargadas:** 13 proyectos (PRY-199 a PRY-211), fichas de `estado/records/`, corte 2026-10-17. Cifras recalculadas con `portafolio.py compute` el 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

# Comité de proyectos — 2026-10-23 (próximo comité según la configuración)
5 decisiones · 6 escalamientos sin decisión asociada · 12 de 13 proyectos con hallazgos (67 señales abiertas)

## Decisiones del comité anterior
No hay decisiones registradas. Ninguna ficha tiene una decisión de comité anterior y no existe una corrida previa de `steering-pack`. El ciclo no se puede cerrar y este comité decide sin ese antecedente. Hay dos decisiones que sí se actuaron sin constar quién las tomó (ver punto 3).

## Decisiones de hoy

### [1] ¿Quién es la autoridad que aprueba cambios y presupuesto en cada proyecto, y se deja escrito en el acta?
**Proyecto:** los 13 · **Quién decide:** no está definido; por eso es el primer punto. Las actas nombran comité (Comité Ambiental, Comité de Inversiones) pero ninguna nombra autoridad de aprobación: `identity.authority` vacío en los 13. · **Si no se decide hoy:** los puntos 2 a 5 se deciden sin poder verificar que quien decide tenga la facultad.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. La autoridad es el comité que cada acta ya nombra; se documenta en el acta | Ninguno | Una ronda de actualización de actas | Esfuerzo de PMO |
| B. El comité decide solo cambios mayores y la PMO los menores, con umbral escrito | Ninguno | Requiere fijar el umbral antes | Esfuerzo de PMO |
| C. Se deja como está | Ninguno | Ninguno | Decisiones sin sustento verificable |

**Recomendación:** A. Es lo que las actas ya insinúan y no inventa una facultad nueva. B se puede pedir después, con el umbral escrito.

### [2] PRY-204 Monitoreo de taludes: ¿se aprueba CC-01 (ampliación de alcance, +73 días, +146.000.000 COP)?
**Proyecto:** PRY-204 · **Quién decide:** Comité Ambiental (el acta lo nombra; la autoridad no está escrita, ver punto 1). Patrocinador: Ricardo Salas. · **Si no se decide hoy:** el cronograma v2, fechado 2026-09-28, sigue en uso con 73 días movidos y 0 autorizados (17.4% sobre la línea base original). La solicitud es del 2026-10-14, 16 días después de que v2 ya existía.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar CC-01 | Ampliado (la solicitud no dice en qué) | +73 días sobre la vigente; fin 2027-06-22 | +146.000.000 COP |
| B. Rechazar | El original | Vuelve a la fecha de la v1 | Sin adicional |
| C. Devolver para sustentar; v1 sigue como línea base vigente | El original, por ahora | La v1 manda hasta decidir | Sin adicional, sin cuantificar el riesgo |

**Recomendación:** C. La solicitud dice «Ampliación de alcance» y nada más: no hay qué se amplía ni por qué, y el movimiento ya ocurrió sin autorización. Se decide en el siguiente comité con la justificación. Además hay dos riesgos de este proyecto (cambio de licencia ambiental, bloqueo de la vía) sin doliente.

### [3] PRY-211 Control de polvo en vías: la ampliación CC-01 (+103 días, +206.000.000 COP) figura «autorizada por el comité». ¿Se ratifica con acta o se decide de nuevo?
**Proyecto:** PRY-211 · **Quién decide:** Comité Ambiental (el acta lo nombra). El documento solo dice «el comité», sin cuál ni en qué fecha. Patrocinadora: Paula Céspedes. · **Si no se decide hoy:** la línea base ya se movió 103 días (23.0% sobre la original) con una autorización que nadie puede mostrar.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Ratificar con el acta que se aporte | Ampliado | +103 días ya reflejados; fin 2026-11-28 | +206.000.000 COP |
| B. Decidir hoy y dejarlo en acta | Ampliado o no, según lo que se resuelva | Igual que A, o se revierte | Igual que A, o se revierte |
| C. Revertir a la línea base anterior | El original | Se deshacen los 103 días | Sin adicional; trabajo ya hecho sobre v2 sin cuantificar |

**Recomendación:** A si el acta aparece antes del comité; si no aparece, B. Aprobar sin dejar constancia de quién aprobó es el mismo hueco del punto 1.

### [4] PRY-203 Despacho automático de flota: ¿se congelan los compromisos nuevos hasta tener un replan con evidencia, o se aprueba ya más presupuesto?
**Proyecto:** PRY-203 · **Quién decide:** Comité de Inversiones (el acta lo nombra). Patrocinador: Carlos Peña. · **Si no se decide hoy:** el hito «Montaje e instalación» (vencido 2026-10-04, 13 días) sigue sin fecha nueva y el proyecto sigue comprometiendo contra una proyección de 8.088.982.862 COP sobre 6.800.000.000 aprobados (19.0% de desviación, umbral 10%).
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar presupuesto hasta la proyección | Igual | Sin fecha nueva dada | 8.088.982.862 COP; no existe solicitud de cambio que lo sustente |
| B. Mantener 6.800.000.000 y recortar alcance | Menor, sin definir | Sin fecha nueva dada | Sin adicional |
| C. Congelar compromisos nuevos y pedir replan con evidencia | Igual | Atraso sigue corriendo hasta el replan | Congelado; comprometido 4.780.108.610 COP (70.3%), disponible real 2.019.891.390 COP |

**Recomendación:** C. La proyección descansa en un avance que los documentos no sostienen: el proyecto declara 26% y el plan sustenta entre 75% y 100%, y dos hitos «cumplidos» no tienen evidencia. Aprobar plata sobre una cifra sin sustento es lo que el comité debe evitar. El gerente (Felipe Arango) ya declara rojo, que es lo coherente.

### [5] PRY-207 Gemelo digital de la planta: ¿se ordena un diagnóstico independiente y se retira el verde hasta tenerlo?
**Proyecto:** PRY-207 · **Quién decide:** Comité Ambiental (el acta lo nombra). Patrocinador: Rubén Cárdenas. Gerente: Natalia Ospina. · **Si no se decide hoy:** un proyecto declarado verde (informe del 2026-09-29, 18 días) sigue comprometiendo: 80.1% comprometido, disponible real 1.354.398.540 COP, fin planeado 2026-11-25.
| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Diagnóstico independiente (`health-check`) y estado en revisión | Igual | Un ciclo de PMO | Esfuerzo de PMO |
| B. Pedir a la gerente replan y nueva declaración | Igual | Lo que tarde la gerente | Sin costo directo |
| C. Nada | Igual | Sin cambio | La desviación de 16.5% (proyección 7.922.563.459 COP sobre 6.800.000.000) sigue sin responsable |

**Recomendación:** A. Declara verde y los documentos dicen otra cosa: 4 señales sin explicar (20% declarado contra 75–100% que sustenta el plan; 3 hitos cumplidos sin evidencia; desviación de costo 16.5%; compromiso de Andrés Lozano vencido hace 7 días). Quien declara no debería ser quien lo verifica.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-200, 202, 205, 206, 207, 209, 210 | Siete proyectos declaran verde y los documentos no lo sostienen (`declared_vs_evidence`) | Informes del 2026-09-29 al 2026-10-16 | Que cada gerente reconcilie su estado con la evidencia; PRY-207 va en el punto 5 |
| PRY-211 | Proveedor Servicios Ambientales del Norte (CT-110): «Licenciamiento del software» vencido hace 386 días (2025-09-26) y «Bolsa de horas de ingeniería» hace 263 (2026-01-27), ambos pendientes; «Calibración de sensores» aceptada sin evidencia. Facturado y aceptado: 392.117.057 COP | Vencidos desde 2025-09-26 y 2026-01-27 | Decisión del patrocinador sobre el contrato; fuera de la autoridad de la gerente |
| PRY-211 | 5 compromisos vencidos (6 a 24 días) y 3 reprogramados: Ricardo Salas 6 veces (original 2026-09-17, hoy 2026-12-03), Rubén Cárdenas 4, Andrés Lozano 3. Más 2 sin fecha | Desde 2026-09-17 | Fecha firme y doliente por compromiso, o cancelarlo |
| PRY-208 | Declarado rojo; 37% declarado contra 100% que sustenta el plan; fin planeado 2026-01-04 (pasado); 3 hitos cumplidos sin evidencia; compromiso de Jorge Medina vencido hace 13 días | Fin planeado 2026-01-04 | Replan o cierre; no existe solicitud de cambio |
| PRY-200 y PRY-205 | Desviación de costo sobre el umbral de 10%: PRY-200 10.3% (proyección 2.647.931.269 sobre 2.400.000.000), PRY-205 12.8% (7.673.156.263 sobre 6.800.000.000). Ambos declaran verde | Informes del 2026-10-14 y 2026-10-15 | Solicitud de cambio o explicación; la autoridad que recibe esto no está escrita (punto 1) |
| PRY-209 | Declara 82%; el plan sustenta entre 33% y 67%. Compromiso de Liliana Torres vencido hace 25 días. Último informe hace 8 días | Compromiso vencido desde 2026-09-22 | Aclarar el avance real y la fecha del compromiso |

## Para conocimiento
- **PRY-199** Luminarias del campamento: verde, sin señales. Declara 20%; el plan sustenta entre 20% y 40%.
- **PRY-201** Ampliación de la relavera: amarillo; 2 hitos cumplidos sin evidencia; declara 29% contra 100% que sustenta el plan; un compromiso vencido (1 día); fin planeado 2026-08-05.
- **PRY-202** Planta de tratamiento de agua: verde contradicho; declara 54% contra 100%; fin planeado 2026-09-10 pasado; 2 hitos sin evidencia.
- **PRY-203, 204, 207, 211:** en los puntos 4, 2, 5 y 3.
- **PRY-205** Sistema de gestión de seguridad: verde con desviación de costo y un hito sin evidencia (escalamientos).
- **PRY-206** Red privada LTE: verde; un hito cumplido sin evidencia; sin otras señales.
- **PRY-208, 209, 210:** 208 y 209 en escalamientos. PRY-210 verde con el hito «Ingeniería de detalle aprobada» vencido hace 4 días (2026-10-13) y uno sin evidencia.
- **PRY-200:** verde; declara 66% contra 25–50% que sustenta el plan.

## Anexo

**Contradicciones abiertas (declarado contra evidencia):** 7 proyectos verdes contradichos (PRY-200, 202, 205, 206, 207, 209, 210). Hitos «cumplidos» sin evidencia: en 11 de 13 proyectos (todos salvo PRY-199 y PRY-200). El acta de PRY-211 dice producto «No aplica» y la ficha de la PMO no lo registra (`pm_vs_pmo`).

**Plata para verificar:** en PRY-201 lo ejecutado (9.566.897.487 COP) supera lo comprometido (8.639.382.262 COP), y lo mismo en PRY-210 (604.969.789 contra 493.839.884) y PRY-211 (1.465.714.221 contra 1.310.630.831). Un gasto ejecutado que supera lo comprometido pide revisar si hay compromisos sin registrar. No es una señal del umbral; es una observación.

**Dolientes:** los riesgos, incidencias y compromisos revisados para este paquete (PRY-203, 204, 207, 211) tienen doliente «no identificado». Los nombres que se repiten entre proyectos (Liliana Torres en 202, 209 y 211; Andrés Lozano en 207 y 211; Rubén Cárdenas en 207 y 211) son coincidencia de nombre en documentos distintos; no se verificó que sea la misma persona ni que haya sobrecarga.

**Vacíos de información:**
- `identity.authority`: vacío en los 13.
- `identity.phase`: vacío en los 13.
- `identity.product`: vacío en PRY-201, 202, 205, 206, 209, 210 y 211.
- PRY-199: facturado del proveedor sin dato.
- PRY-211: la ficha del PM tampoco tiene autoridad ni fase.
- Cadencia de silencio: ningún proyecto supera el umbral de 15 días (máximo 8, PRY-209).
- No hay dato de «dos períodos sin movimiento» (no hay corrida previa contra la cual medirlo).

**Qué no sé:** el contenido de los informes en PDF y de los cronogramas más allá de lo que la ficha extrajo; lo que se habló en comités fuera de los documentos; quién preside cada comité; qué justifica CC-01 en PRY-204 y PRY-211.

---
**Pie.** criterio-portfolio v0.4.0 · términos v1.1 · 13 fichas aplicadas (corte 2026-10-17) · campos inciertos: autoridad (13), fase (13), producto (7), doliente de riesgos · Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
