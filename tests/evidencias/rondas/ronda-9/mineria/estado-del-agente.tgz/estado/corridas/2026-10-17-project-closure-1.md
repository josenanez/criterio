# Corrida del 2026-10-17 · project-closure

13 proyectos · 40 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Cierre de PRY-201 no concluyente: sin declaración de cierre, criterio de éxito (en producción y medido) sin evidencia, 2 de 4 hitos cerrados sin acta, avance 29% contra 100% del plan, ejecutado mayor que comprometido; lecciones no sustentables salvo dos hechos; no se archiva.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Cierre de PRY-201 · Ampliación de la relavera. Sale de la ficha `estado/records/PRY-201.json` y de estos documentos: acta de constitución (2025-09-30), cronograma v1 (2025-09-30), las dos actas de recibo (2026-10-10 y 2026-10-14), el informe de avance (corte 2026-10-14) y el comité semanal (2026-10-14). Las cifras salen de `portafolio.py compute` (corte 2026-10-17). Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17 (versión 0.4.0), sin nuevo registro.

## Cierre — PRY-201 Ampliación de la relavera — 2026-10-17

**Veredicto: este proyecto no se puede cerrar contra su criterio de éxito.** Nadie ha declarado que terminó. El último documento de gerencia (informe del 2026-10-14) lo reporta en **amarillo, con 29 % de avance**, no como terminado. Lo que sigue es lo que la documentación permite decir hoy, no un acta de cierre. Cerrarlo ahora sería una decisión del comité, no un cumplimiento.

### Contra lo comprometido
**Criterio de éxito:** "Ampliación de la relavera en producción y medido." (acta de constitución, 2025-09-30).
**Se cumplió:** no se puede determinar. No hay en la carpeta ningún documento de puesta en producción ni de medición.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Ingeniería básica aprobada (base 2025-12-23) | Cerrado, con acta | Acta de recibo del 2026-10-14, recibida por Diana Molina |
| Ingeniería de detalle aprobada (base 2026-03-08) | Cerrado, con acta | Acta de recibo del 2026-10-10, recibida por Diana Molina |
| Licencia y permisos obtenidos (base 2026-05-22) | Marcado "cerrado" en el cronograma, **sin evidencia** | Ninguna (vencido hace 148 días según el script) |
| Montaje e instalación (base 2026-08-05) | Marcado "cerrado" en el cronograma, **sin evidencia** | Ninguna (vencido hace 73 días según el script) |

Los cuatro hitos del cronograma figuran como cerrados, pero el avance declarado es 29 %. El plan sostendría 100 % (4 de 4), así que hay una brecha de 71.0 puntos. Una de las dos cifras está mal, y los documentos no dicen cuál.

Además, las dos actas de recibo llevan fecha de octubre de 2026, mucho después de las fechas de línea base de esos hitos (2025-12-23 y 2026-03-08). El cronograma no registra ninguna fecha vigente distinta.

El alcance del acta es "Componente 1, Componente 2, Componente 3". Son marcadores sin contenido y no se pueden contrastar con nada entregado. La exclusión ("Lo que otro proyecto cubre") tampoco nombra qué queda fuera.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Ninguno registrado | — | — |

Control de cambios: 0 cambios en la ficha. No hay recorte de alcance registrado. El informe de avance menciona un riesgo de "cambio en la licencia ambiental que puede mover el alcance". Si eso ocurrió, no está decidido en ningún documento.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-05 | 2026-08-05 | sin fecha de cierre real | 0 días contra la fecha original (según el script) |
| Presupuesto aprobado (COP) | 18.000.000.000 | 18.000.000.000 | proyección 18.881.311.733 | 4.9 % por encima de lo aprobado (según el script) |

Replanificaciones: 0.

- La desviación de fecha de 0 días es formal: la línea base nunca se movió. Pero la fecha comprometida (2026-08-05) pasó hace 73 días y no hay cierre. No es lo mismo que cumplir.
- Presupuesto ejecutado: 9.566.897.487 COP (53.1 % del aprobado). Comprometido: 8.639.382.262 COP (48.0 %).
- El ejecutado es mayor que el comprometido, lo cual es anómalo. Hay que aclararlo antes de cualquier cierre financiero.
- Con los hitos de montaje cerrados y el 53.1 % ejecutado, el dato del 100 % de plan frente al 29 % de avance es otra señal de que el reporte y el cronograma no cuadran.

### RAID al cierre
**Materializados:** no se puede determinar. El registro tiene un solo riesgo y no dice si ocurrió.
**No materializados:** ninguno confirmado.
**Abiertos, con doliente:**
- Riesgo: cambio en la licencia ambiental que puede mover el alcance (informe 2026-10-14). **Doliente: no identificado.** Mientras no tenga nombre, no está cerrado.
- Compromiso de Elena Duarte, "Entregar el punto 24", para el 2026-10-16. **Vencido hace 1 día**, sin evidencia (comité del 2026-10-14).
- Compromiso de Camilo Beltrán, "Entregar el punto 12", para el 2026-10-26. Abierto, dentro de plazo.
- Los "puntos" 24 y 12 no se explican en el acta del comité, así que no se sabe de qué entregables son.

Incidencias y dependencias: ninguna registrada. El acta declara "Ninguna declarada" en dependencias.

### Lecciones
Ninguna lección se puede sustentar todavía. Hay hechos con fecha, pero no hay efecto documentado. Lo que sí está anclado:

| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| Los dos hitos con evidencia se recibieron en octubre de 2026, con línea base de 2025-12-23 y 2026-03-08, y el cronograma nunca se replanificó | Actas del 2026-10-10 y 2026-10-14 | No se puede determinar si hubo atraso real o solo registro tardío del recibo | Registrar el recibo cuando ocurre, y replanificar con motivo cuando una fecha se mueve. Queda condicionado a aclarar qué pasó |
| Dos hitos marcados cerrados sin acta | Cronograma v1, estado actual | Avance declarado y plan sostenido no coinciden (29 % frente a 100 %) | Pedir el acta de recibo como condición para marcar un hito cerrado |

La segunda fila describe una disciplina que falta y no una lección de causa y efecto. El resto de aprendizajes ("mejorar la comunicación" y similares) no entra porque ningún documento lo ancla.

### Sin dato
- Declaración de cierre del gerente o del comité. No existe.
- Evidencia de puesta en producción y de medición (criterio de éxito).
- Actas de recibo de "Licencia y permisos obtenidos" y de "Montaje e instalación".
- Contenido real de los componentes 1, 2 y 3 del alcance.
- Qué son los puntos 24 y 12 de los compromisos del comité.
- Por qué el ejecutado supera al comprometido.
- Fase del proyecto y producto asociado (la ficha los declara sin dato; el acta dice "No aplica" para producto).
- Si el riesgo de la licencia ambiental ocurrió, y quién responde por él.

### Qué recomiendo
No archivar PRY-201 ni congelar su ficha. Ofrecí mover la carpeta a `archivo/`, y la respuesta tomada es no hacerlo, porque un proyecto sin cierre declarado sigue en el barrido diario. Antes de volver a correr el cierre, el comité debería (1) pedir a Diana Molina el estado real de cada hito con su acta, (2) asignar doliente al riesgo de licencia, y (3) decidir si el proyecto se cierra por cumplimiento o por decisión.

*Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los documentos citados; la verificación es de quien lo usa. Lo que se habló fuera de los documentos no se conoce.*
