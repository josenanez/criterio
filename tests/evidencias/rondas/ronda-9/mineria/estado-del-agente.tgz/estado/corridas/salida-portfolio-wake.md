## 2026-10-17

**Revisé:** 76 documentos · 0 cambiaron · 0 proyectos recalculados. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Sin peticiones en el servidor.

### Lo que cruzó un umbral
- **PRY-204 (monitoreo de taludes):** última declaración de estado del 2026-09-28, hace 19 días; el umbral de silencio es 15. Cita: `PRY-204-monitoreo-de-taludes/20-seguimiento/2026-09-28-informe-avance.pdf`.
- **PRY-207 (gemelo digital de la planta):** última declaración del 2026-09-29, hace 18 días; umbral 15. Cita: `PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-09-29-informe-avance.pdf`.
- Este hallazgo sale de las fichas existentes; el barrido no recalculó nada porque ningún documento cambió.

### Hallazgo de formato (no es un cambio de documentos)
- El índice no resuelve 22 citas de la ficha de PRY-211 (identidad, plan, dinero, factura CT-110). Los archivos citados existen en la carpeta del proyecto. Las citas de PRY-211 están escritas sin el prefijo de la carpeta del proyecto (`00-gobierno/…`), a diferencia de las otras 12 fichas (`PRY-xxx-…/00-gobierno/…`). Parece un problema de ruta de la ficha, no un documento borrado. No lo corregí: queda para que lo revise quien mantiene la ficha.

### Peticiones atendidas
Ninguna.

### Preguntas (5 de confirmación, no respondidas en esta corrida)
1. **PRY-204, estado declarado** (amarillo, 2026-09-28): ¿sigue vigente o hay un informe más reciente que no está en la carpeta?
2. **PRY-207, estado declarado** (verde, 2026-09-29): ¿sigue vigente o hay un informe más reciente que no está en la carpeta?
3. **PRY-211, avance declarado** (82 %, informe del 2026-10-14): el ejecutado es 1.465.714.221 de 4.200.000.000 aprobados (~35 %); ¿a qué se refiere el 82 %?
4. **PRY-209, avance declarado** (82 %, informe del 2026-10-09): el ejecutado es 268.110.385 de 1.200.000.000 aprobados (~22 %); ¿a qué se refiere el 82 %?
5. **PRY-211, fecha de fin del plan:** el cronograma v2 es del 2026-10-14 y hay una solicitud de cambio CC-01 del 2026-10-07; ¿está aprobada la nueva fecha?

**Vuelvo el 2026-10-18.**
