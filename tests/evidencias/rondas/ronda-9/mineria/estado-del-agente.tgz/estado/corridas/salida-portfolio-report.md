# Portafolio — 2026-10-17

Cargué las 13 fichas de `estado/records/` (generadas el 2026-10-17, barrido de hoy). Ninguna tiene más de una semana sin barrido.
13 proyectos · 12 con hallazgos · 67 señales · último barrido 2026-10-17

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Qué cambió desde la instantánea anterior
Sin cambios, pero con una salvedad: la única instantánea que existe es la de hoy (`snapshots/2026-10-17.json`), y el diff contra ella da 0 cambios. Este es el punto de partida, no hay delta real que reportar.

## Contradicciones abiertas
| Proyecto | Campo | Dice | Fuente | Dice también | Fuente |
|---|---|---|---|---|---|
| PRY-211 | identity.product | (PMO: sin producto) | ficha PMO | «No aplica» | 00-gobierno/2025-05-16-acta-constitucion.md |

Ningún proyecto tiene campos `ambiguous` entre documentos. Tampoco hay cambios de gobierno (personas distintas por rol) contra la corrida anterior ni contra el acta.

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-203 | Montaje e instalación | 2026-10-04 | 13 | informe de avance 2026-10-14 (declara rojo) |
| PRY-210 | Ingeniería de detalle aprobada | 2026-10-13 | 4 | informe de avance 2026-10-16 (declara verde) |

Compromisos de reunión vencidos (9 en 6 proyectos): PRY-211 (5: Javier Hoyos, Liliana Torres, Beatriz Cuéllar ×2, Rubén Cárdenas; 6 a 24 días), PRY-209 (Liliana Torres, 25 días), PRY-207 (Andrés Lozano, 7 días), PRY-208 (Jorge Medina, 13 días), PRY-201 (Elena Duarte, 1 día).
Reprogramados en PRY-211: Ricardo Salas «Enviar el documento 1» 6 veces (original 2026-09-17, hoy 2026-12-03); Rubén Cárdenas «Cerrar la prueba 2» 4 veces; Andrés Lozano «Validar el ambiente 4» 3 veces.
Sin fecha: PRY-202 (Liliana Torres), PRY-203 (Óscar Ramírez), PRY-211 (Diana Molina; Laura Vélez «la otra semana»).

## Proyectos en silencio
Vacía. Ningún proyecto supera el umbral de 15 días; el más callado es PRY-209 con 8 días (último informe 2026-10-09).

## Dependencias en riesgo
Vacía. Ninguna ficha declara dependencias entre proyectos por código.

## Sin sustento
Siete proyectos declaran verde y las señales lo contradicen. En todo el portafolio, 0 de las fuentes están marcadas como evidencia: son declaraciones.

| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-200 | verde, 66 % | El plan sostiene 25–50 % (1 de 4 hitos); proyección de costo +10,3 % |
| PRY-202 | verde, 54 % | Los 4 hitos figuran cumplidos, pero 2 sin evidencia (343 y 241 días) |
| PRY-205 | verde, 44 % | Hito «Ingeniería básica» sin evidencia; costo proyectado +12,8 % |
| PRY-206 | verde, 34 % | Hito «Ingeniería básica» cumplido sin evidencia (83 días) |
| PRY-207 | verde, 20 % (informe de hace 18 días) | 3 hitos sin evidencia; costo +16,5 %; compromiso vencido |
| PRY-209 | verde, 82 % | El plan sostiene 33–67 %; hito sin evidencia; compromiso vencido 25 días |
| PRY-210 | verde, 45 % | Hito vencido hace 4 días; otro cumplido sin evidencia |

También hay hitos declarados cumplidos sin documento que lo pruebe en PRY-201 (2), PRY-203 (2), PRY-204 (2), PRY-208 (3) y PRY-211 (4). En proveedores: PRY-211, Servicios Ambientales del Norte (CT-110) tiene 2 entregables pendientes y vencidos (386 y 263 días) y «Calibración de sensores» aceptado sin evidencia de recibo; el monto facturado es COP 392.117.057.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad (identity.authority) y fase (identity.phase) |
| PRY-201, 202, 205, 206, 209, 210, 211 | Producto asociado |
| PRY-199 | Monto facturado del proveedor CT-199 |
| PRY-201, 202, 207, 208, 211 | Campos con fuente de hace 13 a 17 meses (por encima del umbral de 12) |

## Estado general
Desviación en tiempo contra la fecha de fin; costo es la proyección sobre lo aprobado.

| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 | verde | sin señales | 0 d | 0 d | 0 |
| PRY-200 | verde | contradicho (avance, costo) | 0 d; costo +10,3 % | 0 d | 0 |
| PRY-201 | amarillo | 3 señales sin explicar | 0 d; costo +4,9 % | 0 d | 0 |
| PRY-202 | verde | contradicho (hitos, avance) | 0 d; costo −3,5 % | 0 d | 0 |
| PRY-203 | rojo | 4 señales; fin 2026-10-04 vencido | 0 d; costo +19,0 % | 0 d | 0 |
| PRY-204 | amarillo (hace 19 días) | rebaseline +73 d sin autorización | +73 d (17,4 %) | 0 d | 1 |
| PRY-205 | verde | contradicho (hito, costo) | 0 d; costo +12,8 % | 0 d | 0 |
| PRY-206 | verde | contradicho (hito) | 0 d; costo −7,7 % | 0 d | 0 |
| PRY-207 | verde (hace 18 días) | contradicho (4 señales) | 0 d; costo +16,5 % | 0 d | 0 |
| PRY-208 | rojo | 3 señales; fin 2026-01-04 | 0 d; costo −3,9 % | 0 d | 0 |
| PRY-209 | verde | contradicho (3 señales) | 0 d; costo −2,6 % | 0 d | 0 |
| PRY-210 | verde | contradicho (hito vencido, hito sin evidencia) | 0 d; costo +1,2 % | 0 d | 0 |
| PRY-211 | amarillo | 6 señales sin explicar | +103 d (23,0 %), aprobado en control de cambios | 0 d | 1 |

Dos casos que el comité no debería pasar por alto: PRY-204 movió su línea base 73 días sin ningún cambio autorizado; y PRY-201, 202 y 208 tienen fecha de fin ya pasada (2026-08-05, 2026-09-10, 2026-01-04) con avance declarado de 29 %, 54 % y 37 %.

Recursos repetidos: Liliana Torres tiene compromisos abiertos en PRY-202, PRY-209 (vencido 25 días) y PRY-211 (vencido 24 días); Andrés Lozano en PRY-207 (vencido) y PRY-211 (reprogramado 3 veces); Rubén Cárdenas tiene 2 compromisos con problemas en PRY-211.

## Necesito que confirmes
Sin sesión interactiva, tomo la respuesta sugerida en cada una y lo dejo dicho. Cinco preguntas cerradas (los campos más viejos entre los que importan):
1. PRY-208: ¿la fecha de fin 2026-01-04 (fuente del 2025-06-06) sigue vigente? Sugerido: no, pedir la fecha actual al gerente.
2. PRY-202: ¿la fecha de fin 2026-09-10 (fuente del 2025-07-19) sigue vigente? Sugerido: no, pedir la fecha actual.
3. PRY-201: ¿la fecha de fin 2026-08-05 (fuente del 2025-09-30) sigue vigente? Sugerido: no, pedir la fecha actual.
4. PRY-211: ¿es correcto que no construye ningún producto («No aplica», acta de 2025-05-16)? Sugerido: confirmar con el patrocinador.
5. Los 13 proyectos: ¿quién es la autoridad que aprueba cambios? Sugerido: pedir el nombre en el acta de cada uno.

Las respuestas quedan pendientes; no cambié ninguna ficha.

---
**Dónde quedó el informe:** `/home/claude/banco/ronda-9/mineria/espacio/reportes/` (23 páginas: `index.html`, `decisiones.html` y una por proyecto).
- `index.html` — por campo, con la cadena de evidencia completa: para quien va a actuar (PMO, gerentes).
- `decisiones.html` — por decisión: para el patrocinador y el comité del 2026-10-23.
Para PDF, imprimir el HTML desde el navegador.

**Pie:** criterio-portfolio 0.4.0 · fichas aplicadas: 13, fechadas 2026-10-17 · campos inciertos: autoridad y fase (13 proyectos), producto (7), fechas de fin con fuente de más de 12 meses (5) · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
