# Corrida del 2026-10-17 · budget-tracking

13 proyectos · 30 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Presupuesto de PRY-207: proyección 16.5% sobre el aprobado, ejecutado 59.7% contra avance declarado 20%, tres hitos cumplidos sin evidencia. No supo: autoridad, fase, contratos de proveedor ni respaldo contable de las cifras.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Fuente: ficha `estado/records/PRY-207.json` y `portafolio.py compute`, calculado al 2026-10-17. Documentos de origen: acta de constitución (2025-08-17), informe de avance (2026-09-29), cronograma v1 (2025-08-17).

## Presupuesto — PRY-207 Gemelo digital de la planta, al 2026-10-17
**Moneda:** COP (una sola; no hay contratos en otra moneda ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 6.800.000.000 | 100 | 00-gobierno/2025-08-17-acta-constitucion.docx | 2025-08-17 |
| Comprometido | 5.445.601.460 | 80.1 | 20-seguimiento/2026-09-29-informe-avance.pdf | 2026-09-29 |
| Ejecutado | 4.062.393.959 | 59.7 | 20-seguimiento/2026-09-29-informe-avance.pdf | 2026-09-29 |
| Proyección al cierre | 7.922.563.459 | excede el aprobado en 16.5 | 20-seguimiento/2026-09-29-informe-avance.pdf | 2026-09-29 |

**Disponible real** (aprobado menos comprometido): 1.354.398.540 COP

La proyección es una declaración del informe de avance, no un dato medido. Tiene 18 días y no es más vieja que ningún movimiento de presupuesto: no hay solicitudes de cambio registradas.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 6.800.000.000 | 6.800.000.000 | sin movimiento |
| Proyección frente al aprobado | | | +16.5 % |

Replanificaciones: 0. Solicitudes de cambio: 0. La línea base es una sola (v1, 2025-08-17).

### Ejecución frente a avance
Ejecutado 59.7 % · Hitos cumplidos 3 de 4 · Avance declarado 20 %, mientras el plan sostiene entre 75 y 100 %.
Lectura: la plata va por encima del avance que el propio proyecto declara (59.7 % ejecutado contra 20 % de avance), y los hitos que se dicen cumplidos no tienen evidencia. Las tres cifras no se pueden reconciliar con los documentos que hay.

### Alertas
- **Proyección por encima del aprobado:** 16.5 % de desviación en costo, contra un umbral de 10 %.
- **Ejecución desalineada del avance:** brecha de 55 puntos entre el avance declarado y lo que sostiene el plan.
- **Tres hitos en `met` sin evidencia de recibo:** Ingeniería básica (vencía 2025-12-18, 303 días), Ingeniería de detalle (2026-04-11, 189 días) y Licencia y permisos (2026-08-03, 75 días).
- **Estado declarado «verde» (2026-09-29)** frente a cuatro señales abiertas que el informe no recoge: costo, avance contra plan, hitos sin evidencia y compromiso vencido.
- **Compromiso vencido:** Andrés Lozano, «Entregar el punto 14», vencía el 2026-10-10 (7 días), según el acta del comité del 2026-10-12.
- El comprometido (80.1 %) está por debajo del umbral de 90 %: no hay alerta por ese concepto, pero el disponible real es 1.354.398.540 COP frente a una proyección que ya excede el aprobado.

### Sin dato
- Autoridad que aprueba y fase del proyecto no están declaradas.
- Los cuatro importes salen del acta y de un informe de avance en PDF; ninguno viene de un documento marcado como evidencia (ejecutado y comprometido no están respaldados por extracto contable ni facturas).
- No hay contratos de proveedor registrados, así que no se puede abrir el comprometido por proveedor.
- Los campos de identidad y plan tienen 14 meses (umbral de 12) y piden confirmación.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio (`/criterio-portfolio:change-control`). El detalle por proveedor no se puede hacer hasta que haya contratos registrados.

---
**Pie de rigor:** borrador de trabajo, no decisión ni asesoría. Cada cifra sale de `portafolio.py compute` y de la ficha, con la cita del documento; la verificación es de quien lee. No se asumió nada que no esté en los documentos.
