## Carpeta al 2026-10-17

**Documentos:** 76 · **Sin cambio:** 76 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
22 citas, todas de PRY-211. Los documentos citados SÍ existen en la carpeta; lo que no resuelve es la ruta con la que están escritas.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-211 | identity.code, name, business_area, product, authority, sponsor, manager, committee (8 campos) | 00-gobierno/2025-05-16-acta-constitucion.md |
| PRY-211 | plan.start_date, scope_summary, exclusions (3) | 00-gobierno/2025-05-16-acta-constitucion.md |
| PRY-211 | money.currency, money.approved (2) | 00-gobierno/2025-05-16-acta-constitucion.md |
| PRY-211 | identity.phase, declared.status, declared.progress_pct, declared.as_of (4) | 20-seguimiento/2026-10-14-informe-avance.md |
| PRY-211 | money.committed, executed, projection (3) | 20-seguimiento/2026-10-14-informe-avance.md |
| PRY-211 | plan.end_date | 10-plan/2026-10-14-cronograma-v2.xlsx |
| PRY-211 | vendors[0].invoiced | 20-seguimiento/2026-08-30-factura-ct-110.pdf |

Causa probable: existe una ficha duplicada en `estado/PRY-211-control-de-polvo-en-vías/records/PRY-211.json` cuyas citas no llevan el prefijo de la carpeta del proyecto; la ficha de `estado/records/PRY-211.json` sí lo lleva. No he corregido nada.

### Formatos que no se pudieron leer
Ninguno (este comando no lee contenido).

**Qué ofrezco:** no hay documentos por releer, así que no hace falta `/portfolio-scan`. Si quieres, reviso y corrijo las citas de la ficha duplicada de PRY-211, mostrando cada cambio.
