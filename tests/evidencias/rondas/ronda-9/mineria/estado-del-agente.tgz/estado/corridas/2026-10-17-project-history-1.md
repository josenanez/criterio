# Corrida del 2026-10-17 · project-history

13 proyectos · 109 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Historia de PRY-211 sobre 21 documentos (2025-05-16 a 2026-10-17). 1 replanificación, 103 días (23.0 %) contra la original, 0 cambios de gobierno documentados. Dije que no sé: meses declarando sin sustento (una sola declaración de estado), qué pasó entre 2025-05-18 y 2026-08-30, quién autorizó CC-01 y cuándo se editaron cronograma v1 y contrato.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Historia · PRY-211 Control de polvo en vías · 2025-05-16 a 2026-10-17

**Leí:** 21 documentos entre 2025-05-16 y 2026-10-17 (20 llevan fecha en el nombre; `ficha-pm.json` no tiene fecha propia, y la usé solo como la declaración del gerente, con las fechas de sus fuentes).
**Trimestres sin un solo documento:** 2025-T3, 2025-T4, 2026-T1 y 2026-T2. Entre el contrato (2025-05-18) y la factura (2026-08-30) la carpeta no tiene ningún documento fechado.

*Prueba sin interfaz: términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-17 (versión 0.4.0). No hubo preguntas.*

### En una línea
El proyecto nació con acta, cronograma v1 y contrato firmados entre el 2025-05-16 y el 2025-05-18, y después la carpeta guarda 15 meses de silencio hasta la factura del 2026-08-30. Todo lo demás es de las seis semanas finales: seis comités semanales (2026-09-05 a 2026-10-10), una solicitud de cambio (CC-01, 2026-10-07) que mueve el cierre del 2026-08-17 al 2026-11-28, y un informe de avance (2026-10-14) que declara amarillo y 82 %. Cuatro de los cinco hitos figuran como cumplidos sin un solo documento que lo respalde, y la línea base nueva llegó después de la fecha de cierre original.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 103 días (23.0 %) | **No calculable.** Existe una sola declaración de estado (2026-10-14); no hay serie, y el script no entrega esta cifra | 0 documentados |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-05-16 | `00-gobierno/2025-05-16-acta-constitucion.md` | Nace el proyecto: 4.200.000.000 COP, inicio 2025-05-26, cierre 2026-08-17. Alcance genérico («Componente 1, 2, 3»). Patrocinadora Paula Céspedes, gerente Liliana Torres, Comité Ambiental |
| 2025-05-16 | `10-plan/2025-05-16-cronograma-v1.csv` | Línea base v1, cinco hitos. **Los cinco aparecen «cerrado»,** incluido «Pruebas en operación» (2026-08-17): el estado es posterior a la fecha del archivo |
| 2025-05-18 | `00-gobierno/2025-05-18-contrato-ct-110.md` | Contrato con Servicios Ambientales del Norte, tres entregables de 392.117.057 COP. **Calibración de sensores (vence 2026-05-30) ya figura «recibido»** en un contrato firmado en 2025: también es un estado posterior a la fecha del archivo |
| 2025-05-18 → 2026-08-30 | — | Sin documentos |
| 2026-08-30 | `20-seguimiento/2026-08-30-factura-ct-110.pdf` | Factura FV-1110 por 392.117.057 COP, «Entregables del contrato CT-110», radicada en cuentas por pagar. No hay acta de recibo en la carpeta |
| 2026-09-05 | `30-reuniones/…-comite-semanal.md` | Primer comité escrito. 4 compromisos abiertos. La patrocinadora no figura entre los asistentes |
| 2026-09-12 | ídem | 8 compromisos; primeras fechas movidas |
| 2026-09-19 | ídem | 12 compromisos; aparecen Diana Molina y Javier Hoyos |
| 2026-09-26 | ídem; actas de recibo 5, 8 y 11 | Primeros cierres con acta (3). Javier Hoyos dice que entregó «cerrar la prueba 10»; no hay acta. Aparece Beatriz Cuéllar |
| 2026-10-03 | ídem; actas de recibo 6 y 7 | Dos cierres con acta. Aparece Felipe Arango |
| 2026-10-07 | `20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md` | CC-01: ampliación de alcance, +103 días, +206.000.000 COP. «Autorizada por el comité» |
| 2026-10-10 | ídem; acta de recibo 13 | Un cierre con acta. Felipe Arango dice que entregó «cerrar la prueba 18»; no hay acta. Aparecen Camilo Beltrán y Gustavo Neira |
| 2026-10-14 | `10-plan/2026-10-14-cronograma-v2.xlsx` | Línea base v2: cierre 2026-11-28 |
| 2026-10-14 | `20-seguimiento/2026-10-14-informe-avance.md` | Amarillo, 82 %. Dice que se recibió el permiso ambiental y que las lluvias detuvieron el montaje diez días |
| 2026-10-17 | `2026-10-17-notas-reunion.txt` | Notas informales. Aparece Óscar Ramírez. Se comenta un riesgo del proveedor que nadie anotó. «Próxima reunión en dos semanas» |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-14 (v2) | 2026-11-28 | «Ampliación de alcance» (CC-01, 2026-10-07) | CC-01 dice «autorizada por el comité». **No dice qué comité ni en qué fecha;** no hay acta de ese comité en la carpeta |

- Atraso contra la línea base original: 103 días (23.0 %). Contra la vigente: 0.
- La línea base v2 se aprobó después de la fecha de cierre original (2026-08-17). Entre esa fecha y la solicitud del 2026-10-07 no hay ningún documento de cambio.
- El informe del 2026-10-14 sigue mostrando como «Aprobado» 4.200.000.000 COP; los 206.000.000 COP de CC-01 no aparecen en ese cuadro.
- El alcance original es tan genérico («Componente 1, 2, 3») que no se puede decir qué es lo que se amplió.
- Causas citadas en el informe (lluvias, permiso pendiente) no se mencionan en CC-01; el único motivo documentado de la replanificación es la ampliación de alcance.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité está documentado | — |
| 2026-09-05 → 2026-10-17 | Se suman a los comités, sin acta de designación: Jorge Medina y Paula Céspedes (2026-09-12), Diana Molina y Javier Hoyos (2026-09-19), Beatriz Cuéllar (2026-09-26), Felipe Arango (2026-10-03), Camilo Beltrán y Gustavo Neira (2026-10-10), Óscar Ramírez (2026-10-17). Jorge Medina deja de aparecer desde 2026-09-26 y Javier Hoyos desde 2026-09-26 | Actas de comité y notas |
| 2026-10-17 | «Próxima reunión en dos semanas»: los comités eran semanales | `2026-10-17-notas-reunion.txt` |

La gerente (Liliana Torres) es a la vez solicitante de CC-01, quien firma como receptora todas las actas de recibo, y responsable de un compromiso vencido («Validar el ambiente 12», 2026-09-23). Es un dato de la estructura, no una conclusión sobre nadie.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 6 | 2026-09-17 (original) → 10-02 → 10-20 → 10-28 → 11-06 → 11-19 → 12-03 |
| Rubén Cárdenas | Cerrar la prueba 2 | 4 | 2026-10-02 (original) → 10-09 → 10-21 → 11-02 → 11-15 |
| Andrés Lozano | Validar el ambiente 4 | 3 | 2026-09-25 (original) → 10-14 → 10-28 → 11-14 |

Debajo del umbral (2 movimientos, no lo marca el script): Laura Vélez, «Revisar el anexo 3»: 2026-10-02 → 10-22 → 11-03.

Cada fecha se movió antes de vencer, de modo que ninguno de estos compromisos figura vencido. Los vencidos sin evidencia son otros: Javier Hoyos «Cerrar la prueba 10» (2026-09-27, 20 días), Liliana Torres «Validar el ambiente 12» (2026-09-23, 24 días, la misma fecha en cuatro comités), Beatriz Cuéllar «Actualizar la matriz 14» (2026-10-10, 7 días) y «Confirmar la fecha 15» (2026-10-06, 11 días), Rubén Cárdenas «Entregar el punto 16» (2026-10-11, 6 días). Sin fecha: Diana Molina «Enviar el documento 9» y Laura Vélez «Mandar el ajuste del presupuesto» («la otra semana»).

La fecha «03/12/2026» de las notas del 2026-10-17 la leí como 3 de diciembre; el formato es ambiguo y conviene confirmarlo.

### Desde cuándo lo declarado no se sostiene
**Desde 2025-08-23**, la fecha del primer hito, «Ingeniería básica aprobada», declarado cumplido sin evidencia. Les siguen «Ingeniería de detalle aprobada» (2025-11-21), «Licencia y permisos obtenidos» (2026-02-18) y «Montaje e instalación» (2026-05-19): 420, 330, 241 y 151 días de vencidos sin un solo documento de respaldo. Hay un quinto hito, «Pruebas en operación», también «cerrado», con fecha vigente 2026-11-28, es decir, todavía no vencida.

Lo que se siguió reportando después: el 2026-10-14, 82 % y amarillo, y en ese mismo informe se habla de un permiso ambiental recién recibido y de lluvias que detuvieron el montaje, dos hitos que el cronograma da por cerrados desde febrero y mayo. Contra el cronograma, los cinco hitos cumplidos sustentarían el 100 %; el declarado queda 18 puntos por debajo. Además, 34.9 % del presupuesto está ejecutado y 31.2 % comprometido (el ejecutado supera al comprometido).

Límite: como hay una sola declaración de estado, la fecha es la del primer hito vencido sin evidencia, no la de un cambio en un semáforo. No puedo decir cuándo se declaró cada hito como cumplido.

### Proveedor (CT-110)
Licenciamiento del software (vence 2025-09-26, 386 días) y Bolsa de horas de ingeniería (2026-01-27, 263 días) siguen pendientes. Calibración de sensores consta como recibida, sin acta de recibo. La factura del 2026-08-30 por 392.117.057 COP (el valor de un entregable) se radicó, y el contrato condiciona el pago a un acta de recibo firmada por el gerente: esa acta no está en la carpeta.

### Lecciones ancladas a un hecho
1. **Un hito cumplido necesita un documento.** Cuatro hitos vencidos entre 2025-08-23 y 2026-05-19 figuran como cerrados sin evidencia; el avance de 82 % del 2026-10-14 no se puede contrastar con nada.
2. **La línea base nueva llegó tarde.** El cierre original era el 2026-08-17 y CC-01 es del 2026-10-07, la v2 del 2026-10-14. Por ese tramo el plan vigente ya estaba vencido.
3. **Mover la fecha antes de que venza oculta el atraso a la alarma, no a los datos.** «Enviar el documento 1» se movió seis veces (la primera, el 2026-09-12) sin vencer nunca; el calendario del comité lo muestra siempre «al día».
4. **Decir «ya entregué» no es entregar.** Dos casos (prueba 10 el 2026-09-26, prueba 18 el 2026-10-10) sin acta, a diferencia de los seis compromisos que sí se cerraron con acta de recibo.
5. **Una factura sin acta rompe la condición de pago.** FV-1110 (2026-08-30) está radicada y el contrato exige acta firmada.
6. **Un riesgo dicho en voz alta no es un riesgo registrado.** El 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo; ya tenía dos entregables vencidos (386 y 263 días).
7. **Una autorización sin nombre no es una autorización.** CC-01 dice «el comité» sin comité ni fecha, y movió el cierre 103 días.

### Lo que no sé
- La serie de estados declarados antes del 2026-10-14 (no existe en la carpeta), y por tanto los «meses declarando sin sustento».
- Qué se hizo entre 2025-05-18 y 2026-08-30: la carpeta no lo dice, y no puedo afirmar que no se hiciera nada.
- Cuándo se editaron `cronograma-v1.csv` y el contrato para quedar con los estados actuales: la fecha del nombre no es la del contenido.
- Quién autorizó CC-01, y si hubo un comité distinto de los seis escritos.
- Qué se amplió exactamente en el alcance.

*La historia no atribuye intención: que el atraso no apareciera en los documentos no dice que alguien lo ocultara. Sirve para tener esa conversación con datos, y quién la tiene es una persona.*

### Siguiente paso
Puedo llevar esta historia al cierre del proyecto o al comité del 2026-10-23, donde hay dos decisiones que salen de ella: ratificar CC-01 con comité y fecha, y exigir el acta de recibo de FV-1110 antes del pago.

---
**Rigor:** cifras derivadas copiadas de `portafolio.py compute` (as_of 2026-10-17); las fechas, textos y conteos de asistentes, de los documentos citados. Cada afirmación remite a la carpeta `documentos/proyectos/PRY-211-control-de-polvo-en-vías/`. Es un borrador de trabajo: la verificación es suya.
