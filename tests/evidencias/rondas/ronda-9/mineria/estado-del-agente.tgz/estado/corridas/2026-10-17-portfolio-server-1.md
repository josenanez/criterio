# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 67 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

puerto 8787, informe en reportes/, modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hizo falta pedirlos de nuevo.

Modo elegido: **para mirarlo un rato** (respuesta sugerida: es la forma que se levanta en diez segundos y no pide nada a seguridad).

Hay informe en `reportes/` (13 proyectos, 6 productos, decisiones y portada), así que se puede servir.

Comando:

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las tres secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado ordenado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, enlazado a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, enlazado a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

Lo que no hace: no calcula (sirve lo que ya escribió `informe.py`), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos.

Este modo no tiene enlace estable: al apagarlo, el enlace deja de funcionar. Si después se quiere que quede corriendo, se usa `--abierto` y hay que pedirle a la organización un host y puerto internos, publicarlo detrás de su control de acceso y mantener el equipo encendido; nada más.

Cierre: en este modo el enlace es `http://127.0.0.1:8787/` y solo sirve en este equipo, para quien esté sentado aquí. No se le puede pasar al patrocinador. El informe es del 2026-10-17 y queda desactualizado en cuanto cambie algún documento o se corra un nuevo barrido; la portada muestra su fecha.
