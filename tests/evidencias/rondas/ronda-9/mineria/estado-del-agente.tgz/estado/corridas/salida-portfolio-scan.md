## Barrido — 2026-10-17

Encontré la configuración en `.criterio/portafolio/config.json` y los términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos otra vez). Un solo lote, un proyecto tras otro, sin subagentes (`workers: 1`).

**Documentos:** 76 en la carpeta · 47 leídos · 29 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con ficha · 10 nuevos (PRY-199, 201 a 209) · 0 sin carpeta propia
**Formatos:** 37 .md, 11 .docx, 11 .pdf, 9 .xlsx, 6 .csv, 1 .json, 1 .txt. Todos se convirtieron a texto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Cambio de luminarias del campamento | 6 | identidad, plan, dinero, 3 entregables de CT-199, 1 riesgo, 1 compromiso | autoridad, fase, facturado |
| PRY-201 Ampliación de la relavera | 6 | identidad, plan, dinero, 1 riesgo, 2 compromisos | producto (acta: «No aplica»), autoridad, fase |
| PRY-202 Planta de tratamiento de agua | 6 | identidad, plan, dinero, 2 riesgos, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-203 Despacho automático de flota | 5 | identidad, plan, dinero, 2 riesgos, 2 incidencias, 1 compromiso | autoridad, fase |
| PRY-204 Monitoreo de taludes | 5 | identidad, 2 líneas base, dinero, 2 riesgos, solicitud CC-01 | autoridad, fase |
| PRY-205 Sistema de gestión de seguridad | 4 | identidad, plan, dinero, 2 riesgos, 1 incidencia, 1 compromiso | producto («No aplica»), autoridad, fase |
| PRY-206 Red privada LTE en mina | 3 | identidad, plan, dinero, 2 riesgos, 1 incidencia | producto («No aplica»), autoridad, fase |
| PRY-207 Gemelo digital de la planta | 4 | identidad, plan, dinero, 1 riesgo, 3 incidencias, 1 compromiso | autoridad, fase |
| PRY-208 Trazabilidad del mineral | 4 | identidad, plan, dinero, 2 riesgos, 2 incidencias, 2 compromisos | autoridad, fase |
| PRY-209 Electrificación de equipos | 4 | identidad, plan, dinero, 1 riesgo, 1 compromiso | producto («No aplica»), autoridad, fase |

La autoridad del gerente no aparece en ninguna de las 13 actas, y ninguno de los informes dice en qué fase está el proyecto. Quedan como `not_found`; no los adiviné.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-200, PRY-210, PRY-211 | Nada: sus 29 documentos no cambiaron desde la corrida anterior, así que no los abrí | `meta.documents_seen` |

### Lo que el barrido encontró y no debe esperar al informe
- **PRY-204, cambio de línea base sin autorización documentada.** El cronograma v2 (2026-09-28) mueve «Montaje e instalación» del 2027-04-10 al 2027-06-22, 73 días. La solicitud CC-01 (2026-10-14) pide justo esos +73 días y 146.000.000 COP, y dice «Pendiente de presentación al comité». El plan ya se movió antes de que nadie lo aprobara. Dejé las dos líneas base y la v2 sin motivo ni fecha de aprobación, porque ningún documento los da.
- **Hitos declarados cerrados sin acta de recibo.** Es el hallazgo más repetido: 23 hitos cerrados en los cronogramas de los 10 proyectos nuevos, 17 de ellos sin acta que los pruebe. Los 6 con acta son PRY-199 (ingeniería básica), PRY-201 (básica y detalle), PRY-202 (licencia y montaje) y PRY-203 (detalle). Registré lo que declaran los cronogramas y dejé la evidencia vacía; no cambié ningún estado por falta de acta.
- **PRY-203, hito vencido.** «Montaje e instalación» tenía fecha 2026-10-04, sigue en curso y el informe de 2026-10-14 declara rojo.
- **Compromisos con fecha pasada y sin evidencia de cumplimiento:**
  - PRY-201: Elena Duarte, punto 24, para 2026-10-16.
  - PRY-207: Andrés Lozano, punto 14, para 2026-10-10.
  - PRY-208: Jorge Medina, punto 34, para 2026-10-04.
  - PRY-209: Liliana Torres, punto 4, para 2026-09-22.

  En PRY-207, 208 y 209 la fecha prometida es anterior a la reunión que la registró. Lo dejo como lo dice la minuta.
- **Compromisos sin fecha:** PRY-202 (Liliana Torres, punto 1) y PRY-203 (Óscar Ramírez, punto 8), «por definir».
- **PRY-208 no tiene patrocinador distinto del gerente.** Natalia Ospina figura en las dos funciones en el acta, y la minuta de 2026-10-11 la lista dos veces como asistente. El proyecto está en rojo, con el cierre comprometido del 2026-01-04 ya pasado y todos sus hitos cerrados, y reporta 37% de avance.
- **PRY-199 contradice su propio informe en un punto:** el informe de 2026-10-15 dice que «se recibió el permiso ambiental», pero el cronograma sigue con «Licencia y permisos obtenidos» en curso y sin acta. No resolví cuál vale; el hito quedó como lo declara el cronograma.
- **PRY-199, contrato CT-199:** los tres entregables siguen pendientes y no hay factura. Aun así el informe declara 720.000.000 ejecutados.

El cálculo del portafolio (`compute`, corte 2026-10-17) da 67 señales en 12 de los 13 proyectos y 7 proyectos declarados en verde que los documentos no sustentan. Esas señales son del cálculo, no mías; el detalle va en el informe consolidado.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 76 archivos se convirtieron a texto |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | La carpeta `documentos/entrada/` no existe; no hay nada que clasificar | |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| (ninguno) | |

### Para mirar
- **Citas de PRY-211 que no resuelven.** El índice reporta 22 campos de la ficha PRY-211 cuya fuente está escrita como `00-gobierno/…` o `20-seguimiento/…`, sin el prefijo de carpeta del proyecto. Con esa ruta el índice no encuentra el documento. La ficha viene de `/portfolio-setup` y sus documentos no cambiaron, así que no la reescribí; hay que corregir las rutas la próxima vez que se lea PRY-211.
- Dentro de `estado/` hay una carpeta `PRY-211-control-de-polvo-en-vías/` que contiene otro estado completo (`records/`, `corridas/`, `snapshots/`, `corridas.json`). Parece una copia anidada de una ejecución anterior. No la toqué ni la leí como fuente.

### Siguiente paso
Hay más de un proyecto, así que puedo preparar el informe consolidado con `/criterio-portfolio:portfolio-report`. Antes del comité del 2026-10-23, PRY-204 y PRY-203 son los que más piden una decisión.

---
*criterio-portfolio 0.4.0 · fichas tocadas: PRY-199, 201, 202, 203, 204, 205, 206, 207, 208, 209 · campos en `not_found` por ficha: 2 a 3 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal*
