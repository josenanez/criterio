# Corrida del 2026-10-17 · product-view

13 proyectos · 18 s · 67 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 22 |
| `progress_vs_plan` | 9 |
| `commitment_overdue` | 9 |
| `declared_vs_evidence` | 7 |
| `variance_cost` | 4 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `milestone_overdue` | 2 |
| `variance_time` | 2 |
| `vendor_deliverable_late` | 2 |
| `rebaseline_unauthorized` | 1 |
| `vendor_accepted_without_evidence` | 1 |
| `pm_vs_pmo` | 1 |

Producto de un solo proyecto (PRY-207): no se armó sección, solo resumen de sus 7 alertas. No se armó la tabla de proyectos sin producto (7) ni se verificaron documentos fuente.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Producto «gemelo digital» al 2026-10-17

Sale de las fichas del estado, recalculadas hoy con `compute`.

**«Gemelo digital» tiene un solo proyecto, PRY-207 (Gemelo digital de la planta).** La vista por producto no aporta nada con un solo proyecto, así que no armo la sección: no hay señales que sumar, ni dependencias internas que cruzar, y la fecha del producto es la de ese proyecto, 2026-11-25.

Para no dejarlo en nada, lo que ya dice el cálculo de PRY-207 (7 alertas, 5 días sin movimiento):
- El informe declara verde (corte 2026-09-29), pero el cálculo lo contradice con cuatro señales: avance declarado 20 % frente a 75–100 % que sostiene el plan (3 de 4 hitos cumplidos), sobrecosto proyectado de 16,5 % (7.922.563.459 contra 6.800.000.000 aprobados), compromiso vencido hace 7 días (Andrés Lozano, «Entregar el punto 14», vencía 2026-10-10) y tres hitos dados por cumplidos sin evidencia (ingeniería básica, ingeniería de detalle y licencias).
- No sumé dinero a nivel de producto: con un proyecto, la suma es la cifra del proyecto y no aporta.

Proyectos sin producto declarado en el portafolio: siete (PRY-201, 202, 205, 206, 209, 210 y 211). No armé la tabla con el área dueña porque esta invocación era de un solo producto; corre `/product-view` sin argumento si la necesitas.

Pie de rigor: fichas de `estado`, corte 2026-10-17. Las cifras se copian de `compute`; no verifiqué los documentos fuente en esta corrida. La verificación es tuya.
