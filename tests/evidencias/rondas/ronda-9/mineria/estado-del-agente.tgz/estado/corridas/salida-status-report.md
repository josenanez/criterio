Informe construido desde la ficha `estado/records/PRY-203.json` (actualizada el 2026-10-17) y la salida de `compute` con fecha de cálculo 2026-10-17.

## PRY-203 · Despacho automático de flota — estado al 2026-10-17

**Declara el gerente (Felipe Arango):** rojo · 26 % · al 2026-10-14 (3 días de antigüedad, no está vencida)
**Sustento documental:** parcial. El rojo no está contradicho por ningún documento. Pero el avance del 26 % no cuadra con el plan, y 2 de los 3 hitos marcados como cumplidos no tienen evidencia de cumplimiento. Ningún documento de la ficha está marcado como evidencia (0 de evidencia, 2 de declaración, 16 sin marcar).
**Lo que el semáforo no explica:** `milestone_met_without_evidence`, `milestone_overdue`, `progress_vs_plan`, `variance_cost`
**Último documento:** 2026-10-14 (hace 3 días) · **Última reunión:** 2026-10-14, comité semanal

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-10-04 | 2026-10-04 | 0 días contra la original y contra la vigente. La fecha ya pasó hace 13 días y el proyecto sigue sin cerrar. |
| Presupuesto | COP 6.800.000.000 aprobado | proyección COP 8.088.982.862 | +19,0 % sobre lo aprobado (umbral 10 %) |

Dinero: comprometido COP 4.780.108.610 (70,3 %), ejecutado COP 3.630.058.206 (53,4 %), disponible real COP 2.019.891.390.

Replanificaciones: 0. Hay una sola línea base, la v1 del 2025-11-05. Los informes declaran dos pérdidas de tiempo (dos semanas por la rotación de un ingeniero clave y diez días de lluvia que detuvieron el montaje), pero no hay ninguna replanificación ni solicitud de cambio que las haya recogido en las fechas.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Ingeniería básica aprobada | 2026-02-03 | 2026-02-03 | cumplido (declarado) | **ninguna** (256 días desde la fecha) |
| Ingeniería de detalle aprobada | 2026-04-25 | 2026-04-25 | cumplido | acta de recibo del 2026-10-12 |
| Licencia y permisos obtenidos | 2026-07-15 | 2026-07-15 | cumplido (declarado) | **ninguna** (94 días desde la fecha) |
| Montaje e instalación | 2026-10-04 | 2026-10-04 | pendiente | **vencido hace 13 días** |

### Dónde no coincide
- **Avance contra plan:** el gerente declara 26 % (informe de avance, 2026-10-14). Con 3 de 4 hitos cumplidos, el plan respalda entre 75 % y 100 %. La diferencia es de 49,0 puntos, y la declaración queda por debajo del plan. Hay dos explicaciones posibles: el avance está subdeclarado, o los hitos «cumplidos» no lo están. Los documentos no permiten decidir cuál. Hay que preguntárselo al gerente.
- **Hitos cumplidos sin evidencia:** «Ingeniería básica aprobada» y «Licencia y permisos obtenidos» figuran como cumplidos en el cronograma v1, y no hay acta, aprobación ni permiso que lo sustente.
- **Costo:** la proyección está 19,0 % por encima de lo aprobado y no existe solicitud de cambio de presupuesto (0 cambios registrados).

### Abierto
**Riesgos e incidencias sin movimiento:** hay 2 riesgos y 2 incidencias, todos sin responsable identificado. Los dos riesgos son la concentración del conocimiento en una persona y la fecha de la última entrega del proveedor, que no está confirmada. Las dos incidencias son la rotación del ingeniero y las lluvias. Las cuatro entradas salen del informe del 2026-10-14. El cálculo no entrega días sin movimiento para estas entradas, así que no escribo cifras.
**Compromisos vencidos:** ninguno. Hay uno **sin fecha**: Óscar Ramírez, «Entregar el punto 8», dicho en el comité del 2026-10-14. Sin fecha no puede vencer, y por eso no se puede seguir.
**Dependencias sin confirmar:** ninguna registrada. Tampoco hay proveedores en la ficha, aunque el riesgo del proveedor sugiere que existe uno.

### Sin dato
- Autoridad de aprobación del proyecto (`identity.authority`): no aparece en el acta de constitución.
- Fase del proyecto (`identity.phase`): no aparece en el informe de avance.
- Responsable de los 4 riesgos e incidencias.
- Fecha del compromiso de Óscar Ramírez.

### Siguiente paso
El proyecto está por encima de dos umbrales: costo (19,0 % contra 10 %) y fecha de cierre ya vencida. Puedo preparar el punto de comité del 2026-10-23 y, si se decide mover fechas o presupuesto, la solicitud de cambio que hoy no existe.

---
Criterio Portafolio v0.4.0 · ficha PRY-203 aplicada con fecha 2026-10-17 · campos inciertos: autoridad y fase (no encontrados) · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
