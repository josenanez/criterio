<!-- origen: PRY-203-despacho-automático-de-flota/00-gobierno/2025-11-05-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Despacho automático de flota

**Código:** PRY-203
**Área dueña:** Geología
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Felipe Arango
**Comité:** Comité de Inversiones
**Producto asociado:** despacho de flota
**Fecha de aprobación:** 2025-11-05

## Objetivo del negocio

Entregar despacho automático de flota para Geología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Inversiones el 2025-11-05.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-15 |
| Cierre | 2026-10-04 |

## Criterio de éxito

Despacho automático de flota en producción y medido.

## Dependencias declaradas

- Ninguna declarada
