<!-- origen: PRY-201-ampliación-de-la-relavera/10-plan/2025-09-30-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-12-23,2025-12-23,cerrado
Ingeniería de detalle aprobada,2026-03-08,2026-03-08,cerrado
Licencia y permisos obtenidos,2026-05-22,2026-05-22,cerrado
Montaje e instalación,2026-08-05,2026-08-05,cerrado
