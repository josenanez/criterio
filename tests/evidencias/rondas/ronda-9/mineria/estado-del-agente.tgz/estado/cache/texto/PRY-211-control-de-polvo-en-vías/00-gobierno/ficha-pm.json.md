<!-- origen: PRY-211-control-de-polvo-en-vías/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-211",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "name": {
 "value": "Control de polvo en vías",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Logística",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "product": {
 "value": "No aplica",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "not_found"
 },
 "sponsor": {
 "value": "Paula Céspedes",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "manager": {
 "value": "Liliana Torres",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "committee": {
 "value": "Comité Ambiental",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "not_found"
 }
 },
 "declared": {
 "status": {
 "value": "amarillo",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "progress_pct": {
 "value": 82,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "as_of": {
 "value": "2026-10-14",
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2025-05-26",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "end_date": {
 "value": "2026-11-28",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2025-05-16",
 "start_date": "2025-05-26",
 "end_date": "2026-08-17",
 "reason": "Aprobación inicial: acta de constitución y cronograma v1",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md"
 },
 {
 "version": 2,
 "approved_on": "2026-10-14",
 "start_date": "2025-05-26",
 "end_date": "2026-11-28",
 "reason": "CC-01, ampliación de alcance: +103 días sobre la línea base vigente",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 }
 ],
 "milestones": [
 {
 "name": "Ingeniería básica aprobada",
 "baseline_date": "2025-08-23",
 "current_date": "2025-08-23",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 },
 {
 "name": "Ingeniería de detalle aprobada",
 "baseline_date": "2025-11-21",
 "current_date": "2025-11-21",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 },
 {
 "name": "Licencia y permisos obtenidos",
 "baseline_date": "2026-02-18",
 "current_date": "2026-02-18",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 },
 {
 "name": "Montaje e instalación",
 "baseline_date": "2026-05-19",
 "current_date": "2026-05-19",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 },
 {
 "name": "Pruebas en operación",
 "baseline_date": "2026-08-17",
 "current_date": "2026-11-28",
 "state": "met",
 "evidence": "",
 "source": "10-plan/2026-10-14-cronograma-v2.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componente 1, Componente 2, Componente 3",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "exclusions": {
 "value": "Lo que otro proyecto cubre",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 }
 },
 "money": {
 "currency": {
 "value": "COP",
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "approved": {
 "value": 4200000000,
 "source": "00-gobierno/2025-05-16-acta-constitucion.md",
 "source_date": "2025-05-16",
 "state": "found"
 },
 "committed": {
 "value": 1310630831,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "executed": {
 "value": 1465714221,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 },
 "projection": {
 "value": 4009341481,
 "source": "20-seguimiento/2026-10-14-informe-avance.md",
 "source_date": "2026-10-14",
 "state": "found"
 }
 },
 "vendors": [
 {
 "name": "Servicios Ambientales del Norte",
 "contract_ref": "CT-110",
 "deliverables": [
 {
 "name": "Licenciamiento del software",
 "due_date": "2025-09-26",
 "amount": 392117057,
 "state": "pending",
 "evidence": ""
 },
 {
 "name": "Bolsa de horas de ingeniería",
 "due_date": "2026-01-27",
 "amount": 392117057,
 "state": "pending",
 "evidence": ""
 },
 {
 "name": "Calibración de sensores",
 "due_date": "2026-05-30",
 "amount": 392117057,
 "state": "accepted",
 "evidence": ""
 }
 ],
 "invoiced": {
 "value": 392117057,
 "source": "20-seguimiento/2026-08-30-factura-ct-110.pdf",
 "source_date": "2026-08-30",
 "state": "found"
 },
 "source": "00-gobierno/2025-05-18-contrato-ct-110.md"
 }
 ],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "owner": "no_identificado",
 "source": "20-seguimiento/2026-10-14-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (se comentó en la reunión; nadie lo anotó como riesgo)",
 "owner": "no_identificado",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [
 {
 "ref": "CC-01",
 "requested_on": "2026-10-07",
 "scope_impact": "Ampliación de alcance",
 "time_impact": "+103 días sobre la línea base vigente",
 "cost_impact": "206.000.000 COP adicionales",
 "decision": "approved",
 "decided_by": "el comité (no dice cuál ni en qué fecha)",
 "source": "20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md"
 }
 ],
 "commitments": [
 {
 "who": "Ricardo Salas",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-03",
 "original_due_date": "2026-09-17",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-02",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-20",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-19",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-03",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-15",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-21",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-02",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Revisar el anexo 3",
 "due_date": "2026-11-03",
 "original_due_date": "2026-10-02",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-22",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Andrés Lozano",
 "what": "Validar el ambiente 4",
 "due_date": "2026-11-14",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-14",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-15",
 "original_due_date": "2026-09-15",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-5.md"
 },
 {
 "who": "Ricardo Salas",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-11-10",
 "original_due_date": "2026-10-07",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-24",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-6.md"
 },
 {
 "who": "Paula Céspedes",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-09-27",
 "original_due_date": "2026-09-16",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-09-27",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-7.md"
 },
 {
 "who": "Jorge Medina",
 "what": "Entregar el punto 8",
 "due_date": "2026-09-26",
 "original_due_date": "2026-09-26",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-8.md"
 },
 {
 "who": "Diana Molina",
 "what": "Enviar el documento 9",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-09-27",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "unknown",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-27",
 "original_due_date": "2026-09-27",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-11.md"
 },
 {
 "who": "Liliana Torres",
 "what": "Validar el ambiente 12",
 "due_date": "2026-09-23",
 "original_due_date": "2026-09-23",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-11-01",
 "original_due_date": "2026-10-12",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-11-01",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-13.md"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 14",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-03",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-11",
 "original_due_date": "2026-10-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Felipe Arango",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-23",
 "original_due_date": "2026-10-23",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Revisar el anexo 19",
 "due_date": "2026-10-31",
 "original_due_date": "2026-10-31",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-21",
 "original_due_date": "2026-10-21",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-25",
 "original_due_date": "2026-10-25",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Camilo Beltrán",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Ricardo Salas",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Gustavo Neira",
 "what": "Entregar el punto 24",
 "due_date": "2026-11-01",
 "original_due_date": "2026-11-01",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto («la otra semana»)",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ]
}
