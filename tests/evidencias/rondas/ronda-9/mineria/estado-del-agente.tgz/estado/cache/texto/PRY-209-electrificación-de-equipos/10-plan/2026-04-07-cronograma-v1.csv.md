<!-- origen: PRY-209-electrificación-de-equipos/10-plan/2026-04-07-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-08-19,2026-08-19,cerrado
Ingeniería de detalle aprobada,2026-12-21,2026-12-21,en curso
Licencia y permisos obtenidos,2027-04-24,2027-04-24,en curso
