<!-- origen: PRY-201-ampliación-de-la-relavera/00-gobierno/2025-09-30-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Ampliación de la relavera

**Código:** PRY-201
**Área dueña:** Mina
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Diana Molina
**Comité:** Comité de Inversiones
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-09-30

## Objetivo del negocio

Entregar ampliación de la relavera para Mina.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Inversiones el 2025-09-30.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-10 |
| Cierre | 2026-08-05 |

## Criterio de éxito

Ampliación de la relavera en producción y medido.

## Dependencias declaradas

- Ninguna declarada
