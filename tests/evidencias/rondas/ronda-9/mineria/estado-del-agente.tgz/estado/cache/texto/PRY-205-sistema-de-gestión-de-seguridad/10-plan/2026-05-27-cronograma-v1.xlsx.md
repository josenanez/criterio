<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/10-plan/2026-05-27-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-09-28 | 2026-09-28 | cerrado
Ingeniería de detalle aprobada | 2027-01-20 | 2027-01-20 | en curso
Licencia y permisos obtenidos | 2027-05-14 | 2027-05-14 | en curso
