<!-- origen: PRY-207-gemelo-digital-de-la-planta/00-gobierno/2025-08-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Gemelo digital de la planta

Código: PRY-207

Área dueña: Seguridad y Salud

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Natalia Ospina

Comité: Comité Ambiental

Producto asociado: gemelo digital

Fecha de aprobación: 2025-08-17

Objetivo del negocio

Entregar gemelo digital de la planta para Seguridad y Salud.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité Ambiental el 2025-08-17.

Fechas comprometidas

Fecha

Inicio

2025-08-27

Cierre

2026-11-25

Criterio de éxito

Gemelo digital de la planta en producción y medido.

Dependencias declaradas

• Ninguna declarada
