<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Monitoreo de taludes
Código: PRY-204
Fecha de corte: 2026-09-28
Gerente: Gustavo Neira

Estado declarado
Amarillo
Avance reportado: 24%

Lo que pasó en el periodo
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 9.552.337.322
Ejecutado 7.503.816.747
Proyección al cierre 17.243.019.812

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Bloqueo de la vía de acceso a la mina
