<!-- origen: PRY-207-gemelo-digital-de-la-planta/30-reuniones/2026-10-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Gemelo digital de la planta

**Fecha:** 2026-10-12
**Asistentes:** Natalia Ospina, Rubén Cárdenas

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Andrés Lozano | Entregar el punto 14 | 2026-10-10 |
