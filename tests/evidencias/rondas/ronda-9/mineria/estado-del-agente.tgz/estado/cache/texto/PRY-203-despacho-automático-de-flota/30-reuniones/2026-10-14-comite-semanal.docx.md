<!-- origen: PRY-203-despacho-automático-de-flota/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Inversiones · Despacho automático de flota

Fecha: 2026-10-14

Asistentes: Felipe Arango, Carlos Peña

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 8

por definir
