<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/00-gobierno/2026-05-23-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Programa de relacionamiento comunitario

Código: PRY-210

Área dueña: Mina

Patrocinador: Diana Molina

Gerente de proyecto: Felipe Arango

Comité: Comité de Tecnología

Producto asociado: No aplica

Fecha de aprobación: 2026-05-23

Objetivo del negocio

Entregar programa de relacionamiento comunitario para Mina.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Tecnología el 2026-05-23.

Fechas comprometidas

Fecha

Inicio

2026-06-02

Cierre

2026-12-19

Criterio de éxito

Programa de relacionamiento comunitario en producción y medido.

Dependencias declaradas

• Ninguna declarada
