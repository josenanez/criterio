<!-- origen: PRY-201-ampliación-de-la-relavera/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Ampliación de la relavera

**Código:** PRY-201
**Fecha de corte:** 2026-10-14
**Gerente:** Diana Molina

## Estado declarado

**Amarillo**

Avance reportado: **29%**

## Lo que pasó en el periodo

- Se acordó con operaciones el plan de arranque de los equipos

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 8.639.382.262 |
| Ejecutado | 9.566.897.487 |
| Proyección al cierre | 18.881.311.733 |

## Riesgos abiertos

- Cambio en la licencia ambiental que puede mover el alcance
