<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Mantenimiento predictivo de camiones
Código: PRY-200
Fecha de corte: 2026-10-15
Gerente: Gustavo Neira

Estado declarado
Verde
Avance reportado: 66%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 964.232.430
Ejecutado 789.872.157
Proyección al cierre 2.647.931.269

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Concentración del conocimiento en una sola persona
