<!-- origen: PRY-204-monitoreo-de-taludes/20-seguimiento/2026-10-14-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Monitoreo de taludes
**Fecha:** 2026-10-14
**Solicitante:** Gustavo Neira

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +73 días sobre la línea base vigente |
| Costo | 146.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
