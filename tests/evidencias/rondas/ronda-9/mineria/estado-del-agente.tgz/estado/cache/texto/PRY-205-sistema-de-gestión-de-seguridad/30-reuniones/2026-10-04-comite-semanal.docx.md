<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Tecnología · Sistema de gestión de seguridad

Fecha: 2026-10-04

Asistentes: Rubén Cárdenas, Beatriz Cuéllar

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Liliana Torres

Entregar el punto 9

2026-11-03
