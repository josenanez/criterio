<!-- origen: PRY-201-ampliación-de-la-relavera/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Inversiones · Ampliación de la relavera

Fecha: 2026-10-14

Asistentes: Diana Molina, Jorge Medina

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Elena Duarte

Entregar el punto 24

2026-10-16

Camilo Beltrán

Entregar el punto 12

2026-10-26
