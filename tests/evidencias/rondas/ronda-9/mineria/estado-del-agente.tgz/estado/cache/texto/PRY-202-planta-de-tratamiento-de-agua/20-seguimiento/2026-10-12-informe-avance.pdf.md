<!-- origen: PRY-202-planta-de-tratamiento-de-agua/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Planta de tratamiento de agua
Código: PRY-202
Fecha de corte: 2026-10-12
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 54%

Lo que pasó en el periodo
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 2.414.268.008
Ejecutado 1.280.746.725
Proyección al cierre 4.052.577.343

Riesgos abiertos
- Bloqueo de la vía de acceso a la mina
- Ventana de parada de planta definida por operaciones
