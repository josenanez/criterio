<!-- origen: PRY-206-red-privada-lte-en-mina/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Red privada LTE en mina
Código: PRY-206
Fecha de corte: 2026-10-15
Gerente: Óscar Ramírez

Estado declarado
Verde
Avance reportado: 34%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 487.051.150
Ejecutado 463.268.218
Proyección al cierre 1.108.067.934

Riesgos abiertos
- Ventana de parada de planta definida por operaciones
- Bloqueo de la vía de acceso a la mina
