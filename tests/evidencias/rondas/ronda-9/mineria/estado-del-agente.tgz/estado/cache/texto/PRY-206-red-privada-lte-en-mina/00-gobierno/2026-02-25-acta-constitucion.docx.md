<!-- origen: PRY-206-red-privada-lte-en-mina/00-gobierno/2026-02-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Red privada LTE en mina

Código: PRY-206

Área dueña: Logística

Patrocinador: Natalia Ospina

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Seguridad

Producto asociado: No aplica

Fecha de aprobación: 2026-02-25

Objetivo del negocio

Entregar red privada lte en mina para Logística.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Seguridad el 2026-02-25.

Fechas comprometidas

Fecha

Inicio

2026-03-07

Cierre

2027-05-05

Criterio de éxito

Red privada LTE en mina en producción y medido.

Dependencias declaradas

• Ninguna declarada
