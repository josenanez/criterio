<!-- origen: PRY-205-sistema-de-gestión-de-seguridad/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Sistema de gestión de seguridad

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Rubén Cárdenas

## Estado declarado

**Verde**

Avance reportado: **44%**

## Lo que pasó en el periodo

- Las lluvias detuvieron el montaje durante diez días
- Se actualizó el presupuesto de la obra con el área de compras

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.095.435.938 |
| Ejecutado | 2.958.258.861 |
| Proyección al cierre | 7.673.156.263 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Concentración del conocimiento en una sola persona
