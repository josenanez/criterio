<!-- origen: PRY-207-gemelo-digital-de-la-planta/10-plan/2025-08-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-12-18 | 2025-12-18 | cerrado
Ingeniería de detalle aprobada | 2026-04-11 | 2026-04-11 | cerrado
Licencia y permisos obtenidos | 2026-08-03 | 2026-08-03 | cerrado
Montaje e instalación | 2026-11-25 | 2026-11-25 | en curso
