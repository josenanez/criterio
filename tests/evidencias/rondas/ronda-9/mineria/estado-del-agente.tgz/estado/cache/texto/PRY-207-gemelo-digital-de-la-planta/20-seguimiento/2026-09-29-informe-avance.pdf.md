<!-- origen: PRY-207-gemelo-digital-de-la-planta/20-seguimiento/2026-09-29-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Gemelo digital de la planta
Código: PRY-207
Fecha de corte: 2026-09-29
Gerente: Natalia Ospina

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Las lluvias detuvieron el montaje durante diez días
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- El equipo perdió dos semanas por rotación de un ingeniero clave

Presupuesto
COP
Aprobado 6.800.000.000
Comprometido 5.445.601.460
Ejecutado 4.062.393.959
Proyección al cierre 7.922.563.459

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
