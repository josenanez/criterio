<!-- origen: PRY-204-monitoreo-de-taludes/10-plan/2026-09-28-cronograma-v2.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-05-30 | 2026-05-30 | cerrado
Ingeniería de detalle aprobada | 2026-09-12 | 2026-09-12 | cerrado
Licencia y permisos obtenidos | 2026-12-26 | 2026-12-26 | en curso
Montaje e instalación | 2027-04-10 | 2027-06-22 | en curso
