<!-- origen: PRY-211-control-de-polvo-en-vías/30-reuniones/2026-09-12-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-09-12
**Asistentes:** Andrés Lozano, Jorge Medina, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-10-02 |
| Rubén Cárdenas | Cerrar la prueba 2 | 2026-10-02 |
| Laura Vélez | Revisar el anexo 3 | 2026-10-22 |
| Andrés Lozano | Validar el ambiente 4 | 2026-10-14 |
| Jorge Medina | Aprobar el diseño 5 | 2026-09-15 |
| Ricardo Salas | Actualizar la matriz 6 | 2026-10-07 |
| Paula Céspedes | Confirmar la fecha 7 | 2026-09-16 |
| Jorge Medina | Entregar el punto 8 | 2026-09-26 |
