<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Programa de relacionamiento comunitario
Código: PRY-210
Fecha de corte: 2026-10-16
Gerente: Felipe Arango

Estado declarado
Verde
Avance reportado: 45%

Lo que pasó en el periodo
- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite
- Se actualizó el presupuesto de la obra con el área de compras

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 493.839.884
Ejecutado 604.969.789
Proyección al cierre 1.214.322.242

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
- Concentración del conocimiento en una sola persona
