<!-- origen: PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2026-06-09-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Mantenimiento predictivo de camiones

Código: PRY-200

Área dueña: Tecnología

Patrocinador: Gustavo Neira

Gerente de proyecto: Gustavo Neira

Comité: Comité de Seguridad

Producto asociado: monitoreo de flota

Fecha de aprobación: 2026-06-09

Objetivo del negocio

Entregar mantenimiento predictivo de camiones para Tecnología.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

2.400.000.000 COP, aprobado por Comité de Seguridad el 2026-06-09.

Fechas comprometidas

Fecha

Inicio

2026-06-19

Cierre

2027-04-12

Criterio de éxito

Mantenimiento predictivo de camiones en producción y medido.

Dependencias declaradas

• Ninguna declarada
