<!-- origen: PRY-211-control-de-polvo-en-vías/10-plan/2025-05-16-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-08-23,2025-08-23,cerrado
Ingeniería de detalle aprobada,2025-11-21,2025-11-21,cerrado
Licencia y permisos obtenidos,2026-02-18,2026-02-18,cerrado
Montaje e instalación,2026-05-19,2026-05-19,cerrado
Pruebas en operación,2026-08-17,2026-08-17,cerrado
