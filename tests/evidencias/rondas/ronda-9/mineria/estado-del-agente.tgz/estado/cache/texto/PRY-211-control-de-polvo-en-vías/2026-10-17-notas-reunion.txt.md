<!-- origen: PRY-211-control-de-polvo-en-vías/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión control de polvo en vías — 2026-10-17
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Gustavo Neira, Laura Vélez, Liliana Torres, Paula Céspedes, Ricardo Salas, Rubén Cárdenas, Óscar Ramírez

- Ricardo Salas dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 03/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
