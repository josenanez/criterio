<!-- origen: PRY-203-despacho-automático-de-flota/10-plan/2025-11-05-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2026-02-03 | 2026-02-03 | cerrado
Ingeniería de detalle aprobada | 2026-04-25 | 2026-04-25 | cerrado
Licencia y permisos obtenidos | 2026-07-15 | 2026-07-15 | cerrado
Montaje e instalación | 2026-10-04 | 2026-10-04 | en curso
