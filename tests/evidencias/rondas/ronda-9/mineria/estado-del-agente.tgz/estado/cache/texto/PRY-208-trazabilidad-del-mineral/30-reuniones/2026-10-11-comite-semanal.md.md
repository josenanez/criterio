<!-- origen: PRY-208-trazabilidad-del-mineral/30-reuniones/2026-10-11-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Seguridad · Trazabilidad del mineral

**Fecha:** 2026-10-11
**Asistentes:** Natalia Ospina, Natalia Ospina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Paula Céspedes | Entregar el punto 2 | 2026-11-08 |
| Jorge Medina | Entregar el punto 34 | 2026-10-04 |
