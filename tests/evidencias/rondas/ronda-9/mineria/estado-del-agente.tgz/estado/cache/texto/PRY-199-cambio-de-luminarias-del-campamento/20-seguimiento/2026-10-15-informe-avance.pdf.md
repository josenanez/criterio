<!-- origen: PRY-199-cambio-de-luminarias-del-campamento/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cambio de luminarias del campamento
Código: PRY-199
Fecha de corte: 2026-10-15
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 20%

Lo que pasó en el periodo
- Se recibió el permiso ambiental pendiente desde el trimestre anterior
- Se reprogramó la parada de planta por la ventana de mantenimiento
- Se acordó con operaciones el plan de arranque de los equipos

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.080.000.000
Ejecutado 720.000.000
Proyección al cierre 2.400.000.000

Riesgos abiertos
- Cambio en la licencia ambiental que puede mover el alcance
