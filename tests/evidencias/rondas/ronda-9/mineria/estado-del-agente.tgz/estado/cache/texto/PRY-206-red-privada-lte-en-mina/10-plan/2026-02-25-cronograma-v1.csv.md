<!-- origen: PRY-206-red-privada-lte-en-mina/10-plan/2026-02-25-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-07-26,2026-07-26,cerrado
Ingeniería de detalle aprobada,2026-12-14,2026-12-14,en curso
Licencia y permisos obtenidos,2027-05-05,2027-05-05,en curso
