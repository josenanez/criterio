<!-- origen: PRY-211-control-de-polvo-en-vías/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité Ambiental · Control de polvo en vías

**Fecha:** 2026-09-05
**Asistentes:** Andrés Lozano, Laura Vélez, Liliana Torres, Ricardo Salas, Rubén Cárdenas

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Enviar el documento 1 | 2026-09-17 |
| Rubén Cárdenas | Cerrar la prueba 2 | por definir |
| Laura Vélez | Revisar el anexo 3 | 2026-10-02 |
| Andrés Lozano | Validar el ambiente 4 | 2026-09-25 |
