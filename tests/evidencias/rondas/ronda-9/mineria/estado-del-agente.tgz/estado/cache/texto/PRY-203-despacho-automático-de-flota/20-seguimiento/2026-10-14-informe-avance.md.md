<!-- origen: PRY-203-despacho-automático-de-flota/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Despacho automático de flota

**Código:** PRY-203
**Fecha de corte:** 2026-10-14
**Gerente:** Felipe Arango

## Estado declarado

**Rojo**

Avance reportado: **26%**

## Lo que pasó en el periodo

- Se actualizó el presupuesto de la obra con el área de compras
- El equipo perdió dos semanas por rotación de un ingeniero clave
- Las lluvias detuvieron el montaje durante diez días

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 4.780.108.610 |
| Ejecutado | 3.630.058.206 |
| Proyección al cierre | 8.088.982.862 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
