<!-- origen: PRY-209-electrificación-de-equipos/00-gobierno/2026-04-07-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Electrificación de equipos

**Código:** PRY-209
**Área dueña:** Medio Ambiente
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Andrés Lozano
**Comité:** Comité de Seguridad
**Producto asociado:** No aplica
**Fecha de aprobación:** 2026-04-07

## Objetivo del negocio

Entregar electrificación de equipos para Medio Ambiente.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**1.200.000.000 COP**, aprobado por Comité de Seguridad el 2026-04-07.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-17 |
| Cierre | 2027-04-24 |

## Criterio de éxito

Electrificación de equipos en producción y medido.

## Dependencias declaradas

- Ninguna declarada
