<!-- origen: PRY-208-trazabilidad-del-mineral/10-plan/2025-06-06-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2025-08-22,2025-08-22,cerrado
Ingeniería de detalle aprobada,2025-10-28,2025-10-28,cerrado
Licencia y permisos obtenidos,2026-01-04,2026-01-04,cerrado
