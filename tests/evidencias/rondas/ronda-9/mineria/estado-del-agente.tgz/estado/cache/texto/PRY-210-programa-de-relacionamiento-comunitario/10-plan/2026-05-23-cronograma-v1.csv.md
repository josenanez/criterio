<!-- origen: PRY-210-programa-de-relacionamiento-comunitario/10-plan/2026-05-23-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Ingeniería básica aprobada,2026-08-07,2026-08-07,cerrado
Ingeniería de detalle aprobada,2026-10-13,2026-10-13,en curso
Licencia y permisos obtenidos,2026-12-19,2026-12-19,en curso
