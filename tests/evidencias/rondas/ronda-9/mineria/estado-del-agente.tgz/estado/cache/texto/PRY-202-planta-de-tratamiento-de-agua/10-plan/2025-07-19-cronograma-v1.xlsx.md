<!-- origen: PRY-202-planta-de-tratamiento-de-agua/10-plan/2025-07-19-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Ingeniería básica aprobada | 2025-11-08 | 2025-11-08 | cerrado
Ingeniería de detalle aprobada | 2026-02-18 | 2026-02-18 | cerrado
Licencia y permisos obtenidos | 2026-05-31 | 2026-05-31 | cerrado
Montaje e instalación | 2026-09-10 | 2026-09-10 | cerrado
