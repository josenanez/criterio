<!-- origen: PRY-208-trazabilidad-del-mineral/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Trazabilidad del mineral

**Código:** PRY-208
**Fecha de corte:** 2026-10-13
**Gerente:** Natalia Ospina

## Estado declarado

**Rojo**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se levantó un hallazgo en la auditoría de seguridad
- El primer ensayo de disponibilidad de los equipos no alcanzó lo pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.689.294.906 |
| Ejecutado | 1.580.152.501 |
| Proyección al cierre | 3.171.842.464 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
- El proveedor no ha confirmado la fecha de la última entrega
