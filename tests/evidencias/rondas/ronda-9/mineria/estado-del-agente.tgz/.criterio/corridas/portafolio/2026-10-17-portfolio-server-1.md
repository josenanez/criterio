# Corrida · 2026-10-17-portfolio-server-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-server rato

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T21:38:29 · **Fin:** 2026-10-17T21:39:08 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-server` | 13 | — | — | 67 | puerto 8787, informe en reportes/, modo rato |

Por señal (`portfolio-server`): `milestone_met_without_evidence` 22, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 7, `variance_cost` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `milestone_overdue` 2, `variance_time` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 1, `vendor_accepted_without_evidence` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Rostrum arrancó en el puerto 8790. Lo paré a los 5 segundos, porque esta sesión no tiene a nadie mirando; el código 124 es ese corte, no un fallo.

Los puertos 8787 y 8788 ya estaban ocupados, así que usé el 8790. El 8789 no lo probé.

**Para levantarlo de nuevo y dejarlo abierto:**
```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json --puerto 8790
```
Escucha solo en este equipo (127.0.0.1) y se para con Ctrl-C.

**Qué hay y a quién le sirve:**
- **`/`:** portada con las tres secciones y el formulario de peticiones.
- **`/pmo`:** cómo va el portafolio, para la PMO.
- **`/decisiones`:** lo que necesita decisión, para el comité y el patrocinador.
- **`/proyectos` (13), `/productos` (6) y `/corridas` (31):** los listados.
- **`/estado.json`:** de cuándo es el informe y cuántas peticiones hay abiertas.

**Lo que Rostrum no hace:** no calcula, no escribe fichas, no autentica y no manda correos. Solo crea las peticiones en `estado/peticiones/`.

**Qué enlace pasar a quién:** en este modo el enlace solo funciona en este equipo, así que no se le puede pasar al patrocinador. Para eso haría falta «que quede corriendo» con `--abierto`. Eso exige pedirle a la organización un host y puerto internos, publicarlo detrás de su control de acceso y mantener el equipo encendido; nada más. El informe es del 2026-10-17 y queda desactualizado en cuanto cambie un documento o se corra otro barrido. La portada muestra su fecha.

Los términos ya estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada. Dejé la corrida registrada como `2026-10-17-portfolio-server-1`, con la salida en `estado/corridas/salida-portfolio-server.md`. Esa salida dice 8787, que el puerto ocupado me obligó a cambiar. No la reescribí, y la nota de la corrida también dice 8787.
