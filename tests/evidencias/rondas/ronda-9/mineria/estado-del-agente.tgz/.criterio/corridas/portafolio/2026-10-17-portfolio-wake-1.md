# Corrida · 2026-10-17-portfolio-wake-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:portfolio-wake (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T21:37:36 · **Fin:** 2026-10-17T21:38:24 · **Duración:** 48 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `portfolio-wake` | 13 | — | 36 | 67 | Barrido: 76 documentos sin cambios, nada que releer. Confirmación: 5 preguntas formuladas, sin respuesta (sesión sin interfaz). Silencio >15 días en PRY-204 y PRY-207. Citas de PRY-211 sin prefijo de carpeta: el índice las marca como no resueltas aunque los archivos existen. No sé si los informes de PRY-204/207 existen fuera de la carpeta. |

Por señal (`portfolio-wake`): `milestone_met_without_evidence` 22, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 7, `variance_cost` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `milestone_overdue` 2, `variance_time` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 1, `vendor_accepted_without_evidence` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

Corrí el barrido y la confirmación. No cambió ningún documento, y las cinco preguntas de confirmación quedaron sin respuesta porque nadie podía contestar en esta sesión. Los términos estaban vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrar nada.

- **Barrido:** los 76 documentos están igual que la última vez, así que no releí ni recalculé ningún proyecto. No había peticiones en el servidor.
- **Silencio:** PRY-204 lleva 19 días y PRY-207 lleva 18 sin una declaración nueva de estado. El umbral es 15.
- **Citas de PRY-211:** el índice marca 22 citas de su ficha como no resueltas, pero los archivos existen. Las citas de esa ficha vienen sin el nombre de la carpeta del proyecto, a diferencia de las otras 12. No lo corregí; lo dejé anotado para quien mantiene la ficha.
- **Preguntas de confirmación:**
  - PRY-204 y PRY-207: si el estado declarado sigue vigente.
  - PRY-211 y PRY-209: a qué se refiere el 82 % de avance declarado, porque lo ejecutado frente a lo aprobado es de alrededor del 35 % y del 22 %.
  - PRY-211: si la nueva fecha de fin del plan está aprobada, dado el cambio CC-01.

Registré las dos tareas como hechas y dejé la corrida guardada con lo que mostré aquí. Vuelvo el 2026-10-18.
