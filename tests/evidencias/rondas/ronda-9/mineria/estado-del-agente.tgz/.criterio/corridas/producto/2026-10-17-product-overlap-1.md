# Corrida · 2026-10-17-product-overlap-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-overlap PRD-306

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRD-306

**Inicio:** 2026-10-17T21:40:23 · **Fin:** 2026-10-17T21:40:30 · **Duración:** 6 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

> Esta corrida no dejó cifras medidas por `corrida`: lo que hay es lo que el agente mostró. Si el comando debía correr los scripts y no lo hizo, eso es un hallazgo de la prueba.

## Lo que el agente mostró

La configuración de PRD-306 no existe: en `.criterio/producto/` solo hay `PRD-300`, y no falta ningún `config.json` de `PRD-306` que yo pueda buscar en otro sitio. No la invento ni uso la de otro producto.

Termino aquí, sin correr `terminos`, `corrida-inicio` ni `overlap`. Si quieres crearla, corre `/criterio-product:product-setup` para `PRD-306`. Si el código correcto era `PRD-300`, repite el comando con ese código.
