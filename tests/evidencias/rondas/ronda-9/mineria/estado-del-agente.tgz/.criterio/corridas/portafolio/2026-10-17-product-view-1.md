# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view gemelo digital

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T21:35:51 · **Fin:** 2026-10-17T21:36:22 · **Duración:** 31 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 18 | 67 | Producto de un solo proyecto (PRY-207): no se armó sección, solo resumen de sus 7 alertas. No se armó la tabla de proyectos sin producto (7) ni se verificaron documentos fuente. |

Por señal (`product-view`): `milestone_met_without_evidence` 22, `progress_vs_plan` 9, `commitment_overdue` 9, `declared_vs_evidence` 7, `variance_cost` 4, `commitment_undated` 4, `commitment_rescheduled` 3, `milestone_overdue` 2, `variance_time` 2, `vendor_deliverable_late` 2, `rebaseline_unauthorized` 1, `vendor_accepted_without_evidence` 1, `pm_vs_pmo` 1

## Lo que el agente mostró

## Producto «gemelo digital» al 2026-10-17

Salió de las fichas del estado, recalculadas hoy con `compute`. Los términos estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

**«Gemelo digital» tiene un solo proyecto, PRY-207 (Gemelo digital de la planta).** Con un solo proyecto la vista por producto no aporta nada, así que no armé la sección. No hay señales que sumar ni dependencias internas que cruzar. La fecha del producto es la del proyecto, 2026-11-25.

Esto es lo que ya dice el cálculo de PRY-207 (7 alertas, 5 días sin movimiento):
- **Estado declarado:** el informe lo declara en verde (corte 2026-09-29), pero el cálculo lo contradice con cuatro señales.
- **Avance:** el avance declarado es 20 %. El plan sostiene entre 75 % y 100 %, con 3 de 4 hitos cumplidos.
- **Costo:** el sobrecosto proyectado es 16,5 % (7.922.563.459 contra 6.800.000.000 aprobados).
- **Compromiso vencido:** Andrés Lozano debía «Entregar el punto 14» el 2026-10-10, hace 7 días.
- **Hitos sin evidencia:** tres hitos figuran como cumplidos sin evidencia (ingeniería básica, ingeniería de detalle y licencias).

No sumé dinero a nivel de producto: con un proyecto, la suma es la cifra del proyecto.

**Proyectos sin producto declarado:** son siete (PRY-201, 202, 205, 206, 209, 210 y 211). No armé la tabla con el área dueña porque esta invocación era de un solo producto. Corre `/product-view` sin argumento si la necesitas.

**Pie de rigor:** fichas de `estado`, corte 2026-10-17. Copié las cifras de `compute` y no verifiqué los documentos fuente en esta corrida. La verificación es tuya.

**Corrida registrada:** `2026-10-17-product-view-1`, 18 segundos. La salida quedó en `estado/corridas/salida-product-view.md`.
