# Caso de negocio — Monitoreo de flota (PRD-300) · borrador del 2026-10-17
**Desde:** `00-definicion/2025-12-15-caso-de-negocio.md` y la definición del 2025-12-15 · **Cifras con fuente:** 1 de 2 (la otra, «retorno esperado en 24 meses», no trae cifra)

Términos vigentes: aceptados por José Francisco Ñáñez el 2026-10-17 (versión 1.1, familia 0.4.0); no hubo que registrarlos de nuevo.

## Qué problema resuelve, y para quién
El segmento Mantenimiento no tiene monitoreo de flota. Cita: «Lo necesito y hoy no lo tengo.» — cliente entrevistado, `10-descubrimiento/2025-10-08-entrevistas.md`, 2025-10-08.
Reserva: es una sola persona, no pidió nada concreto y la entrevista no nombra el segmento (evidencia débil, según la corrida de definición).

## Qué se construye
Alcance: los 11 requerimientos decididos (aceptados) del registro. Los 5 propuestos quedan fuera hasta que el comité los decida.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4000, 4001, 4005, 4006, 4007, 4008, 4011, 4013 | aceptado | La misma frase de la misma entrevista (2025-10-08). Ninguno es nombrado en ella; el acta dice que lo pidió un «cliente entrevistado». Es evidencia de la necesidad general, no de cada requerimiento. |
| REQ-4003, 4004, 4009 | aceptado | **Ninguna.** Se van a construir y nadie citó quién los pidió. |
| REQ-4009 | aceptado | Además sin criterio de aceptación. |

Los 11 aceptados citan el acta del comité del 2026-10-15 (`30-decisiones/2026-10-15-comite-producto.docx`), pero en ninguno consta quién decidió. Las fechas de decisión (2026-03-18 a 2026-08-29) son anteriores al acta. Ninguno tiene proyecto que lo construya.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual (declarado) | 236.725 | Declarada | Caso de negocio, preparado por Camilo Beltrán | 2025-12-15 |
| volumen_mensual (medido) | 201.743 | Medida | Bodega de datos, tablero de producto | corte 2026-10-15 |
| «Retorno esperado en 24 meses» | sin cifra | Supuesta | Se afirma, pero sin valor, sin base de cálculo y sin métrica que lo siga | 2025-12-15 |

La serie medida tiene un solo punto, así que no se puede decir si el volumen sube o baja. Ni el caso ni el tablero definen qué cuenta como «volumen», por lo que no consta que las dos cifras midan lo mismo.

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 236.725 | 201.743 (−14,8 %) | Caso de negocio, 2025-12-15 · Tablero de métricas, corte 2026-10-15 |

La diferencia está bajo el umbral configurado de 20 %. Se lee como imprecisión, no como contradicción, pero queda dentro del caso porque el comité la va a preguntar.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **No hay** | Ningún documento de la carpeta lo trae |
| Contratos o cotizaciones | **No hay** | No hay en la carpeta |
| Costo del equipo | **No hay** | No declarado |

**Este es el primer vacío.** Sin el costo de construir lo que hay es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-19; figura verificado el 2026-07-13) | El cronograma y cualquier fecha de retorno dejan de valer | Camilo Beltrán. La verificación usó el documento técnico del propio proveedor, que no está en la carpeta. Falta contrastarlo con una fuente que el proveedor no controle (entrega recibida, acta de aceptación). |
| El «retorno» se alcanza en 24 meses | No hay caso de negocio | El negocio: nadie ha puesto cifra ni método |
| Las dos cifras de volumen miden lo mismo | La brecha de 14,8 % no es comparable | Quien administra el tablero de producto |
| La necesidad de Mantenimiento se generaliza a los 11 requerimientos | Se construye sin demanda | Los dolientes de cada requerimiento |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir (y su fuente) | Sin él no hay caso que evaluar | Camilo Beltrán / finanzas |
| Cifra de retorno, base de cálculo y métrica que la siga | «Retorno en 24 meses» no se puede verificar | El negocio |
| Criterio de éxito | Sin él el producto no se puede cerrar meses después | Camilo Beltrán, con el Comité de producto |
| Qué pasa si no se hace | El comité no puede comparar | El negocio |
| Alternativas consideradas | Ídem | El negocio |
| Cuándo se sabrá si funcionó | Convierte el criterio de éxito en algo verificable | Camilo Beltrán |
| Definición de «volumen mensual» | Sin ella la brecha del 14,8 % no es interpretable | Quien administra el tablero |
| Demanda para REQ-4003, 4004 y 4009 | Aceptados sin que nadie los pidiera | Elena Duarte, Felipe Arango, Liliana Torres |
| Quién decidió los 11 aceptados | El campo está vacío | Comité de producto |
| Contenido de «Propuesta principal» en la definición | La sección está vacía | Camilo Beltrán |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito, ni métrica de éxito, ni fecha de corte. La única métrica con serie es `volumen_mensual`, pero nadie dijo que sea la que mide el éxito. Se deja como vacío y no se propone un objetivo.

## Si hay otros productos publicados
No hay otros productos publicados a la vista en este espacio, así que no se pudo cruzar. Las métricas que este caso afirma (`volumen_mensual`) no se han comparado con las de otro producto.

## Después
- Los supuestos de la tabla pasan al seguimiento con **assumption-tracking**, para que no se queden dentro del caso.
- Con costo y criterio de éxito cerrados y un caso aprobado: `/criterio-product:product-charter`.
- Este documento no recomienda aprobar ni rechazar, y no calcula rentabilidad ni periodo de recuperación.
