**BORRADOR — lo cierra Camilo Beltrán (gerente de producto) con el Comité de producto. Este agente no lo aprueba.**

# Especificación — Monitoreo de flota (PRD-300) · borrador del 2026-10-17

**Antes de leerla:** el registro no tiene el contenido de ningún requerimiento. Los 16 se llaman «Requerimiento REQ-40xx» (el título es el que pone el acta, no un título real) y ninguno tiene la necesidad que resuelve (`need`: no encontrada). Por eso esta especificación **no dice qué debe hacer el producto**: decir algo sería inventarlo. Lo que sí hace es dejar a la vista qué hay decidido, qué se puede verificar y qué falta.

## Alcance

### Entra
Los 11 requerimientos en estado `aceptado` (según el acta del comité del 2026-10-15, `30-decisiones/2026-10-15-comite-producto.docx`). Del producto el registro solo sostiene el problema: «El segmento Mantenimiento no tiene monitoreo de flota» (`00-definicion/2025-12-15-definicion-producto.docx`).

| REQ | Doliente | Aceptado el | Qué debe hacer |
|---|---|---|---|
| REQ-4000 | Diana Molina | 2026-07-29 | No consta en el registro |
| REQ-4001 | Paula Céspedes | 2026-07-03 | No consta en el registro |
| REQ-4003 | Elena Duarte | 2026-03-19 | No consta en el registro |
| REQ-4004 | Felipe Arango | 2026-05-28 | No consta en el registro |
| REQ-4005 | Ricardo Salas | 2026-04-15 | No consta en el registro |
| REQ-4006 | Diana Molina | 2026-05-07 | No consta en el registro |
| REQ-4007 | Paula Céspedes | 2026-05-31 | No consta en el registro |
| REQ-4008 | Natalia Ospina | 2026-06-05 | No consta en el registro |
| REQ-4009 | Liliana Torres | 2026-08-29 | No consta en el registro |
| REQ-4011 | Liliana Torres | 2026-03-18 | No consta en el registro |
| REQ-4013 | Liliana Torres | 2026-08-06 | No consta en el registro |

### No entra
- **REQ-4002, 4010, 4012, 4014 y 4015**: siguen `propuesto` (entre 95 y 214 días sin decidir, umbral de 60). No se especifica lo que nadie decidió.
- **Diseño y arquitectura**: no se decide aquí; es del equipo que construya.
- **Estimaciones** de esfuerzo, costo o fecha: nacen con el plan, y el plan con el acta de constitución. No hay proyecto que ejecute ninguno de los 11.
- **Todo lo que el registro no dice**: nada se agregó «por razonable».

## Criterios de aceptación

Los 10 aceptados que tienen criterio traen el mismo texto, copiado del acta: «se verifica en producción». REQ-4009 no trae ninguno.

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» | REQ-4000, 4001, 4003, 4004, 4005, 4006, 4007, 4008, 4011, 4013 | **No pasa la prueba.** Dice dónde se mira, no qué se mira ni con qué resultado; dos personas mirando lo construido no llegan a la misma respuesta. Un criterio por requerimiento solo se puede redactar cuando se sepa qué hace cada uno. | No se puede decir: el criterio no nombra ninguna medida. |
| *(ninguno)* | REQ-4009 | Sin criterio. | No aplica. |

Sobre medición: la única métrica que la organización mide hoy es `volumen_mensual` (201.743 al 2026-10-15, bodega de datos). Ningún criterio la usa. El producto tampoco declara criterio de éxito (`success`: no encontrado).

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El proveedor cumple el tiempo pactado» (declarado 2026-03-19) | Marcado como verificado el 2026-07-13 «con el documento técnico del proveedor». Reparos: la fuente es el propio proveedor; el documento de verificación no dice quién verificó; y ningún documento dice qué es «el tiempo pactado» ni qué entregable cubre. | Camilo Beltrán: confirmar contra el contrato o acta de compromiso, no contra el dicho del proveedor. |
| Los 8 aceptados con evidencia (REQ-4000, 4001, 4005, 4006, 4007, 4008, 4011, 4013) responden a una necesidad real | **No verificado.** Los 8 citan la misma frase de una entrevista (2025-10-08, «Lo necesito y hoy no lo tengo.») que no nombra ningún requerimiento. Es evidencia de una necesidad general y cumple 12 meses (umbral 12). | Camilo Beltrán, que realizó la entrevista: decir a cuál requerimiento corresponde cada cita, o conseguir otra. |
| REQ-4003, 4004 y 4009 responden a una necesidad real | **Sin evidencia ninguna**; el acta tiene «—» en «Quién lo pidió». | Elena Duarte, Felipe Arango y Liliana Torres respectivamente: aportar quién lo pidió o devolverlos a `propuesto`. |

## Vacíos

| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Qué hace cada requerimiento (título y `need` de los 11) | No hay especificación posible; cada quien construye su idea. | Cada doliente (tabla de Alcance). |
| Criterio de aceptación medible en los 10 que dicen «se verifica en producción» | Nada de lo entregado se puede aceptar o rechazar sin discusión. | Cada doliente, con Camilo Beltrán. |
| Criterio de aceptación de REQ-4009 | Aceptado sin forma de saber si se cumplió. | Liliana Torres. |
| Comportamiento en casos borde (fallos de dato, flota sin señal, etc.) | **No hay ningún caso borde documentado** en el registro; no se redactó ninguno. | Dolientes; el registro no permite ni proponerlos. |
| Quién decidió la aceptación de los 11 (`who` vacío) y por qué un acta del 2026-10-15 recoge decisiones desde 2026-03-18; la única asistente consignada es Camilo Beltrán y la única decisión es «Se mantiene el plan», sin que haya plan | No hay decisión sustentada del Comité de producto. | Camilo Beltrán, confirmando con el Comité de producto. |
| Criterio de éxito del producto | Sin éxito definido, no hay contra qué medir los criterios de los requerimientos. | Camilo Beltrán. |
| Lo que otros equipos tienen que hacer | Nada está acordado: no hay proyecto (0 de 11 con proyecto que lo ejecute) ni equipo nombrado. Solo se sabe que hay un proveedor. | Camilo Beltrán: `/product-charter` o devolver al comité. |
| Obligaciones normativas | **No barridas.** Ningún documento dice qué datos trata el producto (p. ej., ubicación de vehículos o de conductores). Sin eso no se puede decir si aplica alguna obligación, ni este borrador opina sobre cumplimiento. | Camilo Beltrán, con el área jurídica o de cumplimiento, una vez se defina qué datos trata. |

## Requerimientos aceptados que esta especificación no cubre

| REQ | Título | Por qué no |
|---|---|---|
| — | — | Los 11 aceptados están listados en Alcance. Ninguno queda fuera, pero **ninguno está cubierto en el fondo**: se lista el ID y su doliente, sin comportamiento, porque el registro no lo trae. |

Aparte, los 5 `propuesto` (REQ-4002, 4010, 4012, 4014, 4015) quedan fuera por no estar aceptados.

## Pie

Sale del registro de requerimientos de `estado-producto/PRD-300/requirements/`, actualizado el 2026-10-17. Cubre 11 de 16 requerimientos (los 11 aceptados; ninguno `en_construccion`). No hay barrido de fichas de proyecto porque no existe carpeta de fichas en este espacio. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0 (aceptados por José Francisco Ñáñez el 2026-10-17, versión 1.1).

**Después:** no ofrezco `/product-charter` todavía. Los vacíos sobre qué hace cada requerimiento y cómo se acepta siguen abiertos; con eso el acta nacería con la misma ausencia. Cuando los dolientes los cierren, se corre de nuevo.
