## Monitoreo de flota (PRD-300) · 2026-10-17

**Primera revisión del registro: no hay corte anterior**, así que no se puede decir qué cruzó un umbral «desde» una fecha. Lo que sigue es el estado de partida, no una novedad. Esta corrida deja el primer corte (`snapshots/2026-10-17.json`); la próxima sí podrá separar lo nuevo.

Términos: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se pidió ni registró nada.

### Umbrales cruzados (60 días sin decidir, 12 meses de evidencia)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4012 | 214 días (desde 2026-03-17) | Que el Comité de producto lo decida o lo retire | Laura Vélez (doliente); decide el Comité de producto |
| Sin decidir | REQ-4010 | 132 días (desde 2026-06-07) | Ídem; no tiene evidencia de demanda | Beatriz Cuéllar |
| Sin decidir | REQ-4015 | 117 días (desde 2026-06-22) | Ídem | Carlos Peña |
| Sin decidir | REQ-4014 | 111 días (desde 2026-06-28) | Ídem; no tiene evidencia de demanda | Beatriz Cuéllar |
| Sin decidir | REQ-4002 | 95 días (desde 2026-07-14) | Ídem | Carlos Peña |
| Evidencia vencida | 11 REQ (4000, 4001, 4002, 4005, 4006, 4007, 4008, 4011, 4012, 4013, 4015) | 12 meses | Toda esa evidencia es una sola entrevista del 2025-10-08 («Cliente entrevistado»). Esa entrevista no nombra ningún requerimiento. La demanda de estos 11 se sostiene en una frase genérica de un solo cliente. | Camilo Beltrán |

Los 5 requerimientos sin decidir pasan de 60 días; ninguno tiene un decisor con nombre en el registro. El dato que falta es quién del Comité de producto tiene la facultad de decidirlos. Se ofrece llevarlos al comité.

### Aceptado sin respaldo
- **Sin evidencia de demanda:** REQ-4003, REQ-4004, REQ-4009.
- **Sin criterio de aceptación:** REQ-4009. Además de no tener evidencia, no se puede verificar cuándo está terminado.
- **Sin proyecto que lo construya:** los 11 aceptados (0 % de trazabilidad). Se muestra en la sección de trazas.

### Definición contra datos
- `volumen_mensual`: el caso de negocio (2025-12-15) declara 236.725; la bodega de datos mide 201.743 al 2026-10-15. Brecha de 14,8 %, bajo el umbral de 20 %: no es hallazgo, queda anotada.
- La definición **no declara criterio de éxito** (`success` sin dato). Eso no se rellena.
- No hay supuestos sin verificar con más de 30 días registrados.

### Las trazas
Se leyeron las 13 fichas de `estado/records` (PRY-199 a PRY-211). **Ninguna traza se da por confirmada:** ningún requerimiento nombra proyecto, y ninguna ficha declara ejecutar PRD-300 (seis no declaran producto y PRY-211 dice «No aplica»). Esto es un campo vacío de ambos lados, no un desacuerdo.

### Del descubrimiento
Sin documentos nuevos ni cambiados: 6 documentos, 6 sin cambios, nada que releer. No se ofrece `/product-discovery` ni `/product-definition`.

### Una nota sobre el índice
El comando de lectura reporta como «fuente no encontrada» 8 campos de identidad y definición que citan los dos `.docx` (definición del 2025-12-15 y acta del comité del 2026-10-15). Los dos archivos existen en la carpeta. Probablemente el índice resuelve la ruta desde otro punto de partida; no se tocó. Conviene revisarlo antes de que alguien confíe en esas citas.

### Lo que este comando no hizo
No decidió nada, no verificó ningún supuesto, no escribió a ningún doliente ni tocó ninguna ficha.

**Vuelvo el 2026-11-16.**
