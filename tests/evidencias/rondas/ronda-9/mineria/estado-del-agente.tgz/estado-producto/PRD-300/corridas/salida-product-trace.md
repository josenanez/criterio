## Trazabilidad — Monitoreo de flota (PRD-300) · al 2026-10-17
11 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Fichas leídas: las 13 de `estado/records` (PRY-199 a PRY-211). Ninguna traza se da por confirmada: ningún requerimiento nombra proyecto.

### Decidido y nadie lo está construyendo
Los 11 requerimientos aceptados tienen `traces.project = null`. Fuente de la decisión: `documentos/productos/PRD-300/30-decisiones/2026-10-15-comite-producto.docx`. El registro no guarda quién decidió (`decision.who` vacío en todos), así que la columna queda declarada como no encontrada.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4011 | Requerimiento REQ-4011 | 2026-03-18 | no registrado |
| REQ-4003 | Requerimiento REQ-4003 | 2026-03-19 | no registrado |
| REQ-4005 | Requerimiento REQ-4005 | 2026-04-15 | no registrado |
| REQ-4006 | Requerimiento REQ-4006 | 2026-05-07 | no registrado |
| REQ-4004 | Requerimiento REQ-4004 | 2026-05-28 | no registrado |
| REQ-4007 | Requerimiento REQ-4007 | 2026-05-31 | no registrado |
| REQ-4008 | Requerimiento REQ-4008 | 2026-06-05 | no registrado |
| REQ-4001 | Requerimiento REQ-4001 | 2026-07-03 | no registrado |
| REQ-4000 | Requerimiento REQ-4000 | 2026-07-29 | no registrado |
| REQ-4013 | Requerimiento REQ-4013 | 2026-08-06 | no registrado |
| REQ-4009 | Requerimiento REQ-4009 | 2026-08-29 | no registrado |

Los títulos son los genéricos del acta; no hay un título descriptivo en el documento. REQ-4009 además no tiene criterio de aceptación ni evidencia.

### La traza no se confirma
Ninguna fila: no hay trazas declaradas que confirmar, porque ningún REQ dice ejecutarse en un proyecto.

### Lo que un proyecto construye y el registro no tiene
| Proyecto | Su ficha dice que ejecuta este producto | Ningún REQ lo nombra |
|---|---|---|
| PRY-200 Mantenimiento predictivo de camiones | Campo producto = «monitoreo de flota», acta de constitución del 2026-06-09 (`PRY-200-mantenimiento-predictivo-de-camiones/00-gobierno/2026-06-09-acta-constitucion.docx`) | Sí: ninguno de los 16 REQ lo referencia |

Ojo: la ficha lo dice por nombre, no por código PRD-300. Que «monitoreo de flota» sea este producto es una inferencia por coincidencia de nombre; hay que confirmarla con el gerente de PRY-200. PRY-203 (Despacho automático de flota) dice «despacho de flota», que es otro nombre, y no se toca.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4000, 4001, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4011, 4013 | aceptado | comité de producto, acta del 2026-10-15 | — (eslabón roto aquí) | no | — |
| REQ-4002, 4010, 4012, 4014, 4015 | propuesto | sin decisión (95 a 214 días) | — | no | — |

La cadena se rompe en el eslabón decisión → proyecto, en los 11 aceptados. Los 5 propuestos no necesitan traza todavía.

### Sin fichas a la vista
Todas las fichas están. Seis no declaran producto (PRY-201, 202, 205, 206, 209, 210) y PRY-211 dice «No aplica»; eso es un campo vacío del otro lado, no un desacuerdo con este registro.

### Dos cosas que no cierran
- El acta del comité es del 2026-10-15, pero las fechas de decisión por requerimiento van de marzo a agosto: no se puede saber desde aquí si el acta recoge decisiones anteriores o las fechas están mal.
- Cobertura: 11 de 11 decididos sin proyecto (0 %). Evidencia: 8 de 11 (72,7 %), pero la evidencia disponible tiene 12 meses.

Siguiente paso: `/product-charter` para el REQ que esté listo para ser proyecto, y una conversación con el gerente de PRY-200 sobre qué parte de PRD-300 está construyendo.
