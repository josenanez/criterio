# Corrida del 2026-10-17 · product-publish

PRD-300 · 16 requerimientos · 12 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 11 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |

No se publicó: falta la carpeta común de productos publicados en la configuración

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

No publiqué la ficha de PRD-300 (Monitoreo de flota): la configuración no define la carpeta de productos publicados, y no existe ninguna carpeta `publicados` en el espacio. Sin un sitio común acordado no escribí nada; acordarlo es una conversación de la organización, no un comando.

Términos: vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo.

**Lo que llevaría la ficha, con corte al 2026-10-17:** 16 requerimientos · 0 proyectos · 1 métrica afirmada
**Segmento declarado:** Segmento Mantenimiento
**Métricas:** volumen_mensual, declarada 236725, de documentos/productos/PRD-300/00-definicion/2025-12-15-caso-de-negocio.md (2025-12-15). La medición del 2026-10-15 da 201743, 14.8 % por debajo; esa serie medida no se publica.

Nota: ningún requerimiento tiene proyecto asignado, así que la ficha no permitiría cruzar por proyecto.

Para publicar: configurar la carpeta común de publicados y volver a correr el comando.
