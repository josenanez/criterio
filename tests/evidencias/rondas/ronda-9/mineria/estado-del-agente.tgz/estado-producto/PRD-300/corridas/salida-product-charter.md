Términos: vigentes (v1.1), aceptados por José Francisco Ñáñez el 2026-10-17; no hubo que registrarlos de nuevo.
Producto: PRD-300 · Monitoreo de flota (único configurado). Sin interfaz: en cada pregunta se tomó la respuesta sugerida, que es seguir marcando cada faltante como vacío del acta y no rellenarlo.

## Verificación previa de REQ-4000

| Condición | Resultado | Cita |
|---|---|---|
| Aceptado, no propuesto | **Sí**, desde 2026-07-29. Pero **no consta quién lo decidió**: el comité del 2026-10-15 lista como único asistente a Camilo Beltrán y el campo «quién decidió» está vacío. | `30-decisiones/2026-10-15-comite-producto.docx` |
| Criterios de aceptación verificables | **No.** El único criterio es «se verifica en producción»: no dice qué se mide ni con qué umbral. Existe, pero no permite juzgar el cierre. | `30-decisiones/2026-10-15-comite-producto.docx` |
| Evidencia de demanda con cita | **Débil.** La única es una entrevista del 2025-10-08 («Lo necesito y hoy no lo tengo»), de un cliente sin nombre, que **no nombra este requerimiento**. Tiene más de 12 meses (umbral `evidence_stale_months` = 12). | `10-descubrimiento/2025-10-08-entrevistas.md` |
| Autoridad declarada en la definición | **No.** La definición no la dice. «Comité de producto» sale del acta del comité y de la configuración, no de la definición. | `00-definicion/2025-12-15-definicion-producto.docx` |

Faltan o son débiles tres de las cuatro condiciones. Se sigue marcándolas como vacíos del acta, sin rellenarlas.

---

# Acta de constitución — Monitoreo de flota · REQ-4000 · borrador del 2026-10-17
**Producto:** PRD-300 · Monitoreo de flota · **Requerimientos:** REQ-4000

## Qué problema resuelve
«El segmento Mantenimiento no tiene monitoreo de flota.» (`00-definicion/2025-12-15-definicion-producto.docx`, 2025-12-15).
**El requerimiento REQ-4000 no tiene necesidad propia escrita:** su título es el genérico «Requerimiento REQ-4000» y ningún documento dice qué pide. El acta hereda el problema del producto, no uno específico de este requerimiento.

## Criterio de éxito
- «Se verifica en producción» (`30-decisiones/2026-10-15-comite-producto.docx`). **No es verificable tal cual:** no hay métrica, umbral ni fecha.
- La definición del producto **no declara criterio de éxito** (`success`: no encontrado).
- Sin esto, el cierre no se podrá juzgar meses después. Hay que definirlo antes de firmar.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4000 | Requerimiento REQ-4000 (dueña: Diana Molina) | Entrevista 2025-10-08, cliente sin nombre, que no lo nombra (indirecta, vencida). El acta del comité dice que lo pidió un «cliente entrevistado». |

### No entra
Esta acta cubre solo REQ-4000. **Ningún documento dice por qué los demás quedan fuera**; no se inventa una razón. Su estado según el comité del 2026-10-15:
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4001, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4011, 4013 | Requerimiento REQ-… | Aceptados; no se pidieron en esta acta. Razón de exclusión: no está en los documentos. |
| REQ-4002, 4010, 4012, 4014, 4015 | Requerimiento REQ-… | Propuestos: sin decisión del gerente de producto, no pueden entrar. |

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Camilo Beltrán es el gerente **del producto** (definición); este comando no propone ni nombra gerente del proyecto.
- **Comité:** Comité de producto (acta 2026-10-15). Asistió solo Camilo Beltrán.
- **Autoridad del gerente del proyecto:** no está dicha.
- **Dueña del requerimiento:** Diana Molina (acta 2026-10-15).

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-19) | Sí, el 2026-07-13, con el documento técnico del proveedor (`00-definicion/2026-07-13-verificacion-supuesto.md`) | No pasa como riesgo: está verificado. La verificación es del proveedor sobre sí mismo; el gerente del proyecto decide si le basta. |
| REQ-4000 no declara supuestos propios | — | — |

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| No se sabe | No se barrió: ningún documento dice qué datos recoge el monitoreo (p. ej. ubicación de vehículos o conductores) ni el país | — | Sin resolver. Va a revisión jurídica o de cumplimiento; este borrador no opina sobre cumplimiento. |

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Quién decidió aceptar REQ-4000 | La aceptación no tiene dueño; si se discute, no hay a quién preguntar | Camilo Beltrán / Comité de producto |
| Necesidad de REQ-4000 (qué pide) | El proyecto arranca sin saber qué construir | Diana Molina |
| Criterio de aceptación medible | El cierre no se puede juzgar | Diana Molina y Camilo Beltrán |
| Criterio de éxito del producto | Ídem a nivel producto | Camilo Beltrán |
| Evidencia de demanda directa y vigente | El requerimiento descansa en una entrevista vencida que no lo nombra | Camilo Beltrán |
| Autoridad del gerente del proyecto | Escala todo o no escala nada | Comité de producto |
| Patrocinador y gerente del proyecto | Sin firmante ni dueño de la ficha | Comité de producto |
| Hitos y presupuesto aprobado | No hay contra qué medir; no se inventan | Comité de producto |
| Alcance de datos y país (norma) | Riesgo normativo sin ver | Camilo Beltrán con jurídico |

Nota de contexto, no es hallazgo: el volumen mensual medido (201.743, tablero 2026-10-15) está 14,8 % por debajo del declarado (236.725, caso de negocio 2025-12-15). El umbral `claim_gap_pct` es 20 %.

---
**Esto es un borrador.** Lo firma el Comité de producto (quién firma, a confirmar). **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`, y el estado declarado queda vacío por diseño.

## A quién le queda
Cuando haya firma y gerente del proyecto, esa persona instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza, y Alba sabrá si el producto se está construyendo sin preguntarle a nadie.
