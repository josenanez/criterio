Soy Alba. Trabajo antes de que haya proyecto: miro qué sostiene tu definición y qué se sostiene solo.

*(Sesión sin interfaz: las cuatro preguntas se respondieron con la propuesta por defecto, dichas en una línea cada una.)*

- **Quién eres y qué producto es:** Camilo Beltrán, gerente de **PRD-300 · Monitoreo de flota** (segmento Mantenimiento), según la definición del 2025-12-15.
- **Quién decide qué se construye:** el Comité de producto (el acta del 2026-10-15 es de ese comité; ningún documento nombra a una persona que decida).
- **Dónde guardo lo que encuentro:** `estado-producto/PRD-300`, hermana de `documentos/`. No uso `estado/`, que es de otro agente.
- **Términos:** versión 1.1, mostrados tal cual (texto «en corto» y enlace a la nota legal, https://www.josenanez.com/es/agents/criterio-pmo/legal). El sí lo dio la instrucción de la prueba: José Francisco Ñáñez, 2026-10-17.

## Listo — Monitoreo de flota (PRD-300)

**Lo que miré:** 6 documentos · 1 de descubrimiento (una ronda de entrevistas, 2025-10-08) · la definición del 2025-12-15 · lo más reciente es del 2026-10-15 (acta del comité y tablero de métricas). Los 6 se leyeron; no hubo formatos ilegibles (2 son .docx, leídos desde su XML).
**Términos:** aceptados para la versión 0.4.0 de la familia (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 d31e6b3611041018… (huella de los términos); la del comprobante .md es 38ea1d146bbd84f3…

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| El segmento Mantenimiento no tiene monitoreo de flota | **Supuesto.** Una sola frase de un «cliente entrevistado» («Lo necesito y hoy no lo tengo»), que no dice quién es, de qué segmento ni qué necesita | Entrevista 2025-10-08 (12 meses) |
| El volumen mensual es 236.725 | **Contradicha en parte por la medición.** El tablero mide 201.743 al 2026-10-15: el negocio declara 14,8 % por encima de lo medido. Bajo el umbral de 20 %, así que no es alerta | Caso de negocio 2025-12-15 / tablero 2026-10-15 |
| El proveedor cumple el tiempo pactado | **Sostenida por un supuesto verificado**, pero con el documento técnico del propio proveedor | Declarado 2026-03-19, verificado 2026-07-13 |
| Retorno esperado en 24 meses | **No está dicha en ninguna parte** (ver abajo) | — |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ningún documento dice qué tiene que pasar para que este producto haya funcionado.
- **De dónde sale el retorno en 24 meses.** El caso de negocio lo afirma en una línea, sin cifra, sin base de cálculo y sin fuente.
- **De dónde sale 236.725.** La cifra cita al propio caso de negocio como fuente; no hay serie anterior ni definición de qué cuenta como «volumen».
- **La propuesta.** La definición tiene un título, «Propuesta principal», y nada debajo.
- **Qué pidió cada requerimiento.** Los 16 se llaman «Requerimiento REQ-40xx»: ningún documento dice el problema de ninguno, y ninguno está nombrado en las entrevistas.
- **Qué proyecto construye algo.** La definición dice «Ninguno declarado» y la columna de proyecto del acta está vacía en los 16.
- **Qué plan «se mantiene».** La única decisión del acta del 2026-10-15 es «Se mantiene el plan», y no hay plan en la carpeta.
- **Quién decidió cada aceptación.** El acta registra el estado y la fecha, pero no quién lo decidió.

### Supuestos sobre los que está escrita
Uno declarado: «El proveedor cumple el tiempo pactado». Dos cosas a mirar: se verificó con un documento del mismo proveedor (su palabra confirmada por su propio documento), y está fechado el 2026-03-19, tres meses después de la definición del 2025-12-15 a la que pertenece, así que el documento se editó después de su fecha o el supuesto se agregó más tarde sin dejar versión.

### Lo que el registro muestra de los 16 requerimientos del acta (11 aceptados, 5 propuestos)
- **11 aceptados sin proyecto que los ejecute** (11 de 11; 0 % con traza).
- **11 con evidencia vencida:** su única evidencia es la entrevista del 2025-10-08, de 12 meses. Todos los que dicen «cliente entrevistado» apuntan a esa misma entrevista, de un solo cliente: es una evidencia, no once.
- **3 aceptados sin evidencia de demanda:** REQ-4003, REQ-4004 y REQ-4009. El acta no dice quién los pidió.
- **1 aceptado sin criterio de aceptación:** REQ-4009 (además, sin evidencia y sin proyecto).
- **5 propuestos sin decidir:** REQ-4012 (214 días), REQ-4010 (132), REQ-4015 (117), REQ-4014 (111) y REQ-4002 (95). El umbral es 60.
- **El criterio de aceptación escrito en 14 de 16 es «se verifica en producción»** (REQ-4002, propuesto, y REQ-4009 no lo tienen): no es verificable, dice dónde y no qué.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito: las transcripciones completas de las entrevistas (hoy hay una cita de una línea); más de un punto en la serie de `volumen_mensual`, y su definición; el plan que el comité «mantiene»; y quién decide cada aceptación. Sin ellos, un requerimiento descartado se ve igual que uno que nadie miró.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién los pidió.
