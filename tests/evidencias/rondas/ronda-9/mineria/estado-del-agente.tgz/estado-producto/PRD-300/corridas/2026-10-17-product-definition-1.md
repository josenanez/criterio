# Corrida del 2026-10-17 · product-definition

PRD-300 · 16 requerimientos · 31 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 11 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |

La evidencia no contradice la definición; la sostiene débilmente (una entrevista de hace 12 meses). Falta criterio de éxito, propuesta y definición de volumen; la cifra de volumen está 14,8% bajo lo declarado (bajo el umbral).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Monitoreo de flota (PRD-300) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-12-15-definicion-producto.docx` + `2025-12-15-caso-de-negocio.md` · **del** 2025-12-15 · 7 afirmaciones

### Lo que la evidencia contradice
Nada. Ninguna fuente dice lo contrario de lo que afirma la definición.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 236.725 | 201.743 | −14,8 % | Caso de negocio, 2025-12-15 · Tablero de métricas (bodega de datos), corte 2026-10-15 |

La diferencia (14,8 %) queda **bajo el umbral de 20 %** configurado: es imprecisión, no contradicción. Dos reservas: la serie tiene un solo punto (no se puede decir si sube o baja), y el tablero no define qué cuenta como «volumen», así que no se sabe si las dos cifras miden lo mismo.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| «Retorno esperado en 24 meses» | Caso de negocio, 2025-12-15 | Sin cifra, sin base de cálculo y sin métrica que lo siga |

### No está dicho en ninguna parte
- **Criterio de éxito:** la definición no lo declara.
- **La propuesta:** la sección dice solo «Propuesta principal»; no hay contenido.
- **Que el segmento Mantenimiento sea quien tiene el problema:** la única entrevista (2025-10-08) es de un «cliente entrevistado» y no nombra el segmento.
- **Qué cuenta como «volumen mensual»:** ni el caso de negocio ni el tablero lo definen.
- **Qué es «el plan» que el comité de 2026-10-15 decidió mantener:** ningún documento de la carpeta lo contiene.
- **Qué datos recoge el monitoreo:** la definición no lo dice (relevante para el barrido normativo).

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El proveedor cumple el tiempo pactado (declarado 2026-03-19) | 0: figura verificado el 2026-07-13 (116 días después) | Ya verificado, pero con el documento técnico **del propio proveedor**, que no está en la carpeta (solo la nota de verificación). Para sostenerlo: traer ese documento y contrastarlo con una fuente que el proveedor no controle (entrega recibida, acta de aceptación). |

No hay supuestos sin verificar.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento Mantenimiento no tiene monitoreo de flota | Entrevista a un cliente: «Lo necesito y hoy no lo tengo.» | 2025-10-08 | Débil: una persona que dijo que lo necesita; ninguna que pagó o pidió algo concreto. No identifica el segmento. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| El problema del segmento | Entrevista del 2025-10-08 | 12 meses (en el umbral de 12) |
| 11 de los 16 requerimientos del registro | Esa misma entrevista | 12 meses |

Además, 3 requerimientos aceptados (REQ-4003, REQ-4004, REQ-4009) no tienen evidencia de demanda alguna.

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Nada nombrado | — | — | — | La definición no menciona datos personales, pagos, consumidor financiero ni retención. Un monitoreo de flota puede tocar datos de ubicación de conductores, pero el documento no dice qué recoge, y **no se establece si aplica ni si cumple**. Sin país declarado ni norma a la vista. Esto va a revisión jurídica. |

### Lo que falta para cerrar la definición
- **Criterio de éxito:** falta. Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- Problema: declarado. Para quién: declarado (Mantenimiento). Quién decide: Comité de producto (a la reunión del 2026-10-15 asistió solo el gerente de producto).
- Además: ningún proyecto construye el producto («Ninguno declarado»), y 0 de 11 requerimientos aceptados tienen trazabilidad a un proyecto.
