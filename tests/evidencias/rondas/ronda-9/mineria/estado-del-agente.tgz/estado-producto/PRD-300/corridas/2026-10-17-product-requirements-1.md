# Corrida del 2026-10-17 · product-requirements

PRD-300 · 16 requerimientos · 34 s · 31 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 11 |
| `requirement_untraced` | 11 |
| `requirement_undecided` | 5 |
| `requirement_accepted_without_evidence` | 3 |
| `requirement_without_acceptance` | 1 |

REQ-4003, REQ-4004 y REQ-4009 aceptados sin evidencia; 11 aceptados sin proyecto; 5 propuestos sin decidir hace más de 60 días; la evidencia de 8 aceptados es una sola entrevista que no nombra el requerimiento

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Monitoreo de flota (PRD-300) · al 2026-10-17
16 requerimientos · 11 decididos · 72.7% con evidencia · 0% con proyecto que lo ejecuta

Gerente de producto: Camilo Beltrán · Quien decide: Comité de producto.
Las cifras salen de `producto.py compute`. Las trazas a proyecto no se pudieron confirmar contra fichas de proyecto: no se pasó `--fichas` porque no hay carpeta de fichas en este espacio.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4003 | Requerimiento REQ-4003 | aceptado (2026-03-19) | Elena Duarte |
| REQ-4004 | Requerimiento REQ-4004 | aceptado (2026-05-28) | Felipe Arango |
| REQ-4009 | Requerimiento REQ-4009 | aceptado (2026-08-29) | Liliana Torres |

Ninguno tiene una sola cita de quien lo pidió. Cierra el vacío el doliente de cada uno, con la cita de quien lo pidió o con la decisión de devolverlo a `propuesto`.

Ojo con el 72.7%: los 8 aceptados que sí tienen evidencia citan la misma frase de la misma entrevista (2025-10-08, «Lo necesito y hoy no lo tengo.»). Esa entrevista no nombra ninguno de los requerimientos; el acta dice que lo pidió un «cliente entrevistado». Es evidencia de la necesidad general, no de cada requerimiento.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | Doliente |
|---|---|---|---|
| REQ-4011 | Requerimiento REQ-4011 | 2026-03-18 | Liliana Torres |
| REQ-4003 | Requerimiento REQ-4003 | 2026-03-19 | Elena Duarte |
| REQ-4005 | Requerimiento REQ-4005 | 2026-04-15 | Ricardo Salas |
| REQ-4006 | Requerimiento REQ-4006 | 2026-05-07 | Diana Molina |
| REQ-4004 | Requerimiento REQ-4004 | 2026-05-28 | Felipe Arango |
| REQ-4007 | Requerimiento REQ-4007 | 2026-05-31 | Paula Céspedes |
| REQ-4008 | Requerimiento REQ-4008 | 2026-06-05 | Natalia Ospina |
| REQ-4001 | Requerimiento REQ-4001 | 2026-07-03 | Paula Céspedes |
| REQ-4000 | Requerimiento REQ-4000 | 2026-07-29 | Diana Molina |
| REQ-4013 | Requerimiento REQ-4013 | 2026-08-06 | Liliana Torres |
| REQ-4009 | Requerimiento REQ-4009 | 2026-08-29 | Liliana Torres |

Los 11 aceptados tienen `project: null`. Los más viejos llevan 7 meses decididos (REQ-4011, REQ-4003). Quien lo cierra es el gerente de producto, Camilo Beltrán: o abre el proyecto (`/product-charter`) o lo devuelve al comité.

### Sin doliente, o con un área en vez de una persona
Ninguno. Los 16 tienen una persona como doliente.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4009 | Requerimiento REQ-4009 | aceptado |

Solo cuentan los decididos. Los propuestos no se miden por este vacío. El doliente es Liliana Torres.

### Decidido sin documento que lo respalde
Los 11 aceptados citan el acta del comité del 2026-10-15 (`30-decisiones/2026-10-15-comite-producto.docx`), así que no falta el documento. Dos cosas que ese registro no deja ver:
- En ninguno de los 11 consta **quién decidió**: el campo está vacío. Hay que confirmarlo con el Comité de producto.
- Las fechas de decisión (de 2026-03-18 a 2026-08-29) son anteriores al acta, que es del 2026-10-15. El documento recoge decisiones tomadas antes; no las toma ese día.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.
| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4012 | Requerimiento REQ-4012 | 214 días (2026-03-17) | Comité de producto |
| REQ-4010 | Requerimiento REQ-4010 | 132 días (2026-06-07) | Comité de producto |
| REQ-4015 | Requerimiento REQ-4015 | 117 días (2026-06-22) | Comité de producto |
| REQ-4014 | Requerimiento REQ-4014 | 111 días (2026-06-28) | Comité de producto |
| REQ-4002 | Requerimiento REQ-4002 | 95 días (2026-07-14) | Comité de producto |

Los 5 propuestos pasan el umbral. Se propone decidirlos, aceptarlos o descartarlos, en el próximo comité mensual; ninguno se cierra por viejo. REQ-4010 y REQ-4014 no tienen evidencia, y a un propuesto no se le exige.

### Evidencia vieja
Umbral: 12 meses. Todos los casos dependen de la misma entrevista.
| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4000, 4001, 4005, 4006, 4007, 4008, 4011, 4013 (aceptados) | Entrevista 2025-10-08 | 12 meses |
| REQ-4002, 4012, 4015 (propuestos) | Entrevista 2025-10-08 | 12 meses |

### Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 5 | 11 | 0 | 0 | 0 |

No hay ningún descartado registrado. Si el comité descartó algo, nadie lo anotó.

### Lo que no es hallazgo
- Caso de negocio: el volumen mensual declarado es 236.725 y el medido es 201.743 (brecha del 14.8% a 2026-10-15). Queda por debajo del umbral del 20%.
- La definición no declara criterio de éxito (`success`); eso queda como desconocido, no como hallazgo.

### Conteo por señal
evidence_stale 11 · requirement_untraced 11 · requirement_undecided 5 · requirement_accepted_without_evidence 3 · requirement_without_acceptance 1

### Después
11 requerimientos decididos que nadie está construyendo: corresponde `/product-trace`. REQ-4000, 4001, 4005 a 4008, 4011 y 4013 están aceptados, con evidencia y con criterio de aceptación, aunque la evidencia sea vieja y genérica; si el comité quiere abrir proyecto, `/product-charter`.
