# Corrida · 2026-10-17-project-charter-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-charter PRY-200 revisar

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-200

**Inicio:** 2026-10-17T20:46:17 · **Fin:** 2026-10-17T20:46:59 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-charter` | 13 | — | 26 | 52 | Revisión del acta de PRY-200: sin autoridad del gerente, objetivo no medible, alcance y exclusiones placeholder, dependencias contradicen el informe. No sé si hay actas o decisiones fuera de la carpeta. |

Por señal (`project-charter`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Revisé el acta de constitución de PRY-200 (Crédito de libranza digital). Está firmada el 2025-10-01 y no tiene ninguna versión posterior. Le faltan casi todos los campos que importan, y el más grave es la autoridad del gerente.

Los términos ya estaban vigentes, aceptados el 2026-10-17 por José Francisco Ñáñez, así que no los registré de nuevo. Esta corrida no hizo ninguna pregunta.

**Qué falta y qué consecuencia tiene:**
- **Autoridad del gerente:** no existe en ningún documento. La proyección al cierre es 18.323.116.908 COP contra 18.000.000.000 aprobados (+323.116.908, 1,8 %), y el acta no dice quién autoriza ese exceso. Tampoco dice quién decide el ajuste del reglamento que pidió el Consejo de Administración.
- **Objetivo de negocio:** dice «Entregar crédito de libranza digital para Crédito», que repite el nombre del proyecto. No tiene beneficio ni cifra.
- **Alcance y exclusiones:** son texto de relleno («Componente 1, 2, 3» y «Lo que otro proyecto cubre»). No se puede evaluar un cambio contra un alcance que no está escrito.
- **Criterio de éxito:** «en producción y medido» no es medible, y no dice quién lo mide.
- **Dependencias:** el acta dice «ninguna declarada», pero el informe de avance del 2026-10-13 lista como riesgo abierto la dependencia del proveedor del core cooperativo.
- **Supuestos, restricciones, hitos y cadencia del comité:** no hay sección para ninguno. Solo constan las fechas de inicio y cierre.

Patrocinador (Felipe Arango), gerente (Elena Duarte), presupuesto y fechas sí están.

En el contenido del acta dejé como pendiente de definir lo que ningún documento sostiene. No completé nada con supuestos.

**Lo que no sé:** si hay una adenda o una decisión de comité fuera de la carpeta, porque solo hay dos documentos. Tampoco sé cómo se mide el 84 % de avance declarado, que va con solo 46,6 % del presupuesto ejecutado. Eso queda para `/health-check`.

**Lo que ofrezco, sin ejecutar:**
- Llevar la definición de autoridad del gerente al Comité de Riesgos como decisión, empezando por el +323 M y el ajuste del reglamento.
- Pasar los supuestos faltantes y la dependencia del core al registro RAID con `/raid-log PRY-200`.

La corrida quedó registrada como `2026-10-17-project-charter-1`, con tu salida completa guardada como evidencia en `estado/corridas/salida-project-charter.md`.
