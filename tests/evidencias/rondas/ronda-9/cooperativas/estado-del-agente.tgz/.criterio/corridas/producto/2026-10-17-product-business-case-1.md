# Corrida · 2026-10-17-product-business-case-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-business-case (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:18:48 · **Fin:** 2026-10-17T20:19:34 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-business-case` | 16 | — | 33 | 25 | Armó la estructura del caso de negocio de PRD-307. Dijo que no sabe: costo de construir, origen de 68.516, cifra del retorno, propuesta, criterio de éxito y el documento del proveedor que sostiene el único supuesto verificado. |

Por señal (`product-business-case`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 6, `requirement_undecided` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1

## Lo que el agente mostró

Armé el borrador del caso de negocio de PRD-307 (Auxilios de solidaridad) y registré la corrida. Tardó 33 segundos. Las cifras del negocio no tienen de dónde salir.

Los términos ya estaban vigentes y aceptados por José Francisco Ñáñez (v1.1, 2026-10-17), así que no los registré de nuevo.

- **Cifras:** hay una declarada, `volumen_mensual` = 68.516, y su fuente es el mismo caso de negocio, sin documento detrás. El retorno a 24 meses es una frase sin valor ni base. No hay ninguna cifra medida, porque PRD-307 no tiene carpeta de métricas.
- **Costos:** no hay ninguno en los documentos. Es el primer vacío, y sin él hay una propuesta, no un caso que evaluar.
- **Supuesto:** «El reglamento vigente lo permite» figura como verificado el 2026-08-22. Esa verificación cita un documento técnico del proveedor que no está en la carpeta.
- **Demanda:** de los 13 requerimientos aceptados, 6 no tienen ninguna cita de quien los pidió. Los otros 7 comparten una sola entrevista con un cliente sin nombre, que no nombra ninguno de ellos. Ninguno tiene proyecto que lo construya.
- **Otros vacíos:** la propuesta, el criterio de éxito, la alternativa y qué pasa si no se hace.
- **Solape con otros productos:** el valor 68.516 solo aparece en PRD-307. Varios productos usan una métrica con el mismo nombre, pero no hay cifra contada dos veces. No hice el cruce completo de segmento y proyectos, porque PRD-307 no declara proyectos.

No calculé rentabilidad ni recomendé aprobar o rechazar, porque ninguna cifra tiene fuente para hacerlo.

Archivos en `estado-producto/PRD-307/corridas/`:
- `salida-product-business-case.md`
- `2026-10-17-product-business-case-1.md`
