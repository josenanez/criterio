# Corrida · 2026-10-17-project-history-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-history PRY-204

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-204

**Inicio:** 2026-10-17T20:43:46 · **Fin:** 2026-10-17T20:44:45 · **Duración:** 59 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-history` | 13 | — | 45 | 52 | Historia de PRY-204 sobre 7 documentos (2025-12-29 a 2026-10-14). Sin documentos en 2026-T1, T2 y T3. Dijo que no sabe: qué pasó entre enero y septiembre, qué comité aprobó CC-01, qué se amplió, si el presupuesto cambió, y los meses declarando sin sustento (hay un solo estado declarado). |

Por señal (`project-history`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Terminé la historia de PRY-204 y dejé la corrida registrada. No se podía mostrar la salida entera antes de la llamada final, así que la tienes aquí resumida y completa en `estado/corridas/salida-project-history.md`.

**Qué hice:** Los términos ya estaban vigentes (0.4.0, aceptados por José Francisco Ñáñez el 2026-10-17), así que no registré nada nuevo. Leí 7 documentos, entre 2025-12-29 y 2026-10-14.

**Qué encontré:**
- **Silencio:** No hay ningún documento en 2026-T1, T2 ni T3. Entre el acta de constitución y el siguiente documento pasan nueve meses.
- **Cifras:** 1 replanificación, 80 días de atraso contra el original (26,7 %) y 0 cambios de gobierno.
- **Desde cuándo no se sostiene:** Desde el 2026-03-24. Ese día vencía el hito «Diseño funcional aprobado», que figura cumplido sin evidencia (207 días). «Ambiente de pruebas certificado» está igual (132 días).
- **Estado declarado:** El 2026-10-14 el estado es verde, con 76 % de avance. Nada de lo anterior aparece en el informe.
- **Cambio CC-01:** Dice «autorizada por el comité», sin decir cuál ni citar acta. El único comité en la carpeta es del 2026-10-11, un día antes de la solicitud. No trata el cambio y registra un solo asistente («Sandra Gil, Sandra Gil»).
- **Lo que no sé:** No pude calcular los «meses declarando sin sustento» porque hay un solo estado declarado, no una serie. Tampoco sé qué pasó entre enero y septiembre, qué se amplió con CC-01 ni si el presupuesto cambió.

Una cifra no sale del script: los 49 días entre el cierre de la integración con el core (2026-08-21) y su acta de recibo (2026-10-09). La calculé a mano y lo dejé dicho en la salida.

**Cierre:** La corrida quedó como `2026-10-17-project-history-1`, con la nota de lo que no sé. Puedo llevar la historia al comité del 2026-10-24 o al cierre del proyecto, si lo quieres.
