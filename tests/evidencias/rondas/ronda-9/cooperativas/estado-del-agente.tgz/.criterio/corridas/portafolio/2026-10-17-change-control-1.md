# Corrida · 2026-10-17-change-control-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:change-control PRY-201 mover la salida a producción 30 días

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-201

**Inicio:** 2026-10-17T20:42:55 · **Fin:** 2026-10-17T20:43:41 · **Duración:** 46 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `change-control` | 13 | — | 33 | 52 | Solicitud PRY-201 +30 días: sin dependientes en el portafolio, sin autoridad declarada en el acta; no se supo quién pide, motivo, costo ni si CT-894 cubre febrero; ejecutado > comprometido señalado. |

Por señal (`change-control`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Preparé la solicitud de cambio de PRY-201 (Apertura de ahorro en línea). No puede aprobarse todavía: el acta no dice quién tiene autoridad para aprobar este cambio. La corrida quedó registrada como `2026-10-17-change-control-1`, con la salida completa en `estado/corridas/salida-change-control.md`.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no los registré otra vez.

- **Cambio pedido:** la salida a producción pasa del 2027-01-20 al 2027-02-19, es decir, +30 días. Hoy hay una sola línea base (v1, aprobada el 2025-12-12 por el Comité de Riesgos) y ninguna replanificación. Este sería el primer cambio.
- **Impacto en el portafolio:** el cálculo no encuentra ningún proyecto que dependa de PRY-201. Eso no prueba que no haya efecto, porque el acta excluye «lo que otro proyecto cubre» sin nombrar el proyecto. El cálculo tampoco da cuántos días se mueve el piloto del 2026-11-02, porque eso requiere holgura por actividad.
- **Quién decide:** no se puede determinar, porque el acta no declara autoridad. Por eso el paquete va al Comité de Riesgos; el próximo comité está fijado para el 2026-10-24.
- **Costo:** nadie declaró impacto de costo para los 30 días, así que alguien lo absorbería sin que conste. Además, el informe del 2026-10-12 declara ejecutado (1.614.863.025 COP) mayor que comprometido (1.445.061.642 COP), y eso hay que aclararlo antes de fiarse de la proyección.
- **Si se aprueba:** línea base 2 con cierre 2027-02-19, y +30 días de desviación contra la original. La línea base 1 no se toca.

No sé quién pide el cambio ni por qué, cuánto cuesta, ni si el contrato CT-894 con Integración Financiera del Sur cubre hasta febrero. Tampoco sé si hay dependencias reales sin declarar. Todo eso quedó escrito como pendiente en la salida.
