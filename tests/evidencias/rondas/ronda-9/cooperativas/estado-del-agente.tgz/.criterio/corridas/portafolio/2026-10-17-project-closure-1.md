# Corrida · 2026-10-17-project-closure-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:project-closure PRY-203

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-203

**Inicio:** 2026-10-17T20:47:03 · **Fin:** 2026-10-17T20:47:55 · **Duración:** 52 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `project-closure` | 13 | — | 37 | 52 | Cierre de PRY-203 no emitido como cumplimiento: sin declaración de cierre, criterio de éxito indeterminable, 3 hitos cerrados sin evidencia, avance 57% vs plan 100%, ejecutado > comprometido sin explicación, 2 asuntos RAID sin dueño. No se supo: fecha real de cierre, estado de producción, presupuesto final, proveedor. |

Por señal (`project-closure`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

**PRY-203 (Aportes sociales en línea) no se puede cerrar contra lo pactado.** Ningún documento dice que terminó, así que el cierre que dejé es un borrador de lo que la evidencia permite, no un acta de cumplimiento.

Sale del acta de constitución, el cronograma v1 y el informe de avance del 2026-09-23. Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

- **Criterio de éxito:** el acta dice «en producción y medido». No hay evidencia de que se haya cumplido, y el informe habla de un piloto futuro.
- **Hitos:** los 3 hitos del cronograma figuran como cerrados, pero ninguno tiene evidencia (102 a 254 días desde sus fechas). El plan sustenta 100 % de avance y el informe declara 57 %, una brecha de 43 puntos que los documentos no explican.
- **Estado y silencio:** el informe declara el proyecto en verde, y la evidencia no lo respalda. Lleva 24 días sin documentos nuevos (el umbral es 15).
- **Fecha:** la fecha de cierre pactada (2026-07-07) no se movió (0 replanificaciones) y va 102 días vencida. No hay fecha real de cierre, así que no se puede calcular la desviación final.
- **Presupuesto:** la proyección declarada es 7.116.748.864 COP, un 4,7 % sobre los 6.800.000.000 aprobados. Lo ejecutado (3.031.029.425) supera lo comprometido (2.123.715.582), y el informe no lo explica. No hay presupuesto final ejecutado.
- **RAID:** quedan dos asuntos abiertos sin responsable: el riesgo de que el proveedor no confirmó la fecha de la última entrega, y el ajuste al reglamento que pidió el Consejo de Administración. Por eso no están cerrados.
- **Lecciones:** solo una se puede sustentar con los documentos (hitos «cerrados» sin acta ni certificado, con un avance declarado de 57 %).
- **Archivo:** no ofrecí mover la carpeta a `archivo/` ni congelar la ficha. Sin declaración de cierre y con asuntos sin dueño, el proyecto sigue en el barrido diario.

Los datos que faltan están listados en la sección «Sin dato» de la salida. La corrida quedó registrada con id `2026-10-17-project-closure-1`.

Archivos:
- `estado/corridas/salida-project-closure.md`
