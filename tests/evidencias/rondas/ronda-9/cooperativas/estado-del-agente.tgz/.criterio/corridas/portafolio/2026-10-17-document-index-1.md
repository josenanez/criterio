# Corrida · 2026-10-17-document-index-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:document-index (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:37:39 · **Fin:** 2026-10-17T20:38:06 · **Duración:** 27 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `document-index` | 13 | — | 15 | 52 | 67 documentos sin cambio, 0 por releer; 15 citas de PRY-209 no resuelven aunque los archivos existen (hipótesis: ruta relativa al proyecto, no verificada) |

Por señal (`document-index`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

## Carpeta al 2026-10-17

El índice no encontró nada que releer. Hay 67 documentos y los 67 están sin cambio. No hay nuevos, ni con contenido cambiado, ni solo reguardados, ni renombrados, ni borrados. No se ofrece `/portfolio-scan`.

Los términos ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17), así que no hubo que registrarlos de nuevo.

**Citas que dejaron de resolver: 15, todas de PRY-209.**
- 12 apuntan a `00-gobierno/2026-06-20-acta-constitucion.md`. Son el código, el nombre, el área, el producto, el patrocinador, el gerente y el comité, además de la fecha de inicio, el resumen del alcance, la primera exclusión y el presupuesto aprobado.
- 1 apunta a `10-plan/2026-06-20-cronograma-v1.csv` (fecha de fin).
- 3 apuntan a `20-seguimiento/2026-10-09-informe-avance.md` (comprometido, ejecutado y proyección).

Los tres documentos citados existen en la carpeta de PRY-209. Mi explicación más probable es que la ficha de PRY-209 cita la ruta relativa al proyecto y el índice la busca con otra forma. No abrí la ficha para comprobarlo, así que es una hipótesis. Mientras tanto, esos 15 datos no tienen sustento verificable para el índice.

No ofrezco corregir citas por renombrado, porque no hubo renombrados. Lo pendiente es revisar cómo PRY-209 escribe sus citas.

La corrida quedó registrada como `2026-10-17-document-index-1`, con el texto de arriba como salida. El registro de la corrida muestra 52 hallazgos en 13 proyectos, y no los revisé. Sus tiempos están medidos en segundos, pero no su cuenta de documentos.
