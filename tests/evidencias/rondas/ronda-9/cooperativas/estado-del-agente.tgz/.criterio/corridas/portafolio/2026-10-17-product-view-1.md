# Corrida · 2026-10-17-product-view-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:product-view pagos QR

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:50:13 · **Fin:** 2026-10-17T20:50:52 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-view` | 13 | — | 24 | 52 | Producto con un solo proyecto (PRY-206), sin señales abiertas; sin sección propia. Señaló fecha 2026-06-26 anterior al corte sin replanificación registrada, 0 fuentes de evidencia en la ficha, y 5 proyectos sin producto. No sé si el proyecto sigue vigente ni el área dueña de los 5 sin producto. |

Por señal (`product-view`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

**Productos al 2026-10-17 — pagos QR**

Los términos ya estaban vigentes (José Francisco Ñáñez, 2026-10-17, v0.4.0), así que no los registré otra vez. Las cifras salen del cálculo de hoy sobre las fichas de `estado/`.

pagos QR tiene un solo proyecto, PRY-206 Pagos con QR. La vista por producto no suma nada ahí, así que no armé sección propia.

- **Alertas:** ninguna. No hay hitos vencidos, compromisos vencidos ni desviación en tiempo o costo. Lleva 3 días en silencio.
- **Dependencias internas:** ninguna. Con un solo proyecto no hay cruce posible.
- **Fecha del producto:** 2026-06-26, la de PRY-206. Es anterior al corte, y el informe del 2026-10-14 declara 58 % de avance en amarillo. El cálculo no lo marca y la ficha no registra replanificación. No sé si la fecha está realmente vencida o falta registrar un cambio; eso hay que preguntárselo al gerente.
- **Dinero:** la ficha trae las cuatro cifras.

| Concepto | Monto (COP) | Porcentaje |
|---|---|---|
| Aprobado | 4.200.000.000 | |
| Comprometido | 1.553.761.322 | 37,0 % |
| Ejecutado | 1.004.189.836 | 23,9 % |
| Proyección | 4.057.601.292 | 3,4 % por debajo de lo aprobado |

- **Evidencia:** de los 15 datos de la ficha con fuente, ninguno es evidencia. 3 son declaración y 12 no están marcados.
- **Campos faltantes y antiguos:** faltan la autoridad y la fase. 12 campos tienen 12 meses de antigüedad, con fuente del 2025-10-03.
- **Proveedores:** la ficha no registra ninguno.
- **Proyectos sin producto declarado:** son 5. Son PRY-202, 205, 208, 209 y 210, y nadie puede responder por el conjunto al que sirven. No leí su área dueña, porque el cálculo no la da y esta consulta era solo sobre pagos QR.

Dejé el texto en `estado/corridas/salida-product-view.md` y registré la corrida como `2026-10-17-product-view-1`. Duró 24 segundos y el cálculo cubrió 13 proyectos. Por ser una prueba sin interfaz, no ofrecí llevar nada al comité de producto: no hay dependencias internas que llevar.
