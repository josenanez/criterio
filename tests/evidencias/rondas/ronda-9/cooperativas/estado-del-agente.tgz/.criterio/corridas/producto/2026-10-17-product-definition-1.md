# Corrida · 2026-10-17-product-definition-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-definition (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:18:03 · **Fin:** 2026-10-17T20:18:43 · **Duración:** 41 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-definition` | 16 | — | 26 | 25 | La definición no tiene criterio de éxito ni propuesta; la cifra de volumen no tiene serie y la única evidencia de demanda es una entrevista de enero |

Por señal (`product-definition`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 6, `requirement_undecided` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1

## Lo que el agente mostró

La definición de Auxilios de solidaridad (PRD-307) no se puede cerrar. No tiene criterio de éxito ni dice qué se propone. La evidencia no contradice nada, pero tampoco hay con qué contrastar la cifra de volumen.

**Términos:** ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17 (v1.1), así que no los registré de nuevo.

**Lo que encontré:**
- **Contradicciones:** ninguna.
- **Cifras sin serie:**
  - El volumen mensual de 68.516 no tiene ninguna serie medida con la que compararlo.
  - El retorno a 24 meses no trae cifra ni base.
- **No está dicho en ninguna parte:**
  - La propuesta (la sección solo dice «Propuesta principal»).
  - El criterio de éxito.
  - El origen de la cifra de volumen.
  - El tamaño del segmento.
  - El país.
  - Qué datos recoge y qué dinero paga.
  - Qué proyecto lo construye.
- **Supuesto:** «El reglamento vigente lo permite» figura como verificado el 2026-08-22. Pero el documento técnico del proveedor que lo sostiene no está en la carpeta, y tampoco cita el reglamento.
- **Evidencia de demanda:** una sola entrevista del 2026-01-15 («Lo necesito y hoy no lo tengo»). Es débil, anterior a la definición y de ~9 meses, bajo el umbral de 12.
- **Normativo:** nombré lo que toca (pagos, datos personales, reglamento, retención). No cité ninguna norma porque la definición no dice el país, así que todo queda como «no tengo la norma a la vista» o «sin resolver». Esto va a revisión jurídica.

No ofrecí `/product-charter`, porque la definición no está cerrada. Tampoco ofrecí convertir supuestos en riesgos, porque no hay ninguno pendiente de verificar.

La salida completa quedó en `estado-producto/PRD-307/corridas/salida-product-definition.md`. La corrida quedó registrada como `2026-10-17-product-definition-1`.

El registro de la corrida cuenta 25 hallazgos, pero son los de los requerimientos (REQ-47xx) y no los de la definición. El cálculo solo trajo `success` como campo desconocido.
