# Corrida · 2026-10-17-product-charter-1

**Agente:** Alba (producto) · **Comando:** `/criterio-product:product-charter REQ-4700

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** REQ-4700

**Inicio:** 2026-10-17T20:20:47 · **Fin:** 2026-10-17T20:21:36 · **Duración:** 49 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `product-charter` | 16 | — | 35 | 25 | Borrador de acta para REQ-4700, sin firmar y sin ficha. Dijo que no sabe: criterio de éxito medible, necesidad, propuesta, patrocinador, gerente y autoridad del proyecto, y el documento del proveedor que sustenta el supuesto del reglamento. |

Por señal (`product-charter`): `requirement_untraced` 13, `requirement_accepted_without_evidence` 6, `requirement_undecided` 3, `requirement_without_acceptance` 2, `requirement_without_owner` 1

## Lo que el agente mostró

Redacté el borrador del acta de constitución del REQ-4700 (producto PRD-307). Está sin firmar y no creé la ficha del proyecto. Los términos ya estaban aceptados por José Francisco Ñáñez el 2026-10-17, así que no hubo que pedirlos otra vez.

**El requerimiento no tiene con qué.** Seguí adelante y marqué cada falta como vacío, como sugería la plantilla:
- **Criterio de éxito:** el requerimiento dice solo «se verifica en producción», sin medida ni umbral. La definición del producto tampoco declara criterio de éxito.
- **Demanda:** hay una sola entrevista anónima del 2026-01-15, que no nombra el requerimiento.
- **Necesidad y propuesta:** el campo de necesidad del requerimiento está vacío, y la sección de propuesta de la definición solo dice «Propuesta principal».
- **Gobierno:** no hay patrocinador ni gerente del proyecto. La autoridad del gerente tampoco está dicha. Solo consta el Comité de producto.
- **Supuesto del reglamento:** se da por verificado, pero la verificación cita un documento técnico del proveedor que no está en la carpeta.

**Alcance:** entra solo el REQ-4700. Los otros 15 requerimientos quedan fuera porque no se pidieron en esta acta. La tabla aclara que no se descartaron por mérito.

**Lo que sigue:** firma el acta quien tenga la autoridad del Comité de producto, que el acta no nombra. Después se crea la ficha, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`.

La corrida quedó registrada en `estado-producto/PRD-307/corridas/2026-10-17-product-charter-1.md`. La salida completa está en `estado-producto/PRD-307/corridas/salida-product-charter.md`.
