# Corrida · 2026-10-17-steering-pack-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:steering-pack (Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)`

**Inicio:** 2026-10-17T20:48:00 · **Fin:** 2026-10-17T20:50:07 · **Duración:** 128 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `steering-pack` | 13 | — | 112 | 52 | Paquete de comité 2026-10-24: 7 decisiones, 3 escalamientos. No hay acta de comité anterior, así que no se cerró el ciclo. Trabajé sobre fichas y compute; no releí los originales salvo CC-01 de PRY-207 y un acta de PRY-202. Sin dato: autoridad de aprobación en los 13 proyectos, quién decide CC-01, y si lo facturado en PRY-201 ya se pagó. |

Por señal (`steering-pack`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Preparé el paquete de comité para el 2026-10-24: 7 decisiones, 3 escalamientos y 8 proyectos con hallazgos (52 señales), y la corrida quedó registrada. El texto completo está en `estado/corridas/salida-steering-pack.md`.

Los términos v1.1 ya estaban vigentes y aceptados por José Francisco Ñáñez el 2026-10-17, así que no los registré otra vez. Trabajé sobre las 13 fichas (todas del 2026-10-17) y la salida de `compute`. Solo abrí por mi cuenta la solicitud de cambio de PRY-207 y un acta de PRY-202.

**Decisiones**
1. **Quién aprueba qué.** Las 13 fichas no traen quién tiene la facultad de aprobar cambios y escalamientos. Es el primer punto, porque los puntos 2 a 6 dependen de él.
2. **PRY-207, solicitud de cambio CC-01.**
   - Ampliación de alcance con +110 días y +220.000.000 COP, pendiente desde el 2026-10-05.
   - La solicitud no dice qué se agrega ni quién la decide.
   - Recomiendo diferirla hasta que lo diga.
3. **PRY-202, sobrecosto.** La proyección es 24,8 % mayor que lo aprobado y el proyecto se declara verde. Recomiendo exigir un plan de recuperación antes de tocar el presupuesto.
4. **PRY-210, sobrecosto.** La proyección es 18,8 % mayor que lo aprobado y el proyecto se declara verde. Termina el 2026-11-14, así que recomiendo el mismo plan con plazo de una semana.
5. **PRY-201, factura.** Se facturaron 117.336.767 COP por encima de lo aceptado en actas. Recomiendo retener esa diferencia, o pedir nota crédito si ya se pagó.
6. **Fechas de fin vencidas.** PRY-203, 205, 206 y 208 tienen la fecha de fin vencida, avance declarado entre 31 % y 74 %, y ninguna solicitud de cambio. Esta lectura es mía: `compute` no la marca como señal. Recomiendo exigir replanificación formal.
7. **Hitos sin acta.** Hay 19 hitos declarados cumplidos sin acta de recibo, repartidos en 7 proyectos. Recomiendo la regla de que sin acta el hito vuelve a pendiente.

**Escalamientos**
- **PRY-209:** compromisos vencidos, sin fecha o reprogramados varias veces; uno, seis veces.
- **PRY-208:** entregable del proveedor con 133 días de atraso y un licenciamiento aceptado sin acta.
- **PRY-202:** un compromiso vencido hace 7 días.

**Lo que no sé**
- No hay acta de un comité anterior, así que no pude cerrar el ciclo.
- No sé si lo facturado en PRY-201 ya se pagó.
- Ninguna ficha tiene campos marcados como evidencia; todo viene de declaraciones.
- En 5 proyectos el ejecutado supera al comprometido. Lo dejé sin resolver en el anexo.

No registré decisiones en las fichas, porque el comité todavía no sesiona.
