# Corrida · 2026-10-17-budget-tracking-1

**Agente:** Vera (portafolio) · **Comando:** `/criterio-portfolio:budget-tracking PRY-210

(Sesión de prueba sin interfaz: nadie va a responder preguntas. Términos: José Francisco Ñáñez acepta los términos vigentes de esta versión para esta prueba, fecha 2026-10-17; cuando el agente los muestre, regístralo con ese nombre. En cada otra pregunta toma la respuesta sugerida, dila en una línea y sigue. Si un comando pide algo que no existe, dilo y termina; no lo inventes.)` · **Caso:** PRY-210

**Inicio:** 2026-10-17T20:41:11 · **Fin:** 2026-10-17T20:41:50 · **Duración:** 39 s

**Subagentes:** ninguno · la configuración permite 1 a la vez

## Cifras medidas por la corrida

| Qué | Casos | Documentos | Segundos | Hallazgos | Nota |
|---|---:|---:|---:|---:|---|
| `budget-tracking` | 13 | — | 24 | 52 | Presupuesto PRY-210: proyección +18,8% sobre aprobado; ejecutado > comprometido (inconsistente); cifras de gasto solo declaradas, sin evidencia. No sé el desglose de la proyección. |

Por señal (`budget-tracking`): `milestone_met_without_evidence` 19, `commitment_overdue` 7, `declared_vs_evidence` 6, `progress_vs_plan` 5, `commitment_undated` 5, `commitment_rescheduled` 3, `variance_cost` 2, `vendor_invoiced_over_accepted` 1, `silent` 1, `variance_time` 1, `vendor_deliverable_late` 1, `vendor_accepted_without_evidence` 1

## Lo que el agente mostró

Terminé el informe de presupuesto de PRY-210 y registré la corrida. Esto es lo que muestra.

**Presupuesto de PRY-210 (Corresponsales rurales) al 2026-10-17, en COP:**

| | Monto | % del aprobado | Fuente |
|---|---|---|---|
| Aprobado | 9.500.000.000 | 100 % | Acta de constitución, 2025-08-19 |
| Comprometido | 3.046.464.807 | 32,1 % | Declaración del gerente, 2026-10-09 |
| Ejecutado | 4.148.296.231 | 43,7 % | Declaración del gerente, 2026-10-09 |
| Proyección al cierre | 11.281.920.391 | 118,8 % | Declaración del gerente, 2026-10-09 |

- **Proyección:** excede el aprobado en 1.781.920.391 COP (+18,8 %), por encima del umbral de 10 %. No hay replanificaciones de presupuesto ni solicitudes de cambio registradas.
- **Disponible real:** 6.453.535.193 COP (aprobado menos comprometido).
- **Cifras que no cuadran:** el ejecutado es mayor que el comprometido, lo cual no debería pasar. Si se descuenta el ejecutado, el disponible baja a 5.351.703.769 COP. No sé cuál de las dos cifras está mal.
- **Avance:** el gerente declara 59 %, pero el plan sustenta entre 75 % y 100 % (16 puntos por detrás). Los tres hitos declarados como cumplidos no tienen evidencia.
- **Estado declarado:** el informe del 2026-10-09 dice verde, y esas tres señales lo contradicen.
- **Solo declaraciones:** comprometido, ejecutado y proyección son declaraciones del gerente, sin evidencia. El aprobado viene de un acta de hace 14 meses.
- **Lo que no sé:** de dónde sale la proyección, porque el informe no la desglosa. No hay proveedores en la ficha, así que no hay detalle por proveedor.

Los términos ya estaban vigentes a nombre de José Francisco Ñáñez (2026-10-17), así que no hubo que registrarlos de nuevo. No preparé la solicitud de cambio de presupuesto; queda ofrecida con `/change-control`.

Archivos en `/home/claude/banco/ronda-9/cooperativas/espacio/estado/corridas/`:
- `salida-budget-tracking.md`
- `2026-10-17-budget-tracking-1`: id con que quedó registrada la corrida; no confirmé el nombre del archivo que `corrida` crea.

La corrida cuenta 13 proyectos porque `compute` recorre todo el portafolio. El informe es solo de PRY-210.
