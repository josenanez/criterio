<!-- origen: PRY-207-microcrédito-rural/00-gobierno/2026-05-22-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Microcrédito rural

**Código:** PRY-207
**Área dueña:** Canales digitales
**Patrocinador:** Jorge Medina
**Gerente de proyecto:** Camilo Beltrán
**Comité:** Consejo de Administración
**Producto asociado:** microcrédito
**Fecha de aprobación:** 2026-05-22

## Objetivo del negocio

Entregar microcrédito rural para Canales digitales.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**4.200.000.000 COP**, aprobado por Consejo de Administración el 2026-05-22.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-06-01 |
| Cierre | 2027-05-16 |

## Criterio de éxito

Microcrédito rural en producción y medido.

## Dependencias declaradas

- Ninguna declarada
