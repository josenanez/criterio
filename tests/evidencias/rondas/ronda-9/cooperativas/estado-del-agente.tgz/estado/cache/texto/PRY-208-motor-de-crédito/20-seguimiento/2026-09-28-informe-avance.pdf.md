<!-- origen: PRY-208-motor-de-crédito/20-seguimiento/2026-09-28-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Motor de crédito
Código: PRY-208
Fecha de corte: 2026-09-28
Gerente: Andrés Lozano

Estado declarado
Verde
Avance reportado: 31%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 5.624.497.293
Ejecutado 2.042.116.829
Proyección al cierre 9.766.333.561

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
