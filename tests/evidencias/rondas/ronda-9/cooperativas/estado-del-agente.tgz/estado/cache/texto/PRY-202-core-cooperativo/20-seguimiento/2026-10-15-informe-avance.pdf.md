<!-- origen: PRY-202-core-cooperativo/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core cooperativo
Código: PRY-202
Fecha de corte: 2026-10-15
Gerente: Mauricio Pérez

Estado declarado
Verde
Avance reportado: 55%

Lo que pasó en el periodo
- Se recibió el concepto pendiente del ente supervisor
- Se reprogramó la salida por el cierre contable de fin de mes
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 447.707.288
Ejecutado 724.509.244
Proyección al cierre 1.498.158.438

Riesgos abiertos
- El proveedor no ha confirmado la fecha de la última entrega
