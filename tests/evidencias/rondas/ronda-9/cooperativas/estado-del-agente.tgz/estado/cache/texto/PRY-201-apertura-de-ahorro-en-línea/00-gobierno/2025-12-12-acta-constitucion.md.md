<!-- origen: PRY-201-apertura-de-ahorro-en-línea/00-gobierno/2025-12-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Apertura de ahorro en línea

**Código:** PRY-201
**Área dueña:** Tecnología
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Riesgos
**Producto asociado:** ahorro a la vista
**Fecha de aprobación:** 2025-12-12

## Objetivo del negocio

Entregar apertura de ahorro en línea para Tecnología.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Riesgos el 2025-12-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-22 |
| Cierre | 2027-01-20 |

## Criterio de éxito

Apertura de ahorro en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
