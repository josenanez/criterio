<!-- origen: PRY-202-core-cooperativo/00-gobierno/2025-11-17-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core cooperativo

Código: PRY-202

Área dueña: Servicio al asociado

Patrocinador: Laura Vélez

Gerente de proyecto: Mauricio Pérez

Comité: Comité de Educación

Producto asociado: No aplica

Fecha de aprobación: 2025-11-17

Objetivo del negocio

Entregar core cooperativo para Servicio al asociado.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Educación el 2025-11-17.

Fechas comprometidas

Fecha

Inicio

2025-11-27

Cierre

2026-12-15

Criterio de éxito

Core cooperativo en producción y medido.

Dependencias declaradas

• Ninguna declarada
