<!-- origen: PRY-204-tarjeta-débito-para-asociados/10-plan/2025-12-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-24 | 2026-03-24 | cerrado
Ambiente de pruebas certificado | 2026-06-07 | 2026-06-07 | cerrado
Integración con el core cooperativo | 2026-08-21 | 2026-08-21 | cerrado
Piloto con asociados | 2026-11-04 | 2026-11-04 | en curso
