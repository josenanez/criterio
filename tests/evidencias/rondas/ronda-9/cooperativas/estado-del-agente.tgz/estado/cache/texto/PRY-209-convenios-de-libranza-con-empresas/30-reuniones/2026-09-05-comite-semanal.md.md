<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-09-05-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-09-05
**Asistentes:** Camilo Beltrán, Diana Molina, Jorge Medina, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | por definir |
| Jorge Medina | Cerrar la prueba 2 | 2026-09-18 |
| Jorge Medina | Revisar el anexo 3 | 2026-10-02 |
| Sandra Gil | Validar el ambiente 4 | 2026-09-19 |
