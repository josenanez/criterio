<!-- origen: PRY-206-pagos-con-qr/00-gobierno/2025-10-03-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Pagos con QR

Código: PRY-206

Área dueña: Canales digitales

Patrocinador: Camilo Beltrán

Gerente de proyecto: Camilo Beltrán

Comité: Comité de Crédito

Producto asociado: pagos QR

Fecha de aprobación: 2025-10-03

Objetivo del negocio

Entregar pagos con qr para Canales digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

4.200.000.000 COP, aprobado por Comité de Crédito el 2025-10-03.

Fechas comprometidas

Fecha

Inicio

2025-10-13

Cierre

2026-06-26

Criterio de éxito

Pagos con QR en producción y medido.

Dependencias declaradas

• Ninguna declarada
