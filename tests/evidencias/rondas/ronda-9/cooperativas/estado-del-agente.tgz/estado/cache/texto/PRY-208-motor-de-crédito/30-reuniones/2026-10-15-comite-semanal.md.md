<!-- origen: PRY-208-motor-de-crédito/30-reuniones/2026-10-15-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Consejo de Administración · Motor de crédito

**Fecha:** 2026-10-15
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 13 | 2026-11-07 |
| Ricardo Salas | Entregar el punto 32 | 2026-10-15 |
