<!-- origen: PRY-202-core-cooperativo/10-plan/2025-11-17-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-03-02 | 2026-03-02 | cerrado
Ambiente de pruebas certificado | 2026-06-06 | 2026-06-06 | cerrado
Integración con el core cooperativo | 2026-09-10 | 2026-09-10 | cerrado
Piloto con asociados | 2026-12-15 | 2026-12-15 | en curso
