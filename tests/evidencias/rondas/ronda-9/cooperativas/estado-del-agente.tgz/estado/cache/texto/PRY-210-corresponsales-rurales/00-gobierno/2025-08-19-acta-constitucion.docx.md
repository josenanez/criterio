<!-- origen: PRY-210-corresponsales-rurales/00-gobierno/2025-08-19-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Corresponsales rurales

Código: PRY-210

Área dueña: Cartera y cobranza

Patrocinador: Jorge Medina

Gerente de proyecto: Sandra Gil

Comité: Comité de Educación

Producto asociado: No aplica

Fecha de aprobación: 2025-08-19

Objetivo del negocio

Entregar corresponsales rurales para Cartera y cobranza.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Educación el 2025-08-19.

Fechas comprometidas

Fecha

Inicio

2025-08-29

Cierre

2026-11-14

Criterio de éxito

Corresponsales rurales en producción y medido.

Dependencias declaradas

• Ninguna declarada
