<!-- origen: PRY-209-convenios-de-libranza-con-empresas/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "identity": {
 "code": {
 "value": "PRY-209",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "name": {
 "value": "Convenios de libranza con empresas",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Bienestar social",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "product": {
 "value": null,
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "not_found",
 "note": "El acta dice «No aplica»."
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Diana Molina",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "manager": {
 "value": "Camilo Beltrán",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Tecnología",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "amarillo",
 "progress_pct": 24,
 "as_of": "2026-10-09",
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2026-06-30",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "end_date": {
 "value": "2027-04-17",
 "source": "10-plan/2026-06-20-cronograma-v1.csv",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-06-20",
 "start_date": "2026-06-30",
 "end_date": "2027-04-17",
 "reason": "Aprobación inicial del Comité de Tecnología",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2026-09-10",
 "current_date": "2026-09-10",
 "state": "met",
 "evidence": "20-seguimiento/2026-10-04-acta-recibo-diseño-funcional-aprobado.pdf",
 "source": "10-plan/2026-06-20-cronograma-v1.csv"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2026-11-22",
 "current_date": "2026-11-22",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-20-cronograma-v1.csv"
 },
 {
 "name": "Integración con el core cooperativo",
 "baseline_date": "2027-02-03",
 "current_date": "2027-02-03",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-20-cronograma-v1.csv"
 },
 {
 "name": "Piloto con asociados",
 "baseline_date": "2027-04-17",
 "current_date": "2027-04-17",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-06-20-cronograma-v1.csv"
 }
 ],
 "scope_summary": {
 "value": "Tres componentes sin nombrar («Componente 1», «Componente 2», «Componente 3»)",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "exclusions": [
 {
 "value": "«Lo que otro proyecto cubre», sin nombrar el proyecto",
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 }
 ]
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 9500000000,
 "source": "00-gobierno/2026-06-20-acta-constitucion.md",
 "source_date": "2026-06-20",
 "state": "found"
 },
 "committed": {
 "value": 6033140746,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found",
 "source_kind": "declaration"
 },
 "executed": {
 "value": 2806355979,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found",
 "source_kind": "declaration"
 },
 "projection": {
 "value": 9620521967,
 "source": "20-seguimiento/2026-10-09-informe-avance.md",
 "source_date": "2026-10-09",
 "state": "found",
 "source_kind": "declaration"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Aprobación del reglamento por el Consejo de Administración",
 "owner": null,
 "due_date": null,
 "source": "20-seguimiento/2026-10-09-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en la reunión, nadie lo registró como riesgo)",
 "owner": null,
 "due_date": null,
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Diana Molina",
 "what": "Enviar el documento 1",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-02",
 "due_date": "2026-11-17",
 "reschedules": [
 {
 "due_date": "2026-10-12",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-17",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Cerrar la prueba 2",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-18",
 "due_date": "2026-12-06",
 "reschedules": [
 {
 "due_date": "2026-10-01",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-13",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-22",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-06",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Revisar el anexo 3",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-02",
 "due_date": "2026-11-27",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-27",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Sandra Gil",
 "what": "Validar el ambiente 4",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "original_due_date": "2026-09-19",
 "due_date": "2026-09-26",
 "reschedules": [
 {
 "due_date": "2026-09-26",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-4.md"
 },
 {
 "who": "Andrés Lozano",
 "what": "Aprobar el diseño 5",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-09-20",
 "due_date": "2026-10-23",
 "reschedules": [
 {
 "due_date": "2026-10-23",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Laura Vélez",
 "what": "Actualizar la matriz 6",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "original_due_date": "2026-09-30",
 "due_date": "2026-10-10",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Confirmar la fecha 7",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "original_due_date": "2026-09-26",
 "due_date": "2026-10-16",
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-10-acta-recibo-7.md"
 },
 {
 "who": "Camilo Beltrán",
 "what": "Entregar el punto 8",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "original_due_date": "2026-09-23",
 "due_date": "2026-10-01",
 "reschedules": [
 {
 "due_date": "2026-10-01",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "note": "El 2026-09-26 dejó de aparecer en la lista y Camilo Beltrán dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-09-26-comite-semanal.md)."
 },
 {
 "who": "Mauricio Pérez",
 "what": "Enviar el documento 9",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "reschedules": [],
 "note": "El 2026-10-03 Mauricio Pérez dijo que ya lo entregó; no se presentó acta (30-reuniones/2026-10-03-comite-semanal.md). Dejó de aparecer en la lista desde esa reunión."
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Cerrar la prueba 10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "original_due_date": "2026-09-27",
 "due_date": "2026-10-16",
 "reschedules": [
 {
 "due_date": "2026-10-16",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Revisar el anexo 11",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-16",
 "due_date": "2026-10-29",
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Óscar Ramírez",
 "what": "Validar el ambiente 12",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "original_due_date": "2026-10-14",
 "due_date": "2026-10-14",
 "reschedules": [],
 "note": "Las notas del 2026-10-17 traen «revisión con el proveedor, queda para el 2026-10-27» de Óscar Ramírez; no dicen que sea este compromiso, por eso va aparte."
 },
 {
 "who": "Felipe Arango",
 "what": "Aprobar el diseño 13",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-15",
 "due_date": "2026-10-31",
 "reschedules": [
 {
 "due_date": "2026-10-31",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Actualizar la matriz 14",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "original_due_date": "2026-10-12",
 "due_date": "2026-10-12",
 "reschedules": []
 },
 {
 "who": "Javier Hoyos",
 "what": "Confirmar la fecha 15",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-17",
 "due_date": "2026-10-29",
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Rubén Cárdenas",
 "what": "Entregar el punto 16",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-05",
 "due_date": "2026-10-29",
 "reschedules": [
 {
 "due_date": "2026-10-29",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Javier Hoyos",
 "what": "Enviar el documento 17",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Cerrar la prueba 18",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-19",
 "due_date": "2026-10-19",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Revisar el anexo 19",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-30",
 "due_date": "2026-11-15",
 "reschedules": [
 {
 "due_date": "2026-11-15",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Paula Céspedes",
 "what": "Validar el ambiente 20",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-26",
 "due_date": "2026-11-10",
 "reschedules": [
 {
 "due_date": "2026-11-10",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Natalia Ospina",
 "what": "Aprobar el diseño 21",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-11-01",
 "due_date": "2026-11-01",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Actualizar la matriz 22",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "reschedules": []
 },
 {
 "who": "Diana Molina",
 "what": "Confirmar la fecha 23",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-11-04",
 "due_date": "2026-11-04",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Entregar el punto 24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "original_due_date": "2026-10-24",
 "due_date": "2026-10-24",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "reschedules": [],
 "note": "Dicho como «la otra semana»; no es una fecha."
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "original_due_date": "2026-10-27",
 "due_date": "2026-10-27",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "documents_seen": [],
 "fields_not_found": [
 "identity.product",
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
