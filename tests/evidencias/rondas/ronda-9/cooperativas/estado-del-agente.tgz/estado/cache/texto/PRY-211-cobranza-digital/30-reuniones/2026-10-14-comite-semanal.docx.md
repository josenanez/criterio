<!-- origen: PRY-211-cobranza-digital/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Riesgos · Cobranza digital

Fecha: 2026-10-14

Asistentes: Jorge Medina, Gustavo Neira

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Gustavo Neira

Entregar el punto 39

2026-11-10
