<!-- origen: PRY-207-microcrédito-rural/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Microcrédito rural
Código: PRY-207
Fecha de corte: 2026-10-12
Gerente: Camilo Beltrán

Estado declarado
Rojo
Avance reportado: 83%

Lo que pasó en el periodo
- Se reprogramó la salida por el cierre contable de fin de mes

Presupuesto
COP
Aprobado 4.200.000.000
Comprometido 3.396.300.890
Ejecutado 1.480.821.783
Proyección al cierre 3.883.577.548

Riesgos abiertos
- Cambio normativo del supervisor que puede mover el alcance
