<!-- origen: PRY-201-apertura-de-ahorro-en-línea/30-reuniones/2026-10-04-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Riesgos · Apertura de ahorro en línea

Fecha: 2026-10-04

Asistentes: Mauricio Pérez, Felipe Arango

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Andrés Lozano

Entregar el punto 22

2026-11-01
