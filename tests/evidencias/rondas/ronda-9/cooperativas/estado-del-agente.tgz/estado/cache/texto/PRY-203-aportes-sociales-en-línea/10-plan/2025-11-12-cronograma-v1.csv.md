<!-- origen: PRY-203-aportes-sociales-en-línea/10-plan/2025-11-12-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-05,2026-02-05,cerrado
Ambiente de pruebas certificado,2026-04-22,2026-04-22,cerrado
Integración con el core cooperativo,2026-07-07,2026-07-07,cerrado
