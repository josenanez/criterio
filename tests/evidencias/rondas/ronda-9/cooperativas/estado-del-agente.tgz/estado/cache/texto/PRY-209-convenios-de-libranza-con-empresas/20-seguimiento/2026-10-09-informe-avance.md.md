<!-- origen: PRY-209-convenios-de-libranza-con-empresas/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Convenios de libranza con empresas

**Código:** PRY-209
**Fecha de corte:** 2026-10-09
**Gerente:** Camilo Beltrán

## Estado declarado

**Amarillo**

Avance reportado: **24%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.033.140.746 |
| Ejecutado | 2.806.355.979 |
| Proyección al cierre | 9.620.521.967 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
