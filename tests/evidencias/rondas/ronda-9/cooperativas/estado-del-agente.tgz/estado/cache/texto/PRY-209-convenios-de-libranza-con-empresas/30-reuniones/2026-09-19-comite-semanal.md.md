<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-09-19-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-09-19
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Gustavo Neira, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-12 |
| Jorge Medina | Cerrar la prueba 2 | 2026-10-14 |
| Jorge Medina | Revisar el anexo 3 | 2026-10-23 |
| Sandra Gil | Validar el ambiente 4 | 2026-09-26 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-20 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-30 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-26 |
| Camilo Beltrán | Entregar el punto 8 | 2026-10-01 |
| Mauricio Pérez | Enviar el documento 9 | por definir |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-09-27 |
| Natalia Ospina | Revisar el anexo 11 | por definir |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 |
