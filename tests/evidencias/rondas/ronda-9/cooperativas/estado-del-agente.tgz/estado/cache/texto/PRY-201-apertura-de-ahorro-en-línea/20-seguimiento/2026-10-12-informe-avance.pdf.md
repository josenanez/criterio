<!-- origen: PRY-201-apertura-de-ahorro-en-línea/20-seguimiento/2026-10-12-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Apertura de ahorro en línea
Código: PRY-201
Fecha de corte: 2026-10-12
Gerente: Mauricio Pérez

Estado declarado
Amarillo
Avance reportado: 22%

Lo que pasó en el periodo
- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- El equipo perdió dos semanas por rotación de un desarrollador clave

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 1.445.061.642
Ejecutado 1.614.863.025
Proyección al cierre 3.089.208.729

Riesgos abiertos
- Aprobación del reglamento por el Consejo de Administración
