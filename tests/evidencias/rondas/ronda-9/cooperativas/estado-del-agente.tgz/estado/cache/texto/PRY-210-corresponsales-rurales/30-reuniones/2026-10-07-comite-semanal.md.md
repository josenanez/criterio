<!-- origen: PRY-210-corresponsales-rurales/30-reuniones/2026-10-07-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Educación · Corresponsales rurales

**Fecha:** 2026-10-07
**Asistentes:** Sandra Gil, Jorge Medina

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 28 | por definir |
