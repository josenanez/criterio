<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-03 |
| Jorge Medina | Cerrar la prueba 2 | 2026-11-13 |
| Jorge Medina | Revisar el anexo 3 | 2026-11-11 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-20 |
| Laura Vélez | Actualizar la matriz 6 | 2026-10-10 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-16 |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-16 |
| Natalia Ospina | Revisar el anexo 11 | 2026-10-29 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-31 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-12 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-17 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-05 |
| Javier Hoyos | Enviar el documento 17 | por definir |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Sandra Gil | Revisar el anexo 19 | 2026-10-30 |
| Paula Céspedes | Validar el ambiente 20 | 2026-10-26 |

## Lo que se dijo

- Mauricio Pérez dice que ya entregó «enviar el documento 9». No se presentó acta.
