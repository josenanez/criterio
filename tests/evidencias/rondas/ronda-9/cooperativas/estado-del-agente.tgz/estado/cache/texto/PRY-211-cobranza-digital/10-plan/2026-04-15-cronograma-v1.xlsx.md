<!-- origen: PRY-211-cobranza-digital/10-plan/2026-04-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-06-30 | 2026-06-30 | cerrado
Ambiente de pruebas certificado | 2026-09-05 | 2026-09-05 | cerrado
Integración con el core cooperativo | 2026-11-11 | 2026-11-11 | en curso
Piloto con asociados | 2027-01-16 | 2027-01-16 | en curso
