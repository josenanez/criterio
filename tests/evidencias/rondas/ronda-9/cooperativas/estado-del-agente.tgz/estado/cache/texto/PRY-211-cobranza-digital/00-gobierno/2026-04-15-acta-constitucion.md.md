<!-- origen: PRY-211-cobranza-digital/00-gobierno/2026-04-15-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Ahorro y aportes
**Patrocinador:** Gustavo Neira
**Gerente de proyecto:** Jorge Medina
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2026-04-15

## Objetivo del negocio

Entregar cobranza digital para Ahorro y aportes.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**2.400.000.000 COP**, aprobado por Comité de Riesgos el 2026-04-15.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-04-25 |
| Cierre | 2027-01-16 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
