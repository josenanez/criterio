<!-- origen: PRY-210-corresponsales-rurales/20-seguimiento/2026-10-09-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Corresponsales rurales

**Código:** PRY-210
**Fecha de corte:** 2026-10-09
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **59%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 3.046.464.807 |
| Ejecutado | 4.148.296.231 |
| Proyección al cierre | 11.281.920.391 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
