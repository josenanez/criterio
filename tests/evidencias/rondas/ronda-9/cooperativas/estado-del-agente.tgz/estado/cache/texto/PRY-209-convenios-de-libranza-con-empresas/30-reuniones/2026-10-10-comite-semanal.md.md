<!-- origen: PRY-209-convenios-de-libranza-con-empresas/30-reuniones/2026-10-10-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-10-10
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-11-17 |
| Jorge Medina | Cerrar la prueba 2 | 2026-11-22 |
| Jorge Medina | Revisar el anexo 3 | 2026-11-27 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-23 |
| Laura Vélez | Actualizar la matriz 6 | 2026-10-10 |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-16 |
| Natalia Ospina | Revisar el anexo 11 | 2026-10-29 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-31 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-12 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-29 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-29 |
| Javier Hoyos | Enviar el documento 17 | por definir |
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Sandra Gil | Revisar el anexo 19 | 2026-11-15 |
| Paula Céspedes | Validar el ambiente 20 | 2026-11-10 |
| Natalia Ospina | Aprobar el diseño 21 | 2026-11-01 |
| Andrés Lozano | Actualizar la matriz 22 | por definir |
| Diana Molina | Confirmar la fecha 23 | 2026-11-04 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |

## Cerrados en esta reunión

- Confirmar la fecha 7 (Gustavo Neira): recibido, acta de recibo del 2026-10-10.
