<!-- origen: PRY-201-apertura-de-ahorro-en-línea/10-plan/2025-12-12-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-03-10,2026-03-10,cerrado
Ambiente de pruebas certificado,2026-05-28,2026-05-28,cerrado
Integración con el core cooperativo,2026-08-15,2026-08-15,cerrado
Piloto con asociados,2026-11-02,2026-11-02,en curso
Salida a producción,2027-01-20,2027-01-20,en curso
