<!-- origen: PRY-203-aportes-sociales-en-línea/00-gobierno/2025-11-12-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Aportes sociales en línea

**Código:** PRY-203
**Área dueña:** Servicio al asociado
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Paula Céspedes
**Comité:** Comité de Educación
**Producto asociado:** aportes sociales
**Fecha de aprobación:** 2025-11-12

## Objetivo del negocio

Entregar aportes sociales en línea para Servicio al asociado.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Educación el 2025-11-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-22 |
| Cierre | 2026-07-07 |

## Criterio de éxito

Aportes sociales en línea en producción y medido.

## Dependencias declaradas

- Ninguna declarada
