<!-- origen: PRY-209-convenios-de-libranza-con-empresas/10-plan/2026-06-20-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-09-10,2026-09-10,cerrado
Ambiente de pruebas certificado,2026-11-22,2026-11-22,en curso
Integración con el core cooperativo,2027-02-03,2027-02-03,en curso
Piloto con asociados,2027-04-17,2027-04-17,en curso
