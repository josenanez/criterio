<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-05-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-05
Gerente: Jorge Medina

Estado declarado
Verde
Avance reportado: 78%

Lo que pasó en el periodo
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

Presupuesto
COP
Aprobado 2.400.000.000
Comprometido 1.356.733.976
Ejecutado 1.141.532.571
Proyección al cierre 2.313.853.574

Riesgos abiertos
- Dependencia del proveedor del core cooperativo
