<!-- origen: PRY-210-corresponsales-rurales/10-plan/2025-08-19-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2025-12-17,2025-12-17,cerrado
Ambiente de pruebas certificado,2026-04-07,2026-04-07,cerrado
Integración con el core cooperativo,2026-07-27,2026-07-27,cerrado
Piloto con asociados,2026-11-14,2026-11-14,en curso
