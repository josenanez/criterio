<!-- origen: PRY-209-convenios-de-libranza-con-empresas/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión convenios de libranza con empresas — 2026-10-17
estuvieron: Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez

- Jorge Medina dice que lo de «cerrar la prueba 2» no alcanzó, se compromete para el 06/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
