<!-- origen: PRY-208-motor-de-crédito/10-plan/2025-12-12-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-02-05,2026-02-05,cerrado
Ambiente de pruebas certificado,2026-03-22,2026-03-22,cerrado
Integración con el core cooperativo,2026-05-06,2026-05-06,cerrado
Piloto con asociados,2026-06-21,2026-06-21,cerrado
Salida a producción,2026-08-05,2026-08-05,cerrado
