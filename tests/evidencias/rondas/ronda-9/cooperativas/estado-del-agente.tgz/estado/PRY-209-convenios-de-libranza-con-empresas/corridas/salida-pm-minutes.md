# Acta — Convenios de libranza con empresas (PRY-209) · 2026-10-17
**Asistieron:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Paula Céspedes, Rubén Cárdenas, Sandra Gil, Óscar Ramírez (16) · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** ninguno identificable; las notas no traen agenda.

*Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo.*

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Jorge Medina | Cerrar la prueba 2 (nota 1: «lo de cerrar la prueba 2 no alcanzó, se compromete para el 06/12/2026») | 2026-12-06 | **Reprogramado 6 veces.** Original 2026-09-18; luego 10-01, 10-14, 11-03, 11-13, 11-22 y 12-06. |
| Óscar Ramírez | Revisión con el proveedor (nota 3: «revisión con el proveedor, queda para el 2026-10-27») | 2026-10-27 | Nuevo. Ver «Sin resolver»: puede ser o no el compromiso «Validar el ambiente 12», vencido desde el 10-14. |

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto (nota 2: «la otra semana»; eso no es una fecha, y no se convirtió en una) |

Pendientes sin fecha de reuniones anteriores, que esta reunión no resolvió: Mauricio Pérez («documento 9»), Javier Hoyos («documento 17»), Andrés Lozano («matriz 22»). Con el de Laura Vélez son **4 sin fecha**.

## Decisiones
Ninguna. Las notas no registran ninguna decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace frente a que el proveedor no llegue con el equipo completo | Se comentó, nadie lo tomó (nota 4) | No consta en las notas |

## Intenciones sin doliente
Ninguna en esta reunión.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» (nota 4) | No consta («se comentó») | Riesgo (dependencia de proveedor) | No. El único riesgo registrado es la aprobación del reglamento por el Consejo de Administración. Se agregó a la ficha sin dueño ni fecha. |

## Cerrado en esta reunión
Nada. Sin documento no se cierra.

## Lo que esta reunión contradice
Ningún campo. Patrocinador, gerente, comité y fecha de cierre no se tocaron.

## Sin resolver de la transcripción
- «Revisión con el proveedor, queda para el 2026-10-27» (Óscar Ramírez): las notas no dicen si es el compromiso «Validar el ambiente 12» (vencido el 2026-10-14) o uno distinto. Se registró aparte; si es el mismo, sería una reprogramación y el 12 dejaría de estar vencido.
- «Se comentó…» (nota 4): no dice quién lo comentó, y por eso no se le atribuye a nadie.
- «Próxima reunión en dos semanas» (nota 5): sin fecha. La configuración dice comité semanal, con el siguiente el 2026-10-31. Dos semanas desde hoy sería el 2026-10-31, así que coincide; si la cadencia semanal cambió, es un campo de configuración, no del expediente.

## Cifras de seguimiento tras el recálculo
Fichas sin `record_issues`. **5 vencidos** (Laura Vélez, Camilo Beltrán, Beatriz Cuéllar, Óscar Ramírez, Gustavo Neira), **4 sin fecha**, **3 reprogramados 3 o más veces** (Jorge Medina ×2, Diana Molina). Tres de los vencidos ya figuraban antes de esta reunión. El informe del 2026-10-09 declara amarillo y no da cuenta de los compromisos vencidos ni de los reprogramados.

## Después
`/pm-commitments` para el seguimiento completo. No hay campos de la ficha en conflicto con el expediente, pero la ficha cambió (riesgo nuevo, 2 compromisos nuevos), así que `/pm-publish` si quieres que la PMO la vea. El acta es tuya: no se guardó en tu carpeta de reuniones.
