Publiqué la ficha en `documentos/proyectos/PRY-209-convenios-de-libranza-con-empresas/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Antes de escribir:**
- Recalculé la ficha hoy (`compute`). Hay un solo cronograma (`10-plan/2026-06-20-cronograma-v1.csv`), así que `plan.end_date` = 2027-04-17 es la fecha vigente y coincide con la línea base. No hay diferencia que explicar.
- Términos: ya estaban vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). No hubo que registrar nada.
- La carpeta de gobierno ya existía; no creé nada.

**Lleva:** 13 campos con dato · 3 sin decir en ninguna parte (`identity.product`, que el acta dice «No aplica»; `identity.authority`; `identity.phase`) · declara **amarillo** al 2026-10-09 (24 % de avance, fuente `20-seguimiento/2026-10-09-informe-avance.md`, marcada como declaración)

**Lo más viejo que va ahí:** identidad, patrocinador, gerente, comité, fecha de inicio y presupuesto aprobado, todos del acta del 2026-06-20 (119 días; no pasa de un año).

**Lo que la PMO verá:** la declaración «amarillo» llega sin cuenta de 2 señales que el estado no menciona: compromisos vencidos (5) y compromisos reprogramados (3). Los campos de contraste que van con dato: sponsor, manager, committee, end_date, approved, status, as_of; `product` va como no encontrado.
