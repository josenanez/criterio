## Compromisos — Convenios de libranza con empresas (PRY-209) · al 2026-10-17

24 compromisos abiertos: 5 vencidos sin evidencia, 3 reprogramados tres veces o más, 4 sin fecha. 2 cerrados con documento.

### Se viene reprogramando

> **Jorge Medina** · Cerrar la prueba 2
> Prometido para el 2026-12-06, y antes para el 2026-11-22, el 2026-11-13, el 2026-11-03, el 2026-10-14 y el 2026-10-01. La promesa original era del 2026-09-18.
> **Seis reprogramaciones no son un problema de seguimiento: son un bloqueo que nadie ha nombrado.** La última se dijo hoy, 2026-10-17 (`2026-10-17-notas-reunion.txt`: «no alcanzó, se compromete para el 06/12/2026»). El hito «Ambiente de pruebas certificado» está fijado en la línea base para el 2026-11-22 (`10-plan/2026-06-20-cronograma-v1.csv`), una fecha que esta promesa ya rebasa.

> **Diana Molina** · Enviar el documento 1
> Prometido para el 2026-11-17, y antes para el 2026-11-03, el 2026-10-26 y el 2026-10-12. La promesa original era del 2026-10-02 (el 2026-09-05 se había dicho «por definir»).
> **Cuatro reprogramaciones.** Cada fecha nueva se movió después de que la anterior ya había pasado o estaba por pasar (fuentes: comités del 09-19, 09-26, 10-03 y 10-10).

> **Jorge Medina** · Revisar el anexo 3
> Prometido para el 2026-11-27, y antes para el 2026-11-11 y el 2026-10-23. La promesa original era del 2026-10-02.
> **Tres reprogramaciones.** Es la misma persona que arrastra la prueba 2; las dos cosas juntas son el patrón, no cada una por separado.

### Vencidos sin evidencia

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Camilo Beltrán | Entregar el punto 8 | 2026-10-01 | 16 días |
| Laura Vélez | Actualizar la matriz 6 | 2026-10-10 | 7 días |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-12 | 5 días |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 | 3 días |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-16 | 1 día |

- Camilo Beltrán dijo el 2026-09-26 que ya lo entregó; no se presentó acta y no hay nada en el expediente que lo respalde (`30-reuniones/2026-09-26-comite-semanal.md`). Sigue abierto. Camilo es además el gerente del proyecto.
- Óscar Ramírez: las notas de hoy traen «revisión con el proveedor, queda para el 2026-10-27». No dicen que sea este compromiso, así que va como compromiso aparte (abajo) y el ambiente 12 sigue vencido.

### Vencen esta semana (hasta el 2026-10-24)

| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-10-23 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |

Siguen después: Óscar Ramírez, revisión con el proveedor (2026-10-27, dicho hoy); Natalia Ospina, anexo 11 y Javier Hoyos, fecha 15 y Rubén Cárdenas, punto 16 (2026-10-29); Felipe Arango, diseño 13 (2026-10-31); Natalia Ospina, diseño 21 (2026-11-01); Diana Molina, fecha 23 (2026-11-04); Paula Céspedes, ambiente 20 (2026-11-10); Sandra Gil, anexo 19 (2026-11-15).

### Sin fecha

| Quién | Qué | Dicho el |
|---|---|---|
| Mauricio Pérez | Enviar el documento 9 | 2026-09-19 |
| Javier Hoyos | Enviar el documento 17 | 2026-10-03 |
| Andrés Lozano | Actualizar la matriz 22 | 2026-10-10 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-17 |

No pueden estar vencidos; por eso se cuentan aparte. El documento 9 lleva 28 días sin fecha. Mauricio Pérez dijo el 2026-10-03 que ya lo entregó; no se presentó acta, así que sigue abierto. Laura Vélez lo dijo como «la otra semana», que no es una fecha y no se convirtió en una.

### Cerrados desde la última revisión

- Confirmar la fecha 7 (Gustavo Neira): cerrado con `20-seguimiento/2026-10-10-acta-recibo-7.md`.
- Validar el ambiente 4 (Sandra Gil): cerrado con `20-seguimiento/2026-09-26-acta-recibo-4.md`.

### Lo que no es compromiso

- «El proveedor podría no llegar con el equipo completo para la siguiente fase» (notas de hoy) es un riesgo dicho y no registrado; ya quedó en la ficha, sin doliente.
