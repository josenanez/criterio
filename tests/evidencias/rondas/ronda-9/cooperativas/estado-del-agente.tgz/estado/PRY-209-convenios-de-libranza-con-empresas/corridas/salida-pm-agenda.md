*Términos: ya vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo. Sesión sin interfaz: tomé la respuesta sugerida en cada pregunta. Fecha: la reunión del 2026-10-31, que es el próximo comité según la configuración y coincide con «en dos semanas» de las notas de hoy. Duración: nadie la fijó, así que no recorté por tiempo; la suma es la que se ve abajo.*

## Reunión de seguimiento — Convenios de libranza con empresas (PRY-209) · 2026-10-31
6 puntos · 53 minutos · 10 personas requeridas (Jorge Medina, Diana Molina, Camilo Beltrán, Laura Vélez, Gustavo Neira, Óscar Ramírez, Beatriz Cuéllar, Mauricio Pérez, Javier Hoyos, Andrés Lozano)

Los datos están al 2026-10-17. Antes de la reunión conviene correr `/pm-commitments` otra vez: para el 10-31 habrá vencido lo que hoy figura como «vence antes de la próxima».

### Lo que no se destraba solo

> **[1] Qué bloquea la prueba 2 y cómo se sostiene el hito «Ambiente de pruebas certificado» (2026-11-22)** · 15 min · **Jorge Medina, con Camilo Beltrán**
> Prometido para el 2026-12-06, y antes para el 2026-11-22, el 2026-11-13, el 2026-11-03, el 2026-10-14 y el 2026-10-01. La promesa original era del 2026-09-18. Seis reprogramaciones.
> El mismo Jorge arrastra «Revisar el anexo 3»: 2026-11-27, y antes 2026-11-11 y 2026-10-23; original 2026-10-02. Tres reprogramaciones.
> **Debe quedar resuelto:** el nombre del bloqueo, quién lo puede quitar, y si el hito se mantiene o se lleva a comité como cambio de línea base.
> Fuente: `30-reuniones/2026-09-12`, `09-19`, `09-26`, `10-03`, `10-10-comite-semanal.md` y `2026-10-17-notas-reunion.txt` («no alcanzó, se compromete para el 06/12/2026»); hito en `10-plan/2026-06-20-cronograma-v1.csv`.
> **Si no se resuelve hoy:** la fecha prometida (2026-12-06) ya queda 14 días después del hito de la línea base (2026-11-22), y nadie ha pedido el cambio.

> **[2] Documento 1: qué pasa para que llegue** · 8 min · **Diana Molina**
> Prometido para el 2026-11-17, y antes para el 2026-11-03, el 2026-10-26 y el 2026-10-12. La promesa original era del 2026-10-02. Cuatro reprogramaciones.
> Diana es la patrocinadora del proyecto (`00-gobierno/2026-06-20-acta-constitucion.md`): si algo la frena, ella misma es quien puede decir qué.
> **Debe quedar resuelto:** una fecha que no dependa de otra cosa, o lo que la bloquea dicho en voz alta.
> Fuente: `30-reuniones/2026-09-19`, `09-26`, `10-03` y `10-10-comite-semanal.md`.
> **Si no se resuelve hoy:** sigue moviéndose una semana por reunión, como en las últimas cuatro.

### Vencido sin evidencia
| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Camilo Beltrán | Entregar el punto 8 | 2026-10-01 | El acta de recibo, o decir que no se entregó. El 09-26 dijo que ya lo entregó; no hay acta (`30-reuniones/2026-09-26-comite-semanal.md`). Camilo es el gerente. | 3 |
| Laura Vélez | Actualizar la matriz 6 | 2026-10-10 | Fecha real o evidencia (`10-03` y `10-10`) | 2 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-12 | Fecha real o evidencia (`09-26-comite-semanal.md`) | 2 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 | Decir si la «revisión con el proveedor» del 2026-10-27 es este mismo compromiso. Las notas de hoy no lo aclaran. Si lo es, es una reprogramación y deja de estar vencido; si no, sigue vencido. | 3 |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-10-16 | Fecha real o evidencia (`10-03` y `10-10`) | 2 |

Subtotal del punto [3]: 12 min. Más viejo primero.

### Se decide hoy o se atrasa
| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| [4] Qué se hace frente a que el proveedor no llegue con el equipo completo para la siguiente fase. Se comentó el 2026-10-17 y nadie lo tomó; no está en el RAID como riesgo con dueño (`2026-10-17-notas-reunion.txt`). | No consta en los documentos. Quien lo decida tiene que estar en la sala. | Sigue sin dueño ni fecha, y el proyecto lo descubre cuando el equipo no llegue. | 8 |
| [5] Cuatro compromisos sin fecha: Mauricio Pérez, documento 9 (dicho el 2026-09-19, 28 días sin fecha; el 10-03 dijo que ya lo entregó, sin acta); Javier Hoyos, documento 17 (2026-10-03); Andrés Lozano, matriz 22 (2026-10-10); Laura Vélez, ajuste del presupuesto («la otra semana», 2026-10-17). | Cada uno, con el gerente | Sin fecha no pueden vencer, y por eso nadie los ve. | 5 |

### Vence antes de la próxima
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Cerrar la prueba 18 | 2026-10-19 |
| Andrés Lozano | Aprobar el diseño 5 (ya movido una vez, original 2026-09-20) | 2026-10-23 |
| Mauricio Pérez | Entregar el punto 24 | 2026-10-24 |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 |
| Natalia Ospina | Revisar el anexo 11 (movido una vez, original 2026-10-16) | 2026-10-29 |
| Javier Hoyos | Confirmar la fecha 15 (movido una vez, original 2026-10-17) | 2026-10-29 |
| Rubén Cárdenas | Entregar el punto 16 (movido una vez, original 2026-10-05) | 2026-10-29 |
| Felipe Arango | Aprobar el diseño 13 (movido una vez, original 2026-10-15) | 2026-10-31 |

Punto [6], 5 min: repasar en bloque cuáles de estos llegan con evidencia al 10-31; no se discuten uno por uno. Fuente: `30-reuniones/2026-10-03` y `10-10-comite-semanal.md`, y `2026-10-17-notas-reunion.txt`.

### No es de esta reunión
| Qué | Por qué | Dónde va |
|---|---|---|
| Aprobación del reglamento por el Consejo de Administración (riesgo de la ficha, sin dueño ni fecha; `20-seguimiento/2026-10-09-informe-avance.md`) | La decide el Consejo, no nadie de la sala. | Material de comité, o `/pm-escalate` para formularla. |
| Mover el hito «Ambiente de pruebas certificado» (2026-11-22), si el punto [1] concluye que no se sostiene | Cambiar la línea base excede al gerente. | Control de cambios y comité; `/pm-commitments` para formular el compromiso. |

### Anexo
No hay corrida anterior de la que comparar (la primera lectura es el punto de partida), así que no puedo decir qué quedó «sin cambios desde la reunión anterior». Lo único abierto con fecha posterior al 2026-10-31 y sin movimientos: Natalia Ospina, diseño 21 (2026-11-01); Diana Molina, fecha 23 (2026-11-04); Paula Céspedes, ambiente 20 (2026-11-10); Sandra Gil, anexo 19 (2026-11-15, movido una vez). No se repasan en la reunión.

### Lo que esta agenda no sabe
- Cuánto dura la reunión; nadie lo fijó y no quise inventarlo.
- Quién tiene facultad para decidir lo del equipo del proveedor: no está en ningún documento.
- Si la «revisión con el proveedor» es el ambiente 12.
- No hay entregables de proveedor en la ficha (`vendors` está vacío), así que no hay vencidos de proveedor que traer.
- No hay una minuta de decisiones pendientes: las notas del 2026-10-17 no registran ninguna decisión, y lo que quedó sin decidir es el punto [4].

**Después:** cuando la reunión termine, `/pm-minutes` sobre las notas o la transcripción.
