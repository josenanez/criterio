# Plan — PRY-209 Convenios de libranza con empresas · borrador del 2026-10-17
**Desde:** el acta de constitución del 2026-06-20 (`00-gobierno/2026-06-20-acta-constitucion.md`) · **Criterio de éxito:** «Convenios de libranza con empresas en producción y medido.»

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17; comprobante en `.criterio/terminos/aceptacion-criterio-project-0.4.0-2026-10-17.md`). No se pidió un registro nuevo.

Este borrador **no compromete ninguna fecha**. Las fechas que aparecen abajo ya estaban en el acta o en el cronograma v1 aprobado; aquí solo se citan.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| **Alcance vacío.** Dice «Componente 1», «Componente 2», «Componente 3», sin nombrarlos. | No hay de dónde sacar los entregables. Una WBS por entregable no se puede construir desde el acta: lo que salga es del cronograma o es supuesto. |
| **Fuera de alcance sin nombre.** «Lo que otro proyecto cubre», sin decir cuál. | No se sabe qué frontera respetar ni de qué proyecto se depende. Además, el acta declara «Dependencias: Ninguna», lo que no cuadra con tener un fuera de alcance que otro proyecto cubre. |
| **Objetivo del negocio tautológico.** «Entregar convenios de libranza con empresas para Bienestar social.» | No dice cuántos convenios, con qué empresas, ni qué cambia para Bienestar social. «Medido» en el criterio de éxito queda sin métrica ni umbral. |
| **Sin autoridad declarada** del gerente (la ficha lo registra como no encontrado). | No se sabe qué puede decidir quien planifica y qué hay que subir a Diana Molina o al Comité de Tecnología. |
| **Sin quién acepta cada entregable.** El acta nombra patrocinador (Diana Molina) pero no aceptantes. | Los nodos terminales quedan sin aceptante confirmado. |
| **Criterio de éxito «en producción y medido» vs. cierre.** El último hito del cronograma es «Piloto con asociados» el 2027-04-17, el mismo día del cierre comprometido. | Producción y medición no tienen ventana visible dentro del plazo. No se decide aquí cuál manda; es una pregunta para el patrocinador. |

Sí está: patrocinador (Diana Molina), gerente (Camilo Beltrán), comité (Comité de Tecnología), presupuesto aprobado (9.500.000.000 COP) y fechas de inicio y cierre. Se sigue adelante marcando los huecos y sin rellenarlos.

## WBS
Solo hay dos fuentes de entregables: los tres componentes sin nombre del acta y los cuatro hitos del cronograma v1. Los hitos no están en el acta; los trato como **supuesto** de que cada hito equivale a un entregable.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | del acta (solo el rótulo, sin contenido) | vacía |
| 2 | Componente 2 | sin definir | del acta (solo el rótulo, sin contenido) | vacía |
| 3 | Componente 3 | sin definir | del acta (solo el rótulo, sin contenido) | vacía |
| 4 | Diseño funcional aprobado | sin definir (el acta de recibo está en `20-seguimiento/2026-10-04-acta-recibo-diseño-funcional-aprobado.pdf`; no se leyó aquí quién firma) | supuesto: hito del cronograma v1 | vacía; hito 2026-09-10 en la línea base, ya cerrado |
| 5 | Ambiente de pruebas certificado | sin definir | supuesto: hito del cronograma v1 | vacía; hito 2026-11-22 en la línea base |
| 6 | Integración con el core cooperativo | sin definir | supuesto: hito del cronograma v1 | vacía; hito 2027-02-03 en la línea base |
| 7 | Piloto con asociados | sin definir | supuesto: hito del cronograma v1 | vacía; hito 2027-04-17 en la línea base |
| 8 | Convenios en producción y medidos (criterio de éxito) | sin definir | del acta (criterio de éxito); su descomposición es sin definir | vacía |

No se sabe qué componente del acta corresponde a qué hito. Unirlos sería inventar.

## Orden
Sin fechas. Solo lo que el material permite sostener:

- El diseño funcional (4) antecede a todo lo demás. Es el único hito cerrado con acta de recibo.
- El ambiente de pruebas certificado (5) antecede a la integración (6) y al piloto (7). **Supuesto:** el orden de los hitos del cronograma refleja dependencia y no solo calendario.
- El piloto (7) antecede a «en producción y medido» (8), por el propio criterio de éxito.
- Las dependencias de los tres componentes (1 a 3) no se pueden ordenar. Siguen sin definir.
- Hay una dependencia externa que nadie declaró como tal: la aprobación del reglamento por el Consejo de Administración. El informe del 2026-10-09 la lista como riesgo. No se sabe de qué entregable depende.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Cada hito del cronograma v1 equivale a un entregable aceptable. | La WBS describe hitos de calendario y no entregables; los nodos no tienen aceptante real. |
| El orden de los hitos del cronograma es un orden de dependencia. | El orden de arriba no vale y hay que rehacerlo. |
| Los tres componentes del acta son distintos de los cuatro hitos. | Las filas 1 a 3 se duplican con las filas 4 a 7. |
| El cronograma v1 sigue siendo la línea base vigente. En la ficha todas las fechas vigentes son iguales a las originales. | Si ya hubo replanificaciones sin registrar, la referencia está mal. Los compromisos de las reuniones sí se han corrido mucho (p. ej. «Cerrar la prueba 2», de 2026-09-18 a 2026-12-06). |
| La aprobación del reglamento por el Consejo de Administración no bloquea ningún entregable propio. | Un hito puede quedar parado por una decisión ajena al equipo. |

Estos pasan a RAID con doliente cuando el plan se apruebe.

## Sin definir
| Qué | Quién lo define |
|---|---|
| Nombre y contenido de los componentes 1, 2 y 3 | Diana Molina (patrocinadora) |
| Qué proyecto cubre lo que queda fuera de alcance | Diana Molina o el Comité de Tecnología |
| Aceptante de cada entregable | Diana Molina |
| Autoridad del gerente al planificar | Diana Molina o el Comité de Tecnología |
| Qué es «medido»: métrica, umbral y plazo | Diana Molina |
| Número y perfil de empresas con convenio | Diana Molina |
| Si hay dependencias externas (el acta dice «ninguna» pero hay un fuera de alcance y un reglamento por aprobar) | Camilo Beltrán, con la patrocinadora |
| Fase actual del proyecto (la ficha no la tiene) | Camilo Beltrán |

## Proyectos análogos
No hay ninguno a la vista. La configuración de PRY-209 no apunta a una carpeta de fichas de la PMO, así que no se buscó. No se estima por analogía y no se inventa una referencia.

## Preguntas para el equipo
Una por cada duración vacía:

1. Componentes 1, 2 y 3 (filas 1 a 3): ¿cuáles son y qué recibe quien los acepta? ¿Cuánto toma cada uno?
2. Diseño funcional aprobado (fila 4): ¿se tiene la duración real para usarla como referencia de lo que sigue?
3. Ambiente de pruebas certificado (fila 5): ¿cuánto toma, y depende de «Cerrar la prueba 2» (Jorge Medina, hoy 2026-12-06) y de «Validar el ambiente 12» (Óscar Ramírez, vencido desde 2026-10-14)? El hito está en 2026-11-22 y «Cerrar la prueba 2» ya pasó esa fecha; hay que preguntar si se relacionan.
4. Integración con el core cooperativo (fila 6): ¿cuánto toma, y quién del lado del core interviene?
5. Piloto con asociados (fila 7): ¿cuánto dura el piloto y cuántos asociados entran?
6. En producción y medido (fila 8): ¿cuánto toma pasar de piloto a producción, y cuánto tiempo hace falta medir antes de poder decir que el criterio se cumplió?
7. Reglamento: ¿cuándo se espera la decisión del Consejo de Administración y qué entregables dependen de ella?
8. Proveedor: ¿el equipo completo llega para la siguiente fase? Se dijo en la reunión del 2026-10-17 y nadie lo registró como riesgo.

## Para comprometer una fecha falta
- La disponibilidad real del equipo. Es un juicio sobre personas y no está en ningún documento.
- La fecha del proveedor y si trae el equipo completo. Hoy es solo un comentario de reunión sin registrar.
- La ventana de la sala de producción y la del core cooperativo. Ninguna aparece en la documentación.
- La decisión del Consejo de Administración sobre el reglamento.
- El contenido de los componentes 1 a 3. Sin eso no hay duración que preguntar.

## Después
Cuando el plan se apruebe, queda ofrecido registrarlo como **línea base original** y pasar los supuestos de arriba al RAID con doliente, aplicando raid-taxonomy. No se hizo nada de eso en esta corrida.
