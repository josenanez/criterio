*Sesión sin interfaz: la pregunta del paso 2 no tuvo quien la respondiera. No propuse ningún estado. El informe usa la última declaración que el gerente dejó escrita (informe de avance del 2026-10-09) y lo dice. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.*

# PRY-209 Convenios de libranza con empresas — semana del 2026-10-11 al 2026-10-17

**Declara el gerente (Camilo Beltrán):** amarillo · 24 % · al 2026-10-09 (8 días; vigente, no vencida). No hay declaración nueva de esta semana.
**Sustento documental:** sin sustento. Los 11 documentos sin marca son todos de seguimiento o reuniones; ninguna cifra de dinero ni de avance viene de un documento de evidencia (0 de evidencia, 3 de declaración).
**Lo que el semáforo no explica:** `commitment_overdue` (5 compromisos vencidos) y `commitment_rescheduled` (3 compromisos reprogramados). Un amarillo no cubre ninguna de las dos señales.

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: el snapshot de hoy es el primero y el diff dio 0 cambios. No puedo decir qué cambió; solo qué hay hoy.

## Lo que sigue igual y sigue mal
Sin histórico, «desde» es la fecha de vencimiento y «días así» se cuenta a hoy.

| Qué | Desde | Días así |
|---|---|---|
| Camilo Beltrán: Entregar el punto 8 | vence 2026-10-01 | 16 |
| Laura Vélez: Actualizar la matriz 6 | vence 2026-10-10 | 7 |
| Gustavo Neira: Actualizar la matriz 14 | vence 2026-10-12 | 5 |
| Óscar Ramírez: Validar el ambiente 12 | vence 2026-10-14 | 3 |
| Beatriz Cuéllar: Cerrar la prueba 10 | vence 2026-10-16 | 1 |

El primero es del propio gerente.

## Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2027-04-17 | 2027-04-17 | 0 días (original y vigente) |
| Presupuesto | COP 9.500.000.000 | COP 9.500.000.000 | proyección COP 9.620.521.967: +1,3 % |

Replanificaciones: 0. La única línea base es la v1 del 2026-06-20 (Comité de Tecnología).
Avance: el gerente declara 24 %; el plan sustenta entre 25 % y 50 % (1 de 4 hitos cumplido). Diferencia de 1 punto, por debajo del umbral de 10. El cronograma no se ha movido, y que no se haya movido con 8 compromisos vencidos o reprogramados no es prueba de que esté bien.

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
|---|---|---|---|
| Ambiente de pruebas certificado | 2026-11-22 | 2026-11-22 | ninguna |

Es el único dentro de la ventana. Tiene dos compromisos asociados vencidos o reprogramados: «Validar el ambiente 12» (Óscar Ramírez, vencido) y «Cerrar la prueba 2» (Jorge Medina, reprogramado 6 veces, la última a 2026-12-06, que es después del hito). Lo segundo lo infiero por el nombre; no lo vi declarado como dependencia.

Ya cumplido, con evidencia: Diseño funcional aprobado (acta de recibo del 2026-10-04, un hito base del 2026-09-10; la evidencia es 24 días posterior a la fecha base).

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 6.033.140.746 (63,5 %) | 2.806.355.979 (29,5 %) | 9.620.521.967 | 3.466.859.254 |

El disponible real es aprobado menos comprometido, no aprobado menos ejecutado (que daría 6.693.644.021). Comprometido, ejecutado y proyectado son declaración del informe del 2026-10-09, sin documento contable.

## Abierto
**Reprogramados:**
- Jorge Medina, «Cerrar la prueba 2»: 6 veces. Original 2026-09-18, hoy 2026-12-06.
- Diana Molina, «Enviar el documento 1»: 4 veces. Original 2026-10-02, hoy 2026-11-17.
- Jorge Medina, «Revisar el anexo 3»: 3 veces. Original 2026-10-02, hoy 2026-11-27.

**Vencidos sin evidencia:** los cinco de la tabla de arriba.
**Sin fecha:** Mauricio Pérez («Enviar el documento 9»), Javier Hoyos («Enviar el documento 17»), Andrés Lozano («Actualizar la matriz 22») y Laura Vélez («Mandar el ajuste del presupuesto», de las notas de hoy).
**RAID sin movimiento:** dos riesgos, ambos sin dueño ni fecha: aprobación del reglamento por el Consejo de Administración (informe del 2026-10-09) y que el proveedor no llegue con el equipo completo (dicho en la reunión de hoy, nadie lo registró). Sin registro anterior, no puedo contar los días de ninguno.
**Proveedor:** no hay proveedores en la ficha. Hay un riesgo sobre un proveedor en las notas de hoy y ningún contrato registrado.

## Lo que necesito de alguien
- **Jorge Medina:** decir si «Cerrar la prueba 2» (6 reprogramaciones) sigue siendo viable antes del hito del 2026-11-22.
- **Camilo Beltrán:** declarar el estado de esta semana, o confirmar que sigue el amarillo del 9 de octubre, a la vista de los 5 compromisos vencidos.
- **Laura Vélez:** poner fecha al ajuste del presupuesto.
- **Alguien con autoridad sobre el proveedor:** registrar el riesgo de equipo incompleto con dueño y fecha.
- Nada excede la autoridad del gerente. Esta semana no hay material de comité.

## Lo que no se sabe
**Sin dato:** producto (`identity.product`), autoridad que aprueba (`identity.authority`) y fase (`identity.phase`). Sin autoridad no se sabe a quién escalar un compromiso reprogramado 6 veces. Tampoco hay documento contable que sostenga las cifras de dinero.
**Silencio:** último documento hoy (notas de reunión del 2026-10-17) · última reunión de comité hace 7 días (2026-10-10).

---
*Ficha: PRY-209, `estado/PRY-209-convenios-de-libranza-con-empresas/records/PRY-209.json`, actualizada el 2026-10-17. Corte: 2026-10-17. 3 campos sin dato. Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0*
