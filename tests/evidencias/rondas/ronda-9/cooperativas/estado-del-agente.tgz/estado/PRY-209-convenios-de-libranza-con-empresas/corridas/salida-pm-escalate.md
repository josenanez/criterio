## Para decisión — Convenios de libranza con empresas (PRY-209) · 2026-10-17

Nadie marcó un tema como escalable ni se pasó uno en el argumento, así que armé el paquete con lo que la ficha deja escalar hoy. Son dos puntos, en este orden: el segundo depende del primero.

---

### 1. ¿Quién tiene la facultad de aprobar un cambio de línea base y un sobrecosto en PRY-209, y se deja escrito en el acta?

**Quién decide:** Diana Molina, patrocinadora, con el Comité de Tecnología (que aprobó la línea base y el presupuesto el 2026-06-20). **Esto es inferencia mía: el acta no declara la autoridad del gerente ni quién aprueba qué** (`00-gobierno/2026-06-20-acta-constitucion.md`; campo `authority` sin encontrar en la ficha).
**Si no se decide hoy:** el 2026-10-31 (próximo comité) el punto 2 llega sin que nadie sepa si Camilo Beltrán puede mover el hito por sí mismo o si debe pedirlo al comité. Un punto dirigido a quien no puede decidirlo se devuelve.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Se añade al acta una sección de autoridad (umbrales de fecha y de dinero que decide el gerente, y lo que pasa al comité) | Sin cambio | Una adenda; fecha de emisión no la sé | Sin costo declarado en ningún documento |
| B. No se escribe; cada punto se decide caso a caso en el comité | Sin cambio | Cada punto añade una vuelta de comité | Sin costo declarado; el riesgo es decidir algo que no valía |

**Recomiendo:** A. Sin esto el gerente escala todo o no escala nada, y el punto 2 no tiene destinatario cierto.

---

### 2. ¿Se mantiene el hito «Ambiente de pruebas certificado» al 2026-11-22 con un destrabe nombrado, o se abre control de cambios para moverlo al 2026-12-06?

**Quién decide:** el Comité de Tecnología, por ser quien aprobó la línea base (inferencia, ver punto 1). **Si no se decide hoy:** el 2026-10-31 quedan 22 días para el 2026-11-22, con «Cerrar la prueba 2» prometida para 14 días después de ese hito. Si el comité tampoco decide ese día, el hito se vence sin que exista un cambio aprobado.
**No encontré** en los documentos una fecha de vencimiento de oferta o contrato que obligue a decidir antes; si existe, no está en la carpeta.

Por qué sube: Jorge Medina prometió «Cerrar la prueba 2» para el 2026-09-18 y la ha movido seis veces (10-01, 10-14, 11-03, 11-13, 11-22 y 12-06; la última se dijo hoy en `2026-10-17-notas-reunion.txt`). Esa fecha ya rebasa el hito de la línea base. No hay riesgo, incidencia ni dependencia registrados que expliquen el bloqueo, y el acta declara «ninguna dependencia».

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Mantener 11-22; el comité nombra el bloqueo de la prueba 2 y quién lo destraba, con fecha | Sin cambio | Hito en 36 días; no hay evidencia de que se cumpla | No sé. Ningún documento lo calcula |
| B. Abrir control de cambios: hito al 12-06 (+14 días). Como referencia, si el cambio pasara completo al cierre: 2027-05-01 en vez de 2027-04-17 | Sin cambio | +14 días en el hito; el efecto en el cierre no se sabe, porque no hay holgura por actividad en la ficha | No sé. Sí sé que la proyección declarada (9.620.521.967 COP) ya supera lo aprobado (9.500.000.000 COP) por 120.521.967 COP, antes de contar cualquier atraso |
| C. Reducir alcance para cumplir el hito | No se puede evaluar: los tres componentes del acta no tienen nombre | — | — |

**Recomiendo:** A, con la condición de que el comité nombre quién destraba y para cuándo. La fecha del 12-06 es la sexta de la serie y no tiene evidencia detrás; llevarla a la línea base repetiría el error. Si el 2026-10-31 no hay destrabe nombrado, pasar a B.

---

### A quién alcanza

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno | — | — | — |

El cálculo (`impact`, 14 días) no alcanza a ningún otro proyecto: PRY-209 declara «ninguna dependencia» y no hay otra ficha que lo nombre. **Eso no prueba que no haya efecto.** El acta excluye «lo que otro proyecto cubre» sin nombrarlo, y las notas de hoy hablan de un proveedor y del Consejo de Administración (reglamento) que no están como dependencias. Qué proyecto es ese, no lo sé.

### Mis hitos por los que pasa

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ambiente de pruebas certificado | 2026-11-22 | 36 |
| Integración con el core cooperativo | 2027-02-03 | 109 |
| Piloto con asociados | 2027-04-17 | 182 |

Estos son los hitos por los que pasa el cambio, no los que se mueven. **Cuántos días se movería cada uno no lo calculo:** necesita holgura por actividad y la ficha no la tiene.

### Lo que no escala

- El riesgo del proveedor que «podría no llegar con el equipo completo» no escala: nadie lo registró ni tiene doliente. Primero hay que registrarlo.
- Los 5 compromisos vencidos y las 4 promesas sin fecha se destraban con una llamada; no son escalamiento.

### De dónde sale esto

- Autoridad no declarada, presupuesto, comité y fechas comprometidas: `00-gobierno/2026-06-20-acta-constitucion.md`.
- Hitos y fechas de línea base: `10-plan/2026-06-20-cronograma-v1.csv`.
- Seis reprogramaciones de «Cerrar la prueba 2»: comités del 09-12, 09-19, 09-26, 10-03, 10-10 (`30-reuniones/`) y `2026-10-17-notas-reunion.txt`.
- Proyección y presupuesto: `20-seguimiento/2026-10-09-informe-avance.md` (declaración del gerente, sin soporte aparte).
- Próximo comité: 2026-10-31 (`config.json`, `cycle.committee_next`).
- Efecto en hitos: `portafolio.py impact --days 14`.

**Lo que no sé:** el costo de las opciones, la causa del bloqueo de la prueba 2, la autoridad real de Camilo Beltrán, y el efecto en el cierre.
