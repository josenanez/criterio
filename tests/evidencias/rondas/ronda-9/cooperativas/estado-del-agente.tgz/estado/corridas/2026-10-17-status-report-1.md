# Corrida del 2026-10-17 · status-report

13 proyectos · 24 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Informe de PRY-203: verde declarado sin sustento (3 hitos sin evidencia, 24 días de silencio, brecha de avance de 43 puntos). Dijo que no sabe autoridad, fase, última reunión ni proveedores.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Informe generado desde la ficha `estado/records/PRY-203.json` (actualizada el 2026-10-17), recalculada con `portafolio.py compute` al 2026-10-17.

## PRY-203 · Aportes sociales en línea — estado al 2026-10-17

**Declara el gerente (Paula Céspedes):** verde · 57 % · al 2026-09-23 (24 días; dentro del plazo de 30 días, no está vencida la declaración)
**Sustento documental:** sin sustento (0 fuentes de evidencia; 3 declaraciones y 12 campos sin marcar)
**Lo que el semáforo no explica:** `milestone_met_without_evidence` (3 hitos), `progress_vs_plan`, `silent`
**Último documento:** 2026-09-23 (24 días de silencio; umbral 15) · **Última reunión:** sin dato (la ficha no tiene actividad registrada)

Alerta `declared_vs_evidence`: el gerente reporta verde y hay tres señales que ese verde no cubre.

### Contra el plan
| | Línea base original | Vigente | Desviación |
|---|---|---|---|
| Fecha de cierre | 2026-07-07 | 2026-07-07 | 0 días vs. original y vs. vigente |
| Presupuesto aprobado | COP 6.800.000.000 | COP 6.800.000.000 | proyección COP 7.116.748.864, +4,7 % sobre lo aprobado (umbral 10 %) |

Replanificaciones: 0. Una sola línea base (v1, aprobada 2025-11-12 por el Comité de Educación).

Dinero: ejecutado COP 3.031.029.425 (44,6 %), comprometido COP 2.123.715.582 (31,2 %), disponible real COP 4.676.284.418. Las tres cifras y la proyección son declaración del informe del 2026-09-23, no evidencia.

Observación mía, no alerta del script: la fecha de cierre 2026-07-07 ya pasó hace 102 días y la declaración es de 57 %. Con 0 días de desviación y 0 replanificaciones, el plan sigue diciendo que el proyecto terminó, y nadie lo ha movido.

### Hitos
| Hito | Base | Vigente | Estado | Evidencia |
|---|---|---|---|---|
| Diseño funcional aprobado | 2026-02-05 | 2026-02-05 | cumplido (según el cronograma) | ninguna (254 días) |
| Ambiente de pruebas certificado | 2026-04-22 | 2026-04-22 | cumplido (según el cronograma) | ninguna (178 días) |
| Integración con el core cooperativo | 2026-07-07 | 2026-07-07 | cumplido (según el cronograma) | ninguna (102 días) |

### Dónde no coincide
- El cronograma v1 (2025-11-12) marca los 3 hitos de 3 como cumplidos, lo que sostiene entre 100 % y 100 % de avance; el informe del 2026-09-23 declara 57 %. Brecha: 43 puntos. Las dos fuentes se contradicen entre sí, y ninguna trae evidencia de cumplimiento.
- El informe declara verde, con silencio de 24 días, tres hitos sin evidencia y esa brecha de avance.

### Abierto
**Riesgos e incidencias sin movimiento:**
- Riesgo: el proveedor no ha confirmado la fecha de la última entrega (sin dueño, sin fecha; informe 2026-09-23).
- Incidencia: el Consejo de Administración pidió ajustar el reglamento antes del piloto (desde 2026-09-23, 24 días; sin dueño).
**Compromisos vencidos:** ninguno registrado. No hay compromisos en la ficha, lo cual no prueba que no existan: no hay actas de reunión entre los documentos leídos.
**Dependencias sin confirmar:** ninguna registrada. El acta excluye «lo que otro proyecto cubre» sin nombrar el proyecto.

### Sin dato
- Autoridad de aprobación (`identity.authority`) y fase (`identity.phase`).
- Proveedores y contratos: la ficha no trae ninguno, aunque el riesgo menciona a un proveedor.
- Última reunión.
- Alcance: el acta lo describe como «Componente 1, 2 y 3», sin nombrar.

### Siguiente paso
Hay silencio por encima del umbral y un verde sin sustento. Puedo preparar el punto de comité (el próximo es el 2026-10-24) o pedir al gerente la evidencia de los tres hitos.

---
Pie: criterio-portfolio 0.4.0 · ficha aplicada `PRY-203` actualizada el 2026-10-17 (3 documentos, el más reciente del 2026-09-23) · campos inciertos: autoridad, fase, última reunión, proveedor · términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
