# Corrida del 2026-10-17 · project-charter

13 proyectos · 26 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Revisión del acta de PRY-200: sin autoridad del gerente, objetivo no medible, alcance y exclusiones placeholder, dependencias contradicen el informe. No sé si hay actas o decisiones fuera de la carpeta.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos: vigentes (versión 1.1 / familia 0.4.0), aceptados el 2026-10-17 por José Francisco Ñáñez; no se registraron de nuevo.

## Acta — PRY-200 · Crédito de libranza digital
**Estado:** existe, del 2025-10-01 (`PRY-200-crédito-de-libranza-digital/00-gobierno/2025-10-01-acta-constitucion.md`). Revisión hecha el 2026-10-17, es decir, 12,5 meses después de aprobada y sin ninguna versión posterior en la carpeta.

### Qué falta
| Campo | Estado | Consecuencia |
|---|---|---|
| **Autoridad del gerente** (monto y cambios de alcance que decide sin comité) | **No existe** | Elena Duarte no tiene un límite escrito. La proyección al cierre es 18.323.116.908 COP contra 18.000.000.000 aprobados (+323.116.908, +1,8 %): nadie puede decir con el acta en la mano si eso lo decide ella o lo decide el Comité de Riesgos. Lo mismo con el ajuste del reglamento pedido por el Consejo, que puede mover alcance y plan. Sin umbral, todo sube a comité o se decide sin respaldo. |
| **Objetivo de negocio** | Presente pero describe la solución, no un resultado | «Entregar crédito de libranza digital para Crédito» repite el nombre del proyecto. No hay beneficio, cifra ni fecha de negocio, así que nadie puede decir si el proyecto valió la pena aunque entregue. |
| **Alcance** | Placeholder | «Componente 1, 2, 3» no dice qué se construye. Una solicitud de cambio no puede evaluarse contra un alcance que no está escrito: el ajuste del reglamento no se puede clasificar como dentro o fuera. |
| **Exclusiones** | Placeholder | «Lo que otro proyecto cubre» no nombra el proyecto. En un portafolio con PRY-209 (convenios de libranza con empresas), PRY-202 (core cooperativo) y PRY-208 (motor de crédito), la frontera sin nombre es donde se duplica o se cae trabajo. |
| **Criterio de éxito medible y quién lo mide** | Insuficiente / ausente | «En producción y medido» no dice qué métrica ni qué valor. No hay quién lo mida. El cierre no podrá contrastarse contra nada. |
| **Supuestos y restricciones** | Ausentes | No hay sección. Nada de lo que el proyecto da por cierto está declarado, por lo que no hay supuesto que verificar ni que pasar a riesgo. |
| **Dependencias** | «Ninguna declarada» | Contradice el informe de avance del 2026-10-13, que lista como riesgo abierto la «dependencia del proveedor del core cooperativo». O la dependencia nació después del acta, o el acta nunca la vio; en ambos casos el acta quedó desactualizada. |
| **Hitos principales** | Ausentes | Solo inicio y cierre. Sin hitos no hay cómo medir el 84 % reportado (la ficha tampoco tiene hitos). |
| **Cadencia del comité** | Ausente | Nombra al Comité de Riesgos pero no cada cuánto reporta ni qué le lleva. |
| **Patrocinador** | Presente: Felipe Arango | Sin observación. |
| **Gerente** | Presente: Elena Duarte | Sin observación. |
| **Presupuesto y fechas** | Presentes: 18.000.000.000 COP; 2025-10-11 a 2027-01-12 | Sin observación sobre el acta. |

### Contenido
**Objetivo de negocio:** pendiente de definir (el acta solo dice «Entregar crédito de libranza digital para Crédito»; no es medible).
**Alcance:** pendiente de definir (acta: «Componente 1, 2, 3», sin nombrar).
**Exclusiones:** pendiente de definir (acta: «Lo que otro proyecto cubre», sin nombrar el proyecto).
**Patrocinador:** Felipe Arango · **Gerente:** Elena Duarte (acta, 2025-10-01).
**Autoridad del gerente:** pendiente de definir — no está en ningún documento.
**Comité al que reporta:** Comité de Riesgos (acta) · **Cadencia:** pendiente de definir.
**Supuestos:** pendiente de definir · **Restricciones:** pendiente de definir.
**Criterio de éxito:** acta: «Crédito de libranza digital en producción y medido» (no medible) · **Lo mide:** pendiente de definir.
**Hitos principales:** pendiente de definir. Solo constan inicio 2025-10-11 y cierre 2027-01-12 (acta).
**Presupuesto aprobado:** 18.000.000.000 COP, Comité de Riesgos, 2025-10-01 (acta).

### Lo que el informe del 2026-10-13 deja a la vista del acta
- Proyección 18.323.116.908 COP > aprobado: el acta no dice quién autoriza el exceso.
- El Consejo de Administración pidió ajustar el reglamento antes del piloto: es un posible cambio de alcance sin alcance escrito contra el cual medirlo.
- Avance declarado 84 % con 8.390.726.733 COP ejecutados (46,6 % del aprobado) y 11.948.069.445 comprometidos (66,4 %). No se sabe cómo se mide el 84 % porque no hay hitos; es una observación para `/health-check`, no un hallazgo del acta.
- Los dos riesgos y las dos incidencias del informe no tienen responsable ni fecha.

### Lo que no sé
- Si existe un acta posterior, una adenda o una decisión de comité fuera de la carpeta: solo hay dos documentos (el acta y el informe). Lo hablado en comité no está en ellos.
- Cuál es la autoridad real de Elena Duarte en la práctica.

## Después
- El acta quedó sin autoridad declarada. Te ofrezco llevar esa definición al Comité de Riesgos como decisión (monto y tipo de cambio que decide la gerente sin comité), empezando por el +323 M de la proyección y el ajuste del reglamento.
- Los supuestos que faltan y la dependencia del core cooperativo pueden pasarse al registro RAID con `/raid-log PRY-200`. (Sin interfaz: no ejecuté ninguno de los dos; quedan ofrecidos.)

---
**Rigor:** fuentes leídas — acta de constitución (2025-10-01) e informe de avance (2026-10-13), más la ficha `estado/records/PRY-200.json` (actualizada 2026-10-17). Nada se completó con supuestos: lo que no está se marcó pendiente de definir. Los dichos del informe son declaración del gerente, no verificación. Las cifras de porcentaje las calculé yo a partir de las del informe.
