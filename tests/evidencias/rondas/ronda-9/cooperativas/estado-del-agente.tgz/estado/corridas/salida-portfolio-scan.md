Los términos están vigentes: versión 1.1, aceptada por José Francisco Ñáñez el 2026-10-17 para esta prueba. Comprobante en `.criterio/terminos/` (Markdown y PDF). Nada que registrar de nuevo.

## Barrido — 2026-10-17

**Documentos:** 67 en la carpeta · 41 leídos · 26 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 con carpeta · 10 fichas escritas y selladas en esta corrida · 3 sin cambio (PRY-199, PRY-202, PRY-209) · 0 sin carpeta propia

Formatos: 35 .md, 10 .docx, 10 .pdf, 5 .csv, 5 .xlsx, 1 .txt, 1 .json. Plan: 1 lote de 10 proyectos, uno tras otro en esta conversación (`workers: 1`), sin diferidos. Los .docx, .pdf y .xlsx se leyeron por su texto convertido con `texto.py`; las citas van a los originales.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-200 Crédito de libranza digital | 2 | identidad, plazos, presupuesto, estado declarado | `authority`, `phase`; no hay cronograma, así que no hay hitos |
| PRY-201 Apertura de ahorro en línea | 8 | los anteriores, 5 hitos, proveedor CT-894, 1 compromiso | `authority`, `phase` |
| PRY-203 Aportes sociales en línea | 3 | los anteriores, 3 hitos | `authority`, `phase`; no hay contrato aunque el informe habla de un proveedor |
| PRY-204 Tarjeta débito para asociados | 7 | los anteriores, 4 hitos, 2 líneas base, CC-01, 2 compromisos | `authority`, `phase` |
| PRY-205 Prevención de lavado de activos | 2 | los anteriores | `product` (el acta dice «No aplica»), `authority`, `phase`; no hay cronograma |
| PRY-206 Pagos con QR | 2 | los anteriores | `authority`, `phase`; no hay cronograma |
| PRY-207 Microcrédito rural | 3 | los anteriores, CC-01 pendiente | `authority`, `phase`; no hay cronograma |
| PRY-208 Motor de crédito | 6 | los anteriores, 5 hitos, proveedor CT-314, 2 compromisos | `product` («No aplica»), `authority`, `phase` |
| PRY-210 Corresponsales rurales | 4 | los anteriores, 4 hitos, 1 compromiso sin fecha | `product` («No aplica»), `authority`, `phase` |
| PRY-211 Cobranza digital | 4 | los anteriores, 4 hitos, 1 compromiso | `authority`, `phase` |

`authority` y `phase` faltan en las diez: ninguna acta dice hasta qué monto o cambio puede decidir el gerente sin subir a comité. Todas las actas traen el alcance como «Componente 1/2/3» y la exclusión como «lo que otro proyecto cubre», sin nombres.

### Actualizados
| Proyecto | Qué cambió | Fuente |
|---|---|---|
| PRY-204 | Segunda línea base: el piloto pasa de 2026-11-04 a 2027-01-23 por el cambio CC-01 (+80 días, +160.000.000 COP). | `20-seguimiento/2026-10-12-solicitud-cambio-cc-01.md`; `10-plan/2026-10-14-cronograma-v2.xlsx` |

El resto de las fichas son nuevas. PRY-199, PRY-202 y PRY-209 no se releyeron: sus documentos no cambiaron.

### No pude leer
| Archivo | Por qué |
|---|---|
| (ninguno) | Los 67 archivos se leyeron o se convirtieron sin error. |

### Movidos desde entrada/
| Archivo | A qué proyecto | Por qué |
|---|---|---|
| (ninguno) | — | No existe carpeta `entrada/` bajo `documentos/proyectos`. |

### Pendientes de clasificar
| Archivo | Por qué no pude decidir |
|---|---|
| `PRY-209-…/2026-10-17-notas-reunion.txt` | Está suelto en la raíz del proyecto, fuera de `00-gobierno`, `10-plan`, `20-seguimiento` y `30-reuniones`. No lo moví ni lo leí: el plan no lo trae para leer en esta corrida. Pido que alguien confirme en qué carpeta va. |

## Lo que hay que mirar (declarado frente a lo que sustentan los documentos)

**Estado declarado contra otros documentos**
- **PRY-208** declara verde con 31% de avance. Su cronograma marca los cinco hitos como cerrados, incluida la «Salida a producción» del 2026-08-05, y ninguno tiene acta de recibo en la carpeta. La bolsa de horas del contrato CT-314 sigue «en curso» con fecha comprometida 2026-06-06.
- **PRY-203** declara verde con 57% de avance. Su cierre comprometido era el 2026-07-07 y sus tres hitos están «cerrados» sin acta.
- **PRY-205 y PRY-206**: sus fechas de cierre del acta (2026-07-11 y 2026-06-26) ya pasaron. Cada uno declara amarillo con 74% y 58%, y no hay cronograma ni solicitud de cambio que mueva la fecha. PRY-206 dice que «se reprogramó la salida» sin dar fecha nueva.
- **PRY-207** declara rojo con 83% de avance.

**Proveedores y facturas**
- **PRY-201 / CT-894:** dos entregables con acta de recibo (licenciamiento, 2026-04-16; bolsa de horas, 2026-08-11), cada uno de 222.267.112 COP. La factura FV-1894 (2026-08-29) es de 561.870.991 COP. Queda por verificar cuánto de eso tiene acta; el informe consolidado lo calcula.
- **PRY-208 / CT-314:** el contrato dice «recibido» para el licenciamiento, pero no hay acta de recibo de ningún entregable, y la condición de pago exige acta firmada por el gerente. La factura FV-1314 (2026-09-18) es de 909.461.374 COP, igual al valor de un entregable.

**Cambios**
- **PRY-204 / CC-01:** dice «autorizada por el comité», sin nombrar el comité ni citar acta. El acta de comité del 2026-10-11 es anterior a la solicitud (2026-10-12) y no la menciona. El presupuesto del informe de avance (2026-10-14) sigue en 6.800.000.000, sin los 160.000.000 adicionales.
- **PRY-207 / CC-01:** +110 días y +220.000.000 COP, «pendiente de presentación al comité». No toca la línea base mientras no se decida.

**Gobierno**
- En **PRY-204** y **PRY-206**, patrocinador y gerente son la misma persona (Sandra Gil; Camilo Beltrán). En el comité del 2026-10-11 de PRY-204 los dos asistentes son Sandra Gil.

**Compromisos (corte 2026-10-17)**
- **Vencido:** PRY-208, Ricardo Salas, «Entregar el punto 32», para el 2026-10-15; la carpeta no trae evidencia de cumplimiento.
- **Sin fecha:** PRY-210, María Restrepo, «Entregar el punto 28», «por definir».
- **Abiertos con fecha:** PRY-204 (Liliana Torres, 2026-10-25; Ricardo Salas, 2026-11-04), PRY-201 (Andrés Lozano, 2026-11-01), PRY-208 (María Restrepo, 2026-11-07), PRY-211 (Gustavo Neira, 2026-11-10).
- Andrés Lozano figura en el comité de PRY-201 como responsable, pero ahí no es asistente (es el gerente de PRY-208).

**Dependencia sin registrar**
- PRY-200 y PRY-211 listan como riesgo la «dependencia del proveedor del core cooperativo», y las dos actas dicen «ninguna dependencia declarada». No la até a PRY-202 (Core cooperativo) porque ningún documento lo dice; se deja para confirmar.

**Presupuesto (cifras tal como las declaran los informes; no las calculé)**
- En PRY-201, PRY-203, PRY-205 y PRY-210 el ejecutado declarado es mayor que el comprometido.
- En PRY-210 la proyección al cierre (11.281.920.391) supera el aprobado (9.500.000.000).
- El script de la ficha calcula las desviaciones; este barrido no.

**Estado del barrido anterior (PRY-209)**
- El plan marca 15 campos de PRY-209 con citas que ya no resuelven (acta de constitución, cronograma, informe de avance). Los archivos sí están en disco: la ficha cita rutas sin el prefijo `PRY-209-convenios-de-libranza-con-empresas/`. No la reescribí porque sus documentos no cambiaron. Hay que corregir esas citas en la próxima corrida de PRY-209.
- Existe además una carpeta `estado/PRY-209-convenios-de-libranza-con-empresas/` con registros de otra corrida, ajena a este estado; no la toqué.

## Después

Hay diez fichas nuevas y tres contradicciones entre lo declarado y los documentos (PRY-208, PRY-203, PRY-205/206), además de un compromiso vencido. Siguiente paso: `/criterio-portfolio:portfolio-report` para el informe consolidado, que es donde se calculan las desviaciones y las señales de proveedor.

---
criterio-portfolio 0.4.0 · fichas tocadas: PRY-200, 201, 203, 204, 205, 206, 207, 208, 210, 211 · campos en `not_found`: `identity.authority` y `identity.phase` en las 10; `identity.product` en PRY-205, 208 y 210 · términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
