# Corrida del 2026-10-17 · portfolio-report

13 proyectos · 67 documentos, 0 releídos y 67 sin cambio · 47 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

El informe quedó en `/home/claude/banco/ronda-9/cooperativas/espacio/reportes/index.html`.

6 verdes contradichos por la evidencia; sin delta previo (primera instantánea)

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Portafolio — 2026-10-17

**Fichas cargadas:** 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas con documento de seguimiento de entre 0 y 24 días de antigüedad; barrido del 2026-10-17. Ninguna supera la semana sin barrido.
**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Criterio produce borradores de trabajo, no decisiones ni asesoría; cada dato trae la cita del documento y la verificación es suya.

13 proyectos · 8 con hallazgos (52 señales) · 6 en verde contradichos por la evidencia · último barrido 2026-10-17

## Qué cambió desde 2026-10-17
Sin cambios desde la corrida anterior. La única instantánea previa es de hoy (`snapshots/2026-10-17.json`), así que este informe es el punto de partida: no hay delta histórico.

## Contradicciones abiertas
Vacía: ningún proyecto tiene campos en conflicto entre dos fuentes. Lo que sí hay es el verde declarado contra la evidencia (ver "Estado general").

## Hitos vencidos sin evidencia
Ningún hito vencido sin marcar. Lo que hay es lo contrario: hitos declarados cumplidos sin documento que lo sustente.

| Proyecto | Hito declarado cumplido | Fecha | Días |
|---|---|---|---|
| PRY-201 | Diseño funcional aprobado | 2026-03-10 | 221 |
| PRY-201 | Ambiente de pruebas certificado | 2026-05-28 | 142 |
| PRY-201 | Integración con el core cooperativo | 2026-08-15 | 63 |
| PRY-202 | Integración con el core cooperativo | 2026-09-10 | 37 |
| PRY-203 | Diseño funcional / Ambiente de pruebas / Integración con el core (3 hitos) | 2026-02-05 a 2026-07-07 | 102 a 254 |
| PRY-204 | Diseño funcional aprobado | 2026-03-24 | 207 |
| PRY-204 | Ambiente de pruebas certificado | 2026-06-07 | 132 |
| PRY-208 | Los 5 hitos, incluida "Salida a producción" | 2026-02-05 a 2026-08-05 | 73 a 254 |
| PRY-210 | Diseño funcional / Ambiente de pruebas / Integración con el core (3 hitos) | 2025-12-17 a 2026-07-27 | 82 a 304 |
| PRY-211 | Diseño funcional aprobado | 2026-06-30 | 109 |
| PRY-211 | Ambiente de pruebas certificado | 2026-09-05 | 42 |

## Proyectos en silencio
Umbral: 15 días.

| Proyecto | Días | Último documento |
|---|---|---|
| PRY-203 Aportes sociales en línea | 24 | 2026-09-23, informe de avance |

## Dependencias en riesgo
Vacía: ningún proyecto declara dependencias por código.

## Sin sustento
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-202 Core cooperativo | Verde (2026-10-15), avance 55 % | El plan sostiene 75–100 %; sobrecosto proyectado 24,8 %; compromiso vencido hace 7 días (Natalia Ospina, "punto 23") |
| PRY-203 Aportes sociales | Verde (2026-09-23), avance 57 % | Con 3 de 3 hitos "cumplidos" el plan sostiene 100 %; 24 días en silencio; ninguno de los 3 hitos tiene evidencia |
| PRY-204 Tarjeta débito | Verde (2026-10-14) | Una replanificación; atraso de 80 días (26,7 %) contra la línea base original; 2 hitos sin evidencia |
| PRY-208 Motor de crédito | Verde (2026-09-28), avance 31 % | 5 de 5 hitos "cumplidos", incluida salida a producción, con 31 % de avance; entregable del proveedor "Bolsa de horas" pendiente hace 133 días; "Licenciamiento del módulo" aceptado sin evidencia |
| PRY-210 Corresponsales rurales | Verde (2026-10-09), avance 59 % | Sobrecosto proyectado 18,8 % (COP 11.281.920.391 sobre 9.500.000.000); 3 hitos sin evidencia; el plan sostiene 75–100 % |
| PRY-211 Cobranza digital | Verde (2026-10-05) | 2 hitos declarados cumplidos sin evidencia |
| PRY-201 Apertura de ahorro (amarillo) | Amarillo, avance 22 % | El plan sostiene 60–80 % (brecha de 38 puntos); facturado COP 561.870.991 contra COP 444.534.224 aceptado (diferencia COP 117.336.767) con el proveedor Integración Financiera del Sur; 3 hitos sin evidencia |

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad que aprobó (`identity.authority`): ningún proyecto la tiene |
| 12 de 13 | Fase (`identity.phase`) |
| PRY-199 | Facturación del proveedor Soluciones Solidarias (CT-199) |
| PRY-209 | 6 campos sin dato; 4 compromisos sin fecha, 5 vencidos y 3 reprogramados (Jorge Medina: "Cerrar la prueba 2" movida 6 veces, de 2026-09-18 a 2026-12-06; Diana Molina 4 veces; Jorge Medina "Revisar el anexo 3" 3 veces) |
| PRY-210 | Compromiso sin fecha: María Restrepo, "punto 28" |
| PRY-200, PRY-205, PRY-206, PRY-210 | 12 campos de la ficha con 12 meses (2025-10-01), en el umbral de caducidad |
| Sin producto asignado | PRY-202, PRY-205, PRY-208, PRY-209, PRY-210 |
| Fuentes | Ningún dato de ninguna ficha viene marcado como evidencia: todo es declaración o sin marcar |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Mobiliario de agencias | Verde | Sin hallazgos | 0 d | 0 d | 0 |
| PRY-200 Crédito de libranza digital | Amarillo | Sin hallazgos; fichas de 12 meses | 0 d | 0 d | 0 |
| PRY-201 Apertura de ahorro en línea | Amarillo | 5 señales | 0 d | 0 d | 0 |
| PRY-202 Core cooperativo | Verde | Contradicho (4 señales) | 0 d | 0 d | 0 |
| PRY-203 Aportes sociales en línea | Verde | Contradicho (silencio, 3 hitos) | 0 d | 0 d | 0 |
| PRY-204 Tarjeta débito | Verde | Contradicho (atraso 80 d) | 80 d (26,7 %) | 0 d | 1 |
| PRY-205 Prevención de lavado de activos | Amarillo | Sin hallazgos; fichas de 12 meses | 0 d | 0 d | 0 |
| PRY-206 Pagos con QR | Amarillo | Sin hallazgos; fichas de 12 meses | 0 d | 0 d | 0 |
| PRY-207 Microcrédito rural | Rojo | Sin hallazgos adicionales | 0 d | 0 d | 0 |
| PRY-208 Motor de crédito | Verde | Contradicho (9 señales) | 0 d | 0 d | 0 |
| PRY-209 Convenios de libranza | Amarillo | 12 señales de compromisos | 0 d | 0 d | 0 |
| PRY-210 Corresponsales rurales | Verde | Contradicho (sobrecosto 18,8 %) | 0 d | 0 d | 0 |
| PRY-211 Cobranza digital | Verde | Contradicho (2 hitos) | 0 d | 0 d | 0 |

Costo: PRY-202 proyecta COP 1.498.158.438 contra COP 1.200.000.000 aprobados (+24,8 %); PRY-210 +18,8 %. PRY-200 +1,8 %, dentro del umbral de 10 %.

## Necesito que confirmes
Cinco campos, los más viejos que importan (todos del 2025-10-01 o ya vencidos):

1. PRY-200: ¿el patrocinador sigue siendo Felipe Arango? (sí / no)
2. PRY-200: ¿la gerente sigue siendo Elena Duarte? (sí / no)
3. PRY-200: ¿sigue vigente la fecha de fin 2027-01-12? (sí / no)
4. PRY-205: ¿la fecha de fin 2026-07-11, ya pasada, sigue siendo la vigente? (sí / no: indique la nueva fecha)
5. PRY-206: ¿la fecha de fin 2026-06-26, ya pasada, sigue siendo la vigente? (sí / no: indique la nueva fecha)

## Dónde quedó el informe
Carpeta `reportes/` (25 páginas): `index.html` es la vista por campo, con la cadena de evidencia, para quien va a actuar; `decisiones.html` es la vista por decisión, para el patrocinador. Una página por proyecto (`PRY-199.html` a `PRY-211.html`), más páginas por producto. El PDF sale de imprimir el HTML.

---
Versión de la familia 0.4.0 · fichas aplicadas: PRY-199 a PRY-211, barrido 2026-10-17 · campos inciertos: autoridad y fase sin dato; 12 campos de 4 proyectos con 12 meses; fuentes sin marcar · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
