# Corrida del 2026-10-17 · health-check

13 proyectos · 101 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Diagnóstico de PRY-208 desde 6 documentos: 5 sostenidas, 8 sin sustento, 4 contradichas. Dijo que la carpeta no permite diagnosticar el avance real (hitos sin evidencia, piloto contradicho, sin autoridad ni soporte contable).

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrar una aceptación nueva.

## Diagnóstico · PRY-208 Motor de crédito · 2026-10-17

**Leí:** 6 documentos · 2025-12-09 a 2026-10-15 · formatos: Markdown (3), CSV (1), PDF (2). Además busqué el código y el nombre del proyecto en el resto de `documentos/` (otros proyectos y productos): ningún otro documento los menciona.
**No pude leer:** nada quedó sin leer. Los dos PDF salieron como texto corto y completo. No hay actas de recibo, registro de riesgos, solicitudes de cambio ni soportes contables en la carpeta.

### Dictamen
**Sostenido:** 5 afirmaciones · **Sin sustento:** 8 · **Contradicho:** 4

Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuánto se aprobó, qué se pactó con el proveedor y que se radicó una factura. No se puede afirmar que algún hito esté cumplido, que el avance sea 31 % ni que el estado sea verde. El cronograma dice que los cinco hitos están cerrados. El informe de avance dice 31 % y que el piloto aún no ocurrió. Los dos no pueden ser ciertos. Entre el 2025-12-12 y el 2026-09-18 no hay ningún documento fechado. Ese es el periodo en que vencieron los cinco hitos.

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Carlos Peña | acta de constitución, 2025-12-12 |
| Gerente | Andrés Lozano (el informe del 2026-09-28 lo confirma) | acta de constitución; informe de avance |
| Autoridad declarada | No está. El acta no dice qué puede decidir el gerente ni hasta qué monto o plazo. | acta de constitución |
| Comité | Consejo de Administración. Aprobó el presupuesto el 2025-12-12. En la sesión del 2026-10-15 constan solo dos asistentes: Lozano y Peña, es decir gerente y patrocinador. | acta; minuta 2026-10-15 |

Otros vacíos del acta: producto asociado «No aplica»; alcance en «Componente 1, 2, 3» sin nombre; fuera de alcance «lo que otro proyecto cubre» sin nombrar el proyecto; dependencias «Ninguna declarada»; objetivo «Entregar motor de crédito para Operaciones». Sin autoridad declarada no hay desviación aprobada: lo que existe son fechas y cifras escritas.

### Contra el plan
- **Línea base original (v1):** aprobada el 2025-12-12 por el Consejo de Administración. Inicio 2025-12-22, cierre 2026-08-05. Fuente: acta y `cronograma-v1.csv`.
- **Vigente:** igual a la original. Replanificaciones: 0. Solicitudes de cambio en la carpeta: 0. Desviación del cierre contra original y contra vigente: 0 días.
- Ese 0 solo prueba que nadie escribió una fecha nueva. No prueba que el plan se haya cumplido, porque el cronograma que lo respalda no tiene evidencia (ver abajo).
- **Cronograma sin fecha propia:** el archivo está fechado 2025-12-12 y marca como «cerrado» hitos de hasta 2026-08-05. O se editó después sin dejar versión, o el estado se escribió por anticipado. Con lo que hay en la carpeta no se puede saber cuál de las dos.
- **Avance contra plan:** declarado 31 %. Con 5 de 5 hitos cerrados el plan sostiene 100 %. Brecha: 69 puntos.

### Hitos vencidos sin evidencia
Los cinco figuran «cerrado» en el cronograma y ninguno tiene un documento que lo respalde.

| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Diseño funcional aprobado | 2026-02-05 | 254 | Acta o aprobación firmada del diseño funcional |
| Ambiente de pruebas certificado | 2026-03-22 | 209 | Certificado o acta de certificación del ambiente |
| Integración con el core cooperativo | 2026-05-06 | 164 | Acta o informe de pruebas de integración |
| Piloto con asociados | 2026-06-21 | 118 | Informe de resultados del piloto y acta de cierre. El informe del 2026-09-28 sugiere que no ocurrió. |
| Salida a producción | 2026-08-05 | 73 | Acta de paso a producción o registro del despliegue |

Entregable del proveedor vencido: «Bolsa de horas de desarrollo» (CT-314), pactada para el 2026-06-06, 133 días. El contrato la marca «en curso». Se esperaría un acta de recibo o el registro de horas.

### Dinero
Cifras en COP. Aprobado viene del acta. Comprometido, ejecutado y proyección vienen solo del informe de avance, o sea que son declaradas y la carpeta no las respalda con ningún soporte contable.

| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 5.624.497.293 (59,2 % del aprobado) | 2.042.116.829 (21,5 % del aprobado) | 9.766.333.561 (2,8 % sobre el aprobado) | 3.875.502.707 |

- La proyección supera lo aprobado en 2,8 %, por debajo del umbral de 10 %, pero sin solicitud de cambio ni aprobación en la carpeta.
- Ejecutado 21,5 % contra plan que sostiene 100 % y avance declarado 31 %: las tres cifras no se corresponden entre sí.
- **Proveedor Talento Solidario Ltda. (CT-314):** facturado 909.461.374, radicada el 2026-09-18 (FV-1314). Coincide con el monto de un solo entregable, el licenciamiento. El concepto de la factura dice «Entregables» en plural y no nombra cuál. El contrato condiciona el pago a un acta de recibo firmada por el gerente, y esa acta no está en la carpeta.

### Lo que se dijo y nadie registró
No hay registro de riesgos ni de incidencias en la carpeta. Todo lo que sigue está en el informe o en la minuta, sin responsable ni fecha, salvo lo indicado.

- **Incidencia, no riesgo:** «El proveedor no ha confirmado la fecha de la última entrega» (informe) aparece como riesgo, pero la bolsa de horas ya está vencida 133 días. Sin responsable ni fecha.
- **Incidencia:** «El Consejo de Administración pidió ajustar el reglamento antes del piloto» (informe, 2026-09-28). Sin responsable ni fecha. Es además una dependencia no declarada en el acta.
- **Dependencia:** «Se acordó con arquitectura cómo se revisan los requisitos no funcionales» (informe). No hay acta de arquitectura, persona ni fecha.
- **Compromisos de la minuta del 2026-10-15:**
  - María Restrepo, «Entregar el punto 13», para 2026-11-07. Abierto.
  - Ricardo Salas, «Entregar el punto 32», para 2026-10-15. **Vencido hace 2 días, sin evidencia de entrega.** Se fijó para el mismo día de la sesión.
  - Ninguno de los dos asistió a la sesión. Ningún documento de la carpeta define qué son los puntos 13 y 32.
- **Minuta:** los temas «Avance» y «Compromisos» están enunciados sin contenido. No dice nada del estado, del piloto ni del reglamento.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado Verde | Informe de avance 2026-09-28: «Verde» | Contrato CT-314: bolsa de horas «en curso», vencida el 2026-06-06 (133 días). El mismo informe lista como riesgo la fecha de entrega sin confirmar, y la minuta del 2026-10-15 tiene un compromiso vencido. |
| Avance 31 % | Informe de avance: 31 % | Cronograma v1: 5 de 5 hitos «cerrado» (el plan sostiene 100 %) |
| Piloto con asociados cerrado (2026-06-21) | Cronograma v1: «cerrado» | Informe 2026-09-28: el Consejo pidió ajustar el reglamento «antes del piloto» |
| Salida a producción cerrada (2026-08-05) | Cronograma v1: «cerrado» | Informe 2026-09-28: si el piloto no ocurrió, no hay salida; además el criterio de éxito del acta es «en producción y medido» y el avance declarado es 31 % |

### Sin sustento
Lo que nada contradice y nada respalda:

1. Comprometido, ejecutado y proyección: solo existen en el informe.
2. «Diseño funcional aprobado» cerrado.
3. «Ambiente de pruebas certificado» cerrado.
4. «Integración con el core cooperativo» cerrado.
5. «Licenciamiento del módulo» recibido/aceptado. El contrato lo marca «recibido», pero está firmado el 2025-12-09, tres meses antes de la fecha de entrega (2026-03-15), y no hay acta de recibo.
6. La factura FV-1314 corresponde al licenciamiento y se emitió contra acta de recibo firmada.
7. El acuerdo con arquitectura sobre requisitos no funcionales.
8. Que el Consejo de Administración pidió ajustar el reglamento: lo dice solo el informe. La minuta del 2026-10-15 no lo menciona.

Sostenido, para completar el conteo:
1. Patrocinador, gerente y comité (acta, informe y minuta coinciden).
2. Presupuesto aprobado de 9.500.000.000 COP.
3. Fechas de inicio y cierre del plan (acta y cronograma coinciden).
4. Términos del contrato CT-314: entregables, fechas y montos.
5. Radicación de la factura FV-1314 por 909.461.374 COP el 2026-09-18.

### Lo que esta carpeta no permite saber
- **Si algún hito se cumplió.** Sin actas ni certificados, la cifra de avance real es indeterminada y no se puede decir si el proyecto está atrasado ni cuánto.
- **Si el piloto ocurrió.** Los dos documentos que lo mencionan se contradicen. Todo lo que dependa de él (salida a producción, medición) queda sin base.
- **Cuándo se escribió el estado del cronograma.** Sin fecha ni versión propia, no se puede saber si se cerraron los hitos o si se anotaron por anticipado.
- **Qué se pagó y contra qué.** Sin acta de recibo, no se puede decir si la factura de 909.461.374 COP cumple la condición de pago del contrato.
- **Cuánto dinero se ha gastado de verdad.** Sin soporte contable, el disponible real de 3.875.502.707 COP depende de un comprometido que solo declara el gerente.
- **Qué puede decidir el gerente.** Sin autoridad declarada, no se puede decir si algún cambio de fecha o de monto sería legítimo.
- **Qué hizo el proyecto entre diciembre de 2025 y septiembre de 2026.** No hay documentos en ese periodo, y es donde vencieron los cinco hitos.
- **Si hay dependencias con otros proyectos.** El acta dice «ninguna» y excluye «lo que otro proyecto cubre» sin nombrarlo. El portafolio tiene un proyecto «Core cooperativo» (PRY-202), pero no leí sus documentos para esto y no afirmo relación alguna.

### Después
No recomiendo detener, continuar ni reestructurar: eso lo decide quien tiene la facultad. El dictamen es que **esta carpeta no permite diagnosticar el avance real**. Es un resultado, no una disculpa. Puedo preparar el punto de comité con la lista de lo que falta: actas de hitos, acta de recibo del licenciamiento, soporte contable, autoridad del gerente y aclaración del piloto. También puedo llevar las cuatro contradicciones al gerente, Andrés Lozano, como preguntas, una por una.

---
**Rigor:** todo lo escrito sale de los 6 documentos citados y de la salida de `portafolio.py compute` del 2026-10-17. Las cifras derivadas se copiaron de esa salida. Lo declarado y lo probado se mantienen separados: en esta carpeta no hay ninguna fuente de tipo evidencia, solo declaraciones y documentos sin marcar. Cada dato lleva su fuente y la verificación es de quien lo lee. Nota: el «pie de rigor» no está definido en ningún archivo del plugin; este pie es el que la propia salida sostiene.
