Sale de: las 13 fichas (`estado/records/PRY-199` a `PRY-211`, sección RAID) y, para lo no registrado, las minutas y notas de reunión de la carpeta (PRY-209 notas del 2026-10-17 y comité del 2026-10-10; PRY-211 comité 2026-10-14; PRY-202 comité 2026-10-11; PRY-208 comité 2026-10-15; PRY-201 comité 2026-10-04; PRY-199 comité 2026-10-13). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Escala de valoración: la organización no define una; se usaría alta/media/baja, pero ningún ítem trae probabilidad ni impacto, así que no se inventan.

## RAID — portafolio al 2026-10-17
15 riesgos · 0 supuestos · 16 incidencias · 0 dependencias (registradas)
31 sin doliente · 0 sin movimiento medible · 1 no registrado formalmente

Lo que pasa en el registro: **ningún ítem tiene doliente y ningún riesgo tiene fecha**. Las 13 actas de constitución declaran "Ninguna declarada" en dependencias, pero el registro está lleno de cosas que son dependencias disfrazadas de riesgo. Por eso aparecen 0 dependencias y 0 supuestos aunque no sea verdad.

### Necesitan decisión ahora
| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| Consejo-reglamento | Incidencia transversal | "El Consejo de Administración pidió ajustar el reglamento antes del piloto": incidencia en PRY-200 (2026-10-13), PRY-202 (10-15), PRY-203 (09-23), PRY-208 (09-28) y PRY-211 (10-05). Además "Aprobación del reglamento por el Consejo" figura como riesgo en PRY-200, 201, 204, 205 y 209 | sin doliente | 2026-09-23 | Afecta a 10 proyectos; la decide un órgano fuera de los proyectos. Es el caso típico de escalamiento: una decisión, no diez gestiones |
| Proveedor-core | Dependencia (registrada como riesgo) | "Dependencia del proveedor del core cooperativo": PRY-199, PRY-200, PRY-211 (informes del 10-15, 10-13 y 10-05) | sin doliente | 2026-10-05 | Afecta a tres proyectos y su doliente es externo |
| Entrega-proveedor | Dependencia (registrada como riesgo) | "El proveedor no ha confirmado la fecha de la última entrega": PRY-199, 202, 203, 206, 208 y 210 | sin doliente | 2026-09-23 (PRY-203, el más antiguo) | Seis proyectos; PRY-203 y PRY-208 lo arrastran desde informes de septiembre, un período más que el resto. No se sabe si es el mismo proveedor |
| Hallazgo-seguridad | Incidencia | "Hallazgo de seguridad en la revisión de arquitectura": PRY-201, 204, 206, 209 | sin doliente | 2026-10-09 | Incidencia ya ocurrida, sin dueño ni fecha de resolución en cuatro proyectos |

### Detectados en reuniones, no registrados
| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| "El proveedor podría no llegar con el equipo completo para la siguiente fase" | Riesgo | PRY-209, notas de reunión (`2026-10-17-notas-reunion.txt`, "nadie lo anotó como riesgo") | 2026-10-17 |

Es el único. En las otras minutas leídas (PRY-211, PRY-202, PRY-208, PRY-201, PRY-199) solo hay tablas de compromisos, ningún riesgo dicho al pasar; no se inventó ninguno. La ficha de PRY-209 ya lo incorpora, pero marcado como no formal: falta que el gerente decida si lo formaliza, y con qué doliente.

### Sin doliente o sin fecha
Todos. No se rellenó ninguno.
| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| 15 riesgos (ver registro) | Riesgo | todos | doliente y fecha |
| 16 incidencias (ver registro) | Incidencia | todas | doliente (la ficha guarda "desde", no fecha de resolución) |

### Reclasificaciones propuestas (no se tocaron las fichas)
| Ítem | Hoy | Propuesto | Por qué |
|---|---|---|---|
| "Dependencia del proveedor del core cooperativo" (PRY-199, 200, 211) | Riesgo | Dependencia | Depende de alguien fuera del proyecto. Debe llevar el código del proyecto del que depende; los documentos solo dicen "proveedor del core", no un código. PRY-202 es "Core cooperativo", pero ningún documento lo afirma: no lo asumo |
| "El proveedor no ha confirmado la fecha de la última entrega" (PRY-199, 202, 203, 206, 208, 210) | Riesgo | Dependencia declarada, sin confirmar | Un tercero entrega y no ha confirmado. Es declarada, no acordada |
| "Aprobación del reglamento por el Consejo" (PRY-200, 201, 204, 205, 209) | Riesgo | Dependencia (del Consejo) | La decide un órgano externo. En PRY-200 además ya ocurrió: la incidencia "pidió ajustar el reglamento" está registrada el mismo día, así que el riesgo quedó duplicado y vencido |
| "Se reprogramó la salida por el cierre contable" (PRY-206, 207) | Incidencia | Se mantiene | Ya ocurrió; solo falta doliente |

### Dependencias en riesgo
| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (ninguna con código) | — | — | No se puede cruzar. Ninguna dependencia lleva el código del proyecto del que depende, y las actas dicen "Ninguna declarada". El cruce de portafolio (B depende de A y A movió la fecha) hoy no se puede hacer; es una brecha de registro, no una ausencia de dependencias |

### Registro completo
Probabilidad e impacto: no registrados en ningún ítem. Doliente: ninguno. Fecha: ninguna en riesgos. "Último movimiento": la ficha solo guarda la fecha del informe donde apareció, no un historial; con eso no puedo decir si hubo o no movimiento en dos períodos, y no lo afirmo.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Fuente / visto |
|---|---|---|---|---|---|---|---|
| PRY-199 | Riesgo | Dependencia del proveedor del core cooperativo | n/d | n/d | — | — | informe 2026-10-15 |
| PRY-199 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-10-15 |
| PRY-199 | Incidencia | Equipo perdió dos semanas por rotación de un desarrollador clave | | | — | desde 2026-10-15 | informe 2026-10-15 |
| PRY-200 | Riesgo | Dependencia del proveedor del core cooperativo | n/d | n/d | — | — | informe 2026-10-13 |
| PRY-200 | Riesgo | Aprobación del reglamento por el Consejo | n/d | n/d | — | — | informe 2026-10-13 |
| PRY-200 | Incidencia | Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-10-13 | informe 2026-10-13 |
| PRY-200 | Incidencia | Pérdida de dos semanas por rotación de desarrollador clave | | | — | desde 2026-10-13 | informe 2026-10-13 |
| PRY-201 | Riesgo | Aprobación del reglamento por el Consejo | n/d | n/d | — | — | informe 2026-10-12 |
| PRY-201 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-12 | informe 2026-10-12 |
| PRY-201 | Incidencia | Pérdida de dos semanas por rotación de desarrollador clave | | | — | desde 2026-10-12 | informe 2026-10-12 |
| PRY-202 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-10-15 |
| PRY-202 | Incidencia | Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-10-15 | informe 2026-10-15 |
| PRY-203 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-09-23 |
| PRY-203 | Incidencia | Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-09-23 | informe 2026-09-23 |
| PRY-204 | Riesgo | Aprobación del reglamento por el Consejo | n/d | n/d | — | — | informe 2026-10-14 |
| PRY-204 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-14 | informe 2026-10-14 |
| PRY-205 | Riesgo | Aprobación del reglamento por el Consejo | n/d | n/d | — | — | informe 2026-10-14 |
| PRY-205 | Incidencia | Pérdida de dos semanas por rotación de desarrollador clave | | | — | desde 2026-10-14 | informe 2026-10-14 |
| PRY-206 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-10-14 |
| PRY-206 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-14 | informe 2026-10-14 |
| PRY-206 | Incidencia | Se reprogramó la salida por el cierre contable | | | — | desde 2026-10-14 | informe 2026-10-14 |
| PRY-207 | Riesgo | Cambio normativo del supervisor que puede mover el alcance | n/d | n/d | — | — | informe 2026-10-12 |
| PRY-207 | Incidencia | Se reprogramó la salida por el cierre contable | | | — | desde 2026-10-12 | informe 2026-10-12 |
| PRY-208 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-09-28 |
| PRY-208 | Incidencia | Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-09-28 | informe 2026-09-28 |
| PRY-209 | Riesgo | Aprobación del reglamento por el Consejo | n/d | n/d | — | — | informe 2026-10-09 |
| PRY-209 | Riesgo (no registrado formalmente) | Proveedor podría no llegar con el equipo completo a la siguiente fase | n/d | n/d | — | — | notas 2026-10-17 |
| PRY-209 | Incidencia | Hallazgo de seguridad en la revisión de arquitectura | | | — | desde 2026-10-09 | informe 2026-10-09 |
| PRY-210 | Riesgo | Proveedor sin confirmar fecha de última entrega | n/d | n/d | — | — | informe 2026-10-09 |
| PRY-210 | Incidencia | Pérdida de dos semanas por rotación de desarrollador clave | | | — | desde 2026-10-09 | informe 2026-10-09 |
| PRY-211 | Riesgo | Dependencia del proveedor del core cooperativo | n/d | n/d | — | — | informe 2026-10-05 |
| PRY-211 | Incidencia | Consejo pidió ajustar el reglamento antes del piloto | | | — | desde 2026-10-05 | informe 2026-10-05 |

### Lo que no sé
- Las mismas frases se repiten palabra por palabra en proyectos distintos (por ejemplo la rotación del desarrollador, en cinco proyectos). No sé si es un mismo hecho real o texto copiado entre informes. Hay que confirmarlo con cada gerente antes de escalar como una sola causa.
- No releí los informes de avance en PDF ni Markdown: trabajé sobre lo que las fichas ya extrajeron de ellos. No leí la minuta de PRY-204 (2026-10-11); una búsqueda de palabras de riesgo sobre ella no devolvió nada, pero no la leí entera.
- No hay historial de movimiento en las fichas, así que "sin movimiento en dos períodos" queda sin evaluar.
- Los ítems de PRY-209 ya tienen historial propio en su `pm_record`; no lo crucé.

### Después
Puedo subir a comité (2026-10-24) el paquete del Consejo (decisión: ¿quién lleva la aprobación del reglamento y para cuándo?), el proveedor del core y el hallazgo de seguridad. Para los 31 ítems sin doliente puedo proponer doliente (no asignarlo) si me indicas los gerentes de cada proyecto; las fichas no los traen en el RAID.

**Pie de rigor:** esto es un borrador de trabajo, no una decisión. Cada dato sale de la ficha o de la minuta citada; la verificación es tuya.
