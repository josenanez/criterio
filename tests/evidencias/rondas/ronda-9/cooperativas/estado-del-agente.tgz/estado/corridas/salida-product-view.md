## Productos al 2026-10-17 — pagos QR

Sale de las fichas en `estado/`, recalculadas hoy con `portafolio.py compute`. Términos vigentes (aceptados por José Francisco Ñáñez el 2026-10-17, versión 0.4.0).

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| pagos QR | 1 (PRY-206) | 0 | 2026-06-26 | COP 4.200.000.000 | COP 1.553.761.322 |

**pagos QR tiene un solo proyecto (PRY-206 Pagos con QR).** La vista por producto no aporta nada más que la ficha del proyecto, así que no armo sección aparte; lo que sigue es lo que el cálculo da sobre ese proyecto.

- **Señales:** ninguna abierta. Sin hitos vencidos, sin hitos cumplidos sin evidencia, sin compromisos vencidos, sin cambios de control sin línea base nueva, sin desviación contra la línea base original ni la vigente (0 días), 0 replanificaciones. Silencio: 3 días.
- **Dependencias internas:** ninguna declarada. Con un solo proyecto no hay cruce posible dentro del producto.
- **Fecha comprometida del producto:** 2026-06-26, sale de PRY-206. Es una fecha anterior al corte (2026-10-17), mientras el informe de avance del 2026-10-14 declara 58 % de avance y estado amarillo. El cálculo no marca ninguna señal por esto, y yo no puedo decir si la fecha está vencida de verdad o si falta registrar una replanificación: lo que sí se ve es que la ficha no tiene ninguna replanificación ni cambio. Es lo primero que hay que preguntarle al gerente del proyecto.
- **Dinero (las cuatro cifras vienen completas, 1 de 1 proyectos):** aprobado COP 4.200.000.000; comprometido COP 1.553.761.322 (37,0 %); ejecutado COP 1.004.189.836 (23,9 %); proyección COP 4.057.601.292, es decir 3,4 % por debajo de lo aprobado; disponible real COP 2.646.238.678.
- **Contratos con proveedores:** la ficha no registra ninguno, así que no hay entregables que contrastar contra lo facturado.

### Lo que la evidencia no sostiene
- De los 15 datos de la ficha con fuente, **0 son evidencia**, 3 son declaración y 12 no están marcados. El 58 % y el amarillo son del gerente; ningún documento los sustenta por separado.
- Faltan `identity.authority` y `identity.phase`.
- 12 campos tienen 12 meses de antigüedad (fuente del 2025-10-03): código, nombre, área, producto, patrocinador, gerente, comité, fechas de inicio y fin, alcance, exclusión y aprobado. El umbral es 12 meses.

### Proyectos sin producto declarado
No entran a ningún producto. Son 5: PRY-202 Core cooperativo, PRY-205 Prevención de lavado de activos, PRY-208 Motor de crédito, PRY-209 Convenios de libranza con empresas, PRY-210 Corresponsales rurales. No leí el área dueña de cada uno porque el cálculo no la entrega y esta consulta era sobre pagos QR. Consecuencia: nadie puede responder por el conjunto al que sirven.

Fuentes: fichas en `estado/records`, cálculo del 2026-10-17. Rigor: cifras copiadas del cálculo; nada estimado. Lo que no sé: si el proyecto sigue vigente después del 2026-06-26, y qué se habló fuera de los documentos.
