Leí 7 documentos de PRY-204, entre 2025-12-29 y 2026-10-14. Términos vigentes (versión 0.4.0, aceptados por José Francisco Ñáñez el 2026-10-17).

## Historia · PRY-204 Tarjeta débito para asociados · 2025-12-29 a 2026-10-14

**Leí:** 7 documentos entre 2025-12-29 y 2026-10-14
**Trimestres sin un solo documento:** 2026-T1, 2026-T2 y 2026-T3. Entre el acta de constitución (2025-12-29) y el primer documento siguiente (2026-10-09) no hay nada.

### En una línea
El proyecto nace el 2025-12-29 con cierre comprometido al 2026-11-04. Después no hay un solo documento durante nueve meses. Entre el 2026-10-09 y el 2026-10-14 aparecen cinco documentos: un recibo, un comité, una solicitud de cambio con la que el cierre pasa al 2027-01-23, un cronograma nuevo y un informe en verde. Todo lo que dice cómo fue el proyecto antes de octubre queda escrito en esa semana.

### Las cuatro cifras
| Replanificaciones | Atraso acumulado vs. original | Meses declarando sin sustento | Cambios de gobierno |
|---|---|---|---|
| 1 | 80 días (26,7 %) | No se puede calcular: hay un solo estado declarado (2026-10-14), no una serie. Dato disponible: el hito «Diseño funcional aprobado» (2026-03-24) lleva 207 días declarado cumplido sin evidencia. | 0 |

### Línea de tiempo
| Fecha | Documento | Qué cambió |
|---|---|---|
| 2025-12-29 | Acta de constitución (.docx) | Nace el proyecto. Presupuesto de 6.800.000.000 COP, inicio 2026-01-08, cierre 2026-11-04. Sandra Gil es patrocinadora y gerente. Comité de Riesgos. |
| 2025-12-29 | Cronograma v1 (.xlsx) | Línea base original. Cuatro hitos, el último («Piloto con asociados») al 2026-11-04. Con fecha de diciembre de 2025, ya marca tres hitos de 2026 como «cerrado». |
| 2026-03-24 a 2026-10-08 | (sin documentos) | Vencen tres hitos, el 2026-03-24, el 2026-06-07 y el 2026-08-21, y no queda ninguna constancia escrita en su fecha. |
| 2026-10-09 | Acta de recibo · Integración con el core | Se recibe a satisfacción la integración. Es la única evidencia de cierre de un hito en toda la carpeta. El cronograma da el hito por cumplido el 2026-08-21. |
| 2026-10-11 | Comité semanal | Asistentes: «Sandra Gil, Sandra Gil». Temas: avance y compromisos. Dos compromisos: Ricardo Salas, 2026-11-04; Liliana Torres, 2026-10-25. No menciona ningún cambio. |
| 2026-10-12 | Solicitud de cambio CC-01 | Ampliación de alcance: +80 días y +160.000.000 COP. «Autorizada por el comité», sin decir cuál ni citar acta. |
| 2026-10-14 | Cronograma v2 (.xlsx) | El cierre pasa del 2026-11-04 al 2027-01-23. La línea base original se conserva. |
| 2026-10-14 | Informe de avance | Estado **verde**, 76 %. Reporta un hallazgo de seguridad sin responsable. Riesgo abierto: aprobación del reglamento por el Consejo de Administración, sin dueño ni fecha. |

### Replanificaciones
| Nº | Fecha | Fecha de cierre nueva | Motivo declarado | Documento que la aprobó |
|---|---|---|---|---|
| 1 | 2026-10-14 (cronograma v2) | 2027-01-23 | CC-01: ampliación de alcance (+80 días, +160.000.000 COP) | CC-01 (2026-10-12): «Autorizada por el comité». No hay acta del comité que la respalde. |

El atraso de 80 días contra la línea base original coincide con lo que CC-01 aprobó, así que no hay atraso sin autorizar (el script da 0 días sin autorización). El motivo es una ampliación de alcance. El alcance del acta son tres «Componentes» sin nombre, así que no se puede saber qué se amplió.

### Gobierno
| Fecha | Qué cambió | Documento |
|---|---|---|
| — | Ningún cambio de patrocinador, gerente o comité en los documentos leídos. Sandra Gil es patrocinadora, gerente, solicitante del cambio y quien recibe el entregable. | Acta de constitución; CC-01; acta de recibo |

Dato que falta: no hay autoridad de aprobación identificada en ningún documento. Tampoco hay fase.

### Compromisos que se repitieron
| Doliente | Qué | Veces | Fechas prometidas |
|---|---|---|---|
| — | Ninguno se repitió. Hay dos compromisos abiertos, ambos del 2026-10-11 y sin reprogramaciones: Ricardo Salas (punto 31, 2026-11-04) y Liliana Torres (punto 19, 2026-10-25). | 1 | — |

Solo hay un acta de comité, así que la ausencia de repeticiones no dice nada sobre los nueve meses anteriores.

### Desde cuándo lo declarado no se sostiene
**Desde el 2026-03-24**, fecha del primer hito, «Diseño funcional aprobado», que el cronograma da por cumplido sin evidencia. Lo mismo vale para «Ambiente de pruebas certificado» (2026-06-07). Son 207 y 132 días hasta hoy.

El único hito con evidencia es la integración con el core (acta de recibo del 2026-10-09). Quedó escrita 49 días después de la fecha en que el cronograma lo da por cumplido (2026-08-21), cifra que calculé a mano y no sale del script.

Lo que se siguió reportando: el 2026-10-14 el estado es **verde**, 76 %, con los dos hitos sin evidencia y 80 días de atraso contra la línea base original. El informe no menciona ninguna de las dos señales. Las alertas que el script marca son tres: atraso sobre el original, hito cumplido sin evidencia (×2) y estado declarado en contradicción con la evidencia.

### Lecciones ancladas a un hecho
1. **Un hito se cierra con un documento en su fecha.** Hecho: «Diseño funcional aprobado» (2026-03-24) y «Ambiente de pruebas certificado» (2026-06-07) figuran como cerrados sin ningún documento. Efecto: 207 y 132 días después no hay con qué sostener el 76 % declarado.
2. **Un cambio autorizado por «el comité» necesita el acta de ese comité.** Hecho: CC-01 (2026-10-12) cita la autorización, y el único comité en la carpeta (2026-10-11) es anterior, no trata el cambio y tiene un solo asistente registrado. Efecto: +80 días y +160.000.000 COP aprobados sin trazabilidad.
3. **La fecha del archivo debe coincidir con lo que dice dentro.** Hecho: el cronograma v1, con fecha 2025-12-29, marca como «cerrado» hitos que vencen entre marzo y agosto de 2026. Efecto: no se puede confiar en que v1 sea la línea base original sin cambios.

## Lo que no sé
- Qué pasó entre 2026-01 y 2026-09: no hay documentos.
- Si existió un comité que aprobó CC-01 y quiénes asistieron.
- Qué se amplió con CC-01.
- Si el presupuesto aprobado cambió con los 160.000.000 COP: el último total en los documentos sigue siendo 6.800.000.000 COP.
- Quién es el dueño del hallazgo de seguridad y del riesgo del reglamento.

## Pie de rigor
Todo sale de los 7 documentos citados y del cálculo del script (`compute`, 2026-10-17). No atribuyo intención: lo que vemos es que casi todo quedó escrito en una semana, y por qué pasó es una conversación para tener con Sandra Gil con estos datos. Las cifras vienen del script, salvo los 49 días del acta de recibo, que calculé a mano. La verificación es suya.

Puedo llevar esta historia al cierre del proyecto o a un comité donde haya una decisión que tomar. Ofrezco el comité del 2026-10-24.
