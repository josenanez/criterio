# Corrida del 2026-10-17 · portfolio-server

13 proyectos · 52 hallazgos

> El tiempo no se midió: faltó `corrida-inicio` al arrancar. Un tiempo escrito a mano es un recuerdo, no una medición.

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

puerto 8787, informe en reportes/ (HTML del 2026-10-17), modo rato

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Rostrum — para mirarlo un rato

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hay que volver a mostrarlos.

Pregunta de modo: «¿para mirarlo un rato o que quede corriendo?». Respuesta recibida: **rato**. Es el camino que se levanta en diez segundos y no pide nada a seguridad.

Hay informe en `reportes/` (HTML, generado el 2026-10-17 20:51: portada, proyectos PRY-199 a PRY-211, decisiones, productos). El servidor no lo genera, lo sirve.

## Comando

```
python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe /home/claude/banco/ronda-9/cooperativas/espacio/reportes --estado /home/claude/banco/ronda-9/cooperativas/espacio/estado --config /home/claude/banco/ronda-9/cooperativas/espacio/.criterio/portafolio/config.json
```

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`. El portal lleva el nombre «Cooperativa» en todas las páginas.

## Qué hay y a quién le sirve

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita una decisión, con la consecuencia de no decidirla | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a los proyectos que lo construyen | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El enlace proyecto ↔ producto va en los dos sentidos: quien entra por el producto puede descubrir que lo construyen proyectos que reportan a comités distintos.

## Lo que Rostrum no hace

- No calcula: sirve lo que ya escribió `informe.py`; abrir una página no lee documentos.
- No escribe fichas: lo único que crea es la petición, en `estado/peticiones/`.
- No autentica. (Solo importa si algún día se usa `--abierto`.)
- No manda correos ni notificaciones.

## Peticiones

El formulario de la portada deja la petición en `estado/peticiones/` y ahí queda hasta que el agente despierte; `due` las cuenta y una petición abierta rompe el silencio de `/portfolio-wake`. Se marca respondida con `portafolio.py answered`.

## Cierre

- El enlace para mirarlo es `http://127.0.0.1:8787/`; solo sirve en este equipo, así que no se le puede pasar a un patrocinador. Para eso haría falta «que quede corriendo» (host, puerto y control de acceso de la organización), que es una conversación aparte.
- El informe es del 2026-10-17. Con barrido diario configurado, queda desactualizado desde mañana; el comité semanal siguiente es el 2026-10-24, así que conviene regenerarlo antes (`/portfolio-report html`) y la portada indica su fecha.
