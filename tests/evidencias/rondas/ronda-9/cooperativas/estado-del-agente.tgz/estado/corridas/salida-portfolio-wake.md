## 2026-10-17

**Revisé:** 67 documentos · 0 cambiaron · 0 proyectos recalculados (no se corrió `/portfolio-scan`: no hay nada que releer). Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo. Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Es el primer barrido (`sweep` sin corrida previa), así que no hay referencia de ayer: lo que sigue es lo que hoy está sobre el umbral, no lo que cambió. Cifras de `compute`; cada señal trae su cita en la ficha del proyecto.

- **PRY-202 Core cooperativo:** costo proyectado 1.498.158.438 contra 1.200.000.000 aprobados (+24,8 %, umbral 10 %). Declara verde con 4 señales en contra, entre ellas un compromiso vencido hace 7 días (Natalia Ospina, «Entregar el punto 23», comité del 2026-10-11).
- **PRY-210 Corresponsales rurales:** costo proyectado 11.281.920.391 contra 9.500.000.000 (+18,8 %). Declara verde.
- **PRY-204 Tarjeta débito:** 80 días de atraso contra la línea base original (26,7 %). Declara verde.
- **PRY-201 Apertura de ahorro en línea:** el proveedor Integración Financiera del Sur tiene facturado 561.870.991 y aceptado 444.534.224: 117.336.767 facturados sin aceptación.
- **PRY-203 Aportes sociales en línea:** 24 días en silencio (desde 2026-09-23; umbral 15). Declara verde.
- **PRY-208 Motor de crédito:** declara 31 % de avance con 5 de 5 hitos «cumplidos» sin evidencia; entregable del proveedor Talento Solidario vencido hace 133 días.
- **PRY-209 Convenios de libranza:** 5 compromisos vencidos, 4 sin fecha y 3 reprogramados (uno 6 veces: Jorge Medina, «Cerrar la prueba 2»).
- **Hitos «cumplidos» sin evidencia de recibo** en PRY-201, 202, 203, 204, 208, 210 y 211.

### Hallazgo de la carpeta
`index` reporta 15 citas que no resuelven, todas de PRY-209 y todas en `pm_record.*` (la ficha que publica el gerente, `00-gobierno/ficha-pm.json`). Los archivos citados existen en la carpeta del proyecto: la ruta está escrita relativa al proyecto y el índice la busca desde la raíz de documentos. Parece un problema de cómo se escribió la ruta, no de documentos faltantes. No lo corregí: no es mi ficha y no la reescribo. Queda como hallazgo.

### Peticiones atendidas
Ninguna.

### Preguntas
Nadie responde en esta corrida; quedan preguntadas hoy y no se repiten. Una por campo, cinco en total:

1. **PRY-202 · presupuesto:** ¿hay un cambio aprobado que explique la proyección de 1.498 M contra 1.200 M? Dato actual: informe de avance del 2026-10-15.
2. **PRY-210 · presupuesto:** ¿la proyección de 11.282 M tiene aprobación? Dato actual: informe de avance del 2026-10-09.
3. **PRY-204 · fecha de fin:** ¿la línea base se movió con aprobación? Hoy el atraso es de 80 días contra la original. Dato actual: informe de avance del 2026-10-14.
4. **PRY-201 · facturación del proveedor:** ¿existe acta de recibo que cubra los 117 M facturados por encima de lo aceptado?
5. **PRY-203 · estado:** ¿sigue en marcha? Último documento: 2026-09-23.

**Vuelvo el 2026-10-18.**
