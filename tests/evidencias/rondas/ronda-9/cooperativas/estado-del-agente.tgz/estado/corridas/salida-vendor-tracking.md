**Sale de:** contrato CT-894 (2025-12-10), acta de constitución (2025-12-12), cronograma v1, actas de recibo del 2026-04-16 y del 2026-08-11, factura FV-1894 (2026-08-29), informe de avance (2026-10-12), acta del comité semanal (2026-10-04), y el cálculo de `portafolio.py compute` al 2026-10-17.

## Proveedores — PRY-201 Apertura de ahorro en línea al 2026-10-17

### Integración Financiera del Sur — contrato CT-894
**Vigencia:** sin dato (el contrato no declara inicio ni fin) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato
**Firma:** 2025-12-10. **Condición de pago:** cada entregable se factura contra acta de recibo firmada por el gerente del proyecto (contrato CT-894).

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del módulo (222.267.112 COP) | 2026-04-09 | Aceptado | Acta de recibo 2026-04-16, recibido por Mauricio Pérez | Dentro de FV-1894, sin desglose |
| Bolsa de horas de desarrollo (222.267.112 COP) | 2026-07-27 | Aceptado | Acta de recibo 2026-08-11, recibido por Mauricio Pérez | Dentro de FV-1894, sin desglose |
| Parametrización de líneas de crédito (222.267.112 COP) | 2026-11-12 | Pendiente, aún no vence | Ninguna (no se espera todavía) | No debería estar facturado |

Cifras del cálculo: 3 entregables, 2 aceptados, 0 atrasados, 0 aceptados sin evidencia. Aceptado: 444.534.224 COP. Facturado: 561.870.991 COP.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Facturado contra aceptado | Se factura cada entregable contra su acta de recibo | Facturado 561.870.991 COP, aceptado 444.534.224 COP: **117.336.767 COP facturados sin acta que los respalde** (señal `vendor_invoiced_over_accepted`, montos declarados 3 de 3) | Contrato CT-894; actas de recibo 2026-04-16 y 2026-08-11; factura FV-1894 |
| Concepto de la factura | Un entregable por acta | La factura dice «Entregables del contrato CT-894», sin decir cuáles. No se puede saber qué cubre el excedente | Factura FV-1894 |

La factura es del 2026-08-29, posterior a las dos actas, y está radicada en cuentas por pagar. Con lo que hay en la carpeta no se puede afirmar si la parte sin respaldo ya se pagó; el documento solo dice que está radicada.

### Sin evidencia de recibo
Ninguno. Los dos entregables aceptados tienen acta de recibo firmada por el gerente.

### Compromisos del proveedor vencidos
Ninguno. El único compromiso de la reunión del 2026-10-04 es «Entregar el punto 22», de Andrés Lozano, para el 2026-11-01. No vence, y el acta no dice a qué organización pertenece Andrés Lozano ni qué es el «punto 22», así que no se puede atribuir al proveedor.

### Sin dato
- **Vigencia, renovación automática y preaviso del contrato CT-894:** el contrato no los trae. No se puede decir si hay un preaviso que venza antes del cierre del proyecto (2027-01-20).
- **Desglose de la factura FV-1894:** no dice qué entregables cubre.
- **Pago efectivo:** no hay comprobante de pago; solo la radicación.
- **Valor total del contrato:** el contrato no lo declara aparte de los tres montos por entregable.

### Contexto, fuera del cruce del proveedor
El informe de avance declara 22 % y amarillo. El cálculo marca que el plan sustenta entre 60 % y 80 % (brecha de 38 puntos), y que tres hitos figuran cumplidos sin evidencia (Diseño funcional aprobado, Ambiente de pruebas certificado, Integración con el core cooperativo). Eso es de `/status-report`, pero afecta a este proveedor: el informe no menciona la diferencia de facturación.

## Después
No hay preaviso que vigilar porque el contrato no lo declara; conviene pedir el texto completo del contrato. Hay 117.336.767 COP facturados sin evidencia de aceptación: **ofrezco llevarlo a comité** (el próximo es el 2026-10-24) con una pregunta cerrada: ¿se retiene o se corrige FV-1894 hasta que el proveedor la desglose contra actas?

*Rigor: cifras copiadas del cálculo del 2026-10-17; cada línea cita su documento; lo que no está en la carpeta figura como sin dato. Es un borrador de trabajo: la verificación contra los originales es suya.*
