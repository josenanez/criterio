# Corrida del 2026-10-17 · steering-pack

13 proyectos · 112 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Paquete de comité 2026-10-24: 7 decisiones, 3 escalamientos. No hay acta de comité anterior, así que no se cerró el ciclo. Trabajé sobre fichas y compute; no releí los originales salvo CC-01 de PRY-207 y un acta de PRY-202. Sin dato: autoridad de aprobación en los 13 proyectos, quién decide CC-01, y si lo facturado en PRY-201 ya se pagó.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Fichas cargadas:** 13 fichas de proyecto (PRY-199 a PRY-211), todas con fecha de ficha 2026-10-17, más la foto del portafolio `estado/snapshots/2026-10-17.json`. Cifras recalculadas con `portafolio.py compute` el 2026-10-17. Términos v1.1 vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

# Comité de proyectos — 2026-10-24
7 decisiones · 3 escalamientos · 8 proyectos con hallazgos (52 señales en total)

## Decisiones del comité anterior
No hay registro de un comité anterior en las fichas, en `estado/corridas/` ni en las minutas de la carpeta. No se puede cerrar el ciclo: no sé qué se decidió ni qué quedó abierto. Si hubo comité, falta el acta.

## Decisiones de hoy

### [1] ¿Quién tiene la facultad de aprobar cambios de línea base y escalamientos en cada proyecto?
**Proyecto:** los 13 · **Quién decide:** el propio comité; en ningún documento está dicho quién aprueba. Es el primer punto porque los puntos 2 a 6 dependen de él. · **Si no se decide hoy:** CC-01 de PRY-207 y cualquier cambio posterior se aprobarían sin facultad demostrable.

Las 13 fichas tienen `identity.authority` sin dato. Las actas nombran un comité (por ejemplo, el Consejo de Administración aprobó la línea base de PRY-207 el 2026-05-22), pero ninguna dice hasta qué monto o cuántos días puede aprobar cada instancia.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Fijar hoy una matriz de facultades por proyecto y registrarla en cada acta | Sin cambio | Una sesión | Sin costo directo |
| B. Mantener la práctica actual y decidir caso por caso | Sin cambio | Sin cambio | Riesgo de aprobar sin facultad (no cuantificable con los documentos) |

**Recomendación:** A. Sin matriz, el resto de las decisiones queda sin sustento formal.

### [2] ¿Se aprueba la solicitud de cambio CC-01 de PRY-207 (ampliación de alcance)?
**Proyecto:** PRY-207 Microcrédito rural (declarado rojo, 83 %) · **Quién decide:** sin determinar. La solicitud dice «pendiente de presentación al comité» sin nombrarlo, y la ficha no tiene quién decide (`decided_by` sin dato). Depende del punto 1. · **Si no se decide hoy:** sigue pendiente desde el 2026-10-05, y la ficha ya registra que se reprogramó la salida.
Fuente: `PRY-207-microcrédito-rural/20-seguimiento/2026-10-05-solicitud-cambio-cc-01.md`.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar | Ampliado (la solicitud no dice qué se agrega) | +110 días sobre la línea base vigente (fin vigente 2027-05-16) | +220.000.000 COP sobre 4.200.000.000 COP aprobados |
| B. Rechazar | Sin cambio | Sin cambio | Sin cambio |
| C. Diferir hasta que la solicitud describa el alcance agregado y tenga doliente | Sin cambio por ahora | Sin cambio | Sin cambio |

**Recomendación:** C. La solicitud no dice qué componente crece (el acta solo nombra «Componente 1, 2 y 3») ni quién la decide. Aprobar +110 días y 220.000.000 COP sobre ese texto no tiene sustento. Tampoco hay sustento para rechazarla: el riesgo registrado, un cambio normativo del supervisor que puede mover el alcance, no tiene doliente. Si se aprueba, la línea base nueva se agrega sin borrar la anterior.

### [3] PRY-202 Core cooperativo: ¿qué se hace con el sobrecosto proyectado?
**Proyecto:** PRY-202 (declarado verde el 2026-10-15) · **Quién decide:** sin determinar (punto 1) · **Si no se decide hoy:** el fin vigente es 2026-12-15 y el sobrecosto sigue sin dueño.

Proyección 1.498.158.438 COP contra 1.200.000.000 COP aprobados (24,8 % sobre lo aprobado). Avance declarado 55 %, y el plan sostiene entre 75 % y 100 %. El hito «Integración con el core cooperativo» (vencido el 2026-09-10) figura cumplido sin acta de recibo. Hay un compromiso vencido hace 7 días (Natalia Ospina, «Entregar el punto 23»).

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir plan de recuperación y reporte corregido para el próximo comité, sin tocar presupuesto | Sin cambio | Fin 2026-12-15 en riesgo, sin cuantificar | Sobrecosto proyectado sin cubrir |
| B. Ampliar el presupuesto hasta la proyección | Sin cambio | Sin cambio | Hasta 1.498.158.438 COP |
| C. Recortar alcance para ceñirse a 1.200.000.000 COP | Reducido (no sé qué) | Sin cambio | Dentro de lo aprobado |

**Recomendación:** A. La proyección y el avance son declaraciones del gerente, y el verde está contradicho por cuatro señales. Ampliar presupuesto o recortar alcance sobre esas cifras sería decidir sobre números sin verificar.

### [4] PRY-210 Corresponsales rurales: ¿qué se hace con el sobrecosto proyectado?
**Proyecto:** PRY-210 (declarado verde el 2026-10-09) · **Quién decide:** sin determinar (punto 1) · **Si no se decide hoy:** el proyecto termina el 2026-11-14 con el sobrecosto sin decidir.

Proyección 11.281.920.391 COP contra 9.500.000.000 COP aprobados (18,8 % sobre lo aprobado). Avance declarado 59 %, y el plan sostiene entre 75 % y 100 %. Tres hitos figuran cumplidos sin acta de recibo.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir plan de recuperación y reporte corregido en una semana, sin tocar presupuesto | Sin cambio | Fin 2026-11-14 en riesgo, sin cuantificar | Sobrecosto proyectado sin cubrir |
| B. Ampliar el presupuesto hasta la proyección | Sin cambio | Sin cambio | Hasta 11.281.920.391 COP |
| C. Recortar alcance para ceñirse a 9.500.000.000 COP | Reducido (no sé qué) | Sin cambio | Dentro de lo aprobado |

**Recomendación:** A, con plazo de una semana: el fin vigente es 2026-11-14, así que este proyecto no puede esperar dos comités.

### [5] PRY-201 Apertura de ahorro en línea: ¿se autoriza pagar lo facturado por encima de lo aceptado?
**Proyecto:** PRY-201 · **Quién decide:** sin determinar (punto 1) · **Si no se decide hoy:** la diferencia queda facturada sin que el comité haya dicho si se paga.
Fuentes: contrato CT-894, `2026-08-29-factura-ct-894.pdf`, actas de recibo del 2026-04-16 y del 2026-08-11.

Facturado 561.870.991 COP; aceptado 444.534.224 COP en actas (2 de 3 entregables). Diferencia 117.336.767 COP. Los documentos muestran lo facturado, no lo pagado. No sé si ya se pagó.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Retener la diferencia hasta que el tercer entregable tenga acta de recibo | Sin cambio | Posible fricción con el proveedor (no documentada) | 117.336.767 COP sin desembolsar |
| B. Pagar el total facturado | Sin cambio | Sin cambio | 117.336.767 COP pagados sin aceptación |
| C. Pagar solo lo aceptado y pedir nota crédito por la diferencia | Sin cambio | Sin cambio | 444.534.224 COP |

**Recomendación:** A (o C si ya se pagó): lo facturado por encima de lo aceptado no tiene acta de recibo. Además, la declaración amarilla del 2026-10-12 no menciona esta señal.

### [6] ¿Se exige replanificación formal a los proyectos cuyo fin vigente ya pasó sin estar terminados?
**Proyecto:** PRY-203, PRY-205, PRY-206, PRY-208 · **Quién decide:** sin determinar (punto 1) · **Si no se decide hoy:** siguen con una fecha vencida y sin solicitud de cambio, y la línea base no refleja la realidad.

| Proyecto | Fin vigente | Avance declarado | Estado declarado | Cambios / replanificaciones |
|---|---|---|---|---|
| PRY-206 Pagos con QR | 2026-06-26 | 58 % | amarillo | 0 / 0 |
| PRY-203 Aportes sociales | 2026-07-07 | 57 % | verde (informe del 2026-09-23, 24 días sin movimiento) | 0 / 0 |
| PRY-205 Prevención de lavado | 2026-07-11 | 74 % | amarillo | 0 / 0 |
| PRY-208 Motor de crédito | 2026-08-05 | 31 % | verde (informe del 2026-09-28) | 0 / 0 |

Esta lectura es mía: `compute` no la marca como señal (no hay hito vencido, porque los hitos figuran como cumplidos). Sale de comparar el fin vigente con la fecha de hoy y el avance declarado.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Exigir solicitud de cambio con nueva fecha y línea base nueva en 10 días | A confirmar por proyecto | Fechas nuevas, hoy desconocidas | Por confirmar |
| B. Aceptar la fecha vencida como está | Sin cambio | Sin cambio | Sin cambio, con línea base sin sentido |

**Recomendación:** A. Una línea base vencida impide medir desviación. PRY-203 y PRY-208 declaran verde con fechas vencidas.

### [7] ¿Un hito cuenta como cumplido solo con acta de recibo?
**Proyecto:** PRY-201 (3 hitos), PRY-202 (1), PRY-203 (3), PRY-204 (2), PRY-208 (5), PRY-210 (3), PRY-211 (2) · **Quién decide:** el comité, como regla de gobierno · **Si no se decide hoy:** seis proyectos siguen en verde con señales abiertas (202, 203, 204, 208, 210, 211).

En esos siete proyectos, hitos declarados cumplidos no tienen acta de recibo en la carpeta. PRY-199 y PRY-209 sí traen actas y no tienen esta señal.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Regla: sin acta de recibo, el hito vuelve a pendiente | Sin cambio | Avances declarados bajarían; no cuantificable | Esfuerzo de gerentes para conseguir actas |
| B. Mantener la declaración del gerente | Sin cambio | Sin cambio | Estados no verificables |

**Recomendación:** A. Con 19 hitos sin acta en 7 proyectos, el avance declarado no se puede contrastar con nada.

## Escalamientos sin decisión asociada
| Proyecto | Qué | Desde cuándo | Qué se necesita |
|---|---|---|---|
| PRY-209 Convenios de libranza | 5 compromisos vencidos (el más viejo: Camilo Beltrán, «Entregar el punto 8», 16 días); 4 sin fecha; 3 reprogramados (Jorge Medina, «Cerrar la prueba 2», 6 veces, de 2026-09-18 a 2026-12-06) | Primer vencimiento 2026-10-01 | Que el sponsor revise por qué los mismos compromisos se mueven reunión tras reunión y reasigne o recorte |
| PRY-208 Motor de crédito | Proveedor Talento Solidario Ltda. (CT-314): «Bolsa de horas de desarrollo» pendiente, 133 días de atraso (vencía 2026-06-06). «Licenciamiento del módulo» aceptado sin acta. Facturado igual a lo aceptado: 909.461.374 COP | 2026-06-06 | Reclamar al proveedor y conseguir acta de recibo del licenciamiento. Compromiso de Ricardo Salas vencido hace 2 días |
| PRY-202 Core cooperativo | Compromiso de Natalia Ospina vencido hace 7 días | 2026-10-10 | Confirmar entrega o fecha nueva (ver punto 3) |

## Para conocimiento
- PRY-199 Cambio de mobiliario de agencias: verde, 20 %, sin señales.
- PRY-200 Crédito de libranza digital: amarillo, 84 %, sin señales; campos de la ficha con 12 meses de antigüedad.
- PRY-204 Tarjeta débito: verde, 76 %; atraso de 80 días (26,7 %) frente a la línea base original, ya aprobado y con línea base movida; dos hitos sin acta (punto 7).
- PRY-211 Cobranza digital: verde, 78 %; dos hitos sin acta (punto 7).
- PRY-203 y PRY-208: ver puntos 6 y 7. PRY-205 y PRY-206: ver punto 6.
- PRY-207: ver punto 2. PRY-209: ver escalamientos.

## Anexo
**Estado de cada proyecto** (de `compute`, 2026-10-17)

| Proyecto | Declarado | Avance | Días sin movimiento | Señales |
|---|---|---|---|---|
| PRY-199 | verde | 20 % | 2 | 0 |
| PRY-200 | amarillo | 84 % | 4 | 0 |
| PRY-201 | amarillo | 22 % | 5 | 5 |
| PRY-202 | verde | 55 % | 0 | 5 |
| PRY-203 | verde | 57 % | 24 | 6 |
| PRY-204 | verde | 76 % | 3 | 4 |
| PRY-205 | amarillo | 74 % | 3 | 0 |
| PRY-206 | amarillo | 58 % | 3 | 0 |
| PRY-207 | rojo | 83 % | 5 | 0 |
| PRY-208 | verde | 31 % | 2 | 10 |
| PRY-209 | amarillo | 24 % | 0 | 12 |
| PRY-210 | verde | 59 % | 8 | 7 |
| PRY-211 | verde | 78 % | 3 | 3 |

**Contradicciones abiertas entre documentos:** ninguna registrada en las fichas. Sí hay 6 proyectos declarados en verde con señales abiertas.

**Vacíos de información**
- `identity.authority` y `identity.phase`: sin dato en los 13.
- `identity.product`: sin dato en PRY-202, 205, 208, 209 y 210.
- Ninguna ficha tiene campos marcados como evidencia: todo viene de declaraciones o sin marcar.
- Ejecutado mayor que comprometido en PRY-201, 202, 203, 205 y 210. No lo resuelvo: puede ser un error de captura en los informes o una definición distinta de «comprometido».
- Campos con 12 meses o más de antigüedad: PRY-200 (12), PRY-205 (16), PRY-206 (12), PRY-210 (14).
- PRY-199: facturación del proveedor CT-199 sin dato.
- PRY-207: quién decidió CC-01, sin dato.
- La carpeta no trae cronograma de PRY-207 (la fecha vigente sale del acta) ni acta de comité anterior.

---
Pie: criterio-portfolio 0.4.0 · términos v1.1 (`TERMS.es.md`) · fichas aplicadas: las 13 de `estado/records/` (2026-10-17). No releí los documentos originales: trabajé sobre las fichas y `compute`, y solo abrí la solicitud CC-01 de PRY-207 y el acta de recibo de PRY-202. Campos inciertos: los listados en Vacíos de información. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

Una vez el comité sesione, puedo registrar las decisiones en las fichas. Hoy no registro ninguna: todavía no hay decisión tomada.
