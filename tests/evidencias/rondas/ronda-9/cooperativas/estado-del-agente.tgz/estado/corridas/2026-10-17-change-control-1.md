# Corrida del 2026-10-17 · change-control

13 proyectos · 33 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

Solicitud PRY-201 +30 días: sin dependientes en el portafolio, sin autoridad declarada en el acta; no se supo quién pide, motivo, costo ni si CT-894 cubre febrero; ejecutado > comprometido señalado.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Sale de la ficha PRY-201 (`estado/records/PRY-201.json`, actualizada 2026-10-17).

## Solicitud de cambio — PRY-201 Apertura de ahorro en línea — 2026-10-17

**Qué se pide:** mover la salida a producción 30 días (2027-01-20 → 2027-02-19). · **Quién lo pide:** no consta en ningún documento ni en la solicitud. · **Por qué:** no se dio motivo. El informe del 2026-10-12 registra, sin vincularlos a este pedido, un hallazgo de seguridad en la revisión de arquitectura y dos semanas perdidas por rotación de un desarrollador clave.

**Línea base vigente:** v1, aprobada el 2025-12-12 por el Comité de Riesgos, cierre 2027-01-20, 3.300.000.000 COP (acta de constitución y cronograma-v1.csv). Es la única; no hay replanificaciones ni cambios aprobados registrados (`changes` vacío). Con este cambio sería la primera.

### Impacto
| Dimensión | Hoy | Con el cambio | Diferencia |
| Alcance | Tres componentes sin nombrar (acta) | Sin declarar | No se pide cambio de alcance. El alcance del acta no tiene nombres, así que no se puede verificar que no cambie. |
| Tiempo | Salida a producción y cierre 2027-01-20 | 2027-02-19 | +30 días (+~8 % sobre los ~395 días de la línea base) |
| Costo | 3.300.000.000 aprobado; proyección declarada 3.089.208.729 | Sin declarar | No hay impacto de costo declarado. |

**Quién absorbe lo que no se declaró:** treinta días más de equipo, patrocinio y soporte del proveedor no son gratis. Si el costo queda en cero, alguien lo absorbe en horas no pagadas o en calidad. Hay que pedir el costo de la extensión al gerente (Mauricio Pérez) antes de decidir. No lo estimo: no hay tarifa ni plan de recursos en la carpeta.

**Dato que pesa sobre el costo:** el informe del 2026-10-12 declara ejecutado (1.614.863.025) mayor que comprometido (1.445.061.642). Ejecutado no debería superar a lo comprometido; eso hay que aclararlo antes de fiarse de la proyección de 3.089.208.729. Con 22 % de avance declarado y 49 % del aprobado ejecutado, la proyección merece contraste.

### Efecto en el portafolio
| Proyecto afectado | Cómo | Gerente |
| Ninguno | El cálculo (`impact`) no encuentra proyectos que dependan de PRY-201: 0 directos, 0 indirectos, 0 que no puedan sostener su fecha, 0 dependencias sin confirmar. | — |

Esto sale de que PRY-201 declara «Ninguna dependencia» y de que ninguna otra ficha lo cita. **No prueba que no haya efecto**: el acta excluye «lo que otro proyecto cubre» sin nombrar el proyecto, y la carpeta no dice cuál es. Si existe una dependencia real, está sin declarar.

Hitos por los que pasa el cambio: Piloto con asociados (2026-11-02, a 16 días) y Salida a producción (2027-01-20, a 95 días). **No sé** si el piloto se mueve también: eso necesita holgura por actividad, que la ficha no tiene. Tampoco cuántos días se mueve cada hito intermedio.

**Proveedor (CT-894, Integración Financiera del Sur):** queda un entregable pendiente, Parametrización de líneas de crédito, 2026-11-12, 222.267.112 COP. El contrato de la carpeta no trae fecha de terminación ni cláusula de prórroga, así que no sé si el proveedor cubre hasta el 2027-02-19. Hay que preguntarlo.

### Quién decide
**Autoridad requerida:** no se puede determinar. El campo de autoridad (`identity.authority`) no aparece en ningún documento: el acta no dice quién puede aprobar cambios de fecha, ni umbrales. Ese es el hallazgo de fondo. · **Según:** acta de constitución 2025-12-12, sin cláusula de autoridad. · **Va a comité:** sí, por defecto. El comité declarado es el Comité de Riesgos (que aprobó la línea base v1) y, a falta de autoridad escrita, no hay base para que el gerente lo apruebe solo. Patrocinador: Felipe Arango.

### Si no se aprueba
El proyecto sigue con cierre 2027-01-20 y 22 % de avance declarado al 2026-10-12, en amarillo, con un hallazgo de seguridad abierto sin dueño, dos semanas perdidas por rotación y el reglamento pendiente del Consejo de Administración. Ninguno de esos tres puntos tiene dueño ni fecha en el RAID. El plan actual no tiene a la vista cómo recuperarlos, y no puedo afirmar que se cumpla; solo que nada en la carpeta lo sustenta.

### Si se aprueba
Línea base 2 — cierre 2027-02-19 · presupuesto 3.300.000.000 COP (sin cambio declarado; pendiente confirmar) · motivo: no suministrado (hay que dejarlo escrito; el informe sugiere seguridad y rotación pero nadie lo vinculó) · documento aprobatorio: pendiente.
La línea base 1 no se toca. El conteo de replanificaciones pasa de 0 a 1.
Desviación acumulada contra la línea base original: +30 días de tiempo (2027-01-20 → 2027-02-19) · costo +0 declarado, sin confirmar.
Reconciliación: la línea base se movería 30 días; el cambio aprobado debe llevar 30 días de impacto de tiempo escrito en días. Si se aprueba sin documento, `unauthorized_days` quedará en 30.

## Qué no sé
- Quién pide el cambio y por qué.
- El costo de los 30 días.
- Si el piloto y otros hitos se mueven.
- Si el contrato CT-894 cubre hasta febrero.
- Quién tiene autoridad para aprobar.
- Si hay dependencias reales no declaradas.

## Siguiente paso
Llevarlo al Comité de Riesgos (próximo comité de la PMO: 2026-10-24) con motivo, costo y autoridad resueltos. La línea base 2 solo se registra cuando alguien con autoridad lo apruebe por escrito.

*Pie de rigor: borrador de trabajo; cada dato sale de la ficha PRY-201 y de los documentos citados. La verificación es suya.*
