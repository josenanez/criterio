Cierre de PRY-203 · sale de: ficha `estado/records/PRY-203.json`, el acta de constitución (2025-11-12), el cronograma v1 (2025-11-12) y el informe de avance (corte 2026-09-23). Cifras de `portafolio.py compute` con corte 2026-10-17. Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Cierre — Aportes sociales en línea (PRY-203) — 2026-10-17

**Lo primero: este proyecto no está en condiciones de cerrarse contra lo pactado.** Ningún documento dice que terminó. El último informe (2026-09-23) lo declara en verde con 57 % de avance, tiene un asunto abierto sin dueño y proyecta pasarse del presupuesto. Lo que sigue es el cierre que la evidencia permite, no un acta de cumplimiento. Si alguien decide cerrarlo ya, sería un cierre por decisión, y esa decisión no está registrada en ninguna parte.

### Contra lo comprometido
**Criterio de éxito:** «Aportes sociales en línea en producción y medido» (acta de constitución, 2025-11-12).
**Se cumplió:** no se puede determinar. Ningún documento muestra que el servicio esté en producción ni una medición. El informe del 2026-09-23 habla de un piloto futuro («ajustar el reglamento antes del piloto»), lo que apunta a que aún no está en producción. Es una inferencia, no un hecho documentado.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Componente 1 (sin nombre en el acta) | No se puede determinar | Ninguna: el acta no lo describe |
| Componente 2 (sin nombre en el acta) | No se puede determinar | Ninguna |
| Componente 3 (sin nombre en el acta) | No se puede determinar | Ninguna |
| Hito: Diseño funcional aprobado (2026-02-05) | «Cerrado» según el cronograma | Sin evidencia de cumplimiento; 254 días desde su fecha |
| Hito: Ambiente de pruebas certificado (2026-04-22) | «Cerrado» según el cronograma | Sin evidencia de cumplimiento; 178 días |
| Hito: Integración con el core cooperativo (2026-07-07) | «Cerrado» según el cronograma | Sin evidencia de cumplimiento; 102 días |

Los tres hitos están marcados como cumplidos solo por declaración, sin acta de aprobación, certificado ni prueba de integración. Hay además una contradicción: los 3 hitos del plan están cerrados (el plan sustenta 100 %), pero el informe declara 57 %, una brecha de 43 puntos. Alguno de los dos números está mal, o el cronograma no contiene todo el trabajo. Los documentos no permiten saber cuál.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| «Lo que otro proyecto cubre», sin nombrar el proyecto | Acta de constitución (aprobada por el Comité de Educación) | 2025-11-12 |

No hay recortes de alcance posteriores registrados, y no hay solicitudes de cambio (0). Tampoco se puede verificar si el alcance se entregó completo, porque los componentes no tienen nombre. La exclusión del acta no identifica el proyecto que cubre lo excluido y las dependencias declaradas son «ninguna»; el acta no permite saber qué quedó en manos de quién.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-07-07 | 2026-07-07 | No documentada | No calculable: no hay fecha real de cierre. El cronograma no se movió (0 días) y la fecha lleva 102 días vencida al corte |
| Presupuesto aprobado | 6.800.000.000 COP | 6.800.000.000 COP | No documentado | Proyección al cierre declarada: 7.116.748.864 COP, **4,7 %** sobre lo aprobado |

Replanificaciones: **0**. Solo existe la línea base v1 (2025-11-12).

Presupuesto según el informe del 2026-09-23 (declaración, sin soporte contable): comprometido 2.123.715.582 COP (31,2 %), ejecutado 3.031.029.425 COP (44,6 %). **Lo ejecutado supera lo comprometido**, lo cual no debería pasar: o hay gasto sin compromiso registrado, o una de las dos cifras está mal. El informe no lo explica. Sin esa aclaración, el «final» del presupuesto no se puede cerrar.

### RAID al cierre
**Materializados:** ninguno documentado. Por señal propia del informe, el atraso de la entrega del proveedor podría ser un riesgo cercano a materializarse, pero no hay documento que lo confirme.
**No materializados:** ninguno confirmado.
**Abiertos, con doliente:** ninguno. Los dos abiertos no tienen responsable, y por eso no están cerrados:
- Riesgo: «El proveedor no ha confirmado la fecha de la última entrega» (informe 2026-09-23). Sin dueño y sin fecha. El proveedor no está identificado y no hay contrato ni entregables registrados en la ficha (0 proveedores).
- Incidencia: «El Consejo de Administración pidió ajustar el reglamento antes del piloto» (desde 2026-09-23). Sin dueño y sin fecha.

### Lecciones
| Qué pasó | Cuándo | Efecto | Qué haríamos distinto |
|---|---|---|---|
| El cronograma v1 marca los 3 hitos como «cerrado», sin acta ni certificado; el informe declara 57 % de avance y estado verde | Hitos de 2026-02-05, 2026-04-22 y 2026-07-07; informe del 2026-09-23 | El plan sustenta 100 % y el informe dice 57 %: 43 puntos de brecha sin explicación, y el verde no tiene respaldo | Exigir evidencia de aceptación (acta, certificado, prueba) para marcar un hito cerrado, y que el plan incluya todo el trabajo restante |

Es la única lección que se puede anclar a hechos documentados. No se redactan otras, porque los documentos no dicen qué pasó entre 2025-11-12 y 2026-09-23 más allá de estos tres.

### Sin dato
- Si el proyecto terminó, en qué fecha real y quién lo declaró.
- Si el servicio está en producción y medido (criterio de éxito).
- Qué son los tres componentes del alcance; el acta los llama «Componente 1, 2 y 3».
- Evidencia de cumplimiento de los 3 hitos.
- Por qué el avance es 57 % si los 3 hitos están cerrados.
- Por qué lo ejecutado (3.031.029.425 COP) supera lo comprometido (2.123.715.582 COP).
- Presupuesto final ejecutado, con soporte contable; todas las cifras son declaración del gerente.
- Proveedor, contrato y entregables.
- Dueño de los dos asuntos abiertos.
- Qué proyecto cubre lo excluido del alcance.
- Autoridad que aprueba cambios y fase del proyecto (campos no encontrados en la documentación).
- Cualquier documento posterior al 2026-09-23. El proyecto lleva 24 días en silencio (umbral: 15).

### Otras señales abiertas en la ficha
Silencio (24 días), avance contra plan, 3 hitos cumplidos sin evidencia, y estado declarado «verde» no sustentado por la evidencia (declared_vs_evidence).

### Después
No ofrezco mover la carpeta a `archivo/` ni congelar la ficha: sin declaración de cierre y con asuntos abiertos sin dueño, el proyecto sigue activo para el barrido diario. Lo que habría que pedirle a Paula Céspedes (gerente) y a María Restrepo (patrocinadora) para poder cerrar: (1) evidencia de los 3 hitos, (2) estado real del criterio de éxito, (3) explicación de ejecutado > comprometido, (4) dueño y fecha para el riesgo del proveedor y la incidencia del reglamento.

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada dato sale de los tres documentos citados; la verificación es suya. Las cifras derivadas (4,7 %, 31,2 %, 44,6 %, 0 replanificaciones, 24 días en silencio, 43 puntos de brecha) vienen de `portafolio.py compute`; lo que el script no calcula no se escribe. Lo que se habló fuera de estos documentos no se conoce.
