Fuentes: ficha PRY-210 (estado/records/PRY-210.json, actualizada 2026-10-17), acta de constitución 2025-08-19, informe de avance 2026-10-09, cronograma v1 2025-08-19. Cifras derivadas: salida de `portafolio.py compute`, al 2026-10-17.

## Presupuesto — PRY-210 Corresponsales rurales al 2026-10-17
**Moneda:** COP (única; no hay otras monedas)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 9.500.000.000 | 100 % | Acta de constitución (documento) | 2025-08-19 |
| Comprometido | 3.046.464.807 | 32,1 % | Informe de avance (declaración del gerente) | 2026-10-09 |
| Ejecutado | 4.148.296.231 | 43,7 % | Informe de avance (declaración del gerente) | 2026-10-09 |
| Proyección al cierre | 11.281.920.391 | 118,8 % | Informe de avance (declaración del gerente) | 2026-10-09 |

**Disponible real** (aprobado menos comprometido): 6.453.535.193 COP.
Ojo: el ejecutado declarado (4.148.296.231) es mayor que el comprometido (3.046.464.807). Lo ejecutado debería estar dentro de lo comprometido; una de las dos cifras está mal o parte del gasto se hizo sin compromiso registrado. Hasta aclararlo, el disponible real podría ser menor: 5.351.703.769 COP si se descuenta el ejecutado.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 9.500.000.000 | 9.500.000.000 | 0 |
| Proyección vs. aprobado | 9.500.000.000 | 9.500.000.000 | +18,8 % (+1.781.920.391 COP) |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. La línea base de plazo (fin 2026-11-14) tampoco se ha movido.

### Ejecución frente a avance
Ejecutado 43,7 % · Hitos cumplidos 3 de 4 · Avance declarado 59 %, pero el plan sustenta entre 75 % y 100 % (brecha de 16,0 puntos, por detrás). Con 3 de 4 hitos declarados cumplidos, el gasto (43,7 %) y el avance declarado (59 %) no cuentan la misma historia: o se ha hecho más de lo que se ha pagado (trabajo no facturado que aparecerá de golpe), o los hitos no están realmente cumplidos. Ninguno de los 3 hitos «cumplidos» tiene evidencia (los tres vienen solo de la declaración).

### Alertas
- **Proyección por encima del aprobado: 18,8 %** (umbral 10 %). Sobrepasa por 1.781.920.391 COP.
- **Comprometido 32,1 %** del aprobado: por debajo del umbral de 90 %; no hay alerta de agotamiento. Pero la proyección dice que lo que falta por comprometer no cabe.
- **Cifras inconsistentes:** ejecutado mayor que comprometido (ver arriba).
- **Informe en verde con tres señales sin explicar:** el informe del 2026-10-09 declara verde; la proyección, el avance y los hitos sin evidencia lo contradicen.
- **Fuentes:** comprometido, ejecutado y proyección son declaraciones, no evidencia (0 documentos de evidencia). La proyección tiene 8 días y es posterior a cualquier movimiento de presupuesto (no hay ninguno registrado).
- **Dato viejo:** el aprobado viene de un acta de hace 14 meses (umbral 12).
- Incidencia declarada: el equipo perdió dos semanas por rotación de un desarrollador clave, y el proveedor no ha confirmado la fecha de la última entrega. Ninguna tiene responsable.

### Sin dato
- Ninguna de las cuatro cifras de dinero falta. No hay detalle por proveedor (la ficha no tiene proveedores) ni tasa de cambio: no aplica, una sola moneda.
- No se sabe de qué parte de los costos sale la proyección ni por qué excede el aprobado: el informe no lo desglosa.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/change-control`). No la he preparado.

*Pie de rigor: borrador de trabajo; la verificación contra los documentos citados es de quien lo lea. No sé lo que se haya hablado fuera de los documentos.*
