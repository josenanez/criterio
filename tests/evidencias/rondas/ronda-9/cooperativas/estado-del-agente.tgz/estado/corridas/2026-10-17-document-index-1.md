# Corrida del 2026-10-17 · document-index

13 proyectos · 15 s · 52 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 19 |
| `commitment_overdue` | 7 |
| `declared_vs_evidence` | 6 |
| `progress_vs_plan` | 5 |
| `commitment_undated` | 5 |
| `commitment_rescheduled` | 3 |
| `variance_cost` | 2 |
| `vendor_invoiced_over_accepted` | 1 |
| `silent` | 1 |
| `variance_time` | 1 |
| `vendor_deliverable_late` | 1 |
| `vendor_accepted_without_evidence` | 1 |

67 documentos sin cambio, 0 por releer; 15 citas de PRY-209 no resuelven aunque los archivos existen (hipótesis: ruta relativa al proyecto, no verificada)

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Carpeta al 2026-10-17

**Documentos:** 67 · **Sin cambio:** 67 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno.

### Renombrado o movido
Ninguno.

### Ya no está
Ninguno.

### Citas que dejaron de resolver
15 citas, todas de PRY-209, según el índice. Dos fuentes concentran casi todas:

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-209 | identity.code, name, business_area, product, sponsor, manager, committee (7) | 00-gobierno/2026-06-20-acta-constitucion.md |
| PRY-209 | plan.start_date, plan.scope_summary, plan.exclusions[0] (3) | 00-gobierno/2026-06-20-acta-constitucion.md |
| PRY-209 | money.approved | 00-gobierno/2026-06-20-acta-constitucion.md |
| PRY-209 | plan.end_date | 10-plan/2026-06-20-cronograma-v1.csv |
| PRY-209 | money.committed, executed, projection (3) | 20-seguimiento/2026-10-09-informe-avance.md |

Matiz: los tres documentos citados **sí existen** en `PRY-209-convenios-de-libranza-con-empresas/` y no se detectó borrado ni renombrado. Lo más probable es que la ficha de PRY-209 (`pm_record`, ficha-pm.json) cite la ruta relativa al proyecto y no la ruta con que el índice la busca. No lo verifiqué abriendo la ficha; es una hipótesis. Hasta aclararlo, esos 15 datos figuran como sin sustento verificable en el índice.

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Siguiente paso
No hay documentos por releer, así que no se ofrece `/portfolio-scan`. Queda pendiente revisar cómo PRY-209 escribe sus citas.
