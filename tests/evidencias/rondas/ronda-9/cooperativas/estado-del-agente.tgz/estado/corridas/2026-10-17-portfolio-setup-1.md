# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 67 documentos, 41 releídos y 26 sin cambio · 109 s · 17 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 6 |
| `commitment_undated` | 4 |
| `commitment_rescheduled` | 3 |
| `progress_vs_plan` | 1 |
| `milestone_met_without_evidence` | 1 |
| `variance_cost` | 1 |
| `declared_vs_evidence` | 1 |

0 preguntas (prueba sin interfaz, valores sugeridos); tiempo hasta el primer resultado no medido; 3 proyectos (PRY-202, 209, 199): PRY-202 verde contradicho por 4 señales, PRY-209 con 5 compromisos vencidos y 3 reprogramados, PRY-199 sin señales

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

Soy Vera, el agente PMO de Criterio. Proceso la documentación que ya tienes y digo qué no se sostiene.

Sesión de prueba sin interfaz: nadie respondió preguntas. Tomé la respuesta sugerida en cada una (dicho abajo).

## Listo — Cooperativa (instalación de prueba)

**Miré:** 67 documentos en 13 proyectos (PRY-199 a PRY-211) · formatos: .md 35, .docx 10, .pdf 10, .csv 5, .xlsx 5, .json 1, .txt 1 · más reciente: 2026-10-17 · ninguno ilegible
**Eres:** PMO del portafolio (varios proyectos → PMO; sugerido)
**Te aviso:** dos días antes del comité semanal; primer comité supuesto el 2026-10-24 (no hay comité declarado: los comités de las carpetas se llaman «semanal»)
**En:** presentación (sugerido; el valor guardado es `pptx`)
**Términos:** versión 1.1 aceptada por José Francisco Ñáñez el 2026-10-17 (la instrucción de la prueba trae el sí y el nombre; los términos se mostraron tal cual antes de registrarla) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 del .md 96015115a67f6c94…
**Dónde queda todo:** configuración en `.criterio/portafolio/config.json` · lo que voy encontrando en `estado/` · informes en `reportes/` (aún no existe)

Preguntas hechas: 0 (todas resueltas con el valor sugerido).

### Probé con tres proyectos

Los tres con documentación más reciente: PRY-202, PRY-209 y PRY-199. Fichas en `estado/records/` y selladas.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-202 Core cooperativo | 6 | Patrocina Laura Vélez, gerencia Mauricio Pérez, Comité de Educación. Presupuesto 1.200.000.000 COP; cierre comprometido 2026-12-15. Declara **verde, 55 %** (corte 2026-10-15). | Producto («No aplica»), autoridad del gerente y fase. |
| PRY-209 Convenios de libranza con empresas | 14 | Patrocina Diana Molina, gerencia Camilo Beltrán, Comité de Tecnología. Presupuesto 9.500.000.000 COP; cierre 2027-04-17. Declara **amarillo, 24 %** (corte 2026-10-09). Tiene ficha del gerente (`ficha-pm.json`), guardada entera aparte y sin mezclar con mi lectura. 26 compromisos sacados de los seis comités y las notas del 17. | Producto («No aplica»), autoridad y fase. Ni el acta de constitución ni las notas dan fecha a 4 compromisos. |
| PRY-199 Cambio de mobiliario de agencias | 6 | Patrocina María Restrepo, gerencia Andrés Lozano, Consejo de Administración, producto PRD-299. Presupuesto 2.400.000.000 COP; cierre 2027-12-16. Declara **verde, 20 %** (corte 2026-10-15). Contrato CT-199 con Soluciones Solidarias: 3 entregables de 144.000.000 COP, todos pendientes. | Autoridad, fase y facturas del contrato (no hay ninguna en la carpeta). |

### Hallazgos (solo lo que `compute` levantó)

**PRY-202: dice verde y cinco señales lo contradicen** (`declared_vs_evidence`):
- `progress_vs_plan`: declara 55 %, pero el cronograma tiene 3 de 4 hitos cerrados, que sustentan entre 75 % y 100 %. Brecha de 20 puntos, hacia atrás. Es el sentido opuesto al que uno esperaría: el avance declarado va por debajo de lo que el cronograma da por cerrado.
- `milestone_met_without_evidence`: «Integración con el core cooperativo» (fecha 2026-09-10, hace 37 días) figura cerrado y no hay acta que lo pruebe. Las actas de recibo de la carpeta son de «Diseño funcional aprobado» (2026-10-06) y «Ambiente de pruebas certificado» (2026-10-17).
- `variance_cost`: el propio informe proyecta 1.498.158.438 COP contra 1.200.000.000 aprobados, un 24,8 % por encima.
- `commitment_overdue`: Natalia Ospina, «Entregar el punto 23», para el 2026-10-10 (7 días vencido), citado en el comité del 2026-10-11.
- El informe también declara ejecutado 724.509.244 COP contra comprometido 447.707.288. `compute` no lo levantó como señal; lo anoto como dato que hay que preguntar, no como hallazgo.

**PRY-209: amarillo declarado; lo que el informe no menciona son los compromisos** (`unaccounted_signals`: vencidos y reprogramados):
- 5 compromisos vencidos. El más antiguo: Camilo Beltrán, «Entregar el punto 8», para 2026-10-01 (16 días). El 2026-09-26 dijo que ya lo había entregado; no se presentó acta.
- 3 compromisos reprogramados varias veces: Jorge Medina, «Cerrar la prueba 2» (6 veces; original 2026-09-18, hoy 2026-12-06); Diana Molina, «Enviar el documento 1» (4 veces; original 2026-10-02, hoy 2026-11-17); Jorge Medina, «Revisar el anexo 3» (3 veces).
- 4 compromisos sin fecha: Mauricio Pérez («documento 9»), Javier Hoyos («documento 17»), Andrés Lozano («matriz 22»), Laura Vélez («ajuste del presupuesto», dicho como «la otra semana»).
- Costos y plazo dentro de umbral: proyección 1,3 % sobre lo aprobado; brecha de avance de 1 punto.

**PRY-199: sin señales.** Verde declarado y `compute` no levantó nada. Dos cosas que el resultado no es: no es una validación del proyecto, y no se verificó que la factura del ejecutado (720.000.000 COP) exista; no hay ninguna en la carpeta.

**Los tres:** ninguno tiene `authority` (hasta dónde puede decidir el gerente sin subir a comité).

### El portafolio completo
10 proyectos más, 41 documentos (los 3 de prueba suman 26 de los 67), en un solo lote (PRY-200, 201, 203 a 208, 210 y 211), uno tras otro. Tiempo: no lo medí en esta sesión, así que no te doy una cifra.

### Lo que le falta a tu carpeta
Ninguno es bloqueante; son hallazgos sobre la documentación misma.
- **Autoridad del gerente:** ninguna de las tres actas leídas la declara.
- **Actas de recibo de hitos:** los cronogramas declaran hitos cerrados sin acta (PRY-202, «Integración con el core cooperativo»).
- **Fechas de compromiso:** las tablas de comité traen «por definir» y las notas traen «la otra semana».
- **Alcance sin nombrar:** las tres actas dicen «Componente 1, 2, 3» y «lo que otro proyecto cubre», sin decir cuál.
- **Notas fuera de las carpetas:** en PRY-209 hay un `.txt` de notas del 17 de octubre suelto en la raíz del proyecto, fuera de `30-reuniones`.
- **Producto:** PRY-202 y PRY-209 dicen «No aplica»; solo PRY-199 declara producto (PRD-299).
- **Carpeta ya usada:** `estado/` ya traía el trabajo de PRY-209 hecho antes por el agente de proyecto (`estado/PRY-209-convenios-de-libranza-con-empresas/`). No lo toqué.

### Siguiente paso
Correr el portafolio completo (10 proyectos restantes). Como PMO con equipo, también puedes publicar el estándar en una carpeta compartida para que los gerentes usen los mismos criterios. No lo hice: no hay carpeta compartida indicada.
