# Corrida del 2026-10-17 · product-definition

PRD-307 · 16 requerimientos · 26 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |

La definición no tiene criterio de éxito ni propuesta; la cifra de volumen no tiene serie y la única evidencia de demanda es una entrevista de enero

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Auxilios de solidaridad (PRD-307) · contrastada al 2026-10-17
**Documento:** `00-definicion/2026-04-29-definicion-producto.md` (con `2026-04-29-caso-de-negocio.md`) · **del** 2026-04-29 · 5 afirmaciones

Términos v1.1 ya vigentes y aceptados por José Francisco Ñáñez el 2026-10-17; no hizo falta registrarlos de nuevo.

### Lo que la evidencia contradice
Nada. No hay ninguna cifra ni documento que diga lo contrario de lo declarado.

### El negocio y los datos
Ninguna métrica pasa del umbral (20 %), porque no hay ninguna serie medida con la que comparar.

### Afirmaciones numéricas que nadie mide
| Afirma | De qué documento | No hay serie |
|---|---|---|
| `volumen_mensual` = 68.516 | Caso de negocio, 2026-04-29 | Nadie mide el volumen mensual de auxilios. Esto no es una contradicción: la cifra no se puede contrastar. |
| `retorno_24_meses` | Caso de negocio, 2026-04-29 | La frase «Retorno esperado en 24 meses» no trae cifra ni base. No hay nada que medir. |

### No está dicho en ninguna parte
- **Qué se propone.** La sección «La propuesta» solo dice «Propuesta principal».
- **Criterio de éxito.** No hay ninguno declarado.
- **De dónde sale 68.516** ni qué cuenta como «volumen» (solicitudes, auxilios pagados, asociados).
- **Cuánto se espera de retorno, y sobre qué base.**
- **Cuántos asociados urbanos son, cuántos tienen el problema ni cuánto pagarían o aportarían.** La definición solo afirma que el segmento «no tiene auxilios de solidaridad».
- **Qué proyecto lo construye.** «Ninguno declarado».
- **Qué datos recoge y qué dinero mueve.** Esto condiciona el barrido normativo.
- **El país.** La definición no lo declara.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| El reglamento vigente lo permite | 0 pendientes: declarado el 2026-06-01, verificado el 2026-08-22 (82 días después) | Está marcado como verificado, pero el anexo cita «el documento técnico del proveedor del 2026-08-22» y ese documento **no está en la carpeta**. Haría falta incorporarlo, o citar el artículo del reglamento que lo permite. Un documento técnico de un proveedor tampoco es el reglamento. |

No hay supuestos sin verificar en el cálculo (`assumptions_unverified` vacío).

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| El segmento necesita auxilios y hoy no los tiene | Entrevista a un cliente: «Lo necesito y hoy no lo tengo» (`10-descubrimiento/2026-01-15-entrevistas.md`) | 2026-01-15 | Débil. Es una persona y es un dicho («lo necesito»); nadie pagó ni se inscribió. No se sabe si el entrevistado es de Asociados urbanos. |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Necesidad del segmento | Entrevista del 2026-01-15 | ~9 meses (275 días). No pasa el umbral de 12 meses, pero es la única evidencia, y es anterior a la definición. |

### Lo normativo que toca
| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Pago de dinero (auxilios) a asociados | no declarado | Medios y sistemas de pago, reportes | — | no tengo la norma a la vista |
| Datos personales de asociados y beneficiarios (probable, para otorgar el auxilio) | no declarado | Autorización previa y finalidad; datos sensibles si hay salud o fallecimiento | — | no tengo la norma a la vista |
| Reglamento interno de la entidad que permite el auxilio | no declarado | Competencia para crear el beneficio | Reglamento citado en el supuesto, sin artículo | sin resolver (el documento que lo verifica no está en la carpeta) |
| Retención y trazabilidad de los pagos | no declarado | Conservación de la información | — | no tengo la norma a la vista |

No se cita ninguna norma. La definición no dice qué datos recoge ni qué paga, y tampoco dice el país, así que el barrido solo nombra lo que toca. No dice si cumple. Esto va a revisión jurídica, no la reemplaza.

### Lo que falta para cerrar la definición
- **Criterio de éxito (`success`): no está declarado.** Sin él la definición no se puede cerrar.
- Problema y para quién: están declarados (Asociados urbanos). El problema está escrito como la ausencia del producto, no como un daño medible.
- Quién decide: Comité de producto (documento del 2026-10-06, asiste solo el gerente del producto).
- Propuesta y retorno: vacíos, ver arriba.

**Después:** el supuesto del reglamento queda formalmente verificado, pero con un soporte ausente. Esta corrida no ofrece `/product-charter`: la definición no está cerrada.
