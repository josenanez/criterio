# Caso de negocio — Auxilios de solidaridad (PRD-307) · borrador del 2026-10-17
**Desde:** la definición del 2026-04-29 y el caso de negocio del 2026-04-29 · **Cifras con fuente:** 0 de 2 con origen verificable (1 declarada sin origen detrás; 1 sin cifra)

*Pregunta de la sesión: nadie la responde. Términos: ya vigentes y aceptados por José Francisco Ñáñez (v1.1, 2026-10-17); no se registró de nuevo.*

## Qué problema resuelve, y para quién
«El segmento Asociados urbanos no tiene auxilios de solidaridad.» — `00-definicion/2026-04-29-definicion-producto.md`, 2026-04-29. Segmento: Asociados urbanos.

La propuesta no está dicha: la sección dice solo «Propuesta principal».

## Qué se construye
Alcance: los 13 requerimientos aceptados el 2026-10-06 por el Comité de producto (`30-decisiones/2026-10-06-comite-producto.docx`). Los 3 propuestos (REQ-4708, REQ-4710, REQ-4715) quedan fuera hasta que se decidan.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4700, 4702, 4703, 4705, 4709, 4711, 4712 | aceptado | Una sola cita: entrevista 2026-01-15, cliente sin nombre, «Lo necesito y hoy no lo tengo.» La entrevista no nombra ninguno de estos requerimientos; el acta se la atribuye. |
| REQ-4701, 4704, 4706, 4707, 4713, 4714 | aceptado | **Ninguna.** Aceptados sin una cita de quien lo pidió. |

Solo 7 de 13 tienen alguna cita, y es la misma para los siete. REQ-4706 y REQ-4713 tampoco tienen criterio de aceptación. REQ-4702 no tiene doliente. Ninguno tiene proyecto que lo construya (el acta no nombra ninguno).

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 68.516 | Declarada | Caso de negocio, Óscar Ramírez. La fuente que cita es el mismo caso: no hay documento detrás. | 2026-04-29 |
| Retorno esperado en 24 meses | sin cifra | Supuesta | «Retorno esperado en 24 meses.» No trae valor ni base. | 2026-04-29 |

No hay cifras medidas: PRD-307 no tiene carpeta de métricas.

### Donde la cifra declarada y la medida no coinciden
No aplica: no hay serie medida con la que contrastar `volumen_mensual`. Contraste imposible, no coincidencia. Mientras no exista, el umbral de desvío (20 %) no se puede evaluar.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **sin dato** | Ningún documento de la carpeta |
| Costo del equipo / contratos / cotizaciones | **sin dato** | Ningún documento de la carpeta |

**Este es el primer vacío.** Sin costo de construir hay una propuesta, no un caso de negocio que evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| El reglamento vigente lo permite (declarado 2026-06-01) — marcado verificado el 2026-08-22 | El producto no puede operar | La verificación cita «el documento técnico del proveedor del 2026-08-22», **que no está en la carpeta**. El anexo solo dice «se confirmó». Hay que aportar el documento. |
| El volumen mensual será de 68.516 | Ingresos, costo por transacción y retorno quedan sin base | Óscar Ramírez: aportar de dónde sale |
| Habrá retorno en 24 meses | No hay caso | Óscar Ramírez / finanzas: aportar cifra y base |

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso que evaluar | Óscar Ramírez / quien cotice |
| Origen de 68.516 | La cifra ya circula y nadie puede reconstruir de dónde salió | Óscar Ramírez |
| Cifra y base del retorno a 24 meses | Hoy es una frase, no un número | Óscar Ramírez / finanzas |
| Qué se propone construir | La sección de propuesta está vacía | Óscar Ramírez |
| Documento técnico del proveedor del 2026-08-22 | Sostiene el único supuesto «verificado» | Óscar Ramírez / proveedor |
| Qué pasa si no se hace; alternativas consideradas | El comité no puede comparar | Óscar Ramírez |
| Demanda para 6 requerimientos aceptados | Se van a construir sin que nadie los pidiera | Cada doliente (Cuéllar, Ospina, Vélez, Cárdenas, Salas) |
| Proyecto que ejecute los 13 aceptados | Ninguno tiene proyecto declarado | Comité de producto, vía `/product-trace` |

## Cómo se sabrá si funcionó
**No está declarado.** La definición no trae criterio de éxito ni métrica ni fecha de corte. Sin esto el producto no se puede cerrar meses después. Lo debe declarar el gerente de producto con el comité.

## Si hay otros productos publicados
En la carpeta hay otros nueve productos (PRD-299 a PRD-309). Varios usan una métrica llamada `volumen_mensual`, pero **el valor 68.516 solo aparece en PRD-307**: no hay cifra contada dos veces. No se hizo el cruce completo de segmento ni de proyectos (`/product-overlap`), porque PRD-307 no declara proyectos.

## Después
Pasar los tres supuestos de arriba a seguimiento (assumption-tracking). Si el caso se aprueba, `/product-charter`. No se recomienda aprobar ni rechazar, ni se calculó rentabilidad: las cifras no tienen fuente para hacerlo.
