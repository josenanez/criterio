# Corrida del 2026-10-17 · product-requirements

PRD-307 · 16 requerimientos · 27 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |

6 aceptados sin evidencia (4701, 4704, 4706, 4707, 4713, 4714); 13 sin proyecto; 3 propuestos sin decidir (4708, 4710, 4715); 4702 sin doliente

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Registro — Auxilios de solidaridad (PRD-307) · al 2026-10-17
16 requerimientos · 13 decididos · 53,8 % con evidencia · 0 % con proyecto que lo ejecuta

*Nota sobre el último número:* no hay carpeta de fichas de proyecto, así que ninguna traza se pudo confirmar contra una ficha; además el acta del comité no nombra proyecto para ningún requerimiento. El 0 % es "sin traza declarada", no "confirmado que nadie lo construye".

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4701 | Requerimiento REQ-4701 | aceptado (2026-04-28) | Beatriz Cuéllar |
| REQ-4704 | Requerimiento REQ-4704 | aceptado (2026-06-18) | Natalia Ospina |
| REQ-4706 | Requerimiento REQ-4706 | aceptado (2026-08-14) | Natalia Ospina |
| REQ-4707 | Requerimiento REQ-4707 | aceptado (2026-07-28) | Laura Vélez |
| REQ-4713 | Requerimiento REQ-4713 | aceptado (2026-08-02) | Rubén Cárdenas |
| REQ-4714 | Requerimiento REQ-4714 | aceptado (2026-05-25) | Ricardo Salas |

Seis de los trece decididos no tienen una sola cita de quien lo pidió. Cada doliente es quien debe aportar la evidencia o proponer devolverlo a `propuesto`.

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | |
|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | 2026-07-12 | sin proyecto en el acta |
| REQ-4701 | Requerimiento REQ-4701 | 2026-04-28 | sin proyecto en el acta |
| REQ-4702 | Requerimiento REQ-4702 | 2026-07-18 | sin proyecto en el acta |
| REQ-4703 | Requerimiento REQ-4703 | 2026-08-13 | sin proyecto en el acta |
| REQ-4704 | Requerimiento REQ-4704 | 2026-06-18 | sin proyecto en el acta |
| REQ-4705 | Requerimiento REQ-4705 | 2026-08-27 | sin proyecto en el acta |
| REQ-4706 | Requerimiento REQ-4706 | 2026-08-14 | sin proyecto en el acta |
| REQ-4707 | Requerimiento REQ-4707 | 2026-07-28 | sin proyecto en el acta |
| REQ-4709 | Requerimiento REQ-4709 | 2026-05-21 | sin proyecto en el acta |
| REQ-4711 | Requerimiento REQ-4711 | 2026-05-22 | sin proyecto en el acta |
| REQ-4712 | Requerimiento REQ-4712 | 2026-05-04 | sin proyecto en el acta |
| REQ-4713 | Requerimiento REQ-4713 | 2026-08-02 | sin proyecto en el acta |
| REQ-4714 | Requerimiento REQ-4714 | 2026-05-25 | sin proyecto en el acta |

Los trece. Quien lo cierra: Óscar Ramírez (gerente de producto) con el Comité de producto. Siguiente paso: `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 | (sin doliente en el acta) |

Lo cierra el Comité de producto nombrando a una persona.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4706 | Requerimiento REQ-4706 | aceptado |
| REQ-4713 | Requerimiento REQ-4713 | aceptado |

Ambos también están en la primera tabla (sin evidencia): aceptados sin pedido y sin criterio. Los cierra su doliente (Natalia Ospina, Rubén Cárdenas).

### Decidido sin documento que lo respalde
Ninguno: las trece decisiones citan el acta del comité del 2026-10-06 (`documentos/productos/PRD-307/30-decisiones/2026-10-06-comite-producto.docx`).

### Lleva meses y nadie lo decide
Umbral configurado: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4715 | Requerimiento REQ-4715 | 180 días (2026-04-20) | Comité de producto |
| REQ-4710 | Requerimiento REQ-4710 | 154 días (2026-05-16) | Comité de producto |
| REQ-4708 | Requerimiento REQ-4708 | 106 días (2026-07-03) | Comité de producto |

Se propone llevarlos al próximo comité para aceptar o descartar; no se cierran por viejos. REQ-4710 y REQ-4715 además no tienen criterio de aceptación; a un `propuesto` no se le exige, y no cuentan como hallazgo.

### Evidencia vieja
Ninguna con más de 12 meses: lo más nuevo que sostiene cualquier requerimiento es del 2026-01-15 (unos 9 meses). Cruzará el umbral en enero de 2027 si nadie suma evidencia nueva.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 3 | 13 | 0 | 0 | 0 |

Sin requerimientos descartados: no hay registro de lo que se rechazó, y esa discusión suele volver.
