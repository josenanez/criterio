> **Borrador de especificación, no aprobado.** Lo cierra Óscar Ramírez (gerente de producto, PRD-307) con el Comité de producto; este agente no puede firmarlo. Y como está hoy, el registro no alcanza para escribir comportamiento: lo que sigue es sobre todo un inventario de lo que falta decidir.

# Especificación — Auxilios de solidaridad (PRD-307) · borrador del 2026-10-17

## Qué problema resuelve
«El segmento Asociados urbanos no tiene auxilios de solidaridad.» (definición, 2026-04-29). Es todo lo que la definición dice: la propuesta es la línea «Propuesta principal», que no dice qué se propone, y el criterio de éxito del producto **no está dicho en ninguna parte**.

## Alcance
### Entra
Los 13 requerimientos en estado `aceptado` (acta del Comité de producto, 2026-10-06): REQ-4700, 4701, 4702, 4703, 4704, 4705, 4706, 4707, 4709, 4711, 4712, 4713, 4714. No hay ninguno `en_construccion`.

Entran **solo por su identificador**: ninguno tiene título descriptivo (todos dicen «Requerimiento REQ-47xx») ni necesidad registrada (`need`: no está dicho en ninguna parte). Decir qué hace cada uno sería inventarlo.

### No entra
- REQ-4708, REQ-4710 y REQ-4715: siguen en `propuesto`, nadie decidió nada sobre ellos.
- Todo lo que no esté en el registro. No hay requerimientos `descartados` registrados, así que no hay una lista de lo que se decidió no hacer.

## Comportamiento
**No se redacta ninguna sección.** Para escribir el comportamiento de un requerimiento hace falta su necesidad, y los 13 la tienen vacía. Ninguna sección cubre ningún requerimiento; ver la última tabla.

## Criterios de aceptación
| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta, 2026-10-06) | REQ-4700, 4701, 4702, 4703, 4704, 4705, 4707, 4709, 4711, 4712, 4714 | No dice qué se observa ni contra qué valor. Dos personas mirando lo construido no tienen cómo llegar a la misma respuesta | **No.** No es verificable todavía: no hay métrica, umbral ni observable |
| *(ninguno registrado)* | REQ-4706, REQ-4713 | — | — |

La misma frase, idéntica, sirve de criterio a 11 requerimientos distintos: es un trámite del acta, no un criterio.

## Supuestos sobre los que está escrita
| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «El reglamento vigente lo permite» (declarado 2026-06-01) | Marcado como confirmado el 2026-08-22, pero cita «el documento técnico del proveedor del 2026-08-22», **que no está en la carpeta**; el anexo solo dice «se confirmó». No hay nada citable que lo sostenga. Tampoco dice qué reglamento ni de qué país | Óscar Ramírez aporta el documento y nombra el reglamento; la confirmación de fondo es de la revisión jurídica |

Los 13 requerimientos no declaran supuestos propios. Eso no significa que no los tengan: nadie los escribió.

## Vacíos
| Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|
| Necesidad y título de los 13 requerimientos aceptados | No se puede escribir comportamiento; cada quien entiende «auxilio» a su manera | Cada doliente: Óscar Ramírez (4700), Beatriz Cuéllar (4701), Andrés Lozano (4703), Natalia Ospina (4704, 4709), Sandra Gil (4705), Laura Vélez (4707), Felipe Arango (4711), Liliana Torres (4712), Rubén Cárdenas (4713), Ricardo Salas (4714) |
| Doliente de REQ-4702: el acta dice «sin asignar» | Aceptado sin persona que responda por él | Comité de producto asigna; Óscar Ramírez propone |
| Criterio de aceptación verificable en los 13 (11 con «se verifica en producción», 2 sin criterio: REQ-4706, 4713) | No hay forma de decir que algo quedó bien | Dolientes de cada uno, con Óscar Ramírez |
| Evidencia de demanda: 6 aceptados no tienen ninguna (4701, 4704, 4706, 4707, 4713, 4714). Los otros 7 apoyan en la misma frase anónima de una entrevista del 2026-01-15 («Lo necesito y hoy no lo tengo»), que no nombra ningún requerimiento | Se acepta sin que conste quién lo pidió; una frase no distingue entre siete cosas distintas | Óscar Ramírez (realizó las entrevistas) |
| Proyecto que ejecute cada requerimiento: el acta no nombra ninguno y la definición dice «Ninguno declarado» | Aceptados que nadie construye | Comité de producto; es lo que habilita `/product-charter` |
| Criterio de éxito del producto y propuesta concreta | Nada contra qué medir si el producto funcionó | Óscar Ramírez |
| Comportamiento en casos borde (beneficiario que no cumple condiciones, solicitud duplicada, monto, desembolso fallido, reclamo): ningún documento los toca | Los decide quien construya | Óscar Ramírez con los dolientes |
| Cifras del caso: volumen 68.516 al mes sin base ni unidad; «retorno esperado en 24 meses» sin cifra | Cualquier criterio de capacidad o desempeño quedaría sin sustento | Óscar Ramírez (autor del caso) |
| Qué debe hacer otro equipo (sistemas, contabilidad, quien desembolsa, etc.): **ningún documento menciona a otros equipos**, así que no sé si existen dependencias; no es lo mismo que no tenerlas | Dependencias que se descubren con el proyecto ya en marcha | Óscar Ramírez confirma con las áreas |
| Obligaciones normativas (tabla siguiente) | Se descubren con el producto construido | Revisión jurídica de la organización (no nombra persona en los documentos) |

### Barrido normativo (primer barrido, sin opinar sobre cumplimiento)
| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Entrega auxilios de solidaridad (mueve dinero o beneficios a asociados) | No dicho en los documentos | Normativa de la entidad que lo otorga y de pagos | — | no tengo la norma a la vista |
| «El reglamento vigente lo permite» | No dicho | Cuál reglamento y qué permite | — | sin resolver (el documento que lo sostiene no está en la carpeta) |
| Datos de asociados para decidir y pagar (la definición no dice cuáles) | No dicho | Tratamiento de datos personales | — | no tengo la norma a la vista |

No cito ninguna norma: ni el país ni los datos que se recogen están en los documentos, y inventar una cita es peor que dejarla vacía. Este barrido es insumo de la revisión jurídica, no la sustituye.

## Requerimientos aceptados que esta especificación no cubre
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4700 | Sin título | Sin necesidad registrada; criterio no verificable; sin proyecto |
| REQ-4701 | Sin título | Sin necesidad, sin evidencia; criterio no verificable; sin proyecto |
| REQ-4702 | Sin título | Sin necesidad; **sin doliente**; criterio no verificable; sin proyecto |
| REQ-4703 | Sin título | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4704 | Sin título | Sin necesidad, sin evidencia; criterio no verificable; sin proyecto |
| REQ-4705 | Sin título | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4706 | Sin título | Sin necesidad, **sin criterio**, sin evidencia; sin proyecto |
| REQ-4707 | Sin título | Sin necesidad, sin evidencia; criterio no verificable; sin proyecto |
| REQ-4709 | Sin título | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4711 | Sin título | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4712 | Sin título | Sin necesidad; criterio no verificable; sin proyecto |
| REQ-4713 | Sin título | Sin necesidad, **sin criterio**, sin evidencia; sin proyecto |
| REQ-4714 | Sin título | Sin necesidad, sin evidencia; criterio no verificable; sin proyecto |

**13 de 13 aceptados quedan sin cubrir.** No es que se hayan descartado: el registro no tiene con qué escribirlos.

---
**Pie.** Sale del registro `estado-producto/PRD-307/requirements/` (16 requerimientos: 13 aceptados, 3 propuestos, 0 en construcción), actualizado el 2026-10-17, y de `producto.json` de la misma fecha; el acta del comité (2026-10-06) entró por el registro, no la releí. Cubre 0 de 13 requerimientos aceptados. Es un borrador de trabajo, no una decisión ni asesoría; la verificación es de quien lo cierra. Términos v1.1 aceptados por José Francisco Ñáñez el 2026-10-17: https://www.josenanez.com/es/agents/criterio-pmo/legal

**Después:** no ofrezco `/product-charter`. Antes hace falta cerrar necesidad, criterio y proyecto de al menos un requerimiento.
