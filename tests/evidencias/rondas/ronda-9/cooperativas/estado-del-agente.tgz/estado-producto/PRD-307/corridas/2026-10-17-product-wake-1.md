# Corrida del 2026-10-17 · product-wake

PRD-307 · 16 requerimientos · 30 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |

Primera revisión, sin corte anterior: no hay crossed. Sin documentos nuevos. Sin carpeta de fichas: ninguna traza confirmada. No sabe el criterio de éxito ni si algún proyecto construye los 13 aceptados.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Auxilios de solidaridad (PRD-307) · 2026-10-17

**Términos:** vigentes (versión 1.1, aceptados el 2026-10-17 por José Francisco Ñáñez); no hubo que registrarlos de nuevo.

**Qué tocaba:** la revisión del registro. Nunca se había corrido (`last: null`), y no había corte anterior, así que `crossed` no existe todavía: no puedo decir qué cruzó un umbral desde antes. Este corte queda como el punto de partida.

**Revisión contra la carpeta:** 5 documentos, 5 sin cambios, 0 por leer. No hay documentos de descubrimiento nuevos ni cambios en la definición, así que no ofrezco `/product-discovery` ni `/product-definition`.
Nota: `plan-lectura` marcó 9 campos con `source_missing`, pero los 5 documentos citados existen en la carpeta. Lo atribuyo a cómo se resuelve la ruta, no a un documento perdido. No lo verifiqué más.

**Las trazas:** no confirmadas. No existe una carpeta de fichas de proyecto configurada ni encontrada (`--fichas`), así que ninguna traza se da por confirmada. 0 de 16 requerimientos tienen proyecto, y los 13 aceptados salen `requirement_untraced`.

**Registro hoy:** 16 requerimientos (13 aceptados, 3 propuestos). 7 de 16 (53,8 %) tienen evidencia. El éxito de la definición no está dicho en ninguna parte.

### Lo que necesita decisión del comité (a consideración, no es novedad)
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir | REQ-4715 | 180 días | Quién tiene la facultad de decidirlo | Laura Vélez (doliente); decide el Comité de producto |
| Sin decidir | REQ-4710 | 154 días | Ídem; además no tiene criterio de aceptación ni evidencia | Paula Céspedes; decide el Comité de producto |
| Sin decidir | REQ-4708 | 106 días | Ídem | Paula Céspedes; decide el Comité de producto |
| Aceptado sin doliente | REQ-4702 | n/a | Asignar doliente | Sin dato |
| Aceptado sin criterio de aceptación ni evidencia | REQ-4706, REQ-4713 | 64 y 76 días | Criterio de aceptación y sustento de la demanda | Natalia Ospina; Rubén Cárdenas |
| Aceptado sin evidencia de demanda | REQ-4701, 4704, 4707, 4714 | 121 a 172 días | Qué demanda lo sustenta | Beatriz Cuéllar, Natalia Ospina, Laura Vélez, Ricardo Salas |

Los umbrales del producto son 60 días sin decidir y 12 meses de antigüedad de la evidencia. La evidencia más reciente es del 2026-01-15, con unos 9 meses, y todavía no cruza el umbral. Cruzaría hacia el 2027-01-15.

**No sé:** si algún proyecto está construyendo los 13 requerimientos aceptados (falta la carpeta de fichas), ni cuál es el criterio de éxito del producto.

**Vuelvo el 2026-11-16.**
