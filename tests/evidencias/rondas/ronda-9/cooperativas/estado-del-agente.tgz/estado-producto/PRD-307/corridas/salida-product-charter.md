Términos: vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17; comprobante en `.criterio/terminos/aceptacion-criterio-product-0.4.0-2026-10-17.md`). No hubo que volver a pedirlos.

Verificación previa del REQ-4700 (requirement-record):

| Condición | Resultado |
|---|---|
| Aceptado, no propuesto | Sí: «aceptado» desde 2026-07-12 (acta del comité 2026-10-06) |
| Criterios de aceptación verificables | **No.** Dice «se verifica en producción»: no hay qué se mide, con qué umbral ni quién lo juzga |
| Evidencia de demanda con cita | **Débil.** Una entrevista anónima del 2026-01-15 («Lo necesito y hoy no lo tengo.») que no nombra el requerimiento |
| Autoridad declarada en la definición | Parcial: «Comité de producto» (acta 2026-10-06); no dice qué puede decidir el gerente del proyecto |

Respuesta sugerida a «¿sigo sin lo que falta?»: sí, sigo y lo marco como vacío del acta; no lo relleno.

---

# Acta de constitución — Auxilios de solidaridad (REQ-4700) · borrador del 2026-10-17
**Producto:** PRD-307 · Auxilios de solidaridad · **Requerimientos:** REQ-4700

## Qué problema resuelve
«El segmento Asociados urbanos no tiene auxilios de solidaridad.» (`documentos/productos/PRD-307/00-definicion/2026-04-29-definicion-producto.md`, 2026-04-29).
El requerimiento en sí no tiene necesidad escrita: el campo «necesidad» del REQ-4700 no se encontró en ningún documento. La sección «La propuesta» de la definición solo dice «Propuesta principal»: no dice qué se propone.

## Criterio de éxito
| Criterio | Cómo se verifica | Fuente |
|---|---|---|
| «se verifica en producción» | **No dice cómo.** Sin métrica, umbral ni responsable de juzgarlo | `30-decisiones/2026-10-06-comite-producto.docx` |

La definición del producto tampoco declara criterio de éxito (campo `success`: no encontrado). Hoy el cierre de este proyecto no se podría juzgar contra nada.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4700 | «Requerimiento REQ-4700» (el acta no da otro título) | Entrevista anónima 2026-01-15, «Cliente entrevistado», tema «Necesidad principal»; no menciona el requerimiento. Acta 2026-10-06 atribuye la petición a «Cliente entrevistado» |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4701 a REQ-4715 (15 requerimientos del mismo registro) | «Requerimiento REQ-47xx» | Esta acta se pidió solo para REQ-4700. Ninguno tiene proyecto asignado en el acta del comité. Entre ellos: REQ-4708, REQ-4710 y REQ-4715 siguen «propuestos» (sin decisión), y REQ-4702 no tiene doliente. Si alguno debe ir en el mismo proyecto, se agrega con otra invocación; no lo decide este borrador |

La razón de exclusión es de procedimiento, no de mérito: ningún documento dice que se hayan descartado.

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. Óscar Ramírez es gerente del *producto* y doliente del REQ-4700; el acta no lo propone como gerente del proyecto, y este comando no nombra a nadie.
- **Comité:** «Comité de producto» (acta 2026-10-06; asistió solo Óscar Ramírez).
- **Autoridad del gerente:** no está dicha (qué puede decidir solo, qué escala, tope de presupuesto y de plazo). Es el campo que más cuesta después.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «El reglamento vigente lo permite» (declarado 2026-06-01) | Declarado como verificado el 2026-08-22, pero la verificación cita «el documento técnico del proveedor del 2026-08-22», que **no está en la carpeta**. No se puede comprobar | Gerente del proyecto — por asignar; registrar con raid-taxonomy al instalar `criterio-project` |
| La demanda del segmento viene de una entrevista | Una sola entrevista anónima, de hace 9 meses (2026-01-15) | Gerente del proyecto — por asignar |
| Volumen mensual 68.516 (caso de negocio 2026-04-29) | Sin base ni serie medida en la carpeta | Gerente del proyecto — por asignar |

El «retorno esperado en 24 meses» no trae cifra ni base; no se lleva al acta como dato.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Que el reglamento permita el auxilio | Que la prestación esté permitida | «El reglamento vigente» (sin identificar) | Sin resolver: la verificación depende de un documento ausente. No se opina sobre cumplimiento |

No se hizo barrido normativo adicional: las obligaciones (datos personales, pagos) las ve quien tenga el texto del reglamento y del proveedor.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterio de éxito medible (del producto y del REQ-4700) | El cierre no se puede juzgar; «se verifica en producción» lo cumple cualquier cosa | Óscar Ramírez / Comité de producto |
| Necesidad del requerimiento (campo vacío) | Se construye sin saber qué resuelve | Óscar Ramírez |
| Qué se propone (la sección solo dice «Propuesta principal») | El proyecto arranca sin objeto definido | Óscar Ramírez |
| Patrocinador | Nadie responde por el presupuesto ni desbloquea | Comité de producto |
| Gerente del proyecto y su autoridad | El gerente escala todo o no escala nada | Quien tenga la autoridad de nombrar |
| Documento técnico del proveedor del 2026-08-22 | El supuesto del reglamento queda sin sustento comprobable | Óscar Ramírez |
| Demanda sustentada con más que una entrevista anónima | La evidencia no distingue este requerimiento de otros | Óscar Ramírez |
| Presupuesto e hitos | No hay contra qué medir; el acta no inventa plan | Comité de producto / gerente del proyecto |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad del Comité de producto (por definir; el acta no dice quién). **La ficha del proyecto no se creó:** se crea después de la firma, con `portafolio.py init`, y sin escribir el estado declarado.

**Qué sigue y para quién:** cuando haya firma, el gerente del proyecto instala `criterio-project` y corre `/pm-setup`; cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella.
