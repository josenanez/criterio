# Corrida del 2026-10-17 · product-setup

PRD-307 · 16 requerimientos · 38 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `requirement_untraced` | 13 |
| `requirement_accepted_without_evidence` | 6 |
| `requirement_undecided` | 3 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 1 |

0 preguntas (sesión sin interfaz, respuestas sugeridas); ~2 minutos hasta el primer resultado; 5 documentos, 16 requerimientos levantados; 13 aceptados sin proyecto, 6 aceptados sin evidencia, 3 propuestos sin decidir; 5 afirmaciones de la definición, 4 sin sostén directo

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Auxilios de solidaridad (PRD-307)

**Lo que miré:** 5 documentos · 1 de descubrimiento (una ronda de entrevistas, 2026-01-15) · la definición del 2026-04-29 · lo más reciente es el acta del comité del 2026-10-06. Formatos que no pude leer: ninguno (el `.docx` del acta lo leí extrayendo su texto).
**Términos:** aceptados para la versión 0.4.0 (términos 1.1) por José Francisco Ñáñez, 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 38ea1d146bbd84f3…

**Las cuatro preguntas, sin interfaz:** tomé la respuesta sugerida en cada una. Gerente: Óscar Ramírez (lo dice la definición). Quién decide: Comité de producto (lo dice el acta del 2026-10-06; la definición no nombra a nadie). Estado en `estado-producto/PRD-307`, hermana de la documentación y no la carpeta `estado/`. Términos: el sí viene de tu instrucción.

**Levantado:** la ficha del producto y 16 requerimientos, los que nombra el acta del comité. Ninguno inventado: lo que el documento no dice quedó en `not_found`.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| Hay quien necesita auxilios de solidaridad y hoy no los tiene | **Sostenida (media).** Una entrevista: «Lo necesito y hoy no lo tengo.» Cliente sin nombre, sin segmento | 2026-01-15 |
| El segmento *Asociados urbanos* es el que no los tiene | **No está dicha en ninguna parte.** La entrevista no dice a qué segmento pertenece quien habla | — |
| El volumen mensual es 68.516 | **No está dicha en ninguna parte.** La única fuente es el propio caso de negocio; no hay serie medida | 2026-04-29 (el caso de negocio, citándose a sí mismo) |
| Retorno esperado en 24 meses | **No está dicha en ninguna parte.** No trae cifra ni base | 2026-04-29 |
| El reglamento vigente lo permite | **Sostenida por un supuesto**, declarado verificado | supuesto 2026-06-01 · verificación 2026-08-22 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben.
- **La propuesta.** La sección dice solo «Propuesta principal»: no dice qué se propone.
- **De dónde sale 68.516.** Es la única cifra del caso de negocio y no hay serie de nada a la vista que la mida: **nadie está midiendo lo que el negocio afirmó.** No puedo contrastarla, y eso es el hallazgo.
- **Cuánto es el retorno y sobre qué base.**
- **Que el problema sea de Asociados urbanos.** Hay una entrevista y no menciona segmento.
- **Qué proyecto construye esto.** La definición dice «Ninguno declarado».

### Lo que dice el registro, ya calculado
- **16 requerimientos:** 13 aceptados, 3 propuestos.
- **13 de 13 aceptados no tienen proyecto que los ejecute.** Con traza: 0 (0.0%). Es lo decidido que nadie construye.
- **7 de 16 tienen evidencia de demanda (53.8%)**, y las 7 descansan en **la misma entrevista de un solo cliente sin nombre**, que no nombra ninguno de los requerimientos. El acta dice «Cliente entrevistado» y esa es toda la cita.
- **6 aceptados sin ninguna evidencia de demanda:** REQ-4701, 4704, 4706, 4707, 4713, 4714.
- **2 aceptados sin criterio de aceptación:** REQ-4706 y REQ-4713. En los demás el criterio escrito es «se verifica en producción», que dice dónde se mira y no qué se mira.
- **1 aceptado sin doliente:** REQ-4702 («sin asignar»).
- **3 propuestos sin decidir**, por encima de los 60 días: REQ-4708 (106 días), REQ-4710 (154), REQ-4715 (180).
- **Ninguna evidencia envejecida:** la entrevista es del 2026-01-15 y aún no cruza los 12 meses. Cruzará.
- El acta tiene un solo asistente, Óscar Ramírez, que es también el gerente; su única decisión escrita es «Se mantiene el plan», y no hay ningún plan en la carpeta.
- REQ-4701 figura aceptado desde 2026-04-28, un día antes de la definición y del caso de negocio.

### Supuestos sobre los que está escrita
Uno: **«El reglamento vigente lo permite»**, declarado el 2026-06-01 —después de la fecha de la definición— y marcado como verificado el 2026-08-22. Ojo: la verificación se apoya en «el documento técnico del proveedor», que **no está en la carpeta**, y es un documento del proveedor, no del reglamento. Está verificado por el anexo, no por algo que yo pueda ver. Ningún supuesto sin verificar.

### Qué le falta a tu carpeta
Como hallazgo, no como requisito:
- **Las transcripciones de las entrevistas.** Hoy hay una cita de un cliente; con ella se sostienen siete requerimientos.
- **La serie de `volumen_mensual`, con su fuente.** Sin ella la cifra del caso de negocio no se puede contrastar.
- **Las decisiones del comité, requerimiento por requerimiento.** El acta lista estados, no decisiones; un descartado hoy se vería igual que uno que nadie miró.
- **El documento técnico del proveedor** que sostiene el supuesto del reglamento.
- **Un criterio de éxito y un proyecto**, para que la definición tenga contra qué medirse.

**Siguiente:** `/product-discovery` sobre el material de entrevistas, para que los temas se vuelvan requerimientos con la cita de quién los pidió.
