# Comité de Riesgos · Tarjeta débito para asociados

**Fecha:** 2026-10-11
**Asistentes:** Sandra Gil, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Ricardo Salas | Entregar el punto 31 | 2026-11-04 |
| Liliana Torres | Entregar el punto 19 | 2026-10-25 |
