# Acta de constitución · Motor de crédito

**Código:** PRY-208
**Área dueña:** Operaciones
**Patrocinador:** Carlos Peña
**Gerente de proyecto:** Andrés Lozano
**Comité:** Consejo de Administración
**Producto asociado:** No aplica
**Fecha de aprobación:** 2025-12-12

## Objetivo del negocio

Entregar motor de crédito para Operaciones.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Consejo de Administración el 2025-12-12.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-12-22 |
| Cierre | 2026-08-05 |

## Criterio de éxito

Motor de crédito en producción y medido.

## Dependencias declaradas

- Ninguna declarada
