# Acta de constitución · Crédito de libranza digital

**Código:** PRY-200
**Área dueña:** Crédito
**Patrocinador:** Felipe Arango
**Gerente de proyecto:** Elena Duarte
**Comité:** Comité de Riesgos
**Producto asociado:** crédito de libranza
**Fecha de aprobación:** 2025-10-01

## Objetivo del negocio

Entregar crédito de libranza digital para Crédito.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**18.000.000.000 COP**, aprobado por Comité de Riesgos el 2025-10-01.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-10-11 |
| Cierre | 2027-01-12 |

## Criterio de éxito

Crédito de libranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
