# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-09-26
**Asistentes:** Andrés Lozano, Beatriz Cuéllar, Camilo Beltrán, Diana Molina, Felipe Arango, Gustavo Neira, Javier Hoyos, Jorge Medina, Laura Vélez, Mauricio Pérez, Natalia Ospina, Rubén Cárdenas, Óscar Ramírez

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-26 |
| Jorge Medina | Cerrar la prueba 2 | 2026-11-03 |
| Jorge Medina | Revisar el anexo 3 | 2026-11-11 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-20 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-30 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-26 |
| Mauricio Pérez | Enviar el documento 9 | por definir |
| Beatriz Cuéllar | Cerrar la prueba 10 | 2026-09-27 |
| Natalia Ospina | Revisar el anexo 11 | 2026-10-16 |
| Óscar Ramírez | Validar el ambiente 12 | 2026-10-14 |
| Felipe Arango | Aprobar el diseño 13 | 2026-10-15 |
| Gustavo Neira | Actualizar la matriz 14 | 2026-10-12 |
| Javier Hoyos | Confirmar la fecha 15 | 2026-10-17 |
| Rubén Cárdenas | Entregar el punto 16 | 2026-10-05 |

## Cerrados en esta reunión

- Validar el ambiente 4 (Sandra Gil): recibido, acta de recibo del 2026-09-26.

## Lo que se dijo

- Camilo Beltrán dice que ya entregó «entregar el punto 8». No se presentó acta.
