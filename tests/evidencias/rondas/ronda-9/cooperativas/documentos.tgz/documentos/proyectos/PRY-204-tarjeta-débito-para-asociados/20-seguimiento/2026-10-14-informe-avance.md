# Informe de avance · Tarjeta débito para asociados

**Código:** PRY-204
**Fecha de corte:** 2026-10-14
**Gerente:** Sandra Gil

## Estado declarado

**Verde**

Avance reportado: **76%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 3.048.492.028 |
| Ejecutado | 1.434.351.502 |
| Proyección al cierre | 6.459.948.939 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
