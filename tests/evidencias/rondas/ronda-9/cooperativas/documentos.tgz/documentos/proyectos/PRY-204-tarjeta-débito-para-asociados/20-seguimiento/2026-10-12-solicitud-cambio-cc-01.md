# Solicitud de cambio CC-01

**Proyecto:** PRY-204 · Tarjeta débito para asociados
**Fecha:** 2026-10-12
**Solicitante:** Sandra Gil

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +80 días sobre la línea base vigente |
| Costo | 160.000.000 COP adicionales |

## Autorización

Autorizada por el comité.
