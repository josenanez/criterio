# Informe de avance · Pagos con QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-14
**Gerente:** Camilo Beltrán

## Estado declarado

**Amarillo**

Avance reportado: **58%**

## Lo que pasó en el periodo

- Se levantó un hallazgo de seguridad en la revisión de arquitectura
- Se recibió el concepto pendiente del ente supervisor
- Se reprogramó la salida por el cierre contable de fin de mes

## Presupuesto

| | COP |
|---|---|
| Aprobado | 4.200.000.000 |
| Comprometido | 1.553.761.322 |
| Ejecutado | 1.004.189.836 |
| Proyección al cierre | 4.057.601.292 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
