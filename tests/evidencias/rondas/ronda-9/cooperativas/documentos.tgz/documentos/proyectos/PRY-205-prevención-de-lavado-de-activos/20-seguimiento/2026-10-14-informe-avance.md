# Informe de avance · Prevención de lavado de activos

**Código:** PRY-205
**Fecha de corte:** 2026-10-14
**Gerente:** Rubén Cárdenas

## Estado declarado

**Amarillo**

Avance reportado: **74%**

## Lo que pasó en el periodo

- El equipo perdió dos semanas por rotación de un desarrollador clave
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- Se recibió el concepto pendiente del ente supervisor

## Presupuesto

| | COP |
|---|---|
| Aprobado | 1.200.000.000 |
| Comprometido | 369.803.963 |
| Ejecutado | 723.657.628 |
| Proyección al cierre | 1.119.453.579 |

## Riesgos abiertos

- Aprobación del reglamento por el Consejo de Administración
