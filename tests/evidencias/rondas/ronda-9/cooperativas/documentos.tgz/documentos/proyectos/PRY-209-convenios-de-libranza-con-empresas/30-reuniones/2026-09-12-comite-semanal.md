# Comité de Tecnología · Convenios de libranza con empresas

**Fecha:** 2026-09-12
**Asistentes:** Andrés Lozano, Camilo Beltrán, Diana Molina, Gustavo Neira, Jorge Medina, Laura Vélez, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Diana Molina | Enviar el documento 1 | 2026-10-02 |
| Jorge Medina | Cerrar la prueba 2 | 2026-10-01 |
| Jorge Medina | Revisar el anexo 3 | 2026-10-02 |
| Sandra Gil | Validar el ambiente 4 | 2026-09-19 |
| Andrés Lozano | Aprobar el diseño 5 | 2026-09-20 |
| Laura Vélez | Actualizar la matriz 6 | 2026-09-30 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-09-26 |
| Camilo Beltrán | Entregar el punto 8 | 2026-09-23 |
