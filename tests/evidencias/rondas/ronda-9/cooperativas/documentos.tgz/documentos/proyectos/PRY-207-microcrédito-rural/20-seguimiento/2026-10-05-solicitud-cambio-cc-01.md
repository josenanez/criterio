# Solicitud de cambio CC-01

**Proyecto:** PRY-207 · Microcrédito rural
**Fecha:** 2026-10-05
**Solicitante:** Camilo Beltrán

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +110 días sobre la línea base vigente |
| Costo | 220.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
