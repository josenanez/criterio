# Informe de avance · Crédito de libranza digital

**Código:** PRY-200
**Fecha de corte:** 2026-10-13
**Gerente:** Elena Duarte

## Estado declarado

**Amarillo**

Avance reportado: **84%**

## Lo que pasó en el periodo

- El Consejo de Administración pidió ajustar el reglamento antes del piloto
- Se ajustó el plan de pruebas con el área de seguridad
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 18.000.000.000 |
| Comprometido | 11.948.069.445 |
| Ejecutado | 8.390.726.733 |
| Proyección al cierre | 18.323.116.908 |

## Riesgos abiertos

- Dependencia del proveedor del core cooperativo
- Aprobación del reglamento por el Consejo de Administración
