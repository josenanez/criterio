# Informe de avance · Aportes sociales en línea

**Código:** PRY-203
**Fecha de corte:** 2026-09-23
**Gerente:** Paula Céspedes

## Estado declarado

**Verde**

Avance reportado: **57%**

## Lo que pasó en el periodo

- Se acordó con arquitectura cómo se revisan los requisitos no funcionales
- El Consejo de Administración pidió ajustar el reglamento antes del piloto

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 2.123.715.582 |
| Ejecutado | 3.031.029.425 |
| Proyección al cierre | 7.116.748.864 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
