# Consejo de Administración · Motor de crédito

**Fecha:** 2026-10-15
**Asistentes:** Andrés Lozano, Carlos Peña

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| María Restrepo | Entregar el punto 13 | 2026-11-07 |
| Ricardo Salas | Entregar el punto 32 | 2026-10-15 |
