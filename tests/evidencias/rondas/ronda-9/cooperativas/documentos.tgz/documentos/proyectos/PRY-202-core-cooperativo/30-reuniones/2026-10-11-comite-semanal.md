# Comité de Educación · Core cooperativo

**Fecha:** 2026-10-11
**Asistentes:** Mauricio Pérez, Laura Vélez

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Natalia Ospina | Entregar el punto 23 | 2026-10-10 |
| Laura Vélez | Entregar el punto 40 | 2026-11-13 |
