# Definición de producto · Aportes sociales

**Código:** PRD-302
**Gerente de producto:** Felipe Arango
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-01-30

## El problema

El segmento Microempresarios no tiene aportes sociales.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-08-13 · verificado con la entrevista con doce clientes del segmento del 2026-09-20 (anexo «Verificación del supuesto» del 2026-09-20)

## Proyectos que lo construyen

- Ninguno declarado
