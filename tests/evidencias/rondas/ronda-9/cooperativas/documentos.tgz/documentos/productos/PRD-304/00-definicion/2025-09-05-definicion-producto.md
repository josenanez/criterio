# Definición de producto · Pagos QR

**Código:** PRD-304
**Gerente de producto:** Sandra Gil
**Segmento:** Pensionados
**Fecha de la definición:** 2025-09-05

## El problema

El segmento Pensionados no tiene pagos qr.

## La propuesta

- Propuesta principal

## Supuestos

- **Los asociados usan el canal digital** · declarado el 2026-04-29 · verificado con la entrevista con doce clientes del segmento del 2026-07-23 (anexo «Verificación del supuesto» del 2026-07-23)

## Proyectos que lo construyen

- Ninguno declarado
