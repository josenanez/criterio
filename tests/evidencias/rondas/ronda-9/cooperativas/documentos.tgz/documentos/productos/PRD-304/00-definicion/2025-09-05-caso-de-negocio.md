# Caso de negocio · Pagos QR

**Código:** PRD-304
**Fecha:** 2025-09-05
**Preparado por:** Sandra Gil

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 92.656 | Caso de negocio, 2025-09-05 |

## Retorno esperado

Retorno esperado en 24 meses.
