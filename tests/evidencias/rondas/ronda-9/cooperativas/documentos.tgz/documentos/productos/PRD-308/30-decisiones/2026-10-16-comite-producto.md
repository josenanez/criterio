# Comité de producto · Remesas familiares

**Fecha:** 2026-10-16
**Asistentes:** Felipe Arango

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4800 | Requerimiento REQ-4800 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-23 | — |
| REQ-4801 | Requerimiento REQ-4801 | Liliana Torres | se verifica en producción | Cliente entrevistado | propuesto | 2026-06-28 | — |
| REQ-4802 | Requerimiento REQ-4802 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-22 | — |
| REQ-4803 | Requerimiento REQ-4803 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-21 | — |
| REQ-4804 | Requerimiento REQ-4804 | Elena Duarte | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-17 | — |
| REQ-4805 | Requerimiento REQ-4805 | sin asignar | — | Cliente entrevistado | aceptado | 2026-05-31 | — |
| REQ-4806 | Requerimiento REQ-4806 | Camilo Beltrán | — | Cliente entrevistado | aceptado | 2026-08-12 | — |
| REQ-4807 | Requerimiento REQ-4807 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-28 | — |
| REQ-4808 | Requerimiento REQ-4808 | Natalia Ospina | — | — | propuesto | 2026-06-14 | — |
| REQ-4809 | Requerimiento REQ-4809 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-29 | — |
| REQ-4810 | Requerimiento REQ-4810 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-25 | — |
| REQ-4811 | Requerimiento REQ-4811 | Carlos Peña | se verifica en producción | — | aceptado | 2026-08-04 | — |
| REQ-4812 | Requerimiento REQ-4812 | Laura Vélez | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-06 | — |
| REQ-4813 | Requerimiento REQ-4813 | Paula Céspedes | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-25 | — |
| REQ-4814 | Requerimiento REQ-4814 | Paula Céspedes | se verifica en producción | — | aceptado | 2026-07-17 | — |
| REQ-4815 | Requerimiento REQ-4815 | Ricardo Salas | se verifica en producción | Cliente entrevistado | propuesto | 2026-03-31 | — |
| REQ-2037 | Requerimiento REQ-2037 | Felipe Arango | se verifica en producción | Cliente entrevistado | aceptado | 2026-10-13 | — |

## Decisiones

- Se mantiene el plan
