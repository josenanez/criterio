# Tablero de métricas · Remesas familiares

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-13

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 266.082 | 2026-10-13 |
