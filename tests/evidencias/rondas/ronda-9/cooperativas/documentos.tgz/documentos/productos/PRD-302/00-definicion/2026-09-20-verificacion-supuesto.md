# Verificación del supuesto · Aportes sociales

**Fecha:** 2026-09-20

**Supuesto:** El reglamento vigente lo permite

**Con qué se verificó:** la entrevista con doce clientes del segmento del 2026-09-20

**Resultado:** se confirmó.
