# Tablero de métricas · Crédito de libranza

**Fuente:** bodega de datos, tablero de producto
**Última actualización:** 2026-10-08

| Métrica | Valor medido | Corte |
|---|---|---|
| volumen_mensual | 166.885 | 2026-10-08 |
