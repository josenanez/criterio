# Definición de producto · Auxilios de solidaridad

**Código:** PRD-307
**Gerente de producto:** Óscar Ramírez
**Segmento:** Asociados urbanos
**Fecha de la definición:** 2026-04-29

## El problema

El segmento Asociados urbanos no tiene auxilios de solidaridad.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-06-01 · verificado con el documento técnico del proveedor del 2026-08-22 (anexo «Verificación del supuesto» del 2026-08-22)

## Proyectos que lo construyen

- Ninguno declarado
