# Caso de negocio · Remesas familiares

**Código:** PRD-308
**Fecha:** 2026-03-14
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 297.252 | Caso de negocio, 2026-03-14 |

## Retorno esperado

Retorno esperado en 24 meses.
