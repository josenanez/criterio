# Caso de negocio · Recaudos

**Código:** PRD-306
**Fecha:** 2026-07-01
**Preparado por:** Liliana Torres

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 75.827 | Caso de negocio, 2026-07-01 |

## Retorno esperado

Retorno esperado en 24 meses.
