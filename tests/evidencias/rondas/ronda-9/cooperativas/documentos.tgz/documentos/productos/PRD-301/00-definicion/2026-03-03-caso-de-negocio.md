# Caso de negocio · Ahorro a la vista

**Código:** PRD-301
**Fecha:** 2026-03-03
**Preparado por:** Diana Molina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 105.767 | Caso de negocio, 2026-03-03 |

## Retorno esperado

Retorno esperado en 24 meses.
