# Definición de producto · Tarjeta débito

**Código:** PRD-303
**Gerente de producto:** Rubén Cárdenas
**Segmento:** Microempresarios
**Fecha de la definición:** 2026-03-24

## El problema

El segmento Microempresarios no tiene tarjeta débito.

## La propuesta

- Propuesta principal

## Supuestos

- **El reglamento vigente lo permite** · declarado el 2026-09-18 · verificado con el concepto jurídico de cumplimiento del 2026-09-23 (anexo «Verificación del supuesto» del 2026-09-23)

## Proyectos que lo construyen

- Ninguno declarado
