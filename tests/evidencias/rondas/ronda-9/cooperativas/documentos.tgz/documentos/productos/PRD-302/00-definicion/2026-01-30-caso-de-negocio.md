# Caso de negocio · Aportes sociales

**Código:** PRD-302
**Fecha:** 2026-01-30
**Preparado por:** Felipe Arango

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 110.520 | Caso de negocio, 2026-01-30 |

## Retorno esperado

Retorno esperado en 24 meses.
