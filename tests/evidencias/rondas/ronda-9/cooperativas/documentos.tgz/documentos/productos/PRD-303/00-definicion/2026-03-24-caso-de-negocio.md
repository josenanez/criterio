# Caso de negocio · Tarjeta débito

**Código:** PRD-303
**Fecha:** 2026-03-24
**Preparado por:** Rubén Cárdenas

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 118.759 | Caso de negocio, 2026-03-24 |

## Retorno esperado

Retorno esperado en 24 meses.
