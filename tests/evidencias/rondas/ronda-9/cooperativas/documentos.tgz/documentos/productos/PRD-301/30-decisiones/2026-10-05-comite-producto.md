# Comité de producto · Ahorro a la vista

**Fecha:** 2026-10-05
**Asistentes:** Diana Molina

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4100 | Requerimiento REQ-4100 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-26 | — |
| REQ-4101 | Requerimiento REQ-4101 | Jorge Medina | se verifica en producción | Cliente entrevistado | propuesto | 2026-08-05 | — |
| REQ-4102 | Requerimiento REQ-4102 | Rubén Cárdenas | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4103 | Requerimiento REQ-4103 | Carlos Peña | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-31 | — |
| REQ-4104 | Requerimiento REQ-4104 | María Restrepo | se verifica en producción | Cliente entrevistado | propuesto | 2026-07-13 | — |
| REQ-4105 | Requerimiento REQ-4105 | Andrés Lozano | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4106 | Requerimiento REQ-4106 | Jorge Medina | — | — | aceptado | 2026-08-03 | — |
| REQ-4107 | Requerimiento REQ-4107 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-04-27 | — |
| REQ-4108 | Requerimiento REQ-4108 | Beatriz Cuéllar | — | Cliente entrevistado | propuesto | 2026-04-09 | — |
| REQ-4109 | Requerimiento REQ-4109 | Óscar Ramírez | — | Cliente entrevistado | aceptado | 2026-04-01 | — |
| REQ-4110 | Requerimiento REQ-4110 | Gustavo Neira | se verifica en producción | Cliente entrevistado | aceptado | 2026-07-14 | — |
| REQ-4111 | Requerimiento REQ-4111 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-30 | — |

## Decisiones

- Se mantiene el plan
