# Entrevistas · Microcrédito

**Ronda:** Ronda · 2026-04-27
**Realizadas por:** Óscar Ramírez

### Cliente entrevistado · 2026-04-27

> Lo necesito y hoy no lo tengo.

**Tema:** Necesidad principal
