# Caso de negocio · Auxilios de solidaridad

**Código:** PRD-307
**Fecha:** 2026-04-29
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 68.516 | Caso de negocio, 2026-04-29 |

## Retorno esperado

Retorno esperado en 24 meses.
