# Caso de negocio · Microcrédito

**Código:** PRD-305
**Fecha:** 2026-04-06
**Preparado por:** Óscar Ramírez

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 60.645 | Caso de negocio, 2026-04-06 |

## Retorno esperado

Retorno esperado en 24 meses.
