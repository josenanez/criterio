# Caso de negocio · Crédito de libranza

**Código:** PRD-300
**Fecha:** 2026-06-30
**Preparado por:** Jorge Medina

## Cifras que sostienen el caso

| Métrica | Valor declarado | Fuente |
|---|---|---|
| volumen_mensual | 200.638 | Caso de negocio, 2026-06-30 |

## Retorno esperado

Retorno esperado en 24 meses.
