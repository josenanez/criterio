# Comité de producto · Microseguros

**Fecha:** 2026-10-07
**Asistentes:** Carlos Peña

## Requerimientos revisados

| ID | Requerimiento | Doliente | Criterio de aceptación | Quién lo pidió | Estado | Desde | Proyecto que lo ejecuta |
|---|---|---|---|---|---|---|---|
| REQ-4900 | Requerimiento REQ-4900 | Javier Hoyos | se verifica en producción | Cliente entrevistado | aceptado | 2026-05-16 | — |
| REQ-4901 | Requerimiento REQ-4901 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-11 | — |
| REQ-4902 | Requerimiento REQ-4902 | Beatriz Cuéllar | — | — | propuesto | 2026-03-27 | — |
| REQ-4903 | Requerimiento REQ-4903 | Natalia Ospina | — | Cliente entrevistado | aceptado | 2026-07-17 | — |
| REQ-4904 | Requerimiento REQ-4904 | Beatriz Cuéllar | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-18 | — |
| REQ-4905 | Requerimiento REQ-4905 | Andrés Lozano | se verifica en producción | — | aceptado | 2026-04-17 | — |
| REQ-4906 | Requerimiento REQ-4906 | Óscar Ramírez | se verifica en producción | — | aceptado | 2026-03-17 | — |
| REQ-4907 | Requerimiento REQ-4907 | Liliana Torres | — | Cliente entrevistado | aceptado | 2026-06-03 | — |
| REQ-4908 | Requerimiento REQ-4908 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-01 | — |
| REQ-4909 | Requerimiento REQ-4909 | Camilo Beltrán | se verifica en producción | Cliente entrevistado | aceptado | 2026-08-06 | — |
| REQ-4910 | Requerimiento REQ-4910 | Óscar Ramírez | se verifica en producción | Cliente entrevistado | aceptado | 2026-03-17 | — |
| REQ-4911 | Requerimiento REQ-4911 | Beatriz Cuéllar | — | Cliente entrevistado | aceptado | 2026-04-07 | — |
| REQ-2026 | Requerimiento REQ-2026 | Natalia Ospina | se verifica en producción | Cliente entrevistado | aceptado | 2026-09-28 | — |

## Decisiones

- Se mantiene el plan
