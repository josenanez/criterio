# Corrida del 2026-10-17 · product-business-case

PRD-307 · 16 requerimientos · 26 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Caso de negocio estructurado de PRD-307: 1 cifra declarada con fuente (volumen_mensual 108.635 vs medida 76.086, 30 % por encima del umbral de 20 %), retorno sin cifra, costos ausentes (primer vacío), sin criterio de éxito, sin proyecto, sin otros productos publicados para cruzar. No produce ni estima cifras.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

# Caso de negocio — Remesas familiares (PRD-307) · borrador del 2026-10-17
**Desde:** la definición `00-definicion/2025-10-02-definicion-producto.md` (2025-10-02) y el caso de negocio `2025-10-02-caso-de-negocio.md` · **Cifras con fuente:** 1 de 1 (la única cifra del caso es el volumen mensual; el retorno no trae cifra)

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se volvieron a registrar.
Documento nuevo: no había un caso de negocio estructurado. Se partió del caso original de Felipe Arango, que son dos líneas.

## Qué problema resuelve, y para quién
«El segmento Microcomercio no tiene remesas familiares.» — definición, 2025-10-02. Segmento: Microcomercio. Sin tamaño del segmento, sin cuántos tienen el problema y sin lo que usan hoy.

## Qué se construye
La propuesta dice solo «Propuesta principal»: **no hay descripción de qué se construye**. Lo decidido está en el registro (acta del comité, 2026-10-16): 9 requerimientos aceptados.

| Requerimiento | Estado | Evidencia de demanda |
|---|---|---|
| REQ-4702 | aceptado (2026-08-31) | Ninguna; nadie lo pidió, sin criterio de aceptación |
| REQ-4703 | aceptado | Ninguna; nadie lo pidió |
| REQ-4705 | aceptado | «Cliente entrevistado» (entrevistas, 2025-10-10); sin criterio de aceptación |
| REQ-4706 | aceptado | Ninguna; nadie lo pidió |
| REQ-4707 | aceptado | Ninguna; nadie lo pidió |
| REQ-4709 | aceptado | «Cliente entrevistado» (2025-10-10) |
| REQ-4711 | aceptado | «Cliente entrevistado» (2025-10-10) |
| REQ-4713 | aceptado | Ninguna; nadie lo pidió |
| REQ-4714 | aceptado | «Cliente entrevistado» (2025-10-10); sin doliente |

5 de 9 aceptados no tienen evidencia de demanda. Los 9 siguen sin proyecto que los ejecute. Los títulos son solo el ID; el registro no dice qué es cada uno.

## Las cifras
| Cifra | Valor | Clase | De dónde sale | De cuándo |
|---|---|---|---|---|
| volumen_mensual | 108.635 | Declarada | Caso de negocio, Felipe Arango | 2025-10-02 |
| volumen_mensual | 76.086 | Medida | Tablero de métricas, bodega de datos | corte 2026-10-16 |
| Retorno esperado | «en 24 meses», sin valor | Supuesta (sin cifra) | Caso de negocio; ninguna base de cálculo ni fecha de partida | 2025-10-02 |

### Donde la cifra declarada y la medida no coinciden
| Métrica | Declarada | Medida | Las dos fuentes y fechas |
|---|---|---|---|
| volumen_mensual | 108.635 | 76.086 | Declarada por encima en 30 % (umbral 20 %). Caso de negocio, 2025-10-02 · Tablero de métricas, corte 2026-10-16. La serie tiene un solo punto; el caso no aclara si 108.635 era meta o línea de partida. |

Esta diferencia queda dentro del caso: un comité que lo lea verá las dos cifras juntas.

## Los costos
| Concepto | Valor | De dónde sale |
|---|---|---|
| Costo de construir | **no está en ningún documento** | — |
| Equipo, contratos, cotizaciones | no están en ningún documento | — |

Este es el primer vacío. Sin el costo de construir, lo que hay es una propuesta, no un caso de negocio que se pueda evaluar.

## Supuestos sobre los que se sostiene
| Supuesto | Qué pasa si resulta falso | Quién lo verificaría |
|---|---|---|
| La regulación vigente lo permite (declarado 2026-08-31; anexo del 2026-09-11 lo da por confirmado con «la medición del piloto») | El producto no se puede operar tal como está concebido. Los documentos no dicen qué norma ni qué país. | Revisión jurídica; el anexo no cita norma y una medición de piloto no equivale a una lectura de la norma |
| Microcomercio no tiene remesas familiares (afirmado como hecho) | No hay problema que resolver | Nadie todavía; solo lo respalda una frase de un entrevistado, posterior a la definición |
| El retorno llega en 24 meses | El caso pierde su razón económica | Nadie todavía: sin cifra ni base |
| El volumen mensual de 108.635 es alcanzable | El caso se sostiene en una cifra que hoy la medición contradice | Quien opera el producto; ver la tabla de coincidencias |

Se ofrece pasarlos al seguimiento de supuestos (assumption-tracking).

## Vacíos
| Qué falta | Por qué importa | Quién lo produce |
|---|---|---|
| Costo de construir y operar | Sin él no hay caso que evaluar | El negocio (Felipe Arango) |
| Retorno: valor, base de cálculo y fecha de partida de los 24 meses | «Retorno esperado» sin cifra no se puede defender | El negocio |
| Qué se construye (la propuesta) | El caso no dice cuál es el producto | Felipe Arango |
| Tamaño del segmento y cuánto pagaría | Sostiene el volumen | El negocio |
| País y norma | De él depende la parte normativa; hoy ninguna norma está a la vista | El negocio / revisión jurídica |
| Qué pasa si no se hace | Sin alternativa de comparación | El negocio |
| Alternativas consideradas | No hay ninguna escrita | El negocio |
| Proyecto que lo construye | Los 9 aceptados no tienen proyecto | Comité de producto |
| Quién decide | Ningún documento nombra la autoridad («Comité de producto» es la respuesta sugerida de la prueba) | La organización |

## Cómo se sabrá si funcionó
**No está declarado.** Ni la definición ni el caso traen criterio de éxito: solo «Retorno esperado en 24 meses», sin indicador, sin monto y sin fecha de corte. La única métrica con serie es volumen_mensual (76.086 al 2026-10-16), pero ningún documento dice que sea el criterio de éxito. Sin esto el producto no se podrá cerrar meses después.

## Si hay otros productos publicados
No hay otros productos publicados a la vista, así que no se pudo hacer el cruce de `/product-overlap`. Si otro producto afirma volumen_mensual, hay que cruzarlo antes del comité.

## Lo que este documento no hace
No proyecta ingresos, no calcula retorno ni periodo de recuperación, no estima beneficios y no recomienda aprobar ni rechazar. Ninguna cifra se rellenó con referencias del sector.
