# Corrida del 2026-10-17 · product-publish

PRD-307 · 16 requerimientos · 17 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

No se publicó: no hay carpeta de productos publicados configurada ni existente; nada escrito

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**No publiqué la ficha de PRD-307 (Remesas familiares).** Con corte al 2026-10-17.

**Motivo:** la configuración (`.criterio/producto/PRD-307/config.json`) no define una carpeta de productos publicados, y no existe ninguna carpeta `publicados/` en el espacio. Sin un sitio común acordado esto no sirve, y acordarlo es una conversación de la organización, no un comando. No creé la carpeta ni elegí una por mi cuenta.

**Lo que habría publicado (calculado, sin escribir):**
- **Lleva:** 16 requerimientos (9 aceptados, 7 propuestos) · 0 proyectos · 1 métrica afirmada
- **Segmento declarado:** Microcomercio
- **Métrica afirmada:** `volumen_mensual` = 108635.0, del caso de negocio `documentos/productos/PRD-307/00-definicion/2025-10-02-caso-de-negocio.md` (2025-10-02). Medido al 2026-10-16: 76086.0, o sea 30.0 % por debajo de lo declarado. La ficha lleva solo la cifra declarada, no la serie medida.
- Ningún requerimiento tiene proyecto asignado, así que la ficha no permitiría cruzar por proyecto.

**Términos:** ya vigentes, aceptados por José Francisco Ñáñez el 2026-10-17 (versión 1.1). No hubo que registrarlos de nuevo.

**Para publicar:** acordar y configurar la carpeta común de fichas (`productos/publicados/`) y volver a correr `/product-publish`.
