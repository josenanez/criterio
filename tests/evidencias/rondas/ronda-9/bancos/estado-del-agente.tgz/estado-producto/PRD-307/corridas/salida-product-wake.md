## Remesas familiares (PRD-307) · 2026-10-17

**Desde el corte anterior:** no hay corte anterior. Esta es la primera corrida del reloj, así que no puedo decir qué cruzó un umbral *desde* algo. Dejo el corte de hoy como línea de partida; desde la próxima corrida solo se reporta lo nuevo.

**Qué revisé:** la revisión mensual (nunca se había corrido). Contrasté el registro (16 requerimientos) contra el acta del comité del 2026-10-16, el tablero de métricas del 2026-10-16, la definición, el caso de negocio y la verificación del supuesto. Coinciden con el registro. No releí las entrevistas (.docx); me apoyo en lo que ya está extraído en el registro.

### Estado en el corte de hoy
| Qué | REQ | Cuánto lleva | Qué se necesita | Quién |
|---|---|---|---|---|
| Sin decidir (umbral 60 días) | 4700, 4701, 4704, 4708, 4710, 4712, 4715 | 87 a 205 días (4700: 205, 4704: 192, 4701: 152) | Que alguien con la facultad lo decida. El acta solo dice «Se mantiene el plan» y como asistente solo figura Felipe Arango; ningún documento nombra quién decide. | Comité de producto (según la configuración) |
| Aceptado sin nadie que lo construya | 4702, 4703, 4705, 4706, 4707, 4709, 4711, 4713, 4714 (9 de 9) | Aceptados el 2026-10-16 | Ninguno tiene proyecto. La definición dice «Ninguno declarado». Falta el acta de constitución o decir que no se construirá. | Felipe Arango |
| Aceptado sin evidencia de demanda | 4702, 4703, 4706, 4707, 4713 | — | Quién lo pidió: el acta no lo dice. | Doliente de cada uno |
| Aceptado sin criterio de aceptación | 4702, 4705 | — | Redactar el criterio antes de construir. | Felipe Arango, Carlos Peña |
| Sin doliente | 4708, 4714 | — | Asignar uno. 4714 ya está aceptado. | Comité de producto |
| Evidencia vencida (más de 12 meses) | 10 requerimientos | La única entrevista es del 2025-10-10, cumple 12 meses | Las afirmaciones que se sostienen en esa entrevista quedan sin sustento hasta que se vuelva a preguntar. | Felipe Arango |

### Lo que el negocio declara contra lo que miden los datos
El caso de negocio (2025-10-02) declara `volumen_mensual` = 108.635. El tablero del 2026-10-16 mide 76.086. El declarado está 30 % por encima de lo medido, con umbral de 20 %. Esto va al comité.

### Las trazas
No tengo carpeta de fichas de proyecto, así que **ninguna traza se da por confirmada**. El registro dice que ningún requerimiento tiene proyecto.

### Lo que no sé
- El criterio de éxito del producto no está escrito en ninguna parte.
- Quién tiene la facultad de decidir los requerimientos pendientes.

### Nota técnica
No pude sellar la lectura de los documentos: el sellado exige que la ficha se haya reescrito en esta corrida y no la reescribí. El siguiente barrido volverá a listar los 6 documentos como por leer.

**Vuelvo el 2026-11-16.**
