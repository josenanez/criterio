> **Borrador, no aprobado.** Lo redacta el agente; lo cierra Felipe Arango (gerente de producto, PRD-307) ante el Comité de producto. Este agente no puede dar esa firma.

# Especificación — Remesas familiares (PRD-307) · borrador del 2026-10-17

**Resumen en una línea:** del registro salen 9 requerimientos aceptados y ninguno dice qué problema concreto resuelve, así que **la sección de comportamiento no se puede escribir sin inventar**; esta versión deja el alcance, los criterios y los vacíos a la vista, y no rellena nada.

## Qué problema resuelve

Solo lo que dice la definición (`00-definicion/2025-10-02-definicion-producto.md`, 2025-10-02): *«El segmento Microcomercio no tiene remesas familiares.»* Segmento: Microcomercio.

Lo que la definición **no dice**: la propuesta (el texto es «Propuesta principal», sin contenido), el criterio de éxito (`not_found`; el caso de negocio solo dice «Retorno esperado en 24 meses», sin cifra), el país, y los proyectos que lo construyen («Ninguno declarado»).

## Alcance

### Entra
Los 9 requerimientos en estado `aceptado` según el acta del comité del 2026-10-16 (`30-decisiones/2026-10-16-comite-producto.md`). Ninguno está en `en_construccion`.

| REQ | Doliente | Aceptado según |
|---|---|---|
| REQ-4702 | Felipe Arango | acta 2026-10-16 |
| REQ-4703 | Andrés Lozano | acta 2026-10-16 |
| REQ-4705 | Carlos Peña | acta 2026-10-16 |
| REQ-4706 | Laura Vélez | acta 2026-10-16 |
| REQ-4707 | Elena Duarte | acta 2026-10-16 |
| REQ-4709 | Diana Molina | acta 2026-10-16 |
| REQ-4711 | Elena Duarte | acta 2026-10-16 |
| REQ-4713 | Paula Céspedes | acta 2026-10-16 |
| REQ-4714 | **sin asignar** | acta 2026-10-16 |

### No entra
- Los 7 requerimientos `propuesto` (nadie decidió nada sobre ellos): REQ-4700, 4701, 4704, 4708, 4710, 4712, 4715. Especificarlos sería escribir el documento antes de la decisión.
- Cualquier cosa que no esté en el registro. No hay requerimientos `descartado` registrados, así que no hay decisiones previas de «no» que citar.
- Diseño técnico, estimación, costo y fechas: no son de este documento.

## Comportamiento

**No se redacta.** Para los 9 requerimientos el registro tiene el título como placeholder («Requerimiento REQ-47xx») y el campo `need` no está en ninguna parte: ni el acta ni la definición dicen qué necesita cada uno. Escribir aquí «el usuario envía una remesa…» sería decidir por el agente lo que nadie decidió. Queda como el primer vacío (ver Vacíos, V1).

## Criterios de aceptación

El acta trae un solo texto como criterio: *«se verifica en producción»*. No pasa la prueba (dos personas mirando lo construido no pueden llegar a la misma respuesta: no dice qué, cuánto ni contra qué). Se transcribe tal cual y se marca; **no se reemplaza por uno razonable.**

| Criterio | Requerimiento | Cómo se verifica | ¿Se puede medir hoy? |
|---|---|---|---|
| «se verifica en producción» (acta 2026-10-16) | REQ-4703, 4706, 4707, 4709, 4711, 4713, 4714 | No definido: no hay magnitud, umbral ni fuente | **No.** No es verificable todavía |
| *(ninguno)* | REQ-4702, REQ-4705 | — | **No.** Sin criterio |

Lo único que la organización mide hoy en este producto es `volumen_mensual` (bodega de datos, tablero de producto, corte 2026-10-16: 76.086). Ningún criterio de arriba está atado a esa métrica ni a otra.

## Supuestos sobre los que está escrita

| Supuesto | Verificado | Quién lo verificaría |
|---|---|---|
| «La regulación vigente lo permite» (declarado 2026-08-31) | Registrado como verificado con «la medición del piloto del 2026-09-11». **Frágil:** el anexo (`2026-09-11-verificacion-supuesto.md`) solo dice «se confirmó», sin dato, sin norma, sin país; y una medición de piloto no es la fuente natural para confirmar que una norma permite algo. Además, el supuesto lleva fecha 2026-08-31 pero está en una definición fechada 2025-10-02 | Felipe Arango (aportar la medición y la cita) y la revisión jurídica |
| Los requerimientos no declaran supuestos propios (`assumptions` vacío en los 16) | — | Cada doliente; el agente no inventa los que «obviamente» tenían |

## Vacíos

| # | Qué falta decidir | Consecuencia de no decidirlo | Quién lo cierra |
|---|---|---|---|
| V1 | El problema concreto de cada requerimiento aceptado (`need`) y su título real | No hay comportamiento que especificar; el equipo construiría lo que cada quien imagina | Cada doliente (ver Alcance); REQ-4714 sin doliente → Felipe Arango asigna |
| V2 | Criterio de aceptación verificable en los 7 que dicen «se verifica en producción» | Ninguno se puede dar por cumplido sin discusión | Cada doliente, con Felipe Arango |
| V3 | Criterio de aceptación ausente en REQ-4702 y REQ-4705 | Aceptados sin forma de saber cuándo están hechos | Felipe Arango (doliente de 4702); Carlos Peña (4705) |
| V4 | Doliente de REQ-4714 (aceptado, «sin asignar») | Un requerimiento aceptado que nadie defiende | Felipe Arango |
| V5 | Evidencia de demanda: REQ-4702, 4703, 4706, 4707 y 4713 están aceptados sin ninguna; los demás aceptados citan todos la misma frase anónima («Lo necesito y hoy no lo tengo», entrevista del 2025-10-10) que no nombra ningún requerimiento y tiene 12 meses y 7 días (umbral: 12) | La aceptación descansa en demanda no demostrada y vencida | Felipe Arango (nueva ronda de entrevistas o evidencia citable) |
| V6 | Proyecto que ejecute cada requerimiento aceptado: en los 9 la traza es `not_found`; la definición dice «Ninguno declarado» | Lo decidido no tiene quién lo construya | Comité de producto → acta de constitución (`/product-charter`) |
| V7 | Quién decidió: el campo `who` no está en el acta para ninguna de las 9 aceptaciones. El acta lista un solo asistente (Felipe Arango) y solo dice «Se mantiene el plan», sin que exista un plan en los documentos | Decisión sin autor ni plan que la respalde | Comité de producto |
| V8 | Casos borde sin definir en ninguna parte: sin conexión, envío duplicado, cliente que se va antes de la confirmación, remesa rechazada o devuelta | Se decidirán al construir, por quien construya | Doliente de cada requerimiento |
| V9 | Lo que otro equipo tiene que hacer: los documentos no nombran ningún equipo ni proveedor y no hay proyecto; nada está acordado con nadie | No se sabe qué falta pedirle a quién | Felipe Arango |
| V10 | Criterio de éxito del producto y cifra del retorno (24 meses sin monto) | No hay con qué juzgar si la especificación sirvió | Felipe Arango |
| V11 | Cifra del caso de negocio vs. medición: `volumen_mensual` declarado 108.635 (2025-10-02) frente a 76.086 medido (2026-10-16), brecha de 30 % (umbral: 20 %). Ninguna de las dos gana por defecto | Cualquier dimensionamiento que use la cifra declarada parte de un dato que los datos no sostienen | Felipe Arango |
| V12 | Obligaciones normativas (barrido abajo) | Se descubren con el producto construido | Revisión jurídica de la organización |

### Barrido normativo (nombrar y citar, no dictaminar)

La definición no dice el país. Sin él no se puede citar norma, y el agente **no tiene ninguna a la vista**; no se inventa ninguna cita.

| Qué toca la definición | País | Obligación | Norma citada | Estado |
|---|---|---|---|---|
| Mueve dinero de una persona a otra (remesa) | no dicho | Autorización para operar como medio/sistema de pago o envío de dinero y reportes | — | no tengo la norma a la vista |
| Remesa «familiar» probablemente cruza fronteras | no dicho | Operaciones de cambio / transferencia internacional | — | no tengo la norma a la vista |
| Recoge datos de quien envía y quien recibe (la definición no lo detalla) | no dicho | Autorización y finalidad del tratamiento; si el dato sale del país, transferencia internacional | — | no tengo la norma a la vista |
| Identificación de clientes y control de operaciones sospechosas | no dicho | Conocimiento del cliente y prevención de lavado | — | no tengo la norma a la vista |
| Cobra al microcomercio (la definición no lo dice) | no dicho | Información previa, reclamos y cobros al consumidor | — | no tengo la norma a la vista |
| Conserva la trazabilidad de cada remesa | no dicho | Retención y entrega a la autoridad | — | no tengo la norma a la vista |

El supuesto «La regulación vigente lo permite» aparece como verificado, pero el anexo no cita ninguna norma: no se lee como un barrido resuelto. El estado de cada fila es, por ahora, `sin resolver` hasta que jurídico lo confirme. Esto es insumo para esa revisión, no un dictamen de cumplimiento.

## Requerimientos aceptados que esta especificación no cubre

Ninguno queda cubierto en comportamiento: los 9 están en el alcance solo por su ID.

| REQ | Título | Por qué no |
|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 | Sin `need`, sin criterio, sin evidencia, sin quién lo pidió |
| REQ-4703 | Requerimiento REQ-4703 | Sin `need`; criterio no verificable; sin evidencia ni quién lo pidió |
| REQ-4705 | Requerimiento REQ-4705 | Sin `need`; sin criterio; evidencia genérica vencida |
| REQ-4706 | Requerimiento REQ-4706 | Sin `need`; criterio no verificable; sin evidencia ni quién lo pidió |
| REQ-4707 | Requerimiento REQ-4707 | Sin `need`; criterio no verificable; sin evidencia ni quién lo pidió |
| REQ-4709 | Requerimiento REQ-4709 | Sin `need`; criterio no verificable; evidencia genérica vencida |
| REQ-4711 | Requerimiento REQ-4711 | Sin `need`; criterio no verificable; evidencia genérica vencida |
| REQ-4713 | Requerimiento REQ-4713 | Sin `need`; criterio no verificable; sin evidencia ni quién lo pidió |
| REQ-4714 | Requerimiento REQ-4714 | Sin `need`; sin doliente; criterio no verificable; evidencia genérica vencida |

## Después

No se ofrece `/product-charter` todavía: tiene los vacíos V1–V7 abiertos y el producto no tiene criterio de éxito. Cerrarlos es lo que habilita el acta.

---
**Pie.** Sale del registro `estado-producto/PRD-307/requirements/` (16 requerimientos; 9 cubiertos en alcance, 7 fuera por estar `propuesto`), con el acta del comité del 2026-10-16 como fuente de estado y la definición y el caso de negocio del 2025-10-02. Último documento del producto: 2026-10-16. Borrador del 2026-10-17. Términos aceptados (versión 1.1, por José Francisco Ñáñez, 2026-10-17); nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
