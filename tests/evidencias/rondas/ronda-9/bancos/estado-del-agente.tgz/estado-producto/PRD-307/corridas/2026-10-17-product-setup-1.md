# Corrida del 2026-10-17 · product-setup

PRD-307 · 16 requerimientos · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

> El tiempo no se midió: faltó `corrida-inicio` al arrancar.

0 preguntas (todas con respuesta sugerida); ~1 min hasta el primer resultado; 16 requerimientos levantados (9 aceptados, 7 propuestos); caso de negocio 30,0 % por encima del tablero; 5 aceptados sin evidencia, 10 con evidencia envejecida, 9 sin proyecto; sellar falló por falta de corrida-inicio

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Remesas familiares (PRD-307)

**Lo que miré:** 6 documentos · 1 de descubrimiento (entrevistas del 2025-10-10, un solo cliente y un solo tema) · la definición y el caso de negocio del 2025-10-02 · lo más reciente es del 2026-10-16 (acta del comité y tablero). Todos se leen; no hay formatos que se me escapen.
**Términos:** aceptados por José Francisco Ñáñez para la versión 1.1 (familia 0.4.0), el 2026-10-17 · comprobante en `.criterio/terminos/aceptacion-criterio-product-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 38ea1d146bbd84f3…
**Quién decide:** Comité de producto (respuesta sugerida; ningún documento lo dice, y el acta del 2026-10-16 solo registra como asistente a Felipe Arango).
**Dónde guardo lo que encuentro:** `estado-producto/PRD-307` (hermana de la documentación; no toco `estado/`, que es del portafolio).
**Preguntas:** 0 hechas; las cuatro con la respuesta sugerida, y los términos con el sí que trae la sesión de prueba.

### Lo que tu definición afirma, y qué lo sostiene
| Afirmación | Sostenida por | De cuándo |
|---|---|---|
| «El segmento Microcomercio no tiene remesas familiares» | Una entrevista: «Lo necesito y hoy no lo tengo». No dice a qué segmento pertenece el cliente | 2025-10-10 (12 meses) |
| Volumen mensual de 108.635 | Nada fuera del propio caso de negocio, que se cita a sí mismo como fuente. Contra el tablero mide 76.086 (corte 2026-10-16): el caso está **30,0 % por encima** | 2025-10-02 |
| «La regulación vigente lo permite» | Un supuesto declarado como verificado con «la medición del piloto del 2026-09-11». Una medición de piloto no dice qué permite la regulación; no hay concepto jurídico ni norma citada | 2026-08-31 / 2026-09-11 |
| «Retorno esperado en 24 meses» | Nada: no trae cifra | 2025-10-02 |

### Lo que no está dicho en ninguna parte
- **El criterio de éxito.** Ni la definición ni el caso de negocio lo escriben.
- **De dónde sale el 108.635** ni qué cuenta exactamente el «volumen mensual».
- **Cuánto es el retorno** ni contra qué inversión.
- **Qué demanda hay en Microcomercio.** Hay una cita de un cliente, sin segmento, sin tamaño y sin relación con ningún requerimiento en particular.
- **La medición del piloto del 2026-09-11.** Se cita como prueba, pero no está en la carpeta.
- **Qué dice la regulación.** Ninguna norma ni concepto jurídico.
- **Quién decidió** cada requerimiento aceptado. El acta solo dice «Se mantiene el plan».
- **Ningún proyecto ejecuta nada.** La definición dice «Ninguno declarado» y el acta pone «—» en los 16 requerimientos: los 9 aceptados no los está construyendo nadie que esté escrito.

Sobre el registro de requerimientos (16: 9 aceptados, 7 propuestos):
- **5 aceptados sin nadie que los haya pedido:** REQ-4702, 4703, 4706, 4707, 4713.
- **Los otros 4 aceptados (4705, 4709, 4711, 4714) se apoyan en la misma entrevista de hace 12 meses.** En total, 10 requerimientos tienen evidencia envejecida; ningún aceptado tiene demanda vigente.
- **2 aceptados sin criterio de aceptación:** REQ-4702, 4705. En los demás el criterio es la misma frase, «se verifica en producción», que no permite decir cuándo quedó hecho.
- **2 sin doliente:** REQ-4708 y REQ-4714 (este último ya aceptado).
- **Los 7 propuestos llevan más de 60 días sin decidirse**; el más viejo, REQ-4700, 205 días.

### Supuestos sobre los que está escrita
Uno declarado: «La regulación vigente lo permite». Está marcado como verificado, pero con una medición que no corresponde a lo que afirma (ver arriba). Además, la definición está fechada el 2025-10-02 y trae un supuesto declarado el 2026-08-31: se editó después de su fecha y la fecha no se actualizó. No declara más supuestos; lo que sostiene el volumen y el retorno ni siquiera está dicho como supuesto.

### Qué le falta a tu carpeta
- Las **transcripciones** de las entrevistas: hay una sola, resumida en una cita, y no nombra ningún requerimiento.
- La **serie de la métrica principal**: el tablero trae un único punto (2026-10-16); con un punto no se ve tendencia. Y nadie midió lo que el caso de negocio afirmó antes de esta fecha.
- La **medición del piloto** del 2026-09-11 y el soporte regulatorio del supuesto.
- Las **decisiones del comité por requerimiento**, con quién las tomó y por qué; hoy un requerimiento descartado se vería igual que uno que nadie miró.

**Una cosa que no pude hacer:** sellar la lectura (`sellar`) falló con «no hay una corrida abierta: sellar va después de corrida-inicio», y este comando no abre corrida con `corrida-inicio`. Lo dejo dicho y no lo forcé; la ficha y los 16 registros sí quedaron escritos.

**Siguiente paso:** `/product-discovery` sobre el material de entrevistas, que es donde los temas se vuelven requerimientos con la cita de quién los pidió.
