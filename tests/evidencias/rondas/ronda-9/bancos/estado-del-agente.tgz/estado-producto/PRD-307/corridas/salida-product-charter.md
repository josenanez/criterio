Términos vigentes (versión 0.4.0, aceptados por José Francisco Ñáñez el 2026-10-17): no se registran de nuevo.

**Verificación previa (paso 1) sobre REQ-4702.** Está aceptado, pero faltan tres de las cuatro condiciones. Respuesta sugerida tomada: seguir sin ellas, marcadas como vacíos del acta y sin rellenarlas.
- Criterios de aceptación: no hay. El acta del comité marca «—» y el registro tiene `acceptance: []`.
- Evidencia de demanda: no hay. «Quién lo pidió» es «—» y `evidence: []`.
- Autoridad del gerente: ningún documento la declara. `authority = Comité de producto` es una respuesta sugerida de la configuración, no un documento.

---

# Acta de constitución — Remesas familiares (REQ-4702) · borrador del 2026-10-17
**Producto:** PRD-307 · Remesas familiares · **Requerimientos:** REQ-4702

## Qué problema resuelve
«El segmento Microcomercio no tiene remesas familiares.» (`documentos/productos/PRD-307/00-definicion/2025-10-02-definicion-producto.md`, 2025-10-02). La definición no dice qué hace REQ-4702 dentro de ese problema: el requerimiento solo se titula «Requerimiento REQ-4702».

## Criterio de éxito
**No está dicho.**
- REQ-4702 no tiene criterios de aceptación (acta del comité 2026-10-16, columna vacía «—»).
- La definición no trae criterio de éxito. El caso de negocio dice solo «Retorno esperado en 24 meses», sin cifra (`2025-10-02-caso-de-negocio.md`).
- Sin esto el cierre no se podrá juzgar. Ver Vacíos.

## Alcance
### Entra
| REQ | Título | Evidencia que lo sostiene |
|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 | **Ninguna.** Estado «aceptado» el 2026-10-16 (acta del comité), doliente Felipe Arango, declarado desde 2026-08-31. No hay quién lo pidió ni cita de demanda. |

### No entra
| REQ | Título | Por qué no |
|---|---|---|
| REQ-4700, 4701, 4704, 4708, 4710, 4712, 4715 | Requerimiento REQ-… | Siguen en «propuesto» en el acta del 2026-10-16. Sin decisión del gerente de producto no hay acta. |
| REQ-4703, 4705, 4706, 4707, 4709, 4711, 4713, 4714 | Requerimiento REQ-… | Aceptados, pero esta acta es solo de REQ-4702. Cada uno necesita su propia acta o su inclusión explícita. No se asume. |

Todos figuran sin proyecto que los ejecute (acta: «—»).

## Gobierno
- **Patrocinador:** no está dicho en ningún documento.
- **Gerente propuesto:** no está dicho. El gerente de producto es Felipe Arango (definición, 2025-10-02). El gerente del proyecto es otro rol, y asignarlo es de quien tiene la autoridad.
- **Comité:** «Comité de producto», solo en la configuración. El acta del 2026-10-16 lista como único asistente a Felipe Arango.
- **Autoridad del gerente:** no está declarada. Es el campo que más cuesta después.
- **Quién decidió aceptar REQ-4702:** no consta (`decision.who: not_found`). El acta dice «Se mantiene el plan», sin nombrar a quién decide.

## Supuestos que se llevan al proyecto
| Supuesto | Verificado | Se convierte en riesgo de |
|---|---|---|
| «La regulación vigente lo permite» (declarado 2026-08-31) | Declarado como verificado con «la medición del piloto del 2026-09-11». El anexo solo dice «se confirmó», sin norma ni dato. Una medición de piloto no es un concepto regulatorio. **Verificación débil: tratar como no sustentada.** | Doliente: por asignar (Felipe Arango como propuesta). Se registra como riesgo con raid-taxonomy cuando el gerente del proyecto lo reciba. |

Además, el supuesto lleva fecha de declaración 2026-08-31, posterior a la definición del 2025-10-02. Se agregó después y la definición no lo registra como cambio.

## Restricciones normativas sin resolver
| Qué toca | Obligación | Norma | Estado |
|---|---|---|---|
| Remesas (transferencia de dinero, datos de remitente y beneficiario) | No se barrió ninguna. Ningún documento cita una norma. | Ninguna citada. No se inventa una. | **Sin resolver.** El supuesto de regulación es el único rastro. Requiere un barrido normativo antes de firmar. |

## Hallazgo adicional: la cifra del negocio no coincide con la medida
`volumen_mensual`: el caso de negocio declara 108.635 (2025-10-02). El tablero mide 76.086 (corte 2026-10-16). La brecha es de aproximadamente 30 %, sobre el umbral de 20 % configurado. Cualquier retorno que dependa de esa cifra queda sin sustento.

## Vacíos de este acta
| Qué falta | Consecuencia de firmar sin eso | Quién lo cierra |
|---|---|---|
| Criterios de aceptación de REQ-4702 | El cierre no se puede juzgar meses después. | Felipe Arango (doliente) |
| Evidencia de demanda y quién lo pidió | El proyecto arranca sin saber si alguien lo pidió. | Felipe Arango, con descubrimiento (ver entrevistas 2025-10-10) |
| Autoridad del gerente | El gerente escala todo o no escala nada. | Comité de producto (por confirmar) |
| Patrocinador | No hay quién responda por el presupuesto ni por el proyecto. | Por definir |
| Quién decidió la aceptación | La aceptación no es trazable a una persona. | Comité de producto |
| Criterio de éxito y retorno con cifra | No hay contra qué medir el cierre. | Felipe Arango |
| Barrido normativo y verificación real del supuesto regulatorio | El riesgo regulatorio entra al proyecto sin dueño ni fuente. | Por asignar (área legal o de cumplimiento) |
| Presupuesto aprobado e hitos | Ninguno declarado. No se inventan. | Quien firme |
| Cifra de volumen: 108.635 declarado contra 76.086 medido | El caso de negocio se sostiene en una cifra que los datos no respaldan. | Felipe Arango |

---
**Esto es un borrador.** Lo firma quien tenga la autoridad para hacerlo, por definir. Hoy ningún documento dice quién es. **La ficha del proyecto no se creó y no se crea hasta que haya firma.**

## Quién sigue
El proyecto necesita un gerente, y desde la firma la ficha es suya. Esa persona instala `criterio-project` y corre `/pm-setup`. Cuando publique su ficha con `/pm-publish`, `/product-trace` podrá confirmar la traza contra ella. No hay proyecto que lo ejecute todavía, y el acta no nombra gerente.
