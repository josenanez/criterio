# Corrida del 2026-10-17 · product-definition

PRD-307 · 16 requerimientos · 41 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

Volumen declarado 30% por encima del medido; criterio de éxito y autoridad sin documento; única evidencia de demanda es una entrevista de hace 12 meses; supuesto regulatorio confirmado sin norma citada

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Definición — Remesas familiares (PRD-307) · contrastada al 2026-10-17
**Documento:** `00-definicion/2025-10-02-definicion-producto.md` (con el caso de negocio `2025-10-02-caso-de-negocio.md` y el anexo `2026-09-11-verificacion-supuesto.md`) · **del** 2025-10-02 · 6 afirmaciones

Términos: ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no se volvieron a registrar.
Gerente: Felipe Arango. Instancia que decide: «Comité de producto», tomada de la respuesta sugerida de la prueba; ningún documento la nombra.

### Lo que la evidencia contradice
Nada que la evidencia diga en contra. Lo único que no coincide es una cifra, y va en la sección siguiente.

### El negocio y los datos
| Métrica | Declarado | Medido | Diferencia | Las dos fuentes y fechas |
|---|---|---|---|---|
| volumen_mensual | 108.635 | 76.086 | 30 %, declarado por encima (umbral 20 %) | Caso de negocio, 2025-10-02 · Tablero de métricas (bodega de datos), corte 2026-10-16 |

La serie tiene un solo punto. El cálculo compara contra ese punto; no dice si 108.635 era una meta o una línea de partida, porque el caso de negocio no lo aclara.

### Afirmaciones numéricas que nadie mide
Ninguna. La única cifra del caso de negocio (volumen_mensual) tiene serie. «Retorno esperado en 24 meses» no trae cifra, así que no hay nada que medir (ver la sección siguiente).

### No está dicho en ninguna parte
- **El criterio de éxito.** La definición no lo trae; el caso de negocio solo dice «Retorno esperado en 24 meses», sin monto ni indicador. Sin él el cierre no se puede juzgar.
- **Quién decide.** Ningún documento nombra a la autoridad; el acta del 2026-10-16 solo lista como asistente a Felipe Arango.
- **En qué consiste la propuesta.** La sección dice solo «Propuesta principal».
- **Cuántos microcomercios tienen el problema, ni cuánto pagarían.** «El segmento Microcomercio no tiene remesas familiares» no trae tamaño, ni precio, ni alternativa que usen hoy.
- **El país.** Ni la definición ni el caso de negocio lo dicen, y de él depende la parte normativa.
- **Qué proyecto lo construye.** La definición declara «Ninguno»; los 9 requerimientos aceptados siguen sin proyecto.
- **El retorno.** Sin cifra, sin base de cálculo, sin fecha de partida de los 24 meses.

### Sostenida por un supuesto
| Supuesto | Días sin verificar | Qué haría falta para verificarlo |
|---|---|---|
| La regulación vigente lo permite | 0 (el anexo del 2026-09-11 lo da por confirmado) | Nada pendiente de verificación según los documentos. Hay dos puntos que revisar: el supuesto figura «declarado el 2026-08-31» dentro de una definición fechada el 2025-10-02, y el anexo lo confirma con «la medición del piloto», sin decir qué se midió ni qué norma se miró. Una medición de piloto no es, por sí sola, una lectura de la norma; eso queda para la revisión jurídica. |

Además, «el segmento Microcomercio no tiene remesas familiares» se afirma como hecho sin que ningún documento lo sostenga por sí mismo: lo único cercano es una frase de un entrevistado (abajo). Hoy funciona como supuesto sin declarar.

### Sostenida por evidencia
| Afirmación | Sostenida por | De cuándo | Qué tan fuerte |
|---|---|---|---|
| Hay quien necesita remesas y no las tiene | Una entrevista, un cliente: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | 2025-10-10 | Débil: una voz, dicha una vez, y es **posterior en 8 días** a la definición, así que no pudo sostenerla cuando se escribió. Es lo que dijo alguien, no lo que alguien pagó. El documento no permite confirmar que esa persona sea del segmento Microcomercio. |
| El volumen mensual es de la magnitud declarada | Tablero de métricas | 2026-10-16 | Dato medido, pero **no la sostiene**: queda 30 % por debajo (ver arriba). |

### Evidencia que ya envejeció
| Afirmación | Lo más nuevo que la sostiene | Hace |
|---|---|---|
| Hay demanda de remesas en el segmento | Entrevista del 2025-10-10 | 12 meses (umbral 12): en el límite. Es también la evidencia de 10 requerimientos (REQ-4700, 4701, 4704, 4705, 4708, 4709, 4710, 4711, 4712, 4714) |

Contexto del registro, que es evidencia de la definición en los requerimientos: de 9 aceptados, 5 no tienen evidencia (REQ-4702, 4703, 4706, 4707, 4713) y 9 no tienen proyecto.

### Lo normativo que toca
Cuadro nombrado, **no citado**: el país no está declarado y no hay ninguna norma a la vista en los documentos. No dice si el producto cumple; esto va a revisión jurídica, no la reemplaza.

| Qué toca | País | Obligación | Norma | Estado |
|---|---|---|---|---|
| Mover dinero de una persona a su familia (remesa) | no declarado | Quién puede transferir y con qué autorización; reportes del medio de pago | — | no tengo la norma a la vista |
| Remesa que cruza fronteras (se infiere del nombre del producto; la definición no lo dice) | no declarado | Régimen de transferencias y cambios entre países | — | no tengo la norma a la vista |
| Datos de quien envía y de quien recibe | no declarado | Autorización previa y finalidad declarada del tratamiento | — | no tengo la norma a la vista |
| Dato que sale del país si se opera en nube | no declarado | Transferencia internacional de datos | — | no tengo la norma a la vista |
| Prevención de lavado de activos / conocimiento del cliente | no declarado | Identificación del cliente, monitoreo y reporte de operaciones | — | no tengo la norma a la vista |
| Atender a un microcomercio como consumidor financiero | no declarado | Información previa, reclamos, cobros | — | no tengo la norma a la vista |
| Conservación de la trazabilidad de la operación | no declarado | Cuánto se conserva y quién puede pedirlo | — | no tengo la norma a la vista |

El supuesto «la regulación vigente lo permite» está confirmado en el anexo, pero el anexo no cita norma alguna. Lo que quede sin resolver debería entrar al registro como restricción del requerimiento o como riesgo con doliente.

### Lo que falta para cerrar la definición
- **Criterio de éxito: falta.** Sin él el producto no se puede cerrar, porque el cierre se juzga contra él.
- **Quién decide: falta** (solo la respuesta sugerida de la prueba, sin documento).
- **El problema** y **para quién** están escritos (Microcomercio), pero sin tamaño ni evidencia propia más allá de la entrevista.
- Además: la propuesta, el país y el proyecto que lo construye.

### Lo que este contraste no hace
No decide si la demanda alcanza, no juzga si va a gustar, no dice si cumple la norma y no reescribe la definición.
