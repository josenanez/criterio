# Corrida del 2026-10-17 · product-trace

PRD-307 · 16 requerimientos · 32 s · 36 hallazgos

| Señal | Hallazgos |
|---|---:|
| `evidence_stale` | 10 |
| `requirement_untraced` | 9 |
| `requirement_undecided` | 7 |
| `requirement_accepted_without_evidence` | 5 |
| `requirement_without_acceptance` | 2 |
| `requirement_without_owner` | 2 |
| `claim_vs_metric` | 1 |

9 requerimientos aceptados el 2026-10-16 sin proyecto; ninguna de las 13 fichas nombra PRD-307

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Trazabilidad — Remesas familiares (PRD-307) · al 2026-10-17
9 decididos · 0 con proyecto · 0 confirmados contra la ficha · 0 entregados

Hay 16 requerimientos en el registro: 9 aceptados (los "decididos") y 7 propuestos. Se leyeron las 13 fichas de proyecto de `estado/records` (PRY-199 a PRY-211).

### Decidido y nadie lo está construyendo
Los 9 aceptados. Ninguno tiene proyecto en el registro, y el acta del comité tiene "—" en la columna «Proyecto que lo ejecuta» para todos.

| REQ | Título | Decidido el | Por quién |
|---|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 (doliente: Felipe Arango) | 2026-10-16 | Comité de producto; asistió Felipe Arango (documentos/productos/PRD-307/30-decisiones/2026-10-16-comite-producto.md) |
| REQ-4703 | Requerimiento REQ-4703 (doliente: Andrés Lozano) | 2026-10-16 | ídem |
| REQ-4705 | Requerimiento REQ-4705 (doliente: Carlos Peña) | 2026-10-16 | ídem |
| REQ-4706 | Requerimiento REQ-4706 (doliente: Laura Vélez) | 2026-10-16 | ídem |
| REQ-4707 | Requerimiento REQ-4707 (doliente: Elena Duarte) | 2026-10-16 | ídem |
| REQ-4709 | Requerimiento REQ-4709 (doliente: Diana Molina) | 2026-10-16 | ídem |
| REQ-4711 | Requerimiento REQ-4711 (doliente: Elena Duarte) | 2026-10-16 | ídem |
| REQ-4713 | Requerimiento REQ-4713 (doliente: Paula Céspedes) | 2026-10-16 | ídem |
| REQ-4714 | Requerimiento REQ-4714 (doliente: sin asignar) | 2026-10-16 | ídem |

La cadena se rompe en el segundo eslabón. La única decisión escrita del acta del 16-oct es «Se mantiene el plan». No nombra ningún requerimiento ni ningún proyecto, y el registro toma de ahí la fecha de decisión de los 9. Es una decisión citada, pero genérica.

### La traza no se confirma
Vacío. Ningún requerimiento declara un proyecto que lo ejecute, así que no hay traza que confirmar ni contradecir. Las 13 fichas están a la vista.

### Lo que un proyecto construye y el registro no tiene
Ninguno. Ninguna de las 13 fichas nombra PRD-307 ni «Remesas familiares» como producto que ejecuta. Los valores que declaran son:
- «crédito de consumo»
- «APIs de datos»
- «cuenta PyME»
- «cuenta de ahorros»
- «nómina empresarial»
- «pagos QR»
- «recaudos»
- «tarjeta débito»
- PRD-299 (otro producto)
- 4 fichas con el campo vacío

Esas 4 fichas con el campo vacío son un hallazgo del otro lado: no dicen qué producto ejecutan. Puede que alguna construya remesas, pero no se puede saber desde aquí.

### La cadena completa
| REQ | Estado | Decisión | Proyecto | Confirmado | Entregables |
|---|---|---|---|---|---|
| REQ-4702 | aceptado | 2026-10-16 («Se mantiene el plan») | — | no | — |
| REQ-4703 | aceptado | 2026-10-16 | — | no | — |
| REQ-4705 | aceptado | 2026-10-16 | — | no | — |
| REQ-4706 | aceptado | 2026-10-16 | — | no | — |
| REQ-4707 | aceptado | 2026-10-16 | — | no | — |
| REQ-4709 | aceptado | 2026-10-16 | — | no | — |
| REQ-4711 | aceptado | 2026-10-16 | — | no | — |
| REQ-4713 | aceptado | 2026-10-16 | — | no | — |
| REQ-4714 | aceptado | 2026-10-16 | — | no | — |

Los 7 propuestos (REQ-4700, 4701, 4704, 4708, 4710, 4712, 4715) no están decididos, así que no entran en la cadena. Su tema es otro: llevan entre 87 y 205 días sin decidirse.

### Sin fichas a la vista
No aplica. Se leyeron las 13 fichas disponibles. Que ninguna nombre PRD-307 no prueba que no haya un proyecto de remesas: solo prueba que ninguna ficha publicada lo dice.

### Notas
- La cobertura es 0 de 9, sin proyecto ni entregable.
- Si el comité quiere convertir alguno en proyecto, el siguiente paso es `/criterio-product:product-charter` para el requerimiento que ya esté listo.
- De los 9 aceptados, 5 no tienen evidencia de demanda y 2 no tienen criterio de aceptación (REQ-4702 y REQ-4705). Eso se ve mejor en `/product-requirements`.
