## Registro — Remesas familiares (PRD-307) · al 2026-10-17
16 requerimientos · 9 decididos · 44.4% con evidencia · 0% con proyecto que lo ejecuta

Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17). Cifras de `producto.py compute`. Todos los títulos del registro son el genérico «Requerimiento REQ-47xx»: el acta no los nombra.

### Se va a construir y nadie lo pidió
| REQ | Título | Estado | Doliente |
|---|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 | aceptado | Felipe Arango |
| REQ-4703 | Requerimiento REQ-4703 | aceptado | Andrés Lozano |
| REQ-4706 | Requerimiento REQ-4706 | aceptado | Laura Vélez |
| REQ-4707 | Requerimiento REQ-4707 | aceptado | Elena Duarte |
| REQ-4713 | Requerimiento REQ-4713 | aceptado | Paula Céspedes |

Cinco de los nueve aceptados no tienen una sola cita de quien lo pidió (el acta dice «—» en «Quién lo pidió»).

### Decidido y nadie lo está construyendo
| REQ | Título | Decidido el | |
|---|---|---|---|
| REQ-4702, 4703, 4705, 4706, 4707, 4709, 4711, 4713, 4714 | Requerimiento REQ-47xx | 2026-10-16 | Ninguno tiene proyecto; el acta dice «—» en las nueve filas |

Los nueve aceptados, sin proyecto: 0% de lo decidido se está ejecutando. Corresponde `/product-trace`.

### Sin doliente, o con un área en vez de una persona
| REQ | Título | Dice |
|---|---|---|
| REQ-4708 | Requerimiento REQ-4708 | «sin asignar» (propuesto) |
| REQ-4714 | Requerimiento REQ-4714 | «sin asignar» (**aceptado**) |

Quién lo cierra: Felipe Arango, gerente de producto, asigna a una persona; REQ-4714 primero, porque ya está aceptado.

### Sin criterio de aceptación
| REQ | Título | Estado |
|---|---|---|
| REQ-4702 | Requerimiento REQ-4702 | aceptado |
| REQ-4705 | Requerimiento REQ-4705 | aceptado |

Solo decididos. REQ-4710 y REQ-4715 tampoco lo tienen, pero están propuestos y no se les exige. Quién lo cierra: el doliente de cada uno (Felipe Arango en REQ-4702, Carlos Peña en REQ-4705).

Nota sobre los otros siete aceptados: su criterio es «se verifica en producción», que no dice qué se mide ni con qué umbral. Cuenta como criterio presente; que sea verificable es una conversación aparte.

### Decidido sin documento que lo respalde
| REQ | Quién decidió | Cuándo |
|---|---|---|
| — | — | — |

Los nueve aceptados remiten al acta de 2026-10-16, así que ninguno queda sin documento. Pero el acta es débil como respaldo: lista a un solo asistente (Felipe Arango), su única decisión es «Se mantiene el plan», y no dice quién aceptó cada requerimiento. En los nueve, «quién decidió» queda no encontrado.

### Lleva meses y nadie lo decide
Umbral de la configuración: 60 días.

| REQ | Título | Propuesto hace | Quién tiene la facultad |
|---|---|---|---|
| REQ-4700 | Requerimiento REQ-4700 | 205 días (2026-03-26) | Comité de producto |
| REQ-4704 | Requerimiento REQ-4704 | 192 días (2026-04-08) | Comité de producto |
| REQ-4701 | Requerimiento REQ-4701 | 152 días (2026-05-18) | Comité de producto |
| REQ-4712 | Requerimiento REQ-4712 | 108 días (2026-07-01) | Comité de producto |
| REQ-4710 | Requerimiento REQ-4710 | 98 días (2026-07-11) | Comité de producto |
| REQ-4708 | Requerimiento REQ-4708 | 91 días (2026-07-18) | Comité de producto |
| REQ-4715 | Requerimiento REQ-4715 | 87 días (2026-07-22) | Comité de producto |

Los siete propuestos pasaron el umbral. La facultad es del Comité de producto (según la configuración), con Felipe Arango como gerente. Se propone decidirlos —aceptar, descartar o pedir evidencia—; no se cierran por viejos. El comité del 16 de octubre los revisó y no decidió ninguno.

### Evidencia vieja
Umbral: 12 meses.

| REQ | Lo más nuevo que lo sostiene | Hace |
|---|---|---|
| REQ-4700, 4701, 4704, 4705, 4708, 4709, 4710, 4711, 4712, 4714 | Entrevista del 2025-10-10: «Lo necesito y hoy no lo tengo.» (tema: Necesidad principal) | 12 meses |

Diez requerimientos descansan en la misma cita de la misma entrevista. REQ-4715 no tiene evidencia que envejezca; tampoco la tienen los cinco de la primera sección.

## Por estado
| propuesto | aceptado | en construcción | entregado | descartado |
|---|---|---|---|---|
| 7 | 9 | 0 | 0 | 0 |

Ninguno descartado: no hay registro de lo que se rechazó, y esa discusión volverá.

## Aparte, de la definición
El caso de negocio declara un volumen mensual de 108 635 (2025-10-02); el tablero mide 76 086 (2026-10-16): 30% por debajo, sobre el umbral de 20%. El criterio de éxito de la definición no está dicho.

## Después
- `/product-trace`: nueve decididos sin proyecto.
- `/product-charter`: REQ-4709 y REQ-4711 tienen evidencia y criterio (la evidencia ya tiene 12 meses); REQ-4714 también, pero sin doliente. Son los candidatos.
