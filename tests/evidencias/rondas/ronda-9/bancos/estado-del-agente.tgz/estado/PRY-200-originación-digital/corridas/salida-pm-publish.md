Publiqué la ficha en `/home/claude/banco/ronda-9/bancos/espacio/documentos/proyectos/PRY-200-originación-digital/00-gobierno/ficha-pm.json`, con corte al 2026-10-17.

**Lleva:** 14 campos con dato · 2 sin decir en ninguna parte (`identity.authority`, `identity.phase`) · declara **verde** al 2026-10-17

**Lo más viejo que va ahí:** los campos de identidad, alcance, inicio y presupuesto aprobado, del 2026-05-28 (acta de constitución y cronograma v1), unos 5 meses; ninguno pasa de un año.

Antes de publicar:
- Recalculé la ficha con `compute` (corte 2026-10-17).
- Fecha de cierre: no hay cronograma más nuevo que el v1, así que `plan.end_date` (2027-06-04) coincide con la línea base y no hay diferencia que declarar.
- Términos: ya estaban vigentes (aceptados por José Francisco Ñáñez el 2026-10-17); no se registraron de nuevo.
- La carpeta de gobierno ya existía; no se creó nada.

**Ojo antes de que la PMO la lea:** la ficha declara **verde**, y las señales calculadas lo contradicen: hito «Diseño funcional aprobado» vencido hace 12 días, proyección de costo 15,9 % sobre lo aprobado (COP 20.859.955.929 contra 18.000.000.000), 8 compromisos vencidos y 2 reprogramados 4 y 6 veces. La declaración sigue siendo de la gerente y va marcada como declarada.
