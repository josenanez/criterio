Términos: vigentes (aceptados por José Francisco Ñáñez el 2026-10-17, versión 0.4.0); no hizo falta registrarlos de nuevo.

Supuestos que tomé sin preguntar (nadie responde en esta sesión): la fecha es **2026-10-31** (`committee_next` en la configuración; las notas de hoy dicen «en dos semanas», lo que coincide) y la reunión dura **50 minutos** (no hay duración configurada). El `diff` no tiene snapshot previo, así que esta corrida es el punto de partida: «sin cambios desde» no se puede calcular y el anexo se arma por otro criterio (abajo). Los plazos se cuentan al 2026-10-17; el 10-31 se verifican en la sala.

## Reunión de seguimiento — Originación digital (PRY-200) · 2026-10-31
11 puntos · 50 minutos · 11 personas requeridas (Diana Molina, Elena Duarte, Ricardo Salas, Sandra Gil, Carlos Peña, Felipe Arango, María Restrepo, Gustavo Neira, Laura Vélez, Óscar Ramírez y Jorge Medina, patrocinador, para las decisiones)

### Lo que no se destraba solo

> **[1] Nombrar qué bloquea «Enviar el documento 1», o declarar que no se sabe** · 10 min · **Elena Duarte**
> Prometido para el 12-05, y antes para el 11-21, el 11-11, el 11-03, el 10-19, el 10-09 y, al principio, el 09-25. Seis reprogramaciones; el umbral es 3.
> Fuente: notas de la reunión del 2026-10-17 (última fecha, escrita «05/12/2026», leída día/mes; confirmar con Elena) y comités del 09-05 al 10-10.
> **Si no se resuelve hoy:** hay una séptima fecha. La ficha no dice qué depende del documento 1, así que no puedo decir qué se atrasa con él; que Elena lo diga es parte del punto.
> Sale con: la causa dicha en una frase, quién puede quitarla y una fecha que esa persona respalde.

> **[2] Nombrar qué bloquea «Cerrar la prueba 2», o declarar que no se sabe** · 8 min · **Ricardo Salas**
> Primera fecha 09-20 (el 09-05 estaba «por definir»); después 10-09, 10-25, 11-06 y 11-20. Cuatro reprogramaciones.
> Fuente: comités del 2026-09-19, 09-26, 10-03 y 10-10.
> **Si no se resuelve hoy:** una quinta fecha. El informe de avance del 10-17 dice que «la prueba de carga no alcanzó el umbral pactado y se repite»; no dice si es esta prueba. Preguntarlo.
> Sale con: la causa y quién la quita, igual que arriba.

### Vencido sin evidencia
Más viejo primero. En ningún caso hay acta ni entregable en el expediente.

| Quién | Qué | Desde | Qué se necesita hoy | Min |
|---|---|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 09-22 (25 días) | Evidencia de que se validó, o fecha nueva dicha por ella | 2 |
| Carlos Peña | Validar el ambiente 4 (09-25), entregar el punto 8 (antes 10-01, luego 10-10), confirmar la fecha 15 (10-15) | 09-25 (22 días) | Tres vencidos en una sola persona: ¿qué tiene en común? Evidencia o fecha de cada uno | 5 |
| Felipe Arango | Revisar el anexo 11 | 09-29 (18 días) | Evidencia o fecha nueva | 2 |
| María Restrepo | Aprobar el diseño 13 | 10-06 (11 días) | Evidencia o fecha nueva; de paso, fecha para «Entregar el punto 24», que sigue «por definir» | 2 |
| Gustavo Neira | Cerrar la prueba 18 (10-08) y confirmar la fecha 7 (antes 10-06, luego 10-14) | 10-08 (9 días) | De la fecha 7 dijo el 09-26 que ya la había entregado: que traiga el acta o diga que no | 3 |

Fuente: comités semanales del 2026-09-05 al 10-10 y recálculo de la corrida de compromisos del 2026-10-17.

### Se decide hoy o se atrasa

| Qué | Quién decide | Si no se decide | Min |
|---|---|---|---|
| Fecha de «Mandar el ajuste del presupuesto» (Laura Vélez dijo «la otra semana» el 10-17; nadie puso fecha) | Laura la propone; las notas no dicen quién la fija | Sigue sin fecha, y no puede vencer: es un compromiso invisible. Fuente: notas 2026-10-17 | 4 |
| Dueño y fecha de «Diseño funcional aprobado» (hito del 2026-10-05, sin evidencia) | No consta en la ficha | El hito sigue «pendiente» mientras el informe declara verde. Mauricio Pérez tiene «Aprobar el diseño 21» para el 10-20: puede estar relacionado, no consta. Fuente: cronograma v1 e informe del 10-17 | 5 |
| Riesgo del proveedor («podría no llegar con el equipo completo para la siguiente fase»): registrarlo con dueño, probabilidad e impacto, y qué salió de la revisión de Óscar Ramírez (10-27) | Diana Molina lo registra; el dueño no consta | Se sigue «comentando» sin que nadie lo gestione. No estaba en el informe del 10-17 y la ficha no tiene proveedor registrado. Fuente: notas 2026-10-17 | 5 |

### Vence antes de la próxima

| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Validar el ambiente 20 | 10-17 (la reunión de hoy no lo mencionó) |
| Mauricio Pérez | Aprobar el diseño 21 | 10-20 |
| Paula Céspedes | Actualizar la matriz 22 | 10-24 |
| Andrés Lozano | Entregar el punto 16 (reprogramado 1 vez) | 10-27 |
| Óscar Ramírez | Revisión con el proveedor | 10-27 |
| Jorge Medina | Enviar el documento 17 (reprogramado 1 vez) | 10-28 |
| Laura Vélez / Camilo Beltrán | Confirmar la fecha 23 / revisar el anexo 19 (reprogramado 1 vez) | 11-07 / 11-08 |

Todos vencen antes del 10-31 salvo los dos últimos. Un minuto en la sala para ver quién trae el acta y quién no: **4 min** en total. Mauricio, Paula y Andrés no son requeridos si mandan el acta antes.

### No es de esta reunión

| Qué | Por qué | Dónde va |
|---|---|---|
| Proyección de costo de COP 20.859.955.929 contra COP 18.000.000.000 aprobados (15,9 %; el umbral es 10 %) | Excede la autoridad del gerente. La ficha no dice quién tiene la facultad (`authority` sin encontrar) | `/pm-escalate` y material de comité |
| Estado declarado **verde** frente a estos vencidos, estas reprogramaciones, el hito pasado y la proyección | La declaración es de Diana Molina; contrastarla con la evidencia es del informe, no de la sala | `/pm-report` |
| Liliana Torres, «Actualizar la matriz 14» (sin fecha) | No asistió el 10-17. Dijo el 10-03 que ya entregó y no hay acta | Fuera de sala: pedirle el documento antes del 10-31; si no llega, entra como vencido sin evidencia |
| Cadencia: la configuración dice comité semanal, las notas dicen «dos semanas» | Es del gerente, no de la sala | Diana confirma la fecha real y corrige `config.json` o la convocatoria |

### Anexo — no se repasa
El diff no tiene reunión anterior contra la cual comparar. Este anexo es lo que no necesita a nadie en la sala:
- Cerrados con acta de recibo: Gustavo Neira (anexo 3), Elena Duarte (diseño 5 y prueba 10), Beatriz Cuéllar (matriz 6), Jorge Medina (documento 9).
- Con fecha futura y sin novedad: Laura Vélez (fecha 23, 11-07), Camilo Beltrán (anexo 19, 11-08), Ricardo Salas (prueba 2, ya en el punto 2).

### Después
No convoco a nadie ni dirijo la reunión. Cuando termine, `/pm-minutes` sobre las notas; los compromisos nuevos entran a `/pm-commitments` con su cita.
