# Corrida del 2026-10-17 · pm-commitments

1 proyectos · 28 s · 16 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `commitment_undated` | 3 |
| `commitment_rescheduled` | 2 |
| `milestone_overdue` | 1 |
| `variance_cost` | 1 |
| `declared_vs_evidence` | 1 |

Elena Duarte (6 reprogramaciones) y Ricardo Salas (4) pasan el umbral; 8 vencidos sin evidencia, 3 de Carlos Peña; informe declara verde

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## Compromisos — PRY-200 Originación digital · al 2026-10-17

21 abiertos en total: 8 vencidos sin evidencia, 2 reprogramados (los dos ya pasan el umbral de 3), 3 sin fecha, 3 que vencen esta semana y 5 con fecha futura más allá de ella. Otros 5 están cerrados con documento.

### Se viene reprogramando

> **Elena Duarte** · Enviar el documento 1
> Prometido para el 2026-09-25, y después para el 10-09, el 10-19, el 11-03, el 11-11, el 11-21 y el 12-05. **Seis reprogramaciones.**
> La última sale de las notas de hoy («05/12/2026»); la leí como día/mes, y conviene confirmarlo con ella.
> **Seis veces no es un problema de seguimiento: es un bloqueo que nadie ha nombrado.**

> **Ricardo Salas** · Cerrar la prueba 2
> Primera fecha 2026-09-20 (el 09-05 estaba «por definir»), y después 10-09, 10-25, 11-06 y 11-20. **Cuatro reprogramaciones.**
> **Cuatro veces tampoco es seguimiento: es un bloqueo que nadie ha nombrado.**

### Vencidos sin evidencia
Ordenados por días de atraso. Ninguno tiene acta ni entregable en el expediente.

| Quién | Qué | Prometido para | Hace |
|---|---|---|---|
| Sandra Gil | Validar el ambiente 12 | 2026-09-22 | 25 días |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 días |
| Felipe Arango | Revisar el anexo 11 | 2026-09-29 | 18 días |
| María Restrepo | Aprobar el diseño 13 | 2026-10-06 | 11 días |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-08 | 9 días |
| Carlos Peña | Entregar el punto 8 (antes 10-01) | 2026-10-10 | 7 días |
| Gustavo Neira | Confirmar la fecha 7 (antes 10-06) | 2026-10-14 | 3 días |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-15 | 2 días |

- **Gustavo Neira** dijo el 09-26 que «la fecha 7» ya estaba entregada. No se presentó acta y desde esa reunión dejó de aparecer en la tabla. Sigue abierto: no hay nada en el expediente que lo respalde.
- **Carlos Peña** tiene tres de los ocho vencidos. Es un dato de concentración, no un juicio sobre el porqué.

### Vencen esta semana
| Quién | Qué | Para cuándo |
|---|---|---|
| Elena Duarte | Validar el ambiente 20 | 2026-10-17 (hoy) |
| Mauricio Pérez | Aprobar el diseño 21 | 2026-10-20 |
| Paula Céspedes | Actualizar la matriz 22 | 2026-10-24 |

Elena Duarte también es la dueña del documento 1, reprogramado seis veces.

### Sin fecha
No pueden estar vencidos; se cuentan aparte para que no desaparezcan.

| Quién | Qué | Dicho el |
|---|---|---|
| Liliana Torres | Actualizar la matriz 14 | 2026-09-26 |
| María Restrepo | Entregar el punto 24 | 2026-10-10 |
| Laura Vélez | Mandar el ajuste del presupuesto | 2026-10-17 |

- Liliana Torres dijo el 10-03 que ya entregó. No hay acta y desde el 10-10 no aparece en la tabla; sigue abierto.
- Laura Vélez dijo «la otra semana» y nadie puso fecha.
- María Restrepo ya tiene vencido «Aprobar el diseño 13».

### Con fecha futura, sin novedad
Andrés Lozano (punto 16, 10-27, reprogramado una vez), Jorge Medina (documento 17, 10-28, reprogramado una vez), Camilo Beltrán (anexo 19, 11-08, reprogramado una vez), Laura Vélez (fecha 23, 11-07) y Óscar Ramírez (revisión con el proveedor, 10-27).

### Cerrados con documento
Gustavo Neira (anexo 3), Elena Duarte (diseño 5 y prueba 10), Beatriz Cuéllar (matriz 6) y Jorge Medina (documento 9). Cada uno se cerró contra el acta de recibo de `20-seguimiento/`.

### Lo que esto dice del informe de avance
El informe de hoy declara **verde**. Contra eso están estos compromisos vencidos y reprogramados, el hito «Diseño funcional aprobado» (vencía el 10-05, 12 días sin evidencia) y una proyección de costo 15,9 % sobre lo aprobado. Nada de eso lo explica el informe.

### Después
- **Elena Duarte (6) y Ricardo Salas (4) pasan el umbral de reprogramación.** Puedo formularlos como decisión para el comité: qué se pide, qué pasa si no se decide y quién tiene la facultad. Eso excede la autoridad del gerente y por eso sube.
- Los compromisos cambiaron lo que la ficha decía: puedes correr `/pm-publish` para que la PMO lo vea.
