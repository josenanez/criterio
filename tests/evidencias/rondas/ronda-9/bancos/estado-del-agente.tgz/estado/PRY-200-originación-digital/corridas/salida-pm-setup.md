Soy Samuel. Proceso lo que pasa en tu proyecto y llevo la cuenta de lo que se prometió en cada reunión.

## Listo — PRY-200 · Originación digital

**Lo que miré:** 15 documentos · 7 minutas (6 comités semanales y las notas del 2026-10-17) · la última del 2026-10-17. Leí las 7, de la más vieja a la más nueva, más 5 actas de recibo, el informe de avance, el acta de constitución y el cronograma. Todos los formatos se pudieron leer.
**Configuración (respuestas sugeridas, sin interlocutor):** gerente Diana Molina (acta de constitución) · comité semanal, los sábados (así caen las minutas) · estado en `estado/PRY-200-originación-digital`.
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.4.0 (2026-10-17) · comprobante en `.criterio/terminos/aceptacion-criterio-project-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 99704ec1070b8386… (md) · 0c3de2b80140ee41… (pdf)
Texto mostrado: «Criterio produce borradores de trabajo, no decisiones ni asesoría. Procesa los documentos que usted le indique y dice lo que muestran; no sabe lo que se habló fuera de ellos. Puede equivocarse, y por eso cada dato viene con la cita del documento de donde salió: la verificación es suya. Sus documentos se procesan en la infraestructura de la plataforma de IA, no solo en su equipo. Cada versión se certifica antes de publicarse; garantía y responsabilidad: licencia Apache 2.0. Cada versión se acepta de nuevo y deja un comprobante en Markdown y PDF con su huella SHA-256.» Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

### Lo que está abierto, y cuántas veces se ha movido
La ficha tiene 26 compromisos: 5 cumplidos con acta, 8 vencidos sin evidencia, 3 sin fecha y 10 vigentes.

**Los que se vienen moviendo**
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-05 | Reprogramado 6 veces. Primera promesa 2026-09-25 (comité 2026-09-05); luego 2026-10-09, 10-19, 11-03, 11-11, 11-21 y 12-05 (notas 2026-10-17, escrito «05/12/2026», leído día/mes). |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-20 | Reprogramado 4 veces. Estaba «por definir» el 2026-09-05; su primera fecha, 2026-09-20 (comité 2026-09-12), no cuenta como reprogramación. Luego 10-09, 10-25, 11-06 y 11-20. |

Son el mismo patrón que describe la herramienta: no son dos vencidos, son dos bloqueos que nadie ha nombrado. Ninguno aparece en el informe de avance.

**Vencidos sin evidencia** (a 2026-10-17)
| Quién | Qué | Para cuándo | Días | Cita |
|---|---|---|---|---|
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 | 22 | comité 2026-09-05 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-22 | 25 | comité 2026-09-19 |
| Felipe Arango | Revisar el anexo 11 | 2026-09-29 | 18 | comité 2026-09-19 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-06 | 11 | comité 2026-09-26 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-08 | 9 | comité 2026-10-03 |
| Carlos Peña | Entregar el punto 8 | 2026-10-10 (antes 2026-10-01) | 7 | comité 2026-09-12 |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-15 | 2 | comité 2026-09-26 |
| Gustavo Neira | Confirmar la fecha 7 | 2026-10-14 (antes 2026-10-06) | 3 | comité 2026-09-12 |

Sobre «Confirmar la fecha 7»: el 2026-09-26 Gustavo Neira dijo que ya lo entregó y «no se presentó acta»; dicho en la reunión no lo cierra. Los de Carlos Peña (4, 8 y 15) repiten la misma fecha en cada comité sin que nadie los mueva ni los cierre.

**Vigentes con fecha:** Elena Duarte, Enviar el documento 1 (arriba) y Validar el ambiente 20 (2026-10-17, vence hoy) · Ricardo Salas (arriba) · Mauricio Pérez, Aprobar el diseño 21 (2026-10-20) · Paula Céspedes, Actualizar la matriz 22 (2026-10-24) · Óscar Ramírez, Revisión con el proveedor (2026-10-27) · Andrés Lozano, Entregar el punto 16 (2026-10-27, antes 2026-10-14) · Jorge Medina, Enviar el documento 17 (2026-10-28, antes 2026-10-08) · Laura Vélez, Confirmar la fecha 23 (2026-11-07) · Camilo Beltrán, Revisar el anexo 19 (2026-11-08, antes 2026-10-26).

**Cumplidos con acta de recibo:** Revisar el anexo 3 (Gustavo Neira, 2026-09-26) · Aprobar el diseño 5 (Elena Duarte, 2026-09-19) · Actualizar la matriz 6 (Beatriz Cuéllar, 2026-09-19) · Enviar el documento 9 (Jorge Medina, 2026-09-26) · Cerrar la prueba 10 (Elena Duarte, 2026-10-03).

### Sin fecha
Estos no pueden estar vencidos, y por eso son los que desaparecen de los informes:
- Liliana Torres — Actualizar la matriz 14 (comité 2026-09-26: «por definir»). El 2026-10-03 dijo que ya entregó; no se presentó acta, y desde el 2026-10-10 no figura en la tabla.
- María Restrepo — Entregar el punto 24 (comité 2026-10-10: «por definir»).
- Laura Vélez — Mandar el ajuste del presupuesto (notas 2026-10-17: «la otra semana»; nadie dio fecha, no la calculé).

### Otras señales que levantó el cálculo
- **Estado declarado verde contra la evidencia.** El informe de avance del 2026-10-17 declara **verde** y 36%. En esa misma fecha hay 8 compromisos vencidos, 2 reprogramados varias veces, 1 hito vencido y una desviación de costo; el informe no menciona ninguna. El estado lo declaras tú; aquí está contra qué.
- **Hito vencido:** «Diseño funcional aprobado», 2026-10-05, 12 días, sigue «en curso» en el cronograma y no hay acta que lo pruebe.
- **Costo:** la proyección al cierre (20.859.955.929 COP) supera el aprobado (18.000.000.000 COP) en 15,9 %. Ejecutado 25,7 %, comprometido 34,5 %.
- **Riesgo dicho y no registrado:** en las notas del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, y «nadie lo anotó como riesgo». Quedó en la ficha, marcado así.
- **Campos sin dato:** facultad del gerente (cuánto puede decidir sin subir a comité) y etapa declarada.

### Qué le falta a tu carpeta
- Actas de recibo de lo que dicen haber entregado: Confirmar la fecha 7 y Actualizar la matriz 14. Sin ellas se ven igual que los incumplidos.
- El cronograma vigente: solo hay la v1 del 2026-05-28, y ya tiene un hito vencido sin nueva fecha.
- Las minutas dan solo la tabla de compromisos; no traen decisiones, riesgos ni lo que se dijo en la sala, salvo las notas del 17-oct. Si hay actas completas, vale la pena sumarlas.
- Ni el acta de constitución ni los documentos declaran dependencias; el informe sí cita una (calendario de liberaciones del core), pero sin proyecto responsable.

**Cuándo vuelvo:** el comité es semanal y las notas del 2026-10-17 dicen «próxima reunión en dos semanas», así que la ficha deja como próxima reunión el 2026-10-31. Si la cadencia es semanal de verdad, dime y lo cambio.

*Pendiente:* la ficha no está sellada (leí reuniones y actas, no el proyecto entero), y no hay nada de la lectura de los 15 documentos que haya quedado sin hacer.
