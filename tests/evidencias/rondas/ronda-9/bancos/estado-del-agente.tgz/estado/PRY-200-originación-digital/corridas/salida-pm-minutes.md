# Acta — Originación digital (PRY-200) · 2026-10-17
**Asistieron (15):** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez · **Fuente:** `2026-10-17-notas-reunion.txt` · **Ausentes con tema en agenda:** no hay agenda en la carpeta, así que no se puede decir. Hay dos ausentes con compromisos abiertos, sin que eso implique que tuvieran tema hoy: Liliana Torres (matriz 14) y Beatriz Cuéllar (sin compromisos abiertos).

Términos: vigentes (aceptados por José Francisco Ñáñez el 2026-10-17, versión 0.4.0); no hizo falta registrarlos de nuevo.

## Compromisos
| Quién | Qué | Para cuándo | |
|---|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-12-05 | **Reprogramado 6 veces.** Original 2026-09-25; fechas sucesivas: 10-09, 10-19, 11-03, 11-11, 11-21 y ahora 12-05. Supera el umbral de 3. |
| Óscar Ramírez | Revisión con el proveedor | 2026-10-27 | Nuevo. Sin compromiso previo equivalente. |

*Nota de la fecha de Elena:* las notas dicen «05/12/2026». Se lee día/mes (5 de diciembre): el otro orden daría el 12 de mayo, anterior al arranque del proyecto, y el patrón de la serie (+10 a +14 días por reunión) lo confirma. Si quien escribió las notas quiso decir otra cosa, está en `note` de la ficha.

*Elena Duarte también tiene «Validar el ambiente 20» con fecha 2026-10-17 (hoy), abierto, que la reunión no mencionó.*

### Sin fecha
| Quién | Qué |
|---|---|
| Laura Vélez | Mandar el ajuste del presupuesto — dicho como «la otra semana»; nadie dio fecha, y no se le puso una. |

Siguen sin fecha de reuniones anteriores, sin que hoy se hayan tocado: María Restrepo («Entregar el punto 24») y Liliana Torres («Actualizar la matriz 14», que dijo haber entregado el 10-03 sin acta).

## Decisiones
Ninguna. En las notas no hay una sola decisión con quién la tomó y qué se descartó.

## Quedó sin decidir
| Qué | Por qué | Quién tiene la facultad |
|---|---|---|
| Qué se hace si el proveedor no llega con el equipo completo | Se comentó y no pasó de ahí | No consta en las notas |
| Qué fecha tiene el ajuste de presupuesto | Se dijo «la otra semana» | Laura Vélez la propone; no consta quién la fija |

## Intenciones sin doliente
Ninguna. Todo lo dicho tiene nombre propio.

## Dicho al pasar y no registrado
| Qué | Quién lo dijo | Categoría | Ya estaba en el RAID |
|---|---|---|---|
| «Se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo» | Impersonal («se comentó»); las notas no dicen quién | Riesgo (aún no ocurrió) | **No.** El informe de avance de hoy lista solo dos riesgos: concentración del conocimiento y dependencia del calendario de liberaciones del core. |

Queda en la ficha como riesgo con la fuente de la reunión. Nadie la ha escrito aún en el registro oficial del proyecto, y aún no tiene probabilidad, impacto ni dueño. El proyecto tampoco tiene proveedor registrado en la ficha (`vendors` vacío), lo cual conviene mirar.

## Cerrado en esta reunión
Nada. Las notas no mencionan ningún documento de recibo.

## Lo que esta reunión contradice
| Campo | Dijo la reunión | Dice el expediente | Fuente y fecha de cada uno |
|---|---|---|---|
| Cadencia del comité | «Próxima reunión en dos semanas» (≈ 2026-10-31) | Configuración: comité semanal; los seis comités anteriores fueron cada 7 días | Notas 2026-10-17 · `config.json` y actas de 09-05 a 10-10. Ojo: `committee_next` ya dice 2026-10-31 pero con ciclo semanal; una de las dos cosas está mal. |

No hay contradicciones con patrocinador, fechas de cierre ni comité.

## Sin resolver de la transcripción
- «lo de "enviar el documento 1" no alcanzó» — se entiende que no se entregó, pero no dice por qué ni qué falta.
- «05/12/2026» — formato distinto del resto de las fechas (ISO); se tomó día/mes (ver arriba).
- «la otra semana» — sin fecha.
- «se comentó…» — sin autor; no se supo quién levantó el riesgo del proveedor.

## Después de recalcular (`compute`, sin `record_issues`)
- Compromisos vencidos: 8 (Carlos Peña ×3, Gustavo Neira ×2, Felipe Arango, Sandra Gil, María Restrepo). Ninguno cambió hoy.
- Sin fecha: 3. Reprogramados sobre el umbral: Elena Duarte (6 veces); Ricardo Salas lleva 4.
- El informe de avance declara **verde**, y los datos no lo sostienen: vencidos, reprogramaciones, hito «Diseño funcional aprobado» pasado 12 días (2026-10-05) y proyección 15,9 % sobre el presupuesto aprobado.

Siguiente: `/pm-commitments` para el seguimiento completo, y `/pm-publish` cuando quieras que la PMO vea la ficha. El acta es tuya: no se escribió en tu carpeta de reuniones.
