Sesión sin interfaz: nadie respondió. Términos ya vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hubo que registrarlos de nuevo. La declaración no se preguntó ni se sugirió: se usa la que ya está en el informe de avance del propio gerente.

# PRY-200 Originación digital — semana al 2026-10-17

**Declara el gerente:** verde · 36% · al 2026-10-17 (fuente: 20-seguimiento/2026-10-17-informe-avance.md, tomada del documento; no la declaró en esta sesión ni la sugirió el agente)
**Sustento documental:** contradicho
**Lo que el semáforo no explica:** hito vencido, sobrecosto proyectado, compromisos vencidos y compromisos reprogramados (4 señales)

## Qué cambió esta semana
No hay corrida anterior contra la cual comparar: el diff dio 0 cambios porque este es el primer snapshot (2026-10-17). Lo que sigue es el estado de partida, no una variación.

## Lo que sigue igual y sigue mal
Sin histórico no se pueden contar los días «así» de cada desviación. Días de atraso al corte:
| Qué | Desde | Días así |
| Hito «Diseño funcional aprobado» sin evidencia | 2026-10-05 | 12 |
| Proyección de costo sobre lo aprobado (+15,9%) | sin dato | sin dato |

## Contra el plan
| | Línea base original | Vigente | Desviación |
| Fecha de cierre | 2027-06-04 | 2027-06-04 | 0 días |
| Presupuesto (COP) | 18.000.000.000 | 18.000.000.000 | proyección 20.859.955.929 = +15,9% (umbral 10%) |

Replanificaciones: 0. Control de cambios: ninguno registrado. Ojo: la fecha de cierre no se ha movido, pero el primer hito ya lleva 12 días vencido sin que el plan se replanifique; el avance declarado (36%) está por encima de lo que el plan sostiene (0–33%, 0 de 3 hitos cumplidos).

### Hitos de las próximas cuatro semanas
| Hito | Base | Vigente | Evidencia |
| Ninguno cae en las próximas cuatro semanas | | | |
Vencido: Diseño funcional aprobado, base y vigente 2026-10-05, sin evidencia. Siguientes: Ambiente de pruebas certificado 2027-02-03; Integración con el core 2027-06-04.

## Las cifras (COP)
| Aprobado | Comprometido | Ejecutado | Proyectado | Disponible real |
| 18.000.000.000 | 6.215.444.712 (34,5%) | 4.617.386.288 (25,7%) | 20.859.955.929 | 11.784.555.288 (aprobado − comprometido) |

## Abierto
**Reprogramados:** Elena Duarte, «Enviar el documento 1», 6 veces (original 2026-09-25; hoy 2026-12-05). Ricardo Salas, «Cerrar la prueba 2», 4 veces (original 2026-09-20; hoy 2026-11-20). Ambos pasan el umbral de 3.
**Vencidos sin evidencia (8):**
- Sandra Gil, Validar el ambiente 12 — 25 días (2026-09-22)
- Carlos Peña, Validar el ambiente 4 — 22 días (2026-09-25)
- Felipe Arango, Revisar el anexo 11 — 18 días (2026-09-29)
- María Restrepo, Aprobar el diseño 13 — 11 días (2026-10-06)
- Gustavo Neira, Cerrar la prueba 18 — 9 días (2026-10-08)
- Carlos Peña, Entregar el punto 8 — 7 días (2026-10-10)
- Gustavo Neira, Confirmar la fecha 7 — 3 días (2026-10-14)
- Carlos Peña, Confirmar la fecha 15 — 2 días (2026-10-15)
Tres de los ocho son de Carlos Peña.
**Sin fecha (3):** Liliana Torres (Actualizar la matriz 14), María Restrepo (Entregar el punto 24), Laura Vélez (Mandar el ajuste del presupuesto).
**RAID sin movimiento:** hay 3 riesgos registrados y ninguno trae fecha de última revisión, así que no se pueden contar días. Uno, que el proveedor no llegue con el equipo completo para la siguiente fase, se dijo en la reunión del 2026-10-17 y nadie lo había registrado.
**Proveedor:** no hay proveedores en la ficha.

## Lo que necesito de alguien
- Diana Molina: declarar de nuevo el estado a la luz de las 4 señales que el verde no explica.
- Elena Duarte y Ricardo Salas: fecha firme o decisión sobre sus compromisos reprogramados.
- Laura Vélez: fecha para el ajuste del presupuesto; la proyección ya está 15,9% sobre lo aprobado.
- Quien tenga autoridad sobre el presupuesto: material de comité, no de este informe (sobrecosto sobre el umbral del 10%).

## Lo que no se sabe
**Sin dato:** autoridad (identity.authority) y fase (identity.phase). Sin evidencia de cumplimiento en ninguno de los 3 hitos. Los 14 datos sin marcar de origen en la ficha.
**Silencio:** el cálculo no entrega días de silencio (days_silent sin dato). Lo que sí consta: informe de avance del 2026-10-17 y notas de reunión del 2026-10-17, es decir, hoy.

---
Ficha: estado/PRY-200-originación-digital/records/PRY-200.json, actualizada 2026-10-17. Campos sin dato: 2. Términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal

Sugerencia posterior: el verde contradicho por la evidencia cumple el caso de /pm-publish; y hay dos compromisos reprogramados por encima del umbral y un sobrecosto sobre el umbral, que justifican armar un punto de comité.
