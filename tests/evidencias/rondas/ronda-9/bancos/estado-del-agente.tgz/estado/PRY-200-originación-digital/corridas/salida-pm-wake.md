## PRY-200 · Originación digital · 2026-10-17

Términos: ya vigentes (aceptados por José Francisco Ñáñez el 2026-10-17, versión 0.4.0); no se registraron de nuevo.

**Revisé:** 16 documentos · 16 nuevos para el índice (primer barrido de esta carpeta; ninguno cambió porque no había índice previo) · 7 minutas (6 comités + las notas del 2026-10-17), todas ya extraídas a la ficha en corridas de hoy; no hubo nada que extraer de nuevo.

### Lo que se venció solo
Recalculé la ficha (`compute`, corte 2026-10-17). Como es el primer barrido, esto es el estado de partida, no un cambio contra ayer:

- **8 compromisos vencidos sin evidencia:** Validar el ambiente 4 (venció 2026-09-25, 22 días), Validar el ambiente 12 (2026-09-22, 25 días), Revisar el anexo 11 (2026-09-29, 18), Aprobar el diseño 13 (2026-10-06, 11), Cerrar la prueba 18 (2026-10-08, 9), Entregar el punto 8 (2026-10-10, 7), Confirmar la fecha 7 (2026-10-14, 3) y Confirmar la fecha 15 (2026-10-15, 2). En «Confirmar la fecha 7» se dijo el 2026-09-26 que ya se entregó, pero no hay acta de recibo: queda vencido, no cumplido.
- **2 reprogramados por encima del umbral (3):** «Enviar el documento 1» (6 veces; de 2026-09-25 a 2026-12-05) y «Cerrar la prueba 2» (4 veces; de 2026-09-20 a 2026-11-20). Es un bloqueo que nadie ha nombrado, no un problema de seguimiento.
- **3 sin fecha:** Actualizar la matriz 14 (dicho como entregado el 2026-10-03, sin acta), Entregar el punto 24, y Mandar el ajuste del presupuesto («la otra semana»). Hay que preguntar la fecha en la próxima reunión.
- **Hito vencido:** «Diseño funcional aprobado» (2026-10-05), 12 días sin evidencia.
- **Costo:** la proyección (COP 20.859.955.929) supera lo aprobado (COP 18.000.000.000) en 15,9 %, sobre el umbral de 10 %.
- **Declarado vs. evidencia:** el informe de avance declara **verde**; las cuatro señales anteriores no están explicadas en él.
- «Validar el ambiente 20» (Elena Duarte) vence hoy; sigue abierto.

### La reunión
El comité es el 2026-10-31, a 14 días: aún no toca agenda (se ofrece cuando falte un día o menos). El informe toca el 2026-10-30. No hay acta pendiente: las notas del 2026-10-17 ya están registradas.

### Tu ficha publicada
Al día: se publicó hoy y no cambió desde entonces.

**Vuelvo el 2026-10-18.**
