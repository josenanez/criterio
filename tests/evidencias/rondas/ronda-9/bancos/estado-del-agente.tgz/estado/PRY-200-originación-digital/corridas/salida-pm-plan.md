Términos vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17): no hubo que registrarlos de nuevo.

# Plan — Originación digital (PRY-200) · borrador del 2026-10-17
**Desde:** acta de constitución del 2026-05-28 (`00-gobierno/2026-05-28-acta-constitucion.docx`) · **Criterio de éxito:** «Originación digital en producción y medido» (acta). Está declarado, pero sin métrica ni umbral: no dice qué se mide ni qué valor cuenta como éxito.

## Lo que le falta al acta
| Qué | Consecuencia de planificar sin eso |
|---|---|
| Alcance real: dice «Componente 1, 2, 3», sin nombrarlos | No hay entregables que descomponer desde el acta. Los nodos de la WBS son supuestos o están sin definir. |
| Fuera de alcance: «Lo que otro proyecto cubre», sin decir cuál | No se sabe dónde termina este proyecto. Hay 12 proyectos más en la carpeta del portafolio y no se puede saber cuál es «el otro». |
| Criterio de éxito sin métrica («medido» ¿qué y contra qué valor?) | No se puede decidir qué entra al alcance ni qué es «terminado». |
| Autoridad declarada: no aparece | No se sabe qué puede decidir la gerente al planificar y qué hay que subir. |
| Dependencias: «Ninguna declarada» | El informe de avance del 2026-10-17 cita como riesgo la «dependencia del calendario de liberaciones del core». El acta y el informe se contradicen. El plan hereda un orden sin esa dependencia. |
| Patrocinador: Jorge Medina (está) | Sin hallazgo. |

Se sigue marcando los huecos; no se rellenaron.

## WBS
Aviso: el acta no nombra entregables. Los tres nodos salen del cronograma v1 (`10-plan/2026-05-28-cronograma-v1.xlsx`), que es un documento aparte, así que van como **supuesto**. Que el cronograma tenga un hito no significa que el acta lo haya pedido.

| # | Entregable | Quién lo acepta | De dónde sale | Duración |
|---|---|---|---|---|
| 1 | Componente 1 | sin definir | del acta, sin nombre ni contenido → **sin definir** | — |
| 2 | Componente 2 | sin definir | ídem → **sin definir** | — |
| 3 | Componente 3 | sin definir | ídem → **sin definir** | — |
| 4 | Diseño funcional aprobado | sin definir (el acta no lo dice) | **supuesto** (hito del cronograma v1) | — |
| 5 | Ambiente de pruebas certificado | sin definir | **supuesto** (hito del cronograma v1) | — |
| 6 | Integración con el core | sin definir | **supuesto** (hito del cronograma v1) | — |
| 7 | Originación digital en producción | Jorge Medina, como patrocinador (**supuesto**; el acta no dice quién acepta) | **del acta** (criterio de éxito) | — |
| 8 | Medición de la originación digital en producción | sin definir | **del acta** («y medido»); métrica **sin definir** | — |

Cuál de los componentes 1 a 3 corresponde a cuál hito (4 a 6) no está en ningún documento. No se cruzaron.

## Orden
Es lo que se desprende del cronograma v1 y de la lógica del trabajo. No lleva fechas nuevas.
- 4 (diseño) antes de 5 (pruebas) y de 6 (integración): **supuesto**, porque se pone a probar e integrar algo ya diseñado.
- 5 (ambiente de pruebas) antes de 7 (producción): **supuesto**.
- 6 (core) antes de 7 (producción). Si se confirma la dependencia con las liberaciones del core que cita el informe, esa dependencia pasa a ser externa y condiciona 6 y 7.
- 7 antes de 8 (no se mide lo que no está en producción).
- Componentes 1 a 3: sin orden posible mientras no se sepa qué son.

## Supuestos sobre los que está construido
| Supuesto | Qué pasa si resulta falso |
|---|---|
| Los tres hitos del cronograma v1 son entregables del proyecto | La WBS queda con nodos que el acta no pidió, o sin los que sí pidió. |
| «Componente 1, 2, 3» se corresponden con esos hitos | Cobertura de alcance mal medida. |
| El patrocinador acepta el entregable final | Quien acepte no está identificado y el cierre queda sin dueño. |
| Diseño → pruebas/core → producción → medición | Rehacer el orden y el camino crítico. |
| La dependencia del calendario de liberaciones del core es real (viene del informe, no del acta) | Si es real y no está en el plan, el cierre del 2027-06-04 queda expuesto. Si no lo es, sobra una restricción. |

Cuando el plan se apruebe, estos pasan al RAID con doliente (raid-taxonomy).

## Sin definir
| Qué | Quién lo define |
|---|---|
| Contenido de los componentes 1, 2 y 3 | Diana Molina con Jorge Medina (patrocinador) |
| Qué cubre «otro proyecto» y cuál es | Jorge Medina / Comité de Arquitectura |
| Métrica y umbral de «medido» | Jorge Medina (negocio) |
| Quién acepta cada entregable | Jorge Medina |
| Autoridad de la gerente al planificar | Jorge Medina / Comité de Arquitectura |
| Dependencias externas (core, proveedor) | Diana Molina con el dueño del core |

## Proyectos análogos
Ninguno a la vista. La configuración de PRY-200 no apunta a una carpeta de fichas de la PMO, y no se buscaron análogos entre las carpetas de otros proyectos por conjetura. Eso no es un hueco del plan: sin análogos no hay referencia, y no se inventa una. No hay base para estimar por analogía.

## Preguntas para el equipo
Una por duración vacía.
1. ¿Cuánto toma cada uno de los componentes 1, 2 y 3? Primero: ¿qué son?
2. ¿Cuánto toma el diseño funcional? El hito del cronograma vencía el 2026-10-05 y no tiene evidencia de cierre en la carpeta.
3. ¿Cuánto toma certificar el ambiente de pruebas? La prueba de carga no alcanzó el umbral y se repite (informe 2026-10-17).
4. ¿Cuánto toma la integración con el core, y cuándo libera el core lo que se necesita?
5. ¿Cuánto toma pasar a producción?
6. ¿Cuánto tiempo de medición hace falta para decir «medido»?
7. ¿Quién es el proveedor, y con qué equipo cuenta para la siguiente fase? (La reunión del 2026-10-17 dice que podría no llegar completo.)

## Para comprometer una fecha falta
- Disponibilidad real del equipo. No está en ningún documento; además, en las notas del 2026-10-17 el conocimiento depende de una sola persona (informe de avance).
- Fecha del proveedor y su equipo para la siguiente fase. En las notas del 2026-10-17 se comentó que podría no llegar completo y nadie lo registró como riesgo.
- Ventana de la sala de producción, y el calendario de liberaciones del core.
- Un alcance y un criterio de éxito medible, para que haya contra qué fechar.

## Lo que sí conviene decir de entrada
Este borrador sale con el proyecto ya en marcha (inicio 2026-06-07, 36% declarado, verde). Su único hito vencido, «Diseño funcional aprobado» (2026-10-05), sigue «pendiente» sin evidencia. Sin fechas: se señala, no se concluye. Quien comprometa fechas aquí decide también si el cronograma v1 sigue siendo la línea base original; eso es otro acto y otro momento.
