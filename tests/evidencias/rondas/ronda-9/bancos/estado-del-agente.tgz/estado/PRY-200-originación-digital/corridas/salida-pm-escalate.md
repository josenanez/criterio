## Para decisión — PRY-200 Originación digital · 2026-10-17

*Gerente: Diana Molina · Patrocinador: Jorge Medina · Comité: Comité de Arquitectura (próximo, según la configuración: 2026-10-31)*

*Sin argumento, se tomó «lo que ya está marcado como escalable». Salen dos puntos, en este orden: el primero es la autoridad, que el acta no declara; el segundo, la proyección de costo sobre el aprobado.*

---

### 1. ¿Se declara por escrito qué puede decidir la gerente sin subir al Comité de Arquitectura —sobrecosto y corrimiento de fechas—, y mientras no se declare, todo sobrecosto sobre el aprobado y todo corrimiento de hitos se decide en el Comité?

**Quién decide:** Comité de Arquitectura, que aprobó el acta el 2026-05-28 (el acta no lo dice como facultad; es quien la aprobó) · **Si no se decide hoy:** no hay fecha de vencimiento en ningún documento. Lo que sí hay: el punto 2 ya está fuera de cualquier umbral razonable y quien lo decida sin esta definición decide sin saber si podía.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Sí: se enmienda el acta con la autoridad declarada (umbrales de costo y de fechas) | Sin cambio | Una enmienda del acta; el tiempo que tarde el Comité no está en los documentos | Sin costo en el proyecto |
| B. No: se queda sin declarar; todo sube al Comité caso por caso | Sin cambio | Cada decisión espera al Comité semanal | Sin costo directo; la gerente sigue sin saber qué puede decidir |

**Recomiendo:** A — el acta del 2026-05-28 no contiene autoridad (ni dependencias: dice «Ninguna declarada», mientras el informe del 2026-10-17 registra «dependencia del calendario de liberaciones del core»). Sin autoridad escrita no se puede decir qué escala y qué no.

---

### 2. ¿Se aprueba un presupuesto de cierre de ≈ COP 20.860 M (+ COP 2.860 M sobre los 18.000 M aprobados), o se exige al proyecto volver a 18.000 M recortando alcance o replanificando?

**Quién decide:** Comité de Arquitectura (aprobó los 18.000 M); la autoridad de la gerente **no está declarada** (punto 1) · **Si no se decide hoy:** no hay fecha de vencimiento en los documentos. Lo único fechado: Laura Vélez quedó de mandar «el ajuste del presupuesto» «la otra semana», sin día (notas 2026-10-17), y el Comité es el 2026-10-31.

| Opción | Alcance | Tiempo | Costo |
|---|---|---|---|
| A. Aprobar la proyección | Componentes 1, 2 y 3 sin cambio (según el acta) | Sin cambio en cierre (2027-06-04) según los documentos; no hay estimación que lo contradiga ni que lo confirme | +2.859.955.929 COP (+15,9 %; el umbral configurado es 10 %) |
| B. Volver a 18.000 M | **No está en los documentos** qué componente saldría ni cuánto recorta cada uno | **No está en los documentos** | Hasta 2.859.955.929 COP menos de gasto; el costo de lo que se deje de entregar, no calculado |
| C. Aplazar hasta el ajuste de Laura Vélez | Sin cambio | Hasta «la otra semana» (sin fecha) | Ninguno declarado; la proyección sigue sin aprobar |

**Recomiendo:** C — y llevarlo al Comité del 2026-10-31 con el ajuste ya recibido. Hoy la única cifra es la proyección del informe, y el propio informe declara «Verde» con una proyección 15,9 % sobre el aprobado: ni A ni B se pueden sustentar sin el ajuste. Si el ajuste no llega antes del 2026-10-31, el punto se vuelve a subir con los días que lleva.

**Un hallazgo para el comité:** el estado declarado es Verde (36 %) con la proyección por encima del umbral de 10 % y el hito «Diseño funcional aprobado» (2026-10-05) sin evidencia, 12 días después de su fecha. Esa contradicción es del informe, no de este paquete; se señala para que el comité la vea.

---

### A quién alcanza

| Proyecto | Gerente | ¿Sostiene su fecha? | Dependencia confirmada |
|---|---|---|---|
| Ninguno | — | — | — |

*La ficha de PRY-200 no declara dependencias («Ninguna declarada» en el acta) y no hay otros proyectos en el estado. Eso **no** prueba que no haya impacto: el informe menciona la dependencia del calendario de liberaciones del core, y el acta no la recoge. Hay que preguntar a quién pertenece ese calendario.*

### Mis hitos por los que pasa

*Ninguno de los dos puntos propone mover una fecha. Para dar una medida se calculó el efecto de **12 días**, que es el atraso ya acumulado del hito «Diseño funcional aprobado»; no es un cambio solicitado ni se sabe que arrastre a los demás.*

| Hito | Fecha vigente | En cuántos días |
|---|---|---|
| Ambiente de pruebas certificado | 2027-02-03 | 109 |
| Integración con el core | 2027-06-04 (cierre; pasaría al 2027-06-16 con 12 días) | 230 |

*Cuántos días se mueve cada hito no se calcula: falta la holgura por actividad, que la ficha no tiene.*

### Lo que sube con estos puntos pero aún no escala

- **Compromisos con reprogramación repetida** (umbral: 3): «Enviar el documento 1», Elena Duarte — de 2026-09-25 a 2026-12-05, 6 reprogramaciones, 71 días; «Cerrar la prueba 2», Ricardo Salas — hoy 2026-11-20, 4 reprogramaciones. Cumplen el criterio de la PMO, pero el doliente está dentro del proyecto: es una llamada de la gerente, no una decisión de comité. Pasa al comité solo si no se destraba.
- **Riesgo dicho en reunión y sin registrar:** el proveedor podría no llegar con el equipo completo para la siguiente fase (notas 2026-10-17). Hay que registrarlo; todavía no hay fecha ni doliente que lo lleven fuera de la autoridad de la gerente. La reunión «revisión con el proveedor» es el 2026-10-27, antes del Comité.
- **No incluido:** vencidos que se destraban con una llamada (p. ej. los de Carlos Peña, Sandra Gil, Felipe Arango, María Restrepo y Gustavo Neira, todos sin reprogramación).

### De dónde sale esto

- Autoridad no declarada, dependencias «Ninguna declarada», presupuesto aprobado 18.000.000.000 COP, comité y patrocinador: `00-gobierno/2026-05-28-acta-constitucion.docx`.
- Proyección 20.859.955.929, comprometido 6.215.444.712, ejecutado 4.617.386.288, estado Verde 36 %, riesgos abiertos: `20-seguimiento/2026-10-17-informe-avance.md`.
- Hito «Diseño funcional aprobado» 2026-10-05, sin evidencia; Ambiente de pruebas certificado e Integración con el core: `10-plan/2026-05-28-cronograma-v1.xlsx`.
- Ajuste del presupuesto «la otra semana», riesgo del proveedor, nueva fecha de Elena Duarte (05/12/2026, leída día/mes), revisión con el proveedor 2026-10-27: `2026-10-17-notas-reunion.txt`.
- Reprogramaciones de Elena Duarte y Ricardo Salas: `30-reuniones/2026-09-05-comite-semanal.md` a `2026-10-10-comite-semanal.md`.
- Umbrales (10 % de costo, 3 reprogramaciones) y fecha del próximo comité: `.criterio/proyecto/PRY-200/config.json`.

**Lo que no sé:** la autoridad de la gerente; cuánto cuestan las opciones de recortar o replanificar; la fecha en que vence cualquiera de las dos decisiones; qué proyectos usan el calendario de liberaciones del core.
