<!-- origen: PRY-200-originación-digital/10-plan/2026-05-28-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-10-05 | 2026-10-05 | en curso
Ambiente de pruebas certificado | 2027-02-03 | 2027-02-03 | en curso
Integración con el core | 2027-06-04 | 2027-06-04 | en curso
