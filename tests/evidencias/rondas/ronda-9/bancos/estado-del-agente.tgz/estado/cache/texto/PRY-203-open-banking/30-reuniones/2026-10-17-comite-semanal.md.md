<!-- origen: PRY-203-open-banking/30-reuniones/2026-10-17-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Medios de Pago · Open Banking

**Fecha:** 2026-10-17
**Asistentes:** Óscar Ramírez, Sandra Gil

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Carlos Peña | Entregar el punto 21 | 2026-11-13 |
