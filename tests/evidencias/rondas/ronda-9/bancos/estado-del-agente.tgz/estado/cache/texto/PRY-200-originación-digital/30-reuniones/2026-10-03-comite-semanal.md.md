<!-- origen: PRY-200-originación-digital/30-reuniones/2026-10-03-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Arquitectura · Originación digital

**Fecha:** 2026-10-03
**Asistentes:** Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, María Restrepo, Ricardo Salas, Sandra Gil

## Compromisos abiertos

| Responsable | Compromiso | Para |
|---|---|---|
| Elena Duarte | Enviar el documento 1 | 2026-11-11 |
| Ricardo Salas | Cerrar la prueba 2 | 2026-11-06 |
| Carlos Peña | Validar el ambiente 4 | 2026-09-25 |
| Carlos Peña | Entregar el punto 8 | 2026-10-10 |
| Felipe Arango | Revisar el anexo 11 | 2026-09-29 |
| Sandra Gil | Validar el ambiente 12 | 2026-09-22 |
| María Restrepo | Aprobar el diseño 13 | 2026-10-06 |
| Carlos Peña | Confirmar la fecha 15 | 2026-10-15 |
| Andrés Lozano | Entregar el punto 16 | 2026-10-14 |
| Jorge Medina | Enviar el documento 17 | 2026-10-08 |
| Gustavo Neira | Cerrar la prueba 18 | 2026-10-08 |
| Camilo Beltrán | Revisar el anexo 19 | 2026-10-26 |
| Elena Duarte | Validar el ambiente 20 | 2026-10-17 |

## Cerrados en esta reunión

- Cerrar la prueba 10 (Elena Duarte): recibido, acta de recibo del 2026-10-03.

## Lo que se dijo

- Liliana Torres dice que ya entregó «actualizar la matriz 14». No se presentó acta.
