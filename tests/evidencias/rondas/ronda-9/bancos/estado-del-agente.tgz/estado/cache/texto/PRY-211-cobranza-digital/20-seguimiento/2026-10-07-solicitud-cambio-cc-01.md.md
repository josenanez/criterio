<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-07-solicitud-cambio-cc-01.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Solicitud de cambio CC-01

**Proyecto:** PRY-211 · Cobranza digital
**Fecha:** 2026-10-07
**Solicitante:** Natalia Ospina

## Qué cambia

Ampliación de alcance

## Impacto

| | |
|---|---|
| Tiempo | +116 días sobre la línea base vigente |
| Costo | 232.000.000 COP adicionales |

## Autorización

Pendiente de presentación al comité.
