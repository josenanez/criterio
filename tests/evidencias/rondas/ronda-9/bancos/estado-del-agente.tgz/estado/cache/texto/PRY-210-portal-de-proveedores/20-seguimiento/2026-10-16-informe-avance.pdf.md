<!-- origen: PRY-210-portal-de-proveedores/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Portal de proveedores
Código: PRY-210
Fecha de corte: 2026-10-16
Gerente: Rubén Cárdenas

Estado declarado
Verde
Avance reportado: 52%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones

Presupuesto
COP
Aprobado 9.500.000.000
Comprometido 3.878.378.756
Ejecutado 2.965.535.146
Proyección al cierre 8.789.673.693

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
- Disponibilidad del equipo de seguridad para la revisión final
