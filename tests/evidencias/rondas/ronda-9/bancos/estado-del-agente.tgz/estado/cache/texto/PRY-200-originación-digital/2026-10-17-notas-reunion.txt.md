<!-- origen: PRY-200-originación-digital/2026-10-17-notas-reunion.txt · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

notas reunión originación digital — 2026-10-17
estuvieron: Andrés Lozano, Camilo Beltrán, Carlos Peña, Diana Molina, Elena Duarte, Felipe Arango, Gustavo Neira, Jorge Medina, Laura Vélez, María Restrepo, Mauricio Pérez, Paula Céspedes, Ricardo Salas, Sandra Gil, Óscar Ramírez

- Elena Duarte dice que lo de «enviar el documento 1» no alcanzó, se compromete para el 05/12/2026
- Laura Vélez queda de mandar el ajuste del presupuesto la otra semana
- Óscar Ramírez: revisión con el proveedor, queda para el 2026-10-27
- se comentó que el proveedor podría no llegar con el equipo completo para la siguiente fase, nadie lo anotó como riesgo
- próxima reunión en dos semanas
