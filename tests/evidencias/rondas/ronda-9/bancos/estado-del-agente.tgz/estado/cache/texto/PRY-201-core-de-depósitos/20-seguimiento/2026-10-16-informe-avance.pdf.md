<!-- origen: PRY-201-core-de-depósitos/20-seguimiento/2026-10-16-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Core de depósitos
Código: PRY-201
Fecha de corte: 2026-10-16
Gerente: Óscar Ramírez

Estado declarado
Rojo
Avance reportado: 29%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 1.200.000.000
Comprometido 659.252.824
Ejecutado 251.052.408
Proyección al cierre 1.129.406.036

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Cambio regulatorio en discusión que puede mover el alcance
