<!-- origen: PRY-203-open-banking/00-gobierno/2026-03-24-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Open Banking

Código: PRY-203

Área dueña: Riesgo y Cumplimiento

Patrocinador: Sandra Gil

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Medios de Pago

Producto asociado: APIs de datos

Fecha de aprobación: 2026-03-24

Objetivo del negocio

Entregar open banking para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

6.800.000.000 COP, aprobado por Comité de Medios de Pago el 2026-03-24.

Fechas comprometidas

Fecha

Inicio

2026-04-03

Cierre

2026-12-06

Criterio de éxito

Open Banking en producción y medido.

Dependencias declaradas

• Ninguna declarada
