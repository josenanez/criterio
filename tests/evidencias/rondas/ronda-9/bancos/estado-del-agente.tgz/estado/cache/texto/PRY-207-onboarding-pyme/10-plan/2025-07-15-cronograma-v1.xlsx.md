<!-- origen: PRY-207-onboarding-pyme/10-plan/2025-07-15-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-02 | 2025-11-02 | cerrado
Ambiente de pruebas certificado | 2026-02-10 | 2026-02-10 | cerrado
Integración con el core | 2026-05-21 | 2026-05-21 | cerrado
Piloto con usuarios internos | 2026-08-29 | 2026-08-29 | cerrado
