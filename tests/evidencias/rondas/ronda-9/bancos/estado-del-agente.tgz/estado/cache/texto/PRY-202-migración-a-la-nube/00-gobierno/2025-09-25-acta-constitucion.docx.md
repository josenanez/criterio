<!-- origen: PRY-202-migración-a-la-nube/00-gobierno/2025-09-25-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Migración a la nube

Código: PRY-202

Área dueña: Canales Digitales

Patrocinador: Liliana Torres

Gerente de proyecto: Javier Hoyos

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2025-09-25

Objetivo del negocio

Entregar migración a la nube para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Banca Empresas el 2025-09-25.

Fechas comprometidas

Fecha

Inicio

2025-10-05

Cierre

2026-12-14

Criterio de éxito

Migración a la nube en producción y medido.

Dependencias declaradas

• Ninguna declarada
