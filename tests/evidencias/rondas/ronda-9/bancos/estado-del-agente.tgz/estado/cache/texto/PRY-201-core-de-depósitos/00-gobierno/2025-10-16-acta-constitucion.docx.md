<!-- origen: PRY-201-core-de-depósitos/00-gobierno/2025-10-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Core de depósitos

Código: PRY-201

Área dueña: Medios de Pago

Patrocinador: Liliana Torres

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Arquitectura

Producto asociado: cuenta de ahorros

Fecha de aprobación: 2025-10-16

Objetivo del negocio

Entregar core de depósitos para Medios de Pago.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Arquitectura el 2025-10-16.

Fechas comprometidas

Fecha

Inicio

2025-10-26

Cierre

2026-11-22

Criterio de éxito

Core de depósitos en producción y medido.

Dependencias declaradas

• Ninguna declarada
