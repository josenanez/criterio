<!-- origen: PRY-209-nómina-electrónica/20-seguimiento/2026-09-26-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Nómina electrónica

**Código:** PRY-209
**Fecha de corte:** 2026-09-26
**Gerente:** María Restrepo

## Estado declarado

**Amarillo**

Avance reportado: **78%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- El equipo perdió dos semanas por rotación de un desarrollador clave

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 5.744.594.486 |
| Ejecutado | 2.599.596.789 |
| Proyección al cierre | 9.715.554.033 |

## Riesgos abiertos

- Disponibilidad del equipo de seguridad para la revisión final
- Concentración del conocimiento en una sola persona
