<!-- origen: PRY-206-billetera-y-qr/20-seguimiento/2026-10-10-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Billetera y QR

**Código:** PRY-206
**Fecha de corte:** 2026-10-10
**Gerente:** Mauricio Pérez

## Estado declarado

**Verde**

Avance reportado: **36%**

## Lo que pasó en el periodo

- La prueba de carga no alcanzó el umbral pactado y se repite
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

## Presupuesto

| | COP |
|---|---|
| Aprobado | 6.800.000.000 |
| Comprometido | 5.219.280.717 |
| Ejecutado | 1.607.570.664 |
| Proyección al cierre | 6.830.919.685 |

## Riesgos abiertos

- Dependencia del calendario de liberaciones del core
- Disponibilidad del equipo de seguridad para la revisión final
