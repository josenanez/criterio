<!-- origen: PRY-200-originación-digital/00-gobierno/2026-05-28-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Originación digital

Código: PRY-200

Área dueña: Canales Digitales

Patrocinador: Jorge Medina

Gerente de proyecto: Diana Molina

Comité: Comité de Arquitectura

Producto asociado: crédito de consumo

Fecha de aprobación: 2026-05-28

Objetivo del negocio

Entregar originación digital para Canales Digitales.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

18.000.000.000 COP, aprobado por Comité de Arquitectura el 2026-05-28.

Fechas comprometidas

Fecha

Inicio

2026-06-07

Cierre

2027-06-04

Criterio de éxito

Originación digital en producción y medido.

Dependencias declaradas

• Ninguna declarada
