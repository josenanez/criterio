<!-- origen: PRY-201-core-de-depósitos/10-plan/2025-10-16-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-01 | 2026-02-01 | cerrado
Ambiente de pruebas certificado | 2026-05-10 | 2026-05-10 | cerrado
Integración con el core | 2026-08-16 | 2026-08-16 | cerrado
Piloto con usuarios internos | 2026-11-22 | 2026-11-22 | en curso
