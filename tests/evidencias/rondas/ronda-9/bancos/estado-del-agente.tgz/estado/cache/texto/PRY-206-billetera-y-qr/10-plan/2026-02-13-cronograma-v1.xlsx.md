<!-- origen: PRY-206-billetera-y-qr/10-plan/2026-02-13-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-05-16 | 2026-05-16 | cerrado
Ambiente de pruebas certificado | 2026-08-06 | 2026-08-06 | cerrado
Integración con el core | 2026-10-28 | 2026-10-28 | en curso
Piloto con usuarios internos | 2027-01-18 | 2027-01-18 | en curso
