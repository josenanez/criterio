<!-- origen: PRY-202-migración-a-la-nube/20-seguimiento/2026-10-13-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Migración a la nube

**Código:** PRY-202
**Fecha de corte:** 2026-10-13
**Gerente:** Javier Hoyos

## Estado declarado

**Verde**

Avance reportado: **37%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior

## Presupuesto

| | COP |
|---|---|
| Aprobado | 9.500.000.000 |
| Comprometido | 6.552.528.459 |
| Ejecutado | 2.548.693.323 |
| Proyección al cierre | 12.125.785.918 |

## Riesgos abiertos

- El proveedor no ha confirmado la fecha de la última entrega
- Dependencia del calendario de liberaciones del core
