<!-- origen: PRY-206-billetera-y-qr/00-gobierno/2026-02-13-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Billetera y QR

**Código:** PRY-206
**Área dueña:** Banca PyME
**Patrocinador:** María Restrepo
**Gerente de proyecto:** Mauricio Pérez
**Comité:** Comité de Medios de Pago
**Producto asociado:** pagos QR
**Fecha de aprobación:** 2026-02-13

## Objetivo del negocio

Entregar billetera y qr para Banca PyME.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**6.800.000.000 COP**, aprobado por Comité de Medios de Pago el 2026-02-13.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2026-02-23 |
| Cierre | 2027-01-18 |

## Criterio de éxito

Billetera y QR en producción y medido.

## Dependencias declaradas

- Ninguna declarada
