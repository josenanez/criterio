<!-- origen: PRY-209-nómina-electrónica/00-gobierno/2025-11-19-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Nómina electrónica

**Código:** PRY-209
**Área dueña:** Banca PyME
**Patrocinador:** Beatriz Cuéllar
**Gerente de proyecto:** María Restrepo
**Comité:** Comité de Banca Empresas
**Producto asociado:** nómina empresarial
**Fecha de aprobación:** 2025-11-19

## Objetivo del negocio

Entregar nómina electrónica para Banca PyME.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**9.500.000.000 COP**, aprobado por Comité de Banca Empresas el 2025-11-19.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-11-29 |
| Cierre | 2026-06-28 |

## Criterio de éxito

Nómina electrónica en producción y medido.

## Dependencias declaradas

- Ninguna declarada
