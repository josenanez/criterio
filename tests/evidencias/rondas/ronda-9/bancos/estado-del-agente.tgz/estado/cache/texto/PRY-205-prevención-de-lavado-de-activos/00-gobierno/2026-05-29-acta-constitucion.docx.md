<!-- origen: PRY-205-prevención-de-lavado-de-activos/00-gobierno/2026-05-29-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Prevención de lavado de activos

Código: PRY-205

Área dueña: Banca PyME

Patrocinador: Rubén Cárdenas

Gerente de proyecto: Óscar Ramírez

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2026-05-29

Objetivo del negocio

Entregar prevención de lavado de activos para Banca PyME.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

800.000.000 COP, aprobado por Comité de Transformación Digital el 2026-05-29.

Fechas comprometidas

Fecha

Inicio

2026-06-08

Cierre

2027-06-28

Criterio de éxito

Prevención de lavado de activos en producción y medido.

Dependencias declaradas

• Ninguna declarada
