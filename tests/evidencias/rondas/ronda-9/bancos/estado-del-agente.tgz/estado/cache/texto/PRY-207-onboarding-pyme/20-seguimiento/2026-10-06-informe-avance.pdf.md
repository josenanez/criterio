<!-- origen: PRY-207-onboarding-pyme/20-seguimiento/2026-10-06-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Onboarding PyME
Código: PRY-207
Fecha de corte: 2026-10-06
Gerente: Beatriz Cuéllar

Estado declarado
Rojo
Avance reportado: 76%

Lo que pasó en el periodo
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core
- Se acordó con arquitectura cómo se revisan los requisitos no funcionales

Presupuesto
COP
Aprobado 18.000.000.000
Comprometido 14.120.349.319
Ejecutado 5.521.092.051
Proyección al cierre 21.962.012.879

Riesgos abiertos
- Disponibilidad del equipo de seguridad para la revisión final
- Dependencia del calendario de liberaciones del core
