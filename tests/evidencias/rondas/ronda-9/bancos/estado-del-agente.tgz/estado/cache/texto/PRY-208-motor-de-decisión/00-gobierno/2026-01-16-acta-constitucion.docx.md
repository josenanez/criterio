<!-- origen: PRY-208-motor-de-decisión/00-gobierno/2026-01-16-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Motor de decisión

Código: PRY-208

Área dueña: Banca Empresas

Patrocinador: Elena Duarte

Gerente de proyecto: Carlos Peña

Comité: Comité de Transformación Digital

Producto asociado: No aplica

Fecha de aprobación: 2026-01-16

Objetivo del negocio

Entregar motor de decisión para Banca Empresas.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

1.200.000.000 COP, aprobado por Comité de Transformación Digital el 2026-01-16.

Fechas comprometidas

Fecha

Inicio

2026-01-26

Cierre

2027-03-15

Criterio de éxito

Motor de decisión en producción y medido.

Dependencias declaradas

• Ninguna declarada
