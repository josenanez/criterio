<!-- origen: PRY-200-originación-digital/00-gobierno/ficha-pm.json · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

{
 "schema_version": "0.2",
 "identity": {
 "code": {
 "value": "PRY-200",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "name": {
 "value": "Originación digital",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "aliases": [],
 "business_area": {
 "value": "Canales Digitales",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "product": {
 "value": "crédito de consumo",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "authority": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 },
 "sponsor": {
 "value": "Jorge Medina",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "manager": {
 "value": "Diana Molina",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "committee": {
 "value": "Comité de Arquitectura",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "phase": {
 "value": null,
 "source": null,
 "source_date": null,
 "state": "not_found"
 }
 },
 "declared": {
 "status": "verde",
 "progress_pct": 36,
 "as_of": "2026-10-17",
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_kind": "declaration"
 },
 "plan": {
 "start_date": {
 "value": "2026-06-07",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "end_date": {
 "value": "2027-06-04",
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "baseline": [
 {
 "version": 1,
 "approved_on": "2026-05-28",
 "start_date": "2026-06-07",
 "end_date": "2027-06-04",
 "reason": "Aprobación del acta de constitución por el Comité de Arquitectura",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx"
 }
 ],
 "milestones": [
 {
 "name": "Diseño funcional aprobado",
 "baseline_date": "2026-10-05",
 "current_date": "2026-10-05",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 },
 {
 "name": "Ambiente de pruebas certificado",
 "baseline_date": "2027-02-03",
 "current_date": "2027-02-03",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 },
 {
 "name": "Integración con el core",
 "baseline_date": "2027-06-04",
 "current_date": "2027-06-04",
 "state": "pending",
 "evidence": null,
 "source": "10-plan/2026-05-28-cronograma-v1.xlsx"
 }
 ],
 "scope_summary": {
 "value": "Componentes 1, 2 y 3",
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "exclusions": [
 "Lo que otro proyecto cubre"
 ]
 },
 "money": {
 "currency": "COP",
 "approved": {
 "value": 18000000000,
 "source": "00-gobierno/2026-05-28-acta-constitucion.docx",
 "source_date": "2026-05-28",
 "state": "found"
 },
 "committed": {
 "value": 6215444712,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "executed": {
 "value": 4617386288,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 },
 "projection": {
 "value": 20859955929,
 "source": "20-seguimiento/2026-10-17-informe-avance.md",
 "source_date": "2026-10-17",
 "state": "found"
 }
 },
 "vendors": [],
 "raid": {
 "risks": [
 {
 "what": "Concentración del conocimiento en una sola persona",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "Dependencia del calendario de liberaciones del core",
 "source": "20-seguimiento/2026-10-17-informe-avance.md"
 },
 {
 "what": "El proveedor podría no llegar con el equipo completo para la siguiente fase (dicho en reunión, nadie lo registró)",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "assumptions": [],
 "issues": [],
 "dependencies": []
 },
 "changes": [],
 "commitments": [
 {
 "who": "Elena Duarte",
 "what": "Enviar el documento 1",
 "due_date": "2026-12-05",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md"
 },
 {
 "due_date": "2026-10-19",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-11-03",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-11",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-21",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 },
 {
 "due_date": "2026-12-05",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt"
 }
 ],
 "note": "la fecha vigente se lee «05/12/2026» en las notas del 2026-10-17; se toma como día/mes"
 },
 {
 "who": "Ricardo Salas",
 "what": "Cerrar la prueba 2",
 "due_date": "2026-11-20",
 "original_due_date": "2026-09-20",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-09",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 },
 {
 "due_date": "2026-10-25",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 },
 {
 "due_date": "2026-11-06",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md"
 },
 {
 "due_date": "2026-11-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ],
 "note": "el 2026-09-05 estaba «por definir»; 2026-09-20 (comité del 2026-09-12) es su primera fecha, no una reprogramación"
 },
 {
 "who": "Gustavo Neira",
 "what": "Revisar el anexo 3",
 "due_date": "2026-09-26",
 "original_due_date": "2026-09-10",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-09-26",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-3.md"
 },
 {
 "who": "Carlos Peña",
 "what": "Validar el ambiente 4",
 "due_date": "2026-09-25",
 "original_due_date": "2026-09-25",
 "stated_on": "2026-09-05",
 "source": "30-reuniones/2026-09-05-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Elena Duarte",
 "what": "Aprobar el diseño 5",
 "due_date": "2026-09-28",
 "original_due_date": "2026-09-28",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-5.md"
 },
 {
 "who": "Beatriz Cuéllar",
 "what": "Actualizar la matriz 6",
 "due_date": "2026-09-19",
 "original_due_date": "2026-09-19",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-19-acta-recibo-6.md"
 },
 {
 "who": "Gustavo Neira",
 "what": "Confirmar la fecha 7",
 "due_date": "2026-10-14",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-14",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ],
 "note": "el 2026-09-26 dijo que ya lo entregó; no se presentó acta, y desde esa reunión dejó de aparecer en la tabla"
 },
 {
 "who": "Carlos Peña",
 "what": "Entregar el punto 8",
 "due_date": "2026-10-10",
 "original_due_date": "2026-10-01",
 "stated_on": "2026-09-12",
 "source": "30-reuniones/2026-09-12-comite-semanal.md",
 "state": "overdue",
 "reschedules": [
 {
 "due_date": "2026-10-10",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Enviar el documento 9",
 "due_date": "2026-10-04",
 "original_due_date": "2026-10-04",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [],
 "evidence": "20-seguimiento/2026-09-26-acta-recibo-9.md"
 },
 {
 "who": "Elena Duarte",
 "what": "Cerrar la prueba 10",
 "due_date": "2026-10-26",
 "original_due_date": "2026-10-13",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "met",
 "reschedules": [
 {
 "due_date": "2026-10-26",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md"
 }
 ],
 "evidence": "20-seguimiento/2026-10-03-acta-recibo-10.md"
 },
 {
 "who": "Felipe Arango",
 "what": "Revisar el anexo 11",
 "due_date": "2026-09-29",
 "original_due_date": "2026-09-29",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Sandra Gil",
 "what": "Validar el ambiente 12",
 "due_date": "2026-09-22",
 "original_due_date": "2026-09-22",
 "stated_on": "2026-09-19",
 "source": "30-reuniones/2026-09-19-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Aprobar el diseño 13",
 "due_date": "2026-10-06",
 "original_due_date": "2026-10-06",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Liliana Torres",
 "what": "Actualizar la matriz 14",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [],
 "note": "el 2026-10-03 dijo que ya entregó; no se presentó acta, y desde el 2026-10-10 no aparece en la tabla"
 },
 {
 "who": "Carlos Peña",
 "what": "Confirmar la fecha 15",
 "due_date": "2026-10-15",
 "original_due_date": "2026-10-15",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Andrés Lozano",
 "what": "Entregar el punto 16",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-14",
 "stated_on": "2026-09-26",
 "source": "30-reuniones/2026-09-26-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-27",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Jorge Medina",
 "what": "Enviar el documento 17",
 "due_date": "2026-10-28",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-10-28",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Gustavo Neira",
 "what": "Cerrar la prueba 18",
 "due_date": "2026-10-08",
 "original_due_date": "2026-10-08",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "overdue",
 "reschedules": []
 },
 {
 "who": "Camilo Beltrán",
 "what": "Revisar el anexo 19",
 "due_date": "2026-11-08",
 "original_due_date": "2026-10-26",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": [
 {
 "due_date": "2026-11-08",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md"
 }
 ]
 },
 {
 "who": "Elena Duarte",
 "what": "Validar el ambiente 20",
 "due_date": "2026-10-17",
 "original_due_date": "2026-10-17",
 "stated_on": "2026-10-03",
 "source": "30-reuniones/2026-10-03-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Mauricio Pérez",
 "what": "Aprobar el diseño 21",
 "due_date": "2026-10-20",
 "original_due_date": "2026-10-20",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Paula Céspedes",
 "what": "Actualizar la matriz 22",
 "due_date": "2026-10-24",
 "original_due_date": "2026-10-24",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Confirmar la fecha 23",
 "due_date": "2026-11-07",
 "original_due_date": "2026-11-07",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "María Restrepo",
 "what": "Entregar el punto 24",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-10",
 "source": "30-reuniones/2026-10-10-comite-semanal.md",
 "state": "open",
 "reschedules": []
 },
 {
 "who": "Laura Vélez",
 "what": "Mandar el ajuste del presupuesto",
 "due_date": "no_declarada",
 "original_due_date": "no_declarada",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": [],
 "note": "dicho como «la otra semana»; nadie dio fecha"
 },
 {
 "who": "Óscar Ramírez",
 "what": "Revisión con el proveedor",
 "due_date": "2026-10-27",
 "original_due_date": "2026-10-27",
 "stated_on": "2026-10-17",
 "source": "2026-10-17-notas-reunion.txt",
 "state": "open",
 "reschedules": []
 }
 ],
 "meta": {
 "record_updated": "2026-10-17",
 "fields_not_found": [
 "identity.authority",
 "identity.phase"
 ],
 "open_conflicts": []
 }
}
