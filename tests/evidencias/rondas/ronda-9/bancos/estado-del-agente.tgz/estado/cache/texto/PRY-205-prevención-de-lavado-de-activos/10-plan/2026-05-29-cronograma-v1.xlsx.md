<!-- origen: PRY-205-prevención-de-lavado-de-activos/10-plan/2026-05-29-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-24 | 2026-08-24 | cerrado
Ambiente de pruebas certificado | 2026-11-09 | 2026-11-09 | en curso
Integración con el core | 2027-01-25 | 2027-01-25 | en curso
Piloto con usuarios internos | 2027-04-12 | 2027-04-12 | en curso
Salida a producción | 2027-06-28 | 2027-06-28 | en curso
