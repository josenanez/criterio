<!-- origen: PRY-201-core-de-depósitos/30-reuniones/2026-10-13-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Arquitectura · Core de depósitos

Fecha: 2026-10-13

Asistentes: Óscar Ramírez, Liliana Torres

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Óscar Ramírez

Entregar el punto 22

2026-11-07
