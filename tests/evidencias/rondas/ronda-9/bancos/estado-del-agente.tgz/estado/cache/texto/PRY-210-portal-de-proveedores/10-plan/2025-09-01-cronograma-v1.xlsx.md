<!-- origen: PRY-210-portal-de-proveedores/10-plan/2025-09-01-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2025-11-28 | 2025-11-28 | cerrado
Ambiente de pruebas certificado | 2026-02-15 | 2026-02-15 | cerrado
Integración con el core | 2026-05-04 | 2026-05-04 | cerrado
Piloto con usuarios internos | 2026-07-22 | 2026-07-22 | cerrado
Salida a producción | 2026-10-08 | 2026-10-08 | en curso
