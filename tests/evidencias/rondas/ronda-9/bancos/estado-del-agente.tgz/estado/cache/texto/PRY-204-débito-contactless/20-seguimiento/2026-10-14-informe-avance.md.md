<!-- origen: PRY-204-débito-contactless/20-seguimiento/2026-10-14-informe-avance.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Informe de avance · Débito contactless

**Código:** PRY-204
**Fecha de corte:** 2026-10-14
**Gerente:** Ricardo Salas

## Estado declarado

**Verde**

Avance reportado: **68%**

## Lo que pasó en el periodo

- Se recibió la aprobación regulatoria pendiente desde el trimestre anterior
- Se ajustó el plan de pruebas con el área de seguridad
- La prueba de carga no alcanzó el umbral pactado y se repite

## Presupuesto

| | COP |
|---|---|
| Aprobado | 3.300.000.000 |
| Comprometido | 2.071.318.737 |
| Ejecutado | 1.003.450.206 |
| Proyección al cierre | 3.463.346.820 |

## Riesgos abiertos

- Concentración del conocimiento en una sola persona
