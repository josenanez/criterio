<!-- origen: PRY-204-débito-contactless/30-reuniones/2026-10-16-comite-semanal.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Comité de Transformación Digital · Débito contactless

**Fecha:** 2026-10-16
**Asistentes:** Ricardo Salas, Gustavo Neira

## Temas tratados

1. Avance
2. Compromisos

## Compromisos

| Responsable | Compromiso | Para |
|---|---|---|
| Jorge Medina | Entregar el punto 26 | 2026-10-12 |
