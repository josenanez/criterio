<!-- origen: PRY-203-open-banking/10-plan/2026-03-24-cronograma-v1.csv · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

hito,fecha_linea_base,fecha_vigente,estado
Diseño funcional aprobado,2026-06-03,2026-06-03,cerrado
Ambiente de pruebas certificado,2026-08-04,2026-08-04,cerrado
Integración con el core,2026-10-05,2026-10-05,en curso
Piloto con usuarios internos,2026-12-06,2026-12-06,en curso
