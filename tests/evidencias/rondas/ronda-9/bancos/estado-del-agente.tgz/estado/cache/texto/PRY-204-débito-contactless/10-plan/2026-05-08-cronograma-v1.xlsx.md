<!-- origen: PRY-204-débito-contactless/10-plan/2026-05-08-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-08-26 | 2026-08-26 | cerrado
Ambiente de pruebas certificado | 2026-12-04 | 2026-12-04 | en curso
Integración con el core | 2027-03-14 | 2027-03-14 | en curso
Piloto con usuarios internos | 2027-06-22 | 2027-06-22 | en curso
