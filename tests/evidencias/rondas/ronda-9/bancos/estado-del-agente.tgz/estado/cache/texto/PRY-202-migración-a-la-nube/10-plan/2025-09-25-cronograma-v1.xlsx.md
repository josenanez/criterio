<!-- origen: PRY-202-migración-a-la-nube/10-plan/2025-09-25-cronograma-v1.xlsx · convertidor: xlsx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

## Cronograma

hito | fecha_linea_base | fecha_vigente | estado
Diseño funcional aprobado | 2026-02-27 | 2026-02-27 | cerrado
Ambiente de pruebas certificado | 2026-07-22 | 2026-07-22 | cerrado
Integración con el core | 2026-12-14 | 2026-12-14 | en curso
