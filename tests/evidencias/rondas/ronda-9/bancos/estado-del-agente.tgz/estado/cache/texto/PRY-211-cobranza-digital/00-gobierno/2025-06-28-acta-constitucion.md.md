<!-- origen: PRY-211-cobranza-digital/00-gobierno/2025-06-28-acta-constitucion.md · convertidor: nativo -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

# Acta de constitución · Cobranza digital

**Código:** PRY-211
**Área dueña:** Banca PyME
**Patrocinador:** Javier Hoyos
**Gerente de proyecto:** Natalia Ospina
**Comité:** Comité de Riesgos
**Producto asociado:** recaudos
**Fecha de aprobación:** 2025-06-28

## Objetivo del negocio

Entregar cobranza digital para Banca PyME.

## Alcance

- Componente 1
- Componente 2
- Componente 3

## Fuera de alcance

- Lo que otro proyecto cubre

## Presupuesto aprobado

**3.300.000.000 COP**, aprobado por Comité de Riesgos el 2025-06-28.

## Fechas comprometidas

| | Fecha |
|---|---|
| Inicio | 2025-07-08 |
| Cierre | 2026-01-27 |

## Criterio de éxito

Cobranza digital en producción y medido.

## Dependencias declaradas

- Ninguna declarada
