<!-- origen: PRY-210-portal-de-proveedores/30-reuniones/2026-10-14-comite-semanal.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Comité de Banca Empresas · Portal de proveedores

Fecha: 2026-10-14

Asistentes: Rubén Cárdenas, Carlos Peña

Temas tratados

1. Avance

2. Compromisos

Compromisos

Responsable

Compromiso

Para

Andrés Lozano

Entregar el punto 7

2026-09-25

Liliana Torres

Entregar el punto 25

2026-11-14
