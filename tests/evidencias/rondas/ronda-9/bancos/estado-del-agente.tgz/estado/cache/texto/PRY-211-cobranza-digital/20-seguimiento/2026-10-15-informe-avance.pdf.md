<!-- origen: PRY-211-cobranza-digital/20-seguimiento/2026-10-15-informe-avance.pdf · convertidor: pdftotext -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Informe de avance · Cobranza digital
Código: PRY-211
Fecha de corte: 2026-10-15
Gerente: Natalia Ospina

Estado declarado
Rojo
Avance reportado: 74%

Lo que pasó en el periodo
- Se reprogramó la salida por ventana de cambio del área de operaciones
- Dos historias quedaron fuera del alcance del sprint por dependencia con el core

Presupuesto
COP
Aprobado 3.300.000.000
Comprometido 2.417.074.776
Ejecutado 1.438.639.658
Proyección al cierre 3.243.862.115

Riesgos abiertos
- Dependencia del calendario de liberaciones del core
