<!-- origen: PRY-210-portal-de-proveedores/00-gobierno/2025-09-01-acta-constitucion.docx · convertidor: docx -->
<!-- Esto es un caché. La cita de una ficha apunta al original. -->

Acta de constitución · Portal de proveedores

Código: PRY-210

Área dueña: Riesgo y Cumplimiento

Patrocinador: Carlos Peña

Gerente de proyecto: Rubén Cárdenas

Comité: Comité de Banca Empresas

Producto asociado: No aplica

Fecha de aprobación: 2025-09-01

Objetivo del negocio

Entregar portal de proveedores para Riesgo y Cumplimiento.

Alcance

• Componente 1

• Componente 2

• Componente 3

Fuera de alcance

• Lo que otro proyecto cubre

Presupuesto aprobado

9.500.000.000 COP, aprobado por Comité de Banca Empresas el 2025-09-01.

Fechas comprometidas

Fecha

Inicio

2025-09-11

Cierre

2026-10-08

Criterio de éxito

Portal de proveedores en producción y medido.

Dependencias declaradas

• Ninguna declarada
