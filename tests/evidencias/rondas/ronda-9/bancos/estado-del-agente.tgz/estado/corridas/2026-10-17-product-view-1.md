# Corrida del 2026-10-17 · product-view

13 proyectos · 21 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 14 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `milestone_overdue` | 3 |
| `variance_cost` | 3 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 2 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

Producto con un solo proyecto (PRY-209); se resumió en una línea. Señal abierta: silencio de 21 días. No se pudo verificar la fecha de cierre 2026-06-28 ni la fuente de los 14 datos (todos sin marcar). Se reportaron 4 proyectos sin producto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

**Fuente:** fichas del portafolio en `estado/`, recalculadas con `portafolio.py compute` al 2026-10-17. Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17).

## Productos al 2026-10-17 — nómina empresarial

El producto **nómina empresarial** tiene un solo proyecto, **PRY-209 Nómina electrónica**. La vista por producto no aporta nada sobre un solo proyecto, así que no armo la sección completa. Esto es lo que hay:

| Producto | Proyectos | Con alertas | Fecha más tardía | Aprobado | Comprometido |
|---|---|---|---|---|---|
| nómina empresarial | 1 (PRY-209) | 1 (1 alerta) | 2026-06-28 (PRY-209) | COP 9.500.000.000 | COP 5.744.594.486 |

**Lo que hay que ver:**
- **Proyecto en silencio:** PRY-209 lleva 21 días sin movimiento (desde 2026-09-26). El umbral configurado es 15 días.
- **Último informe:** declara estado *amarillo* y 78 % de avance, con fecha 2026-09-26 (21 días de antigüedad). La señal de silencio no está explicada en ese informe.
- **Dinero:** ejecutado COP 2.599.596.789 (27,4 %), comprometido 60,5 %, proyección COP 9.715.554.033 (2,3 % sobre lo aprobado), disponible real COP 3.755.405.514. Las cuatro cifras vienen completas (1 de 1 proyecto).
- **Sin desviación calculada:** el script no reporta atraso contra la línea base (0 días, sin replanificaciones), ni hitos vencidos, ni compromisos vencidos.

**Dependencias internas:** ninguna declarada. Con un solo proyecto no hay con quién coordinarse dentro del producto.

**Fecha comprometida del producto:** 2026-06-28, sale de PRY-209. Es anterior a la fecha de corte (2026-10-17), y el script no calcula días de atraso ni hitos vencidos para este proyecto. Con un informe amarillo del 78 % y una fecha de cierre ya pasada, algo no cuadra. No puedo decir qué sin leer el plan: el cálculo no lo da.

**Lo que no sé:**
- Ninguno de los 14 datos de la ficha de PRY-209 tiene marca de fuente: 0 de evidencia, 0 de declaración, 14 sin marcar. Todo lo anterior es lo que dice la ficha, no lo que sustenta un documento.
- Faltan `identity.authority` e `identity.phase`. Nadie figura como autoridad que apruebe cambios.
- No sé si la fecha 2026-06-28 es la vigente o una anterior que nadie actualizó.

### Proyectos sin producto declarado (hallazgo de gobierno)
| Proyecto | Área dueña |
|---|---|
| PRY-202 Migración a la nube | no consta en la ficha |
| PRY-205 Prevención de lavado de activos | no consta en la ficha |
| PRY-208 Motor de decisión | no consta en la ficha |
| PRY-210 Portal de proveedores | no consta en la ficha |

Consecuencia: nadie puede responder por el conjunto al que sirven. No tocan nómina empresarial, pero salen en el cálculo.

Además, el producto «PRD-299» (PRY-199) parece un código y no un nombre, y no coincide con los nombres de los demás productos.

**Siguiente paso sugerido:** pedir a la persona que lleva PRY-209 un informe actualizado y la fecha de cierre vigente.

---
*Pie de rigor:* cifras copiadas de la salida de `compute` al 2026-10-17. Borrador de trabajo, no decisión ni asesoría; la verificación contra los documentos citados es suya.
