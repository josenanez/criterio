## Barrido — 2026-10-17

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17): https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

**Documentos:** 71 en la carpeta · 44 leídos · 27 sin cambio desde la corrida anterior · 0 ilegibles
**Proyectos:** 13 en la carpeta · 10 con ficha nueva (PRY-199, 202, 204 a 211) · 3 sin cambio (PRY-200, 201, 203) · 0 sin carpeta propia
**Formatos:** 36 .md, 12 .docx, 10 .pdf, 10 .xlsx, 1 .csv, 1 .json, 1 .txt. Los .docx, .xlsx y .pdf se leyeron por su texto convertido; las citas van a los originales.

Nada se aplazó: el plan cabía en un solo lote (44 documentos, `workers: 1`). Cada ficha se escribió y se selló al terminar su proyecto.

### Nuevos
| Proyecto | Documentos | Campos encontrados | Campos sin dato |
|---|---|---|---|
| PRY-199 Renovación de cajeros automáticos | 6 | identidad, plazo, presupuesto, 5 hitos, 1 contrato (3 entregables), 1 riesgo, 1 compromiso | autoridad, fase, facturado |
| PRY-202 Migración a la nube | 3 | identidad, plazo, presupuesto, 3 hitos, 2 riesgos | producto («No aplica»), autoridad, fase |
| PRY-204 Débito contactless | 5 | identidad, plazo, presupuesto, 4 hitos, 1 riesgo, 1 incidencia, 1 compromiso | autoridad, fase |
| PRY-205 Prevención de lavado de activos | 6 | identidad, plazo, presupuesto, 5 hitos, 1 contrato (3 entregables), 1 riesgo, 2 incidencias, 1 compromiso | producto («No aplica»), autoridad, fase, facturado |
| PRY-206 Billetera y QR | 5 | identidad, plazo, presupuesto, 4 hitos, 2 riesgos, 1 incidencia, 1 compromiso | autoridad, fase |
| PRY-207 Onboarding PyME | 4 | identidad, plazo, presupuesto, 4 hitos, 2 riesgos, 1 incidencia | autoridad, fase |
| PRY-208 Motor de decisión | 2 | identidad, plazo, presupuesto, 1 riesgo, 1 incidencia | producto («No aplica»), autoridad, fase; no hay cronograma |
| PRY-209 Nómina electrónica | 2 | identidad, plazo, presupuesto, 2 riesgos, 2 incidencias | autoridad, fase; no hay cronograma |
| PRY-210 Portal de proveedores | 8 | identidad, plazo, presupuesto, 5 hitos, 1 contrato (4 entregables, 2 con acta), factura, 2 riesgos, 2 compromisos | producto («No aplica»), autoridad, fase |
| PRY-211 Cobranza digital | 3 | identidad, plazo, presupuesto, 1 solicitud de cambio, 1 riesgo, 2 incidencias | autoridad, fase; no hay cronograma |

### Actualizados
Ninguno. Las fichas de PRY-200, 201 y 203 no se tocaron: sus documentos no cambiaron.

### Lo que el cálculo señala (de las fichas de esta corrida)
| Proyecto | Declara | Señal | Fuente |
|---|---|---|---|
| PRY-202 | Verde, 37% | 2 hitos «cerrado» sin acta de recibo; avance 30 puntos por debajo de lo que sostiene el plan; proyección 27,6% sobre el presupuesto | informe 2026-10-13; cronograma v1 |
| PRY-204 | Verde, 68% | Compromiso de Jorge Medina vencido hace 5 días; avance declarado muy por encima de lo que sostienen los hitos (1 de 4 cerrado) | comité 2026-10-16 |
| PRY-205 | Verde, 82% | Avance muy por encima de lo que sostienen los hitos (1 de 5); entregable «Licenciamiento del motor» de CT-172 vencido hace 25 días; compromiso de Laura Vélez vencido | contrato CT-172; comité 2026-10-15 |
| PRY-206 | Verde, 36% | Hito «Ambiente de pruebas certificado» cerrado sin acta de recibo; 14 puntos por debajo del plan | cronograma v1 |
| PRY-207 | Rojo, 76% | 3 de 4 hitos cerrados sin acta (solo el piloto tiene); proyección 22% sobre el presupuesto; el cierre comprometido (2026-08-29) ya pasó | informe 2026-10-06 |
| PRY-208 | Verde, 47% | En silencio hace 17 días (último documento 2026-09-30) | informe 2026-09-30 |
| PRY-209 | Amarillo, 78% | En silencio hace 21 días; el cierre comprometido (2026-06-28) ya pasó y no hay cronograma ni nueva fecha | informe 2026-09-26 |
| PRY-210 | Verde, 52% | Hito «Salida a producción» vencido hace 9 días (el informe dice «se reprogramó» sin dar fecha); 4 hitos cerrados sin acta; 2 entregables de CT-882 vencidos sin entregar (315 y 142 días); compromiso de Andrés Lozano vencido hace 22 días | informe 2026-10-16; contrato CT-882; comité 2026-10-14 |
| PRY-211 | Rojo, 74% | Solicitud CC-01 pendiente de comité: +116 días y +232.000.000 COP; el cierre comprometido (2026-01-27) ya pasó; sin cronograma | CC-01 2026-10-07 |
| PRY-199 | Verde, 20% | Sin señales | — |

Facturación de PRY-210: la factura FV-1882 por 1.361.054.552 COP cuadra con los dos entregables que sí tienen acta (Bolsa de horas, Mesa de ayuda); no hay factura adelantada.

### No pude leer
Ninguno.

### Movidos desde entrada/
Ninguno: no hay carpeta `entrada/` con archivos sueltos.

### Pendientes de clasificar
Ninguno.

### Para mirar
- Contradicciones entre documentos: ninguna.
- En PRY-208, 209 y 211 no hay cronograma, así que no hay hitos que medir; sus fechas de cierre salen del acta. Es un vacío de información.
- PRY-210 y PRY-211 dicen que la salida «se reprogramó», pero ningún documento da la fecha nueva. Se dejó la comprometida y no se inventó otra.
- `identity.authority` y `identity.phase` no están en ningún acta: `not_found` en los 10 proyectos.
- Los compromisos con fecha anterior a la minuta que los registra (PRY-204, 205, 210) se guardaron vencidos, con la fecha tal como está escrita.

### Pie
criterio-portfolio 0.4.0 · fichas tocadas: 10 (PRY-199, 202, 204 a 211) · campos en `not_found`: 2 en cada ficha (autoridad, fase) más producto en PRY-202, 205, 208 y 210 (el acta dice «No aplica») · Términos: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

Siguiente paso: ofrezco el informe consolidado del portafolio (`/portfolio-report`), con las contradicciones y los compromisos vencidos ya a la vista.
