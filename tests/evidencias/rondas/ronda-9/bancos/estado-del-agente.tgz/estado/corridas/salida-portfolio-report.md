# Portafolio — 2026-10-17
13 proyectos · 11 con hallazgos (58 señales) · último barrido 2026-10-17 · formato: html

**Fichas cargadas:** 13 fichas de `estado/records/` (PRY-199 a PRY-211), todas del barrido de hoy, 2026-10-17. Ninguna tiene más de una semana; no hace falta correr `/portfolio-scan` antes. (Las fichas están en `estado/records/`, no en `estado/fichas/`; usé la carpeta que existe.)

**Términos:** vigentes (v1.1, aceptados por José Francisco Ñáñez el 2026-10-17, comprobante en `.criterio/terminos/`); no hubo que registrarlos de nuevo. En corto: Criterio produce borradores de trabajo, no decisiones ni asesoría; procesa solo los documentos indicados y puede equivocarse, por eso cada dato lleva su cita y la verificación es de quien lo usa; los documentos se procesan en la infraestructura de la plataforma de IA. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

## Informe generado
Carpeta: `/home/claude/banco/ronda-9/bancos/espacio/reportes` (26 páginas: 13 proyectos, 9 productos y las dos vistas).
- `index.html` — por campo, con la cadena de evidencia. Para quien va a actuar (gerente de PMO, gerentes de proyecto).
- `decisiones.html` — por decisión, solo lo que excede la facultad de quien gerencia. Para el patrocinador y el comité del 2026-10-24.
- PDF: se obtiene imprimiendo el HTML (hoja de estilos de impresión incluida).

## Qué cambió desde la corrida anterior
Sin cambios desde la corrida anterior. La única instantánea es la de hoy (`2026-10-17`) y el diff contra ella da 0 cambios: es el punto de partida, no hay delta.

## Contradicciones abiertas
Vacía: ninguna ficha tiene campos en conflicto entre dos fuentes.

La contradicción que sí aparece es otra: **8 de 13 proyectos declaran verde y las señales no lo sostienen** (PRY-200, 202, 203, 204, 205, 206, 208, 210). Ver "Estado general".

## Hitos vencidos sin evidencia
| Proyecto | Hito | Fecha | Días | Última mención |
|---|---|---|---|---|
| PRY-200 | Diseño funcional aprobado | 2026-10-05 | 12 | sin hito cumplido (0 de 3) |
| PRY-203 | Integración con el core | 2026-10-05 | 12 | declarado verde el 2026-09-23 |
| PRY-210 | Salida a producción (fin del proyecto) | 2026-10-08 | 9 | declarado verde el 2026-10-16 |

Además, hitos declarados cumplidos sin documento que lo pruebe:
| Proyecto | Hitos "cumplidos" sin evidencia | Días desde su fecha (el mayor) |
|---|---|---|
| PRY-207 | 3 de 4 | 349 |
| PRY-210 | 4 de 5 | 323 |
| PRY-202 | 2 de 3 | 232 |
| PRY-201 | 2 de 4 | 160 |
| PRY-203 | 2 de 4 | 136 |
| PRY-206 | 1 de 4 | 72 |

## Proyectos en silencio
Umbral: 15 días.
| Proyecto | Días | Último documento |
|---|---|---|
| PRY-209 Nómina electrónica | 21 | 2026-09-26 |
| PRY-208 Motor de decisión | 17 | 2026-09-30 |

Cerca del umbral: PRY-207 (11 días), PRY-206 (7).

## Dependencias en riesgo
Vacía: ninguna ficha declara dependencias por código entre proyectos.

## Sin sustento
Compromisos y cifras que no tienen respaldo:
| Proyecto | Declara | Qué lo respalda |
|---|---|---|
| PRY-205 | 82 % de avance | El plan sustenta 20–40 % (1 de 5 hitos). Brecha de 42 puntos adelante |
| PRY-204 | 68 % de avance | El plan sustenta 25–50 % (1 de 4 hitos). Brecha de 18 puntos adelante |
| PRY-201 | 29 % de avance | El plan sustenta 75–100 % (3 de 4 hitos). Brecha de 46 puntos atrás |
| PRY-207 | 76 % de avance | El plan sustenta 100 % (4 de 4 hitos). Brecha de 24 puntos atrás |
| PRY-202 | 37 % de avance | El plan sustenta 67–100 %. Brecha de 30 puntos atrás |
| PRY-210 | 52 % de avance | El plan sustenta 80–100 %. Brecha de 28 puntos atrás |
| PRY-206 | 36 % de avance | El plan sustenta 50–75 %. Brecha de 14 puntos atrás |

Nota: en las 13 fichas ninguna fuente está marcada como evidencia ni como declaración (`unmarked`); la distinción entre ambas queda por hacer.

Compromisos de reunión:
- PRY-200: 8 vencidos sin evidencia (hasta 25 días), 3 sin fecha, 2 reprogramados 6 y 4 veces (Elena Duarte, "Enviar el documento 1", de 2026-09-25 a 2026-12-05; Ricardo Salas, "Cerrar la prueba 2", de 2026-09-20 a 2026-11-20).
- PRY-204: 1 vencido (Jorge Medina, 5 días). PRY-205: 1 vencido (Laura Vélez, 6 días). PRY-210: 1 vencido (Andrés Lozano, 22 días).

Proveedores:
- PRY-210, Talento Digital S.A.S. (CT-882): "Licenciamiento del motor" pendiente 315 días y "Parametrización del tarifario" 142 días; se han aceptado y facturado COP 1.361.054.552.
- PRY-205, Núcleo Financiero S.A. (CT-172): "Licenciamiento del motor" pendiente 25 días.

## Vacíos de información
| Proyecto | Qué falta |
|---|---|
| Los 13 | Autoridad de aprobación (`identity.authority`) y fase (`identity.phase`) |
| PRY-202, 205, 208, 210 | Producto asociado; no entran a ninguna vista por producto |
| PRY-199, 205 | Monto facturado del proveedor |
| PRY-201, 202, 207, 210, 211 | Campos de identidad y plan con más de 12 meses (hasta 16) |
| PRY-203 | Cambio CC-01 aprobado (114 días) sin línea base nueva registrada |

## Estado general
| Proyecto | Declarado | Sustento | Desviación vs original | vs vigente | Replanificaciones |
|---|---|---|---|---|---|
| PRY-199 Renovación de cajeros | verde | sin señales | 0 días | 0 | 0 |
| PRY-200 Originación digital | verde | **contradicho**: hito vencido, costo +15,9 %, 8 compromisos vencidos | 0 días | 0 | 0 |
| PRY-201 Core de depósitos | rojo | consistente con las señales; 2 hitos sin evidencia | 0 días | 0 | 0 |
| PRY-202 Migración a la nube | verde | **contradicho**: costo +27,6 %, avance 30 puntos atrás | 0 días | 0 | 0 |
| PRY-203 Open Banking | verde | **contradicho**: +114 días (46,2 %), hito vencido | +114 días | 0 | 1 |
| PRY-204 Débito contactless | verde | **contradicho**: avance adelantado sin hitos, compromiso vencido | 0 días | 0 | 0 |
| PRY-205 Prevención de lavado | verde | **contradicho**: avance 42 puntos adelante, proveedor atrasado | 0 días | 0 | 0 |
| PRY-206 Billetera y QR | verde | **contradicho**: avance 14 puntos atrás, hito sin evidencia | 0 días | 0 | 0 |
| PRY-207 Onboarding PyME | rojo | consistente: costo +22 %, 3 hitos sin evidencia; fecha fin 2026-08-29 ya pasó | 0 días | 0 | 0 |
| PRY-208 Motor de decisión | verde | **contradicho**: 17 días en silencio | 0 días | 0 | 0 |
| PRY-209 Nómina electrónica | amarillo | 21 días en silencio; fecha fin 2026-06-28 ya pasó | 0 días | 0 | 0 |
| PRY-210 Portal de proveedores | verde | **contradicho**: 5 señales, salida a producción vencida 9 días | 0 días | 0 | 0 |
| PRY-211 Cobranza digital | rojo | sin señales; fecha fin 2026-01-27 ya pasó | 0 días | 0 | 0 |

Presupuesto: proyecciones sobre el aprobado por encima del umbral de 10 %: PRY-202 (+27,6 %), PRY-207 (+22,0 %), PRY-200 (+15,9 %). Ningún proyecto supera el 90 % comprometido; el más alto es PRY-205 con 83,2 %.

Observación: PRY-207, PRY-209 y PRY-211 tienen fecha de fin ya vencida y siguen abiertos sin replanificación registrada (0 replanificaciones). Es dato de la ficha; confirmar si cerraron o si la fecha no se actualizó.

## Necesito que confirmes
No toca confirmación periódica este mes: es la primera corrida y no hay confirmaciones previas con las que medir antigüedad. Cuando toque (mensual, 5 campos), saldrán de los campos de identidad de PRY-211, PRY-207, PRY-210, PRY-202 y PRY-201.

---
Criterio portfolio 0.4.0 · términos v1.1 · fichas aplicadas: 13, todas del 2026-10-17 · campos inciertos: autoridad y fase en los 13 proyectos, producto en 4, fuentes sin marcar en las 13 · términos y nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0
