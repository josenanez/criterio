Fuentes: ficha `estado/records/PRY-202.json` (acta de constitución del 2025-09-25 e informe de avance del 2026-10-13) y cifras de `portafolio.py compute` al 2026-10-17. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## Presupuesto — PRY-202 Migración a la nube, al 2026-10-17
**Moneda:** COP (única; no hay otras monedas ni conversiones)

| | Monto (COP) | % del aprobado | Fuente | Fecha |
|---|---|---|---|---|
| Aprobado | 9.500.000.000 | — | 00-gobierno/2025-09-25-acta-constitucion.docx | 2025-09-25 |
| Comprometido | 6.552.528.459 | 69.0% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Ejecutado | 2.548.693.323 | 26.8% | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |
| Proyección al cierre | 12.125.785.918 | 27.6% por encima del aprobado | 20-seguimiento/2026-10-13-informe-avance.md | 2026-10-13 |

**Disponible real** (aprobado menos comprometido): 2.947.471.541 COP

La proyección es una declaración del gerente, no un dato duro. Es posterior al aprobado (2025-09-25) y no hay ningún movimiento de presupuesto posterior que la contradiga.

### Contra la línea base
| | Original | Vigente | Desviación |
|---|---|---|---|
| Presupuesto aprobado | 9.500.000.000 | 9.500.000.000 | 0 |
| Proyección vs aprobado | 9.500.000.000 | 12.125.785.918 | +27.6% (umbral 10%) |

Replanificaciones de presupuesto: 0. Solicitudes de cambio registradas: 0. Solo existe una versión de línea base (v1, 2025-09-25).

### Ejecución frente a avance
Ejecutado 26.8% · Hitos cumplidos 2 de 3 (declarados) · Avance declarado 37.0%; el plan sustenta entre 67% y 100%, una brecha de 30.0 puntos por detrás. Ninguno de los dos hitos "cumplidos" tiene evidencia de recibo.

Lectura: la ejecución es baja frente a los hitos declarados, pero el hito 3 (Integración con el core, 2026-12-14) sigue pendiente. La ejecución no está desalineada hacia arriba. El problema es que la proyección excede el aprobado en 27.6% con dos meses de plazo, y que el avance declarado (37%) no cuadra con los hitos (2 de 3).

### Alertas
- **Proyección excede el aprobado:** 12.125.785.918 frente a 9.500.000.000, 27.6% (umbral 10%).
- **Estado declarado "verde" (informe del 2026-10-13)** sin tener en cuenta tres señales abiertas: el sobrecosto, la brecha de avance y los hitos sin evidencia.
- **Hitos cumplidos sin evidencia:** "Diseño funcional aprobado" (vencía 2026-02-27, 232 días) y "Ambiente de pruebas certificado" (vencía 2026-07-22, 87 días).
- Comprometido 69.0%: por debajo del umbral de 90%, sin alerta por ese concepto.

### Sin dato
- Detalle por proveedor: la ficha no registra proveedores ni contratos para PRY-202.
- Fecha de la última aprobación de presupuesto distinta del acta: no declarada.
- Campos de identidad sin dato: producto, autoridad, fase.
- El monto aprobado tiene 13 meses de antigüedad (umbral 12 meses): conviene confirmarlo.

### Siguiente paso
La proyección excede el aprobado: puedo preparar la solicitud de cambio de presupuesto (`/criterio-portfolio:change-control`).

---
Pie de rigor: borrador de trabajo, no decisión ni asesoría. Cada cifra sale de la ficha y de `compute`; la verificación contra los documentos es de quien lo lee. No sé lo que se haya hablado fuera de esos documentos.
