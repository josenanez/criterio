## RAID — portafolio (13 proyectos, PRY-199 a PRY-211) al 2026-10-17

**De qué documentos sale:** las 13 fichas (`estado/records/PRY-199…211.json`), que citan los informes de avance 2026-09-23 a 2026-10-17; las actas de constitución (sección «Dependencias declaradas»); las minutas de comité 2026-09-05 a 2026-10-17; y las notas de reunión de PRY-200 del 2026-10-17. No leí correos, chats ni nada que no esté en la carpeta.

**Conteo del registro tal como está en los informes:** 21 riesgos · 0 supuestos · 14 incidencias · 0 dependencias
**Hallazgos:** 35 de 35 sin doliente · 21 de 21 riesgos sin probabilidad, impacto ni fecha · 1 no registrado formalmente (PRY-200) · 0 dependencias con código de proyecto
**Sin movimiento en dos períodos:** no se puede determinar. Las fichas guardan una sola fecha por ítem (la del informe en que aparece), sin historial de movimiento.

Escala: ningún documento define probabilidad ni impacto. Uso alta/media/baja y no valoro ninguno, porque no hay base documental para hacerlo.

Los Id (`203-R1`, `205-I2`…) los puse yo para poder citarlos. Los documentos no traen identificadores de riesgo.

### Lo que dice el conjunto, antes de la tabla

Casi todo el registro es texto repetido palabra por palabra entre proyectos. Puede ser un problema compartido o plantilla copiada. Los documentos no permiten distinguirlo, y eso hay que verificarlo con los gerentes.

| Texto | Proyectos | Tipo en el informe |
|---|---|---|
| «Dependencia del calendario de liberaciones del core» | 200, 202, 203, 206, 207, 208, 210, 211 (8) | riesgo |
| «Concentración del conocimiento en una sola persona» | 199, 200, 203, 204, 205, 209 (6) | riesgo |
| «La prueba de carga no alcanzó el umbral pactado y se repite» | 200, 203, 204, 205, 206, 209 (6) | incidencia |
| «Disponibilidad del equipo de seguridad para la revisión final» | 201, 206, 207, 209, 210 (5) | riesgo |
| «Dos historias quedaron fuera del alcance del sprint por dependencia con el core» | 201, 205, 207, 211 (4) | incidencia |

### Reclasificaciones

- **«Dependencia del calendario de liberaciones del core» (8 proyectos): riesgo → dependencia.** Depende de alguien fuera del proyecto. Ningún informe dice de qué proyecto o equipo habla, así que no puedo ponerle código. Ver abajo.
- **«Disponibilidad del equipo de seguridad…» (5 proyectos): riesgo → dependencia.** El equipo de seguridad es ajeno al proyecto. No dice de cuál área ni de qué proyecto.
- **202-R1 «El proveedor no ha confirmado la fecha de la última entrega»: riesgo → dependencia** declarada, no acordada. El proveedor no ha confirmado.
- **«Dos historias quedaron fuera… por dependencia con el core»:** sigue siendo incidencia, porque ya pasó. Pero deja confirmado que la dependencia del core ya se materializó en 4 proyectos. De esos 4, solo 207 y 211 la registran también como riesgo; 201 y 205 no.
- **Supuestos: 0 registrados.** No levanté ninguno, porque ningún documento dice que algo se esté dando por cierto. Los que suelen fallar y que nadie anotó, y que habría que preguntar: disponibilidad de la persona clave (hay 6 proyectos con «concentración del conocimiento») y que la ventana de cambio de operaciones esté disponible (PRY-210 y PRY-211 ya la perdieron).

### Necesitan decisión ahora

| Id | Tipo | Qué | Doliente | Desde | Por qué sube |
|---|---|---|---|---|---|
| 8 proyectos | dependencia (hoy figura como riesgo) | Calendario de liberaciones del core | sin doliente | informe 2026-09-23 (203) | Afecta a 8 proyectos a la vez y nadie lo confirmó con el dueño del core. Ya costó incidencias en 201, 205, 207 y 211. |
| 6 proyectos | incidencia | Prueba de carga bajo el umbral, «se repite» | sin doliente | informe 2026-09-23 (203) | Mismo texto en 200, 203, 204, 205, 206 y 209. Si es una causa común, la decisión no está en ningún proyecto. |
| 5 proyectos + 208-I1 | dependencia + incidencia | Equipo de seguridad para la revisión final; hallazgo de seguridad en la revisión de arquitectura de PRY-208 | sin doliente | informe 2026-09-30 (208, el hallazgo) | Es un recurso compartido. El hallazgo de PRY-208 ya ocurrió y nadie lo tiene a su cargo. |
| 210-I1 | incidencia | Salida reprogramada por ventana de cambio de operaciones; el informe no da la fecha nueva | sin doliente | informe 2026-10-16 | El plan de PRY-210 tenía la salida a producción el 2026-10-08 y el hito sigue pendiente. El informe declara verde. |
| 211-I1 | incidencia | Misma reprogramación; sin fecha nueva | sin doliente | informe 2026-10-15 | PRY-211 declara rojo y su fecha fin vigente es 2026-01-27. Además, su CC-01 (+116 días, 232.000.000 COP) está «pendiente de presentación al comité». |
| 209-I2 | incidencia | El equipo perdió dos semanas por rotación de un desarrollador clave | sin doliente | informe 2026-09-26 | Declara amarillo con fecha fin 2026-06-28 ya vencida. El informe es de hace 21 días (umbral de silencio: 15). |
| 202-R1 | dependencia | El proveedor no ha confirmado la fecha de la última entrega | sin doliente | informe 2026-10-13 | El hito «Integración con el core» es el 2026-12-14 (58 días). Es una dependencia externa sin confirmar. |

### Detectados en reuniones, no registrados

| Qué | Tipo | Dicho en | Fecha |
|---|---|---|---|
| «El proveedor podría no llegar con el equipo completo para la siguiente fase» («nadie lo anotó como riesgo») | riesgo (con componente de dependencia: proveedor) | PRY-200, `2026-10-17-notas-reunion.txt` | 2026-10-17 |

Es el único. Las minutas de comité de los demás proyectos solo traen tablas de compromisos y ningún riesgo dicho al pasar. No inventé más. Está marcado como no registrado formalmente: el gerente (Diana Molina) decide si lo formaliza. Las notas no dicen quién lo comentó ni cuál es la fase.

### Sin doliente o sin fecha

| Id | Tipo | Qué | Qué falta |
|---|---|---|---|
| Los 14 | incidencia | Todas las incidencias (ver registro completo) | doliente y fecha de resolución; solo traen la fecha «desde» |
| Los 21 + el no registrado | riesgo | Todos los riesgos | doliente, fecha, probabilidad, impacto, mitigación |

No rellené ninguno. Quién gestiona qué es decisión del gerente o del comité.

### Dependencias en riesgo

| Id | Depende de | Confirmada | Qué pasó |
|---|---|---|---|
| (8 proyectos) calendario de liberaciones del core | «el core»: no consta qué proyecto | No | No hay código de proyecto en ningún documento. Las actas de constitución de los 13 dicen «Ninguna declarada». Solo PRY-201 se llama «Core de depósitos»: su piloto (2026-11-22) no se movió (línea base = vigente) y declara rojo. No afirmo que «el core» sea PRY-201; hay que confirmarlo. |
| 202-R1 proveedor | proveedor externo | No | Sin confirmación de la fecha de la última entrega. |
| equipo de seguridad (5 proyectos) | área ajena | No | Sin fecha ni confirmación. |

**No pude hacer el cruce de portafolio** (el proyecto B depende de A y A movió su fecha), porque ninguna dependencia lleva código de proyecto. Un movimiento de fechas sí consta: PRY-203 pasó su piloto del 2026-12-06 al 2027-03-30 en el cronograma v2, y la ficha dice que el motivo está «no declarado». Ningún documento dice que otro proyecto dependa de ese piloto.

### Registro completo

Ítems: 21 riesgos formales, 1 no registrado, 14 incidencias. Prob., Impacto, Doliente y Fecha: «n/c» = no consta en ningún documento. «Último mov.» = fecha del informe donde aparece; no hay historial.

| Id | Tipo | Qué | Prob. | Impacto | Doliente | Fecha | Último mov. |
|---|---|---|---|---|---|---|---|
| 199-R1 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-10-15 |
| 200-R1 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-10-17 |
| 200-R2 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-17 |
| 200-R3 (no registrado) | riesgo | Proveedor podría no llegar con el equipo completo | n/c | n/c | n/c | n/c | 2026-10-17 (notas) |
| 200-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-10-17 |
| 201-R1 | riesgo → dependencia | Disponibilidad del equipo de seguridad | n/c | n/c | n/c | n/c | 2026-10-16 |
| 201-R2 | riesgo | Cambio regulatorio en discusión que puede mover el alcance | n/c | n/c | n/c | n/c | 2026-10-16 |
| 201-I1 | incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/c | n/c | 2026-10-16 |
| 202-R1 | riesgo → dependencia | Proveedor sin confirmar fecha de la última entrega | n/c | n/c | n/c | n/c | 2026-10-13 |
| 202-R2 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-13 |
| 203-R1 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-09-23 |
| 203-R2 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-09-23 |
| 203-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-09-23 |
| 204-R1 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-10-14 |
| 204-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-10-14 |
| 205-R1 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-10-14 |
| 205-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-10-14 |
| 205-I2 | incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/c | n/c | 2026-10-14 |
| 206-R1 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-10 |
| 206-R2 | riesgo → dependencia | Disponibilidad del equipo de seguridad | n/c | n/c | n/c | n/c | 2026-10-10 |
| 206-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-10-10 |
| 207-R1 | riesgo → dependencia | Disponibilidad del equipo de seguridad | n/c | n/c | n/c | n/c | 2026-10-06 |
| 207-R2 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-06 |
| 207-I1 | incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/c | n/c | 2026-10-06 |
| 208-R1 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-09-30 |
| 208-I1 | incidencia | Hallazgo de seguridad en la revisión de arquitectura | — | — | n/c | n/c | 2026-09-30 |
| 209-R1 | riesgo → dependencia | Disponibilidad del equipo de seguridad | n/c | n/c | n/c | n/c | 2026-09-26 |
| 209-R2 | riesgo | Concentración del conocimiento en una persona | n/c | n/c | n/c | n/c | 2026-09-26 |
| 209-I1 | incidencia | Prueba de carga bajo el umbral, se repite | — | — | n/c | n/c | 2026-09-26 |
| 209-I2 | incidencia | Dos semanas perdidas por rotación de un desarrollador clave | — | — | n/c | n/c | 2026-09-26 |
| 210-R1 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-16 |
| 210-R2 | riesgo → dependencia | Disponibilidad del equipo de seguridad | n/c | n/c | n/c | n/c | 2026-10-16 |
| 210-I1 | incidencia | Salida reprogramada por ventana de operaciones; sin fecha nueva | — | — | n/c | n/c | 2026-10-16 |
| 211-R1 | riesgo → dependencia | Calendario de liberaciones del core | n/c | n/c | n/c | n/c | 2026-10-15 |
| 211-I1 | incidencia | Salida reprogramada por ventana de operaciones; sin fecha nueva | — | — | n/c | n/c | 2026-10-15 |
| 211-I2 | incidencia | Dos historias fuera del sprint por dependencia con el core | — | — | n/c | n/c | 2026-10-15 |

**Datos viejos:** los informes de PRY-209 (2026-09-26, 21 días), PRY-203 (2026-09-23, 24 días) y PRY-208 (2026-09-30, 17 días) pasan el umbral de silencio de 15 días. Su RAID puede estar desactualizado.

### Después

Ofrezco, sin hacerlo: (1) subir a comité los 7 ítems de «Necesitan decisión ahora», cada uno con la decisión formulada; (2) proponer un doliente para cada ítem sin doliente. Propongo, no asigno; ese nombre lo pone el gerente o el comité.

---
**Pie de rigor.** Hecho con los documentos de la carpeta a 2026-10-17. Lo que no sé: quién es «el core» ni quién es el «equipo de seguridad»; si el texto repetido en varios proyectos es un problema común o plantilla; la probabilidad, el impacto, el doliente y la fecha de cada ítem (nadie los escribió); cuánto lleva cada ítem sin movimiento (no hay historial); y lo que se habló fuera de estos documentos. La reclasificación de riesgo a dependencia es mía, por la prueba de la taxonomía, y está sin confirmar. La verificación contra los originales es de quien lo lea; cada ítem remite al informe de su proyecto.
