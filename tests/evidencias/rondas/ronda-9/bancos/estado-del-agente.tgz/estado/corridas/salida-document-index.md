## Carpeta al 2026-10-17

**Documentos:** 71 · **Sin cambio:** 71 · **Hay que releer:** 0

### Cambió el contenido
Ninguno.

### Solo se reguardó
Ninguno. 0 documentos.

### Renombrado o movido
Ninguno.

### Ya no está
Ningún documento indexado desapareció.

### Citas que dejaron de resolver
Todas son del proyecto PRY-200: 14 campos citan documentos que no están en la carpeta.

| Proyecto | Campo | Documento citado |
|---|---|---|
| PRY-200 | identity.code | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.name | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.business_area | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.product | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.sponsor | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.manager | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | identity.committee | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | plan.start_date | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | plan.end_date | 10-plan/2026-05-28-cronograma-v1.xlsx |
| PRY-200 | plan.scope_summary | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | money.approved | 00-gobierno/2026-05-28-acta-constitucion.docx |
| PRY-200 | money.committed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-200 | money.executed | 20-seguimiento/2026-10-17-informe-avance.md |
| PRY-200 | money.projection | 20-seguimiento/2026-10-17-informe-avance.md |

El informe sigue mostrando estos datos como sustentados y ya no lo están. El índice no registra renombrados ni borrados que expliquen la falta, así que no hay corrección de citas que ofrecer.

### Formatos que no se pudieron leer
El índice no reportó ninguno.

### Siguiente paso
No hay documentos por releer ni proyectos por recomputar (`projects_to_recompute` vacío), así que no hace falta `/portfolio-scan`. Lo pendiente es PRY-200: aparece su acta de constitución, su cronograma o su informe de avance, o se retiran esas citas.
