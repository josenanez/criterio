# Corrida del 2026-10-17 · portfolio-wake

13 proyectos · 46 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 14 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `milestone_overdue` | 3 |
| `variance_cost` | 3 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 2 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

Barrido: 71 documentos, 0 cambiados, nada cruzó umbral. Confirmación: 5 preguntas formuladas, sin respuesta (sesión sin interfaz). Hallazgo: 14 citas pm_record de PRY-200 marcadas rotas por forma de ruta, archivos existen; no se tocó la ficha. No se corrió portfolio-scan ni report.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

## 2026-10-17

**Revisé:** 71 documentos · 0 cambiaron · 0 proyectos recalculados

Términos vigentes (versión 1.1, aceptados por José Francisco Ñáñez el 2026-10-17); no hizo falta registrarlos de nuevo. Peticiones en el servidor: ninguna.

### Lo que cruzó un umbral
Nada. La comparación contra el snapshot de hoy no trae cambios. Siguen abiertas las señales que ya estaban (58 en 11 de 13 proyectos); no se repiten aquí. Hoy no corrí `/portfolio-scan`, porque no hay documentos cambiados.

### Hallazgo de integridad (no es un umbral)
`index` reporta 14 citas rotas en PRY-200, todas en los campos `pm_record` (acta de constitución, cronograma v1 e informe de avance del 2026-10-17). Los tres archivos existen en la carpeta. El desajuste es de forma de ruta: la ficha publicada por el gerente cita con la ruta relativa al proyecto (`00-gobierno/…`) y el índice espera la ruta desde la raíz de documentos (`PRY-200-originación-digital/00-gobierno/…`). No toqué la ficha ni los datos: la declaración es del gerente. Queda para quien mantiene la publicación `pm-publish`.

### Peticiones atendidas
Ninguna.

### Preguntas (confirmación periódica, primera vez: sin respuestas previas)
Nadie respondió en esta corrida; quedan preguntadas hoy y no se repiten.
1. **Autoridad de los 13 proyectos** (`authority`): no está en ninguna ficha. ¿Quién la ejerce y en qué documento consta?
2. **PRY-209 Nómina electrónica:** 21 días sin documentos nuevos (umbral 15). ¿Sigue activo, o está pausado y con qué documento?
3. **PRY-208 Motor de decisión:** 17 días en silencio (umbral 15). ¿Qué estado tiene hoy y qué documento lo sustenta?
4. **PRY-203 Open Banking:** hay un cambio sin línea base asociada. ¿Quién lo aprobó y dónde consta?
5. **PRY-200 Originación digital:** la variación de costo supera el 10% y el estado declarado no coincide con la evidencia. ¿Qué documento respalda el estado que reporta el gerente?

**Vuelvo el 2026-10-18.** El informe de comité del 2026-10-24 toca el 2026-10-22.
