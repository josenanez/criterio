# Corrida del 2026-10-17 · portfolio-setup

3 proyectos · 71 documentos, 44 releídos y 27 sin cambio · 131 s · 25 hallazgos

| Señal | Hallazgos |
|---|---:|
| `commitment_overdue` | 8 |
| `milestone_met_without_evidence` | 4 |
| `commitment_undated` | 3 |
| `milestone_overdue` | 2 |
| `commitment_rescheduled` | 2 |
| `declared_vs_evidence` | 2 |
| `variance_cost` | 1 |
| `progress_vs_plan` | 1 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

0 preguntas (sesión sin interfaz; se tomaron los valores sugeridos). Minutos hasta el primer resultado: no medidos con reloj; corrida-inicio marcada al empezar los 3 proyectos. Encontró: 71 documentos en 13 proyectos; 3 proyectos leídos (PRY-200, 203, 201), 25 señales, 2 verdes contradichos.

Primera corrida: no hay una anterior contra la cual comparar.

## Lo que produjo

## Listo — Portafolio de proyectos

**Miré:** 71 documentos en 13 proyectos · formatos: .md 36, .docx 12, .pdf 10, .xlsx 10, .csv 1, .json 1, .txt 1 · más reciente: 2026-10-17
**Eres:** PMO del portafolio (propuesto: hay 13 proyectos)
**Te aviso:** dos días antes del comité semanal; el primero que dejé anotado es el 2026-10-24 (supuesto mío: los documentos muestran comités semanales, pero no una fecha fija)
**En:** presentación (valor por defecto)
**Términos:** aceptados por José Francisco Ñáñez para la versión 0.4.0 (términos 1.1) · comprobante en `.criterio/terminos/aceptacion-criterio-portfolio-0.4.0-2026-10-17.md` y `.pdf` · SHA-256 96015115a67f6c94… (md) y c7b81687bb0e2d29… (pdf)

Decisiones que tomé sin preguntar, porque no había quién respondiera: documentos en `documentos/proyectos`, lo que voy encontrando en `estado`, informes en `reportes`; en la configuración quedó el nombre «Portafolio de proyectos», que puedes cambiar cuando quieras.

### Probé con tres proyectos

Tomé los de documentación más reciente: PRY-200, PRY-203 y PRY-201. Las fichas quedaron en `estado/records/` y selladas.

| Proyecto | Documentos | Qué supe | Qué no está |
|---|---|---|---|
| PRY-200 Originación digital | 16 | Gerente Diana Molina, patrocinador Jorge Medina, 18.000 M COP aprobados, cierre 2027-06-04. Declara verde, 36 %. 26 compromisos de comité seguidos (acta del 2026-05-28, informe del 2026-10-17). Este proyecto publicó su propia `ficha-pm.json`; la guardé aparte, sin mezclarla con mi lectura. | Autoridad del gerente y etapa. Ningún proveedor ni contrato. |
| PRY-203 Open Banking | 6 | Gerente Óscar Ramírez, patrocinadora Sandra Gil, 6.800 M COP aprobados. Cierre 2027-03-30 según el cronograma v2 (la línea base original decía 2026-12-06). Declara verde, 60 %, con corte al 2026-09-23. | Autoridad y etapa. Quién autorizó CC-01: el documento dice «el comité» y no nombra a nadie. |
| PRY-201 Core de depósitos | 5 | Gerente Óscar Ramírez, patrocinadora Liliana Torres, 1.200 M COP aprobados, cierre 2026-11-22. Declara rojo, 29 %. | Autoridad y etapa. |

### Lo que levantó el cálculo

**PRY-200 Originación digital** (declara verde; 16 señales)
- El hito «Diseño funcional aprobado» venció el 2026-10-05, hace 12 días, y sigue «en curso».
- La proyección al cierre es 20.859 M COP contra 18.000 M aprobados: 15,9 % por encima.
- 8 compromisos vencidos sin acta. El más viejo es «Validar el ambiente 12» (Sandra Gil), 25 días. Carlos Peña tiene tres: ambiente 4 (22 días), punto 8 (7 días) y fecha 15 (2 días).
- 3 compromisos sin fecha: Liliana Torres (matriz 14), María Restrepo (punto 24) y Laura Vélez (ajuste del presupuesto).
- 2 compromisos reprogramados varias veces: «Enviar el documento 1» (Elena Duarte), 6 veces desde el 2026-09-25 hasta el 2026-12-05, y «Cerrar la prueba 2» (Ricardo Salas), 4 veces.
- La señal central: el gerente declara verde y el cálculo contradice ese verde con cuatro señales (compromisos vencidos, compromisos reprogramados, hito vencido y sobrecosto proyectado).
- En las notas del 2026-10-17 se comentó que el proveedor podría no llegar con el equipo completo y nadie lo registró como riesgo. Lo dejé en la ficha, citando las notas.

**PRY-203 Open Banking** (declara verde; 6 señales)
- Atraso de 114 días (46,2 %) contra la línea base original.
- El hito «Integración con el core» venció el 2026-10-05, hace 12 días, y sigue «en curso».
- «Diseño funcional aprobado» y «Ambiente de pruebas certificado» están declarados cerrados, sin acta de recibo.
- CC-01 (+114 días, +228 M COP) quedó autorizado sin línea base nueva que lo recoja.
- El verde, con corte al 2026-09-23 y 24 días de antigüedad, queda contradicho por esas señales.

**PRY-201 Core de depósitos** (declara rojo; 3 señales)
- Declara 29 % de avance, pero su cronograma tiene 3 de 4 hitos cerrados, lo que sustenta entre 75 y 100 %. Distancia: 46 puntos.
- «Ambiente de pruebas certificado» (2026-05-10) e «Integración con el core» (2026-08-16) están declarados cerrados sin acta. De «Diseño funcional aprobado» sí hay acta, firmada el 2026-10-12, ocho meses después de su fecha de cronograma (2026-02-01).

Entre los tres: 25 señales. Dos verdes contradichos (PRY-200 y PRY-203).
Los tres proyectos tienen la autoridad del gerente sin declarar. Ninguno tiene dependencias declaradas, aunque PRY-200 y PRY-203 listan como riesgo la dependencia del calendario de liberaciones del core.

### El portafolio completo

10 proyectos más (PRY-199, 202, 204 a 211) y 44 documentos, en un solo lote, uno tras otro. Calculo unos 20 a 30 minutos; es una estimación mía a partir de lo que costaron estos tres, no una medida.

### Lo que le falta a tu carpeta

- Sin cronograma: PRY-208, PRY-209 y PRY-211. Sin cronograma no hay hitos ni atraso que calcular.
- PRY-202 trae solo acta, cronograma e informe de avance.
- Las actas de recibo escasean: en los tres proyectos que leí, solo uno de los cinco hitos declarados cerrados trae el acta que lo prueba.
- Autoridad del gerente: ninguna de las tres actas leídas la trae.
- Las actas de constitución dicen «Dependencias: ninguna declarada», pero los informes de avance mencionan dependencias del core.
- Solo PRY-200 tiene ficha publicada por su gerente.
- `estado/PRY-200-originación-digital/` ya existía, creada por el agente de ese proyecto. La dejé como estaba; las fichas del portafolio van en `estado/records/`.

Ninguno de estos puntos es bloqueante.

### Siguiente paso

Puedo correr los 10 proyectos que faltan. Si tienes equipo de gerentes, también puedo publicar el estándar en una carpeta compartida para que usen los mismos criterios.
