**Sale de:** `00-gobierno/2026-05-19-contrato-ct-172.md`, `00-gobierno/2026-05-29-acta-constitucion.docx`, `10-plan/2026-05-29-cronograma-v1.xlsx`, `20-seguimiento/2026-10-08-acta-recibo-diseño-funcional-aprobado.md`, `20-seguimiento/2026-10-14-informe-avance.md`, `30-reuniones/2026-10-15-comite-semanal.md` (todos de PRY-205) y la salida de `portafolio.py compute`. Términos vigentes, aceptados por José Francisco Ñáñez el 2026-10-17.

## Proveedores — PRY-205 Prevención de lavado de activos al 2026-10-17

### Núcleo Financiero S.A. — contrato CT-172
**Vigencia:** sin dato (el contrato solo trae fecha de firma, 2026-05-19) · **Preaviso de no renovación:** sin dato · **Vence el:** sin dato

| Entregable | Comprometido | Estado | Evidencia | Facturado |
|---|---|---|---|---|
| Licenciamiento del motor | 2026-09-22 · COP 90.410.166 | `pending` (el contrato dice "pendiente") | ninguna | sin dato |
| Bolsa de horas de desarrollo | 2027-01-06 · COP 90.410.166 | `pending` (el contrato dice "en curso") | ninguna | sin dato |
| Parametrización del tarifario | 2027-04-22 · COP 90.410.166 | `pending` (el contrato dice "en curso") | ninguna | sin dato |

Entregables: 3. Aceptados: 0. Con fecha pasada y sin evidencia: 1. Declarados entregados o aceptados sin documento: 0.

### Dónde no cuadra
| Qué | Dice el contrato | Dice la evidencia | Fuentes |
|---|---|---|---|
| Licenciamiento del motor | Comprometido para 2026-09-22 | Sin acta de recibo ni mención de entrega; lleva 25 días de atraso | contrato CT-172; ficha PRY-205 |
| Estado "en curso" de la bolsa de horas y la parametrización | "en curso" | Ningún documento muestra trabajo ni recibo; se lleva como `pending`, no como avance | contrato CT-172 |
| Avance del proyecto | — | El informe del 2026-10-14 declara verde y 82%; el plan sustenta entre 20% y 40% (1 de 5 hitos cumplidos, brecha de 42,0 puntos). El único entregable del proveedor con fecha vencida está sin recibir | informe de avance 2026-10-14; cronograma v1 |

La condición de pago del contrato exige acta de recibo firmada por el gerente del proyecto para facturar cada entregable. La única acta de recibo en la carpeta (2026-10-08) es del hito interno "Diseño funcional aprobado", no de un entregable de CT-172.

### Sin evidencia de recibo
Ninguno está marcado como entregado o aceptado. Los tres están `pending`; no hay entregable aceptado sin evidencia.

### Compromisos del proveedor vencidos
| Qué | Prometido en | Para | Días |
|---|---|---|---|
| Laura Vélez: "Entregar el punto 31" | comité semanal 2026-10-15 | 2026-10-11 | 6 |

Nada en los documentos dice que Laura Vélez sea del proveedor ni qué es el "punto 31". Se lista porque es el único compromiso vencido del proyecto, no porque sea del proveedor. El proveedor no asistió al comité del 2026-10-15 (asistentes: Óscar Ramírez, Rubén Cárdenas).

### Sin dato
- **Facturado:** ningún documento declara facturas de Núcleo Financiero. Sin ese dato no se puede cruzar contra lo entregado ni levantar `vendor_invoiced_without_delivery`.
- **Vigencia, terminación, renovación automática y preaviso de CT-172:** el contrato no los trae. No se puede decir si hay un preaviso por vencer.
- **Total contractual:** no está declarado como total; solo hay tres montos por entregable.
- **Fase, producto y autoridad del proyecto:** no encontrados en la documentación.

### Qué sigue
- El licenciamiento del motor lleva 25 días vencido. Conviene pedir al gerente (Óscar Ramírez) que diga si se entregó y, si sí, el acta; si no, una nueva fecha del proveedor.
- Pedir a Finanzas lo facturado a CT-172, para cerrar el cruce.
- Pedir el contrato completo, con cláusulas de vigencia y renovación.
- El proyecto reporta verde con tres señales abiertas sin explicar (avance contra plan, compromiso vencido, entregable del proveedor vencido). Si se quiere llevar a comité, esa es la discrepancia.

*Pie de rigor: cifras copiadas de `portafolio.py compute` (as_of 2026-10-17). Lo que no está en los documentos se dice como "sin dato". Los documentos son la única fuente; no se sabe lo que se habló fuera de ellos. La verificación es suya.*
