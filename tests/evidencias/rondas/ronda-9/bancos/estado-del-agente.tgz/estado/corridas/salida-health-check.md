## Diagnóstico · Portal de proveedores (PRY-210) · 2026-10-17

**Leí:** 8 documentos · de 2025-09-01 a 2026-10-16 · formatos: docx (2), md (3), xlsx (1), pdf (2)
**No pude leer:** nada quedó sin leer. Los dos PDF (informe de avance y factura) y los dos docx los leí desde el texto convertido en caché (pdftotext / docx), no desde el original; la cita apunta al original. Busqué PRY-210, "Portal de proveedores", CT-882 y Talento Digital en las carpetas de los otros 11 proyectos: ninguna otra minuta ni documento lo menciona.

*Términos: vigentes (versión 1.1), aceptados por José Francisco Ñáñez el 2026-10-17.*

### Dictamen
**Sostenido:** 5 afirmaciones · **Sin sustento:** 9 · **Contradicho:** 3 (17 en total)

Desde esta carpeta se puede afirmar quién gobierna el proyecto, cuánto se aprobó, qué dos entregables del proveedor se recibieron con acta y que lo facturado coincide con lo recibido. No se puede afirmar que el proyecto esté en verde: el propio informe del 2026-10-16 que lo declara dice que la salida se reprogramó, el hito de salida a producción está vencido hace 9 días, y el avance declarado (52%) está 28 puntos por debajo de lo que sostiene el cronograma (80–100%). Ninguno de los cuatro hitos marcados como cumplidos tiene documento que lo pruebe. El estado "verde" no tiene a ningún documento detrás, y 5 señales abiertas lo contradicen.

| Dictamen | Afirmación | Base |
|---|---|---|
| Sostenido | Presupuesto aprobado 9.500.000.000 COP | Acta de constitución (2025-09-01) |
| Sostenido | Patrocinador Carlos Peña, gerente Rubén Cárdenas, Comité de Banca Empresas | Acta de constitución |
| Sostenido | Dos entregables de CT-882 recibidos (bolsa de horas, mesa de ayuda) | Dos actas de recibo firmadas por el gerente |
| Sostenido | Factura FV-1882 por 1.361.054.552 COP cubre solo lo recibido | Factura = 2 × 680.527.276; contrato; 2 actas |
| Sostenido | La salida a producción (2026-10-08) no ocurrió | Cronograma "en curso"; informe admite reprogramación |
| Contradicho | Estado verde | Hito vencido, avance, hitos sin evidencia, proveedor atrasado, compromiso vencido (ver abajo) |
| Contradicho | Avance 52% | Cronograma: 4 de 5 hitos "cerrado" (el plan sostiene 80–100%) |
| Contradicho | "Se reprogramó la salida" | Cronograma: fecha vigente = línea base = 2026-10-08; no hay solicitud de cambio ni línea base nueva |
| Sin sustento | Cuatro hitos cumplidos (diseño funcional, ambiente de pruebas, integración con el core, piloto) | Solo el cronograma; ningún acta ni certificado |
| Sin sustento | Comprometido 3.878.378.756 · ejecutado 2.965.535.146 · proyección 8.789.673.693 | Solo el informe; no hay extracto contable ni orden de compra |
| Sin sustento | Riesgos: dependencia del calendario de liberaciones del core; disponibilidad del equipo de seguridad | Solo el informe; ningún registro de riesgos |

### Gobierno
| | Qué dice el documento | Fuente |
|---|---|---|
| Patrocinador | Carlos Peña | Acta de constitución, 2025-09-01 |
| Gerente | Rubén Cárdenas | Acta de constitución, 2025-09-01 |
| Autoridad declarada | **No declarada.** El acta no dice qué puede aprobar el gerente en fechas o presupuesto | — |
| Comité | Comité de Banca Empresas (aprobó el presupuesto el 2025-09-01); el comité del 2026-10-14 reúne a Rubén Cárdenas y Carlos Peña | Acta; acta de comité 2026-10-14 |

El acta tiene el alcance sin llenar ("Componente 1, 2, 3"), "fuera de alcance: lo que otro proyecto cubre" y producto asociado "No aplica". Sin autoridad declarada no hay desviación aprobada: cualquier fecha nueva es una fecha que alguien escribió. Los datos de gobierno tienen 13 meses de antigüedad (umbral: 12) y nadie los ha reconfirmado.

### Contra el plan
Hay una sola línea base: v1, aprobada el 2025-09-01, con cierre el 2026-10-08. Replanificaciones registradas: 0. Desviación contra la original: 0 días; contra la vigente: 0 días. Cero porque el cronograma no refleja ninguna reprogramación, **no porque el proyecto vaya a tiempo**: el informe dice que la salida se reprogramó y no da la fecha nueva, y no existe solicitud de cambio, acta de comité que la apruebe ni línea base v2. El cronograma además tiene los cinco hitos con fecha vigente igual a la de línea base, nunca movidos.

### Hitos vencidos sin evidencia
| Hito | Fecha | Días | Qué documento se esperaría |
|---|---|---|---|
| Salida a producción (pendiente) | 2026-10-08 | 9 | Acta de salida, o solicitud de cambio aprobada con línea base nueva |
| Diseño funcional aprobado (declarado cumplido) | 2025-11-28 | 323 | Acta de recibo / aprobación del diseño |
| Ambiente de pruebas certificado (declarado cumplido) | 2026-02-15 | 244 | Certificado del ambiente |
| Integración con el core (declarado cumplido) | 2026-05-04 | 166 | Acta o evidencia de integración |
| Piloto con usuarios internos (declarado cumplido) | 2026-07-22 | 87 | Acta de recibo del piloto |

Los otros proyectos de esta carpeta sí traen actas de recibo para hitos equivalentes; este no trae ninguna para los cuatro hitos.

### Dinero (COP)
| Aprobado | Comprometido | Ejecutado | Proyección | Disponible real |
|---|---|---|---|---|
| 9.500.000.000 | 3.878.378.756 | 2.965.535.146 | 8.789.673.693 | 5.621.621.244 |

Ejecutado: 31,2% del aprobado. Comprometido: 40,8%. Proyección: 7,5% por debajo del aprobado. Las tres cifras salen del informe de avance; ningún documento independiente las respalda. Lo único comprobable es el proveedor: CT-882 factura 1.361.054.552 COP (FV-1882, 2026-08-30) y ese monto coincide con lo recibido por acta (2 entregables de 680.527.276). Con el contrato y la factura no puedo explicar el resto de lo ejecutado ni de lo comprometido; faltan los demás contratos u órdenes. Que el contrato sume cuatro entregables y el comprometido sea otra cifra es una pregunta para el gerente; no la calculo porque el script no la da.

Proveedor Talento Digital S.A.S. (CT-882), 2 de 4 entregables recibidos:
- **Licenciamiento del motor**: vencido 2025-12-06, pendiente, 315 días.
- **Parametrización del tarifario**: vencido 2026-05-28, pendiente, 142 días (el contrato lo marca "en curso").
- Bolsa de horas: debía el 2026-03-02, recibida el 2026-03-18. Mesa de ayuda del primer trimestre: debía el 2026-08-22, recibida el 2026-08-30. Ambas con acta; ambas recibidas después de la fecha contractual.
- Señalo, sin concluir: se recibió una mesa de ayuda y se facturó, mientras el licenciamiento del motor sigue sin recibirse, y el piloto se declara cumplido (2026-07-22) con ese licenciamiento pendiente.

### Lo que se dijo y nadie registró
- **Compromiso vencido:** Andrés Lozano, "Entregar el punto 7", para el 2026-09-25: 22 días vencido, sin evidencia de entrega. El acta de comité del 2026-10-14 lo registra con una fecha anterior a la propia reunión y sin explicar qué es el "punto 7".
- **Compromiso abierto:** Liliana Torres, "Entregar el punto 25", para el 2026-11-14. Tampoco se sabe qué es.
- Ninguno de los dos responsables figura como asistente (asistieron Rubén Cárdenas y Carlos Peña). El acta lista "Avance" como tema pero no contiene lo tratado.
- **Incidencia sin dueño ni fecha:** la reprogramación de la salida (informe de avance). No tiene responsable, fecha nueva ni causa más allá de "ventana de cambio del área de operaciones".
- **Dependencia no declarada:** el informe cita como riesgo la dependencia del calendario de liberaciones del core; el acta de constitución dice "Ninguna declarada". Es una dependencia, no un riesgo, y no está en ningún registro.
- No existe registro RAID del proyecto en la carpeta.

### Contradicho
| Afirmación | Documento A | Documento B |
|---|---|---|
| Estado verde | Informe de avance 2026-10-16: "Verde" | Mismo informe: la salida se reprogramó; cronograma: salida vencida 9 días; el plan sostiene 80–100% de avance contra 52% declarado |
| Avance 52% | Informe 2026-10-16: 52% | Cronograma v1: 4 de 5 hitos "cerrado" |
| La salida se reprogramó | Informe 2026-10-16 | Cronograma v1: fecha vigente 2026-10-08, igual a la línea base; ningún documento de cambio |

Una de las dos lecturas del avance es falsa: o hay cuatro hitos cumplidos (y 52% está mal) o el avance real es cercano a 52% (y los hitos están marcados cumplidos sin haberlo estado). Esta carpeta no permite saber cuál.

### Sin sustento
- Los cuatro hitos "cerrado" del cronograma: el cronograma es la única fuente y es un documento de plan, no evidencia de recibo.
- Comprometido, ejecutado y proyección al cierre: solo el informe, que escribe quien está siendo evaluado.
- Los dos riesgos abiertos (core, equipo de seguridad): sin dueño, valoración ni fecha.
- El criterio de éxito "Portal de proveedores en producción y medido": sin métrica ni línea de partida.
- Alcance: tres componentes sin nombre.

### Lo que esta carpeta no permite saber
- **Si el proyecto va a tiempo.** Falta la fecha nueva de salida y el documento que la apruebe; sin autoridad declarada no sabemos quién puede aprobarla.
- **Si los cuatro hitos pasados ocurrieron.** Faltan las actas de recibo; consecuencia: no se puede sostener el 80–100% del plan ni explicar el 52%.
- **Cuánto se ha gastado de verdad.** Faltan extractos contables y los demás contratos; consecuencia: el disponible real de 5.621.621.244 COP es aritmética sobre cifras declaradas.
- **Qué contiene el alcance.** Componentes sin nombre: consecuencia: no hay forma de medir si "Salida a producción" cumple el alcance.
- **Qué se trató en el comité.** Acta sin contenido sobre el avance; consecuencia: el comité no deja rastro de haber visto el estado.
- **Producto, fase y autoridad del gerente**: no encontrados.

Este diagnóstico no recomienda detener, continuar ni reestructurar; esa decisión es de quien tiene la facultad. Puedo preparar el punto de comité con la lista de lo que falta, o llevar las contradicciones al gerente como preguntas, una por una:
1. ¿Cuál es la fecha nueva de salida y quién la aprobó?
2. ¿Dónde están las actas de los cuatro hitos cerrados?
3. ¿Qué respalda el 52% si el cronograma da cuatro de cinco hitos cerrados?
4. ¿Por qué se recibió y facturó la mesa de ayuda con el licenciamiento y la parametrización sin recibir?

### Pie de rigor
Borrador de trabajo, no decisión ni asesoría. Se basa solo en los 8 documentos citados de la carpeta de PRY-210; no sabe lo que se habló fuera de ellos. Las cifras derivadas (días, porcentajes, conteo de señales, disponible real) salen de `portafolio.py compute` al 2026-10-17; las demás se copian de los documentos. La verificación de cada cita es suya.
