# Corrida del 2026-10-17 · project-closure

13 proyectos · 31 s · 58 hallazgos

| Señal | Hallazgos |
|---|---:|
| `milestone_met_without_evidence` | 14 |
| `commitment_overdue` | 11 |
| `declared_vs_evidence` | 8 |
| `progress_vs_plan` | 7 |
| `milestone_overdue` | 3 |
| `variance_cost` | 3 |
| `commitment_undated` | 3 |
| `vendor_deliverable_late` | 3 |
| `commitment_rescheduled` | 2 |
| `silent` | 2 |
| `variance_time` | 1 |
| `change_without_baseline` | 1 |

Cierre no determinable: sin declaración de cierre, sin evidencia de producción ni medición, 3 hitos sin acta, alcance recortado sin decisión, sobrecosto proyectado 22% sin cambio aprobado. Sin lecciones sustentables; sin dato de doliente de lo abierto.

Contra la corrida del 2026-10-17: +0 hallazgos.

## Lo que produjo

Cierre de PRY-207 · Onboarding PyME · 2026-10-17
Sale de la ficha estado/records/PRY-207.json y de cuatro documentos: acta de constitución (2025-07-15), cronograma v1 (2025-07-15), acta de recibo del piloto (2026-10-04) e informe de avance (2026-10-06). Las cifras salen de `portafolio.py compute`. Términos vigentes: los aceptó José Francisco Ñáñez el 2026-10-17 (versión 1.1).

## Cierre — PRY-207 Onboarding PyME — 2026-10-17

**Resumen: el proyecto no está en condiciones de cerrarse contra su criterio de éxito.** Ningún documento declara que terminó, y el último informe lo reporta en rojo con 76 % de avance. Si se cierra hoy, sería por decisión y no por cumplimiento. Esa decisión no está registrada.

### Contra lo comprometido
**Criterio de éxito:** "Onboarding PyME en producción y medido." (acta de constitución, 2025-07-15, sección Criterio de éxito.)
**Se cumplió:** no se puede determinar. Ningún documento menciona puesta en producción ni medición. El último hito del cronograma es un piloto con usuarios internos, que no equivale a producción.

| Entregable comprometido | Estado | Evidencia |
|---|---|---|
| Diseño funcional aprobado (línea base 2025-11-02) | El cronograma lo marca "cerrado" | Sin acta de recibo en la carpeta |
| Ambiente de pruebas certificado (línea base 2026-02-10) | Cerrado según el cronograma | Sin acta de recibo |
| Integración con el core (línea base 2026-05-21) | Cerrado según el cronograma | Sin acta de recibo |
| Piloto con usuarios internos (línea base 2026-08-29) | Recibido | Acta de recibo del 2026-10-04, firmada por Beatriz Cuéllar, que es la gerente del proyecto |
| Onboarding PyME en producción y medido (criterio de éxito) | No hay hito ni evidencia | — |

Los tres primeros hitos aparecen como cumplidos sin evidencia de recibo. El script los señala con 349, 249 y 149 días de vencidos sin sustento. El piloto sí tiene acta, pero la fecha de recibo (2026-10-04) es posterior a la fecha de línea base (2026-08-29). El cronograma no registra ese corrimiento: muestra fecha vigente igual a la original.

### Fuera de alcance final
| Qué quedó fuera | Decidido por | Cuándo |
|---|---|---|
| Dos historias fuera del alcance del sprint por dependencia con el core (informe 2026-10-06) | Sin decisión registrada | Sin dato |

Es un hallazgo del cierre: hay alcance recortado sin decisión documentada. El acta define el alcance solo como "Componente 1, 2 y 3", sin desglose. Por eso no se puede saber si esas historias pertenecen a un componente comprometido.

### Números finales
| | Original | Vigente | Final | Desviación vs original |
|---|---|---|---|---|
| Fecha de cierre | 2026-08-29 | 2026-08-29 | Sin cierre declarado | 0 días registrados contra la línea base. El script no ve que el cronograma no se movió pese al piloto recibido el 2026-10-04 |
| Presupuesto aprobado | 18.000.000.000 COP | 18.000.000.000 COP | Proyección al cierre: 21.962.012.879 COP | +22,0 % sobre lo aprobado |

- Comprometido: 14.120.349.319 COP (78,4 % del aprobado).
- Ejecutado: 5.521.092.051 COP (30,7 %).
- Disponible real: 3.879.650.681 COP.
- Replanificaciones: 0. Solicitudes de cambio: 0. No hay control de cambios registrado, y el sobrecosto proyectado tampoco tiene aprobación documentada.
- Avance declarado: 76 %. El plan marca 4 de 4 hitos cumplidos, así que el plan sostiene 100 %. La diferencia es de 24 puntos.

### RAID al cierre
**Materializados:** la única incidencia registrada es "dos historias fuera del alcance del sprint por dependencia con el core" (desde 2026-10-06). No hay registro RAID formal que permita decir qué riesgos se materializaron.
**No materializados:** sin dato.
**Abiertos, con doliente:** ninguno tiene doliente con nombre.
- Riesgo: disponibilidad del equipo de seguridad para la revisión final.
- Riesgo: dependencia del calendario de liberaciones del core.
- Incidencia: las dos historias fuera del sprint.

Lo abierto sin doliente no está cerrado.

### Lecciones
No entra ninguna lección. Los documentos no sustentan un hecho con fecha y efecto que sirva de lección. Lo que hay son hallazgos de gobierno, no aprendizajes:
- Hitos marcados como cumplidos sin acta de recibo.
- Piloto recibido 2026-10-04 contra línea base 2026-08-29, sin replanificación.
- Sobrecosto proyectado de 22,0 % sin cambio aprobado.
- Alcance recortado sin decisión.

Una lección sobre cualquiera de ellos exige primero conocer la causa, y esa causa no está en los documentos.

### Sin dato
- Declaración de cierre y quién la hace.
- Evidencia de producción y de medición, que son el criterio de éxito.
- Actas de recibo de los hitos 1 a 3.
- Quién decidió dejar fuera las dos historias, y cuándo.
- Aprobación del sobrecosto proyectado.
- Doliente de los riesgos y de la incidencia abiertos.
- Autoridad que aprueba cambios y fase del proyecto (no figuran en el acta).
- Fecha real de cada hito, salvo el piloto.

### Después
No muevo la carpeta a `archivo/` ni congelo la ficha. El proyecto no está cerrado y archivarlo lo sacaría del barrido diario con tres señales abiertas: avance contra plan, hitos sin evidencia y sobrecosto. Antes de archivar hace falta que alguien con autoridad declare el cierre y que el Comité de Arquitectura decida sobre el alcance recortado y el sobrecosto.

Rigor: toda cifra derivada viene de `portafolio.py compute`. Los días de atraso del piloto no los calculé, porque el script no los da. No se leyó ningún documento fuera de los cuatro citados. La verificación es suya.
