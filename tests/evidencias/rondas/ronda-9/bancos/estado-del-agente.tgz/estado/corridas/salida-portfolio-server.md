# Rostrum — modo «para mirarlo un rato»

**Términos:** ya vigentes para esta versión (0.4.0), aceptados por José Francisco Ñáñez el 2026-10-17. Nota legal: https://www.josenanez.com/es/agents/criterio-pmo/legal#v0.4.0

**Pregunta de modo:** sin nadie que responda, se toma la respuesta sugerida: empezar por «para mirarlo un rato». Se levanta en diez segundos, se ve funcionando, y la conversación con seguridad llega después con algo en la mano.

**Informe:** hay informe HTML en `reportes/` (portada, proyectos, productos, decisiones y 13 proyectos PRY-199 a PRY-211). Rostrum no lo genera, lo sirve.

**Comando:**

    python3 "/home/claude/banco/criterio/plugins/criterio-portfolio/scripts/servidor.py" --informe reportes --estado estado --config .criterio/portafolio/config.json

Escucha en `127.0.0.1:8787`, solo en este equipo. Se para con Ctrl-C. Si el puerto está ocupado: `--puerto 8788`.

| Ruta | Qué es | Para quién |
|---|---|---|
| `/` | Portada con las secciones y el formulario de peticiones | Todos |
| `/pmo` | Cómo va el portafolio: verdes sin sustento, silencios, patrocinadores repetidos | La PMO |
| `/decisiones` | Lo que necesita decisión, con la consecuencia de no decidir | Comité y patrocinador |
| `/proyectos` | Listado por lo que más pide atención | Todos |
| `/p/<código>` | Informe de un proyecto, con enlace a su producto | Quien gerencia |
| `/productos` | Listado de productos y proyectos sin producto declarado | Quien responde por un producto |
| `/producto/<nombre>` | Informe de un producto, con enlace a sus proyectos | Quien responde por un producto |
| `/estado.json` | Fecha del informe y peticiones abiertas | Un mecanismo |

El enlace proyecto ↔ producto va en los dos sentidos: quien entra por el producto puede descubrir que lo construyen proyectos de comités distintos.

**Lo que Rostrum no hace:** no calcula (sirve lo que `informe.py` ya escribió), no escribe fichas (solo crea peticiones en `estado/peticiones/`), no autentica y no manda correos.

**Para que quede corriendo** (más adelante): `--abierto`, que escucha fuera del equipo y **no trae autenticación, a propósito**. Hay que pedir: un host y un puerto dentro de la red; publicarlo detrás del control de acceso que ya usa la organización; que el equipo siga encendido. Nada más: ni base de datos, ni certificado, ni salida a internet.

**Cierre:** el enlace `http://127.0.0.1:8787/` es solo para quien lo levanta. El informe es del 2026-10-17; la portada indica su fecha, así que conviene regenerarlo con `/portfolio-report html` antes de mostrárselo al patrocinador.
